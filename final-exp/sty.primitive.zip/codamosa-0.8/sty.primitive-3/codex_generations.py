

# Generated at 2022-06-12 09:50:01.066417
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Unit-test for method `as_dict` of class `Register`.
    """
    r = Register()
    setattr(r, "red", Style(value="\x1b[31m"))
    setattr(r, "green", Style(value="\x1b[32m"))
    setattr(r, "blue", Style(value="\x1b[34m"))
    setattr(r, "none", Style(value=""))

    d = r.as_dict()

    assert isinstance(d, dict)
    assert isinstance(d["red"], str)
    assert isinstance(d["green"], str)
    assert isinstance(d["blue"], str)
    assert isinstance(d["none"], str)



# Generated at 2022-06-12 09:50:02.912305
# Unit test for constructor of class Style
def test_Style():
    # Check if isinstance(Style, str) is True
    assert isinstance(Style(), str)



# Generated at 2022-06-12 09:50:14.573291
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Test1: A register with a custom render-function and an RgbFg-rendertype
    r = Register()
    r.set_renderfunc(RenderType, lambda red, green, blue: f"{red}-{green}-{blue}")
    r.set_rgb_call(RenderType)

    assert r(42, 23, 11) == "42-23-11"

    # Test2: A register with a custom render-function and an RgbFg-rendertype
    r = Register()
    r.set_renderfunc(RenderType, lambda red, green, blue: f"{red}-{green}-{blue}")
    r.set_rgb_call(RenderType)

    assert r(42, 23, 11) == "42-23-11"


# Generated at 2022-06-12 09:50:20.292352
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Setup fixture.
    mock_class = namedtuple("MockClass", ["__name__"])
    mock_type = mock_class("MockClass")
    mock_renderfunc = lambda x: "mock_result"
    mock_register = Register()
    mock_register.set_renderfunc(mock_type, mock_renderfunc)

    # Test register object with new render type.
    mock_register.set_eightbit_call(mock_type)
    assert mock_register(2) == "mock_result"



# Generated at 2022-06-12 09:50:30.998016
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbBg, RgbFg
    from .renderfunc import rgb_to_ansi_seq

    r = Register()

    r.set_renderfunc(RgbFg, rgb_to_ansi_seq)
    r.set_renderfunc(RgbBg, rgb_to_ansi_seq)

    # RGB-Call
    r.custom_attr = Style(RgbFg(1, 2, 3))

    assert r("custom_attr") == "\x1b[38;2;1;2;3m"

    # Eightbit-Call
    r.set_eightbit_call(RgbBg)
    r.custom_attr2 = Style(RgbBg(10, 10, 10))

# Generated at 2022-06-12 09:50:39.597496
# Unit test for method __call__ of class Register
def test_Register___call__():

    rg = Register()
    rg.red = Style(RgbFg(255, 0, 0), Sgr(1), value="\x1b[38;2;255;0;0m\x1b[1m")

    assert rg("red") == "\x1b[38;2;255;0;0m\x1b[1m"

    rg.green = Style(RgbFg(0, 255, 0), Sgr(1), value="\x1b[38;2;0;255;0m\x1b[1m")
    assert rg("green") == "\x1b[38;2;0;255;0m\x1b[1m"
    assert rg("blue") == ""

# Generated at 2022-06-12 09:50:47.108270
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Default register (fg)
    assert fg.rgb_call == RgbFg()

    # New default rendertype
    fg.set_rgb_call(RgbFg)
    assert fg.rgb_call == RgbFg()

    # Custom rendertype
    fg.set_renderfunc(RgbBg, lambda r,g,b: "\x1b[48;2;{0};{1};{2}m".format(r,g,b))
    fg.set_rgb_call(RgbBg)
    assert fg.rgb_call == RgbBg()


# Generated at 2022-06-12 09:50:51.787122
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import sty

    fg = sty.fg
    fg.red = sty.Style(fg.red, sty.Bold)

    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"

    assert fg.red == fg.as_namedtuple().red

# Generated at 2022-06-12 09:50:56.962502
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, lambda x: x)

    r.mute()
    r.unmute()

    assert r.is_muted == False

    r.mute()

    assert r.is_muted == True



# Generated at 2022-06-12 09:51:06.868602
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class FakeRenderType(RenderType):
        pass
    func = lambda x: x

    # Create register object
    reg = Register()

    # Check if register does not have an eightbit_call function.
    assert not hasattr(reg, "eightbit_call")

    # Set a renderfunc for the fake render type
    reg.set_renderfunc(FakeRenderType, func)

    # Check if register does not have an eightbit_call function.
    assert not hasattr(reg, "eightbit_call")

    # Set the eightbit_call
    reg.set_eightbit_call(FakeRenderType)

    # Check if new eightbit_call function exists in register
    assert hasattr(reg, "eightbit_call")

    # Check if eightbit_call function returns the correct value
    assert reg.eightbit_call(42)

# Generated at 2022-06-12 09:51:09.794330
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    pass

# Generated at 2022-06-12 09:51:17.674687
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    def rgb_fg(r, g, b) -> str:
        return "\x1b[38;2;%d;%d;%dm" % (r, g, b)

    def rgb_bg(r, g, b) -> str:
        return "\x1b[48;2;%d;%d;%dm" % (r, g, b)

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg)
    r.set_renderfunc(RgbBg, rgb_bg)

    # Setup
    r.orange = Style(RgbFg(1, 5, 10))
    r.red = Style(RgbBg(1, 5, 10))

    # Test
    r.set_

# Generated at 2022-06-12 09:51:27.672553
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .ansi import RgbFg, RgbBg
    from .sgr import Sgr
    from .xterm256 import XtermFg

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(XtermFg, lambda x: f"\x1b[38;5;{x}m")
    fg.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    fg.red = Style(RgbFg(255, 0, 0))

    assert str(fg.red) == "\x1b[38;2;255;0;0m"

   

# Generated at 2022-06-12 09:51:33.308541
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class FakeRegister(Register):
        pass

    r = FakeRegister()
    r.red = "red"
    r.green = "green"
    r.blue = "blue"
    assert r.as_namedtuple().red == "red"
    assert r.as_namedtuple().green == "green"
    assert r.as_namedtuple().blue == "blue"

# Generated at 2022-06-12 09:51:39.681584
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg, Sgr

    r1 = Style(Sgr(1), RgbFg(10, 20, 30))
    assert isinstance(r1, str)
    assert isinstance(r1, Style)
    assert r1.rules == (Sgr(1), RgbFg(10, 20, 30))
    assert str(r1) == "\x1b[1m\x1b[38;2;10;20;30m"

# Generated at 2022-06-12 09:51:44.079213
# Unit test for method copy of class Register
def test_Register_copy():
    from .modifiers import Sgr
    from .rendertypes import RgbBg

    register = Register()
    register.test_style = Style(RgbBg(255, 0, 0), Sgr(1))

    register2 = register.copy()

    assert register2.test_style == "\x1b[48;2;255;0;0m\x1b[1m"

# Generated at 2022-06-12 09:51:51.770440
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.test = Style(RgbFg(0,0,0))

    assert r.test == "\x1b[38;2;0;0;0m"
    assert r.test.rules[0].__class__ == RgbFg

    r.set_rgb_call(RgbBg)
    assert r.test == "\x1b[38;2;0;0;0m"
    assert r.test.rules[0].__class__ == RgbBg


# Generated at 2022-06-12 09:52:01.189090
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr

    # Create register
    register = Register()

    # Set values
    register.bold = Style(Sgr(1))
    register.red = Style(Sgr(31))
    register.bg_red = Style(Sgr(41))

    # Mute register
    register.mute()

    # Test for muted register
    assert register.bold == ""
    assert register.red == ""
    assert register.bg_red == ""

    # Unmute register
    register.unmute()

    # Test for muted register
    assert register.bold == "\x1b[1m"
    assert register.red == "\x1b[31m"
    assert register.bg_red == "\x1b[41m"

# Generated at 2022-06-12 09:52:10.176205
# Unit test for method copy of class Register
def test_Register_copy():

    import textwrap
    from .register import fg, bg, ef, rs

    fg_blue = fg.blue

    r1 = fg
    r2 = r1.copy()

    assert fg_blue == r1.blue
    assert fg_blue == r2.blue

    assert id(fg) != id(r2)

    r1.green = Style(RgbBg(15, 255, 0), RgbFg(150, 0, 150))

    assert r1.green != r2.green

    r2.darkgreen = Style(RgbFg(0, 78, 0))

    assert hasattr(r1, "darkgreen") == False
    assert hasattr(r2, "darkgreen") == True

    # test if register is deepcopied

# Generated at 2022-06-12 09:52:20.991850
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Define test functionality
    def _test_func(r, g, b, *args):
        return f"test_func({r}, {g}, {b}, *{args})"

    # Define test rendertype
    A = RenderType(name="A", func=_test_func)

    # Create register object with test renderfunc
    reg = Register()
    reg.set_renderfunc(A, _test_func)

    # Set rendertype for rgb calls
    reg.set_rgb_call(A)

    # Call register with 20, 30, 40
    result = reg(20, 30, 40)

    assert result == "test_func(20, 30, 40, *())"

    # Call register with 100, 200, 200, {'a': 1, 'b': 2}

# Generated at 2022-06-12 09:52:25.933746
# Unit test for method __new__ of class Style
def test_Style___new__():

    s = Style(fg=15, ef=1, value="\x1b[38;5;15m\x1b[1m")

    assert isinstance(s, Style)



# Generated at 2022-06-12 09:52:31.905377
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.test1 = Style(value="Testvalue1")
    r.test2 = Style(value="Testvalue2")
    r.test3 = Style(value="Testvalue3")
    t = r.as_namedtuple()
    assert t.test1 == "Testvalue1"
    assert t.test2 == "Testvalue2"
    assert t.test3 == "Testvalue3"

# Generated at 2022-06-12 09:52:39.212279
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from sty.ansi import parse_ansi_color

    c1 = (0, 0, 0)
    c2 = (255, 255, 255)
    c3 = (255, 0, 0)
    c4 = (0, 255, 0)
    c5 = (0, 0, 255)

    RgbBg = NamedTuple("RgbBackgroundColor", [("r", int), ("g", int), ("b", int)])
    RgbFg = NamedTuple("RgbForegroundColor", [("r", int), ("g", int), ("b", int)])

    def render_rgb_fg(r: int, g: int, b: int):
        return parse_ansi_color(r, g, b)


# Generated at 2022-06-12 09:52:46.683614
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    import pytest
    from sty.sgr import FgBg, Sgr


    class MockRenderType(RenderType):
        def __init__(self, arg1, arg2):
            super().__init__(arg1, arg2)

        def render_ansi(self, **kwargs):
            return "TEST"

    def renderfunc(rendertype: MockRenderType, **kwargs):
        return rendertype.render_ansi(**kwargs)

    r = Register()

    r.set_renderfunc(Sgr, renderfunc)
    r.set_renderfunc(FgBg, renderfunc)
    r.set_renderfunc(MockRenderType, renderfunc)

    sgr = Sgr(1)
    fgbg = FgBg(1, 2)
    mrt = MockRender

# Generated at 2022-06-12 09:52:49.166032
# Unit test for constructor of class Register
def test_Register():

    r = Register()
    assert r.eightbit_call is not None
    assert r.rgb_call is not None
    assert r.renderfuncs is not None
    assert r.is_muted is False

# Generated at 2022-06-12 09:52:59.244448
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Verify if we can use a register-object like a function.
    """
    import sty

    # Here we define some custom renderfunc for the register-object.
    def sgr_renderfunc(*args: Any) -> str:
        return f"{args[0]}"

    # The sgr-function requires an integer as input.
    # Therefore we have to cast the input from string to integer.
    def sgr_call(*args: Union[str, int], **kwargs) -> str:
        return sgr_renderfunc(int(*args))

    # Create a copy of the default register-object 'ef'.
    my_ef = sty.ef.copy()

    # Attach the custom renderfunc to the register-object.
    my_ef.set_renderfunc(sty.Sgr, sgr_renderfunc)

    #

# Generated at 2022-06-12 09:53:09.759632
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test method Register.as_namedtuple.
    """

    class TestRegister(Register):
        """
        Test register class.
        """

        def __init__(self):
            super().__init__()

    test_reg = TestRegister()

    # Create some styles.
    test_reg.teststyle = Style("teststyle")
    test_reg.teststyle2 = Style("teststyle2")
    test_reg.teststyle3 = Style("teststyle3")

    # Check if the derived namedtuple has the same properties as the register.
    assert test_reg.as_namedtuple().teststyle == "teststyle"
    assert test_reg.as_namedtuple().teststyle2 == "teststyle2"
    assert test_reg.as_namedtuple().teststyle3 == "teststyle3"



# Generated at 2022-06-12 09:53:18.169642
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Create a new register-object
    r = Register()

    # Add register functions for two render types
    r.set_renderfunc(str, lambda x: x + "A")
    r.set_renderfunc(int, lambda x: x + 1)

    # Create some styles
    s1 = Style(str("a"))
    s2 = Style(int(5))

    # Add styles to the register
    r.a = s1
    r.b = s2

    # Confirm that styles are rendered correctly
    assert str(r.a) == "aA"
    assert str(r.b) == "6"

    # Change the render functions
    r.set_renderfunc(str, lambda x: x + "B")
    r.set_renderfunc(int, lambda x: x + 2)

    # Confirm

# Generated at 2022-06-12 09:53:27.944054
# Unit test for method mute of class Register
def test_Register_mute():
    import sty

    sty.config.setup(sty.config.StyleConfig())
    sty.config.setup(sty.config.StyleConfig(False))
    sty.config.setup(sty.config.StyleConfig(False), sty.config.StyleConfig())

    b1 = sty.fg.blue
    b2 = sty.fg.blue
    b3 = sty.fg.blue

    f1 = sty.ef.reset
    f2 = sty.ef.reset
    f3 = sty.ef.reset

    assert str(b1) == ""
    assert str(b2) == ""
    assert str(b3) == ""

    assert str(f1) == ""
    assert str(f2) == ""
    assert str(f3) == ""



# Generated at 2022-06-12 09:53:38.151155
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from sty import RenderType, fg, bg
    from sty.ansitowin32 import AnsiToWin32

    rendertype = RenderType()

    class RgbFg(RenderType):
        code = 38
        args = ('r', 'g', 'b')

    class Sgr(RenderType):
        code = 1
        args = ('r', 'g', 'b')

    def rgb_call(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{r};{g};{b}m".format(r=r, g=g, b=b)

    def sgr_call(*args) -> str:
        return "\x1b[1m"

    r1 = Register()
    r1.set_renderfunc(rendertype, rgb_call)

# Generated at 2022-06-12 09:53:51.649513
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class TestRegister(Register):
        pass

    tr = TestRegister()

    tr.test1 = Style()
    tr.test2 = Style()

    tr.test1 = Style(RgbFg(255, 255, 255))
    tr.test2 = Style(RgbFg(0, 0, 0))

    test_register = tr.as_namedtuple()

    assert isinstance(test_register, namedtuple)

    assert hasattr(test_register, "test1")
    assert hasattr(test_register, "test2")

    assert hasattr(test_register, "test1")
    assert hasattr(test_register, "test2")

    assert test_register.test1 == "\x1b[38;2;255;255;255m"

# Generated at 2022-06-12 09:53:53.832038
# Unit test for method __new__ of class Style
def test_Style___new__():

    assert issued_new_style == rendered_style
    assert new_style.rules == TestStyle.rules


# Generated at 2022-06-12 09:54:03.957894
# Unit test for method mute of class Register
def test_Register_mute():

    import colorama

    colorama.init()

    class MyRenderType(RenderType):
        pass

    trenderfunc = lambda *args: colorama.Fore.BLACK + colorama.Style.NORMAL

    r = Register()

    r.set_renderfunc(MyRenderType, trenderfunc)

    r.blue = Style(MyRenderType())
    r.red = Style(MyRenderType(bold=True))

    r2 = r.copy()

    assert r2.blue == colorama.Fore.BLUE + colorama.Style.NORMAL
    assert r2.red == colorama.Fore.RED + colorama.Style.BRIGHT

    r2.mute()

    assert r2.blue == ""
    assert r2.red == ""

    r2.unmute()

    assert r2.blue == colorama

# Generated at 2022-06-12 09:54:14.202088
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Unit test for method as_namedtuple of class Register
    """
    from . import sty, rs

    sty.fg.red = Style(sty.RgbFg(255, 0, 0))

    sty.bg.red = Style(sty.RgbBg(255, 0, 0))

    sty.ef.red = Style(sty.RgbEf(255, 0, 0))

    styled = sty.fg.red("styled")

    print(styled)

    print("Styled with namedtuple:")

    styled = sty.bg.red("styled")

    print(styled)

    sty.fg.red = sty.fg.red.as_namedtuple()

    sty.bg.red = sty.bg.red.as_namedtuple()

    sty.ef.red = sty.ef

# Generated at 2022-06-12 09:54:20.903240
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from . import RgbBg, RgbFg, Sgr

    r1 = Register()

    r1.set_renderfunc(Sgr, lambda x: f"Sgr{x}")
    r1.set_renderfunc(RgbFg, lambda r, g, b: f"RgbFg{r}_{g}_{b}")
    r1.set_renderfunc(RgbBg, lambda r, g, b: f"RgbBg{r}_{g}_{b}")

    r1.black = Style(RgbFg(0, 0, 0), Sgr(1))
    r1.blau = Style(RgbBg(50, 50, 200), Sgr(4))

    assert r1.black == "RgbFg0_0_0_Sgr1"
   

# Generated at 2022-06-12 09:54:25.908133
# Unit test for constructor of class Style
def test_Style():
    s: Style = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == '\x1b[38;2;1;5;10m\x1b[1m'

# Generated at 2022-06-12 09:54:27.143448
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    This test is just a placeholder.
    """
    pass

# Generated at 2022-06-12 09:54:36.821589
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Setup test
    from .rendertype import RgbBg, RgbFg, Sgr
    from .register import FG, BG, EF, RS

    def mocked_render_function(c):
        return f"{c}"

    FG.set_renderfunc(RgbFg, mocked_render_function)
    BG.set_renderfunc(RgbBg, mocked_render_function)
    FG.set_eightbit_call(RgbFg)
    BG.set_eightbit_call(RgbBg)

    FG.mute()
    BG.mute()
    EF.mute()
    RS.mute()

    FG.green = Style(RgbFg(42, 42, 42))
    BG.white = Style(RgbBg(255, 255, 255))

# Generated at 2022-06-12 09:54:43.406233
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Bla(RenderType):
        pass

    class Foo(RenderType):
        pass

    class Bar(RenderType):
        pass

    def renderfunc_bla(arg1: int) -> str:
        return f"{arg1}"

    def renderfunc_foo(arg1: int, arg2: int) -> str:
        return f"{arg1}{arg2}"

    def renderfunc_bar(arg1: int, arg2: int, arg3: int) -> str:
        return f"{arg1}{arg2}{arg3}"

    r = Register()

    r.set_renderfunc(Bla, renderfunc_bla)
    r.set_renderfunc(Foo, renderfunc_foo)
    r.set_renderfunc(Bar, renderfunc_bar)

    f1 = r.renderfun

# Generated at 2022-06-12 09:54:52.158767
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from . import fg
    from .rendertype import RgbFg, Sgr

    fg.orange = Style(RgbFg(1, 20, 40), Sgr(1))
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    n = fg.as_namedtuple()
    assert n.orange == "\x1b[38;2;1;20;40m\x1b[1m"
    assert n.red == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-12 09:55:06.141006
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class TestRegister(Register):
        red = Style(RgbFg(255, 0, 0))
        blue = Style(RgbFg(0, 0, 255))

    tr = TestRegister()
    nt = tr.as_namedtuple()

    assert type(nt) is namedtuple
    assert nt.red == Style(RgbFg(255, 0, 0))
    assert nt.blue == Style(RgbFg(0, 0, 255))

# Generated at 2022-06-12 09:55:13.998469
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import KbInput, fg, bg, ef, rs, RgbFg, RgbBg, SgrFg, SgrBg, Sgr, FgBg, Fg, Bg

    # Some definitions of random color-registers to test with

    fg.black = Style(SgrFg(Sgr.black), Fg(0))
    fg.red = Style(SgrFg(Sgr.red), Fg(1))
    fg.green = Style(SgrFg(Sgr.green), Fg(2))
    fg.yellow = Style(SgrFg(Sgr.yellow), Fg(3))
    fg.blue = Style(SgrFg(Sgr.blue), Fg(4))

# Generated at 2022-06-12 09:55:20.417354
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .render import Sgr

    r = Register()

    r.set_renderfunc(Sgr, lambda *args: f"SGR{args}")

    r.bold = Style(Sgr(1), value="SGR(1)")

    assert str(r.bold) == "SGR(1)"


# Generated at 2022-06-12 09:55:27.359932
# Unit test for method copy of class Register
def test_Register_copy():
    def renderfunc(rgbstring: str) -> str:
        return rgbstring

    r = Register()
    r.set_renderfunc(RenderType, renderfunc)

    # Create style
    r.blue = Style(RenderType("blue"))

    # Copy r1
    r1 = r.copy()

    assert r.blue == r1.blue

    # Change r1
    r1.red = Style(RenderType("red"))

    # Make sure r1 has changed but not r
    assert r.blue == r1.blue
    assert r.red == ""
    assert r1.red != ""

# Generated at 2022-06-12 09:55:38.116423
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertypes import Sgr, RgbFg

    register = Register()
    register.test1 = Style(Sgr(1), RgbFg(1, 5, 10))
    register.test2 = Style(RgbFg(2, 6, 11), Sgr(0), RgbFg(3, 7, 12))

    assert isinstance(register.test1, Style)
    assert len(register.test1) > 0
    assert isinstance(register.test2, Style)
    assert len(register.test2) > 0

    register_dict = register.as_dict()

    assert isinstance(register_dict, dict)
    assert len(register_dict) == 2
    assert "test1" in register_dict
    assert "test2" in register_dict

# Generated at 2022-06-12 09:55:44.601747
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()

    assert isinstance(r, Register)

    setattr(r, "test", Style(value = "12"))

    assert isinstance(r.test, Style)

    assert callable(r)

    # Call with string
    assert isinstance(r("test"), str)
    assert r("test") == "12"

    # Call with one int
    assert r(1) == ""

    # Call with three ints
    assert r(1, 2, 3) == ""



# Generated at 2022-06-12 09:55:47.157294
# Unit test for method copy of class Register
def test_Register_copy():

    rg = Register()
    rg.foo = Style(value="bar")

    rg_copy = rg.copy()

    assert(rg_copy is not rg)
    assert(rg_copy.foo == "bar")

# Generated at 2022-06-12 09:55:51.553253
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Setup
    bg = Register()
    setattr(bg, "test", Style(bg.rgb(1, 2, 3)))
    # Execution
    res = bg.as_dict()
    # Test
    assert res == {"test": '\x1b[48;2;1;2;3m'}


# Generated at 2022-06-12 09:56:01.669742
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import Sgr, RgbFg, RgbBg
    from .render import sgr_render_func, rgb_fg_render_func, rgb_bg_render_func

    attrs = {"red": Style(RgbFg(1, 5, 10)), "blue": Style(RgbBg(2, 10, 1))}
    renderfuncs = {
        RgbFg: rgb_fg_render_func,
        RgbBg: rgb_bg_render_func,
        Sgr: sgr_render_func,
    }

    reg = Register()
    for attr_name, style in attrs.items():
        setattr(reg, attr_name, style)
    reg.renderfuncs = renderfuncs

    # Before calling set_rgb_call, calls of the form `

# Generated at 2022-06-12 09:56:05.146986
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r.renderfuncs, Renderfuncs)
    assert r.is_muted == False
    assert callable(r.eightbit_call)
    assert callable(r.rgb_call)



# Generated at 2022-06-12 09:56:44.626460
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import sty
    r1 = sty.fg
    r1.red = Style(r1.renderfuncs['RgbFg'](255,0,0))
    r1.green = Style(r1.renderfuncs['RgbFg'](0,255,0))
    d1 = r1.as_dict()
    assert len(d1) == 8
    assert d1['red'] == '\x1b[38;2;255;0;0m'
    assert d1['green'] == '\x1b[38;2;0;255;0m'
    assert d1['purple'] == '\x1b[38;2;170;34;187m'

# Generated at 2022-06-12 09:56:51.619461
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create register
    register = Register()
    register.renderfuncs.update({RenderType: lambda x: x})

    # Add style to register
    register.test = Style(RenderType(42, "arg1"))

    # Test cases
    assert register("test") == "42"
    assert register(42) == 42
    assert register(10, 42, 255) == (10, 42, 255)

# Generated at 2022-06-12 09:57:00.333265
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertypes import CsiEightbitFg, CsiEightbitBg, Sgr

    register = Register()

    register.set_renderfunc(CsiEightbitFg, lambda x: f"\x1b[38;5;{x}m")
    register.set_renderfunc(CsiEightbitBg, lambda x: f"\x1b[48;5;{x}m")
    register.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    register.bright_red = Style(CsiEightbitFg(1), Sgr(1))

    # Define render-type for calls like that: register(42)
    register.set_eightbit_call(CsiEightbitFg)
    assert register(1) == register.bright_red




# Generated at 2022-06-12 09:57:07.598061
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Check if unmute sets is_muted attribute to False and re-renders colors.
    """
    r1 = Register()
    r1.green = Style(Sgr(92))
    r1.mute()
    assert r1.is_muted == True
    assert str(r1.green) == ""
    r1.unmute()
    assert r1.is_muted == False
    assert str(r1.green) == '\x1b[92m'


TESTS = [
    test_Register_unmute,
]

# Generated at 2022-06-12 09:57:14.384375
# Unit test for method mute of class Register
def test_Register_mute():

    r1 = Register()
    r2 = r1.copy()

    r1.set_eightbit_call(RenderType.Eightbit)
    r2.set_eightbit_call(RenderType.Eightbit)

    r1.set_renderfunc(RenderType.Eightbit, lambda x: f"{x}_r1")
    r2.set_renderfunc(RenderType.Eightbit, lambda x: f"{x}_r2")

    r1.blue = Style(RenderType.Eightbit(3), RenderType.Sgr(1))
    r2.blue = Style(RenderType.Eightbit(3), RenderType.Sgr(1))

    assert str(r1.blue) != str(r2.blue)

    r2.mute()

# Generated at 2022-06-12 09:57:22.907288
# Unit test for method unmute of class Register
def test_Register_unmute():

    from sty.rendering import StyleRenderer
    from sty.rendertype import RgbFg, RgbBg

    renderer = StyleRenderer()

    reg = Register()
    reg.set_renderfunc(RgbFg, renderer.render_rgb_fg)
    reg.set_renderfunc(RgbBg, renderer.render_rgb_bg)
    reg.set_eightbit_call(RgbFg)
    reg.set_rgb_call(RgbFg)

    reg.red = Style(RgbFg(255, 0, 0))
    reg.set_eightbit_call(RgbFg)

    reg.mute()

    assert reg.red == ""
    assert reg.red == reg.red
    assert reg(255) == ""

    reg.unm

# Generated at 2022-06-12 09:57:27.552460
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.test = Style(value='\x1b[42m')
    r.test2 = Style(value='\x1b[101m')

    assert r.as_dict() == {'test': '\x1b[42m', 'test2': '\x1b[101m'}

# Generated at 2022-06-12 09:57:37.301688
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg
    from .rendertype import Sgr

    red = Style(RgbFg(255, 0, 0))
    assert str(red) == "\x1b[38;2;255;0;0m"

    gray = Style(RgbFg(100, 100, 100))
    assert str(gray) == "\x1b[38;2;100;100;100m"

    bold_red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert str(bold_red) == "\x1b[38;2;255;0;0m\x1b[1m"

    italic_red = Style(RgbFg(255, 0, 0), Sgr(3))

# Generated at 2022-06-12 09:57:44.426332
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class DefaultRegister:
        def __init__(self):
            self.is_muted = False

    class Foo(RenderType):
        def __init__(self, x: int):
            super().__init__(x)

        def render(self, *args, **kwargs) -> str:
            return "\x1b[1;38;5;{x}m".format(x=args[0])

    class Bar(RenderType):
        def __init__(self, r: int, g: int, b: int):
            super().__init__(r, g, b)


# Generated at 2022-06-12 09:57:50.507071
# Unit test for method unmute of class Register
def test_Register_unmute():
    from sty import fg

    # prepare
    fg.mute()
    assert fg.is_muted is True
    assert fg.black == str()

    # exercise
    fg.unmute()

    # verify
    assert fg.is_muted is False
    assert fg.black == Style(RgbFg(0, 0, 0), value="\x1b[38;2;0;0;0m")


if __name__ == "__main__":
    test_Register_unmute()

# Generated at 2022-06-12 09:58:37.596968
# Unit test for method mute of class Register
def test_Register_mute():
    # Setup
    class MyRegister(Register):
        a = Style(RgbFg(0,0,0))
        b = Style(RgbFg(10,10,10))

    # Simulate user registering two renderfuncs.
    def f1(x):
        return x

    def f2(x, y, z):
        return x, y, z

    r = MyRegister()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(RgbFg, f1)
    r.set_renderfunc(RgbFg, f2)

    # Test
    r.mute()
    assert r.is_muted
    assert r.a == ""
    assert r.b == ""



# Generated at 2022-06-12 09:58:40.635473
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import fg, bg, ef, rs

    setattr(fg, "test", Style(fg.red, bg.green))
    assert isinstance(fg.test, Style)

    fg.test = Style(fg.cyan, bg.blue)
    assert isinstance(fg.test, Style)



# Generated at 2022-06-12 09:58:50.583497
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class R1(RenderType):
        pass

    class R2(RenderType):
        pass

    class R3(RenderType):
        pass

    def f1(*args, **kwargs):
        return args, kwargs

    def f2(*args, **kwargs):
        return args, kwargs

    def f3(*args, **kwargs):
        return args, kwargs

    r = Register()
    r.set_renderfunc(R1, f1)
    r.set_renderfunc(R2, f2)
    r.set_renderfunc(R3, f3)

    r.set_eightbit_call(R1)
    r.set_rgb_call(R2)

    args1 = (1,2,3)

# Generated at 2022-06-12 09:58:56.707252
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Method set_rgb_call(self, rendertype: Type[RenderType]) -> None:

    # With this method you can call a register-object directly.
    # A call like this ``fg(10,42,255)`` is a RGB-call. With this method
    # you can define the render-type for such calls.

    r = Register()

    r.set_renderfunc(RgbFg, lambda r,g,b: f"({r}){g}{b}")

    r.set_rgb_call(RgbFg)

    assert r.rgb_call(10,42,255) == "(10)42551"

# Generated at 2022-06-12 09:59:02.204474
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr

    style1 = Style(Sgr(1), value="hello world")

    assert style1.rules == (Sgr(1),)
    assert style1 == "hello world"
    assert isinstance(style1, Style)

    style2 = Style(Sgr(1), Sgr(2), value="hello world")

    assert style2.rules == (Sgr(1), Sgr(2))
    assert style2 == "hello world"
    assert isinstance(style2, Style)



# Generated at 2022-06-12 09:59:11.516046
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.r, self.g, self.b = r, g, b

    class Sgr(RenderType):
        def __init__(self, value: int):
            self.value = value

    class Rgb2Ansi(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.r, self.g, self.b = r, g, b

    def rgbfg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def sgr(value):
        return f"\x1b[{value}m"


# Generated at 2022-06-12 09:59:13.825121
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_renderfunc(RenderType.Sgr, lambda x: "SET")
    r.set_eightbit_call(RenderType.Sgr)
    assert r(1) == "SET"

# Generated at 2022-06-12 09:59:16.331953
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.is_muted = True
    r.foo = Style()
    r.unmute()

    assert r.foo == ""
    assert r.is_muted is False


# Generated at 2022-06-12 09:59:27.352699
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Unit-Test for method set_renderfunc of class Register.
    """
    from .rendertype import Sgr

    class RegisterA(Register):
        def __init__(self):
            super().__init__()

        # override Sgr function
        def set_renderfunc(self, rendertype, func):
            if rendertype == Sgr:
                super().set_renderfunc(rendertype, lambda x: "SGR: " + str(x))
            else:
                super().set_renderfunc(rendertype, func)

    register = RegisterA()

    # test
    register.set_renderfunc(Sgr, lambda x: "SGR: " + str(x))

    assert str(register.bold) == "SGR: 1"
    assert str(register.inverse) == "SGR: 7"




# Generated at 2022-06-12 09:59:33.887193
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Build a mock class
    class MockRenderType:

        def __init__(self, args: Tuple[int]):
            self.args = args

    # Define a renderfunc for the mock class.
    def _mock(x: int) -> str:
        return f"~{x}"

    # Define a register that contains a style
    reg = Register()
    reg.test = Style(MockRenderType(args=(9,)))

    # Check if the style is rendered correctly
    assert str(reg.test) == ""

    # Set the renderfunc
    reg.set_renderfunc(rendertype=MockRenderType, func=_mock)

    # Check if the style is rendered correctly
    assert str(reg.test) == "~9"

    # Reset function
    def _reset(*args):
        reset