

# Generated at 2022-06-12 09:49:49.413328
# Unit test for constructor of class Register
def test_Register():
    """
    Construct the class Register
    """
    return Register()

# Generated at 2022-06-12 09:49:52.214804
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from . import RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r(10, 10, 10) == "\x1b[38;2;10;10;10m"


# Generated at 2022-06-12 09:50:02.477221
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, *args):
            self.renderfunc = self._render
            self.args = args

        def _render(self, *args):
            return f"{args[0]}{args[1]}{args[2]}"

    class RgbBg(RenderType):
        def __init__(self, *args):
            self.renderfunc = self._render
            self.args = args

        def _render(self, *args):
            return f"@{args[0]}{args[1]}{args[2]}"

    register = Register()
    register.set_renderfunc(RgbFg, RgbFg._render)
    register.set_renderfunc(RgbBg, RgbBg._render)

    register.set_r

# Generated at 2022-06-12 09:50:14.479035
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbFgTest(RenderType):
        """
        A testclass to test the set_rgb_call method of the register class.
        """
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b

        @property
        def args(self):
            return self.r, self.g, self.b

    register = Register()

    # Add renderfunc for the testclass RgbFgTest
    register.set_renderfunc(RgbFgTest, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set new renderfunc as the RGB-renderfunc.
    register.set_rgb_call(RgbFgTest)

    # Create new

# Generated at 2022-06-12 09:50:21.877023
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit test for method __call__ of class Register.
    """

    # Set up 8-bit render function
    def render_eightbit(x: int, *args) -> str:
        return "\x1b[{}m".format(x)

    # Set up RGB render function
    def render_rgb(r: int, g: int, b: int, *args) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    # Create new register object
    r = Register()
    r.set_renderfunc(Eightbit, render_eightbit)
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_eightbit_call(Eightbit)

# Generated at 2022-06-12 09:50:25.834860
# Unit test for constructor of class Register
def test_Register():
    r = Register()

    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-12 09:50:34.840808
# Unit test for method __call__ of class Register
def test_Register___call__():

    def test_register(r: Register, expected: str, inputs: Iterable[Union[int, str]]) -> None:
        """
        Test if register-object `r` correctly maps `input` to `expected`.
        """

        print(f"Testing {r}")
        for i in inputs:
            print(f"∙ input  : {i}")
            print(f"∙ result : {r(i)}")
            assert r(i) == expected, f"{r(i)} != {expected}"

    red = Style(RgbFg(255, 0, 0))
    blue = Style(RgbFg(0, 0, 255))
    green = Style(RgbFg(0, 255, 0))
    yellow = Style(RgbFg(255, 255, 0))

    fg = Register()

# Generated at 2022-06-12 09:50:43.202810
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Method tests if method set_rgb_call (see above) changes the register object in
    a way, so that it returns the correct ANSI-sequence for a given RGB-code.
    """

    from .rendertypes import RgbBg, RgbFg, Sgr, EightBit
    from .register import Register
    from .renderfunctions import render_ansi_eightbit, render_ansi_rgb

    fg = Register()

    fg.set_renderfunc(RgbFg, render_ansi_rgb)
    fg.set_rgb_call(RgbFg)

    fg.red = Style(RgbFg(255,0,0))

    # Call register with given rgb-code:
    assert fg(255,0,0) == fg.red



# Generated at 2022-06-12 09:50:53.429571
# Unit test for method __call__ of class Register
def test_Register___call__():
    import pytest

    # Check if method __call__ raises appropriate errors.
    with pytest.raises(TypeError) as excinfo:
        reg = Register()
        reg(12, 13, 14, 15)
    assert "too many positional arguments" in str(excinfo.value)

    with pytest.raises(TypeError) as excinfo:
        reg = Register()
        reg(12, a=13, b=14)
    assert "unexpected keyword argument" in str(excinfo.value)

    # Create register with simple Eightbit and RGB types
    # and check if calls are handled as expected.
    Eightbit = RenderType.create(
        name="Eightbit", renderfunc=lambda x: f"\x1b[{x}m", argtypes={"x": int}
    )

# Generated at 2022-06-12 09:51:03.941985
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr
    import pytest

    r = Register()

    def eightbit(x: int) -> str:
        return f"{x}"

    def rgb(r: int, g: int, b: int) -> str:
        return f"{r, g, b}"

    r.set_renderfunc(Eightbit, eightbit)
    r.set_renderfunc(RgbFg, rgb)

    r.red = Style(RgbFg(255, 0, 0))

    assert r(42) == "42"
    assert r(255, 0, 0) == "(255, 0, 0)"
    assert r("red") == "\x1b[38;2;255;0;0m"

    with pytest.raises(ValueError):
        r

# Generated at 2022-06-12 09:51:29.521013
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Default register-objects.
    r1 = Register()
    r1.set_eightbit_call(RenderType)
    r1.set_rgb_call(RenderType)

    r2 = Register()
    r2.set_eightbit_call(RenderType)
    r2.set_rgb_call(RenderType)

    # Check if a register is muted.
    assert not r1.is_muted
    assert not r2.is_muted

    # Check if __call__ works when muted.
    r1.mute()
    assert not r1.is_muted
    assert r1(42) == ""
    assert r1(42, 42, 42) == ""
    assert r1("foo") == ""

    # Check if __call__ works when not muted.
    r2.unmute

# Generated at 2022-06-12 09:51:36.937916
# Unit test for method __call__ of class Register
def test_Register___call__():

    def dummy_func(*args, **kwargs): return True


    # Create register
    register = Register()

    # Mute register
    register.mute()

    # Add function
    register.set_renderfunc(type, dummy_func)

    # Add style
    register.style = Style(type(type))

    # Call register
    assert register(type) == ""

    # Unmute register
    register.unmute()

    # Call register
    assert register(type) == True




# Generated at 2022-06-12 09:51:45.692999
# Unit test for method __call__ of class Register
def test_Register___call__():
    def render_sgr(value):
        return f"\x1b[{value}m"

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rgb_cursor(r, g, b):
        return f"\x1b[39;2;{r};{g};{b}m"

    def render_rgb_cursor_bg(r, g, b):
        return f"\x1b[49;2;{r};{g};{b}m"

    mock_style_register

# Generated at 2022-06-12 09:51:55.937127
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .register.terminal import fg, bg

    # This should return bg.red as an Style object.
    res1 = bg(9)
    assert isinstance(res1, Style)
    assert res1 == "\x1b[48;5;9m"
    assert res1 == bg.red

    # This should return bg.rgb(255, 255, 0) as an Style object.
    res2 = bg(255, 255, 0)
    assert isinstance(res2, Style)
    assert res2 == "\x1b[38;2;255;255;0m"
    assert res2 == fg.rgb(255, 255, 0)

    # This should return an empty string.
    res3 = bg(10, 20, 30, 40, 50, 60)
    assert res

# Generated at 2022-06-12 09:52:03.579080
# Unit test for method __call__ of class Register
def test_Register___call__():

    r: Register = Register()
    r.red = Style(RgbBg(1, 5, 10))
    r.eightbit_call = lambda x: "EightBit"
    r.rgb_call = lambda r, g, b: f"RGB(r={r}, g={g}, b={b})"

    assert r.red == "RGB(r=1, g=5, b=10)"
    assert r(42) == "EightBit"
    assert r(1, 5, 10) == "RGB(r=1, g=5, b=10)"

# Generated at 2022-06-12 09:52:11.311373
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Sgr, RgbFg, RgbBg

    reg = Register()
    reg.set_renderfunc(Sgr, lambda *args: "\x1b[1m")
    reg.set_renderfunc(RgbFg, lambda *args: "\x1b[38;2;255;255;255m")
    reg.set_renderfunc(RgbBg, lambda *args: "\x1b[48;2;0;0;0m")

    reg.foo = Style(RgbFg(255, 255, 255), Sgr(1))

    assert reg("foo") == "\x1b[38;2;255;255;255m\x1b[1m"
    assert reg(17) == ""
    assert reg(255, 255, 255) == ""

# Generated at 2022-06-12 09:52:20.992836
# Unit test for method __call__ of class Register
def test_Register___call__():

    from sty import fg

    r = Register()
    r.__class__.red = Style(fg(255, 0, 0))

    assert r.__call__('red') == fg(255, 0, 0)

    assert r.__call__(14) == ''

    r = Register()
    r.__class__.red = Style(fg(255, 0, 0))
    r.mute()

    assert r.__call__('red') == ''

    assert r.__call__(14) == ''

    r.unmute()

    assert r.__call__('red') == fg(255, 0, 0)

    assert r.__call__(14) == ''



# Generated at 2022-06-12 09:52:22.367284
# Unit test for constructor of class Register
def test_Register():

    register = Register()

    assert isinstance(register, Register)



# Generated at 2022-06-12 09:52:26.141327
# Unit test for constructor of class Register
def test_Register():
    """
    Test the constructor of the class Register.
    """
    register = Register()
    assert register.is_muted is False
    assert register.eightbit_call is None
    assert register.rgb_call is None
    assert register.renderfuncs == {}



# Generated at 2022-06-12 09:52:34.920549
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit test for method __call__ of class Register.
    """
    import sty
    import sty.ansi

    fg = sty.ansi.register.Fg()
    fg.set_eightbit_call(sty.ansi.SGR)
    fg.set_renderfunc(sty.ansi.SGR, lambda *args: f"SGR({args})")
    fg.red = Style(sty.ansi.SGR(1))

    assert fg.red == "SGR(1)"
    assert fg(1) == "SGR(1)"
    assert fg("red") == "SGR(1)"

# Generated at 2022-06-12 09:52:58.704320
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr

    from .rendertype import RgbFg, RgbBg
    from .rendertype import TrueColorFg, TrueColorBg

    fg = Register()

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    s = fg.red

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s == "\x1b[38;2;255;0;0m\x1b[1m"

    fg.mute()

    assert fg.red == ""

    fg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"

    # Test for TrueColor registers.

# Generated at 2022-06-12 09:53:07.417257
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertypes import Sgr

    renderfuncs = {
        Sgr: lambda *a: ""
    }

    r = Register()
    r.set_renderfunc(Sgr, renderfuncs[Sgr])
    r.eightbit_call = renderfuncs[Sgr]
    r.rgb_call = renderfuncs[Sgr]

    r.test3 = Style(Sgr(), Sgr())
    r.test4 = Style(Sgr())
    r.test5 = Style(Sgr(), Sgr())

    nt = r.as_namedtuple()
    assert str(nt.test3) == str(nt.test5)
    assert str(nt.test3) != str(nt.test4)

# Generated at 2022-06-12 09:53:17.322155
# Unit test for method mute of class Register
def test_Register_mute():
    from .styleRegister import styleReg
    from .styleRenderType import EightbitBg, EightbitFg, Sgr

    register = Register()
    styleReg.fg.set_renderfunc(EightbitFg, lambda x: "\033[38;5;{}m".format(x))
    styleReg.fg.set_renderfunc(Sgr, lambda x: "\033[{}m".format(x))
    styleReg.fg.bold = Style(EightbitFg(144), Sgr(1))
    styleReg.bg.set_renderfunc(EightbitBg, lambda x: "\033[48;5;{}m".format(x))
    styleReg.bg.set_renderfunc(Sgr, lambda x: "\033[{}m".format(x))

# Generated at 2022-06-12 09:53:27.799375
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Sgr(RenderType):
        args = ["sgr_code"]

    class RgbFg(RenderType):
        args = ["r", "g", "b"]

    class SgrFg(RenderType):
        args = ["fg_code"]

    def sgr_render(*args):
        return f"\x1b[{args[0]}m"

    def rgb_render(*args):
        return f"\x1b[38;2;{args[0]};{args[1]};{args[2]}m"

    def sgr_fg(*args):
        return f"\x1b[38;5;{args[0]}m"

    class TestRegister(Register):
        def __init__(self):
            super().__init__()

# Generated at 2022-06-12 09:53:38.146865
# Unit test for method __new__ of class Style
def test_Style___new__():

    testval = Style("a", "b")
    assert testval == "a"
    assert testval.rules == ("a", "b")

    testval = Style("a", "b", value="c")
    assert testval == "c"
    assert testval.rules == ("a", "b")

    testval = Style("a", "b", value="c", content="d")
    assert testval == "c"
    assert testval.rules == ("a", "b")
    assert testval.content == "d"

    testval = Style("a", "b", content="d")
    assert testval == ""
    assert testval.rules == ("a", "b")
    assert testval.content == "d"

    testval = str(Style("a", "b"))
    assert testval == ""

# Generated at 2022-06-12 09:53:44.244717
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    r = Register()
    r.set_renderfunc(str, lambda x: "HeyHo")
    assert r("NewRule") == "HeyHo"

    r.set_renderfunc(str, lambda x: "NewHeyHo")
    assert r("NewRule") == "NewHeyHo"



# Generated at 2022-06-12 09:53:49.546722
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .const import fg
    from .rendertype import Sgr, TrueColorFg

    t1 = fg.red.rules
    fg.set_renderfunc(TrueColorFg, lambda r, g, b: "")
    fg.set_renderfunc(Sgr, lambda *args: "".join(str(arg) for arg in args))

    assert fg.red.rules == t1



# Generated at 2022-06-12 09:53:54.339236
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg

    @RgbBg.register_render_func
    def _test_render_RgbBg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r = Register()

    r.set_rgb_call(RgbBg)

    assert r(42, 42, 42) == r.rgb_call(42, 42, 42)


# Generated at 2022-06-12 09:54:00.628536
# Unit test for constructor of class Style
def test_Style():
    Style1 = Style("val")
    assert isinstance(Style1, str)
    assert isinstance(Style1, Style)
    assert str(Style1) == "val"
    assert Style1.rules == []

    Style2 = Style("val", "val2")
    assert isinstance(Style2, str)
    assert isinstance(Style2, Style)
    assert str(Style2) == "val"
    assert Style2.rules == ["val2"]



# Generated at 2022-06-12 09:54:08.035714
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register = Register()

    def render_red(r, g, b):
        return f"{r} {g} {b}"

    def render_bold(bold):
        return bold

    register.set_renderfunc(RenderType.RgbFg, render_red)
    register.set_renderfunc(RenderType.Sgr, render_bold)

    register.red = Style(RenderType.RgbFg(255, 0, 0), RenderType.Sgr(1))

    assert str(register.red) == "255 0 0 1"

# Generated at 2022-06-12 09:54:28.849464
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """ Unit test function """
    from .colortypes import Ansi8bit, Bg256

    # Create example register
    register = Register()

    # Add test renderfuncs for Ansi8bit and Bg256 ColorTypes.
    renderfuncs = {Ansi8bit: lambda x: "Ansi8bit_function", Bg256: lambda x: "Bg256_function"}
    register.renderfuncs.update(renderfuncs)

    if register.eightbit_call:
        register.eightbit_call(0)

    # Set Bg256 to be used for Eightbit calls.
    register.set_eightbit_call(Bg256)

    # Check if eigthbit-call with Bg256 is used.
    assert register.eightbit_call(0) == "Bg256_function"


# Unit test

# Generated at 2022-06-12 09:54:32.829839
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    r = Register()
    r.null = Style(RenderType())
    r.test = Style(RenderType())

    export = r.as_dict()

    assert isinstance(export, dict)
    assert len(export) == 2
    assert "null" in export
    assert "test" in export



# Generated at 2022-06-12 09:54:36.286001
# Unit test for constructor of class Style
def test_Style():

    class TestType(RenderType):
        """Just a testing rendertype"""

    test_type = TestType(1, 2, 3)

    style = Style(test_type)

    assert isinstance(style, Style)
    assert isinstance(style, str)



# Generated at 2022-06-12 09:54:47.451236
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr

    # Create a register
    reg = Register()

    # Set render-functions for two rendertypes.
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\033[38;2;{r};{g};{b}m")
    reg.set_renderfunc(Sgr, lambda r: f"\033[{r}m")

    # Set eightbit call to the first rendertype.
    reg.set_eightbit_call(RgbFg)

    # Set an attribute in the register.
    reg.test = Style(RgbFg(0, 0, 0), Sgr(1))

    # get the value of the attribute.
    val = reg.test


# Generated at 2022-06-12 09:54:55.906664
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import Eightbit, Sgr

    # Create new register.
    rs = Register()

    # Add new style to register.
    rs.red = Style(Eightbit(160))

    # Call register-object.
    assert rs(160) == "\x1b[38;5;160m"

    # Add new rendertype to register.
    rs.set_renderfunc(Sgr, lambda x: "\x1b[{}m".format(x))

    # Add new style to register.
    rs.bold = Style(Sgr(1))

    # Change color to bold red.
    rs.red = Style(rs.bold, Eightbit(160))

    # Call register-object with new style.
    assert rs(160) == "\x1b[1m\x1b[38;5;160m"



# Generated at 2022-06-12 09:55:04.937962
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from sty import fg, bg

    fg.red

    fg.set_eightbit_call(RenderType.SGR)

    assert fg(1) == "\x1b[31m"

    fg.set_eightbit_call(RenderType.RGB)

    assert fg(1) == "\x1b[38;2;255;0;0m"

    bg.blue

    bg.set_eightbit_call(RenderType.RGB)

    assert bg(4) == "\x1b[48;2;0;0;255m"

    bg.set_eightbit_call(RenderType.SGR)

    assert bg(4) == "\x1b[44m"

# Generated at 2022-06-12 09:55:12.096099
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg

    def return_rgb(r, g, b):
        return f"{r}{g}{b}"

    r = Register()
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(RgbFg, return_rgb)

    r.red = Style(RgbFg(255, 0, 0))
    assert r.red == "255000"

    r.mute()
    assert r.red == ""

    r.unmute()
    assert r.red == "255000"



# Generated at 2022-06-12 09:55:14.385461
# Unit test for method __new__ of class Style
def test_Style___new__():

    s = Style(value="test")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s.value == "test"
    assert s.rules == tuple()


# Generated at 2022-06-12 09:55:26.175834
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    fg = Register()

    # Create an Sgr-rendertype and its corresponding renderfunc
    Sgr = RenderType("Sgr", ["bold", "underline", "reverse", "normal"])
    sgr: Callable = lambda *args: "\x1b[" + ";".join(args) + "m"

    # Register renderfunc for Sgr-rendertype
    fg.set_renderfunc(Sgr, sgr)

    # Define our first style
    fg.orange = Style(RgbFg(1, 5, 10), Sgr("bold"))

    # Create an RgbFg-rendertype and its corresponding renderfunc
    RgbFg = RenderType("RgbFg", [int, int, int])

# Generated at 2022-06-12 09:55:32.682512
# Unit test for method copy of class Register
def test_Register_copy():

    from .. import Fg

    r = Fg()
    r1 = r.copy()

    assert r.blue == r1.blue
    assert r.is_muted is False
    assert r1.is_muted is False

    r.blue = "blue"

    assert r.blue == r1.blue
    assert r.is_muted is False
    assert r1.is_muted is False

    r.is_muted = True

    assert r.blue != r1

# Generated at 2022-06-12 09:55:59.816005
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # The functions (renderfuncs)
    def _rgb_sgr(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}"

    def _rgb_ansi(r, g, b):
        return f"\x1b[38;5;{16 + 36*r + 6*g + b}m"

    def _rgb_truecolor(r, g, b):
        return f"\x1b[38;2;{r};{g};{bm}m\x1b[48;2;{r};{g};{bm}m"

    # The render types
    class RgbSgr(NamedTuple):
        r: int
        g: int
        b: int


# Generated at 2022-06-12 09:56:08.045983
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        args = 3

    class Sgr(RenderType):
        args = 1

    class RgbBg(RenderType):
        args = 3

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m")
    r.set_renderfunc(Sgr, lambda x: "\x1b[" + str(x) + "m")
    r.set_renderfunc(RgbBg, lambda r, g, b: "\x1b[48;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m")

# Generated at 2022-06-12 09:56:15.821002
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Tests if the new rendertype is used when calling the register-object directly.
    """
    from .rendertype import RgbFg, RgbBg
    from .register import Register

    register_obj = Register()

    # Set render-function for rendertype RgbBg
    renderfunc = lambda *args: "bg " + str(args)
    register_obj.set_renderfunc(RgbBg, renderfunc)

    # Set default rendertype for RGB-calls
    register_obj.set_rgb_call(RgbBg)

    # Call the register-object directly with an RGB value and test the output
    assert register_obj(10, 20, 30) == "bg (10, 20, 30)"



# Generated at 2022-06-12 09:56:20.127206
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """ Test the as_dict method of the Register class. """
    # Create an instance of the Register class.
    class Test(Register):
        pass

    test = Test()
    test.red = "red"
    test.white = "white"
    result = test.as_dict()
    assert isinstance(result, dict)



# Generated at 2022-06-12 09:56:23.310321
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda *a: "FAKED")

    r.set_rgb_call(RgbFg)

    assert r(1, 2, 3) == "FAKED"



# Generated at 2022-06-12 09:56:26.540590
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg

    fg.red = Style(fg(255, 0, 0))

    assert fg.red == "\x1b[38;2;255;0;0m"

    fg.mute()

    assert fg.red == ""

    fg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-12 09:56:36.362074
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class Tester(Register):

        def __init__(self):

            super().__init__()

            self.set_eightbit_call(RgbFg)
            self.set_rgb_call(RgbFg)


# Generated at 2022-06-12 09:56:43.660555
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import Sgr, RgbBg, RgbFg

    def render_bg_rgb(r, g, b):
        return "\x1b[48;2;{};{};{}m".format(r, g, b)

    def render_fg_rgb(r, g, b):
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    def render_bg_256(bg256):
        return "\x1b[48;5;{}m".format(bg256)

    def render_fg_256(fg256):
        return "\x1b[38;5;{}m".format(fg256)

    r = Register()

# Generated at 2022-06-12 09:56:55.318423
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Run unit tests for method __call__ of class Register.
    """

    from .ansi import RgbFg, RgbBg, Rs, Sgr

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_rs():
        return f"\x1b[0m"

    def render_sgr(sgr):
        return f"\x1b[{sgr}m"


# Generated at 2022-06-12 09:56:58.845194
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    testregister: Register = Register()
    style: Style = Style(Sgr(1))
    setattr(testregister, "bold", style)
    testregister.set_eightbit_call(Sgr)
    assert testregister(1) == "\x1b[1m"



# Generated at 2022-06-12 09:57:24.833950
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from colorama import Fore, AnsiCodes

    # Create a new Register object
    test = Register()

    # Set the renderfunc for EightbitCodes
    test.set_renderfunc(AnsiCodes.EightbitCodes, lambda x: x + "EIGHTBIT")

    # Set the renderfunc for RGB
    test.set_renderfunc(AnsiCodes.RGBCodes, lambda x: x + "RGB")

    # Set EightbitCodes as default rendertype for direct calls as fg(220)
    test.set_eightbit_call(AnsiCodes.EightbitCodes)

    # Set RGB as default rendertype for direct calls as fg(42, 42, 42)
    test.set_rgb_call(AnsiCodes.RGBCodes)

    # Test EightbitCodes for direct calls as fg

# Generated at 2022-06-12 09:57:27.836849
# Unit test for constructor of class Style
def test_Style():
    s = Style(*[1,2,3])
    assert isinstance(s, str)
    assert isinstance(s, Style)
    assert len(s.rules) == 3


# Generated at 2022-06-12 09:57:37.555579
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr
    from .sty import bg, fg
    from .libsty import set_fg
    
    set_fg(99, 0, 0)

    bg.red = Style(Sgr(41))

    def test_str():
        assert str(bg.red) == "\x1b[41m"

    def test_call():
        assert str(bg(1)) == "\x1b[48;2;255;0;0m"

    def test_mute():
        bg.mute()
        assert str(bg.red) == ""
        assert str(bg(1)) == ""

    def test_unmute():
        bg.unmute()
        assert str(bg.red) == "\x1b[41m"

# Generated at 2022-06-12 09:57:44.609617
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    This is a unittest for the as_dict method of Register class.

    More unittests can be found in tests/tests.py.
    """
    # ------ SETUP ------
    # Define a register
    class testregister(Register):

        black = Style(RgbFg(0, 0, 0))
        white = Style(RgbBg(255, 255, 255))
        gray = Style(RgbFg(110, 110, 110))
        yellow = Style(RgbBg(253, 253, 0))

    # The expected result

# Generated at 2022-06-12 09:57:53.228687
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbBg, RgbFg, RenderType, Sgr

    def color_func(rgb: Tuple[int, int, int]) -> str:
        rgb = rgb + (16,)
        return f"\x1b[38;2;{rgb[0]};{rgb[1]};{rgb[2]}m"

    r = Register()

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.blue == "\x1b[38;2;0;0;255m"

    r.set_eightbit_call(RgbFg)
    r.set

# Generated at 2022-06-12 09:58:01.849383
# Unit test for method mute of class Register
def test_Register_mute():

    # Prepare Mock-Class
    class TestRenderType(NamedTuple, RenderType):
        """
        Mock rendertype.
        """

        def __str__(self):
            return "test"

    class TestRegister(Register):
        """
        Mock register.
        """

    t = TestRenderType()
    r = TestRegister()
    r.set_renderfunc(t, lambda x: x)

    assert isinstance(r.test, Style)
    assert str(r.test) == "test"
    assert str(r(1)) == "test"

    r.mute()

    assert isinstance(r.test, Style)
    assert str(r.test) == ""
    assert str(r(1)) == ""

    r.unmute()

    assert isinstance(r.test, Style)
   

# Generated at 2022-06-12 09:58:11.056539
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test if set_renderfunc() works as expected.
    """
    import sty

    r = sty.fg()
    # Save original renderfunc
    orig = r.renderfuncs[sty.RgbFg]

    def new_renderfunc(*args):
        return "NEW"

    r.set_renderfunc(sty.RgbFg, new_renderfunc)
    assert r.renderfuncs[sty.RgbFg] != orig  # pylint: disable=E1101
    assert r.renderfuncs[sty.RgbFg] == new_renderfunc

    # Test if call updates attributes
    assert hasattr(r, "red")
    assert isinstance(r.red, str)
    assert r.red == "NEW"  # pylint: disable=E1101

    # Test if call

# Generated at 2022-06-12 09:58:20.523448
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbBg, RgbFg, Sgr

    s1: Style = Style(RgbFg(1, 2, 3), Sgr(0), value="\x1b[31m\x1b[39m")
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1.rules[0] == RgbFg(1, 2, 3)
    assert s1.rules[1] == Sgr(0)

    s2: Style = Style(RgbBg(1, 2, 3), Sgr(1))
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert s2.rules[0] == RgbBg(1, 2, 3)
    assert s2.rules[1]

# Generated at 2022-06-12 09:58:22.337891
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style("Foo")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s == "Foo"

# Generated at 2022-06-12 09:58:30.608542
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class Sgr(RenderType):
        rendertype = "render"

        def __init__(self, *args):
            self.args = args

    class Rgb(RenderType):
        rendertype = "render"

        def __init__(self, *args):
            self.args = args

    def render_sgr(*args, **kwargs):
        return "\x1b[{};{}m".format(*args)

    def render_rgb(r, g, b, **kwargs):
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    fg = Register()
    fg.set_renderfunc(Sgr, render_sgr)
    fg.set_renderfunc(Rgb, render_rgb)


# Generated at 2022-06-12 09:59:15.519002
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .register.fg import fg

    assert fg.black == fg.as_namedtuple().black

# Generated at 2022-06-12 09:59:24.956807
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    register_cls: Type[Register] = type(fg)
    reg = register_cls()

    for name in dir(reg):

        name = name.strip()

        if name.startswith("_"):
            continue

        setattr(reg, name, Style(name, name))

    nt = reg.as_namedtuple()

    assert nt.black == "black"
    assert nt.white == "white"
    assert nt.rgb8_0_0_0 == "rgb8_0_0_0"
    assert nt.rgb24_255_255_255 == "rgb24_255_255_255"

# Generated at 2022-06-12 09:59:26.283066
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg
# Unit tests for method set_renderfunc

# Generated at 2022-06-12 09:59:33.573534
# Unit test for method __call__ of class Register
def test_Register___call__():

    from sty import fg, bg, ef, rs

    assert fg(1) == '\x1b[38;5;1m'
    assert bg(10) == '\x1b[48;5;10m'
    assert ef(1) == '\x1b[1m'
    assert rs(1) == '\x1b[21m'
    assert fg('black') == '\x1b[38;5;0m'
    assert bg('white') == '\x1b[48;5;15m'
    assert fg(1, 2, 3) == '\x1b[38;2;1;2;3m'
    assert bg(1, 2, 3) == '\x1b[48;2;1;2;3m'




# Generated at 2022-06-12 09:59:42.836481
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .colors import Red, Green, Orange

    r = Register()
    r.set_renderfunc(Sgr, lambda *x: "SGR")
    r.set_renderfunc(RgbFg, lambda *x: "RGBFG")
    r.set_renderfunc(RgbBg, lambda *x: "RGBBG")

    r.red = Style(Red, Sgr(1))
    r.green = Style(Green, Sgr(2))
    r.orange = Style(Orange, Sgr(3))

    assert str(r.red) == "RGBFGSGR"
    assert str(r.green) == "RGBBGSGR"
    assert str(r.orange) == "RGBFGSGR"

    r.mute