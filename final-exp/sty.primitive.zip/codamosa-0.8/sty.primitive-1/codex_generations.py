

# Generated at 2022-06-12 09:49:55.551311
# Unit test for constructor of class Register
def test_Register():

    register = Register()
    register.red = Style(RgbFg(10, 10, 10))
    register.blue = Style(RgbFg(100, 100, 100))
    assert str(register.red) == ""
    assert str(register.blue) == ""



# Generated at 2022-06-12 09:49:56.918376
# Unit test for constructor of class Register
def test_Register():
    r: Register = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-12 09:49:58.260597
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r is not None



# Generated at 2022-06-12 09:49:59.696572
# Unit test for constructor of class Register
def test_Register():
    a = Register()
    assert a.is_muted is False

# Generated at 2022-06-12 09:50:01.257800
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert not hasattr(r, "_init_")

# Generated at 2022-06-12 09:50:02.741783
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert str(register) == ""


# Generated at 2022-06-12 09:50:08.245268
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert hasattr(reg, "renderfuncs")
    assert type(reg.renderfuncs) == dict
    assert reg.is_muted == False
    assert isinstance(reg.eightbit_call, Callable)
    assert isinstance(reg.rgb_call, Callable)



# Generated at 2022-06-12 09:50:10.115003
# Unit test for constructor of class Register
def test_Register():
    # Test if instance of base class
    assert isinstance(Register(), Register)



# Generated at 2022-06-12 09:50:11.524513
# Unit test for constructor of class Register
def test_Register():
    register: Register = Register()
    assert register != None



# Generated at 2022-06-12 09:50:16.789130
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    rgb = (1,5,10)
    r.rgb = Style(rgb=rgb)
    assert isinstance(r.rgb, str)
    assert r.rgb == Style(*rgb)
    assert r.rgb != Style(rgb=rgb)


if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-12 09:50:28.595954
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, Sgr

    c = Register()
    c.set_renderfunc(Eightbit, lambda x: f"This is a Eightbit-value {x}.")
    c.set_eightbit_call(Eightbit)

    assert str(c(42)) == "This is a Eightbit-value 42."

    c.set_renderfunc(Sgr, lambda x: f"This is a Sgr-value {x}.")
    c.set_eightbit_call(Sgr)

    assert str(c(42)) == "This is a Sgr-value 42."



# Generated at 2022-06-12 09:50:36.117784
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import Sgr, RgbFg

    r1 = Register()

    r1.set_renderfunc(Sgr, lambda x, y: f"{x}{y}")
    r1.set_renderfunc(RgbFg, lambda x, y, z: f"{x}{y}{z}")

    r1.fg = Style(RgbFg(10, 20, 30))
    assert r1.fg == "102030"

    r1.set_rgb_call(Sgr)
    r1.fg = Style(RgbFg(10, 20, 30))
    assert r1.fg == "102030"

    r1.set_rgb_call(Sgr)
    r1.fg = Style(RgbFg(10, 20, 30))
    assert r1

# Generated at 2022-06-12 09:50:43.849641
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertypes import EightbitFg, EightbitBg, RgbFg, RgbBg, Reset

    renderfunc = lambda x: f"\x1b[{x}m"

    r = Register()
    r.set_renderfunc(EightbitFg, renderfunc)
    r.set_renderfunc(EightbitBg, renderfunc)
    r.set_renderfunc(RgbFg, renderfunc)
    r.set_renderfunc(RgbBg, renderfunc)

    r.green = Style(EightbitFg(34))
    r.blue = Style(EightbitBg(45))
    r.orange = Style(RgbFg(64, 0, 0))
    r.reset = Style(Reset())

# Generated at 2022-06-12 09:50:45.461303
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.is_muted is False


# Generated at 2022-06-12 09:50:55.404639
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    This method is for unit testing the method unmute of the Register class.
    """
    from .rendertype import Fg, Sgr

    fg = Register()

    fg.blue = Style(Fg(12), Sgr(1))
    fg.muted_blue = Style(Fg(12), Sgr(1))

    fg.mute()

    assert fg.blue == ""
    assert str(fg.blue) == ""

    assert fg.muted_blue == ""
    assert str(fg.muted_blue) == ""

    fg.unmute()

    assert fg.blue == "\x1b[38;5;12m\x1b[1m"

# Generated at 2022-06-12 09:51:03.706418
# Unit test for method copy of class Register
def test_Register_copy():

    from sty import fg

    # For example, let's change the render method for certain style attributes.
    fg.blue.rules[0].args[2] = 55 # Change argument b of RgbFg to 55
    fg.blue.rules[0].args[3] = 2 # Change argument a of RgbFg to 2

    # Create a deepcopy of the object to see the changes.
    new_fg = fg.copy()

    assert new_fg.blue.rules[0].args[2] == 55
    assert new_fg.blue.rules[0].args[3] == 2

# Generated at 2022-06-12 09:51:14.132345
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    lst = []

    def func_1(x: int) -> str:
        lst.append(x)
        return f"A{x}"

    def func_2(y: int) -> str:
        lst.append(y)
        return f"B{y}"

    class DummyRenderType_1(RenderType):
        def __init__(self, x: int):
            self.args = (x,)

    class DummyRenderType_2(RenderType):
        def __init__(self, y: int):
            self.args = (y,)

    r = Register()
    r.set_renderfunc(DummyRenderType_1, func_1)

    r.foo = Style(DummyRenderType_1(1))
    r.bar = Style(DummyRenderType_1(2))

# Generated at 2022-06-12 09:51:23.365659
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, Sgr

    # Create a custom register.
    reg = Register()

    # Create a style and add it to the register
    red = Style(RgbFg(255, 0, 0))
    reg.red = red

    # Create a simple renderfunc.
    def renderer(r, g, b):
        return f"{r}, {g}, {b}"

    # Register renderfunc.
    reg.set_renderfunc(RgbFg, renderer)

    # Set 8bit call function.
    reg.set_eightbit_call(RgbFg)

    # Call the register.
    rendered = reg(255, 0, 0)

    # Check rendered with custom renderfunc.
    assert rendered == "255, 0, 0"

    # Call the register.

# Generated at 2022-06-12 09:51:33.731080
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Create register-object with some styles
    r = Register()
    r.foo = Style(r.fg(1))
    r.bar = Style(r.fg(2), r.bg(3))
    r.moo = Style(r.fg(4), r.bg(5), r.ef(6))

    # Test method as_dict
    d = r.as_dict()
    assert d == {"foo" : "\x1b[38;5;1m", "bar" : "\x1b[38;5;2m\x1b[48;5;3m", "moo" : "\x1b[38;5;4m\x1b[48;5;5m\x1b[1;6m"}



# Generated at 2022-06-12 09:51:38.980193
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    a = Register()
    b = Register()
    assert a.renderfuncs == b.renderfuncs

    def new_renderfunc(x):
        return 42

    a.set_renderfunc(int, new_renderfunc)

    assert a.renderfuncs == b.renderfuncs
    assert a.renderfuncs == {int: new_renderfunc}



# Generated at 2022-06-12 09:51:52.800834
# Unit test for method mute of class Register
def test_Register_mute():

    class RenderType1(RenderType):
        """
        Test class for testing class Register.
        """
        pass

    r1 = Register()
    r1.set_renderfunc(RenderType1, lambda *args, **kwargs: '\x1b[38;2;{};{};{}m'.format(*args, **kwargs))
    r1.mute()

    for name in dir(r1):
        if not name.startswith("_"):
            assert(not isinstance(getattr(r1, name), Style))

    r1.unmute()

    for name in dir(r1):
        if not name.startswith("_"):
            assert(isinstance(getattr(r1, name), Style))

# Generated at 2022-06-12 09:51:55.274959
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbBg
    from .renderfunc import CSIG_BGR

    reg = Register()
    reg.set_renderfunc(RgbBg, CSIG_BGR)
    assert reg.renderfuncs[RgbBg] == CSIG_BGR



# Generated at 2022-06-12 09:52:03.661787
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty import fg, bg, ef, rs

    assert Style(fg.blue) == fg.blue
    assert Style(fg.blue, ef.bold) == fg.blue + ef.bold
    assert Style(fg.blue, ef.bold, fg.blue) == fg.blue + ef.bold + fg.blue

    assert Style(bg.red, rs.bold) == bg.red + rs.bold

    assert Style(bg.red, fg.blue, ef.bold, rs.bold) == bg.red + fg.blue + ef.bold + rs.bold


# Generated at 2022-06-12 09:52:09.846282
# Unit test for method mute of class Register
def test_Register_mute():

    import sty

    # Empty register
    fg = sty.fg

    fg.orange = Style(sty.RgbFg(1,5,10), sty.Sgr(1))

    assert fg.orange == '\x1b[38;2;1;5;10m\x1b[1m'
    fg.mute()
    assert fg.orange == ''
    fg.unmute()
    assert fg.orange == '\x1b[38;2;1;5;10m\x1b[1m'

# Generated at 2022-06-12 09:52:20.708539
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import fg, bg

    class MockRenderType:
        def __init__(self, *args):
            self.args = args

    class MockRenderFunc:
        def __init__(self, _):
            pass

    r = Register()
    r.set_renderfunc(MockRenderType, MockRenderFunc)
    setattr(r, "mock_style_1", Style(MockRenderType(42)))
    setattr(r, "mock_style_2", Style(MockRenderType(42), MockRenderType(21)))
    setattr(r, "mock_style_3", Style(Style(MockRenderType(42)), MockRenderType(21)))

    assert hasattr(r, "mock_style_1")

# Generated at 2022-06-12 09:52:31.337130
# Unit test for constructor of class Style
def test_Style():
    # test with empty rules
    style1 = Style()
    assert style1.rules == ()
    assert str(style1) == ""

    # test with RenderType
    style2 = Style(RgbFg(10, 10, 10), RgbBg(1, 2, 3))
    assert len(style2.rules) == 2
    assert all(isinstance(r, RenderType) for r in style2.rules)
    assert str(style2) == "\x1b[38;2;10;10;10m\x1b[48;2;1;2;3m"

    # test with Style

# Generated at 2022-06-12 09:52:36.210310
# Unit test for constructor of class Style
def test_Style():

    class RgbFg(RenderType):
        def render(r: int, g: int, b: int) -> str:
            pass

    s = Style(RgbFg(1, 1, 1))
    assert isinstance(s, Style)
    assert getattr(s, "rules")[0].args == (1, 1, 1)
    assert not hasattr(s, "renderfuncs")



# Generated at 2022-06-12 09:52:42.241143
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Fg(Register):
        pass
    fg = Fg()

    # NOTE: The following two lines of code should be equivalent.
    fg.green = Style(fg.green, fg.green)
    fg.green = Style(fg.grass, fg.grass)

    # TODO: This should raise an error.
    # fg.other = Style(fg.pink, fg.red)

# Generated at 2022-06-12 09:52:51.347127
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    rgbfg_func = lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"
    sgr_func = lambda sgr: f"\x1b[{sgr}m"

    test_register = Register()
    test_register.renderfuncs = {RgbFg: rgbfg_func, Sgr: sgr_func}

    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r*2};{g*2};{b*2}m")

# Generated at 2022-06-12 09:52:55.971925
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg

    class Dummy(Style):
        pass

    style = Dummy(Sgr(1), RgbFg(1, 2, 3))
    assert isinstance(style, str)
    assert style.rules == (Sgr(1), RgbFg(1, 2, 3))


# Generated at 2022-06-12 09:53:16.600637
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr
    from .flavour import basic

    register = Register()

    style_blue = Style(Sgr(34))
    register.blue = style_blue

    assert str(register.blue) == "\x1b[34m"

    register.mute()

    assert str(register.blue) == ""

    register.unmute()

    assert str(register.blue) == "\x1b[34m"

# Generated at 2022-06-12 09:53:21.233729
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(style, Style) == True
    assert isinstance(style, str) == True
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-12 09:53:32.136597
# Unit test for method __call__ of class Register
def test_Register___call__():

    fg = Register()

    fg.red = style = Style(rgb.rgbFg(255, 0, 0))
    fg.blue = style = Style(rgb.rgbFg(0, 0, 255))

    assert fg("red") == "\x1b[38;2;255;0;0m"
    assert fg("blue") == "\x1b[38;2;0;0;255m"

    assert fg(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert fg(0, 0, 255) == "\x1b[38;2;0;0;255m"

    assert fg(144) == ""


# Generated at 2022-06-12 09:53:36.887477
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertypes import Sgr, RGB

    reg = Register()
    attr_name = "attr"
    val = Style(Sgr(1))
    setattr(reg, attr_name, val)

    reg.mute()

    assert reg.is_muted
    assert val.value == ""



# Generated at 2022-06-12 09:53:45.348884
# Unit test for method __new__ of class Style
def test_Style___new__():

    teststyle1 = Style(value="test")
    teststyle2 = Style(value="test", rules=["test2"])

    assert isinstance(teststyle1, Style)
    assert isinstance(teststyle1, str)
    assert str(teststyle1) == "test"

    assert isinstance(teststyle2, Style)
    assert isinstance(teststyle2, str)
    assert str(teststyle2) == "test"

    assert teststyle1.rules == []
    assert teststyle2.rules == ["test2"]

# Generated at 2022-06-12 09:53:52.087173
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, EightbitFg

    class TestBenchRegister(Register):

        def __init__(self):
            Register.__init__(self)
            self.set_renderfunc(RgbFg, lambda *x: "RGB")
            self.set_renderfunc(EightbitFg, lambda *x: "EightBit")
            self.orange = Style(RgbFg(1, 5, 10), value="RGB")
            self.red = Style(EightbitFg(1, value="EightBit"))

    tb = TestBenchRegister()
    assert tb("orange") == "RGB"
    assert tb(144) == "EightBit"
    assert tb(10, 15, 20) == "RGB"
    assert tb(255, 0, 0) == ""

# Generated at 2022-06-12 09:54:00.759032
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register

    # Define a test renderfunc.
    def func(x: int):
        return f"\x1b[{x}m"

    # Add renderfunc to test register.
    r.set_renderfunc(RenderType, func)

    # Add test style to register.
    r.test = Style(Sgr(0), Sgr(1), Sgr(2), Sgr(3))

    # Call method as_dict.
    d = r.as_dict()

    # Test the result.
    assert d == {"test": "\x1b[0m\x1b[1m\x1b[2m\x1b[3m"}

# Generated at 2022-06-12 09:54:11.577079
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Foo(RenderType):
        pass

    class Bar(RenderType):
        pass

    def render_foo(x: int) -> str:
        return f"Foo{x}"

    def render_bar(x: int) -> str:
        return f"Bar{x}"

    f = Register()
    f.set_renderfunc(Foo, render_foo)
    f.set_renderfunc(Bar, render_bar)

    # Normal 8bit-call
    assert f(42) == ""

    f.set_eightbit_call(Foo)
    assert f(42) == "Foo42"

    f.set_eightbit_call(Bar)
    assert f(42) == "Bar42"

    f.mute()
    assert f(42) == ""

    f.set_eightbit_

# Generated at 2022-06-12 09:54:19.275129
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .sgr import Sgr
    from .rgb import RgbFg, RgbBg

    class ColorRegister(Register):
        pass

    # Create some dummy rules.
    sgr_bold = Sgr(1)
    sgr_underline = Sgr(4)

    rgb_fg_cyan = RgbFg(0, 255, 255)
    rgb_fg_orange = RgbFg(1, 5, 10)
    rgb_bg_red = RgbBg(255, 0, 0)
    rgb_bg_blue = RgbBg(0, 0, 255)

    # Create style-rules.
    cyan_bold_underline = Style(rgb_fg_cyan, sgr_bold, sgr_underline)

# Generated at 2022-06-12 09:54:25.335118
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def func1(x: str) -> str:
        return x

    def func2(x: str) -> str:
        return x

    reg = Register()
    reg.set_renderfunc(str, func1)
    assert func1 == reg.renderfuncs[str]
    reg.set_renderfunc(str, func2)
    assert func2 == reg.renderfuncs[str]

# Generated at 2022-06-12 09:54:52.118597
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()

    # Test call with int
    setattr(r, "red", "red")
    assert r(1) == ""
    assert r(1) == ""
    r.set_eightbit_call(None)
    setattr(r, "red", Style("red"))
    assert r(1) == ""
    r.set_eightbit_call(RgbFg)
    setattr(r, "red", Style(RgbFg(255, 0, 0)))
    assert r(1) == ""

    # Test call with str
    setattr(r, "red", "red")
    assert r("red") == "red"
    setattr(r, "red", Style("red"))
    assert r("red") == "red"

# Generated at 2022-06-12 09:54:55.672276
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.is_muted == False
    assert issubclass(type(register.eightbit_call), Callable)
    assert issubclass(type(register.rgb_call), Callable)
    assert issubclass(type(register.renderfuncs), dict)
    assert issubclass(type(register.renderfuncs), dict)

# Generated at 2022-06-12 09:54:59.088818
# Unit test for constructor of class Style
def test_Style():
    red = Style("red")
    assert red.rules == ("red",)
    assert red == "red"

    bold_red = Style(red, "bold")
    assert bold_red.rules == ("red", "bold")
    assert bold_red == "redbold"



# Generated at 2022-06-12 09:55:09.576374
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Test8bitRenderType(RenderType):

        def __init__(self, *args):
            self.args = args

    class Test_Register(Register):
        pass

    test_register = Test_Register()

    def test_renderfunc(value):
        return f"\x1b[38;3;{value}m"

    # Add renderfunc
    test_register.set_renderfunc(Test8bitRenderType, test_renderfunc)

    # Set eightbit_call to use Test8bitRenderType
    test_register.set_eightbit_call(Test8bitRenderType)

    setattr(test_register, "test", Style(Test8bitRenderType(42)))

    assert test_register.test == "\x1b[38;3;42m"

# Generated at 2022-06-12 09:55:12.461982
# Unit test for method copy of class Register
def test_Register_copy():
    from .sty import Sty
    import sys

    sty: Sty = Sty()
    fg: Register = sty.fg.copy()
    assert sys.getrefcount(fg) == 2
    assert sys.getrefcount(sty.fg) == 2

# Generated at 2022-06-12 09:55:18.938612
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register = Register()
    register.test = Style(RgbFg(0, 0, 0))
    assert register.test == '\x1b[38;2;0;0;0m'
    register.test = Style(RgbFg(2, 3, 4))
    assert register.test == '\x1b[38;2;2;3;4m'



# Generated at 2022-06-12 09:55:25.620337
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    The function creates a new dummy Register, adds some values and tests the
    result of the "as_namedtuple" method.
    """
    d = Register()
    d.foo = Style(value="Foo")
    d.bar = Style(value="Bar")
    d.fu = Style(value="Fu")

    t = d.as_namedtuple()

    assert t.foo == "Foo"
    assert t.bar == "Bar"
    assert t.fu == "Fu"

# Generated at 2022-06-12 09:55:28.181368
# Unit test for method __new__ of class Style
def test_Style___new__():
    test_rules = (RgbFg(1,2,3), Sgr(1))
    test_style = Style(*test_rules)
    assert test_style.rules == test_rules


# Generated at 2022-06-12 09:55:36.274524
# Unit test for constructor of class Register
def test_Register():

    def test_func(*args):
        pass

    r = Register()
    r.set_renderfunc(RenderType, test_func)
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    r.mute()
    r.unmute()

    assert isinstance(r, Register)
    assert isinstance(r.as_namedtuple(), NamedTuple)
    assert isinstance(r.as_dict(), dict)
    assert isinstance(r.copy(), Register)

# Generated at 2022-06-12 09:55:42.016306
# Unit test for constructor of class Style
def test_Style():
    rule_type = namedtuple("RuleType", ["args", "rendered"])
    class Sgr(RenderType):
        pass

    class RgbFg(RenderType):
        pass

    # Helpers
    def render_sgr(*args) -> str:
        return f"\x1b[{';'.join(map(str, args))}m"

    def render_rgb_fg(*args) -> str:
        return f"\x1b[38;2;{';'.join(map(str, args))}m"

    def test_render_rule(renderfuncs, rule, expected):
        rendered, rules = _render_rules(renderfuncs, rule)
        assert rendered == expected

    # Tests.
    sgr_func = render_sgr
    rgb_fg_func = render_rgb_

# Generated at 2022-06-12 09:56:24.763151
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Somehow the following tuple is needed.
    # Otherwise the type system is confused.
    T = Tuple[RenderType, Callable]

    Sgr = NamedTuple("Sgr", [("args", Tuple[int, ...])])
    SgrFg = NamedTuple("SgrFg", [("code", int)])

    def render_SgrFg_func(code: int) -> str:
        return chr(code)

    def render_Sgr_func(code: int) -> str:
        return chr(code)

    r = Register()
    r.set_renderfunc(SgrFg, render_SgrFg_func)
    r.set_renderfunc(Sgr, render_Sgr_func)

    r.credit = Style(SgrFg(65))
    r.warn

# Generated at 2022-06-12 09:56:33.523397
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Basic test
    test_reg = Register()

    test_reg.eightbit_call = lambda x: x
    test_reg.set_eightbit_call(int)


# Generated at 2022-06-12 09:56:34.134644
# Unit test for constructor of class Register
def test_Register():
    r = Register()

# Generated at 2022-06-12 09:56:40.646035
# Unit test for method __call__ of class Register
def test_Register___call__():
    from os import name
    from sty import fg

    if name == "nt":
        # Windows does not support 24bit colors
        # TODO: Should we raise an error here?
        return

    len_args = lambda args: len(args)

    f = Register()
    f.set_eightbit_call(len_args)
    f.set_rgb_call(len_args)

    assert f("black") == 0
    assert f(1) == 1
    assert f("orange") == 0
    assert f(12, 34, 56) == 3

# Generated at 2022-06-12 09:56:44.856354
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg

    class A(Register):
        red = Style(RgbFg(1, 0, 0))

    register = A()
    style = register("red")

    assert style == "\x1b[38;2;1;0;0m"

    style = register(1, 0, 0)

    assert style == "\x1b[38;2;1;0;0m"



# Generated at 2022-06-12 09:56:53.147670
# Unit test for method copy of class Register
def test_Register_copy():
    """
    The copy method should copy everything except the render functions and the
    is_muted flag.
    """
    reg = Register()
    reg.renderfuncs.update({"Test": 255})
    reg.is_muted = True
    reg.foo = Style(value="bar")

    reg_copy = reg.copy()

    assert reg_copy.is_muted == False
    assert reg_copy.renderfuncs == {}
    assert reg_copy.foo == "bar"



# Generated at 2022-06-12 09:56:55.319156
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Test default case
    r = Register()

    rgb_call = r.rgb_call

    rgb_call(3, 4, 5)

# Generated at 2022-06-12 09:57:02.325020
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr
    from .ansi_color_table import fg

    rt = RgbFg(1, 2, 3)
    rt_str = "\x1b[38;2;1;2;3m"
    s = Style(rt, Sgr(1))
    s_str = "\x1b[38;2;1;2;3m\x1b[1m"

    assert (s_str == str(s))

    assert (s == fg.red)

    assert (fg.red == str(fg.red))

    assert (rt_str == str(rt))

    assert (rt == fg.red.rules[0])


# Generated at 2022-06-12 09:57:11.702382
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    import sty

    fg = sty.fg
    bg = sty.bg
    ef = sty.ef


# Generated at 2022-06-12 09:57:18.274405
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from . import fg

    # Generate a new namedtuple
    nt = fg.as_namedtuple()

    # Generate a new dict
    d = fg.as_dict()

    assert hasattr(nt, "black")
    assert nt.black == "\x1b[38;5;16m"

    assert "black" in d
    assert d["black"] == "\x1b[38;5;16m"



# Generated at 2022-06-12 09:58:40.518552
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Simple example to test the Register class.
    """

    r = Register()

    r.set_renderfunc(RenderType, lambda x: "RENDERED")

    r.fg = Style(RenderType(7))
    r.bg = Style(RenderType(17))

    assert r.fg == "RENDERED"
    assert r.bg == "RENDERED"

    r.mute()

    assert r.fg == ""
    assert r.bg == ""

    r.unmute()

    assert r.fg == "RENDERED"
    assert r.bg == "RENDERED"

# Generated at 2022-06-12 09:58:50.480091
# Unit test for method unmute of class Register
def test_Register_unmute():

    import pytest
    from .rendertype import RgbFg

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.mute()
    assert fg.red == ""
    fg.unmute()
    assert fg.red != ""

    # Test with style-rule being a str
    fg.blue = Style(RgbFg(0, 0, 255))
    fg.mute()
    assert fg.blue == ""
    fg.unmute()
    assert fg.blue != ""

    fg.yellow = Style(RgbFg(100, 100, 0))
    fg.mute()
    assert fg.yellow == ""
    fg.unmute()
    assert fg.yellow != ""


# Generated at 2022-06-12 09:58:57.596961
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass
    class Sgr(RenderType):
        pass
    class EightBitFg(RenderType):
        pass

    # create a new register class
    class RgbRegister:

        def __init__(self):
            self.renderfuncs = {
                RgbFg: lambda r, g, b: "\x1b[38;2;{};{};{}m".format(r, g, b),
                Sgr: lambda s: "\x1b[{}m".format(s),
                EightBitFg: lambda c: "\x1b[38:5:{}m".format(c),
            }
            self.is_muted = False

            # Register object calls

# Generated at 2022-06-12 09:59:05.609748
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rules import Sgr
    from .rules.bg import Bg255
    from .rules.fg import Fg255

    assert(str(Style(Fg255(42))) == "\\x1b[38;5;42m")
    assert(str(Style(Fg255(42), Sgr(1))) == "\\x1b[38;5;42m\\x1b[1m")
    assert(
        str(
            Style(Fg255(42), Bg255(33), Sgr(1, 4))
        )
        == "\\x1b[38;5;42m\\x1b[48;5;33m\\x1b[1m\\x1b[4m"
    )

# Generated at 2022-06-12 09:59:08.276176
# Unit test for constructor of class Register
def test_Register():

    # Create test register
    register = Register()

    # Test success
    assert isinstance(register, Register)
    assert register.is_muted == False



# Generated at 2022-06-12 09:59:12.095126
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg

    class MyTuple(NamedTuple):
        red: str
        orange: str

    fg_mt = MyTuple(**fg.as_dict())

    assert isinstance(fg_mt, MyTuple)
    assert fg.red.value == fg_mt.red
    assert fg.orange.value == fg_mt.orange

# Generated at 2022-06-12 09:59:18.265146
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .render import Render

    render = Render()
    fg = render.fg
    fg_nt = fg.as_namedtuple()
    assert fg_nt.green == fg.green
    assert fg_nt.black == fg.black
    assert fg_nt._0_black == fg._0_black
    assert fg_nt._0_red == fg._0_red
    assert fg_nt.reset == fg.reset
    assert hasattr(fg_nt, "green")
    assert hasattr(fg_nt, "black")
    assert hasattr(fg_nt, "_0_black")
    assert hasattr(fg_nt, "_0_red")
    assert hasattr(fg_nt, "reset")

# Generated at 2022-06-12 09:59:28.238051
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RenderType, Sgr

    class CustomRegister(Register):
        green = Style(Sgr(42))

    reg = CustomRegister()

    # Before setup
    assert reg.eightbit_call == reg.renderfuncs[Sgr]
    assert str(reg(42)) == "\x1b[42m"

    # After setup
    reg.set_eightbit_call(Sgr)
    assert reg.eightbit_call == reg.renderfuncs[Sgr]
    assert str(reg(42)) == "\x1b[42m"

    # In case of invalid input
    class InvalidInputRenderType(RenderType):
        pass

    # Should not raise exception
    reg.set_eightbit_call(InvalidInputRenderType)

    # Should not raise exception

# Generated at 2022-06-12 09:59:34.842763
# Unit test for method __call__ of class Register
def test_Register___call__():

    from sty import fg, rs

    fg.green = Style(fg.green.rules)

    assert fg(42) == "\x1b[38;5;42m"
    assert fg("green") == "\x1b[38;5;2m"

    fg.white = Style(fg.white.rules)
    assert fg(10, 92, 255) == "\x1b[38;2;10;92;255m"

    fg.set_eightbit_call(fg.Eightbit)
    assert fg(144) == "\x1b[38;5;144m"

    fg.set_rgb_call(fg.Rgb)
    assert fg(255, 255, 255) == "\x1b[38;2;255;255;255m"


# Generated at 2022-06-12 09:59:44.294043
# Unit test for constructor of class Style
def test_Style():
    """
    This class should be a string, that stores the different stylegules
    that were used to create it (`rules`).
    """

    # Single rule
    s = Style(RgbFg(10, 10, 10))

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s.rules == (RgbFg(10, 10, 10),)

    # Multiple rules
    s = Style(RgbFg(10, 10, 10), Sgr(1))

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s.rules == (RgbFg(10, 10, 10), Sgr(1))

    # Multiple rules and value