

# Generated at 2022-06-12 09:49:52.287432
# Unit test for constructor of class Register
def test_Register():

    # Create a new register instance.
    register = Register()

    # Give the register two render-functions.
    register.set_renderfunc(RenderType.Sgr, lambda *args, **kwargs: "SGR_FUNC_CALL")
    register.set_renderfunc(RenderType.RgbFg, lambda *args, **kwargs: "RGB_FUNC_CALL")

    # Create a new style-rule and store it in the register object.
    register.my_style = Style(
        RenderType.Sgr("my_style"), RenderType.RgbFg("my_style")
    )

    # Confirm that the expected value is set.
    assert str(register.my_style) == "SGR_FUNC_CALLRGB_FUNC_CALL"

# Generated at 2022-06-12 09:50:02.572418
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .render import render
    from .sgr import Sgr
    reg = Register()
    reg.set_renderfunc(Sgr, render)
    reg.bold = Style(Sgr(1))
    reg.italics = Style(Sgr(3))
    assert reg("bold") == "\x1b[1m"
    assert reg("italics") == "\x1b[3m"

    class RgbFg(NamedTuple): pass
    reg.set_eightbit_call(RgbFg)
    reg.set_renderfunc(RgbFg, render)
    reg.black = Style(RgbFg(0, 0, 0))
    reg.white = Style(RgbFg(255, 255, 255))

# Generated at 2022-06-12 09:50:14.525748
# Unit test for constructor of class Register
def test_Register():

    def renderfunc(x: int) -> str:
        return "\x1b[38;5;" + str(x) + "m"

    r = Register()
    r.set_renderfunc(RgbFg, renderfunc)

    assert str(r) == ""

    r.black = Style(RgbFg(0, 0, 0))
    assert str(r.black) == "\x1b[38;5;0m"

    assert str(r(42)) == "\x1b[38;5;42m"

    r.set_renderfunc(RgbFg, lambda x, y, z: x + y + z)
    assert str(r(1, 2, 3)) == "123"

    r.set_eightbit_call(RgbFg)

# Generated at 2022-06-12 09:50:21.898352
# Unit test for method __call__ of class Register
def test_Register___call__():
    class TestRegister(Register):
        pass

    # Setup
    r = TestRegister()
    r.z1 = Style(rgb_fg=(255, 0, 0), sgr_bold=True)
    r.z2 = Style(rgb_fg=(0, 255, 0), rgb_bg=(0, 0, 255))
    r.z3 = Style(rgb_bg=(0, 0, 255), rgb_fg=(0, 255, 0))
    r.set_renderfunc(
        rendertype=RgbFg,
        func=lambda r, g, b: f"{r + g + b}",
    )
    r.set_renderfunc(
        rendertype=RgbBg,
        func=lambda r, g, b: f"bg{r + g + b}",
    )

# Generated at 2022-06-12 09:50:26.721109
# Unit test for method __call__ of class Register
def test_Register___call__():

    class DummyRenderType(RenderType):
        pass

    @DummyRenderType.render("render")
    def render(x, y):
        return "dummy"

    reg = Register()
    reg.set_renderfunc(DummyRenderType, render)

    r = reg("render")
    assert r == "dummy"

# Generated at 2022-06-12 09:50:35.354527
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .render import Eightbit, RgbFg, RgbBg, RgbEf

    # Setup render-functions
    def rgb_render(r, g, b):
        return repr((r, g, b))

    def eightbit_render(x):
        return repr(x)

    # Create register
    r = Register()
    r.set_renderfunc(Eightbit, eightbit_render)
    r.set_renderfunc(RgbFg, rgb_render)
    r.set_renderfunc(RgbBg, rgb_render)
    r.set_renderfunc(RgbEf, rgb_render)

    # Set style
    r.red = Style(RgbFg(66, 23, 32))

    # Eightbit call
    assert r(17) == "17"

# Generated at 2022-06-12 09:50:42.103996
# Unit test for constructor of class Register
def test_Register():
    rs = Register()
    assert isinstance(rs, Register)
    assert hasattr(rs, "renderfuncs") and rs.renderfuncs == {}
    assert hasattr(rs, "is_muted") and rs.is_muted is False
    assert hasattr(rs, "eightbit_call")
    assert callable(rs.eightbit_call)
    assert hasattr(rs, "rgb_call")
    assert callable(rs.rgb_call)
    assert "mute" in dir(rs)
    assert "unmute" in dir(rs)



# Generated at 2022-06-12 09:50:48.986526
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()

    r.red = Style(value="\x1b[31m")
    r.green = Style(value="\x1b[32m")
    r.blue = Style(value="\x1b[34m")
    r.pink = Style(value="\x1b[35m")

    assert r("red") == r.red
    assert r("green") == r.green
    assert r("blue") == r.blue
    assert r("pink") == r.pink



# Generated at 2022-06-12 09:50:50.429794
# Unit test for constructor of class Register
def test_Register():
    assert Register().__class__.__name__ == "Register"

# Generated at 2022-06-12 09:50:53.017526
# Unit test for constructor of class Register
def test_Register():
    fg = Register()
    assert fg.is_muted == False
    assert fg.eightbit_call == fg.rgb_call == (lambda x: x)

# Generated at 2022-06-12 09:51:04.941342
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr

    class MockRegister(Register):
        red = Style(RgbFg(255, 0, 0))

    reg = MockRegister()
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"{r} {g} {b}")

    assert reg.red == "255 0 0"

# Generated at 2022-06-12 09:51:14.830228
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Create a Style instance and make sure that its ``rules`` attribute was set properly.
    Also check that the instance is a string.
    """
    from .rendertype import RgbFg, RgbBg, EightbitFg, EightbitBg, Sgr

    # Create a Style object
    style = Style(RgbFg(11, 22, 33), RgbBg(44, 55, 66), EightbitFg(1), EightbitBg(2))
    style = Style(style, Sgr(1))

    # Make sure the Style object is a str.
    assert isinstance(style, str)

    # Make sure that the _rules attribute is set properly

# Generated at 2022-06-12 09:51:16.041586
# Unit test for constructor of class Register
def test_Register():
    fg = Register()
    assert fg is not None


# Generated at 2022-06-12 09:51:25.680709
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertypes import AixtermFg, AixtermBg, AixtermBold, AixtermResetSequence

    from .renderfuncs import aixterm256fg_func, aixterm256bg_func

    from .register import Register

    from .colorcodes import ColorCodes as cc

    reg = Register()

    # Set renderfuncs for register
    reg.set_renderfunc(AixtermFg, aixterm256fg_func)
    reg.set_renderfunc(AixtermBg, aixterm256bg_func)
    reg.set_renderfunc(AixtermBold, lambda: "\x1b[1m")
    reg.set_renderfunc(AixtermResetSequence, lambda: "\x1b[0m")

    # Set color codes for register
    reg.red

# Generated at 2022-06-12 09:51:31.192312
# Unit test for method unmute of class Register
def test_Register_unmute():

    from . import fg

    fg.unmute()

    assert fg.is_muted is False

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert fg.yellow == "\x1b[38;2;255;255;0m"
    assert fg.blue == "\x1b[38;2;0;0;255m"


# Generated at 2022-06-12 09:51:41.956893
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Import RenderType class
    from sty.rendertype import RenderType

    # Make Register instance
    R = Register()

    # Add a rendertype to the register
    @R.set_renderfunc(RenderType)
    def test_renderfunc(*args, **kwargs):
        return "RENDERFUNC-CALLED"

    # Set 8bit renderfunc
    R.set_eightbit_call(RenderType)

    # Test if eightbit call works
    assert R(42) == "RENDERFUNC-CALLED"

    # Add an attribute to register
    R.test = Style("TEST-STYLE")

    # Test if attribute can be called
    assert R("test") == "TEST-STYLE"

    # Test if empty string is returned if register is muted
    R.mute()
   

# Generated at 2022-06-12 09:51:51.918703
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Unit test for method set_eightbit_call of class Register.
    """
    from .rendertype import RgbFg, RgbBg, Ef

    rgbfg = RgbFg(255, 125, 50)
    rgb_bg = RgbBg(255, 125, 50)
    ef = Ef()

    # Create register-object and add render function
    reg = Register()
    reg.set_renderfunc(RgbFg, lambda r, g, b: "rgb({r}, {g}, {b})".format(r=r, g=g, b=b))

    # Set input eightbit-call to be RgbFg.
    reg.set_eightbit_call(RgbFg)

    assert str(reg(125)) == "rgb(125, 125, 50)"

# Generated at 2022-06-12 09:52:02.145621
# Unit test for constructor of class Style
def test_Style():
    Style(RgbFg(10,20,30))
    Style(RgbFg(10,20,30), Sgr(1))
    Style(RgbFg(10,20,30), Sgr(1), Sgr(4))
    Style(RgbFg(10,20,30), Sgr(1), RgbBg(10,20,30))
    Style(RgbFg(10,20,30), Sgr(1), RgbBg(10,20,30), Sgr(4))
    Style(RgbFg(10,20,30), Sgr(1), Sgr(4), RgbBg(10,20,30), Sgr(1), Sgr(2))

# Generated at 2022-06-12 09:52:09.538087
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()

    assert r(144) == ""

    r.set_eightbit_call(RenderType)

    assert r(144) == "\x1b[38;5;144m"

    r.set_rgb_call(RenderType)

    assert r(144, 49, 42) == "\x1b[38;2;144;49;42m"

    assert r("red") == "\x1b[31m"

    r.set_eightbit_call(None)

    assert r(144) == ""

    r.set_rgb_call(None)

    assert r(144, 49, 42) == ""

# Generated at 2022-06-12 09:52:15.118192
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rules import RgbFg, Sgr
    from .util import is_valid_ansi

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert is_valid_ansi(str(style))

# Generated at 2022-06-12 09:52:22.205770
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()

    register.fg_red = Style(RedFg())
    register.bg_blue = Style(BlueBg())

    tp = register.as_namedtuple()

    assert tp.fg_red == register.fg_red
    assert tp.bg_blue == register.bg_blue

# Generated at 2022-06-12 09:52:26.331436
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r2 = r1.copy()
    assert id(r2) != id(r1)
    assert r1 == r2
    for name in dir(r1):
        assert id(getattr(r1, name)) != id(getattr(r2, name))



# Generated at 2022-06-12 09:52:31.517708
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class NewRegister(Register):
        pass

    newreg = NewRegister()
    newreg.new_color = Style(RgbFg(0,0,0))

    d = newreg.as_dict()
    assert d["new_color"] == "\x1b[38;2;0;0;0m"



# Generated at 2022-06-12 09:52:39.022678
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, RgbBg, ResetStyle

    reg = Register()

    for name, value in {"red" : RgbFg(255, 0, 0),
                        "blue": RgbFg(0, 0, 255),
                        "green" : RgbBg(0, 255, 0)}.items():
        setattr(reg, name, Style(value))

    funcs = {RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
             RgbBg: lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m",
             ResetStyle: lambda: "\x1b[m"}


# Generated at 2022-06-12 09:52:44.312409
# Unit test for method copy of class Register
def test_Register_copy():
    # create a basic register
    register1 = Register()
    # add some attributes
    register1.attr1 = Style(1)
    register1.attr2 = Style(2)
    # create a copy
    register2 = register1.copy()

    # check, if the copy is a different object
    assert register1 is not register2

    # check, if the attributes of the copy are different objects
    assert register1.attr1 is not register2.attr1
    assert register1.attr2 is not register2.attr2

# Generated at 2022-06-12 09:52:49.007837
# Unit test for method copy of class Register
def test_Register_copy():
    import copy

    r1 = Register()
    r1.a = Style()

    r2 = r1.copy()
    assert r1 == r2
    assert r1 is not r2

    r1.a = Style(*[], value="Hello World!")
    assert r1.a == r2.a
    assert r1.a is not r2.a

# Generated at 2022-06-12 09:52:56.394667
# Unit test for method __new__ of class Style
def test_Style___new__():
    a = Style(RgbBg(255, 255, 255), value="")
    assert a == ""

    b = Style(Bold(), value="!@#$")
    assert b == "!@#$"

    c = Style(Bold(), value="")
    assert c == ""

    d = Style(RgbBg(255, 255, 255), value="!@#$")
    assert d == "!@#$"


# Generated at 2022-06-12 09:52:57.882482
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:53:04.047833
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Unit test for method set_renderfunc.
    """

    class Sgr(RenderType):
        """Custom Sgr."""

        def render(self):
            return "sgr"

    class Bold(RenderType):
        """Custom Bold."""

        def render(self):
            return "bold"

    # Create register-object and add renderfuncs.
    r = Register()
    r.set_renderfunc(Sgr, lambda *args: "sgr")
    r.set_renderfunc(Bold, lambda *args: "bold")

    # Add Style-objects to the register-object.
    r.bold = Style(Bold(), Sgr(1))

    # Make sure render-functions work.
    assert(r.bold == "bold")

    # Make sure that a render-function can be replaced.


# Generated at 2022-06-12 09:53:13.550320
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test for method set_rgb_call of class Register
    """
    from .rendertype import RgbFg, RgbBg

    reg = Register()
    assert reg.rgb_call(1, 2, 3) == (1, 2, 3)

    reg.set_rgb_call(RgbFg)
    assert reg.rgb_call(1, 2, 3) == "\x1b[38;2;1;2;3m"

    reg.set_rgb_call(RgbBg)
    assert reg.rgb_call(1, 2, 3) == "\x1b[48;2;1;2;3m"

# Generated at 2022-06-12 09:53:24.803039
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Create renderfuncs
    renderfunc_sgr: Callable = lambda x: f"\x1b[{x}m"

    # Create new Register
    r1 = Register()
    r1.set_renderfunc(RenderType.Sgr, renderfunc_sgr)

    # Set style attributes
    r1.bold = Style(Sgr(1))
    r1.faint = Style(Sgr(2))

    # Test if attributes are set correctly
    assert r1.bold == "\x1b[1m"
    assert r1.faint == "\x1b[2m"


# Generated at 2022-06-12 09:53:33.494433
# Unit test for method copy of class Register
def test_Register_copy():
    # arrange
    sty = Register()
    sty.a = Style(RgbFg(1,2,3))
    sty.b = Style(EightbitFg(3))
    sty.c = Style(EightbitBg(4))
    sty.d = Style(Sgr(1))
    sty.e = Style()

    # act
    sty2 = sty.copy()

    # assert
    assert sty.a == sty2.a
    assert sty.b == sty2.b
    assert sty.c == sty2.c
    assert sty.d == sty2.d
    assert sty.e == sty2.e


# Generated at 2022-06-12 09:53:40.644613
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    This test validates that the style-register can be exported as a namedtuple.
    """
    # Create a new register and add an style to it.
    fg = Register()
    fg.green = Style(value='\x1b[38;5;10m')

    # Create the namedtuple from the register
    MyNamedTuple = fg.as_namedtuple()

    # Create the expected result namedtuple
    ExpectedNamedTuple = namedtuple("StyleRegister", {"green": '\x1b[38;5;10m'})

    assert isinstance(MyNamedTuple, NamedTuple)
    assert MyNamedTuple.green == ExpectedNamedTuple.green

# Generated at 2022-06-12 09:53:46.378721
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbFg(1, 2, 3), RgbBg(4, 5, 6), Sgr(1))
    assert s.rules == (RgbFg(1, 2, 3), RgbBg(4, 5, 6), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)

# Generated at 2022-06-12 09:53:47.623013
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-12 09:53:54.603008
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, EightbitFg

    class Register(Register):

        red = Style(RgbFg(255, 0, 0))
        orange = Style(EightbitFg(208))
        blue_bold = Style(EightbitFg(4), RgbFg(10, 10, 10), bold=True)

    r = Register()
    assert r(4) == "\x1b[38;5;4m"
    assert r('red') == "\x1b[38;2;255;0;0m"
    assert r(208) == "\x1b[38;5;208m"
    assert r(10, 10, 10) == "\x1b[38;2;10;10;10m"



# Generated at 2022-06-12 09:54:04.939506
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    '''
    Each test function should be called in order.
    '''

    r = Register()
    r.test_str = Style("test_str")
    assert isinstance(r.test_str, Style)

    r.test_Style = Style(r.test_str)
    assert isinstance(r.test_Style._value_, str)

    r.test_Styles = Style("test_Styles_1", "test_Styles_2")
    assert isinstance(r.test_Styles, Style)
    assert isinstance(r.test_Styles._value_, str)
    assert len(r.test_Styles._value_) == 2 * len("test_Styles")

    r.test_Styles_2 = Style(r.test_Styles, r.test_Style)

# Generated at 2022-06-12 09:54:08.428533
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg

    assert isinstance(fg(144), str)

    fg.mute()

    assert isinstance(fg(144), str)
    assert fg(144) == ""

# Generated at 2022-06-12 09:54:16.054799
# Unit test for method __call__ of class Register
def test_Register___call__():
    class TestRegisterClass(Register):
        pass
    testregister = TestRegisterClass()
    testregister.foo = Style(RenderType(1), Sgr(1))
    assert isinstance(testregister.foo, Style)
    assert isinstance(testregister.foo, str)
    testregister.eightbit_call = lambda x: Style(RenderType(x), Sgr(1))
    testregister.rgb_call = lambda x, y, z: Style(RgbFg(x, y, z))
    assert isinstance(testregister(42), str)
    assert isinstance(testregister(42, 43, 44), str)
    assert isinstance(testregister("foo"), str)

# Generated at 2022-06-12 09:54:22.074085
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .register.rendertype.eightbit import Eightbit

    s = Style(Eightbit(144))

    str(s) == r"\x1b[38;5;144m"
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s.rules == (Eightbit(144),)
    assert str(s) == r"\x1b[38;5;144m"



# Generated at 2022-06-12 09:54:36.287572
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Init
    my_register: Register = Register()
    style1 = Style(RgbFg(1,5,10))
    style2 = Style(RgbFg(13,37,42))
    my_register.my_style1 = style1
    my_register.my_style2 = style2

    # Test
    nt = my_register.as_namedtuple()
    assert nt.my_style1 == str(style1)
    assert nt.my_style2 == str(style2)

# Generated at 2022-06-12 09:54:40.493185
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test for method __new__ of class Style.

    :return: None
    """

    s = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-12 09:54:50.325144
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty import RgbFg, Sgr

    style = Style(
        RgbFg(10, 20, 30), Sgr(0), value="\x1b[38;2;10;20;30m\x1b[0m"
    )  # type: ignore
    assert style == "\x1b[38;2;10;20;30m\x1b[0m"
    assert style.rules[0] == RgbFg(10, 20, 30)
    assert style.rules[1] == Sgr(0)
    assert not issubclass(style.__class__, RenderType)



# Generated at 2022-06-12 09:54:57.410454
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    # Test register without render types
    assert register.renderfuncs == {}
    assert not hasattr(register, "test")
    assert register.is_muted is False

    # Test adding/setting render type
    def test_render_func():
        pass

    register.set_renderfunc(type("test_render_type"), test_render_func)

    assert type("test_render_type") in register.renderfuncs
    assert register.renderfuncs[type("test_render_type")] == test_render_func

    # Test adding style attribute
    setattr(register, "test", Style("test"))
    assert hasattr(register, "test")

    # Test __call__ without attributes
    assert register("test") == ""

    # Test __call__ with attributes

# Generated at 2022-06-12 09:55:08.113620
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    r = Register()

    r.red = Style(RgbFg(255, 0, 0))
    assert str(r.red) == "\x1b[38;2;255;0;0m"

    r.blue = Style(RgbFg(0, 0, 255), Bold())
    assert str(r.blue) == "\x1b[38;2;0;0;255m\x1b[1m"

    r.green = Style(RgbFg(0, 255, 0))

    r.yellow = Style(r.red, r.green)
    assert str(r.yellow) == "\x1b[38;2;255;0;0m\x1b[38;2;0;255;0m"

    r.yellow = Style(r.red)

# Generated at 2022-06-12 09:55:12.500093
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg
    from .utils import ansi_fg

    reg = Register()
    reg.set_renderfunc(rendertype=RgbFg, func=ansi_fg)
    reg.set_eightbit_call(rendertype=RgbFg)
    assert reg.eightbit_call == ansi_fg
    reg.mute()
    assert reg.eightbit_call == ansi_fg


# Generated at 2022-06-12 09:55:22.781635
# Unit test for method copy of class Register
def test_Register_copy():
    fg_black = Style(RgbFg(0, 0, 0))
    fg_black.set_renderfunc(RgbFg, lambda r, g, b: "")

    fg_white = Style(RgbFg(255, 255, 255))
    fg_white.set_renderfunc(RgbFg, lambda r, g, b: "")

    fg = Register()
    fg.black = fg_black
    fg.white = fg_white

    new_fg = fg.copy()

    assert fg is not new_fg
    assert fg.black is not new_fg.black
    assert fg.white is not new_fg.white


# Generated at 2022-06-12 09:55:29.970890
# Unit test for method mute of class Register
def test_Register_mute():

    class SgrRegister(Register):
        """
        A simple register class that uses Sgr for rendering.
        """

        def __init__(self):
            super().__init__()
            self.bold = Style(Sgr(1))
            self.italic = Style(Sgr(3))
            self.underline = Style(Sgr(4))
            self.blink = Style(Sgr(5))
            self.reverse = Style(Sgr(7))
            self.reset = Style(Sgr(0))
            self.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    sgr = SgrRegister()

    assert isinstance(sgr.bold, Style)
    assert sgr.bold == "\x1b[1m"

    sgr.mute()



# Generated at 2022-06-12 09:55:38.629431
# Unit test for method unmute of class Register
def test_Register_unmute():
    reg = Register()
    reg.set_eightbit_call(RenderType)
    reg.set_rgb_call(RenderType)
    reg.black = Style(RenderType(30))
    reg.green = Style(RenderType(32))
    reg.red = Style(RenderType(31))

    # unmute
    reg.is_muted = True
    assert reg.black == ""
    assert reg.green == ""
    assert reg.red == ""

    reg.unmute()
    assert reg.black == "\x1b[30m"
    assert reg.green == "\x1b[32m"
    assert reg.red == "\x1b[31m"

# Generated at 2022-06-12 09:55:45.895908
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class MyRegister(Register):
        pass

    myreg = MyRegister()

    myreg.set_renderfunc(RenderType.Sgr, lambda x: f"sgr({x})")
    myreg.set_renderfunc(RenderType.Eightbit, lambda x: f"eightbit({x})")

    myreg.set_eightbit_call(RenderType.Sgr)
    assert myreg(42) == "sgr(42)"

    myreg.set_eightbit_call(RenderType.Eightbit)
    assert myreg(42) == "eightbit(42)"



# Generated at 2022-06-12 09:56:03.325168
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    _Register = Register()

    class _Eightbit(_Register):
        red = Style(RgbFg(255, 0, 0))

    class _Rgb(_Register):
        red = Style(RgbFg(255, 0, 0))

    _Rgb.set_renderfunc(RgbFg, lambda r, g, b: f"{r}-{g}-{b}")

    _Register.set_eightbit_call(RgbFg)
    _Register.set_rgb_call(RgbFg)

    assert _Eightbit.red == _Rgb.red
    assert _Register.red == str(_Eightbit.red)
    assert _Register.red == str(_Rgb.red)



# Generated at 2022-06-12 09:56:05.502914
# Unit test for constructor of class Style
def test_Style():
    r1 = Style(RgbFg(1, 2, 3))
    assert isinstance(r1, str)
    assert isinstance(r1, Style)



# Generated at 2022-06-12 09:56:09.340089
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test for register.as_dict()
    """
    from .api import fg
    from .rendertype import DecFg, DecBg, DecFx

    d2 = {"test": DecFg(42), "bar": DecBg(100), "baz": DecFx(1, 2, 3)}
    d = {**fg.as_dict(), **d2}
    fg2 = Register()
    for k, v in d.items():
        setattr(fg2, k, v)
    assert fg2.as_dict() == d



# Generated at 2022-06-12 09:56:18.494426
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, EightbitFg, RgbBg, EightbitBg, Sgr, TruecolorFg, TruecolorBg
    from .register import Register
    reg = Register()

    # Example registers
    reg.set_rgb_call(RgbFg)
    reg.set_eightbit_call(EightbitFg)
    reg.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;{};{};{}m".format(r, g, b))
    reg.set_renderfunc(EightbitFg, lambda x: "\x1b[38;5;{}m".format(x))
    reg.set_renderfunc(Sgr, lambda x: "\x1b[{}m".format(x))

    reg

# Generated at 2022-06-12 09:56:23.140389
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestType(RenderType):

        def __init__(self, a, b, c):
            pass

    f = lambda a,b,c: "foo"
    reg = Register()

    reg.set_renderfunc(TestType, f)

    assert reg.renderfuncs[TestType] == f

    reg.test = Style(TestType(1, 2, 3), TestType(4, 5, 6))

    assert str(reg.test) == "foo"


# Generated at 2022-06-12 09:56:31.344349
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    r = Register()
    r.blue = Style(RgbFg(0, 0, 1), Sgr(1))
    r.green = Style(RgbFg(0, 1, 0), Sgr(1))
    r.orange = Style(RgbFg(1, 0.5, 0), Sgr(1))
    r.red = Style(RgbFg(1, 0, 0), Sgr(1))
    r.violet = Style(RgbFg(1, 0, 1), Sgr(1))
    r.yellow = Style(RgbFg(1, 1, 0), Sgr(1))

    r.default_fg = Style(RgbFg(0, 0, 0), Sgr(1))

    # set render functions and calls

# Generated at 2022-06-12 09:56:40.607159
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RenderType

    class DummyRenderType(RenderType):
        pass

    class DummyRegister(Register):
        foo = Style(DummyRenderType(12), DummyRenderType(23))
        bar = Style(DummyRenderType(42), DummyRenderType(33))

    def _dummy_render_func(*args):
        return "Dummy Render Function {}".format(args)

    t = DummyRegister()
    t.set_renderfunc(DummyRenderType, _dummy_render_func)
    assert t("foo") == "Dummy Render Function (12,)\nDummy Render Function (23,)"
    assert t("bar") == "Dummy Render Function (42,)\nDummy Render Function (33,)"
    assert t(12, 23) == ""

# Generated at 2022-06-12 09:56:50.426947
# Unit test for method unmute of class Register
def test_Register_unmute():
    from sty import fg, bg

    fg.red = Style(fg.black, fg.red)

    # Test mute
    fg.mute()
    assert fg.red == ""

    # Test unmute
    fg.unmute()
    assert fg.red == "\x1b[30m\x1b[31m"

    fg.green = Style(fg.blue, fg.green)
    fg.mute()
    assert fg.green == ""
    fg.unmute()
    assert fg.green == "\x1b[34m\x1b[32m"

    fg.blue = Style(fg.black, fg.blue)
    # Test mute
    bg.mute()
    assert fg.blue == ""

    # Test unm

# Generated at 2022-06-12 09:56:54.358631
# Unit test for constructor of class Style
def test_Style():
    s = Style(foreground=RgbFg(42, 49, 255), background=RgbBg(255, 49, 42))
    assert isinstance(s, str)
    assert isinstance(s, Style)



# Generated at 2022-06-12 09:57:01.722264
# Unit test for method mute of class Register
def test_Register_mute():

    class RgbFg(RenderType):
        """
        This class encodes the rendering of foreground 24-bit RGB colors.
        """

        renderfunc = lambda x: "Foo"

    renderfuncs: Renderfuncs = {}
    renderfuncs[RgbFg] = RgbFg.renderfunc

    r = Register()
    r.set_renderfunc(RgbFg, renderfuncs[RgbFg])
    r.test1 = Style(RgbFg(10, 20, 30))

    # Test muted register
    r.mute()
    assert isinstance(r.test1, Style)
    assert r.test1.value == ""
    assert str(r.test1) == ""

    # Test unmuted register
    r.unmute()

# Generated at 2022-06-12 09:57:22.056514
# Unit test for constructor of class Style
def test_Style():
    SimpleRule = namedtuple("SimpleRule", ["args"])

    valid_rules = [SimpleRule((1, 2, 3)), SimpleRule((1, 2, 3))]
    style = Style(*valid_rules)

    assert style.rules == valid_rules

# Generated at 2022-06-12 09:57:28.641135
# Unit test for method copy of class Register
def test_Register_copy():
    register = Register()
    register.__setattr__("test1", Style(value="\x1b[38;2;1;5;10m\x1b[1m"))
    register.__setattr__("test2", Style(value="\x1b[38;2;2;6;11m\x1b[1m"))
    new_register = register.copy()
    assert new_register.test1 == register.test1
    assert new_register.test2 == register.test2



# Generated at 2022-06-12 09:57:38.143019
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Create register
    register = Register()

    # Define rules
    Sgr = namedtuple("Sgr", ["args"])
    RgbFg = namedtuple("RgbFg", ["r", "g", "b"])

    fg = Style(RgbFg(1, 1, 1), Sgr(3))
    bg = Style(RgbFg(2, 2, 2), Sgr(4))

    # Set attribute fg and bg to register-object
    setattr(register, "fg", fg)
    setattr(register, "bg", bg)

    # Define functions
    def sgr(*args):
        return f"\x1b[{args[0]}m"


# Generated at 2022-06-12 09:57:39.501120
# Unit test for constructor of class Style
def test_Style():
    assert type(Style(RgbFg(1,5,10), Sgr(1))) == Style


# Generated at 2022-06-12 09:57:43.897725
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbBg, RgbFg, Sgr
    from .sty import fg, bg

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert str(fg.orange) == "\x1b[38;2;1;5;10m\x1b[1m"

    fg.mute()

    assert str(fg.orange) == ""



# Generated at 2022-06-12 09:57:50.545984
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRenderType(RenderType):
        def __init__(self, arg: str) -> None:
            super().__init__(arg)

    def render_func(arg: str) -> str:
        return f"{arg}{arg}"

    register = Register()

    register.set_renderfunc(TestRenderType, render_func)

    register.x = Style(TestRenderType("x"))

    assert register("x") == "xx"

    assert register(1) == ""

    register.set_eightbit_call(TestRenderType)

    assert register(1) == "11"

# Generated at 2022-06-12 09:57:59.088805
# Unit test for method __call__ of class Register
def test_Register___call__():

    def _register() -> Register:

        class RgbFg(RenderType):

            def __init__(self, r, g, b):
                self.args = (r, g, b)

        class Sgr(RenderType):

            def __init__(self, *args):
                self.args = args

        def render_rgb_fg(r, g, b):
            return "this is rgb fg"

        def render_sgr(*args):
            return "this is sgr"

        rgbfg: Type[RenderType] = RgbFg
        sgr: Type[RenderType] = Sgr
        r = Register()

        r.set_renderfunc(rgbfg, render_rgb_fg)
        r.set_renderfunc(sgr, render_sgr)

        r.red = Style

# Generated at 2022-06-12 09:58:08.125299
# Unit test for method __call__ of class Register
def test_Register___call__():
    def render_eightbit_call(val):
        if val in range(0, 256):
            return "\x1b[38;5;" + str(val) + "m"
        else:
            return "\x1b[38;5;8m"

    def render_rgb_call(r, g, b):
        return "\x1b[38;2;" + str(int(r)) + ";" + str(int(g)) + ";" + str(int(b)) + "m"

    from .rendertype import Sgr, RgbFg, EightbitFg, AnsiBold
    from .enabling import Enabling

    Enabling()
    fg = Register()
    fg.set_eightbit_call(EightbitFg)

# Generated at 2022-06-12 09:58:10.753758
# Unit test for constructor of class Register
def test_Register():
    reg = Register()

    assert reg.is_muted == False
    assert reg.renderfuncs == {}
    assert reg.eightbit_call is not None
    assert reg.rgb_call is not None

# Generated at 2022-06-12 09:58:20.321844
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    rendertype1 = NamedTuple("Rendertype_rgb", [("r", "g", "b")])
    rendertype2 = NamedTuple("Rendertype_other", [("x", "y")])

    def func_rgb(r, g, b):
        return "RgbFg(" + str(r) + ", " + str(g) + ", " + str(b) + ")"

    def func_other(x, y):
        return "Other(" + str(x) + ", " + str(y) + ")"

    r = Register()

    # Check if default renderfunc is RgbFg:
    assert str(r(1, 2, 3)) == "\\x1b[38;2;1;2;3m"

    # Check if set_renderfunc works correctly:
    r.set_render

# Generated at 2022-06-12 09:58:55.268388
# Unit test for method __new__ of class Style
def test_Style___new__():

    rgb_fg_style = Style(value="\x1b[38;2;3;3;3m", rules=[RgbFg(3, 3, 3)])

    # return value of __new__ should be an istance of Style
    assert isinstance(rgb_fg_style, Style)

    # return value of __new__ should be also be an istance of str
    assert isinstance(rgb_fg_style, str)

    assert rgb_fg_style == "\x1b[38;2;3;3;3m"

    # Style should contain the SGR codes stored in rules
    assert rgb_fg_style.rules == [RgbFg(3, 3, 3)]

# Generated at 2022-06-12 09:58:58.897539
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg

    d1 = fg.as_dict()

    assert isinstance(d1, dict)
    for item in d1.items():
        assert len(item) == 2
        assert isinstance(item[0], str)
        assert isinstance(item[1], str)
        assert item[1] != ""


# Generated at 2022-06-12 09:59:00.634935
# Unit test for constructor of class Style
def test_Style():
    style = Style(None)
    assert style.rules == (None,)
    assert str(style) == ""

# Generated at 2022-06-12 09:59:06.674838
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit test for method __call__ of class Register.

    # TODO: Expanded test.
    """
    class TestRegister(Register):
        pass

    tr = TestRegister()

    # Test 1
    tr.test1 = Style("Test 1")
    assert tr("test1") == "Test 1"

    # Test 2
    tr("test2", 255, 255, 0) == None

    # Test 3
    tr("test3", 255, 255) == None

# Generated at 2022-06-12 09:59:07.956169
# Unit test for method __new__ of class Style
def test_Style___new__():
    str(Style(RgbFg(1,2,3), Sgr(1)))

# Generated at 2022-06-12 09:59:13.662732
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import XTerm256

    r = Register()

    # Test default values

# Generated at 2022-06-12 09:59:22.325418
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()

    setattr(r, "rgb", Style(rgb.rgb(1, 2, 3)))
    setattr(r, "style1", Style(rgb.rgb(1, 2, 3), sgr.bold))
    setattr(r, "style2", Style(rgb.rgb(1, 2, 3), sgr.bold, sgr.italic))

    assert isinstance(r("rgb"), str)
    assert r("rgb") == "\x1b[38;2;1;2;3m"

    assert isinstance(r("style1"), str)
    assert r("style1") == "\x1b[38;2;1;2;3m\x1b[1m"

    assert isinstance(r("style2"), str)

# Generated at 2022-06-12 09:59:30.875009
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from sty import fg
    from sty.rendertype import RgbFg, EightBitFg, Sgr

    fg.green = Style(RgbFg(10, 255, 0), Sgr(1))

    assert str(fg.green) == "\x1b[38;2;10;255;0m\x1b[1m"

    fg.set_eightbit_call(EightBitFg)

    assert str(fg(2)) == "\x1b[38;5;2m"

    fg.set_eightbit_call(RgbFg)

    assert str(fg(2)) == "\x1b[38;2;2;2;2m"



# Generated at 2022-06-12 09:59:38.118466
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Unit test for method __new__ of class Style
    """
    # Success
    a = Style(1, 2)
    assert isinstance(a, Style)
    assert a.rules == (1, 2)

    a = Style(1, 2, value="a")
    assert isinstance(a, Style)
    assert a.rules == (1, 2)
    assert a == "a"

    # Fail
    try:
        a = Style("a")
        assert False
    except TypeError:
        assert True

    try:
        a = Style(1, "a")
        assert False
    except TypeError:
        assert True

