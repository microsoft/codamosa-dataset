

# Generated at 2022-06-12 09:50:01.952927
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbEf
    from .renderfuncs import ansi_foreground, ansi_background, ansi_effect

    r = Register()
    r.set_renderfunc(RgbFg, ansi_foreground)
    r.set_renderfunc(RgbBg, ansi_background)
    r.set_renderfunc(RgbEf, ansi_effect)

    r.set_rgb_call(RgbFg)
    assert r(5, 10, 20) == ansi_foreground(5, 10, 20)

    r.set_rgb_call(RgbBg)
    assert r(5, 10, 20) == ansi_background(5, 10, 20)


# Generated at 2022-06-12 09:50:05.921794
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg
    register = Register()
    register.set_renderfunc(RgbFg, lambda r, g, b: f"{r}-{g}-{b}")
    register.set_rgb_call(RgbFg)
    assert register(100, 150, 200) == "100-150-200"


# Generated at 2022-06-12 09:50:09.106443
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register = Register()
    register.set_rgb_call = lambda r, g, b: f"{r};{g};{b}"

    assert register(42, 255, 200) == "42;255;200"

# Generated at 2022-06-12 09:50:18.937319
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # GIVEN
    from .rendertype import RgbFg
    from .rendertype import Sgr
    from .render import ansi

    # WHEN
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.apple = Style(RgbFg(10, 20, 30))
            self.banana = Style(RgbFg(15, 25, 35))

    reg = MyRegister()

    # THEN
    assert (ansi(reg.apple) == "\x1b[38;2;10;20;30m")
    assert (reg.apple == Style(RgbFg(10, 20, 30)))

    # WHEN
    reg.set_rgb_call(Sgr)

    # THEN

# Generated at 2022-06-12 09:50:26.864093
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, bg, ef, rs

    # Set rendering of rgb-calls to HslFg
    bg.set_rgb_call(bg.HslFg)

    assert str(bg(10, 42, 255)) == '\x1b[48;2;10;42;255m'

    # Set rendering of rgb-calls to RgbBg
    bg.set_rgb_call(bg.RgbBg)

    assert str(bg(10, 42, 255)) == '\x1b[48;2;10;42;255m'

# Generated at 2022-06-12 09:50:35.356413
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Given
    register = Register()

    # When

    # Empty register
    assert register(1,2,3) == ""

    # Then
    # Add renderfunc for RgbFg
    @register.register_renderfunc(RgbFg)
    def rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    # RgbFg is renderfunc for 8bit-calls
    assert register(1, 2, 3) == "\x1b[38;2;1;2;3m"

    # No change if a style-attribute is set.
    register.black = Style(RgbFg(1,2,3))
    assert register.black == "\x1b[38;2;1;2;3m"



# Generated at 2022-06-12 09:50:43.448215
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg

    class MyRegister(Register):

        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.black = Style(RgbFg(0, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))

    # Create register
    reg = MyRegister()
    reg.set_rgb_call(RgbFg)

    assert reg.rgb_call(0, 255, 0) == reg.green
    assert reg.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-12 09:50:53.642383
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg
    from .sty import fg, bg

    RenderFunc = NamedTuple("RenderFunc", [("rgb", Callable)])

    def rgb_render(r, g, b, **kwargs) -> str:
        return "\x1b[48;2;{};{};{}m".format(r, g, b)

    test_fg_render_func: RenderFunc = RenderFunc(rgb=rgb_render)
    test_bg_render_func: RenderFunc = RenderFunc(rgb=rgb_render)


# Generated at 2022-06-12 09:51:04.162212
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    This tests whether the two registers "red" and "orange" get the same
    red,green and blue channel value.
    """
    from sty import fg, bg, ef, rs
    fg.red = Style(rgb=(255, 0, 0))
    fg.orange = Style(rgb=(255, 165, 0))

    fg.set_rgb_call(rgb=fg.red)
    str(fg.orange) == str(fg.red)

    bg.set_rgb_call(rgb=bg.red)
    str(bg.orange) == str(bg.red)

    ef.set_rgb_call(rgb=ef.red)
    str(ef.orange) == str(ef.red)


# Generated at 2022-06-12 09:51:14.393980
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Test register
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.white = Style(RgbFg(255, 255, 255))

    # Test render method
    def render(r: int, g: int, b: int) -> str:
        return f"RGB({r},{g},{b})"

    # Init test register
    reg = TestRegister()
    reg.set_rgb_call(RgbBg)
    reg.set_renderfunc(RgbBg, render)

    # Test if the new rendertype is used.
    assert reg(255, 255, 255) == "\x1b[48;2;255;255;255m"

    # Test if

# Generated at 2022-06-12 09:51:26.583542
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType): pass
    class RgbBg(RenderType): pass

    class StyTest(Register):

        def __init__(self):
            super().__init__()

            self.renderfuncs = {RgbFg: lambda *args: "test: " + str(args),
                                RgbBg: lambda *args: "test: " + str(args)}

            self.red: Style = Style(RgbFg(1, 2, 3))
            self.red_to_bg: Style = Style(RgbBg(11, 22, 33))

    test_register = StyTest()
    test_register.set_rgb_call(RgbFg)

    # Test
    test_call = test_register((1, 2, 3))

    print(test_call)
   

# Generated at 2022-06-12 09:51:30.827927
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, f1)
    r.set_rgb_call(RgbFg)

    assert r(1, 2, 3) == "1, 2, 3"



# Generated at 2022-06-12 09:51:41.706116
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class Rgb(RenderType):
        pass

    class Rgb2(RenderType):
        pass

    r1: Register = Register()
    r1.set_renderfunc(Rgb, lambda r, g, b: f"R1: {(r, g, b)}")
    r1.set_renderfunc(Rgb2, lambda r, g, b: f"R2: {(r, g, b)}")

    r1.set_rgb_call(Rgb)

    assert r1.rgb_call(expect=f"R1: (1, 2, 3)") == (1, 2, 3)

    r1.set_rgb_call(Rgb2)

    assert r1.rgb_call(1, 2, 3) == "R2: (1, 2, 3)"

# Generated at 2022-06-12 09:51:45.604764
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg

    register = Register()
    register.red = Style(RgbBg(255, 0, 0))
    register.set_renderfunc(RgbBg, lambda *args, **kwargs: "rgb")
    register.set_rgb_call(RgbBg)
    assert register(255, 0, 0) == "rgb"



# Generated at 2022-06-12 09:51:50.636394
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    r = Register()

    r.set_rgb_call(RgbFg)

    assert r(1,2,3) == "\x1b[38;2;1;2;3m"

    r.set_rgb_call(RgbBg)

    assert r(1,2,3) == "\x1b[48;2;1;2;3m"

# Generated at 2022-06-12 09:52:00.934222
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertypes import EightBitFg, EightBitBg
    from .rendertypes import RgbFg, RgbBg
    from .rendertypes import EightBitFg256, EightBitBg256

    from .renderfuncs import rgb_fg, rgb_bg
    from .renderfuncs import eightbit_fg, eightbit_bg
    from .renderfuncs import eightbit_fg256, eightbit_bg256

    # Test object.
    register = Register()

    register.set_renderfunc(RgbFg, rgb_fg)
    register.set_renderfunc(RgbBg, rgb_bg)

    register.set_renderfunc(EightBitFg, eightbit_fg)
    register.set_renderfunc(EightBitBg, eightbit_bg)


# Generated at 2022-06-12 09:52:07.967254
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test: Register().set_rgb_call(type)
    """
    from .rendertype import RgbFg, Sgr

    rg = Register()
    rg.set_renderfunc(Sgr, lambda x: f"SGR-{x}")
    rg.set_renderfunc(RgbFg, lambda x, y, z: f"RGB-{x},{y},{z}")

    rg.set_rgb_call(RgbFg)

    assert rg(255, 255, 0) == "RGB-255,255,0"


# Generated at 2022-06-12 09:52:19.099966
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

        @staticmethod
        def code() -> str:
            return "38"

        @staticmethod
        def rgb() -> str:
            return ";2"

        @staticmethod
        def end() -> str:
            return "m"

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

        @staticmethod
        def code() -> str:
            return "48"

        @staticmethod
        def rgb() -> str:
            return ";2"


# Generated at 2022-06-12 09:52:24.563015
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbEf
    from .colorsetup import RgbColor
    from .render import RgbStyleRegister

    fg = RgbStyleRegister()

    # Set custom renderfunc for RgbEf.
    def func(red, green, blue):
        return f"{red} {green} {blue}"

    fg.set_renderfunc(RgbEf, func)

    # Change RGB-call to use RgbEf.
    fg.set_rgb_call(RgbEf)

    assert (40, 127, 255) == fg.rgb_call(*RgbColor.blue.rgb)



# Generated at 2022-06-12 09:52:35.269519
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r: Register = Register()

    def render(r: int, g: int, b: int) -> str:
        return f"{r}-{g}-{b}"

    r.set_eightbit_call(RgbBg)
    r.set_renderfunc(RgbBg, render)

    assert r(10, 20, 30) == "10-20-30"
    assert r.eightbit_call(10, 20, 30) == "10-20-30"
    assert r.rgb_call(20, 30, 40) == "20-30-40"
    assert r.rgb_call == r.eightbit_call

    r.set_rgb_call(RgbFg)


# Generated at 2022-06-12 09:52:46.191698
# Unit test for method __call__ of class Register
def test_Register___call__():

    class EightBitFg(RenderType):
        pass

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    # Create a new register-object.
    r = Register()

    # Set renderfunctions for RGB and 8bit fg and bg.
    r.set_renderfunc(EightBitFg, lambda x: f"\x1b[38;5;{x}m")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set def

# Generated at 2022-06-12 09:52:56.986659
# Unit test for constructor of class Style
def test_Style():

    class Rgb(RenderType):
        """Just to test _render_rules"""

    class Bg(RenderType):
        """Just to test _render_rules"""

    renderfuncs = {
        Rgb: lambda r, g, b: f"\x1b[{r},{g},{b}m",
        Bg: lambda: f"\x1b[bgm",
    }

    # Only one rendertype
    __test_Style(
        renderfuncs=renderfuncs,
        input=[Rgb(1, 5, 8)],
        expected_value="\x1b[1,5,8m",
        expected_rules=[Rgb(1, 5, 8)],
    )

    # Normals and nested Rendertypes

# Generated at 2022-06-12 09:53:01.939022
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertypes import Sgr
    from .constants import RgbFg
    from .default_register import fg

    assert fg.orange == "\x1b[38;2;1;5;10m\x1b[1m"
    fg.orange.mute()
    assert fg.orange == ""
    fg.unmute()
    assert fg.orange == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-12 09:53:13.456661
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .render import Eightbit, Rgb, RgbFg, Sgr

    class CustomRegister(Register):
        pass

    c = CustomRegister()

    c.renderfuncs[Eightbit] = lambda x: f"\x1b[{x}m"
    c.renderfuncs[Rgb] = lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"
    c.renderfuncs[RgbFg] = lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"
    c.renderfuncs[Sgr] = lambda r: f"\x1b[{r}m"

    c.red = Style(Eightbit(1))

# Generated at 2022-06-12 09:53:15.384418
# Unit test for method copy of class Register
def test_Register_copy():
    R = Register()
    R.black = Style()
    R2 = R.copy()
    assert R.black == R2.black

# Generated at 2022-06-12 09:53:25.577095
# Unit test for constructor of class Style
def test_Style():

    r1 = Style(value="foobar")
    r2 = Style(RenderType(1))
    r3 = Style(RenderType(2), RenderType(3))
    r4 = Style(RenderType(3), RenderType(3), RenderType(3))
    r5 = Style(RenderType(1), RenderType(2), RenderType(3))

    assert isinstance(r1, Style)
    assert isinstance(r2, Style)
    assert isinstance(r3, Style)
    assert isinstance(r4, Style)
    assert isinstance(r5, Style)

    assert str(r1) == "foobar"
    assert str(r2) == RenderType(1).to_string()

# Generated at 2022-06-12 09:53:29.347142
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    def func(*args):
        return args

    r = Register()
    r.set_renderfunc(Sgr, func)

    assert r.renderfuncs[Sgr] == func



# Generated at 2022-06-12 09:53:39.007608
# Unit test for method unmute of class Register
def test_Register_unmute():
    # TODO: Better tests
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.yay = Style(Sgr(1), RgbFg(10,10,10))

    reg = TestRegister()
    assert reg.yay == '\x1b[38;2;10;10;10m\x1b[1m'
    reg.mute()
    assert reg.yay == ''
    reg.unmute()
    assert reg.yay == '\x1b[38;2;10;10;10m\x1b[1m'
    reg.mute()
    reg.yay = ''
    assert reg.yay == ''

# Generated at 2022-06-12 09:53:41.936632
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.white = Style("")
    assert isinstance(r.as_namedtuple(), NamedTuple)

# Generated at 2022-06-12 09:53:45.571154
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg

    t = fg.red.as_namedtuple()

    assert isinstance(t, NamedTuple)      # type is correct
    assert t.red == fg.red                # values are correct

# Generated at 2022-06-12 09:53:55.548163
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    #Test muted
    assert r.is_muted == False
    r.mute()
    assert r.is_muted == True
    r.unmute()
    assert r.is_muted == False
    r = Register()
    #Test renderfuncs
    r.set_renderfunc(RenderType, lambda: "")
    r.set_renderfunc(RenderType, lambda: "")
    assert r.renderfuncs != {}
    #Test as_dict
    assert isinstance(r.as_dict(), dict)
    assert isinstance(r.as_namedtuple(), NamedTuple)
    assert r.copy() != r
    r = Register()

# Generated at 2022-06-12 09:53:59.371482
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    def func() -> str:
        return "Foo"

    r = Register()
    r.set_renderfunc(Sgr, func)

    assert r.renderfuncs[Sgr] == func



# Generated at 2022-06-12 09:54:06.086121
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Args(NamedTuple):
        a: int
        b: int

    def func1(*args): return "ARGS: " + str(args)

    def func2(args: Args): return "ARGS: " + str(args)

    r = Register()
    r.set_renderfunc(Args, func2)

    # with pytest.raises(ValueError):
    #     r.set_renderfunc(int, func1)

    r.set_renderfunc(int, func1)

# Generated at 2022-06-12 09:54:09.051377
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Sgr
    from .fg import Fg

    Fg.black = Style(Sgr(0))
    assert Fg.black == "\x1b[0m"

# Generated at 2022-06-12 09:54:10.668243
# Unit test for constructor of class Register
def test_Register():

    fg = Register()

    assert isinstance(fg, Register)



# Generated at 2022-06-12 09:54:18.158308
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import AnsiBg, AnsiFg, SetGraphicsRendition, Sgr
    from .register import Register

    def test1(*args):
        return "*test1*"

    def test2(*args):
        return "*test2*"

    def test3(*args):
        return "*test3*"

    reg = Register()
    reg.set_renderfunc(AnsiBg, test2)
    reg.set_renderfunc(AnsiFg, test1)
    reg.set_renderfunc(SetGraphicsRendition, test3)
    reg.set_rgb_call(AnsiBg)

    assert reg.rgb_call(1, 2, 3) == "*test2*"

# Generated at 2022-06-12 09:54:28.971020
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        a: Style = Style(RgbFg(1, 3, 4), Sgr(1))
        b = Style(RgbFg(2, 4, 5))

    r = TestRegister()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    # Test Eightbit call
    assert r(1, 3, 4) == "\x1b[38;2;1;3;4m\x1b[1m"
    assert r(2, 4, 5) == "\x1b[38;2;2;4;5m"
    assert r(a=1, b=3, c=4) == "\x1b[38;2;1;3;4m\x1b[1m"



# Generated at 2022-06-12 09:54:32.618142
# Unit test for constructor of class Style
def test_Style():

    import pytest

    from sty import Style, fg, bg, ef, rs

    style = Style(fg.red, bg.blue)
    assert style.rules[0] == fg.red
    assert style.rules[1] == bg.blue



# Generated at 2022-06-12 09:54:40.968193
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/../")
    from sty import fg, rst, ef, bg, rs
    from sty.ansi import RgbBg, RgbFg

    # Create a new Register object and set a rendertype for RGB-calls.
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;{};{};{}m".format(r, g, b))
    r.set_rgb_call(RgbFg)

    # Add new styling rules
    r.red = Style(RgbFg(255, 0, 0))


# Generated at 2022-06-12 09:54:48.249136
# Unit test for constructor of class Register
def test_Register():

    reg = Register()
    reg.red = Style(value="RED")
    reg.blue = Style(value="BLUE")

    assert isinstance(reg.red, str)
    assert isinstance(reg.blue, str)
    assert isinstance(reg.red, Style)
    assert isinstance(reg.blue, Style)
    assert reg.red == "RED"
    assert reg.blue == "BLUE"



# Generated at 2022-06-12 09:55:09.129784
# Unit test for method __new__ of class Style
def test_Style___new__():
    class MyStyle(Style):
        pass

    s = MyStyle(value="dude")
    assert s == "dude"
    assert isinstance(s, str)
    assert isinstance(s, MyStyle)

# Generated at 2022-06-12 09:55:10.527550
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register = Register()
    register.set_rgb_call(RenderType)

# Generated at 2022-06-12 09:55:21.903455
# Unit test for method copy of class Register
def test_Register_copy():
    class CustomRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(Foreground(8))
            self.blue = Style(Foreground(12))

    custom_register = CustomRegister()
    custom_register.set_rgb_call(Foreground)

    new_register = custom_register.copy()

    assert custom_register.red == new_register.red
    assert custom_register.blue == new_register.blue

    custom_register.red = Style(Foreground(13))

    assert custom_register.red != new_register.red  # values are not equal
    assert custom_register.red.rules == new_register.red.rules  # rules are still equal

    custom_register.mute()

    assert custom_register.red != new_register.red
   

# Generated at 2022-06-12 09:55:25.904952
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg

    r1 = RgbFg(1,2,3)
    r2 = RgbFg(4,5,6)
    s1 = Style(r1,r2)
    s2 = Style(r1,r2,"")

    assert s1 == s2

# Generated at 2022-06-12 09:55:36.473778
# Unit test for method __call__ of class Register
def test_Register___call__():
    """Unit test for method __call__ of class Register."""
    # Create register object
    r = Register()

    # Test 1-parameter call
    # Test for success
    r.light_blue = Style(RgbFg(12, 13, 14))
    assert str(r("light_blue")) == "\x1b[38;2;12;13;14m"
    # Test for failure
    try:
        r("")
        assert False
    except:
        assert True

    # Test 3-parameter call
    # Test for success
    assert str(r(12, 13, 14)) == "\x1b[38;2;12;13;14m"
    # Test for failure
    try:
        r(12)
        assert False
    except:
        assert True

# Generated at 2022-06-12 09:55:37.297901
# Unit test for constructor of class Register
def test_Register():
    assert Register()



# Generated at 2022-06-12 09:55:45.638085
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class Rgb:
        def __init__(self):
            self.rgb_call = lambda r, g, b: (r, g, b)

        def __call__(self, *args, **kwargs):
            return self.rgb_call(*args, **kwargs)

    rgb = Rgb()

    assert rgb() == ()

    rgb.rgb_call = lambda r, g, b: (r, g, b, None)
    assert rgb() == (None,)

    rgb.rgb_call = lambda r, g, b: r
    assert rgb() == (None,)

    rgb.set_rgb_call(lambda r, g, b: b)
    assert rgb() == (None,)

# Generated at 2022-06-12 09:55:47.948952
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(), str)
    assert issubclass(Style(), str)
    assert isinstance(Style(value="test"), str)
    assert issubclass(Style(value="test"), str)


# Generated at 2022-06-12 09:55:56.131928
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MyRenderType(RenderType):
        pass

    class MyRegister(Register):

        def __init__(self):
            super().__init__()
            self.red = Style(MyRenderType(1))

    mr = MyRegister()
    mr.set_renderfunc(MyRenderType, lambda x: "abc")
    mr.red
    mr.set_eightbit_call(MyRenderType)

    assert mr("red") == "abc"
    assert mr(1) == "abc"
    assert mr(1, 2, 3) == "abc"



# Generated at 2022-06-12 09:56:03.881418
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Tests method set_rgb_call of class Register.
    """
    from .rendertype import RgbFg

    def render_x(r, g, b):
        return f"X{r}XY{g}XY{b}XY"

    register = Register()
    register.renderfuncs = {RgbFg: lambda *args: ""}
    register.set_renderfunc(rendertype=RgbFg, func=render_x)
    register.set_rgb_call(RgbFg)

    assert register(10, 20, 50) == "X10XY20XY50XY"



# Generated at 2022-06-12 09:56:26.235904
# Unit test for method unmute of class Register
def test_Register_unmute():

    def test_func():
        pass

    sty = Register()
    sty.red = Style(value="\x1b[31m")
    sty.set_renderfunc(RenderType, test_func)
    sty.mute()

    assert sty.red == ""
    assert sty(1) == ""
    assert sty(1, 1, 1) == ""

    sty.unmute()

    assert sty.red == "\x1b[31m"
    assert sty(1) == ""
    assert sty(1, 1, 1) == ""



# Generated at 2022-06-12 09:56:27.311210
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    rgbfg = RgbFg(0,0,0)

# Generated at 2022-06-12 09:56:29.648250
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import Sgr, RgbSgr

    Style(*[Sgr(1), RgbSgr(10, 20, 30)])

# Generated at 2022-06-12 09:56:34.685139
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Sgr

    reg = Register()

    # Add style with Sgr(1)=bold and str value = "\x1b[1m"
    reg.bold = Style(Sgr(1), value="\x1b[1m")

    # Write "Hello" in bold
    print(reg(1))
    print("Hello")
    print(reg.rs)

# Generated at 2022-06-12 09:56:41.860374
# Unit test for method __new__ of class Style
def test_Style___new__():
    # create register:
    def renderer(x): return f"{x}"

    class RgbFg(RenderType):
        pass

    test_register = Register()

    test_register.set_renderfunc(RenderType, renderer)
    test_register.set_renderfunc(RgbFg, renderer)

    sgr = Style(RgbFg(1, 5, 10), value="\x1b[38;2;1;5;10m")
    assert isinstance(sgr, Style)
    assert isinstance(sgr, str)
    assert str(sgr) == "\x1b[38;2;1;5;10m"



# Generated at 2022-06-12 09:56:52.782495
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbfBg

    class RegisterForTest(Register):
        pass

    register = RegisterForTest()

    register.set_rgb_call(RgbBg)

    # Test set_rgb_call() method with int-input
    assert register(42, 42, 42) == ""

    # Test set_rgb_call() method with int-input
    # Test if new renderfunc was set
    register.set_renderfunc(RgbfBg, lambda r, g, b: (r, g, b))
    assert register(42, 42, 42) == (42, 42, 42)

    # Test set_rgb_call() method with int-input
    # Test if new renderfunc was set

# Generated at 2022-06-12 09:57:00.992277
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from sty import RenderType, Sgr, Fg, bg

    fg = Fg(255)
    bg = bg(255)
    bright = Sgr(1)
    underline = Sgr(4)

    def render_0(x):
        return f"{x}"

    def render_1(x, y):
        return f"{x}:{y}"

    def render_2(x, y, z):
        return f"{x}:{y}:{z}"

    def render_3(x, y, z, w):
        return f"{x}:{y}:{z}:{w}"

    def render_4(x, y, z, w, v):
        return f"{x}:{y}:{z}:{w}:{v}"

    reg = Register()

    rendertype

# Generated at 2022-06-12 09:57:10.506791
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .render import Render, RgbFg, RgbBg, Sgr

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            setattr(self, "hello", Style(RgbFg(1, 2, 3), RgbBg(1, 2, 3), Sgr(1, 2, 3)))

    # Call method 'set_renderfunc'
    r = MyRegister()
    r.hello  # Not-accessible yet.
    r.set_renderfunc(RgbFg, RgbFg.render)
    r.set_renderfunc(RgbBg, RgbBg.render)
    r.set_renderfunc(Sgr, Sgr.render)

    # Set a new Style

# Generated at 2022-06-12 09:57:12.691695
# Unit test for method unmute of class Register
def test_Register_unmute():
    # TODO: Make Unit test for method unmute of class Register

    assert True == True

# Generated at 2022-06-12 09:57:17.432757
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class CustomRendertype(RenderType):
        pass

    register = Register()

    # set initial value for attribute color
    register.color = Style(CustomRendertype(42))
    assert str(register.color) == ""

    # set a render function
    register.set_renderfunc(CustomRendertype, lambda x: f"{x}")
    assert str(register.color) == "42"

# Generated at 2022-06-12 09:57:57.306778
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from sty import fg, RenderType, Sgr

    fg.set_eightbit_call(Sgr)
    fg.set_renderfunc(Sgr, lambda x: f"<SGR-{x}>")
    assert fg(1) == "<SGR-1>"



# Generated at 2022-06-12 09:58:01.714746
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: x)

    r.custom = Style(RenderType(1), value="test")

    r2 = r.copy()

    r2.custom = Style(RenderType(2), value="test2")

    assert str(r.custom) == "test"
    assert str(r2.custom) == "test2"


# Generated at 2022-06-12 09:58:10.341820
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Test set simple attribute
    r1 = Register()
    r1.a = 42
    assert r1.a == 42

    # Test set attribute with Style type
    r1.a = Style("Gibt nicht", "auch auf Regenbogen")
    assert r1.a == 'Gibt nichtauch auf Regenbogen'

    # Test set attribute with Style type with explicit value
    r1.a = Style("Gibt nicht", "auch auf Regenbogen", value="Test")
    assert r1.a == 'Test'

    # Test set attribute with wrong type
    import pytest
    with pytest.raises(ValueError):
        r1.a = 123



# Generated at 2022-06-12 09:58:19.998677
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class R1(RenderType):
        pass
    class R2(RenderType):
        pass
    f1 = lambda x: f"FAKE-RENDER1-FUNCTION-CALLED-WITH-{x}"
    f2 = lambda x: f"FAKE-RENDER2-FUNCTION-CALLED-WITH-{x}"

    r = Register()
    r.set_renderfunc(R1, f1)
    r.set_renderfunc(R2, f2)
    assert r.eightbit_call == r.renderfuncs[R1]

    r.set_eightbit_call(R2)
    assert r.eightbit_call == r.renderfuncs[R2]

    r.set_eightbit_call(R1)

# Generated at 2022-06-12 09:58:27.741917
# Unit test for method unmute of class Register
def test_Register_unmute():
    from sty import fg, bg, ef, rs
    from sty.types import RgbFg, RgbBg, Ef

    RgbFg.init_colors()
    RgbBg.init_colors()

    assert str(fg.red) == "\x1b[38;2;255;0;0m"
    assert str(bg.blue) == "\x1b[48;2;0;0;255m"
    assert str(ef.bold) == "\x1b[1m"

    fg.mute()
    bg.mute()
    ef.mute()

    assert str(fg.red) == ""
    assert str(bg.blue) == ""
    assert str(ef.bold) == ""

    fg.unmute()
    bg.un

# Generated at 2022-06-12 09:58:36.813683
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test the mute method of class Register.
    """
    class MockRegister(Register):
        """
        Mock class for testing unmute.
        """
        attr1: Style
        attr2: Style
        attr3: Style

    m = MockRegister()
    setattr(m, "attr1", Style(RgbFg(1, 1, 1), Sgr(1)))
    setattr(m, "attr2", Style(RgbFg(2, 2, 2), Sgr(2)))
    setattr(m, "attr3", Style(RgbFg(3, 3, 3), Sgr(3)))

    m.mute()

    # Test that attributes have not been changed with muted register:

# Generated at 2022-06-12 09:58:41.748716
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRenderType(RenderType):
        pass

    # Prepare dummy test render function
    renderfunc = lambda *args: f"test-render-{args}"

    # Instantiate register-object
    r = Register()

    # Add TestRenderType
    r.set_renderfunc(TestRenderType, renderfunc)

    # Add style attribute
    setattr(r, "test_style", Style(TestRenderType(42)))

    # Call attribute
    assert r.test_style == "test-render-42"

    # Mute register-object
    r.mute()

    # Call attribute
    assert r.test_style == ""



# Generated at 2022-06-12 09:58:50.159369
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import RenderType, Style, Register

    class RgbFg(RenderType):
        pass

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb)

    # todo: what is this test supposed to test?
    r.test = Style(RgbFg(10, 20, 30))
    assert r.test == "\x1b[38;2;10;20;30m"



# Generated at 2022-06-12 09:58:57.386213
# Unit test for method mute of class Register
def test_Register_mute():

    from .rgb import RgbFg, RgbBg
    from .sgr import Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda s: f"\x1b[{s}m")

    r.red = Style(RgbFg(255, 10, 20))
    r.green = Style(RgbFg(10, 255, 20))

# Generated at 2022-06-12 09:59:06.376308
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Arrange
    def stub(x: int, y: int, z: int):
        return x, y, z


    class G(RenderType, NamedTuple):
        pass

    class H(RenderType, NamedTuple):
        pass

    class I(RenderType, NamedTuple):
        pass

    class J(RenderType, NamedTuple):
        pass

    class K(RenderType, NamedTuple):
        pass

    class A(RenderType, NamedTuple):
        pass

    class B(RenderType, NamedTuple):
        pass

    class C(RenderType, NamedTuple):
        pass

    class D(RenderType, NamedTuple):
        pass

    a = 0
    b = 1
    c = 2
    d = 3
    e = 4
    f = 5