

# Generated at 2022-06-12 09:49:52.853859
# Unit test for method __call__ of class Register
def test_Register___call__():
    # TODO: Implement me!
    """
    Register.__call__
    """
    pass


# Generated at 2022-06-12 09:49:54.520941
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register is not None


# Generated at 2022-06-12 09:49:58.923324
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(1) == ""
    assert r(1, 2, 3) == ""
    assert r("") == ""
    assert r("a", "b", "c") == ""


# Generated at 2022-06-12 09:50:03.244175
# Unit test for method __call__ of class Register
def test_Register___call__():
    def __init__(self, value: str = ""):
        self.value = value

    register = Register()

    register.renderfuncs.update({__init__: lambda x: Register(x)})

    assert register(42) == ""


# Unit tests for method copy() of class Register

# Generated at 2022-06-12 09:50:04.692930
# Unit test for constructor of class Register
def test_Register():
    reg1 = Register()
    reg2 = Register()

    assert reg1 is not reg2

# Generated at 2022-06-12 09:50:14.573511
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.red = Style(value="\x1b[0m\x1b[31m")
    r.two_fifty_five = Style(value="\x1b[0m\x1b[38;2;255;0;0m")

    assert r.__call__(42) == ""
    assert r.__call__("red") == "\x1b[0m\x1b[31m"
    assert r.__call__(1,2,3) == ""
    assert r.__call__("two_fifty_five") == "\x1b[0m\x1b[38;2;255;0;0m"

# Generated at 2022-06-12 09:50:20.737107
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MockRegister(Register):
        reset = Style(value="\x1b[0m")

    register = MockRegister()
    register.set_renderfunc(RenderType, lambda x: x)

    # Test Eightbit call
    assert register(24) == "\x1b[28m"

    # Test RGB call
    assert register(10, 24, 255) == "\x1b[38;2;10;24;255m"

    # Test string call
    assert register("reset") == "\x1b[0m"

    # Test other call
    assert register(1, 2, 3, 4) == ""

# Generated at 2022-06-12 09:50:27.276049
# Unit test for constructor of class Register
def test_Register():

    reg = Register()
    assert isinstance(reg, Register)

    # Test if we can make a namedtuple of it.
    nt = reg.as_namedtuple()
    assert isinstance(nt, NamedTuple)

    # Test if we can make a dict of it.
    d = reg.as_dict()
    assert isinstance(d, dict)


if __name__ == "__main__":

    test_Register()

# Generated at 2022-06-12 09:50:35.435377
# Unit test for constructor of class Register
def test_Register():

    class RgbFg(RenderType):
        args = ["r", "g", "b"]

    class RgbBg(RenderType):
        args = ["r", "g", "b"]

    class Sgr(RenderType):
        args = ["code"]

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\u001b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\u001b[48;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\u001b[{code}m"

    # Create new register

# Generated at 2022-06-12 09:50:38.476756
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.set_renderfunc(RenderType.reset, lambda: "\x1b[0m")
    assert str(r) == "\x1b[0m"

# Generated at 2022-06-12 09:50:51.883746
# Unit test for method __call__ of class Register
def test_Register___call__():

    import pytest
    from .ansi8bit import Ansi8Bit
    from .ansirgb import AnsiRgb
    from .sgr import SGR

    def rgb(r: int, g: int, b: int) -> Tuple[int, int, int]:
        return (r, g, b)

    reg = Register()

    # Test with empty register
    test_str = str(reg(42))
    assert test_str == ""

    reg.set_eightbit_call(Ansi8Bit)
    reg.set_rgb_call(AnsiRgb)
    reg.set_renderfunc(SGR, lambda x: "OK")

    test_str = str(reg(42))
    assert test_str == "OK"
    test_str = str(reg(255, 255, 255))

# Generated at 2022-06-12 09:50:59.495945
# Unit test for constructor of class Register
def test_Register():
    assert hasattr(Register, "__init__")
    assert hasattr(Register, "__setattr__")
    assert hasattr(Register, "__call__")
    assert hasattr(Register, "set_eightbit_call")
    assert hasattr(Register, "set_rgb_call")
    assert hasattr(Register, "set_renderfunc")
    assert hasattr(Register, "mute")
    assert hasattr(Register, "unmute")
    assert hasattr(Register, "as_dict")
    assert hasattr(Register, "as_namedtuple")
    assert hasattr(Register, "copy")

# Generated at 2022-06-12 09:51:00.744483
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg



# Generated at 2022-06-12 09:51:02.119945
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:51:13.775189
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Setup
    class RenderTypeClassOne(RenderType):
        pass

    class RenderTypeClassTwo(RenderType):
        pass

    class RenderTypeClassThree(RenderType):
        pass

    renderfunc_one = lambda x: x + "abc"
    renderfunc_two = lambda r, g, b: r + g + b

    rf: Renderfuncs = {
        RenderTypeClassOne: renderfunc_one,
        RenderTypeClassTwo: renderfunc_two,
    }

    reg = Register()
    reg.renderfuncs = rf

    reg.set_eightbit_call(RenderTypeClassOne)
    reg.set_rgb_call(RenderTypeClassTwo)

    # Execute & verify
    assert reg(123) == "abc"
    assert reg(1, 2, 3) == "6"

# Generated at 2022-06-12 09:51:14.961984
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)

# Generated at 2022-06-12 09:51:24.438928
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, RgbBg, Sgr

    style_obj = Style(RgbFg(42, 0, 0), Sgr(1), RgbBg(0, 0, 42))
    assert str(style_obj) == "\x1b[38;2;42;0;0m\x1b[1m\x1b[48;2;0;0;42m"

    # Create test instance of Register
    testinst = Register()

    # Add some renderfunctions
    testinst.set_renderfunc(RgbFg, lambda *args: f"{args[0]} {args[1]} {args[2]}")
    testinst.set_renderfunc(RgbBg, lambda *args: f"{args[1]} {args[0]} {args[2]}")


# Generated at 2022-06-12 09:51:27.338551
# Unit test for constructor of class Register
def test_Register():
    import pytest

    with pytest.raises(TypeError):
        assert Register.__new__(Register, 0xFF)

    assert isinstance(Register.__new__(Register), Register)


# Generated at 2022-06-12 09:51:28.690179
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:51:39.067685
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create test function

    def test_function(code: str, ansi_code: str):
        fg = Register()
        fg.set_renderfunc(RenderType, lambda c: f"\x1b[38;5;{c}m")
        setattr(fg, "orange", Style(RenderType(1)))
        assert getattr(fg, code) == ansi_code
        assert fg(code) == ansi_code
        assert fg(1) == ansi_code

    # Create test data

    tests = {"orange": "\\x1b[38;5;1m"}

    # Make assertions

    for code, ansi_code in tests.items():
        test_function(code, ansi_code)

# Generated at 2022-06-12 09:51:47.866178
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import ef, fg

    # the dict

# Generated at 2022-06-12 09:51:58.459472
# Unit test for method copy of class Register
def test_Register_copy():
    import unittest
    import sys

    class TestRegister(unittest.TestCase):
        """
        Unit-test for copy-method of class Register.
        """

        def setUp(self):
            from .easyrender import easyrender
            from .register import Register
            from .style import register_style

            fg_old = Register()
            bg_old = Register()

            @register_style(fg_old)
            def test_fg(color: int) -> str:
                """
                Test renderfunc for fg.
                """
                return f"{color}"

            @register_style(bg_old)
            def test_bg(color: int) -> str:
                """
                Test renderfunc for bg.
                """
                return f"{color}"

            fg_old.set_rgb

# Generated at 2022-06-12 09:52:07.881578
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Testing function call with classes as parameters.
    r = Register()

    r.set_renderfunc(int, lambda n: n)
    r.set_renderfunc(str, lambda n: n)

    r.set_eightbit_call(int)
    assert r(42) == 42

    r.set_eightbit_call(str)
    assert r(42) == "42"

    # Testing function call with wrong parameter types.
    r.set_renderfunc(int, lambda n: n)

    with pytest.raises(TypeError):
        r.set_eightbit_call(str)

    with pytest.raises(TypeError):
        r.set_eightbit_call(RgbBg(1,1,1))

# Generated at 2022-06-12 09:52:12.529663
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style("red")
            self.blue = Style("blue")

    register = TestRegister()

    assert register.as_dict() == {
        "red": "red",
        "blue": "blue"
    }


# Generated at 2022-06-12 09:52:17.124032
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    TestRegister = Register()
    TestRegister.foo = Style(value="Foo")
    TestRegister.bar = Style(value="Bar")

    assert TestRegister.as_dict() == {"foo": "Foo", "bar": "Bar"}



# Generated at 2022-06-12 09:52:24.731257
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """ Unit test for method as_namedtuple of class Register """

    # Import test objects
    from sty import fg, bg, ef, rs

    # Create new named tuple from the fg color register.
    # First create a copy of the fg-register.
    fg1 = fg.copy()

    # Add new attributes
    fg1.new = Style(fg=255)
    fg1.new2 = Style(fg=1)

    # Export namedtuple
    t = fg1.as_namedtuple()

    # Test that the namedtuple is the same.
    assert t.red == fg.red
    assert t.new == fg1.new
    assert t.new2 == fg1.new2

# Generated at 2022-06-12 09:52:26.627452
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(0,0,0)), Style)


# Generated at 2022-06-12 09:52:36.650026
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from colorama import Fore
    from pprint import pprint
    from .rendertype import Sgr

    reg = Register()

    reg.set_renderfunc(Sgr, lambda a: "SGR(" + str(a) + ")")
    reg.eightbit_black = Style(Sgr(30))
    reg.eightbit_red = Style(Sgr(31))

    assert str(reg.eightbit_black) == ""
    assert str(reg.eightbit_red) == ""

    reg.set_eightbit_call(Sgr)

    assert str(reg.eightbit_black) == "SGR(30)"
    assert str(reg.eightbit_red) == "SGR(31)"

    assert reg(8) == "SGR(38)"

# Generated at 2022-06-12 09:52:43.747600
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from sty import RenderType
    import pytest

    class TestRenderType(RenderType):
        renderfunc: Callable = lambda x: x

    renderfunc_index: dict = {TestRenderType: TestRenderType.renderfunc}

    test_register: Register = Register()
    test_register.renderfuncs = renderfunc_index

    test_register.test_color = Style(TestRenderType(3), value="")

    test_register.set_eightbit_call(TestRenderType)

    assert test_register(3) == "3"

# Generated at 2022-06-12 09:52:50.970412
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .config import MutedRenderer

    ef = Register()
    ef.set_renderfunc(Sgr, MutedRenderer)
    ef.set_eightbit_call(Sgr)
    ef.mute()

    ef.yellow = Style(Sgr(33))
    assert ef.yellow == ""

    ef.green_bg = Style(Sgr(48), Sgr(42))
    assert ef.green_bg == ""

    assert ef(42) == ""

    ef.unmute()
    assert ef.yellow != ""

test_Register_mute()

# Generated at 2022-06-12 09:53:00.081082
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    sty.rs is a register-object.
    sty.rs(12, 33, 42) is a RGB-call.
    sty.rs(12, 33, 42) raises a ValueError as there is no default renderfunc for RGB-calls.
    sty.rs.set_rgb_call(RgbBg(1,1,1)) sets a default renderfunc for RGB-calls.

    """
    from . import sty

    try:
        sty.rs(12, 33, 42)
    except ValueError:
        pass
    else:
        raise AssertionError("RGB-calls should result in ValueError.")

    sty.rs.set_rgb_call(RgbBg(1, 1, 1))


# Generated at 2022-06-12 09:53:05.814133
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.foo = Style(RgbFg(255, 0, 0))
            self.bar = Style(RgbBg(255, 0, 0))

    register = MyRegister()
    assert isinstance(register.as_namedtuple(), NamedTuple)
    assert len(register.as_namedtuple()._fields) == 2

# Generated at 2022-06-12 09:53:12.483222
# Unit test for method unmute of class Register
def test_Register_unmute():
    class TestRegister(Register):
        black = Style(RgbFg(0, 0, 0))

    r = TestRegister()
    # Set some random value for "black"
    r.black = 42
    # Mute register object
    r.mute()
    # Unmute register object
    r.unmute()
    # Test if the value for "black" is the expected Style object.
    assert isinstance(r.black, Style)

# Generated at 2022-06-12 09:53:15.646413
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Implement unit test for method copy of class Register
    """
    import sty
    sty_copy = sty.fg.copy()
    sty_copy.red = 42
    assert sty.fg.red == sty.red


# Generated at 2022-06-12 09:53:19.258892
# Unit test for method mute of class Register
def test_Register_mute():

    class MyRegister(Register):
        red = Style(RgbFg(33, 33, 33))

    r = MyRegister()
    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red != ""



# Generated at 2022-06-12 09:53:25.672238
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)

    assert r(10, 46, 102) == RgbFg(10, 46, 102).as_ansi()
    assert r(10, 46, 102) != RgbBg(10, 46, 102).as_ansi()


if __name__ == '__main__':
    test_Register_set_rgb_call()

# Generated at 2022-06-12 09:53:32.473286
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style()
    assert isinstance(s, str)
    assert isinstance(s, Style)
    assert len(s) == 0

    s = Style("foo")
    assert isinstance(s, str)
    assert isinstance(s, Style)
    assert len(s) == 3

    s = Style(value="foo")
    assert isinstance(s, str)
    assert isinstance(s, Style)
    assert len(s) == 3


# Generated at 2022-06-12 09:53:40.541299
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Tests muting of register object.
    """
    fg = Register()
    fg.set_eightbit_call(RenderType.SGR)
    fg.set_rgb_call(RenderType.SGR_RGB_FG)
    fg.new_style = Style(
        RenderType.SGR(1), RenderType.SGR_RGB_FG(1, 255, 255)
    )

    fg.mute()
    assert fg.is_muted == True
    assert fg.new_style == ""
    assert fg(100) == ""
    assert fg(1, 255, 255) == ""
    assert fg("new_style") == ""

    fg.unmute()

    assert fg.is_muted == False

# Generated at 2022-06-12 09:53:42.162055
# Unit test for constructor of class Register
def test_Register():

    from sty import fg

    assert type(fg) == Register



# Generated at 2022-06-12 09:53:46.508743
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.red = Style("\x1b[31m")

    assert r("red") == r.red
    assert r("red") == "\x1b[31m"
    assert r("red") is not r.red

test_Register___call__()

# Generated at 2022-06-12 09:53:55.004449
# Unit test for constructor of class Register
def test_Register():
    R = Register()
    assert R.renderfuncs == {}
    assert R.is_muted == False
    assert R.eightbit_call(1) == 1
    assert R.rgb_call(1, 2, 3) == (1, 2, 3)


# Generated at 2022-06-12 09:54:05.652156
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import (
        EightbitBg,
        EightbitFg,
        RgbBg,
        RgbFg,
        Sgr,
    )
    from .style import Style
    from .render import render

    fg = Register()
    fg.set_renderfunc(SixteenbitFg, lambda c: "")
    fg.set_renderfunc(EightbitFg, lambda c: f"<{c}>")
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"<{r},{g},{b}>")
    fg.set_renderfunc(SixteenbitBg, lambda c: "")
    fg.set_renderfunc(EightbitBg, lambda c: f"[{c}]")
    fg.set

# Generated at 2022-06-12 09:54:11.826514
# Unit test for constructor of class Style
def test_Style():
    Style(RgbFg(10, 5, 1))
    Style(RgbBg(10, 5, 1))
    Style(RgbFg(10, 5, 1), Sgr(1))
    Style(RgbBg(10, 5, 1), Sgr(1))
    Style(RgbBg(10, 5, 1), Sgr(1), RgbBg(1, 5, 10), Sgr(0))


# Generated at 2022-06-12 09:54:15.027039
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr
    s = Style('red', Sgr(1))
    assert isinstance(s, Style)
    assert s.rules == ('red', Sgr(1))
    assert str(s) == '\x1b[1m'


# Generated at 2022-06-12 09:54:21.300314
# Unit test for method __call__ of class Register
def test_Register___call__():
    class TestRegister(Register):
        red = Style(value="\x1b[38;2;255;0;0m")
        green = Style(value="\x1b[38;2;0;255;0m")
        blue = Style(value="\x1b[38;2;0;0;255m")

        def __init__(self):
            super().__init__()
            self.set_eightbit_call(type(self.red.rules[0]))
            self.set_rgb_call(type(self.red.rules[0]))

    r1 = TestRegister()

    assert r1("red") == "\x1b[38;2;255;0;0m"
    assert r1("blue") == "\x1b[38;2;0;0;255m"


# Generated at 2022-06-12 09:54:28.512640
# Unit test for method __call__ of class Register
def test_Register___call__():

    Rend = RenderType("test")

    def render_func(rendertype, *args):

        return "42"

    r = Register()
    r.renderfuncs.update({Rend: render_func})
    r.set_eightbit_call(Rend)
    r.set_rgb_call(Rend)

    assert r(42) == "42"
    assert r(10, 20, 30) == "42"

    assert r("red") == ""

# Generated at 2022-06-12 09:54:37.106282
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Make sure that the named tuple created by Register.as_name tuple is
    actually a Named Tuple.
    """
    from .registers import fg, bg
    from .ansi import Sgr, RgbFg, Sgr0

    fg.blue = Style(Sgr(4), RgbFg(1,1,1), Sgr0())
    bg.blue = Style(Sgr(4), RgbFg(1,1,1), Sgr0())

    namedtuple = fg.as_namedtuple()

    assert 'blue' in namedtuple and namedtuple.blue == '\x1b[4m\x1b[38;2;1;1;1m\x1b[0m'

# Generated at 2022-06-12 09:54:49.113082
# Unit test for method __call__ of class Register
def test_Register___call__():

    renderfuncs_rgb: Renderfuncs = {
        RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
        RgbBg: lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m",
        RgbEf: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
        RgbRs: lambda r, g, b: f"\x1b[0m",
    }


# Generated at 2022-06-12 09:54:51.157884
# Unit test for constructor of class Register
def test_Register():
    def test():
        assert len(dir(Register())) == 11
        assert 9 == len(Register().renderfuncs)

    test()

# Generated at 2022-06-12 09:54:57.918287
# Unit test for method copy of class Register
def test_Register_copy():

    from . import fg

    fg_copy = fg.copy()

    assert fg_copy.__class__.__name__ == "Register"

    assert fg_copy.__dict__ != fg.__dict__

    try:
        assert fg_copy.__dict__ == fg.__dict__
    except AssertionError:
        assert True

    fg_copy.green = Style(fg.red, fg.green, fg.blue)

    try:
        assert fg_copy.__dict__ == fg.__dict__
    except AssertionError:
        assert True

    try:
        assert fg_copy != fg
    except AssertionError:
        assert True

    fg_copy.as_dict()
    fg_copy.as_namedtuple()



# Generated at 2022-06-12 09:55:14.086183
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import CursorPos
    from .rendertype import Sgr

    c = Register()
    c.set_renderfunc(Sgr, lambda *args: "SGR{}".format(args[0]))
    c.set_renderfunc(CursorPos, lambda *args: "\x1b[{};{}H".format(*args))
    c.foo = Style(CursorPos(2, 3))
    c.bar = Style(Sgr(1))
    c.mute()

    assert c.foo == '\x1b[0;0H'
    assert c.bar == "SGR0"

    c.unmute()
    assert c.foo == '\x1b[2;3H'
    assert c.bar == "SGR1"



# Generated at 2022-06-12 09:55:15.293609
# Unit test for constructor of class Style
def test_Style():
    # style = Style()
    # assert style == ""
    assert True



# Generated at 2022-06-12 09:55:24.708440
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertypes import EightbitFg

    # Create a register object and a new render func.
    register = Register()

    def func(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    register.set_renderfunc(EightbitFg, func)

    # Set new renderfunc as eightbit_call
    register.set_eightbit_call(EightbitFg)

    # Call register with eightbit value.
    assert register(144) == "\x1b[38;5;144m"



# Generated at 2022-06-12 09:55:28.026652
# Unit test for constructor of class Style
def test_Style():
    r1 = Register()

    assert isinstance("abc", Style("abc"))

    assert isinstance(r1.green, Style)

    assert isinstance(r1.green, str)

    assert str(r1.green) == Style("\x1b[32m")

    assert str(r1.green) == "\x1b[32m"

# Generated at 2022-06-12 09:55:38.419335
# Unit test for method mute of class Register
def test_Register_mute():
    from .effects import Underline

    # Define Register with underline rendertype.
    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.set_renderfunc(Underline, lambda *args, **kwargs: "Test")

    # Define Style object on self.red.
    test = TestRegister()
    test.red = Style(Underline(2))

    # Test, if self.red is a Style object.
    assert isinstance(test.red, Style)

    # Test, if value of self.red is ANSI sequence from Underline class.
    assert str(test.red) == "\x1b[4m\x1b[4m"

    # Mute testregister.
    test.mute()

    # Test, if value of self.red is empty string

# Generated at 2022-06-12 09:55:47.031311
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Test RGB-call with 8bit
    rg1 = Register()
    rg2 = Register()

    rg1.set_rgb_call(RenderType.EIGHTBIT)
    rg2.set_rgb_call(RenderType.RGB)

    rg1.renderfuncs.update({RenderType.EIGHTBIT: lambda x: f"\x1b[38;5;{x}m"})
    rg2.renderfuncs.update({RenderType.RGB: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"})

    assert rg1(60) == "\x1b[38;5;60m"
    assert rg2(60) == "\x1b[38;5;60m"

    # Test RGB-call with RGB

# Generated at 2022-06-12 09:55:57.349725
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg

    # Create a register
    fg = Register()

    # Add renderfunc for RGB-Colors
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Check that RGB-Renderfunc is set and works
    assert fg.rgb("255", "100", "100") == "\x1b[38;2;255;100;100m"

    # Set eightbit-Renderfunc to RGB-Renderfunc
    fg.set_eightbit_call(RgbFg)

    # Check that the eightbit-Renderfunc is the same as the RGB-Renderfunc

# Generated at 2022-06-12 09:56:00.734725
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.blau = "blau"
    r.gelb = "gelb"

    assert r.as_dict() == {"blau": "blau", "gelb": "gelb"}



# Generated at 2022-06-12 09:56:05.502923
# Unit test for method mute of class Register
def test_Register_mute():

    test = Register()
    test.set_eightbit_call(type(RenderType()))
    test.TEST = Style(RenderType())

    assert (test.TEST == "\x1b[0m")

    test.mute()

    assert (test.TEST == "")

    test.set_eightbit_call(type(RenderType()))

    assert (test.TEST == "")

# Generated at 2022-06-12 09:56:11.212894
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, Style, RgbFg
    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))
    fg.blue = Style(RgbFg(0, 0, 255))
    fg.set_rgb_call(RgbFg)
    assert fg(255, 0, 0) == fg.red
    assert fg(0, 255, 0) == fg.green
    assert fg(0, 0, 255) == fg.blue


# Generated at 2022-06-12 09:56:32.758533
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register = Register()

    register.set_renderfunc(type, lambda x: "test")

    assert register("test") == ""

    register.set_rgb_call(type)

    assert register("test") == "test"

# Generated at 2022-06-12 09:56:41.500845
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    def _return_rgb(r, g, b):
        return r, g, b

    class MockRgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int) -> None:
            pass

    class MockRgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int) -> None:
            pass

    # Test that color is returned as tuple
    reg1 = Register()
    reg1.renderfuncs.update({MockRgbFg: _return_rgb})
    reg1.set_rgb_call(MockRgbFg)
    assert reg1(10, 20, 30) == (10, 20, 30)

    # Test that color is returned as tuple of strings
    reg2 = Register()

# Generated at 2022-06-12 09:56:46.585457
# Unit test for method unmute of class Register
def test_Register_unmute():

    from . import fg

    fg.red = Style(RgbFg(255, 0, 0))

    assert str(fg.red) == "\x1b[38;2;255;0;0m"

    fg.mute()

    assert str(fg.red) == ""

    fg.unmute()

    assert str(fg.red) == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-12 09:56:56.740923
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .render import Eightbit, Sgr, RgbFg, RgbBg, EightbitBg, EightbitFg, Ef

    red = EightbitFg(1)
    green = EightbitFg(2)
    blue = EightbitBg(3)

    fg = Register()
    fg.red = Style(red)
    fg.green = Style(green)
    fg.blue = Style(blue)

    nt: NamedTuple = fg.as_namedtuple()

    assert nt.red == red()
    assert nt.green == green()
    assert nt.blue == blue()

    # TODO: Write a test for registers with RGB-params.

# Generated at 2022-06-12 09:57:03.102974
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, EightbitFg, EightbitBg

    reg = Register()

    # Test __call__ for 8bit rendertypes
    reg.set_eightbit_call(EightbitFg)
    reg.set_eightbit_call(EightbitBg)
    reg.set_renderfunc(EightbitFg, lambda x: f"({x})")
    reg.set_renderfunc(EightbitBg, lambda x: f"[{x}]")

    reg.testfg = Style(EightbitFg(42))
    reg.testbg = Style(EightbitBg(144))

    assert reg(42) == "(42)"
    assert reg(144) == "[144]"
    assert reg("testfg") == "(42)"

# Generated at 2022-06-12 09:57:12.106507
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define test render-type
    class RgbFg(RenderType):
        """
        This rendertype can be used to colour the foreground of a string.
        """

    # Define test render-functions
    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return ""

    def render_rgb_fg_test(r: int, g: int, b: int) -> str:
        return r, g, b

    # Create test-register
    r = Register()
    setattr(r, "test_style", Style(RgbFg(0, 0, 0), value=""))

    # 1st render-function call
    r.set_renderfunc(RgbFg, render_rgb_fg)

    # Check if style is updated
    res = r

# Generated at 2022-06-12 09:57:16.165565
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.blue = Style(rgb="blue")
    r.green = Style(rgb="green")
    d = r.as_dict()
    assert isinstance(d, dict)
    assert len(d) == 2


# Generated at 2022-06-12 09:57:23.061655
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from . import fg

    # Variable fg_nt should be an instance of class Register
    fg_nt = fg.as_namedtuple()

    # Variable fg_nt should be an instance of class namedtuple
    assert isinstance(fg_nt, NamedTuple) == True

    # fg_nt should have attribute 'red'
    assert hasattr(fg_nt, 'red') == True

    # fg_nt.red should be a string
    assert isinstance(fg_nt.red, str) == True

    # fg_nt.red should be equal to fg.red
    assert fg_nt.red == fg.red

# Generated at 2022-06-12 09:57:26.111236
# Unit test for method copy of class Register
def test_Register_copy():
    from .registrar import registrar, _default_register_definitions
    r = registrar
    r.reset()
    rr = r.register
    rr._set_default_renderfuncs()
    rr.copy()

# Generated at 2022-06-12 09:57:36.471040
# Unit test for method mute of class Register
def test_Register_mute():

    class Test(Register):
        apple = Style(RgbFg(1, 5, 10))
        orange = Style(RgbFg(255, 5, 10))
        pear = Style(RgbFg(1, 255, 10))
        banana = Style(RgbFg(1, 5, 255))

    t = Test()
    t.set_renderfuncs(RgbFg=lambda r, g, b: f"<{r},{g},{b}>")
    t.set_eightbit_call(RgbFg)
    t.set_rgb_call(RgbFg)

    assert t.apple == "<1,5,10>"
    assert t.orange == "<255,5,10>"
    assert t.pear == "<1,255,10>"

# Generated at 2022-06-12 09:58:50.995633
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Run unit test for method __call__ of class Register

    :raise AssertionError: If one test fails
    """

    # Create a fresh register object and set sgr to be the eightbit call
    # and rgb to be the rgb call.
    register = Register()
    register.set_eightbit_call(RenderType.Sgr)
    register.set_rgb_call(RenderType.RgbFg)

    # Add a renderfunc for sgr.
    register.set_renderfunc(RenderType.Sgr, lambda code: "\x1b[{}m".format(code))

    # Add a renderfunc for rgb.

# Generated at 2022-06-12 09:58:57.898587
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import RgbBg

    # 1. Create a register
    register = Register()

    # 2. Add render-function for rendertype RgbBg
    renderfunc = lambda r,g,b: f"\x1b[48;2;{r};{g};{b}{{end}}"
    register.set_renderfunc(RgbBg, renderfunc)

    # 3. Create a style, that uses the renderfunction
    register.my_style = Style(RgbBg(123,124,125))

    # 4. The renderfunctino must be called, when we access the style
    assert register.my_style == "\x1b[48;2;123;124;125{end}"

    # 5. Mute the register
    register.mute()

    # 6. The renderfunc must not

# Generated at 2022-06-12 09:59:00.248626
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)
    assert "as_dict" in dir(register)
    assert "as_namedtuple" in dir(register)


# Generated at 2022-06-12 09:59:05.047899
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    r = TestRegister()

    setattr(r, "test", Style(1))

    assert r.test == "\x1b[1m"

    r.mute()

    setattr(r, "test", Style(1))

    assert r.test == ""

    r.test
    r.is_muted = False
    assert r.test == "\x1b[1m"



# Generated at 2022-06-12 09:59:14.029325
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RenderType0(RenderType):
        args: Tuple[int]
        renderfunc: Callable

    class RenderType1(RenderType):
        args: Tuple[int, int, int]
        renderfunc: Callable

    class RenderType2(RenderType):
        args: Tuple[str]
        renderfunc: Callable

    RenderType0.renderfunc = lambda x: str(x) + "|"
    RenderType1.renderfunc = lambda r, g, b: str(r) + str(g) + str(b) + "|"
    RenderType2.renderfunc = lambda x: "*" + x + "*"

    r = Register()
    r.set_renderfunc(RenderType0, RenderType0.renderfunc)

# Generated at 2022-06-12 09:59:16.048950
# Unit test for constructor of class Style
def test_Style():
    style_obj = Style(RgbFg(1,5,10), Sgr(1))
    assert isinstance(style_obj, Style)


# Generated at 2022-06-12 09:59:26.037011
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    def _check_call(self, *args, **kwargs):
        return str(args) + " " + str(kwargs)

    def SetRgbFg(self, r: int, g: int, b: int, pal: str = "default"):
        pass

    reg = Register()
    reg.set_renderfunc(SetRgbFg, _check_call)

    # Set rendertype to SetRgbFg
    reg.set_rgb_call(SetRgbFg)

    # Check that calling RGB-code results in call of SetRgbFg-function.
    assert reg(42, 44, 55) == "((42, 44, 55),) {}"



# Generated at 2022-06-12 09:59:29.273045
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()
    reg.test1 = "test1"
    reg.test2 = "test2"
    reg.__test3__ = "test3"
    assert reg.as_dict() == {"test1": "test1", "test2": "test2"}

# Generated at 2022-06-12 09:59:34.982025
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .render import RgbFg, EightBitFg

    # Mock-class for register with rendertypes RgbFg and EightBitFg
    class Reg(Register):
        pass

    # Instantiate register with renderfunctions for RgbFg and EightBitFg.
    reg = Reg()
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.set_renderfunc(EightBitFg, lambda x: f"\x1b[38;5;{x}m")

    # Set render-type for rgb-calls and test it.
    reg.set_rgb_call(RgbFg)

# Generated at 2022-06-12 09:59:44.295896
# Unit test for method mute of class Register
def test_Register_mute():
    class RgbFg(RenderType):
        pass

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, render_rgb_fg)
    fg.set_renderfunc(Sgr, render_sgr)
    fg.set_eightbit_call(RgbFg)

    fg.green = Style(RgbFg(51, 255, 51), Sgr(1))