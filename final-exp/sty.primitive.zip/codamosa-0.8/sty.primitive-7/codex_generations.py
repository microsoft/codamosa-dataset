

# Generated at 2022-06-12 09:50:03.447708
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create new register
    r = Register()

    # Define test cases:

# Generated at 2022-06-12 09:50:08.193568
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty.rendering import RgbFg

    register = Register()
    register.set_rgb_call(RgbFg)

    assert register(42, 142, 255) == "\u001b[38;2;42;142;255m"


# Generated at 2022-06-12 09:50:08.777001
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    pass

# Generated at 2022-06-12 09:50:16.530618
# Unit test for method __call__ of class Register
def test_Register___call__():
    class _TestRegister(Register):
        pass

    r = _TestRegister()

    # Set calls
    r.set_eightbit_call(lambda x: x)
    r.set_rgb_call(lambda r, g, b, d: (r, g, b, d))

    # Add color for eightbit-call
    r.color_name = Style(lambda x: x)

    assert r(1) == 1
    assert r(1, 2, 3) == (1, 2, 3)
    assert r("color_name") == r.color_name


# Generated at 2022-06-12 09:50:26.630291
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def my_rgb(r: int, g: int, b: int) -> str:
        pass

    class MyRegister(Register):
        pass

    Rgb = MyRegister()
    Rgb.set_renderfunc(RgbFg, my_rgb)

    assert Rgb.rgb_call == my_rgb
    assert Rgb.eightbit_call == my_rgb

    Rgb.set_rgb_call(RgbFg)

    assert Rgb.rgb_call == my_rgb
    assert Rgb.eightbit_call != my_rgb

    Rgb.set_rgb_call(RgbBg)

    assert Rgb.rgb_call != my_

# Generated at 2022-06-12 09:50:29.277208
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.red = Style(value="\x1b[31m")

    assert isinstance(r.red, Style)

# Generated at 2022-06-12 09:50:35.181735
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    RgbFg = NamedTuple("RgbFg", [("r", int), ("g", int), ("b", int)])

    def render_rgb_fg(r, g, b):
        return f"\033[38;2;{r};{g};{b}m"

    rgb_fg = Register()
    rgb_fg.set_renderfunc(RgbFg, render_rgb_fg)
    rgb_fg.set_rgb_call(RgbFg)

    assert rgb_fg(1, 5, 10) == "\033[38;2;1;5;10m"

# Generated at 2022-06-12 09:50:41.195471
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    register = TestRegister()
    register.red = Style(RgbFg(255, 0, 0))

    assert str(register.red) == "\x1b[38;2;255;0;0m"

    register.set_rgb_call(RgbBg)

    assert str(register.red) == "\x1b[48;2;255;0;0m"


# Generated at 2022-06-12 09:50:42.368592
# Unit test for constructor of class Register
def test_Register():
    assert Register().__class__.__name__ == "Register"



# Generated at 2022-06-12 09:50:52.429485
# Unit test for constructor of class Register
def test_Register():

    # Test if class Register exists
    r = Register()

    # Test if renderfuncs are of type Dict[Type[RenderType], Callable]
    assert isinstance(r.renderfuncs, Renderfuncs)

    # Test if object is muted.
    assert r.is_muted is False

    # Test if object can mute itself.
    r.mute()
    assert r.is_muted

    # Test if object can unmute itself.
    r.unmute()
    assert not r.is_muted

    # Test if renderfunc is added.
    def renderfunc(x: int) -> None:
        return None

    RType = Union[RenderType, Type[RenderType]]
    r.set_renderfunc(RType, renderfunc)

# Generated at 2022-06-12 09:51:03.799800
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .ansi import SgrFg, RgbFg

    rg = Register()

    setattr(rg, "black", Style(SgrFg(0), SgrFg(0)))

    rg.set_renderfunc(SgrFg, lambda x: "SGR")

    rg.set_eightbit_call(SgrFg)

    rg.set_rgb_call(RgbFg)

    assert rg.black == "SGR"
    assert rg(0) == "SGR"
    assert rg(0, 0, 0) == "\x1b[38;2;0;0;0m"



# Generated at 2022-06-12 09:51:14.207602
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RGBFg, RgbFg
    from .register import (
        fg,
        Register,
    )

    mock_func = lambda r, g, b: (f"\x1b[38;2;{r};{g};{b}m")
    r = Register()

    # When rendertype RGBFg is used for rgb-calls,
    # the rgb-call-function must return a string that starts with "\x1b[38;2"
    r.set_rgb_call(RGBFg)
    assert r.rgb_call(42, 0, 0).startswith("\x1b[38;2")

    # When rendertype RgbFg is used for rgb-calls,
    # the rgb-call-function must return a string that starts with "\x1b

# Generated at 2022-06-12 09:51:23.515419
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    def renderfunc(r, g, b):
        return f"<{r};{g};{b}>"

    from .rendertype import RgbBg

    r = Register()
    r.set_renderfunc(RgbBg, renderfunc)

    assert r(1, 5, 10) == "<1;5;10>"

    assert r.blue == "\x1b[48;2;0;0;255m"

    assert r.blue.rules == (RgbBg("0", "0", "255"),)

    assert str(r.blue) == "\x1b[48;2;0;0;255m"

    # Add new renderfunc:
    r.set_rgb_call(RgbBg)

    assert r(10, 20, 30) == "<10;20;30>"

    #

# Generated at 2022-06-12 09:51:31.470422
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import fg
    from sty.rendertype import RgbFg

    r1 = fg.red
    fg.set_rgb_call(RgbFg)

    assert r1.rgb_call == fg.rgb_call

    r2 = fg(1, 2, 3)
    r3 = fg(r=1, g=2, b=3)

    assert r2 == r3 == '\x1b[38;2;1;2;3m'


if __name__ == "__main__":
    test_Register_set_rgb_call()

# Generated at 2022-06-12 09:51:42.135411
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    # Create register.
    r = Register()

    # Define two renderfuncs for RgbBg and RgbFg
    def render_rgb_bg(*args):
        return f"\x1b[48;2;{args[0]};{args[1]};{args[2]}m"

    def render_rgb_fg(*args):
        return f"\x1b[38;2;{args[0]};{args[1]};{args[2]}m"

    # Set the renderfuncs for RgbBg and RgbFg.
    r.set_renderfunc(RgbBg, render_rgb_bg)
    r.set_renderfunc(RgbFg, render_rgb_fg)

   

# Generated at 2022-06-12 09:51:48.281188
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg
    assert fg.rgb_call.__code__.co_name == "RgbFg"
    fg.set_rgb_call(RgbFg)
    assert fg.rgb_call.__code__.co_name == "RgbFg"
    from sty import RgbBg
    fg.set_rgb_call(RgbBg)
    assert fg.rgb_call.__code__.co_name == "RgbBg"

# Generated at 2022-06-12 09:51:58.851669
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Define some example attributes and modes.
    elem_name_attr = "dummy_attr"
    dummy_attr = Style(value="\x1b[-123m")

    elem_name_mode = "dummy_mode"
    dummy_mode = Style(value="\x1b[-456m")

    # Create test register
    test_reg = Register()

    # Define dummy function that is used for rendertype processing.
    def dummy_func(arg1):
        return arg1

    # Add renderfunc for attr
    test_reg.set_renderfunc(type(dummy_attr), dummy_func)

    # Add renderfunc for mode
    test_reg.set_renderfunc(type(dummy_mode), dummy_func)

    # Set rgb-call for attr

# Generated at 2022-06-12 09:52:03.256445
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .render import Sgr, RgbBg, RgbFg

    fg = Register()
    fg.set_renderfunc(Sgr, lambda *args: f"SGR: {args}")
    fg.set_renderfunc(RgbFg, lambda *args: f"RGB-FG: {args}")
    fg.set_renderfunc(RgbBg, lambda *args: f"RGB-BG: {args}")
    fg.red = Style(RgbFg(1,2,3), RgbBg(3, 2, 1))

    fg.set_rgb_call(RgbBg)
    assert fg(10, 200, 3) == "RGB-BG: (10, 200, 3)"

# Generated at 2022-06-12 09:52:11.149901
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # prepare register object with 2 entries
    tmp_reg = Register()
    tmp_reg.aliceblue = Style(Sgr("30"), RgbFg("240", "248", "255"))
    tmp_reg.antiquewhite = Style(Sgr("1"), Sgr("30"), RgbFg("250", "235", "215"))

    # prepare dictionary with 2 entries
    tmp_dict = {}
    tmp_dict["aliceblue"] = "\x1b[38;2;240;248;255m"
    tmp_dict["antiquewhite"] = "\x1b[38;2;250;235;215m\x1b[1m"

    # call function
    tmp_reg.set_rgb_call(RgbFg)

    # compare dictionary with attribute names and values
    # from the

# Generated at 2022-06-12 09:52:21.699978
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import (
        AnsiFgBg,
        AnsiFgBg256,
        AnsiFgBg16,
        AnsiFgBg8,
        RgbFg,
        RgbBg,
    )

    # initialize a new register
    reg = Register()

    # set renderfuncs
    reg.set_renderfunc(AnsiFgBg, lambda x: "")
    reg.set_renderfunc(AnsiFgBg256, lambda x, y: f"{x}256{y}")
    reg.set_renderfunc(AnsiFgBg16, lambda x, y: f"{x}16{y}")

# Generated at 2022-06-12 09:52:36.893998
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        code = 38
        args = ("r", "g", "b")

    class RgbBg(RenderType):
        code = 48
        args = ("r", "g", "b")

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    rg = Register()
    rg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-12 09:52:39.160054
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # TODO: Add test.
    pass


# Generated at 2022-06-12 09:52:46.654015
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import pytest
    from .rendertype import RgbBg, RgbFg, RgbBg24, RgbFg24

    register = Register()

    @register.set_renderfunc(rendertype=RgbBg24, func=lambda r, g, b: str(r) + str(g) + str(b))
    def render_rgbbg24(self, r, g, b):
        return str(r) + str(g) + str(b)

    @register.set_renderfunc(rendertype=RgbFg24, func=lambda r, g, b: str(r) + str(g) + str(b))
    def render_rgbfg24(self, r, g, b):
        return str(r) + str(g) + str(b)

    register.set_r

# Generated at 2022-06-12 09:52:57.470188
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.one = Style(Sgr(1), RgbFg(1, 1, 1))

    assert str(r.one) == '\x1b[38;2;1;1;1m\x1b[1m'

    r.two = Style(Sgr(1), RgbFg(2, 2, 2))

    assert str(r.two) == '\x1b[38;2;2;2;2m\x1b[1m'

    r.set_rgb_call(RgbFg)

    assert str(r(1, 1, 1)) == str(r.one)

    assert r(2, 2, 2) == str(r.two)

# Generated at 2022-06-12 09:52:59.289452
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    r.set_rgb_call(RenderType)
    assert isinstance(r.rgb_call, Callable)

# Generated at 2022-06-12 09:53:09.812300
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    def three_times_sgr_fmt(sgr1, sgr2, sgr3):
        return f"{sgr1}{sgr2}{sgr3}"

    def three_times_rgb_fmt(r, g, b):
        return f"{r}{g}{b}"

    # noinspection PyUnusedLocal
    def sgr_to_ansi(sgr):
        return f"\x1b[{sgr}m"

    def rgb_to_ansi(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    # Create test register
    register = Register()

    # Create classes for test purpose
    class Sgr(RenderType):
        pass


# Generated at 2022-06-12 09:53:16.377903
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    >>> from sty import fg
    >>> fg.renderfuncs[fg.RgbFg] = lambda r, g, b: f"Custom {r},{g},{b}"
    >>> fg.set_rgb_call(fg.RgbFg)
    >>> fg(1,2,3)
    'Custom 1,2,3'
    >>> fg.rgb(1,2,3)
    '\x1b[38;2;1;2;3m'
    """
    pass



# Generated at 2022-06-12 09:53:26.587913
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from . import RgbFg, TrueColor, fg
    from .base import BaseRender
    from .rendertype import RenderType

    class TrueColor1(RenderType, TrueColor):
        pass

    class Rgbfg1(RenderType, RgbFg):
        pass

    class BaseRender1(RenderType, BaseRender):
        pass

    def render_truecolor(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgbfg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;5;{16 + (36 * r) + (6 * g) + b}m"


# Generated at 2022-06-12 09:53:37.381987
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .sgr import Sgr
    from .rgb import RgbFg

    assert RgbFg.format_string == "{0}8;2;{1};{2};{3}m"
    assert Sgr.format_string == "{0}1m"

    red = RgbFg(10, 20, 30)
    bright = Sgr(1)

    reg = Register()
    reg.r1 = Style(red)
    reg.r2 = Style(bright, red)
    reg.r3 = Style(red, bright)
    reg.muted = Style(red, bright)

    as_string = reg.as_dict()

    assert "\x1b[38;2;10;20;30m" in as_string["r1"]

# Generated at 2022-06-12 09:53:48.811871
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, RgbEf

    class R(Register):
        pass

    r: R = R()
    r.renderfuncs.update({RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"})
    r.renderfuncs.update({RgbBg: lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m"})
    r.renderfuncs.update({RgbEf: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m\x1b[48;2;{r};{g};{b}m"})


# Generated at 2022-06-12 09:54:15.778115
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import RgbBg, RgbFg, Sgr

    def my_renderfunc(*args):
        params = ";".join(str(x) for x in args)
        return f"\x1b[{params}m"

    r1 = Register()
    r1.set_renderfunc(RgbFg, my_renderfunc)
    r1.set_eightbit_call(RgbFg)

    r1.red = Style(RgbFg(1, 0, 0), Sgr(1))

    assert isinstance(r1.red, Style) is True
    assert r1.red == "\x1b[38;2;1;0;0m\x1b[1m"

# Generated at 2022-06-12 09:54:25.732150
# Unit test for constructor of class Style
def test_Style():

    r1 = RenderType("R1")
    r2 = RenderType("R2")
    r3 = RenderType("R3")

    sty1 = Style(r1, r2)
    sty2 = Style(r2, r3)

    sty3 = Style(sty1, sty2, value="")

    assert sty3 == "\x1b[R1;R2m\x1b[R2;R3m"
    assert sty3.rules == (r1, r2, r2, r3)

    sty4 = Style("R4")

    assert sty4 == "\x1b[R4m"
    assert sty4.rules == ("R4",)



# Generated at 2022-06-12 09:54:35.519945
# Unit test for constructor of class Register
def test_Register():
    """
    Tests the constructor of class Register.
    """

    from .rendertype import RgbBg
    from .util_renderfunc import render_rgb_bg

    reg1 = Register()

    # Test if default values are set
    assert len(reg1.renderfuncs) == 0
    assert reg1.is_muted == False

    # Test if attributes can be set manually.
    reg1.is_muted = True
    reg1.renderfuncs = {RgbBg: render_rgb_bg}
    assert reg1.is_muted == True
    assert len(reg1.renderfuncs) == 1
    assert reg1.renderfuncs[RgbBg] == render_rgb_bg

# Generated at 2022-06-12 09:54:41.901461
# Unit test for constructor of class Register
def test_Register():

    # Test if constructor works.
    r1: Register = Register()
    r2: Register = Register()

    # Test if attributes can be set and if they are equal afterwards.
    attr1 = "bla"
    r1.bla = "Value"
    r2.bla = "Value"

    assert getattr(r1, attr1) == getattr(r2, attr1)

    # Test if attributes can be set to default-values.
    attr2 = "default"
    r1.default = 10
    r2.default = None

    assert getattr(r1, attr2) == getattr(r2, attr2)

# Generated at 2022-06-12 09:54:52.492895
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class Rgb1(RenderType):
        rt = '\x1b[38;2;{};{};{}m'

    class Rgb2(RenderType):
        rt = '\x1b[38;5;{};{};{}m'

    fg = Register()
    fg.set_renderfunc(Rgb1, lambda r, g, b: Rgb1(r, g, b))
    fg.set_renderfunc(Rgb2, lambda r, g, b: Rgb2(r, g, b))

    red = fg.red = Style(Rgb1(5, 5, 5))

    fg.set_rgb_call(Rgb2)

    assert red != fg.red



# Generated at 2022-06-12 09:54:58.764600
# Unit test for method mute of class Register
def test_Register_mute():
    class MyRegister(Register):
        pass

    myr = MyRegister()
    myr.set_renderfunc(RenderType, lambda x: "k")

    myr.test = Style("test", value="foobar")

    assert myr.test == "foobar"

    myr.mute()
    assert myr.test == ""

    myr.unmute()
    assert myr.test == "foobar"

# Generated at 2022-06-12 09:55:06.055924
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r1 = fg.blue + bg.yellow + ef.bold
    r2 = bg.red
    r3 = ef.bold

    register = Register()

    register.blue = r1
    register.red = r2
    register.bold = r3

    register_dict = register.as_dict()
    assert (register_dict == {"blue": "\x1b[34m\x1b[43m\x1b[1m", "red": "\x1b[41m", "bold": "\x1b[1m"})


# Generated at 2022-06-12 09:55:08.436452
# Unit test for method unmute of class Register
def test_Register_unmute():
    register = Register()
    register.unmute()
    assert register.is_muted is False


# Generated at 2022-06-12 09:55:11.269378
# Unit test for constructor of class Register
def test_Register():
    def render_func(x):
        return

    rs = Register()
    assert len(rs.renderfuncs) == 0

    rs.set_renderfunc(RenderType, render_func)
    assert len(rs.renderfuncs) == 1

# Generated at 2022-06-12 09:55:22.822102
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty.rendertype import RgbFg, Sgr

    # Test if the string attribute gets set correctly.
    reg = Register()
    reg.test = Style(RgbFg(10, 20, 30), Sgr(1))
    assert str(reg.test) == "\x1b[38;2;10;20;30m\x1b[1m"
    assert reg.test == Style(RgbFg(10, 20, 30), Sgr(1))

    # Test if it is possible to create a class attribute.
    reg.test2 = Style(RgbFg(10, 20, 30), Sgr(1))
    assert str(reg.test2) == "\x1b[38;2;10;20;30m\x1b[1m"

# Generated at 2022-06-12 09:55:49.395219
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg

    def render(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    fg = Register()
    fg.renderfuncs.update({RgbFg: render})
    fg.set_rgb_call(RgbFg)
    assert fg(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-12 09:55:50.650840
# Unit test for method __call__ of class Register
def test_Register___call__():
    pass



# Generated at 2022-06-12 09:55:58.605697
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test the method set_eightbit_call for Register objects.
    It creates an new register-object and adds a renderfunc for
    the rendertype Sgr. Then it calls a register-object with an int.
    """
    reg = Register()

    @reg.set_renderfunc(Sgr, lambda *args: f"SGR_{args[0]}")
    def render(rendertype: Type[RenderType], *args) -> str:
        return rendertype(*args)

    reg.set_eightbit_call(Sgr)

    assert reg(42) == "SGR_42"

# Generated at 2022-06-12 09:56:02.769220
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import pytest
    from sty import fg
    from sty.ansi import RgbBg, RgbFg

    assert isinstance(fg.red, Style)

    fg.set_rgb_call(rendertype=RgbFg)

    assert isinstance(fg(0, 0, 0), str)



# Generated at 2022-06-12 09:56:08.684542
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.set_renderfunc(None, lambda x: "2")
    r.set_eightbit_call(None)
    r.set_rgb_call(None)
    r.aa = Style()
    r.is_muted = True

    r_ = r.copy()

    assert r_ is not r

    assert r_.renderfuncs is not r.renderfuncs
    assert r_.rgb_call is not r.rgb_call
    assert r_.eightbit_call is not r.eightbit_call
    assert r_.aa is not r.aa


# Generated at 2022-06-12 09:56:17.136778
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        sequence: str = "38;2"
        args: Tuple[int, int, int]

    class Sgr(RenderType):
        sequence: str = "1"
        args: Tuple[int]

    class RgbBg(RenderType):
        sequence: str = "48;2"
        args: Tuple[int, int, int]

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)


# Generated at 2022-06-12 09:56:25.128242
# Unit test for constructor of class Style
def test_Style():

    a = Style(RenderType(1, 2, 3))
    assert isinstance(a, Style)
    assert a.rules[0].args == (1, 2, 3)

    a = Style(RenderType(1, 2, 3), RenderType(1, 2, 3))
    assert a.rules[0].args == (1, 2, 3)
    assert a.rules[1].args == (1, 2, 3)

    a = Style(RenderType(1, 2, 3), value="a")
    assert a == "a"
    assert a.rules[0].args == (1, 2, 3)

    a = Style(RenderType(1, 2, 3), "a")
    assert a == "a"
    assert a.rules[0].args == (1, 2, 3)

# Generated at 2022-06-12 09:56:34.685655
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr

    class RgbFg2(RgbFg):
        pass

    class RgbBg2(RgbFg):
        pass

    class Sgr2(Sgr):
        pass

    class CustomRegister(Register):
        test = Style(Sgr(1))
        test2 = Style(RgbBg(1, 2, 3), Sgr(1))

    r = CustomRegister()

    r.set_renderfunc(RgbFg2, lambda r, g, b: f"Fg({r}, {g}, {b})")

    r.set_renderfunc(RgbBg2, lambda r, g, b: f"Bg({r}, {g}, {b})")


# Generated at 2022-06-12 09:56:42.727783
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MyColor(RenderType):
        cmd = '\x1b[{}m'

    class MyBgColor(RenderType):
        cmd = '\x1b[{}m'

    def my_render(delta):
        # Adds color code to cmd.
        return MyColor.cmd.format(delta)

    def my_bg_render(delta):
        # Adds color code to cmd.
        return MyBgColor.cmd.format(delta)

    reg = Register()
    # Add render-functions to register object.
    reg.set_renderfunc(MyColor, my_render)
    reg.set_renderfunc(MyBgColor, my_bg_render)

    c = Style(MyColor(5), MyBgColor(42))

    reg.test = c

    assert isinstance

# Generated at 2022-06-12 09:56:54.172305
# Unit test for method unmute of class Register
def test_Register_unmute():

    class MyRegister(Register):
        pass

    test_reg = MyRegister()

    test_reg.red = Style(RgbFg(255, 0, 0))
    test_reg.green = Style(RgbFg(0, 255, 0))

    assert test_reg.red == "\x1b[38;2;255;0;0m"
    assert test_reg.green == "\x1b[38;2;0;255;0m"

    test_reg.mute()
    assert test_reg.red == ""
    assert test_reg.green == ""

    test_reg.unmute()

    assert test_reg.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-12 09:57:36.056776
# Unit test for constructor of class Register
def test_Register():

    class _Register(Register):
        pass

    r = _Register()
    assert r.is_muted is False
    assert r.eightbit_call is not None
    assert r.rgb_call is not None
    assert isinstance(r.renderfuncs, dict)


# Generated at 2022-06-12 09:57:41.997627
# Unit test for constructor of class Style
def test_Style():

    from sty.fmt import RgbFg, Sgr
    from sty.types import Color

    fg = Color.fg
    style = Style(RgbFg(1, 2, 3), Sgr(1))

    assert style == "\x1b[38;2;1;2;3m\x1b[1m"
    assert style.rules == (RgbFg(1, 2, 3), Sgr(1))

    style = fg.red
    assert style == "\x1b[31m"
    assert style.rules == (Sgr(31),)



# Generated at 2022-06-12 09:57:48.272518
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(1,2,3), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules == (RgbFg(1,2,3), Sgr(1))
    assert str(style) == "\x1b[38;2;1;2;3m\x1b[1m"

    style = Style()
    assert style == ""
    assert style.rules == ()


# Generated at 2022-06-12 09:57:57.018172
# Unit test for method __call__ of class Register
def test_Register___call__():

    register = Register()

    func_24bit = lambda *args: f"{args}"
    func_8bit = lambda *args: f"{args}"
    register.set_renderfunc(rendertype=RgbFg, func=func_24bit)
    register.set_renderfunc(rendertype=Bg, func=func_24bit)
    register.set_renderfunc(rendertype=EightbitFg, func=func_8bit)
    register.set_renderfunc(rendertype=EightbitBg, func=func_8bit)

    register.set_rgb_call(RgbFg)
    register.set_eightbit_call(EightbitFg)

    register.fg_1 = Style(RgbBg(1, 2, 3))

# Generated at 2022-06-12 09:58:01.433854
# Unit test for method copy of class Register
def test_Register_copy():
    from .predefined import fg, bg, ef, rs

    fg2 = fg.copy()
    assert fg2.blue == fg.blue
    assert fg2.dark_green == fg.dark_green

    fg.blue = Sty("blue")
    assert fg2.blue != fg.blue
    assert fg2.dark_green == fg.dark_green

# Generated at 2022-06-12 09:58:02.870502
# Unit test for method __new__ of class Style
def test_Style___new__():
    value = "test"
    style = Style(*value)
    assert style == value


# Generated at 2022-06-12 09:58:12.421516
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_eightbit_call(TypeError)  # TypeError is not a RenderType, so no change
    r.set_eightbit_call(RenderType)  # RenderType is not a RenderType, so no change
    assert type(r.eightbit_call) is not TypeError
    assert type(r.eightbit_call) is not RenderType
    r.set_eightbit_call(RenderType)  # RenderType is not a RenderType, so no change
    assert type(r.eightbit_call) is not TypeError
    assert type(r.eightbit_call) is not RenderType
    r.set_eightbit_call(RenderType)  # RenderType is not a RenderType, so no change
    assert type(r.eightbit_call) is not TypeError

# Generated at 2022-06-12 09:58:20.679404
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define a dummy rendertype with a default renderfunction.
    class DummyRendertype(RenderType):
        renderfunc = lambda x: x

    # Create a dummy register.
    dummy_reg = Register()

    # Add a style to register.
    dummy_reg.test = Style(DummyRendertype(), "test")

    # The style should be rendered with the default renderfunc.
    assert dummy_reg.test == "test"

    # Replace the renderfunc with a function that wraps the output in [].
    dummy_reg.set_renderfunc(DummyRendertype, lambda x: "[{}]".format(x))

    # The style should be rendered with the new renderfunc.
    assert dummy_reg.test == "[test]"

# Generated at 2022-06-12 09:58:26.097721
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from . import ansi

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(ansi.RgbFg(1,2,3), ansi.Sgr(4), ansi.Sgr(5))

    rg = MyRegister()
    rg.red = Style(ansi.Sgr(10))
    rg.mute()
    assert str(rg.red) == ""
    assert rg.red.rules == (ansi.Sgr(10),)



# Generated at 2022-06-12 09:58:35.198518
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import EightBitFg, RgbFg

    class RegisterX(Register):
        red = Style(EightBitFg(124))
        blue = Style(EightBitFg(124))

    r = RegisterX()
    r.set_eightbit_call(EightBitFg)

    assert r("red") == "\x1b[38;5;124m"
    assert r("blue") == "\x1b[38;5;124m"
    assert r(42) == "\x1b[38;5;42m"
    assert r(42, 42) == "\x1b[38;5;42m"
    assert r(42, 42, 42) == ""
    assert r("green") == ""

    r.set_rgb_call(RgbFg)

    assert r("red")