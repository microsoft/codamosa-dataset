

# Generated at 2022-06-12 09:50:04.419230
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    The function `Register.__call__` is called when you write `fg(11)`.
    This test checks that the function handles both 8bit and 24bit color calls.
    """
    # Create register object and add render funcs.
    register = Register()
    register.set_renderfunc(RenderType.Eightbit, lambda x: "\x1b[38;5;{}m".format(x))
    register.set_renderfunc(RenderType.Rgb, lambda r, g, b: "\x1b[38;2;{};{};{}m".format(r, g, b))
    fg = "\x1b[38;5;11m"
    rgb = "\x1b[38;2;10;42;255m"

    # Set eightbit and rgb call funcs.
    register.set

# Generated at 2022-06-12 09:50:07.135076
# Unit test for constructor of class Register
def test_Register():
    new_register = Register()
    assert isinstance(new_register, Register)



# Generated at 2022-06-12 09:50:17.454186
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Test setup
    class RgbFg(RenderType, NamedTuple):
        r: int
        g: int
        b: int

    class Sgr(RenderType, NamedTuple):
        val: int

    fg = Register()
    fg.renderfuncs = {RgbFg: lambda x, y, z: f"\x1b[38;2;{x};{y};{z}m"}

    # Test with 8bit register call
    fg.set_eightbit_call(RgbFg)
    assert fg(10) == "\x1b[38;2;10;10;10m"

    # Test with RGB register call
    fg.set_rgb_call(RgbFg)

# Generated at 2022-06-12 09:50:19.665171
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.eightbit_call == None
    assert r.rgb_call == None
    assert len(r.renderfuncs) == 0

# Generated at 2022-06-12 09:50:20.540031
# Unit test for method __call__ of class Register
def test_Register___call__():
    # TODO
    pass

# Generated at 2022-06-12 09:50:30.201793
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    r.set_renderfunc(RgbFg, lambda *args, **kwargs: "\x1b[38;2;" + str(args[0]) + "m")

    r.blue = Style(RgbFg(42), Sgr(1))

    assert isinstance(r.blue, Style)
    assert isinstance(r.blue, str)
    assert str(r.blue) == "\x1b[38;2;42m\x1b[1m"



# Generated at 2022-06-12 09:50:31.240172
# Unit test for constructor of class Register
def test_Register():
    pass


# Generated at 2022-06-12 09:50:34.387053
# Unit test for constructor of class Register
def test_Register():

    import unittest

    class A(Register):
        pass

    a = A()

    class TestRegister(unittest.TestCase):

        def test(self):
            self.assertIsInstance(a, Register)

    unittest.main()

# Generated at 2022-06-12 09:50:35.975087
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register
    assert isinstance(register, Register)



# Generated at 2022-06-12 09:50:39.296062
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    # Test constructor.
    assert isinstance(register, Register)
    assert isinstance(register.renderfuncs, dict)
    assert register.is_muted is False



# Generated at 2022-06-12 09:50:49.507395
# Unit test for constructor of class Register
def test_Register():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()

    # Test for callable with render-func
    tr = TestRegister()
    tr.set_renderfunc(str, lambda r: f"{r!s}")
    assert isinstance(tr, Register)
    assert tr == Register()
    assert isinstance(tr.as_dict(), dict)
    assert isinstance(tr.as_namedtuple(), NamedTuple)


# Generated at 2022-06-12 09:50:52.014718
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    assert register.is_muted == False
    assert register.eightbit_call == register.rgb_call
    assert register.renderfuncs == {}

# Generated at 2022-06-12 09:50:53.428602
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)

# Generated at 2022-06-12 09:50:55.500315
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False


# Generated at 2022-06-12 09:50:59.687020
# Unit test for constructor of class Register
def test_Register():

    r1 = Register()
    assert r1.is_muted == False

    r2 = Register()
    r2.mute()
    assert r2.is_muted == True

    r2.unmute()
    assert r2.is_muted == False


# Generated at 2022-06-12 09:51:01.285904
# Unit test for constructor of class Register
def test_Register():

    reg1 = Register()
    assert isinstance(reg1, Register)


# Generated at 2022-06-12 09:51:08.088438
# Unit test for constructor of class Register
def test_Register():

    reg = Register()

    # Check that the call method of Register works
    reg.red = Style(value="red")

    assert reg.red == "red"

    # Check that the call method of Register works
    reg.green = Style(value="green")

    assert reg.green == "green"

    # Check that the call method of Register works
    reg.blue = Style(value="blue")

    assert reg.blue == "blue"

    assert isinstance(reg.red, str)

    assert isinstance(reg.green, str)

    assert isinstance(reg.blue, str)



# Generated at 2022-06-12 09:51:09.779665
# Unit test for constructor of class Register
def test_Register():
    my_register: Register = Register()

    assert my_register
    assert my_register.is_muted is False

# Generated at 2022-06-12 09:51:13.024245
# Unit test for constructor of class Register
def test_Register():
    g1 = Register()
    g2 = g1.copy()
    g2.red = Style(RgbFg(255,0,0))
    assert not hasattr(g1, "red")
    assert hasattr(g2, "red")

# Generated at 2022-06-12 09:51:16.169528
# Unit test for constructor of class Register
def test_Register():
    from . import ansi

    assert isinstance(ansi.fg, Register)
    assert isinstance(ansi.bg, Register)
    assert isinstance(ansi.ef, Register)
    assert isinstance(ansi.rs, Register)



# Generated at 2022-06-12 09:51:42.627904
# Unit test for method __new__ of class Style
def test_Style___new__():

    class Sgr(RenderType):
        args = ('value', )

        def __init__(self, value: int) -> None:
            self.value = value

        def __format__(self, fmt: str) -> str:
            return "\x1b[{}m".format(self.value)

    tests = [
        (Style(Sgr(1), value="\x1b[1m"), True),
        (Style(Sgr("1"), value="\x1b[1m"), False),
        (Style("foo"), False),
        (Style(Sgr("1"), value="foo"), False),
    ]

    for style, test_result in tests:
        isinstance_result = isinstance(style, Style)

# Generated at 2022-06-12 09:51:45.756198
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    R = Register()
    R.set_renderfunc(RenderType, lambda x: x)

    with pytest.raises(TypeError):
        R.set_eightbit_call(None)



# Generated at 2022-06-12 09:51:54.427774
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Test with rendertype as an attribute.
    class MyRenderType(RenderType):
        def render_string(self):
            return "hello"

    def render_func(rt: MyRenderType) -> str:
        return rt.render_string()

    r = Register()
    rt = MyRenderType()
    r.set_renderfunc(MyRenderType, render_func)
    a = Style(rt)

    r.attr = a

    assert r.attr == "hello"

    # Test with Style as an attribute.
    r = Register()
    s = Style(rt)
    r.attr = s

    assert r.attr == "hello"

# Generated at 2022-06-12 09:51:59.239485
# Unit test for method mute of class Register
def test_Register_mute():

    fg = Register()

    fg.set_renderfunc(RenderType, lambda *x: "".join(x))

    fg.blue = Style(RenderType("BLUE"))

    fg.mute()

    assert fg.blue == ""

    fg.unmute()

    assert fg.blue == RenderType("BLUE")

# Generated at 2022-06-12 09:52:02.384175
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertypes import RgbFg

    reg = Register()
    reg.set_eightbit_call(RgbFg)
    assert reg.eightbit_call is reg.renderfuncs[RgbFg]



# Generated at 2022-06-12 09:52:10.868453
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        rendertype = 38
        number_of_arguments = 3

        @staticmethod
        def render(r: int, g: int, b: int):
            return f"\x1b[38;2;{r};{g};{b}m"

    class RgbBg(RenderType):
        rendertype = 48
        number_of_arguments = 3

        @staticmethod
        def render(r: int, g: int, b: int):
            return f"\x1b[48;2;{r};{g};{b}m"

    class Sgr(RenderType):
        rendertype = None
        number_of_arguments = 1


# Generated at 2022-06-12 09:52:14.330744
# Unit test for constructor of class Register
def test_Register():
    """
    Test constructor for class Register.
    """
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-12 09:52:23.082403
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Is24Bit

    r0 = Register()

    # Test for string
    r0.foo = Style("bar")
    assert r0.foo == "bar"

    # Test for 24Bit-rendertype
    r0.foo = Style(Is24Bit(1, 2, 3))
    assert r0.foo == Style(Is24Bit(1, 2, 3))

    # Test for style
    r0.foo = Style(Style("bar"))
    assert r0.foo == "bar"

    # Test for rendertype and style
    r0.foo = Style(Is24Bit(1, 2, 3), Style("bar"))
    assert r0.foo == "bar"

    # Test for recursively nested lists.

# Generated at 2022-06-12 09:52:27.227315
# Unit test for method unmute of class Register
def test_Register_unmute():
    class Foo(Register):
        one = Style("one")

    foo = Foo()
    foo.mute()
    
    assert foo.one == ""
    assert foo.unmute() is None
    assert foo.one == "\x1b[4m\x1b[7mone"

# Generated at 2022-06-12 09:52:37.041882
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertypes import RgbFg as rgbfg
    from .rendertypes import Sgr as sgr
    from .rendertypes import RgbBg as rgbbg
    from .rendertypes import Ef as ef
    from .rendertypes import Rs as rs

    c = Register()
    c.renderfuncs = {
        sgr: lambda *args: f"ESC[{args[0]}m",
        rgbfg: lambda r, g, b: f"ESC[38;2;{r};{g};{bm}m",
        rgbbg: lambda r, g, b: f"ESC[48;2;{r};{g};{bm}m",
    }

    # Set some styles for the register
    c.red = Style(rgbfg(255, 0, 0), sgr(1))


# Generated at 2022-06-12 09:52:59.965116
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .main import fg, bg, ef, rs
    from .modes import RgbFg, RgbBg, Sgr
    fg.set_renderfunc(RgbFg, lambda r, g, b: "fff")
    # setattr(fg, 'test', Style(RgbFg(2, 3, 4)))
    fg.test = Style(RgbFg(2, 3, 4))
    assert fg.as_dict() == {"test": "fff"}
    fg.set_eightbit_call(RgbFg)
    assert fg("red") == "fff"
    bg.set_renderfunc(RgbFg, lambda r, g, b: "fff")
    bg.red = Style(RgbBg(1, 2, 3))
    assert bg

# Generated at 2022-06-12 09:53:10.907321
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register()
    reg.set_eightbit_call(rendertype=RenderType)
    reg.set_rgb_call(rendertype=RenderType)

# Generated at 2022-06-12 09:53:15.932285
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class TestRegister(Register):
        pass

    reg = TestRegister()
    reg.foo = Style(value="\x1b[38;5;5m")

    Sty = reg.as_namedtuple()

    assert isinstance(Sty, NamedTuple)
    assert isinstance(Sty.foo, str)
    assert Sty.foo == "\x1b[38;5;5m"



# Generated at 2022-06-12 09:53:22.389410
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    r = Register()
    r.red = Style(b"\x1b[31m")
    r.green = Style(b"\x1b[32m")
    r.blue = Style(b"\x1b[34m")

    assert r.as_namedtuple().red == "\x1b[31m"
    assert r.as_namedtuple().green == "\x1b[32m"
    assert r.as_namedtuple().blue == "\x1b[34m"

# Generated at 2022-06-12 09:53:30.284953
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.set_renderfunc(RgbBg, lambda r, g, b: f"RGB{r}{g}{b}")

        def set_eightbit_call(self, rendertype):
            raise NotImplementedError()

        def set_rgb_call(self, rendertype):
            raise NotImplementedError()

    ro = TestRegister()
    assert ro(100) == ""
    assert ro(100, 50, 250) == "RGB10050250"

# Generated at 2022-06-12 09:53:33.493406
# Unit test for constructor of class Register
def test_Register():

    r = Register()

    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-12 09:53:40.079961
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .number import Number

    class SomeRegister(Register):
        pass

    r = SomeRegister()
    r.n = Style(Number(1), Sgr(7), RgbFg(10, 20, 30))
    assert r.n == "\x1b[38;2;10;20;30m\x1b[7m1\x1b[0m"

    r.mute()
    assert r.n == "1"

    r.unmute()
    assert r.n == "\x1b[38;2;10;20;30m\x1b[7m1\x1b[0m"

# Generated at 2022-06-12 09:53:50.428480
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for method mute of class Register
    """
    from .rendertype import RgbFg

    class TestRegister(Register):
        def __init__(self):
            super().__init__()

            self.red = Style(RgbFg(255, 0, 0))

    test_reg = TestRegister()

    # Should not be muted by default
    assert test_reg.is_muted is False

    # Calling an attribute should not crash
    assert test_reg.red == "\x1b[38;2;255;0;0m"

    # mute and try to call an attribute
    test_reg.mute()
    try:
        # Should crash with value error
        test_reg.red
        assert False
    except ValueError:
        pass

    # Finally unmute and check that the attribute is correctly

# Generated at 2022-06-12 09:53:57.358578
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    r1 = Style(RgbFg(0, 0, 0), Sgr(1))
    r2 = Style(RgbFg(0, 0, 0), Sgr(1))
    r3 = Style(RgbFg(255, 255, 255), Sgr(0))

    assert r1 == r2
    assert r1 != r3



# Generated at 2022-06-12 09:54:07.824061
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def sgr(*args):
        return "\x1b[{}m".format(";".join(map(str, args)))

    def rgb_fg(*args):
        return "\x1b[38;2;{};{};{}m".format(*args)

    def rgb_bg(*args):
        return "\x1b[48;2;{};{};{}m".format(*args)

    r = Register()
    r.set_renderfunc(Sgr, sgr)
    r.set_renderfunc(RgbFg, rgb_fg)

    r.set_eightbit_call(RgbFg)


# Generated at 2022-06-12 09:54:40.837890
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        """
        This is a test render type to be used in this unit test.
        """
        pass

    def renderfunc(*args) -> str:
        """
        This is a test render function to be used in this unit test.
        """
        return str(args)

    register = Register()
    register.set_renderfunc(TestRenderType, renderfunc)

    # Test if renderfunc works
    assert renderfunc(1, 2, 3) == "(1, 2, 3)"

    # Test if renderfunc is registered
    assert register.renderfuncs[TestRenderType](1, 2, 3) == "(1, 2, 3)"

    # Test if renderfunc is registered as eightbit_call
    assert register.renderfuncs[TestRenderType](1, 2, 3) == register.eightbit_

# Generated at 2022-06-12 09:54:52.118801
# Unit test for method copy of class Register
def test_Register_copy():
    # Build test register
    reg = Register()
    reg.b = Style(RgbBg(10, 20, 30))
    reg.r = Style(Bg(40))
    reg.q = Style()

    # Manually change attributes of original register
    reg.b = Style(RgbBg(1, 2, 3))
    reg.r = Style()

    # Make a copy of the original
    clone = reg.copy()

    # Check if copy is different from original.
    assert clone.b == reg.b
    assert clone.r != reg.r
    assert clone.q == reg.q

    # Check if changes to original are not carried over to copy
    reg.b = Style(RgbBg(4, 5, 6))
    assert clone.b != reg.b

# Generated at 2022-06-12 09:54:58.405180
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Test1
    fg = Register()
    fg.eightbit_call = lambda x: "%s:%d" % (x, x)
    fg.red = fg(1)

    assert fg.red == "1:1"

    fg.yellow = fg(3)

    assert fg.yellow == "3:3"

    assert fg.red != fg.yellow

    # Test2
    fg = Register()
    fg.mute()
    fg.eightbit_call = lambda x: "%s:%d" % (x, x)
    fg.red = fg(1)

    assert fg.red == ""

    fg.yellow = fg(3)

    assert fg.yellow == ""

    assert fg.red == fg.yellow




# Generated at 2022-06-12 09:55:02.348462
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class TestRegister(Register):
        pass

    test = TestRegister()
    test.r = Style("r")
    test.rr = Style("rr")

    assert test.as_dict() == {"r": "r", "rr": "rr"}



# Generated at 2022-06-12 09:55:11.860285
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Register1(Register):
        def __init__(self):
            super().__init__()

        def eightbit_call1(self, code: int) -> str:
            return f"{code}--"

        def rgb_call1(self, r: int, g: int, b: int) -> str:
            return f"{r},{g},{b}--"

    r = Register1()
    r.set_eightbit_call(lambda code: f"{code}-")
    r.set_rgb_call(lambda r, g, b: f"{r},{g},{b}-")
    assert r(8) == "8-"
    assert r("my_key") == ""
    assert r(10, 20, 30) == "10,20,30-"
    assert r.eight

# Generated at 2022-06-12 09:55:17.872457
# Unit test for constructor of class Register
def test_Register():

    # Check constructor
    r1 = Register()

    # Check that attributes are set
    assert isinstance(r1, Register)
    assert isinstance(r1.renderfuncs, dict)
    assert isinstance(r1.is_muted, bool)
    assert isinstance(r1.eightbit_call, Callable)
    assert isinstance(r1.rgb_call, Callable)

# Generated at 2022-06-12 09:55:25.621218
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == r.renderfuncs[RgbFg]

    assert callable(r.rgb_call)

    assert r.rgb_call(1, 2, 3) == "\x1b[38;2;1;2;3m"

    assert r.rgb_call(2, 3, 4) == "\x1b[38;2;2;3;4m"



# Generated at 2022-06-12 09:55:36.394683
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Test colors
    colors = Register()
    colors.black = Style(RgbFg(0, 0, 0))
    colors.white = Style(RgbFg(255, 255, 255))
    colors.red = Style(RgbFg(255, 0, 0))
    colors.green = Style(RgbFg(0, 255, 0))
    colors.blue = Style(RgbFg(0, 0, 255))
    colors.yellow = Style(RgbFg(255, 255, 0))
    colors.grey = Style(RgbFg(85, 85, 85))

    colors_dict = colors.as_dict()

    assert colors_dict["black"] == str(colors.black)
    assert colors_dict["white"] == str(colors.white)

# Generated at 2022-06-12 09:55:39.000254
# Unit test for method __new__ of class Style
def test_Style___new__():

    Sgr = lambda x: x

    s = Style(Sgr(1), Sgr(4))

    assert isinstance(s, Style)
    assert isinstance(s, str)

    assert str(s) == "\x1b[1m\x1b[4m"

# Generated at 2022-06-12 09:55:42.885643
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    assert isinstance(r, Register)  # Test if __init__ works


# Generated at 2022-06-12 09:56:48.131455
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr, RgbFg, RgbBg

    # Setup
    reg = Register()
    reg.bold = Style(Sgr(1))
    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    reg.blue = Style(RgbBg(0, 0, 255), Sgr(1))

    # Mute
    reg.mute()
    # Style should be empty
    assert str(reg.bold) == ""
    assert str(reg.red) == ""
    assert str(reg.blue) == ""

    # Unmute
    reg.unmute()
    # Style should not be empty
    assert str(reg.bold) == "\x1b[1m"

# Generated at 2022-06-12 09:56:55.317818
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class MR(Register):
        def __init__(self):
            super().__init__()
            self.xy = Style('x')
            self.xz = Style('y')
            self._xy = Style('x')
            self.__xy = Style('x')

    mr = MR()
    assert mr.as_dict() == {'__xy': '', 'xy': 'x', 'xz': 'y'}


# Generated at 2022-06-12 09:57:02.299603
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Prepare Test
    def f1(x):
        return "f1"

    def f2(x):
        return "f2"

    class RT1(RenderType):
        def __init__(self):
            super().__init__()

    class RT2(RenderType):
        def __init__(self):
            super().__init__()

    rt1 = RT1()
    rt2 = RT2()

    # Test
    r = Register()
    r.set_renderfunc(RT1, f1)
    assert r.renderfuncs[RT1] is f1

    r.set_renderfunc(RT2, f2)
    assert r.renderfuncs[RT1] is f1
    assert r.renderfuncs[RT2] is f2

    # One render type has been replaced.

# Generated at 2022-06-12 09:57:08.986394
# Unit test for constructor of class Register
def test_Register():
    # Create testing register
    reg1 = Register()
    assert reg1.is_muted == False

# Generated at 2022-06-12 09:57:15.026806
# Unit test for method mute of class Register
def test_Register_mute():
    from .crayon import Generate
    from .render import RenderType

    def renderfunc1(arg1: int, arg2: str) -> str:
        return str(arg1) + arg2

    def renderfunc2(arg1: int, arg2: str) -> str:
        return str(arg1) + arg2

    rendertype1: Type[RenderType] = Generate("MyRendertype1", "suf1")
    rendertype2: Type[RenderType] = Generate("MyRendertype2", "suf2")

    r = Register()
    r.set_renderfunc(rendertype1, renderfunc1)
    r.set_renderfunc(rendertype2, renderfunc2)

    r.test1 = Style(rendertype1(1, "!"), rendertype2(1, "!"))
    r

# Generated at 2022-06-12 09:57:18.676314
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert "blue_bold_underline" == Style(
        RgbFg(0, 0, 255), Sgr(1), Sgr(4), value="\x1b[38;2;0;0;255m\x1b[1m\x1b[4m"
    )

# Generated at 2022-06-12 09:57:23.100686
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    rgb_rule = RgbFg(1, 2, 3)
    sgr_rule = Sgr(1)

    sty = Style(rgb_rule, sgr_rule)

    assert isinstance(sty, Style)
    assert isinstance(sty, str)
    assert sty.rules == (rgb_rule, sgr_rule)

# Generated at 2022-06-12 09:57:32.719837
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    bg = Register()

    # Create a stupid dummy rendertype
    class RgbBg(RenderType):
        def __init__(self, r, g, b):
            super().__init__(r, g, b)

    # Create a stupid dummy render-func
    bg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set register render for RGB-call
    bg.set_rgb_call(RgbBg)

    # Test
    assert bg(255, 255, 255) == "\x1b[48;2;255;255;255m"



# Generated at 2022-06-12 09:57:40.859396
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RenderType1(RenderType):
        sequence = "\x1b[{fn};{fg};{bg}m"

    class RenderType2(RenderType):
        sequence = "\x1b[{fn};{fg};{bg}m"

    def render1(*args):
        return RenderType1(*args).sequence

    def render2(*args):
        return RenderType2(*args).sequence

    register = Register()

    register.set_renderfunc(RenderType1, render1)

    assert register.eightbit_call == render1

    register.set_renderfunc(RenderType2, render2)

    assert register.eightbit_call == render1

    register.set_eightbit_call(RenderType2)

    assert register.eightbit_call == render2


# Generated at 2022-06-12 09:57:42.733845
# Unit test for method mute of class Register
def test_Register_mute():
    reg: Register = Register()
    reg.mute()
    assert reg.is_muted
    reg.unmute()
    assert not reg.is_muted