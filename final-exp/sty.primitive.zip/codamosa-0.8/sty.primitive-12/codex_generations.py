

# Generated at 2022-06-12 09:50:03.447589
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from . import SGR, RGB

    r = Register()
    r.set_renderfunc(SGR, lambda r1: f"\x1b[{r1}m")
    r.set_renderfunc(RGB, lambda r1, r2, r3: f"\x1b[38;2;{r1};{r2};{r3}m")

    with pytest.raises(ValueError):
        r.test_rule = Style((1, 2, 3))

    with pytest.raises(ValueError):
        r.test_rule = Style(RGB(1, 2, 3), 4)

    r.test_rule = Style(RGB(1, 2, 3), SGR(1))

# Generated at 2022-06-12 09:50:14.919029
# Unit test for method __call__ of class Register
def test_Register___call__():

    from . import fg, bg, ef, rs

    from .colorclass import ColorClass
    from .bg import RgbBg
    from .fg import RgbFg
    from .ef import Bg, Bold

    fg.red = Style(RgbFg(255, 0, 0), Bg(128, 128, 128))
    bg.red = Style(RgbBg(255, 0, 0), Bold)

    assert fg.red is fg.red
    assert bg.red is bg.red

    assert fg.red == fg.red
    assert bg.red == bg.red

    assert fg.red is not bg.red
    assert fg.red != bg.red

    assert fg(42) == fg.red

# Generated at 2022-06-12 09:50:22.037856
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .ansi import fg, RgbFg, Sgr

    # Set property (needs type-hint for mypy)
    fg.red: Style = Style(RgbFg(255, 0, 0))
    assert isinstance(fg.red, str)
    assert str(fg.red) == "\x1b[38;2;255;0;0m"
    assert isinstance(fg.red, Style)
    assert len(fg.red.rules) == 1

    # Set property with two rules
    fg.bright_red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert isinstance(fg.bright_red, str)

# Generated at 2022-06-12 09:50:32.380972
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import SgrCode

    class FakeSgrCode(SgrCode):
        args: Tuple[int, ...]

        def __init__(self, *args):
            self.args = args

    def sgr_render_func(code: int) -> str:
        return "\x1b[{}m".format(code)

    class FakeRegister(Register):
        pass

    # Create a fake register with a render-func for SgrCode's.
    fake_register = FakeRegister()
    fake_register.set_renderfunc(FakeSgrCode, sgr_render_func)

    fake_register.bold = Style(FakeSgrCode(1))
    fake_register.underline = Style(FakeSgrCode(4))

# Generated at 2022-06-12 09:50:41.426378
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .builtins import fg
    from .rendertype import SgrFg, RgbFg

    fg_test = fg.copy()
    fg_test.set_eightbit_call(SgrFg)
    fg_test.set_rgb_call(RgbFg)
    setattr(fg_test, "custom_name", Style(SgrFg(255), RgbFg(1, 2, 3)))

    assert fg_test(255) == fg_test.custom_name == "\033[38;5;255m\033[38;2;1;2;3m"
    assert fg_test(0, 1, 0) == "\033[38;2;0;1;0m"

# Generated at 2022-06-12 09:50:45.414910
# Unit test for method __call__ of class Register
def test_Register___call__():

    fg = Register()
    fg.r = Style(RgbFg(10, 20, 30))
    fg.set_rgb_call(RgbFg)

    assert fg(10, 20, 30) == fg.r
    assert fg("r") == fg.r

# Generated at 2022-06-12 09:50:47.953458
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg

    d = fg.as_dict()
    assert "red" in d
    assert isinstance(d, dict)



# Generated at 2022-06-12 09:50:57.953298
# Unit test for method unmute of class Register
def test_Register_unmute():
    import pytest
    class MockRenderType:
        pass

    class MockStyle:
        def __init__(self, rules):
            self.rules = rules

    settings = {
        MockRenderType: lambda x: f'<MockRenderType {x}>'
    }
    class MockRegister(Register):
        def __setattr__(self, name, value):
            if isinstance(value, Style) or isinstance(value, MockStyle):
                self.renderfuncs = settings
                rendered, rules = _render_rules(settings, value.rules)
                rendered_style = MockStyle(rules, value=rendered)
                return super().__setattr__(name, rendered_style)
            else:
                return super().__setattr__(name, value)

    r = MockRegister()
    r.foo = MockRenderType

# Generated at 2022-06-12 09:51:01.530103
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.foo = Style(value="bar")
    t = r.as_namedtuple()
    assert isinstance(t, NamedTuple)
    assert t.foo == "bar"


# Generated at 2022-06-12 09:51:06.589620
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for Register.unmute() method
    """

    register = Register()
    register.eightbit_call = lambda x: "test"
    setattr(register, "test_style", Style(value="test"))

    register.is_muted = True
    register.unmute()

    assert register.is_muted is False
    assert register.test_style == "test"

# Generated at 2022-06-12 09:51:22.162561
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RenderType, RgbBg
    from .register import Register

    # Test Case 1:
    # Test RGB-call with RenderType: RgbBg
    r = Register()

    rgb_bg = RgbBg(0, 0, 0)
    r.set_renderfunc(RgbBg, lambda r, g, b, *args: "RGB")
    r.set_rgb_call(rgb_bg)
    assert (r(0, 0, 0) == "RGB")

    # Test Case 2:
    # Test RGB-call with RenderType: RgbBg
    # and with extra args.
    r = Register()

    rgb_bg = RgbBg(0, 0, 0)

# Generated at 2022-06-12 09:51:27.431888
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertypes import RgbFg
    r = Register()
    r.set_renderfunc(RgbFg, lambda x, y, z: (x, y, z))
    r.set_eightbit_call(RgbFg)
    assert r(1, 2, 3) == (1, 2, 3)
    assert r(4) == ""



# Generated at 2022-06-12 09:51:31.864649
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.foo = Style(1)
    r.bar = Style(2)
    r.baz = Style(3)
    assert r.as_dict() == {'foo': '1', 'bar': '2', 'baz': '3'}


# Generated at 2022-06-12 09:51:42.424566
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertypes import RgbFg, Sgr, NixFg

    # Create a new register-object and add render-function for RgbFg
    r1 = Register()
    r1.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set new rendertype for rgb call
    r1.set_rgb_call(RgbFg)

    # Create a style-object with rgb value
    r1.red = Style(RgbFg(255, 0, 0), Sgr(1))

    # Create a style-object with 8bit value
    r1.blue = Style(NixFg(4), Sgr(1))

    # Call style attribute red and expect result from RgbFg

# Generated at 2022-06-12 09:51:44.724362
# Unit test for method copy of class Register
def test_Register_copy():

    new_register: Register = Register().copy()

    assert new_register is not None
    assert isinstance(new_register, Register)

# Generated at 2022-06-12 09:51:53.212906
# Unit test for method copy of class Register
def test_Register_copy():
    from sty import fg

    new_fg = fg.copy()

    assert fg.rgb_call == new_fg.rgb_call

    assert fg.eightbit_call == new_fg.eightbit_call

    assert fg.renderfuncs == new_fg.renderfuncs

    assert new_fg is not fg

    assert fg("blue") == new_fg("blue")  # __call__

    assert fg.blue == new_fg.blue  # __getattr__

    assert fg.blue.value == new_fg.blue.value  # __getattr__

    assert fg.is_muted == new_fg.is_muted

# Generated at 2022-06-12 09:51:58.029814
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from sty.rendertype import RgbFg
    from sty.efftype import Bd

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: "rgb({},{},{})".format(r, g, b))
    r.set_renderfunc(Bd, lambda: "+1")

    style_1 = Style(RgbFg(100, 200, 255), Bd())
    r.test_1 = style_1

    style_2 = Style(style_1, RgbFg(1, 5, 10))
    r.test_2 = style_2

    style_3 = Style(RgbFg(1, 2, 3), RgbFg(4, 5, 6))
    r.test_3 = style_3


# Generated at 2022-06-12 09:52:03.964084
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 5, 10), Sgr(1, 1))
    assert style == '\x1b[38;2;1;5;10m\x1b[1;1m'
    assert style.rules == (RgbFg(1, 5, 10), Sgr(1, 1))
    assert isinstance(style, Style)
    assert isinstance(style, str)



# Generated at 2022-06-12 09:52:08.616354
# Unit test for constructor of class Style
def test_Style():
    """
    Test if Style behaves like a normal str.

    :return:
    """
    r1 = RenderType()
    r2 = RenderType()

    s1 = Style(r1, r2)

    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert "r1" not in str(s1)
    assert "r2" not in str(s1)

# Generated at 2022-06-12 09:52:19.618123
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class EightbitTestType(RenderType):
        pass

    class RGBTestType(RenderType):
        pass

    def eightbit_func(i: int) -> str:
        return "eightbit"

    def rgb_func(r: int, g: int, b: int) -> str:
        return "rgb"

    reg = Register()
    reg.set_renderfunc(EightbitTestType, eightbit_func)
    reg.set_renderfunc(RGBTestType, rgb_func)

    assert reg.eightbit_call == rgb_func
    assert reg.rgb_call == rgb_func

    reg.set_eightbit_call(EightbitTestType)
    reg.set_rgb_call(RGBTestType)

    assert reg.eightbit_call == eightbit_func
    assert reg.rgb_call

# Generated at 2022-06-12 09:52:34.101792
# Unit test for method unmute of class Register
def test_Register_unmute():

    r = Register()
    r.red = Style(RgbFg(255,0,0))
    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)

    r.mute()

    assert str(r.red) == ""
    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)

    r.unmute()

    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert isinstance(r.red, Style)
    assert isinstance(r.red, str)

# Generated at 2022-06-12 09:52:37.632472
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.red = Style()
    r.white = Style()
    r.black = Style()
    x = r.as_dict()

    assert isinstance(x, dict)
    assert x == {"red": "", "white": "", "black": ""}



# Generated at 2022-06-12 09:52:42.114429
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbBg(1, 2, 3))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[48;2;1;2;3m"



# Generated at 2022-06-12 09:52:47.584421
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestRender(RenderType):
        pass

    def renderfunc(t):
        return "test"

    r1 = Register()
    r1.test = Style(TestRender())

    assert str(r1.test) == ""

    r1.set_renderfunc(TestRender, renderfunc)

    assert str(r1.test) == "test"

# Generated at 2022-06-12 09:52:58.151905
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Eightbit, RgbFg, Sgr

    r = Register()

    class SgrBold(Sgr):
        sgr = 1

    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(SgrBold, lambda s, bold: "\x1b[{};1m".format(s))

    r.red = Style(Eightbit(196), SgrBold(1))

    # Test Eightbit-call
    assert r(196) == "\x1b[38;5;196m\x1b[1m"

    # Test RGB-call
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    # Test Attribute-

# Generated at 2022-06-12 09:53:03.279015
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg = Register()
    reg.set_eightbit_call(lambda x: f"{x}")
    reg.set_rgb_call(lambda r, g, b: f"{r};{g};{b}")

    reg.test1 = Style(10)
    reg.test2 = Style(10, 20)
    reg.test3 = Style(10, 20, 30)

    nt = reg.as_namedtuple()

    assert nt.test1 == "10"
    assert nt.test2 == "10;20"
    assert nt.test3 == "10;20;30"


# Generated at 2022-06-12 09:53:05.856197
# Unit test for method copy of class Register
def test_Register_copy():

    from . import fg

    c = fg.red.copy()

    assert c is not fg.red
    assert c == fg.red


# Generated at 2022-06-12 09:53:16.345508
# Unit test for method __call__ of class Register
def test_Register___call__():
    class FG(Register):
        black = Style(RgbFg(0, 0, 0))
        red = Style(RgbFg(255, 0, 0))

    fg = FG()
    new_fg = fg.copy()

    fg.set_rgb_call(RgbFg)
    fg.set_eightbit_call(CsiFg)

    new_fg.set_renderfunc(CsiBg, lambda x: f"\x1b[48;5;{x}m")
    new_fg.set_rgb_call(CsiBg)
    new_fg.set_eightbit_call(CsiBg)

    assert fg("red") == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-12 09:53:23.951019
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertypes import Sgr
    from .default import fg
    r: Register = fg

    assert r.eightbit_call == fg.renderfuncs[Sgr]

    r.set_eightbit_call(Sgr)

    assert r.eightbit_call == fg.renderfuncs[Sgr]

    with T.RaiseContextManager(
        TypeError,
        "The render function of the rendertype 'RgbFg' was not found in the register.",
    ):
        r.set_eightbit_call(fg.renderfuncs[RgbFg])



# Generated at 2022-06-12 09:53:25.198056
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    Register().as_namedtuple()


# Generated at 2022-06-12 09:53:40.799668
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import (
        RgbBg,
        RgbFg,
        Sgr,
    )

    # Every style in this dict is muted.
    style_dict = {
        "red": Style(RgbFg(255, 0, 0), Sgr(1)),
        "blue": Style(RgbBg(0, 0, 255), Sgr(0)),
        "yellow": Style(RgbFg(239, 155, 0), Sgr(7)),
        "green": Style(RgbFg(0, 255, 0), Sgr(0)),
    }

    # This dict contains the corresponding unmuted styles.

# Generated at 2022-06-12 09:53:49.835306
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from ..render import RgbFg, Sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: "")
    fg.set_renderfunc(Sgr, lambda *args: "")

    fg.blue = Style(RgbFg(0, 0, 255))
    fg.bold = Style(Sgr(1))

    fg.set_rgb_call(RgbFg)
    assert fg(0, 0, 255) == "\x1b[38;2;0;0;255m"
    assert fg(0, 0, 255, 1) == "\x1b[1m"



# Generated at 2022-06-12 09:53:54.969659
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .register import Register
    from .rendertype import RgbFg, RgbBg, Sgr

    r = Register()
    r.red = Style(RgbFg(1,0,0), RgbBg(10,0,0), Sgr(1))

    d = r.as_dict()

    assert len(d) == 1
    assert isinstance(d, dict)
    assert d["red"] == "\x1b[38;2;1;0;0m\x1b[48;2;10;0;0m\x1b[1m"



# Generated at 2022-06-12 09:54:05.543350
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import Sgr, RgbFg, EightbitFg

    red = Style(RgbFg(255, 0, 0))
    assert red == "\x1b[38;2;255;0;0m"
    assert red.rules == (RgbFg(255, 0, 0),)

    bold_red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert bold_red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert bold_red.rules == (RgbFg(255, 0, 0), Sgr(1))

    eightbit_red = Style(EightbitFg(1), RgbFg(255, 0, 0))

# Generated at 2022-06-12 09:54:09.315558
# Unit test for constructor of class Style
def test_Style():
    s = Style(RenderType(), RenderType())
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert len(s.rules) == 2
    assert s.rules == [RenderType(), RenderType()]

# Generated at 2022-06-12 09:54:17.926689
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class Rgb(NamedTuple):
        r: int
        g: int
        b: int

    class StyleRegister(Register):
        red: "Style" = Style(Rgb(255, 0, 0))
        blue: "Style" = Style(Rgb(0, 0, 255))

    style_reg = StyleRegister()

    # Make sure that _render_rules actually works.
    assert style_reg.red == "\x1b[38;2;255;0;0m"
    assert style_reg.blue == "\x1b[38;2;0;0;255m"

    # Test with dict.
    style_tuple_dict = style_reg.as_namedtuple()._asdict()

# Generated at 2022-06-12 09:54:23.105432
# Unit test for method __new__ of class Style
def test_Style___new__():
    f = Style(rgb(10, 20, 30), sgr(1))
    assert str(f), "\x1b[38;2;10;20;30m\x1b[1m"
    assert f.rules[0].__class__.__name__ == "RgbFg"
    assert f.rules[1].__class__.__name__ == "Sgr"


# Generated at 2022-06-12 09:54:32.827632
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg

    r = Register()

    r.set_renderfunc(
        rendertype=RgbFg,
        func=lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
    )

    r.set_eightbit_call(RgbFg)

    r.red = Style(RgbFg(10, 40, 40))

    assert r(1) == ""
    assert r(100) != ""
    assert r(100) == r.red
    assert r(100) != r.red
    assert r(100) == "\x1b[38;2;7;68;68m"

# Generated at 2022-06-12 09:54:33.231441
# Unit test for constructor of class Register
def test_Register():
    Register()

# Generated at 2022-06-12 09:54:35.899620
# Unit test for method __new__ of class Style
def test_Style___new__():

    s = Style(*[], value="")

    assert isinstance(s, str)
    assert isinstance(s, Style)

    assert len(s) == 0

    assert s.rules == []



# Generated at 2022-06-12 09:54:57.079828
# Unit test for method copy of class Register
def test_Register_copy():
    register_A = Register()
    register_B = register_A.copy()

    assert(id(register_A) != id(register_B))
    assert(id(register_A.renderfuncs) != id(register_B.renderfuncs))

# Unit tests for method mute/unmute of class Register

# Generated at 2022-06-12 09:55:07.632272
# Unit test for constructor of class Register
def test_Register():
    from .sgr import Sgr
    from .rgb import RgbEf, RgbBg, RgbFg
    r = Register()
    r.set_renderfunc(Sgr, str)
    r.set_renderfunc(RgbEf, lambda r, g, b: (r, g, b))
    r.set_renderfunc(RgbBg, lambda r, g, b: (r, g, b))
    r.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))

    r.cyan = Style(RgbFg(10, 42, 255))
    r.red = Style(RgbFg(255, 42, 42))
    r.bold = Style(Sgr(1))

# Generated at 2022-06-12 09:55:14.190224
# Unit test for method copy of class Register
def test_Register_copy():

    from . import fg

    new_fg = fg.copy()
    assert new_fg.gray == fg.gray
    assert fg.gray is not new_fg.gray
    assert new_fg.gray is not fg.gray
    assert new_fg.gray == "\033[38;2;14;14;14m"
    assert new_fg.gray == fg.gray
    assert fg.gray is not new_fg.gray
    assert new_fg.gray is not fg.gray
    assert new_fg.renderfuncs is not fg.renderfuncs
    assert new_fg.eightbit_call is not fg.eightbit_call
    assert new_fg.rgb_call is not fg.rgb_call



# Generated at 2022-06-12 09:55:25.985818
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        name = "RgbFg"

        def __init__(self, r: int, g: int, b: int) -> None:
            self.args = (r, g, b)

    class Sgr(RenderType):
        name = "Sgr"

        def __init__(self, code: int) -> None:
            self.args = (code,)

    def sgr_func(code: int) -> str:
        return f"\x1b[{code}m"

    def rgb_func(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    r = Register()
    r.set_eightbit_call(Sgr(1))


# Generated at 2022-06-12 09:55:34.472361
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg

    r = Register()
    r.black = Style(RgbBg(0, 0, 0))
    r.set_rgb_call(RgbBg)

    assert r(0, 0, 0) == "\x1b[48;2;0;0;0m"
    assert r(255, 255, 255) == "\x1b[48;2;255;255;255m"
    assert r(3, 10, 20) == "\x1b[48;2;3;10;20m"



# Generated at 2022-06-12 09:55:41.105954
# Unit test for method __call__ of class Register
def test_Register___call__():

    import sty

    fg = sty.fg
    bg = sty.bg

    # 1. fg(42) calls
    fg.yellow = Style(RgbFg(10, 10, 1))

    assert fg(42) == ""
    assert fg(42, muted=True) == ""

    assert fg(42) != fg.yellow
    assert fg(42, muted=True) == fg.yellow

    assert fg.yellow == "\x1b[38;2;10;10;1m"
    assert fg.yellow == "yellow"

    # 2. bg(42) calls
    bg.purple = Style(RgbBg(10, 10, 1))

    assert bg(42) == ""
    assert bg(42, muted=True) == ""

    assert b

# Generated at 2022-06-12 09:55:50.263686
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        deep_blue = Style(Bg8(21))
        deep_purple = Style(Bg24(20, 40, 60))

    renderfuncs = {
        Bg8: lambda x: f"{x}m",
        Bg24: lambda r, g, b: f"{r}-{g}-{b}m",
    }

    test_register = TestRegister()
    test_register.renderfuncs = renderfuncs
    test_register.set_eightbit_call(Bg8)
    test_register.set_rgb_call(Bg24)

    assert test_register("deep_blue") == "21m"
    assert test_register(21) == "21m"

# Generated at 2022-06-12 09:56:00.576110
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import ANSI256_8bit, RgbFg
    from .render import Render
    import sty

    # Setup render instance.
    r = Render(reset=False)

    # Setup register.
    register = Register()
    register.set_eightbit_call(ANSI256_8bit)
    register.set_renderfunc(RgbFg, r.ansi24bit_foreground)

    # Create style and set a attribute for register.
    style = Style(RgbFg(5,5,5))
    setattr(register, "custom_color", style)


    assert isinstance(register.custom_color, Style) # Sanity check.

    # Mute register.
    register.mute()

    # Check that register.custom_color is now an immutable style.

# Generated at 2022-06-12 09:56:08.720442
# Unit test for method mute of class Register
def test_Register_mute():
    # Create test register
    register = Register()

    # Set render_func with dummy values
    register.set_renderfunc(type, lambda x: "test")
    register.eight_bit_call = lambda x: "test"
    register.rgb_call = lambda x, y, z: "test"

    # Create dummy Style object
    styl = Style(type(2), type(3))

    # Set dummy Style
    setattr(register, "test_style", styl)

    # Mute register
    register.mute()

    # Check that style is muted
    assert register.test_style == ""

    # Check that Renderfuncs produce empty strings
    assert type(2) == ""
    assert type(3) == ""
    assert register.eight_bit_call(2) == ""

# Generated at 2022-06-12 09:56:12.715540
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.yellow = Style(RgbFg(1, 2, 3))

    assert r(1) == ""
    assert r(1, 2, 3) == ""
    assert r(1, 2, 3, 4) == ""
    assert r("1") == ""

    r.set_renderfunc(RgbFg, str)
    assert r(1) == ""
    assert r(1, 2, 3) == "(1, 2, 3)"
    assert r(1, 2, 3, 4) == ""

    r.yellow()
    assert r(1, 2, 3) == "(1, 2, 3)"
    assert r.yellow == "(1, 2, 3)"
    assert r.yellow() == "(1, 2, 3)"

# Generated at 2022-06-12 09:56:52.384967
# Unit test for method __new__ of class Style
def test_Style___new__():

    class TestStyle(Style):
        def __new__(cls, *args, value="") -> "TestStyle":
            return super().__new__(cls, *args, value=value)

    s1: TestStyle = TestStyle(TestStyle("Foo"), TestStyle("Bar"))

    assert isinstance(s1, str)
    assert s1 == "FooBar"

# Generated at 2022-06-12 09:56:57.310424
# Unit test for method copy of class Register
def test_Register_copy():

    register = Register()
    register.k = Style(RgbBg(1,2,3))

    assert register.k.rules == [RgbBg(1,2,3)]

    register_copy = register.copy()

    assert register_copy.k.rules == [RgbBg(1,2,3)]

    register_copy.k.rules.append(RgbBg(4,5,6))

    assert register_copy.k.rules == [RgbBg(1,2,3), RgbBg(4,5,6)]

    assert register.k.rules == [RgbBg(1,2,3)]



# Generated at 2022-06-12 09:57:03.291457
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    This is a unit test that tests the as_namedtuple method of the Register class.
    """
    from sty import fg
    r = fg.copy().as_namedtuple()
    assert hasattr(r, "red")
    assert hasattr(r, "rgb_red")
    assert hasattr(r, "green")
    assert hasattr(r, "rgb_green")
    assert hasattr(r, "blue")
    assert hasattr(r, "rgb_blue")
    assert hasattr(r, "bright_black")
    assert hasattr(r, "bright_red")
    assert hasattr(r, "bright_green")
    assert hasattr(r, "bright_yellow")
    assert hasattr(r, "bright_blue")

# Generated at 2022-06-12 09:57:07.797468
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from . import fg, bg, ef, rs, hsl

    bg.orange = Style(RgbBg(1, 2, 3))

    style_register = bg.as_namedtuple()

    assert style_register.orange == "\x1b[48;2;1;2;3m"



# Generated at 2022-06-12 09:57:09.997489
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r2 = r1.copy()
    assert r2 == r1 and r1 is not r2



# Generated at 2022-06-12 09:57:13.700375
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rgb import RgbFg

    fg = Register()
    fg.set_rgb_call(RgbFg)
    assert fg.rgb_call is not None

# Generated at 2022-06-12 09:57:15.689661
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r != None

# Unit tests for `set_eightbit_call` of class Register.

# Generated at 2022-06-12 09:57:24.309541
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        red = Style(rendertype.RgbFg(255, 0, 0))
        green = Style(rendertype.RgbFg(0, 255, 0))
        blue = Style(rendertype.RgbFg(0, 0, 255))
        yellow = Style(rendertype.RgbFg(255, 255, 0))
        pink = Style(rendertype.RgbFg(255, 192, 203))

    tr = TestRegister()

    assert tr("red") == "\x1b[38;2;255;0;0m"
    assert tr("green") == "\x1b[38;2;0;255;0m"
    assert tr("blue") == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-12 09:57:27.599909
# Unit test for method copy of class Register
def test_Register_copy():

    class A2(Register):
        pass

    a1 = A2()
    a2 = a1.copy()

    assert a1 != a2
    assert isinstance(a2, A2)

# Generated at 2022-06-12 09:57:37.338665
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
  class A(RenderType):
      ansi_seq = '\e[1;42;49m'

  class B(RenderType):
      ansi_seq = '\e[1;10;49m'

  def f1(a: A) -> str:
      return a.ansi_seq
  def f2(b: B) -> str:
      return b.ansi_seq

  reg = Register()
  reg.set_renderfunc(A, f1)
  reg.set_renderfunc(B, f2)

  a, b = A(1, 42, 49), B(1, 10, 49)
  assert reg.renderfuncs[A](a) == f1(a)
  assert reg.renderfuncs[B](b) == f2(b)

  # Override render func for A


# Generated at 2022-06-12 09:59:12.698309
# Unit test for constructor of class Register
def test_Register():
    fg: Register = Register()
    assert '\x1b[38;2;1;5;10m\x1b[1m' in str(fg.orange)
    assert '\x1b[38;2;1;5;10m\x1b[1m' in str(fg('orange'))
    assert '\x1b[38;2;201;205;210m\x1b[1m' in str(fg('grey'))
    assert '\x1b[38;2;1;5;10m\x1b[1m' in str(fg(1))
    assert fg.is_muted == False
    assert fg._eightbit_call == fg.eightbit_call
    assert fg._rgb_call == fg.rgb_call

    assert fg

# Generated at 2022-06-12 09:59:18.787334
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(1,5,10), Sgr(1))
    fg.green = Style(RgbFg(2,6,11))
    fg.blue = Style(RgbFg(3,7,12))

    assert fg.red == '\x1b[38;2;1;5;10m\x1b[1m'
    assert fg.green == '\x1b[38;2;2;6;11m\x1b[0m'
    assert fg.blue == '\x1b[38;2;3;7;12m\x1b[0m'


# Generated at 2022-06-12 09:59:28.659897
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import Sgr, RgbEf
    import json

    register = Register()
    register.foo = Style(Sgr(0, 1, 2))

    foo_dict = dict(
        foo='\x1b[0m\x1b[1m\x1b[2m',
        foo_rules=dict(
            rules=(
                dict(
                    type='sgr',
                    args=(0,1,2)
                ),
            ),
        )
    )

    assert register.as_dict() == foo_dict, "Register.as_dict() failed to return dictionary representation."

    # Test that dict is unpickleable
    pickleable_dict = dict(
        foo='\x1b[0m\x1b[1m\x1b[2m',
    )
    assert register

# Generated at 2022-06-12 09:59:32.360106
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    a = Register()
    b = Register()
    a.red = "red"
    b.green = "green"
    a.blue = "blue"
    b.yellow = "yellow"
    assert a.as_dict() == {"red": "red", "blue": "blue"}
    assert b.as_dict() == {"green": "green", "yellow": "yellow"}

# Generated at 2022-06-12 09:59:35.963219
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class TestRegister(Register):
        pass

    test_register = TestRegister()

    def f(x: int) -> str:
        return "This " + str(x)

    test_register.set_renderfunc(RenderType, f)

    test_register.test = Style(RenderType(10))

    assert test_register.test == "This 10"

# Generated at 2022-06-12 09:59:39.865639
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    #
    # Test overwrite of existing name.
    #
    class MyRegister(Register):
        test: Style

    assert not hasattr(MyRegister(), "test")

    #
    # Test overwrite of missing name.
    #
    class MyRegister(Register):
        test: Style

    assert not hasattr(MyRegister(), "test")



# Generated at 2022-06-12 09:59:43.268904
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register()
    reg.black = Style(RgbFg(0,0,0))
    reg.white = Style(RgbFg(255,255,255))
    assert reg.black != reg.white

