

# Generated at 2022-06-12 09:50:02.203085
# Unit test for method __call__ of class Register
def test_Register___call__():

    class FakeRenderType:
        def __init__(self, *args: int):
            self.args = args

    class FakeRenderfunc:
        def __call__(self, *args: int):
            return args

    fake_rendertype = FakeRenderType
    fake_renderfunc = FakeRenderfunc()

    reg = Register()
    reg.set_renderfunc(fake_rendertype, fake_renderfunc)
    reg.set_eightbit_call(fake_rendertype)
    reg.set_rgb_call(fake_rendertype)

    assert reg() == ""
    assert reg(42) == (42,)
    assert reg(42, 42, 42) == (42, 42, 42)

# Generated at 2022-06-12 09:50:03.446801
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert(reg.renderfuncs == {})

# Generated at 2022-06-12 09:50:06.094371
# Unit test for constructor of class Register
def test_Register():

    # Create new register-object.
    re = Register()

    # Attributes.
    assert isinstance(re, Register)

# Generated at 2022-06-12 09:50:07.578695
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert "" == r("red")



# Generated at 2022-06-12 09:50:10.607291
# Unit test for method __call__ of class Register
def test_Register___call__():
    register = Register()
    setattr(register, "red", "Something")
    assert register("red") == "Something"
    assert register(42) == ""
    assert register(1, 2, 3) == ""



# Generated at 2022-06-12 09:50:20.045871
# Unit test for method __call__ of class Register
def test_Register___call__():
 
    fg = Register()
    fg.set_eightbit_call(RenderType.RgbFg)
    fg.set_rgb_call(RenderType.RgbFg)

    fg.renderfuncs[RenderType.RgbFg] = lambda x: f"NON-8 bit {x}"
    fg.renderfuncs[RenderType.RgbBg] = lambda r, g, b: f"8 bit {r} {g} {b}"

    fg.red = Style(RenderType.RgbFg(5,5,5))
    fg.green = Style(RenderType.RgbFg(5,5,5))

    assert fg('red') == 'NON-8 bit 5 5 5'

# Generated at 2022-06-12 09:50:25.452167
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Bla(Register):
        pass

    bla = Bla()

    assert bla(1) == ""

    bla.blue = Style(SgrFg(4))
    bla.green = Style(SgrFg(2))

    assert bla("blue") == "\x1b[34m"
    assert bla("green") == "\x1b[32m"



# Generated at 2022-06-12 09:50:34.702381
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertypes import RgbFg, RgbBg, RgbEf, Sgr

    r = Register()

    # Test Eightbit-call with single argument
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert r(255) == r.red
    assert r(255) == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r(255, 42, 255) == "\x1b[48;2;255;42;255m"

    # Test RGB-call with three arguments
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))
    assert r(0, 0, 255) == r.blue

# Generated at 2022-06-12 09:50:43.119514
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import RgbFg

    fg = Register()

    # Check that a custom rendertype can be added.
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\n{r}, {g}, {b}\n")

    # Create a style for an attribute of register fg.
    fg.deep_red = Style(RgbFg(1, 0, 0))

    # Create an attribute that is an int.
    fg.nine = 9

    # Calling the attribute 'deep_red' should return the string with the rendered
    # RGB-code.
    assert str(fg.deep_red) == "\n1, 0, 0\n"

    # Calling the attribute 'nine' should return the integer.
    assert fg.nine == 9

    # Create a style for

# Generated at 2022-06-12 09:50:44.414128
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:51:00.599159
# Unit test for constructor of class Register
def test_Register():
    """
    the following tests are based on the following color register:

        @fg.red
        def render_bold_underlined(self):
            return self.render(Sgr(1, 4))

        @fg.red
        def render_bold(self):
            return self.render(Sgr(1))

        @fg.red
        def render_underlined(self):
            return self.render(Sgr(4))

        @fg.red
        def render(self):
            return self.render(self)
    
        @bg.red
        @fg.white
        def render(self, text: str) -> str:
            return "This is a test: " + text

    """
    from .rendertype import Sgr, Eightbit, RgbFg
    from .sty import fg, bg


# Generated at 2022-06-12 09:51:02.029225
# Unit test for constructor of class Register
def test_Register():

    register = Register()
    assert register is not None


# Generated at 2022-06-12 09:51:10.686091
# Unit test for constructor of class Register
def test_Register():

    from .rendertypes import Sgr

    # we want to test the basic behaviour of the register class. Therefore
    # we create a test-class. It contains all the logic we want to test.
    class R(Register):
        def __init__(self):
            super().__init__()

            # we add a renderfunc to our testclass.
            self.set_renderfunc(Sgr, lambda *args: "".join([str(arg) for arg in args]))

            # we add a style to our testclass.
            setattr(self, "test", self.Style(Sgr(1)))

    # we create an instance of our testclass
    r = R()

    # we check if the renderfunc as expected
    assert r.renderfuncs[Sgr]("1", "4", "3") == "143"

    # we

# Generated at 2022-06-12 09:51:11.630547
# Unit test for constructor of class Register
def test_Register():
    assert Register()



# Generated at 2022-06-12 09:51:13.072405
# Unit test for constructor of class Register
def test_Register():
    temp = Register()
    assert isinstance(temp, Register)

# Generated at 2022-06-12 09:51:14.203287
# Unit test for constructor of class Register
def test_Register():

    instance = Register()

    assert isinstance(instance, Register)

# Generated at 2022-06-12 09:51:15.473186
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)

# Generated at 2022-06-12 09:51:19.043453
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert not r.is_muted
    assert "eightbit_call" not in r.__dict__.keys()
    assert "rgb_call" not in r.__dict__.keys()
    assert "256_call" not in r.__dict__.keys()

# Generated at 2022-06-12 09:51:22.161921
# Unit test for constructor of class Register
def test_Register():

    # Create a new register object. Default attrs are muted.
    r = Register()
    assert r.is_muted is True
    assert hasattr(r, "mute")
    assert hasattr(r, "unmute")



# Generated at 2022-06-12 09:51:24.683806
# Unit test for constructor of class Register
def test_Register():
    """
    Tests the constructor of the Register class.
    """
    reg = Register()
    assert isinstance(reg, Register)



# Generated at 2022-06-12 09:51:42.173984
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.a = Style("a")
    r2 = r1.copy()
    assert r1 is not r2
    assert r1.a == r2.a
    assert r1.a is not r2.a

# Generated at 2022-06-12 09:51:44.764840
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(RgbFg(1,2,3))
    assert(s == '\x1b[38;2;1;2;3m')


# Generated at 2022-06-12 09:51:50.880244
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class MyRegister(Register):
        pass

    r = MyRegister()
    r.blue = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    nt = r.as_namedtuple()

    assert nt.blue == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-12 09:52:01.152499
# Unit test for method copy of class Register
def test_Register_copy():

    from sty import fg, bg, ef, rs

    def reset():
        fg.delete(fg.red)
        bg.delete(bg.green)
        ef.delete(ef.bold)
        rs.delete(rs.reset)

    def verify(fn, attr, val):
        with fn():
            assert getattr(fn, attr) == val

    fg.red = Style(fg.red, ef.bold)
    bg.green = Style(bg.green, ef.bold)
    ef.bold = Style(ef.bold)
    rs.reset = Style(rs.reset)

    verify(fg, "red", "\u001b[38;2;255;0;0m\u001b[1m")

# Generated at 2022-06-12 09:52:10.149292
# Unit test for method mute of class Register
def test_Register_mute():

    class FrobRenderType(RenderType):
        pass

    class FrobRenderType2(RenderType):
        pass

    def frob_renderfunc(func, *args, **kwargs):
        return f"{func.__name__}({', '.join(args)})"

    class R1(Register):

        def __init__(self):

            super().__init__()

            self.foo = Style(
                FrobRenderType("bar", "baz"), FrobRenderType2("lorem", "ipsum")
            )
            self.bar = Style(FrobRenderType2("lorem", "ipsum"))
            self.baz = Style(FrobRenderType2("lorem", "ipsum"))

    r1 = R1()

# Generated at 2022-06-12 09:52:20.951965
# Unit test for method mute of class Register
def test_Register_mute():
    # Use Register class to create a new register-object
    R = Register()
    R.set_eightbit_call(RgbFg)
    R.set_rgb_call(RgbFg)

    # Add a style to R
    R.black = Style(RgbFg(0, 0, 0))

    # Assert that R.black is set properly.
    print(R.black)
    assert R.black == '\x1b[38;2;0;0;0m'

    # Set R.black to another value
    R.black = Style(RgbFg(42, 42, 42))
    assert R.black == '\x1b[38;2;42;42;42m'

    # Mute R
    R.mute()

    # Assert that R.black is empty

# Generated at 2022-06-12 09:52:30.846854
# Unit test for method copy of class Register
def test_Register_copy():

    from sty import fg  # noqa

    x: Register = fg.copy()

    assert x.__class__ is fg.__class__
    assert x.rgb_call is fg.rgb_call
    assert x.eightbit_call is not fg.eightbit_call
    assert x.eightbit_call(144) == fg.eightbit_call(144)

    y = x.copy()

    assert y.__class__ is fg.__class__
    assert y.rgb_call is fg.rgb_call
    assert y.eightbit_call is not fg.eightbit_call
    assert y.eightbit_call(144) == fg.eightbit_call(144)

# Generated at 2022-06-12 09:52:38.694534
# Unit test for method unmute of class Register
def test_Register_unmute():
    # pylint: disable=unused-argument
    def render_eightbit(color_idx: int, *_args, **_kwargs):
        if color_idx == 0:
            return "\x1b[0m"
        return "\x1b[38;5;{}m".format(color_idx)

    def render_rgb(r: int, g: int, b: int, *_args, **_kwargs):
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    # Initialize a new register
    my_register = Register()

    # Set renderfuncs for the new register
    my_register.set_renderfunc(Eightbit, render_eightbit)

# Generated at 2022-06-12 09:52:45.269344
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda *args: f"{args[0]};{args[1]};{args[2]}")
    r.set_rgb_call(RgbFg)

    r.blabla = Style(RgbFg(5, 6, 7))
    assert str(r.blabla) == "5;6;7"

    r.mute()
    assert str(r.blabla) == ""

    r.unmute()
    assert str(r.blabla) == "5;6;7"



# Generated at 2022-06-12 09:52:47.509892
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()

    r.red = Style(RgbFg(1, 2, 3))

    assert r("red") == "\x1b[38;2;1;2;3m"

# Generated at 2022-06-12 09:53:09.211458
# Unit test for method copy of class Register
def test_Register_copy():
    from . import fg, bg

    register1 = fg.copy()

    register1.set_eightbit_call(fg.RgbFg)

    assert register1.eightbit_call != fg.eightbit_call
    assert register1.rgb_call == fg.rgb_call
    assert register1.renderfuncs != fg.renderfuncs
    assert register1.is_muted == fg.is_muted

    register2 = bg.copy()

    register2.mute()

    assert register2.eightbit_call == bg.eightbit_call
    assert register2.rgb_call == bg.rgb_call
    assert register2.renderfuncs == bg.renderfuncs
    assert register2.is_muted is True

# Generated at 2022-06-12 09:53:11.675060
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert hasattr(r, "eightbit_call")
    assert hasattr(r, "rgb_call")



# Generated at 2022-06-12 09:53:19.034444
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        """
        Test class for method __call__ of class Register.
        """

        # Define some styles
        red = Style(Fg(1))
        green = Style(Fg(2))
        blue = Style(Fg(4))


    # Create test register
    r = TestRegister()

    # Set render-functions
    r.set_renderfunc(Fg, lambda x: f"\x1b[38;5;{x:d}m")
    r.set_eightbit_call(Fg)

    # Test for direct call
    assert r(1) == "\x1b[38;5;1m"
    assert r(2) == "\x1b[38;5;2m"

# Generated at 2022-06-12 09:53:20.409923
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-12 09:53:31.510506
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .ansi import Sgr
    from .rgb import RgbFg
    from .eightbit import EightbitFg

    # Make style of class Style.
    style_test = Style(Sgr(1), RgbFg(1, 5, 10), EightbitFg(127), value="")

    assert isinstance(style_test, Style)
    assert isinstance(style_test, str)

    assert style_test == Style(Sgr(1), RgbFg(1, 5, 10), EightbitFg(127), value="")

    # Make style of class Register
    fg = Register()

# Generated at 2022-06-12 09:53:34.725475
# Unit test for method __new__ of class Style
def test_Style___new__():
    class Test:
        pass

    test = Style(Test(1))
    assert isinstance(test, Style)
    assert isinstance(test, str)


# Generated at 2022-06-12 09:53:39.345669
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class DummyRenderType(RenderType):
        """
        Dummy render type for unit testing
        """

    dummy_register = Register()
    dummy_register.set_renderfunc(DummyRenderType, lambda x: f"{x}+")
    dummy_register.dummy = Style(DummyRenderType(10))

    assert str(dummy_register.dummy) == "10+"



# Generated at 2022-06-12 09:53:48.347435
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, Sgr
    from .sty import Sty
    from .util import ansi

    reg = Register()
    reg.set_rgb_call(RgbBg)
    reg.rgb_call = lambda r, g, b: f"{r}/{g}/{b}"

    sty = Sty()
    sty.register(reg)
    sty.theme = lambda self: self.black(RGB=True)

    res = styled(sty, "hello")
    assert(res.startswith(f"{ansi(0)}/{ansi(0)}/{ansi(0)}"))

# Generated at 2022-06-12 09:53:56.822145
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

        def __repr__(self):
            return str(self)

        def __str__(self):
            return "rgb_fg"

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return "rgb_fg_func"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb_fg)
    reg.set_rgb_call(RgbFg)

    assert reg(42, 255, 42) == "rgb_fg_func"

# Generated at 2022-06-12 09:54:07.333369
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    CustomRegister = type("CustomRegister", (Register,), {})

    class Eightbit(RenderType):
        pass

    class Rgb(RenderType):
        pass

    custom_register = CustomRegister()
    custom_register.set_renderfunc(Eightbit, lambda x: f"eightbit({x})")
    custom_register.set_renderfunc(Rgb, lambda r, g, b: f"rgb({r}, {g}, {b})")
    custom_register.set_eightbit_call(Eightbit)

    assert custom_register.eightbit_call(42) == "eightbit(42)"
    assert custom_register.eightbit_call(233) == "eightbit(233)"

    custom_register.set_eightbit_call(Rgb)

# Generated at 2022-06-12 09:54:29.682280
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define a new rendertype
    class RgbFgE(RenderType):
        def render(self, r: int, g: int, b: int) -> str:
            return f"\x1b[38;2;{r};{g};{b}m"

    # Declare 8bit function for new rendertype
    def _color_to_rgb(num: int, *args, **kwargs):
        return RgbFgE(int(num / 36.22), int(num / 85.59), int(num / 43.59))

    def _rgb_to_color(r: int, g: int, b: int, *args, **kwargs) -> str:
        return str(_color_to_rgb(r, g, b))

    # Create a register.
    reg = Register()



# Generated at 2022-06-12 09:54:36.245273
# Unit test for constructor of class Style
def test_Style():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert fg.renderfuncs[RgbFg] == RgbFg.render
    assert fg.renderfuncs[Sgr] == Sgr.render
    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert fg.red.rules == (RgbFg(255, 0, 0), Sgr(1))



# Generated at 2022-06-12 09:54:46.557742
# Unit test for method __new__ of class Style
def test_Style___new__():
    class C:
        def __init__(self, *args):
            self.args = args

    class D:
        def __init__(self, *args):
            self.args = args

    class E:
        def __init__(self, *args):
            self.args = args

    class F:
        pass

    rule1 = C(1,2)
    rule2 = D(3,4,5)
    rule3 = E(42)
    style1 = Style(rule1, rule2, rule3)
    style2 = Style(style1, rule3)

    assert style1.rules == (rule1, rule2, rule3)
    assert style2.rules == (rule1, rule2, rule3, rule3)

# Generated at 2022-06-12 09:54:49.855155
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .fg import fg

    # Get a dict with all attribute names and their corresponding ANSI-sequences.
    d = fg.as_dict()

    # Check if all attributes have been exported correctly.
    assert len(d) == len(dir(fg)) - 2

    # d should not have the attribute 'rules', nor 'default'
    assert "rules" not in d.keys()
    assert "default" not in d.keys()



# Generated at 2022-06-12 09:54:57.145179
# Unit test for method mute of class Register
def test_Register_mute():

    # set up class
    class Foo(RenderType):

        args = 0

    class R(Register):

        @property
        def a(self):
            return Style(Foo(), RgbBg(1, 2, 3), RgbFg(42, 42, 42))

        @property
        def b(self):
            return self.a

    r = R()

    # create register
    r.set_renderfunc(Foo, lambda: "foo")

    # test if attribute a has been set correctly
    assert r.a == "\x1b[48;2;1;2;3m\x1b[38;2;42;42;42mfoo"

    r.mute()

    # test if attribute a has been muted correctly
    assert r.a == ""

    # check if unmuteing works
    r

# Generated at 2022-06-12 09:55:06.672882
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sgr import Sgr
    from .rgb import RgbFg, RgbBg

    r = Register()
    r.red = Style(Sgr(1))
    r.blue = Style(RgbBg(0,0,255))

    assert r.red == "\x1b[1m"
    assert r.blue == "\x1b[48;2;0;0;255m"

    nt = r.as_namedtuple()
    assert nt.red == "\x1b[1m"
    assert nt.blue == "\x1b[48;2;0;0;255m"

    return

if __name__ == "__main__":
    test_Register_as_namedtuple()

# Generated at 2022-06-12 09:55:09.732662
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg

    assert len(fg.as_dict().keys()) > 0

    assert fg.red == fg.as_dict()["red"]


# Generated at 2022-06-12 09:55:20.706842
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    def renderfunc1(code: int) -> str:
        return "RenderFunc1: " + str(code)

    def renderfunc2(r: int, g: int, b: int) -> str:
        return "RenderFunc2: " + str((r, g, b))

    class RenderClass1(RenderType):
        pass

    class RenderClass2(RenderType):
        pass

    class RenderClass3(RenderType):
        pass

    reg = Register()

    reg.set_renderfunc(RenderClass1, renderfunc1)
    reg.set_renderfunc(RenderClass2, renderfunc2)

    reg.attr1 = Style(RenderClass1(42))
    assert str(reg.attr1) == renderfunc1(42)
    assert reg.attr1.rules == (RenderClass1(42),)



# Generated at 2022-06-12 09:55:28.879494
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    '''
    Tests set_eightbit_call method in class Register

    '''
    from .rendertype import RgbFg
    from .rendertype import Sgr

    renderfunc_dict: Dict[Type[RenderType], Callable] = {
        RgbFg: lambda R, g, b: f"\x1b[38;2;{R};{g};{b}m",
        Sgr: lambda *args: f"\x1b[{';'.join(str(num) for num in args)}m"
    }

    test_register = Register()
    test_register.set_renderfunc(RgbFg, renderfunc_dict[RgbFg])
    test_register.set_renderfunc(Sgr, renderfunc_dict[Sgr])

# Generated at 2022-06-12 09:55:36.473489
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    new_register = Register()
    new_register.red = "red"
    new_register.green = "green"
    new_register.blue = "blue"
    new_register.black = "black"

    nt = new_register.as_namedtuple()
    assert nt.__name__ == "StyleRegister"
    assert nt.red == "red"
    assert nt.green == "green"
    assert nt.blue == "blue"
    assert nt.black == "black"

# Generated at 2022-06-12 09:55:58.942858
# Unit test for constructor of class Register
def test_Register():
    assert Register()


# Generated at 2022-06-12 09:56:07.346890
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .sgr import Sgr
    from .rgb import RgbFg, RgbBg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.set_rgb_call(RgbFg)
    r.set_eightbit_call(Sgr)

    r.set_renderfunc(RgbFg, lambda r, g, b: f"RGB({r},{g},{b})")
    r.set_renderfunc(Sgr, lambda sgr: f"SGR({sgr})")

    r.red = Style(RgbFg(1, 0, 0), RgbBg(1, 1, 1))
    r.green = Style(RgbFg(0, 1, 0), Sgr(1))

# Generated at 2022-06-12 09:56:11.400559
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from collections import namedtuple
    from .register import fg
    assert isinstance(fg.as_namedtuple(), namedtuple)
    assert fg.as_namedtuple().red == '\x1b[38;2;1;0;0m'
    assert fg.as_namedtuple().white == '\x1b[38;2;1;1;1m'

# Generated at 2022-06-12 09:56:15.054117
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Unit test for method as_namedtuple of class Register.
    """
    rm = Register()
    rm.set_eightbit_call(lambda x: f"\x1b[38;5;{x}m")
    rm.red = Style(RgbFg(255, 0, 0))
    rm.blue = Style(RgbBg(0, 0, 255))

    nt = rm.as_namedtuple()
    assert type(nt) is namedtuple

    assert nt.red == rm.red
    assert nt.blue == rm.blue

# Generated at 2022-06-12 09:56:23.585753
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.r, self.g, self.b = r, g, b
            self.args = (r, g, b)

    def rgb_render_func(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    r: Register = Register()
    r.set_renderfunc(RgbFg, rgb_render_func)

    r.set_rgb_call(RgbFg)

    assert r(255, 255, 255) == "\x1b[38;2;255;255;255m"



# Generated at 2022-06-12 09:56:27.309766
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertypes import RgbFg, Sgr

    fg_orange = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(fg_orange, Style)
    assert isinstance(fg_orange, str)
    assert str(fg_orange) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-12 09:56:34.126701
# Unit test for constructor of class Register
def test_Register():
    # Basic construction of a register-object
    reg1 = Register()

    # Construction with some predefined styles
    reg2 = Register([("dark_gray", Style("\x1b[38;2;77;77;77m"))])

    # Construction fails with invalid argumetns
    try:
        reg3 = Register("invalid-type", ["invalid-type"])
    except ValueError:
        pass
    else:
        raise AssertionError("Register() did not fail with invalid arguments.")



# Generated at 2022-06-12 09:56:41.743006
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0))
    reg.green = Style(RgbFg(0, 255, 0))
    reg.blue = Style(RgbFg(0, 0, 255))

    copy = reg.copy()

    assert copy is not reg

    assert copy.red is not reg.red
    assert copy.red == reg.red

    assert copy.green is not reg.green
    assert copy.green == reg.green

    assert copy.blue is not reg.blue
    assert copy.blue == reg.blue

    copy.red = Style(RgbFg(0, 0, 255))

    assert copy.red != reg.red

# Generated at 2022-06-12 09:56:49.642786
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class MyRegister(Register):
        pass

    # Create new RenderType
    class EightBitTest(RenderType):
        escape = "\x1b[48;5;{}m"

    # Create new register object.
    reg = MyRegister()

    # Set render function for newly created RenderType.
    reg.set_renderfunc(EightBitTest, EightBitTest.render)

    # Set the new RenderType for eightbit-calls.
    reg.set_eightbit_call(EightBitTest)

    # Check if EightBit-call with new RenderType was successful.
    assert reg(42) == "\x1b[48;5;42m"

# Generated at 2022-06-12 09:56:59.565071
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg, bg, ef, rs, rf

# Generated at 2022-06-12 09:57:21.240002
# Unit test for constructor of class Register
def test_Register():
    class MyRegister(Register):
        pass

    foo = MyRegister()
    foo.set_eightbit_call(RenderType.SGR)
    foo.set_rgb_call(RenderType.SGR)
    return True

# Generated at 2022-06-12 09:57:31.964273
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test the implementation of the __setattr__ method.
    """
    from .rendertype import RgbFg

    r = Register()
    r.test = Style(RgbFg(5, 5, 5), value="")

    assert isinstance(r.test, Style)
    assert r.test == ""
    assert r.test.rules == (RgbFg(5, 5, 5),)

    # Two render types
    r.test = Style(RgbFg(5, 5, 5), RgbFg(5, 5, 5), value="")

    assert r.test.rules == (RgbFg(5, 5, 5), RgbFg(5, 5, 5))

    # Nested styles

# Generated at 2022-06-12 09:57:33.795063
# Unit test for constructor of class Register
def test_Register():

    r = Register()
    assert isinstance(r, Register)
    assert r.is_muted == False


# Generated at 2022-06-12 09:57:39.921946
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Dummy(RenderType):
        pass

    r1 = Register()
    r1.set_renderfunc(Dummy, lambda r: "dummy_rule(%s)" % str(r))

    r1.dummy_rule = Style(Dummy("test"))
    assert isinstance(r1.dummy_rule, Style)
    assert r1.dummy_rule == "dummy_rule(test)"

    r1.dummy_rule = Style(Dummy("test2"))
    assert r1.dummy_rule == "dummy_rule(test2)"


# Generated at 2022-06-12 09:57:46.032460
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # saves the expected result

    # fg.red = Style(RgbFg(255, 0, 0))
    # bg.green = Style(RgbBg(0, 255, 0))

    fg_red_as_dict_expected = dict({"red": "\x1b[38;2;255;0;0m"})
    bg_green_as_dict_expected = dict({"green": "\x1b[48;2;0;255;0m"})

    from .themes import default

    fg_red_as_dict = default.fg.as_dict()
    bg_green_as_dict = default.bg.as_dict()

    assert fg_red_as_dict == fg_red_as_dict_expected

    assert bg_green_as_dict == b

# Generated at 2022-06-12 09:57:51.337196
# Unit test for constructor of class Style
def test_Style():

    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)

    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)

    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == '\x1b[38;2;1;5;10m\x1b[1m'



# Generated at 2022-06-12 09:57:59.270172
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Check if method as_namedtuple works as expected.
    """
    my_reg = Register()
    my_reg.red = "red"
    my_reg.green = "green"
    my_reg.blue = "blue"

    my_named_tup = my_reg.as_namedtuple()

    assert hasattr(my_named_tup, "red")
    assert hasattr(my_named_tup, "green")
    assert hasattr(my_named_tup, "blue")

    assert my_named_tup.red == "red"
    assert my_named_tup.green == "green"
    assert my_named_tup.blue == "blue"


# Generated at 2022-06-12 09:58:08.300315
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbTest(RenderType):
        pass

    class SgrTest(RenderType):
        pass

    # Setup
    register = Register()
    register.set_renderfunc(RgbTest, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    register.set_renderfunc(SgrTest, lambda *args: f"\x1b[{';'.join(map(str, args))}m")

    # Test attr setting without mutedness check
    register.red = Style(RgbTest(255, 0, 0), SgrTest(1))
    assert str(register.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-12 09:58:18.060742
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .sixbit import SixBit
    from .sgr import Sgr
    from .rgb import Rgb

    from .rendertype import RenderType

    # Create test register with two rendertype: Rgb and SixBit.
    r1 = Register()
    r1.set_renderfunc(Rgb, lambda *args: f"Rgb {args}")
    r1.set_renderfunc(SixBit, lambda *args: f"SixBit {args}")

    r1.red = Style(Rgb(255, 0, 0), Sgr("bold"))

    # By default rgb-calls are handled by rendertype Rgb.
    assert str(r1.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    # Use set_rgb_call to override default renderer.

# Generated at 2022-06-12 09:58:24.034845
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Rgb, RgbBg

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(Rgb(10, 5, 0))
            self.blue = Style(RgbBg(0, 0, 255))

    register: Register = TestRegister()
    assert isinstance(register.red, Style)
    assert isinstance(register.red, str)

    register.mute()
    assert isinstance(register.red, Style)
    assert isinstance(register.red, str)
    assert len(str(register.red)) == 0

    register.unmute()
    assert isinstance(register.red, Style)
    assert isinstance(register.red, str)
    assert len(str(register.red)) > 0



# Generated at 2022-06-12 09:59:16.454906
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Unit test for method as_dict of class Register.

    Test:
        - Test that the as_dict method gives a dictionary with values as strings.
        - Test that the as_dict method omits private attributes.
    """
    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self._hidden_attr = Style(RgbFg(0, 0, 0))

    my_register = TestRegister()
    reg_as_dict = my_register.as_dict()

    assert isinstance(reg_as_dict, dict)
    for k, v in reg_as_dict.items():
        assert isinstance(v, str)
    assert "red" in reg_as_dict

# Generated at 2022-06-12 09:59:27.392802
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    # Setup register object and add render functions
    rg = Register()

    def f1(*args):
        return "a=" + ",".join(map(str, args))

    def f2(*args):
        return "b=" + ",".join(map(str, args))

    def f3(*args):
        return "c=" + ",".join(map(str, args))

    rg.set_renderfunc(RgbBg, f1)
    rg.set_renderfunc(RgbFg, f2)
    rg.set_renderfunc(Sgr, f3)

    # Define style rules with different renderfuncs
    rg.w

# Generated at 2022-06-12 09:59:32.126103
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .register import Register
    from .rendertype import RgbFg

    my_reg = Register()
    my_reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    my_reg.red = Style(RgbFg(0, 0, 255))

    my_reg.red # '\x1b[38;2;0;0;255m'

    my_reg.as_namedtuple().red == my_reg.red # True

# Generated at 2022-06-12 09:59:39.981687
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import Sgr, Rgb24

    # Create register and add a renderfunc for Rgb24.
    reg = Register()
    reg.set_renderfunc(Rgb24, lambda r, g, b: f"{r},{g},{b}")

    reg.set_rgb_call(Rgb24)

    reg.blue = Style(Rgb24(0, 0, 255))
    reg.red = Style(Rgb24(255, 0, 0))

    # Make a call to the register.
    assert reg(255, 0, 0) == "255,0,0"

    # Assert
    assert str(reg.blue) == "0,0,255"
    assert str(reg.red) == "255,0,0"
