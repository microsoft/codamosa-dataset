

# Generated at 2022-06-12 09:49:50.351109
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:49:51.110169
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r


# Generated at 2022-06-12 09:49:52.811859
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)
    assert not isinstance(r, str)
    assert not isinstance(r, int)

# Generated at 2022-06-12 09:49:55.212896
# Unit test for constructor of class Register
def test_Register():
    r = Register()

    assert r.renderfuncs == {}
    assert r.is_muted == False


# Generated at 2022-06-12 09:50:04.858027
# Unit test for method __call__ of class Register
def test_Register___call__():

    r: Register = Register()

    def render_eightbit(x):
        return "eightbit-call"

    def render_rgb(r, g, b):
        return "rgb-call"

    r.renderfuncs[RenderType] = render_eightbit

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(42) == "eightbit-call"
    assert r(12, 42, 99) == "rgb-call"
    assert r("red") == ""

    r.mute()

    assert r(12, 42, 99) == ""
    assert r(42) == ""
    assert r("red") == ""

    r.unmute()

    assert r(12, 42, 99) == "rgb-call"


# Generated at 2022-06-12 09:50:07.531689
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    reg.lol = Style(123)
    assert reg.lol == "\x1b[123m"

# Generated at 2022-06-12 09:50:11.334966
# Unit test for constructor of class Register
def test_Register():
    # Create register
    reg = Register()

    # Check if the register has the right attrs.
    assert hasattr(reg, "eightbit_call")
    assert hasattr(reg, "rgb_call")
    assert hasattr(reg, "renderfuncs")

# Generated at 2022-06-12 09:50:20.461464
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, RgbBg, RenderType

    class RegisterMock(Register):
        pass

    class RenderTypeMock(RenderType):
        """
        Has to be a subclass of RenderType or the unittest will fail.
        """
        pass

    # Create a new register called 'register'.
    register = RegisterMock()

    # Add renderfunc for the rendertype 'Eightbit' to the register.
    renderfunc1: Callable[[int], str] = lambda x: x
    register.set_renderfunc(Eightbit, renderfunc1)

    # Add renderfunc for the rendertype 'RgbFg' to the register.
    renderfunc2: Callable[[int, int, int], str] = lambda a, b, c: a + b + c
    register.set_render

# Generated at 2022-06-12 09:50:25.167308
# Unit test for constructor of class Register
def test_Register():
    """
    Check if constructor of Register class works as expected.
    """
    # Create new empty register
    reg = Register()

    assert len(reg.renderfuncs) == 0

    assert reg.is_muted == False


# Generated at 2022-06-12 09:50:31.365336
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(1) == "\x1b[38;5;1m"
    assert r(255) == "\x1b[38;5;255m"
    assert r(1, 2, 3) == "\x1b[38;2;1;2;3m"



# Generated at 2022-06-12 09:50:43.447830
# Unit test for method __call__ of class Register
def test_Register___call__():
    fg = Register()
    Sty = Style(RgbFg(1, 2, 3))
    fg.blue = Sty

    assert fg(42) == ""
    # assert fg(42) == '\x1b[38;5;42m'

    fg.set_eightbit_call(EightBitFg)
    assert fg(42) == "\x1b[38;5;42m\x1b[0m"
    assert fg("blue") == "\x1b[38;2;1;2;3m\x1b[0m"

    fg.set_rgb_call(RgbFg)
    assert fg(42, 43, 44) == "\x1b[38;2;42;43;44m\x1b[0m"


# Generated at 2022-06-12 09:50:48.937369
# Unit test for constructor of class Register
def test_Register():
    reg1 = Register()
    reg2 = Register()
    reg1.foo = Style(RgbFg(125, 255, 200))
    reg2.foo = Style(RgbFg(125, 255, 200))
    reg1.set_renderfunc(RgbFg, lambda r, g, b: "")
    assert reg1.foo == ""
    assert reg2.foo != ""

# Generated at 2022-06-12 09:50:58.568508
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertypes import Fg, Bg

    renderfuncs: Renderfuncs = {Fg: lambda x: f"\x1b[38;5;{x}m", Bg: lambda x: f"\x1b[48;5;{x}m"}

    r1 = Register()
    r1.set_renderfunc(Fg, renderfuncs[Fg])
    r1.set_eightbit_call(Fg)
    r1.set_rgb_call(Bg)

    assert r1.__call__(144) == f"\x1b[38;5;144m"
    assert r1.__call__(10, 42, 255) == f"\x1b[48;2;10;42;255m"

# Generated at 2022-06-12 09:51:04.634900
# Unit test for method __call__ of class Register
def test_Register___call__():
    class MyRegister(Register):
        pass

    r = MyRegister()
    r.set_eightbit_call(str)
    r.set_rgb_call(str)
    r.a = Style(str(10))

    assert r(10) == "10"
    assert r(20, 30, 40) == "(20, 30, 40)"
    assert r.a == "10"
    assert r("a") == "10"

# Generated at 2022-06-12 09:51:12.690087
# Unit test for method __call__ of class Register
def test_Register___call__():

    class CustomRegister(Register):
        """
        This is a dummy register object that can be used for testing purposes.
        """

        def __init__(self):
            super().__init__()
            self.set_eightbit_call(lambda x: "42")
            self.set_rgb_call(lambda x, y, z: "66")

    cr = CustomRegister()

    assert cr(42) == "42"
    assert cr(144) == "42"
    assert cr(102, 49, 42) == "66"
    assert cr(10, 200, 255) == "66"



# Generated at 2022-06-12 09:51:13.932752
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-12 09:51:15.133623
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register) is True



# Generated at 2022-06-12 09:51:24.634943
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import EightBit, RgbFg, Sgr

    def render_8bit(val: int) -> str:
        return f'\033[38;5;{val}m'

    def render_rgb(r: int, g: int, b: int) -> str:
        return f'\033[38;2;{r};{g};{b}m'

    reg = Register()

    reg.yellow = Style(EightBit(220))
    reg.orange = Style(RgbFg(120, 100, 210))
    reg.bold = Style(Sgr(1))

    reg.set_eightbit_call(EightBit)
    reg.set_rgb_call(RgbFg)

    result_1 = reg(220)

    assert result_1 == reg.yellow

    result_

# Generated at 2022-06-12 09:51:35.397834
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import RenderType, Sgr, RgbEf, RgbFg, RgbBg
    import types
    import sys

    # Constructor
    r = Register()
    assert isinstance(r, Register)

    # Constructor - with renderfuncs
    f1 = lambda *x: "1"
    f2 = lambda *x: "2"
    r = Register(renderfuncs={RenderType: f1, RgbFg:f2})
    assert isinstance(r, Register)

    # Attribute test
    assert r.renderfuncs == {RenderType: f1, RgbFg: f2}

    # set_eightbit_call & eightbit-call
    r.set_eightbit_call(RgbFg)
    assert r(42) == "2"

    # set_

# Generated at 2022-06-12 09:51:44.481583
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbBg, RgbFg

    class MyRegister(Register):

        def __init__(self):
            super().__init__()
            self.red = Style(RgbBg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))

    r = MyRegister()
    assert r.red == "\x1b[48;2;255;0;0m"
    assert r.green == "\x1b[38;2;0;255;0m"

    assert r(0) == ""

    assert r("red") == r.red
    assert r("green") == r.green

    assert r(0, 255, 0) == r.green

# Generated at 2022-06-12 09:52:06.052679
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, SgrFg

    r: Register = Register()
    r.set_renderfunc(SgrFg, lambda x: f"sgr{x}")
    r.set_renderfunc(RgbFg, lambda x, y, z: f"rgb{x}{y}{z}")

    r.set_eightbit_call(RgbFg)
    assert str(r(140)) == "rgb140NoneNone"

    r.set_eightbit_call(SgrFg)
    assert str(r(141)) == "sgr141"



# Generated at 2022-06-12 09:52:12.358889
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import BgRgb, FgRgb

    reg = Register()
    reg.set_renderfunc(FgRgb, lambda r, g, b: F"\x1b[38;2;{r};{g};{b}m")

    reg.set_rgb_call(FgRgb)

    assert(reg(1, 5, 10) == "\x1b[38;2;1;5;10m")
    assert(reg(10, 20, 30) == "\x1b[38;2;10;20;30m")

    reg.set_renderfunc(BgRgb, lambda r, g, b: F"\x1b[48;2;{r};{g};{b}m")

    reg.set_rgb_call(BgRgb)

   

# Generated at 2022-06-12 09:52:22.385016
# Unit test for method mute of class Register
def test_Register_mute():

    from .fg import Fg
    from .bg import Bg
    from .ef import Ef
    from .rs import Rs

    from .rendertype import Sgr, RgbFg, RgbBg

    # Define some color attributes for four register objects.
    fg: Fg = Fg()
    bg: Bg = Bg()
    ef: Ef = Ef()
    rs: Rs = Rs()

    # Define some style rules for the color attributes
    ef.red = Style(Sgr(1))
    fg.red = Style(Sgr(1))
    bg.red = Style(Sgr(1))
    rs.red = Style(Sgr(1))

    # Verify that the style rules are rendered properly
    print(fg.red)
    print(bg.red)
   

# Generated at 2022-06-12 09:52:27.318230
# Unit test for constructor of class Style
def test_Style():
    """
    Check that instance of Style(name,value) has the same behavior as str(name,value).

    Also make sure that the string value is stored correctly in the object.
    """
    a = Style(value='hello', rules=['world'])
    b = str('hello', 'world')

    assert str(a) == str(b)
    assert a == b



# Generated at 2022-06-12 09:52:34.273272
# Unit test for method mute of class Register
def test_Register_mute():
    from sty import ef, fg
    assert ef.bold.startswith('\x1b[')
    ef.mute()
    assert ef.bold == ''
    ef.unmute()
    assert ef.bold.startswith('\x1b[')
    fg.mute()
    assert fg.blue == ''
    fg.unmute()
    assert fg.blue.startswith('\x1b[')


# Generated at 2022-06-12 09:52:43.777531
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Unit test for method __setattr__ of class Register
    """

    from .sty import RgbBg, RgbFg, Sgr

    fg: Register = Register()
    fg.renderfuncs[RgbFg] = lambda r, g, b: f"{r}{g}{b}"
    fg.renderfuncs[Sgr] = lambda x: f"s{x}"

    # When creating a new style-object, render the style
    fg.red = Style(RgbFg(255, 0, 0))
    assert fg.red == "255000"

    # When creating a new style-object that consists of a Style-object and
    # a rendertype-object, render the style
    fg.black = Style(fg.red, Sgr(2))
    assert fg.black

# Generated at 2022-06-12 09:52:51.808945
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    r = Register()
    names = [s.name for s in list(r.renderfuncs.keys())]
    assert "RgbFg" not in names

    r.set_rgb_call(RgbFg)
    names = [s.name for s in list(r.renderfuncs.keys())]
    assert "RgbFg" in names

    assert r(42) == ""
    assert r("blue") == ""

    r.blue = Style(RgbFg(0,0,255))
    assert r("blue") != ""

    r.mute()
    assert r("blue") == ""

    r.unmute()
    assert r("blue") != ""

    assert r.as_dict() != {}

# Generated at 2022-06-12 09:52:53.814575
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register
    assert register.__class__.__name__ == "Register"


# Generated at 2022-06-12 09:53:00.361746
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    style = Register()

    style.black = Style(RgbFg(0, 0, 0))
    style.white = Style(RgbFg(255, 255, 255))
    style.grey = Style(RgbFg(128, 128, 128))

    style.red = Style(RgbFg(255, 0, 0))
    style.green = Style(RgbFg(0, 255, 0))
    style.blue = Style(RgbFg(0, 0, 255))

    style.yellow = Style(RgbFg(255, 255, 0))
    style.magenta = Style(RgbFg(255, 0, 255))
    style.cyan = Style(RgbFg(0, 255, 255))

    style.orange = Style(RgbFg(255, 165, 0))
   

# Generated at 2022-06-12 09:53:03.933906
# Unit test for method copy of class Register
def test_Register_copy():

    register = Register()
    register.cool = Style("foo")
    register.set_renderfunc(RenderType, lambda x, y: "bar")

    new_reg = register.copy()

    assert new_reg.cool == "bar"



# Generated at 2022-06-12 09:53:19.836762
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class ATestRegister(Register):
        def __init__(self):
            super().__init__()
            self.rm = Style(Sgr(0))
            self.bold = Style(Sgr(1))
            self.faint = Style(Sgr(2))
            self.italic = Style(Sgr(3))
            self.underline = Style(Sgr(4))
            self.blink = Style(Sgr(5))
            self.blink2 = Style(Sgr(6))
            self.inverse = Style(Sgr(7))
            self.inverse2 = Style(Sgr(8))
            self.conceal = Style(Sgr(8))
            self.strike = Style(Sgr(9))
            self.black = Style(Eightbit(0))
            self.red = Style

# Generated at 2022-06-12 09:53:23.689425
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Create a new muted register. Set a style and see if it is correctly re-rendered.
    """
    r = Register()
    r.new = Style(RenderType())
    r.mute()
    r.unmute()
    assert str(r.new) != ""

# Generated at 2022-06-12 09:53:33.388561
# Unit test for constructor of class Style
def test_Style():
    # StylingRule = Union["Style", RenderType]
    # Style(I(1,2,3))
    assert Style(I(1,2,3))
    assert Style(Sgr(1))
    assert Style(I(1,2,3), Sgr(1))
    assert Style(Style(I(1,2,3), Sgr(1)))
    assert Style(Style(I(1,2,3), Sgr(1)), I(2,2,0))
    assert Style(RenderType(), Style(I(1,2,3), Sgr(1)), I(2,2,0))
    assert Style(Style(I(1,2,3), Sgr(1)))


# Generated at 2022-06-12 09:53:39.637097
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .ansi import Sgr
    from .rendertypes import RgbFg, RgbBg, RgbEf

    r = Register()

    r.__setattr__("teststyle", Style(RgbFg(0, 0, 0)))

    assert(r.teststyle == "\x1b[38;2;0;0;0m")

    r.set_renderfunc(RgbFg, lambda r, g, b: "this is a custom render function")

    assert(r.teststyle == "this is a custom render function")



# Generated at 2022-06-12 09:53:48.216164
# Unit test for constructor of class Register
def test_Register():

    # Test simple initialization
    assert Register

    # Test initialization with normal attributes
    assert Register(normal="\x1b[0m", bold="\x1b[1m")

    # Test initialization with style attributes
    assert Register(bold=Style(Sgr(1)))

    # Test initialization with style attributes and other attributes
    assert Register(bold=Style(Sgr(1)), normal="\x1b[0m")

    # Test initialization with style attributes and other attributes (2)
    assert Register(bold=Style(Sgr(1), Sgr(3)), normal="\x1b[0m")



# Generated at 2022-06-12 09:53:55.216431
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import SgrFg, SgrBg

    register = Register()
    register.set_eightbit_call(SgrFg)
    register.set_rgb_call(SgrBg)
    register.set_renderfunc(SgrBg, lambda r,g,b: f"\x1b[48;2;{r};{g};{b}m")

    register.r = Style(SgrFg(5), SgrBg(10, 20, 30))
    register.b = Style(SgrFg(15), SgrBg(20, 30, 40))

    assert r == Style(SgrFg(5), SgrBg(10, 20, 30))
    assert register.r is r

    register.mute()

    assert getattr(register, "r")

# Generated at 2022-06-12 09:54:01.230196
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .render import _Renderer
    renderer = _Renderer(256)
    renderer.register_funcs()

    import sty

    cls = sty.fg
    cls.unmute()
    
    assert cls.is_muted == False

    cls.mute()

    assert cls.is_muted == True

    cls.unmute()

    assert cls.is_muted == False

# Generated at 2022-06-12 09:54:08.385051
# Unit test for method mute of class Register
def test_Register_mute():

    bg1 = Register()
    bg1.set_eightbit_call(RenderType.SgrBg)

    bg1.red = Style(RenderType.SgrBg(1))

    # When muted, bg1.red should be an empty string.
    bg1.mute()

    assert str(bg1.red) == ""

    bg1.unmute()

    assert str(bg1.red) == "\x1b[48;5;1m"

# Generated at 2022-06-12 09:54:12.486216
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    fg_register = Register()
    fg_register.red = Style(RgbFg(10, 15, 20), Sgr(1))
    assert isinstance(fg_register.red, Style)
    assert fg_register.red.rules == (RgbFg(10, 15, 20), Sgr(1))

# Generated at 2022-06-12 09:54:19.853237
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        pass

    reg = MyRegister()

    reg.z = Style(RgbFg(10, 20, 30), Sgr(1))
    reg.y = Style(RgbFg(10, 20, 30), Sgr(2))
    reg.x = Style(RgbFg(10, 20, 30), Sgr(3))
    reg._foo = Style(RgbFg(10, 20, 30), Sgr(4))


# Generated at 2022-06-12 09:54:39.219896
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .rendertype import RenderType, Sgr

    class CustomRenderType(RenderType):
        pass

    fg = Register()
    fg.red = Style(CustomRenderType(1))
    fg.blue = Style(CustomRenderType(2))
    fg.green = Style(CustomRenderType(3))

    assert fg.as_dict() == {'red': '\x1b[1m',
                            'blue': '\x1b[2m',
                            'green': '\x1b[3m'}

    fg.set_renderfunc(CustomRenderType, lambda x: f"\033[{x}m")

# Generated at 2022-06-12 09:54:48.333579
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .sty import fg

    # The fg register uses SgrFg for 8bit calls.
    assert fg.eightbit_call == fg.renderfuncs[fg.SgrFg]

    # Change eightbit call type to RgbFg.
    fg.set_eightbit_call(fg.RgbFg)

    # Verify that the fg register uses RgbFg for 8bit calls now.
    assert fg.eightbit_call == fg.renderfuncs[fg.RgbFg]


# Generated at 2022-06-12 09:54:52.158893
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RGB
    rg = Register()
    rg.construct_funcs(RGB)
    rg.set_rgb_call(RGB)
    assert rg.rgb_call(1,2,3) == "\x1b[38;2;1;2;3m"


# Generated at 2022-06-12 09:54:57.893516
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))
    r.set_renderfunc(Sgr, lambda i, j, k: (i, j, k))
    r.foo = Style(RgbFg(9, 9, 9))
    r.bar = Style(Sgr(2))
    r.baz = Style(
        RgbFg(9, 9, 9), Sgr(2)
    )
    assert (r.foo == (9, 9, 9))
    assert (r.bar == (2,))
    assert (r.baz == ((9, 9, 9), (2,)))


test_Register()

# Generated at 2022-06-12 09:55:00.710161
# Unit test for method copy of class Register
def test_Register_copy():
    assert fg.red is fg.red
    assert fg.red is not fg.copy().red
    assert fg.red is not fg.copy().copy().red



# Generated at 2022-06-12 09:55:10.909881
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Fix order of register-objects so the test can be deterministic.
    original_dir = dir(Register)

    Register_template: NamedTuple = namedtuple("Register_template", ["name", "color"])
    test_data = [
        Register_template("red", "#FF0000"),
        Register_template("green", "#00FF00"),
        Register_template("blue", "#0000FF"),
        Register_template("red", "#FF0000"),
    ]

    r = Register()

    r_dumped = r.as_dict()
    assert r_dumped == {}

    new_dir_order = sorted(test_data, key=lambda x: x.name)


# Generated at 2022-06-12 09:55:22.515984
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Setup
    class MockedRenderType(RenderType):
        """
        Helper class for unit tests.
        """
        args = ()
        value = ""

    r1: Register = Register()
    r1.set_renderfunc(MockedRenderType, lambda x: 42)
    r1.set_eightbit_call(MockedRenderType)

    mocked_style: Style = Style(MockedRenderType())
    setattr(r1, "style1", mocked_style)

    # Tests
    # Test empty string if r1 is muted.
    r1.mute()
    assert r1(10) == ""

    # Test attribute with name if r1 is unmuted.
    r1.unmute()
    assert r1("style1") == mocked_style
    assert r1(42) == 42


#

# Generated at 2022-06-12 09:55:28.592801
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class MockRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0), Sgr(1))
            self.green = Style(RgbFg(0, 255, 0))

    r1 = MockRegister()
    d1 = r1.as_dict()

    d2 = {"red": "\x1b[38;2;255;0;0m\x1b[1m", "green": "\x1b[38;2;0;255;0m"}

    assert d1 == d2


# Generated at 2022-06-12 09:55:38.808200
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Setup
    r = Register()
    r.renderfuncs.update({str: lambda x: x})
    r.set_eightbit_call(str)

    # Assertion 1
    r.red = Style(RgbFg(255, 0, 0))
    assert r.red == "RgbFg(255, 0, 0)"

    # Assertion 2
    r.mute()
    r.red = Style(RgbFg(255, 0, 0))
    assert r.red == ""

    # Assertion 3
    r.unmute()
    r.red = Style(RgbFg(255, 0, 0))
    assert r.red == "RgbFg(255, 0, 0)"

    # Assertion 4

# Generated at 2022-06-12 09:55:47.449148
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Setup
    class RgbFg(RenderType):
        pass
    class Bg(RenderType):
        pass
    fg = Register()
    fg.red: Style = Style(RgbFg(10, 42, 255), "red")
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"rgb-fg({r}, {g}, {b})")

    fg.set_rgb_call(RgbFg)

    # Test
    assert str(fg.red) == "rgb-fg(10, 42, 255)"
    assert str(fg(10, 42, 255)) == "rgb-fg(10, 42, 255)"
    assert str(fg(fg.red)) == "rgb-fg(10, 42, 255)"

# Generated at 2022-06-12 09:56:09.101928
# Unit test for constructor of class Style
def test_Style():
    assert issubclass(Style, str)

# Generated at 2022-06-12 09:56:18.257851
# Unit test for method mute of class Register
def test_Register_mute():
    from sty import fg, bg
    from sty.types import RgbFg

    # Disable mute to get actual styling-output.
    fg.is_muted = False

    # Create some styles
    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))

    # Enable mute to suppress actual styling-output.
    fg.mute()
    assert fg.is_muted

    # Invoke styling.
    assert fg.green == ''
    assert fg(255, 0, 0) == ''

    # Disable mute to get actual styling-output.
    fg.unmute()
    assert not fg.is_muted

    # Invoke styling.

# Generated at 2022-06-12 09:56:25.471698
# Unit test for constructor of class Style
def test_Style():

    from .rendertypes import RgbFg, RgbBg, Sgr

    Style1 = Style(
        RgbFg(1, 5, 10),
        Sgr(1),
        value="\x1b[38;2;1;5;10m\x1b[1m",
    )

    Style2 = Style(
        RgbFg(1, 5, 10),
        Sgr(1),
    )

    Style3 = Style(
        Style1,
        Style2,
        value="\x1b[38;2;1;5;10m\x1b[1m\x1b[38;2;1;5;10m\x1b[1m",
    )

    Style4 = Style(
        Style1,
        Style2,
    )


# Generated at 2022-06-12 09:56:33.226641
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Reset, RgbFg, Sgr

    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    reg.blue = Style(RgbFg(0, 0, 255), Sgr(2))

    assert reg.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert reg.blue == "\x1b[38;2;0;0;255m\x1b[2m"

    reg.mute()

    assert reg.red == ""
    assert reg.blue == ""



# Generated at 2022-06-12 09:56:41.375425
# Unit test for constructor of class Style
def test_Style():
    assert Style() == ""
    assert Style(value="x") == "x"

    rt1 = RenderType("x")
    assert Style(rt1) == "\x1b[xm"

    rt2 = RenderType("y")
    assert Style(rt1, rt2) == "\x1b[x;ym"

    st1 = Style(rt1, rt2)
    assert Style(st1) == "\x1b[x;ym"
    assert Style(rt1, st1) == "\x1b[x;x;ym"

    st2 = Style(rt1, rt2, value="x")
    assert Style(st2) == "\x1b[x;y;x;ym"



# Generated at 2022-06-12 09:56:45.925809
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda *x: str(x))
    r.red = Style(Sgr(1))
    assert str(r.red) == "1"

    r.mute()
    assert str(r.red) == ""

    r.unmute()
    assert str(r.red) == "1"



# Generated at 2022-06-12 09:56:50.135585
# Unit test for method mute of class Register
def test_Register_mute():
    r1 = Register()
    setattr(r1, "test_style", Style(Sgr(1, 2, 3)))
    r1.mute()

    assert r1.test_style == ""



# Generated at 2022-06-12 09:56:56.085820
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define a new rendertype and its renderfunc.
    class CustomRenderType(RenderType):
        pass

    def custom_render_func(x: CustomRenderType):
        return f"{x.args[0]}"

    # Make a Register-object and add the new renderfunc.
    register = Register()
    register.set_renderfunc(CustomRenderType, custom_render_func)

    # Define two styles with different rendertypes.
    style1 = Style(CustomRenderType(1))
    style2 = Style(rendertype=Sgr(1))

    # Set the styles to the register.
    register.style1 = style1
    register.style2 = style2

    # Test that the register returns the correct style-data for the arguments.
    assert register.style1 == "1"

# Generated at 2022-06-12 09:57:00.074465
# Unit test for method copy of class Register
def test_Register_copy():
      r1 = Register()
      r2 = Register()
      r1.a = Style(r2.a, "foo")
      r2.b = Style(r1.a, "bar")

      r3 = r1.copy()
      assert r2.b == r3.b
      assert r1.a == r3.a
      assert r1.a is not r3.a

# Generated at 2022-06-12 09:57:06.315423
# Unit test for method unmute of class Register
def test_Register_unmute():
    a = Register()
    a.rgb = Style("rgb_test")
    a.mute()
    assert a.rgb == ""
    a.unmute()
    assert a.rgb == "rgb_test"
    a.rgb = Style("rgb_test2")
    a.mute()
    assert a.rgb == ""
    a.unmute()
    assert a.rgb == "rgb_test2"

# Generated at 2022-06-12 09:57:52.805058
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Unit test for method mute of class Register.

    The class Register has a `mute`-method. It allows you
    to mute a register-object.

    Let's assume we have this very simple register:

        r = Register()
        r.red = Style(RgbFg(255,0,0))
        print(r.red)  # '\x1b[38;2;255;0;0m'

    We can mute it by calling the `mute`-method:

        r.mute()
        print(r.red)  # ''

    Now let's unmute it again:

        r.unmute()
        print(r.red)  # '\x1b[38;2;255;0;0m'

    """

    # Create a simple register
    from .sty import Sty

# Generated at 2022-06-12 09:58:01.148054
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    def make_namedtuple(d):
        return namedtuple("StyleRegister", d.keys())(*d.values())

    from sty import fg, rs

    # Create a custom register.
    my_color = Register()
    my_color.red = Style(fg.red)
    my_color.reset = Style(rs.all)

    # Expected result
    d = {"red": fg.red, "reset": rs.all}
    Expected = make_namedtuple(d)

    # Actual result
    Result = my_color.as_namedtuple()

    assert isinstance(Result, NamedTuple)
    assert len(Result) == 2
    assert Result.red == Expected.red
    assert Result.reset == Expected.reset



# Generated at 2022-06-12 09:58:10.292120
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Create dummy-register
    register = Register()

    # Add render rule
    register.renderfuncs.update({RenderType: lambda x: x})

    # Assert Style is created
    style_test = Style("test")
    register.test = style_test
    assert isinstance(register.test, Style)
    assert register.test == style_test

    # Assert RenderType is created
    rule_test = RenderType("test")
    register.test = rule_test
    assert isinstance(register.test, Style)
    assert register.test == style_test

    # Assert error is raised if non Style object is created
    wrong_test = 123
    try:
        register.test = wrong_test
    except ValueError:
        assert True
    else:
        assert False

    # Assert style is muted if register is

# Generated at 2022-06-12 09:58:14.416111
# Unit test for constructor of class Style
def test_Style():
    """
    Flat test of the Style class, only checks if constructor works as intended.
    """
    styles = [
        Style(fg=1),
        Style(bg=2),
        Style(fg=3, bg=4),
        Style(fg=5, bg=6),
    ]

# Generated at 2022-06-12 09:58:21.056575
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestType(RenderType):
        pass

    test_register = Register()
    test_key = TestType
    test_func = lambda x: x + 4

    # Check if key is not in dict before calling set_renderfunc.
    assert test_key not in test_register.renderfuncs

    # Call set_renderfunc and check if key is in renderfuncs.
    test_register.set_renderfunc(test_key, test_func)
    assert test_key in test_register.renderfuncs
    assert test_register.renderfuncs[test_key] == test_func



# Generated at 2022-06-12 09:58:27.322701
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for the `unmute` method of the register class.
    """
    from sty import fg, ef

    sty = fg.blue
    sty2 = ef.bold
    sty3 = sty + sty2

    sty_ref = sty.copy()
    sty_ref2 = sty2.copy()
    sty_ref3 = sty3.copy()

    fg.mute()

    assert sty == ""
    assert sty2 == ""
    assert sty3 == ""

    fg.unmute()

    assert sty == sty_ref
    assert sty2 == sty_ref2
    assert sty3 == sty_ref3

# Generated at 2022-06-12 09:58:33.322217
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Check that the method mute of class Register works as intended.
    """
    from . import fg

    test_style = Style(fg("red"))

    assert is_style_with_ANSI_sequence(test_style)

    fg.mute()

    assert is_style_without_ANSI_sequence(test_style)

    fg.unmute()

    assert is_style_with_ANSI_sequence(test_style)



# Generated at 2022-06-12 09:58:40.282654
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .register import fg, bg
    from .style import fg8, bg8

    # These imports are needed to make the types for the attributes of the
    # StyleRegister type to be available.
    # If you have a better idea, please create an issue.
    # pylint: disable=unused-import
    from .register import Ef
    from .rendertype import Bg, Fg, RgbFg, RgbBg, Reset

    # Create some attributes in the register
    setattr(fg, "red", Style(Fg(1)))
    setattr(fg, "green", Style(Fg(2)))

    nt = fg.as_namedtuple()

    # All attributes we created should be there.
    assert nt.red == "\x1b[31m"

# Generated at 2022-06-12 09:58:44.533349
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    assert Register().as_namedtuple() == namedtuple("StyleRegister", [])(*[])
    method = lambda: Register().as_namedtuple()
    assert method.__name__ == "StyleRegister"
    assert hasattr(method, "red")
    assert hasattr(method, "blue")
    assert hasattr(method, "green")
    assert not hasattr(method, "black")
    assert getattr(method, "red") == "\033[38;2;255;0;0m"
    assert getattr(method, "blue") == "\033[38;2;0;0;255m"
    assert getattr(method, "green") == "\033[38;2;0;255;0m"


# Generated at 2022-06-12 09:58:53.494978
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Ansi, Eightbit, Rgb

    class TestRegister(Register):
        pass

    def test_renderfunc(color: int, bold: bool = False) -> str:
        return "\x1b[38;2;{};{};{}m".format(color, color, color)

    fg = TestRegister()
    fg.set_eightbit_call(Rgb)
    fg.set_renderfunc(Rgb, test_renderfunc)
    assert fg.eightbit_call is not test_renderfunc
    fg.set_eightbit_call(Rgb)
    assert fg.eightbit_call is test_renderfunc
    fg.set_eightbit_call(Eightbit)
    assert fg.eightbit_call is not test_renderfunc
    fg.set_