

# Generated at 2022-06-12 09:49:52.968404
# Unit test for constructor of class Register
def test_Register():
    assert isinstance(Register(), Register)

# Generated at 2022-06-12 09:49:54.293000
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    return reg



# Generated at 2022-06-12 09:50:04.114836
# Unit test for constructor of class Register
def test_Register():
    """
    Test if each Register instance is callable and has the correct properties.

    :raise: AssertionError
    """
    from . import style

    # Check if registers are callable
    for reg in [style.fg, style.bg, style.ef, style.rs]:
        assert callable(reg)

    # Check if registers have the correct attributes
    for reg in [style.fg, style.bg, style.ef, style.rs]:
        assert hasattr(reg, "mute")
        assert hasattr(reg, "is_muted")
        assert hasattr(reg, "unmute")
        assert hasattr(reg, "set_eightbit_call")
        assert hasattr(reg, "set_rgb_call")
        assert hasattr(reg, "set_renderfunc")

# Generated at 2022-06-12 09:50:12.094368
# Unit test for method __call__ of class Register
def test_Register___call__():

    class FakeRenderType(RenderType):
        def render(self) -> str:
            return "foobar"

    class FakeRegister(Register):
        pass

    fr = FakeRenderType()
    fg = FakeRegister()
    fg.set_renderfunc(FakeRenderType, fr.render)

    fg.set_eightbit_call(FakeRenderType)
    assert fg(42) == "foobar"
    fg.set_eightbit_call(FakeRenderType)
    assert fg(10, 20, 30) == "foobar"

# Generated at 2022-06-12 09:50:13.933397
# Unit test for constructor of class Register
def test_Register():
    new_register = Register()

    assert isinstance(new_register, Register)


# Generated at 2022-06-12 09:50:21.633451
# Unit test for method __call__ of class Register
def test_Register___call__():

    from . import bg
    from .rendertype import RgbBg

    register = Register()
    register.set_rgb_call(RgbBg)
    register.one = Style(RgbBg(100, 200, 100))
    register.two = Style(RgbBg(200, 100, 100))
    register.three = Style(RgbBg(100, 100, 40))

    # Test call with style-name
    assert register("one") == bg(100, 200, 100)

    # Test call with Rgb-Code
    assert register(100, 200, 100) == bg(100, 200, 100)

    # Test call with Eightbit-Code
    register.set_eightbit_call(RgbBg)
    assert register(125) == bg(125, 125, 125)  # Eight

# Generated at 2022-06-12 09:50:23.104454
# Unit test for method __call__ of class Register
def test_Register___call__():

    # TODO: do we need this test here?
    pass

# Generated at 2022-06-12 09:50:29.470988
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RenderState

    fg = Register()
    fg.set_eightbit_call(Eightbit)
    fg.green = Style(Eightbit(28), RenderState(1))

    assert fg(28) == "\x1b[38;5;28m\x1b[1m"
    assert fg('green') == "\x1b[38;5;28m\x1b[1m"

# Generated at 2022-06-12 09:50:33.788132
# Unit test for constructor of class Register
def test_Register():
    style = Style(1, fg=1, bg=2)
    reg = Register()
    reg.a = style
    assert reg.a == style
    assert reg.a.rules == style.rules
    assert reg.a.value == ''
    assert reg.a.__class__ is Style

# Generated at 2022-06-12 09:50:39.448090
# Unit test for method __call__ of class Register
def test_Register___call__():
    #create register
    r = Register()

    #create mock style and save in register
    r.f = Style(RenderType(args=(144,)))

    #check if register was correctly created
    assert str(r.f) == "\x1b[38;2;204;51;255m"

    #check if __call__ works
    assert r(144) == "\x1b[38;2;204;51;255m"

# Generated at 2022-06-12 09:50:52.686974
# Unit test for method __call__ of class Register
def test_Register___call__():
    renderfuncs = {RenderType: lambda *args, **kwargs: ""}
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, renderfuncs[RenderType])
    r.one = Style(
        RenderType(1),
        RenderType(2),
        RenderType(3),
    )
    r.two = Style(
        RenderType(4),
        RenderType(5),
        RenderType(6),
    )
    assert r(1) == r.one
    assert r(0, 0, 0) == ""
    assert r("one") == r.one
    assert r("two") == r.two



# Generated at 2022-06-12 09:50:59.544018
# Unit test for method copy of class Register
def test_Register_copy():
    import pytest
    from sty import fg, ef

    fg1 = fg.reset.copy()

    assert isinstance(fg1, Register)
    assert fg1 is not fg

    fg2 = fg1.copy()

    assert fg1 is not fg2
    assert fg.red == fg2.red

    fg1.red = ef.bold
    assert fg1.red == ef.bold
    assert fg2.red == fg.red


# Generated at 2022-06-12 09:51:08.719415
# Unit test for method copy of class Register
def test_Register_copy():
    def render_func_1(*args):
        return "".join([str(i) for i in args])

    def render_func_2(*args):
        return "".join([str(i) for i in args])

    reg = Register()
    reg.set_renderfunc(RenderType, render_func_1)
    reg.set_renderfunc(RenderType, render_func_2)

    reg.foo = Style(RenderType(3, 4, 5))
    reg.bar = Style(RenderType(7, 8, 9))

    reg.foo = "foo"
    reg.bar = "bar"

    reg.baz = Style(RenderType(3, 4, 5))
    reg.baz.baz = "baz"

    reg_copy = reg.copy()

    assert reg.foo == reg_copy

# Generated at 2022-06-12 09:51:11.500762
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .rendertype import Sgr

    r = Register()
    r.yellow = Style(Sgr(33))

    assert r.as_dict() == {"yellow": "\x1b[33m"}


# Generated at 2022-06-12 09:51:16.707192
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertypes import RgbBg, Sgr

    class MyRegister(Register):
        pass

    reg = MyRegister()

    style = Style(RgbBg(1, 5, 10), Sgr(1))

    reg.red = style

    assert isinstance(reg.red, Style)
    assert isinstance(reg.red, str)
    assert str(reg.red) == "\x1b[48;2;1;5;10m\x1b[1m"


# Generated at 2022-06-12 09:51:20.534661
# Unit test for method __new__ of class Style
def test_Style___new__():
    from . import RenderType, Sgr

    assert isinstance(Style(Sgr(1)), str)
    assert isinstance(Style(Sgr(1)), Style)
    assert isinstance(Style(Sgr(1)), RenderType)
    assert isinstance(Style(Sgr(1)), Style)



# Generated at 2022-06-12 09:51:23.617666
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.a = 1
    r.b = 2
    r.c = 3

    assert r.as_dict() == {"a": "1", "b": "2", "c": "3"}

# Generated at 2022-06-12 09:51:34.465489
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, EightBitFg

    def eightbitfunc(x: int, *args, **kwargs):
        return f"\x1b[3{x}m"

    def rgbfunc(r: int, g: int, b: int, *args, **kwargs):
        return f"\x1b[38;2;{r};{g};{b}m"

    reg: Register = Register()

    assert reg(None) == ""

    reg.set_renderfunc(EightBitFg, eightbitfunc)
    reg.set_eightbit_call(EightBitFg)

    assert reg(144) == "\x1b[38;2;34;34;34m"
    assert reg(255) == "\x1b[38;2;255;255;255m"


# Generated at 2022-06-12 09:51:36.656186
# Unit test for constructor of class Register
def test_Register():
    rg = Register()

    assert rg.is_muted == False
    assert not hasattr(rg, "renderfuncs")



# Generated at 2022-06-12 09:51:45.517452
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    This test checks if the register's method set_renderfunc works as expected.

    It checks if the given renderfunc overrides the default renderfunc
    of the given rendertype.
    """

    # Create a RenderType-obj.
    dummy_sgr = Sgr(1)
    dummy_sgr_output = "\x1b[1m"

    # Create a dummy renderfunc
    def dummy_renderfunc(sgr: Sgr) -> str:
        return sgr_renderfunc(sgr)

    # Create a dummy register-obj
    dummy_register = Register()

    # Set default renderfunc for Sgr.
    dummy_register.set_renderfunc(Sgr, sgr_renderfunc)

    # This should be the same as with the default renderfunc.

# Generated at 2022-06-12 09:51:58.161950
# Unit test for constructor of class Style
def test_Style():
    """
    Test `Style`-constructor.
    """
    class Sgr(RenderType):
        pass

    sgr = Sgr(1, "test")
    style = Style(sgr)

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules[0] == sgr
    assert str(style) == "\x1b[1mtest"



# Generated at 2022-06-12 09:52:05.590774
# Unit test for method __new__ of class Style
def test_Style___new__():
    r1 = Style(Sgr(1), RgbBg(1, 5, 10))

    assert isinstance(r1, Style)
    assert isinstance(r1, str)
    assert str(r1) == "\x1b[1m\x1b[48;2;1;5;10m"

    r2 = Style(Sgr(1, 2), value=b"test".decode())

    assert isinstance(r2, Style)
    assert isinstance(r2, str)
    assert str(r2) == "\x1b[1;2mtest"

# Generated at 2022-06-12 09:52:09.641997
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRegister(Register):
        pass

    register = TestRegister()
    register.test = Style(RenderType("test"))

    assert str(register.test) == "\x1b[testm"

    register.mute()

    assert str(register.test) == ""

    register.unmute()

    assert str(register.test) == "\x1b[testm"

# Generated at 2022-06-12 09:52:20.539414
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, RgbBg, RgbEf

    class test_class1(Register):
        def __init__(self):
            super().__init__()
            self.blau = Style(RgbFg(0,0,255), RgbBg(0,255,255))
            self.gruen = Style(RgbEf(0,255,0))

    c = test_class1()
    nt = c.as_namedtuple()
    assert(nt.blau == "\x1b[38;2;0;0;255m\x1b[48;2;0;255;255m")
    assert(nt.gruen == "\x1b[48;2;0;255;0m")

    # Test __contains__

# Generated at 2022-06-12 09:52:31.082976
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    If a register-object can be muted, we need to ensure that all the
    styles are re-rendered when the register is unmuted, so that the
    ANSI-sequences of the unmuted register match the ANSI-sequences of
    the original register.
    """

    class RenderTypeTest(RenderType):
        """
        A dummy class to test the method set_renderfunc of class Register.
        """
        def __init__(self):
            super().__init__()
            self.args = (1, 2)

        def _renderfunc(self):
            return "ab"

    reg_original = Register()
    reg_original.set_renderfunc(RenderTypeTest, lambda x, y: "ab")

    reg_original.a = Style(RenderTypeTest(), value="ab")

    reg_mutated = reg

# Generated at 2022-06-12 09:52:33.877212
# Unit test for method copy of class Register
def test_Register_copy():
    # given
    r = Register()

    # when
    r.foo = "bar"
    r2 = r.copy()

    # then
    assert r.foo == r2.foo

# Generated at 2022-06-12 09:52:35.501906
# Unit test for constructor of class Register
def test_Register():
    """
    >>> r = Register()
    >>> isinstance(r, Register)
    True
    """
    pass



# Generated at 2022-06-12 09:52:39.939508
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr
    from .render import render_sgr

    r = Register()
    r.set_renderfunc(Sgr, render_sgr)
    assert r.renderfuncs[Sgr] == render_sgr



# Generated at 2022-06-12 09:52:49.044005
# Unit test for method copy of class Register
def test_Register_copy():
    import pytest
    from .rendertype.rgb import RgbBg
    fg = Register()
    fg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    fg.red = Style(RgbBg(255, 0, 0))
    fg.blue = Style(RgbBg(0, 0, 255))
    fg_copy = fg.copy()
    fg_copy.red = Style(RgbBg(0, 255, 0))

    assert fg.red == "\x1b[48;2;255;0;0m"
    assert fg.blue == "\x1b[48;2;0;0;255m"

# Generated at 2022-06-12 09:52:55.159315
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    fg = Register()
    fg.init_from_dict({"red": "\x1b[31m", "green": "\x1b[32m"})
    assert fg.as_dict() == {"red": "\x1b[31m", "green": "\x1b[32m"}



# Generated at 2022-06-12 09:53:15.267424
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class MyType(RenderType):

        def __str__(self):
            return "MyType Class"

    def my_func(x):
        return str(MyType(x))

    r1 = Register()
    r1.set_renderfunc(MyType, my_func)

    r1.set_eightbit_call(MyType)

    assert r1(42) == "MyType Class"  # type: ignore
    assert r1(42) != ""  # type: ignore

# Generated at 2022-06-12 09:53:19.258785
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    reg = Register()
    reg.rgb_call = lambda r, g, b: [r, g, b]
    reg.eightbit_call = lambda x: [x]
    reg.set_eightbit_call(RgbFg)
    assert reg.eightbit_call == reg.rgb_call

# Generated at 2022-06-12 09:53:22.340594
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit
    from .register import fg

    fg.set_eightbit_call(Eightbit)
    fg.set_eightbit_call(Eightbit)



# Generated at 2022-06-12 09:53:33.210397
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import Render

    # Create mocked register
    register = Register()
    register.renderfuncs = Render.funcs

    # Set some attributes
    register.bright_blue = Style(Bg(0,0,128))
    register.bright_red = Style(Bg(128,0,0))
    register.bright_green = Style(Bg(0,128,0))
    register.bright_yellow = Style(Bg(128,128,0))
    register.bright_magenta = Style(Bg(128,0,128))
    register.bright_cyan = Style(Bg(0,128,128))
    register.bright_white = Style(Bg(192,192,192))

    # Test
    assert isinstance(register.bright_blue, str)

# Generated at 2022-06-12 09:53:39.292906
# Unit test for method __new__ of class Style
def test_Style___new__():
    a = Style(RgbFg(1, 5, 10), Sgr(1))
    rendered_a, _ = _render_rules({RgbFg: lambda x, y, z: x + y + z, Sgr: lambda x: x}, (a.rules))
    # Note: Why does the rendered_a string contain '\x1b[1m'? Isn't this the result of the last
    # call in _render_rules, which is str(Sgr(1))?
    assert str(a) == rendered_a
    

# Generated at 2022-06-12 09:53:48.348534
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test the __setattr__ method of the Register class. This is a very important method.
    It intercepts the assignment of a style attribute and creates a new attribute with the same name
    that contains the correctly rendered style string.
    """

    class TestRender(RenderType):
        pass

    class TestRegister(Register):
        pass

    test_register = TestRegister()
    test_register.set_renderfunc(TestRender, lambda *args: "Hello World! {}".format(args))
    test_register.test = Style(TestRender(4, 5))

    assert test_register.test == "Hello World! (4, 5)"

# Generated at 2022-06-12 09:53:50.535526
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class CustomRegister(Register):
        def __init__(self):
            super().__init__()

    r = CustomRegister()
    r.a = "123"
    r.b = "456"
    assert r.as_dict() == {"a": "123", "b": "456"}



# Generated at 2022-06-12 09:54:01.610790
# Unit test for constructor of class Register
def test_Register():

    from .attributes import Attributes
    from .rendertype import RenderType
    from .rendertypes import EightbitFg, Sgr, SgrFg, SgrBg
    from .style import Style
    from .sty import Sty

    r1 = RenderType(SgrFg, [124])
    r2 = RenderType(SgrBg, [90])
    r3 = RenderType(EightbitFg, [45])
    r4 = RenderType(Sgr, [1], "b")
    r5 = Style(r1, r2, r3, r4)

    reg = Register()

    reg.set_renderfunc(EightbitFg, Sty.render_eightbit)
    reg.set_renderfunc(SgrFg, Sty.render_rgb256)

# Generated at 2022-06-12 09:54:12.360228
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    rgbfg_renderfunc = lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int) -> None:
            self.args = r, g, b

    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int) -> None:
            self.args = r, g, b

    def sgr_renderfunc(*args):
        return f"\x1b[{';'.join(map(str, args))}m"

    class Sgr(RenderType):
        def __init__(self, *args: int) -> None:
            self.args = args

   

# Generated at 2022-06-12 09:54:16.736302
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .ansi import Fg
    from .rendertype import Sgr

    fg_orange = Style(Fg(1, 5, 10), Sgr(1))

    assert isinstance(fg_orange, Style)
    assert isinstance(fg_orange, str)
    assert str(fg_orange) == '\x1b[38;2;1;5;10m\x1b[1m'

# Generated at 2022-06-12 09:55:10.593081
# Unit test for constructor of class Register
def test_Register():

    # Create a new empty register.
    reg1 = Register()



# Generated at 2022-06-12 09:55:13.889644
# Unit test for method copy of class Register
def test_Register_copy():
    rg = Register()

    rg.test = Style(RgbFg(1, 5, 10))

    rg2 = rg.copy()
    del rg2.test
    assert hasattr(rg, "test") and not hasattr(rg2, "test")



# Generated at 2022-06-12 09:55:17.636352
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .parameters import fg, ef
    nt = fg.as_namedtuple()
    assert nt.black == fg.black


# Generated at 2022-06-12 09:55:21.686855
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.foo = Style(value="bar")
    r2 = r1.copy()

    assert id(r1) != id(r2)
    assert id(r1.foo) != id(r2.foo)

# Generated at 2022-06-12 09:55:26.894639
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 5, 12))
    assert len(style.rules) == 1
    assert style.rules[0].args == (1, 5, 12)

    # Test the rules attribute
    assert isinstance(style.rules, Iterable)

    # Test the value attribute
    assert isinstance(style.value, str)

    # Test that Style is a str.
    assert isinstance(style, str)

# Generated at 2022-06-12 09:55:34.471176
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Rendertype(RenderType):
        def __str__(self):
            return f"foo{self.args[0]}"
    y: Style = Style(Rendertype(144))
    r = Register()
    r.foo = y
    assert r.foo == "foo144"
    r.set_eightbit_call(type(y.rules[0]))
    assert str(r(144)) == "foo144"
    return True


# Generated at 2022-06-12 09:55:39.726554
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the __new__ method of class Style.
    """
    style_instance_0 = Style()
    assert style_instance_0 is not "" and style_instance_0 is not str()
    assert style_instance_0 == ""

    style_instance_1 = Style(value="\x1b[1m")
    assert style_instance_1 is not "\x1b[1m" and style_instance_1 is not str("\x1b[1m")
    assert style_instance_1 == "\x1b[1m"
    return



# Generated at 2022-06-12 09:55:48.397357
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr, RenderType

    class FakeRenderType(RenderType):
        render_base: str = "Fake"

    class FakeRenderType2(RenderType):
        render_base: str = "Faux"

    f1: Callable = lambda x, y, z: "Fake1"
    f2: Callable = lambda x: "Fake2"
    r: Register = Register()
    r.set_renderfunc(FakeRenderType, f1)
    r.set_renderfunc(FakeRenderType2, f2)

    fg_red = Style(FakeRenderType(1, 5, 10))
    fg_orange = Style(FakeRenderType(1, 2, 3), Sgr(1))

    r.red = fg_red
    r.orange = fg_orange



# Generated at 2022-06-12 09:55:51.556877
# Unit test for method unmute of class Register
def test_Register_unmute():

    register = Register()

    register.is_muted = True

    assert register.is_muted == True

    register.unmute()

    assert register.is_muted == False


# Generated at 2022-06-12 09:55:55.680519
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    register = Register()
    register.set_renderfunc(RenderType, lambda x: f"\x1b[38;2;{x};{x};{x}m")

    StyleRule = namedtuple("StyleRule", ["name", "args"])

    style1 = Style(StyleRule("RgbFg", (24, 42, 230)))
    style2 = Style(style1, StyleRule("Bold", ()))

    setattr(register, "green", style1)
    setattr(register, "green_bold", style2)

    assert str(style1) == str(register.green)
    assert str(style2) == str(register.green_bold)

    register.set_renderfunc(StyleRule, lambda name, *args: f"\x1b[{name}m")

    assert str(style1)

# Generated at 2022-06-12 09:56:41.592246
# Unit test for constructor of class Style
def test_Style():
    """Test constructor of class Style."""
    from .rendertype import Dummy

    s = Style(Dummy(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)

    assert s == ""
    assert s.rules == (Dummy(1),)

    s = Style(Dummy(1), value="Dummy(1)")
    assert s == "Dummy(1)"
    assert s.rules == (Dummy(1),)

# Generated at 2022-06-12 09:56:52.382211
# Unit test for method __call__ of class Register
def test_Register___call__():

    class FakeRegister(Register):
        """
        This register object is used in the unit test for the method __call__ of class Register.
        """

        def __init__(self):
            super().__init__()

        def eightbit_call(self, x: int, y: int = 0) -> str:
            return str(x + y)

        def rgb_call(self, r: int, g: int, b: int, c: int = 0) -> str:
            return str(r + g + b + c)

    def test_eightbit_call(register: Register) -> bool:
        """
        Unit test for Eightbit-call
        """

        assert register(1) == "1"
        assert register(1, 2) == "3"

        # Test muting
        register.mute()
        assert register

# Generated at 2022-06-12 09:56:55.581932
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.r0 = Style(RenderType())
    d = r.as_dict()
    assert isinstance(d, dict)
    assert list(d.keys()) == ['r0']
    assert d['r0'] == ''

# Generated at 2022-06-12 09:56:56.420685
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r is not None

# Generated at 2022-06-12 09:56:58.728982
# Unit test for method mute of class Register
def test_Register_mute():
    fg = Register()
    fg.black = Style(Sgr(30))
    fg.mute()
    assert fg.black == ""


# Generated at 2022-06-12 09:57:04.862668
# Unit test for constructor of class Register
def test_Register():

    def my_color_func(value):
        return value

    fg = Register()
    fg.set_renderfunc(RenderType, my_color_func)
    fg.red = Style("red")

    assert fg.red == "red"

    assert str(fg("red")) == "red"

    fg.blue = Style("blue")

    assert str(fg("blue")) == "blue"

    fg.yellow = Style("yellow")

    assert str(fg("yellow")) == "yellow"

# Generated at 2022-06-12 09:57:12.954325
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))
    r.red24 = Style(rgb(255, 0, 0))
    r.blue24 = Style(rgb(0, 0, 255))

    assert r.red() == "\x1b[38;2;255;0;0m"
    assert r.blue() == "\x1b[48;2;0;0;255m"
    assert r.red24() == "\x1b[48;2;255;0;0m"
    assert r.blue24() == "\x1b[48;2;0;0;255m"

    r.set_

# Generated at 2022-06-12 09:57:17.594421
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = "hello"
            self.green = "world"
            self.blue = 42

    r = TestRegister()

    assert r.as_dict() == {"red": "hello", "green":"world", "blue":"42"}



# Generated at 2022-06-12 09:57:23.427422
# Unit test for method __new__ of class Style
def test_Style___new__():

    class R1(RenderType):
        args = ()

    r1 = R1()

    class R2(RenderType):
        args = ()

    r2 = R2()

    Style(r1)
    Style(r1, r2)

    # Create new style
    style1: Style = Style(r1, r2, "")

    # Check if value attribute is stored correctly.
    assert style1 == ""

    # Check if rules attribute is stored correctly.
    assert style1.rules == (r1, r2)


# Generated at 2022-06-12 09:57:28.876213
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    _ = Register()
    mapping = _.as_namedtuple()
    assert mapping.black == '\x1b[38;2;0;0;0m\x1b[48;2;0;0;0m'
    assert mapping.red == '\x1b[38;2;128;0;0m\x1b[48;2;128;0;0m'

# Generated at 2022-06-12 09:59:33.684310
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import RgbFg, RgbBg, Rgb8bitFg, Rgb8bitBg
    rules = (RgbFg(1, 1, 1), RgbBg(2, 2, 2))
    s = Style(*rules)
    assert isinstance(s, Style)
    assert len(s.rules) == 2
    assert s.rules[0] == RgbFg(1, 1, 1)
    assert s.rules[1] == RgbBg(2, 2, 2)
    r1, r2 = _render_rules(fg.renderfuncs, s.rules)
    assert str(s) == r1
    assert s.rules == r2

    s = Style(Rgb8bitFg(130))
    assert isinstance(s, Style)

# Generated at 2022-06-12 09:59:37.121578
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    Test = fg.as_namedtuple()
    assert Test.red == fg.red



# Generated at 2022-06-12 09:59:40.478712
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Setup
    class MyRegister(Register):
        pass

    r = MyRegister()
    r.foo = Style()

    # Test
    r.set_renderfunc(RenderType, lambda x: "test")
    r.set_renderfunc(RenderType, lambda y: "test")

    assert r.foo == "test"

# Generated at 2022-06-12 09:59:44.367967
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    reg = Register()

    DummyStyle = namedtuple("DummyStyle", "args")

    reg.set_eightbit_call(DummyStyle)
    reg.eightbit_call = lambda x: x * 2

    assert reg(5) == 10
