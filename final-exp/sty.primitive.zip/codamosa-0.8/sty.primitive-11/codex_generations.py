

# Generated at 2022-06-12 09:50:02.427309
# Unit test for constructor of class Register
def test_Register():
    """
    This is a unit test for the Register class.
    """
    from .rendertype import RgbFg, Sgr, RenderType, ClearScreen
    from .color import RgbMapping, RgbFgMapping
    from .xterm256 import xtermcolors
    import os

    def _render_func(rgb_fg: RenderType) -> str:
        return "\x1b[" + str(rgb_fg.args) + "m"

    def _render_clear(clear_screen: ClearScreen) -> str:
        return "\x1b[2J"

    r = Register()
    r.set_renderfunc(RgbFg, _render_func)
    r.set_renderfunc(ClearScreen, _render_clear)

    # overwrite renderfunc for style

# Generated at 2022-06-12 09:50:08.781902
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbBg
    from .rendertype import RgbFg
    from .rendertype import EightbitBg
    from .rendertype import EightbitFg

    def rgb_bg_call(r, g, b):
        return f"RGBBG:{r}/{g}/{b}"

    def rgb_fg_call(r, g, b):
        return f"RGBFG:{r}/{g}/{b}"

    def eightbit_bg_call(x):
        return f"8BitBG:{x}"

    def eightbit_fg_call(x):
        return f"8BitFG:{x}"

    # Create reg object
    reg = Register()

    # Add render-funcs
    reg.set_renderfunc(EightbitBg, eightbit_bg_call)
    reg

# Generated at 2022-06-12 09:50:18.790641
# Unit test for method __call__ of class Register
def test_Register___call__():
    fg = Register()
    class Eightbit(RenderType):
        args = (int, )
    class RgbFg(RenderType):
        args = (int, int, int)
    class Sgr(RenderType):
        args = tuple()

    fg.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda: "\x1b[1m")

    fg.blue: Style = Style(Eightbit(4))

# Generated at 2022-06-12 09:50:23.772730
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertypes import RgbBg, Sgr

    r = Register()
    r.red = Style(RgbBg(255, 0, 0), Sgr(1))

    assert r.red == "\x1b[48;2;255;0;0m\x1b[1m"
    r.mute()
    assert r.red == ""



# Generated at 2022-06-12 09:50:30.490442
# Unit test for constructor of class Register
def test_Register():

    from sty import fg

    assert fg.is_muted == False
    assert fg.eightbit_call(1) == "\x1b[38;5;1m"
    assert fg.rgb_call(1, 2, 3) == "\x1b[38;2;1;2;3m"
    assert fg.renderfuncs[type(fg.black)](1) == "\x1b[38;5;1m"



# Generated at 2022-06-12 09:50:40.211309
# Unit test for method mute of class Register
def test_Register_mute():

    # Create register
    sty = Register()
    sty.set_renderfunc(RenderType.foreground, lambda x: f"\x1b[38;5;{x}m")
    sty.set_renderfunc(RenderType.rgb_foreground, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    sty.set_eightbit_call(RenderType.foreground)
    sty.set_rgb_call(RenderType.rgb_foreground)

    sty.red = Style(RenderType.foreground(1))
    sty.green = Style(RenderType.foreground(2))
    sty.orange = Style(RenderType.foreground(3, RenderType.rgb_foreground(128, 10, 10)))

# Generated at 2022-06-12 09:50:46.323942
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRender(RenderType):
        pass

    def test_render(x: int) -> str:
        return "42"

    register = Register()
    register.set_renderfunc(TestRender, test_render)

    register.test_style = Style(TestRender(1))

    # Test whether 'test_style' has been set correctly.
    assert register.test_style == "42"

    # Test whether mueting has worked
    register.mute()
    assert register.test_style == ""



# Generated at 2022-06-12 09:50:52.515066
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .tests_styles import create_register_object
    reg = create_register_object()
    assert reg(0) == ansi_256_8bit_color(0)
    assert reg(255) == ansi_256_8bit_color(255)
    assert reg(13, 45, 111) == ansi_256_rgb_color(13, 45, 111)
    assert reg("test") == Style()
    assert reg(1, 2, 3, 4) == ""



# Generated at 2022-06-12 09:51:01.576239
# Unit test for method mute of class Register
def test_Register_mute():

    from ..rendertype import Fg, Bg, Sgr, RgbFg, RgbBg

    # Create new register-object fg with an attribute called "one"
    fg = Register()
    setattr(fg, "one", Style(Fg(1), Sgr(2)))

    # Use mute-method to disable the formatting for the register-object.
    fg.mute()

    # Test if style-attribute "one" is not formatted
    assert(str(fg.one) == "")

    # Restore formatting for register-object.
    fg.unmute()
    assert(str(fg.one) == "\x1b[38;5;1m\x1b[2m")



# Generated at 2022-06-12 09:51:10.418626
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    reg = TestRegister()
    reg.red = Style(EscapeSequence(1))
    reg.green = Style(EscapeSequence(2))

    reg.set_renderfunc(EscapeSequence, lambda *args: f"\x1b[{args[0]}m")
    reg.set_eightbit_call(EscapeSequence)
    reg.set_rgb_call(EscapeSequence)

    assert reg(1) == "\x1b[1m"
    assert reg(42) == "\x1b[42m"
    assert reg(17, 42, 130) == "\x1b[17;42;130m"
    assert reg(42, 17, 130) == "\x1b[42;17;130m"

# Generated at 2022-06-12 09:51:24.588711
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightBit, RgbFg, Sgr, RgbBg
    from .base import Fg, Bg

    styles = [EightBit(), RgbFg(50, 170, 110), Sgr(1), RgbBg(10, 50, 200), Sgr(0)]

    renderfuncs = {
        EightBit: lambda f: f"8bit({f})",
        RgbFg: lambda r, g, b: f"rgb_fg({r}, {g}, {b})",
        RgbBg: lambda r, g, b: f"rgb_bg({r}, {g}, {b})",
        Sgr: lambda f: f"sgr({f})",
    }

    fg = Fg()
    fg.set_eightbit_call(EightBit)
   

# Generated at 2022-06-12 09:51:35.353378
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightbitBg, EightbitFg, Reset

    def fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    def reset() -> str:
        return "\x1b[0m"

    fg_register = Register()
    fg_register.set_renderfunc(EightbitFg, fg)
    fg_register.set_eightbit_call(EightbitFg)
    fg_register.set_renderfunc(Reset, reset)
    fg_register

# Generated at 2022-06-12 09:51:40.149599
# Unit test for constructor of class Register
def test_Register():
    rg1 = Register()
    assert(rg1.is_muted == False)

# Generated at 2022-06-12 09:51:44.857015
# Unit test for constructor of class Register
def test_Register():
    """
    Test Register class constructor.
    """

    # This is the default (initial) value of mute.
    assert not Register().is_muted

    # Assert muted after mute() call.
    registerObject = Register()
    registerObject.mute()
    assert registerObject.is_muted

    # Assert not muted after unmute() call.
    registerObject.unmute()
    assert not registerObject.is_muted


# Generated at 2022-06-12 09:51:46.827934
# Unit test for constructor of class Register
def test_Register():
    register: Register = Register()
    assert isinstance(register, Register)
    assert isinstance(register.renderfuncs, Renderfuncs)


# Generated at 2022-06-12 09:51:57.336816
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a mock-object of the class Register.
    def _render_func(value: int) -> str:
        return "renderfunc" + str(value)

    def _rgb_func(r: int, g: int, b: int) -> str:
        return "rgb" + str(r) + str(g) + str(b)

    mock_register = Register()
    mock_register.renderfuncs = {int: _render_func}
    mock_register.rgb_call = _rgb_func

    # Create a mock style attribute
    mock_style = Style(value="style")
    setattr(mock_register, "mock_style", mock_style)

    # Make sure that return value is the style attribute if a string is passed
    # as argument.

# Generated at 2022-06-12 09:52:07.267833
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create test-register fg.
    fg = Register()

    # Add some styles
    fg.red = Style(value="\x1b[38;2;1;5;10m")
    fg.green = Style(value="\x1b[38;2;1;5;10m")

    # Add some render-functions
    fg.set_rgb_call(lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_eightbit_call(lambda x: f"\x1b[38;5;{x}m")

    # Test calling with 24bit colors
    assert fg(10, 11, 12) == "\x1b[38;2;10;11;12m"

    # Test

# Generated at 2022-06-12 09:52:18.624675
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test register with all possible calls.
    """

    class Rgbfg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    dut = Register()
    dut.set_eightbit_call(Rgbfg)
    dut.set_renderfunc(Rgbfg, lambda x: x)
    dut.set_rgb_call(Rgbfg)
    dut.set_renderfunc(Sgr, lambda x: x)

    dut.ren = Style(Rgbfg(42), Sgr(4))
    dut.mute()

    assert dut("ren") == ""
    assert dut(42) == 42
    assert dut(41, 42, 43) == (41, 42, 43)

# Generated at 2022-06-12 09:52:25.054222
# Unit test for constructor of class Register
def test_Register():
    import pytest

    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    # The default constructor does not accept any arguments
    with pytest.raises(TypeError):
        Register(1)

    # The constructor returns an empty instance of Register
    rg = Register()
    assert isinstance(rg, Register)
    assert not dir(rg)
    assert rg.is_muted is False
    assert rg.eightbit_call is not None
    assert rg.rgb_call is not None

    # A register object can be muted
    rg.mute()
    assert rg.is_muted is True

    # A register object can be unmuted
    rg.unmute()
    assert rg.is_muted is False

    # A default coloring rule is defined as string

# Generated at 2022-06-12 09:52:35.566432
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test __call__() method of Register class.
    """
    import pytest
    from collections import namedtuple
    from sty.colorscheme import _gen_styles_rgb
    from sty import RenderType, Style
    from sty.ansi import Sgr

    rgb_rendertype = RenderType("RgbFg", "RgbBg")
    rgb_func = lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"
    color_call_test = Register()
    color_call_test.set_renderfunc(rgb_rendertype, rgb_func)
    color_call_test.set_eightbit_call(rgb_rendertype)
    color_call_test.set_rgb_call(rgb_rendertype)
    color

# Generated at 2022-06-12 09:52:51.028906
# Unit test for method __call__ of class Register
def test_Register___call__():
    register = Register()

    setattr(register, "test_attr_8bit_1", Style(RgbFg(1, 1, 1), Sgr(1)))
    setattr(register, "test_attr_8bit_2", Style(RgbFg(2, 2, 2), Sgr(2)))
    setattr(register, "test_attr_rgb_1", Style(RgbFg(3, 3, 3), Sgr(3)))
    setattr(register, "test_attr_rgb_2", Style(RgbFg(4, 4, 4), Sgr(4)))

    def eightbit_func(code) -> str:
        return "\x1b[38;" + str(code) + "m"

    def rgb_func(code) -> str:
        return "\x1b[38;"

# Generated at 2022-06-12 09:52:55.707042
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.is_muted == False
    reg.mute()
    assert reg.is_muted == True
    reg.unmute()
    assert reg.is_muted == False

    reg2 = reg.copy()
    assert reg2.is_muted == False
    reg2.mute()
    assert reg2.is_muted == True
    assert reg.is_muted == False

    reg3 = Register()
    reg3.set_renderfunc(RenderType, lambda *args, **kwargs: "RENDER-FUNC")
    assert reg3.renderfuncs[RenderType]() == "RENDER-FUNC"

# Generated at 2022-06-12 09:52:57.805791
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)
    assert not hasattr(r, "red")

# The eightbit register:

# Generated at 2022-06-12 09:53:00.119697
# Unit test for constructor of class Register
def test_Register():
    """Test constructor of class Register."""

    # Create a new instance of Register
    r = Register()

    # Check if new instance is of type Register
    assert isinstance(r, Register)



# Generated at 2022-06-12 09:53:01.343609
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)


# Generated at 2022-06-12 09:53:02.571144
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:53:03.716164
# Unit test for constructor of class Register
def test_Register():
    Register()

# Generated at 2022-06-12 09:53:14.662098
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Set up
    class MockRegister(Register):
        def __init__(self):
            super().__init__()
            self.renderfuncs = {"EightbitFg": lambda x: "EFG", "RgbFg": lambda r, g, b: "RGB"}
            self.is_muted = False
            self.eightbit_call = lambda x: f"8B{x}"
            self.rgb_call = lambda r, g, b: f"RGB{r}{g}{b}"

    mock_register = MockRegister()

    # Assertions
    assert mock_register(42) == "8B42"
    assert mock_register(42, 43, 44) == "RGB424344"
    assert mock_register("green") == "RGB02550"



# Generated at 2022-06-12 09:53:24.346554
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create dummy register for this test.
    class DummyRegister(Register):
        def __init__(self):
            super().__init__()
            self.DummyType = RenderType

        def render_dummy(self, r: int, g: int, b: int) -> str:
            return f"Dummy({r}, {g}, {b})"

        def render_dummy_default(self, a: int, b: int) -> str:
            return f"DummyDefault({a}, {b})"

    # Create dummy register object
    dummy = DummyRegister()

    # Add renderfunc for DummyType
    dummy.set_renderfunc(DummyRegister.DummyType, dummy.render_dummy)

    # Create StylingRuleStyle-objects with one and two arguments

# Generated at 2022-06-12 09:53:29.771996
# Unit test for constructor of class Register
def test_Register():

    def render_type1(value):

        return f"{value}"

    fg = Register()
    fg.set_renderfunc(RenderType, render_type1)

    fg.black = Style(RenderType(30))
    fg.red = Style(RenderType(31))

    assert fg.black == "30"
    assert fg.red == "31"

# Generated at 2022-06-12 09:53:51.615804
# Unit test for constructor of class Register
def test_Register():

    def renderfunc(value: int) -> str:
        # ignore
        return "\x1b[38;5;{}m".format(value)

    def renderfunc2(value: int) -> str:
        # ignore
        return "\x1b[38;2;{};{};{}m".format(value, value, value)

    r = Register()
    r.set_renderfunc(EightBit, renderfunc)
    r.set_renderfunc(RgbFg, renderfunc2)

    r.test = Style(EightBit(42))
    assert r.test == "\x1b[38;5;42m"
    assert r.test.rules[0].value == 42
    assert isinstance(r.test, Style)
    assert isinstance(r.test, str)

    r.test2 = Style

# Generated at 2022-06-12 09:53:53.831556
# Unit test for constructor of class Register
def test_Register():
    a = Register()
    assert isinstance(a, Register), "Register() should return a Register object"

# Generated at 2022-06-12 09:53:54.952406
# Unit test for constructor of class Register
def test_Register():
    r = Register()

    assert isinstance(r, Register)


# Generated at 2022-06-12 09:53:56.670921
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert type(r) is Register


# Generated at 2022-06-12 09:54:06.133900
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .init import init
    from .rendertype import RgbBg

    s: Register = init(RgbBg)

    assert s(201) == s.rgb_call(201)
    assert s(22, 10, 42) == s.rgb_call(22, 10, 42)
    assert s("red") == s.red

    s.mute()

    assert s(201) == ""
    assert s(22, 10, 42) == ""
    assert s("red") == ""

    s.unmute()

    assert s(201) == s.rgb_call(201)
    assert s(22, 10, 42) == s.rgb_call(22, 10, 42)
    assert s("red") == s.red

# Generated at 2022-06-12 09:54:08.691300
# Unit test for constructor of class Register
def test_Register():
    class _Register(Register):
        pass

    r = _Register()

    assert isinstance(r, Register)


# Generated at 2022-06-12 09:54:17.458578
# Unit test for method __call__ of class Register
def test_Register___call__():
    import pytest
    from .colortype import HslFg
    from .definitions import Rs

    register = Register()
    register.set_renderfunc(HslFg, lambda h, s, l: f"{h}.{s}.{l}")
    register.set_eightbit_call(HslFg)
    register.set_rgb_call(HslFg)

    register.test = Style(HslFg(1, 2, 3), Rs())

    assert str(register.test) == "1.2.3"
    assert register(1, 2, 3) == "1.2.3"
    assert register(1) == "1.2.3"
    assert register("test") == "1.2.3"
    assert register("test2") == ""



# Generated at 2022-06-12 09:54:28.749091
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import EightBit, RgbFg, RgbBg, Rgb24bitFg, Rgb24bitBg, Sgr


# Generated at 2022-06-12 09:54:37.990481
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Fg(Register):
        pass

    class Bg(Register):
        pass

    def f1(eightbit):
        assert eightbit == 144
        return ""

    def f2(r, g, b):
        assert r == 10
        assert g == 42
        assert b == 255
        return ""

    fg = Fg()
    bg = Bg()

    fg.set_eightbit_call(f1)
    fg.set_rgb_call(f2)
    fg.set_renderfunc(f1, f1)
    fg.set_renderfunc(f2, f2)

    fg(144)
    fg(10, 42, 255)

    fg.red = Style(f1(1))
    fg.blue = Style(f1(2))

# Generated at 2022-06-12 09:54:49.795283
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRenderType(RenderType):
        """
        This is just a dummy class for testing the method __call__ from the Register class.
        """

        start: str = "test-render-type"

        def __call__(self, *args) -> str:
            return self.start + str(*args)

    class TestRegister(Register):
        """
        This is just a dummy class for testing the method __call__ from the Register class.
        """
        pass

    rt = TestRenderType()
    r = TestRegister()
    r.set_renderfunc(TestRenderType, rt)

    assert r(42) == "test-render-type(42)"
    assert r(33, 44, 55) == "test-render-type(33, 44, 55)"

# Generated at 2022-06-12 09:55:10.762790
# Unit test for constructor of class Register
def test_Register():
    class MyRegister(Register):
        pass

    c = MyRegister()

    assert c.is_muted == False

# Generated at 2022-06-12 09:55:22.285121
# Unit test for constructor of class Register
def test_Register():

    fg = Register()
    assert fg.renderfuncs == {}

    assert fg.is_muted
    assert fg.eightbit_call(0) == ""
    assert fg.rgb_call(0, 0, 0) == ""
    assert fg(42) == ""
    assert fg(42, 255, 42) == ""
    assert fg("red") == ""

    fg.unmute()
    assert not fg.is_muted
    assert fg.eightbit_call(0, 0, 0) == ""
    assert fg.rgb_call(0, 0, 0) == ""
    assert fg(42) == ""
    assert fg(42, 255, 42) == ""
    assert fg("red") == ""


# Generated at 2022-06-12 09:55:29.523466
# Unit test for constructor of class Register
def test_Register():
    """
    Test method for this module.
    """
    r1 = Register()
    rgb = lambda r, g, b: (r, g, b)
    r1.set_renderfunc(RgbFg, rgb)
    r1.set_rgb_call(RgbFg)
    r1.test1 = Style(RgbFg(10, 20, 30))
    r1.test2 = Style(RgbFg(40, 50, 60), Sgr(1))
    assert r1.test1 == (10, 20, 30)
    assert r1.test2 == ((40, 50, 60), True)
    assert r1.test2 == (40, 50, 60, True)
    assert callable(r1)


# Generated at 2022-06-12 09:55:30.877296
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-12 09:55:35.574124
# Unit test for constructor of class Register
def test_Register():
    reg = Register()

    assert isinstance(reg.renderfuncs, dict)
    assert reg.is_muted is False
    assert callable(reg.eightbit_call)
    assert callable(reg.rgb_call)


# Generated at 2022-06-12 09:55:37.517222
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    reg.set_renderfunc(RenderType, lambda x: x)
    reg.test = Style(RenderType())
    assert str(reg.test) == "test"



# Generated at 2022-06-12 09:55:46.545531
# Unit test for constructor of class Register
def test_Register():

    from .rendertypes import Ansi, RgbFg, Sgr

    r1 = Register()
    assert str(r1()) == ""

    r1.set_eightbit_call(type(Ansi()))
    assert str(r1(111)) == "\x1b[38;5;111m"

    r1.set_rgb_call(type(RgbFg()))
    assert str(r1(1, 5, 9)) == "\x1b[38;2;1;5;9m"

    r1.bold = Style(value="\x1b[1m", rules=(Sgr(1),))
    assert str(r1.bold) == "\x1b[1m"
    assert r1.bold.rules == (Sgr(1),)


# Generated at 2022-06-12 09:55:48.635915
# Unit test for constructor of class Register
def test_Register():
    """
    Creates an instance of the Register class and checks that all attributes
    are correctly set.
    """
    reg = Register()

    assert isinstance(reg, Register)
    assert reg.is_muted == False

# Generated at 2022-06-12 09:55:51.115626
# Unit test for constructor of class Register
def test_Register():
    """
    Check if constructor of class Register works as expected.
    """
    # TODO: Add test
    pass



# Generated at 2022-06-12 09:55:52.842132
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-12 09:56:51.815998
# Unit test for method unmute of class Register
def test_Register_unmute():
    myregister = Register()
    myregister.green = Style(Sgr(1))
    myregister.mute()
    myregister.unmute()
    assert isinstance(myregister.green, Style)

# Generated at 2022-06-12 09:56:55.200258
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    register = Register()
    register.white = Style(RgbFg(1,1,1))

    register.set_rgb_call(RgbFg)

    assert register(1,1,1) == register.white



# Generated at 2022-06-12 09:57:02.027737
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import Sgr

    # We want to check if this class can be instantiated without raising an error.
    R = Register()

    assert isinstance(R, Register)

    # Basic test if the render function stuff is working.
    R.set_renderfunc(Sgr, lambda x: "test " + str(x))

    R.bold = Style(Sgr(1))

    assert str(R.bold) == "test 1"

    R.mute()

    assert str(R.bold) == ""

    R.unmute()

    assert str(R.bold) == "test 1"

    assert isinstance(R.as_dict(), dict)
    assert isinstance(R.as_namedtuple(), NamedTuple)



# Generated at 2022-06-12 09:57:10.404175
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: "")
    r.set_renderfunc(RgbBg, lambda r, g, b: "")

    default_rgb_call = r.rgb_call
    default_eightbit_call = r.eightbit_call

    r.set_rgb_call(RgbFg)
    assert r.rgb_call == default_eightbit_call

    r.set_eightbit_call(RgbBg)
    assert r.eightbit_call == default_rgb_call


# Generated at 2022-06-12 09:57:20.357780
# Unit test for method mute of class Register
def test_Register_mute():

    from .render import render_rgb, render_sgr

    register = Register()

    register.set_renderfunc(RenderType.RGB_FG, render_rgb)
    register.set_renderfunc(RenderType.SGR, render_sgr)

    register.orange = Style(RenderType.RGB_FG(1, 5, 10), RenderType.SGR(1))

    assert str(register.orange) == "\x1b[38;2;1;5;10m\x1b[1m"
    assert str(register.orange) != ""
    assert str(register.orange) != " "

    register.mute()

    assert str(register.orange) == ""
    assert str(register.orange) != "\x1b[38;2;1;5;10m\x1b[1m"
   

# Generated at 2022-06-12 09:57:29.965079
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .ansi import RgbBg
    from .effects import Sgr, Bold

    # Prepare register
    test_reg = Register()
    test_reg.set_renderfunc(RgbBg, lambda x, y, z: f"\x1b[48;2;{x};{y};{z}m")
    test_reg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    test_reg.set_renderfunc(Bold, lambda: f"\x1b[1m")

    # Test style
    test_reg.orange = Style(RgbBg(1, 5, 10), Sgr(1))
    expected = "\x1b[48;2;1;5;10m\x1b[1m"

# Generated at 2022-06-12 09:57:36.512903
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from sty import ef

    class TestRenderType(RenderType):
        pass

    test_register = Register()

    test_renderfunc = lambda *x: "Test"

    test_register.set_renderfunc(TestRenderType, test_renderfunc)

    testrule = TestRenderType()

    test_style = Style(testrule)

    test_register.new_style = test_style

    result = str(test_register.new_style)

    expected = "Test"

    assert result == expected

# Generated at 2022-06-12 09:57:43.869523
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class TestRegister(Register):
        pass

    class TestRenderType(RenderType):
        pass

    class TestRenderType2(RenderType):
        pass

    def test_renderfunc(arg1, arg2):
        return "test" + str(arg1 + arg2)

    r = TestRegister()
    r.set_renderfunc(TestRenderType, test_renderfunc)

    s = Style(TestRenderType(1, 2), TestRenderType2())
    s2: Style = Style(*s.rules, value="test3")

    assert s.rules == s2.rules
    assert s == s2

    def test_renderfunc2(arg1, arg2):
        return "test" + str(arg1 - arg2)

    r.set_renderfunc(TestRenderType, test_renderfunc2)
    s2

# Generated at 2022-06-12 09:57:52.055250
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertypes import RgbBg, RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    r.set_eightbit_call(RgbBg)

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r(0, 0, 255) == "\x1b[48;2;0;0;255m"

    assert r(255, 0, 0) == r.red
    assert r(0, 0, 255) == r.blue

# Generated at 2022-06-12 09:58:00.832689
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Create example for Style with Sgr and no value
    rule_1: Sgr = Sgr(1)
    style_1: Style = Style(rule_1)
    assert style_1.rules[0] == rule_1
    assert str(style_1) == ""

    # Create example for Style with no params 
    style_2: Style = Style()
    assert style_2.rules == ()
    assert str(style_2) == ""

    # Create example for Style with Sgr and RgbFg and value
    rule_1: Sgr = Sgr(1)
    rule_2: RgbFg = RgbFg(10, 11, 12)

# Generated at 2022-06-12 09:59:13.952721
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import fg, bg, ef, rs, Sgr, RgbFg, RgbBg, Fx

    reg = Register()

    reg.renderfuncs.update({Sgr: lambda x: f"SGR({x})", RgbFg: lambda r, g, b: f"RgbFg({r}, {g}, {b})", RgbBg: lambda r, g, b: f"RgbBg({r}, {g}, {b})", Fx: lambda x: f"Fx({x})"})

    reg.myattr = Style(fg.orange, Sgr(1))

    assert isinstance(reg.myattr, Style)
    assert reg.myattr.value == "RgbFg(1, 5, 10)SGR(1)"

# Generated at 2022-06-12 09:59:19.362319
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    from .render import render_rgb_fg, render_rgb_bg

    r = Register()
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(RgbFg, render_rgb_fg)

    r.red = Style(RgbFg(255, 0, 0))

    assert r(255, 0, 0) == r.red, "set_rgb_call() fails on RgbFg()"

    r.set_rgb_call(RgbBg)
    r.set_renderfunc(RgbBg, render_rgb_bg)

    r.yellow = Style(RgbBg(255, 255, 0))

    assert r(255, 255, 0) == r.yellow

# Generated at 2022-06-12 09:59:29.202260
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test method __new__ of class Style.
    """
    from .rendertype import RgbBg, RgbFg, Sgr

    rule_1 = Sgr(1, 3)
    rule_2 = RgbBg(1, 2, 3)
    rule_3 = RgbFg(4, 5, 6)

    expected_val = "\x1b[38;2;4;5;6m\x1b[48;2;1;2;3m\x1b[1;3m"

    s = Style(rule_1, rule_2, rule_3)

    assert s == expected_val
    assert type(s) is Style
    assert isinstance(s, str)
    assert s.rules == (rule_1, rule_2, rule_3)



# Generated at 2022-06-12 09:59:32.523963
# Unit test for constructor of class Style
def test_Style():
    style = Style(value="test")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "test"

    style = Style(value="test", rules=[True])
    assert len(style.rules) == 1
    assert style.rules[0] is True
    assert style == "test"

# Generated at 2022-06-12 09:59:37.903790
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for method unmute of class Register.
    """
    class R(Register):
        pass

    r = R()
    setattr(r, "a", Style(RgbFg(1, 1, 1), Sgr(1)))
    r.mute()
    r.unmute()
    assert str(getattr(r, "a")) == "\x1b[38;2;1;1;1m\x1b[1m"

# Generated at 2022-06-12 09:59:45.072574
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Test renderfunc
    renderfunc = lambda x: f"\x1b[38;5;{x}m"

    # Create register
    reg: Register = Register()

    # Add render type to register
    reg.set_renderfunc(EightbitFg, renderfunc)

    # Assign style
    reg.blue = Style(EightbitFg(12))

    # Style should be rendered
    assert reg.blue == "\x1b[38;5;12m"

    # Now we mute the register
    reg.mute()

    # The style should not be rendered
    assert reg.blue != "\x1b[38;5;12m"