

# Generated at 2022-06-24 04:49:25.236301
# Unit test for constructor of class Register
def test_Register():
    r1 = Register()
    r2 = r1.copy()

    assert r1 is not r2
    assert r1.__dict__ is not r2.__dict__

    assert r1.renderfuncs is not r2.renderfuncs



# Generated at 2022-06-24 04:49:34.358475
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from . import RenderType
    from .rendertypes import RgbFg, RgbBg, Sgr, Ega, Truecolor

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Truecolor, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.green = Style(RgbFg(0, 255, 0))
    r.set_eightbit_call(Truecolor)
   

# Generated at 2022-06-24 04:49:39.846194
# Unit test for method copy of class Register
def test_Register_copy():

    # This test is not really satisfying. It is a bit of a dirty hack.
    # It only checks if the attributes names are passed on to the new
    # object. We should do more checks here.

    # Prepare
    r = Register()
    r.attr1 = "test"

    # Do
    r2 = r.copy()

    # Assert
    assert hasattr(r, "attr1")
    assert hasattr(r2, "attr1")

# Generated at 2022-06-24 04:49:45.158075
# Unit test for method copy of class Register
def test_Register_copy():
    """
    This test checks, whether or not the method copy of Register works as expected.
    """

    class TestRegister(Register):
        pass

    foo = TestRegister()

    # Add attributes to register-object.
    foo.test = "test"
    foo.test2 = Style(foo.test, value="test2")

    # Make a copy of register-object.
    bar = foo.copy()

    assert foo.test == bar.test
    assert foo.test2 == bar.test2

# Generated at 2022-06-24 04:49:47.287513
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    RegisterTest = RegisterTestCase()
    RegisterTest.test_set_eightbit_call()


# Generated at 2022-06-24 04:49:49.493308
# Unit test for method __new__ of class Style
def test_Style___new__():

    tmp = Style("a", "b")
    assert isinstance(tmp, Style)
    assert isinstance(tmp, str)


# Generated at 2022-06-24 04:49:53.232371
# Unit test for method mute of class Register
def test_Register_mute():
    import sty
    fg = sty.fg

    fg.black = Style(fg.black, fg.red)
    assert str(fg.black) == '\x1b[38;5;0m\x1b[31m'

    fg.mute()
    assert str(fg.black) == ''



# Generated at 2022-06-24 04:50:01.280475
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestRendertype(RenderType):
        pass

    def renderfunc(a1: int) -> str:
        return f"ABC{str(a1)}"

    register = Register()

    register.red = Style(TestRendertype(3))

    register.set_renderfunc(TestRendertype, renderfunc)
    assert str(register.red) == "ABC3"

    register.set_eightbit_call(TestRendertype)
    assert register(3) == "ABC3"

# Unit Test for method mute of class Register

# Generated at 2022-06-24 04:50:08.343929
# Unit test for constructor of class Register
def test_Register():

    r = Register()

    r.set_renderfunc(RenderType, lambda *args: 'foo')
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r(14) == 'foo'
    assert r(100,100,100) == 'foo'

    assert r.eightbit_call(144) == 'foo'
    assert r.rgb_call(100,100,100) == 'foo'

    r.foo = Style(RenderType(), RenderType())
    assert r.foo == 'foofoo'

    r.mute()
    assert r.foo == ''

    r.unmute()
    assert r.foo == 'foofoo'

    assert r.is_muted == False
    assert r.eightbit_call == r.render

# Generated at 2022-06-24 04:50:13.641257
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import Bg, RenderType

    fg1 = Register()
    fg1.grey = Style(Bg(240))

    fg2 = fg1.copy()

    assert fg1.grey == fg2.grey

# Generated at 2022-06-24 04:50:19.670277
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    reg1 = Register()
    reg1.renderfuncs.update({int: lambda x: str(x)})
    reg1.foo = Style(1, 2)
    assert reg1.foo == "12"
    assert reg1.foo.rules == (1, 2)


# Generated at 2022-06-24 04:50:28.358485
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for method unmute of class Register.
    """
    import pytest
    from .rendertype import Bold, RgbFg
    from .ansi import REGISTERS_8BIT, REGISTERS_24BIT

    r1 = Register()
    r1.test_style = Style(RgbFg(1, 2, 3), Bold())
    r1.test_style_8bit = Style(REGISTERS_8BIT.black, Bold())
    r1.test_style_24bit = Style(REGISTERS_24BIT.black, Bold())

    r1.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

# Generated at 2022-06-24 04:50:33.119203
# Unit test for method copy of class Register
def test_Register_copy():
    a = Register()
    a.fg = Style(RgbFg(1, 2, 3))
    a.bg = Style(RgbBg(4, 5, 6))
    b = a.copy()
    assert(a.fg == b.fg)
    assert(a.bg == b.bg)

# Generated at 2022-06-24 04:50:39.481790
# Unit test for constructor of class Style
def test_Style():
    assert Style()
    assert Style(RgbFg(1, 2, 3), RgbBg(4, 5, 6))
    assert Style(RgbFg(1, 2, 3), value="\x1b[48;2;4;5;6m")
    assert Style(RgbFg(1, 2, 3), value="\x1b[48;2;4;5;6m") == "\x1b[48;2;4;5;6m\x1b[38;2;1;2;3m"


# Generated at 2022-06-24 04:50:42.593319
# Unit test for constructor of class Register
def test_Register():
    r = Register()

# Generated at 2022-06-24 04:50:47.762851
# Unit test for method __new__ of class Style
def test_Style___new__():
    style: Style = Style(value="\x1b[38;2;1;5;10m\x1b[1m")  # type: ignore
    assert style == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-24 04:50:52.614854
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from . import rgb

    reg = Register()
    assert reg.rgb_call(0,0,0) == None

    reg.set_rgb_call(rgb.RgbFg)
    assert reg.rgb_call(0,0,0) == "\x1b[38;2;0;0;0m"

# Generated at 2022-06-24 04:50:59.231335
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.test = Style(value="\x1b[42m")
    r.test2 = Style(value="\x1b[43m")
    r.test3 = Style(value="\x1b[44m")

    assert r.as_dict() == {"test": "\x1b[42m", "test2": "\x1b[43m", "test3": "\x1b[44m"}



# Generated at 2022-06-24 04:51:05.006979
# Unit test for constructor of class Style
def test_Style():
    s = Style()
    assert len(s.rules) == 0
    assert str(s) == ""

    s = Style("a", "b", "c", value="xx")
    assert len(s.rules) == 3
    assert str(s) == "xx"

    s = Style("a")
    assert len(s.rules) == 1
    assert s.rules[0] == "a"



# Generated at 2022-06-24 04:51:13.163119
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .ansi import Ansi, RgbFg, EightbitFg

    an = Ansi()
    assert an.fg(84) == "\x1b[38;5;84m"
    assert an.fg(10, 42, 255) == "\x1b[38;2;10;42;255m"

    an.fg.set_eightbit_call(EightbitFg)
    an.fg.set_rgb_call(RgbFg)

    assert an.fg(84) == "\x1b[38;2;75;38;112m"
    assert an.fg(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-24 04:51:17.336148
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.green = Style(RgbFg(0, 255, 0))
    r1 = r.copy()
    assert r1 is not r
    assert r1.green is not r.green
    assert str(r1.green) == str(r.green)

# Generated at 2022-06-24 04:51:22.524749
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg = Register()
    setattr(reg, "blue", Style("", RgbFg(44, 55, 66)))
    setattr(reg, "red", Style("", RgbFg(11, 22, 33)))
    assert reg.as_namedtuple().blue == ""
    assert reg.as_namedtuple().red == ""
    assert reg.blue == ""
    assert reg.red == ""

# Generated at 2022-06-24 04:51:32.901969
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Create a fresh Register and set two attributes.
    r = Register()
    r.green = Style(RgbFg(1, 2, 3))
    r.red = Style(RgbFg(3, 2, 1))

    # Create a copy of the Register.
    r_copy = r.as_namedtuple()

    # Check if the copy is a namedtuple and check if it has the same values
    assert isinstance(r_copy, NamedTuple)

    assert r_copy.green == Style(RgbFg(1, 2, 3))
    assert r_copy.red == Style(RgbFg(3, 2, 1))

    # Check if the two registers are not the same.
    assert r is not r_copy

    # Create a copy of the Register.
    r_copy2 = r.copy

# Generated at 2022-06-24 04:51:37.189555
# Unit test for method copy of class Register
def test_Register_copy():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.foo = Style(Sgr(1))
            self.bar = Style(Sgr(2))
            self.foobar = Style(Sgr(1), Sgr(2))

    reg = TestRegister()
    reg_copy = reg.copy()
    assert reg_copy.foo != reg.foo
    assert reg_copy.bar != reg.bar
    assert reg_copy.foobar != reg.foobar

# Generated at 2022-06-24 04:51:48.564463
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class RgbFg: pass
    class RgbBg: pass
    class RgbBoth: pass


    register = Register()

    register.set_renderfunc(RgbFg, lambda r, g, b: ";".join([str(r), str(g), str(b)]))
    register.set_renderfunc(RgbBg, lambda r, g, b: "*".join([str(r), str(g), str(b)]))
    register.set_renderfunc(RgbBoth, lambda r, g, b: "+".join([str(r), str(g), str(b)]))

    register.set_rgb_call(RgbFg)
    register.set_eightbit_call(RgbBg)

    register.red = Style(RgbFg(1, 5, 2))



# Generated at 2022-06-24 04:51:52.936433
# Unit test for method copy of class Register
def test_Register_copy():
    register = Register()
    register.testprop = Style("test")
    assert "test" in str(register.testprop)
    register2 = register.copy()
    register.testprop = Style("")
    assert "test" in str(register2.testprop)



# Generated at 2022-06-24 04:52:01.100749
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg

    # Create a new register-object and add styles to it.
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))

    # Make a copy of it.
    r2 = r.copy()

    # Check if copy has the same color as the original object.
    assert r2.red == r.red

    # Check if copy has its own attribute 'rules'
    assert r2.red.rules is not r.red.rules

    # Check if copy has its own attribute 'rules'
    assert id(r2) != id(r)



# Generated at 2022-06-24 04:52:02.751514
# Unit test for method __new__ of class Style
def test_Style___new__():

    Style("a", "b")



# Generated at 2022-06-24 04:52:04.705821
# Unit test for constructor of class Register
def test_Register():
    r = Register()

if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-24 04:52:13.641521
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertypes import Eightbit, RgbFg

    # Create two registers with identical content.
    r1 = Register()
    r2 = Register()

    r1.set_renderfunc(Eightbit, lambda code: "")
    r2.set_renderfunc(Eightbit, lambda code: "")

    r1.set_renderfunc(RgbFg, lambda r, g, b: "")
    r2.set_renderfunc(RgbFg, lambda r, g, b: "")

    r1.red = Style(Eightbit(41))
    r2.red = Style(Eightbit(41))

    r1.maroon = Style(RgbFg(180, 0, 0))
    r2.maroon = Style(RgbFg(180, 0, 0))

    # 1. Check if copies

# Generated at 2022-06-24 04:52:19.114627
# Unit test for constructor of class Register
def test_Register():
    r = Register()

    assert len(r.renderfuncs) == 0, "At initialization a Register-object should have no renderfuncs."
    assert r.is_muted == False, "At initialization a Register-object should not be muted."
    assert r.eightbit_call == r.rgb_call, "At initialization a Register-object has the same renderfunc for 8bit and 24bit."

# Generated at 2022-06-24 04:52:29.418123
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbEf(RenderType):
        """
        RGB effect (for a given red, green and blue value).
        """

        def render(self, r, g, b) -> str:
            return f"\x1b[38;2;{r};{g};{b}m"
    class Sgr(RenderType):
        """
        SGR - Select Graphic Rendition (Modes).
        """


# Generated at 2022-06-24 04:52:35.505672
# Unit test for method copy of class Register
def test_Register_copy():
    from .register import fg

    r1 = fg.copy()
    assert r1 is not fg
    assert r1.red is not fg.red
    assert r1.blue is not fg.blue
    assert r1.eightbit_call is not fg.eightbit_call
    assert r1.rgb_call is not fg.rgb_call

# Generated at 2022-06-24 04:52:44.482947
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    import sty

    class C:
        pass

    # Create register
    r = Register()

    # Add new entry
    r.set_renderfunc(C, lambda: "C")

    # Add new entry, which is supposed to override former entry
    r.set_renderfunc(C, lambda: "newC")

    # Add two new entries
    r.set_renderfunc(sty.Sgr, lambda: "SGR")
    r.set_renderfunc(sty.RgbBg, lambda: "RGBBG")

    # Main test
    assert r.renderfuncs == {C: lambda: "newC", sty.Sgr: lambda: "SGR", sty.RgbBg: lambda: "RGBBG"}



# Generated at 2022-06-24 04:52:54.225521
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .ansi import fg, bg
    from .color import RgbFg, SetFg, RgbBg, SetBg

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert bg.blue == "\x1b[48;2;0;0;255m"

    assert fg.as_dict() == {"red": "\x1b[38;2;255;0;0m"}
    assert bg.as_dict() == {"blue": "\x1b[48;2;0;0;255m"}

    # test dynamic style
    fg.color = Style(fg=RgbFg(10, 20, 40))
    fg.color = Style(fg=SetFg(34))


# Generated at 2022-06-24 04:53:00.731828
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import EightbitBg, EightbitFg, Sgr

    # Create new register for Unit tests
    register = Register()

    # Define render functions for Unit tests
    def test_render(code: int) -> str:
        if code > 101 or code < 0:
            raise ValueError("code must be in [0;101]")
        return "\u001b[48;5;" + f"{code}" + "m"

    register.set_renderfunc(EightbitBg, test_render)

    def test_render(code: int) -> str:
        if code > 101 or code < 0:
            raise ValueError("code must be in [0;101]")
        return "\u001b[38;5;" + f"{code}" + "m"


# Generated at 2022-06-24 04:53:11.080833
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from ..rendertype import RgbBg, RgbFg

    # Setup register
    reg = Register()
    bg = RgbBg(255, 255, 255)
    fg = RgbFg(255, 255, 255)

    # Setup render functions
    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    reg.set_rgb_call(RgbFg)
    reg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-24 04:53:15.289440
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    style = Style(RgbFg(10, 20, 30))
    register = Register()
    register.test = style
    assert register.as_dict() == {"test": "\u001b[38;2;10;20;30m"}

# Generated at 2022-06-24 04:53:23.671276
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define rendertype
    class TestRenderType(RenderType):
        args = None

    # Create object
    reg = Register()

    # Define test function
    def func1(x, y):
        return "TestString"

    # Add renderfunc
    reg.set_renderfunc(TestRenderType, func1)

    # Check
    assert reg.renderfuncs[TestRenderType] == func1

    # Define test function
    def func2(x, y):
        return "AnotherTestString"

    # Add renderfunc
    reg.set_renderfunc(TestRenderType, func2)

    # Check
    assert reg.renderfuncs[TestRenderType] == func2


# Generated at 2022-06-24 04:53:28.819144
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .rendertype import Sgr

    fg = Register()
    fg.red = Style(Sgr(1), Sgr(31))

    fg.as_dict() == {"red": "\x1b[1m\x1b[31m"}


# Generated at 2022-06-24 04:53:35.957293
# Unit test for method mute of class Register
def test_Register_mute():

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.red = Style(RgbFg(255, 0, 0))
    assert str(r.red) == "\x1b[38;2;255;0;0m"
    r.mute()
    assert r.is_muted == True
    r.red = Style(RgbFg(255, 0, 0))
    assert str(r.red) == ""



# Generated at 2022-06-24 04:53:40.155055
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg
    from .sty import fg

    fg.orangered = Style(RgbFg(255, 69, 0))

    assert fg.orangered == str(fg.orangered)
    assert isinstance(fg.orangered, Style)
    assert fg.orangered == "\x1b[38;2;255;69;0m"

# Generated at 2022-06-24 04:53:51.312193
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Mock:

        def __init__(self):
            self.renderfuncs = {int: lambda x: x}

    fg = Register()
    bg = Register()
    ef = Register()
    rs = Register()

    fg.set_eightbit_call(int)
    bg.set_eightbit_call(int)
    ef.set_eightbit_call(int)
    rs.set_eightbit_call(int)

    fg.test = 1
    bg.test = 2
    ef.test = 3
    rs.test = 4

    result = [fg("test"), bg("test"), ef("test"), rs("test")]


# Generated at 2022-06-24 04:53:58.832128
# Unit test for constructor of class Style
def test_Style():
    """
    Test if class Style is defined properly.
    """
    from .rendertype import Sgr

    test_style1 = Style(Sgr(1), "foo")
    test_style2 = Style(Sgr(1))

    assert isinstance(test_style1, Style)
    assert isinstance(test_style2, Style)

    assert test_style1.rules[0] == Sgr(1)
    assert test_style1.value == "foo"

    assert test_style2.rules[0] == Sgr(1)
    assert test_style2.value == ""

# Generated at 2022-06-24 04:54:05.325029
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty.rendertype import Sgr

    register = Register()
    register.test1 = Style(Sgr(1))
    register.test2 = Style(Sgr(2))
    register.test3 = Style(Sgr(3))

    assert register.as_dict() == {"test1": "\x1b[1m", "test2": "\x1b[2m", "test3": "\x1b[3m"}



# Generated at 2022-06-24 04:54:15.024746
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    This method executes a unit test for the method set_renderfunc of the Register class.
    """
    # We use this dummy-register for the test:
    class DummyRegister(Register):
        """
        The method set_renderfunc of a register is the same for all register-types. We
        therefore use a dummy-register for testing purposes.
        """

        def __init__(self, renderfuncs: Renderfuncs):
            super().__init__()
            self.renderfuncs = renderfuncs

    # This is the set of renderfuncs we use for testing purposes.
    RenderFuncSet = NamedTuple(
        "RenderFuncSet", [("a", Callable), ("b", Callable), ("c", Callable)]
    )

    # We create two instances of the dummy-register: one we use as a source

# Generated at 2022-06-24 04:54:16.641495
# Unit test for constructor of class Style
def test_Style():
    rules = tuple(Style("test").rules)

    assert isinstance(rules, tuple)
    assert len(rules) == 0



# Generated at 2022-06-24 04:54:20.520400
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    s = Register()
    s.set_renderfunc(RgbFg, lambda *args: f"{args}")
    assert str(s.red) == "((10, 0, 0),)"
    assert str(s.green) == "((0, 10, 0),)"
    assert str(s.blue) == "((0, 0, 10),)"
    assert str(s.magenta) == "((10, 0, 10),)"

# Generated at 2022-06-24 04:54:23.837248
# Unit test for method mute of class Register
def test_Register_mute():
    class TestRegister(Register):
        yellow = Style(RgbFg(10, 255, 100))
    r = TestRegister()
    assert str(r.yellow) == "\x1b[38;2;10;255;100m"
    r.mute()
    assert str(r.yellow) == ""


# Generated at 2022-06-24 04:54:34.694843
# Unit test for method __new__ of class Style
def test_Style___new__():
    class TestRenderType(RenderType):
        pass

    test_rt1 = TestRenderType(1)
    test_rt2 = TestRenderType(2)

    test_style1 = Style(test_rt1, test_rt2)
    assert isinstance(test_style1, Style)
    assert isinstance(test_style1, str)
    assert test_style1.rules == (test_rt1, test_rt2)

    test_style2 = Style(test_style1, test_rt1, value="Sty")
    assert isinstance(test_style2, Style)
    assert isinstance(test_style2, str)
    assert test_style2.rules == (test_rt1, test_rt2, test_rt1)
    assert str(test_style2) == "Sty"



# Generated at 2022-06-24 04:54:40.215472
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()

    # Create test styles
    r.white = Style(RgbFg(255, 255, 255))
    r.black = Style(RgbFg(0, 0, 0))

    # Assert that namedtuple has the correct values
    assert hasattr(r.as_namedtuple(), "white")
    assert r.as_namedtuple().white == str(r.white)
    assert r.as_namedtuple().black == str(r.black)

# Generated at 2022-06-24 04:54:45.124798
# Unit test for method __new__ of class Style
def test_Style___new__():
    
    # condition: input is a string
    assert isinstance(Style("hello world"), Style) # True
    assert isinstance(Style("hello world"), str) # True
    assert str(Style("hello world")) == "hello world" # True

    # condition: input is a Style
    assert isinstance(Style(Style("hello world")), Style) # True
    assert isinstance(Style(Style("hello world")), str) # True
    assert str(Style(Style("hello world"))) == "hello world" # True

    # condition: input is a RenderType
    class CustomType(RenderType):
        def __init__(self):
            super(CustomType, self).__init__()
            self.args = ("hello", "world")
    assert isinstance(Style(CustomType()), Style) # True

# Generated at 2022-06-24 04:54:54.998677
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test that the unmute() method works properly.

    """
    class TestClass1(RenderType):
        def __init__(self, arg1):
            self.args = (arg1,)

    class TestClass2(RenderType):
        def __init__(self, arg1, arg2):
            self.args = (arg1, arg2)

    def test_func1(arg):
        return "1{}".format(arg)

    def test_func2(arg1, arg2):
        return "2{}{}".format(arg1, arg2)

    test_register = Register()
    test_register.test = Style(TestClass1(1), TestClass2(2, 3))

    test_register.set_renderfunc(TestClass1, test_func1)
    test_register.set

# Generated at 2022-06-24 04:55:04.719469
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import sty
    sty.style.register(fg="blue", bg="red", ef="yellow")
    sty.style.register(r="green", g="white")
    assert isinstance(sty.style.fg.as_namedtuple(), namedtuple)
    assert isinstance(sty.style.bg.as_namedtuple(), namedtuple)
    assert isinstance(sty.style.ef.as_namedtuple(), namedtuple)
    assert isinstance(sty.style.rs.as_namedtuple(), namedtuple)
    assert isinstance(sty.style.r.as_namedtuple(), namedtuple)
    assert isinstance(sty.style.g.as_namedtuple(), namedtuple)

# Generated at 2022-06-24 04:55:06.472348
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)



# Generated at 2022-06-24 04:55:12.182974
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestRegister(Register):
        pass

    class TestRenderType(RenderType):
        pass

    def renderfunc(value: int):
        return '<' + str(value) + '>'

    test_register = TestRegister()
    test_rendertype = TestRenderType()

    test_register.set_renderfunc(test_rendertype, renderfunc)

    assert test_register.renderfuncs[test_rendertype] == renderfunc



# Generated at 2022-06-24 04:55:20.201575
# Unit test for method __new__ of class Style
def test_Style___new__():

    class Foo(RenderType):
        pass

    Foo.__init__ = lambda self, value: [value]

    f1 = Foo(1)
    f2 = Foo(2)
    s1 = Style(f1, f2)

    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1.rules == (f1, f2)



# Generated at 2022-06-24 04:55:26.398180
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from . import rendertype as rtype
    from . import render as render

    # Setup Sty
    sty = render.Sty(mu=~True)

    # Create a new register.
    new_register = Register()

    # Set the renderfunc for Sgr-attribute in the new register.
    new_register.set_renderfunc(rtype.Sgr, render._sgr_render)

    # Set the rendertype for Eightbit-calls.
    new_register.set_eightbit_call(rtype.Sgr)

    # Configure dummy style
    new_register.style1 = Style(rtype.Sgr(1, 2, 3), rtype.Sgr(4, 5, 6))

    # Run call

# Generated at 2022-06-24 04:55:30.318354
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Tests the method as_namedtuple of class Register.
    """
    from .style import ef, fg, bg
    assert isinstance(fg.as_namedtuple(), namedtuple)
    assert isinstance(bg.as_namedtuple(), namedtuple)
    assert isinstance(ef.as_namedtuple(), namedtuple)


# Generated at 2022-06-24 04:55:40.234248
# Unit test for method __new__ of class Style
def test_Style___new__():
    class Sty1(RenderType):
        __render_type_name__ = "sty1"

    class Sty2(RenderType):
        __render_type_name__ = "sty2"

    sty1 = Sty1(1, 1)
    sty2 = Sty2(2, 2)
    sty_a = Style(sty1, sty2)

    sty_b = Style(sty2)

    sty_c = Style(sty_a)

    sty_d = Style(sty1, sty_b, sty_c)

    sty_e = Style(sty_d)

    sty_f = Style(sty_e)

    assert sty_d.rules[0] is sty1
    assert sty_d.rules[1] is sty_b
    assert sty_d.rules[2] is sty_c

    assert sty_e

# Generated at 2022-06-24 04:55:50.384559
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    eightbit = RenderType()
    rgb = RenderType()
    rgba = RenderType()

    def eightbit_func(code) -> str:
        return f"eightbit({code})"

    def rgb_func(r, g, b) -> str:
        return f"rgb({r}, {g}, {b})"

    def rgba_func(r, g, b, a) -> str:
        return f"rgba({r}, {g}, {b}, {a})"

    r = TestRegister()
    r.set_renderfunc(eightbit, eightbit_func)
    r.set_renderfunc(rgb, rgb_func)
    r.set_renderfunc(rgba, rgba_func)

# Generated at 2022-06-24 04:55:51.294003
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    pass

# Generated at 2022-06-24 04:56:01.069689
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # set up a basic register
    attr = {
        "red": "rgb(255, 0, 0)",
        "green": "rgb(0, 255, 0)",
        "blue": "rgb(0, 0, 255)",
    }

    reg = Register()
    for name in attr:
        setattr(reg, name, attr[name])

    # execute the code to be tested
    nt = reg.as_namedtuple()

    # check that the attributes of the returned namedtuple are
    # equal to the attributes of the register

    for name in attr:
        assert getattr(nt, name) == attr[name]

# Generated at 2022-06-24 04:56:07.540695
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype.ansi256 import Ansi256Fg
    from .rendertype.sgr import Sgr
    from .rendertype.truecolor import TrueColorFg

    sgr = Sgr(2)
    ansi256 = Ansi256Fg(1)
    truecolor = TrueColorFg(1, 2, 3)

    style1 = Style(sgr, ansi256)
    style2 = Style(sgr, truecolor)

    assert style1.rules == (sgr, ansi256)
    assert style2.rules == (sgr, truecolor)

# Generated at 2022-06-24 04:56:17.833856
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    def create_renderfunc1(a: str):
        def renderfunc1(arg, *args, **kwargs):
            return a + str(arg)

        return renderfunc1

    def create_renderfunc2(a: str, b: str):
        def renderfunc2(arg, *args, **kwargs):
            return a + str(arg) + b

        return renderfunc2

    MyRenderType1 = RenderType("MyRenderType1")
    MyRenderType2 = RenderType("MyRenderType2", args=["arg1"])
    MyRenderType3 = RenderType("MyRenderType3", args=["arg1", "arg2"])
    MyRenderType4 = RenderType("MyRenderType4", args=["arg1", "arg2"])

# Generated at 2022-06-24 04:56:22.327704
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test method set_rgb_call of class Register.
    """

    def test_func(*args):
        return f"test_func{args}"

    fg = Register()
    fg.set_renderfunc(RgbFg, test_func)
    fg.set_rgb_call(RgbFg)

    assert fg(10, 42, 56) == "test_func(10, 42, 56)"


# Generated at 2022-06-24 04:56:27.580094
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .style import DEFAULT

    test_reg = DEFAULT.copy()

    test_reg.foo = Style(RgbFg(10, 20, 30))

    assert test_reg.foo == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-24 04:56:33.314357
# Unit test for constructor of class Style
def test_Style():
    """
    >>> styled = Style(RgbFg(150,200,100), Sgr(1))
    >>> styled
    '\\x1b[38;2;150;200;100m\\x1b[1m'
    >>> styled2 = Style(styled, Sgr(2))
    >>> styled2
    '\\x1b[38;2;150;200;100m\\x1b[1m\\x1b[2m'
    """
    pass

# Generated at 2022-06-24 04:56:41.752589
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg, Sgr
    from . import fg

    # >>> fg.orange = Style(RgbFg(1,5,10), Sgr(1))
    # >>> isinstance(fg.orange, Style) # True
    assert isinstance(Style(RgbFg(1,5,10), Sgr(1)), Style)

    # >>> isinstance(fg.orange, str) # True
    assert isinstance(Style(RgbFg(1,5,10), Sgr(1)), str)

    # >>> str(fg.orange) # '\x1b[38;2;1;5;10m\x1b[1m' (The ASNI sequence for orange and bold)

# Generated at 2022-06-24 04:56:48.767737
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class CustomRendertype(RenderType):
        """
        Dummy rendertype.
        """
        def __repr__(self):
            return f"{self.__class__.__name__}()"

        def render(self, *args):
            return str(self)

    dummy = CustomRendertype()

    class Sty(Register):
        """
        Dummy class.
        """

        def __init__(self):
            super().__init__()
            self.custom_rendertype = dummy

    sty = Sty()

    sty.red = Style(sty.custom_rendertype)

    assert str(sty.red) == ""

    sty.set_eightbit_call(CustomRendertype)

    assert str(sty.red) == "CustomRendertype()"

# Generated at 2022-06-24 04:56:55.390188
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    reg = Register()

    def render(x):
        return str(x)

    reg.set_renderfunc(RenderType, render)

    r1 = RenderType(1)
    s1 = Style(r1)

    reg.test = s1

    assert reg.test == "1"

    s2 = Style(r1, s1)

    reg.test = s2

    assert reg.test == "112"

# Generated at 2022-06-24 04:57:02.777474
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    r: Register = Register()
    r.set_renderfunc(RenderType.ANSI256_8BIT_FG, lambda x: "1")
    r.set_renderfunc(RenderType.ANSI256_8BIT_BG, lambda x: "2")
    r.set_eightbit_call(RenderType.ANSI256_8BIT_BG)
    assert r(8) == "2"
    assert r("black") == "\x1b[38;5;8m"

# Generated at 2022-06-24 04:57:11.835294
# Unit test for constructor of class Register
def test_Register():

    def test_func_8bit(color_code: int, *args) -> str:
        return "test_func_8bit({}, {})".format(color_code, args)

    def test_func_rgb(r: int, g: int, b: int, *args) -> str:
        return "test_func_rgb({}, {}, {}, {})".format(r, g, b, args)

    r = Register()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(RgbFg, test_func_8bit)
    r.set_renderfunc(RgbFg, test_func_rgb)


# Generated at 2022-06-24 04:57:15.853533
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r2 = Register()
    r2.notdefault = "test"
    r1.r2 = r2
    r3 = r1.copy()
    r3.r2.notdefault = "test2"
    assert r1.r2.notdefault == "test"


# Generated at 2022-06-24 04:57:22.341850
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class DummyRegister(Register):
        pass

    dummy = DummyRegister()
    dummy.set_renderfunc(rendertype=RenderType, func=int)

    dummy.attr1 = Style(rendertype_val=10, rendertype_val2=20)
    dummy.attr2 = Style(rendertype_val=10, attr1="attr1")

    dummy.attr3 = Style(attr1="attr1", rendertype_val=10)
    dummy.attr4 = Style(rendertype_val=10, rendertype_val2=20, attr1="attr1")
    dummy.attr5 = Style(rendertype_val=10, attr1="attr1")

    assert dummy.attr1 == "1020"
    assert dummy.attr2 == "10attr1"
    assert dummy.attr3 == "attr110"


# Generated at 2022-06-24 04:57:29.450705
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    def eightbit_func1(i):
        return "1"

    def eightbit_func2(i):
        return "2"

    R = Register()
    R.set_eightbit_call(eightbit_func1)

    assert R.eightbit_call("8") == "1"

    R.set_eightbit_call(eightbit_func2)

    assert R.eightbit_call("8") == "2"

# Generated at 2022-06-24 04:57:33.197974
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    assert r() == ""
    assert r(111) == "111"
    assert r(1, 2, 3) == "(1, 2, 3)"

# Generated at 2022-06-24 04:57:43.530615
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Create a Register instance, fill it with some data and test as_dict method.
    """

    reg = Register()
    reg.a = Style(value="\x1b[1m")
    reg.b = Style(value="\x1b[2m")
    reg.c = Style(value="\x1b[3m")
    reg.d = Style(value="\x1b[4m")
    reg.e = Style(value="\x1b[5m")
    reg.f = Style(value="\x1b[7m")
    reg.g = Style(value="\x1b[8m")
    reg.h = Style(value="\x1b[9m")

    d = reg.as_dict()


# Generated at 2022-06-24 04:57:52.327371
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Sgr(RenderType):
        def render(self, code: int) -> str:
            return f"\x1b[{code}m"

        @classmethod
        def test_params(cls, *args, **kwargs) -> bool:
            if not len(args) == 1:
                return False
            if not isinstance(args[0], int):
                return False
            if not 0 <= args[0] <= 5:
                return False
            return True

    def render_Sgr(*args, **kwargs) -> str:
        return Sgr(*args, **kwargs).render(*args)


# Generated at 2022-06-24 04:57:56.722232
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbFg(10, 10, 10), Sgr(1))

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;10;10;10m\x1b[1m"


# Generated at 2022-06-24 04:58:02.761021
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    rest = Register()
    rest.red = Style(RgbFg(1, 0, 0))
    rest.clear_screen = Style(ClearScreen())
    rest.reset = Style(Sgr(0))
    rest.bold = Style(Sgr(1))
    rest.italic = Style(Sgr(3))
    rest.underline = Style(Sgr(4))
    rest.underscore = Style(Sgr(4))
    rest.blink = Style(Sgr(5))
    rest.reverse = Style(Sgr(7))
    rest.concealed = Style(Sgr(8))

    MyNamedTuple = rest.as_namedtuple()

    assert MyNamedTuple.red == '\x1b[38;2;1;0;0m'
    assert MyNamedTuple

# Generated at 2022-06-24 04:58:11.271426
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    import pytest
    from .rendertype import RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")

    r.set_eightbit_call(RgbFg)
    assert r(144) == "\x1b[38;2;144;0;0m"

    r.set_rgb_call(RgbFg)
    assert r(12, 34, 56) == "\x1b[38;2;12;34;56m"

# Generated at 2022-06-24 04:58:18.873751
# Unit test for constructor of class Register
def test_Register():
  r = Register()
  # test for __init__
  assert r.renderfuncs == {}
  assert r.is_muted == False

# Generated at 2022-06-24 04:58:29.116970
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg
    from sty.ansi import RgbFg

    test1 = fg(255, 240, 200)
    assert isinstance(test1, str)

    # Replace renderfunc for RgbFg
    def testfunc(red: int, green: int, blue: int) -> str:
        return str(red * red + green * green + blue * blue)

    fg.set_renderfunc(RgbFg, testfunc)

    # Set RbgAbort to be the new rendertype for rgb-calls.
    fg.set_rgb_call(RgbFg)

    test2 = fg(255, 240, 200)
    assert isinstance(test2, str)


if __name__ == "__main__":
    test_Register_set_rgb_call()

# Generated at 2022-06-24 04:58:39.240104
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbEf, RgbFg

    from . import fg, bg

    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    bg.orange = Style(RgbEf(255, 127, 0))
    bg.magenta = Style(RgbEf(255, 0, 255))
    bg.yellow = Style(RgbEf(255, 255, 0))

    Fg = fg.as_namedtuple()
    Bg = bg.as_namedtuple()

    assert Fg.red == fg.red
    assert Fg.green == fg.green


# Generated at 2022-06-24 04:58:46.962629
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbBg, RgbFg, Sgr

    class R(Register):
        pass

    # Create a mock-register with fg-render-info
    # This is needed to test register-calls such as fg(144)
    r = R()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda code: f"\x1b[{code}m")

    # The new rendertype for Eightbit-calls must be set
    r.set_eightbit_call(RgbFg)

    # Add styles to register that are needed to test different styles

# Generated at 2022-06-24 04:58:51.800983
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rule import RgbFg, Sgr

    style = Style("", RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, str)
    assert isinstance(style, Style)


# Generated at 2022-06-24 04:59:03.388434
# Unit test for method unmute of class Register
def test_Register_unmute():

    # define function that is used for the tests
    def dummy_fun(a,b,c):
        return "hallo"

    # create dummy register
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.blue = Style(RgbFg(0, 0, 255))
    fg.set_renderfunc(RgbFg, dummy_fun)
    fg.set_eightbit_call(RgbFg)
    fg.set_rgb_call(RgbFg)

    # save fg register to compare it with new register
    fg_old = fg.as_dict()

    # mute and unmute register
    fg.mute()
    fg.unmute()

    # compare new fg register with old and

# Generated at 2022-06-24 04:59:15.067974
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Initialize new register-object
    r = Register()
    r.set_renderfunc(type, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(type, lambda x: f"\x1b[{x}m")

    # Define a style that uses the two render-functions
    r.test = Style(type(1), type(2))

    # Check if the created style is a Style object
    assert isinstance(r.test, Style)

    # Set the eightbit-call value of the register object to the first render function
    r.set_eightbit_call(type)

    # Call the register-object with an integer argument, that should be passed to the
    # eightbit-call function. Because the eightbit-call function is the first one,
    # the string `

# Generated at 2022-06-24 04:59:21.099132
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class DummyRt(RenderType):
        def render_in_register(self):
            pass

    r = Register()
    r.foo = Style(DummyRt(1), DummyRt(2))
    r.set_renderfunc(DummyRt, lambda x: "Dummy")
    assert str(r.foo) == "DummyDummy"
    r2 = Register()
    r2.foo = Style(DummyRt(1), DummyRt(2))
    r2.set_renderfunc(DummyRt, lambda x: "AnotherDummy")
    assert str(r2.foo) == "AnotherDummyAnotherDummy"



# Generated at 2022-06-24 04:59:28.220681
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    def w8bit(x):
        return f"\x1b[{x}m"

    def wrgb(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    reg = Register()
    reg.set_renderfunc(EightbitBg, w8bit)
    reg.set_renderfunc(RgbBg, wrgb)

    reg.set_eightbit_call(EightbitBg)
    reg.set_rgb_call(RgbBg)

    assert reg(255) == "\x1b[255m"
    assert reg(42, 42, 42) == "\x1b[48;2;42;42;42m"