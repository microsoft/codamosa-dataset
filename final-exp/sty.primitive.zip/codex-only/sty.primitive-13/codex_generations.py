

# Generated at 2022-06-24 04:49:32.091221
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .styscope import StyScope
    from .rendertype import RgbFg
    StyScope("rgb")

    def f(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    # Normal setting of styles
    register = Register()
    register.set_renderfunc(RgbFg, f)

    register.red = Style(RgbFg(10, 50, 60))
    assert isinstance(register.red, Style)
    assert register.red == "\x1b[38;2;10;50;60m"

    # Setting of styles when muted
    register.mute()

    register.red_muted = Style(RgbFg(10, 50, 60))
    assert isinstance(register.red_muted, Style)

# Generated at 2022-06-24 04:49:34.084043
# Unit test for method copy of class Register
def test_Register_copy():
    a = Register()
    fg.green = Style(Sgr(42))
    assert a.copy().fg.green == fg.green

# Generated at 2022-06-24 04:49:42.464095
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Unit test for method: Sty.Register.as_dict

    This test verifies that a register object is transformed into a dictionary
    correctly.
    """
    import pytest
    from .const import fg, bg, ef, rs


# Generated at 2022-06-24 04:49:48.349055
# Unit test for method mute of class Register
def test_Register_mute():

    rg1 = Register()
    rg1.bg.red = Style(Sgr("48", "5", "1"))

    rg1.mute()

    assert str(rg1.bg.red) == ""

    rg1.unmute()

    assert str(rg1.bg.red) == "\x1b[48;5;1m"

# Generated at 2022-06-24 04:49:54.498171
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    r = Register()
    r.on_red = Style(RgbEf(10, 20, 30))
    r.bg_red = Style(RgbBg(40, 50, 60))

    d = r.as_dict()

    assert isinstance(d, dict)
    assert len(d) == 2
    assert d["on_red"] == "\x1b[38;2;10;20;30m"
    assert d["bg_red"] == "\x1b[48;2;40;50;60m"

# Generated at 2022-06-24 04:50:05.096138
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .render_type import RgbBg, RgbFg
    from .render_func import render_ansi_rgb

    class TestReg:
        def __init__(self):
            self.renderfuncs: Renderfuncs = {}
            self.is_muted = False
            self.eightbit_call = lambda x: x
            self.rgb_call = lambda r, g, b: (r, g, b)

        def __setattr__(self, name: str, value: Style):
            if isinstance(value, Style):
                if self.is_muted:
                    rendered_style = Style(*value.rules, value="")
                else:
                    rendered, rules = _render_rules(self.renderfuncs, value.rules)
                    rendered_style = Style(*rules, value=rendered)

               

# Generated at 2022-06-24 04:50:10.558157
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Setup
    register = Register()

    # Run
    register.set_rgb_call(RgbBg)

    # Assert
    assert register.rgb_call is RgbBg



# Generated at 2022-06-24 04:50:13.220473
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .registers import fg
    nt = fg.as_namedtuple()
    fg_red = nt.red
    assert isinstance(fg_red, str)
    assert fg_red == fg.red

# Generated at 2022-06-24 04:50:22.669205
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Unit-test for method set_eightbit_call of class Register.
    """
    from .rendertype import RgbFg

    # Define renderfuncs
    def def_render(code):
        return "\x1b", code

    def reset_render():
        return "\x1b", "-1"

    # Create a new register
    class TestRegister(Register):
        pass

    reg = TestRegister()
    reg.set_renderfunc(RgbFg, def_render)
    reg.set_eightbit_call(RgbFg)

    assert reg(100) == "\x1b[38;2;100;0;0m"

    reg.set_renderfunc(RgbFg, reset_render)
    assert reg(100) == "\x1b[-1m"


# Unit

# Generated at 2022-06-24 04:50:31.035133
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Reg(Register):
        pass

    reg = Reg()
    reg.rgb_call = lambda x, y, z: str((x, y, z))
    reg.eightbit_call = lambda x: str(x)

    assert reg(42) == "42"
    assert reg(1, 2, 3) == "(1, 2, 3)"

    reg.mute()

    assert reg(42) == ""

    reg.unmute()

    assert reg(42) == "42"

# Generated at 2022-06-24 04:50:38.169843
# Unit test for constructor of class Style
def test_Style():

    style = Style(value="test")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules == tuple()

    style = Style(RenderType(), value="test")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules == (RenderType(),)

    style = Style(Style(RenderType(), value="test"), value="test")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules == (Style(RenderType(), value="test"),)



# Generated at 2022-06-24 04:50:41.603712
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg = Register()
    # example style definition in register
    reg.green = Style(RgbFg(0, 255, 100))
    # make new namedtuple from register
    nt = reg.as_namedtuple()
    # check if green is present in namedtuple
    assert str(nt.green) == str(reg.green)

# Generated at 2022-06-24 04:50:50.192217
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Unit test for method set_eightbit_call of class Register.
    """
    reg = Register()
    assert reg.eightbit_call == reg.eightbit_call  # test, if it callable
    reg.set_eightbit_call(RenderType)
    assert reg.eightbit_call == reg.eightbit_call  # test, if it callable
    reg.set_eightbit_call(None)
    assert reg.eightbit_call == reg.eightbit_call  # test, if it callable


# Generated at 2022-06-24 04:50:58.890008
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Mock a register
    class MyRegister(Register):
        pass

    red = Style(RgbBg(255, 0, 0), Sgr(1))
    blue = Style(RgbBg(0, 0, 255), Sgr(4))

    my_reg = MyRegister()

    my_reg.red = red
    my_reg.blue = blue

    my_reg.red_bold = Style(my_reg.red, Sgr(1))
    my_reg.blue_bold = Style(my_reg.blue, Sgr(1))

    # Verify if the exported dict is correct

# Generated at 2022-06-24 04:51:04.981395
# Unit test for constructor of class Register
def test_Register():
    from .register import Register
    from .styletype import StyleType

    reg = Register()

    assert isinstance(reg, Register)
    assert isinstance(reg, StyleType)

    from .register import fg

    assert isinstance(fg, Register)
    assert isinstance(fg, StyleType)

    # TODO: Check for @classmethods fg, bg, ef, rs.
    # assert isinstance(Register.fg, StyleType)

# Generated at 2022-06-24 04:51:08.639736
# Unit test for constructor of class Style
def test_Style():
    assert Style(0x7, 0x1) == Style(0x7, 0x1).value == "\x1b[7m\x1b[1m"
    assert not isinstance(Style(0x7, 0x1), str)



# Generated at 2022-06-24 04:51:12.564630
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    setattr(r, "x", Style(RgbFg(1,0,1)))
    r.mute()
    r.unmute()

    assert not r.is_muted
    assert str(r.x) == "\x1b[38;2;1;0;1m"

# Generated at 2022-06-24 04:51:20.365094
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, SgrFg

    fg.red = Style(SgrFg(1))

    # Check that fg('red') is a str
    assert isinstance(fg('red'), str)

    # Check that fg('red') returns the correct ANSI code
    assert fg('red') == '\x1b[38;5;9m'

    # Check that fg(1,2,3) is a str
    assert isinstance(fg(1,2,3), str)

    # Check that fg(1,2,3) returns an empty str
    assert fg(1,2,3) == ''

    # Set new rendertype for RGB calls.
    fg.set_rgb_call(SgrFg)

    # Check that fg('red') is still a str
   

# Generated at 2022-06-24 04:51:32.029813
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Rgbtest:
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b

    f = lambda r, g, b: "test"

    class RgbFgtest(NamedTuple):
        r: int
        g: int
        b: int

    rf = lambda r, g, b: "test"

    fg = Register()
    fg.set_renderfunc(Rgbtest, f)
    fg.set_eightbit_call(Rgbtest)
    assert fg(144) == "test"

    fg.set_renderfunc(RgbFgtest, rf)
    fg.set_eightbit_call(RgbFgtest)

# Generated at 2022-06-24 04:51:34.209857
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    reg = Register()
    reg.red = Style(Sgr(1))
    assert reg.red == "\x1b[1m"



# Generated at 2022-06-24 04:51:38.743140
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg

    t1 = fg.as_namedtuple()
    assert isinstance(t1, NamedTuple)
    assert t1.white == "\x1b[38;2;255;255;255m"

# Generated at 2022-06-24 04:51:46.869114
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty.rendertype import RgbFg
    r = Register()
    ansi_red = RgbFg(255, 0, 0)
    assert r(10, 255, 0) == ""
    assert r(128, 0, 255) == ""
    r.set_rgb_call(RgbFg)
    assert r(10, 255, 0) == "\x1b[38;2;10;255;0m"
    assert r(128, 0, 255) == "\x1b[38;2;128;0;255m"


# Generated at 2022-06-24 04:51:58.757418
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbRenderType(RenderType):

        """Placeholder for unit test."""

    rgb: Type[RenderType] = RgbRenderType()
    r = Register()

    # If no argument is given, return empty string.
    assert r() == ""

    # If argument is an int, return empty string.
    assert r(42) == ""

    # If argument is a string, return empty string.
    assert r("red") == ""

    # If argument is a tuple, return empty string.
    assert r(42, 55, 255) == ""

    # If argument is an int and there is a registered render-func,
    # then return the result of the render-func with the arguments.
    r.set_renderfunc(rgb, lambda i: f"rgb({i})")

# Generated at 2022-06-24 04:52:08.197605
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .registers.fg import fg
    from .rendertypes.rgb import RgbFg

    fg.set_renderfunc(RgbFg, lambda a,b,c: f"\x1b[38;2;{a};{b};{c}m")
    fg.rgb = Style(RgbFg(255, 127, 0))

    assert fg.rgb == "\x1b[38;2;255;127;0m"
    fg.mute()
    assert fg.rgb == ""
    fg.unmute()
    assert fg.rgb == "\x1b[38;2;255;127;0m"

# Generated at 2022-06-24 04:52:16.782441
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def rgb_to_ansi(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def rgb_to_hex(r, g, b):
        return f"\x1b[38;5;{16 + (r / (256 / 5)) + 6 * (g / (256 / 5)) + 36 * (b / (256 / 5))}m"

    def sgr_to_ansi(sgr):
        return f"\x1b[{sgr}m"

    class RgbFg:

        def __init__(self, r, g=None, b=None):
            self.args = (r, g, b)


# Generated at 2022-06-24 04:52:23.841281
# Unit test for method __call__ of class Register
def test_Register___call__():
    test_register = Register()
    test_register.test_style = Style(RgbFg(10, 20, 30))

    assert test_register("test_style") == "\x1b[38;2;10;20;30m"
    assert test_register(10, 20, 30) == "\x1b[38;2;10;20;30m"
    assert test_register(254) == ""

# Generated at 2022-06-24 04:52:26.541495
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class Reg(Register):

        A = Style("A")
        B = Style("b")
        C = Style("c")

    reg = Reg()
    assert reg.as_dict() == {"A": "A", "B": "b", "C": "c"}


# Generated at 2022-06-24 04:52:34.237703
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg
    from .definitions import StyleRegisters

    style = Style(RgbFg(5,5,5))
    setattr(StyleRegisters, "foo", style)

    assert str(getattr(StyleRegisters, "foo")) == "\x1b[38;2;5;5;5m"

    StyleRegisters.unmute()

    assert str(getattr(StyleRegisters, "foo")) == "\x1b[38;2;5;5;5m"


# Generated at 2022-06-24 04:52:37.962417
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test function for method unmute of class Register.
    """
    r = Register()
    r.mute()

    assert r.is_muted

    r.unmute()

    assert not r.is_muted



# Generated at 2022-06-24 04:52:41.570939
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert str(r.as_namedtuple()) == str(r.as_dict()) and "0x1b[m" == str(r.as_dict()["reset"])




# Generated at 2022-06-24 04:52:46.174496
# Unit test for constructor of class Register
def test_Register():
    rg = Register()
    for _ in dir(rg):
        assert isinstance(getattr(rg, _), Style) is False


# Generated at 2022-06-24 04:52:53.573139
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Arrange
    class Sgr(RenderType):
        pass

    class RgbFg(RenderType):
        pass

    def f1(self):
        return "a"

    def f2(self):
        return "b"

    register = Register()
    register.set_renderfunc(Sgr, f1)
    register.set_renderfunc(RgbFg, f2)

    # Act
    register.set_renderfunc(RgbFg, f1)

    # Assert
    assert register.renderfuncs[RgbFg].__name__ == "f1"



# Generated at 2022-06-24 04:52:58.187882
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Create register object
    r: Register = Register()

    # Create test style attribute
    test_attribute = Style()

    # Set test style attribute
    r.test = test_attribute  # noqa: F841

    # Test if attribute has been set
    assert hasattr(r, "test")

# Generated at 2022-06-24 04:53:08.112526
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    import sty

    # Create a new register-object.
    new_register = Register()

    # Add two style attributes.
    setattr(new_register, "attr_1", Style(sty.RgbFg(0, 0, 0, "attr_1")))
    setattr(new_register, "attr_2", Style(sty.RgbFg(0, 0, 0, "attr_2")))

    # Export the new register-object.
    exported = new_register.as_dict()

    assert exported == {"attr_1": str(sty.RgbFg(0, 0, 0, "attr_1")), "attr_2": str(sty.RgbFg(0, 0, 0, "attr_2"))}

# Generated at 2022-06-24 04:53:14.216151
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class CustomRegister(Register):
        pass

    class Sgr0(RenderType):
        pass

    class Sgr1(RenderType):
        pass

    class Sgr2(RenderType):
        pass

    r = CustomRegister()
    r.set_renderfunc(Sgr0, lambda *args, **kwargs: "<SGR0>")
    r.set_renderfunc(Sgr1, lambda *args, **kwargs: "<SGR1>")

    assert isinstance(r, Register)
    assert str(r.test) == ""

    r.test = Style(Sgr2())
    assert str(r.test) == "<SGR2>"

    r.set_renderfunc(Sgr2, lambda *args, **kwargs: "<SGR2-and-SGR1>")

# Generated at 2022-06-24 04:53:20.458465
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Test(RenderType):
        def __init__(self, *args):
            pass

    def func1():
        return "A"

    def func2():
        return "B"

    test = Test()

    register = Register()
    register.set_renderfunc(type(test), func1)

    assert register.renderfuncs[type(test)]() == "A"

    register.set_renderfunc(type(test), func2)

    assert register.renderfuncs[type(test)]() == "B"

# Generated at 2022-06-24 04:53:30.363962
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .rendertypes import Sgr, RgbBg

    fg = Register()

    fg.green = Style(Sgr(32))
    fg.blue = Style(Sgr(44))
    fg.white = Style(Sgr(97))
    fg.magenta = Style(Sgr(35), Sgr(1))

    fg.orange = Style(RgbFg(255, 123, 50))
    fg.light_blue = Style(RgbFg(196, 255, 255))
    

# Generated at 2022-06-24 04:53:39.227737
# Unit test for constructor of class Style
def test_Style():
    # Test for valid rule-Input
    r1 = Style(Sgr(1))
    r2 = Style(RgbFg(1, 2, 3))
    r3 = Style(Sgr(1), RgbBg(1, 2, 3))
    r4 = Style(Sgr(1), RgbBg(1, 2, 3), value=":D")

    # Check attrs
    assert hasattr(r1, "rules")
    assert hasattr(r2, "rules")
    assert hasattr(r3, "rules")
    assert hasattr(r4, "rules")

    # Check types
    assert isinstance(r1, Style)
    assert isinstance(r2, Style)
    assert isinstance(r3, Style)
    assert isinstance(r4, Style)

    # Check str-method

# Generated at 2022-06-24 04:53:40.423549
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.is_muted == False



# Generated at 2022-06-24 04:53:43.386629
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from sty.constants import fg

    fg.set_eightbit_call(rendertype=None)



# Generated at 2022-06-24 04:53:53.235842
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # This test is a little bit tricky, because we have to test
    # a lot of stuff at once:

    # We will test the method set_renderfunc with 2 rendertypes:
    # 1.) SomeSgrRenderType
    # 2.) SomeRgbRenderType
    # The object of the class Register will store both render-functions.

    # The following lines define SomeSgrRenderType.
    # (It is just a dummy-class)
    class SomeSgrRenderType(NamedTuple):

        param: int
        name: str = ""

        def __format__(self, format_spec):
            return f"\x1b[{self.param}m"

    # The following lines define SomeRgbRenderType
    class SomeRgbRenderType(NamedTuple):

        r: int
        g: int
        b

# Generated at 2022-06-24 04:54:01.163427
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Create new Register
    r = Register()

    # Create new rendertype
    rendertype = RenderType("TEST", "Test", "")

    # Create new renderfunc
    func = lambda: "Test"

    # Set new renderfunc
    r.set_renderfunc(rendertype, func)

    # Create new style
    setattr(r, "test", Style(rendertype))

    # Mute register
    r.mute()

    # Check that str(style) == empty string
    assert str(r.test) == ""

    # Unmute register
    r.unmute()

    # Check that str(style) != empty string
    assert str(r.test) != ""



# Generated at 2022-06-24 04:54:05.434665
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.test = Style(r.test, value="test")
    d = r.as_dict()
    assert d == {"test": "test"}


# Generated at 2022-06-24 04:54:13.236251
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: "\x1b[{}m".format(x))

    r.a = Style(RenderType(42))
    r.b = Style(RenderType(100))

    assert str(r.a) == "\x1b[42m"
    assert str(r.b) == "\x1b[100m"

    r.mute()

    assert str(r.a) == ""
    assert str(r.b) == ""
    assert r.is_muted


# Generated at 2022-06-24 04:54:20.282897
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import Sgr, RgbFg, RgbBg
    from .style import Style as s
    from .style import RS as rs

    fg = Register()
    fg.red = Style(Sgr(1), RgbFg(255, 0, 0))
    fg2 = fg.copy()

    assert fg is not fg2
    assert fg.red is not fg2.red
    assert fg.red == fg2.red

    fg3 = Register()
    fg3.red = s(RgbFg(255, 0, 0))

    assert fg3.red is not fg.red
    assert fg3.red == fg.red

    # Test Register with strings
    bg = Register()

# Generated at 2022-06-24 04:54:23.549402
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .rendertype import RgbBg
    from .register import Register

    custom_register = Register()
    custom_register.yellow = Style(RgbBg(10, 25, 25))

    assert {"yellow": f"{RgbBg(10, 25, 25)}"} == custom_register.as_dict()


# Generated at 2022-06-24 04:54:34.452265
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Unit test for method as_namedtuple of class Register
    """
    from .rendertype import RgbFg, Sgr

    fg = Register()
    fg.red = Style(RgbFg(1, 0, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 1), Sgr(1))
    fg.green = Style(RgbFg(0, 1, 0), Sgr(1))

    nt1 = fg.as_namedtuple()
    assert nt1.red == "\x1b[38;2;1;0;0m\x1b[1m"
    assert nt1.blue == "\x1b[38;2;0;0;1m\x1b[1m"
    assert nt

# Generated at 2022-06-24 04:54:44.189114
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test for method set_rgb_call of class Register.
    """

    import unittest
    import sty

    class Register_set_rgb_call_Test(unittest.TestCase):

        def test_init(self):

            fg: Register = sty.fg

            # Now register fg is a 8bit register and only accepts 8bit
            # color codes.

            # Register fg should accept rgb color codes as well.
            # So we want to change the rendertype for rgb calls.

            # Add a new rendertype RgbFg to sty.
            sty.RgbFg = sty.namedtuple("RgbFg", "r, g, b")

            # Create a new renderfunc that handles the rendertype RgbFg.

# Generated at 2022-06-24 04:54:52.685334
# Unit test for method mute of class Register
def test_Register_mute():

    from . import fg

    from .rendertype import RgbFg

    fg.mute()
    assert fg.is_muted
    for style in dir(fg):
        if not style.startswith("_"):
            assert not fg.renderfuncs[RgbFg] in fg.__getattribute__(style)

    fg.unmute()
    assert not fg.is_muted
    for style in dir(fg):
        if not style.startswith("_"):
            assert fg.renderfuncs[RgbFg] in fg.__getattribute__(style)

# Generated at 2022-06-24 04:55:02.504308
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty.colortbl import RgbFg, Sgr

    myregister = Register()
    myregister.set_eightbit_call(RgbFg)
    myregister.set_rgb_call(RgbFg)

    myregister.red = Style(RgbFg(255, 0, 0))
    myregister.blue = Style(RgbFg(0, 0, 255))

    assert isinstance(myregister.red, Style)
    assert isinstance(myregister.blue, Style)

    assert isinstance(myregister.red, str)
    assert isinstance(myregister.blue, str)

    assert str(myregister.red) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:55:11.631168
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbBg

    class Rs(RenderType):
        def __init__(self) -> None:
            self.args = None

    rs = Register()

    rs.renderfuncs.update({Sgr: lambda *args: "\x1b[0;m", RgbBg: lambda *args: "\x1b[48;2;0;0;255m"})

    rs.blue = Style(RgbBg(0, 0, 255))

    rs.mute()

    assert rs.blue == ""

    rs.unmute()

    assert rs.blue == "\x1b[48;2;0;0;255m"

# Generated at 2022-06-24 04:55:14.007976
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    tr = TestRegister()
    setattr(tr, "red", "red")

    result = tr("red")
    assert result == "red"



# Generated at 2022-06-24 04:55:17.066540
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.a = "a"
            self.b = "b"
            self.c = "c"

    t = TestRegister()

    assert isinstance(t.as_namedtuple(), NamedTuple)

# Generated at 2022-06-24 04:55:26.803565
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RenderTypeFoo(RenderType):
        def render(self):
            return "\x1b[1m"  # Bold

    renderfunc = lambda *args, **kwargs: RenderTypeFoo().render()

    register = Register()

    assert register.eightbit_call(144) == ""
    assert register.eightbit_call(255) == ""

    register.set_renderfunc(RenderTypeFoo, renderfunc)
    register.set_eightbit_call(RenderTypeFoo)

    assert register.eightbit_call(144) == "\x1b[1m"
    assert register.eightbit_call(255) == "\x1b[1m"

# Generated at 2022-06-24 04:55:36.104180
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertypes import (
        Foreground,
        Background,
        Effect,
        Reset,
        TrueColorBackground,
        TrueColorForeground,
    )
    from .rendertype_renderfuncs import render_fg, render_bg, render_ef, render_rs, render_rgb_bg, render_rgb_fg
    from . import (
        fg,
        bg,
        ef,
        rs,
        eightbit,
        truecolor,
        register_renderfuncs,
    )

    # Create test-Register
    fg_r = Register()
    fg_r.is_muted = False
    fg_r.set_eightbit_call(Foreground) # fg(8)
    fg_r.set_rgb_call(TrueColorForeground) # f

# Generated at 2022-06-24 04:55:37.580962
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test method `Register.copy()`.
    """
    from .all import fg

    assert fg.copy() == fg

# Generated at 2022-06-24 04:55:43.052822
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .render import render_rgb
    class RgbRenderTest(RenderType):
        pass

    r = Register()
    r.set_renderfunc(RgbRenderTest, render_rgb)
    r.set_rgb_call(RgbRenderTest)
    assert r(1, 2, 3) == "\x1b[38;2;1;2;3m"

    r.mute()
    r.unmute()
    assert r(1, 2, 3) == "\x1b[38;2;1;2;3m"

    r.set_renderfunc(RgbRenderTest, lambda r, g, b: (r, g, b))
    assert r(42, 0, 255) == (42, 0, 255)



# Generated at 2022-06-24 04:55:46.255858
# Unit test for constructor of class Style
def test_Style():
    s = Style(fg=1, bg=2)
    assert s.fg == 1
    assert s.bg == 2
    assert isinstance(s, Style)


# Generated at 2022-06-24 04:55:54.586737
# Unit test for method mute of class Register
def test_Register_mute():
    reg = Register()

    class TestRenderType(RenderType):
        def render(self, *args, **kwargs):
            return "".join(args)

        def __str__(self):
            return "TestRenderType"

    reg.set_renderfunc(TestRenderType, lambda x, y: "TestRenderType")
    reg.one = Style(TestRenderType("arg1", "arg2"))
    reg.two = Style(TestRenderType("arg3", "arg4"))
    reg.three = Style(TestRenderType("arg5", "arg6"))

    assert str(reg.one) == "TestRenderType"

    assert reg.mute() == None

    assert str(reg.one) == ""
    assert str(reg.two) == ""
    assert str(reg.three) == ""

    assert reg.un

# Generated at 2022-06-24 04:55:59.537859
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class FakeRegister(Register):
        def __init__(self):
            self.red = "red"
            self.green = "green"
            self.blue = "blue"

    fr = FakeRegister()

    assert fr.as_dict() == {"red": "red", "green": "green", "blue": "blue"}



# Generated at 2022-06-24 04:56:04.847290
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-24 04:56:15.302421
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Setup
    class ExampleRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style()

    # Execute
    reg = ExampleRegister()
    reg.dark_red = "dark"
    reg.green = "green"
    reg.dark_green = "dark"
    reg.blue = "blue"
    reg.dark_blue = "dark"
    reg.cyan = "cyan"
    reg.dark_cyan = "dark"
    reg.magenta = "magenta"
    reg.dark_magenta = "dark"
    reg.yellow = "yellow"
    reg.dark_yellow = "dark"
    reg.light_gray = "light"
    reg.dark_gray = "dark"
    reg.white = "white"
    reg

# Generated at 2022-06-24 04:56:23.082073
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RenderType1:
        def __init__(self, arg1, arg2):
            pass

        def __getitem__(self, item):
            return None

        def __iter__(self):
            return None

    class RenderType2:
        def __init__(self, arg):
            pass

        def __getitem__(self, item):
            return None

        def __iter__(self):
            return None

    func1 = lambda arg1, arg2: ""
    func2 = lambda arg: ""

    register = Register()
    register.set_renderfunc(RenderType1, func1)
    register.set_renderfunc(RenderType2, func2)

    style1 = Style(RenderType1(1, 2))
    style2 = Style(RenderType2(1))

# Generated at 2022-06-24 04:56:29.498282
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg, bg, ef, bf

    d = {}
    assert hasattr(d, "setdefault")

    fg.green = Style(fg(0, 69, 0))
    d.setdefault(fg.green)

    assert d == fg.as_dict()


reg_type = NamedTuple("reg_type", [("name", str), ("style", str)])



# Generated at 2022-06-24 04:56:37.383862
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def f1(r, g, b):
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    def f2(code):
        return "\x1b[{}m".format(code)

    def f3(r, g, b):
        return "\x1b[38;5;{};38;2;{};{};{}m".format(0, r, g, b)

    red = Style(RgbFg(10, 20, 30), Sgr(1))

    r = Register()
    r.set_renderfunc(RgbFg, f1)
    r.set_renderfunc(Sgr, f2)
   

# Generated at 2022-06-24 04:56:44.360526
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class R1(RenderType):
        args = []

        def __init__(self):
            pass

    class R2(RenderType):
        args = []

        def __init__(self):
            pass

    r1 = R1()
    r2 = R2()

    def render1(*args):
        return "r1"

    def render2(*args):
        return "r2"

    register = Register()
    register.set_renderfunc(R1, render1)
    register.set_renderfunc(R2, render2)
    register.eightbit_call = render1

    # Test default renderfunc
    assert register(8) == "r1"

    # Set new renderfunc to R2
    register.set_eightbit_call(R2)
    assert register(8) == "r2"

# Generated at 2022-06-24 04:56:55.738624
# Unit test for method unmute of class Register
def test_Register_unmute():
    class SpecialRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 128, 0))
            self.blue = Style(RgbFg(0, 0, 255))
            self.mute()

    sr = SpecialRegister()

    assert sr.red == ""
    assert sr.green == ""
    assert sr.blue == ""

    sr.unmute()

    assert sr.red == "\x1b[38;2;255;0;0m"
    assert sr.green == "\x1b[38;2;0;128;0m"
    assert sr.blue == "\x1b[38;2;0;0;255m"

#

# Generated at 2022-06-24 04:57:06.904586
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Create a fake Register
    class MyRegister:  # pylint: disable=too-few-public-methods
        def __init__(self):
            self.renderfuncs: Renderfuncs = {}
            self.is_muted = False
            self.eightbit_call = lambda x: x
            self.rgb_call = lambda r, g, b: (r, g, b)

    # Create fake rendertype and renderfunc.
    class FakeRenderType:  # pylint: disable=too-few-public-methods
        pass

    def renderfunc():
        pass

    # Create FakeRegister and add renderfunc for FakeRenderType.
    r = MyRegister()
    r.set_renderfunc(FakeRenderType, renderfunc)

    # Create a Style with a single FakeRenderType rule, set it as an attribute

# Generated at 2022-06-24 04:57:12.282327
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: x)
    r.black = Style(RenderType(0))
    r.white = Style(RenderType(7))

    t1 = r.as_namedtuple()
    t2 = r.as_namedtuple()

    assert t1 is not t2

    assert t1.white == "\x1b[37m"
    assert t2.white == "\x1b[37m"

# Generated at 2022-06-24 04:57:15.586331
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False
    assert r.eightbit_call(41) == 41
    assert r.rgb_call(9, 13, 37) == (9, 13, 37)



# Generated at 2022-06-24 04:57:23.708807
# Unit test for method mute of class Register
def test_Register_mute():
    import sty

    r = Register()

    r.set_renderfunc(RenderType, lambda x: x)
    r.set_eightbit_call(RenderType)

    r.red = Style(RenderType(31))

    r.mute()

    assert r.red == ""
    assert r(31) == ""

    r.unmute()

    assert r.red == "31"
    assert r(31) == "31"

# Generated at 2022-06-24 04:57:25.930596
# Unit test for constructor of class Style
def test_Style():
    style = Style(*[RgbFg(1, 2, 3)], value="test")
    assert len(style.rules) == 1
    assert style.rules[0].args == (1, 2, 3)
    assert str(style) == "test"

# Generated at 2022-06-24 04:57:33.522856
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test if RGB-calls work as expected.
    """

    r = Register()
    r.set_rgb_call(RenderType.RGB)

    assert r.rgb_call(0, 0, 0) == '\x1b[38;2;0;0;0m'
    assert r.rgb_call(255, 255, 255) == '\x1b[38;2;255;255;255m'

    assert r(0, 0, 0) == '\x1b[38;2;0;0;0m'
    assert r(255, 255, 255) == '\x1b[38;2;255;255;255m'

    # Check that 8bit-calls are not working
    assert r(255) == ''
    assert r(42) == ''

    #

# Generated at 2022-06-24 04:57:43.753047
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbBg

    # Create a new register-object with a mock render-function
    register = Register()
    register.set_renderfunc(RgbBg, lambda x,y,z: "MOCK")

    # Create a style
    style = Style(RgbBg(42, 42, 42))

    # Add style to register-object so it can be accessed via attribute.
    setattr(register, "blue", style)

    # Check if style is rendered correctly
    assert register.blue == "MOCK"

    # Mute style
    register.mute()

    # Check if style is muted correctly
    assert register.blue == ""

    # Unmute style
    register.unmute()

    # Check if style is unmuted correctly
    assert register.blue == "MOCK"

# Generated at 2022-06-24 04:57:50.322484
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style(RgbFg(1, 2, 3), Sgr(1), value="\x1b[38;2;1;2;3m\x1b[1m")
    assert len(style) == 22
    assert style == "\x1b[38;2;1;2;3m\x1b[1m"
    assert style.rules == (RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(style, Style)
    assert isinstance(style, str)



# Generated at 2022-06-24 04:57:56.086197
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.red = Style(Sgr(1))
    r.yellow = Style(Sgr(43))

    assert r.red == "\\x1b[1m"
    assert r.yellow == "\\x1b[43m"

    r.mute()
    assert r.red == ""
    assert r.yellow == ""

    r.unmute()
    assert r.red == "\\x1b[1m"
    assert r.yellow == "\\x1b[43m"

# Generated at 2022-06-24 04:58:02.467595
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test function with simple example to ensure that method set_renderfunc
    works properly.
    """

    class MyRenderType(RenderType):
        """
        This is a custom render type that is just used for the test function.
        """

        def __init__(self, value: int):
            super().__init__()
            self.value = value

    def my_render_func(value: int) -> str:
        """
        This is a custom render function that is just used for the test function.
        """
        return f"{value} "

    r = Register()
    r.foo = Style(MyRenderType(1))
    r.set_renderfunc(MyRenderType, my_render_func)
    assert r.foo == "1"

# Generated at 2022-06-24 04:58:13.270289
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # arrange
    class TestRegister(Register):
        def __init__(self):
            super().__init__()

            self.a = Style(RgbFg(1, 5, 10), Sgr(1))
            self.b = Style(RgbFg(2, 6, 10), Sgr(2))
            self.c = Style(RgbFg(4, 6, 10), Sgr(4))
            self.d = Style(RgbFg(3, 6, 10), Sgr(3))

    # act
    test_register = TestRegister()
    t: NamedTuple = test_register.as_namedtuple()
    # assert
    assert t.a == "\x1b[38;2;1;5;10m\x1b[1m"

    # arrange

# Generated at 2022-06-24 04:58:24.204975
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Expected output:
    {"black": "\x1b[38;2;0;0;0m", "red": "\x1b[38;2;255;0;0m", "green": "\x1b[38;2;0;128;0m", "yellow": "\x1b[38;2;255;255;0m", "blue": "\x1b[38;2;0;0;255m", "magenta": "\x1b[38;2;255;0;255m", "cyan": "\x1b[38;2;0;255;255m", "white": "\x1b[38;2;255;255;255m"}
    """

    from sty import fg

    fg.set_eightbit_call(RgbFg)

    return fg.as_

# Generated at 2022-06-24 04:58:31.368034
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbBg, RgbFg

    register = Register()
    register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    register.set_eightbit_call(RgbFg)

    assert register(42) == "\x1b[38;2;42;42;42m"



# Generated at 2022-06-24 04:58:38.550501
# Unit test for method mute of class Register
def test_Register_mute():
    fg = Register()
    fg.red = Style(SgrFg(1))
    assert isinstance(fg.red, Style)

    fg.mute()
    assert isinstance(fg.red, Style)
    assert fg.red.rules == (SgrFg(1),)
    assert str(fg.red) == ""

    fg.unmute()
    assert isinstance(fg.red, Style)
    assert str(fg.red) == "\x1b[31m"


# Generated at 2022-06-24 04:58:45.013083
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .sgr import Sgr
    from .fg import RgbFg
    from .rs import Rs

    r = Register()
    r.black = Style(RgbFg(0, 0, 0), Sgr(1))
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    r.yellow = Style(RgbFg(255, 255, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))
    r.magenta = Style(RgbFg(255, 0, 255), Sgr(1))

# Generated at 2022-06-24 04:58:51.250860
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class A(RenderType):
        pass

    class B(RenderType):
        pass

    class C(RenderType):
        pass

    def f1(*args):
        pass

    def f2(*args):
        pass

    def f3(*args):
        pass

    r = Register()
    r.set_renderfunc(A, f1)
    r.set_renderfunc(B, f2)
    r.set_renderfunc(C, f3)
    r.set_renderfunc(A, f3)

    assert r.renderfuncs.keys() == {A, B, C}
    assert r.renderfuncs.values() == {f1, f2, f3}

# Generated at 2022-06-24 04:58:57.810163
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRegister(Register):
        pass

    tr = TestRegister()

    test_style = Style(RgbBg(42, 100, 200, 1), Sgr(1))
    tr.test_sty = test_style

    assert tr.test_sty == "\x1b[48;2;42;100;200;1m\x1b[1m"

    tr.mute()

    assert tr.test_sty == ""



# Generated at 2022-06-24 04:59:05.665142
# Unit test for method __call__ of class Register
def test_Register___call__():

    def func1(x: int) -> str:
        return "I am func1"

    def func2(r: int, g: int, b: int) -> str:
        return "I am func2"

    r = Register()
    r.set_eightbit_call(int)
    r.set_rgb_call(int)
    r.set_renderfunc(int, func1)
    r.set_renderfunc(int, func2)

    r1 = r(42)

    r2 = r(10, 20, 30)

    if r1 != "I am func1" or r2 != "I am func2":
        raise RuntimeError

# Generated at 2022-06-24 04:59:16.118645
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    XTERM256_NamedTuple = namedtuple("Xterm256", [str(i) for i in range(256)])
    XTERM256 = XTERM256_NamedTuple(*range(256))

    rendertype1 = RenderType
    rendertype2 = NamedTuple
    renderfunc1 = lambda x: rendertype1
    renderfunc2 = lambda x: rendertype2

    class R:
        def __init__(self, renderfuncs):
            self.renderfuncs = renderfuncs

    r = R(renderfuncs={rendertype1: renderfunc1, rendertype2: renderfunc2})
    r.set_eightbit_call(rendertype1)
    assert r(0) == rendertype1

    r.set_eightbit_call(rendertype2)
    assert r(0) == render

# Generated at 2022-06-24 04:59:22.919498
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr

    fg = Register()
    fg.red = Style(Sgr(31))

    assert fg.red == "\x1b[31m"

    fg.mute()

    assert fg.red == ""

    fg.unmute()

    assert fg.red == "\x1b[31m"