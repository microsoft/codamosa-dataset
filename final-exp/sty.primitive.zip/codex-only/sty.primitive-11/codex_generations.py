

# Generated at 2022-06-24 04:49:24.295563
# Unit test for constructor of class Register
def test_Register():
    fg = Register()
    assert isinstance(fg, Register)

# Generated at 2022-06-24 04:49:33.731732
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test for the Style-class.
    """
    import sty

    sty.rs.set_renderfunc(sty.Sgr, lambda *args: ";".join(str(a) for a in args) + "m")

    sty.fg.red = sty.Style(sty.Sgr(31), sty.rs)
    sty.bg.green = sty.Style(sty.Sgr(42), sty.rs)

    assert isinstance(sty.fg.red, sty.Style)
    assert isinstance(sty.fg.red, str)
    assert str(sty.fg.red) == "31;0m"
    assert str(sty.bg.green) == "42;0m"


# Generated at 2022-06-24 04:49:35.585483
# Unit test for method copy of class Register
def test_Register_copy():

    from .registers import fg

    fg1 = fg.copy()

    assert fg is not fg1
    assert fg.red is not fg1.red
    assert fg.red == fg1.red


# Generated at 2022-06-24 04:49:39.725736
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr

    # Str -> Style
    assert isinstance(Style("test"), Style)
    assert str(Style("test")) == "test"

    # Tuple of StylingRules -> Style
    assert str(Style(Sgr(1), value="test2")) == "\x1b[1mtest2"

    # No input -> Style
    assert str(Style()) == ""

# Generated at 2022-06-24 04:49:50.625008
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        pass

    class Rgb(RenderType):
        pass

    class RgbFg(Rgb):
        pass

    # Preparing 8bit rendertype and renderfunc
    render_8b_func = lambda x: "\x1b[38:5:%dm" % x

    # Preparing 24bit rendertype and renderfunc
    render_24b_func = lambda r, g, b: "\x1b[38:2:%d:%d:%dm" % (r, g, b)

    # Preparing two rendertypes
    renderfuncs = {Sgr: lambda *foo: "\x1b[%sm" % foo[0], RgbFg: render_24b_func}

    # Creating new register-object and adding renderfuncs
    reg = Register()

# Generated at 2022-06-24 04:50:02.416720
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Rgb256(NamedTuple):
        idx: int

    class RgbFg(NamedTuple):
        r: int
        g: int
        b: int

    class RgbBg(NamedTuple):
        r: int
        g: int
        b: int

    def render_func_rgb256(idx):
        return "\x1b[38;5;%dm" % idx

    def render_func_rgbfg(r, g, b):
        return "\x1b[38;2;%d;%d;%dm" % (r, g, b)

    def my_render_func_rgb256(r, g, b):
        return "\x1b[48;2;%d;%d;%dm" % (r, g, b)

# Generated at 2022-06-24 04:50:08.984027
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .renderfuncs import create_renderfunc_sgr

    fg = Register()

    fg.red = Style(RenderType.Sgr(31))
    assert fg.red == "\x1b[31m"

    fg.non_existent_rendertype = Style(RenderType.Sgr(31))
    assert fg.non_existent_rendertype == ""

    fg.set_renderfunc(RenderType.Sgr, create_renderfunc_sgr)
    fg.non_existent_rendertype = Style(RenderType.Sgr(31))
    assert fg.non_existent_rendertype == "\x1b[31m"

    fg.red = Style(RenderType.Sgr(32))
    assert fg.red == "\x1b[32m"

    fg.mute()


# Generated at 2022-06-24 04:50:15.336926
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.test = Style("\x1b[1m")
    register.test2 = Style("\x1b[2m")
    assert isinstance(register.as_dict(), dict)
    assert register.as_dict()["test"] == "\x1b[1m"
    assert register.as_dict()["test2"] == "\x1b[2m"


# Generated at 2022-06-24 04:50:23.285805
# Unit test for method mute of class Register
def test_Register_mute():
    from sty import fg, bg

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert bg.green == "\x1b[48;2;0;128;0m"

    fg.mute()
    bg.mute()

    assert fg.red == ""
    assert bg.green == ""

    fg.unmute()
    bg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert bg.green == "\x1b[48;2;0;128;0m"



# Generated at 2022-06-24 04:50:29.909207
# Unit test for constructor of class Style
def test_Style():

    # check if Style is a subclass of str
    assert issubclass(Style, str)

    # check if a Style-object is an instance of str
    s = Style(value='\x1b[1m')
    assert isinstance(s, str)

    # check if str(<Style-object>) returns <value>
    assert str(s) == '\x1b[1m'

    # check if <Style-object>.rules is set correctly
    s = Style(Sgr(1), Sgr(3), Sgr(4), value='\x1b[1;3;4m')
    assert s.rules == (Sgr(1), Sgr(3), Sgr(4))



# Generated at 2022-06-24 04:50:39.916885
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    def renderfunc(x):
        return "seq_%s" % x

    def renderfunc_rgb(r, g, b):
        return "seq_rgb_%i%i%i" % (r, g, b)

    # Create a new register-object
    clrs = Register()

    # Assign renderfunc for 8bit codes to object
    clrs.set_eightbit_call(Eightbit)
    clrs.set_renderfunc(Eightbit, renderfunc)

    # Assign renderfunc for 24bit codes to object
    clrs.set_rgb_call(RgbFg)
    clrs.set_renderfunc(RgbFg, renderfunc_rgb)

    # Assign test style to object

# Generated at 2022-06-24 04:50:49.321794
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .registers import fg
    from .rendertype import Sgr, RgbFg
    from .sty import Sty

    sty = Sty()
    # fg.orange = Style(RgbFg(1,50,10), Sgr(1))

    sty.fg.orange = Style(RgbFg(1, 50, 10), Sgr(1))
    sty.fg.reset = ""

    nt = sty.fg.as_namedtuple()
    assert nt.orange == "\x1b[38;2;1;50;10m\x1b[1m"
    assert nt.reset == ""

# Generated at 2022-06-24 04:50:52.064437
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style(RgbFg(10, 15, 20))
    assert isinstance(style, Style)
    assert isinstance(style, str)



# Generated at 2022-06-24 04:50:57.210779
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg
    r = Register()
    r.red = Style(RgbFg(255, 17, 81))

    assert(r.red == "\x1b[38;2;255;17;81m")

    r.mute()

    assert(r.red == "\x1b[0m")

# Generated at 2022-06-24 04:51:05.655502
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This test verifies that the method __setattr__ works as expected.
    """
    from sty import fg

    # Save old bg.green attr
    bg_green_old_value = fg.green

    # Create new style.
    fg.green = Style(fg.green, "foo", fg.blue)

    # Save new bg.green attr
    bg_green_new_value = fg.green

    # Assert that bg.green attrs are diferent.
    assert bg_green_new_value.value != bg_green_old_value.value

    # Assert that bg.green has the correct value

# Generated at 2022-06-24 04:51:07.683171
# Unit test for method __setattr__ of class Register
def test_Register___setattr__(): pass
    # TODO: write test for __getattribute__
    # TODO: write test for __getattr__

# Generated at 2022-06-24 04:51:10.697985
# Unit test for constructor of class Style
def test_Style():
    assert Style("red", "red", value="\x1b[31m\x1b[31m") == "\x1b[31m\x1b[31m"

# Generated at 2022-06-24 04:51:14.146485
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()

    setattr(r, "test1", Style())
    setattr(r, "test2", Style())

    assert isinstance(r.as_dict(), dict)



# Generated at 2022-06-24 04:51:22.152426
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: x)
    r.set_rgb_call(RenderType)
    r.set_eightbit_call(RenderType)
    r.rgb = Style(RenderType(1,2,3))
    r.eightbit = Style(RenderType(42))
    assert(r.rgb == "\x1b[1;2;3m")
    assert(r.eightbit == "\x1b[42m")
    assert(r(0) == "\x1b[0m")
    assert(r(1,2,3) == "\x1b[1;2;3m")
    r.mute()
    assert(r.rgb == "")
    assert(r.eightbit == "")

# Generated at 2022-06-24 04:51:32.732527
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test __setattr__ method of class Register
    """
    class MyRegister(Register):
        pass

    r = MyRegister()

    r.woot = Style(RgbFg(0, 0, 0))
    assert isinstance(r.woot, Style)

    # Set an attribute that is not a Style or Register
    # This should just set it normally (no error)
    r.foo = 42
    assert r.foo == 42

    # Set an attribute that is a Style but contains a string as value.
    # There should be no error.
    r.bar = Style("Nord", "Green")
    assert isinstance(r.bar, Style)
    assert isinstance(r.bar, str)
    assert r.bar == "NordGreen"

    # Set an attribute that is a string (not a Style).

# Generated at 2022-06-24 04:51:35.275890
# Unit test for method unmute of class Register
def test_Register_unmute():
    reg = Register()
    reg.bright = Style(Sgr(1))
    reg.red = Style(Sgr(31))

    reg.unmute()

    assert str(reg.red) == "\x1b[31m"



# Generated at 2022-06-24 04:51:45.832431
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import RgbFg, Sgr
    from .registers import fg

    new_fg = fg.copy()

    # test if copy is different from original
    assert fg != new_fg

    # test if copy has same rules as original
    assert new_fg.bold == fg.bold

    # test if copy has same renderfuncs as original
    assert new_fg.renderfuncs == fg.renderfuncs

    # test if a style attribute (e.g. 'bold') is copied properly
    assert new_fg.bold == Style(Sgr(1), RgbFg(100,100,100), Sgr(22))

# Generated at 2022-06-24 04:51:52.240765
# Unit test for constructor of class Register
def test_Register():
    # Basic test: No renderfuncs
    assert Register().renderfuncs == {}
    assert Register().is_muted is False
    assert str(Register().eightbit_call(0)) == "0"
    assert str(Register().rgb_call(0, 0, 0)) == "0,0,0"



# Generated at 2022-06-24 04:51:55.464205
# Unit test for method __new__ of class Style
def test_Style___new__():
    class Test(Style):
        pass

    t = Test("Test")
    assert isinstance(t, Test)
    assert isinstance(t, str)



# Generated at 2022-06-24 04:51:58.295881
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import Fg
    from .sgr import Bold

    s = Style(Bold(), Fg(50))

    assert isinstance(s, Style)



# Generated at 2022-06-24 04:52:07.142211
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import Sgr

    register = Register()
    register.set_renderfunc(Sgr, lambda x, y: "")
    register.bold = Style(Sgr(1))

    register_copy = register.copy()

    assert register.bold == register_copy.bold
    assert register.is_muted != register_copy.is_muted
    assert register.eightbit_call != register_copy.eightbit_call
    assert register.rgb_call != register_copy.rgb_call
    assert register.renderfuncs != register_copy.renderfuncs

if __name__ == "__main__":
    test_Register_copy()

# Generated at 2022-06-24 04:52:15.725832
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertypes import SgrEightbit, RgbFg

    # Create Register instance
    r: Register = Register()

    # Define two render-methods
    sgr_eightbit_call = lambda x: f"\033[48;5;{x}m"
    rgb_call = lambda r, g, b: f"\033[48;2;{r};{g};{b}m"

    # Save render-methods in register
    r.set_renderfunc(SgrEightbit, sgr_eightbit_call)
    r.set_renderfunc(RgbFg, rgb_call)

    # Set eightbit-call
    r.set_eightbit_call(SgrEightbit)

    # Create a style-attribute
    r.red = Style(SgrEightbit(9))

    #

# Generated at 2022-06-24 04:52:26.705372
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .ansi import Sgr, RgbFg

    # Test 1: The initalized style should contain the rules and the ANSI-style.
    style1 = Style(Sgr(1), RgbFg(1, 5, 10), value="\x1b[1;38;2;1;5;10m")
    assert style1.rules == (Sgr(1), RgbFg(1, 5, 10))
    assert style1 == "\x1b[1;38;2;1;5;10m"

    # Test 2: Style should not be affected by changes of value.
    style1 = Style(Sgr(1), RgbFg(1, 5, 10), value="\x1b[1;38;2;1;5;10m")

# Generated at 2022-06-24 04:52:36.847912
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr, RgbFg, RgbBg
    from .render import render_sgr, render_rgb

    reg = Register()
    reg.set_renderfunc(Sgr, render_sgr)
    reg.set_renderfunc(RgbFg, render_rgb)
    reg.set_renderfunc(RgbBg, render_rgb)

    # Test existing render-func
    assert reg.renderfuncs.get(Sgr) == render_sgr

    # Test new render-func
    reg.set_renderfunc(Sgr, lambda x: f"custom render-func for Sgr({x}).")

# Generated at 2022-06-24 04:52:43.735305
# Unit test for method mute of class Register
def test_Register_mute():
    
    rs = Register()

    assert rs.is_muted == False
    rs.mute()
    assert rs.is_muted == True

    attr_dict = dict()
    for name in dir(rs):
        if not name.startswith("_") and isinstance(getattr(rs, name), str):
            attr_dict[name] = getattr(rs, name)
    
    for name, value in attr_dict.items():
        assert value == ''


# Generated at 2022-06-24 04:52:50.411286
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Initialize test register
    register = Register()
    register.set_eightbit_call(RenderType.Eightbit)

    # Set up test data
    num = 42

    # Render with Sty
    expected = RenderType.Eightbit(num)()

    # Test set_eightbit_call
    register.set_eightbit_call(RenderType.Rgb)

    # Render with Sty
    actual = register(num)

    # Assertions
    assert actual == expected

# Generated at 2022-06-24 04:52:57.013609
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test for method 'set_renderfunc' of class Register.
    """
    from .rendertype import RgbFg, Sgr

    def render_func(x: int) -> str:
        return str(x)

    reg = Register()
    reg.set_renderfunc(RgbFg, render_func)
    reg.set_renderfunc(Sgr, render_func)

    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert reg.red == "255010"

# Generated at 2022-06-24 04:53:07.903743
# Unit test for method unmute of class Register
def test_Register_unmute():
    r1 = Register()
    r1.is_muted = True
    r1.foo = Style("\x1b[38;2;1;5;10m\x1b[1m")
    r1.bar = Style("\x1b[38;2;102;42;123m\x1b[1m")

    r1.foo == ""
    r1.bar == ""
    
    r1.unmute()

    assert r1.foo == "\x1b[38;2;1;5;10m\x1b[1m"
    assert r1.bar == "\x1b[38;2;102;42;123m\x1b[1m"


# Generated at 2022-06-24 04:53:10.075527
# Unit test for constructor of class Style
def test_Style():
    """
    Unit test to make sure that Style objects are preserved as we expect them to be.
    """
    pass

# Generated at 2022-06-24 04:53:21.877990
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    The function should update a style attrib based on a changed renderfunc.
    """

    # Setup
    class Foo(RenderType):
        call = lambda x, y: f"Foo: {x},{y}"

    class Bar(RenderType):
        call = lambda x, y: f"Bar: {x},{y}"

    class StyTest:
        foo = Style(Foo(42, 24), Bar(24, 42))  # This style should be updated.

    stytest = StyTest()

    # Execute
    assert str(stytest.foo) == "Foo: 42,24Bar: 24,42"

    stytest.set_renderfunc(Foo, lambda x, y: f"Foo: {y},{x}")

    # Verify

# Generated at 2022-06-24 04:53:25.421912
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    r = Register()

    class Foo(RenderType):
        pass

    a = Foo(123)
    setattr(r, "foo", Style(a))

    assert r.foo.rules == (a, )
    assert r.foo == "123"

# Generated at 2022-06-24 04:53:31.971085
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Test with normal and with muted register
    r1 = Register()
    r2 = Register()
    r2.mute()

    # Set attribute
    setattr(r1, "test", Style(RgbBg(10,20,30)))
    setattr(r2, "test", Style(RgbBg(10,20,30)))

    assert str(getattr(r1, "test")) == "\x1b[48;2;10;20;30m"
    assert str(getattr(r2, "test")) == ""
    r2.unmute()
    assert str(getattr(r2, "test")) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-24 04:53:38.203806
# Unit test for method mute of class Register
def test_Register_mute():
    import sty
    fg = sty.fg
    fg.black =  Style(fg.RgbFg(0,0,0))
    fg.mute()
    assert not hasattr(fg, 'black')
    fg.unmute()
    assert hasattr(fg, 'black')

# Generated at 2022-06-24 04:53:41.434132
# Unit test for constructor of class Register
def test_Register():
    assert issubclass(Register, object)
    assert Register().rgb_call is not None
    assert Register().eightbit_call is not None
    assert Register().renderfuncs is not None
    assert Register().is_muted is False


# Generated at 2022-06-24 04:53:49.206706
# Unit test for method unmute of class Register
def test_Register_unmute():
    fg = Register()
    fg.black = Style(RgbFg(255, 0, 0))

    # Testcase 1
    # Call fg.black before unmuting
    assert fg.black == "\x1b[38;2;255;0;0m"

    # Unmute register
    fg.unmute()

    # Call fg.black after unmuting
    assert fg.black == "\x1b[38;2;255;0;0m"


# Generated at 2022-06-24 04:54:00.001160
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test the magic method __call__ of class Register.
    """

    class TestRegister(Register):
        """
        A test class.
        """

        def __new__(cls, *args, **kwargs):
            instance = super().__new__(cls, *args, **kwargs)
            instance.one = Style(Sgr(1))
            instance.two = Style(Sgr(2))
            instance.three = Style(Sgr(3))
            instance.four = Style(Sgr(4))
            return instance

    # Test 1: Call register with number.
    reg = TestRegister()
    reg.set_eightbit_call(Sgr)
    assert reg(1) == "\x1b[1m"

    # Test 2: Call register with number-tuple.
    reg = TestRegister

# Generated at 2022-06-24 04:54:12.039338
# Unit test for method copy of class Register
def test_Register_copy():
    from .registers import fg, bg
    r1 = fg.red
    r2 = bg.blue

    fg_copy = fg.copy()

    assert fg_copy is not fg
    assert fg_copy.eightbit_call is not fg.eightbit_call
    assert fg_copy.rgb_call is not fg.rgb_call
    assert fg_copy.renderfuncs is not fg.renderfuncs
    assert fg.red is r1
    assert fg_copy.red is r1
    assert fg_copy.green is not r2
    assert fg_copy.red_0 is not r2

    bg_copy = bg.copy()

    assert bg_copy is not bg

# Generated at 2022-06-24 04:54:21.897611
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg, Sgr

    style1 = Style(RgbFg(1, 5, 3), Sgr(1), RgbFg(5, 4, 2), value="\x1b[38;2;1;5;3m\x1b[1m\x1b[38;2;5;4;2m")
    assert style1 == "\x1b[38;2;1;5;3m\x1b[1m\x1b[38;2;5;4;2m"
    assert style1.rules == (RgbFg(1, 5, 3), Sgr(1), RgbFg(5, 4, 2))
    assert isinstance(style1, str)


# Generated at 2022-06-24 04:54:27.783407
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    tr = TestRegister()
    tr.test = Style(value="test")
    assert tr.test == "test"

    tr.test = Style(value="test1")
    assert tr.test == "test1"


# Generated at 2022-06-24 04:54:35.473333
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg
    from sty.colors import RgbFg
    from sty.sgr import Bold

    # Make sure that both the strings and the names are correct for the namedtuple.
    red = fg(255, 0, 0)
    assert red == red.as_namedtuple().red == '\x1b[38;2;255;0;0m'
    assert 'red' in dir(red.as_namedtuple())

    # Make sure that the names of the namedtuple are unique.
    blue = fg(0, 0, 255)
    orange = fg(255, 165, 0)
    fg.orange = Style(RgbFg(255, 165, 0), Bold)

# Generated at 2022-06-24 04:54:43.244804
# Unit test for constructor of class Register
def test_Register():

    from .rendertype.base import Base

    class TestRtype(RenderType):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    def f1(*args, **kwargs):
        return f"{args}{kwargs}"

    r1 = Register()

    r1.set_renderfunc(TestRtype, f1)

    r1.test = Style(TestRtype(1, 2, a=1, b=2))

    assert str(r1.test) == "((1, 2), {'a': 1, 'b': 2})"


# Generated at 2022-06-24 04:54:45.687981
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.set_rgb_call(RgbFg)
    assert str(r(255, 0, 0)) == "\x1b[38;2;255;0;0m"
    assert r.red == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-24 04:54:51.381892
# Unit test for method copy of class Register
def test_Register_copy():

    from . import fg, bg, ef, rs

    r = fg.copy()

    assert id(r) != id(fg)
    assert id(fg.red) != id(r.red)

    r.red = Style(r.rgb_to_ansi(200, 20, 10))

    assert r.red != fg.red

# Generated at 2022-06-24 04:54:59.094978
# Unit test for method unmute of class Register
def test_Register_unmute():

    def test_func(x: int) -> str: return str(x)

    r = Register()
    r.set_renderfunc(RenderType, test_func)
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    # Create attibute 'black' with style 0
    r.black = Style(RenderType(0))

    # Renders as expected
    assert str(r.black) == test_func(0)

    # Mute - renders empty string
    r.mute()
    assert str(r.black) == ""

    # Unmute - renders again as expected
    r.unmute()
    assert str(r.black) == test_func(0)



# Generated at 2022-06-24 04:55:04.143931
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Test 1: set_renderfunc is working
    # ---------------------------------
    class RenderFuncTest(RenderType):
        pass

    def func(render_self, *args):
        return f"{args[0]}"

    register = Register()
    register.set_renderfunc(RenderFuncTest, func)
    register.foo = Style(RenderFuncTest(100))

    assert str(register.foo) == "100"

    # Test 2: Overwrite existing renderfunc
    # -------------------------------------
    def func_new(render_self, *args):
        return f"{args[0]}"

    register = Register()
    register.set_renderfunc(RenderType, func_new)
    register.set_eightbit_call(RenderType)
    register.set_rgb_call(RenderType)


# Generated at 2022-06-24 04:55:06.820168
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .main import fg
    fg("red")
    cls = fg.as_namedtuple()
    assert cls.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:55:14.445273
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Some dummy classes
    class RenderTypeA(RenderType):
        def __init__(self, a: int):
            self.args = (a,)

        def get_start_sequence(self) -> str:
            return f"A{self.args[0]}"

        def get_reset_sequence(self) -> str:
            return "A0"

    class RenderTypeB(RenderType):

        def __init__(self, b: int):
            self.args = (b,)

        def get_start_sequence(self) -> str:
            return f"B{self.args[0]}"

        def get_reset_sequence(self) -> str:
            return "B0"

    # Dummy render function for random render type.
    def renderfunc(arg: int):
        return f"S{arg}"



# Generated at 2022-06-24 04:55:18.612442
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert not r.is_muted

# Generated at 2022-06-24 04:55:29.292560
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Unit test for method as_namedtuple of class Register
    """
    def _new_reg(rgb) -> Register:
        reg = Register()
        reg.background = Style(rgb)
        reg.foreground = Style(rgb)
        return reg

    reg1 = _new_reg(RenderType())
    reg2 = _new_reg(RenderType())
    reg1.set_renderfunc(RenderType, lambda x: f"\x1b[38;2;{x[0]};{x[1]};{x[2]}m")
    reg2.set_renderfunc(RenderType, lambda x: f"\x1b[48;2;{x[0]};{x[1]};{x[2]}m")


# Generated at 2022-06-24 04:55:39.061520
# Unit test for constructor of class Style
def test_Style():
    print("Test Style:")
    # Example 1
    print("Example 1:")
    print("Style(RgbFg())")
    s1 = Style(RgbFg())
    print(s1)
    print(s1.rules)
    # Example 2
    print("Example 2:")
    print("Style(RgbFg(), Bold())")
    s2 = Style(RgbFg(), Bold())
    print(s2)
    print(s2.rules)
    # Example 3
    print("Example 3:")
    print("Style(Style(Bold()), Style(Underline(), Inverse()))")
    s3 = Style(Style(Bold()), Style(Underline(), Inverse()))
    print(s3)
    print(s3.rules)
    # Example 4
   

# Generated at 2022-06-24 04:55:42.284066
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import pytest
    from .registers import fg

    nt = fg.as_namedtuple()

    assert isinstance(nt, namedtuple)
    assert hasattr(nt, "default")
    assert nt.default == fg.default

# Generated at 2022-06-24 04:55:51.722347
# Unit test for constructor of class Style
def test_Style():

    class RgbFg:
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    class RgbBg:
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    class Sgr:
        def __init__(self, n):
            self.args = (n, )

    def render_rgb_fg(r, g, b):
        return "\x1b[38;2;{0};{1};{2}m".format(r, g, b)

    def render_rgb_bg(r, g, b):
        return "\x1b[48;2;{0};{1};{2}m".format(r, g, b)


# Generated at 2022-06-24 04:55:59.759812
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import Rgb

    r = Register()

    # Add render method for Sgr(38)
    r.set_renderfunc(Rgb, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set render method for the RGB-call.
    r.set_rgb_call(Rgb)

    # Check if calling with RGB-values returns the expected string.
    assert r(42, 42, 42) == "\x1b[38;2;42;42;42m"



# Generated at 2022-06-24 04:56:06.745532
# Unit test for constructor of class Style
def test_Style():
    # Instantiate
    s: Style = Style(RgbFg(1, 1, 1), RgbBg(2, 2, 2))

    # Test for style rules.
    assert (s.rules[0] == RgbFg(1, 1, 1))
    assert (s.rules[1] == RgbBg(2, 2, 2))

    # Test for string representation.
    assert (str(s) == "\x1b[38;2;1;1;1m\x1b[48;2;2;2;2m")



# Generated at 2022-06-24 04:56:15.946781
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr
    from .ansi import SgrFunc

    class MyRegister(Register):
        pass

    r = MyRegister()

    assert "Sgr" not in r.renderfuncs

    r.set_renderfunc(Sgr, SgrFunc)

    assert "Sgr" in r.renderfuncs
    assert r.renderfuncs["Sgr"] == SgrFunc

    r.set_renderfunc(Sgr, lambda x: f"--{x}--")

    assert "Sgr" in r.renderfuncs
    assert r.renderfuncs["Sgr"] != SgrFunc
    assert r.renderfuncs["Sgr"](1) == "--1--"

# Generated at 2022-06-24 04:56:27.462061
# Unit test for method __call__ of class Register
def test_Register___call__():

    import pytest


# Generated at 2022-06-24 04:56:38.471664
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Tests whether set_renderfunc works with a given rendertype.

    It is tested if an Eightbit-call is rendered by the new renderfunc.

    e.g.:
        reg.set_renderfunc(RgbFg, r)
        reg.set_renderfunc(Sgr, s)
        reg.green    # "\x1b[32m"
        reg(1)       # "\x1b[38;2;255;0;0m"

    """

    # def test_render_func(code, *args) -> str: return '\x1b[38;2;{};{};{}m'.format(*args)
    # test_reg = Register()

    # test_reg.set_renderfunc(RgbFg, test_render_func)
    # test_reg.green = Style(R

# Generated at 2022-06-24 04:56:45.310549
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    SetFg = fg.as_namedtuple()

    assert isinstance(SetFg, NamedTuple)
    assert SetFg.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:56:54.680091
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .style import Style
    from .register import Register
    from .rendertype import RgbFg, Sgr
    reg = Register()
    reg.rgb = Style(RgbFg(10, 42, 255), Sgr(1))
    assert str(reg.rgb) == "\x1b[38;2;10;42;255m\x1b[1m"
    reg.mute()
    assert str(reg.rgb) == ""
    reg.unmute()
    assert str(reg.rgb) == "\x1b[38;2;10;42;255m\x1b[1m"



# Generated at 2022-06-24 04:57:06.475133
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class Rendertype1(RenderType):
        def __init__(self, a: int, b: int):
            super().__init__(a, b)

        def __repr__(self):
            return f"Foo(a={self.a}, b={self.b})"

    class Rendertype2(RenderType):
        def __init__(self, c: int, d: int):
            super().__init__(c, d)

        def __repr__(self):
            return f"Bar(c={self.c}, d={self.d})"

    def renderfunc1(a: int, b: int) -> str:
        return str(Rendertype1(a, b))


# Generated at 2022-06-24 04:57:15.266806
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty import Fg, Bg, Rs, Ef, RgbFg, RgbBg, RgbEf


# Generated at 2022-06-24 04:57:26.373115
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Rule1(RenderType):
        __slots__ = ["args"]

        def __init__(self, *args):
            self.args = args

    class Rule2(RenderType):
        __slots__ = ["args"]

        def __init__(self, *args):
            self.args = args

    def f1(*args):
        return "f1" + str(args)

    def f2(*args):
        return "f2" + str(args)

    renderfunc_dict = {Rule1: f1, Rule2: f2}

    a = Register()
    a.set_renderfunc(Rule1, f1)
    a.set_renderfunc(Rule2, f2)

    rule1 = Rule1(42)
    rule2 = Rule2(143)

# Generated at 2022-06-24 04:57:33.897781
# Unit test for constructor of class Register
def test_Register():

    from .colortype import ColorType  # type: ignore
    from .rendertype import Ansi256Fg, RgbFg  # type: ignore

    def render_ansi256(one: int, two: int = 0) -> str:
        return "\x1b[" + str(one) + ";" + str(two) + "m"

    def render_rgb(one: int, two: int, three: int) -> str:
        return "\x1b[" + str(one) + ";" + str(two) + ";" + str(three) + "m"

    def render_rgb_bg(one: int, two: int, three: int) -> str:
        return "\x1b[" + str(one) + ";" + str(two) + ";" + str(three) + "m"

   

# Generated at 2022-06-24 04:57:38.810275
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test method 'copy' of class Register.
    """
    r1 = Register()
    r1.blue = Style(RgbFg(0, 0, 255))
    r2 = r1.copy()
    assert r1.blue == r2.blue
    assert r1 is not r2

# Generated at 2022-06-24 04:57:43.214006
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class X:
        pass

    class Y:
        pass

    def f(x):
        return x

    r = Register()
    r.set_renderfunc(X, f)
    assert r.renderfuncs[X] == f

    r.set_renderfunc(Y, f)
    assert r.renderfuncs[Y] == f



# Generated at 2022-06-24 04:57:51.250497
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertypes import SgrFg, RgbFg

    r1 = Register()
    r1.set_renderfunc(SgrFg, lambda x: f"SGRFG-{x}")

    r2 = Register()
    r2.set_renderfunc(RgbFg, lambda r, g, b: f"RGBFG-{r}-{g}-{b}")

    r1.set_eightbit_call(SgrFg)
    r2.set_rgb_call(RgbFg)

    assert r1(42) == "SGRFG-42"
    assert r2(42, 10, 13) == "RGBFG-42-10-13"



# Generated at 2022-06-24 04:58:00.947406
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register.
    """
    def func(code: int = None, *args) -> str:
        return str(code)

    a = Register()
    a.set_rgb_call(RenderType.RgbFg)
    a.set_eightbit_call(RenderType.EightbitFg)
    a.set_renderfunc(RenderType.EightbitFg, func)
    a.set_renderfunc(RenderType.RgbFg, func)
    a.red = Style(RenderType.EightbitFg(9))
    a.q = Style(RenderType.RgbBg(1,1,1))

    b = a.copy()

    assert a.as_dict() == b.as_dict()

    assert a is not b


# Generated at 2022-06-24 04:58:07.544455
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, RgbBg
    from .renderfunc import render_rgb_fg, render_rgb_bg
    from .builder import Builder

    register = Register()
    register.set_renderfunc(RgbFg, render_rgb_fg)
    register.set_renderfunc(RgbBg, render_rgb_bg)

    register.red_fg = Style(RgbFg(255, 0, 0))
    register.red_bg = Style(RgbBg(255, 0, 0))

    builder = Builder()
    builder.register(register)

    assert builder.render("\x1b[38;2;255;0;0mRed\x1b[39mText\x1b[0m") == "RedText"

# Generated at 2022-06-24 04:58:16.503033
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .sgr import Sgr
    from .rgb import RgbFg

    # Crate a register with two styles.
    register = Register()
    setattr(register, "red", Style(RgbFg(255, 0, 0), Sgr(1)))
    setattr(register, "blue", Style(RgbFg(0, 0, 255), Sgr(2)))

    # Test if values are set as Style-objects.
    assert isinstance(getattr(register, "red"), Style)
    assert isinstance(getattr(register, "blue"), Style)

    # Test if values are set correctly.
    assert register.red.rules == (RgbFg(255, 0, 0), Sgr(1))
    assert register.blue.rules == (RgbFg(0, 0, 255), Sgr(2))



# Generated at 2022-06-24 04:58:25.043806
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr, XTermFg

    r = Register()

    r.set_renderfunc(XTermFg, lambda x: f"\x1b[38;5;{x}m")

    r.set_eightbit_call(XTermFg)

    r.eightbit_call(100) == r(100)

    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}")

    r.set_eightbit_call(RgbFg)

    assert r.eightbit_call(11, 22, 33) == r(11, 22, 33)

    r.set_eightbit_call(Sgr)


# Generated at 2022-06-24 04:58:34.005896
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty import ANSIFg

    r = Register()

    setattr(r, "red", Style(ANSIFg(221)))
    r42 = Style(ANSIFg(42))
    setattr(r, "red42", r42)

    assert r("red") == "\x1b[38;2;221;0;0m"
    assert r("red42") == "\x1b[38;2;221;0;0m\x1b[38;2;0;128;0m"
    assert r(42) == ""
    assert r(42, 123, "abc") == ""



# Generated at 2022-06-24 04:58:42.762357
# Unit test for method copy of class Register
def test_Register_copy():
    import pytest
    register = Register()
    register.red = Style(RgbFg(255, 0, 0))
    register.green = Style(RgbFg(0, 255, 0))
    copy_register = register.copy()

    # Verify safety of copy
    copy_register.set_renderfunc(RgbFg, lambda r, g, b: f"{r},{g},{b}")
    assert copy_register.red == "255,0,0"
    assert register.red == register.red.rules[0].ansi

    # Verify safety of copy
    copy_register.red = Style(RgbFg(0, 255, 0))
    assert register.red == register.red.rules[0].ansi



# Generated at 2022-06-24 04:58:47.029687
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    import pytest

    r: Register = Register()
    r.set_renderfunc(RenderType, lambda x: x * 2)

    # assert without call to set_eightbit_call
    assert r(1) == "22"

    # set eightbit-rendertype to RenderType
    r.set_eightbit_call(RenderType)

    # assert with call to set_eightbit_call
    assert r(1) == "22"

    # assert correct behavior if non-existing rendertype is used with call to
    # set_eightbit_call
    with pytest.raises(KeyError):
        r.set_eightbit_call(int)



# Generated at 2022-06-24 04:58:55.976310
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This unit test test the __setattr__ method of the
    Register class. It is necessary to overwrite the
    __setattr__ method, because the attributes of a
    Register object are Style objects and not strings.
    """

    # Define a renderfunc to use in this test.
    def renderfunc(arg):
        return str(arg)

    register = Register()
    register.set_renderfunc(RenderType, renderfunc)

    # Define a style with a render-type in it.
    style = Style(RenderType(1))

    # Set the style on the register object.
    # This should call the renderfunc of the rendertype.
    register.test_style = style

    # The value of the style attribute should be '1'
    assert register.test_style == "1"

    # The value of the attribute should

# Generated at 2022-06-24 04:58:59.901287
# Unit test for constructor of class Style
def test_Style():
    style = Style(RenderType(1), RenderType(2, 5), RenderType(3, 10, 44))
    assert len(style.rules) == 3
    assert isinstance(style, Style)
    assert isinstance(style, str)

# Generated at 2022-06-24 04:59:02.343826
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty.rendertype import RgbBg

    sty = Register()
    sty.white = Style(RgbBg(255, 255, 255))

    d = sty.as_dict()

    assert isinstance(d, dict)
    assert d['white'] == "\x1b[48;2;255;255;255m"

# Generated at 2022-06-24 04:59:13.963434
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from . import ef, fg, bg
    from .rendertype import RgbFg

    # Create new register
    class MyRegister(Register):
        pass

    myregister = MyRegister()
    myregister.test = Style(ef.italic)

    # Check that myregister.test is of type Style
    assert isinstance(myregister.test, Style)
    # Check that myregister.test is of type str
    assert isinstance(myregister.test, str)

    # Check that myregister.test.rules is a tuple
    assert isinstance(myregister.test.rules, tuple)

    # Create style with new renderfunc and set it to register.
    def myrenderfunc(*args, **kwargs):
        return f"\x1b[{args[0]}]"


# Generated at 2022-06-24 04:59:16.657261
# Unit test for constructor of class Style
def test_Style():
    """
    Test the constructor of class Style
    """
    style = Style(
        fg=100,
        bg=100,
    )

    assert isinstance(style, Style)



# Generated at 2022-06-24 04:59:27.148985
# Unit test for method mute of class Register
def test_Register_mute():

    def _eightbit_call(x):
        return x

    def _rgb_call(r, g, b):
        return (r, g, b)

    def _render_type1(x):
        return x

    def _render_type2(r, g, b):
        return (r, g, b)

    Reg = Register()

    Reg.set_eightbit_call(int)
    Reg.set_rgb_call(int)

    # Add rendertype
    Reg.set_renderfunc(int, _render_type1)
    Reg.set_renderfunc(int, _render_type2)

    Reg.test1 = Style(10, 20)
    Reg.test2 = Style(30, 40)

    Reg("test1")
    Reg("test2")
    Reg(10)
   