

# Generated at 2022-06-24 04:49:28.444717
# Unit test for method __new__ of class Style
def test_Style___new__():
    class SomeRenderType(RenderType):

        def __init__(self, value: int):
            self.args = (value,)

        def render(self):
            return f"\x1b[{self.args[0]}m"

    renderfuncs = {SomeRenderType: SomeRenderType.render}

    style = Style(SomeRenderType(1), SomeRenderType(2), value="")
    style_1, rules_1 = _render_rules(renderfuncs, style.rules)
    assert style_1 == "\x1b[1m\x1b[2m"
    assert rules_1 == [SomeRenderType(1), SomeRenderType(2)]

    style = Style(SomeRenderType(1), SomeRenderType(2), value="\x1b[1m\x1b[2m")
    style_

# Generated at 2022-06-24 04:49:34.274706
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_eightbit_call(RenderType)
    r1.set_rgb_call(RenderType)

    r2 = r1.copy()
    assert r1 is not r2
    assert r1.renderfuncs is not r2.renderfuncs



# Generated at 2022-06-24 04:49:38.266888
# Unit test for constructor of class Style
def test_Style():
    from .rendertypes import RgbFg, Sgr
    style = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-24 04:49:49.593296
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Create a mock-register
    class MockRegister(Register):
        def __init__(self):
            super().__init__()
            self.set_eightbit_call(RgbFg)

    r = MockRegister()

    # Create a style rule
    a = Style(RgbFg(1, 2, 3), Sgr(4))
    r.a = a

    # Create a style rule that calls another style rule
    b = Style(r.a, Sgr(7))
    r.b = b

    assert str(r("a")) == "\x1b[38;2;1;2;3m"
    assert str(r("b")) == "\x1b[38;2;1;2;3m\x1b[4m\x1b[7m"


# Generated at 2022-06-24 04:50:00.683145
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rgb import RgbFg
    from .sgr import Sgr

    reg = Register()
    reg.set_renderfunc(RgbFg, lambda x, y, z: f"\x1b[38;2;{x};{y};{z}m")
    reg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    reg.eightbit = Style(
        Sgr(7), RgbFg(*reg.rgb_call(10, 20, 30))
    )
    assert str(reg.eightbit) == "\x1b[7m\x1b[38;2;10;20;30m"

# Generated at 2022-06-24 04:50:02.999524
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg

    assert isinstance(fg.as_namedtuple(), NamedTuple)
    assert fg.as_namedtuple().red == fg.red

# Generated at 2022-06-24 04:50:05.975248
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from . import core

    reg = core.fg.copy().mute()
    reg.aquamarine = Style(RgbFg(127, 255, 212))

    NamedStyle = reg.as_namedtuple()

    assert NamedStyle.aquamarine == ""

# Generated at 2022-06-24 04:50:15.427060
# Unit test for method mute of class Register
def test_Register_mute():

    # Create register object
    r = Register()

    # Create some style
    r.one = Style(RgbFg(10, 11, 12))
    r.two = Style(RgbFg(20, 21, 22))

    # Create some render function
    def renderfunc(r: int, g: int, b: int) -> str:
        return f"{r}{g}{b}"

    # Set render functions
    r.set_renderfunc(RgbFg, renderfunc)

    # Set rgb call
    r.set_rgb_call(RgbFg)

    # r.one should be "101112"
    # r.two should be "202122"

    # Calling register object
    r(10, 11, 12) # "101112"
    r(20, 21, 22) # "202122

# Generated at 2022-06-24 04:50:25.837182
# Unit test for method copy of class Register
def test_Register_copy():

    # Create a new register object and fill it with style rules.
    r1 = Register()
    r1.green = Style(RgbFg(10, 20, 30))
    r1.blue = Style(RgbFg(40, 50, 60), Sgr(1))

    # Make a copy of r1 and fill it with style rules.
    r2 = r1.copy()
    r2.red = Style(Sgr(2))
    r2.orange = Style(Sgr(4))

    # Check that r1 is not changed after filling r2.
    assert r1.green == Style(RgbFg(10, 20, 30))
    assert r1.blue == Style(RgbFg(40, 50, 60), Sgr(1))
    assert "red" not in dir(r1)

# Generated at 2022-06-24 04:50:34.849448
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    r = Register()

    r.A = Style(RgbFg(1, 2, 3), Sgr(1))
    r.B = Style(r.A, RgbFg(4, 5, 6))

    assert r.A == "\x1b[38;2;1;2;3m\x1b[1m"
    assert r.B == "\x1b[38;2;1;2;3m\x1b[1m\x1b[38;2;4;5;6m"

# Generated at 2022-06-24 04:50:37.673694
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    attr = "test"
    r.test = Style(RenderType())
    assert getattr(r, attr) == getattr(r.copy(), attr) == Style(RenderType()).__str__()
    r.test = r.test
    assert r.test is r.copy().test


# Generated at 2022-06-24 04:50:41.466476
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Default Register object.
    class Fg(Register):
        pass

    fg = Fg()
    fg.test = Style(value="test")

    # CONVERT STYLE TO NORMAL STRING
    fg.is_muted = True

    assert fg.test == "test"
    assert len(str(fg.test)) == 4



# Generated at 2022-06-24 04:50:48.733643
# Unit test for method __new__ of class Style
def test_Style___new__():

    s = Style(RgbBg(10, 42, 255), RgbFg(42, 255, 10), value="\x1b[42m")
    assert isinstance(s, Style)
    assert isinstance(s, str)

    assert str(s) == "\x1b[42m"
    assert s.rules == (RgbBg(10, 42, 255), RgbFg(42, 255, 10))

# Generated at 2022-06-24 04:50:54.130246
# Unit test for method __call__ of class Register
def test_Register___call__():

    style_ = Style(rendertypes.RgbFg(1, 2, 3), rendertypes.Sgr(7))

    register = Register()

    register.test_ = style_

    assert register("test_") == str(style_)

    assert register(1, 2, 3) == register.rgb_call(1, 2, 3)
    assert register(42) == register.eightbit_call(42)

# Generated at 2022-06-24 04:51:00.510666
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .rendertype import sgr, fg

    r = Register()
    r.foo = Style(sgr(32), fg(100))
    r.bar = Style(sgr(1))

    d = r.as_dict()

    assert isinstance(d, dict)
    assert d["foo"] == "\x1b[32m\x1b[38;5;100m"
    assert d["bar"] == "\x1b[1m"



# Generated at 2022-06-24 04:51:06.848594
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class MyRegister(Register):
        red = Style(RgbFg(255, 0, 0))

    r = MyRegister()

    assert r("red") == "\x1b[38;2;255;0;0m"

    r.set_rgb_call(RgbFg)

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:51:16.702944
# Unit test for constructor of class Style
def test_Style():
    from . import fg, bg, ef, rs
    from .rendertype import Rgb, RgbFg, RgbBg, Sgr

    fg.orange = Style(RgbFg(10, 5, 1), Sgr(1))

    assert isinstance(fg.orange, Style)
    assert isinstance(fg.orange, str)
    assert str(fg.orange) == "\x1b[38;2;10;5;1m\x1b[1m"

    bg.orange = Style(RgbBg(10, 5, 1), Sgr(1))

    assert isinstance(bg.orange, Style)
    assert isinstance(bg.orange, str)

# Generated at 2022-06-24 04:51:22.496301
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Make sure that a ``Style``-object is rendered and saved in the instance
    of a ``Register``-object.
    """
    class RgbFg(RenderType):
        def render(self, *args):
            return "RgbFg"

    class RgbBg(RenderType):
        def render(self, *args):
            return "RgbBg"

    class RgbFg2(RenderType):
        def render(self, *args):
            return "RgbFg2"

    r = Register()
    r.set_renderfunc(RgbFg, lambda *a: "RgbFg")
    r.set_renderfunc(RgbBg, lambda *a: "RgbBg")

# Generated at 2022-06-24 04:51:32.867994
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test method __setattr__ of class Register.
    """

    def check_8bit_call(x):
        return x

    def check_rgb_call(r, g, b):
        return r, g, b

    register = Register()
    register.set_eightbit_call(RenderType)
    register.set_rgb_call(RenderType)
    register.set_renderfunc(RenderType, lambda *x: "")
    register.is_muted = False

    # Test eightbit call
    register.style_name = Style(RenderType(0))
    assert(register.style_name == "0")
    register.style_name(10)
    assert(check_8bit_call(10) == 10)

    # Test rgb call

# Generated at 2022-06-24 04:51:36.736284
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for method unmute of class Register.
    """
    fg: Register = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    assert str(fg.red) == "\x1b[38;2;255;0;0m"
    fg.unmute()
    assert str(fg.red) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:51:43.158228
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.bg = Style(RgbBg(20, 30, 40))
    r.mute()

    assert str(r.bg) == ""

    r.unmute()

    assert str(r.bg) == '\x1b[48;2;20;30;40m'



# Generated at 2022-06-24 04:51:46.756589
# Unit test for method unmute of class Register
def test_Register_unmute():

    fg: Register = Register()

    assert not fg.is_muted

    fg.mute()
    assert fg.is_muted

    fg.unmute()
    assert not fg.is_muted

    fg.mute()
    assert fg.is_muted

    fg.reset()
    assert not fg.is_muted


# Generated at 2022-06-24 04:51:58.763042
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from sty import fg, bg, ef, rs

    # RenderStyle is used as a placeholder for the expected result

# Generated at 2022-06-24 04:52:03.463960
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r: Register = Register()
    b: Style = Style(Fg(16))
    r.blue = b
    r.set_rgb_call(Fg)
    assert str(r(0, 0, 100)) == "\x1b[38;2;0;0;100m"


# Generated at 2022-06-24 04:52:05.213755
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(1), Style)
    assert isinstance(str(Style(1)), str)
    assert str(Style(1)) == "1"

# Generated at 2022-06-24 04:52:12.245194
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()

    # attributes that start with an underscore must be ignored
    setattr(reg, "_foo", Style(RgbBg(255, 255, 255)))

    # String objects must be ignored
    setattr(reg, "foo", "bar")

    # Style objects must be added to dict
    setattr(reg, "bar", Style(RgbBg(255, 255, 255), Bold))

    assert reg.as_dict() == {"bar": "\x1b[48;2;255;255;255m\x1b[1m"}



# Generated at 2022-06-24 04:52:17.984068
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register()

    # Test that the new object is a new instance.
    new_reg = reg.copy()
    assert id(reg) != id(new_reg)

    # Test that the new object has the same attributes.
    assert set(reg.__dict__.keys()) == set(new_reg.__dict__.keys())

    # Test that the new object has the same attribute-values.
    for key in reg.__dict__.keys():
        assert reg.__dict__[key] == new_reg.__dict__[key]

# Generated at 2022-06-24 04:52:27.547903
# Unit test for constructor of class Register
def test_Register():
    # Test basic attributes
    r = Register()
    assert isinstance(r, Register)
    assert r.is_muted == False
    assert r.eightbit_call(0) == ""
    assert r.rgb_call(0,0,0) == (0,0,0)
    assert r.renderfuncs == {}

    # Test that we are allowed to add attributes
    r.foobar = 42
    assert r.foobar == 42

    # Test that we can set class attributes
    r.test_attr = "mytest"
    assert r.test_attr == "mytest"
    test_attr = "test_attr"
    assert getattr(r, test_attr) == "mytest"
    assert hasattr(r, test_attr) == True
    assert r.__getattribute__(test_attr)

# Generated at 2022-06-24 04:52:29.082801
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class Foo(Register):
        pass

    foo = Foo()
    foo.blue = "blue"

    print(foo.as_namedtuple())


# Generated at 2022-06-24 04:52:31.699990
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .style import Style

    class TestRender(RenderType):
        def __init__(self, val):
            self.args = (val,)

    class TestRegister(Register):
        pass

    TestRegister.set_renderfunc(TestRender, lambda x: "dummy")

    test = TestRegister()
    test.test = Style(TestRender(10))

    assert test.test == "dummy"

# Generated at 2022-06-24 04:52:36.068021
# Unit test for constructor of class Register
def test_Register():
    """
    Test style attribute creation and color rendering in class Register.
    """
    # TODO: test_Register

    # Setup
    from .rendertype import Sgr, RgbFg

    renderfuncs: Renderfuncs = {
        Sgr: lambda *args: "\x1b[{}]".format(args[0]),
        RgbFg: lambda *args: "\x1b[38;2;{};{};{}m".format(args[0], args[1], args[2])
    }

    register = Register()
    register.set_renderfunc(RgbFg, renderfuncs[RgbFg])
    register.set_renderfunc(Sgr, renderfuncs[Sgr])

    # Define style attribute and check output.

# Generated at 2022-06-24 04:52:41.625451
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .register import Register
    from .eightbit import EightbitFg, EightbitBg

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(EightbitFg(1))

    r = MyRegister()
    assert str(r.red) == '\x1b[38;5;1m'
    r.set_eightbit_call(EightbitBg)
    assert str(r.red) == '\x1b[48;5;1m'


# Generated at 2022-06-24 04:52:47.337806
# Unit test for method copy of class Register
def test_Register_copy():
    fg = Register()

    fg.red = Style(RgbFg(1, 2, 3))
    fg.blue = Style(RgbFg(3, 2, 1))

    # Deepcopy register
    fg_copy = fg.copy()

    # Update red colour
    fg.red = Style(RgbFg(6, 5, 4))

    # Test
    assert fg.red == Style(RgbFg(6, 5, 4))
    assert fg_copy.red == Style(RgbFg(1, 2, 3))



# Generated at 2022-06-24 04:52:56.714891
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class Dummy(RenderType):
        pass

    class Dummy4(RenderType):
        pass

    class Dummy5(RenderType):
        pass

    def func1(*args):
        return 1

    def func2(*args):
        return 2

    def func3(*args):
        return 3

    def func4(*args):
        return 4

    def func5(*args):
        return 5

    reg = Register()

    # Add callables for Dummy and Dummy2 to register.
    reg.set_renderfunc(Dummy, func1)
    reg.set_renderfunc(Dummy4, func4)

    assert reg.renderfuncs[Dummy] == func1
    assert reg.renderfuncs[Dummy4] == func4

    # Add style to register

# Generated at 2022-06-24 04:53:01.113072
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.my_style = Style(Sgr(1))
    r.my_other_style = Style(Sgr(2))

    d = r.as_dict()

    assert isinstance(d, dict)
    assert sorted(d.keys()) == ["my_other_style", "my_style"]
    assert d["my_style"] == "\x1b[1m"

# Generated at 2022-06-24 04:53:11.240411
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    
    from .rendertype import Sgr, RgbBg
    from . import fg

    class F0:
        fg.f0 = Style(RgbFg(0,0,0), Sgr(1))

    assert F0.fg.f0 == '\x1b[38;2;0;0;0m\x1b[1m'

    # Now mute and re-set fg.f0
    fg.mute()

    class F1:
        fg.f0 = Style(RgbFg(0,0,0), Sgr(1))

    assert F1.fg.f0 == ''

    # Add a new style
    class F2:
        fg.f1 = Style(RgbFg(255, 255, 255))

    assert F2.fg.f1

# Generated at 2022-06-24 04:53:19.359010
# Unit test for method unmute of class Register
def test_Register_unmute():
    class TestRegister(Register):
        pass

    testreg = TestRegister()
    testreg.red = Style(RgbFg(255,0,0))
    testreg.red = '\x1b[38;2;255;0;0m'
    testreg.mute()
    testreg.red = '\x1b[0m'
    testreg.unmute()
    res = testreg.red == '\x1b[38;2;255;0;0m'
    assert res, 'unmute() does not work'


# Generated at 2022-06-24 04:53:30.411261
# Unit test for method mute of class Register
def test_Register_mute():
    from .sty import Sgr, FgBg, fg

    fg.set_eightbit_call(FgBg)
    fg.set_renderfunc(Sgr, lambda *x: "SGR")
    fg.set_renderfunc(FgBg, lambda *x: "EIGHTBIT")
    fg.red = Style(FgBg(1))
    fg.blue = Style(FgBg(2))

    assert fg.red == "EIGHTBIT"
    assert fg.blue == "EIGHTBIT"

    fg.mute()   # Muting the fg-register
    assert fg.red == ""
    assert fg.blue == ""

    fg.unmute() # Unmuting the fg-register

# Generated at 2022-06-24 04:53:38.392916
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .colorregister import ColorRegister, RgbFg, Sgr

    cr = ColorRegister()
    cr.set_renderfunc(RgbFg, lambda *x: "".join(str(i) for i in x))
    cr.set_renderfunc(Sgr, lambda *x: ";".join(str(i) for i in x))

    cr.test = Style(RgbFg(1,2,3), Sgr(1), RgbFg(4,5,6))

    assert cr.test == "1;2;3;1;4;5;6"
    assert cr.as_dict() == {"test": "1;2;3;1;4;5;6"}

# Generated at 2022-06-24 04:53:47.735061
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Create new Register object
    reg = Register()

    # Create random color
    reg.foo = Style(RgbFg(1, 1, 1, True))
    reg.bar = Style(RgbBg(1, 1, 1, True))

    foo_str = reg.foo
    bar_str = reg.bar

    reg_dict = reg.as_dict()

    # Check if dictonary keys are correct
    assert "foo" in reg_dict and "bar" in reg_dict

    # Check if dictionary values are correct.
    assert reg_dict["foo"] == foo_str
    assert reg_dict["bar"] == bar_str

# Generated at 2022-06-24 04:53:59.846101
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightBit, RgbFg, RgbBg
    from .converter import AnsiStyle

    # Setup register
    register = Register()
    register.set_eightbit_call(EightBit)
    register.set_rgb_call(RgbFg)
    register.set_renderfunc(EightBit, AnsiStyle.render_eightbit)
    register.set_renderfunc(RgbFg, AnsiStyle.render_rgb)

    # Setup styles
    register.red = Style(RgbFg(255, 0, 0))
    register.green = Style(RgbFg(0, 255, 0))
    register.blue = Style(RgbFg(0, 0, 255))


# Generated at 2022-06-24 04:54:11.832678
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Style8Bit, StyleRgb

    class TestRegister(Register):
        """
        Custom registers for testing method mute of class Register.
        """

        def __init__(self):
            super().__init__()

        def test_inheritance_attributes(self):

            # renderfuncs
            from .rendertype import Sgr

            self.set_renderfunc(Sgr, lambda x: "\x1b[1m")

            # eightbit_call
            self.set_eightbit_call(Style8Bit)

            # rgb_call
            self.set_rgb_call(StyleRgb)

            # ...

    # Create a register object
    test_register = TestRegister()

    # Start test
    test_register.test_inheritance_attributes()

# Generated at 2022-06-24 04:54:17.500755
# Unit test for method mute of class Register
def test_Register_mute():
    from sty.modes import FgBg
    reg = FgBg()
    reg.mute()
    assert reg.is_muted is True
    assert reg.black == ""


# Generated at 2022-06-24 04:54:23.522381
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .ansi_rendertype import AnsiFg, AnsiBg, AnsiBold, AnsiReset

    # Create a new register object.
    r = Register()

    # Add renderfunctions for rendertypes.
    r.set_renderfunc(AnsiFg, lambda *args: f"\x1b[38;5;{args[0]}m")
    r.set_renderfunc(AnsiBg, lambda *args: f"\x1b[48;5;{args[0]}m")
    r.set_renderfunc(AnsiBold, lambda: "\x1b[1m")
    r.set_renderfunc(AnsiReset, lambda: "\x1b[0m")

    # Define colors that are muted.

# Generated at 2022-06-24 04:54:32.139177
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    This unit test checks if the attributes of the namedtuple returned by
    method Register.as_namedtuple() are correct.
    """
    from .color import Color

    register = Color()
    namedtuple_register = register.fg.as_namedtuple()

    style_reg_dict = register.fg.as_dict()
    style_reg_nt_dict = {key: getattr(namedtuple_register, key) for key in style_reg_dict.keys()}

    assert style_reg_dict == style_reg_nt_dict

# Generated at 2022-06-24 04:54:34.906403
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Unit test for method __new__ of class Style.
    """

    # Check if Style is of type str.
    assert issubclass(Style, str)

    # Check if Style(value='test') is of type Style.
    assert isinstance(Style(value='test'), Style)

    # Check if Style(value='test') is of type str.
    assert isinstance(Style(value='test'), str)



# Generated at 2022-06-24 04:54:44.202385
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class A:
        pass

    class B:
        pass

    class C:
        pass

    reg = Register()
    render_func_a = lambda x: x
    render_func_b = lambda x: x
    render_func_c = lambda x: x

    reg.set_renderfunc(A, render_func_a)
    reg.set_renderfunc(B, render_func_b)
    reg.set_renderfunc(C, render_func_c)

    assert len(reg.renderfuncs) == 3
    assert reg.renderfuncs[A] == render_func_a
    assert reg.renderfuncs[B] == render_func_b
    assert reg.renderfuncs[C] == render_func_c

    render_func_b = lambda x: x + 1

    reg.set

# Generated at 2022-06-24 04:54:54.257217
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for method `unmute` of class Register
    """

    class CustomRegister(Register):
        """
        A custom register class.
        """

        def __init__(self):
            super().__init__()

            setattr(self, "test", Style(RgbFg(10, 10, 10), Sgr(1)))

    r1 = CustomRegister()
    r1.mute()

    # If r1 is muted, the renderfunc does not render anything.
    assert str(r1.test) == ""

    r1.unmute()

    def renderfunc(code: int) -> str:
        return "{" + str(code) + "}"

    # Set a renderfunc, that can be tested.
    r1.set_renderfunc(Eightbit, renderfunc)

# Generated at 2022-06-24 04:54:56.727203
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    ef = Register()
    ef.blink = Style(Sgr(5))

    assert ef.blink == "\x1b[5m"
    assert ef.as_namedtuple().blink == "\x1b[5m"

# Generated at 2022-06-24 04:55:02.281774
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 5, 10), Sgr(1))
    assert style.rules[0].args == (1, 5, 10)
    assert style.rules[1].args == (1,)


# Generated at 2022-06-24 04:55:05.615405
# Unit test for method __new__ of class Style
def test_Style___new__():

    s1 = Style()
    assert isinstance(s1, Style)
    assert s1.rules == tuple()

    s2 = Style(Sgr())
    assert isinstance(s2, Style)
    assert s2.rules == (Sgr(),)

    s3 = Style(Sgr(), Sgr(1))
    assert isinstance(s3, Style)
    assert s3.rules == (Sgr(), Sgr(1))

    s4 = Style(value="x")
    assert isinstance(s4, Style)
    assert s4.rules == tuple()
    assert s4 == "x"



# Generated at 2022-06-24 04:55:14.264543
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFgRegister(Register):
        def __init__(self):
            super().__init__()
            self.renderfuncs.update({RgbFg: lambda r, g, b: "%d %d %d" % (r, g, b)})

    class EightbitRegister(Register):
        def __init__(self):
            super().__init__()
            self.renderfuncs.update({Eightbit: lambda x: "%d" % x})

    rgb = RgbFgRegister()
    eightbit = EightbitRegister()

    # Register.__call__
    assert rgb(10, 0, 10) == "10 0 10"
    assert eightbit(10) == "10"

    # Register.set_eightbit_call
    rgb.set_eightbit_call(RgbFg)

# Generated at 2022-06-24 04:55:23.546982
# Unit test for method __call__ of class Register
def test_Register___call__():
    fg = Register()
    fg.black = Style(RenderType.EightBit.Fg(0))
    fg.white = Style(RenderType.EightBit.Fg(255))
    fg.set_eightbit_call(RenderType.EightBit.Fg)

    assert fg.black == "\x1b[38;5;0m"
    assert fg("black") == "\x1b[38;5;0m"
    assert fg("white") == "\x1b[38;5;255m"
    assert fg("red") == ""
    assert fg(255) == "\x1b[38;5;255m"
    assert fg(0, 0, 0) == ""



# Generated at 2022-06-24 04:55:30.280937
# Unit test for method mute of class Register
def test_Register_mute():
    """ Test muting of register. """
    from sty import fg, bg

    fg.red = Style(fg.red, fg.red)

    fg.mute()
    assert fg.red == ""
    assert fg.red.rules == (fg.red, fg.red)
    assert str(fg.red) == ""
    assert fg.red_10 == ""
    assert fg.red_100 == ""
    assert fg.red_200 == ""
    assert fg.red_220 == ""
    assert fg.red_230 == ""
    assert fg.red_250 == ""
    assert fg.red_255 == ""
    assert fg.rgb_10_50_5 == ""
    assert fg.rgb_12_42_255 == ""
    assert fg

# Generated at 2022-06-24 04:55:38.688577
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    styles = Register()
    style_1 = Style(RgbFg(1, 5, 36))
    style_2 = Style(RgbFg(10, 150, 255), Sgr(1))
    style_3 = Style(RgbBg(1, 5, 36), RgbFg(10, 150, 255))

    styles.s1 = style_1
    styles.s2 = style_2
    styles.s3 = style_3

    nt = styles.as_namedtuple()

    assert(nt.s1 == style_1)
    assert(nt.s2 == style_2)
    assert(nt.s3 == style_3)

# Generated at 2022-06-24 04:55:49.222719
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .colors import fg
    assert fg(0) == "\x1b[38;5;16m"
    assert fg(1) == "\x1b[38;5;17m"
    assert fg(2) == "\x1b[38;5;18m"
    assert fg(3) == "\x1b[38;5;19m"
    assert fg(42) == "\x1b[38;5;124m"
    assert fg(43) == "\x1b[38;5;125m"
    assert fg(44) == "\x1b[38;5;126m"
    assert fg(45) == "\x1b[38;5;127m"
    assert fg(167) == "\x1b[38;5;231m"
   

# Generated at 2022-06-24 04:56:00.583087
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    r = Register()


    # Test with a default value that has rules
    class RedFg(RenderType):
        pass
    class Ef(RenderType):
        pass
    class RgbFg(RenderType):
        pass
    class Bg(RenderType):
        pass
    class Sgr(RenderType):
        pass

    r.set_renderfunc(RedFg, lambda x: "\x1b[31m")
    r.set_renderfunc(Ef, lambda x: "\x1b[5m")
    r.set_renderfunc(RgbFg, lambda x, y, z: "\x1b[38;2;{};{};{}m".format(x, y, z))
    r.set_renderfunc(Bg, lambda x: "\x1b[40m")
    r

# Generated at 2022-06-24 04:56:08.709243
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .sty import sty
    from .rendertype import Rgb

    sty.bg.red = Style(Rgb(200,0,0))
    sty.bg.red = Style(Rgb(22,34,43))

    print(sty.bg.red)
    # >> \x1b[48;2;22;34;43m (This is the result for the default renderfunc for Rgb)
    sty.bg.set_renderfunc(Rgb, lambda r, g, b: f"Rgb: {r}, {g}, {b}.")
    sty.bg.red = Style(Rgb(22,34,43))
    print(sty.bg.red)
    # >> Rgb: 22, 34, 43. (Now we can see that the renderfunc has changed.)

# Generated at 2022-06-24 04:56:18.706973
# Unit test for constructor of class Register

# Generated at 2022-06-24 04:56:24.397553
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test if the namedtuple returned by `as_namedtuple` can be accessed by
    property-dot-notation.
    """
    cls = Register()
    cls.a = Style(RgbFg(1, 10, 100))
    cls.b = Style(RgbFg(2, 20, 200))
    cls.c = Style(RgbFg(3, 30, 300))

    nt = cls.as_namedtuple()

    assert nt.a == str(cls.a)
    assert nt.b == str(cls.b)
    assert nt.c == str(cls.c)

# Generated at 2022-06-24 04:56:27.334825
# Unit test for method mute of class Register
def test_Register_mute():
    register = Register()
    register.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")
    register.red = Style(RenderType(31))
    assert register.red == "\x1b[31m"
    register.mute()
    assert register.red == ""


# Generated at 2022-06-24 04:56:32.299721
# Unit test for method mute of class Register
def test_Register_mute():
    fg = Register()

    fg.red = Style(RgbFg(10, 20, 30))

    assert fg.red == "\x1b[38;2;10;20;30m"

    fg.mute()

    assert fg.red == ""

    fg.unmute()

    assert fg.red == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-24 04:56:35.039013
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Curry(NamedTuple):
        args: Tuple
        kwargs: Dict

    def dummy_renderfunc(a, b, c=None):
        return Curry(args=(a, b, c), kwargs={})

    r = Register()

    r.set_renderfunc(RenderType, dummy_renderfunc)

    assert r.renderfuncs[RenderType] == dummy_renderfunc


# Generated at 2022-06-24 04:56:41.375739
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from . import fg
    from .rendertype import RgbFg, RgbBg
    register = fg.copy()
    register.red = Style(RgbFg(255, 0, 0))
    assert register(255, 0, 0) == "\x1b[38;2;255;0;0m"
    register.set_rgb_call(RgbBg)
    assert register(255, 0, 0) == "\x1b[48;2;255;0;0m"
    assert "red" in dir(register)
    assert register.red == "\x1b[38;2;255;0;0m"
    assert register is not fg



# Generated at 2022-06-24 04:56:48.224296
# Unit test for method __new__ of class Style
def test_Style___new__():
    r1 = RenderType(1, 2)
    r2 = RenderType(3, 4)
    r3 = RenderType(5, 6)

    s1 = Style(r1)
    s2 = Style(r2)
    s3 = Style(s1, r3)

    assert isinstance(s1, Style)
    assert isinstance(s2, Style)
    assert isinstance(s3, Style)
    assert isinstance(s1, str)
    assert isinstance(s2, str)
    assert isinstance(s3, str)
    assert s1.rules == (r1,)
    assert s2.rules == (r2,)
    assert s3.rules == (s1, r3)

# Generated at 2022-06-24 04:56:58.032711
# Unit test for method mute of class Register
def test_Register_mute():

    import sty
    import sty.rgb
    import sty.sgr

    fg_register = sty.rgb.fg
    items_before = fg_register.as_dict()
    fg_register.set_eightbit_call(sty.rgb.RgbFg)
    fg_register.set_rgb_call(sty.rgb.RgbFg)
    fg_register.set_renderfunc(sty.sgr.Sgr, lambda *x, **y: "Sgr renderfunc")
    fg_register.mute()
    items_after = fg_register.as_dict()

    assert items_before != items_after

    for val in items_after.values():
        assert val == ""

    items_after_while_muted = fg_register.as_dict()



# Generated at 2022-06-24 04:56:59.481614
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.mute()
    assert r.is_muted is True
    r.unmute()
    assert r.is_muted is False

# Generated at 2022-06-24 04:57:05.719052
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import SevenbitFg, Sgr

    fg = Register()

    fg.blue = Style(SevenbitFg(4), Sgr(1))

    fg.mute()

    assert str(fg.blue) == ""

    fg.unmute()

    assert str(fg.blue) == "\x1b[38;5;4m\x1b[1m"

# Generated at 2022-06-24 04:57:08.282622
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .fg import Fg

    Style(Fg(100))

# Generated at 2022-06-24 04:57:15.509620
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Dummy(RenderType):
        def __init__(self):
            self.name = "dummy"

    r = Register()
    r.set_renderfunc(Dummy, lambda x: "a")

    assert r.eightbit_call(123) == ""  # Before setting call type to Dummy, register is muted.

    r.set_eightbit_call(Dummy)
    assert r.eightbit_call(123) == "a"  # After, it is not.

    r.mute()
    assert r.eightbit_call(123) == ""  # Call works even if register is muted.



# Generated at 2022-06-24 04:57:22.145566
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test method __call__ of class Register.
    """
    from .rendertype import RgbFg, Sgr, Rgb

    fg = Register()
    red = Style(RgbFg(255, 0, 0))
    green = Style(RgbFg(0, 255, 0))
    bold = Style(Sgr(1))

    fg.red = red
    fg.green = green
    fg.bold = bold
    fg.set_eightbit_call(RgbFg)
    fg.set_rgb_call(Rgb)


# Generated at 2022-06-24 04:57:30.890960
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbBg

    # set up
    class myregister(Register):
        blue = Style(RgbBg(42, 64, 122))

    myreg = myregister()
    myreg.set_renderfunc(RgbBg, lambda r, g, b: f"\033[48;2;{r};{g};{b}m\033[38;2;{r};{g};{b}m")

    # test
    assert myreg.blue == "\x1b[48;2;42;64;122m\x1b[38;2;42;64;122m"

# Generated at 2022-06-24 04:57:41.763763
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test if setting a new rgb-function works.
    """
    from random import random

    from .rendertype import RgbBg, RgbFg
    from .renderfunc import render_rgb_bg, render_rgb_fg

    r = Register()

    r.set_renderfunc(RgbBg, render_rgb_bg)
    r.set_renderfunc(RgbFg, render_rgb_fg)

    r.set_rgb_call(RgbBg)  # This is the only line that is different!

    r.test = Style(RgbBg(1, 1, 1), RgbFg(255, 255, 255))


# Generated at 2022-06-24 04:57:49.334624
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .render import ansi256, ansi24bit

    r = Register()
    r.set_renderfunc(RenderType.RGB256, ansi256)
    r.set_renderfunc(RenderType.RGBCOLOR, ansi24bit)

    r.red = Style(RenderType.RGBCOLOR(255, 0, 0))

    r.mute()
    assert r.red == ""
    r.unmute()
    assert r.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:57:58.331766
# Unit test for method mute of class Register
def test_Register_mute():
    # Note: To test muted register, we will not use actual renderfuncs
    # We will use a class with a __repr__ method instead

    # This is the class that we will use for the testing
    class ExampleRenderType(RenderType):
        def __repr__(self):
            return "ExampleRenderType"

    # Create a register object
    reg = Register()
    reg.set_renderfunc(ExampleRenderType, lambda x: x)
    # Create style object that uses ExampleRenderType
    reg.red = Style(ExampleRenderType())
    # Test if string output is as expected
    assert str(reg.red) == "ExampleRenderType"
    # Mute register object
    reg.mute()
    # Test if string output is as expected
    assert str(reg.red) is ""

# Generated at 2022-06-24 04:58:04.088466
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def testfunc_1(r: int, g: int, b: int) -> str:
        return f"1: {r} {g} {b}"

    def testfunc_2(x: int) -> str:
        return f"2: {x}"

    class TestClass_1(RenderType):
        def __init__(self, r: int, g: int, b: int) -> None:
            self.args = (r, g, b)

    class TestClass_2(RenderType):
        def __init__(self, x: int) -> None:
            self.args = (x,)

    reg = Register()
    reg.set_renderfunc(TestClass_1, testfunc_1)
    reg.set_rgb_call(TestClass_1)

# Generated at 2022-06-24 04:58:14.913924
# Unit test for constructor of class Style
def test_Style():

    class Rgb(RenderType):
        """
        Some dummy render type for testing.
        """
        pass

    class Bold(RenderType):
        """
        Some dummy render type for testing.
        """
        pass

    def rgb(*args):
        return f"<Rgb {args}>"

    def bold(*args):
        return f"<Bold {args}>"

    renderfuncs = {Rgb: rgb, Bold: bold}

    style = Style(Rgb(255, 255, 255), Bold())

    assert style == "<Rgb (255, 255, 255)><Bold ()>"

    assert style.rules[0].args == (255, 255, 255)
    assert style.rules[1].args == ()

    style = Style(style, Rgb(0, 0, 0))


# Generated at 2022-06-24 04:58:17.484892
# Unit test for method copy of class Register
def test_Register_copy():

    r1 = Register()
    r1.blau = Style(RgbFg(10, 10, 10))
    r1.grün = Style(RgbFg(10, 10, 10))

    r2 = r1.copy()

    assert r2.blau == r1.blau



# Generated at 2022-06-24 04:58:24.792176
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class R(Register):
        pass
    r = R()
    r.red = Style(RgbFg(1,0,0))
    r.green = Style(RgbFg(0,1,0))
    r.blue = Style(RgbFg(0,0,1))

    nt = r.as_namedtuple()
    assert hasattr(nt, "red")
    assert hasattr(nt, "green")
    assert hasattr(nt, "blue")
    assert not hasattr(nt, "copy")
    assert not hasattr(nt, "renderfuncs")
    assert str(nt) == str(r)

# Generated at 2022-06-24 04:58:35.958865
# Unit test for constructor of class Register

# Generated at 2022-06-24 04:58:44.817366
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class RgbFg(RenderType):
        rendertype = "RgbFg"

    class RgbBg(RenderType):
        rendertype = "RgbBg"

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: (str(r), str(g), str(b)))

    # First, define test style with original renderfunc for RgbFg
    r.blue_foreground = Style(RgbFg(0, 0, 255))

    # Create a new renderfunc for RgbFg that works with only one r-value.
    r.set_renderfunc(RgbFg, lambda r: (str(r), "42", "17"))

    # Define second test style with new renderfunc for RgbFg
    r.red_foreground = Style

# Generated at 2022-06-24 04:58:54.560373
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty import fg, bg

    # Test 8-bit foreground calls.
    assert fg(144) == fg.light_purple
    assert fg(10) == fg.green
    assert fg(222) == fg.dark_yellow

    # Test 8-bit background calls.
    assert bg(144) == bg.light_purple
    assert bg(10) == bg.green
    assert bg(222) == bg.dark_yellow

    # Test 24-bit foreground calls.
    assert fg(10, 42, 255) == fg.red
    assert fg(10, 42, 255) == fg.blue
    assert fg(10, 42, 255) == fg.magenta

    # Test 24-bit background calls.

# Generated at 2022-06-24 04:59:05.322100
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Tests for Register.set_renderfunc.

    :return:
    """
    import textwrap
    import doctest

    # Create new register
    r = Register()

    # Create new SGR-object
    class Sgr(RenderType):
        args: Tuple[Union[int, str, None], ...]

        def __init__(self, *args: Union[int, str, None]):
            self.args = args

    # Create render func for SGR-object
    def sgr_render(*args: Union[int, str, None]) -> str:
        return "".join(f"\x1b[{arg}" for arg in args)

    # Add new render func to the Register-object
    r.set_renderfunc(Sgr, sgr_render)

    # Create new style 'foo'


# Generated at 2022-06-24 04:59:15.290528
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Unit test for method set_eightbit_call of class Register.
    """
    # Create empty register
    reg = Register()

    reg.set_renderfunc(RenderType.FG, lambda x: "F" * x)
    reg.set_renderfunc(RenderType.BG, lambda x: "B" * x)

    # Set Eightbit rendertype
    reg.set_eightbit_call(RenderType.FG)

    # Call register-object.
    assert str(reg(42)) == "F" * 42

    # Set BG rendertype
    reg.set_eightbit_call(RenderType.BG)

    # Call register-object.
    assert str(reg(42)) == "B" * 42


# Generated at 2022-06-24 04:59:19.370180
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Use class Style to create a style and test Style.__new__ method.
    """
    # Given
    import sty

    style: Style = Style(sty.fg.red, sty.bg.blue, sty.ef.bold)

    # When
    new_style: Style = Style(sty.fg.red, sty.bg.blue, sty.ef.bold)

    # Then
    assert new_style == style

