

# Generated at 2022-06-24 04:49:25.768190
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from sty import fg, Style
    from sty.compat import Fore

    fg.blue = Style(Fore.BLUE, "test")

    x = fg.as_namedtuple()

    assert x.blue == '\x1b[34mtest'
    assert x.blue != '\x1b[34mtest2'

# Generated at 2022-06-24 04:49:36.384565
# Unit test for method mute of class Register
def test_Register_mute():
    # pylint: disable=protected-access
    def _test_mute(rgb_rendertype, eightbit_rendertype, style, expected_style):

        myregister = Register()
        myregister.set_renderfunc(rgb_rendertype, lambda r, g, b: (r, g, b))
        myregister.set_renderfunc(eightbit_rendertype, lambda x: x)
        myregister.set_rgb_call(rgb_rendertype)
        myregister.set_eightbit_call(eightbit_rendertype)
        setattr(
            myregister,
            "blue",
            Style(
                rgb_rendertype.from_name("blue"),
                eightbit_rendertype.from_name("blue"),
                style,
                value="",
            ),
        )

        myregister.m

# Generated at 2022-06-24 04:49:40.556794
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr
    from .registers import fg

    rendertype = RgbFg
    func = lambda r,g,b: ""
    fg.set_renderfunc(rendertype, func)

    assert fg.set_eightbit_call(rendertype) is None
    assert repr(fg.eightbit_call) == repr(func)

# Generated at 2022-06-24 04:49:46.121419
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    style = Style(RgbFg(11, 11, 11), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "\x1b[38;2;11;11;11m\x1b[1m"


# Generated at 2022-06-24 04:49:54.636666
# Unit test for constructor of class Register
def test_Register():
    """
    Unit test for constructor of class Register
    """

    # The following should work without any errors.
    r = Register()
    r()
    r(10)
    r(10, 42, 255)
    r.mute()
    r.unmute()
    r.set_eightbit_call(object)
    r.set_rgb_call(object)
    r.set_renderfunc(object, lambda x: x)
    r.as_dict()
    r.as_namedtuple()
    r.copy()

    # The following should raise a TypeError.
    try:
        r(None)
    except TypeError:
        pass
    else:
        assert False, "The following should raise a TypeError."

    # The following should raise a TypeError.

# Generated at 2022-06-24 04:50:05.166439
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        """This is an example rendertype. It has an own render-function."""
        args = ["r", "g", "b"]

    rendertype = RgbFg  # type: Type[RenderType]

    def rgb_render(r: int, g: int, b: int):
        return f"RENDERRGB({r},{g},{b})"

    # Create register-object
    register = Register()

    # Add the render-function for rendertype RgbFg
    register.set_renderfunc(rendertype, rgb_render)

    # Create a style that uses RgbFg
    style = Style(RgbFg(1, 2, 3))

    # Set the style as attribute
    register.my_style = style

    # The render-function should be used by

# Generated at 2022-06-24 04:50:14.049942
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test to check correct behavior of __setattr__ method in class Register.
    """

    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    test_reg = TestRegister()

    # initalize new style
    test_reg.test_style = Style(RgbFg(1, 5, 10), Sgr(1))

    # test
    assert isinstance(test_reg.test_style, str)
    assert test_reg.test_style == '\x1b[38;2;1;5;10m\x1b[1m'



# Generated at 2022-06-24 04:50:20.347984
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(RgbFg(10, 42, 255), Sgr(5)), Style)
    assert isinstance(Style(RgbFg(10, 42, 255)), Style)
    assert isinstance(Style(RgbFg(10, 42, 255), Sgr(5)), str)
    assert isinstance(Style(RgbFg(10, 42, 255)), str)


# Generated at 2022-06-24 04:50:25.192402
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class DummyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style("{}")
            self.green = Style("{}")
            self.blue = Style("{}")

    r = DummyRegister()
    assert r.as_dict() == {"red": "{}", "green": "{}", "blue": "{}"}


# Generated at 2022-06-24 04:50:28.141900
# Unit test for constructor of class Register
def test_Register():
    r1 = Register()
    assert r1 is not None
    assert isinstance(r1, Register)



# Generated at 2022-06-24 04:50:34.897563
# Unit test for method __new__ of class Style
def test_Style___new__():
    # without overridden value
    s1 = Style(RgbFg(1, 2, 3), RgbBg(2, 3, 4))

    assert isinstance(s1, Style)
    assert s1 == ""

    # with overridden value
    s2 = Style(RgbFg(1, 2, 3), RgbBg(2, 3, 4), value="foo")

    assert isinstance(s2, Style)
    assert s2 == "foo"

# Generated at 2022-06-24 04:50:39.887906
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    reg = Register()
    reg.set_renderfunc(RenderType, lambda *args, **kwargs: "")
    reg.set_eightbit_call(RenderType)
    reg.set_rgb_call(RenderType)

    reg.red = Style(RenderType(42))

    assert isinstance(reg.red, Style)
    assert isinstance(reg.red, str)
    assert str(reg.red) == ""

    reg.unmute()
    assert str(reg.red) == ""

    reg.mute()
    assert str(reg.red) == ""


# Generated at 2022-06-24 04:50:51.395422
# Unit test for method mute of class Register
def test_Register_mute():

    from colorclass.rendertypes import SgrFg, CursorPos, SgrBg, SgrReset, SgrFg8bit, SgrBg8bit, SgrExtended

    rs = Style(SgrReset())

    fg = Style(SgrFg(200, 50, 0), SgrFg8bit(176,177), SgrExtended(1))
    bg = Style(SgrBg(100,100,100), SgrBg8bit(177,176), SgrExtended(9, 1))

    ef = Style(SgrExtended(1, 2, 3))

    my_register = Register()

    my_register.rs = rs
    my_register.fg = fg
    my_register.bg = bg
    my_register.ef = ef

    my_

# Generated at 2022-06-24 04:50:59.395996
# Unit test for method mute of class Register
def test_Register_mute():

    import sty

    # Pre-configure register fg.
    fg = Register()
    fg.renderfuncs = sty.rendertypes.ansi.renderfuncs
    fg.is_muted = False
    fg.eightbit_call = sty.rendertypes.ansi.rendertypes.RgbFg
    fg.rgb_call = sty.rendertypes.ansi.rendertypes.RgbFg

    # Test empty register fg

# Generated at 2022-06-24 04:51:07.395113
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg

    class TestRegister(Register):
        pass

    testregister = TestRegister()
    testregister.set_renderfunc(RgbFg, lambda r, g, b: "")
    testregister.newstyle = Style(RgbFg(1, 2, 3))
    assert isinstance(testregister.newstyle, Style)

    testregister.newstyle = "hello"
    assert testregister.newstyle == "hello"



# Generated at 2022-06-24 04:51:12.841117
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(), Style)
    assert isinstance(Style(""), Style)
    assert isinstance(Style("Hello World"), Style)
    assert isinstance(Style(value="Hello World"), Style)
    assert isinstance(Style(42), Style)
    assert isinstance(Style(42, value="Hello World"), Style)
    assert isinstance(Style(42, "Hello World"), Style)
    assert isinstance(Style(42, "Hello World", value="Kittens!"), Style)

# Generated at 2022-06-24 04:51:19.311633
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    The function test_Register_as_namedtuple tests the method as_namedtuple of the class Register.
    """
    fg = Register()
    fg.red = Style(RgbFg(1, 1, 1), Sgr(1))
    fg.blue = Style(RgbFg(2, 2, 2), Sgr(1, 4))

    nt: NamedTuple = fg.as_namedtuple()

    assert isinstance(nt, namedtuple)
    assert isinstance(nt.red, str)
    assert isinstance(nt.blue, str)
    assert len(nt.red) > 0
    assert len(nt.blue) > 0


# Generated at 2022-06-24 04:51:29.417727
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .render import RgbFg
    from .ansi import Fg as AnsiFg
    from .truecolor import Fg as TruecolorFg

    r = Register()
    r.set_renderfunc(AnsiFg, lambda x: x)
    r.set_renderfunc(TruecolorFg, lambda x, y, z: x + y + z)
    r.black = Style(RgbFg(0, 0, 0))
    assert r.black == "Black"

    r.set_rgb_call(TruecolorFg)
    r.black = Style(RgbFg(0, 0, 0))
    assert r.black == "000"

# Generated at 2022-06-24 04:51:38.319532
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import Sgr, RgbFg, EightbitFg
    from .style import Style
    from collections import abc
    from .serialize import register_serializer

    r = Register()
    r.green = Style(Sgr(1), RgbFg(0, 15, 0))

    assert isinstance(r, abc.Mapping)
    assert isinstance(r, abc.MutableMapping)
    assert r.green == '\x1b[38;2;0;15;0m\x1b[1m'
    assert r['green'] == '\x1b[38;2;0;15;0m\x1b[1m'
    assert list(r) == ['green']

    r.set_eightbit_call(EightbitFg)
    r.set_

# Generated at 2022-06-24 04:51:41.502212
# Unit test for method copy of class Register
def test_Register_copy():
    a = Register()
    b = a.copy()
    b.foo = "bar"
    assert "foo" not in a.__dict__
    assert "foo" in b.__dict__

# Generated at 2022-06-24 04:51:42.898989
# Unit test for constructor of class Register
def test_Register():

    rg = Register()
    assert isinstance(rg, Register)
    assert isinstance(rg, object)

# Generated at 2022-06-24 04:51:48.162682
# Unit test for method copy of class Register
def test_Register_copy():
    from .registers import fg
    fg2 = fg.copy()
    for c in fg2:
        assert isinstance(c, Style)
    assert fg2.red != fg.red
    assert fg.red != fg.red
    assert fg2.renderfuncs == fg.renderfuncs


RegisterTuple = NamedTuple("RegisterTuple", [("register", Register), ("name", str)])

# Generated at 2022-06-24 04:51:56.624666
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestStyle(RenderType):
        pass
        
    class TestStyle2(RenderType):
        pass

    register = Register()
    register.set_renderfunc(TestStyle, lambda x: "TestStyleFunc")
    register.set_renderfunc(TestStyle2, lambda x: "TestStyle2Func")
    register.TestStyle = Style(TestStyle(42))
    register.TestStyle2 = Style(TestStyle2(42))

    assert str(register.TestStyle) == "TestStyleFunc"
    assert str(register.TestStyle2) == "TestStyle2Func"

# Generated at 2022-06-24 04:52:04.931321
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # create a new register-object
    reg = Register()

    # define a render-func for rendertype RgbFg
    def rgb_render(r, g, b):
        return (r, g, b)

    # define a render-func for rendertype RgbBg
    def eightbit_render(x):
        return x

    # add render funcs to register-object
    reg.set_renderfunc(RgbFg, rgb_render)
    reg.set_renderfunc(EightbitFg, eightbit_render)

    # set EightbitFg to be used for Eightbit-calls
    reg.set_rgb_call(RgbFg)

    # set RgbFg to be used for RGB-calls
    reg.set_eightbit_call(EightbitFg)

    # set attributes

# Generated at 2022-06-24 04:52:10.183191
# Unit test for constructor of class Style
def test_Style():
    class Dummy:
        pass

    sgr_bold = Dummy()
    sgr_bold.args = [1]

    fg_red = Dummy()
    fg_red.args = [1, 0, 0]

    style = Style(*[sgr_bold, fg_red])

    assert style.rules == [sgr_bold, fg_red]

# Generated at 2022-06-24 04:52:10.799589
# Unit test for constructor of class Register
def test_Register():
    Register()

# Generated at 2022-06-24 04:52:13.989158
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.is_muted == False
    assert register.eightbit_call == register.eightbit_call
    assert register.rgb_call == register.rgb_call
    assert register.renderfuncs == {}


# Generated at 2022-06-24 04:52:18.058605
# Unit test for method mute of class Register
def test_Register_mute():

    from sty.colors import fg

    fg.mute()
    assert fg.is_muted
    assert fg.black is None  # style attribute black is muted now.

    fg.unmute()
    assert not fg.is_muted
    assert fg.black is not None  # style attribute black is unmuted now. 



# Generated at 2022-06-24 04:52:27.548156
# Unit test for method set_rgb_call of class Register

# Generated at 2022-06-24 04:52:33.348746
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    renderfuncs: Renderfuncs = {
        RgbFg: lambda r, g, b: f"RgbFg({r},{g},{b})",
        RgbBg: lambda r, g, b: f"RgbBg({r},{g},{b})",
    }

    r = Register()
    r.set_renderfunc(RgbFg, renderfuncs[RgbFg])
    r.set_renderfunc(RgbBg, renderfuncs[RgbBg])
    r.set_rgb_call(RgbBg)
    r.red = Style(Sgr(1), RgbBg(255, 255, 0))
    assert str(r.red) == "\x1b[1mRgbBg(255,255,0)"

# Generated at 2022-06-24 04:52:41.175207
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        args = ("code",)

    class RgbFg(RenderType):
        args = ("r", "g", "b")

    class RgbBg(RenderType):
        args = ("r", "g", "b")

    class TrueType(RenderType):
        args = ("True",)

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda *_: "\x1b[38;2;{};{};{}m".format(*_))
    fg.set_renderfunc(RgbBg, lambda *_: "\x1b[48;2;{};{};{}m".format(*_))
    fg.set_renderfunc(Sgr, lambda *_: "\x1b[{}m".format(*_))



# Generated at 2022-06-24 04:52:51.348683
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Create a new Register-class
    class MyRegister(Register):
        pass

    reg = MyRegister()

    reg.set_eightbit_call(RenderType("MyRenderType1", "ANSI_CODE1_{}", eightbit=True))
    reg.set_rgb_call(RenderType("MyRenderType2", "ANSI_CODE2_{}_{}_{}", eightbit=False))

    # Test call with string
    setattr(reg, "red", Style(RenderType("MyRenderType1", "ANSI_CODE1_{}", eightbit=True), "42"))
    assert reg("red") == "ANSI_CODE1_42"

    # Test call with 8bit
    assert reg(144) == "ANSI_CODE1_144"

    # Test call with RGB
    reg.set

# Generated at 2022-06-24 04:52:58.854183
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.renderfuncs = {RgbFg: lambda *args: "RgbFg-call"}

    # Case 1: value has type Style
    value = Style(RgbFg(1, 2, 3), Sgr(1))
    r.new_attr = value
    assert r.new_attr == "RgbFg-call"

    # Case 2: value is not of type Style
    value = 42
    with pytest.raises(ValueError):
        r.new_attr = value



# Generated at 2022-06-24 04:53:09.885813
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import Ansi2, Ansi8bit, RgbFgBg, RgbFgBgIntense

    def to_rgb_string(r, g, b):
        return "{};{};{}".format(r, g, b)

    def _render_ansi2(code2):
        return "2;{}".format(code2)

    def _render_ansi8bit(code8):
        return "8;{}".format(code8)

    def _render_rgbfgbg(r, g, b, fg=True):
        return "RgbFgBg({},{},{},{})".format(r, g, b, fg)


# Generated at 2022-06-24 04:53:18.781703
# Unit test for method __call__ of class Register
def test_Register___call__():
    class TestRegister(Register):
        def __init__(self):
            self.renderfuncs = {}
            self.is_muted = False
            self.eightbit_call = lambda x: 42
            self.rgb_call = lambda x, y, z: 42

    r = TestRegister()
    assert r(42) == 42
    assert r(1, 2, 3) == 42
    assert r() == ""
    assert r(1, 2) == ""
    assert r(1, 2, 3, 4) == ""

# Generated at 2022-06-24 04:53:30.153979
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.set_renderfunc(rendertype=RenderType, func=lambda x: x)
    r.new_style = Style(RenderType)
    r.new_style_2 = Style(RenderType, RenderType)
    r.new_style_3 = Style(Style(RenderType), RenderType)
    r.new_style_4 = Style(Style(Style(RenderType)))

    r2 = r.copy()

    assert r.new_style == r2.new_style
    assert r.new_style_2 == r2.new_style_2
    assert r.new_style_3 == r2.new_style_3
    assert r.new_style_4 == r2.new_style_4



# Generated at 2022-06-24 04:53:33.774048
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import AnsiFg, RenderType, RgbFg

    def foo(x): return str(x)

    r: Register = Register()
    r.set_renderfunc(AnsiFg, foo)

    r.set_eightbit_call(AnsiFg)

    assert r.eightbit_call == foo
    assert r(10) == "10"

    r.set_eightbit_call(RgbFg)
    assert r.eightbit_call == None


# Generated at 2022-06-24 04:53:42.360129
# Unit test for method __new__ of class Style
def test_Style___new__():

    assert isinstance(Style(name="red"), Style)
    assert isinstance(Style(name="red"), str)

    assert isinstance(Style(name="green"), Style)
    assert isinstance(Style(name="green"), str)

    assert not isinstance(Style(name="green"), Style)
    assert not isinstance(Style(name="green"), str)

    assert isinstance(Style(RgbFg(1, 2, 3), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3), Sgr(1)), str)

    assert not isinstance(Style(RgbFg(1, 2, 3), Sgr(1)), Style)
    assert not isinstance(Style(RgbFg(1, 2, 3), Sgr(1)), str)


# Generated at 2022-06-24 04:53:52.866391
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .ansi import fg, bg, ef, rs
    from .rendertype import Sgr, SgrFg, SgrBg, RgbFg, RgbBg, XtermFg, XtermBg, Iterm2Fg, Iterm2Bg
    from .colordata import colors_256, colors_16m
    from .solarized import solarized
    from .w3c import w3c, w3c_16m

    fg.light_grey = Style(Sgr(37))
    fg.dark_grey = Style(Sgr(90))
    fg.light_blue = Style(Sgr(94))
    fg.dark_blue = Style(Sgr(34))
    fg.light_red = Style(Sgr(91))
    fg.dark_red

# Generated at 2022-06-24 04:54:01.661997
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RegisterTest:

        def __init__(self):
            self.renderfuncs = {"fg": lambda x: x, "bg": lambda x: x}
            self.is_muted = False

        def __call__(self, *args, **kwargs) -> str:
            return Register.__call__(self, *args, **kwargs)

    reg = RegisterTest()

    # Test tuple-call.
    assert reg("red") == "red"
    assert reg("red", "white") == "red"
    assert reg("red", 1, 2, 3) == "red"
    assert reg("red", 1, 2, 3, b=4) == "red"

    # Test Color-code-call.
    assert reg(144) == 144

    # Test RGB-call.

# Generated at 2022-06-24 04:54:04.657442
# Unit test for method __new__ of class Style
def test_Style___new__():
    new_style = Style(1, 2, value="something")
    assert new_style.rules == (1, 2)

# Generated at 2022-06-24 04:54:12.459962
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Setup
    fg = Register()

    fg.red = Style(RgbFg(1, 2, 3))
    fg.green = ""
    fg.blue = Style(RgbFg(4, 5, 6))
    fg._yellow = Style(RgbFg(4, 5, 6))

    # Test
    assert fg.as_dict() == {"red": "\x1b[38;2;1;2;3m", "blue": "\x1b[38;2;4;5;6m"}

# Generated at 2022-06-24 04:54:21.927357
# Unit test for method mute of class Register
def test_Register_mute():

    from .render import Sgr
    from .rendertype import RgbBg, RgbFg

    class TestRegister(Register):
        pass

    tr = TestRegister()

    # Test default register
    tr.renderfuncs.update({RgbFg: lambda r, g, b: ""})
    tr.rgb = Style(RgbFg(10, 42, 255))

    assert tr.rgb == ""

    tr.unmute()
    assert tr.rgb == ""

    # Test custom register
    tr.renderfuncs.update({Sgr: lambda code: f"the sgr code is {code}"})
    tr.bold = Style(Sgr(1))
    assert tr.bold == "the sgr code is 1"

    tr.mute()
    assert tr.bold == ""

    tr.un

# Generated at 2022-06-24 04:54:33.067297
# Unit test for method mute of class Register
def test_Register_mute():

    # Create a new register
    reg = Register()

    # Create styles for the new register.
    reg.red = Style(RenderType(1))
    reg.bold = Style(RenderType(2))
    reg.yellow = Style(RenderType(3), RenderType(4))

    # Register can now be called in the following ways:

    # Call string 'red'
    assert reg.red == "\033[1m"
    assert reg("red") == "\033[1m"

    # Call string 'bold'
    assert reg.bold == "\033[2m"
    assert reg("bold") == "\033[2m"

    # Call string 'yellow'
    assert reg.yellow == "\033[3m\033[4m"
    assert reg("yellow") == "\033[3m\033[4m"

    # Mute

# Generated at 2022-06-24 04:54:44.117322
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg, ef

    fg.orange = Style(fg.orange, ef.bold)

    assert fg.orange == str(fg.orange)
    assert ef.bold in fg.orange.rules
    assert fg.orange == "\x1b[38;2;255;165;0m\x1b[1m"
    assert fg(144) == "\x1b[38;5;144m"

    fg.mute()

    assert str(fg.orange) == ""
    assert ef.bold in fg.orange.rules
    assert fg.orange == ""
    assert fg(144) == ""

    fg.set_eightbit_call(fg.rgb)

    assert fg(144) == ""

    fg.unmute()

    assert f

# Generated at 2022-06-24 04:54:53.084560
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rules import Sgr, RgbFg
    SGR = Sgr(1)
    R1 = RgbFg(15, 15, 15)
    style1 = Style(SGR, R1)
    reg = Register()
    reg.set_rgb_call(RgbFg)
    setattr(reg, "black", style1)
    reg.mute()
    r1 = str(reg.black)
    assert r1 == ""
    reg.unmute()
    r2 = str(reg.black)
    assert r2 == '\x1b[38;2;15;15;15m\x1b[1m'

# Generated at 2022-06-24 04:54:55.126177
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.test1 = Style("test1")
    r.test2 = Style("test2")
    assert r.as_dict() == {"test1":"test1", "test2":"test2"}



# Generated at 2022-06-24 04:55:06.288633
# Unit test for method __call__ of class Register
def test_Register___call__():
    u1 = Register()
    u1.test1 = Style(Rgb(255, 0, 0))
    u1.test2 = Style(eightbit(1))

    assert str(u1.test1) == "\x1b[38;2;255;0;0m"
    assert str(u1.test2) == "\x1b[38;5;1m"

    assert u1.test1 == "\x1b[38;2;255;0;0m"
    assert u1.test2 == "\x1b[38;5;1m"

    assert u1(1) == "\x1b[38;5;1m"
    assert u1(1) == u1.test2


# Generated at 2022-06-24 04:55:14.258100
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import EightbitBg, EightbitFg

    class MyRegister(Register):
        pass

    myrg = MyRegister()

    def eightbit_bg(index: int) -> str:
        return f"\x1b[48;5;{index}m"

    def eightbit_fg(index: int) -> str:
        return f"\x1b[38;5;{index}m"

    myrg.set_renderfunc(EightbitBg, eightbit_bg)
    myrg.set_renderfunc(EightbitFg, eightbit_fg)

    assert str(myrg(42)) == '\x1b[38;5;42m'

    myrg.set_eightbit_call(EightbitBg)

# Generated at 2022-06-24 04:55:15.653157
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)


# Generated at 2022-06-24 04:55:24.799596
# Unit test for method copy of class Register
def test_Register_copy():

    class DerivedRegister(Register):
        pass

    r = Register()
    r.foo = "bar"
    r.renderfuncs["Sgr"] = lambda x: f'\x1b[{x}m'

    r2 = r.copy()

    assert isinstance(r2, Register)

    assert r2 is not r

    assert r2.foo == "bar"

    assert r2.renderfuncs["Sgr"] is r.renderfuncs["Sgr"]

    r3 = DerivedRegister()
    r3.foo = "bar"
    r3.renderfuncs["Sgr"] = lambda x: f'\x1b[{x}m'

    r4 = r3.copy()

    assert isinstance(r4, Register)

    assert r4 is not r3

    assert r4.foo

# Generated at 2022-06-24 04:55:32.111997
# Unit test for constructor of class Register
def test_Register():
    # Basic test creation of default registers.
    assert isinstance(fg, Register)
    assert isinstance(bg, Register)
    assert isinstance(ef, Register)
    assert isinstance(rs, Register)

    # Test that default registers are set to correct render-functions.
    assert fg.eightbit_call == fg.renderfuncs[EightbitFg]
    assert bg.eightbit_call == bg.renderfuncs[EightbitBg]
    assert ef.eightbit_call == ef.renderfuncs[EightbitFg]
    assert rs.eightbit_call == rs.renderfuncs[RgbFg]

    assert fg.rgb_call == fg.renderfuncs[RgbFg]

# Generated at 2022-06-24 04:55:39.107745
# Unit test for method mute of class Register
def test_Register_mute():
    fg = Register()
    fg.mute()

    assert fg.is_muted

    attribute_test = Style(RenderType("38;2;1;2;3"), RenderType("1"))
    attribute_test_muted = Style(*attribute_test.rules, value="")
    assert getattr(fg, "attribute_test") == attribute_test_muted

    fg.unmute()

    assert not fg.is_muted
    assert getattr(fg, "attribute_test") == attribute_test



# Generated at 2022-06-24 04:55:46.685260
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.red = Style()
            self.blue = Style()
            self.green = Style()

    tr = TestRegister()

    # Test attribute lookup
    assert tr("red") == ""

    # Test 8bit call
    tr.set_eightbit_call(RgbFg)
    assert tr(1) == ""
    tr.set_eightbit_call(RgbBg)
    assert tr(1) == ""

# Generated at 2022-06-24 04:55:50.550835
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.red = "red"

    tr = TestRegister()

    result = tr.as_dict()

    assert result == {"red": "red"}, "Expected {'red': 'red'}, get {}.".format(result)


# Generated at 2022-06-24 04:55:54.356290
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg, bg

    fg.orange = Style(RgbFg(1,1,1))

    fg.mute()

    assert str(fg.orange) == ""


# Generated at 2022-06-24 04:55:58.997118
# Unit test for method copy of class Register
def test_Register_copy():
    register = Register()
    register.test = Style(RenderType)
    new_register = register.copy()
    assert register is not new_register
    assert register.test is not new_register
    assert register.test.rules[0] is new_register.test.rules[0]

# Generated at 2022-06-24 04:56:08.085572
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit test for method __call__ of class Register.
    """

    class Rgb(RenderType):
        """
        Custom rendertype for simulating rgb render-types.
        """
        name = "rgb"

        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

        def __str__(self):
            return f"{self.name}({self.args})"

    class Fg(Rgb):
        """
        Custom rendertype for simulating fg render-types.
        """
        name = "fg"

    class Bold(RenderType):
        """
        Custom rendertype for simulating bold render-types.
        """
        name = "bold"

        def __init__(self):
            self.args = ()

# Generated at 2022-06-24 04:56:13.754110
# Unit test for method mute of class Register
def test_Register_mute():
    # Arrange
    class Rt(RenderType):
        pass

    rt = Rt(0, 1, 2, 3)
    style = Style(rt)
    register = Register()
    register.set_renderfunc(Rt, lambda *args: "RENDERFUNC")
    register.style = style

    # Act
    register.mute()

    # Assert
    assert register.style == Style() # type: ignore


# Generated at 2022-06-24 04:56:18.742599
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    s = Style(RgbFg(100, 200, 255), Sgr(1))
    r.test = s
    r.foo = "foobar"

    assert r.as_dict() == {"test": "\x1b[38;2;100;200;255m\x1b[1m", "foo": "foobar"}



# Generated at 2022-06-24 04:56:27.993035
# Unit test for method mute of class Register
def test_Register_mute():

    import sty

    _fg = sty.fg
    _bg = sty.bg

    _fg.mute()
    _bg.mute()

    assert _fg(1) == ""
    assert _fg(42) == ""
    assert _fg(255) == ""
    assert _fg(100, 100, 100) == ""
    assert _fg('red') == ""
    assert _fg('blue') == ""

    assert _bg(1) == ""
    assert _bg(42) == ""
    assert _bg(255) == ""
    assert _bg(100, 100, 100) == ""
    assert _bg('red') == ""
    assert _bg('blue') == ""

    _fg.unmute()
    _bg.unmute()

    assert _fg(1) != ""
    assert _fg(42)

# Generated at 2022-06-24 04:56:37.242420
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    reg = Register()
    reg.test = Style("test")
    reg.test1 = Style("test1")
    reg.test2 = Style("test2", "test3")
    reg.test3 = Style("test4", *reg.test1)
    reg.test4 = Style("test5", *reg.test2)

    assert reg.test == "test"
    assert reg.test1 == "test1"
    assert reg.test2 == "test2test3"
    assert reg.test3 == "test1test1"
    assert reg.test4 == "test2test3test2test3"

# Generated at 2022-06-24 04:56:46.167866
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Mock render-functions
    renderfuncs: Renderfuncs = {}

    def func1(*args):
        return "1"

    def func2(*args):
        return "2"

    def func3(*args):
        return "3"

    # Mock Rendertypes
    class MockRt1(RenderType):
        pass

    class MockRt2(RenderType):
        pass

    class MockRt3(RenderType):
        pass

    r1 = MockRt1()
    r2 = MockRt2()
    r3 = MockRt3()

    # Mock style
    s1 = Style(r1, r2, r3)

    # Assign mock renderfuncs

# Generated at 2022-06-24 04:56:56.116240
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        def render(self, r, g, b):
            return "\x1b[38;5;" + self._call(r, g, b) + "m"

    class Sgr(RenderType):
        def render(self, *args):
            return "\x1b[" + ";".join(map(str, args)) + "m"

    class RgbBg(RenderType):
        def render(self, r, g, b):
            return "\x1b[48;5;" + self._call(r, g, b) + "m"

    def rgb_fg_to_8bit_call(r, g, b):
        return str(r + g + b)


# Generated at 2022-06-24 04:57:04.436542
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    _Register = Register()

    _RenderType = RenderType()

    _RenderType.func = lambda d, x: str(x)

    _Register.set_renderfunc(rendertype=RenderType, func=_RenderType.func)

    for i in range(4):
        setattr(_Register, f"F{i}", Style(*[RenderType(i)]))

    assert _Register.as_dict() == {'F0': '0', 'F1': '1', 'F2': '2', 'F3': '3'}



# Generated at 2022-06-24 04:57:15.139788
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .render import RgbBg, RgbFg, Sgr

    def render_func(*args):
        return "".join(f"{x};" for x in args)

    # Create test register.
    r = Register()
    r.set_renderfunc(Sgr, render_func)
    r.set_renderfunc(RgbFg, render_func)
    r.set_renderfunc(RgbBg, render_func)

    # Create default styles.
    r.red = Style(RgbFg(1, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 1), Sgr(1))

    # Change rendertype for RGB-calls
    r.set_rgb_call(RgbFg)

    assert r.red == ""

# Generated at 2022-06-24 04:57:17.163935
# Unit test for method unmute of class Register
def test_Register_unmute():
    import pytest
    from sty import fg
    fg.unmute()
    # Check if styles are really rendered
    assert isinstance(fg.red, str)


# Generated at 2022-06-24 04:57:26.828211
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    register.red = Style(RgbFg(101, 11, 20))
    register.green = Style(RgbFg(11, 202, 20))
    register.blue = Style(RgbFg(11, 33, 20))

    assert register.red == "\x1b[38;2;101;11;20m"
    assert register.green == "\x1b[38;2;11;202;20m"
    assert register.blue == "\x1b[38;2;11;33;20m"

    namedtuple_register = register.as_namedtuple()
    assert namedtuple_register.red == "\x1b[38;2;101;11;20m"

# Generated at 2022-06-24 04:57:32.645231
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Test with simple register without attributes
    registers = Register()
    assert registers.as_dict() == {}

    test_tuple = NamedTupleStyleRegister(red="\x1b[1;31m", green="\x1b[1;32m")

    # Test with register that has attributes
    registers = Register()
    registers.red = test_tuple.red
    registers.green = test_tuple.green
    assert registers.as_dict() == {"red": test_tuple.red, "green": test_tuple.green}



# Generated at 2022-06-24 04:57:40.356438
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Sty(Register):
        pass

    sty = Sty()

    @sty.set_renderfunc(RenderType, lambda x: f"{x} rendered")
    def f1(x):
        assert x == "one"
        return x

    sty.one = Style(RenderType("one"))

    sty.two = Style(RenderType("two"))

    sty.set_eightbit_call(RenderType)

    assert sty("one") == "one rendered"

    assert sty("two") == "two rendered"



# Generated at 2022-06-24 04:57:42.745681
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register) == True

# Generated at 2022-06-24 04:57:48.137851
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

    # is_muted is False by default
    assert r.is_muted == False

    # register is not muted after calling mute()
    r.mute()
    assert r.is_muted == True

    # register is not muted after calling unmute()
    r.unmute()
    assert r.is_muted == False



# Generated at 2022-06-24 04:57:54.594145
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    This unittest tests method set_rgb_call of class Register.
    """

    def rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def eightbit_bg(code, *args):
        return f"\x1b[48;5;{code}m"

    Fg = Register()
    Fg.set_renderfunc(RgbFg, rgb_fg)
    Fg.set_renderfunc(EightbitFg, eightbit_bg)

    Fg.set_rgb_call(RgbFg)

# Generated at 2022-06-24 04:57:57.852331
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: x)
    r.set_eightbit_call(RenderType)
    assert r(42) == 42


# Generated at 2022-06-24 04:58:02.299990
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr

    fg = Register()

    # Define red as SGR-formatting
    fg.red = Style(Sgr(1))

    # Muting a register will transfer the String-attributes to an empty String.
    # A call with this Style instance still returns the same String.
    fg.mute()

    assert not fg.red
    assert fg.red() == fg.red

    # Unmuting the register will transfer the Styles back to the original Strings.
    fg.unmute()

    assert fg.red

# Generated at 2022-06-24 04:58:13.096497
# Unit test for method __call__ of class Register
def test_Register___call__():

    register = Register()

    class RgbFg(RenderType):
        def __call__(self, r, g, b):
            return f"\x1b[38;2;{r};{g};{b}m"

    class Sgr(RenderType):
        def __call__(self, n):
            return f"\x1b[{n}m"

    register.set_renderfunc(RgbFg, RgbFg.__call__)
    register.set_renderfunc(Sgr, Sgr.__call__)

    register.red = Style(Sgr(1), RgbFg(255, 0, 0))

    assert register("red") == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-24 04:58:20.900333
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbBg

    # Test register
    class TestRegisterA:
        __a = Style(RgbBg(0,0,0))
        __b = Style(RgbBg(0,0,0))

    a = TestRegisterA()
    assert(a.__a == a.__b)
    a.set_renderfunc(RgbBg, lambda r, g, b: "X")
    assert(a.__a != a.__b)

# Generated at 2022-06-24 04:58:28.056344
# Unit test for method __call__ of class Register
def test_Register___call__():

    def eightbit_render(code: int) -> str:
        return f"{code}_eightbit"

    def rgb_render(r: int, g: int, b: int) -> str:
        return f"{r}_{g}_{b}_rgb"

    class RgbRenderType(RenderType):
        def __init__(self, *args):
            pass

    my_reg = Register()
    my_reg.set_eightbit_call(RgbRenderType)
    my_reg.set_rgb_call(RgbRenderType)
    my_reg.set_renderfunc(RgbRenderType, eightbit_render)
    my_reg.set_renderfunc(RgbRenderType, rgb_render)

    assert my_reg.eightbit_call == eightbit_render
    assert my_reg

# Generated at 2022-06-24 04:58:38.147053
# Unit test for method mute of class Register
def test_Register_mute():

    # Init Register
    fg = Register()
    fg.set_eightbit_call(lambda x: f"\x1b[38;5;{x}m{x}")
    fg.set_rgb_call(lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m{r};{g};{b}")

    # Create a new style
    fg_red = Style(RgbFg(255, 0, 0))
    fg.red = fg_red

    # Check if name is set correctly
    assert hasattr(fg, "red")

    # Check rendered value
    assert str(fg.red) == "\x1b[38;2;255;0;0m"

    # Mute register
    fg.mute()

# Generated at 2022-06-24 04:58:42.721818
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.style1 = Style()
    r.style2 = Style()
    r.style3 = Style()
    nt1 = r.as_namedtuple()
    nt2 = namedtuple("StyleRegister", ("style1", "style2", "style3"))()
    assert nt1 == nt2, "Register.as_namedtuple should return an empty namedtuple"



# Generated at 2022-06-24 04:58:50.115576
# Unit test for constructor of class Style
def test_Style():
    # Test user defined Style
    style = Style(RgbFg(1,2,3), Sgr(1))
    assert isinstance(style, Style) is True
    assert isinstance(style, str) is True
    assert str(style) == "\x1b[38;2;1;2;3m\x1b[1m"

    # Test default fg Style
    style = Style(RgbFg(1,2,3), Sgr(1))
    assert str(style) == "\x1b[38;2;1;2;3m\x1b[1m"



# Generated at 2022-06-24 04:58:52.800987
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r=Register()

    r.bold="\x1b[1m"

    t=r.as_namedtuple()

    assert t.bold == "\x1b[1m"
# EOF

# Generated at 2022-06-24 04:59:04.123376
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertypes import Eightbit, RgbFg

    # Setup Register
    reg = Register()
    func1 = lambda *args, **kwargs: "".join(f"{arg}_" for arg in args)
    func2 = lambda r, g, b, **kwargs: f"{r}:{g}:{b}"
    reg.set_renderfunc(Eightbit, func1)
    reg.set_renderfunc(RgbFg, func2)
    reg.yellow = Style(Eightbit(125))
    reg.background = Style(RgbFg(1, 1, 1))

    # Register must not have eightbit_call attribute
    assert not hasattr(reg, "eightbit_call")

    # Register must not have rgb_call attribute
    assert not hasattr(reg, "rgb_call")

   

# Generated at 2022-06-24 04:59:15.588493
# Unit test for method mute of class Register
def test_Register_mute():

    # class TestRegister(Register):
    #     white = Style(RgbFg(255, 255, 255))

    # r = TestRegister()
    # r.white = Style(RgbFg(255, 255, 255))

    r = Register()
    r.white = Style(RgbFg(255, 255, 255))
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    assert str(r.white) == "\x1b[38;2;255;255;255m"
    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert str(r.blue) == "\x1b[38;2;0;0;255m"

    r

# Generated at 2022-06-24 04:59:27.066621
# Unit test for method mute of class Register
def test_Register_mute():
    class CustomRenderType(RenderType):
        def __init__(self, value: int):
            self.value = value

        def __str__(self):
            return "CustomRenderType {value}".format(value=self.value)

    @CustomRenderType.render_function()
    def render_custom_type(custom_type: CustomRenderType):
        return str(custom_type)

    r = Register()
    r.set_renderfunc(CustomRenderType, render_custom_type)

    r.red = Style(CustomRenderType(2))
    assert str(r.red) == "CustomRenderType 2"

    r.mute()
    assert str(r.red) == ""

    r.unmute()
    assert str(r.red) == "CustomRenderType 2"

