

# Generated at 2022-06-24 04:49:32.559693
# Unit test for method __call__ of class Register
def test_Register___call__():
    one_input_cases = [
        (None, ""),
        ("red", "\x1b[38;2;255;0;0m"),
        (42, "\x1b[38;5;42m"),
        (102, "\x1b[48;5;102m"),
        (10, "\x1b[38;5;10m"),
    ]

    one_input_test(one_input_cases)


# Generated at 2022-06-24 04:49:37.538409
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import ef

    # init register
    reg = Register()
    reg.renderfuncs.update({RenderType: lambda x, y, z: "abc"})

    # call it with default render-type RenderType
    reg.set_rgb_call(RenderType)
    assert reg.rgb_call(1, 2, 3) == "abc"

    # call it with another render-type
    reg.renderfuncs.update({ef.RenderType: lambda x, y, z: "xyz"})
    reg.set_rgb_call(ef.RenderType)
    assert reg.rgb_call(1, 2, 3) == "xyz"

# Generated at 2022-06-24 04:49:47.137187
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .sgr import Sgr
    from .rgb import RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(Sgr, lambda x: "\x1b[%sm" % x)
    r.foo = Style(RgbFg(1, 5, 10), Sgr(1))
    r.mute()
    assert str(r.foo) == ""
    r.unmute()

    assert str(r.foo) == "\x1b[38;2;1;5;10m\x1b[1m"
    assert r.is_muted is False


# Generated at 2022-06-24 04:49:55.159474
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Test with wrong type of parameter rendertype.
    try:
        Register.set_rgb_call(None, None)
        assert False, "Exception should be raised."
    except ValueError:
        pass

    # Test with wrong type of parameter func.
    try:
        Register.set_rgb_call(type(RgbFg), None)
        assert False, "Exception should be raised"
    except ValueError:
        pass

    class RegisterNew(Register):
        pass

    # Test with wrong type of parameter func.
    register_new = RegisterNew()
    register_new.set_rgb_call(type(RgbFg), lambda r, g, b: (r, g, b))

    assert register_new.rgb_call(1, 2, 3) == (1, 2, 3)

# Generated at 2022-06-24 04:50:05.271465
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    rendertype: Type[RenderType] = RenderType("hello")

    rendertype.add_param("bold", 23, ())
    rendertype.add_param("italic", 28, ("italic",))

    arg_1: RenderType = rendertype(bold=True, italic=True)


# Generated at 2022-06-24 04:50:15.403573
# Unit test for method unmute of class Register
def test_Register_unmute():

    """
    Test to check if the unmute method restores the changed rendered string after
    the object has been muted.
    """

    from . import fg, bg
    from .ansi import RgbFg, RgbBg, Sgr

    RgbFg.ansi_func = lambda *args: "MUTED"
    Sgr.ansi_func = lambda *args: "STILLMUTED"

    fg.test = Style(RgbFg(1,2,3), Sgr())
    fg.mute()

    assert fg.test == "MUTED"

    fg.unmute()

    assert fg.test == "\x1b[38;2;1;2;3m"


# Generated at 2022-06-24 04:50:16.900153
# Unit test for constructor of class Style
def test_Style():
    assert Style("a", "b") == "ab"
    assert Style("a", "b", value="c") == "c"


# Generated at 2022-06-24 04:50:23.247592
# Unit test for method __new__ of class Style
def test_Style___new__():

    def test_Style_is_not_Style():
        s = Style()
        assert not isinstance(s, Style)

    def test_Style_is_str():
        s = Style()
        assert isinstance(s, str)

    def test_Style_has_rules():
        s = Style()
        assert hasattr(s, "rules")

    test_Style_is_not_Style()
    test_Style_is_str()
    test_Style_has_rules()



# Generated at 2022-06-24 04:50:30.494770
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    def testfunc(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(RgbFg, testfunc)
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    r.red = Style(RgbFg(255, 0, 0))
    r.yellow = Style(RgbFg(255, 255, 255), Sgr(1))

    data: Dict[str, str] = r.as_dict()

    assert data["red"] == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:50:39.921875
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg
    from .ansi import ANSI

    ansi_fg: Register = ANSI.fg
    ansi_bg: Register = ANSI.bg

    # Set rendertype for rgb-call
    ansi_fg.set_rgb_call(RgbFg)
    ansi_bg.set_rgb_call(RgbBg)

    # Set render-functions to return values
    ansi_fg.set_renderfunc(RgbFg, lambda r, g, b: r)
    ansi_bg.set_renderfunc(RgbBg, lambda r, g, b: g)

    assert ansi_fg(1,2,3) == 1
    assert ansi_bg(1,2,3) == 2

# Generated at 2022-06-24 04:50:51.446333
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    tr1 = TestRegister()
    tr2 = TestRegister()

    class R1(RenderType):
        def render(self, *args):
            return "R1"

    class R2(RenderType):
        def render(self, *args):
            return "R2"

    class R3(RenderType):
        def render(self, *args):
            return "R3"

    class R4(RenderType):
        def render(self, *args):
            return "R4"

    tr1.set_renderfunc(R1, lambda *args: "R1")
    tr1.set_renderfunc(R2, lambda *args: "R2")
    tr1.set_renderfunc(R3, lambda *args: "R3")

    tr1.blue

# Generated at 2022-06-24 04:51:01.423333
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Rgbfg(RenderType):

        def __init__(self, r: int, g: int, b: int):
            super().__init__(self.__class__, (r, g, b))

        def render(self) -> str:
            return "\x1b[38;2;%d;%d;%dm" % self.args

    class Simple(RenderType):

        def __init__(self, i: int):
            super().__init__(self.__class__, (i,))

        def render(self) -> str:
            return "\x1b[%sm" % self.args[0]

    r = Register()


# Generated at 2022-06-24 04:51:11.641849
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This is a unit test for the register class. It tests the __setattr__ method.
    """

    from .rendertype import Sgr

    from .color_space import ColorSpace

    from .rgbtohtml import RGBToHTML
    from .rgbtohtml import HexToHTML
    from .rgbtohtml import NameToHTML

    rgbth = RGBToHTML()
    hextohtml = HexToHTML()
    nametohtml = NameToHTML()

    # Create a new register object.
    cl = Register()

    # Register the render-functions.
    cl.set_renderfunc(Sgr, lambda x: f"{x}")

    # Register the rgb conversion function (for example rgbth)

# Generated at 2022-06-24 04:51:18.605678
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .sgr import Sgr, RgbFg, RgbBg
    import sys
    import os

    def myrenderfunc(x: int) -> str:
        return "test-{}".format(x)

    def print_mutes_and_unmutes(msg):
        out = sys.stdout
        os.write(out.fileno(), msg.encode("utf-8"))

    r = Register()
    r.set_renderfunc(Sgr, myrenderfunc)

    r.bold = Style(Sgr(1))
    assert r.bold == "test-1"

    r.bold_and_red = Style(r.bold, RgbFg(255, 0, 0))

# Generated at 2022-06-24 04:51:20.365083
# Unit test for method copy of class Register
def test_Register_copy():
    register = Register()
    register.test = Style(value="yo")

    assert id(register.test) != id(register.copy().test)

# Generated at 2022-06-24 04:51:27.026076
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register
    """
    reg = Register()
    reg.test_attr = Style(value="test_value")
    reg2 = reg.copy()

    assert hasattr(reg, "test_attr")
    assert id(reg) != id(reg2)
    assert hasattr(reg2, "test_attr")
    assert reg2.test_attr == "test_value"

# Generated at 2022-06-24 04:51:30.225500
# Unit test for method unmute of class Register
def test_Register_unmute():
    register = Register()
    register.is_muted = True
    register.test = Style("\033[94m")
    register.unmute()
    assert register.is_muted == False


# Generated at 2022-06-24 04:51:35.753076
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Tests for method set_rgb_call of Register class.
    """
    from .render import RgbFg

    register = Register()
    register.set_rgb_call(RgbFg)

    assert register.rgb_call(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-24 04:51:38.199299
# Unit test for constructor of class Register
def test_Register():
    rs = Register()
    assert isinstance(rs, Register)


# Generated at 2022-06-24 04:51:48.446808
# Unit test for constructor of class Style
def test_Style():

    class RuleA(RenderType):

        @staticmethod
        def ansi_code() -> str:
            return "test"

    class RuleB(RenderType):

        @staticmethod
        def ansi_code() -> str:
            return "test2"

    class RuleC(RenderType):

        @staticmethod
        def ansi_code() -> str:
            return "test3"

    a = Style(RuleA(), RuleB(), RuleC())

    assert str(a) == "testtest2test3"
    assert a.rules[0] == RuleA()
    assert a.rules[1] == RuleB()
    assert a.rules[2] == RuleC()

    b = Style(a, RuleC())

    assert str(b) == "testtest2test3test3"

# Generated at 2022-06-24 04:51:51.574731
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    r = Register()
    r.blue = Style(RgbFg(0, 0, 255))

    assert r.blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-24 04:52:00.346835
# Unit test for method __new__ of class Style
def test_Style___new__():

    s1 = Style(value="abc")
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "abc"
    assert s1.rules == ()

    s2 = Style("rule1", "rule2", value="")
    assert isinstance(s2, Style)
    assert s2.rules == ("rule1", "rule2")

    s3 = Style("rule1", "rule2", value="abc")
    assert isinstance(s3, Style)
    assert str(s3) == "abc"
    assert s3.rules == ("rule1", "rule2")



# Generated at 2022-06-24 04:52:01.226641
# Unit test for constructor of class Register
def test_Register():
    # register = Register()
    return True

# Generated at 2022-06-24 04:52:07.483316
# Unit test for method __call__ of class Register
def test_Register___call__():
    class TestRegister(Register):
        rule_1: Style
        rule_2: Style

    TestRegister.renderfuncs = {int: lambda x: f"{x}"}

    t = TestRegister()
    t.rule_1 = Style(1)
    t.rule_2 = Style(2)

    assert t(1) == "1"
    assert t("rule_1") == "1"



# Generated at 2022-06-24 04:52:16.088584
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Test for strings
    fg = Register()
    fg.r = Style(fg.rgb, fg.bold, value="\x1b[31m")
    assert isinstance(fg.r, Style)
    assert str(fg.r) == "\x1b[31m"

    # Test for ints
    fg = Register()
    fg.set_eightbit_call(fg.rgb)
    fg.r = Style(fg.rgb, fg.bold, value="\x1b[1m")
    assert isinstance(fg.r, Style)
    assert str(fg.r) == "\x1b[1m"

    # Test for tuples
    fg = Register()
    fg.set_rgb_call(fg.rgb)

# Generated at 2022-06-24 04:52:23.180485
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class MyRegister(Register):
        orange = Style(RgbFg(1,5,10), Sgr(1))

    sty = MyRegister()
    d = sty.as_dict()
    assert d == {'orange': '\x1b[38;2;1;5;10m\x1b[1m'}


# Generated at 2022-06-24 04:52:27.023571
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr

    reg = Register()
    reg.set_renderfunc(Sgr, lambda *args: "test")
    reg.testcolor = Style(Sgr(1))

    assert reg.testcolor == "test"
    reg.mute()
    assert reg.testcolor == ""
    reg.unmute()
    assert reg.testcolor == "test"

# Generated at 2022-06-24 04:52:31.091722
# Unit test for method mute of class Register
def test_Register_mute():
    class CustomRegister(Register):
        def __init__(self, r: str):
            self.r = Style(r)
            self.renderfuncs = {"a": lambda x: "aaa"}

    r: CustomRegister = CustomRegister("a")

    r.mute()

    assert r.is_muted == True and r.r == ""

# Generated at 2022-06-24 04:52:42.166694
# Unit test for method copy of class Register
def test_Register_copy():

    # Create simple register object with one attribute.
    class TestRegister(Register):
        pass

    test_register = TestRegister()

    setattr(test_register, "test_attr", Style(fg=42, bg=255))

    # Make a deepcopy of test_register.
    test_register_copy = test_register.copy()

    # Check that attribute test_attr has been copied.
    assert hasattr(test_register_copy, "test_attr")

    # Check that test_register_copy.test_attr is a Style object.
    assert isinstance(test_register_copy.test_attr, Style)

    # Check that test_register_copy.test_attr.rules is a tuple.
    assert isinstance(test_register_copy.test_attr.rules, tuple)

    # Check that test_register_copy.

# Generated at 2022-06-24 04:52:43.566791
# Unit test for method mute of class Register
def test_Register_mute():
    pass



# Generated at 2022-06-24 04:52:50.028055
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Assert that a register-object can be called with a single int and single string.
    """
    fg = Register()
    fg.red = Style(RgbFg(10, 20, 31))

    assert fg(42) == ""
    assert fg("red") == '\x1b[38;2;10;20;31m'


# Unit tests for method set_renderfunc of class Register

# Generated at 2022-06-24 04:52:59.234040
# Unit test for constructor of class Register
def test_Register():
    class RGB(NamedTuple):
        r: int
        g: int
        b: int

    class Color(NamedTuple):
        name: str
        rgb: RGB
        hex: str
        ansi: str


# Generated at 2022-06-24 04:53:10.149250
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        def set_eightbit_call(self, rendertype: Type[RenderType]) -> None:
            pass

        def set_rgb_call(self, rendertype: Type[RenderType]) -> None:
            pass

        def set_renderfunc(self, rendertype: Type[RenderType], func: Callable) -> None:
            pass

    class TestRenderType(RenderType):
        sequence: str = "Test"

    RESULT1: RenderType = TestRenderType()
    RESULT2: RenderType = TestRenderType()

    test_register: TestRegister = TestRegister()

    test_register.renderfuncs.update({TestRenderType: lambda x: RESULT1})

    test_register.test_rendertype_1 = Style(TestRenderType())
    test_register.test_rendertype_2

# Generated at 2022-06-24 04:53:13.008699
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)

# Generated at 2022-06-24 04:53:23.010978
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MockRenderType(RenderType):

        call_func: Callable[[], None]

        def __init__(self, call_func=None):
            self.call_func = call_func

        def render(self) -> str:
            self.call_func()
            return ""

    class MockEightBitRenderType(MockRenderType):

        args: Tuple[int]

        def __init__(self, call_func=None, args=()):
            super().__init__(call_func)
            self.args = args

    class MockRgbRenderType(MockRenderType):

        args: Tuple[int]

        def __init__(self, call_func=None, args=()):
            super().__init__(call_func)
            self.args = args

    # Define some mock render

# Generated at 2022-06-24 04:53:27.279715
# Unit test for method mute of class Register
def test_Register_mute():
    from .xterm256 import fg

    fg.mute()
    assert fg.is_muted == True
    fg.unmute()
    assert fg.is_muted == False

    fg.mute()
    assert fg.reset == ""
    assert fg.white == ""
    assert fg.light_gray == ""


# Generated at 2022-06-24 04:53:31.729344
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test Register.set_eightbit_call()
    """

    RgbFg = RenderType("RgbFg", "38", "2")
    renderfuncs: Renderfuncs = {RgbFg: lambda r, g, b: f"{r+g+b}"}

    r = Register()
    r.set_renderfunc(RgbFg, renderfuncs[RgbFg])
    r.set_eightbit_call(RgbFg)

    assert r(99) == "297"



# Generated at 2022-06-24 04:53:42.205360
# Unit test for method mute of class Register
def test_Register_mute():
    class FooRegister(Register):
        def __init__(self):
            super().__init__()
            self.foo = Style(RgbFg(0,0,0), Sgr(1))
            self.bar = Style(EightBitBg(10), Sgr(0))
            self.foo_bar = Style(EightBitBg(10), Sgr(1))

    fg = FooRegister()
    fg.mute()
    assert fg.foo == ""
    assert fg.bar == ""
    assert fg.foo_bar == ""

    fg.unmute()
    assert fg.foo == "\x1b[38;2;0;0;0m\x1b[1m"

# Generated at 2022-06-24 04:53:48.897810
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = (code)

    def render_func_1(r: int, g: int, b: int):
        return f"\x1b[{r}{g}{b}m"

    def render_func_2(code: int):
        return f"\x1b[{code}m"

    r = Register()
    r.set_renderfunc(rendertype=RgbFg, func=render_func_1)
    r.set_renderfunc(rendertype=Sgr, func=render_func_2)

   

# Generated at 2022-06-24 04:53:55.232709
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0))
    reg.green = Style(RgbFg(0, 255, 0))
    assert reg.as_dict() == {"red": "\x1b[38;2;255;0;0m", "green": "\x1b[38;2;0;255;0m"}

# Generated at 2022-06-24 04:54:01.748635
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RenderType

    class RgbTest(RenderType):

        def render(self, r: int, g: int, b: int) -> str:

            return ""

    class TestRegister(Register):

        def __init__(self):

            super().__init__()
            self.reset = Style(RgbTest())

    test_register = TestRegister()

    assert test_register.reset == ""
    test_register.set_rgb_call(RgbTest)
    assert test_register.reset == ""
    assert test_register.reset(0, 0, 0) == ""

# Generated at 2022-06-24 04:54:09.138847
# Unit test for method __new__ of class Style
def test_Style___new__():

    fg = Register()
    fg.set_renderfunc(RenderType, lambda x: "\x1b[38;2;{};{};{}m".format(x))
    fg.fg = Style(RenderType(10, 40, 100))

    assert str(fg.fg) == '\x1b[38;2;10;40;100m'

# Generated at 2022-06-24 04:54:18.502977
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Rs(RenderType):
        """
        This is a dummy rendertype to test Register's set_eightbit_call method.
        """

        def render(self, code: int) -> str:
            return "\x1b[39m\x1b[49m"

    class RgbFg(RenderType):
        """
        This is a dummy rendertype to test Register's set_eightbit_call method.
        """

        def render(self, r: int, g: int, b: int) -> str:
            return "rgbFg"

    r: Register = Register()
    r.test_style = Style(Rs())
    r.test_style2 = Style(RgbFg(1, 2, 3))
    r.set_eightbit_call(Rs)

# Generated at 2022-06-24 04:54:29.054122
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .sgr import Sgr
    from .rgb import RgbFg

    r = Register()
    r.set_renderfunc(Sgr, lambda a, b, c: f"<SGR:{a};{b};{c}>")
    r.set_renderfunc(RgbFg, lambda a, b, c: f"<RGB:{a};{b};{c}>")
    r.set_rgb_call(Sgr)

    assert r(255, 0, 0) == "<SGR:255;0;0>"
    assert r(RgbFg(255, 0, 1)) == "<RGB:255;0;1>"
    assert r(RgbFg(0, 255, 1)) == "<RGB:0;255;1>"



# Generated at 2022-06-24 04:54:37.391407
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .renderfunc import render_ansi256
    from .constants import Fg, Bg, RgbFg, RgbBg

    # Create new register-object
    fg = Register()

    # Register some renderfuncs.
    fg.set_renderfunc(Fg, render_ansi256)
    fg.set_renderfunc(Bg, render_ansi256)
    fg.set_renderfunc(RgbFg, render_ansi256)
    fg.set_renderfunc(RgbBg, render_ansi256)

    # Set fg-rule for attribute 'orange'
    fg.orange = Style(Fg(214))

    # Change default RGB-call to Fg
    fg.set_rgb_call(Fg)

    #


# Generated at 2022-06-24 04:54:45.269596
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import RgbFg, Sgr
    from .renderfunc import _render_rgb24, _render_sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))

    rg = TestRegister()

    # Check that there is only the default render-function for RgbFg in register
    assert RgbFg in rg.renderfuncs.keys()
    assert (rg.renderfuncs[RgbFg] == _render_rgb24)

    # Set new render function for Sgr
    rg.set_renderfunc(Sgr, _render_sgr)
    assert Sgr in rg.renderfuncs.keys()

# Generated at 2022-06-24 04:54:50.759928
# Unit test for constructor of class Register
def test_Register():
    assert issubclass(Register, object)
    assert isinstance(Register(), object)
    register = Register()
    register.set_eightbit_call(RenderType)
    assert isinstance(register("blue"), str)
    assert not isinstance(register("blue"), RenderType)


# Generated at 2022-06-24 04:54:55.365632
# Unit test for method unmute of class Register
def test_Register_unmute():

    r = Register()
    r.foo = Style(RenderType)
    assert not hasattr(r.foo, "rules")

    r.unmute()
    assert hasattr(r.foo, "rules")

# Generated at 2022-06-24 04:55:06.485243
# Unit test for method __call__ of class Register
def test_Register___call__():

    register = Register()

    register.black = Style(ColorFg(0))
    assert str(register.black) == "\x1b[30m"

    register.black = Style(ColorFg(0))
    assert str(register.black) == "\x1b[30m"

    register.black = Style(ColorBg(0))
    assert str(register.black) == "\x1b[40m"

    assert str(register("black")) == "\x1b[40m"

    register.set_eightbit_call(ColorFg)
    assert str(register("black")) == "\x1b[30m"

    register.set_rgb_call(RgbFg)
    assert str(register(10, 50, 255)) == "\x1b[38;2;10;50;255m"



# Generated at 2022-06-24 04:55:14.258100
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import fg

    # 1. Set color blue.
    fg.blue = Style(RgbFg(100, 100, 255), Sgr(1))
    assert(fg.blue == "\x1b[38;2;100;100;255;1m")

    # 2. Set color red.
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    assert(fg.red == "\x1b[38;2;255;0;0;1m")

    # 3. Mutte color red.
    fg.mute()
    assert(fg.red == "")

    # 4. Unmute color red.
    fg.unmute()

# Generated at 2022-06-24 04:55:19.599270
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from sty import fg, bg, ef

    x = fg.red
    y = bg.blue
    z = ef.bold
    assert Register.as_namedtuple(x) == fg.red.as_namedtuple()


# Generated at 2022-06-24 04:55:28.185907
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRenderType(RenderType):
        def render(self, *args):
            return "".join(args)

    def renderfunc(x: TestRenderType, *args):
        return x.render(*args)

    r = Register()
    r.set_renderfunc(TestRenderType, renderfunc)

    # Test setting Style to attribute
    r.test = Style(TestRenderType("test"), TestRenderType("test2"))
    assert isinstance(r.test, Style)

    # Test setting non-Style object to attribute
    r.test2 = 42
    assert not isinstance(r.test2, Style)


# Generated at 2022-06-24 04:55:33.542515
# Unit test for constructor of class Style
def test_Style():

    assert isinstance(Style(RenderType('1'), RenderType('2')), Style)
    assert isinstance(Style(RenderType('1'), RenderType('2')), str)

    assert str(Style(RenderType('1'), RenderType('2'))) == '12'

    Style(RenderType('1'), RenderType('2'), value='foobar')

    assert str(Style(RenderType('1'), RenderType('2'), value='foobar')) == 'foobar'

# Generated at 2022-06-24 04:55:43.800860
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertypes import RgbFg, Sgr

    name = "mystyle"
    rules = [RgbFg(30, 40, 50), Sgr(1)]
    value = "\x1b[38;2;30;40;50m\x1b[1m"

    # Create Style with given rules
    s = Style(*rules)

    # Check if created style is a str
    assert isinstance(s, str)

    # double check, that value is correct
    assert str(s) == value

    # Create Style with rules and value
    s = Style(*rules, value=value)

    # check, that value is correct
    assert str(s) == value

    # check, that rules are correct
    assert s.rules == rules

    # Create Style with name and rules

# Generated at 2022-06-24 04:55:49.558219
# Unit test for method __call__ of class Register
def test_Register___call__():
    class TestRegister(Register):

        def __call__(self, *args, **kwargs):
            assert args == (1, 2, 3)
            assert kwargs == {"name": "ben"}
            return "whatever"

    reg1 = TestRegister()
    reg1(1, 2, 3, name="ben")  # Just calls the method __call__, so no real test.



# Generated at 2022-06-24 04:55:53.495577
# Unit test for constructor of class Style
def test_Style():
    style1 = Style(value="Test 1")
    style2 = Style(value="Test 2")

    assert style1 == "Test 1"
    assert style2 == "Test 2"
    assert style1 != style2



# Generated at 2022-06-24 04:55:56.418592
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call is r.renderfuncs[RgbFg]

# Generated at 2022-06-24 04:55:59.492222
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr
    obj = Style(Sgr(1), value="hi")
    assert isinstance(obj, Style)
    assert isinstance(obj, str)
    assert obj=="hi"

# Generated at 2022-06-24 04:56:08.417902
# Unit test for method __new__ of class Style
def test_Style___new__():

    # Create a sample render type
    class MyRenderType(RenderType):
        start_str = "MyRenderType"
        end_str = "MyRenderType"
        arg_sep = ":"

    Rule = StylingRule

    # Create a sample render function
    def render(a: int, b: int) -> str:
        return f"{MyRenderType.start_str}{a}{MyRenderType.arg_sep}{b}{MyRenderType.end_str}"

    # Create a register and add a render function for the sample render type
    register = Register()
    register.set_renderfunc(MyRenderType, render)

    # Create a style for the sample render type
    style: Style = Style(MyRenderType(4, 8))

    # Test if __new__ is called for assignment
    assert str(style) == render

# Generated at 2022-06-24 04:56:12.822870
# Unit test for method mute of class Register
def test_Register_mute():
    import sty
    sty.registers.reset_defaults()

    # Test if the unformatted style is rendered.
    assert sty.registers.fg.red == "\x1b[31m"
    sty.registers.fg.red.mute()
    assert sty.registers.fg.red == ""



# Generated at 2022-06-24 04:56:17.022290
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr

    my_style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(my_style, Style)
    assert isinstance(my_style, str)



# Generated at 2022-06-24 04:56:24.043140
# Unit test for method copy of class Register
def test_Register_copy():
    # 1. Create basic register object
    r1 = Register()
    r1.renderfuncs = {"t1": lambda: None}
    r1.is_muted = True
    r1.eightbit_call = lambda x: x
    r1.rgb_call = lambda x,y,z: (x,y,z)
    r1.some_value = "some_string"

    # 2. Create deepcopy
    r2 = r1.copy()

    # 3. Check for equality
    assert r1.renderfuncs == r2.renderfuncs
    assert r1.is_muted == r2.is_muted
    assert r1.eightbit_call == r2.eightbit_call
    assert r1.rgb_call == r2.rgb_call
    assert r1.some_

# Generated at 2022-06-24 04:56:26.965289
# Unit test for method unmute of class Register
def test_Register_unmute():

    class R(Register):
        pass

    r = R()
    r.set_renderfunc(RenderType, lambda x: x)

    r.x = Style("x")
    assert r.x == "x"

    r.mute()
    assert r.x == ""

    r.unmute()
    assert r.x == "x"

# Generated at 2022-06-24 04:56:29.117065
# Unit test for constructor of class Register
def test_Register():

    fg: Register = Register()

    assert fg is not None
    assert fg.is_muted == False
    assert fg.eightbit_call(0) == ""
    assert fg.rgb_call(0, 0, 0) == ""

# Generated at 2022-06-24 04:56:37.364910
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    fg = Register()
    fg.red = Style(Sgr(1))
    fg.orange = Style(Sgr(1))
    fg.yellow = Style(Sgr(1))
    fg.green = Style(Sgr(1))
    fg.blue = Style(Sgr(1))
    fg.purple = Style(Sgr(1))
    fg.blue1 = Style(Sgr(1))
    fg.blue2 = Style(Sgr(1))
    fg.grey = Style(Sgr(1))
    fg.grey25 = Style(Sgr(1))
    fg.grey50 = Style(Sgr(1))
    fg.grey75 = Style(Sgr(1))
    fg.black = Style(Sgr(1))

# Generated at 2022-06-24 04:56:41.977502
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import sty
    
    fg = sty.fg
    d = fg.black.as_dict()

    assert d["black"] == "\x1b[30m"
    assert d["red"] == "\x1b[31m"
    assert d["green"] == "\x1b[32m"
    assert d["yellow"] == "\x1b[33m"
    assert d["blue"] == "\x1b[34m"
    assert d["magenta"] == "\x1b[35m"
    assert d["cyan"] == "\x1b[36m"
    assert d["white"] == "\x1b[37m"
    assert d["reset"] == "\x1b[39m"


# Generated at 2022-06-24 04:56:45.419199
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(RgbFg(1, 2, 3), Strip, Sgr(1), value="asdf")
    assert type(s) == Style
    assert s.rules[0].args == (1,2,3)
    assert s.rules[1].args == ()
    assert s.rules[2].args == (1,)
    assert s == "asdf"

# Generated at 2022-06-24 04:56:52.074006
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Do:
    r = Register()
    r.bar = Style(RgbBg(1,2,3))
    r.foo = Style(RgbBg(10,5,5))
    nt = r.as_namedtuple()

    # Assert:
    assert nt.bar == '\x1b[48;2;1;2;3m'



# Generated at 2022-06-24 04:56:55.792154
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .registers import fg, bg

    assert len(fg.as_namedtuple()._fields) == len(fg.as_dict().keys())
    assert len(bg.as_namedtuple()._fields) == len(bg.as_dict().keys())



# Generated at 2022-06-24 04:57:00.633086
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class X(Register):
        def __init__(self, **kwargs):
            super().__init__()

            for name, value in kwargs.items():
                setattr(self, name, value)

    x = X(test="test")

    assert x.as_dict() == {"test": "test"}

# Generated at 2022-06-24 04:57:03.139806
# Unit test for constructor of class Register
def test_Register():
    """
    Test constructor of class Register.
    """
    r = Register()
    assert r



# Generated at 2022-06-24 04:57:08.106793
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg

    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call(42, 255, 10) == (42, 255, 10)

# Generated at 2022-06-24 04:57:10.804383
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    c = Register()
    r = c.as_namedtuple()
    assert r.bold == "\x1b[1m"
    assert r.underline == "\x1b[4m"

# Generated at 2022-06-24 04:57:14.241063
# Unit test for method __new__ of class Style
def test_Style___new__():
    sty = Style(RgbFg(1,2,3), Sgr(1), value="")
    assert sty.rules == (RgbFg(1,2,3), Sgr(1))
    assert not hasattr(sty, "value")


# Generated at 2022-06-24 04:57:21.286637
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg, Sgr

    style1 = Style(RgbFg(3, 2, 5), Sgr(2))
    style2 = Style(RgbFg(3, 2, 5), Sgr(1))

    a = Register()

    a.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    a.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    a.north_pole = style1
    a.south_pole = style2
    a.west_pole = style2

    assert a.north_pole == '\x1b[38;2;3;2;5m\x1b[2m'



# Generated at 2022-06-24 04:57:24.872813
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbBg)

    s = Style(RgbFg(1, 2, 3), RgbBg(4, 5, 6))
    setattr(r, "red", s)

    r2 = r.copy()
    assert r2.red == s

# Generated at 2022-06-24 04:57:26.315422
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test
    """
    r = Register()
    r.unmute()

# Generated at 2022-06-24 04:57:33.846113
# Unit test for method mute of class Register
def test_Register_mute():
    import pytest
    from sty import fg

    fg.mute()
    assert fg.is_muted == True

    fg.red = fg.red
    assert fg.red == ""

    fg.unmute()
    assert fg.is_muted == False

    fg.red = fg.red
    assert fg.red != ""

    # Test if mute and unmute works on a custom register.
    fg_256 = Register()
    fg_256.set_renderfunc(RenderType.EIGHT_BIT, lambda x: chr(x))
    fg_256.red = Style(RenderType.EIGHT_BIT(196))
    fg_256.mute()
    assert fg_256.is_muted == True

# Generated at 2022-06-24 04:57:44.002225
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test for method __call__ of class Register
    """
    # Make empty register and set eightbit and rgb call to dummy functions
    r = Register()
    r.set_eightbit_call(lambda x: x)
    r.set_rgb_call(lambda r, g, b: (r, g, b))

    # Set dummy style to an attribute of the register
    dummy_style = Style(value='\x1b[0m')
    r.dummy_style = dummy_style

    # Assert that the dummy style is returned on call with a matching string.
    assert r('dummy_style') == dummy_style
    # Assert that the dummy style is returned on call with a matching int.
    assert r(0) == '0'
    # Assert that the dummy style is returned on call with a matching tuple

# Generated at 2022-06-24 04:57:48.246095
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from sty import fg

    class SetEightbitCall(NamedTuple):
        rendertype: Type[RenderType]
        eightbit_call: Callable

    def render_eightbit(self, x: int) -> str:
        return f'\x1b[38;5;{x % 256}m'

    rules: List[SetEightbitCall] = [
        SetEightbitCall(
            rendertype=RenderType, eightbit_call=lambda x: f'\x1b[38;5;{x % 256}m'
        ),
        SetEightbitCall(rendertype=RenderType, eightbit_call=render_eightbit),
    ]

    for rule in rules:
        fg_register = fg.copy()
        fg_register.set_eightbit_call(rule.rendertype)
       

# Generated at 2022-06-24 04:57:54.657314
# Unit test for constructor of class Style
def test_Style():

    class CustomRenderType(RenderType):
        attr = "CustomRenderType"
        code = 38

    def custom_renderfunc(*args: int) -> str:
        return "\x1b[{};{};{}m".format(*args)

    custom_register = Register()
    custom_register.set_renderfunc(CustomRenderType, custom_renderfunc)

    custom_style = Style(CustomRenderType(1, 2, 3))
    assert isinstance(custom_style, Style)
    assert isinstance(custom_style, str)
    assert str(custom_style) == "\x1b[38;1;2;3m"
    assert getattr(custom_style, "rules")[0].attr == "CustomRenderType"
    assert getattr(custom_style, "rules")[0].code == 38
    assert custom

# Generated at 2022-06-24 04:57:57.165042
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 2, 3))
    assert isinstance(style, Style)



# Generated at 2022-06-24 04:58:04.095055
# Unit test for method __new__ of class Style
def test_Style___new__():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    r1 = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(r1, Style)

    r2 = Style(r1, RgbBg(10, 20, 30), Sgr(1))
    assert isinstance(r2, Style)

    assert str(r2) == "\x1b[38;2;1;5;10m\x1b[1m\x1b[48;2;10;20;30m\x1b[1m"


# Generated at 2022-06-24 04:58:14.049627
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()

    assert r.rgb_call(0, 0, 0) == (0, 0, 0)

    r.set_rgb_call(RgbFg)

    assert r.rgb_call(0, 0, 0) == "38;2;0;0;0m"

    r.set_rgb_call(RgbBg)

    assert r.rgb_call(0, 0, 0) == "48;2;0;0;0m"

    r.set_rgb_call(RgbFg)

    assert r.rgb_call(0, 0, 0) == "38;2;0;0;0m"


# Generated at 2022-06-24 04:58:23.363731
# Unit test for method unmute of class Register
def test_Register_unmute():
    from . import fg, bg, ef, rs

    fg = fg.copy()
    bg = bg.copy()
    ef = ef.copy()
    rs = rs.copy()

    fg.mute()
    bg.mute()
    ef.mute()
    rs.mute()

    fg.unmute()
    bg.unmute()
    ef.unmute()
    rs.unmute()

    assert fg.is_muted == False
    assert bg.is_muted == False
    assert ef.is_muted == False
    assert rs.is_muted == False



# Generated at 2022-06-24 04:58:31.288577
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    The Style-class overrides method __new__ from class str. This method simply
    returns a string with an ANSI formatting sequence.
    """
    from sty import fg

    assert isinstance(fg.red, Style)
    assert isinstance(fg.red, str)
    assert fg.red == "\x1b[38;2;255;0;0m"
    assert len(fg.red) == 10


# Generated at 2022-06-24 04:58:40.934922
# Unit test for method mute of class Register
def test_Register_mute():

    from .ansireset import AnsiReset
    from .render import Render
    from .sgr import Sgr

    r = Register()
    r.renderfuncs.update(
        {Sgr: Render().get_func(Sgr), AnsiReset: Render().get_func(AnsiReset)}
    )

    r.mute()

    assert str(r.red) == ""
    assert repr(r.red) == '"\x1b[38;2;255;0;0m"'

    r.unmute()
    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert repr(r.red) == '"\x1b[38;2;255;0;0m"'



# Generated at 2022-06-24 04:58:51.030175
# Unit test for method mute of class Register
def test_Register_mute():

    class Mock(RenderType):

        def __init__(self, name, args):
            self.name = name
            self.args = args

        def render(self, *args):
            return f"{self.name}{self.args}"

    class MockRegister(Register):
        pass

    reg = MockRegister()

    reg.test = Style(Mock("TEST", "TEST"), value="")

    reg.mute()

    assert reg.test == ""

    reg.unmute()

    assert reg.test == "TESTTEST"

    ###############################################################################

    def render(arg1, arg2, arg3):
        return f"RENDER{arg1}{arg2}{arg3}"

    reg.set_renderfunc(Mock, render)


# Generated at 2022-06-24 04:58:59.496787
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: f"{x}")
    r.bold = "bold"
    r.faint = "faint"

    assert str(r.bold) == "bold"
    assert str(r.faint) == "faint"

    r.mute()

    assert str(r.bold) == ""
    assert str(r.faint) == ""

    r.unmute()

    assert str(r.bold) == "bold"
    assert str(r.faint) == "faint"

# Generated at 2022-06-24 04:59:07.226805
# Unit test for method mute of class Register
def test_Register_mute():
    
    # Create a new register object
    register = Register()
    
    # Setting renderfunctions
    register.set_renderfunc(str, lambda *x: "f")
    
    # Defining different styles
    register.style_1 = Style(str())
    register.style_2 = Style(str())
    register.style_3 = Style(str())
    
    # Mute the register object
    register.mute()
    
    # Unit test 1:
    assert str(register.style_1) == ""
    # Unit test 2:
    assert str(register.style_2) == ""
    # Unit test 3:
    assert str(register.style_3) == ""
    
    # Unmute the register object
    register.unmute()
    
    # Unit test 4:

# Generated at 2022-06-24 04:59:17.160604
# Unit test for method copy of class Register
def test_Register_copy():
    class R1(Register): pass
    class R2(Register): pass
    class R3(Register): pass

    r1 = R1()
    r1.red = Style(Sgr(1))
    r2 = R2()
    r2.red = Style(Sgr(2))
    r3 = R3()
    r3.red = Style(Sgr(3))

    r1_copy = r1.copy()
    r2_copy = r2.copy()
    r3_copy = r3.copy()

    assert len(r1_copy.renderfuncs) == 0
    assert len(r2_copy.renderfuncs) == 0
    assert len(r3_copy.renderfuncs) == 0

    assert len(r1.renderfuncs) == 0

# Generated at 2022-06-24 04:59:18.434118
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    r = Register()

    r.set_renderfunc(RenderType, lambda x: "")



# Generated at 2022-06-24 04:59:20.192016
# Unit test for constructor of class Style
def test_Style():

    Style()
    Style("Foo")
    Style("Foo", "Bar")
    Style("Foo", "Bar", "Baz")



# Generated at 2022-06-24 04:59:25.983488
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Setup
    RenderTypeArray = NamedTuple("RenderTypeArray", [("rendertype", Type[RenderType]), ("arg_count", int)])
    render_type_array = [RenderTypeArray(rendertype=RgbFg, arg_count=3),
                         RenderTypeArray(rendertype=RgbBg, arg_count=3),
                         RenderTypeArray(rendertype=RgbFg, arg_count=4),
                         RenderTypeArray(rendertype=RgbBg, arg_count=4)]

    # One test for each rendertype that has 3 or 4 arguments.
    for render_type in render_type_array:

        # Create a new register object and define the default rgb-call.
        r = Register()
        r.set_rgb_call(rendertype=RgbFg)

        # Assert
       