

# Generated at 2022-06-24 04:49:30.035326
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty.ansitowin32 import AnsiToWin32

    fg = Register()
    fg.set_renderfunc(RenderType.SgrFg, AnsiToWin32.sgr_fg)
    fg.set_renderfunc(RenderType.RgbFg, AnsiToWin32.rgb_fg)

    fg.red = Style(RenderType.SgrFg(31))

    d = fg.as_dict()
    assert d['red'] == '\x1b[31m'



# Generated at 2022-06-24 04:49:31.160979
# Unit test for constructor of class Register
def test_Register():
    """Test the constructor of Register class."""
    reg = Register()



# Generated at 2022-06-24 04:49:39.491901
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import EightBit, RgbFg, Sgr

    from .render.ansi import eightbit, sgr

    from .shortcuts import fg

    # Create a new register object from class Register
    r = Register()

    # Add render-functions for given rendertypes to register object.
    r.set_renderfunc(EightBit, eightbit)
    r.set_renderfunc(RgbFg, lambda r, g, b: "")
    r.set_renderfunc(Sgr, sgr)

    # Add an attribute to register
    setattr(r, "yellow", Style(EightBit(10), Sgr(1)))

    # Call the register object with the attribute name. This
    # should return "\x1b[33m\x1b[1m".

# Generated at 2022-06-24 04:49:48.251017
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .csi import Sgr, Eightbit
    from .custom_rendertype import CustomRenderType
    register = Register()
    register.set_renderfunc(Eightbit, lambda x: f"{x}")
    register.set_renderfunc(CustomRenderType, lambda x: f"{x}")
    register.set_renderfunc(Sgr, lambda x, *args: f"{x}")
    register.set_eightbit_call(Eightbit)
    register.set_eightbit_call(CustomRenderType)
    register.set_eightbit_call(Sgr)



# Generated at 2022-06-24 04:49:54.875669
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import RenderType, fg, ef
    red = fg.red
    test = ef.test
    test.clear = fg.clear
    rendertype = ef(123)
    renderfunc = lambda *args, **kwargs: "abc"
    test.set_renderfunc(rendertype, renderfunc)
    test.set_rgb_call(rendertype)

    d = test.as_dict()
    res = {"red": str(red), "test": str(test), "clear": str(test.clear)}
    assert d == res, "The result should be: {}. But is: {}".format(res, d)


# Generated at 2022-06-24 04:49:58.347606
# Unit test for method __new__ of class Style
def test_Style___new__():
    style: Style = Style("ASD")
    assert isinstance(style, Style)
    assert style == "ASD"
    assert style.rules == ()



# Generated at 2022-06-24 04:50:04.585429
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class TestRenderType(RenderType):

        renderfunc = lambda x, y, z: "foo"

    r = Register()

    r.renderfuncs.update({TestRenderType: TestRenderType.renderfunc})

    r.set_renderfunc(TestRenderType, TestRenderType.renderfunc)

    # Set renderfunc for RGB calls to TestRenderType
    r.set_rgb_call(TestRenderType)

    assert r(1, 2, 3) == "foo"


# Generated at 2022-06-24 04:50:10.479179
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.test_color = Style("test_color")

    r2 = r1.copy()

    assert r1.test_color == r2.test_color
    assert r1.test_color == "test_color"

# Generated at 2022-06-24 04:50:16.038820
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    r.set_rgb_call(RgbFg)
    rgb_call = r.rgb_call

    assert r.rgb_call(255, 255, 255) == "\x1b[38;2;255;255;255m"
    assert r.rgb_call(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert rgb_call(42, 42, 42) == "\x1b[38;2;42;42;42m"
    assert rgb_call(42, 42, 42) == "\x1b[38;2;42;42;42m"


# Generated at 2022-06-24 04:50:25.388605
# Unit test for method __call__ of class Register
def test_Register___call__():

    # TODO: We may want to move these three classes to a separate test module.

    # Define a class that is used to test method __call__ of class Register
    class MockRegister(Register):
        def __init__(self):
            super().__init__()
            self.renderfuncs.update({str: lambda x: x})
            self.set_eightbit_call(str)
            self.set_rgb_call(str)

    # Create instance of MockRegister
    r = MockRegister()
    styles = ["red", "green", "blue"]

    # Create attributes with name of all styles
    for s in styles:
        setattr(r, s, Style(s))

    # Test attributes
    assert r.red == "red"
    assert r.green == "green"
    assert r.blue == "blue"

# Generated at 2022-06-24 04:50:36.753239
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertypes import Sgr
    from  .renderfuncs import make_func_sgr

    fg = Register()
    fg.set_renderfunc(Sgr, make_func_sgr)

    fg.black = Style(Sgr(30))
    fg.bold_black = Style(Sgr(30), Sgr(1))
    fg.red = Style(Sgr(31))

    assert fg.black == "\x1b[30m"
    assert fg.bold_black == "\x1b[30;1m"
    assert fg.red == "\x1b[31m"
    assert str(fg.black) == "\x1b[30m"

    fg.mute()

    assert fg.black == ""
    assert fg.bold_black == ""
   

# Generated at 2022-06-24 04:50:42.162953
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Make a deepcopy of a register-object.
    """
    class NewRegister(Register):
        pass

    register = NewRegister()
    register.red = Style(RgbFg(255, 0, 0), Sgr(1))
    register.bold_red = Style(RgbFg(255, 0, 0), Sgr(1), Sgr(2))

    namedtuple = register.as_namedtuple()

    assert namedtuple.red == register.red
    assert namedtuple.bold_red == register.bold_red

# Generated at 2022-06-24 04:50:48.092947
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr
    from .sty import fg as _fg

    fg = Register()

    default = "This is a string"
    rule = Sgr(1)
    fg.black = Style(rule, default)

    nt = fg.as_namedtuple()

    assert nt.black == default



# Generated at 2022-06-24 04:50:57.891567
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestRenderType(RenderType):
        pass

    class TestRenderType2(RenderType):
        pass

    def renderfunc(rendertype, *args, **kwargs):
        return f"Renderfunc1 called for {rendertype}".format(rendertype, *args, **kwargs)

    def renderfunc2(rendertype, *args, **kwargs):
        return f"Renderfunc2 called for {rendertype}".format(rendertype, *args, **kwargs)

    register = Register()
    register.set_renderfunc(TestRenderType, renderfunc)

    expected = "Renderfunc1 called for "
    assert renderfunc(TestRenderType()) == expected
    assert renderfunc(TestRenderType, 1, 2, 3) == expected

    register.a = Style(TestRenderType(1, 2, 3))

# Generated at 2022-06-24 04:51:04.980692
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    r1 = Register()
    r1.set_renderfunc(RgbBg, lambda x, y, z: "a")
    r1.set_renderfunc(Sgr, lambda x: "b")

    r1.test_style1 = Style(Sgr(1))
    r1.test_style2 = Style(Sgr(1), RgbBg(1, 2, 3))

    assert r1.test_style1 == "b"
    assert r1.test_style2 == "bab"



# Generated at 2022-06-24 04:51:07.657155
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .styles import Aix

    def _render_aix(color_code: int) -> str:
        return Aix(color_code)

    register = Register()
    register.set_eightbit_call(Aix)

    assert register(100) == ""
    assert register(100) == ""

    register.set_renderfunc(Aix, _render_aix)

    assert register(100) == "\x1b(0\x1b[38;5;100m"



# Generated at 2022-06-24 04:51:15.861135
# Unit test for constructor of class Style
def test_Style():
    r1 = Style(rgb.red, sgr.bold)
    r2 = Style(rgb.green, sgr.underlined, sgr.italic)
    r3 = Style(rgb.red, sgr.bold, r2)
    assert isinstance(r1, Style)
    assert isinstance(r2, Style)
    assert isinstance(r3, Style)
    assert r1.rules == (rgb.red, sgr.bold)
    assert r3.rules == (rgb.red, sgr.bold, rgb.green, sgr.underlined, sgr.italic)
    assert str(r1) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-24 04:51:25.825624
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This test is for the __setattr__ method of the Register class. It tests that the
    correct values are assigned at the class-level when an attribute gets added to a
    register.
    """

    from .rules import Fg, Bg, Ef, Rs
    from .rules.rendertypes import Sgr, RgbFg, RgbBg, RgbEf, RgbRs

    class TestRegister(Register):
        pass

    r = TestRegister()
    renderfuncs: renderfuncs = {
        Sgr: lambda *x: "|".join(str(i) for i in x),
        RgbFg: lambda *x: "|".join(str(i) for i in x),
    }

    r.set_renderfunc(Sgr, renderfuncs[Sgr])
    r.set_

# Generated at 2022-06-24 04:51:29.219296
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1,2,3)), Style)
    assert isinstance(Style(RgbFg(1,2,3)), str)
    assert str(Style(RgbFg(1,2,3))) == '\x1b[38;2;1;2;3m'


# Generated at 2022-06-24 04:51:34.902205
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.red = Style(Sgr(1))
    register.green = Style(Sgr(2))

    d = register.as_dict()
    assert d == {"red": "\x1b[1m", "green": "\x1b[2m"}



# Generated at 2022-06-24 04:51:39.678006
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.red = Style("red")
    r.blue = Style("blue")
    assert(r.red.rules == ("red",))
    assert(r.blue.rules == ("blue",))


# Generated at 2022-06-24 04:51:41.899465
# Unit test for method unmute of class Register
def test_Register_unmute():
    register = Register()
    assert register.is_muted == False

    register.mute()
    assert register.is_muted == True

    register.unmute()
    assert register.is_muted == False

# Generated at 2022-06-24 04:51:48.601044
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, RgbBg, Sgr

    custom_fg = Register()
    custom_fg.rgb_call = lambda r, g, b: f"<rgb({r}, {g}, {b})>"
    custom_fg.eightbit_call = lambda i: f"<{i}>"

    custom_fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    custom_fg.blue = Style(RgbFg(0, 0, 255))

    assert custom_fg.red == "<rgb(255, 0, 0)>"
    assert custom_fg.blue == "<rgb(0, 0, 255)>"

    custom_fg.mute()
    assert custom_fg.red == ""
    assert custom_fg.blue == ""

    custom

# Generated at 2022-06-24 04:51:59.644570
# Unit test for method unmute of class Register
def test_Register_unmute():
    register = Register()
    register.set_renderfunc(RenderType.Sgr, lambda x: f"\x1b[{x}m")
    register.fg_red = Style(RenderType.Sgr(1), RenderType.Sgr(31))
    register.mute()
    assert hasattr(register, "fg_red")
    assert register.fg_red == ""
    register.unmute()
    assert register.fg_red == "\x1b[1m\x1b[31m"
    # Any render functions added to the register instance after mute
    # should be accessible.
    register.set_renderfunc(RenderType.Sgr, lambda x: f"\x1b[{x+1}m")
    register.fg_green = Style(RenderType.Sgr(32))
    assert register.fg

# Generated at 2022-06-24 04:52:10.576491
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    r = Register()
    r.set_eightbit_call(RgbFg)

    class RgbFg:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    RgbFg.__name__ = "RgbFg"

    # without a renderfunc, no ANSI-sequence is returned:
    assert r(42) == ""

    def func(r, g, b, *args, ansi_sequence="\x1b[38;2;{};{};{}m", **kwargs):
        return ansi_sequence.format(r, g, b)

    # with a renderfunc, the ANSI-sequence is returned:
    r.set_renderfunc(RgbFg, func)
    assert r(42)

# Generated at 2022-06-24 04:52:17.241583
# Unit test for constructor of class Style
def test_Style():
    style1 = Style(RgbFg(25, 45, 67, "bright"), Sgr(1))
    style2 = Style(RgbFg(25, 45, 67, "bright"), Sgr(1), value="\x1b[38;2;25;45;67;5m\x1b[1m")
    assert str(style1) == "\x1b[38;2;25;45;67;5m\x1b[1m"

    assert isinstance(style2, Style)
    assert isinstance(style2, str)

    assert style1 == style2
    assert style1 is not style2


# Generated at 2022-06-24 04:52:23.295184
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class A(RenderType):
        pass

    r = Register()
    r.set_renderfunc(A, lambda x: "a{}".format(x))
    r.set_eightbit_call(A)
    assert r(1) == "a1"


# Unit tests for method set_rgb_call of class Register

# Generated at 2022-06-24 04:52:27.836939
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Create the registers
    fg = Register()
    bold = RenderType("bold")
    bold.set_renderfunc(lambda: f"\x1b[{bold.args[0]}m")
    fg.set_renderfunc(bold, bold.renderfunc)
    fg.set_eightbit_call(bold)

    # Check if fg.bold(42) returns \x1b[1m\x1b[38;2;42m
    assert fg.bold(42) == "\x1b[1m\x1b[38;2;42m"



# Generated at 2022-06-24 04:52:31.477608
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .common import Sgr

    r = Register()
    r.b = Style(Sgr(1), value="\x1b[1m")
    r.set_renderfunc(Sgr, lambda x: "\x1b[{}m".format(x))
    r.b = Style(Sgr(2))

    assert r.b == "\x1b[2m"



# Generated at 2022-06-24 04:52:33.903720
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """ Test for method as_dict of class Register"""
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    d = r.as_dict()
    assert "red" in d.keys()
    assert d["red"] == '\x1b[38;2;255;0;0m'


# Generated at 2022-06-24 04:52:44.452493
# Unit test for method copy of class Register
def test_Register_copy():

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            r = lambda x, y, z: f"R:{x},G:{y},B:{z}"
            t = lambda x, y, z: f"T:{x},G:{y},B:{z}"
            self.renderfuncs.update({rendertype.RGBFG: r, rendertype.RGBBG: t})
            self.rgb_call = r
            self.set_renderfunc(rendertype.RGBBG, t)
            self.my_attr = 42

    sty_reg = TestRegister()
    sty_reg2 = sty_reg.copy()

    sty_reg.set_rgb_call(rendertype.RGBBG)

    assert sty_reg.is_muted == sty_reg2.is_muted


# Generated at 2022-06-24 04:52:54.174986
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr

    r = Register()

    r.reset = Style("\x1b[0m", "Reset")
    r.bold = Style("\x1b[1m", "Bold")
    r.italic = Style("\x1b[3m", "Italic")
    r.underline = Style("\x1b[4m", "Underline")

    assert not r.is_muted

    r.mute()

    assert r.is_muted

    assert r.reset == ""
    assert r.bold == ""
    assert r.italic == ""
    assert r.underline == ""

    r.unmute()

    assert not r.is_muted

    assert r.reset == "\x1b[0m"

# Generated at 2022-06-24 04:53:02.665018
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Eightbit, RgbFg

    r = Register()
    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)

    r.one = Style(Eightbit(100), RgbFg(100, 101, 102))
    r.two = Style(RgbFg(100, 101, 102), Eightbit(100))

    assert r(100) == "\x1b[38;5;100m"
    assert r(42) == "\x1b[38;5;42m"
    assert r(100, 101, 102) == "\x1b[38;2;100;101;102m"
    assert r(100, 101, 102) == "\x1b[38;2;100;101;102m"

# Generated at 2022-06-24 04:53:11.768117
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbBg

    register = Register()

    register.test1 = Style(RgbBg(255, 255, 255), value="\x1b[48;2;255;255;255m")
    register.test2 = Style(RgbBg(0, 0, 0), value="\x1b[48;2;0;0;0m")

    assert register.as_dict() == {
        "test1": "\x1b[48;2;255;255;255m",
        "test2": "\x1b[48;2;0;0;0m",
    }


# Generated at 2022-06-24 04:53:20.068348
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    The purpose of this test is to check if the set_renderfunc method works as
    expected.
    """

    # Create a new register object
    r = Register()

    # Create dummy renderfuncs.
    def f1(rendertype):
        def f2(value):
            return rendertype + ": " + str(value)

        r.set_renderfunc(rendertype, f2)

    f1("foo")
    f1("bar")

    # Create a style with the dummy rendertypes foo and bar.
    s = Style(foo(1), bar(2))
    assert str(s) == "foo: 1bar: 2"

# Generated at 2022-06-24 04:53:26.957028
# Unit test for constructor of class Style
def test_Style():
    # style = Style(fg=[255, 255, 255])
    # assert style == Style(fg=[255, 255, 255])
    assert Style(fg=[255, 255, 255]) == Style(fg=[255, 255, 255])
    assert Style(fg=[255, 255, 255]) != Style(fg=[255, 255, 255], bg=[255, 255, 255])

# Generated at 2022-06-24 04:53:37.383583
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    C = Register()

    def _test_register_as_string(C: Register):
        assert isinstance(C.orange, str)
        assert isinstance(C.orange, Style)

        assert isinstance(C.red, str)
        assert isinstance(C.red, Style)

    def _test_register_as_nested_strings(C: Register):
        assert isinstance(C.orange_bold, str)
        assert isinstance(C.orange_bold, Style)

        assert isinstance(C.red_bold, str)
        assert isinstance(C.red_bold, Style)

    # Test call without any renderfuncs.
    C.orange = Style(1)
    _test_register_as_string(C)

    C.red = Style(2)

# Generated at 2022-06-24 04:53:40.458275
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False
    assert r.renderfuncs == {}

# Generated at 2022-06-24 04:53:51.562239
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .style import fg, fg_rgb

    r = fg.red
    rfg = RgbFg(255, 0, 0)
    rs = Sgr(1)

    style_red = Style(rfg, rs)

    assert fg.red == "[38;2;255;0;0m[1m"
    assert style_red == "[38;2;255;0;0m[1m"
    assert fg_rgb("red") == (255, 0, 0)
    assert fg("red") == "[38;2;255;0;0m[1m"
    assert fg.red == "[38;2;255;0;0m[1m"


# Generated at 2022-06-24 04:54:00.621103
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRegister(Register):
        pass

    tr = TestRegister()
    tr.set_eightbit_call(RenderType)
    tr.set_rgb_call(RenderType)
    tr.set_renderfunc(RenderType, lambda x: "Test")

    tr.mute()

    assert tr.is_muted == True
    assert str(tr.red) == ""
    assert tr(33) == ""
    assert tr(10, 20, 30) == ""

    tr.unmute()

    assert tr.is_muted == False
    assert str(tr.red) == "Test"
    assert tr(33) == "Test"
    assert tr(10, 20, 30) == "Test"

# Generated at 2022-06-24 04:54:10.883363
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.red = Style("\x1b[1m\x1b[31m")
    r.green = Style("\x1b[1m\x1b[32m")
    r.blue = Style("\x1b[1m\x1b[34m")
    mt = r.as_namedtuple()
    assert mt.red == "\x1b[1m\x1b[31m"
    assert mt.green == "\x1b[1m\x1b[32m"
    assert mt.blue == "\x1b[1m\x1b[34m"

# Generated at 2022-06-24 04:54:15.785308
# Unit test for constructor of class Register
def test_Register():
    r1 = lambda **kwargs: "test"
    r2 = lambda **kwargs: "test2"
    renderfuncs = {RenderType: r1, RenderType: r2}
    reg = Register()
    reg.set_eightbit_call(RenderType)
    reg.set_rgb_call(RenderType)
    reg.set_renderfunc(RenderType, r1)
    reg.set_renderfunc(RenderType, r2)

test_Register()


# Generated at 2022-06-24 04:54:22.710862
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r1, r2 = Register(), Register()

    class A(RenderType):
        pass

    class B(RenderType):
        pass

    f1, f2 = lambda *args: f"A {args}", lambda *args: f"B {args}"
    r1.set_renderfunc(A, f1)
    r2.set_renderfunc(B, f2)

    r1.set_rgb_call(A)
    r2.set_rgb_call(B)

    r1(20, 10, 200)
    r2(20, 10, 200)
    assert r1.eightbit_call == f1
    assert r2.eightbit_call == f2

# Generated at 2022-06-24 04:54:33.862193
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the __new__ method of class Style.
    """
    from .sgr import Bg, Fg, Sgr
    from .rgb import RgbBg, RgbFg

    # Init
    rules1 = (RgbBg(1, 5, 10), Sgr(1))
    rules2 = (RgbFg(1, 5, 10), Sgr(1))
    style = Style(*rules1)
    expected = Style(*rules1, value="\x1b[48;2;1;5;10m\x1b[1m")
    style2 = Style(*rules2, value="\x1b[38;2;1;5;10m\x1b[1m")

    # Expected
    assert isinstance(style, Style)

# Generated at 2022-06-24 04:54:44.162562
# Unit test for constructor of class Register
def test_Register():
    from .sgr import Sgr
    from .rgb import RgbFg

    # Create renderfuncs
    def f1(code: int) -> str:
        return f"\x1b[{code}m"

    def f2(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def f3(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    # Create register
    reg = Register()

    # Add renderfuncs to register
    reg.set_renderfunc(Sgr, f1)
    reg.set_renderfunc(RgbFg, f2)


# Generated at 2022-06-24 04:54:48.583344
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_renderfunc(int, lambda x: "8bit-value")
    r.set_eightbit_call(int)

    assert r(42) == "8bit-value"

# Generated at 2022-06-24 04:54:57.704895
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .foreground import Foreground
    from .eightbitsgr import EightbitSgr
    from .rgb import Rgb

    fg = Foreground()
    fg.set_eightbit_call(EightbitSgr)
    fg.set_rgb_call(Rgb)

    assert fg(42) == "\x1b[38:5:42m"
    assert fg(42, 1) == "\x1b[38:5:42;1m"
    assert fg(128, 10) == "\x1b[38:5:128m"
    assert fg(256) == ""
    assert fg(0, 0, 0) == "\x1b[38:2:0:0:0m"

# Generated at 2022-06-24 04:55:01.543563
# Unit test for constructor of class Style
def test_Style():

    style = Style("", "")

    assert isinstance(style, str)
    assert isinstance(style, Style)

    assert style == ""

# Generated at 2022-06-24 04:55:11.333620
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestType(RenderType):
        pass

    class TestRegister(Register):
        pass

    # Add Renderfunctions
    test_reg = TestRegister()
    test_reg.set_renderfunc(TestType, lambda val: f"<{val}>")

    # Test 8bit call
    assert test_reg(42) == "<42>"

    # Test rgb call
    assert test_reg(2, 3, 4) == "<2 3 4>"

    # Test named style
    test_reg.style_example = Style(TestType(42))
    assert test_reg("style_example") == "<42>"


# Generated at 2022-06-24 04:55:15.135952
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(10, 20, 30))

    R = TestRegister()

    nt = R.as_namedtuple()
    assert nt.red == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-24 04:55:17.522649
# Unit test for constructor of class Style
def test_Style():

    s = Style()
    assert isinstance(s, Style)

    s = Style(1)
    assert isinstance(s, Style)

    s = Style(1, 2, 3)
    assert isinstance(s, Style)



# Generated at 2022-06-24 04:55:22.363689
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    def _render_test(a: int, b: int) -> str:
        return f"{a} {b} "

    RenderTypeTest = NamedTuple("RenderTypeTest", [("a", int), ("b", int)])
    f1 = Register()
    f1.set_renderfunc(RenderTypeTest, _render_test)
    f1.rtt = Style(RenderTypeTest(1, 2), RenderTypeTest(3, 4))
    f1.rtt2 = Style(RenderTypeTest(5, 6), RenderTypeTest(7, 8))
    assert f1.rtt == "1 2 3 4 "
    assert f1.rtt2 == "5 6 7 8 "

# Generated at 2022-06-24 04:55:26.868252
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg, Sgr

    reg = Register()

    def rgb_fg(r, g, b):
        return f"REG{RgbFg(r, g, b)}"

    reg.set_renderfunc(RgbFg, rgb_fg)

    reg.set_rgb_call(RgbFg)

    assert reg(10, 42, 255) == "REG\x1b[38;2;10;42;255m"
    assert str(reg.white) == "REG\x1b[38;2;10;42;255m"


# Generated at 2022-06-24 04:55:36.253954
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbEf(RenderType):
        """
        This is a custom rendertype.
        """

        def __init__(self, *args):
            super().__init__(*args)

        def render(self, r: int, g: int, b: int) -> str:
            return f"{r}, {g}, {b}"

    class RgbBg(RenderType):
        """
        This is a custom rendertype.
        """

        def __init__(self, *args):
            super().__init__(*args)

        def render(self, r: int, g: int, b: int) -> str:
            return f"{r} {g} {b}"

    class RgbFg(RenderType):
        """
        This is a custom rendertype.
        """


# Generated at 2022-06-24 04:55:39.204459
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.red = Style(Bg(1))

    assert register.as_dict() == {'red': '\x1b[48;5;1m'}



# Generated at 2022-06-24 04:55:49.662636
# Unit test for method mute of class Register
def test_Register_mute():
    from sty.ansi import Fg, Bg, Ef, Rs, fg, bg, ef, rs

    fg.red = Style(Fg(1))
    bg.red = Style(Bg(1))
    ef.red = Style(Ef(1))
    rs.red = Style(Rs(1))

    assert str(fg.red) == "\x1b[38;5;1m"
    assert str(bg.red) == "\x1b[48;5;1m"
    assert str(ef.red) == "\x1b[3;1m"
    assert str(rs.red) == "\x1b[0;1m"

    assert fg.red != ""
    assert bg.red != ""
    assert ef.red != ""
    assert rs.red

# Generated at 2022-06-24 04:56:01.341134
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import RenderType, Styler, Fg, Bg, Ef, Rs

    sty = Styler()

    sty.fg.set_rgb_call(RenderType.RgbFg)

    assert sty.fg("red") == "\x1b[38;2;255;0;0m"
    assert sty.fg("red", RenderType.RgbFg) == "\x1b[38;2;255;0;0m"
    assert sty.fg("red", RenderType.TrueColorFg) == "\x1b[38;2;255;0;0m"

    sty.bg.set_rgb_call(RenderType.RgbBg)

    assert sty.bg("blue") == "\x1b[48;2;0;0;255m"

# Generated at 2022-06-24 04:56:03.174909
# Unit test for constructor of class Style
def test_Style():
    Style(*(1, 2,), value="")
    Style(1, 2, value="")

# Generated at 2022-06-24 04:56:12.702586
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class MyReg(Register):
        def __init__(self):
            super().__init__()
            self.set_eightbit_call(RgbFg)
            self.set_rgb_call(RgbFg)
            self.red = Style(RgbFg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(RgbFg(0, 0, 255))

    myreg = MyReg()
    myreg_nt = myreg.as_namedtuple()

    assert myreg.red == myreg_nt.red
    assert myreg.green == myreg_nt.green
    assert myreg.blue == myreg_nt.blue


# Generated at 2022-06-24 04:56:19.719615
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Given
    r = Register()
    r.red = Style(Sgr(1), RgbFg(255, 0, 0))
    r.green = Style(Sgr(2), RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    # When
    nt = r.as_namedtuple()

    # Then
    assert nt.red == str(r.red)
    assert nt.green == str(r.green)
    assert nt.blue == str(r.blue)

# Generated at 2022-06-24 04:56:26.458494
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, RgbBg, Sgr

    class MyRegister(Register):
        def __init__(self):
            super().__init__()

            # Add render functions
            self.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
            self.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
            self.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

            # Define rules
            self.orange = Style(RgbFg(100, 100, 0), Sgr(1))
            self.red = Style

# Generated at 2022-06-24 04:56:33.510083
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Initialize a Register
    r: Register = Register()

    # Set two rules and a renderfunc
    r.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    r.red = Style(RenderType(31))
    r.bold = Style(RenderType(1))

    assert str(r.red) == "\x1b[31m"
    assert str(r.bold) == "\x1b[1m"

    assert r("red") == "\x1b[31m"
    assert r("bold") == "\x1b[1m"


# Generated at 2022-06-24 04:56:41.810842
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Foo(Register):
        pass

    f = Foo()
    f.blue = Style(value="\x1b[34m")
    f.blue_bg = Style(value="\x1b[44m")
    f.foo = Style(value="\x1b[42m")
    f.bar = Style(value="\x1b[43m")

    # Test Eightbit-call
    assert f(42) == ""

    f.set_eightbit_call(type(Fg(0)))

    assert f(42) == "\x1b[42m"

    f.mute()
    assert f(42) == ""

    f.unmute()
    assert f(42) == "\x1b[42m"

    f.mute()
    assert f(42) == ""

    #

# Generated at 2022-06-24 04:56:47.081326
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Sgr, RgbFg

    fg = Register()
    fg.red = Style(Sgr(1))

    assert fg(1) == ""
    assert fg(255) == ""
    assert fg(255, 255, 255) == ""
    assert fg("red") == "\x1b[1m"
    assert fg("red", "red") == "\x1b[1m"

# Generated at 2022-06-24 04:56:53.143376
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    register = Register()

    register.set_renderfunc(RenderType.EIGHTBIT, lambda x: "eightbit")
    register.set_renderfunc(RenderType.RGB, lambda r, g, b: "rgb")

    register.set_eightbit_call(RenderType.EIGHTBIT)
    assert register(102) == "eightbit"

    register.eightbit_call = lambda x: "new_eightbit"
    assert register(102) == "new_eightbit"


# Generated at 2022-06-24 04:56:58.339112
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Rgb(RenderType):
        pass

    class Rgb2(RenderType):
        pass

    r1 = Register()
    r1.renderfuncs[Rgb] = lambda x: "RGB({})".format(x)
    r1.renderfuncs[Rgb2] = lambda x: "RGB2({})".format(x)
    r1.set_eightbit_call(Rgb)
    assert r1(42) == "RGB(42)"
    r1.set_eightbit_call(Rgb2)
    assert r1(42) == "RGB2(42)"

# Generated at 2022-06-24 04:57:03.782963
# Unit test for method copy of class Register
def test_Register_copy():
    """
    The method copy of class Register should return an equal and independent object from the original object.
    """
    from .rendertypes import Sgr, RgbFg, RgbBg

    # Create Register and style.
    register = Register()
    register.renderfuncs.update(Sgr.renderfuncs)
    register.renderfuncs.update(RgbFg.renderfuncs)
    register.renderfuncs.update(RgbBg.renderfuncs)
    register.yellow = Style(Sgr(33))
    register.dark_yellow = Style(Sgr(33), Sgr(2))
    register.dark_red = Style(RgbFg(10, 0, 0), Sgr(2))
    # Copy Register
    register_copy = register.copy()
    # Change original register
    register.renderfun

# Generated at 2022-06-24 04:57:08.426733
# Unit test for constructor of class Register
def test_Register():

    class X(RenderType):
        def render(self):
            return "Hi"

    f1 = lambda *args: "F1"
    f2 = lambda *args: "F2"

    r1 = Register()
    r1.set_renderfunc(X, f1)

    r2 = Register()
    r2.set_renderfunc(X, f2)

    r1.R1 = Style(X())
    r1.R2 = Style(X())

    r2.R1 = Style(X())
    r2.R2 = Style(X())

    assert r1.R1 == "F1"
    assert r1.R2 == "F1"
    assert r2.R1 == "F2"
    assert r2.R2 == "F2"


# Generated at 2022-06-24 04:57:13.448441
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if copied register-objects are not equal.
    """
    from .fg import fg

    copy1 = fg.copy()
    copy2 = fg.copy()

    def changed_renderfunc(x: str) -> str:
        return x

    fg.set_renderfunc(None, changed_renderfunc)

    assert fg == copy1
    assert copy1 != copy2

# Generated at 2022-06-24 04:57:20.723746
# Unit test for method __call__ of class Register
def test_Register___call__():
    import pytest

    from .rendertypes import Sgr, RgbFg, RgbBg

    # Test Eightbit-call
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.set_eightbit_call(RgbFg)
    assert fg(255, 0, 0) == fg.red
    assert fg.red == "\x1b[38;2;255;0;0m"

    # Test rgb-call
    bg = Register()
    bg.green = Style(RgbBg(0, 255, 0))
    bg.set_rgb_call(RgbBg)
    assert bg(0, 255, 0) == bg.green

# Generated at 2022-06-24 04:57:30.965847
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RenderType1(RenderType):
        def __init__(self, val: int):
            self.args = (val,)

    class RenderType2(RenderType):
        def __init__(self, val: int):
            self.args = (val,)

    f1 = lambda val: f"{val}F1"
    f2 = lambda val: f"{val}F2"

    reg = Register()
    reg.set_renderfunc(RenderType1, f1)
    reg.set_renderfunc(RenderType2, f2)

    assert reg.renderfuncs[RenderType1] == f1
    assert reg.renderfuncs[RenderType2] == f2

    # Mutate the register-object with the new renderfuncs.

# Generated at 2022-06-24 04:57:34.083980
# Unit test for method unmute of class Register
def test_Register_unmute():
    import sty

    fg = Register()
    fg.red = Style(sty.sgr.foreground(sty.rgb.red))
    fg.mute()

    assert fg.red == ""

    fg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-24 04:57:43.991918
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define some render types
    RenderA = NamedTuple("RenderA", (("m", int),))
    RenderB = NamedTuple("RenderB", (("m", str),))

    # Define some render functions
    def func_a(m: int) -> str:
        return f"<a {m}>"

    def func_b(m: str) -> str:
        return f"<b {m}>"

    # Create register object
    r = Register()

    # Define some styles
    r.s1 = Style(RenderA(1))
    r.s2 = Style(RenderA(2))
    r.s3 = Style(Style(RenderB("x"), RenderA(3)), RenderB("y"))

    # Test that s1 is rendered correctly

# Generated at 2022-06-24 04:57:45.104405
# Unit test for constructor of class Register
def test_Register():
    """
    Test for Register.
    """
    assert Register is not None

# Generated at 2022-06-24 04:57:48.982800
# Unit test for method copy of class Register
def test_Register_copy():
    f1 = Register()
    f1.bla = Style(RgbFg(1, 2, 3))
    f2 = f1.copy()
    assert f2.bla == f1.bla


# Generated at 2022-06-24 04:57:56.598892
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test for method copy of class Register
    """
    fg = Register()
    fg.blue = Style(Sgr(34))
    assert fg.blue == "\033[38;2;0;0;255m"
    fg.mute()
    assert fg.blue == ""

    fg_copy = fg.copy()
    assert fg_copy.blue == ""
    fg_copy.unmute()
    assert fg_copy.blue == "\033[38;2;0;0;255m"

# Generated at 2022-06-24 04:58:02.656613
# Unit test for method copy of class Register
def test_Register_copy():
    from .style import init_style
    from .render import RenderType, ANSIRender

    sty = init_style()
    sty.register(RenderType, ANSIRender())
    sty.register(RenderType, ANSIRender())
    sty.fg[RgbFg(10, 10, 10)]
    sty.set_eightbit_call(RgbFg)
    sty.set_rgb_call(RgbFg)
    sty.mute()
    sty.unmute()

    sty2 = sty.copy()

    assert sty is not sty2

    assert sty.fg is not sty2.fg
    assert sty.bg is not sty2.bg
    assert sty.ef is not sty2.ef
    assert sty.rs is not sty2.rs


# Generated at 2022-06-24 04:58:07.902025
# Unit test for method __new__ of class Style
def test_Style___new__():
    r = Register()
    r.set_renderfunc(RenderType.Sgr, lambda *args: "::sgr")
    r.set_renderfunc(RenderType.RgbFg, lambda *args: "::rgb_fg")
    fg = r.copy()
    fg.red = Style(
        RenderType.Sgr(1),
        Style(
            RenderType.RgbFg(1, 2, 3),
            RenderType.Sgr(2, 30),
            value="::rgb_fg",
        ),
        RenderType.Sgr(3),
    )
    assert str(fg.red) == "::sgr::rgb_fg::sgr"

# Generated at 2022-06-24 04:58:13.545315
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sgr import Sgr

    register = Register()
    register.test_name = Style(Sgr(1))
    register.test_name_2 = Style(Sgr(2))

    assert register.as_namedtuple() == register.as_namedtuple()

# Generated at 2022-06-24 04:58:22.008415
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test method set_rgb_call of class Register.
    """
    from .sgr import Sgr

    class MyRegister(Register):

        foo = Style(Sgr(1))

    my_reg = MyRegister()

    assert str(my_reg.foo) == ""

    my_reg.set_rgb_call(Sgr)

    assert str(my_reg.foo) == "\x1b[1m"


if __name__ == "__main__":
    import pytest
    pytest.main(["-v", __file__])

# Generated at 2022-06-24 04:58:26.317967
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # TODO: Test that setattr throws error if value is not of type Style.
    # TODO: Test that setattr works with mute is False (i.e. that assignements are
    #       performed).
    # TODO: Test that setattr works with mute is True (i.e. that only assignements are
    #       performed).
    assert True is True  # Avoids failed test in test coverage report.

# Generated at 2022-06-24 04:58:33.212280
# Unit test for constructor of class Style
def test_Style():
    r1 = Style(RgbFg(100, 100, 100))
    assert isinstance(r1, Style)
    r2 = Style(Sgr(1), r1)

    assert isinstance(r2, Style)
    assert str(r2) == "\x1b[38;2;100;100;100m\x1b[1m"
    assert isinstance(r2.rules[0], Sgr)
    assert isinstance(r2.rules[1], RgbFg)


# Unit tests for constructor of class Register

# Generated at 2022-06-24 04:58:42.762960
# Unit test for constructor of class Style
def test_Style():

    r1: Style = Style(RgbFg(1, 2, 3), Sgr(1), RgbBg(3, 2, 1), Sgr(0), Sgr(22))

    assert isinstance(r1, Style)

    assert isinstance(r1, str)

    assert str(r1) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[48;2;3;2;1m\x1b[0m\x1b[22m"

    assert getattr(r1, 'rules') == (RgbFg(1, 2, 3), Sgr(1), RgbBg(3, 2, 1), Sgr(0), Sgr(22))


# Generated at 2022-06-24 04:58:46.237616
# Unit test for constructor of class Style
def test_Style():

    assert Style() == Style(value="")
    assert Style() is not Style(value="")

    assert Style(RgbFg(3, 2, 1)) == Style(RgbFg(3, 2, 1), value="\x1b[38;2;3;2;1m")
    assert Style(RgbFg(3, 2, 1)) is not Style(RgbFg(3, 2, 1), value="\x1b[38;2;3;2;1m")



# Generated at 2022-06-24 04:58:53.969602
# Unit test for constructor of class Style
def test_Style():
    s = Style(*[1, 2, 3], value="")
    assert isinstance(s, Style)
    assert s.rules == (1, 2, 3)
    assert str(s) == ""

    s = Style(*["orange"], value="\x1b[38;2;255;160;0m")
    assert isinstance(s, Style)
    assert s.rules == ("orange",)
    assert str(s) == "\x1b[38;2;255;160;0m"



# Generated at 2022-06-24 04:58:56.672316
# Unit test for constructor of class Register
def test_Register():
    my_register = Register()
    assert(isinstance(my_register, Register))


# Generated at 2022-06-24 04:59:02.034314
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .fg import fg
    from .bg import bg

    r = Register()
    r.r = Style("r")
    r.g = Style("g")
    r.b = Style("b")

    assert r.as_dict() == {"r": "r", "g": "g", "b": "b"}

# Generated at 2022-06-24 04:59:06.485237
# Unit test for method __call__ of class Register
def test_Register___call__():
    """ """
    fg = Register()

    red = Style(SgrFg(1), SgrBold())
    setattr(fg, "red", red)

    assert str(fg.red) == "\x1b[31m\x1b[1m"
    assert fg("red") == "\x1b[31m\x1b[1m"
    assert fg(1) == ""
    assert fg(1, 2, 3) == ""
    assert fg(1, 2) == ""

# Generated at 2022-06-24 04:59:12.484073
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register = Register()
    assert len(register.renderfuncs) == 0

    # Add a renderfunc
    rendertype = RenderType()
    renderfunc = lambda *_, **__: ""
    register.set_renderfunc(rendertype=rendertype, func=renderfunc)

    assert len(register.renderfuncs) == 1
    assert register.renderfuncs == {rendertype: renderfunc}



# Generated at 2022-06-24 04:59:15.760177
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    nt: NamedTuple = fg.blue.as_namedtuple()
    assert nt.blue == "\x1b[38;5;4m"

# Generated at 2022-06-24 04:59:27.067555
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Bg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"{r},{g},{b}")
    r.set_renderfunc(Sgr, lambda s: f"SGR-{s}")

    r.set_eightbit_call(RgbFg)

    assert r.eightbit_call(1, 2, 3) == "1,2,3"

    r.set_eightbit_call(Sgr)
    assert r.eightbit_call(42) == "SGR-42"

    r.red = Style(RgbFg(1,2,3), Sgr(1))
    assert r.red == r.eightbit_call(1,2,3)

