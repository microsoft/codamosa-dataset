

# Generated at 2022-06-24 04:49:30.638029
# Unit test for constructor of class Style
def test_Style():
    class Sgr(RenderType):
        fmt = "\x1b[{code}m"
    class Eightbit(RenderType):
        fmt = "\x1b[38;5;{code}m"

    fg = Register()
    fg.set_eightbit_call(Eightbit)
    fg.set_renderfunc(Sgr, lambda c: Sgr.fmt.format(code=c))

    fg.red = Style(Sgr(1), Eightbit(1))
    assert fg.red == "\x1b[1m\x1b[38;5;1m"


if __name__ == "__main__":
    test_Style()

# Generated at 2022-06-24 04:49:36.193673
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    sty = Register()
    sty.fivebit_rgb = Style(RgbFg(255, 255, 255))
    sty.eightbit_rgb = Style(RgbFg(255, 255, 255))

    sty.set_rgb_call(Rgb)
    assert sty(255, 255, 255) == sty.fivebit_rgb

    sty.set_rgb_call(Rgb8)
    assert sty(255, 255, 255) == sty.eightbit_rgb

    sty.set_rgb_call(Rgb8)
    sty.set_rgb_call(Rgb8)



# Generated at 2022-06-24 04:49:44.597951
# Unit test for method __new__ of class Style
def test_Style___new__():
    from sty.ansi import Fg, Bg, Ef, Rs
    from sty.mapping import Mapping

    def test_function():
        style_0 = Style(Fg.black, value="black")
        style_1 = Style(Fg.blue, Fg.orange, value="blue orange")
        style_2 = Style(Fg.blue, Fg.orange, Fg.red, value="blue orange red")
        style_3 = Style(Fg.blue, Fg.orange, Fg.red, Fg.yellow, value="blue orange red yellow")
        style_4 = Style(Fg.blue, Fg.orange, Fg.red, Fg.yellow, Fg.green, value="blue orange red yellow green")

# Generated at 2022-06-24 04:49:47.941581
# Unit test for method unmute of class Register
def test_Register_unmute():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.yellow = Style(RgbFg(255, 255, 0))



# Generated at 2022-06-24 04:49:55.513615
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Style()
    """
    # This test only works if there is no name clash between any of the register names and
    # the names of the headers, because this is not uniquely defined.

    def test_render(header: str, rules: Iterable[StylingRule]) -> None:
        rendered, rules = _render_rules(renderfuncs, rules)
        if rendered != expected_ansi:
            raise ValueError(f"Header '{header}' is rendered wrong.")


# Generated at 2022-06-24 04:50:05.439846
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0_1 = Style(value="\033[31m")
    style_0_2 = Style(value="\033[32m")
    style_1_1 = Style(style_0_1, style_0_2, value="")

    assert isinstance(style_0_1, str)
    assert isinstance(style_1_1, str)

    assert isinstance(style_0_1, Style)
    assert isinstance(style_1_1, Style)

    assert style_0_1 == "\033[31m"
    assert style_1_1 == ""

    assert style_0_1.rules == ()
    assert style_1_1.rules == (Style(value="\033[31m"), Style(value="\033[32m"))



# Generated at 2022-06-24 04:50:15.403762
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class DummyRenderType(RenderType):
        pass

    # Create dummy render-type
    dummy_rendertype = DummyRenderType(1)

    def renderfunc(x: int) -> str:
        return "rendered"

    # Create a Regsiter object
    register = Register()

    # Set the renderfunc for dummy render-type.
    # Use this to test set_rgb_call.
    register.set_renderfunc(dummy_rendertype, renderfunc)

    # Set render-type for RGB-Calls.
    #
    # This should not raise an error and return None.
    register.set_rgb_call(dummy_rendertype)

    # The result should be "rendered" and not "" (empty string)
    assert register(1, 2, 3) == "rendered"

# Generated at 2022-06-24 04:50:18.546088
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg

    reg = Register()
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"{r}, {g}, {b}")

    reg.red = Style(RgbFg(1, 0, 0))
    reg.set_rgb_call(RgbFg)

    assert reg(1, 0, 0) == "1, 0, 0"


# Generated at 2022-06-24 04:50:29.410004
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register.
    """
    r1 = Register()
    r2 = Register()
    r2.blue = Style(RgbFg(1,2,3), BgRed())
    r2.red = Style(BgBlue())
    r1.yellow = Style(BgWhite())
    setattr(r1, "blue", Style(BgRed()))
    setattr(r2, "black", Style(BgBlack()))
    r3 = r2.copy()
    assert r2.blue == r3.blue
    assert r2.red == r3.red
    assert r1.yellow != r3.yellow
    assert r1.yellow != r2.yellow
    assert r1.blue != r2.blue



# Generated at 2022-06-24 04:50:39.666602
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):

        def render(self, r: int, g: int, b: int) -> str:
            return f"\x1b[38;2;{r};{g};{b}m"

    class Sgr(RenderType):

        def render(self, n: int) -> str:
            return f"\x1b[{n}m"

    def renderfunc1(*args) -> str:
        return "\x1b[38;2;{};{};{}m".format(*args)

    def renderfunc2(*args) -> str:
        return "\x1b[{}m".format(*args)

    class TestRegister(Register):
        pass

    testregister = TestRegister()

    testregister.set_renderfunc(RgbFg, renderfunc1)
   

# Generated at 2022-06-24 04:50:51.085678
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbSetFg(RenderType):
        name = "RgbFg"
        args = ["red", "green", "blue"]

    def fg(r, g, b):
        return "\x1b[38;2;%d;%d;%dm" % (r, g, b)

    class RgbFg(RenderType):
        name = "RgbFg"
        args = ["red", "green", "blue"]

    def fg2(r, g, b):
        return "\x1b[38;2;%d;%d;%dm" % (r, g, b)

    def fb(brightness: int = None):
        if brightness is None:
            return "\x1b[38;5;{}m".format(brightness)
        else:
            return

# Generated at 2022-06-24 04:50:53.935663
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.foo = Style(value="foo")
    register.bar = Style(value="bar")

    assert register.as_dict() == {"foo": "foo", "bar": "bar"}

# Generated at 2022-06-24 04:51:00.356469
# Unit test for method unmute of class Register
def test_Register_unmute():
    # Given
    reg = Register()
    setattr(reg, "my_color", Style(Sgr(1), RgbFg(10, 20, 30)))
    reg.mute()

    # When
    reg.unmute()

    # Then
    assert str(reg.my_color) == "\x1b[38;2;10;20;30m\x1b[1m"
    assert isinstance(reg.my_color, str)



# Generated at 2022-06-24 04:51:05.682812
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    r1 = Register()
    r1.red = Style(r1.rgb(255, 0, 0))

    rend_func = lambda *args: "rendered"

    r1.set_renderfunc(r1.rgb, rend_func)

    assert r1.red[0] == "rendered"

# Generated at 2022-06-24 04:51:10.659494
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    class StyTest:

        fg = Register()

    sty = StyTest()
    sty.fg.set_rgb_call(RgbFg)



# Generated at 2022-06-24 04:51:18.657639
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, RgbBg, Sgr

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))

# Generated at 2022-06-24 04:51:25.045962
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class R(Register):
        x = Style(RgbFg(10, 20, 30))
        y = Style(RgbFg(10, 20, 30), Sgr(2))

    r = R()

    assert r.as_dict() == {"x": "\x1b[38;2;10;20;30m", "y": "\x1b[38;2;10;20;30m\x1b[2m"}

# Generated at 2022-06-24 04:51:34.522509
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import Sgr, RgbBg, RgbFg, SetFgBg

    class NewRenderType(RenderType):
        pass

    class TestRegister(Register):
        _black = Style(RgbFg(0, 0, 0))

        def __init__(self):
            super().__init__()
            self.set_renderfunc(NewRenderType, lambda *args: f"\x1b[{args[0]};{args[1]};{args[2]}m")

    r = TestRegister()
    r.set_rgb_call(NewRenderType)

    # Test if rgb-call was set to NewRenderType
    assert r.rgb_call == r.renderfuncs[NewRenderType]

    # Test if value of attribute was altered by call

# Generated at 2022-06-24 04:51:36.827111
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register = Register()
    register.set_eightbit_call(RenderType)
    assert register.eightbit_call(1) == ""

# Generated at 2022-06-24 04:51:48.196675
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty.sgr import Red

    st = Style(Red)
    assert isinstance(st, Style)
    assert isinstance(st, str)
    assert st == '\x1b[31m'

    st = Style(Red, 'bold')
    assert isinstance(st, Style)
    assert isinstance(st, str)
    assert st == '\x1b[31m\x1b[1mbold'

    st = Style(Red, value='bold')
    assert isinstance(st, Style)
    assert isinstance(st, str)
    assert st == '\x1b[31mbold'

    st = Style(Red, Red)
    assert isinstance(st, Style)
    assert isinstance(st, str)

# Generated at 2022-06-24 04:51:57.390276
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Setup test
    fg = Register()
    bg = Register()
    fg.set_renderfunc(RgbFg, lambda x: lambda r, g, b: f"{x}{r};{g};{b}")
    fg.set_rgb_call(RgbFg)
    fg.black = Style(RgbFg(0, 0, 0))


    # Test
    fg.set_eightbit_call(RgbFg)
    black_from_8bit = fg(0)

    # Assert
    assert black_from_8bit == "0;0;0"



# Generated at 2022-06-24 04:52:09.053535
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class DummyRenderType(RenderType):
        """
        Dummy render class to make unit tests for __setattr__.
        """
        pass

    class DummyRegister(Register):
        """
        Dummy register-class to make unit tests for __setattr__.
        """

        def __init__(self):
            super().__init__()
            self.renderfuncs = {DummyRenderType: lambda *args: "\x1b[0m"}

    # !!! Note: The dict comprehension is not available in python 3.5. !!!

# Generated at 2022-06-24 04:52:15.523412
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    nt = r.as_namedtuple()
    assert type(nt) == namedtuple("StyleRegister", "red green blue")
    assert isinstance(nt.red, str)
    assert isinstance(nt.green, str)
    assert isinstance(nt.blue, str)


# Generated at 2022-06-24 04:52:22.303232
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty.render.eightbit import EightbitFg, EightbitBg
    from sty.render.sgr import Reset, Bold
    from sty.render.rgb import RgbFg, RgbBg

    expected = "\x1b[38;5;144m\x1b[48;5;246m"

    style = Style(EightbitFg(144), EightbitBg(246))
    assert style == expected

    style = Style(Reset, Bold, EightbitFg(144), EightbitBg(246))
    assert style == expected

    style = Style(Reset, Bold, RgbFg(1, 2, 3), EightbitBg(246))

# Generated at 2022-06-24 04:52:29.968912
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from collections import namedtuple

    def test_fg():

        from sty import fg

        class FgRegister(namedtuple("FgRegister", fg.as_dict().keys())):
            """
            Class to test namedtuple converter method.
            """

        fg_r = FgRegister(*fg.as_dict().values())

        assert fg_r.black == fg.black

    def test_bg():

        from sty import bg

        class FgRegister(namedtuple("FgRegister", bg.as_dict().keys())):
            """
            Class to test namedtuple converter method.
            """

        bg_r = FgRegister(*bg.as_dict().values())

        assert bg_r.black == bg.black

    def test_ef():

        from sty import ef

# Generated at 2022-06-24 04:52:39.301790
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .register import fg

    nt = fg.as_namedtuple()

    assert isinstance(nt, NamedTuple)

    assert isinstance(nt, NamedTuple)
    assert isinstance(nt.black, str)
    assert isinstance(nt.red, str)
    assert isinstance(nt.green, str)
    assert isinstance(nt.yellow, str)
    assert isinstance(nt.blue, str)
    assert isinstance(nt.magenta, str)
    assert isinstance(nt.cyan, str)
    assert isinstance(nt.white, str)
    assert isinstance(nt.bright_black, str)
    assert isinstance(nt.bright_red, str)
    assert isinstance(nt.bright_green, str)
    assert isinstance(nt.bright_yellow, str)

# Generated at 2022-06-24 04:52:47.117615
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Eightbit, Sgr

    def render_sgr(int_value: int) -> str:
        return f"\x1b[38;5;{int_value}m"

    fg = Register()
    fg.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")
    fg.set_renderfunc(Sgr, lambda x, y: f"\x1b[{x};{y}m")

    fg.set_eightbit_call(Eightbit)

    fg.red = Style(RgbFg(1, 0, 0), Sgr(1))

    assert fg.red == "\x1b[38;2;1;0;0m\x1b[1m"

# Generated at 2022-06-24 04:52:57.144213
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg

    # Set two attributes for the register fg
    for i, color in enumerate(["red", "green"]):
        fg(color)
        setattr(fg, f"test{i}", fg)

    # Get the expected dict out of the fg object.
    d1 = fg.as_dict()

    # Check if d1 is a dict
    assert isinstance(d1, dict)

    # Check the expected length of d1.
    assert len(d1) == 2

    # Check if all expected keys are in d1
    for key in ["test0", "test1"]:
        assert key in d1.keys()

    # Check if all expected values are in d1

# Generated at 2022-06-24 04:53:08.571682
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # define test RenderType
    class RGBSgrFg(NamedTuple):
        r: int
        g: int
        b: int
        sgr: int

    # define test renderfunc
    renderfunc = lambda r, g, b, sgr: "".join(
        ["\x1b[38;2;", str(r), ";", str(g), ";", str(b), "m", "\x1b[", str(sgr), "m"]
    )

    # create test register
    reg = Register()

    # set renderfunc
    reg.set_renderfunc(RGBSgrFg, renderfunc)

    # set style attribute
    reg.blue = Style(RGBSgrFg(0, 0, 255, 1))

    # test if applying the style attribute worked

# Generated at 2022-06-24 04:53:16.733420
# Unit test for method copy of class Register
def test_Register_copy():

    """
    The function registers.copy() should create a new register object that
    has the same attributes and values as the original register object. In
    particular, the two register objects should be completely independent of
    each other.
    """

    # Create a test register
    reg = Register()
    reg.red = Style(1, 2)

    # Create a deep copy and make a change
    copy = reg.copy()
    copy.red = 3

    # The original register should not be changed.
    assert reg.red == Style(1, 2)



# Generated at 2022-06-24 04:53:23.236434
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Due to the way __setattr__ works, only writing the style to the object
    # once will be enough.

    # Create Mapping for Sgr
    rendering_funcs = {Sgr: lambda x: f"\\x1b[{x}m"}

    # Create register
    register = Register()
    register.set_renderfunc(Sgr, rendering_funcs[Sgr])

    # Set style
    register.style = Style(Sgr(1))

    assert str(register.style) == "\x1b[1m"

# Generated at 2022-06-24 04:53:27.378119
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    rs = Register()
    rs.set_renderfunc(RgbFg, str)

    class RgbTest(RenderType):
        args = (1, 2, 3)

    rs.test = Style(RgbTest)

    assert rs.test == "123"
    assert isinstance(rs.test, str)
    assert isinstance(rs.test, Style)


# Generated at 2022-06-24 04:53:33.487247
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Foreground, Background

    # Test 1
    class TestRegister1(Register):
        def __init__(self):
            super().__init__()
            self.black = Style(Foreground(8))

        @staticmethod
        def render(instance: Foreground) -> str:
            return f"\x1b[{instance.value_type};{instance.value}m"

    # Test 1
    tr1 = TestRegister1()
    tr1.set_renderfunc(Foreground, TestRegister1.render)
    assert str(tr1.black) == "\x1b[38;8m"
    assert str(tr1(8)) == "\x1b[38;8m"
    assert str(tr1("black")) == "\x1b[38;8m"
    # Test 2
   

# Generated at 2022-06-24 04:53:39.200417
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Sgr(RenderType):
        def __init__(self, *args: int):
            self.args = args

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    fg = Register()

    # Set renderfuncs.
    fg.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join([str(x) for x in args])}m")
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Set style attributes.
    fg.red = Style(Sgr(1))
    fg

# Generated at 2022-06-24 04:53:43.522637
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    r = Register()
    r.foo = Style("\x1b[31")
    r.bar = Style("\x1b[32")

    assert r.as_dict() == {"foo": "\x1b[31", "bar": "\x1b[32"}

# Generated at 2022-06-24 04:53:53.328496
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(NamedTuple):
        r: int
        g: int
        b: int

    class Sgr(NamedTuple):
        sgr: int

    class Fg(NamedTuple):
        color: int

    renderfuncs: Renderfuncs = {}
    renderfuncs[RgbFg] = lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"
    renderfuncs[Sgr] = lambda sgr: f"\x1b[{sgr}m"
    renderfuncs[Fg] = lambda color: f"\x1b[38;5;{color}m"

    reg = Register()
    reg.renderfuncs = renderfuncs

    reg.blue = Style(Fg(24))


# Generated at 2022-06-24 04:54:01.228685
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestType(RenderType):
        pass

    reg = Register()

    with pytest.raises(TypeError, match=".*rendertype.*"):
        reg.set_eightbit_call(RenderType)

    with pytest.raises(ValueError, match=".*rendertype.*"):
        reg.set_eightbit_call(TestType)

    def test_func(*args):
        pass

    reg.set_renderfunc(TestType, test_func)
    assert reg.eightbit_call == test_func
    reg.set_eightbit_call(TestType)
    assert reg.eightbit_call == test_func


# Unit tests for method set_rgb_call of class Register

# Generated at 2022-06-24 04:54:07.776516
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    testRegister = Register(fg=Style(RgbFg(1,8,9), Sgr(1,2)))
    testDict = testRegister.as_dict()
    assert isinstance(testDict, dict)
    assert isinstance(testDict['fg'], Style)


# Generated at 2022-06-24 04:54:15.929777
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MyRegister(Register):
        pass

    myreg = MyRegister()
    myreg.three = Style(RgbBg(10, 20, 30))

    assert myreg.three == '\x1b[48;2;10;20;30m'
    assert myreg(10, 20, 30) == '\x1b[48;2;10;20;30m'
    assert myreg(3) == '\x1b[48;2;10;20;30m'

    myreg.set_rgb_call(RgbFg)
    myreg.set_eightbit_call(EightbitFg)
    myreg.set_renderfunc(RgbBg, lambda r, g, b: f"{r}:{g}:{b}")


# Generated at 2022-06-24 04:54:18.462073
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)

# Generated at 2022-06-24 04:54:23.985024
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbBg, RgbFg
    from .register import Style

    sgr = Sgr(1, 2, 3)
    r1 = Style(sgr, value="")

    assert r1.rules == (sgr,)
    assert r1.value == ""

    rgb = RgbBg(220, 100, 50)
    r2 = Style(sgr, rgb, value="")

    assert r2.rules == (sgr, rgb)
    assert r2.value == ""

    rgb_fg = RgbFg(255, 255, 255)
    r3 = Style(rgb_fg, value="ABC")

    assert r3.rules == (rgb_fg,)
    assert r3.value == "ABC"


# Generated at 2022-06-24 04:54:28.019128
# Unit test for method copy of class Register
def test_Register_copy():

    # Create new register
    register = Register()

    # Add some render-types
    register.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")
    register.set_renderfunc(RenderType, lambda x: f"\x1b[{x}m")

    # Create new style-attribute called 'err'
    register.err = Style(RenderType(31))

    # Test copy
    register2= register.copy()
    register2.err = Style(RenderType(30))

    assert register.err == '\x1b[31m'
    assert register2.err == '\x1b[30m'



# Generated at 2022-06-24 04:54:35.657155
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """Test for method as_dict of class Register"""
    from sty import fg

# Generated at 2022-06-24 04:54:44.674916
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertypes import RenderType

    class RenderType1(RenderType):
        def render(self):
            return "RENDERTYPE1"

    class RenderType2(RenderType):
        def render(self):
            return "RENDERTYPE2"

    class RenderType3(RenderType):
        def render(self):
            return "RENDERTYPE3"

    class RenderType4(RenderType):
        def render(self):
            return "RENDERTYPE4"

    rendertype1 = RenderType1()
    rendertype2 = RenderType2()
    rendertype3 = RenderType3()
    rendertype4 = RenderType4()

    sty = Register()

    sty.set_renderfunc(RenderType1, lambda: "RENDERTYPE1")

# Generated at 2022-06-24 04:54:49.096692
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .sty import fg
    from .rendertype import Sgr

    fg.some = Style(Sgr(1))

    assert isinstance(fg.some, Style)


# Generated at 2022-06-24 04:54:53.447002
# Unit test for method __new__ of class Style
def test_Style___new__():

    style = Style(RgbFg(1, 5, 10), Sgr(1))
    assert style == "\x1b[38;2;1;5;10m\x1b[1m"

    style = Style(Sgr(1), RgbFg(1, 5, 10))
    assert style == "\x1b[1m\x1b[38;2;1;5;10m"

# Generated at 2022-06-24 04:54:56.236811
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg

    r = Register()
    r.green = Style(RgbFg(0, 160, 0))
    r.set_rgb_call(RgbFg)

    assert r(0, 160, 0) == r.green



# Generated at 2022-06-24 04:55:01.496796
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)
    assert isinstance(r.rgb_call, Callable)
    assert isinstance(r.eightbit_call, Callable)

# Generated at 2022-06-24 04:55:12.495816
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Call to Register.__call__ must return String
    assert isinstance(Register()(101), str)

    # Calling Register.__call__ must return empty string
    assert isinstance(Register().__call__(101), str)

    # Calling Register.__call__ with an 8Bit value
    assert isinstance(Register().__call__(101), str)

    # Calling Register.__call__ with a rgb-value (tuple)
    assert isinstance(Register().__call__(101, 101, 101), str)

    # Calling Register.__call__ with a rgb-value (list)
    assert isinstance(Register().__call__([101, 101, 101]), str)

    # Calling Register.__call__ without arguments
    assert isinstance(Register().__call__(), str)

    # Calling Register.__call__ with a style

# Generated at 2022-06-24 04:55:19.483731
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg, bg, rs, RenderType, ef, Style

    eb = RenderType("0")
    rb = RenderType("1")
    gb = RenderType("2")
    yb = RenderType("3")
    bb = RenderType("4")
    mb = RenderType("5")
    cb = RenderType("6")
    wb = RenderType("7")

    eb = Style(ef.bold, eb)
    eb = Style(ef.underline, eb)
    rb = Style(ef.bold, rb)
    rb = Style(ef.underline, rb)
    gb = Style(ef.bold, gb)
    gb = Style(ef.underline, gb)
    yb = Style(ef.bold, yb)
    yb

# Generated at 2022-06-24 04:55:25.365250
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from . import fg, bg
    from .colors import black, white

    r = fg.copy()
    d = r.as_dict()
    nt = r.as_namedtuple()
    assert all(getattr(nt, n, None) == d[n] for n in d)

# Generated at 2022-06-24 04:55:33.198474
# Unit test for method copy of class Register
def test_Register_copy():

    from .register import fg, bg

    fg_c = fg.copy()
    assert fg_c is not fg

    a = Style(fg.green)
    b = Style(fg.green)
    assert a is not b
    assert a == b

    a_c = Style(fg_c.green)
    b_c = Style(fg_c.green)
    assert a_c is not b_c
    assert a_c == b_c

    assert fg.green is not fg_c.green

    assert fg.green == fg_c.green

    bg.set_renderfunc(RenderType, lambda *_: "\x1b[1m")
    bg_c = bg.copy()
    assert bg_c.renderfuncs[RenderType] == bg

# Generated at 2022-06-24 04:55:43.463268
# Unit test for method mute of class Register
def test_Register_mute():
    import unicodedata
    from .rendertypes import RgbFg, Sgr
    from .foreground import fg

    # Multiply each r,g,b by 12 to get a nice range of color codes
    # between 0 and 12.
    colored_boxes = {
        "red": RgbFg(0, 0, 0),
        "orange": RgbFg(1, 0, 0),
        "yellow": RgbFg(2, 2, 0),
        "green": RgbFg(0, 2, 0),
        "blue": RgbFg(0, 0, 2),
        "indigo": RgbFg(0, 0, 3),
        "violet": RgbFg(1, 0, 2),
        "white": RgbFg(2, 2, 2),
    }



# Generated at 2022-06-24 04:55:49.865477
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class TestRenderType(RenderType):
        def __init__(self) -> None:
            self.value = "test"

    def test_renderfunc(rendertype: RenderType) -> str:
        return rendertype.value

    register = Register()
    register.set_renderfunc(TestRenderType, test_renderfunc)
    assert isinstance(register, Register)
    assert register.renderfuncs[TestRenderType] == test_renderfunc



# Generated at 2022-06-24 04:55:53.495619
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style("a", "b", "c")
    assert style == "abc"
    assert style.rules == ("a", "b", "c")



# Generated at 2022-06-24 04:55:59.319039
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .render import RgbBg, RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r,g,b: r+g+b)
    r.set_rgb_call(RgbBg)

    assert r(1, 2, 3) == 6
    assert r(0, 0, 0, 0, 0) == 0



# Generated at 2022-06-24 04:56:04.305977
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.red = Style(RgbFg(255, 0, 0))
    r2 = r1.copy()

    assert r1 != r2
    assert hasattr(r2, "red")
    assert r2.red == Style(RgbFg(255, 0, 0))
    assert r2.red == r1.red


# Generated at 2022-06-24 04:56:11.342540
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class CustomRegister(Register):
        def __init__(self):
            self.renderfuncs = {}
            self.is_muted = False
            self.eightbit_call = lambda x: x
            self.rgb_call = lambda r, g, b: (r, g, b)
            self.test1 = Style("test1")
            self.test2 = Style("test2")

    cr = CustomRegister()

    assert cr.as_dict() == {"test1": "test1", "test2": "test2"}



# Generated at 2022-06-24 04:56:21.102530
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_renderfunc(RenderType.SGR, lambda *args, **kwargs: "\x1b[" + ";".join([str(i) for i in args]) + "m")
    r1.set_renderfunc(RenderType.RGB_FG, lambda r, g, b, **kwargs: "\x1b[38;2;" + ";".join([str(i) for i in (r, g, b)]) +"m")
    r1.set_eightbit_call(RenderType.SGR)
    r1.set_rgb_call(RenderType.RGB_FG)

# Generated at 2022-06-24 04:56:27.674210
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestRenderType(RenderType):
        ansi = "\x1b[0m"
        param = "test_param"

        def render(self, value):
            return self.ansi + str(value)

    # Create register object.
    rg = Register()

    # Create test style.
    TestStyle = Style(TestRenderType("test_value"))

    # Define Test-render_function.
    def test_renderfunc(_, value):
        return "test_renderfunc" + str(value)

    # Set renderfunc.
    rg.set_renderfunc(TestRenderType, test_renderfunc)

    # Assert if new renderfunc is used.
    assert test_renderfunc(*TestStyle.rules[0].args) == str(TestStyle)

    # Assert if old renderfuncs are still present.
   

# Generated at 2022-06-24 04:56:33.140661
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test Register.unmute()
    """
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.test = Style(value="test")

    my_reg = MyRegister()
    my_reg.mute()

    assert my_reg.test == ""

    my_reg.unmute()

    assert my_reg.test == "test"


# Generated at 2022-06-24 04:56:40.105383
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class A(Register):
        def __init__(self):

            super().__init__()
            self.set_eightbit_call(RgbFg)
            self.set_rgb_call(RgbFg)

            self.black = Style(RgbFg(0, 0, 0))

    a = A()

    assert a.as_namedtuple().black == a.black

    assert a.as_namedtuple().black == "\x1b[38;2;0;0;0m"

# Generated at 2022-06-24 04:56:47.366206
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        render_fg_rgb = lambda r, g, b: "\x1b[38;2;{r};{g};{b}m".format(r=r, g=g, b=b)

    # Create register object
    r = Register()

    # Set rendertype RgbFg as default rendertype
    r.set_renderfunc(RgbFg, RgbFg.render_fg_rgb)

    # Set new color attribute 'red'
    r.red = Style(RgbFg(150, 50, 50))

    # Set RgbFg to be the rendertype for rgb-calls.
    r.set_rgb_call(RgbFg)

    # Make a rgb-call
    ansi = r(150, 50, 50)

   

# Generated at 2022-06-24 04:56:56.826187
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test method set_rgb_call of class Register.
    """

    class CustomRgbRenderType(RenderType):
        """
        Custom rendertype for tests.
        """

        def __init__(self, red: int, green: int, blue: int):
            self.args = (red, green, blue)

    CustomNamedTuple = namedtuple("CustomNamedTuple", ["red", "green", "blue"])

    def custom_rgb_render_func(
        red: int, green: int, blue: int, reverse: bool = False
    ) -> Tuple[str, NamedTuple]:

        red = int(round(red / 255.0 * 5.0))
        green = int(round(green / 255.0 * 5.0))

# Generated at 2022-06-24 04:57:07.755723
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # pylint: disable=no-self-use, unused-argument

    # Create the 8bit and 24bit functions.
    def f1(code):
        return "\x1b[38;5;" + str(code) + "m"

    def f2(r, g, b):
        return "\x1b[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m"

    # Create two new rendertypes.
    Style1 = RenderType("Style1", "style1")
    Style2 = RenderType("Style2", "style2")

    # Create the register obj.
    register = Register()

    # There are no renderfuncs yet.
    assert len(register.renderfuncs) == 0

    # This should work.
    register.set_renderfunc

# Generated at 2022-06-24 04:57:16.499583
# Unit test for method unmute of class Register
def test_Register_unmute():

    class MockedRendertype(RenderType):
        args = ()

    def renderfunc(self, *args):
        return "Any string"

    # Create mocked renderfunc and register
    r1 = Register()
    r1.set_renderfunc(MockedRendertype, renderfunc)

    # Create test style
    s1 = Style(MockedRendertype())
    s2 = Style(MockedRendertype())
    s3 = Style(MockedRendertype())

    # Add styles to register
    r1.s1 = s1  # mutate once
    r1.s2 = s2
    r1.s3 = s3

    # Mutate twice
    r1.mute()
    r1.mute()

    # Unmute once
    r1.unmute()

    # Check if styles contains empty string


# Generated at 2022-06-24 04:57:22.791029
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbBg

    r = Register()
    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.red = Style(Sgr(1), RgbBg(10, 20, 30))
    r.blue = Style(RgbBg(40, 60, 80))
    r.green = Style("green")

    # Mute the register.
    r.mute()

    assert r.red == ""
    assert r.blue == ""
    assert r.green == "green"

    # Unmute the register.
    r.unmute

# Generated at 2022-06-24 04:57:32.999271
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class SomeRenderType(RenderType):
        """A fake Rendertype"""
        args: List[int]

        def __init__(self, *args: int) -> None:
            self.args = args

        def __str__(self):
            return "".join([str(a) for a in self.args])

    some_rendertype = SomeRenderType

    def some_renderfunc(*args: int) -> str:
        return ":".join([str(a) for a in args])

    r = Register()
    r.set_renderfunc(some_rendertype, some_renderfunc)
    r.style = Style(some_rendertype(1, 2), some_rendertype(3, 4))

    assert isinstance(r.style, Style)

# Generated at 2022-06-24 04:57:37.620136
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Unit test for method as_dict of class Register.
    """
    reg: Register = Register()
    reg.test = Style(value="test")

    dic = reg.as_dict()

    assert dic == {"test": "test"}


# Generated at 2022-06-24 04:57:41.250157
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .sgr import Sgr
    r = Register()
    r.set_renderfunc(Sgr, lambda x: f"!!!{x}")
    r.set_eightbit_call(Sgr)
    assert r(31) == "!!!31"


# Generated at 2022-06-24 04:57:44.696734
# Unit test for constructor of class Style
def test_Style():
    s0 = Style('test')
    assert isinstance(s0, str)
    assert isinstance(s0, Style)
    assert s0 != 'test'
    assert s0 == 'test'
    assert eval(repr(s0)) == 'test'
    assert s0.rules == ()


# Generated at 2022-06-24 04:57:53.205487
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Sgr8bit(RenderType):

        _args_to_sgr_params: Tuple[Tuple[int, str]] = (
            (0, ""),
            (1, "1"),
            (2, "2"),
            (3, "3"),
            (4, "4"),
            (5, "5"),
            (7, "7"),
            (8, "8"),
            (9, "9"),
        )

        def __init__(self, *args):
            self.args = args

        def sgr_params(self):
            return self._args_to_sgr_params[self.args[0]]

    def sgr_fg8bit_func(val: int) -> str:
        return Sgr8bit(val).sgr_params()


# Generated at 2022-06-24 04:58:00.741765
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test Register.as_dict().
    """
    d: Dict[str, str] = {"red": "\x1b[31m", "white": "\x1b[37m", "yellow": "\x1b[33m"}
    test_reg = Register()

    test_reg.red = Style(value="\x1b[31m")
    test_reg.white = Style(value="\x1b[37m")
    test_reg.yellow = Style(value="\x1b[33m")

    assert d == test_reg.as_dict()



# Generated at 2022-06-24 04:58:11.935197
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class Rgb24Ef(RenderType):
        def __init__(self, red: int, green: int, blue: int):
            super().__init__(red, green, blue)

    class Rgb24Fg(RenderType):
        def __init__(self, red: int, green: int, blue: int):
            super().__init__(red, green, blue)

    f = lambda x, y, z: f"{x}.{y}.{z}"

    x = Register()
    x.set_renderfunc(Rgb24Ef, f)
    x.set_renderfunc(Rgb24Fg, f)
    x.set_rgb_call(Rgb24Ef)

    assert x(10, 20, 30) == "10.20.30"



# Generated at 2022-06-24 04:58:23.215674
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register
    """

    from .ansi import ansi_render, ansi_true_type_render, rgb_ansi_true_type_render

    class CustomRegister(Register):
        yellow = Style(RgbFg(r=255, g=255, b=0))

    r: CustomRegister = CustomRegister()

    r.set_rgb_call(ansi_true_type_render)

    assert r.yellow == "\x1b[38;2;255;255;0m"
    assert r.yellow == r.yellow

    s: CustomRegister = r.copy()
    s.set_rgb_call(ansi_render)
    s.set_eightbit_call(RgbFg)


# Generated at 2022-06-24 04:58:31.636140
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    def example_renderfunc(a, b, c):
        return "renderfunc_called"

    custom_register = Register()
    custom_register.set_eightbit_call(RgbFg)
    custom_register.set_renderfunc(RgbFg, example_renderfunc)

    assert custom_register(144) == ""
    custom_register.unmute()
    assert custom_register(144) == "renderfunc_called"


# Generated at 2022-06-24 04:58:41.634839
# Unit test for method __new__ of class Style
def test_Style___new__():

    class SgrFg(RenderType):
        pass

    class SgrBg(RenderType):
        pass

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    fg_red_style = Style(
        RgbFg(1, 0, 0),
        SgrFg(3, 2),
        RgbFg(2, 1, 3, 5),
        RgbFg(42, 10, 12),
        SgrBg(14, 2),
        SgrFg(2),
        RgbBg(0, 2, 3),
    )


# Generated at 2022-06-24 04:58:51.356044
# Unit test for constructor of class Style
def test_Style():
    # invoke all constructors
    Style(*[])
    Style(*[Sgr(4)])
    Style(*[Sgr(4), Sgr(2)])
    Style(*[Sgr(4), Sgr(2)], value="")
    Style(*[Sgr(4), Sgr(2)], value="\x1b[1m")
    Style(*[Sgr(4), Sgr(2)], value="\x1b[1m\x1b[2m")
    Style(*[Sgr(4), Sgr(2)], value="\x1b[1m\x1b[2m\x1b[7m")
    # test if constructor raises correct excpetions
    assert Style(*["sgr(4)"]) is None

# Generated at 2022-06-24 04:58:58.798280
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Test for basic color names

    def black(value: str, *args) -> str:
        return f"{value}{args[0]}{value}"

    registers: Register = Register()

    registers.set_renderfunc(RenderType[8], black)

    setattr(registers, "black", Style(RgbFg(0, 0, 0)))

    assert registers.black == black(black(black(black(black(black(black(black("", 0), 0), 0), 0), 0), 0), 0), 0)

# Generated at 2022-06-24 04:59:01.268572
# Unit test for constructor of class Register
def test_Register():
    assert isinstance(Register(), Register)

# Unit tests for Register.set_eightbit_call()

# Generated at 2022-06-24 04:59:07.809047
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # First we create a 'Color Register'
    class TestRegister(Register):

        red = Style(RgbFg(255, 0, 0))
        green = Style(RgbFg(0, 255, 0))
        blue = Style(RgbFg(0, 0, 255))
        orange = Style(RgbFg(255, 127, 0))

    # Now we create a TestRegister object
    t = TestRegister()

    # This is the expected value

# Generated at 2022-06-24 04:59:14.235050
# Unit test for method copy of class Register
def test_Register_copy():
    new_register = Register()
    new_register.test = Style(value="test")
    new_register.test2 = Style(value="test2")
    new_register.test3 = Style(value="test3")
    copied_register = new_register.copy()
    assert copied_register.test == new_register.test
    assert copied_register.test2 == new_register.test2
    assert copied_register.test3 == new_register.test3



# Generated at 2022-06-24 04:59:21.262223
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Checks if method set_renderfunc of class Register works.
    """

    from .style import Style
    from .rendertype import RgbFg, Sgr

    def render_sgr(n: int) -> str:
        return "\x1b[{}m".format(n)

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    register = Register()

    register.set_renderfunc(Sgr, render_sgr)
    register.set_renderfunc(RgbFg, render_rgb_fg)

    assert register.bold == Style(Sgr(1))