

# Generated at 2022-06-24 04:49:32.589602
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .anysyntax import fg
    from .rendertype import EightBitSetFg, EightBitSetBg, RGBFg, RGBBg, Sgr

    # Create a new Register instance with some test attributes.
    r = Register()
    r.test_sgr = Style(Sgr(1))
    r.test_rgb = Style(RGBFg(10, 20, 30))
    r.test_eightbit = Style(EightBitSetFg(144))

    # Define test render functions (ANSI-sequences).
    sgr_func = lambda *args: "\x1b[{0}m".format(args[0])
    rgb_func = lambda r, g, b: "\x1b[38;2;{0};{1};{2}m".format(r, g, b)
   

# Generated at 2022-06-24 04:49:42.447226
# Unit test for method unmute of class Register
def test_Register_unmute():
    class MockRenderType(RenderType):
        def __init__(self, x):
            super().__init__(x)
            self.x = x

        def __str__(self) -> str:
            return f"{self.x}\x1b[39m"

    reg = Register()
    reg.set_renderfunc(MockRenderType, lambda x: f"\x1b[{x}m")
    reg.red = Style(MockRenderType(100))
    reg.mute()
    assert reg.red == ""
    reg.unmute()
    assert reg.red == "\x1b[100m\x1b[39m"

# Generated at 2022-06-24 04:49:52.855845
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    def f1(x: int) -> str: return f"8bit: {x}\n"
    def f2(r: int, g: int, b: int) -> str: return f"rgb: {r}, {g}, {b}\n"

    r1 = Register()
    r1.set_eightbit_call(RgbFg)
    r1.set_rgb_call(RgbBg)

    r1.set_renderfunc(RgbFg, f1)
    r1.set_renderfunc(RgbBg, f2)

    assert r1(144) == "8bit: 144\n"

# Generated at 2022-06-24 04:50:04.026189
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Unit test for method mute of class Register.
    """

    # #### Setup: Create a new Register object and add some styles.
    r = Register()
    r.renderfuncs[RenderType] = str

    r.black = Style(RenderType(), RenderType())
    r.white = Style(RenderType(), RenderType(), RenderType())

    # #### Test: Mute register and check values.
    r.mute()
    assert r.is_muted is True
    assert isinstance(r.black, Style)
    assert isinstance(r.white, Style)
    assert str(r.black) == ""
    assert str(r.white) == ""

    # #### Test: Unmute register and check values.
    r.unmute()
    assert r.is_muted is False

# Generated at 2022-06-24 04:50:07.786172
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert len(r.renderfuncs) == 0



# Generated at 2022-06-24 04:50:13.287877
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class DummyRegister(Register):
        orange = Style(RgbFg(1,5,10), Sgr(1))
        blue = Style(Bold)

    r = DummyRegister()
    nt = r.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.orange == "\x1b[38;2;1;5;10m"
    assert nt.blue == "\x1b[1m"

# Generated at 2022-06-24 04:50:17.265540
# Unit test for method copy of class Register
def test_Register_copy():
    from sty import ef
    from sty.constants import BOLD

    # Create a custom register.
    r = Register()
    r.set_eightbit_call(ef.Sgr)
    setattr(r, "bold", Style(ef.Sgr(BOLD)))

    # Copy custom register
    r2 = r.copy()



# Generated at 2022-06-24 04:50:26.757760
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .render import get_rendertype_renderfunc_dict, SgrFg8bit, SgrFgRgb

    fg = Register()
    fg.renderfuncs = get_rendertype_renderfunc_dict()
    fg.set_eightbit_call(SgrFg8bit)
    fg.set_rgb_call(SgrFgRgb)
    fg.red = Style(fg.rgb_call(255, 0, 0))

    assert fg(0) == "\x1b[38;5;0m"
    assert fg(42) == "\x1b[38;5;42m"
    assert fg(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-24 04:50:29.731787
# Unit test for constructor of class Style
def test_Style():
    assert Style("test").rules == ("test",)
    assert Style("test", "test2").rules == ("test", "test2")
    assert Style("test", "test2", value="test3").rules == ("test", "test2")
    assert str(Style("test", "test2", value="test3")) == "test3"



# Generated at 2022-06-24 04:50:34.723688
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 5, 10), Sgr(1))
    assert str(style) == "\x1b[38;2;1;5;10m\x1b[1m"
    assert isinstance(style, Style)
    assert isinstance(style, str)

# Generated at 2022-06-24 04:50:40.245181
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr

    class MyRegister(Register):
        red = Style(RgbFg(255, 0, 0))
        blue = Style(RgbFg(0, 0, 255))
        blue_bold = Style(RgbFg(0, 0, 255), Sgr(1))

    fg = MyRegister()
    fg.mute()

    assert fg.red == ""
    assert fg.blue == ""
    assert fg.blue_bold == ""

# Generated at 2022-06-24 04:50:47.650662
# Unit test for method mute of class Register
def test_Register_mute():

    from .rules import RgbBg

    class FgRegister(Register):
        red = Style(RgbBg(10, 20, 30))

    fg = FgRegister()

    assert isinstance(fg.red, Style)
    assert str(fg.red) == '\x1b[48;2;10;20;30m'

    fg.mute()
    assert fg.is_muted
    assert str(fg.red) == ''


# Generated at 2022-06-24 04:50:57.159466
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class MyRegister(Register):
        ...
    my_register = MyRegister()
    my_register.red = Style(RgbFg(100,100,100), Bold)
    my_register.green = Style(RgbFg(100,200,100), Underline)
    my_register.blue = Style(RgbFg(100,200,200))
    my_register.set_eightbit_call(RgbFg)
    assert my_register.as_namedtuple() == (StyleRegister(red='\x1b[38;2;100;100;100m', green='\x1b[38;2;100;200;100m', blue='\x1b[38;2;100;200;200m'))

# Generated at 2022-06-24 04:51:05.224700
# Unit test for method mute of class Register
def test_Register_mute():
    from .render import Render
    from .rendertypes import Sgr, RgbFg

    ANSI: Render = Render()

    foo: Register = Register()
    foo.bar = Style(Sgr(1), RgbFg(10, 20, 30), Sgr(0), "bar", Sgr(1), "foobar")
    s: str = ANSI.render(foo.bar)

    assert s == "\x1b[1m\x1b[38;2;10;20;30mbar\x1b[0m\x1b[1mfoobar"

    foo.mute()
    s: str = ANSI.render(foo.bar)

    assert s == "barfoobar"


# Generated at 2022-06-24 04:51:16.620396
# Unit test for method mute of class Register
def test_Register_mute():

    from .render import DefaultRender
    from .rendertype import Sgr, RgbBg

    r = Register()
    r.set_renderfunc(Sgr, DefaultRender.render_Sgr)
    r.set_renderfunc(RgbBg, DefaultRender.render_RgbBg)
    r.example = Style(Sgr(1), RgbBg(200, 50, 50))
    r.example2 = Style(Sgr(2), RgbBg(10, 10, 10))

    assert str(r.example) == "\x1b[38;2;200;50;50m\x1b[1m"
    assert str(r.example2) == "\x1b[48;2;10;10;10m\x1b[2m"

    r.mute()


# Generated at 2022-06-24 04:51:19.701286
# Unit test for method __new__ of class Style
def test_Style___new__():
    t = Style("a", "b")
    assert isinstance(t, Style), "Style() should create Style-obj."
    assert isinstance(t, str), "Style() should create str-obj."
    assert t == "", "t.__str__() should be an empty string."
    assert t.rules == ("a", "b"), "t.rules should be a tuple of strings."

# Generated at 2022-06-24 04:51:30.749976
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Register-objects can be copied with the copy()-method.
    """
    expected = {
        "black": '\x1b[38;2;0;0;0m',
        "orange": '\x1b[38;2;1;5;10m\x1b[1m',
    }

    register_1 = Register()
    register_1.black = Style(RgbFg(0,0,0))
    register_1.orange = Style(RgbFg(1,5,10), Sgr(1))

    register_2 = register_1.copy()

    assert register_2.black == expected["black"]
    assert register_2.orange == expected["orange"]



# Generated at 2022-06-24 04:51:36.980650
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style()
            self.green = Style()
            self.blue = Style()
            self.muted = Style()

    reg = MyRegister()
    reg.mute()

    nt = reg.as_namedtuple()
    assert nt.red == ""
    assert nt.green == ""
    assert nt.blue == ""
    assert nt.muted == ""

# Generated at 2022-06-24 04:51:40.203337
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_eightbit_call(int)
    assert r.eightbit_call == int


# Generated at 2022-06-24 04:51:49.537486
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Setup:
    class Rgbfg(RenderType): pass
    class Sgr(RenderType): pass
    class Setbg(RenderType): pass

    renderfuncs = {
        Rgbfg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
        Sgr: lambda *args: f"\x1b[{';'.join([str(i) for i in args])}m",
        Setbg: lambda *args: f"\x1b[48;2;{';'.join([str(i) for i in args])}m",
    }

    fg = Register()
    fg.set_renderfunc(Rgbfg, renderfuncs[Rgbfg])

    # Test that dict is returned properly:
    fg.red

# Generated at 2022-06-24 04:51:55.270284
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()
    r.a = Style(RgbFg(1,2,3))
    r.b = Style(SgrBold())

    r2 = r.copy()

    assert r2.a == '\x1b[38;2;1;2;3m'
    assert r2.b == '\x1b[1m'

# Generated at 2022-06-24 04:52:04.087620
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test the __call__ function for the class Register.
    """
    from .eightbit import Eightbit
    from .rgb import RgbFg

    def render_eightbit_function(x: int) -> str:
        return f"eightbit {x}"

    def render_rgb_function(x: int, y: int, z: int) -> str:
        return f"rgb {x}, {y}, {z}"

    # Create test-register
    test_register = Register()

    # Set render functions for eightbit and rgb
    test_register.set_renderfunc(Eightbit, render_eightbit_function)
    test_register.set_renderfunc(RgbFg, render_rgb_function)

    # Set rgb-call and eightbit-call
    test_register.set_eightbit_

# Generated at 2022-06-24 04:52:10.459190
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MockRendertype:
        def __call__(self, args):
            return args

    register = Register()
    register.set_renderfunc(MockRendertype, lambda x: x)
    register.set_eightbit_call(MockRendertype)
    register.set_rgb_call(MockRendertype)

    assert register(8) == 8
    assert register(10, 20, 30) == (10, 20, 30)



# Generated at 2022-06-24 04:52:12.649797
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    register.foo = Style(value="bar")
    nt = register.as_namedtuple()
    assert nt.foo == "bar"

# Generated at 2022-06-24 04:52:18.057120
# Unit test for method unmute of class Register
def test_Register_unmute():

    fg = Register()
    fg.set_renderfunc(RenderType.EightbitFg, lambda x: f"\x1b[38;5;{x}m")
    fg.blue = Style(RenderType.EightbitFg(12), RenderType.Bold())
    fg.mute()
    assert fg.blue == ""
    fg.unmute()
    assert fg.blue == "\x1b[38;5;12m\x1b[1m"


# Generated at 2022-06-24 04:52:28.287559
# Unit test for constructor of class Register
def test_Register():
    # Create some sample objects to store in register
    class RgbFg(RenderType):
        cssname = "rgb-fg"
        args = ["r", "g", "b"]

        def render(self, r, g, b):
            return "\x1b[38;2;{};{};{}m".format(r, g, b)

    class RgbBg(RenderType):
        cssname = "rgb-bg"
        args = ["r", "g", "b"]

        def render(self, r, g, b):
            return "\x1b[48;2;{};{};{}m".format(r, g, b)

    class Sgr(RenderType):
        cssname = "sgr"
        args = ["sgr"]


# Generated at 2022-06-24 04:52:29.373930
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    pass


# Generated at 2022-06-24 04:52:33.621482
# Unit test for method __new__ of class Style
def test_Style___new__():

    class FG(Register):
        """
        Test class.
        """

    r = FG()

    r.blue = Style("x", "y")

    assert r.blue == "xy"

# Generated at 2022-06-24 04:52:41.395472
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create test-register for Eightbit-Call:

    one = RenderType()
    two = RenderType()
    three = RenderType()
    four = RenderType()
    five = RenderType()
    six = RenderType()
    seven = RenderType()
    eight = RenderType()
    nine = RenderType()
    ten = RenderType()

    test_register = Register()
    test_register.set_eightbit_call(one)
    test_register.set_rgb_call(two)
    test_register.set_renderfunc(five, lambda *args: "five")
    test_register.set_renderfunc(six, lambda *args: "six")
    test_register.set_renderfunc(seven, lambda *args: "seven")

# Generated at 2022-06-24 04:52:50.695732
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    def func1(*args):
        return "1234"

    def func2(*args):
        return "5678"

    class R1(RenderType):
        pass

    class R2(RenderType):
        pass

    reg = Register()
    reg.set_renderfunc(R1, func1)
    reg.set_renderfunc(R2, func2)

    assert reg.renderfuncs[R1] == func1
    assert reg.renderfuncs[R2] == func2
    assert reg.renderfuncs[R1] != reg.renderfuncs[R2]
    assert reg.renderfuncs[R1] != func2
    assert reg.renderfuncs[R2] != func1


# Generated at 2022-06-24 04:52:59.727154
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from sty import fg

    def func1(x1):
        return "|1|"

    def func2(x2):
        return "|2|"

    class Render1:
        @classmethod
        def args(cls, *args):
            return args

    class Render2:
        @classmethod
        def args(cls, *args):
            return args

    fg = fg.copy()
    fg.set_renderfunc(Render1, func1)
    fg.set_renderfunc(Render2, func2)

    fg.set_eightbit_call(Render1)

    assert fg(1) == "|1|"
    assert fg(2) == "|1|"

    fg.set_eightbit_call(Render2)


# Generated at 2022-06-24 04:53:05.455773
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import sys
    import pytest

    from .rendertype import Sgr, SgrFg, SgrBg

    rg: Register = Register()
    rg.set_renderfunc(SgrFg, lambda *args: f"SgrFg{args}")
    rg.set_renderfunc(SgrBg, lambda *args: f"SgrBg{args}")
    rg.black = Style(SgrBg(1), SgrFg(2))
    rg.set_rgb_call(SgrFg)

    # Test the rgb call
    assert rg(10, 0, 0) == "SgrFg(10, 0, 0)"

    # Test the attributes
    assert rg.black == "SgrBg1SgrFg2"

    # Test the 8bit call
    rg.set_

# Generated at 2022-06-24 04:53:10.881401
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    def test():
        r = Register()
        r.a = Style(RgbFg(1,2,3))
        r.b = Style(RgbFg(4,5,6))

        d = r.as_dict()

        assert d["a"] == "\x1b[38;2;1;2;3m"
        assert d["b"] == "\x1b[38;2;4;5;6m"

    test()

# Generated at 2022-06-24 04:53:15.650704
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.foo = Style(r, value="\x1b[1m")

    assert r(1) == ""
    assert r("foo") == "\x1b[1m"
    assert r(1, 2, 3) == ""



# Generated at 2022-06-24 04:53:23.047468
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg, bg, ef, rs

    muted_fg = fg.copy()
    muted_bg = bg.copy()
    muted_ef = ef.copy()
    muted_rs = rs.copy()

    muted_fg.mute()
    muted_bg.mute()
    muted_ef.mute()
    muted_rs.mute()

    assert muted_fg.red == ""
    assert muted_bg.orange_red_2 == ""
    assert muted_ef.blink == ""
    assert muted_rs.rs == ""



# Generated at 2022-06-24 04:53:26.207675
# Unit test for method copy of class Register
def test_Register_copy():
    a = Register()
    a.blue = Style(RgbFg(10, 20, 40))
    b = a.copy()
    assert id(a) != id(b)
    assert a.blue == b.blue



# Generated at 2022-06-24 04:53:32.612235
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()

    r.set_eightbit_call(RgbFg)
    assert r(1, "red") == "\x1b[38;2;1;0;0m"

    r.set_eightbit_call(RgbBg)
    assert r(1, "red") == "\x1b[48;2;1;0;0m"

    r.set_eightbit_call(EightbitFg)
    assert r(1, "red") == "\x1b[38;5;1m"

    r.set_eightbit_call(EightbitBg)
    assert r(1, "red") == "\x1b[48;5;1m"

    r.set_rgb_call(RgbFg)
    assert r(5,6,7, "red")

# Generated at 2022-06-24 04:53:42.283380
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class A(RenderType):
        pass

    class B(RenderType):
        pass

    def a(x: int) -> str:
        return f"[a{x}]"

    def b(x: int) -> str:
        return f"[b{x}]"

    class FakeRegister(Register):
        a = Style(A(42), value='[a42]')
        b = Style(B(42), value='[b42]')

    fake_register: FakeRegister = FakeRegister()
    fake_register.set_renderfunc(A, a)
    fake_register.set_renderfunc(B, b)

    fake_register.set_eightbit_call(A)
    assert fake_register(42) == "[a42]"

    fake_register.set_eightbit_call(B)
    assert fake_register

# Generated at 2022-06-24 04:53:51.563002
# Unit test for method __new__ of class Style
def test_Style___new__():
    r1 = RenderType(1)
    sr1 = Style(r1)
    sr1b = Style(r1, "123")
    sr2 = Style(sr1)
    sr2b = Style(sr1, "123")
    sr3 = Style(r1, sr2)
    sr3b = Style(r1, sr2, "123")

    assert isinstance(sr1, Style)
    assert isinstance(sr1b, Style)
    assert isinstance(sr2, Style)
    assert isinstance(sr2b, Style)
    assert isinstance(sr3, Style)
    assert isinstance(sr3b, Style)



# Generated at 2022-06-24 04:53:55.705695
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False
    assert r.eightbit_call == r.eightbit_call
    assert r.rgb_call == r.rgb_call
    assert r.renderfuncs == dict()


# Generated at 2022-06-24 04:54:03.196018
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """"""
    import pytest

    def test_as_dict_1():
        register = Register()
        register.a = Style(RgbFg(10, 20, 30))
        register.b = Style(RgbFg(10, 20, 30))
        register.c = Style(RgbFg(10, 20, 30))
        register.d = Style(RgbFg(10, 20, 30))
        d = register.as_dict()
        assert len(d) == 4
        assert d["a"] == "\x1b[38;2;10;20;30m"
        assert d["b"] == "\x1b[38;2;10;20;30m"
        assert d["c"] == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-24 04:54:13.658985
# Unit test for method unmute of class Register
def test_Register_unmute():

    def renderfunc(i: int) -> str:
        return "###" + str(i) + "###"

    class MyRenderType(RenderType):
        def __init__(self, _: str = "", i: int = 0):
            self.i = i

    test_reg = Register()
    test_reg.set_renderfunc(MyRenderType, renderfunc)
    test_reg.test = Style(MyRenderType("", i=9))

    test_reg.mute()

    assert test_reg.is_muted == True
    assert test_reg.test == ""

    test_reg.unmute()

    assert test_reg.is_muted == False
    assert test_reg.test == "###9###"

# Generated at 2022-06-24 04:54:20.638689
# Unit test for method __new__ of class Style
def test_Style___new__():
    # create a test-object
    bg = Register()

    # we don't want to overwrite values
    bg.renderfuncs = {}

    # create some mock data (the renderfunc is not important)

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    # Prepare register with renderfuncs
    bg.set_renderfunc(RgbFg, lambda *args: f"{args[0]} {args[1]} {args[2]}")
    bg.set_renderfunc(RgbBg, lambda *args: f"{args[0]} {args[1]} {args[2]}")
    bg.set_renderfunc(Sgr, lambda *args: f"{args[0]}")

   

# Generated at 2022-06-24 04:54:23.983168
# Unit test for method mute of class Register
def test_Register_mute():
    from .ansi import bg, fg
    from .rendertypes import AnsiBg, AnsiFg

    bg.red = Style(AnsiBg(1))

    assert str(bg.red) == "\x1b[41m"

    bg.mute()

    assert bg.red == ""



# Generated at 2022-06-24 04:54:33.386138
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Basic test
    s1 = Style(value="a")
    assert str(s1) == "a"
    assert s1.rules == ()

    # Test default values
    s2 = Style()
    assert str(s2) == ""
    assert s2.rules == ()

    # Test with rules
    s3 = Style(value="b", rules=(1, 2))
    assert s3.rules == (1, 2)

    # Test with rules and without value
    s4 = Style(rules=(1, 2))

    assert s4.rules == (1, 2)
    assert "value" not in s4.__dict__

# Generated at 2022-06-24 04:54:38.646687
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    rg = Register()

    rg.red = Style(RgbFg(255, 0, 0))

    assert rg.as_dict() == {"red": '\x1b[38;2;255;0;0m'}



# Generated at 2022-06-24 04:54:45.756858
# Unit test for method copy of class Register
def test_Register_copy():

    from .bg import bg
    from .rendertype import RgbBg

    r = Register()

    r.renderfuncs = {RgbBg: lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m" }
    r.set_rgb_call(RgbBg)
    r.r1 = Style(RgbBg(42, 33, 22))

    r.set_eightbit_call(RgbBg)
    r.r2 = Style(RgbBg(42))

    r.set_eightbit_call(bg.eightbit.SgrBg)
    r.r3 = Style(bg.eightbit.SgrBg(49))


# Generated at 2022-06-24 04:54:55.392883
# Unit test for method __call__ of class Register
def test_Register___call__():

    # class SimpleRegister(Register):
    #     def __init__(self):
    #         super().__init__()
    #         self.red = Style(RgbFg(1, 2, 3))
    #         self.green = Style(RgbFg(42, 42, 42))
    #         self.blue = Style(RgbFg(10, 11, 12))

    class SimpleRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(Sgr(1))
            self.green = Style(Sgr(2))
            self.blue = Style(Sgr(3))

    simple_register = SimpleRegister()

    assert simple_register("red") == "\033[1m"
    assert simple_register("green") == "\033[2m"
   

# Generated at 2022-06-24 04:55:06.515269
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.set_rgb_call(RenderType)
    r.set_eightbit_call(None)
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))
    r.blue = Style(RgbFg(0, 0, 255), Sgr(1))
    r.green = Style(RgbFg(0, 255, 0), Sgr(1))
    nt = r.as_namedtuple()

    assert nt, 'red' == '\x1b[38;2;255;0;0m'
    assert nt.green == '\x1b[38;2;0;255;0m'
    assert nt.blue == '\x1b[38;2;0;0;255m'


# Unit test

# Generated at 2022-06-24 04:55:14.113908
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg, rs, ef, bg, RenderType

    class CustomRender(RenderType):
        renderfunc = lambda x: f"{x}"

    fg.custom = ef.custom = bg.custom = Style(CustomRender(42))

    assert fg.custom == "42"
    assert ef.custom == "42"
    assert bg.custom == "42"

    assert fg.as_dict() == {"custom": "42"}
    assert ef.as_dict() == {"custom": "42"}
    assert bg.as_dict() == {"custom": "42"}

    rs.custom = Style(CustomRender("reset"))
    assert rs.custom == "reset"
    assert rs.as_dict() == {"custom": "reset"}

# Generated at 2022-06-24 04:55:18.842002
# Unit test for constructor of class Style
def test_Style():
    """
    Unit test for constructor of class Style.
    """
    x = Style(1)
    assert isinstance(x, Style)
    assert isinstance(x, str)
    assert str(x) == ""

# Generated at 2022-06-24 04:55:26.445672
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test whether register is copied correctly.
    """
    from .std import fg

    test_reg = fg.copy()

    assert id(test_reg) != id(fg)
    assert test_reg.gray == str(fg.gray)
    assert isinstance(test_reg.gray, str)
    assert test_reg.red == str(fg.red)
    assert isinstance(test_reg.red, str)



# Generated at 2022-06-24 04:55:33.346314
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()

    # Type: Eightbit-call
    assert r(42) == ""
    r.set_eightbit_call(RenderType)
    assert r(42) == chr(27) + "RENDERTYPE" + str(42)

    # Type: RGB-call
    assert r(255, 255, 255) == ""
    r.set_rgb_call(RenderType)
    assert r(255, 255, 255) == chr(27) + "RENDERTYPE" + str((255, 255, 255))

    # Type: Unknown
    assert r(1, 2, 3, 4) == ""

# Generated at 2022-06-24 04:55:39.252010
# Unit test for constructor of class Style
def test_Style():
    style = Style(Sgr(1, 2), RgbFg(42, 11, 0))
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules == (Sgr(1, 2), RgbFg(42, 11, 0))
    assert str(style) == '\x1b[1;2m\x1b[38;2;42;11;0m'


# Generated at 2022-06-24 04:55:47.590728
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    assert fg.as_dict() == {'red': '\x1b[38;2;255;0;0m',
                            'green': '\x1b[38;2;0;255;0m',
                            'blue': '\x1b[38;2;0;0;255m'}


# Generated at 2022-06-24 04:55:54.729215
# Unit test for method mute of class Register
def test_Register_mute():
    r1 = Register()
    r1.fg_blue = Style(RgbFg(255, 255, 255), Sgr(1))
    r1.bg_blue = Style(RgbFg(255, 255, 255))

    assert str(r1.fg_blue) == "\x1b[38;2;255;255;255m\x1b[1m"
    assert str(r1.bg_blue) == "\x1b[48;2;255;255;255m"

    r1.mute()

    assert str(r1.fg_blue) == ""
    assert str(r1.bg_blue) == ""

    r1.unmute()


# Generated at 2022-06-24 04:55:57.280694
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    value = "testvalue"
    fg = Register()
    fg.foo = Style(value)
    assert fg.foo is value


# Generated at 2022-06-24 04:56:02.357146
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.fg_red = "a"
    r.fg_green = "b"
    r.fg_blue = "c"

    nt = r.as_namedtuple()

    assert nt.fg_red == "a"
    assert nt.fg_green == "b"
    assert nt.fg_blue == "c"

# Generated at 2022-06-24 04:56:08.968272
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    fg = Register()

    # Set some colors
    fg.red = Style()
    fg.green = Style()
    fg.blue = Style()

    # Test
    fg_tuple = fg.as_namedtuple()
    assert isinstance(fg_tuple, namedtuple)

    assert getattr(fg_tuple, "red") == ""
    assert getattr(fg_tuple, "green") == ""
    assert getattr(fg_tuple, "blue") == ""


# Generated at 2022-06-24 04:56:13.855279
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import Sgr

    register = Register()

    register.test_style = Style(Sgr(4))
    register.set_eightbit_call(Sgr)
    register.set_renderfunc(Sgr, lambda *args: str(args[0]))

    assert register(4) == "4"
    assert register("test_style") == "4"

# Generated at 2022-06-24 04:56:22.445897
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .stypes import RgbFg, RgbBg, Sgr

    eightbit_call = lambda x: x
    rgb_call = lambda r, g, b: (r, g, b)

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def render_bold(a):
        return f"\x1b[{a}m"


# Generated at 2022-06-24 04:56:31.743576
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import os
    import tempfile
    import pickle

    # Create a file in a temporary directory
    tmpd = tempfile.TemporaryDirectory()
    fname = tmpd.__enter__()
    fname += "/tempfile.pickle"
    with open(fname, "wb") as tmpf:
        # Dump the dict of a register in the temporary file
        pickle.dump(fg.as_dict(), tmpf)

    # Remove temporary directory and file
    tmpd.cleanup()

    # Test that no file remains in temporary directory
    assert len(os.listdir(tmpd.name)) == 0


# Generated at 2022-06-24 04:56:42.613032
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Define a new render function that changes all colors to 0.
    def renderfunc_zero(x):
        return "\x1b[38;5;0m"

    # Define a render type.
    class RenderTypeZero(RenderType):
        """
        Set color to 0.
        """

        args: List[int] = []  # type: ignore
        nargs: int = 0

        def __init__(self, x: int):
            self.args = [x]

    # Create a new register.
    r = Register()

    # Add render func to register.
    r.set_renderfunc(RenderTypeZero, renderfunc_zero)

    # Set render type for Eightbit calls.
    r.set_eightbit_call(RenderTypeZero)


# Generated at 2022-06-24 04:56:55.120933
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test method set_renderfunc of class Register
    """
    from .rendertype import RgbFg, Sgr

    class RgbFgRedefinition(RgbFg):
        """
        New RenderType for defining ANSI-sequences.
        """
        def __init__(self, r: float, g: float, b: float):
            self.r = r
            self.g = g
            self.b = b
            self.args = (self.r, self.g, self.b)


# Generated at 2022-06-24 04:57:01.678701
# Unit test for constructor of class Register
def test_Register():
    # Test with defaults
    register1 = Register()
    assert register1.renderfuncs is not None

    # Test with renderfunc
    renderfunc = lambda *args: "test"
    rendertype = RenderType
    renderfuncs = {rendertype: renderfunc}
    register2 = Register(renderfuncs)
    assert register2.renderfuncs[rendertype] == renderfunc


# Generated at 2022-06-24 04:57:06.714837
# Unit test for method unmute of class Register
def test_Register_unmute():
    reg = Register()

    # Create 2 styles with the same rules but different renderfuncs.
    # The renderfunc for s1 returns "A" and the renderfunc for
    # s2 returns "B"
    s1 = Style("A")
    s2 = Style("B")

    # Add style-attributes to register.
    reg.s1 = s1
    reg.s2 = s2

    # Mute register. The renderfuncs for s1 and s2 are not called
    # and the value of s2 and s1 is "".
    reg.mute()
    assert reg.s1 == ""
    assert reg.s2 == ""

    # Unmute register. The renderfuncs for s1 and s2 are called
    # and the value of s1 and s2 is "A" and "B".

# Generated at 2022-06-24 04:57:14.841861
# Unit test for method mute of class Register
def test_Register_mute():
    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.foo = Style(value="\x1b[8m")

    # Check whether the initial value is "\x1b[8m" (not muted)
    assert str(TestRegister().foo) == "\x1b[8m"

    testreg = TestRegister()
    testreg.mute()

    # Check whether the muted value is "" (empty string)
    assert str(testreg.foo) == ""

    testreg.unmute()

    # Check whether the unmuted value is "\x1b[8m" again
    assert str(testreg.foo) == "\x1b[8m"


# Generated at 2022-06-24 04:57:21.706518
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # This unit test tests if the method set_eightbit_call works as expected.
    # It creates a new Register object and adds a dummy renderfunc to it. Then
    # it calls the method and checks if the attribute eightbit_call is what it
    # should be: The callable that was set before.
    pass


# Generated at 2022-06-24 04:57:22.729226
# Unit test for method mute of class Register
def test_Register_mute():
    assert False


# Generated at 2022-06-24 04:57:30.202015
# Unit test for method copy of class Register
def test_Register_copy():

    # Create a new register
    x = Register()

    # Create a style
    mystyle = Style(RgbFg(0, 1, 2))

    # Create a attrribute
    x.mystyle = mystyle

    # Copy the register
    y = x.copy()

    # Check if attr mystyle is the same
    assert mystyle is y.mystyle

    # Check if the values are the same
    assert str(mystyle) == str(y.mystyle)

# Generated at 2022-06-24 04:57:41.078882
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class SetEightBitCall(NamedTuple):
        rendertype: Type[RenderType]
        func: Callable

    # testdata
    testdata: List[SetEightBitCall] = [
        SetEightBitCall(RgbFg, lambda x: f"RgbFg:{x}"),
        SetEightBitCall(RgbBg, lambda x: f"RgbBg:{x}"),
        SetEightBitCall(Sgr, lambda x: f"Sgr:{x}"),
    ]

    for data in testdata:

        r = Register()
        r.set_renderfunc(data.rendertype, data.func)

        r.set_eightbit_call(data.rendertype)

        assert str(getattr(r, chr(25))) == data.func(25)

# Generated at 2022-06-24 04:57:50.077102
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Create render function
    def simple_renderfunc(sty):
        return f"({sty})"

    # Define test parameters
    t_param = NamedTuple('t_param', [('name', str), ('sty', RenderType)])

    # Create test data
    data = [
        t_param(name='SgrFg', sty=SgrFg(1)),
        t_param(name='SgrBg', sty=SgrBg(2)),
        t_param(name='SgrEf', sty=SgrEf(3)),
        t_param(name='SgrRs', sty=SgrRs())
    ]

    for t in data:
        # Create register object
        reg = Register()

        # Set rende function

# Generated at 2022-06-24 04:57:55.862942
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class FakeRegister(Register):
        a = Style("a")
        b = Style("b")
        c = Style("c")

    FakeRegister.e = Style("e")

    fr = FakeRegister()
    nt = fr.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert len(nt._fields) == 4
    assert isinstance(nt, FakeRegister.as_namedtuple.__annotations__["return"])



# Generated at 2022-06-24 04:57:59.707471
# Unit test for method __call__ of class Register
def test_Register___call__():
    class MyRegister(Register):
        pass

    my_register = MyRegister()
    my_register.red = "red"
    my_register.yellow = "yellow"

    assert my_register("red") == my_register.red
    assert my_register("yellow") == my_register.yellow

# Generated at 2022-06-24 04:58:00.504144
# Unit test for constructor of class Register
def test_Register():
    assert isinstance(Register(), Register)

# Generated at 2022-06-24 04:58:07.287826
# Unit test for method unmute of class Register
def test_Register_unmute():

    reg_class = namedtuple("Register", ["renderfuncs"])

    renderfuncs = {
        "rendertype": lambda x: f"\x1b[{str(x)}m"
    }

    reg = Register()
    reg.set_eightbit_call(str)
    reg.set_rgb_call(str)
    reg.set_renderfunc(str, lambda fe, ba: "")

    FooStyle = Style(str(1))

    reg.renderfuncs = renderfuncs
    reg.FooStyle = FooStyle

    assert reg.FooStyle == Style(str(1), value="")
    reg.unmute()
    assert reg.FooStyle == Style(str(1), value="\x1b[1m")
    reg.mute()

# Generated at 2022-06-24 04:58:11.099558
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    assert Register().as_dict() == {}

    class MyRegister(Register):
        hello = "hello"
        world = "world"

    reg = MyRegister()
    assert reg.as_dict() == MyRegister().as_dict() == {"hello": "hello", "world": "world"}



# Generated at 2022-06-24 04:58:18.746584
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import Extended
    from .foreground import RgbFg, AnsiFg
    from .effect import BOLD
    register = Register()
    register.set_renderfunc(Extended, lambda cls, a: "\\x1b[38;2;{};{};{}m".format(*a))
    register.set_renderfunc(AnsiFg, lambda cls, a: "\\x1b[38;5;{}m".format(*a))
    register.set_renderfunc(BOLD, lambda cls, *a: "\\x1b[1m")
    register.set_eightbit_call(Extended)
    register.set_rgb_call(Extended)
    register.red = Sty(RgbFg(255,0,0))

# Generated at 2022-06-24 04:58:29.080262
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Eightbit(RenderType):
        def ansi_sequence(self, code) -> str:
            return f"\x1b[{code}m"

    class Eightbit2(RenderType):
        def ansi_sequence(self, code) -> str:
            return f"\x1b[{100 + code}m"

    class Rgb(RenderType):
        def ansi_sequence(self, r, g, b) -> str:
            return f"\x1b[38;2;{r};{g};{b}m"

    class Rgb2(RenderType):
        def ansi_sequence(self, r, g, b) -> str:
            return f"\x1b[48;2;{r};{g};{b}m"

    reg = Register()

    reg.set_

# Generated at 2022-06-24 04:58:31.145211
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r
    assert isinstance(r, Register)
    assert r.eightbit_call
    assert r.rgb_call

# Generated at 2022-06-24 04:58:36.304633
# Unit test for method copy of class Register
def test_Register_copy():
    # Create a new register.
    class R(Register): pass
    r = R()

    r.test = Style(fg=1)
    r.test2 = Style(fg=2)

    r_copy = r.copy()

    assert r is not r_copy
    assert r.test is not r_copy.test
    assert r.test2 is not r_copy.test2

# Generated at 2022-06-24 04:58:37.327829
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    pass



# Generated at 2022-06-24 04:58:39.809384
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .sgr import Sgr

    style = Style(Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)



# Generated at 2022-06-24 04:58:40.689535
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-24 04:58:43.659446
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Test if Style-object correctly sets value and rules attributes.
    s = Style(value="TestString", rules=[1, 2, 3])
    if not isinstance(s, Style):
        raise AssertionError
    if s.value != "TestString":
        raise AssertionError
    if s.rules != [1, 2, 3]:
        raise AssertionError



# Generated at 2022-06-24 04:58:50.943121
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MockRegister(Register):
        pass

    reg = MockRegister()

    class RgbFg:
        def __init__(self, r, g, b, sgr=None):
            self.r = r
            self.g = g
            self.b = b
            self.sgr = sgr

        def args(self):
            return (self.r, self.g, self.b)

    def _rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    reg.set_renderfunc(RgbFg, _rgb_fg)

    style = Style(RgbFg(1, 2, 3))
    reg.s = style


# Generated at 2022-06-24 04:59:02.628406
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .render import Sgr

    class MyRegister(Register):
        pass

    reg = MyRegister()

    # Test:
    #
    # Given: Muting the object
    # Expected: Setting a Style object does not change the style.

    reg.is_muted = True
    reg.set_renderfunc(Sgr, lambda *args: "\x1b[{}m".format(*args))
    reg.my_style = Style(Sgr(1))
    assert str(reg.my_style) == ""
    reg.is_muted = False

    # Test:
    #
    # Given: Register object with a style that contains sgr-rules.
    # Expected: Setting the style-attribute generates the correct ANSI-sequence.


# Generated at 2022-06-24 04:59:06.865650
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .stylers.default import fg, bg

    bg._set("blue", 42)
    assert isinstance(bg.as_namedtuple(), namedtuple("StyleRegister", ["blue"]))


# Generated at 2022-06-24 04:59:16.913198
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test if the 8bit-renderfunc of the register-object is changed.
    """

    def func1(code: int) -> str:
        return f"1{code}"

    def func2(code: int) -> str:
        return f"2{code}"

    class RenderTypeA:
        args: Tuple[int] = (1,)

    class RenderTypeB:
        args: Tuple[int] = (2,)

    a = Register()
    a.set_renderfunc(RenderTypeA, func1)
    a.set_renderfunc(RenderTypeB, func2)

    assert a(1) == "11"
    assert a(2) == "22"

    a.set_eightbit_call(RenderTypeB)
    assert a(1) == "11"

# Generated at 2022-06-24 04:59:20.303761
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        red = Style()
        blue = Style()

    r = TestRegister()
    assert r("blue") == ""
    assert r("red", 1, 2) == ""
    assert r(1, 2, 3) == ""
    assert r("red", 1) == ""
    assert isinstance(r("blue"), str)

# Generated at 2022-06-24 04:59:26.174441
# Unit test for method mute of class Register
def test_Register_mute():
    """
    """
    fg = Register()

    fg.set_renderfunc(RenderType.FgColor, lambda x: f"\x1b[38;5;{x}m")
    fg.set_eightbit_call(RenderType.FgColor)

    fg.red = Style(RenderType.FgColor(1))
    fg.green = Style(RenderType.FgColor(2))
    fg.blue = Style(RenderType.FgColor(3))

    assert fg.red == "\x1b[38;5;1m"
    assert fg.green == "\x1b[38;5;2m"
    assert fg.blue == "\x1b[38;5;3m"
