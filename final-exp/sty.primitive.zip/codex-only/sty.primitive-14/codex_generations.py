

# Generated at 2022-06-24 04:49:31.896908
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()

    M = namedtuple("M", ["args", "result"])

    class R(RenderType):
        pass

    @RenderType.register(R)
    def r_func(*args):
        return "".join([str(x) for x in args])

    r.set_renderfunc(R, r_func)

    r.set_rgb_call(R)

    d = [
        M(args=(1, 2, 3), result="123"),
        M(args=(11, 22, 33), result="112233"),
        M(args=(111, 222, 333), result="111222333"),
    ]

    for m in d:
        assert r(*m.args) == m.result


# Generated at 2022-06-24 04:49:40.223283
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbBg

    class RegisterTest(Register):
        def __init__(self):
            super().__init__()
            self.set_rgb_call(RgbBg)
            self.rgb_call = lambda r, g, b: f"rgb-call({r}, {g}, {b})"

    r = RegisterTest()
    r.blue = Style(RgbBg(0, 0, 255))

    assert str(r.blue) == "\x1b[48;2;0;0;255m"
    assert r(3) == "rgb-call(3, 42, 255)"

    r.mute()

    assert str(r.blue) == ""
    assert r(3) == ""

    r.unmute()

    assert str(r.blue)

# Generated at 2022-06-24 04:49:43.291350
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbBg(1,2,3))
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[48;2;1;2;3m"

# Generated at 2022-06-24 04:49:46.730721
# Unit test for constructor of class Register
def test_Register():

    # Arrange
    fg: Register = Register()

    # Act
    fg.red = Style(RenderType())

    # Assert
    assert isinstance(fg.red, Style)

# Generated at 2022-06-24 04:49:50.174162
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    The default registers should have a default render type for calls with 8bit codes. ``fg(42)``
    """
    r = Register()
    assert r.eightbit_call(42) == "\033[38;5;42m"

# Generated at 2022-06-24 04:49:55.082360
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg

    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0))

    reg.set_rgb_call(RgbFg)
    assert reg(255, 0, 0) == reg.red
    assert reg(255, 0, 0) == "\x1b[38;2;255;0;0m"

    # If register object is muted:
    reg.mute()
    assert reg(255, 0, 0) == ""
    reg.unmute()

# Generated at 2022-06-24 04:49:59.006114
# Unit test for constructor of class Register
def test_Register():

    r = Register()
    r.foo = Style(RgbFg(1,2,3))

    assert isinstance(r.foo, str)
    assert isinstance(r.foo, Style)



# Generated at 2022-06-24 04:50:07.238732
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    import unittest

    class TestClass(unittest.TestCase):
        def setUp(self):

            def func1(x):
                return "func1"

            def func2(x, y, z):
                return "func2"

            self.func1 = func1

            self.func2 = func2

        def test_it(self):
            from .rendertype import Sgr, RgbFg

            reg = Register()

            reg.set_renderfunc(Sgr, self.func1)
            reg.set_renderfunc(RgbFg, self.func2)

            reg.set_eightbit_call(Sgr)
            reg.set_rgb_call(RgbFg)

            self.assertEqual(reg(1), "func1")

# Generated at 2022-06-24 04:50:15.517339
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class ColorA(RenderType):
        """Class for test-purposes."""
        pass

    class ColorB(RenderType):
        """Class for test-purposes."""
        pass

    def render_func_a(s) -> str:
        """Render func for test-purposes."""
        return f"{s}a"

    def render_func_b(s) -> str:
        """Render func for test-purposes."""
        return f"{s}b"

    r1 = Register()
    r2 = Register()

    r1.set_renderfunc(ColorA, render_func_a)
    r1.set_renderfunc(ColorB, render_func_b)

    r1.set_eightbit_call(ColorA)
    r2.set_eightbit_call(ColorB)

# Generated at 2022-06-24 04:50:24.791730
# Unit test for constructor of class Style
def test_Style():

    # Create a style rule
    def test_rule(*args) -> str:
        return f'{args[0].__class__.__name__} {args}'

    # Add render-function for SGR-type
    r = Register()
    r.set_renderfunc(RenderType, test_rule)

    # Create style
    r.style = Style(RenderType(0))

    # Compare style and str-output of style
    assert r.style.rules == (RenderType(0),)
    assert str(r.style) == f'{RenderType(0).__class__.__name__} (0,)'



# Generated at 2022-06-24 04:50:27.572464
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style("foo")
    assert isinstance(s, Style)

# Generated at 2022-06-24 04:50:33.245035
# Unit test for constructor of class Register
def test_Register():

    custom = Register()
    assert isinstance(custom.as_dict(), dict)

    assert isinstance(custom.as_namedtuple(), NamedTuple)

    cp = custom.copy()
    assert cp is not custom
    assert cp.__dict__ is not custom.__dict__
    assert cp.__dict__ == custom.__dict__

    custom.mute()

    # Tests muting and unmuting of register-object.
    custom.black = Style(RgbFg(30, 30, 30))
    assert custom.black == ""
    custom.unmute()
    assert custom.black != ""

# Generated at 2022-06-24 04:50:41.838934
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    r = Register()
    r.renderfuncs = {
        "a": lambda x: x,
        "b": lambda x, y, z: x + y + z,
    }

    r.dark_red = Style(a(1), b(1, 2, 3), a(4), b(5, 6, 7), a(7), a(8))
    r.dark_green = Style(a(1), b(1, 2, 3), a(4), b(5, 6, 7), a(7), a(8))
    r.dark_blue = Style(a(1), b(1, 2, 3), a(4), b(5, 6, 7), a(7), a(8))

# Generated at 2022-06-24 04:50:53.535000
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, RgbBg, RgbBold, RgbUnderline, RgbDim, RgbItalic, RgbCrossed
    from .rendertype import RgbBlink, RgbReversed, RgbConcealed, RgbUnderline2

    # Test initialization of different render types and evaluation by
    # direct attribute access.
    rs = Register()
    rs.my_rule1 = Style(RgbFg(1, 5, 10))
    rs.my_rule2 = Style(RgbBg(2, 7, 11), RgbBold(True), RgbUnderline(True))
    rs.my_rule3 = Style(RgbDim(True), RgbItalic(True), RgbCrossed(True))

# Generated at 2022-06-24 04:51:00.625198
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: "rgb")
    r.set_renderfunc(EightbitFg, lambda x: "eight")
    r.eightbit_call = lambda x: None

    r.set_eightbit_call(RgbFg)
    assert r.eightbit_call("", "", "") == "rgb"

    r.set_eightbit_call(EightbitFg)
    assert r.eightbit_call("") == "eight"

# Generated at 2022-06-24 04:51:09.466029
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .color_defs import fg, bg, ef, rs

    class CustomRegister(Register):
        pass

    rendertype = fg.renderfuncs.get(bg.RgbBg)
    cr = CustomRegister()
    cr.set_renderfunc(bg.RgbBg, rendertype)
    cr.info = Style(bg.RgbBg(10, 42, 255))
    cr.warn = Style(bg.RgbBg(255, 0, 255))

    nt = cr.as_namedtuple()
    assert nt.info
    assert nt.warn

# Generated at 2022-06-24 04:51:10.953268
# Unit test for method __new__ of class Style
def test_Style___new__():
    class StyleTypeSubclass(Style):
        pass

    StyleTypeSubclass()  # Should not throw error

# Generated at 2022-06-24 04:51:14.106758
# Unit test for method mute of class Register
def test_Register_mute():
    from sty import fg

    fg.red = Style(fg.red)
    fg.mute()
    assert fg.red == ""


# Generated at 2022-06-24 04:51:22.112976
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()

    r.set_eightbit_call(type)
    r.set_rgb_call(type)

    r.black = Style(RenderType, RenderType)
    r.red = Style(RenderType, RenderType)
    r.green = Style(RenderType, RenderType)
    r.yellow = Style(RenderType, RenderType)
    r.blue = Style(RenderType, RenderType)
    r.magenta = Style(RenderType, RenderType)
    r.cyan = Style(RenderType, RenderType)
    r.white = Style(RenderType, RenderType)

    r2 = r.copy()

    assert r2 is not r

    assert r2.renderfuncs is not r.renderfuncs
    assert r2.rgb_call is not r.rgb_call

# Generated at 2022-06-24 04:51:28.541705
# Unit test for constructor of class Register
def test_Register():
    fg = Register()
    assert isinstance(fg, Register)

    bg = Register()
    assert isinstance(bg, Register)

    ef = Register()
    assert isinstance(ef, Register)

    rs = Register()
    assert isinstance(rs, Register)

    assert fg.is_muted == bg.is_muted == ef.is_muted == rs.is_muted



# Generated at 2022-06-24 04:51:36.648159
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class TestRegister(Register):
        pass

    r = TestRegister()
    r.test_rule = Style(RgbBg(10, 10, 10), RgbFg(10, 10, 10))
    r.test_rule2 = Style(RgbBg(10, 10, 10), RgbFg(10, 10, 10))

    d = r.as_dict()

    assert len(d) == 2
    assert d["test_rule"]  == str(r.test_rule)
    assert d["test_rule2"] == str(r.test_rule2)


# Generated at 2022-06-24 04:51:48.155748
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Note: These tests only make sense if ANSI-render-functions return static strings.
    #       (Therefore I set the ansi-render-functions to lambda x: str(x)).

    # Create custom register
    class RgbRegister(Register):
        __slots__ = ["red", "green", "blue"]

    r1 = RgbRegister()
    r1.blue = Style(value="\x1b[38;2;0;0;255m")
    r1.set_eightbit_call(type(None))
    r1.set_rgb_call(type(None))
    r1.set_renderfunc(type(None), lambda x: str(x))

    assert r1.blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-24 04:51:59.222318
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test method Register.as_dict().
    """

    import sty

    fg: sty.Register = sty.fg


# Generated at 2022-06-24 04:52:03.999861
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg

    value = Style(fg.blue)

    assert(str(value) == fg.blue)

    fg.mute()

    assert(str(value) == "")

    fg.unmute()

    assert(str(value) == fg.blue)


# Generated at 2022-06-24 04:52:05.469683
# Unit test for constructor of class Register
def test_Register():  # type: ignore
    assert Register() is not None


# Generated at 2022-06-24 04:52:14.742942
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class RgbFg(RenderType):
        pass

    class SetFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    def rgb_fg(r, g, b):
        return f'\x1b[38;2;{r};{g};{b}m'

    def set_fg(i):
        return f'\x1b[38;5;{i}m'

    def rgb_bg(r, g, b):
        return f'\x1b[48;2;{r};{g};{b}m'

    register = Register()

    register.set_renderfunc(RgbFg, rgb_fg)
    register.set_renderfunc(SetFg, set_fg)

# Generated at 2022-06-24 04:52:20.699525
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Make sure muted register returns empty string.
    """

    from .rendertype import Sgr, FgBg

    def sgr_render(x):
        return f"\x1b[{x}m"

    def fgbg_render(x, y):
        return f"\x1b[{x};{y}m"

    regist = Register()
    regist.set_renderfunc(Sgr, sgr_render)
    regist.set_renderfunc(FgBg, fgbg_render)

    regist.white = Style(
        Sgr(1),
        FgBg(38, 2),
        Sgr(27),
        FgBg(1, 38),
        Sgr(28),
        FgBg(2, 1),
    )


# Generated at 2022-06-24 04:52:25.969809
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Fg(RenderType):
        sgr: str = "38"

    class Bg(RenderType):
        sgr: str = "48"

    def renderfunc_test(value: int) -> str:
        return f"test-val:{value}"

    register = Register()
    register.set_renderfunc(Fg, renderfunc_test)

    register.test = Style(Fg(42))

    assert str(register.test) == renderfunc_test(42)



# Generated at 2022-06-24 04:52:33.912153
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, RgbBg, Sgr

    def testfunction(x, y):
        return f"TESTING {x} and {y}"

    # Create Register
    rgb = Register()
    rgb.set_renderfunc(RgbFg, testfunction)

    # Create Style
    rgb.test = Style(RgbFg(1, 2, 3))

    # Check if renderfunc has changed
    assert str(rgb.test) == "TESTING 1 and 2"
    assert rgb.test.value == "TESTING 1 and 2"

# Generated at 2022-06-24 04:52:39.687947
# Unit test for constructor of class Register
def test_Register():
    # Test if register has no renderfuncs on init
    reg = Register()

    assert reg.renderfuncs == {}

# Generated at 2022-06-24 04:52:42.008755
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if a register object and its copy are not the same object.
    """
    a = Register()
    b = a.copy()

    assert id(a) != id(b)
    assert a is not b

# Generated at 2022-06-24 04:52:46.782185
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Sgr, SgrFg

    register = Register()

    register.set_renderfunc(Sgr, lambda code: f"SGR:{code}")
    register.set_renderfunc(SgrFg, lambda code: f"SGR_FG:{code}")

    register.set_eightbit_call(Sgr)

    assert register(42) == "SGR:42"
    assert register(23, 7) == "SGR_FG:23;7"

# Generated at 2022-06-24 04:52:57.142968
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg, Sgr
    import sty

    style = sty.Style(RgbFg(255, 0, 0), Sgr(1))
    r = sty.Register()
    r.red = style

    assert callable(r.rgb_call)

    r.set_rgb_call(RgbFg)

    assert r.rgb_call(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r.red == "\x1b[38;2;255;0;0m\x1b[1m"

    r.set_rgb_call(RgbBg)


# Generated at 2022-06-24 04:52:59.127121
# Unit test for constructor of class Register
def test_Register():
    pass


# Generated at 2022-06-24 04:53:01.287911
# Unit test for method copy of class Register
def test_Register_copy():

    r1 = Register()
    name = "test"
    r1.test = Style(name)

    r2 = r1.copy()
    assert getattr(r2, "test") == name



# Generated at 2022-06-24 04:53:12.764660
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Unit test for method mute of class Register.
    """
    from .ansi import RgbFg, Sgr
    from .ansifuncs import render_rgb_fg

    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    reg.set_renderfunc(RgbFg, render_rgb_fg)

    assert not reg.is_muted
    assert reg.red == "\x1b[38;2;255;0;0m\x1b[1m"

    reg.mute()

    assert reg.is_muted
    assert reg.red == ""

    reg.unmute()

    assert not reg.is_muted

# Generated at 2022-06-24 04:53:14.445483
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.is_muted == False


# Generated at 2022-06-24 04:53:20.109404
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    r = Register()

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))

    d = r.as_dict()
    assert d["red"] == "\x1b[38;2;255;0;0m"
    assert d["blue"] == "\x1b[48;2;0;0;255m"



# Generated at 2022-06-24 04:53:21.885820
# Unit test for constructor of class Register
def test_Register():

    reg = Register()

# Generated at 2022-06-24 04:53:31.257276
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    class RgbFg(NamedTuple):
        r: int
        g: int
        b: int

    def render_sgr(code: int) -> str:
        return chr(27) + f"[{code}m"

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return chr(27) + f"[38;2;{r};{g};{b}m"

    sgr = Sgr(1)
    rgb_fg = RgbFg(1, 5, 10)

    # set up register
    r = Register()
    r.red = Style(rgb_fg)

    # set up renderfuncs
    r.set_renderfunc(Sgr, render_sgr)

# Generated at 2022-06-24 04:53:41.824588
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .cli import fg, bg, sgr, ef

    named_tup = fg.as_namedtuple()

    assert isinstance(named_tup, namedtuple)

    assert hasattr(named_tup, "red")
    assert named_tup.red == fg.red

    assert hasattr(named_tup, "green")
    assert named_tup.green == fg.green

    assert hasattr(named_tup, "blue")
    assert named_tup.blue == fg.blue

    assert hasattr(named_tup, "cyan")
    assert named_tup.cyan == fg.cyan

    assert hasattr(named_tup, "yellow")
    assert named_tup.yellow == fg.yellow


# Generated at 2022-06-24 04:53:52.538982
# Unit test for method mute of class Register
def test_Register_mute():

    from .render import RgbFg, Sgr

    # Create a test register
    class TestRegister(Register):
        att1 = Style(RgbFg(255, 102, 10), Sgr(1))
        att2 = Style(RgbFg(10, 102, 255))

    # Create a test register instance
    rr = TestRegister()

    # Make sure, that attr values are equal to the ANSI escape codes
    assert str(rr.att1) == "\033[38;2;255;102;10m\033[1m"
    assert str(rr.att2) == "\033[38;2;10;102;255m"

    # Mute the test register
    rr.mute()

    # Make sure, that attr values are empty strings
    assert str(rr.att1) == ""


# Generated at 2022-06-24 04:53:59.563892
# Unit test for method mute of class Register
def test_Register_mute():
    from pytest import approx

    from .rendertype import RgbFg, RgbBg

    r = Register()

    r.green = Style(RgbFg(0, 200, 0))
    r.blue = Style(RgbBg(0, 0, 200))

    assert r.green == "\x1b[38;2;0;200;0m"
    assert r.blue == "\x1b[48;2;0;0;200m"

    r.mute()

    assert r.green == ""
    assert r.blue == ""



# Generated at 2022-06-24 04:54:11.537396
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    TestCase = namedtuple("TestCase", "test_input expected_result")

    def f1(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    def f2(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    fg = Register()
    fg.set_renderfunc(RgbFg, f2)


# Generated at 2022-06-24 04:54:20.369108
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Ansi8Bg, Sgr

    r = Register()

    r.test_style = Style(Sgr(1), Ansi8Bg(55))

    assert r.test_style == "\x1b[1m\x1b[48;5;55m"

    r.mute()

    assert r.test_style == ""
    assert r.test_style.rules == (Sgr(1), Ansi8Bg(55))

    r.unmute()

    assert r.test_style == "\x1b[1m\x1b[48;5;55m"

# Generated at 2022-06-24 04:54:31.029783
# Unit test for method __call__ of class Register
def test_Register___call__():

    import pytest

    RgbFg = RenderType("38;2", "%s;%s;%s")

    def f1(r, g, b):
        return RgbFg(r, g, b)

    r = Register()
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(RgbFg, f1)
    r.red = Style(RgbFg(255, 0, 0))

    print(r.red)

    print(r(10, 42, 255))

    # with pytest.raises(ValueError):
    #     r()

    with pytest.raises(AttributeError):
        r("does_not_exist")

    assert str(r("red")) == str(r.red)



# Generated at 2022-06-24 04:54:33.993801
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class DummyRenderType: pass
    r = Register()
    r.set_renderfunc(DummyRenderType, lambda x: "")
    r.set_eightbit_call(DummyRenderType)
    assert r.eightbit_call == r.renderfuncs[DummyRenderType]

# Generated at 2022-06-24 04:54:44.161838
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class TestRenderType(RenderType):
        """
        A test rendertype class
        """

        def to_str(self, r: int, g: int, b: int) -> str:
            return f"\x1b[38;2;{r};{g};{b}m"

    # The new rendertype
    rendertype = TestRenderType()

    # Init a new register-object
    register = Register()

    # Add a new renderfunc to register-object
    register.set_renderfunc(rendertype, rendertype.to_str)

    # Set new renderfunc for RGB-calls for register-object
    register.set_rgb_call(rendertype)

    # Invoke register-object like a function
    test = register(10, 42, 255)

    # Check the result

# Generated at 2022-06-24 04:54:49.584174
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .sgr import Reset

    r = Register()
    r.reset = Style(Reset())
    r.mute()

    assert str(r.reset) == ""
    r.unmute()
    assert str(r.reset) == "\x1b[0m"

# Generated at 2022-06-24 04:54:54.641810
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()

    r.set_renderfunc(RenderType, lambda *args: "Test")
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    r.r = Style(RenderType(1), RenderType(2))

    r2 = r.copy()

    assert r2.r == r.r
    assert r2.eightbit_call == r.eightbit_call
    assert r2.rgb_call == r.rgb_call

# Generated at 2022-06-24 04:55:04.318982
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, bg
    assert fg.rgb_call is bg.rgb_call
    assert fg.rgb_call != bg.as_dict

    # Test if new rgb_call is correct
    def new_rgb_call(r, g, b):
        return '{},{},{}'.format(r, g, b)

    fg.set_rgb_call(new_rgb_call)
    assert fg.rgb_call(255, 255, 255) == '255,255,255'

    # Test if bg-object is not affected.
    assert fg.rgb_call != bg.rgb_call

    fg.unmute()

# Generated at 2022-06-24 04:55:13.339629
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .stylist import Stylist


    class Foo:
        pass


    stylist = Stylist()

    # Create a new empty fg-register
    fg = Register()

    # Create a simple renderfunc
    def render_fg_red(code: int) -> str:
        return f'\x1b[38;5;{code}m'

    # Set render func
    fg.set_renderfunc(Foo, render_func=render_fg_red)

    # Create attribute red:
    fg.red = Style(Foo(1))

    # Print fg.red:
    print(fg.red)  # Produces '\x1b[38;5;1m'

    # Mute fg:
    fg.mute()

    # Print fg.red:

# Generated at 2022-06-24 04:55:23.697553
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        args = (0, 0, 0)
        as_str = "\x1b[38;2;{};{};{}m"

    class Sgr(RenderType):
        args = (0,)
        as_str = "\x1b[{}m"

    # Example colors
    colors = {"blue": Style(RgbFg(0, 0, 255), Sgr(1))}

    # Create register
    register = Register()

    # Add render-functions
    renderfuncs: Renderfuncs = {
        Sgr: lambda *args: Sgr(*args).as_str.format(*args),
        RgbFg: lambda *args: RgbFg(*args).as_str.format(*args),
    }
    register.renderfuncs = renderfuncs



# Generated at 2022-06-24 04:55:29.906612
# Unit test for constructor of class Register
def test_Register():

    from .sty import sty

    sty.rs.is_muted = False
    sty.rs.eightbit_call = lambda x: "8"
    sty.rs.rgb_call = lambda r, g, b: "24"

    r = Register()
    r.set_eightbit_call(sty.RgbFg)
    r.set_rgb_call(sty.RgbFg)

    r.foo = Style(sty.RgbFg(101, 42, 42))
    r.bar = Style(sty.RgbFg(101, 42, 42), sty.Bold)

    assert r.eightbit_call == sty.rs.eightbit_call
    assert r.rgb_call == sty.rs.rgb_call
    assert r.foo == sty.rs.foo
    assert r.bar

# Generated at 2022-06-24 04:55:31.525190
# Unit test for constructor of class Register
def test_Register():
    new_register = Register()
    assert new_register.as_dict() == {}



# Generated at 2022-06-24 04:55:41.449696
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class X1(RenderType):
        pass

    class X2(RenderType):
        pass

    class R(Register):
        def __init__(self):
            super().__init__()
            self.renderfuncs.update({X1: lambda x: "X1", X2: lambda x: "X2"})

    r = R()
    assert r(100) == "X1"
    assert r(100, 200, 300) == "X1"

    r.set_rgb_call(X2)
    assert r(100) == "X1"
    assert r(100, 200, 300) == "X2"

    r.set_rgb_call(X1)
    assert r(100) == "X1"
    assert r(100, 200, 300) == "X1"

# Generated at 2022-06-24 04:55:44.598708
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg: Register = Register()
    reg.black = "black"
    reg.white = "white"
    reg.empty = ""

    assert reg.as_dict() == {"black": "black", "white": "white"}

# Generated at 2022-06-24 04:55:50.615820
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import sty
    sty.rendertype.render_type("Test24Bit", "{0}{1}{2}")
    register = Register()
    register.set_rgb_call(sty.rendertype.Test24Bit)
    register.set_renderfunc(sty.rendertype.Test24Bit, lambda r,g,b: "".join([chr(r), chr(g), chr(b)]))
    assert register(20, 30, 40) == "\x14\x1e("

# Generated at 2022-06-24 04:55:59.850214
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .renderfuncs import render_sgr

    e = Register()
    e.set_renderfunc(Sgr, render_sgr)

    for x in range(0, 255):
        e.set_eightbit_call(Sgr)
        assert str(e(x)) == f"\x1b[38;5;{x}m"

    for x in range(0, 255):
        e.set_rgb_call(Sgr)
        assert str(e(x, x, x)) == "\x1b[38;2;{r};{r};{r}m".format(r=x)


# Generated at 2022-06-24 04:56:04.478271
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbBg, Sgr

    my_style = Style(RgbBg(250, 10, 1), Sgr(1))

    assert isinstance(my_style, Style)
    assert my_style == "\x1b[48;2;250;10;1m\x1b[1m"

# Generated at 2022-06-24 04:56:13.019479
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Register-object 'fg' is defined in module sty.fgbg
    from sty.fgbg import fg

    # Eightbit-call
    assert fg(44) == fg.light_blue
    assert fg(44) != fg.blue

    # RGB-call with integers
    assert fg(102, 49, 42) == fg.medium_wood_brown
    assert fg(102, 49, 42) != fg.dark_wood_brown

    # RGB-call with named color
    assert fg('medium_wood_brown') == fg.medium_wood_brown
    assert fg('medium_wood_brown') != fg.dark_wood_brown

# Generated at 2022-06-24 04:56:21.896505
# Unit test for method copy of class Register
def test_Register_copy():
    from . import fg, sgr

    # Create a new register (copy fg):
    myfg = fg.copy()

    # Add a new color-name and style:
    myfg.orange = sgr.fg(244, 164, 96)

    # Orange (from fg-register) and orange (from myfg-register)
    # should be equal:
    assert fg.orange == myfg.orange

    # Remove attributes of fg register (that you want to transfer to
    # myfg register):
    del fg.orange

    # Assign the fg register to myfg register.
    # This will replace the orange style from myfg register with the orange
    # style from fg register.
    myfg.__dict__.update(fg.__dict__)

    # Orange (from fg-register) and orange

# Generated at 2022-06-24 04:56:25.861762
# Unit test for constructor of class Register
def test_Register():

    r = Register()

    assert isinstance(r, Register)
    assert isinstance(r.__dict__, dict)



# Generated at 2022-06-24 04:56:31.871749
# Unit test for method copy of class Register
def test_Register_copy():

    # Setup
    rs = Register()
    rs.set_rgb_call(RgbFg)
    register_a = Register()
    register_a.set_rgb_call(RgbFg)
    register_a.red = Style(RgbFg(255, 0, 0), RgbBg(255, 0, 0))

    # Test
    register_b = register_a.copy()

    assert id(register_a) != id(register_b)
    assert id(register_a.red) != id(register_b.red)
    assert register_a.red == register_b.red
    assert register_a.red.rules == register_b.red.rules
    assert register_a.red.rules[0] == register_b.red.rules[0]

# Generated at 2022-06-24 04:56:42.220902
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .renderfunction import ansi_render

    from .sty import StyleRule

    this_register = Register()
    this_register.set_renderfunc(StyleRule, ansi_render)

    this_register.test1 = Style(StyleRule(None, None, None, 1), StyleRule(None, None, None, 2))
    this_register.test2 = Style(StyleRule(None, None, None, 3), StyleRule(None, None, None, 4))

    this_register.test3 = "bla"

    assert this_register.as_dict() == {"test1": "\x1b[1m\x1b[2m", "test2": "\x1b[3m\x1b[4m", "test3": "bla"}

# Generated at 2022-06-24 04:56:46.072308
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class myRegister(Register):
        pass

    r = myRegister()
    r.test = Style()
    r.test2 = Style()

    assert r.as_dict() == {"test": "", "test2": ""}

# Generated at 2022-06-24 04:56:55.767355
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()
    reg.r1 = Style(
        RenderType(1, 2, 3),
        RenderType(4, 5, 6),
    )
    reg.r2 = Style(
        Style(1, 2),
        RenderType(5, 6),
    )
    reg.r3 = Style(
        Style(1, 2),
        Style(5, 6),
    )
    expected = {
        "r1": "\x1b[1;2;3m\x1b[4;5;6m",
        "r2": "\x1b[1m\x1b[2m\x1b[5;6m",
        "r3": "\x1b[1m\x1b[2m\x1b[5m\x1b[6m",
    }


# Generated at 2022-06-24 04:57:02.827496
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = "1"
            self.blue = "2"
            self.green = "3"

    r = MyRegister()
    d = r.as_dict()

    assert isinstance(d, dict)
    assert d == {'red': '1', 'blue': '2', 'green': '3'}



# Generated at 2022-06-24 04:57:12.441841
# Unit test for method __call__ of class Register
def test_Register___call__():
    # obj called with int
    obj = Register()
    obj.red = "red"

    obj.eightbit_call = lambda x: "eightbit-call-called"
    obj.rgb_call = lambda x, y, z: "rgb_call-called"

    assert obj(42) == "eightbit-call-called"
    assert obj(10, 24, 42) == "rgb_call-called"
    assert obj("red") == "red"
    # Empty string for unknown color name
    assert obj("unknown") == ""
    # Empty string for obj muted
    obj.mute()
    assert obj(42) == ""
    assert obj(10, 24, 42) == ""
    assert obj("red") == ""
    assert obj("unknown") == ""
    obj.unmute()

    # obj called with

# Generated at 2022-06-24 04:57:20.178044
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):

        def asString(*args):
            if len(args) == 1:
                return f"\x1b[{args[0]}m"
            else:
                return f"\x1b[{';'.join(args)}m"

    class Rgb(NamedTuple):
        red: int
        green: int
        blue: int

    def render_rgb_fg(red: int, green: int, blue: int) -> str:
        rgb = Rgb(red, green, blue)
        return f"\x1b[38;2;{rgb.red};{rgb.green};{rgb.blue}m"


# Generated at 2022-06-24 04:57:27.886185
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Create two registers and configure them separately.
    """

    class R1(RenderType):
        render = lambda x: "R1"

    class R2(RenderType):
        render = lambda x: "R2"

    class R3(RenderType):
        render = lambda x: "R3"

    class R4(RenderType):
        render = lambda x: "R4"

    r1 = Register()
    r2 = Register()

    r1.set_renderfunc(R1, R1.render)
    r1.set_renderfunc(R2, R2.render)
    r1.set_renderfunc(R3, R3.render)

    r2.set_renderfunc(R1, R1.render)
    r2.set_renderfunc(R2, R2.render)

# Generated at 2022-06-24 04:57:34.664052
# Unit test for method __new__ of class Style
def test_Style___new__():

    import attr
    from .rendertype import RgbBg, RgbFg, Sgr

    rules_1 = (RgbFg(10, 5, 2), Sgr(1, 2, 3))

    rules_2 = (Sgr(1), rules_1, Sgr(4))

    rules_3 = (rules_1, rules_2, rules_1, rules_2)

    style_1 = Style(*rules_1)

    assert style_1 == "\x1b[38;2;10;5;2m\x1b[1;2;3m"

# Generated at 2022-06-24 04:57:39.739235
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Create new register object
    r = Register()

    # Set a renderfunc
    r.set_renderfunc(None, lambda x: str(x))

    # Set the rendertype for eightbit-calls
    r.set_eightbit_call(None)

    # Expect correct output
    assert r(42) == "42"


# Generated at 2022-06-24 04:57:49.139502
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import RgbFg, RgbBg, RgbEf

    class CustomRegister(Register):
        pass

    renderfuncs: Dict[Type[RenderType], Callable] = {
        RgbBg: lambda r, g, b: (r, g, b),
        RgbFg: lambda r, g, b: (r, g, b),
        RgbEf: lambda **kwargs: (kwargs,),
    }

    r = CustomRegister()
    r.set_renderfunc(RgbBg, renderfuncs[RgbBg])
    r.set_renderfunc(RgbEf, renderfuncs[RgbEf])
    r.set_renderfunc(RgbFg, renderfuncs[RgbFg])

# Generated at 2022-06-24 04:57:58.533179
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import sys

    import pytest

    if sys.version_info.major >= 3 and sys.version_info.minor >= 6:
        from . import fg, bg, ef, rs

        nt_fg = fg.as_namedtuple()
        nt_bg = bg.as_namedtuple()
        nt_ef = ef.as_namedtuple()
        nt_rs = rs.as_namedtuple()

        result1 = nt_fg.white + "Hello"
        result2 = nt_bg.white + "Hello"
        result3 = nt_ef.bold + "Hello"
        result4 = nt_rs.sgr0 + "Hello"

        assert result1 == "\x1b[38;5;15mHello"

# Generated at 2022-06-24 04:58:02.909353
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # create a test-register
    test_reg = Register()

    # add rendertype and renderfunc
    test_reg.set_renderfunc(RenderType, lambda x: x)

    # create Style-object
    test_style = Style(RenderType(42))

    # set attribute with new style
    setattr(test_reg, "test", test_style)

    # check if attribute "test" is a Style-object with value "42"
    assert isinstance(test_reg.test, Style)
    assert test_reg.test == 42



# Generated at 2022-06-24 04:58:11.409569
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg, bg, ef, rs

    assert fg.deepskyblue == '\x1b[38;2;0;191;255m'

    # Test with simple terminal
    with open('simple_term.txt', 'r') as file:
        data = file.read()
    assert data == str(fg(deepskyblue=True))

    # Test with rich terminal
    with open('rich_term.txt', 'r') as file:
        data = file.read()
    assert data == fg.as_dict()['deepskyblue']

    assert str(rs) == ""

# Generated at 2022-06-24 04:58:18.078311
# Unit test for constructor of class Style
def test_Style():
    """Test constructor for Style()."""
    # Build a style
    style = Style(RenderType("SGR", 1),
                  RenderType("SGR", 2),
                  RenderType("SGR", 3),
                  RenderType("SGR", 5),
                  RenderType("SGR", 6),
                  RenderType("SGR", 8),
                  )
    # Test if Style is really a string
    assert isinstance(style, Style)
    assert isinstance(style, str)
    # Test if all rules are set
    assert style.rules == (
        RenderType("SGR", 1),
        RenderType("SGR", 2),
        RenderType("SGR", 3),
        RenderType("SGR", 5),
        RenderType("SGR", 6),
        RenderType("SGR", 8),
    )
    # Test if the `

# Generated at 2022-06-24 04:58:26.597292
# Unit test for method __new__ of class Style
def test_Style___new__():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    s = Style(RgbFg(10, 10, 10), Sgr(1))

    assert isinstance(s, Style)
    assert isinstance(s, str)

    assert len(s.rules) == 2
    assert isinstance(s.rules[0], RgbFg)
    assert isinstance(s.rules[1], Sgr)



# Generated at 2022-06-24 04:58:33.524586
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):

        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)

        @staticmethod
        def renderfunc(*args) -> str:
            return args[0]

    class TestRegister(Register):
        pass

    reg = TestRegister()
    reg.set_renderfunc(TestRenderType, TestRenderType.renderfunc)
    reg.set_eightbit_call(TestRenderType)
    assert reg(42) == "42"



# Generated at 2022-06-24 04:58:38.550622
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    style1 = Style(RgbFg(1, 2, 3))
    style2 = Style(RgbFg(3, 2, 1))

    r1 = Register()

    r1.red = style1

    assert r1.red.rules == style1.rules

    r1.red = style2

    assert r1.red.rules == style2.rules

# Generated at 2022-06-24 04:58:45.764853
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.foo = Style(Sgr(1))
    r.baz = Style(Sgr(1), RgbFg(32,64,128))
    r.bar = Style(r.foo, RgbFg(10,20,30), r.baz)

    assert r.as_dict() == {"foo": "\x1b[1m", "baz": "\x1b[1m\x1b[38;2;32;64;128m", "bar": "\x1b[1m\x1b[38;2;10;20;30m\x1b[1m\x1b[38;2;32;64;128m"}


# Generated at 2022-06-24 04:58:51.212531
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert Style().rules == ()
    assert Style(1).rules == (1,)
    assert Style(1, 2).rules == (1, 2)
    assert Style(1, 2, "Hallo").value == "Hallo"


# Generated at 2022-06-24 04:58:53.684690
# Unit test for constructor of class Style
def test_Style():

    test_style = Style(RenderType(), RenderType())

    assert test_style.rules
    assert isinstance(test_style.rules, Iterable)



# Generated at 2022-06-24 04:59:03.637997
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    def f1(x: int) -> str:
        return f"\x1b[3{x}m"

    def f2(x: int) -> str:
        return f"\x1b[9{x}m"

    r = Register()
    r.set_renderfunc(RenderType, f1)
    r.set_eightbit_call(RenderType)

    assert r(42) == "\x1b[342m"

    r.set_renderfunc(RenderType, f2)
    r.set_eightbit_call(RenderType)

    assert r(42) == "\x1b[942m"



# Generated at 2022-06-24 04:59:15.248724
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .sty import sty

    sty.rs = Style(Sgr(0))

    sty.fg.red = Style(RgbFg(255, 0, 0))

    sty.bg.red = Style(RgbFg(255, 0, 0), Sgr(48))

    sty.ef.bold = Style(Sgr(1))

    sty.ef.bright = Style(Sgr(1), Sgr(38))

    dict1 = sty.fg.as_dict()

    assert len(dict1) == 1

    dict2 = sty.bg.as_dict()

    assert len(dict2) == 1

    dict3 = sty.ef.as_dict()

    assert len(dict3) == 2

    dict4 = sty.rs.as_dict()

   

# Generated at 2022-06-24 04:59:22.049814
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Fg(Register):
        pass

    fg: Fg = Fg()
    fg.renderfuncs = {
        object: lambda x: "test"
    }

    style_obj: Style = Style(object(42))

    # Assign new style object to a attribute "test".
    fg.test: Style = style_obj

    # Check if attribute has been assigned.
    assert hasattr(fg, "test")

    # Check if value of attribute is rendered style.
    assert fg.test == "test"

    # Check if value of attribute is still style object.
    assert isinstance(getattr(fg, "test"), Style)

    # Check if value of attribute is still style object and the same object.
    assert getattr(fg, "test") is style_obj

# Generated at 2022-06-24 04:59:25.232702
# Unit test for method unmute of class Register
def test_Register_unmute():

    from . import fg

    fg.unmute()

    assert fg.is_muted == False
    assert str(fg.red) == "\x1b[38;2;255;0;0m"

