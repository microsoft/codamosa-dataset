

# Generated at 2022-06-24 04:49:30.977249
# Unit test for constructor of class Style
def test_Style():
    class A(RenderType):
        DEFAULT = NamedTuple('A', [('myint', int)])

        def render(self) -> str:
            return "A"*self.myint
    class B(RenderType):
        def render(self) -> str:
            return "B"

    render_funcs = {A: lambda x: x.render(), B: lambda x: x.render()}

    s = Style(A(3), B())
    assert isinstance(s, str)
    assert isinstance(s, Style)

    assert s.rules == (A(3), B())
    assert s == "AAA"

    s = Style(A(3), B(), value="AAA")
    assert isinstance(s, str)
    assert isinstance(s, Style)


# Generated at 2022-06-24 04:49:35.710715
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r1 = Register()
    r1.red = Style(RgbFg(10, 10, 10))
    nt = r1.as_namedtuple()
    assert nt.red == "\x1b[38;2;10;10;10m"
    assert nt.green is None

if __name__ == "__main__":
    test_Register_as_namedtuple()

# Generated at 2022-06-24 04:49:42.490858
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.set_eightbit_call(RgbFg)
            self.set_rgb_call(RgbEf)

    reg = TestRegister()
    assert reg.eightbit_call == RgbFg  # type: ignore

    reg.set_rgb_call(RgbBg)
    assert reg.rgb_call == RgbBg  # type: ignore

    assert reg(10, 42, 255)  # type: ignore
    assert reg(144)

# Generated at 2022-06-24 04:49:52.892421
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertypes import *
    from .registers import *

    fg = Register()
    fg.renderfuncs.update({Sgr: lambda *args: "\x1b[3" + str(args[0]) + "m"})

    assert fg(1) == "\x1b[31m"
    assert fg(144) == "\x1b[31m"

    fg.set_eightbit_call(Sgr)
    assert fg(144) == "\x1b[31m"
    assert fg(255) == ""

    fg.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m")


# Generated at 2022-06-24 04:50:04.026355
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbBg, RgbFg, Sgr

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.test1 = Style(RgbFg(0, 0, 0))
            self.test2 = Style(RgbFg(0, 0, 0), Sgr(1))
            self.test3 = Style(RgbBg(0, 0, 0), Sgr(1))

    import sty

    sty.register_renderfuncs(sty.RenderType.EIGHTBIT, lambda x: f"Eightbit({x})")
    sty.register_renderfuncs(sty.RenderType.RGB, lambda r, g, b: f"Rgb({r},{g},{b})")

    test_register = TestRegister()
    test_register

# Generated at 2022-06-24 04:50:09.671713
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    renderfuncs = {}

    class TestRegister(Register):
        f1 = Style(RgbFg(0, 0, 0))
        f2 = Style(RgbFg(0, 0, 0))

        def __init__(self):
            super().__init__()
            self.renderfuncs = renderfuncs

    r = TestRegister()

    # assert isinstance(r.f1, Style)
    # assert isinstance(r.f2, Style)
    assert not hasattr(r, "f3")

    r.f3 = Style(RgbFg(0, 0, 0))
    # assert isinstance(r.f3, Style)

    r.f4 = "test"
    assert r.f4 == "test"


# Generated at 2022-06-24 04:50:15.063899
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg1(RenderType):
        def __init__(self, r, g, b):
            super().__init__(r, g, b)

    class SgrBold(RenderType):
        def __init__(self):
            super().__init__()

    class RgbFg2(RenderType):
        def __init__(self, r, g, b):
            super().__init__(r, g, b)

    class SgrDim(RenderType):
        def __init__(self):
            super().__init__()

    def fg_render_func1(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-24 04:50:16.584671
# Unit test for method copy of class Register
def test_Register_copy():
    """Test for method copy of class Register."""
    from sty import fg
    copy = fg.green.copy()
    assert str(copy) == str(fg.green)

# Generated at 2022-06-24 04:50:24.026777
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class CustomRegister(Register):
        def __init__(self):
            super().__init__()

            self.black = Style(RgbFg(0, 0, 0))
            self.white = Style(RgbFg(255, 255, 255))
            self.bla = "not a style"

    reg = CustomRegister()
    reg_dict = reg.as_dict()
    
    expected = {"black": "\x1b[38;2;0;0;0m", "white": "\x1b[38;2;255;255;255m"}
    assert reg_dict == expected



# Generated at 2022-06-24 04:50:25.231326
# Unit test for constructor of class Register
def test_Register():
    """
    Test if the constructor of Register works.
    """
    r = Register()

# Generated at 2022-06-24 04:50:35.390173
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        def render(self, r: int, g: int, b: int) -> str:
            return "render_rgb"

    class EightbitFg(RenderType):
        def render(self, code: int) -> str:
            return "render_eightbit"

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: "rgb")
    r.set_renderfunc(EightbitFg, lambda code: "eightbit")

    assert "rgb" == r(10, 20, 30)
    assert "eightbit" == r(42)



# Generated at 2022-06-24 04:50:43.137818
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    def r(r: int, g: int, b: int, bg: Union[str, int] = None) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    r1 = Register()
    r2 = r1.copy()

    r1.set_renderfunc(RenderType, r)
    r1.some_style = Style(RenderType(100,200,30))
    r1.some_other_style = Style(RenderType(120,240,60))

    assert r1.some_style != r1.some_other_style

    assert r1(100, 200, 30) == r1.some_style
    assert r1(120, 240, 60) == r1.some_other_style

    r1.set_rgb_call

# Generated at 2022-06-24 04:50:53.575165
# Unit test for method unmute of class Register
def test_Register_unmute():
    # Arrange
    test_register = Register()

    test_style = Style(
        RgbFg(1, 5, 10), # type: ignore
        Sgr(1), # type: ignore
    )

    # Act
    test_register.fg = test_style
    test_register.mute()
    test_register.unmute()

    # Assert
    actual = test_register.fg == test_style
    assert actual

    # Arrange
    test_register.mute()

    # Act
    test_register.fg = test_style
    test_register.unmute()

    # Assert
    actual = test_register.fg == test_style
    assert actual

# Generated at 2022-06-24 04:51:02.341059
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import RenderType
    from sty import fg, bg
    from sty import ef, rs

    def renderfunc(*args, **kwargs):
        return f"{args[0]}"

    class TestRenderType(RenderType):
        pass

    # Test mute()
    r = Register()
    r.set_eightbit_call(TestRenderType)
    r.set_renderfunc(TestRenderType, renderfunc)

    r.red = Style(TestRenderType(207))
    r.blue = Style(TestRenderType(68))

    assert r.red == f"207"
    assert r.blue == f"68"

    r.mute()
    assert r.red == ""
    assert r.blue == ""



# Generated at 2022-06-24 04:51:12.445523
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .ansi import fg, bg, ef
    from .ansi import rgb_fg  # noqa
    from .ansi import rgb_bg  # noqa

    fg.red = Style(fg.red.rules)
    fg.rgb_red = Style(rgb_fg(255, 0, 0).rules)

    # Mute
    fg2 = fg.copy()
    fg2.mute()
    fg.red == fg2.red # False
    fg2.red == "" # True
    fg.rgb_red == fg2.rgb_red # False
    fg2.rgb_red == "" # True

    # Unmute
    fg2.unmute()
    fg.red == fg2.red # True
    f

# Generated at 2022-06-24 04:51:19.195713
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class Bold(Sgr):
        args = 1

    class Italic(Sgr):
        args = 3

    def render_rgb_fg(r: int, g: int, b: int):
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    def render_rgb_bg(r: int, g: int, b: int):
        return "\x1b[48;2;{};{};{}m".format(r, g, b)

    def render_bold(x: int):
        return "\x1b[{}m".format(x)


# Generated at 2022-06-24 04:51:25.696721
# Unit test for method copy of class Register
def test_Register_copy():
    def renderfunc(value: int) -> str:
        return f"{self._rendertype.value}{value}m"

    # Create a dummy register and set a dummy renderfunc
    r = Register()
    r.set_renderfunc(RenderType.Reset, renderfunc)

    # Create a dummy style-attribute
    setattr(r, "style", "style")

    # Make a copy of the the dummy register
    r_copy = r.copy()

    # Test that the copy has the same style-attribute
    assert hasattr(r_copy, "style")

    # Test that the copy has the same renderfunc
    assert r_copy.renderfuncs[RenderType.Reset] == renderfunc

# Generated at 2022-06-24 04:51:34.898797
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This test validates the __setattr__-method of the class Register.
    """

    from .rendertype import RgbFg, RgbBg
    from .rendertype import Sgr, Reset

    r = Register()

    r.renderfuncs[RgbFg] = RgbFg.render_256
    r.renderfuncs[RgbBg] = RgbBg.render_256
    r.renderfuncs[Sgr] = Sgr.render
    r.renderfuncs[Reset] = Reset.render

    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r.blue = Style(RgbFg(0, 0, 255))

# Generated at 2022-06-24 04:51:43.063560
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class A(RenderType):
        pass

    class B(RenderType):
        pass

    f = lambda x: x
    g = lambda x: 10

    reg = Register()
    reg.eightbit_call = f
    reg.set_renderfunc(A, g)
    reg.set_eightbit_call(A)

    assert reg.eightbit_call(42) == 10

    assert reg.eightbit_call(42, 10) == 10



# Generated at 2022-06-24 04:51:46.188350
# Unit test for method __new__ of class Style
def test_Style___new__():
    s: Style = Style(RgbFg(10, 11, 12), Sgr(1))
    assert type(s) is Style
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;10;11;12m\x1b[1m"

# Generated at 2022-06-24 04:51:54.312722
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.set_renderfunc(RenderType, lambda: "Escape")
    r.set_eightbit_call(RenderType)

    r.aa = Style(RenderType(1), RenderType(2))
    r.bb = Style(r.aa)
    r.cc = r.aa

    r.mute()

    assert r.aa == ""
    assert r.bb == ""
    assert r.cc == ""
    assert r(12) == ""

# Generated at 2022-06-24 04:52:00.942844
# Unit test for method __call__ of class Register
def test_Register___call__():

    register = Register()
    register.eightbit_call = lambda x: "EightbitColor%s" % x
    register.rgb_call = lambda r, g, b: "RgbColor%s%s%s" % (r, g, b)

    res = register(10)
    assert res == "EightbitColor10"

    res = register(10, 20, 30)
    assert res == "RgbColor102030"

    res = register()
    assert res == ""



# Generated at 2022-06-24 04:52:09.273524
# Unit test for method copy of class Register
def test_Register_copy():

    from . import fg
    from .render import Sgr

    fg.red = Style(Sgr(31))

    fg_copy = fg.copy()

    assert fg.red == fg_copy.red
    assert fg.is_muted == fg_copy.is_muted
    assert fg.renderfuncs == fg_copy.renderfuncs
    assert id(fg) != id(fg_copy)

    fg_copy.eightbit_call = lambda x: x
    assert fg.eightbit_call != fg_copy.eightbit_call

# Generated at 2022-06-24 04:52:15.648381
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sty import ef
    name_tuple = ef.as_namedtuple()
    assert name_tuple.blink == ef.blink
    assert name_tuple.invisible == ef.invisible
    assert name_tuple.underlined == ef.underlined


# Generated at 2022-06-24 04:52:16.605471
# Unit test for constructor of class Register
def test_Register():

    r = Register()

    assert r.is_muted is False


# Generated at 2022-06-24 04:52:26.037102
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Ensure Register.unmute() works as expected.
    """

    from .render import apply_rendertype

    r = Register()
    setattr(r, "bold", Style("bold"))
    setattr(r, "test", Style("test"))
    r.set_renderfunc(RenderType.SGR, apply_rendertype)
    r.mute()

    assert r.is_muted
    assert r.bold == ""
    assert r.test == ""

    r.unmute()

    assert not r.is_muted
    assert r.bold == "\x1b[1m"
    assert r.test == "\x1b[1m"

# Generated at 2022-06-24 04:52:33.662612
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted is False
    assert r.eightbit_call(1) == 1
    assert r.rgb_call(0, 1, 2) == (0, 1, 2)
    assert r(1) == 1
    assert r(0, 1, 2) == (0, 1, 2)
    assert r('test') == ''
    assert r() == ''
    assert r(1, 2, 3, 4) == ''


# Generated at 2022-06-24 04:52:40.001738
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import sty

    fg = Register()
    fg.set_renderfunc(sty.RgbFg, lambda r, g, b: (r, g, b))

    fg.set_rgb_call(sty.RgbFg)

    assert fg.rgb_call(15, 20, 255) == (15, 20, 255)



# Generated at 2022-06-24 04:52:44.481891
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from . import fg

    nt = fg.as_namedtuple()

    assert(isinstance(nt.blue, Style))
    assert(isinstance(nt.red, Style))
    assert(isinstance(nt.green, Style))
    assert(isinstance(nt.black, Style))
    assert(nt.black == "")
    assert(nt.blue == fg(12))

# Generated at 2022-06-24 04:52:53.197402
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    renderfuncs: Renderfuncs = {}
    register = Register()
    register.set_renderfunc(RenderType.Sgr, lambda x: x)
    register.set_renderfunc(RenderType.Bg, lambda x: x)
    register.set_renderfunc(RenderType.Reset, lambda x: x)

    # Test setting a new rendertype
    register.set_eightbit_call(RenderType.Reset)
    assert register.eightbit_call == register.renderfuncs[RenderType.Reset]

    # Test with unknown rendertype
    try:
        register.set_eightbit_call(RenderType.Unknown)
    except KeyError:
        assert(True)



# Generated at 2022-06-24 04:52:56.715109
# Unit test for method __new__ of class Style
def test_Style___new__():
    r1 = RenderType(20)
    r2 = RenderType(0)
    s1 = Style(r1, r2)
    s2 = Style(r1, r2, value="")
    assert s1 == s2

# Generated at 2022-06-24 04:53:00.285766
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.renderfuncs = {str: lambda x: x}
    s1 = Style(value="hello", rules=[])
    setattr(r1, "s1", s1)
    r2 = r1.copy()
    assert r1.__dict__ == r2.__dict__

# Generated at 2022-06-24 04:53:05.819254
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestClass:
        # Make some dummy render types to test with
        class Type1(RenderType): pass
        class Type2(RenderType): pass
        class Type3(RenderType): pass

        r = Register()
        r.set_eightbit_call(Type1)
        r.set_rgb_call(Type2)

        def test_init(self):
            assert len(self.r.renderfuncs.keys()) == 0
            assert self.r.eightbit_call == self.r.renderfuncs[TestClass.Type1]
            assert self.r.rgb_call == self.r.renderfuncs[TestClass.Type2]
            assert self.r.is_muted is False


# Generated at 2022-06-24 04:53:07.109775
# Unit test for constructor of class Style
def test_Style():
    """
    >>> Style(Sty.reset)
    Style(Sty.reset, value='\x1b[0m')
    """
    pass



# Generated at 2022-06-24 04:53:09.165419
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.value = "8b"

    assert r(42) == "8b"

    r.set_eightbit_call(RgbFg)
    assert r(255, 255, 255) == "8b"

    r.set_rgb_call(RgbFg)
    assert r(42) == "8b"



# Generated at 2022-06-24 04:53:14.725491
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    bg = Register()
    bg.set_renderfunc(AnsiBg, lambda x: "a")
    assert bg.renderfuncs[AnsiBg]("x") == "a"


# Generated at 2022-06-24 04:53:17.468761
# Unit test for constructor of class Register
def test_Register():
    r = Register()

# Generated at 2022-06-24 04:53:19.216948
# Unit test for method unmute of class Register
def test_Register_unmute():
    register = Register()
    register.unmute()
    assert register.is_muted == False


# Generated at 2022-06-24 04:53:30.387088
# Unit test for method mute of class Register
def test_Register_mute():

    ###########################################
    # Testing decorator on other functions

    def test_decorator(func):
        def inner(*args, **kwargs):
            return func(*args, **kwargs) + " decorated"
        return inner

    @test_decorator
    def test1(a: str) -> str:
        return a

    assert test1("hallo") == "hallo decorated"

    ###########################################
    # Testing stacking of render-functions

    class Foo(RenderType):
        pass

    class Bar(RenderType):
        pass

    class FooBar(RenderType):
        pass

    # Define render-functions
    def test_renderfunc_foo(a: float) -> str:
        return "Foo({})".format(a)


# Generated at 2022-06-24 04:53:33.411835
# Unit test for method unmute of class Register
def test_Register_unmute():
    from . import fg

    assert fg.red == "\x1b[38;2;255;0;0m"

    fg.mute()
    assert fg.red == "\x1b[38;2;255;0;0m"

    fg.unmute()
    assert fg.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:53:41.202361
# Unit test for constructor of class Style
def test_Style():
    import pytest
    from sty.rendertypes import RgbFg, Sgr
    s1 = Style(RgbFg(1,2,3), Sgr(1))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1 == '\x1b[38;2;1;2;3m\x1b[1m'
    with pytest.raises(ValueError, match='must be of type Iterable'):
        Style(1)
    with pytest.raises(ValueError, match='must be of type Iterable'):
        Style(1,2)


# Generated at 2022-06-24 04:53:51.870424
# Unit test for method __call__ of class Register
def test_Register___call__():

    """ Test the __call__ method of Register class. """

    def f8(x: int) -> str:
        return str(x)

    def f24(r: int, g: int, b: int) -> str:
        return str(r) + str(g) + str(b)

    r = Register()
    r.set_renderfunc(int, f8)
    r.set_eightbit_call(int)
    r.set_renderfunc(RgbFg, f24)
    r.set_rgb_call(RgbFg)
    r.setattr("red", Style(int(255)))

    assert r(255) == "255"
    assert r(10, 20, 30) == "102030"
    assert r("red") == "255"



# Generated at 2022-06-24 04:54:01.423924
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test case for method set_rgb_call of class Register
    """

    from sty import fg, bg, ef, rs

    fg.rgb_call(10, 42, 255)
    bg.rgb_call(10, 42, 255)
    ef.rgb_call(10, 42, 255)
    rs.rgb_call(10, 42, 255)

    # Original functions

    assert fg.rgb_call == fg.rgb
    assert bg.rgb_call == bg.rgb
    assert ef.rgb_call == ef.rgb
    assert rs.rgb_call == rs.rgb

    # Change rendertype and confirm change

    from sty.ansiformat import RgbBg


# Generated at 2022-06-24 04:54:13.291893
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import pytest
    from .rendertype import RgbBg, RgbFg
    from .sty import Sty

    # Use register object with custom rendertype.
    sty = Sty(inline=True)
    sty.configure(fg=RgbFg, bg=RgbBg)

    # Create empty register object.
    register = Register()

    # Register object should not have a renderfunc for RgbFg.
    with pytest.raises(Exception):
        register.rgb_call(0, 0, 0)

    # Register object should not have a renderfunc for RgbBg.
    with pytest.raises(Exception):
        register.rgb_call(0, 0, 0)

    # Set renderfuncs for RgbFg and RgbBg.

# Generated at 2022-06-24 04:54:17.989651
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    setattr(register, "a", Style(RenderType()))
    setattr(register, "b", Style(RenderType()))
    setattr(register, "c", Style(RenderType()))
    setattr(register, "d", Style(RenderType()))
    setattr(register, "e", Style(RenderType()))
    assert register.as_dict() == {"a": "", "b": "", "c": "", "d": "", "e": ""}



# Generated at 2022-06-24 04:54:24.504202
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.set_eightbit_call(RenderType)
    setattr(r, "hans", Style(RenderType(42)))
    r.mute()

    assert r.is_muted == True
    assert r.hans == ""


# Generated at 2022-06-24 04:54:34.724928
# Unit test for constructor of class Style
def test_Style():
    from .render import RgbBg, RgbFg, Sgr

    # Initialize a style with one render-type
    s1 = Style(RgbBg(42, 42, 42))
    assert str(s1) == "\x1b[48;2;42;42;42m"
    assert s1.rules == (RgbBg(42, 42, 42),)

    # Initialize a style with two render-types
    s2 = Style(RgbBg(42, 42, 42), RgbFg(42, 42, 42))
    assert str(s2) == "\x1b[48;2;42;42;42m\x1b[38;2;42;42;42m"

# Generated at 2022-06-24 04:54:40.484205
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg

    assert fg.as_dict() == {"black": "\x1b[30m", "red": "\x1b[31m"}

    fg.black = Style(RgbFg(255, 255, 255))

    assert fg.as_dict() == {"black": "\x1b[38;2;255;255;255m", "red": "\x1b[31m"}



# Generated at 2022-06-24 04:54:48.231334
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbEf, RgbFg, RgbBg

    fg = Register()

    # - Given
    fg.red = Style(RgbFg(255, 0, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    fg.set_eightbit_call(RgbFg)
    fg.set_rgb_call(RgbEf)

    # - When
    # I call just one color 46 (which is blue)
    fg(46)
    # -- Then
    # I expect a blue foreground.
    assert fg.blue == "\x1b[38;2;0;0;255m"

    # - When
    # I call three colors 255, 0, 0
    fg(255, 0, 0)


# Generated at 2022-06-24 04:54:57.337033
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test whether method `set_eightbit_call` works.
    """

    def render_func1(color_number: int) -> str:
        return (f"render_func1::{color_number}")

    def render_func2(color_number: int, *args) -> str:
        return (f"render_func2::{color_number}")

    class RenderType1(RenderType):
        def __init__(self, color_number: int):
            self.color_number = color_number
            self.args = (color_number,)

    class RenderType2(RenderType):
        def __init__(self, color_number: int, *args):
            self.color_number = color_number
            self.args = (color_number,)

    reg = Register()
    reg.set

# Generated at 2022-06-24 04:55:07.552991
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test for method copy of class Register.
    """

    from .rendertype import Color, RgbFg, Sgr

    r = Register()
    r.set_eightbit_call(Color)
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")

    r.green = Style(Color(32), Sgr(1))
    r.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    r2 = r.copy()

    assert r.orange == r2.orange
    assert r.green == r2.green

    assert r.eightbit_call == r2.eightbit_call
    assert r.rgb_call == r2.rgb_call

# Generated at 2022-06-24 04:55:16.335602
# Unit test for method unmute of class Register
def test_Register_unmute():
    import sty
    import random
    import operator
    import os

    save_sgr0 = os.environ.get("STY_SGR0", "\x1b[0m")

    # Here we create a register with four non-empty styles
    r1 = sty.Register()
    r1.set_renderfunc(sty.Sgr, operator.mod)
    r1.red = sty.Style(sty.Sgr(1), sty.RgbFg(1, 0, 0))
    r1.blue = sty.Style(sty.Sgr(1), sty.RgbFg(0, 0, 1))
    r1.green = sty.Style(sty.Sgr(1), sty.RgbFg(0, 1, 0))

# Generated at 2022-06-24 04:55:23.867294
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Define new rendertype
    class Dummy1(RenderType): pass

    # Define render-function for Dummy1
    def dummy1(cls, *args):
        return "dummy1"

    # Create new register
    reg = Register()

    # Add render-function for Dummy1
    reg.set_renderfunc(Dummy1, dummy1)

    # Set Dummy1 as new rendertype for RGB-calls
    reg.set_rgb_call(Dummy1)

    # Check if RGB-call of new rendertype works
    assert reg(1, 2, 3) == "dummy1"



# Generated at 2022-06-24 04:55:28.316271
# Unit test for method copy of class Register
def test_Register_copy():

    r1 = Register()

    r1.renderfuncs = {"a": 42}

    r1.is_muted = False
    r1.set_eightbit_call(RenderType)
    r1.set_rgb_call(RenderType)

    r2 = r1.copy()

    assert r1.renderfuncs == r2.renderfuncs

    assert r1.is_muted is False
    assert r2.is_muted is False



# Generated at 2022-06-24 04:55:36.681964
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register()
    reg.set_renderfunc(RenderType.RgbBg, lambda *x: '\x1b[48;2' + str(x) + 'm')
    reg.blue = Style(RenderType.RgbBg(1,2,3))
    reg2 = reg.copy()
    reg2.blue = Style(RenderType.RgbBg(4,5,6))
    assert reg.blue == '\x1b[48;2(1, 2, 3)m'
    assert reg2.blue == '\x1b[48;2(4, 5, 6)m'
    assert reg.renderfuncs == reg2.renderfuncs

# Generated at 2022-06-24 04:55:47.352065
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Create and use a custom register.
    """

    class CustomRegister(Register):  # type: ignore
        """
        IMPORTANT: The class that is inheriting from Register must
        have the attribute 'rules'. This class is used as a placeholder.
        """

        # These are the rules that are used to create the final ANSI-sequences
        # in the Style-objects.
        rules = []

    # Create register object
    custom_register = CustomRegister()

    # Add render-functions
    custom_register.set_renderfunc(Bold, lambda x: "B")
    custom_register.set_renderfunc(Italic, lambda x: "I")

    # Create styles
    custom_register.bold_italic = Style(Bold(), Italic())

# Generated at 2022-06-24 04:55:50.831593
# Unit test for method __new__ of class Style
def test_Style___new__():

    class Foo: pass
    s = Style(Foo(), value="foo")

    assert isinstance(s, str)
    assert isinstance(s, Style)
    assert s.rules == (Foo(),)
    assert isinstance(s.rules[0], Foo)
    assert str(s) == "foo"


# Generated at 2022-06-24 04:56:02.179935
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test if the attribute `rules` of a Style-object can be correctly updated when calling
    the method set_renderfunc.
    """

    class TestRenderType(RenderType):
        pass

    class TestClass(Register):
        pass

    # Define a new rendertype and a corresponding renderfunction.
    test_rendertype = TestRenderType()
    renderfunc = lambda fg: "\x1b[38;2;{};{};{}m".format(fg.r, fg.g, fg.b)

    # Set renderfunc for TestClass
    TestClass.set_renderfunc(TestClass, test_rendertype, renderfunc)

    # Create an object from TestClass and store it as a style attribute.
    test_class = TestClass()

# Generated at 2022-06-24 04:56:11.928643
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    import textwrap
    from sty import fg, rs
    from sty.ansitowin32 import Sgr as Sgr32
    import pytest

    print("\n" + textwrap.dedent("""

        Testing:
            - method set_eightbit_call of class Register
            - setattr of class Register

    """))

    def func(n):
        return '\x1b[{}m'.format(n)

    fg.set_eightbit_call(Sgr32)
    fg.set_renderfunc(Sgr32, func)

    fg(42)

    with pytest.raises(AttributeError) as excinfo:
        assert fg("red") == "Fail"
    excinfo.match("'str' object has no attribute '_red'")



# Generated at 2022-06-24 04:56:21.134329
# Unit test for method mute of class Register
def test_Register_mute():

    r = Register()
    r.test_nothing = Style(value="test")
    r.test_mute = Style(value="test2")
    r.test_mute_after_mute = Style(value="test3")

    assert r.test_nothing == "test"
    assert r.test_mute == "test2"
    assert r.test_mute_after_mute == "test3"

    r.mute()
    assert r.test_nothing == "test"
    assert r.test_mute == ""
    assert r.test_mute_after_mute == ""

    r.test_mute_after_mute = Style(value="test3")
    assert r.test_mute_after_mute == ""

    r.unmute()
    assert r.test_

# Generated at 2022-06-24 04:56:31.871746
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import fg, bg

    a = fg.red
    b = bg.red

    assert a == "\x1b[31m"
    assert b == "\x1b[41m"

    fg.set_rgb_call(bg.RgbBg)
    bg.set_rgb_call(fg.RgbFg)

    assert a == "\x1b[41m"
    assert b == "\x1b[31m"

    a = fg.red
    b = bg.red

    assert a == "\x1b[41m"
    assert b == "\x1b[31m"



# Generated at 2022-06-24 04:56:39.319189
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .ansi import fg, bg

    style_register = fg.red  # type: ignore
    style_register_2 = bg.blue  # type: ignore
    test_namedtuple = style_register.as_namedtuple()
    test_namedtuple_2 = style_register_2.as_namedtuple()
    assert test_namedtuple.red == '\x1b[31m'
    assert test_namedtuple_2.blue == '\x1b[44m'


# Generated at 2022-06-24 04:56:48.244203
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class Foo(RenderType):
        def render(self, r, g, b):
            return f"{r} {g} {b}"

    def foo(r, g, b):
        return f"{r} {g} {b}"

    r = Register()

    r.set_renderfunc(Foo, foo)

    r.set_rgb_call(Foo)

    assert r(32, 16, 1) == "32 16 1"

    class Bar(RenderType):
        def render(self, r, g, b):
            return f"{r} {g} {b}"

    def bar(r, g, b):
        return f"{r} {g} {b}"

    r.set_renderfunc(Bar, bar)

    r.set_rgb_call(Bar)


# Generated at 2022-06-24 04:56:54.602652
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.renderfuncs == {}, "Renderfuncs does not exist, or is not initialized as empty dict."
    assert reg.is_muted == False, "Mute flag is not initialized at False."

# Generated at 2022-06-24 04:56:59.428974
# Unit test for constructor of class Register
def test_Register():
    """
    Test the constructor of class Register.
    """
    r: Register = Register()
    assert r.renderfuncs == {}
    assert r.is_muted is False

# Generated at 2022-06-24 04:57:04.779255
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test method set_renderfunc of class Register.
    """
    def dummy_func(*args, **kwargs) -> str:
        return "dummy"

    # Setup Register
    r1 = Register()
    r1.register1 = Style(
        RgbFg(10, 20, 30),
        RgbBg(40, 50, 60),
        Sgr(3),
        Sgr(4),
        Sgr(5),
        Sgr(6),
        Sgr(7),
        Sgr(8),
    )
    r1.register2 = Style(
        RgbFg(10, 20, 30),
        EightbitFg(74),
        Sgr(1),
        EightbitBg(104),
        Sgr(2),
    )

    # Create expected strings with dummy

# Generated at 2022-06-24 04:57:15.162727
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import bg
    t = bg.as_namedtuple()
    assert hasattr(t, "black")
    assert hasattr(t, "blue")
    assert hasattr(t, "bright_black")
    assert hasattr(t, "bright_blue")
    assert hasattr(t, "bright_cyan")
    assert hasattr(t, "bright_green")
    assert hasattr(t, "bright_magenta")
    assert hasattr(t, "bright_red")
    assert hasattr(t, "bright_white")
    assert hasattr(t, "bright_yellow")
    assert hasattr(t, "cyan")
    assert hasattr(t, "green")
    assert hasattr(t, "magenta")
    assert hasattr(t, "red")

# Generated at 2022-06-24 04:57:18.616965
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.red = Style(RgbFg(255, 0, 0))
    r2 = r1.copy()
    assert r2.red == r1.red
    r1.red = Style(RgbFg(0, 0, 255))
    assert r2.red != r1.red

# Generated at 2022-06-24 04:57:27.366787
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Create new Register-object for testing.
    r = Register()

    # Define new render-type for testing.
    class TestRenderType1(RenderType):
        pass

    # Define new render-type for testing.
    class TestRenderType2(RenderType):
        pass

    # Define new render function for testing.
    def test_renderfunc1(a):
        return "Renderfunc1"

    # Define new render function for testing.
    def test_renderfunc2(a, b):
        return "Renderfunc2"

    # Add new render-type and render-function to our test object.
    r.set_renderfunc(TestRenderType1, test_renderfunc1)

    # Add new render-type and render-function to our test object.

# Generated at 2022-06-24 04:57:31.257734
# Unit test for method mute of class Register
def test_Register_mute():
    from .term256 import fg

    fg.blue.value: str = "\x1b[38;5;21m"
    fg.mute()
    assert fg.blue.value == ""
    fg.unmute()
    assert fg.blue.value == "\x1b[38;5;21m"

# Generated at 2022-06-24 04:57:42.115495
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Mute:
        def __init__(self):
            self.is_muted = True

        def mute(self):
            self.is_muted = True

        def unmute(self):
            self.is_muted = False

    class Renderable:

        rule: bool

        args: str

        def render_rule(self):
            self.args = "foo"
            self.rule = False
            return "bar"

        def render_style(self):
            self.args = "foo"
            self.rule = True
            return "bar"

        @property
        def style(self) -> "Style":
            return Style(Renderable())

    r: Renderable = Renderable()

    assert r.rule
    assert r.args == ""

    r.rule = Renderable.render_rule(r)

# Generated at 2022-06-24 04:57:49.520839
# Unit test for method mute of class Register
def test_Register_mute():

    from . import rendertype
    from .tty import render_to_tty

    fg = Register()
    fg.set_renderfunc(rendertype.SgrFg, render_to_tty(rendertype.SgrFg))

    fg.yellow = Style(fg=rendertype.SgrFg(3))

    assert str(fg.yellow) == "\x1b[33m"

    fg.mute()

    assert str(fg.yellow) == ""

    fg.unmute()

    assert str(fg.yellow) == "\x1b[33m"

# Generated at 2022-06-24 04:57:55.340633
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Unit test for method as_dict of class Register
    """
    class MyRegister(Register):
        blue = Style(RgbFg(0, 0, 255))
        red = Style(RgbFg(255, 0, 0))
        green = Style(RgbFg(0, 255, 0))
        yellow = Style(RgbFg(255, 255, 0))

    mr = MyRegister()
    mr2 = mr.copy()

    assert mr.as_dict() == mr2.as_dict()

    assert mr2.blue == "\x1b[38;2;0;0;255m"
    assert mr2.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:58:00.050908
# Unit test for method __new__ of class Style
def test_Style___new__():

    class Tmp(RenderType):
        args = [1, 2, 3]

    class Tmp2(RenderType):
        args = [3, 4, 5]

    x = Style(Tmp())
    assert x.rules == (Tmp(),)

    x = Style(Tmp(), Tmp2())
    assert list(x.rules) == [Tmp(), Tmp2()]

# Generated at 2022-06-24 04:58:02.695424
# Unit test for constructor of class Register
def test_Register():

    r1 = Register()
    r1.set_renderfunc(str, lambda s: s)
    r1.name = Style("", "Hello World")

    assert str(r1.name) == "Hello World"



# Generated at 2022-06-24 04:58:11.143636
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    import tempfile
    with open(tempfile.NamedTemporaryFile(delete=False).name, mode="w") as f:
        f.write("test_Register_set_renderfunc_ok")

    class TestType(RenderType):
        pass

    def render_func(test_type_instance):
        return "test_Register_set_renderfunc_ok"

    r = Register()
    r.set_renderfunc(TestType, render_func)
    r.test = Style(TestType())
    assert str(r.test) == "test_Register_set_renderfunc_ok"



# Generated at 2022-06-24 04:58:18.058435
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import (
        AnsiBg,
        AnsiFg,
        RgbBg,
        RgbFg,
        Sgr,
    )

    class TestRegister(Register):
        white = Style(AnsiFg(15))
        black = Style(AnsiBg(1))
        bold = Style(Sgr(1))

    r = TestRegister()
    r.set_renderfunc(RgbFg, lambda x, y, z: f"{x}|{y}|{z}")
    r.set_rgb_call(RgbFg)

    assert r(255, 255, 255) == "255|255|255"



# Generated at 2022-06-24 04:58:29.043307
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MyRegister(Register):
        pass

    my_register = MyRegister()

    class RenderTypeA(RenderType):
        pass

    class RenderTypeB(RenderType):
        pass

    assert len(my_register.renderfuncs) == 0

    my_register.set_renderfunc(RenderTypeA, lambda: "A")
    my_register.set_renderfunc(RenderTypeB, lambda: "B")

    assert len(my_register.renderfuncs) == 2

    my_register.my_red = Style(
        RenderTypeA(1), RenderTypeA(2), RenderTypeB(3), RenderTypeA(4)
    )

    assert str(my_register.my_red) == "ABAA"

    my_register.set_renderfunc(RenderTypeA, lambda x: str(x))


# Generated at 2022-06-24 04:58:39.151745
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class RGB(RenderType):
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b

    def renderfunc_one(r, g, b):
        return f"{r},{g},{b}"

    r = Register()
    r.set_renderfunc(RGB, renderfunc_one)
    r.red = Style(RGB(10, 20, 30))
    r.green = Style(RGB(20, 30, 40))
    r.blue = Style(RGB(30, 40, 50))

    nt = r.as_namedtuple()

    assert(nt.red == "10,20,30")
    assert(nt.green == "20,30,40")
    assert(nt.blue == "30,40,50")

# Generated at 2022-06-24 04:58:46.659598
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRegister(Register):
        pass

    test_reg = TestRegister()

    def _renderfunc(rendertype: RenderType) -> str:
        return f"{rendertype.__class__.__name__}-{rendertype.args[0]}"

    @RenderType.register
    class TestRenderType(RenderType):
        pass

    test_reg.set_renderfunc(TestRenderType, _renderfunc)
    test_reg.set_eightbit_call(TestRenderType)

    assert not hasattr(test_reg, "tenbit")
    assert test_reg(10) == "TestRenderType-10"

    test_reg.set_eightbit_call(TestRenderType)
    assert test_reg(25) == "TestRenderType-25"

# Generated at 2022-06-24 04:58:55.951185
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    r = Register()

    # Create test-rendertype
    class R1(RenderType):
        args: Tuple[int]

        def __init__(self, *args: int) -> None:
            super().__init__(args)

        @classmethod
        def ansi_string(cls, *args: int) -> str:
            return str(args[0])

    # Create test-renderfunc
    def r1(*args: int) -> str:
        return str(args[0])

    # Set renderfunc on register-object
    r.set_renderfunc(R1, r1)

    # Test if renderfunc changed
    assert r.renderfuncs.get(R1) == r1

    # Test if this renderfunc is used for style
    r.a = Style(R1(1))


# Generated at 2022-06-24 04:58:56.732666
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    pass

# Generated at 2022-06-24 04:59:05.291127
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr, RgbFg

    register_name = "foo"
    r = Register()

    setattr(r, register_name, Style(Sgr(1)))

    # check that unmute is invoked
    assert r.is_muted == False

    # mute the register
    r.mute()

    # check that mute is invoked
    assert r.is_muted == True

    # unmute the register
    r.unmute()

    # check that unmute is invoked
    assert r.is_muted == False

    # check that unmute returns former color
    assert getattr(r, register_name) == "\x1b[1m"



# Generated at 2022-06-24 04:59:06.528136
# Unit test for method unmute of class Register
def test_Register_unmute():
    raise NotImplementedError()



# Generated at 2022-06-24 04:59:16.693932
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Ensure a deepcopy of a register is fully independent.
    """
    # Setup
    r1 = Register()
    r1.is_muted = True

    r1.set_renderfunc(RenderType.SGR, lambda x: f"\x1b[{x}m")
    r1.color1 = Style(RenderType.SGR(42))

    r2 = r1.copy()
    r3 = r1.copy()

    # Test
    assert r1.is_muted == r2.is_muted

    r2.color2 = Style(RenderType.SGR(1))
    assert hasattr(r1, "color2") is False

    r1.is_muted = False
    assert r3.is_muted is True

    # Teardown
    del r1


# Generated at 2022-06-24 04:59:23.571961
# Unit test for method mute of class Register
def test_Register_mute():
    test1 = Register()
    test1.test = Style("test", fg=1)
    test2 = test1.copy()
    assert test1.is_muted == False
    assert test2.is_muted == False
    assert test1.test == "\u001b[38;5;1mtest"
    assert test2.test == "\u001b[38;5;1mtest"
    test1.mute()
    assert test1.is_muted == True
    assert test2.is_muted == False
    assert test1.test == "test"
    assert test2.test == "\u001b[38;5;1mtest"
    test1.unmute()
    assert test1.is_muted == False
    assert test2.is_muted == False
    assert test