

# Generated at 2022-06-24 04:49:31.962477
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Method set_renderfunc of class Register
    """
    from .rendertype import RgbFg, Sgr
    from .renderfunc import render_sgr, render_rgb_fg

    r: Register = Register()

    # Create class attribute with style
    setattr(r, "red", Style(RgbFg(255, 0, 0), Sgr(1)))

    # Check if it has the right value
    assert str(r.red) == '\x1b[38;2;255;0;0m\x1b[1m'

    # Define renderfunction for Sgr-rendertype
    r.set_renderfunc(rendertype=Sgr, func=lambda *args: "")

    # Check if value has changed

# Generated at 2022-06-24 04:49:33.320532
# Unit test for constructor of class Register
def test_Register():

    register = Register()

    assert isinstance(register, Register)



# Generated at 2022-06-24 04:49:34.430877
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False



# Generated at 2022-06-24 04:49:40.335048
# Unit test for method copy of class Register
def test_Register_copy():

    class TestRegister(Register):
        pass

    fg = TestRegister()
    fg.black = Style(RgbFg(255, 255, 255))
    fg.white = Style(RgbFg(0, 0, 0))

    # Use a copy of fg
    fg_copy = fg.copy()

    # Mute the copy.
    fg.mute()

    fg.as_dict() == fg_copy.as_dict()
    fg.as_namedtuple() == fg_copy.as_namedtuple()

# Generated at 2022-06-24 04:49:44.772298
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg, bg, Style

    CustomRegister = Register()
    CustomRegister.brown = Style(fg.brown, bg.blue)
    CustomRegister.red = Style(bg.red)

    assert CustomRegister.as_dict() == ModuleType.as_dict()


# Generated at 2022-06-24 04:49:45.371999
# Unit test for constructor of class Register
def test_Register():
    Register()

# Generated at 2022-06-24 04:49:54.348884
# Unit test for method __call__ of class Register
def test_Register___call__():
    def _test_eightbit_call(x):
        return "Eightbit-call: " + str(x)

    def _test_rgb_call(r, g, b):
        return "Rgb-call: " + str(r) + "," + str(g) + "," + str(b)

    def _test_string_call(name: str):
        return "String-call: " + name

    reg = Register()
    setattr(reg, "test", Style())

    reg.set_eightbit_call(RenderType)
    reg.set_renderfunc(RenderType, _test_eightbit_call)
    assert reg(1) == "Eightbit-call: 1"

    reg.set_rgb_call(RenderType)

# Generated at 2022-06-24 04:50:04.982413
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import Eightbit, RGB, SGR

    # Create an object of the class Register
    fg = Register()
    # Add some renderfuncs to the object.
    fg.set_renderfunc(Eightbit, lambda x: "eightbit")
    fg.set_renderfunc(RGB, lambda c, r, b: "rgb")
    fg.set_renderfunc(SGR, lambda x: "sgr")


# Generated at 2022-06-24 04:50:11.442082
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()

    register.black = Style(RgbFg(0, 0, 0))
    register.white = Style(RgbFg(255, 255, 255))

    assert register.black == register.as_namedtuple().black
    assert register.white == register.as_namedtuple().white

# Generated at 2022-06-24 04:50:17.039793
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertypes import RgbFg, Sgr

    # Setup registers and dummy renderfunctions
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join([str(a) for a in args])}m")

    r.red = Style(RgbFg(255, 0, 0))
    r.bold = Style(Sgr(1))
    r.bold_red = Style(RgbFg(255, 0, 0), Sgr(1))

    d: Dict[str, str] = r.as_dict()

# Generated at 2022-06-24 04:50:26.572729
# Unit test for method __call__ of class Register
def test_Register___call__():

    # We need an instance to test this method.
    instance = Register()

    # Ensure that an empty string is returned if no renderfuncs and styles are present.
    assert instance() == ""

    # Set some renderfuncs and styles to test the method.
    instance.renderfuncs = {int: lambda *args: f"{args[0] * 2}-func-run"}
    instance.red = Style(value="red", rules=[])

    assert instance() == ""  # Test with no arguments.
    assert instance(1) == "2-func-run"  # Test with single argument of type int.
    assert instance(10, 20, 30) == ""  # Test with three arguments.
    assert instance("red") == "red"  # Test with single argument of type str.

# Generated at 2022-06-24 04:50:34.384746
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Func1(RenderType):
        def __init__(self, x: int):
            self.args = (x,)

    class Func2(RenderType):
        def __init__(self, x: int, y: float):
            self.args = (x, y)

    func1: Callable = lambda x: f"Renderfunc1: {x}"
    func2: Callable = lambda x, y: f"Renderfunc2: {x}/{y}"

    register: Register = Register()

    register.set_renderfunc(Func1, func1)
    register.set_renderfunc(Func2, func2)

    style1: Style = Style(Func1(15))
    style2: Style = Style(Func2(15, 43.3))


# Generated at 2022-06-24 04:50:42.422792
# Unit test for constructor of class Style

# Generated at 2022-06-24 04:50:49.710899
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, bg
    from sty.ansi import RgbBg

    r = Register()
    r.set_renderfunc(RgbBg, lambda *args: "blub")
    r.set_rgb_call(RgbBg)

    assert r(42) == ""
    assert r(102, 49, 42) == "blub"
    assert r(bg=42) == ""


# Generated at 2022-06-24 04:50:57.357176
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty import fg

    assert isinstance(fg.red, Style)

    assert isinstance(fg.red, str)

    assert str(fg.red) == "\x1b[38;2;255;0;0m"

    # If you want to inspect the original parameters that were used to create a
    # Style object, you can access them via the 'rules' attribute.

    assert fg.red.rules == (RgbFg(255, 0, 0),)

    assert fg.orange.rules == (RgbFg(1, 5, 10), Sgr(1))



# Generated at 2022-06-24 04:51:05.705561
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .sgr import Sgr
    from .rgb import RgbEscape

    # Create a new Register
    buf: Register = Register()
    # Add the render-functions for the redertypes
    buf.renderfuncs.update({Sgr: Sgr.render, RgbEscape: RgbEscape.render})
    # Create new styles for the register
    buf.black = Style(Sgr(0), RgbEscape(0, 0, 0))
    buf.red = Style(Sgr(1), RgbEscape(255, 0, 0))
    buf.green = Style(Sgr(1), RgbEscape(0, 255, 0))
    buf.yellow = Style(Sgr(1), RgbEscape(255, 255, 0))

# Generated at 2022-06-24 04:51:10.660841
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 2, 3), Sgr(1))

    assert style == str(style)
    assert isinstance(style, str)
    assert len(style.rules) == 2


# Generated at 2022-06-24 04:51:18.657837
# Unit test for method __call__ of class Register
def test_Register___call__():

    class DummyRenderType(RenderType):

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    class DummyRegister(Register):

        def __init__(self):
            super().__init__()
            self.renderfuncs.update({DummyRenderType: lambda *a, **kw: None})

    eightbit_call = lambda *a, **kw: (a, kw)
    rgb_call = lambda *a, **kw: (a, kw)

    dummy_register = DummyRegister()
    dummy_register.set_eightbit_call(DummyRenderType)
    dummy_register.set_rgb_call(DummyRenderType)


# Generated at 2022-06-24 04:51:19.614315
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    assert isinstance(register, Register)

# Generated at 2022-06-24 04:51:24.949238
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()

    r.red = "bla"
    r.green = "blu"
    r._renderfuncs = {"Bla": lambda x: x}

    assert r.as_dict() == {"red": "bla", "green": "blu"}


# Generated at 2022-06-24 04:51:28.541295
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .register import fg
    fg.is_muted = True
    assert fg.is_muted == True
    fg.unmute()
    assert fg.is_muted == False

# Generated at 2022-06-24 04:51:32.592846
# Unit test for constructor of class Style
def test_Style():
    # Type checks
    style = Style(RgbFg(1,2,3))
    assert isinstance(style, Style)
    assert isinstance(style, str)

    # Object data correct
    assert style == "\x1b[38;2;1;2;3m"


# Generated at 2022-06-24 04:51:39.069362
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.new_color_1 = Style("test1")
    r.new_color_2 = Style("test2")

    dict_out = r.as_dict()

    assert isinstance(dict_out, dict)
    assert len(dict_out) == 2
    assert dict_out.get("new_color_1") == "test1"
    assert dict_out.get("new_color_2") == "test2"

# Generated at 2022-06-24 04:51:43.510416
# Unit test for constructor of class Style
def test_Style():
    rule = Style("")
    assert rule == ""
    assert rule.rules is not None
    assert len(rule.rules) == 0

    rule = Style("", "")
    assert rule == ""
    assert rule.rules is not None
    assert len(rule.rules) == 1

# Generated at 2022-06-24 04:51:49.792306
# Unit test for constructor of class Register
def test_Register():
    """
    Create a simple register object. Call the object as function and set a render-function.
    """
    reg = Register()

    reg.red = Style(RgbFg(255, 0, 0))

    assert str(reg.red) == ""  # Attribute is empty, because render-function is not set

    def render_rgb_fg(r, g, b):
        return "RENDER"

    reg.set_renderfunc(RgbFg, render_rgb_fg)

    assert str(reg.red) == "RENDER"  # Render-function was set, so attribute is rendered

    assert str(reg(255, 0, 0)) == "RENDER"  # Call the register object with a tuple (rgb_call)

    assert str(reg("red")) == "RENDER"  # Call

# Generated at 2022-06-24 04:51:56.239507
# Unit test for method mute of class Register
def test_Register_mute():

    rg = Register()
    rg.test = Style(RgbBg(10, 42, 255))

    assert str(rg.test) == "\x1b[48;2;10;42;255m"

    rg.mute()

    assert str(rg.test) == ""

    rg.unmute()

    assert str(rg.test) == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-24 04:52:02.279273
# Unit test for constructor of class Style
def test_Style():
    """
    Test style constructor.
    """
    # Make sure style is a subclass of str.
    assert issubclass(Style, str)
    # Show that string can be constructed with Style-class
    s1 = Style("Hello style.")
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1 == "Hello style."
    # Show that string can be constructed with Style-class and multiple rules
    s2 = Style("Hello style.", "Hello style 2.")
    assert s2 == "Hello style.Hello style 2."

# Generated at 2022-06-24 04:52:08.629039
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sgr import Sgr
    from . import fg

    sgr = Sgr(1)
    fg.red.rules = (sgr,)

    class Foo:
        sgr: int
    foo = Foo()

    foo.sgr = 42
    assert foo.sgr == 42

    Nt = fg.as_namedtuple()
    assert Nt.red == "\x1b[31m\x1b[1m"

# Generated at 2022-06-24 04:52:15.283513
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightBit, RgbFg

    class _Register(Register):
        pass

    r: _Register = _Register()
    r.red = Style(EightBit(1))
    r.rgb = Style(RgbFg(1, 2, 3))

    assert r("red") == r.red
    assert r("rgb") == r.rgb
    assert r(1) == r.red

    call_rgb_ok: bool = True

    try:
        r(1, 2, 3)
    except ValueError:
        call_rgb_ok = False

    assert call_rgb_ok

    r.set_eightbit_call(RgbFg)
    assert r(1) == r.rgb

# Generated at 2022-06-24 04:52:20.963181
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRenderType1(RenderType):
        args_definition = ("arg1",)

    class TestRenderType2(RenderType):
        args_definition = ("arg1", "arg2")

    def renderfunc1(arg1):
        return f"{arg1}"

    def renderfunc2(arg1, arg2):
        return f"{arg1};{arg2}"

    register = Register()
    register.set_renderfunc(TestRenderType1, renderfunc1)
    register.set_renderfunc(TestRenderType2, renderfunc2)

    style = Style(TestRenderType1(1), TestRenderType2(2, 3))

    assert str(style) == "123"

    register.blue = style

    assert str(register.blue) == "123"

# Generated at 2022-06-24 04:52:29.766582
# Unit test for method copy of class Register
def test_Register_copy():
    renderfuncs: Renderfuncs = {}
    render_type = type("RenderType", (RenderType,), {})
    render = lambda *x: "".join("{}".format(i) for i in x)
    renderfuncs[render_type] = render
    eight_bit = lambda x: render("{}".format(x), end="")
    rgb = lambda r, g, b: render("{}".format(r + g + b), end="")
    a = Register()
    a.set_renderfunc(render_type, render)
    a.set_eightbit_call(render_type)
    a.set_rgb_call(render_type)
    a.test = Style(render_type(1))
    b = a.copy()
    assert a.test == b.test
    assert a

# Generated at 2022-06-24 04:52:33.996594
# Unit test for constructor of class Register
def test_Register():

    class MyRegister(Register):
        # ...
        pass

    r = MyRegister()

    assert isinstance(r, Register)
    assert isinstance(r, MyRegister)



# Generated at 2022-06-24 04:52:43.746997
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test the __setattr__ method of class Register.
    """
    from sty import Sgr, Fg, register, RgbFg, Rs

    # Create the default foreground color register object.
    fg = register.fg

    # Create a new style with bold.
    fg.bold_orange = Style(RgbFg(1, 5, 10), Sgr(1))

    # Ensure that the new attribute is registred.
    assert hasattr(fg, "bold_orange")

    # Ensure that the new attribute is a Style-object.
    assert isinstance(fg.bold_orange, Style)

    # Ensure that the new attribute is a string.
    assert isinstance(str(fg.bold_orange), str)

    # Ensure that the new attribute is colored orange and bold.
    assert str(fg.bold_orange)

# Generated at 2022-06-24 04:52:53.772756
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .sgr import Sgr

    # Example for correct func that can be set as renderfunc:
    def _my_sgr_func(code: int) -> str:
        return "my_" + Sgr(code).render()

    # Example for wrong func that could be set as renderfunc:
    def _wrong_sgr_func(code: int, another_code: int) -> str:
        return "my_" + Sgr(code).render()

    # Create a new Register
    reg = Register()

    # set renderfunc with wrong func
    reg.set_renderfunc(Sgr, _wrong_sgr_func)

    # Check if there is no renderfunc for Sgr in self.renderfuncs
    assert Sgr not in reg.renderfuncs

    # set renderfunc with correct func
    reg.set_render

# Generated at 2022-06-24 04:53:02.409523
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RenderType, RgbFg, RgbBg

    # Create a Register
    register = Register()

    # Define a new render function. Use this function in the next step.
    def new_rgb_call(r, g, b):
        return f"Rgb: {r}, {g}, {b}"

    # Add render function for RGB rendertype.
    register.set_renderfunc(RgbFg, new_rgb_call)

    # Set rendertype to be used for direct calls to register.
    register.set_rgb_call(RgbFg)

    # Create a new style with RGB rendertype
    register.mystyle = Style(RgbFg(200, 100, 50))

    # Test if direct call to register with RGB values is rendered with new render function.

# Generated at 2022-06-24 04:53:08.459404
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertypes import RgbFg, Sgr

    r = Register()

    expected_output = "\x1b[38;2;3;3;3m"
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r.set_eightbit_call(RgbFg)

    assert r(8) == expected_output



# Generated at 2022-06-24 04:53:11.817443
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .registers import fg

    assert isinstance(fg.as_namedtuple(), NamedTuple)
    assert hasattr(fg.as_namedtuple(), "red")

    assert fg.as_namedtuple().red == fg.red



# Generated at 2022-06-24 04:53:21.429944
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .register import Register
    from .rendertype import Sgr
    from .sty import Sty

    sty = Sty()

    # Create a custom Register object.
    class MyRegister(Register):
        foo = Style(Sgr(1, 2, 3))

    myreg = MyRegister()

    assert myreg.as_namedtuple() == myreg.as_namedtuple()
    assert isinstance(myreg.as_namedtuple(), NamedTuple)
    assert isinstance(myreg.as_namedtuple(), sty.as_namedtuple())
    assert dir(myreg.as_namedtuple()) == ["foo"]
    assert myreg.as_namedtuple().foo == '\x1b[1;2;3m'

# Generated at 2022-06-24 04:53:26.443931
# Unit test for constructor of class Register
def test_Register():

    _R = Register()
    assert _R.renderfuncs == {}
    assert _R.is_muted == False
    assert _R.eightbit_call is not None
    assert _R.rgb_call is not None


# Generated at 2022-06-24 04:53:28.951259
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.b = Style(Sgr(1))
    r.x = "Test"
    assert r.as_dict() == {"b": "\x1b[1m", "x": "Test"}



# Generated at 2022-06-24 04:53:38.908564
# Unit test for method mute of class Register
def test_Register_mute():

    class RgbEf(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr(RenderType):
        def __init__(self, *args: int):
            self.args = args

    # Dict with ANSI render functions
    render_funcs: Dict[Type[RenderType], Callable] = {
        Sgr: lambda *args: f"\x1b[{';'.join(map(str, args))}m",
        RgbEf: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
    }

    reg = Register()

# Generated at 2022-06-24 04:53:49.928197
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class StyRegister(Register):
        pass

    sty = StyRegister()
    sty.red = Style(1, 2, 3)
    sty.orange = Style(5, 6, 7, 8)

    assert isinstance(sty.red, str)
    assert isinstance(sty.orange, str)

    sty.blue = Style(1, 2, 3)
    sty.green = Style(sty.blue, 8, 9)

    assert sty.red == sty.blue
    assert sty.orange != sty.green

    sty.mute()
    sty.red = Style(1, 2, 3)

    assert sty.red == ""
    sty.unmute()
    sty.red = Style(1, 2, 3)
    assert sty.red != ""



# Generated at 2022-06-24 04:53:54.050753
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg
    r2 = Register()
    r2.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r2.set_rgb_call(RgbBg)
    assert r2(255, 255, 255) == "\x1b[48;2;255;255;255m"

# Generated at 2022-06-24 04:53:56.943610
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from  sty import fg
    from sty.rendertype import RgbFg

    fg.set_rgb_call(RgbFg)
    assert isinstance(fg(10, 42, 255), str)

# Generated at 2022-06-24 04:54:03.722304
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from colorama import Fore
    from .rendertype import RgbFg

    assert str(Fore("red")) == f"\x1b[38;2;255;0;0m"

    assert str(Fore("blue")) == f"\x1b[38;2;0;0;255m"

    Fore.set_rgb_call(RgbFg)

    assert str(Fore("red")) == f"\x1b[38;2;255;0;0m"

    assert str(Fore("blue")) == f"\x1b[38;2;0;0;255m"

    Fore.set_rgb_call(RgbFg, prefix=u"\u001b[")

    assert str(Fore("red")) == f"\u001b[38;2;255;0;0m"

# Generated at 2022-06-24 04:54:08.662729
# Unit test for method __new__ of class Style
def test_Style___new__():
    class A(RenderType):
        id = 0
    a = A()
    style = Style(a)
    assert style.rules == (a,)
    style = Style(a, value="test")
    assert style == "test"

# Generated at 2022-06-24 04:54:13.087874
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .sgr import Sgr

    register = Register()
    register.set_renderfunc(Sgr, lambda *x: "SGR")
    register.set_eightbit_call(Sgr)

    # Assert that function set_eightbit_call has set the desired attribtue.
    assert register.eightbit_call(1) == "SGR"


# Generated at 2022-06-24 04:54:15.780404
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty import fg

    assert isinstance(fg.blue, Style)
    assert str(fg.blue) == fg.blue


# Generated at 2022-06-24 04:54:21.658823
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    If register is muted, the attribute 'is_muted' should be True.
    After unmuting the attribute 'is_muted' should be False and the color
    should be the same as before muting.
    """
    fg = Register()
    fg.set_eightbit_call(RenderType)
    fg.dark_blue = Style(EightBitFg(4))
    fg.mute()
    assert fg.is_muted == True
    name = "dark_blue"
    before_muting = fg.dark_blue
    fg.unmute()
    assert fg.is_muted == False
    assert fg.dark_blue == before_muting

# Generated at 2022-06-24 04:54:32.098740
# Unit test for method mute of class Register
def test_Register_mute():
    import pytest
    from .rendertype import Sgr

    reg = Register()
    reg.set_renderfunc(Sgr, lambda *args: "".join(f"\x1b[{i}m" for i in args))

    test_style = Style(Sgr(1, 31, 7))
    setattr(reg, "test_style", test_style)

    assert reg.test_style == "\x1b[1m\x1b[31m\x1b[7m"

    reg.mute()

    assert reg.test_style == ""

    reg.unmute()

    assert reg.test_style == "\x1b[1m\x1b[31m\x1b[7m"



# Generated at 2022-06-24 04:54:34.510104
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertypes import Sgr, RgbFg

    s1 = Style(RgbFg(1, 5, 7), Sgr(1))

    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;5;7m\x1b[1m"

# Generated at 2022-06-24 04:54:40.996240
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    r = Register()
    f = lambda r, g, b, a=0: (r, g, b, a)
    RgbBg = RenderType("RgbBg", ["red", "green", "blue"], a=0)

    r.set_renderfunc(RgbBg, f)
    r.set_rgb_call(RgbBg)

    assert r.rgb_call(255, 0, 0, a=255) == (255, 0, 0, 255)


# Generated at 2022-06-24 04:54:48.528976
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Style.__new__ accepts iterable of objects and returns Style object with
    # string representing for them.
    class RgbFg(RenderType):
        # pylint: disable=too-few-public-methods
        def render(self) -> str:
            return f"\x1b[38;2;{self.r};{self.g};{self.b}m"

    class Bold(RenderType):
        # pylint: disable=too-few-public-methods
        def render(self) -> str:
            return "\x1b[1m"

    s = Style(RgbFg(1, 5, 10), Bold())
    assert isinstance(s, Style)
    assert isinstance(s, str)

# Generated at 2022-06-24 04:54:49.493268
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.foo = "bar"
    r.as_dict() == {"foo": "bar"}

# Generated at 2022-06-24 04:54:50.999516
# Unit test for constructor of class Style
def test_Style():
    S = Style("test")
    assert isinstance(S, str)
    assert S == "test"

# Generated at 2022-06-24 04:54:59.247257
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Setup
    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.eightbit_call = lambda x, y=0: x
            self.rgb_call = lambda r, g, b, y=0: r + g + b

    test_reg = TestRegister()
    val_1 = test_reg(42)
    val_2 = test_reg(42, y=42)
    val_3 = test_reg(10, 42, 255)
    val_4 = test_reg(10, 42, 255, y=42)
    val_5 = test_reg("bla")

    # Assertions
    assert val_1 == 42
    assert val_2 == 42
    assert val_3 == 42
    assert val_4 == 42
    assert val_

# Generated at 2022-06-24 04:55:02.360686
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class FakeRegister(Register):
        pass

    fake_register = FakeRegister()
    fake_register.dummy = "dummy"

    fake_register_namedtuple = fake_register.as_namedtuple()

    assert hasattr(fake_register_namedtuple, "dummy")
    assert fake_register_namedtuple == (
        "dummy",
    )
    assert fake_register_namedtuple.dummy == "dummy"



# Generated at 2022-06-24 04:55:04.324651
# Unit test for constructor of class Register
def test_Register():

    # Create a new register object
    register = Register()

    # Assert object is Register
    assert isinstance(register, Register)

    # Assert it has no attrs
    assert not hasattr(register, "any_attr")

# Generated at 2022-06-24 04:55:09.655625
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class RenderTypeTest(RenderType):
        ascii_code = "42 42"

    def renderfunc(x: int) -> str:
        return f"{x} {x}"

    register = Register()
    register.bg = Style(RenderTypeTest(144))
    register.set_renderfunc(RenderTypeTest, renderfunc)
    nt = register.as_namedtuple()

    assert nt.bg == "3 3"
    assert nt.bg == register.bg

# Generated at 2022-06-24 04:55:12.606073
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .sgr import Sgr

    class CustomRegister(Register):
        pass

    cr = CustomRegister()

    cr.set_renderfunc(Sgr, lambda x: f"{x}x")



# Generated at 2022-06-24 04:55:23.640772
# Unit test for method mute of class Register
def test_Register_mute():
    from .sgr import Sgr

    r = Register()
    r.test = Style(Sgr(1), Sgr(2))

    # Check if rendering works.
    assert isinstance(r.test, Style)
    assert isinstance(r.test, str)
    assert str(r.test) == "\x1b[1m\x1b[2m"

    # Mute the register object and check that rendering is not working any more.
    r.mute()

    assert isinstance(r.test, Style)
    assert not isinstance(r.test, str)
    assert str(r.test) == ""

    # Unmute the register object and check if rendering works again.
    r.unmute()

    assert isinstance(r.test, Style)
    assert isinstance(r.test, str)


# Generated at 2022-06-24 04:55:26.465951
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .ansi import RgbFg, Sgr

    register = Register()

    register.set_rgb_call(rendertype=RgbFg)

    assert register(255, 128, 0) == "\x1b[38;2;255;128;0m"

    register.set_rgb_call(rendertype=Sgr)

    assert register(255, 128, 0) == "\x1b[1;1m"



# Generated at 2022-06-24 04:55:27.980532
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert repr(reg) == "Register()"
    reg.hello = Style(RenderType())
    assert reg.hello == ""

# Generated at 2022-06-24 04:55:30.359070
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r is not None
    assert r.as_dict() == {}
    assert r.as_namedtuple().__dict__ == {}

# Generated at 2022-06-24 04:55:31.285957
# Unit test for constructor of class Register
def test_Register():
    rg = Register()


# Generated at 2022-06-24 04:55:41.274981
# Unit test for method mute of class Register
def test_Register_mute():
    import sys
    import unittest
    from unittest.mock import patch

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.custom_style = Style("foo")

    class TestRegisterTestCase(unittest.TestCase):

        @patch("sys.stdout.write")
        def test_mute(self, mock_stdout):
            r = TestRegister()
            print("x", end="")
            r.mute()
            print("y", end="")
            r.custom_style.print("z")

            mock_stdout.assert_called_with("xyz")

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])

# Generated at 2022-06-24 04:55:46.587726
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sty import fg, bg

    assert isinstance(bg.as_namedtuple(), NamedTuple)
    assert isinstance(fg.as_namedtuple(), NamedTuple)
    assert fg.as_namedtuple().blue == fg.blue
    assert bg.as_namedtuple().blue == bg.blue

# Generated at 2022-06-24 04:55:54.612715
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .styleregister import fg, bg

    fg_nt = fg.as_namedtuple()
    bg_nt = bg.as_namedtuple()

    assert fg_nt.black == fg.black
    assert fg_nt.red == fg.red
    assert fg_nt.green == fg.green
    assert fg_nt.yellow == fg.yellow
    assert fg_nt.blue == fg.blue
    assert fg_nt.magenta == fg.magenta
    assert fg_nt.cyan == fg.cyan
    assert fg_nt.white == fg.white

    assert fg_nt.lightblack == fg.lightblack
    assert fg_nt.lightred == fg.lightred

# Generated at 2022-06-24 04:55:59.234679
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr
    from .registertypes import fg

    fg.new = Style(Sgr(0, 1))
    fg.mute()
    assert fg.new == ""
    fg.unmute()
    assert fg.new is not ""


# Generated at 2022-06-24 04:56:08.237459
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    # Define register
    reg = Register()
    reg.hello = Style(Sgr(1), Sgr(4))

    # Set initial Attribute
    assert getattr(reg, 'hello') == '\x1b[1m\x1b[4m'

    # Add new render type, add new render func for this render type.
    # Set new attribute. Check if string has changed.
    reg.set_renderfunc(Sgr, lambda x: "changed")
    reg.hello = Style(Sgr(1), Sgr(4))
    assert getattr(reg, 'hello') == 'changedchanged'

    # Check if the initial attribute is not changed.
    assert getattr(reg, 'hello') != '\x1b[1m\x1b[4m'

    # Check

# Generated at 2022-06-24 04:56:17.754011
# Unit test for method __new__ of class Style
def test_Style___new__():

    f1: Callable = lambda *args: "\x1b[38;2;{0};{1};{2}m".format(*args)
    f2: Callable = lambda *args: "\x1b[{0}m".format(*args)

    renderfuncs = {
        RgbFg: f1,
        Sgr: f2
    }

    rules = RgbFg(1, 2, 3), Sgr(4)
    s1 = Style(*rules, value="")

    assert isinstance(s1, Style)
    assert isinstance(s1, str)

    rendered, _ = _render_rules(renderfuncs, s1.rules)
    assert str(s1) == rendered


# Generated at 2022-06-24 04:56:22.659131
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr
    r1: Style = Style(Sgr(1), value="\x1b[1m")
    r2: Style = r1
    assert r1 == r2
    r2 = Style(Sgr(2), value="\x1b[2m")
    assert r1 != r2



# Generated at 2022-06-24 04:56:31.743320
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRenderType:

        def __init__(self, value: str):
            self.value = value

        def __call__(self, *args, **kwargs):
            return f"{self.value}{''.join([str(i) for i in args])}"

    rendertype = TestRenderType("foo")
    renderfunc = lambda x: rendertype(x)

    register = Register()
    register.set_renderfunc(rendertype, renderfunc)

    register.x = Style(rendertype(15))

    assert isinstance(register.x, Style)
    assert register.x == "foo15"


# Generated at 2022-06-24 04:56:42.613510
# Unit test for method mute of class Register
def test_Register_mute():

    from .register import Register

    class TestRenderType(RenderType):
        pass

    def render_function(*args, **kwargs) -> str:
        return "".join(["\x1b[", str(*args, **kwargs), "m"])

    # Create a TestRegister with a style that uses a TestRenderType.
    class TestRegister(Register):
        test_style = Style(TestRenderType(44))

    r1 = TestRegister()
    r1.set_renderfunc(TestRenderType, render_function)

    ANSI_val = "\x1b[44m"
    assert ANSI_val == r1.test_style  # Assert that the ANSI-sequence is returned as a string.

    assert "test_style" in dir(r1)  # Assert that the style is registered


# Generated at 2022-06-24 04:56:45.865175
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    r = Register()

    r.renderfuncs = {"a": lambda x: str(x)}

    r.x = Style("a")

    assert r.x == "a"



# Generated at 2022-06-24 04:56:56.187329
# Unit test for method mute of class Register
def test_Register_mute():

    def rgb_sgr(r, g, b):
        return f"\033[38;2;{r};{g};{b}m\033[1m"

    class MyRegister(Register):
        pass

    myregister = MyRegister()
    myregister.set_eightbit_call(MircFg)
    myregister.set_rgb_call(RgbFg)

    myregister.set_renderfunc(RgbFg, rgb_sgr)

    myregister.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(myregister.red) == "\033[38;2;255;0;0m\033[1m"

    myregister.mute()
    assert str(myregister.red) == ""
    myregister.unmute()


# Generated at 2022-06-24 04:57:03.414991
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.red = Style(RgbFg(12,34,56))
    r.blue = Style(RgbFg(78,90,5))
    nt = r.as_namedtuple()
    assert nt.red == "\x1b[38;2;12;34;56m"
    assert nt.blue == "\x1b[38;2;78;90;5m"

# Generated at 2022-06-24 04:57:12.501928
# Unit test for method mute of class Register
def test_Register_mute():  # pylint: disable=unused-variable
    """
    This is a unit test for the Register class.

    It tests if the muting and unmuting methods work as expected.
    """

    # noinspection PyUnusedLocal
    register = Register()

    """
    The test will check if a style mutated is not changed back if the register is
    unmuted.
    """

    # Create a style and add it to the register.
    SgrBold = Style(Sgr(1))
    setattr(register, "bold", SgrBold)

    # Test that the register output is expected.
    assert str(register.bold) == "\\x1b[1m"

    # Mute the register and test that the style output is changed.
    register.mute()
    assert str(register.bold) == ""

    #

# Generated at 2022-06-24 04:57:16.433590
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    def rgb_func(r: int, g: int, b: int) -> str:
        return f"rgb-({r}, {g}, {b})"

    r = Register()

    r.set_rgb_call(int, rgb_func)

    assert r(255, 255, 255) == "rgb-(255, 255, 255)"

# Generated at 2022-06-24 04:57:24.804083
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Create register object
    register = Register()

    # Create and define some style attr
    magenta = Style(RenderType(), RenderType())
    setattr(register, "magenta", magenta)

    # Mute register object
    register.mute()

    # Check if muted attributes are empty str
    assert str(register.magenta) == ""

    # Unmute register
    register.unmute()

    # Check if muted attributes are rendered again
    assert str(register.magenta) == "\u001b[38;2;255;0;255m\u001b[1m"

# Generated at 2022-06-24 04:57:26.313772
# Unit test for constructor of class Register
def test_Register():
    r1 = Register()
    r2 = Register()

    assert id(r1) == id(r2)

# Generated at 2022-06-24 04:57:31.670975
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(RgbFg(255, 0, 255), Sgr(1))
    assert isinstance(s, Style)
    assert str(s) == "\\x1b[38;2;255;0;255m\\x1b[1m"
    assert repr(s) == "Style('\\x1b[38;2;255;0;255m\\x1b[1m', rules=[RgbFg(255, 0, 255), Sgr(1)])"



# Generated at 2022-06-24 04:57:42.265866
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg, TruecolorFg, TruecolorBg
    from .color import Color, ColorList
    from .sty import sty
    from .style import fg, bg, rs

    # Define new, custom render-functions for the test.
    def truecolor_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def truecolor_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    def rgb_fg(r, g, b):
        return f"\x1b[38;5;{Color(r,g,b).to_index}m"


# Generated at 2022-06-24 04:57:44.170743
# Unit test for method mute of class Register
def test_Register_mute():

    # TODO: create a Register, call mute and compare the output of
    # _render_rules with an empty string.
    pass

# Generated at 2022-06-24 04:57:48.363695
# Unit test for method copy of class Register
def test_Register_copy():

    from .registers.default_register import ef

    ef_new = ef.copy()
    assert ef_new is not ef
    assert ef_new.underline is not ef.underline
    assert ef_new.underline == ef.underline

# Generated at 2022-06-24 04:57:50.936090
# Unit test for constructor of class Register
def test_Register():
    reg = Register()

    assert reg is not None
    assert reg.renderfuncs == {}
    assert reg.is_muted is False
    assert reg.eightbit_call is not None
    assert reg.rgb_call is not None



# Generated at 2022-06-24 04:57:58.677090
# Unit test for method __call__ of class Register
def test_Register___call__():

    class _Render(RenderType):
        @staticmethod
        def render(v: int, bold: bool = False) -> str:
            if bold:
                return f"\x1b[38;5;{v}m"
            else:
                return f"\x1b[38;5;{v}m"

    r = Register()
    r.set_renderfunc(_Render, _Render.render)
    r.red = Style(_Render(42))
    r.blue = Style(_Render(144))
    r.yellow = Style(_Render(11))

    assert str(r.red) == "\x1b[38;5;42m"
    assert str(r.blue) == "\x1b[38;5;144m"

# Generated at 2022-06-24 04:58:00.798427
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    orig = Register().as_dict()
    res = Register().as_namedtuple()

    assert isinstance(res, NamedTuple)

    for key, val in orig.items():
        assert getattr(res, key) == val



# Generated at 2022-06-24 04:58:11.933409
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This test only checks if the setattr-method is able to handle the new Style-type.
    """
    class RgbFg(RenderType):
        def __call__(self, r: int, g: int, b: int) -> str:
            return f"RgbFg({r}, {g}, {b}); "

    class Sgr(RenderType):
        def __call__(self, n: int) -> str:
            return f"Sgr({n}); "

    class RgbBg(RenderType):
        def __call__(self, r: int, g: int, b: int) -> str:
            return f"RgbBg({r}, {g}, {b}); "

    r = Register()

# Generated at 2022-06-24 04:58:19.253176
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Define a very simple register:
    class Sty(Register):
        pass

    sty = Sty()

    # Define some simple render-functions
    def eightbit_func(x: int) -> str:
        return f"{x}"

    def rgb_func(r: int, g: int, b: int) -> str:
        return f"rgb({r}, {g}, {b})"

    # Add render-functions to register.
    sty.set_renderfunc(int, eightbit_func)
    sty.set_renderfunc(tuple, rgb_func)

    # Define some styles:
    sty.red = Style(0)
    sty.green = Style(1)
    sty.blue = Style(2)

    sty.muted = Style(3)


# Generated at 2022-06-24 04:58:29.153702
# Unit test for constructor of class Register
def test_Register():

    # Test constructor.
    assert(isinstance(Register(), Register))

    # We cannot set a style attribute that is declared in the constructor.
    example = Register()
    assert(not hasattr(example, "test_non_existent"))

    # Test setting a style attribute.
    example.test_style = Style(value="test_style")
    assert(hasattr(example, "test_style"))
    assert(isinstance(example.test_style, Style))

    # Test call with color name
    assert(example.test_style == example("test_style"))

    # Test call with color code
    assert(example.test_style == example(4))

    # Test set_renderfunc
    example.set_renderfunc(int, lambda x: "test")
    test2 = example(4)
    assert(test2 == "test")

# Generated at 2022-06-24 04:58:37.271497
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg

    class MyRegister(Register):
        red = Style(RgbFg(255, 0, 0))
        blue = Style(RgbFg(0, 0, 255))

    my_reg = MyRegister()
    my_reg.set_renderfunc(RgbFg, lambda r, g, b: f"{r}/{g}/{b}")

    assert str(my_reg.red) == "255/0/0"
    assert str(my_reg.blue) == "0/0/255"

    my_reg.mute()

    assert str(my_reg.red) == ""
    assert str(my_reg.blue) == ""

# Generated at 2022-06-24 04:58:44.889943
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg, Sgr

    r: Style = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(r, Style)
    assert isinstance(r, str)

    assert r.rules == (RgbFg(1, 2, 3), Sgr(1))
    assert str(r) == "\x1b[38;2;1;2;3m\x1b[1m"

    assert r.rules == (RgbFg(1, 2, 3), Sgr(1))
    assert str(r) == "\x1b[38;2;1;2;3m\x1b[1m"


# Generated at 2022-06-24 04:58:51.667694
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class CountBytes:
        count: int

        def __init__(self) -> None:
            self.count = 0

        def __call__(self, *args, **kwargs):
            self.count += 1
            return f"\x1b[{self.count}m"

    cb = CountBytes()

    class RgbFg(RenderType):
        args: Tuple[int, int, int]

    class Sgr(RenderType):
        args: Tuple[int]

    rgbfg1 = RgbFg(1, 5, 10)
    sgr1 = Sgr(1)


# Generated at 2022-06-24 04:59:03.284382
# Unit test for method mute of class Register
def test_Register_mute():
    class RgbFgFromRegister(RenderType):
        pass

    RgbFgFromRegister.trans_func = lambda r, g, b: (r, g, b)
    RgbFgFromRegister.render_func = lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"

    class RgbBgFromRegister(RenderType):
        pass

    RgbBgFromRegister.trans_func = lambda r, g, b: (r, g, b)
    RgbBgFromRegister.render_func = lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m"

    class SgrFromRegister(RenderType):
        pass


# Generated at 2022-06-24 04:59:06.756068
# Unit test for constructor of class Register
def test_Register():
    r1 = Register()

    assert isinstance(r1, Register)
    assert isinstance(r1, Register)

# Generated at 2022-06-24 04:59:16.840770
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Unit test for method set_renderfunc of class Register.
    """

    class TestRegister(Register):
        pass

    tr = TestRegister()

    tr.set_renderfunc(RenderType, lambda x: "Test" + str(x))


# Generated at 2022-06-24 04:59:22.552816
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, RgbBg, Sgr

    class MyRegister(Register):
        pass

    register = MyRegister()
    register.set_renderfunc(RgbFg, lambda r, g, b: f"{r}{g}{b}")
    register.set_renderfunc(Sgr, lambda x: "10")

    register.eightbit = Style(RgbFg(1, 2, 3), Sgr(10))

    register.set_eightbit_call(RgbFg)

    assert register.eightbit_call(1, 2, 3) == "123"

