

# Generated at 2022-06-24 04:49:24.122176
# Unit test for constructor of class Register
def test_Register():
    assert issubclass(Register, object)

# Generated at 2022-06-24 04:49:31.308494
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()
    r.test = Style(value="test")
    r.test2 = Style(value="test2")

    r2 = Register()
    r2.test = Style(value="test")
    r2.test2 = Style(value="test2")

    r3 = Register()
    r3.other = "test3"

    assert r3.other != r.other

    r4 = r.copy()

    assert r4.test != r3.test
    assert r4.test2 != r3.test2

    assert r4 == r
    assert r4 != r3

# Generated at 2022-06-24 04:49:38.665448
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda *args: ">{}<".format(args))
    fg.set_eightbit_call(RgbFg)

    assert fg.eightbit_call(42) == ">42<"

    bg = Register()
    bg.set_renderfunc(RgbBg, lambda *args: "#{}#".format(args))
    bg.set_eightbit_call(RgbBg)

    assert bg.eightbit_call(42) == "#42#"


# Generated at 2022-06-24 04:49:47.994589
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class CustomRegister(Register):
        pass

    custom_register = CustomRegister()
    custom_register.set_eightbit_call(RenderType)

    def render_func1(x: int) -> str:
        return "\x1b[%dm" % x

    def render_func2(x: int) -> str:
        return "hallo"

    custom_register.set_renderfunc(RenderType, render_func1)
    assert custom_register(42) == "\x1b[42m"

    custom_register.set_renderfunc(RenderType, render_func2)
    assert custom_register(42) == "hallo"

# Generated at 2022-06-24 04:49:53.030235
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class CustomRegister(Register):
        def __init__(self):
            self.monster_color = Style(RgbFg(42, 13, 110))

    reg = CustomRegister()
    d = reg.as_dict()

    assert isinstance(d, dict)
    assert len(d) == 1
    assert d["monster_color"] == "\x1b[38;2;42;13;110m"



# Generated at 2022-06-24 04:50:04.026743
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    rg = Register()
    fg = Register()

    def testfunc1(*args):
        return f"{args[0]} test 1"

    def testfunc2(*args):
        return f"{args[0]} test 2"

    def testfunc3(*args):
        return f"{args[0]} test 3"

    class TestRenderType1(RenderType):
        pass

    class TestRenderType2(RenderType):
        pass

    class TestRenderType3(RenderType):
        pass

    rg.set_renderfunc(TestRenderType1, testfunc1)
    fg.set_renderfunc(TestRenderType2, testfunc2)
    fg.set_renderfunc(TestRenderType3, testfunc3)

    # Test first call to set_eightbit_call
    rg.set_eightbit_call

# Generated at 2022-06-24 04:50:14.613254
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .register import fg

    colornames_keys = [
        "black",
        "red",
        "yellow",
        "green",
        "blue",
        "magenta",
        "cyan",
        "white",
        "gray",
        "orange",
        "lightblue",
        "lightgreen",
        "lightred",
        "lightcyan",
        "lightmagenta",
    ]


# Generated at 2022-06-24 04:50:19.956881
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class A(Register):
        def __init__(self):
            super().__init__()
            def a(): pass
            self.set_renderfunc(int, a)
            self.c = Style(1)

    a = A()
    d = a.as_dict()

    assert list(d.keys()) == ['c']

# Generated at 2022-06-24 04:50:26.572356
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Test case with 8bit input
    r1 = Register()
    r1.blue = Style(RgbFg(0, 0, 1))
    assert r1(10) == r1.blue

    # Test case with string input
    r2 = Register()
    r2.red = Style(RgbFg(1, 0, 0))
    assert r2("red") == r2.red

    # Test case with invalid input
    r3 = Register()
    assert r3("abc") == ""

    r4 = Register()
    assert r4(0, 1) == ""

# Generated at 2022-06-24 04:50:32.303520
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Test: Replacing render function for bg.black
    from .rendertype import Rgb, RgbBg
    from .renderfunc import render_rgb_bg

    # Render bg.black with SGR
    assert str(bg.black) == "\x1b[48;2;0;0;0m\x1b[0m"
    # Replace renderfunc for bg.black
    bg.set_renderfunc(RgbBg, render_rgb_bg)
    # Render bg.black with RGB
    assert str(bg.black) == "\x1b[48;2;0;0;0m\x1b[0m"

    # Test: Replacing render function for fg.red
    from .rendertype import RgbFg
    from .renderfunc import render_rgb_fg



# Generated at 2022-06-24 04:50:41.128539
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if muted register objects return empty strings when called.
    """
    # Init Register-Class
    reg = Register()
    assert reg.is_muted == False

    # Set function for 8bit calls
    def eightbit_call(*args, **kwargs):
        return "\x1b[38;5;{0}m".format(args[0])
    reg.set_eightbit_call(eightbit_call)

    # Set function for RGB calls
    def rgb_call(*args, **kwargs):
        return "\x1b[38;2;{0};{1};{2}m".format(args[0], args[1], args[2])
    reg.set_rgb_call(rgb_call)

    # Set some colors

# Generated at 2022-06-24 04:50:52.960238
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Sgr(RenderType):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def render(self) -> str:
            return "\x1b[{}m".format(self.args[0])

    class RgbFg(RenderType):
        def __init__(self, r, g, b, **kwargs):
            self.args = (r, g, b)
            self.kwargs = kwargs

        def render(self) -> str:
            r, g, b = self.args
            return "\x1b[38;2;{};{};{}m".format(r, g, b)

    red = Style(RgbFg(255, 0, 0))

# Generated at 2022-06-24 04:50:55.795527
# Unit test for constructor of class Register
def test_Register():

    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False
    assert str(r) == "[]"


# Generated at 2022-06-24 04:51:05.987220
# Unit test for method copy of class Register
def test_Register_copy():
    """
    - Test ``Register.copy()``.
    """

    # Create a new register from scratch.
    class TestRegister(Register):

        green = Style(SgrFg(2))

    testreg = TestRegister()

    # Copy the register-object.
    newreg = testreg.copy()

    # Check if new object has the same attributes.
    assert hasattr(newreg, "green")

    # Add new descriptors and update attributes.
    newreg.black = Style(SgrFg(0))
    assert hasattr(newreg, "black")

    # Check if old object was not changed.
    assert not hasattr(testreg, "black")
    assert not hasattr(testreg.green, "black")

    # Change old object and check if it is changed.

# Generated at 2022-06-24 04:51:16.675188
# Unit test for method unmute of class Register
def test_Register_unmute():

    # TODO: Improve test.

    from sty import fg, bg, render

    def renderfunc_42(i: int) -> str:
        return str(i)

    # Save a copy of the original renderfuncs for further use.
    old_renderfuncs = fg.renderfuncs

    fg.mute()
    # fg.set_renderfunc(render.EightBit, renderfunc_42)

    assert fg.is_muted == True

    for name in dir(fg):

        val = getattr(fg, name)
        if isinstance(val, Style):
            assert val == ""

    fg.unmute()

    assert fg.is_muted == False

    for name in dir(fg):

        val = getattr(fg, name)

# Generated at 2022-06-24 04:51:26.383813
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .register import Register
    from .rendertype import EightbitFg
    from .rendertype import EightbitBg

    # Create test object
    r = Register()

    # Add renderfuncs
    r.set_renderfunc(EightbitFg, lambda x: f"{x}!")
    r.set_renderfunc(EightbitBg, lambda x: f"{x}!")

    # Do some calls
    assert r(42) == "42!"
    assert r(42, 43) == "43!"
    assert r(42, 43, 44) == "44!"
    assert r(*[42]) == "42!"
    assert r(*[42, 43, 44]) == "44!"
    assert r(*[42], foo=42) == "42!"

# Generated at 2022-06-24 04:51:32.334016
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    def _test_func(*args):
        return "".join(args)

    test_reg = Register()
    test_reg.one = Style(value="1", rules=[])
    test_reg.set_renderfunc(RenderType, _test_func)

    test_reg.two = Style(value="2", rules=[])

    assert test_reg.one == "1"
    assert test_reg.two == "2"

# Generated at 2022-06-24 04:51:43.886057
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Docstring:
    --------
    1. Create a fake-register with some dummy styles
    2. Add a custom render-function for the fake-register
    3. Check if the new render-function is used by calling the fake-register

    Expected Result:
    --------
    If there is no error, the test was successful.
    """
    def custom_renderfunc(x: int) -> str:
        return f"{x}"

    class FakeRegister(Register):
        foo = Style(RgbFg(1, 2, 3))
        baz = Style(RgbFg(3, 3, 3))

    fake = FakeRegister()
    fake.set_renderfunc(RgbFg, custom_renderfunc)

    assert str(fake.foo) == "1"

# Generated at 2022-06-24 04:51:48.624187
# Unit test for method __new__ of class Style
def test_Style___new__():
    r1 = RgbFg(100, 100, 100)
    r2 = Sgr(1, 3)
    s1 = Style(r1, r2)
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\033[38;2;100;100;100m\033[1;3m"


# Generated at 2022-06-24 04:51:52.274866
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.red = Style(Sgr(31), RgbFg(255, 0, 0))
    r.green = Style(Sgr(32), RgbFg(0, 255, 0))
    r.blue = Style(Sgr(34), RgbFg(0, 0, 255))

    nt = r.as_namedtuple()

    assert nt[0] == r.red
    assert nt[1] == r.green
    assert nt[2] == r.blue

# Generated at 2022-06-24 04:51:56.247221
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Foobar(RenderType):
        def render(self, *args) -> str:
            return "Foobar"

    def func_1(*arg):
        return "function1"

    def func_2(a):
        return "function2"

    register = Register()

    register.set_renderfunc(Foobar, func_1)
    assert register.renderfuncs == {Foobar: func_1}

    register.set_renderfunc(Foobar, func_2)
    assert register.renderfuncs == {Foobar: func_2}



# Generated at 2022-06-24 04:52:00.374674
# Unit test for method __call__ of class Register
def test_Register___call__():

    def my_render_func(*args, **kwargs):
        return args, kwargs

    r = Register()
    r.set_renderfunc(rendertype=RenderType, func=my_render_func)

    assert r.eightbit_call(0) == ((0,), {})
    assert r.eightbit_call(14) == ((14,), {})

    assert r.rgb_call(0, 0, 0) == ((0, 0, 0), {})
    assert r.rgb_call(1, 3, 5) == ((1, 3, 5), {})

    assert r(0) == ((0,), {})
    assert r(14) == ((14,), {})

    assert r(0, 0, 0) == ((0, 0, 0), {})

# Generated at 2022-06-24 04:52:11.100222
# Unit test for method mute of class Register
def test_Register_mute():

    # Init default style registers
    import sty

    StyRegister_args = namedtuple("StyRegister_args", "eightbit_rendertype rgb_rendertype renderfuncs")

    fg = Register()
    fg_args = StyRegister_args(
        eightbit_rendertype=sty.AnsiFg, rgb_rendertype=sty.RgbFg, renderfuncs=sty.renderfuncs
    )
    fg.set_eightbit_call(fg_args.eightbit_rendertype)
    fg.set_rgb_call(fg_args.rgb_rendertype)
    fg.set_renderfunc(sty.RgbFg, fg_args.renderfuncs[sty.RgbFg])

    bg = Register()

# Generated at 2022-06-24 04:52:20.387969
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class A(RenderType):
        pass

    class B(RenderType):
        pass

    reg = Register()

    reg.set_renderfunc(A, lambda x: "\x1b[4m")
    reg.set_renderfunc(B, lambda x: "\x1b[7m")

    reg.a = Style(A(0))
    reg.b = Style(B(0))

    assert reg.a == "\x1b[4m"
    assert reg.a.rules[0].renderfunc == reg.renderfuncs[A]
    assert reg.b == "\x1b[7m"
    assert reg.b.rules[0].renderfunc == reg.renderfuncs[B]

# Generated at 2022-06-24 04:52:29.627298
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Eightbit(RenderType):
        pass

    class RGB(RenderType):
        pass

    class Render:
        def __call__(self, *args):
            return "".join(reversed(list(args)))

    def ansi_func(value: int) -> int:
        return value + 1

    def rgb_func(r: int, g: int, b: int) -> Tuple[int, int, int]:
        return (r, g, b)

    # Test
    register = Register()
    render = Render()

    register.set_renderfunc(Eightbit, ansi_func)
    register.set_renderfunc(RGB, rgb_func)
    register.set_eightbit_call(Eightbit)
    register.set_rgb_call(RGB)


# Generated at 2022-06-24 04:52:39.269729
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr
    from . import fg

    # Create test Register
    test_register = Register()

    # Add rendertype to register
    test_register.set_renderfunc(type(Sgr), sgr_render)

    # Create test Style with rendertype Sgr with parameter 1 (code for bold text)
    test_style = Style(Sgr(1), value="\x1b[1m")

    # Set test Style as atribute of test Register
    setattr(test_register, "test_style", test_style)

    # Mute register
    test_register.mute()

    # Check if attribute "test_style" is muted.
    assert test_register.test_style == ""

    # Unmute test Register
    test_register.unmute()

    # Check if attribute "test_

# Generated at 2022-06-24 04:52:44.773174
# Unit test for method unmute of class Register
def test_Register_unmute():
    class CustomRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0), Sgr(1))

    reg = CustomRegister()
    reg.mute()
    assert str(reg.red) == ""
    reg.unmute()
    assert str(reg.red) == "\x1b[38;2;255;0;0m\x1b[1m"


# Generated at 2022-06-24 04:52:54.373961
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class CustomRegister(Register):
        pass

    r = CustomRegister()
    rgbfg = r.renderfuncs[RgbFg]

    # We do not want to test the renderfuncs here. So we set
    # a dummy function.
    def dummy(x, y, z):
        pass

    r.set_renderfunc(RgbFg, dummy)
    r.set_renderfunc(Sgr, dummy)
    r.set_renderfunc(RgbBg, dummy)

    # Tests for Attributes
    r.blue = Style(RgbFg(0, 0, 255))
    assert "blue" in dir(r)
    assert str(r.blue) == ""

    # Tests for StylingRules
    r.boldred = Style(RgbFg(255, 0, 0), Sgr(1))

# Generated at 2022-06-24 04:53:00.765506
# Unit test for method __call__ of class Register
def test_Register___call__():
    import pytest
    from .rgb import RgbFg, RgbBg
    from .eightbit import EightbitFg, EightbitBg
    from .special import Bold, Reset, Sgr, Sgr0

    # Register
    register = Register()
    register.set_renderfunc(RgbFg, lambda r, g, b: f"RgbFg({r},{g},{b})")
    register.set_renderfunc(RgbBg, lambda r, g, b: f"RgbBg({r},{g},{b})")
    register.set_renderfunc(EightbitFg, lambda x: f"EightbitFg({x})")
    register.set_renderfunc(EightbitBg, lambda x: f"EightbitBg({x})")

# Generated at 2022-06-24 04:53:06.133873
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .builtinrenderfuncs import AnsiRender

    render_funcs = {
        RgbFg: lambda r, g, b: "N/A",
        RgbBg: lambda r, g, b: "N/A",
        Sgr: lambda *args: "N/A",
    }

    reg = Register()
    reg.set_eightbit_call(RgbFg)
    reg.set_rgb_call(RgbFg)
    reg.set_renderfunc(RgbFg, AnsiRender(RgbFg))

    assert reg.eightbit_call == AnsiRender(RgbFg)
    assert reg.rgb_call != AnsiRender(RgbFg)

# Generated at 2022-06-24 04:53:08.975917
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))
    d = RgbFg(10, 20, 30)

    assert r.renderfuncs[RgbFg] == (lambda r, g, b: (r, g, b))
    assert r("red") == ""
    assert r(10, 20, 30) == (10, 20, 30)

# Generated at 2022-06-24 04:53:18.690808
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class TestRegister(Register):
        pass

    # Create test register.
    t = TestRegister()
    t.foo = "FOO"
    t.bar = "BAR"

    # Export as namedtuple
    nt = t.as_namedtuple()

    # Test values of exported namedtuple
    assert nt.foo == "FOO", "Failed to properly export 'foo' value to namedtuple."
    assert nt.bar == "BAR", "Failed to properly export 'bar' value to namedtuple."


# Generated at 2022-06-24 04:53:30.363232
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from sty import RgbFg, RgbBg, ef, rs, fg, bg, Sgr, fx

    reg = Register()
    reg.set_eightbit_call(RgbFg)
    reg.set_rgb_call(RgbBg)
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"{r} {g} {b}")
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"{r} {g} {b}")

    reg.red = Style(RgbFg(255, 0, 0))
    reg.blue = Style(RgbBg(0, 0, 255))
    reg.red_bold = Style(RgbFg(255, 0, 0), Sgr(1))



# Generated at 2022-06-24 04:53:35.605897
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class RgbFg(NamedTuple):
        r: int
        g: int
        b: int

    class Sgr(NamedTuple):
        sgr_code: int

    class RgbBg(NamedTuple):
        r: int
        g: int
        b: int

    class EightbitFg(NamedTuple):
        color_code: int

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;{r};{g};{b}m".format(**locals()))
    r.set_renderfunc(RgbBg, lambda r, g, b: "\x1b[48;2;{r};{g};{b}m".format(**locals()))
    r

# Generated at 2022-06-24 04:53:41.487284
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Initialize test objects.
    class CustomRenderType(RenderType):
        """
        Custom type that inherits from RenderType.
        """

    class CustomRegister(Register):
        """
        Custom register that inherits from Register.
        """

    rendertype = CustomRenderType()

    register = CustomRegister()
    register.set_renderfunc(rendertype, lambda: "8bit")

    register.set_eightbit_call(rendertype)
    assert register(10) == "8bit"

    register.set_rgb_call(rendertype)
    assert register(1, 2, 3) == "8bit"

# Generated at 2022-06-24 04:53:48.138977
# Unit test for constructor of class Style
def test_Style():

    from sty import RgbFg, Sgr

    style1 = Style(
        RgbFg(100, 200, 255),
        Sgr(1),  # Bold
        "Hello World",
    )

    style2 = Style(style1, "This is another hello world!")

    assert style1 == "Hello World"
    assert style2 == "This is another hello world!"


# Generated at 2022-06-24 04:53:59.925049
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from sty import fg, bg, ef
    red = fg(255, 0, 0)
    bold_red = fg(255, 0, 0, ef.bold)
    red_bg = bg(255, 0, 0)
    bold_red_bg = bg(255, 0, 0, ef.bold)
    cr = Register()

    # Test overwriting of existing attributes
    cr.red = red
    cr.red = bold_red
    cr.red_bg = red_bg
    cr.red_bg = bold_red_bg

    # Test setattr for new attributes
    cr.green = fg(0, 255, 0)
    assert hasattr(cr, "green")
    assert cr.green == fg(0, 255, 0)

    # Test setattr for Style with more

# Generated at 2022-06-24 04:54:05.565894
# Unit test for method __new__ of class Style
def test_Style___new__():
    a: Style = Style(value="\x1b[1m")
    assert a == "\x1b[1m"
    assert a.rules == tuple()

    b: Style = Style(RenderType("1"), RenderType("2"))
    assert b.rules == (RenderType("1"), RenderType("2"))



# Generated at 2022-06-24 04:54:14.071305
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class MyRegister(Register):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.foo = Style(RgbFg(255, 0, 0))
            self.bar = Style(RgbFg(0, 0, 255))

    r = MyRegister()
    nt = r.as_namedtuple()

    assert nt.foo == "\x1b[38;2;255;0;0m"
    assert nt.bar == "\x1b[38;2;0;0;255m"
    assert nt.foo == r.foo
    assert nt.bar == r.bar

# Generated at 2022-06-24 04:54:19.397660
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class X(RenderType):
        pass

    class Y(RenderType):
        pass

    r = Register()
    r.set_renderfunc(X, lambda: "X")
    assert str(X()) == "X"
    r.set_renderfunc(Y, lambda: "Y")
    assert str(Y()) == "Y"
    r.set_renderfunc(X, lambda: "A")
    assert str(X()) == "A"

# Generated at 2022-06-24 04:54:29.596851
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class EightbitCall(RenderType):
        def __init__(self, x: int):
            self.args = (x,)

        def __repr__(self) -> str:
            return "EightbitCall(%s)" % ", ".join(map(str, self.args))

        def __str__(self) -> str:
            return "\x1b[38;5;%sm" % self.args[0]

    class RgbCall(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

        def __repr__(self) -> str:
            return "RgbCall(%s)" % ", ".join(map(str, self.args))


# Generated at 2022-06-24 04:54:38.363224
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class RgbRegister(Register):
        """
        Test register
        """

        quit = Style(RgbEf(0, 0, 0), RgbFg(0, 0, 0))
        red = Style(RgbFg(255, 0, 0))
        green = Style(RgbFg(0, 255, 0))
        blue = Style(RgbFg(0, 0, 255))

        def __init__(self):
            super().__init__()
            self.set_renderfunc(RgbEf, RenderType.render_rgb_ef)
            self.set_renderfunc(RgbFg, RenderType.render_rgb_fg)
            self.set_eightbit_call(RgbEf)
            self.set_rgb_call(RgbFg)

    rgb_register

# Generated at 2022-06-24 04:54:42.924224
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    def testfunc():
        return 123

    renderfuncs = {TestRenderType: testfunc}
    register = Register()
    register.set_renderfunc(TestRenderType, testfunc)
    setattr(register, "foo", Style(TestRenderType(1, 2, 3)))
    register.set_eightbit_call(TestRenderType)

    t = register.as_namedtuple()

    assert t.foo == "123"
    assert t(1) == "123"



# Generated at 2022-06-24 04:54:45.228885
# Unit test for method mute of class Register
def test_Register_mute():

    from .color import Color

    color = Color()

    color.fg.gray(42)



# Generated at 2022-06-24 04:54:55.083925
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .enums import Color

    # Setup mock data
    renderfuncs = {Color: lambda x: str(x)}
    pr = Register()
    pr.renderfunc = renderfuncs
    pr.is_muted = False

    # Setup mock style
    color = Color(1)
    style = Style(color)

    # Setup mock attribute
    attribute_name = "att1"

    # Setup mock return
    return_value = "attribute value"

    # Mock super settter method
    def mock_super_setattr(self, name, value):
        assert self == pr
        assert name == attribute_name
        assert value == return_value

    # Replace imlementation of built-in function super
    # with our mock function
    super_setattr = Register.__setattr__
    Register.__setattr__ = mock_

# Generated at 2022-06-24 04:55:06.223238
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test the method `as_namedtuple` of class Register.
    """

    def r(rgb: List) -> str:
        r, g, b = rgb[0], rgb[1], rgb[2]
        return f"\x1b[38;2;{r};{g};{b}m"

    def b(rgb: List) -> str:
        r, g, b = rgb[0], rgb[1], rgb[2]
        return f"\x1b[48;2;{r};{g};{b}m"

    def s(sgr: List) -> str:
        sgr = sgr[0]
        return f"\x1b[{sgr}m"


# Generated at 2022-06-24 04:55:10.729300
# Unit test for constructor of class Style
def test_Style():
    assert issubclass(Style, str)
    assert isinstance(Style("", RgbFg(1, 5, 10)), Style)
    assert isinstance(Style("", RgbFg(1, 5, 10)), str)


# Unit tests for class Register

# Generated at 2022-06-24 04:55:16.061751
# Unit test for constructor of class Style
def test_Style():
    # If a parameter is a Rendertype, initilize with 'value' = None
    rule: RenderType = RenderType()
    style = Style(rule)
    assert style == ""

    # If a parameter is a Style, initilize with 'value' = None
    rule = RenderType()
    style_nested = Style(rule)
    style = Style(style_nested)
    assert style == ""

    # If a parameter is neither, raise error.
    with pytest.raises(ValueError):
        style = Style(True)

# Generated at 2022-06-24 04:55:27.326590
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class FakeRenderType:
        def __init__(self, args):
            self.args = args

    class FakeRegister(Register):
        def __init__(self):
            super().__init__()
            self.renderfuncs.update({FakeRenderType: lambda x: "fake_code"+str(x)})
            self.set_eightbit_call(FakeRenderType)
            self.set_rgb_call(FakeRenderType)


    fg = FakeRegister()
    fg.red = Style(FakeRenderType(1))
    fg.blue = Style(FakeRenderType(2))
    fg.yellow = Style(FakeRenderType(3))
    fg.green = Style(FakeRenderType(4))


# Generated at 2022-06-24 04:55:36.898004
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create mock-rendertypes
    class RgbFg(RenderType):
        pass

    class Eightbit(RenderType):
        pass

    # Create register-object and fill renderfuncs.
    r = Register()

    r.renderfuncs.update(
        {
            RgbFg: lambda r, g, b: "\033[38;2;{};{};{}m".format(r, g, b),
            Eightbit: lambda x: "\033[38;5;{}m".format(x),
        }
    )

    # Test Rgb-call
    assert r(10, 42, 255) == "\033[38;2;10;42;255m"

    # Test 8bit-call
    assert r(144) == "\033[38;5;144m"

    # Test string-call


# Generated at 2022-06-24 04:55:41.321360
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    >>> register = Register()
    >>> register.set_renderfunc(RgbBg, lambda *args: "test")
    >>> register.renderfuncs[RgbBg]
    <function test_Register_set_renderfunc.<locals>.<lambda> at 0x7fa7e4c4dae8>
    """

# Generated at 2022-06-24 04:55:50.857396
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class rt1:
        def __call__(self, *args):
            return "1-" + str(args)

    class rt2:
        def __call__(self, *args):
            return "2-" + str(args)

    reg = Register()
    reg.ht = Style(rt1())
    assert str(reg.ht) == "1-()"

    reg.set_renderfunc(rt1, lambda *args: "1-new" + str(args))
    assert str(reg.ht) == "1-new()"

    reg.set_renderfunc(rt2, lambda *args: "2-new-" + str(args[0]))
    assert str(reg) == "2-new-1-new()"


# Generated at 2022-06-24 04:56:02.217969
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Csi

    # Define a new render-type
    class Test(RenderType):
        pass

    # Define a renderfunc for the render-type
    def test_func(*args) -> str:
        return "<TEST>"

    # Setup a new register
    reg = Register()

    # Define a style for the register
    reg.red = Style(Csi(38, 5, 1))

    # Set the renderfunc for the register
    reg.set_renderfunc(Test, test_func)

    # Define a new style with the new render-type
    reg.blue = Style(Test())

    # Check if the new style has the format <TEST>
    assert str(reg.blue) == "<TEST>"

    # Update both styles

# Generated at 2022-06-24 04:56:08.478739
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Unit test for set_eightbit_call.
    """

    # mock render function
    def func(x):
        return "8bit mock render function output"

    # create object
    r: Register = Register()

    # Add render function
    r.set_renderfunc(RenderType, func)

    # set rendertype
    r.set_eightbit_call(RenderType)

    # assert
    assert r(42) == "8bit mock render function output"



# Generated at 2022-06-24 04:56:18.556252
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import Hsl, Rgb

    def hsl_func(h: int, s: int, l: int, prefix: str = "\x1b[") -> str:
        return prefix + "38;2;{};{};{}m".format(h, s, l)

    def rgb_func(r: int, g: int, b: int, prefix: str = "\x1b[") -> str:
        return prefix + "38;2;{};{};{}m".format(r, g, b)

    test_reg = Register()
    test_reg.set_renderfunc(Hsl, hsl_func)
    test_reg.set_renderfunc(Rgb, rgb_func)

    # Check if set_rgb_call works for init
    test_reg.set_rgb_call

# Generated at 2022-06-24 04:56:27.830095
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbFg(RenderType):
        pass
    class RgbBg(RenderType):
        pass
    class Sgr(RenderType):
        pass
    class RgbC256(RenderType):
        pass
    class RgbC16(RenderType):
        pass
    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m")
    fg.set_renderfunc(RgbBg, lambda r, g, b: "\x1b[48;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m")

# Generated at 2022-06-24 04:56:33.511145
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Test with empty register
    r = Register()
    r.mute()
    r.unmute()
    assert not r.is_muted

    # Test with register that contains a single style
    r.foo = Style(RgbFg(0,0,0))
    r.mute()
    r.unmute()
    assert not r.is_muted
    assert r.foo == '\x1b[38;2;0;0;0m'

# Generated at 2022-06-24 04:56:44.309489
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class FakeRenderType(RenderType):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # Fake a rendertype with a renderfunc
    rendertype = FakeRenderType()
    def fake_func(*args, **kwargs):
        return (args, kwargs)

    rendertype.func = fake_func

    # Create a register
    reg = Register()

    # Configure Register to use render type as render func for rgb-calls
    reg.set_renderfunc(rendertype, rendertype.func)

    # Call the Register as rgb-call and check if the expected rgb-func has been called.
    args = (1,2,3)
    kwargs = {"a": "A"}

# Generated at 2022-06-24 04:56:51.661183
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Run unit test for method unmute of class Register.
    """

    # TODO:
    # There is not really a unit test that shows that this function does what's intended
    # to do. The only test for this function is the one for method mute(). Here we only
    # check that unmute can be called without errors.

    from .register import fg
    fg.unmute()

# Generated at 2022-06-24 04:56:59.323946
# Unit test for method __new__ of class Style
def test_Style___new__():

    Style("\x1b[38;2;1;5;10m", "\x1b[1m")

    # test_str
    assert str(Style("\x1b[38;2;1;5;10m", "\x1b[1m")) == "\x1b[38;2;1;5;10m\x1b[1m"

    # test_isinstance
    assert isinstance(Style("\x1b[38;2;1;5;10m", "\x1b[1m"), Style)
    assert isinstance(Style("\x1b[38;2;1;5;10m", "\x1b[1m"), str)

    # test_rules

# Generated at 2022-06-24 04:57:07.611908
# Unit test for method copy of class Register
def test_Register_copy():

    fg = Register()
    fg_c = Register()
    fg_c.set_renderfunc(RenderType, lambda x: "fg")
    fg.set_renderfunc(RenderType, lambda x: "fg")

    assert fg_c != fg
    assert fg != fg_c

    fg_a = fg.copy()
    assert fg_a != fg
    assert fg != fg_a

    fg_b = fg_c.copy()
    assert fg_b != fg_c
    assert fg_c != fg_b



# Generated at 2022-06-24 04:57:14.802788
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    RgbFg = NamedTuple("RgbFg", [("r", int), ("g", int), ("b", int)])

    def rgb_to_ansi(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, rgb_to_ansi)
    reg.rgb_call = rgb_to_ansi

    assert reg.rgb_call(42, 255, 0) == "\x1b[38;2;42;255;0m"



# Generated at 2022-06-24 04:57:25.845370
# Unit test for method copy of class Register
def test_Register_copy():
    register = Register()

    render_type0 = type("RenderType0", (RenderType,), {"args": [], "name": "RenderType0"})
    render_type1 = type("RenderType1", (RenderType,), {"args": [], "name": "RenderType1"})

    renderfunc0 = lambda a: ""
    renderfunc1 = lambda a: ""

    register.set_renderfunc(render_type0, renderfunc0)
    register.set_renderfunc(render_type1, renderfunc1)

    red = Style(render_type0(), render_type1())

    register.red = red

    register.set_eightbit_call(render_type0)
    register.set_rgb_call(render_type1)

    register.mute()

    new_register = register.copy()

   

# Generated at 2022-06-24 04:57:33.440136
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import register as sty_register

    # Case 1:
    # Initialization
    my_register = Register()

    # Set a new style attribute
    my_register.red = Style(fg="red")

    # Check if attribute was set correctly.
    assert str(my_register.red) == "\x1b[38;2;255;0;0m"

    # Mute register
    my_register.mute()

    # Check if attribute was updated
    assert str(my_register.red) == ""

    # Case 2:
    # Initialization
    sty_register.fg.mute()

    # Set a new style attribute
    sty_register.fg.red = Style(fg="red")

    # Check if attribute was set correctly.
    assert str(sty_register.fg.red) == ""

    # Un

# Generated at 2022-06-24 04:57:38.354046
# Unit test for method copy of class Register
def test_Register_copy():

    r1 = Register()
    r1.green = Style(RgbFg(0, 255, 0))

    r2: Register = r1.copy()

    assert r1 is not r2
    assert r1.green is not r2.green
    assert r1.green == r2.green

# Generated at 2022-06-24 04:57:40.824481
# Unit test for method copy of class Register
def test_Register_copy():
    reg1 = Register()
    reg1.red = Style()
    reg2 = reg1.copy()
    assert reg1 is not reg2
    assert reg1.red is reg2.red

# Generated at 2022-06-24 04:57:48.756825
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg
    from .rendertype import RgbBg
    from .register import Register
    reg = Register()
    reg.set_renderfunc(RgbFg, lambda r,g,b: f"{r},{g},{b}_RgbFg")
    reg.set_renderfunc(RgbBg, lambda r,g,b: f"{r},{g},{b}_RgbBg")
    reg.set_rgb_call(RgbFg)  # Set register to RgbFg for RGB-calls
    assert reg(42, 51, 77) == "42,51,77_RgbFg"

# Generated at 2022-06-24 04:57:54.067858
# Unit test for method __new__ of class Style
def test_Style___new__():

    class A(RenderType):
        def __init__(self):
            pass

    class B(RenderType):
        def __init__(self):
            pass

    s = Style(A())
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s == ""

    s1 = Style(B())
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1 == ""

    s2 = Style(A(), B())
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert s2 == ""



# Generated at 2022-06-24 04:58:03.140041
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            super().__init__("<RGB-FG-STRING>")

    class Sgr(RenderType):
        def __init__(self, value: int):
            super().__init__("<SGR-STRING>")

    def f1(r: int, g: int, b: int) -> str:
        return f"\033[38;2;{r};{g};{b}m"

    def f2(value: int) -> str:
        return f"\033[{value}m"

    r = Register()
    r.renderfuncs[RgbFg] = f1
    r.renderfuncs[Sgr] = f2

    r.red = Style

# Generated at 2022-06-24 04:58:14.059073
# Unit test for constructor of class Register
def test_Register():

    with pytest.raises(TypeError, match="__init__() missing 1 required positional argument"):
        Register()

    with pytest.raises(TypeError, match="__init__() takes 1 positional argument but 2 were given"):
        Register("string", "string")

    # Empty constructor
    register = Register()

    # Functions are not present yet.
    with pytest.raises(KeyError, match="42 is not a rendertype."):
        register.set_eightbit_call(42)

    # Adding a render-function.
    renderfunc = lambda *args: "test"
    rendertype = RenderType
    register.set_renderfunc(rendertype, renderfunc)

    register.set_eightbit_call(rendertype)
    assert register.eightbit_call == renderfunc


# Generated at 2022-06-24 04:58:19.056580
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class SomeClass(RenderType):
        def render(self) -> str:
            return "Foo"

    rendertype1 = SomeClass()
    rendertype2 = SomeClass()

    register = Register()
    register.set_renderfunc(rendertype1, lambda: "Bar")

    assert register.rgb_call() == ""

    assert register(42, 12, 3) == "Bar"

    register.set_rgb_call(rendertype2)

    assert register.rgb_call() == "Foo"
    assert register(42, 12, 3) == "Foo"

# Generated at 2022-06-24 04:58:29.116799
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RegisterTest(Register):
        pass

    rt = RegisterTest()
    rt.set_rgb_call(RgbBg)
    rt.set_eightbit_call(EightBitFg)
    rt.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    rt.black = Style(RgbFg(0, 0, 0), RgbBg(0, 0, 0))
    rt.white = Style(RgbFg(255, 255, 255), RgbBg(255, 255, 255))
    rt.red = Style(RgbFg(255, 0, 0), RgbBg(255, 0, 0))

# Generated at 2022-06-24 04:58:34.040554
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for method unmute of class Register.
    """
    fg = Register()
    fg.green = Style(value="\x1b[1m", rules=[RenderType("Sgr", 1)])
    fg.mute()
    assert fg.green == ""
    fg.unmute()
    assert fg.green == "\x1b[1m"


# Generated at 2022-06-24 04:58:41.742308
# Unit test for constructor of class Style
def test_Style():
    rt = RenderType("TEST", 1, 2, kw="kw")
    rt2 = RenderType("TEST2", 1, 2, kw="kw")
    assert isinstance(Style(rt, rt2), Style)
    assert Style(rt, rt2).rules == (rt, rt2)
    assert Style(rt, rt2).__str__() == rt.__str__() + rt2.__str__()
    assert str(Style(rt, rt2)) == rt.__str__() + rt2.__str__()
    assert Style(rt, rt2) == rt.__str__() + rt2.__str__()



# Generated at 2022-06-24 04:58:49.069045
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRegister(Register):
        pass

    r = TestRegister()

    r.eightbit = Style(RgbFg(10, 20, 30))
    r.rgb = Style(RgbFg(10, 20, 30))

    assert r.rgb == "\x1b[38;2;10;20;30m"
    assert r.eightbit == "\x1b[38;2;10;20;30m"

    r.mute()

    assert r.rgb == ""
    assert r.eightbit == ""

    r.unmute()

    assert r.rgb == "\x1b[38;2;10;20;30m"
    assert r.eightbit == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-24 04:58:52.848654
# Unit test for method mute of class Register
def test_Register_mute():
    fg = Register()

    fg.red = Style(Fg("red"))

    fg.mute()
    assert str(fg.red) == ""

    fg.unmute()

    assert str(fg.red) == "\x1b[31m"


# Generated at 2022-06-24 04:59:02.679019
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class CustomRenderType1(RenderType):
        pass

    class CustomRenderType2(RenderType):
        pass

    MyRegister = Register()

    def render_func1():
        return "CustomRenderType1"

    def render_func2():
        return "CustomRenderType2"

    MyRegister.set_renderfunc(CustomRenderType1, render_func1)
    MyRegister.set_renderfunc(CustomRenderType2, render_func2)

    assert MyRegister.renderfuncs[CustomRenderType1] == render_func1
    assert MyRegister.renderfuncs[CustomRenderType2] == render_func2



# Generated at 2022-06-24 04:59:10.279723
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    test_Register_as_namedtuple
    """
    class MockRegister(Register):
        red = Style("")
        pink = Style("")
        black = Style("")
        white = Style("")

    r = MockRegister()

    style_tuple = r.as_namedtuple()
    assert isinstance(style_tuple, namedtuple("StyleRegister", ["red", "pink", "black", "white"]))

# Generated at 2022-06-24 04:59:18.835787
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Foo(Register):
        pass

    foo = Foo()

    # Set attribute 'bar' of register 'foo' to value red
    foo.bar = Style(RedFg())

    # Call object 'foo' with input 'bar'. This should return the ANSI sequence for red
    # (\x1b[31m).
    x = foo("bar")

    # Register 'foo' has a new rendertype that is not known. Therefore, 'foo' doesn't
    # know how to render the rendertype. 'foo' should return an empty string instead.
    assert x == ""

    # Set new render-function for rendertype RedFg
    foo.set_renderfunc(rendertype=RedFg, func=lambda: "X")

    # As the new rendertype is now known, 'foo' can render the code for red ('X')
   

# Generated at 2022-06-24 04:59:23.537525
# Unit test for constructor of class Style
def test_Style():
    style1 = Style(RgbFg(1,2,3), RgbBg(255,255,255))

    ansi_sequence, rules = _render_rules(
        default_renderfuncs, [RgbFg(1,2,3), RgbBg(255,255,255)]
    )

    style2 = Style(*rules, value=ansi_sequence)

    assert type(style1) == Style
    assert style1 == style2
    assert str(style1) == str(style2)
