

# Generated at 2022-06-24 04:49:24.046007
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-24 04:49:33.598233
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Just to make sure the mute/unmute method works as expected.
    """

    class _Mock:
        def __init__(self):
            self.values = {}
            self.muted = False

        def __getattr__(self, attr):
            return self.values.get(attr, "")

        def __setattr__(self, name, value):

            if name == "values":
                self.__dict__[name] = value
                return

            if self.muted:
                self.values[name] = "test_muted"
            else:
                self.values[name] = value

        def update(self, renderfuncs: Renderfuncs):
            self.renderfuncs = renderfuncs

        def mute(self):
            self.muted = True


# Generated at 2022-06-24 04:49:38.339782
# Unit test for method mute of class Register
def test_Register_mute():

    r = Register()
    r.set_eightbit_call(type(RgbFg(0, 0, 0)))
    r.set_rgb_call(type(RgbFg(0, 0, 0)))

    r.renderfuncs.update(
        {type(RgbFg(0, 0, 0)): lambda x: f"\u001b[38;2;{x[0]};{x[1]};{x[2]}m",}
    )

    r.red = Style(RgbFg(255, 0, 0))

    assert r.red == "\u001b[38;2;255;0;0m"
    assert r(255) == "\u001b[38;2;255;0;0m"

# Generated at 2022-06-24 04:49:49.594252
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Unit test for method set_renderfunc of class Register.
    """

    # Create register-object
    r = Register()
    r.set_renderfunc(int, lambda x: f"NEW INT-FUNC: {x}")
    r.set_renderfunc(list, lambda x, y, z: f"NEW LIST-FUNC: {x}, {y}, {z}")

    # Prepare new style to render
    s = Style(1, 2, RenderType(list, 3, 4, 5))

    # Activate new render-functions
    r.set_eightbit_call(int)
    r.set_rgb_call(list)

    # The new render-functions should be used when setting a new attr.
    r.newstyle = s

    # TODO: This is a bit to hacky.

# Generated at 2022-06-24 04:49:52.524317
# Unit test for constructor of class Register
def test_Register():

    reg = Register()

    assert "renderfuncs" in dir(reg)
    assert "is_muted" in dir(reg)
    assert "eightbit_call" in dir(reg)
    assert "rgb_call" in dir(reg)



# Generated at 2022-06-24 04:49:59.341665
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    res = ef.cyan.as_dict()
    assert res == {"cyan":"\x1b[36;1m"}

    res = ef.underline.as_dict()
    assert res == {"underline":"\x1b[4m"}

    res = ef.bold.as_dict()
    assert res == {"bold":"\x1b[1m"}

# Generated at 2022-06-24 04:50:07.398669
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.set_renderfunc(RenderType, lambda x: "\x1b[{}m".format(x))
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.red = Style(RenderType(31))
    assert r.red == "\x1b[31m"
    assert r(31) == "\x1b[31m"
    assert r(255, 0, 0) == "\x1b[31m"
    assert len(dir(r)) == 4  # The class has 4 attributes.
    r.mute()
    assert r.red == ""
    assert r(31) == ""
    assert r(255, 0, 0) == ""
    r.unmute()

# Generated at 2022-06-24 04:50:12.715697
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import RgbFg, Sgr
    s1 = Style(RgbFg(1,5,10), Sgr(1))
    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == '\x1b[38;2;1;5;10m\x1b[1m'


# Generated at 2022-06-24 04:50:22.247662
# Unit test for constructor of class Register
def test_Register():

    # Create a new register
    register = Register()

    # Define dummy render function
    renderfunc = lambda *s: "_. style_. {} _.".format("".join(s))

    # Add renderfunc to register object
    register.set_renderfunc(RenderType, renderfunc)

    # Define style with some rendertypes
    style = Style(Sgr(1), RgbFg(1, 2, 3), RgbBg(3, 2, 1))

    # Add style to register
    setattr(register, "stylish", style)

    # Unit test code
    assert isinstance(register, Register)
    assert register.stylish == "_. style_. \x1b[1m\x1b[38;2;1;2;3m\x1b[48;2;3;2;1m _."



# Generated at 2022-06-24 04:50:32.538660
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # See https://stackoverflow.com/a/10087819/5833283
    # for the workaround with the __new__ method.

    from . import style
    from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs

    class TestRegister(Register):
        style1 = Style(RgbFg(1, 2, 3))
        style2 = Style(RgbBg(1, 2, 3))
        style3 = Style(RgbEf(1, 2, 3))
        style4 = Style(RgbRs(1, 2, 3))

    nt1 = TestRegister().as_namedtuple()
    nt2 = TestRegister().as_namedtuple()

    assert hasattr(nt1, "style1")

# Generated at 2022-06-24 04:50:41.298657
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .sgr import Sgr
    from .eightbit import EightBit

    # Render-Func for Sgr
    def render_Sgr(*args):
        return "\x1b[{0}m".format(";".join(str(x) for x in args))

    # Render-Func for EightBit
    def render_EightBit(*args):
        return "\x1b[{0}m".format(";".join(str(x) for x in args))

    # Create Registers
    register1 = Register()
    register2 = Register()

    # Set Render-Funcs
    register1.set_renderfunc(Sgr, render_Sgr)
    register2.set_renderfunc(EightBit, render_EightBit)

    # Create Style
    register1.bold = Style(Sgr(1))
    register

# Generated at 2022-06-24 04:50:43.858596
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(), Style)
    assert isinstance(Style("test"), Style)
    assert isinstance(Style("test", value="test"), Style)
    assert isinstance(Style("test", value="test", rules="test"), Style)


# Unit tests for method __call__ of class Register:

# Generated at 2022-06-24 04:50:55.143207
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, Sgr

    def func(x):
        return f"\x1b[38;{x}m"

    def func2(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    r = Register()
    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;1m"
    assert r(10, 20, 30) == "\x1b[38;2;10;20;30m"

    r.set_rgb_call(RgbFg)
    assert r(1) == "\x1b[38;2;1;0;0m"

# Generated at 2022-06-24 04:51:03.883188
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .styles import fg as myfg, fg256, fg24bit

    r1, r2, r3 = Register(), Register(), Register()

    r1.red = Style(fg24bit(255, 0, 0))
    r1.green = Style(fg24bit(0, 128, 0))
    r1.blue = Style(fg24bit(0, 0, 255))

    r2.red = Style(fg256(172))
    r2.green = Style(fg256(34))
    r2.blue = Style(fg256(255))

    r3.red = Style(fg(1))
    r3.green = Style(fg(2))
    r3.blue = Style(fg(3))


# Generated at 2022-06-24 04:51:07.684298
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register = Register()
    style = Style(RgbFg(0, 0, 0), Sgr(1))
    register.black = style
    assert register.black == style



# Generated at 2022-06-24 04:51:14.896569
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .stylist import Fg, Bg, Rs, RgbFg, Sgr

    r = Register()
    r.red = Style(RgbFg(1, 5, 10), Sgr(1))

    assert r(42) == ""
    assert r(1, 2, 3) == ""

    assert r.red == str(r.red) == "\x1b[38;2;1;5;10m\x1b[1m"
    assert r("red") == str(r.red)

# Generated at 2022-06-24 04:51:25.344984
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Test setattr with str param
    reg = Register()
    reg.test_1 = "Test"
    assert reg.test_1 == "Test"

    # Test setattr with Style param
    reg.test_2 = Style("test_2")
    assert reg.test_2 == "test_2"

    assert isinstance(reg.test_2, Style)
    assert not isinstance(reg.test_2, str)

    # Test setattr with Style param with multiple rules
    reg.test_3 = Style("test_3", "test_4")
    assert reg.test_3 == "test_3test_4"

    # Test setattr with Style param with multiple rules and non-ASCII chars
    reg.test_4 = Style("test_3", "äöü")


# Generated at 2022-06-24 04:51:29.706059
# Unit test for constructor of class Style
def test_Style():

    from .sgr import Sgr
    sgr = Sgr(1)
    style = Style(sgr)
    assert isinstance(style, str)
    assert isinstance(style, Style)
    assert str(style) == '\x1b[1m'


# Generated at 2022-06-24 04:51:34.842492
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    import sty

    def eightbit_func(designator, color_number):
        return f"\x1b[{designator}{color_number}m"

    fg_copy = sty.fg.copy()
    fg_copy.set_eightbit_call(sty.SgrFg)
    fg_copy.set_renderfunc(sty.SgrFg, eightbit_func)

    assert fg_copy(42) == "\x1b[38;5;42m"



# Generated at 2022-06-24 04:51:35.442978
# Unit test for method copy of class Register
def test_Register_copy():
    pass

# Generated at 2022-06-24 04:51:47.449812
# Unit test for method __call__ of class Register

# Generated at 2022-06-24 04:51:54.461418
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from . import Sgr
    from .constants import fg
    from .rendertype import RenderType

    fg2 = fg.copy()

    fg2.set_renderfunc(RenderType, lambda *x: "")

    assert fg2.black == ""

    assert fg2(0) == ""

    fg2.set_renderfunc(Sgr, lambda x: f"Sgr {x}")

    assert fg2.black == "Sgr 0"

# Generated at 2022-06-24 04:52:03.642640
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    The class Register can be called directly to create a style-string. This
    unit test checks if the method __call__ works.
    """

    from .render import Sgr, RgbFg, Fg
    from .utils import _RgbTuple

    reg: Register = Register()
    reg.set_renderfunc(Sgr, lambda *args, **kwargs: "\x1b[{}m".format(*args))
    reg.set_renderfunc(RgbFg, lambda *args, **kwargs: "\x1b[38;2;{};{};{}m".format(*args))
    reg.set_renderfunc(Fg, lambda *args, **kwargs: "\x1b[38;5;{}m".format(*args))

    reg.set_eightbit_call(Fg)
   

# Generated at 2022-06-24 04:52:12.492854
# Unit test for method copy of class Register
def test_Register_copy():

    new_register = Register()

    new_register.set_eightbit_call(RenderType.Eightbit)
    new_register.set_rgb_call(RenderType.RgbFg)

    # Create a style attribute
    new_register.red = Style(eightbit.red)

    # Mute register object.
    new_register.mute()

    # Copy register object
    new_register_copy = new_register.copy()

    # Mute should return the same register object.
    assert id(new_register) == id(new_register_copy)

    # Mute should return a copy of the register object.
    assert id(new_register) != id(new_register_copy.copy())

test_Register_copy()

# Generated at 2022-06-24 04:52:20.235524
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import Rgb, RgbBg, RgbFg

    class CustomRegister(Register):
        pass

    my_register = CustomRegister()
    my_register.set_rgb_call(RgbFg)

    assert my_register(10,20,30) == ""
    my_register.rgb_call = lambda r,g,b: RgbFg(r,g,b)
    assert my_register(10,20,30) == "\x1b[38;2;10;20;30m"

    assert my_register(10,20,30) == ""
    my_register.set_rgb_call(Rgb)
    assert my_register(10,20,30) == "\x1b[38;2;10;20;30m"


# Generated at 2022-06-24 04:52:26.951561
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    
    # Create a dummy rendertype with a dummy render func.
    class DummyRendertype(RenderType):
        pass

    def render_dummy(x: int) -> str:
        return "DUMMY"

    # Create a dummy register.
    class DummyRegister(Register):
        pass

    obj = DummyRegister()
    obj.set_renderfunc(DummyRendertype, render_dummy)

    # Assing a style to the dummy register.
    obj.test_STYLE = Style(DummyRendertype(1))

    # Check if __setattr__ has been called and render-func has been applied.
    assert obj.test_STYLE == "DUMMY"

# Generated at 2022-06-24 04:52:36.511331
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbBg, RgbFg, Sgr

    fg_orange = Style(RgbFg(1, 5, 6), Sgr(1))
    assert isinstance(fg_orange, Style)
    assert isinstance(fg_orange, str)
    assert str(fg_orange) == "\x1b[38;2;1;5;6m\x1b[1m"

    bg_orange = Style(RgbBg(1, 5, 6), Sgr(1))
    assert isinstance(bg_orange, Style)
    assert isinstance(bg_orange, str)
    assert str(bg_orange) == "\x1b[48;2;1;5;6m\x1b[1m"

# Generated at 2022-06-24 04:52:47.151389
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    # Setup
    reg = Register()
    reg.red = Style(RgbFg(1, 5, 10))
    reg.green = Style(RgbBg(5, 10, 15))
    reg.blue = Style(RgbFg(10, 15, 20))

    def func1(*args):
        return "test1"

    def func2(*args):
        return "test2"

    reg.set_rgb_call(RgbFg)
    reg.set_renderfunc(RgbFg, func1)

    reg.set_rgb_call(RgbBg)
    reg.set_renderfunc(RgbBg, func2)

    # Test 1
    assert reg(10, 20, 30) == "test1"

# Generated at 2022-06-24 04:52:55.141006
# Unit test for method __new__ of class Style
def test_Style___new__():
    class Base:
        pass

    class A(Base):
        def __new__(cls, *args, **kwargs):
            return super().__new__(cls)

    # Create instance A
    a = A()

    # Create instance B that inherits from A
    b = A()

    # Check
    assert isinstance(a, Base)
    assert issubclass(type(a), Base)
    assert isinstance(b, Base)
    assert issubclass(type(b), Base)

# Generated at 2022-06-24 04:53:01.518907
# Unit test for method copy of class Register
def test_Register_copy():

    import pytest

    from .template import fg, bg

    new_fg = fg.copy()
    assert new_fg != fg

    new_bg = bg.copy()
    assert new_bg != bg

    assert new_bg.blue == bg.blue
    assert new_bg.blue != fg.blue

# Generated at 2022-06-24 04:53:05.188223
# Unit test for method __new__ of class Style
def test_Style___new__():
    rules = [RgbFg(10, 20, 30)]
    style = Style(*rules)
    assert style.rules == rules

# Generated at 2022-06-24 04:53:14.676402
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty.rendering.ansi_escape_codes import (
        RgbBg,
        RgbFg,
        Sgr,
        reset,
    )

    def render_rgb(r: int, g: int, b: int) -> str:
        return Sgr(1) + RgbFg(r, g, b) + reset

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return Sgr(1) + RgbBg(r, g, b) + reset

    reg = Register()
    reg.set_renderfunc(RgbFg, render_rgb)
    reg.set_renderfunc(RgbBg, render_rgb_bg)
    reg.set_rgb_call(RgbBg)

# Generated at 2022-06-24 04:53:26.454134
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .sgr import Sgr
    from .rgb import RgbFg, RgbBg

    class RenderTypeA:

        def __init__(self, *args):
            pass

        def to_ansi(self, *args):
            return f"\x1b[{args[0]}m"

    class RenderTypeB:

        def __init__(self, *args):
            pass

        def to_ansi(self, *args):
            return f"\x1b[{args[0]+20}m"


# Generated at 2022-06-24 04:53:31.048416
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test of the ``copy`` method of the ``Register`` class.
    """
    reg = Register()
    reg.blue = Style("blue", value="\x1b[34m")
    reg2 = reg.copy()
    assert reg2.blue == "\x1b[34m"
    reg.blue = Style("blue", value="\x1b[35m")
    assert reg2.blue == "\x1b[34m"

# Generated at 2022-06-24 04:53:37.275971
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test the method __new__ of the class Style.
    """
    class A:
        pass
    class B:
        pass

    a = A()
    b = Style(a)

    assert b.rules == (a,)


# Generated at 2022-06-24 04:53:41.776207
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class A(Register):
        a = Style()
        b = Style()

    a = A()

    # Because we need a instance of a class with a __dict__-attribute.
    r = a.as_namedtuple()

    assert isinstance(r, NamedTuple)
    assert hasattr(r, "a")
    assert hasattr(r, "b")

# Generated at 2022-06-24 04:53:52.514373
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MockRenderType:
        def __init__(self, *args):
            self.args = args

    class MockRegister(Register):
        def __init__(self, *args):
            super().__init__()
            self.renderfuncs.update({MockRenderType: lambda *args: "".join(args)})

    rg = MockRegister()
    rg.blue = Style(MockRenderType("a", "b"))
    assert "blue" in dir(rg)
    assert rg.blue == "ab"

    rg.blue = Style(MockRenderType("x", "y"))
    assert rg.blue == "xy"

    rg.set_renderfunc(MockRenderType, lambda *args: "".join(reversed(args)))

    rg.blue = Style(MockRenderType("a", "b"))

# Generated at 2022-06-24 04:54:01.543965
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty.render import Sgr, SgrFg, RgbFg, SgrBg, RgbBg, SgrEf, RgbEf

    rule0 = Sgr(1)
    rule1 = SgrFg(1)
    rule2 = RgbFg(1, 2, 3)

    rule3 = Sgr(2)
    rule4 = SgrBg(1)
    rule5 = RgbBg(1, 2, 3)

    rule6 = Sgr(3)
    rule7 = SgrEf(1)
    rule8 = RgbEf(1, 2, 3)

    rule9 = Style(rule0, rule1, rule2)
    rule10 = Style(rule3, rule4, rule5)

# Generated at 2022-06-24 04:54:09.712531
# Unit test for method copy of class Register
def test_Register_copy():

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.customfield = ""

    r1 = TestRegister()

    print(f"hash(r1)={hash(r1)}")

    r1.customfield = 42

    r2 = r1.copy()

    print(f"hash(r2)={hash(r2)}")

    assert r1.customfield == r2.customfield

# Generated at 2022-06-24 04:54:17.345309
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertypes import EightbitRgb, Sgr, Style
    from .renderfuncs import EIGHTBIT_SGR, RGB_SGR

    # Create register-object
    r = Register()

    # Add rendertype
    r.set_renderfunc(EightbitRgb, EIGHTBIT_SGR)
    r.set_renderfunc(Sgr, RGB_SGR)
    r.set_eightbit_call(EightbitRgb)
    r.set_rgb_call(EightbitRgb)

    # Add styles
    r.red = Style(EightbitRgb(1), Sgr(1))
    r.orange = Style(EightbitRgb(202))

    assert r(144) == "\x1b[38;5;144m"

# Generated at 2022-06-24 04:54:23.399579
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import Sgr, RgbFg, RgbBg

    class BlueRegister(Register):
        def __init__(self):
            super().__init__()
            self.blue = Style(RgbFg(0, 0, 256))

    r: BlueRegister = BlueRegister()
    assert str(r.blue) == "\x1b[38;2;0;0;256m"

    r.set_rgb_call(Sgr)
    assert str(r.blue) == "\x1b[38;2;0;0;256m"
    assert str(r(0, 0, 256)) == "\x1b[38;2;0;0;256m"

    r.set_rgb_call(RgbBg)

# Generated at 2022-06-24 04:54:30.340823
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit test for method unmute of class Register
    """

    from .register.rendertype import Sgr

    def render_sgr(attributes: List[int], *args) -> str:
        return f"\033[{';'.join(str(a) for a in attributes) if attributes else ''}m"

    def render_sgr_n(attributes: List[int], *args) -> str:
        return f"\033[39;49m\033[{';'.join(str(a) for a in attributes) if attributes else ''}m"

    r = Register()
    r.set_renderfunc(Sgr, render_sgr)

    r.test = Style(Sgr(1))

    r.mute()

    assert str(r.test) == ""

# Generated at 2022-06-24 04:54:39.216250
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.rgb_call = lambda r, g, b: (r, g, b)
    r.eightbit_call = lambda x: x

    @r.set_renderfunc(int)  # type: ignore
    def render(x: int) -> str:
        return str(x)

    @r.set_renderfunc(str)  # type: ignore
    def render(text: str) -> str:
        return text + " foo"

    assert r.rgb_call(1, 2, 3) == (1, 2, 3)
    assert r.eightbit_call(42) == 42

    from sty.mapping import RgbFg

    blue = Style(RgbFg(0, 0, 255))

# Generated at 2022-06-24 04:54:46.075622
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertypes import Sgr, Rgb24BitFg, Rgb24BitBg

    c = Style(Rgb24BitFg(0, 255, 0))
    assert isinstance(c, Style) is True
    assert isinstance(c, str) is True
    assert c == "\x1b[38;2;0;255;0m"

    c = Style(Rgb24BitBg(0, 255, 0))
    assert isinstance(c, Style) is True
    assert isinstance(c, str) is True
    assert c == "\x1b[48;2;0;255;0m"

    c = Style(Rgb24BitFg(0, 255, 0), Sgr(1), Rgb24BitBg(255, 0, 0))
    assert isinstance(c, Style) is True

# Generated at 2022-06-24 04:54:55.544508
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFgTest(RenderType):
        pass

    class RgbBgTest(RenderType):
        pass

    # Create a new register
    re = Register()

    # Set renderfuncs for fg- and bg-rendertype
    re.set_renderfunc(RgbFg, lambda r, g, b: " FG ")
    re.set_renderfunc(RgbBg, lambda r, g, b: " BG ")

    # Set fg-color for rendertype rgb
    re.red = Style(RgbFg(255, 0, 0))

    # Call register object with RGB-code
    assert re(255, 0, 0) == " FG "

    # Set new renderfunc for rendertype rgb
    re.set_rgb_call(RgbBgTest)

    # Set fg

# Generated at 2022-06-24 04:54:56.680134
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)



# Generated at 2022-06-24 04:55:06.778315
# Unit test for constructor of class Style
def test_Style():

    dummy_rule = RenderType("dummy_rule", "dummy_rule")

    try:
        style = Style(dummy_rule, value="Hello World.")
    except ValueError:
        # This should not be raised.
        assert False

    assert style.value == "Hello World."
    assert len(style.rules) == 1
    assert isinstance(style.rules[0], RenderType)
    assert style.rules[0] == dummy_rule

    assert style == "Hello World."
    assert style == Style(dummy_rule, value="Hello World.")

    style2 = Style(dummy_rule, value="Test.")
    assert style2 != style
    assert style2 == Style(dummy_rule, value="Test.")

# Generated at 2022-06-24 04:55:08.308597
# Unit test for constructor of class Register
def test_Register():

    r: Register = Register()
    assert r.renderfuncs == {}
    assert r.is_muted is False



# Generated at 2022-06-24 04:55:09.457238
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r

# Generated at 2022-06-24 04:55:17.595798
# Unit test for constructor of class Style
def test_Style():
    class Foo(RenderType):
        def __init__(self, n: int):
            self.n = n

        def get_ansi(self) -> str:
            return f"\033[{self.n};Foo"

        def __eq__(self, other):
            return self.n == other.n

    f1 = Foo(1)
    f2 = Foo(2)

    s1 = Style(f1)
    s2 = Style(s1)
    s3 = Style(f2, s2)

    assert isinstance(s1, Style)
    assert isinstance(s2, Style)
    assert isinstance(s3, Style)

    assert len(s1.rules) == 1
    assert len(s2.rules) == 1
    assert len(s3.rules) == 2
   

# Generated at 2022-06-24 04:55:28.527963
# Unit test for method __new__ of class Style
def test_Style___new__():

    class X(RenderType):
        pass
        
    class Y(RenderType):
        pass


    x1 = X(42)
    x2 = X(13)
    y1 = Y(144)
    y2 = Y(117)

    style1 = Style(x1, x2, value="ABC")
    style2 = Style(style1, y1, y2)

    reg = Register()
    reg.set_renderfunc(X, lambda x: "X" + str(x))
    reg.set_renderfunc(Y, lambda y: "Y" + str(y))

    setattr(reg, "abc", style1)
    setattr(reg, "def", style2)

    assert str(reg.abc) == "ABC"

# Generated at 2022-06-24 04:55:37.971765
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Sgr

    rg = Register()
    new_style = Style(Sgr(3))
    setattr(rg, "test", new_style)

    assert str(rg("test")) == new_style
    assert str(rg(3)) == ""

    rg.set_eightbit_call(Sgr)

    assert str(rg(3)) == new_style

    rg.mute()

    assert str(rg("test")) == ""
    assert str(rg(3)) == ""

    rg.unmute()

    assert str(rg("test")) == new_style
    assert str(rg(3)) == new_style

    rg.mute()

    assert str(rg("test")) == ""
    assert str(rg(3)) == ""


# Generated at 2022-06-24 04:55:48.579464
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr, RgbBg

    class R(Register):
        pass

    rf = {"RgbFg": lambda a: "fgfunc: " + str(a), "Sgr": lambda a: "sgrfunc: " + str(a)}
    r = R()
    r.renderfuncs = rf

    r.test_style = Style(RgbFg(12, 34, 56), Sgr(1))

    assert r.test_style == "fgfunc: (12, 34, 56)sgrfunc: 1"

    r.test_style2 = Style(Sgr(1), Style(Sgr(1), Style(RgbFg(12, 34, 56), Sgr(1)), RgbBg(12, 34, 56)), Sgr(1))

    assert r

# Generated at 2022-06-24 04:55:53.946832
# Unit test for method copy of class Register
def test_Register_copy():
    renderfuncs = {}
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, lambda x: x)
    for attr_name in dir(r):
        val = getattr(r, attr_name)
        if isinstance(val, Style):
            setattr(r, attr_name, val)
    r_copy = r.copy()
    # TODO: This test is useless.
    assert r == r_copy

# Generated at 2022-06-24 04:55:55.017220
# Unit test for constructor of class Register
def test_Register():
    fg = Register()


# Generated at 2022-06-24 04:55:57.562153
# Unit test for constructor of class Style
def test_Style():
    expected = Style(fg.blue, s_bold)
    actual = Style(fg.blue, s_bold)
    assert expected == actual

# Generated at 2022-06-24 04:56:07.060433
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test that when a register is muted and then unmuted again, the ANSI
    sequences are restored.
    """
    from .rendertypes import Eightbit, RgbFg, Sgr

    class DummyRegister(Register):
        def __init__(self):
            super().__init__()
            self.set_eightbit_call(Eightbit)
            self.set_rgb_call(RgbFg)

    dummy = DummyRegister()
    dummy.black = Style(Eightbit(0), Sgr(0))
    dummy.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    # Muting register changes styles to strings without ANSI sequences.
    dummy.mute()
    assert dummy.blue == ""
    assert dummy.black == ""

    # Unmuting register restores AN

# Generated at 2022-06-24 04:56:17.472208
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(Sgr(1), value="\x1b[1m"), str)
    assert isinstance(Style(Sgr(1), value="\x1b[1m"), Style)
    assert Style(RgbFg(1, 2, 3), value="\x1b[38;2;1;2;3m") == "\x1b[38;2;1;2;3m"
    assert Style(RgbFg(1, 2, 3), RgbBg(4, 5, 6), value="\x1b[38;2;1;2;3m\x1b[48;2;4;5;6m") == "\x1b[38;2;1;2;3m\x1b[48;2;4;5;6m"

# Generated at 2022-06-24 04:56:21.903195
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    register = Register()
    register.set_renderfunc(RenderType.EIGHTBIT, lambda x: f"Eight-8bit-func({x})")
    register.set_eightbit_call(RenderType.EIGHTBIT)

    assert register(1) == "Eight-8bit-func(1)"
    assert register(144) == "Eight-8bit-func(144)"
    assert register(255) == "Eight-8bit-func(255)"



# Generated at 2022-06-24 04:56:25.861616
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, bg, ef
    a = fg.rgb255
    b = fg.rgb255
    assert a is b

# Generated at 2022-06-24 04:56:31.068018
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Create a new register object with some color attributes.
    r = Register()
    r.test1 = Style(value="\x1b[1m")
    r.test2 = Style(value="\x1b[31m")
    assert r.as_dict() == {"test1": "\x1b[1m", "test2": "\x1b[31m"}



# Generated at 2022-06-24 04:56:37.335030
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    myregister = Register()
    myregister.set_renderfunc(RenderType, lambda x: "RenderType(" + str(x) + ")")

    class MyRegister(Register):
        red = Style(RenderType(100))

    myregister.set_eightbit_call(RenderType)

    assert myregister("red") == myregister(100)

# Generated at 2022-06-24 04:56:43.803136
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class DummyRenderType(RenderType):
        def __init__(self, *args):
            self.arg = "DummyRenderType"
            self.args = args

    def renderfunc(dummyrendertype):
        return "Rendered: " + str(dummyrendertype.arg)

    register = Register()
    register.set_renderfunc(DummyRenderType, renderfunc)
    register.set_eightbit_call(DummyRenderType)

    assert register(10) == "Rendered: DummyRenderType"

# Generated at 2022-06-24 04:56:49.589507
# Unit test for method mute of class Register
def test_Register_mute():
    c = Register()
    c.blue = Style(RgbFg(10, 20, 30), Sgr(1))  # noqa
    c.red = Style(RgbFg(20, 30, 40), Sgr(2))  # noqa
    c.green = Style(RgbFg(30, 40, 50), Sgr(3))  # noqa
    a = c.blue
    assert a == "\x1b[38;2;10;20;30m\x1b[1m"
    b = c.red
    assert b == "\x1b[38;2;20;30;40m\x1b[2m"
    c.mute()
    a = c.blue
    assert a == ""
    b = c.red
    assert b == ""
    c.unmute

# Generated at 2022-06-24 04:56:53.797862
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    c = r.copy()
    r.name = "Test"
    assert r.name == "Test"
    assert c.name == ""

# Generated at 2022-06-24 04:56:56.344420
# Unit test for method mute of class Register
def test_Register_mute():
    R = Register()
    R.blue = Style(RgbFg(10, 20, 30), Sgr(1))
    R.mute()
    assert str(R.blue) == ""



# Generated at 2022-06-24 04:57:03.130228
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    r.red = Style(value="\x1b[38;2;255;0;0m")
    assert str(r("red")) == "\x1b[38;2;255;0;0m"
    assert str(r(255, 0, 0)) == "\x1b[38;2;255;0;0m"
    assert str(r(205)) == ""

# Generated at 2022-06-24 04:57:09.883098
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Set up
    class A(RenderType):
        pass

    class B(RenderType):
        pass

    def f1(*args):
        return "foobar"

    def f2(*args):
        return "barfoo"

    r = Register()
    r.set_renderfunc(A, f1)
    r.set_renderfunc(B, f2)

    # Test
    assert r.renderfuncs[A] == f1
    assert r.renderfuncs[B] == f2

    # Clean up - no clean-up needed


# Generated at 2022-06-24 04:57:17.928834
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class RegisterTest(Register):
        __slots__ = ("test", "test2")

        test: Style = Style()
        test2: Style = Style()

    r = RegisterTest()
    items = r.as_dict()

    assert len(items) == 2
    assert "test" in items
    assert "test2" in items

    # TODO: Test with real data.


# Generated at 2022-06-24 04:57:25.417596
# Unit test for method mute of class Register
def test_Register_mute():
    class TestRegister(Register):
        pass

    # Create register and add some styles to it.
    reg = TestRegister()
    reg.set_eightbit_call(RenderType)
    reg.set_rgb_call(RenderType)

    reg.red = Style(RenderType(1))

    reg.red == "\x1b[1m"  # True

    reg.mute()

    # After mute, no styling should be applied.
    reg.red == ""  # True

    reg.unmute()

    # After unmute, styling should be applied.
    reg.red == "\x1b[1m"  # True



# Generated at 2022-06-24 04:57:29.375979
# Unit test for method copy of class Register
def test_Register_copy():

    # Set up register
    r = Register()
    r.set_renderfunc(RenderType.BOLD, lambda: "")

    r.foo = Style(RenderType.BOLD)

    # Create a copy
    r2 = r.copy()

    # Change property in original register
    r2.foo = "bar"

    # Check that registers are no longer equal.
    assert r.foo != r2.foo



# Generated at 2022-06-24 04:57:40.229252
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method Register.copy
    """
    from .fg import fg
    from .bg import bg
    from .ef import ef

    fg_copy = fg.copy()
    fg_copy.black = Style(RgbFg(0,0,0))
    assert fg.black == Style(RgbFg(0,0,0))
    assert fg_copy.black != Style(RgbFg(0,0,0))

    bg_copy = bg.copy()
    bg_copy.black = Style(RgbFg(0,0,0))
    assert bg.black == Style(RgbFg(0,0,0))
    assert bg_copy.black != Style(RgbFg(0,0,0))

    ef_

# Generated at 2022-06-24 04:57:49.546501
# Unit test for method __new__ of class Style
def test_Style___new__():
    style1 = Style()
    style2 = Style(value="")
    style3 = Style(value="foo")
    style4 = Style(value="bar")
    style5 = Style(style3, value="")
    style6 = Style(style3, style4)

    assert isinstance(style1, Style)
    assert isinstance(style2, Style)
    assert isinstance(style3, Style)
    assert isinstance(style4, Style)
    assert isinstance(style5, Style)
    assert isinstance(style6, Style)

    assert style1 == ""
    assert style2 == ""
    assert style3 == "foo"
    assert style4 == "bar"
    assert style5 == "foo"
    assert style6 == "foobar"

    assert style3.rules == []
    assert style4.rules == []

# Generated at 2022-06-24 04:57:54.653467
# Unit test for method __new__ of class Style
def test_Style___new__():
    sty1 = Style(value = "huhu", rules = [])
    sty2 = Style("huhu", [])
    assert sty1 == sty2
    assert sty1 is not sty2
    assert sty1.rules == sty2.rules
    assert sty1.rules is not sty2.rules


# Generated at 2022-06-24 04:58:03.466624
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit test for method __call__ of class Register
    """

    ###################################################
    # Test Register.__call__(self, *args, **kwargs)
    ###################################################
    def render_func(arg: int) -> str:
        return f"\x1b[{arg}m"

    class RenderTypeA(RenderType):
        pass

    class RegisterA(Register):

        def __init__(self):
            super().__init__()

    fg: RegisterA = RegisterA()
    fg.set_renderfunc(RenderTypeA, render_func)
    fg.set_eightbit_call(RenderTypeA)
    fg.set_rgb_call(RenderTypeA)

    # Test for 8bit call
    assert fg == "\x1b[39m"


# Generated at 2022-06-24 04:58:14.357169
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Create register
    r = Register()

    # Define some render type
    class TestRenderType(RenderType):
        pass

    # Define render function for TestRenderType
    def renderfunc(x):
        return "{}".format(x)

    # Add renderfunc to register
    r.set_renderfunc(TestRenderType, renderfunc)

    # Create some style
    r.test_style = Style(TestRenderType(10))

    # Set some style
    r.test1 = Style(r.test_style)

    # Check if setting a style works
    assert(r.test1 == "10")

    # Set a new style
    r.test1 = Style(TestRenderType(11))

    # Check if setting a style works
    assert(r.test1 == "11")

    # Set a new style


# Generated at 2022-06-24 04:58:21.756277
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert Style("foo").rules == ("foo",)
    assert Style("foo", "bar").rules == ("foo", "bar")
    assert Style("foo").value == "foo"
    assert Style("foo", "bar").value == "foobar"
    assert Style().value == ""
    assert Style(value="foo").rules == ()
    assert Style(value="foo").value == "foo"

# Generated at 2022-06-24 04:58:30.688865
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import RgbFg, Sgr
    from .register import Register
    from .render import render_class_8bit, render_class_rgb

    # Prepare a test register.
    reg = Register()
    reg.set_renderfunc(RgbFg, render_class_rgb)
    reg.set_renderfunc(Sgr, render_class_8bit)
    reg.set_eightbit_call(RgbFg)
    reg.set_rgb_call(RgbFg)
    reg.orange = Style(RgbFg(1,5,10), Sgr(1)) # orange and bold

    # Check if test register is muted by default.
    assert(reg.is_muted is False)

    # Mute the test register.
    reg.mute()

    # Check if

# Generated at 2022-06-24 04:58:40.720283
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import sty

    # Create new register class.
    class Register2(Register):
        pass

    r = Register2()
    r.renderfuncs = {sty.sgr: lambda x, y: "SGR", sty.rgb_bg: lambda x, y, z: "RGB"}

    # First call is ignored.
    assert r(10, 20, 30) is ""

    # Set default rgb-call to rgb_bg
    r.set_rgb_call(sty.rgb_bg)

    # Create new style with rgb_bg
    r.red = sty.Style(sty.rgb_bg(10, 20, 30))

    assert r.red == "RGB"
    assert r.rgb_call == r.renderfuncs[sty.rgb_bg]

    # Method call returns SGR since default rgb-call

# Generated at 2022-06-24 04:58:48.198559
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import Sgr

    # Test constructor
    a = Style(Sgr(1, 2, 3), "ABC")
    assert a == "ABC"
    assert a.rules[0] == Sgr(1, 2, 3)
    assert a.rules[1] == Sgr(1, 2, 3)  # The same as above, because deepcopy is used.



# Generated at 2022-06-24 04:58:58.851792
# Unit test for method __call__ of class Register
def test_Register___call__():

    class FakeRenderType(RenderType):
        pass

    class FakeFunc:
        def __call__(self, *args, **kwargs) -> str:
            return "FakeFunc"

    fb = FakeRenderType(10)
    rg = FakeRenderType(10, 20, 30)
    s = Style(fb, rg)

    # Create register with fake rendertype and renderfunc.
    reg = Register()
    reg.renderfuncs.update({
        FakeRenderType: FakeFunc()
    })

    # Set attribute with Style-object.
    reg.attr = s

    # Set style attributes.
    reg.eightbit = Style(fb)
    reg.rgb = Style(rg)

    assert str(reg.attr) == "FakeFuncFakeFunc"


# Generated at 2022-06-24 04:59:05.777959
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .register import Register

    r = Register()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    r.mute()

    r.blue = Style(RgbBg(0, 0, 255), Sgr(1))

    assert str(r.blue) == ""

    r.unmute()

    assert str(r.blue) == "\x1b[48;2;0;0;255m\x1b[1m"

# Generated at 2022-06-24 04:59:16.197298
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    def dummy_renderfunc(x):
        return x

    def dummy_renderfunc2(x, y):
        return x, y

    # Test one positional argument
    r1 = TestRegister()
    r1.set_renderfunc(RenderType, dummy_renderfunc)
    assert r1(42) == 42

    # Test three positional arguments
    r2 = TestRegister()
    r2.set_renderfunc(RenderType, dummy_renderfunc2)
    assert r2(5, 6, 7) == (5, 6, 7)

    # Test wrong count of positional arguments
    r3 = TestRegister()
    r3.set_renderfunc(RenderType, dummy_renderfunc2)
    assert r3(5) == ""

    # Test keyword arguments
    r4 = TestRegister

# Generated at 2022-06-24 04:59:27.094289
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .fg import Fg
    from .sgr import Sgr
    from .rgb import RgbFg, RgbBg, Rgb

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 255), Sgr(2))

    fg.set_rgb_call(Rgb)

    assert fg.red == "\x1b[38;2;255;0;0m\x1b[1m"
    assert fg.blue == "\x1b[38;2;0;0;255m\x1b[2m"
    assert fg(1, 2, 3) == "\x1b[38;2;1;2;3m"
