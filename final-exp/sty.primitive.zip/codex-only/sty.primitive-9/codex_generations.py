

# Generated at 2022-06-24 04:49:31.851011
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert Style(RgbFg(1, 2, 3)) == "\x1b[38;2;1;2;3m"
    assert Style(RgbFg(1, 2, 3), Sgr(1)) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert Style(RgbFg(1, 2, 3), Sgr(1), value="\x1b[38;2;1;2;3m") == "\x1b[38;2;1;2;3m"

# Generated at 2022-06-24 04:49:40.186774
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    cls = Register()
    cls.foo = Style(value="foo")
    cls.bar = Style(value="bar")
    cls.dup = Style(value="dup")

    nt = cls.as_namedtuple()

    # Test if namedtuple is of type namedtuple
    assert isinstance(nt, tuple)
    assert isinstance(nt, NamedTuple)

    # Test if nt has the correct attributes
    assert hasattr(nt, "foo")
    assert hasattr(nt, "bar")
    assert hasattr(nt, "dup")
    assert not hasattr(nt, "baz")

    # Test if nt has the correct attribute values
    assert getattr(nt, "foo") == "foo"
    assert getattr(nt, "bar") == "bar"
   

# Generated at 2022-06-24 04:49:46.532406
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style(value='\x1b[38;2;1;5;10m\x1b[1m', rules=(RgbFg(1,5,10), Sgr(1)))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == '\x1b[38;2;1;5;10m\x1b[1m'



# Generated at 2022-06-24 04:49:51.980913
# Unit test for method __new__ of class Style
def test_Style___new__():
    fg = Register()
    fg.set_renderfunc(RenderType, lambda x: str(x))
    fg.eightbit = Style(RenderType(42))
    assert isinstance(fg.eightbit, Style)
    assert str(fg.eightbit) == "42"

    fg.intens = Style(fg.eightbit, RenderType(666))
    assert str(fg.intens) == "42666"


# Generated at 2022-06-24 04:49:57.585145
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Create a minimal Register-object
    r = Register()
    r.red = Style("\x1b[31m")

    # Test if dict has red key with ANSI-sequence as value
    assert r.as_dict() == {'red': '\x1b[31m'}



# Generated at 2022-06-24 04:50:06.526629
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import SgrFg, RgbFg, XtermFg

    class DummyRegister(Register):
        def __init__(self):
            super().__init__()
            self.foo = Style(SgrFg(10), XtermFg(10))
            self.bar = Style(RgbFg(10, 2, 5))
            self.set_eightbit_call(SgrFg)
            self.set_rgb_call(RgbFg)

    r = DummyRegister()
    assert r("foo") == r.foo
    assert r(10) == r.renderfuncs[SgrFg](10)
    assert r(10, 2, 5) == r.renderfuncs[RgbFg](10, 2, 5)

# Generated at 2022-06-24 04:50:08.888166
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    # TODO: Write test.
    """
    pass


# Generated at 2022-06-24 04:50:19.746713
# Unit test for method copy of class Register
def test_Register_copy():

    # Make basic style register
    r1 = Register()

    # Add attributes
    r1.bold = Style(Bold())
    r1.light = Style(Bold())

    # Copy register
    r2 = r1.copy()

    # Toggle bold in both
    r1.bold = Style(Bold(False))
    r2.bold = Style(Bold(False))

    # Toggle light in both
    r1.light = Style(Bold(False))
    r2.light = Style(Bold(False))

    # Toggle light in r1 only
    r1.light = Style(Bold())

    # Compare attributes
    assert r1.bold != r2.bold
    assert r1.light != r2.light

    # Mute registers
    r1.mute()
    r2.mute()

# Generated at 2022-06-24 04:50:20.992317
# Unit test for constructor of class Style
def test_Style():
    style = Style()
    assert style == ""


# Generated at 2022-06-24 04:50:29.233984
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class TestType1(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class TestType2(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_func1(r: int, g: int, b: int) -> str:
        return f"R1({r}, {g}, {b})"

    def render_func2(r: int, g: int, b: int) -> str:
        return f"R2({r}, {g}, {b})"

    r = Register()
    r.set_renderfunc(TestType1, render_func1)
    r.set_renderfunc

# Generated at 2022-06-24 04:50:38.918469
# Unit test for method mute of class Register
def test_Register_mute():

    class Rgb: pass

    class Sgr: pass

    fg = Register()

    fg.set_renderfunc(Rgb, lambda x: f"\x1b[38;2;{x}")
    fg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}")

    fg.blue = Style(Rgb(144), Sgr(1))
    assert fg.blue == "\x1b[38;2;144m\x1b[1m"

    fg.mute()
    assert fg.blue == ""

    fg.unmute()
    assert fg.blue == "\x1b[38;2;144m\x1b[1m"


# Generated at 2022-06-24 04:50:41.364243
# Unit test for method __new__ of class Style
def test_Style___new__():
    r1 = Style(value="x")
    r2 = Style(r1, r1, value="y")
    assert isinstance(r1, Style)
    assert isinstance(r1, str)
    assert isinstance(r2, Style)
    assert isinstance(r2, str)



# Generated at 2022-06-24 04:50:44.658074
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Foo(RenderType):
        pass

    def foo_func(*args):
        return "foo"

    reg = Register()
    reg.set_renderfunc(Foo, foo_func)

    reg.red = Style(Foo())

    f = reg.red

    assert isinstance(f, Style)
    assert f == "foo"

    reg.is_muted = True

    f = reg.red

    assert f == ""


# Generated at 2022-06-24 04:50:51.291130
# Unit test for constructor of class Register
def test_Register():

    renderfuncs = {"a": lambda: "a"}
    r = Register()
    r.renderfuncs = renderfuncs

    with pytest.raises(ValueError):
        r.set_renderfunc(None)

    assert r.eightbit_call == r.eightbit_call
    assert r.rgb_call == r.rgb_call

    assert not r.is_muted



# Generated at 2022-06-24 04:50:59.338421
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg

    class TestRegister(Register):
        pass

    # Set rendertype for 'test_register'
    test_register = TestRegister()
    test_register.set_renderfunc(RgbFg, lambda r, g, b: f"{r}, {g}, {b}")

    # Add style attributes to 'test_register'
    test_register.blue = Style(RgbFg(0, 0, 255))
    test_register.red = Style(RgbFg(255, 0, 0))

    assert str(test_register.red) == "0, 0, 255"
    assert str(test_register.blue) == "255, 0, 0"

    # Test mute/unmute
    test_register.mute()

# Generated at 2022-06-24 04:51:06.627735
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    fg = Register()
    reset = Register()

    Sgr1 = Sgr(1)
    RgbFg2 = RgbFg(10, 50, 100)

    style = Style(Sgr1, RgbFg2)

    fg.set_renderfunc(RgbFg, lambda *args: f"\x1b[38;2;{args[0]};{args[1]};{args[2]}m")
    fg.set_renderfunc(Sgr, lambda *args: f"\x1b[{args[0]}m")

    fg.set_eightbit_call(RgbFg)

    fg.style = style


# Generated at 2022-06-24 04:51:15.191132
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class TestRegister(Register):
        pass

    register: TestRegister = TestRegister()
    register.black = Style(RgbFg(0, 0, 0))
    register.red = Style(RgbFg(255, 0, 0))
    register.green = Style(RgbFg(0, 255, 0))
    register.yellow = Style(RgbFg(255, 255, 0))
    register.blue = Style(RgbFg(0, 0, 255))
    register.magenta = Style(RgbFg(255, 0, 255))
    register.cyan = Style(RgbFg(0, 255, 255))
    register.white = Style(RgbFg(229, 229, 229))
    register.br_black = Style(RgbFg(77, 77, 77))

# Generated at 2022-06-24 04:51:22.491184
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.first = Style(RgbBg(1, 2, 3))
    r.second = Style(RgbBg(4, 5, 6))
    assert r.as_dict() == {'first': '\x1b[48;2;1;2;3m', 'second': '\x1b[48;2;4;5;6m'}

# Generated at 2022-06-24 04:51:32.868201
# Unit test for method mute of class Register
def test_Register_mute():

    from .render import Sgr, Render

    from .rendertype import RgbFg

    from .solarized import solarized

    # Create a register object and mute it.
    r1 = Register()
    r1.set_renderfunc(RgbFg, Render.rgb_fg)
    r1.set_renderfunc(Sgr, Render.sgr)
    r1.rgb_yellow = Style(RgbFg(10, 42, 255), Sgr(1))
    r1.rgb_blue = Style(RgbFg(100, 42, 255), Sgr(1))
    r1.mute()

    # Check that the value of rgb_blue is an empty string.
    assert r1.rgb_blue == ""

    # Unmute the register object and check that the values for the styles changed.

# Generated at 2022-06-24 04:51:39.596786
# Unit test for method unmute of class Register
def test_Register_unmute():
    # Create some names
    class A(RenderType):
        pass

    class B(RenderType):
        pass

    # Create a new register and add a style
    r = Register()
    r.set_renderfunc(A, lambda x: f"\x1b[{x}mA")
    r.set_renderfunc(B, lambda x: f"\x1b[{x}mB")
    r.foo = Style(A("1"), B("2"), B("3"))

    # Check if the style is rendered
    assert r.foo == "\x1b[1mA\x1b[2mB\x1b[3mB"

    # Mute register and check if the style is muted
    r.mute()
    assert r.foo == ""

    # Unmute register and check if the style is unm

# Generated at 2022-06-24 04:51:40.907902
# Unit test for constructor of class Register
def test_Register():
    a = Register()
    assert type(a).__name__ == "Register"



# Generated at 2022-06-24 04:51:42.034157
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert len(dir(register)) == 0


# Generated at 2022-06-24 04:51:48.873075
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class TestRegister(Register):
        pass

    TestRegister.red = Style(RgbFg(255, 0, 0))

    assert str(TestRegister.red) == "\x1b[38;2;255;0;0m"

    TestRegister.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;5;{}m".format(16 + r))
    TestRegister.set_eightbit_call(RgbFg)

    assert TestRegister.red == "\x1b[38;5;196m"

# Generated at 2022-06-24 04:51:49.905524
# Unit test for constructor of class Style
def test_Style():
    Style
    StylingRule



# Generated at 2022-06-24 04:51:51.776871
# Unit test for constructor of class Style
def test_Style():
    # TODO: Improve this unit test
    style = Style()
    assert isinstance(style, Style)



# Generated at 2022-06-24 04:51:58.437847
# Unit test for method unmute of class Register
def test_Register_unmute():
    class R1(Register):
        pass

    r1 = R1()
    r1.blue = Style(RgbFg(0, 0, 255))
    r1.red = Style(RgbFg(255, 0, 0))

    r1.mute()
    assert r1.blue is not str(r1.blue)
    r1.unmute()
    assert r1.blue == str(r1.blue)

# Generated at 2022-06-24 04:52:05.617139
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg
    from .register import Register

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"{r} {g} {b}")

    # Set eightbit-call to RgbFg.
    r.set_eightbit_call(RgbFg)

    # Call register as an eightbit-call.
    s = r(42)

    assert s == "0 0 42"


# Generated at 2022-06-24 04:52:10.515807
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda c: "Test" * c)
    r.bold = Style(Sgr(1))
    assert r.bold == "Test"

    r.mute()
    assert r.bold == ""

    r.unmute()
    assert r.bold == "Test"


# Generated at 2022-06-24 04:52:17.478891
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    fg = Register()
    fg.black = Style(RgbFg(0, 0, 0))
    fg.white = Style(RgbFg(255, 255, 255))
    fg.pink = Style(RgbFg(255, 102, 255))

    if fg.as_dict() != {"white": "\x1b[38;2;255;255;255m", "black": "\x1b[38;2;0;0;0m", "pink": "\x1b[38;2;255;102;255m"}:
        raise AssertionError("Test failed: method as_dict of class Register")



# Generated at 2022-06-24 04:52:27.984644
# Unit test for method __new__ of class Style
def test_Style___new__():

    class TestRenderType(RenderType):
        """
        This is a sample render type that's used for testing the Register and
        Style classes. The resulting sequence is simply "test".
        """

        def __init__(self):
            super().__init__(False, False)

        def render_sequence(self, *args):
            return "test"

    # Test without any args.
    s: Style = Style("test")

    assert s[0] == "t"
    assert str(s) == "test"

    # Test with one rendertype.
    render = TestRenderType()
    s = Style(render, value="test")

    assert isinstance(s.rules[0], TestRenderType)
    assert s[0] == "t"
    assert str(s) == "test"

    # Test with multiple rendertypes.

# Generated at 2022-06-24 04:52:32.655020
# Unit test for method __new__ of class Style
def test_Style___new__():

    class RgbFg:
        def __init__(self, r, g, b):
            pass

    b = Style(RgbFg(1, 2, 3))

    assert isinstance(b, Style)
    assert isinstance(b, str)
    assert str(b) == ''
    assert b.rules == [RgbFg(1, 2, 3)]



# Generated at 2022-06-24 04:52:40.896732
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.x = Style(RgbFg(1, 2, 3), Sgr(1))
            self.y = Style(RgbBg(4, 5, 6), Sgr(1))
            self.unmute()

    reg = MyRegister()

    assert isinstance(reg.as_dict(), dict)
    assert isinstance(reg.as_dict()["x"], str)
    assert isinstance(reg.as_dict()["y"], str)

# Generated at 2022-06-24 04:52:50.772177
# Unit test for constructor of class Register
def test_Register():
    """
    Testing the Register class.
    """

    def black(attribute: str = "") -> str:
        return f"\x1b[{attribute}0m"

    r = Register()
    r.set_renderfunc(type(Rgb()), black)

    # Test attribute 'renderfuncs'
    assert r.renderfuncs[Rgb] == black

    # Test attribute 'eightbit_call'
    assert r.eightbit_call == black

    # Test attribute 'rgb_call'
    assert r.rgb_call == black

    # Test method 'mute'
    r.mute()
    assert r.is_muted

    # Test method 'unmute'
    r.unmute()
    assert not r.is_muted

    # Test method 'set_eightbit_call'

# Generated at 2022-06-24 04:52:59.726930
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.test = Style(Bg24())

    register = TestRegister()

    # Set new render function for Bg24-rendertype.
    register.set_renderfunc(Bg24, lambda r, g, b: f"{r};{g};{b}")

    # Set new render function for Bg8-rendertype.
    register.set_renderfunc(Bg8, lambda c: f"{c}")

    # Set new render function for Bg8-rendertype.
    register.set_renderfunc(Bold, lambda: "bold")

    # Set new render function for Bg8-rendertype.
    register.set_renderfunc(Underline, lambda: "underline")

    # Set new render function

# Generated at 2022-06-24 04:53:02.236849
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg

    class TestRegister(Register):
        pass

    renderfunc = lambda r, g, b: ""

    reg = TestRegister()

    assert reg.rgb_call(10, 42, 255) == ""

    reg.set_renderfunc(RgbBg, renderfunc)
    reg.set_rgb_call(RgbBg)

    assert reg.rgb_call(10, 42, 255) == ""



# Generated at 2022-06-24 04:53:10.909181
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        args = ["r", "g", "b"]

        @classmethod
        def render(cls, r: int, g: int, b: int):
            return "RgbFg({}, {}, {})".format(r, g, b)

    fg = Register()
    rgb = RgbFg(255, 255, 255)
    fg.white = Style(rgb)

    assert str(fg.white) == "RgbFg(255, 255, 255)"


# Generated at 2022-06-24 04:53:21.956658
# Unit test for method __call__ of class Register
def test_Register___call__():

    import sty

    # 1. Create a new custom color register.
    class CustomRegister(Register):
        pass
    register = CustomRegister()
    assert isinstance(register, Register)

    # 2. Add custom render-function.
    def sgr_func(arg1, arg2, arg3):
        return f"{arg1} {arg2} {arg3}"
    register.set_renderfunc(type(sty.rs), sgr_func)
    assert register.renderfuncs[type(sty.rs)] == sgr_func

    # 3. Set up custom attribute.
    register.test_style = Style(sty.rs(1, 2, 3))
    assert hasattr(register, "test_style")
    assert isinstance(register.test_style, str)

    # 4. Check if calling the register directly with an integer

# Generated at 2022-06-24 04:53:30.883863
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MockRenderType(RenderType):

        def __init__(self, *args, **kwargs):
            self.args: List[str] = args

    render_type1 = MockRenderType("foo", "bar", "baz")
    render_type2 = MockRenderType(1, 2, 3)

    rules1: Iterable[StylingRule] = ()
    rules2: Iterable[StylingRule] = (render_type1,)
    rules3: Iterable[StylingRule] = (render_type1, render_type2)

    rules4 = (Style(rules1, value=""),)
    rules5 = (Style(rules1, value=""), Style(rules2, value=""))
    rules6 = (Style(rules1, value=""), Style(rules2, value=""), Style(rules3, value=""))



# Generated at 2022-06-24 04:53:35.860983
# Unit test for method copy of class Register
def test_Register_copy():
    from .style import fg
    fg2 = fg.copy()
    assert fg2.green == '\x1b[32m'

# Generated at 2022-06-24 04:53:38.435141
# Unit test for constructor of class Register
def test_Register():

    f = lambda x: str(x)

    r = Register()

    r.set_renderfunc(str, f)

    r.blue = Style(str("blue"))

    assert(str(r.blue) == "blue")

# Generated at 2022-06-24 04:53:45.345005
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register()
    reg.set_renderfunc(RenderType, lambda *args: args)
    reg.a = Style(RenderType(42), RenderType(101))
    reg_copy = reg.copy()
    assert reg.a == reg_copy.a
    assert reg != reg_copy
    assert reg.a == reg_copy.a
    reg_copy.a = Style(RenderType(13))
    assert not reg.a == reg_copy.a


# Generated at 2022-06-24 04:53:50.207988
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()

    r.set_renderfunc(RenderType, lambda: "a")

    Style("a")

    assert str(r.a) == "a"

    r.mute()

    assert str(r.a) == ""

    r.unmute()

    assert str(r.a) == "a"



# Generated at 2022-06-24 04:53:54.085803
# Unit test for method __new__ of class Style
def test_Style___new__():

    # Test with single rule
    s1 = Style(Sgr(1))
    assert str(s1) == "\x1b[1m"

    # More complex example
    s2 = Style(Sgr(1), RgbFg(255, 0, 0))
    assert str(s2) == "\x1b[38;2;255;0;0m\x1b[1m"

    # Test with stylestring
    s3 = Style("bold red")
    assert str(s3) == "\x1b[1m\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:54:00.113287
# Unit test for constructor of class Style
def test_Style():
    from .colortype import RgbFg, Sgr

    fg_yellow = Style(fg.yellow, RgbFg(1, 2, 3))
    assert fg_yellow == "\\x1b[38;2;1;2;3m\\x1b[38;5;11m"

    yellow_and_bold = Style(fg.yellow, Sgr(1))
    assert yellow_and_bold == "\\x1b[38;5;11m\\x1b[1m"

# Generated at 2022-06-24 04:54:12.120485
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # First create a fg-register and add two renderfuncs to it.
    fg = Register()
    r1: RenderType = Sgr(38, 2)

    @r1.renderfunc
    def f1(*args):
        return f"\x1b[38;2;{args[0]};{args[1]};{args[2]}m"

    r2: RenderType = Sgr(38, 5)

    @r2.renderfunc
    def f2(*args):
        return f"\x1b[38;5;{args[0]}m"

    fg.set_renderfunc(Sgr, f1)
    fg.set_renderfunc(Sgr, f2)

    # Then set default rendertype for rgb-calls to r1 and test if rgb call works.
    f

# Generated at 2022-06-24 04:54:19.382503
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .render import Renderer
    r: Renderer = Renderer()

    color_call: Callable = lambda x: r.apply_styles((r.Foreground(x),), "")
    color_value: Callable = lambda x: r.apply_styles((r.Foreground(x),))

    reg: Register = Register()

    reg.set_eightbit_call(r.Foreground)
    reg.set_rgb_call(r.Foreground)
    reg.set_renderfunc(r.Sgr, r.apply_styles)

    setattr(reg, 'blue', Style(r.Foreground(33), r.Sgr(0, 0, 1)))

    # Setting default renderfunctions
    setattr(reg, '_', Style(r.Foreground(39)))

# Generated at 2022-06-24 04:54:29.558111
# Unit test for method mute of class Register
def test_Register_mute():
    from .rendertype import Sgr
    from .rules import Fg

    def renderfunc(x:int) -> str:
        return f"renderfunc called: {x}"

    reg = Register()
    reg.set_eightbit_call(Fg)
    reg.set_renderfunc(Fg, renderfunc)

    reg.red = Style(Fg(1))

    # No effect because renderfunc is not callable yet
    reg.mute()
    assert reg.red == ""

    # Call eightbit renderfunc
    reg.set_eightbit_call(Fg)
    assert reg.red == "renderfunc called: 1"

    # Now mute the register object and see if the red style is applied correctly
    # once the register object is unmuted again.
    reg.mute()

# Generated at 2022-06-24 04:54:35.748120
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Setup
    r = Register()
    r.foo = Style("\x1b[38;2;255;255;255m")
    r.bar = Style("\x1b[48;2;255;255;255m")

    # Run test
    assert r.as_dict() == {"foo": "\x1b[38;2;255;255;255m", "bar": "\x1b[48;2;255;255;255m"}



# Generated at 2022-06-24 04:54:42.831588
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg, Sgr

    # Create new style object
    my_style = Style(Rgbfg(3,4,5), Sgr(1))

    # Check type
    assert isinstance(my_style, Style)

    # Check string value
    assert str(my_style) == "\x1b[38;2;3;4;5m\x1b[1m"

    # Check rules
    assert my_style.rules == (Rgbfg(3,4,5), Sgr(1))


# Generated at 2022-06-24 04:54:53.893140
# Unit test for method __call__ of class Register
def test_Register___call__():
    import pytest
    from sty import fg, bg, ef, rs

    fg.blue = Style(fg.rgb(1, 1, 255))
    bg.green = Style(bg.rgb(1, 255, 1))
    ef.underline = Style(ef.underline)
    rs.bold = Style(rs.bold)
    rs.reset = Style(rs.reset)

    assert fg.blue == "\x1b[38;2;1;1;255m"
    assert bg.green == "\x1b[48;2;1;255;1m"
    assert ef.underline == "\x1b[4m"
    assert rs.bold == "\x1b[22m"
    assert rs.reset == "\x1b[0m"


# Generated at 2022-06-24 04:55:04.284948
# Unit test for method mute of class Register
def test_Register_mute():
    ff: Register = Register()
    ff.set_renderfunc(RenderType.Sgr, lambda x, y: f"{x}{y}")
    ff.set_renderfunc(RenderType.RgbBg, lambda x, y, z: f"{x}{y}{z}")

    ff.blu = Style(RenderType.Sgr(1), RenderType.RgbBg(10, 20, 30))
    ff.grn = Style(RenderType.Sgr(2), RenderType.RgbBg(40, 50, 60))

    ff.mute()

    assert str(ff.blu) == ""
    assert str(ff.grn) == ""

    ff.unmute()

    assert str(ff.blu) == "10203021"

# Generated at 2022-06-24 04:55:11.788713
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Dummy(RenderType):
        def render(self):
            return

    class DummyRegister(Register):
        def render_dummy(self, *args, **kwargs) -> str:
            return "dummy"

    dummy = DummyRegister()
    dummy.set_eightbit_call(Dummy)
    dummy.set_rgb_call(Dummy)
    dummy.set_renderfunc(Dummy, dummy.render_dummy)
    dummy.dummy = Style(Dummy())

    assert dummy(255) == "dummy"
    assert dummy(42, 1, 0) == "dummy"
    assert dummy("dummy") == "dummy"

    dummy.mute()
    assert dummy(255) == ""
    assert dummy(42, 1, 0) == ""
    assert dummy("dummy")

# Generated at 2022-06-24 04:55:15.613360
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .renderfuncs_terminal import TERMINAL_RENDER_FUNCS, TerminalStyle

    fg = Register()

    for name, func in TERMINAL_RENDER_FUNCS.items():
        fg.set_renderfunc(name, func)

    fg.blue = Style(TerminalFg(4))
    fg.aqua = Style(TerminalFg(6))

    nt = fg.as_namedtuple()
    assert nt.blue == "\x1b[38;5;21m"
    assert nt.aqua == "\x1b[38;5;45m"


# Generated at 2022-06-24 04:55:21.750005
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test if Register.mute works correctly.
    """
    class DummyRegister(Register):
        def __init__(self):
            super().__init__()
            self.a = Style(Sgr(1), value="\x1b[1m")
            self.b = Style(Sgr(2), value="\x1b[2m")
            self.c = Style(Sgr(3), value="\x1b[3m")

    r = DummyRegister()
    assert r.a == "\x1b[1m"
    assert r.b == "\x1b[2m"
    assert r.c == "\x1b[3m"

    r.mute()
    assert r.a == ""
    assert r.b == ""
    assert r.c == ""


# Generated at 2022-06-24 04:55:23.090575
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    return register


print(f"Register = {test_Register()}")

# Generated at 2022-06-24 04:55:29.959291
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .render import Render
    from .rendertype import Sgr, RgbFg

    r = Render()
    r.add_register("test", Register())
    r.test.set_eightbit_call(Sgr)
    r.test.set_rgb_call(RgbFg)
    r.test.set_renderfunc(Sgr, lambda x: "SGR({})".format(x))
    r.test.set_renderfunc(RgbFg, lambda r, g, b: "RGB({},{},{})".format(r, g, b))
    r.test.mute()
    r.test.black = Style(Sgr(30))
    r.test.red = Style(RgbFg(255, 0, 0))

    assert r.test(1) == ""
    assert r

# Generated at 2022-06-24 04:55:33.060357
# Unit test for constructor of class Style
def test_Style():
    rule1 = Style("rule1")
    rule2 = Style("rule2")
    fg = Style("fg", rule1, rule2)
    assert fg == ""
    assert fg.rules == ("rule1", "rule2")


# Generated at 2022-06-24 04:55:38.570014
# Unit test for method __new__ of class Style
def test_Style___new__():

    from . import fg
    from .rendertype import Sgr

    s = Style(Sgr(1), fg.blue, Sgr(0))

    assert str(s) == "\x1b[1m\x1b[38;2;0;0;170m\x1b[0m"
    assert s.rules == (Sgr(1), fg.blue, Sgr(0))


# Generated at 2022-06-24 04:55:48.401205
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr
    from .register import Register
    from .style import Style

    fg = Register()

    # -------------
    # Muted
    fg.mute()

    fg.muted_style = Style(RgbFg(1, 2, 3), Sgr(4))
    assert fg.muted_style == ""

    # ---------------
    # Not muted
    fg.unmute()

    fg.test_style = Style(RgbFg(1, 2, 3), Sgr(4))
    assert fg.test_style == "\x1b[38;2;1;2;3m\x1b[4m"
    # ---------------

# Generated at 2022-06-24 04:55:55.169506
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg

    r1 = Register()
    r1.set_eightbit_call(RgbFg)
    r1.set_rgb_call(RgbFg)
    r1.a = Style(RgbFg(255,0,0))
    r1.b = Style(RgbFg(0,255,0))
    r1.c = Style(RgbFg(0,0,255))
    r1.d = Style(RgbFg(255,0,0))

    assert r1(1,1,1) == "\x1b[38;2;1;1;1m"
    assert r1(0, 1, 255) == "\x1b[38;2;0;1;255m"

# Generated at 2022-06-24 04:56:03.692497
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import fg, Style as S

    fg.red_24bit = S(fg.rgb(255, 0, 0))
    assert fg.red == "\x1b[38;2;255;0;0m"
    assert fg.red_24bit == "\x1b[38;2;255;0;0m"

    fg.set_rgb_call(fg.bg.RgbBg)
    fg.red_24bit = S(fg.rgb(255, 0, 0))
    assert fg.red_24bit == "\x1b[48;2;255;0;0m"

# Generated at 2022-06-24 04:56:05.634993
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(255, 255, 255)), Style)



# Generated at 2022-06-24 04:56:12.704588
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import Sgr

    r = Register()

    r.green = Style(Sgr(1))

    r1 = Register()

    r1.green = Style(Sgr(0))

    assert r1.green != r.green # This works fine.

    r2 = r.copy()

    r2.green = Style(Sgr(0))

    assert r.green != r2.green # This also works fine.

    r.green = Style(Sgr(0))

    assert r.green != r2.green # This works fine.


# Generated at 2022-06-24 04:56:17.461370
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Unit test for method set_renderfunc of class Register
    """
    fg = Register()

    @fg.set_renderfunc
    def test1(*args):
        return "test1"

    @fg.set_renderfunc
    def test2(*args):
        return "test2"

    assert fg.renderfuncs[test1] == test1
    assert fg.renderfuncs[test2] == test2

    # Check if attributes are updated with new renderfunc
    fg.red = test1(5)
    assert str(fg.red) == "test1"
    fg.green = test2("test", "test2")
    assert str(fg.green) == "test2"

    # Check if as_dict method of register works.
    d = fg.as_dict()
   

# Generated at 2022-06-24 04:56:27.589276
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertypes import RgbFg, RgbBg
    from .classes import Fg, Bg

    # Create fg register
    fg = Fg()
    fg.set_rgb_call(RgbFg)
    fg.red = Style(RgbFg(100, 0, 0), value="\x1b[38;2;100;0;0m")

    # Test: 1 parameter call -> fg.red = Style(RgbFg(100, 0, 0), value="\x1b[38;2;100;0;0m")
    expected = "\x1b[38;2;100;0;0m"
    actual = fg("red")
    assert actual == expected

    # Test: 3 parameter call -> RgbFg(100, 0, 0)
    expected

# Generated at 2022-06-24 04:56:37.027486
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Define rendertype and render func for it.
    class A(RenderType):
        pass

    def func_a(*args):
        return str(args)

    # Create Register instance.
    r = Register()

    # Add render type A and render func (func_a)
    r.set_renderfunc(A, func_a)

    # Set rendefunc for rgb-calls.
    r.set_rgb_call(A)

    # Make rgb-call.
    a = r(1, 2, 3)

    assert a == "(1, 2, 3)"



# Generated at 2022-06-24 04:56:46.138963
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, Sgr

    class RegisterTest(Register):
        def __init__(self, func):

            super(RegisterTest, self).__init__()

            self.set_eightbit_call(RgbFg)
            self.set_renderfunc(RgbFg, func)

            self.red = Style(RgbFg(255, 0, 0))

    from .render import Render

    render = Render()

    func = lambda *x: render.render(RgbFg(*x))

    r = RegisterTest(func)

    # This call should not lead to any output
    assert r(144) == ""

    # This call should lead to a red output.
    assert r("red") == r.red

    # After calling the set_eightbit_call method with the RgbFg

# Generated at 2022-06-24 04:56:53.421983
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr

    # setup
    sgr_fn = lambda n: n
    r1 = Register()
    r1.set_renderfunc(Sgr, sgr_fn)
    r2 = Register()
    r2.set_renderfunc(Sgr, lambda n: n)

    # assert
    assert r1.renderfuncs[Sgr] is sgr_fn
    assert r2.renderfuncs[Sgr] is not sgr_fn



# Generated at 2022-06-24 04:56:57.897654
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Unit test for method __new__ of class Style
    """
    r1 = Style(value="a")
    assert isinstance(r1, Style)
    assert str(r1) == "a"
    assert r1.rules == []

    r2 = Style(value="b")
    assert isinstance(r2, Style)
    assert str(r2) == "b"
    assert r2.rules == []

# Generated at 2022-06-24 04:57:07.971355
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    # Define new render func
    def my_renderfunc(a, b):
        return "myfunc({}, {})".format(a, b)

    # Create register object
    r = Register()

    # Add new renderfunc
    r.set_renderfunc(Sgr, my_renderfunc)

    # Add new style using the new renderfunc
    r.foo = Style(Sgr(1, 2, 3))

    # Test if new renderfunc has been set
    assert hasattr(r, "foo")
    assert str(r.foo) == "myfunc(1, 2)myfunc(2, 3)"

    # Test if new renderfunc can be set again
    r.set_renderfunc(Sgr, lambda x, y: "")
    assert hasattr(r, "foo")


# Generated at 2022-06-24 04:57:15.541353
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .rendertype import Epsilon

    from .funcs_base import _RenderSimple, _RenderRgb

    def render_epsilon(f, s, b):
        return "\x1b[{};{};{}m".format(f, s, b)

    rg = Register()
    rg.set_eightbit_call(Epsilon)
    rg.set_rgb_call(Epsilon)
    rg.set_renderfunc(Epsilon, render_epsilon)

    rg.red = Style(Epsilon(10, 2, 3))

    nt = rg.as_namedtuple()

    assert nt.red == str(rg.red)
    assert nt.red == "\x1b[10;2;3m"


# Generated at 2022-06-24 04:57:26.393558
# Unit test for constructor of class Register
def test_Register():

    class RType1(RenderType):
        pass

    class RType2(RenderType):
        pass

    r = Register()
    r.set_renderfunc(RType1, lambda: "\x1b[1m")
    r.set_renderfunc(RType2, lambda: "\x1b[2m")

    r.bold = Style(RType1())
    r.italic = Style(RType2())

    assert r.bold == "\x1b[1m"
    assert r.italic == "\x1b[2m"

    assert r.italic != r.bold

    r.set_eightbit_call(RType1)
    assert r(44) == "\x1b[1m"

    r.set_rgb_call(RType2)

# Generated at 2022-06-24 04:57:33.897046
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg
    from .rendertype import Sgr

    assert Style(RgbFg(1, 5, 10), Sgr(1)) == "\x1b[38;2;1;5;10m\x1b[1m"
    assert Style(RgbFg(1, 5, 10), Sgr(1), "Hello world!") == "Hello world!"
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)).rules[0], RgbFg)

# Generated at 2022-06-24 04:57:43.991665
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbBg, RgbFg, RenderType

    class TestRgb(RenderType):
        def render(self, *args, **kwargs):
            return "TEST"

    FG = Register()
    FG.set_renderfunc(TestRgb, TestRgb.render)
    FG.red = Style(TestRgb(1, 2, 3))
    FG.red_bg = Style(TestRgb(2, 3, 4), RgbFg(3, 2, 1))

    assert FG.red == "TEST"
    assert FG.red_bg == "TEST\x1b[38;2;3;2;1m"
    FG.mute()
    assert FG.red == ""
    assert FG.red_bg == ""

    FG.unmute()
    assert FG

# Generated at 2022-06-24 04:57:45.145478
# Unit test for constructor of class Register
def test_Register():

    reg = Register()

    assert isinstance(reg, Register)



# Generated at 2022-06-24 04:57:50.548378
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.red = Style("foo", "bar")
    r.blue = Style("baz", "qux")

    assert id(r.red) != id(r.copy().red)
    assert r.red.rules == r.copy().red.rules
    assert id(r.blue) != id(r.copy().blue)
    assert r.blue.rules == r.copy().blue.rules

# Generated at 2022-06-24 04:57:58.643413
# Unit test for method unmute of class Register
def test_Register_unmute():
    import pytest
    from .register import Register
    from .rendertype import Sgr

    # create a new object of class Register
    reg = Register()

    # set attributes to object reg
    setattr(reg, "attr1", Style(Sgr(1, 2, 3)))
    setattr(reg, "attr2", Style(Sgr(1, 2, 3)))

    # set render function
    reg.set_renderfunc(Sgr, lambda *args: f"\x1b[{';'.join(str(x) for x in args)}m")

    # mute object reg
    reg.mute()

    # check if value of attributes equal empty string
    assert reg.attr1 == ""
    assert reg.attr2 == ""

    # unmute object reg
    reg.unmute()

    # check if value of attributes not

# Generated at 2022-06-24 04:57:59.822502
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-24 04:58:03.001637
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    reg = Register()
    reg.foo = Style(RenderType)
    reg.bar = Style(RenderType)
    reg.baz = Style(RenderType, RenderType)

    assert reg.as_dict() == {'foo': '', 'bar': '', 'baz': ''}


# Generated at 2022-06-24 04:58:13.891541
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import pytest
    from sty import fg
    mt = fg.as_namedtuple()
    assert mt.black == '\x1b[38;5;16m'
    assert mt.b_red == '\x1b[48;5;9m'
    assert mt.cyan == '\x1b[38;5;14m'
    assert mt.reverse == '\x1b[7m'
    assert mt.bold == '\x1b[1m'
    assert mt.dim == '\x1b[2m'
    assert mt.italic == '\x1b[3m'
    assert mt.red == '\x1b[38;5;9m'

# Generated at 2022-06-24 04:58:24.238919
# Unit test for method __call__ of class Register
def test_Register___call__():

    import sty

    # fg = sty.fg
    fg = Register()
    fg.red = Style(sty.RgbFg(255, 0, 0))
    fg.green = Style(sty.RgbFg(0, 255, 0))

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert fg.green == "\x1b[38;2;0;255;0m"

    assert fg.red == fg(1)
    assert fg.green == fg(2)

    assert fg(1) == "\x1b[38;2;255;0;0m"
    assert fg(2) == "\x1b[38;2;0;255;0m"

    assert fg(3) == ""
   

# Generated at 2022-06-24 04:58:27.947920
# Unit test for method unmute of class Register
def test_Register_unmute():
    class MyRegister(Register):
        pass
    reg = MyRegister()
    reg.red = Style(RgbFg(255, 0, 0))
    reg.mute()
    reg.unmute()

    class R(NamedTuple):
        red: str
    r = R(reg.red)
    assert r.red == '\x1b[38;2;255;0;0m'


# Generated at 2022-06-24 04:58:36.837907
# Unit test for method mute of class Register
def test_Register_mute():
    from .ansi import RgbFg
    from .style import Sty

    sty = Sty()

    # A register object that has not been muted
    reg0 = sty.fg

    assert reg0.red == "\x1b[38;2;255;0;0m"

    reg0.mute()

    assert reg0.red == ""

    reg0.unmute()

    assert reg0.red == "\x1b[38;2;255;0;0m"

    # A register object that has been muted by calling the Sty instance
    assert sty.fg.red == ""

    sty.unmute()

    assert sty.fg.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-24 04:58:38.297016
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert Style() == ""
    assert Style("test") == "test"



# Generated at 2022-06-24 04:58:39.588731
# Unit test for constructor of class Register
def test_Register():

    from .render import Render

    render = Render()

    test_register = Register()

# Generated at 2022-06-24 04:58:47.183348
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define render functions
    def render_RgbFg_xterm256(r: int, g: int, b: int) -> str:
        return "\x1b[38;5;" + str(16 + (36 * r) + (6 * g) + b) + "m"

    def render_RgbFg_xterm24bit(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m"


# Generated at 2022-06-24 04:58:54.036733
# Unit test for method __new__ of class Style
def test_Style___new__():
    style1 = Style(1)
    style2 = Style(1, 2, 3)

    assert style1.value == 1
    assert style2.value == (1, 2, 3)
    assert repr(style1) == "Style(1)"
    assert repr(style2) == "Style(1, 2, 3)"
    assert isinstance(style1, Style)
    assert isinstance(style2, Style)
    assert isinstance(style1, str)
    assert isinstance(style2, str)



# Generated at 2022-06-24 04:59:01.064061
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if deepcopy works properly.
    """
    styledict = {"test": Style(RenderType())}
    register = Register()
    register.__dict__.update(styledict)

    register_copy = register.copy()
    register_copy.test = "42"

    assert register.test == styledict["test"]
    assert register_copy.test == "42"



# Generated at 2022-06-24 04:59:11.329045
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import EightbitFg, EightbitBg, RgbFg, RgbBg, Sgr

    # Create an empty register
    test_register = Register()

    # Define a single render-function for the register.
    def renderfunc(x: int) -> str:
        return f"\x1b[{x}m"

    # Add the render-function to the register.
    test_register.set_renderfunc(EightbitFg, renderfunc)

    # Create a new style
    test_style = Style(EightbitFg(42))

    # Is test_style a Style?
    assert isinstance(test_style, Style)

    # Is test_style a string?
    assert isinstance(test_style, str)

    # Is test_style a Style?

# Generated at 2022-06-24 04:59:14.869621
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-24 04:59:21.545614
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()

    # Test for Eightbit-call.
    r.set_eightbit_call(RenderType.SGR)
    r.set_renderfunc(RenderType.SGR, lambda x: f"\x1b[{x}m")
    assert(r(144) == "\x1b[144m")

    # Test for RGB-call.
    r.set_rgb_call(RenderType.RGB_FG)
    r.set_renderfunc(RenderType.RGB_FG, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    assert(r(10, 42, 255) == "\x1b[38;2;10;42;255m")

    # Test for String-call.

# Generated at 2022-06-24 04:59:28.844068
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Unit test for method mute of class Register.
    """

    # Test muted, eightbit-call, eightbit-rendertype.
    register = Register()
    register.set_renderfunc(RenderType.EIGHTBIT, lambda x: f"{x:03d}")
    register.set_eightbit_call(RenderType.EIGHTBIT)
    register.red = Style(RenderType.EIGHTBIT(1))

    # Test muted, rgb-call, rgb-rendertype.
    register2 = Register()
    register2.set_renderfunc(RenderType.RGB, lambda r, g, b: f"{r:03d}{g:03d}{b:03d}")
    register2.set_rgb_call(RenderType.RGB)