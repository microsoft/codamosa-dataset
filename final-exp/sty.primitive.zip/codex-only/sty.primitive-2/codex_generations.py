

# Generated at 2022-06-24 04:49:30.444215
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test unmute method.
    """
    from .rendertype import Sgr, Reset
    from tests.sty_registers import fg

    # Set up register.
    fg.bold_red = Style(Sgr(1), fg="red")
    fg.reset = Style(Reset())
    fg.mute()

    # Test if muted
    assert fg.bold_red == ""
    assert fg.reset == ""

    # Unmute
    fg.unmute()

    assert isinstance(fg.bold_red, str)
    assert isinstance(fg.reset, str)


# Generated at 2022-06-24 04:49:34.160330
# Unit test for constructor of class Register
def test_Register():
    reg1 = Register()
    assert isinstance(reg1, Register)
    reg2 = Register()
    assert isinstance(reg2, Register)
    assert reg1 is not reg2


# Unit tests for set_eightbit_call and set_rgb_call of class Register

# Generated at 2022-06-24 04:49:41.842759
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .core import fg, bg, rs, ef

    a = fg.as_dict()
    b = fg.as_dict()
    assert a == b

    a = bg.as_dict()
    b = bg.as_dict()
    assert a == b

    a = rs.as_dict()
    b = rs.as_dict()
    assert a == b

    a = ef.as_dict()
    b = ef.as_dict()
    assert a == b

    c = {}
    assert a != c
    assert b != c



# Generated at 2022-06-24 04:49:47.641397
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from . import Sty
    sty_dict = Sty.as_dict()
    sty_nt = Sty.as_namedtuple()
    for k in sty_dict:
        assert getattr(sty_nt, k) == sty_dict[k]
    for k in sty_nt._fields:
        assert getattr(sty_nt, k) == sty_dict[k]


# Generated at 2022-06-24 04:49:53.368746
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Test1(RenderType):
        tokens = ['1', '2']

    def test_funct(*args):
        return ''.join(args)

    r = Register()
    r.set_renderfunc(Test1, test_funct)

    assert r.renderfuncs[Test1] == test_funct

    style = Style(Test1('a', 'b'))
    setattr(r, 'test', style)

    assert r.test == 'ab'



# Generated at 2022-06-24 04:50:04.188044
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import AnsiFg, AnsiBg, RgbFg, RgbBg
    from .renderfunction import ansi_fg, ansi_bg, rgb_fg, rgb_bg

    # Instantiate a new register object.
    r = Register()

    # Install render-functions
    r.set_renderfunc(AnsiFg, ansi_fg)
    r.set_renderfunc(AnsiBg, ansi_bg)
    r.set_renderfunc(RgbFg, rgb_fg)
    r.set_renderfunc(RgbBg, rgb_bg)

    # Install render-types for 8-bit and 24-bit calls.
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(AnsiFg)

    #

# Generated at 2022-06-24 04:50:13.782119
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    This function tests if the as_namedtuple method of the Register class works as
    intended.
    """
    register = Register()

    register.red = Style(RgbFg(10, 0, 0), Sgr(1))
    register.lred = Style(RgbFg(60, 0, 0), Sgr(1))
    register.yellow = Style(RgbFg(10, 10, 0), Sgr(1))

    register_nt = register.as_namedtuple()

    assert register_nt.red == register.red
    assert register_nt.lred == register.lred
    assert register_nt.yellow == register.yellow

# Generated at 2022-06-24 04:50:22.371205
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RenderType1:
        args: Tuple[int, ...]

    class RenderType2:
        args: Tuple[int, ...]

    reg: Register = Register()

    reg.set_renderfunc(RenderType1, lambda a: "renderfunc1:" + str(a))
    reg.set_renderfunc(RenderType2, lambda a, b: "renderfunc2:" + str(a) + str(b))

    s1: Style = Style(RenderType1(42), RenderType2(1, 2))
    assert str(s1) == "renderfunc1:42renderfunc2:12"


# Generated at 2022-06-24 04:50:31.366681
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertypes import RgbFg, RgbBg

    r: Register = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: f"{r},{g},{b}")
    r.set_renderfunc(RgbBg, lambda r, g, b: f"B{r},{g},{b}")

    r.set_rgb_call(RgbFg)
    r.set_rgb_call(RgbBg)

    assert r(244, 212, 140) == "244,212,140"
    assert r(3, 244, 212, 140) == "B3,244,212,140"

# Generated at 2022-06-24 04:50:36.718040
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    # Test 8bit-Call
    test_register.set_eightbit_call(RenderType)
    test_register.renderfuncs[RenderType] = lambda x, y: f"{x}-{y}"

    assert test_register(42, "red") == "42-red"

    # Test RGB-Call
    test_register.set_rgb_call(RenderType)
    test_register.renderfuncs[RenderType] = lambda r, g, b: f"{r}-{g}-{b}"

    assert test_register(42, 245, 12) == "42-245-12"

    # Test invalid calls
    assert test_register() == ""
    assert test_register(1,2,3,4) == ""

# Generated at 2022-06-24 04:50:40.493565
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .ansi import fg, bg, ef, rs

    fg.black = Style(rs, ef.reset)
    fg.black.mute()

    fg.black.unmute()

    assert fg.black.is_muted == False
    assert fg.black == rs + ef.reset

# Generated at 2022-06-24 04:50:43.812024
# Unit test for constructor of class Register
def test_Register():
    fg = Register()
    fg.reset = Style(RenderType.reset, value="")
    assert fg.reset == ""
    assert fg.reset.rules == (RenderType.reset,)



# Generated at 2022-06-24 04:50:55.106471
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Create test rendertype and renderfunc
    class TestType(RenderType):
        def __init__(self, *args):
            self.name = "TestType"
            self.args = args

    def test_render_function(*args):
        return "".join(map(str, args))

    # Create test register
    test = Register()

    # Add renderfunc for TestType
    test.set_renderfunc(TestType, test_render_function)

    # Assert that TestType is now recognized
    assert TestType in test.renderfuncs.keys()

    # Test renderfunc for TestType
    t1 = TestType(1, 2, 3, 4, 5)

    # Assert that renderfunction of TestType is invoked.

# Generated at 2022-06-24 04:51:02.858039
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .modifiers import Sgr, RgbFg, RgbBg

    def noop(*args, **kwargs):
        return ""

    r = Register()
    r.set_renderfunc(Sgr, noop)

    r.red = Style(Sgr(1))
    assert r.red == ""

    r.green = Style(Sgr(2))
    assert r.green == ""

    r.blue = Style(RgbBg(42, 49, 102))
    assert r.blue == ""

    r.orange = Style(RgbFg(1,5,10), Sgr(1))
    assert r.orange == ""


# Generated at 2022-06-24 04:51:12.880654
# Unit test for method copy of class Register
def test_Register_copy():
    """
    This test verifies that the deepcopy operation of registers works properly.
    """
    from .rendertypes.eightbit import EightBit
    from .rendertypes.truecolor import TrueColor

    # Prepare
    from . import style
    from . import fg, bg, ef, rs
    default_register: Register = fg
    default_style_rule_keys = list(default_register.as_dict().keys())
    style.styling_off = True
    bg.set_eightbit_call(EightBit)
    fg.set_rgb_call(TrueColor)
    # Run
    new_register = deepcopy(default_register)
    # Verify
    new_style_rule_keys = list(new_register.as_dict().keys())
    assert default_style_rule_keys == new_style

# Generated at 2022-06-24 04:51:21.701738
# Unit test for constructor of class Register
def test_Register():

    fg = Register()
    fg.red = Style(RgbFg(red=255))
    fg.green = Style(RgbFg(green=255))
    fg.blue = Style(RgbFg(blue=255))

    assert fg.red.value == "\x1b[38;2;255;0;0m"
    assert fg.green.value == "\x1b[38;2;0;255;0m"
    assert fg.blue.value == "\x1b[38;2;0;0;255m"


# Generated at 2022-06-24 04:51:32.372089
# Unit test for constructor of class Register
def test_Register():
    """
    Create an instance of the Register class and check, wether the
    attributes are callable.
    """
    from .defaults import fg, bg, ef, rs

    # Check, if all attributes are callable
    for attr in dir(fg):

        val = getattr(fg, attr)

        if not attr.startswith("_") and callable(val):

            assert attr in ["mute", "set_rgb_calls", "set_eightbit_calls", "as_dict", "copy", "as_namedtuple"]

    # Now check, if the attributes are style-types.
    for attr in dir(fg):

        val = getattr(fg, attr)

        if not attr.startswith("_"):
            assert isinstance(val, Style)

# Generated at 2022-06-24 04:51:43.887090
# Unit test for method __call__ of class Register
def test_Register___call__():

    def eightbit_call(code: int) -> str:
        return f"eightbit-call: {code}"

    def rgb_call(r: int, g: int, b: int) -> str:
        return f"rgb-call: {r}, {g}, {b}"

    def render1(code: int) -> str:
        return f"render1: {code}"

    def render2(r: int, g: int, b: int) -> str:
        return f"render2: {r}, {g}, {b}"

    register = Register()

    # Test default return value:
    assert register() == ""

    # Check if 8bit-renderfunc is called.
    register.eightbit_call = eightbit_call
    assert register(42) == "eightbit-call: 42"

    # Check if rgb

# Generated at 2022-06-24 04:51:51.296110
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFgTest:
        pass

    class RgbBgTest:
        pass

    class StringFgTest:
        pass

    class StringBgTest:
        pass

    renderfuncs: Renderfuncs = {
        RgbFgTest: lambda r, g, b: f"{r} {g} {b}",
        RgbBgTest: lambda r, g, b: f"{r} {g} {b}",
        StringFgTest: lambda s: f"{s}",
        StringBgTest: lambda s: f"{s}",
    }

    reg = Register()

    reg.set_renderfunc(RgbFgTest, renderfuncs[RgbFgTest])

# Generated at 2022-06-24 04:52:01.637744
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg, Sgr, RgbBg

    assert isinstance(Style(RgbFg(1, 1, 1)), Style)

    assert isinstance(Style(RgbFg(1, 1, 1)), str)

    assert str(Style(RgbFg(1, 1, 1))) == "\x1b[38;2;1;1;1m"

    assert Style(RgbFg(1, 1, 1)) == "\x1b[38;2;1;1;1m"

    assert Style(RgbFg(1, 1, 1), Sgr(1)) == "\x1b[38;2;1;1;1m\x1b[1m"


# Generated at 2022-06-24 04:52:04.557024
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register
    assert isinstance(register, Register)


# Unit tests for set_eightbit_call

# Generated at 2022-06-24 04:52:12.292116
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import random
    import string

    reg = Register()
    chars = string.ascii_uppercase
    for char in chars:
        i = random.randint(0, 255)
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        val = random.choice([i, (r, g, b)])
        setattr(reg, char, reg(val))

    d = reg.as_dict()
    for k, v in d.items():
        assert k in chars
        assert v == str(reg(k))

# Generated at 2022-06-24 04:52:20.090021
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Mock1(namedtuple("Mock1", ["args"])):
        @classmethod
        def from_tuple(cls, *args):
            return cls(args=args)
        @staticmethod
        def render(*args):
            return "Mock1: " + str()

    class Mock2(namedtuple("Mock2", ["args"])):
        @classmethod
        def from_tuple(cls, *args):
            return cls(args=args)
        @staticmethod
        def render(*args):
            return "Mock2: " + str()

    R = Register()
    R.set_renderfunc(Mock1, Mock1.render)
    R.set_renderfunc(Mock2, Mock2.render)

# Generated at 2022-06-24 04:52:25.777640
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Given
    r: Register = Register()
    test_func = lambda x: "F"
    r.set_renderfunc(RenderType, test_func)

    # When
    r.set_eightbit_call(RenderType)

    # Then
    assert r.eightbit_call == r.renderfuncs[RenderType]



# Generated at 2022-06-24 04:52:34.356231
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This function tests if the method __setattr__ works as expected.
    """

    # Setup
    def renderfunc(x: int, *args) -> str:
        return f"\x1b[1;{x}m"

    r: Register = Register()
    r.renderfuncs.update({int: renderfunc})

    # Exercise
    r.test = Style(10, 20)

    # Verify
    assert r.test == "\x1b[1;10m\x1b[1;20m"
    assert r.test.rules == (10, 20)

test_Register___setattr__()

# Generated at 2022-06-24 04:52:41.088837
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.eightbit = 42
    r.rgb = (255, 255, 42)

    assert(r.eightbit == r(8))
    assert(r.rgb == r(rgb=rgb(255, 255, 42)))

    return True



# Generated at 2022-06-24 04:52:44.127114
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbBg

    register = Register()

    register.set_eightbit_call(RgbBg)
    assert register(255) == "\x1b[48;5;255m"



# Generated at 2022-06-24 04:52:53.927374
# Unit test for method copy of class Register
def test_Register_copy():

    import sys
    import unittest

    register1 = Register()
    register2 = Register()

    register1.fg = Style(RgbFg(0,0,0), Sgr(1))
    register2.fg = Style(RgbFg(0,0,0))

    assert register1.copy().fg == "\x1b[38;2;0;0;0m\x1b[1m"
    assert register2.copy().fg == "\x1b[38;2;0;0;0m"

# # Unit test for method set_renderfunc
# def test_Register_set_renderfunc():
#
#     import unittest
#
#     register = Register()
#
#     register.set_renderfunc(CsiForeground, lambda x: "")
#
#     register.fg

# Generated at 2022-06-24 04:53:00.180130
# Unit test for method __call__ of class Register
def test_Register___call__():
    r1 = Register()

    assert r1(1) == ""
    assert r1() == ""
    assert r1(1, 2, 3) == ""
    assert r1("red") == ""

    r1.red = Style(value="123")
    assert r1("red") == "123"

    r1.blue = Style(value="321")
    assert r1(2, 3, 4) == ""
    assert r1.blue == "321"
    assert r1("blue") == "321"

# Generated at 2022-06-24 04:53:10.711994
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Create a new register-object.
    testreg = Register()

    # Add a renderfunc to register.
    def render_bg(code: int) -> str:
        return "\x1b[0;7{}m".format(code)

    testreg.set_renderfunc(RenderType, render_bg)

    # Create a style.
    s1 = Style(value="\x1b[7;31m")

    # Set style as attribute to register-object.
    testreg.my_style = s1

    # Mute register.
    testreg.mute()

    # The style attribute should be an empty string now.
    assert testreg.my_style == ""

    # Unmute register.
    testreg.unmute()

    # The style attribute has the same value as before.
    assert testreg

# Generated at 2022-06-24 04:53:21.917157
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import RgbBg, SgrBg, SgrFg

    r = Register()

    r.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r.set_renderfunc(SgrBg, lambda c: f"\x1b[48;5;{c}m")
    r.set_renderfunc(SgrFg, lambda c: f"\x1b[38;5;{c}m")

    r.red = Style(SgrFg(1))
    r.green = Style(SgrFg(2))
    r.blue = Style(SgrFg(4))


# Generated at 2022-06-24 04:53:30.014630
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))
    r.green = Style(RgbFg(0, 255, 0))

    d = r.as_dict()

    assert d["red"] == "\x1b[38;2;255;0;0m"
    assert d["blue"] == "\x1b[38;2;0;0;255m"
    assert d["green"] == "\x1b[38;2;0;255;0m"


# Generated at 2022-06-24 04:53:38.182685
# Unit test for method mute of class Register
def test_Register_mute():
    """
    A test function for the method mute of class Register.
    """
    from .rendertype import RgbFg

    def my_renderfunc(r, g, b):
        return "Test"

    r = Register()
    r.set_renderfunc(RgbFg, my_renderfunc)

    # Normal use
    r.test_rgb = Style(RgbFg(1, 2, 3))
    assert str(r.test_rgb) == "Test"

    # Muted
    r.mute()
    assert str(r.test_rgb) == ""

    # Unmuted again
    r.unmute()
    assert str(r.test_rgb) == "Test"

# Generated at 2022-06-24 04:53:40.073403
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r2 = r.copy()

    assert r is not r2
    assert r.renderfuncs is not r2.renderfuncs

# Generated at 2022-06-24 04:53:51.236737
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Create a new register to test unmuting.
    my_register = Register()

    # Create a style and add it to the new register
    my_style = Style("foo")
    setattr(my_register, "my_style", my_style)

    # Make sure that the style was added to the register
    assert hasattr(my_register, "my_style")

    # Mute the register
    my_register.mute()

    # Make sure that the style object was updated in the register object
    assert str(getattr(my_register, "my_style")) == ''

    # Unmute the register
    my_register.unmute()

    # Make sure that the style object was updated in the register object
    assert str(getattr(my_register, "my_style")) == 'foo'

# Generated at 2022-06-24 04:54:00.897844
# Unit test for method __call__ of class Register
def test_Register___call__():

    from sty import fg

    class Rgb(str, RenderType):
        def __new__(cls, fg: int, bg: int, ef: int) -> str:
            return super().__new__(cls, f"\x1b[{fg};{bg};{ef}m")

        @classmethod
        def from_rgb(cls, r: int, g: int, b: int) -> "Rgb":
            return cls(r, g, b)

    fg.set_rgb_call(Rgb)
    assert fg("red") == fg(Rgb.from_rgb(255, 0, 0)) == f'\x1b[255;0;0m'
    assert fg(120) == fg(Rgb(120, 0, 0)) == f

# Generated at 2022-06-24 04:54:12.885413
# Unit test for method __call__ of class Register
def test_Register___call__():

    def test_call(register, result_keys):

        values_from_render: List[str] = []
        values_from_attr: List[str] = []

        for key in result_keys:

            attr_value: str = getattr(register, key)
            call_value: str = register(key)

            values_from_render.append(call_value)
            values_from_attr.append(attr_value)

        assert values_from_attr == values_from_render

    # Sixbit-register, no Eightbit or RGB-call
    rgb = Register()
    rgb.set_renderfunc(RGB, lambda r, g, b: f"{r}-{g}-{b}")

    rgb.red = Style(RGB(0, 0, 255))

# Generated at 2022-06-24 04:54:21.958169
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Create two registers
    r1 = Register()
    r2 = Register()

    # Add rendertype and renderfunc to r1
    r1.set_renderfunc(RenderType, lambda x: x - 5)

    # Define Eightbit-call for r1
    r1.set_eightbit_call(RenderType)

    # Define Eightbit-call for r2
    r1.set_eightbit_call(RenderType)

    # Call registers
    assert str(r1(10)) == "5"
    assert str(r2(10)) == "5"

    # Change Eightbit-call for r2
    def minus(x):
        return x - 2

    r1.set_eightbit_call(RenderType, minus)

    # Call registers
    assert str(r1(10)) == "8"


# Generated at 2022-06-24 04:54:28.828170
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import Sgr

    style = Style(Sgr(1), "bla", Sgr(0))

    assert style.rules[0] == Sgr(1)
    assert style.rules[1] == "bla"
    assert style.rules[2] == Sgr(0)
    assert str(style) == "\x1b[1m"



# Generated at 2022-06-24 04:54:37.639917
# Unit test for constructor of class Register
def test_Register():
    st1 = Style(RgbFg(1, 4, 5), Sgr(1, 2))
    r1 = Register()
    r1.red = st1
    r1.green = "blue"
    assert(r1.red == "")
    assert(r1.green == "blue")
    r1.set_renderfunc(RgbFg, lambda r, g, b: "RgbFg({},{},{})".format(r, g, b))
    r1.set_renderfunc(Sgr, lambda *args: "Sgr({})".format(list(args)))
    r1.red = st1
    assert(r1.red == "RgbFg(1,4,5)Sgr(1,2)")
    assert(r1.green == "blue")

# Generated at 2022-06-24 04:54:44.680488
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Unit test for method set_rgb_call of class Register
    """

    def render_func1(r: int, g: int, b: int) -> str:
        return f"\x1b[0;38;2;{r};{g};{b}m"

    def render_func2(r: int, g: int, b: int) -> str:
        return f"\x1b[1;38;2;{r};{g};{b}m"

    register = Register()

    class RenderType1(RenderType):
        def __init__(self, *args, **kwargs):
            pass

    class RenderType2(RenderType):
        def __init__(self, *args, **kwargs):
            pass


# Generated at 2022-06-24 04:54:54.642571
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg, RgbBg, Utf8, Eightbit

    fg = Register()
    fg.renderfuncs = {RgbFg: lambda *x: "RgbFg-call", Eightbit: lambda *x: "Eightbit-call"}
    fg.black = Style(RgbFg(0, 0, 0))

    fg.mute()
    print(fg.black)
    assert fg.black == ""
    fg.unmute()
    assert fg.black == "RgbFg-call"

    # Test Eightbit-calls
    fg.set_eightbit_call(Eightbit)
    fg.mute()
    print(fg(42))
    assert fg(42) == ""
    fg.unmute()


# Generated at 2022-06-24 04:55:04.614197
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class MockClass(RenderType):
        name = "Mock"

    class MockClass2(RenderType):
        name = "Mock2"

    def mock_render_func(*args, **kwargs) -> str:
        return "Mock"

    def mock_render_func2(*args, **kwargs) -> str:
        return "Mock2"

    reg1 = Register()

    reg1.set_renderfunc(MockClass, mock_render_func)
    reg1.set_renderfunc(MockClass2, mock_render_func2)

    assert reg1.renderfuncs[MockClass] == mock_render_func
    assert reg1.renderfuncs[MockClass2] == mock_render_func2

# Generated at 2022-06-24 04:55:13.809771
# Unit test for constructor of class Register
def test_Register():

    def r1(code):
        # Renderfunction for Sgr-rendertype
        return f"\x1b[{code}m"

    def r2(r, g, b):
        # Renderfunction for RgbFg-rendertype
        return f"\x1b[38;2;{r};{g};{b}m"

    # Create Register object with two renderfunctions:
    sty = Register()
    sty.set_renderfunc(Sgr, r1)
    sty.set_renderfunc(RgbFg, r2)

    # Set attributes
    sty.red = Style(RgbFg(255, 0, 0))
    sty.bold = Style(Sgr(1))
    sty.bold_red = Style(sty.bold, sty.red)
    sty.bold_red_bg = Style

# Generated at 2022-06-24 04:55:19.250293
# Unit test for constructor of class Register
def test_Register():
    a = Register()
    b = Register()
    a.set_renderfunc(RenderType, lambda x: x)
    a.set_eightbit_call(RenderType)
    assert a.eightbit_call == b.eightbit_call == RenderType

# Generated at 2022-06-24 04:55:20.025113
# Unit test for constructor of class Style
def test_Style():
    # TODO
    assert True == True

# Generated at 2022-06-24 04:55:26.303782
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Sgr, RgbBg

    class MockRegister(Register): pass

    def render_sgr(*args):
        return "".join(["\x1b[{}m".format(arg) for arg in args])

    def render_rgb(*args):
        return '\x1b[48;2;{};{};{}m'.format(*args)

    mock_register = MockRegister()
    mock_register.set_renderfunc(Sgr, render_sgr)
    mock_register.set_renderfunc(RgbBg, render_rgb)
    mock_register.blue = Style(Sgr(1), RgbBg(10, 50, 100))

    assert isinstance(mock_register.blue, Style)

# Generated at 2022-06-24 04:55:31.982238
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .fmt import fmt, Fmt

    def renderfunc():
        return "RENDERED_WITH_RENDERFUNC"

    fmt.set_renderfunc(Fmt.bold, renderfunc)
    fmt.mute()
    assert str(fmt.bold) == ""
    fmt.unmute()
    assert str(fmt.bold) == "RENDERED_WITH_RENDERFUNC"

    # Reset Fmt object.
    fmt.set_renderfunc(Fmt.bold, Fmt.bold.renderfunc)

# Generated at 2022-06-24 04:55:35.799996
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 5, 10), Sgr(1))

    if style != "\x1b[38;2;1;5;10m\x1b[1m":
        raise ValueError("Constructor of class 'Style' failed.")



# Generated at 2022-06-24 04:55:41.965833
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __new__(cls, r: int, g: int, b: int):
            return super().__new__(cls, r, g, b)

    class RgbBg(RenderType):
        def __new__(cls, r: int, g: int, b: int):
            return super().__new__(cls, r, g, b)

    class EightbitFg(RenderType):
        def __new__(cls, c: int):
            return super().__new__(cls, c)

    class EightbitBg(RenderType):
        def __new__(cls, c: int):
            return super().__new__(cls, c)

    rgbfg_call: Callable = lambda x: "RgbFg"

# Generated at 2022-06-24 04:55:47.397831
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.light = Style(Sgr(1), value="1")
    r.dark = Style(Sgr(0), value="0")
    n = r.as_namedtuple()
    assert isinstance(n, NamedTuple)
    assert isinstance(n, tuple)
    assert n.light == "1"

# Generated at 2022-06-24 04:55:53.871080
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import EightbitFg

    class MyColor(Style):
        fg_red: Style
        fg_gray: Style

    class MyRegister(Register):
        color: MyColor

    r = MyRegister()

    r.set_renderfunc(EightbitFg, lambda x: f"-[{x}]-")
    r.set_eightbit_call(EightbitFg)

    r.color = MyColor()
    r.color.fg_red = Style(EightbitFg(1))
    r.color.fg_gray = Style(EightbitFg(240))

    assert r(1) == "-[1]-", "set_eightbit_call() not working!"
    assert r.color(1) == r.color.fg_red, "set_eightbit_call() not working!"

# Generated at 2022-06-24 04:55:59.365201
# Unit test for method mute of class Register
def test_Register_mute():
    from .sgr import Sgr

    r = Register()
    r.blue = Style(Sgr(4))
    assert str(r.blue) == "\x1b[4m"

    r.mute()
    assert str(r.blue) == ""

    r.unmute()
    assert str(r.blue) == "\x1b[4m"



# Generated at 2022-06-24 04:56:03.273410
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Example style definition
    styling_rule: StylingRule = RenderType(1)

    style = Style(styling_rule, "")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules == (styling_rule,)



# Generated at 2022-06-24 04:56:06.538108
# Unit test for constructor of class Style
def test_Style():

    s = Style(value="\x1b[38;2;1;5;10m")
    assert s.rules == ()
    assert str(s) == "\x1b[38;2;1;5;10m"


# Generated at 2022-06-24 04:56:12.568022
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    assert r.as_namedtuple() == namedtuple("StyleRegister", [])()

    r.reset = Style()
    assert r.as_namedtuple() == namedtuple("StyleRegister", ["reset"])("")

    r.red = Style(Sgr(1))
    assert r.as_namedtuple() == namedtuple("StyleRegister", ["reset", "red"])("", "\x1b[1m")


# Generated at 2022-06-24 04:56:21.197950
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .termrender import string_to_rendertype

    Sty = namedtuple("Sty", "fg")
    sty = Sty(fg=Register())
    sty.fg.renderfuncs = {
        string_to_rendertype(R"\x1b[38;2;{};{};{}m"): lambda r, g, b: r + g + b,
        string_to_rendertype(R"\x1b[{}m"): lambda v: v,
    }
    sty.fg.set_eightbit_call(string_to_rendertype(R"\x1b[38;5;{}m"))
    sty.fg.set_rgb_call(string_to_rendertype(R"\x1b[38;2;{};{};{}m"))


# Generated at 2022-06-24 04:56:33.280918
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    rgba = (0.8, 1.0, 0.4, 0.6)
    renderfuncs = {
        RgbFg: lambda r, g, b: f"\x1b[38;2;{r},{g},{b}m"
    }
    rt = RgbFg(*rgba)
    # Create an instance of class Register
    fg = Register()
    # Add renderfunc to register.
    fg.set_renderfunc(RgbFg, renderfuncs[RgbFg])
    # Assign a Style attribute to the register.
    fg.custom = Style(rt)
    # Assert the assignemnt has worked.
    assert fg.custom == "\x1b[38;2;0.8,1.0,0.4m"
    # Assert

# Generated at 2022-06-24 04:56:41.734586
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    register_obj = Register()
    r1 = Style(RgbFg(1,5,10))
    r2 = Style(RgbBg(1,5,10))
    register_obj.r1 = r1
    register_obj.r2 = r2

    assert str(r1) == ""
    assert str(r2) == ""

    register_obj.set_rgb_call(RgbFg)
    assert str(r1) == "\x1b[38;2;1;5;10m"
    assert str(r2) == "\x1b[48;2;1;5;10m"

    register_obj = Register()
    r1 = Style(RgbFg(1,5,10))
    r2 = Style(RgbBg(1,5,10))
   

# Generated at 2022-06-24 04:56:45.984038
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class TestRegister(Register):
        rule1 = Style(value="")
        rule2 = Style(value="")

    test_reg = TestRegister()

    assert test_reg.as_dict() == {"rule1": "", "rule2": ""}


# Generated at 2022-06-24 04:56:55.740421
# Unit test for constructor of class Register
def test_Register():

    # Create register
    r = Register()

    # Create style-attributes
    r.red = Style(RgbFg(255, 0, 0))

    # Apply render-func
    r.set_renderfunc(RgbFg, lambda r, g, b: f"{r}:{g}:{b}")

    # Test style-attribute
    assert r.red == "255:0:0"

    # Test if register object can be called as function
    r.set_rgb_call(RgbFg)
    assert r(255, 0, 0) == "255:0:0"

    # Test muting
    r.mute()
    assert r.red == ""

    # Test unmuting
    r.unmute()
    assert r.red == "255:0:0"

    # Test as

# Generated at 2022-06-24 04:57:00.927872
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from sty import fg
    rendertype = fg.RgbFg
    renderfunc = lambda r, g, b: "foooooooo"
    fg.set_renderfunc(rendertype, renderfunc)
    assert fg.renderfuncs[rendertype] == renderfunc
    assert fg.red == "foooooooo"


# Generated at 2022-06-24 04:57:10.804425
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg

    fg.blue = Style(RgbFg(0, 0, 255))
    fg.red = Style(RgbFg(255, 0, 0))

    assert fg.blue == '\x1b[38;2;0;0;255m'
    assert fg.red == '\x1b[38;2;255;0;0m'

    # Mute register
    fg.mute()

    assert fg.blue == ''
    assert fg.red == ''

    # Unmute register
    fg.unmute()

    assert fg.blue == '\x1b[38;2;0;0;255m'
    assert fg.red == '\x1b[38;2;255;0;0m'


# Unit test

# Generated at 2022-06-24 04:57:11.994332
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.renderfuncs == {}


# Generated at 2022-06-24 04:57:19.629962
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MyRenderType(RenderType):
        def __init__(self, int_number):
            self.int_number = int_number

        def renderfunc(self, *args):
            return self.int_number

    register = Register()
    register.set_renderfunc(MyRenderType, lambda x: x)

    attr_name = "blue_expected"
    rule = MyRenderType(42)
    value = Style(rule)

    register.__setattr__(attr_name, value)
    assert getattr(register, attr_name) == str(rule), "rendered value must be string representation of rule"

    val = getattr(register, attr_name)
    assert isinstance(val, Style), "rendered attr must be of type Style"



# Generated at 2022-06-24 04:57:24.693512
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightBit, RgbFg

    # Check RgbFg-call
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))

    assert r(42, 68, 99) == (42, 68, 99)

    # Check EightBit-call
    r = Register()
    r.set_renderfunc(EightBit, lambda x: x)

    assert r(42) == 42

    # Check attribute-call
    r = Register()
    r.set_renderfunc(EightBit, lambda x: x)
    r.set_eightbit_call(EightBit)

    r.r = Style(EightBit(42))

    assert r("r") == 42



# Generated at 2022-06-24 04:57:29.412214
# Unit test for method __new__ of class Style
def test_Style___new__():

    assert isinstance(Style(RgbFg(1, 2, 3), Sgr(1)), Style)

    assert isinstance(Style(RgbFg(1, 2, 3), Sgr(1)), str)

    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"

# Unit tests for method __call__ of class Register

# Generated at 2022-06-24 04:57:37.526669
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Create and fill register object
    r = Register()
    r.red = Style("\x1b[31m")
    r.orange = Style("\x1b[38;2;255;127;0m")

    # Test if method works
    nt = r.as_namedtuple()
    assert hasattr(nt, "red")
    assert hasattr(nt, "orange")
    assert nt.red == "\x1b[31m"
    assert nt.orange == "\x1b[38;2;255;127;0m"


# Generated at 2022-06-24 04:57:47.447218
# Unit test for method __new__ of class Style
def test_Style___new__():
    s: Style = Style(value="")
    s2: Style = Style(RgbFg(50, 50, 50), value="")
    s3: Style = Style(Bold, Underline, RgbFg(50, 50, 50), value="")
    s4: Style = Style(
        s,
        RgbFg(50, 50, 50),
        RgbBg(50, 50, 50),
        Reverse,
        Bold,
        italic,
        strike,
        underline,
        no_bold,
        no_italic,
        no_strike,
        no_underline,
        no_reverse,
        no_reset,
        value="",
    )

    assert isinstance(s, Style)
    assert isinstance(s2, Style)

# Generated at 2022-06-24 04:57:54.188986
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RenderTypeExample(RenderType):
        pass

    class RenderTypeExample2(RenderType):
        pass

    def renderfunc_example(x: int) -> str:
        return "F"

    def renderfunc_example2(x: int) -> str:
        return "S"

    x = RenderTypeExample(1)
    y = RenderTypeExample2(2)
    xy = Style(x, y)

    r1 = Register()
    r2 = Register()

    r2.set_renderfunc(RenderTypeExample, renderfunc_example)
    r2.set_renderfunc(RenderTypeExample2, renderfunc_example2)

    r2.example = xy

    assert str(r1.example) == ""
    assert str(r2.example) == "FS"



# Generated at 2022-06-24 04:58:03.207585
# Unit test for method __new__ of class Style
def test_Style___new__():

    class Fg(RenderType):
        pass

    class Bg(RenderType):
        pass

    class Eb(RenderType):
        pass

    colors = Register()

    colors.set_renderfunc(Fg, lambda x: f"\033[38;5;{x}m")
    colors.set_renderfunc(Bg, lambda x: f"\033[48;5;{x}m")
    colors.set_renderfunc(Eb, lambda x, y: f"\033[{x};{y}m")

    colors.default = Style(
        Fg(230), Bg(232), Eb(1, 1), Eb(3, 0), Eb(2, 0)
    )


# Generated at 2022-06-24 04:58:14.128307
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Unit test 'Register' class.
    """
    sty = Register()
    sty.red = Style(30)
    sty.blue = Style(38, 2, 0, 0, 255)

    NamedTuple = sty.as_namedtuple()

    # Check if namedtuple values are correctly exported.
    assert str(NamedTuple.red).strip() == "\x1b[39m"
    assert str(NamedTuple.blue).strip() == "\x1b[38;2;0;0;255m"

    # Check if the values of the namedtuple can be used in the same way as a
    # styler-object.
    assert str(sty(NamedTuple.red)) == "red"
    assert str(sty(NamedTuple.blue, "blue")) == "blue"

# Generated at 2022-06-24 04:58:20.742464
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg

    Renderfuncs = Dict[Type[RenderType], Callable]

    renderfuncs = {
        Eightbit: lambda *args: "Eightbit",
        RgbFg: lambda *args: "RgbFg",
    }

    class TestRegister(Register):
        pass

    t = TestRegister()
    t.renderfuncs = renderfuncs
    assert t(1) == "Eightbit"
    assert t("red") == ""
    assert t(1,2,3) == "RgbFg"
    assert t() == ""
    assert t(None) == ""

    t.mute()
    assert t(1,2,3) == ""
    assert t("red") == ""
    t.unmute()

# Generated at 2022-06-24 04:58:27.971337
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from .renderfuncs import ansi_renderfunc

    register = Register()
    register.set_renderfunc(RgbFg, ansi_renderfunc)

    assert register.rgb_call == register.eightbit_call

    register.set_rgb_call(RgbFg)

    assert register.rgb_call != register.eightbit_call
    assert register.rgb_call == ansi_renderfunc

    register.set_renderfunc(RgbBg, ansi_renderfunc)
    register.set_rgb_call(RgbBg)

    assert register.rgb_call != register.eightbit_call
    assert register.rgb_call == ansi_renderfunc

    # Check that Style-objects are updated
    register.blue

# Generated at 2022-06-24 04:58:33.268646
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()

    r.red = Style(RgbFg(255,0,0))
    r.green = Style(RgbFg(0,255,0))

    assert r.as_dict() == {'red': '\x1b[38;2;255;0;0m', 'green': '\x1b[38;2;0;255;0m'}



# Generated at 2022-06-24 04:58:35.963967
# Unit test for constructor of class Style
def test_Style():
    assert Style(one=1, two=2).one == 1
    assert Style(one=1, two=2).two == 2
    assert Style(one=1, two=2).three is None


# Generated at 2022-06-24 04:58:44.817456
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.a = Style(1, 2)
    assert isinstance(r.a, Style)

# Styles for foregrounds
fg = Register()
fg.default = Style()
fg.black = Style(EightBitFg(0))
fg.red = Style(EightBitFg(1))
fg.green = Style(EightBitFg(2))
fg.yellow = Style(EightBitFg(3))
fg.blue = Style(EightBitFg(4))
fg.magenta = Style(EightBitFg(5))
fg.cyan = Style(EightBitFg(6))
fg.lightgray = Style(EightBitFg(7))
fg.darkgray = Style(EightBitFg(8))
fg.lightred = Style(EightBitFg(9))

# Generated at 2022-06-24 04:58:51.138465
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty.types import RgbFg
    from sty.sgr import Bold

    # Init.
    r1 = Register()
    class Red(RgbFg):
        args = (255, 0, 0)
    r1.red = Style(Red, Bold)
    r1.eightbit_call = lambda x: "8bit"
    r1.rgb_call = lambda r, g, b: "rgb"

    # Test.
    assert r1("red") == "\x1b[38;2;255;0;0m\x1b[1m"
    assert r1(144) == "8bit"
    assert r1(10, 42, 255) == "rgb"

# Generated at 2022-06-24 04:59:02.828717
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    register = Register()
    register.set_renderfunc(str, lambda x: f"{x}_str")
    register.set_renderfunc(int, lambda x: f"{x}_int")

    register.a = Style(str("string_string"))
    register.b = Style(int(42), int(24))

    register.c = Style(register.a, register.b)
    register.d = Style(register.b, str("string_eightbit"))

    register.e = Style(register.c, register.d)
    register.f = Style(register.a, register.b)


# Generated at 2022-06-24 04:59:14.801933
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class RegisterWithStyles(Register):
        """
        This class is a unit test for the method `as_namedtuple` of the base class `Register`.
        """
        style1 = Style(RenderType.simple_type1.NONE)
        style1_1 = Style(RenderType.simple_type2.RED, style1)
        style1_2 = Style(RenderType.simple_type2.GREEN, style1)
        style1_3 = Style(RenderType.simple_type1.BOLD, style1)
        style1_4 = Style(RenderType.simple_type2.BLUE, style1)

        style2 = Style(RenderType.simple_type1.RED, RenderType.simple_type1.BOLD)
        style2_1 = Style(RenderType.simple_type2.BLACK, style2)

# Generated at 2022-06-24 04:59:19.120654
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr
    from .renderfuncs import sgr_to_ansi

    r = Register()
    r.set_renderfunc(Sgr, sgr_to_ansi)
    r.bold = Style(Sgr(1))

    assert str(r.bold) == "\x1b[1m"

    r.set_renderfunc(Sgr, lambda *args: "X")
    assert str(r.bold) == "X"



# Generated at 2022-06-24 04:59:21.652986
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .render.truecolor import RgbFg

    r = Register()
    r.set_eightbit_call(RgbFg)
    assert r(0, 0, 0) == "\x1b[38;2;0;0;0m"