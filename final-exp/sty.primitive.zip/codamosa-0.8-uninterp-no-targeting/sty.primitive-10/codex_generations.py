

# Generated at 2022-06-21 23:55:13.915737
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class Foo(Register):
        bar = Style(value="foo")

    assert Foo().as_dict() == {"bar": "foo"}



# Generated at 2022-06-21 23:55:14.836647
# Unit test for constructor of class Style
def test_Style():
    Style(1, "rgb", "a", 10)

# Generated at 2022-06-21 23:55:19.698124
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r1 = Register()

    class Test(RenderType):
        pass

    r1.set_renderfunc(Test, lambda x : f"Test({x})")

    r1.set_eightbit_call(Test)
    assert r1(5) == "Test(5)"

# Generated at 2022-06-21 23:55:29.742087
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestClass:

        def __init__(self):
            self.renderfuncs = {}
            self.is_muted = False
            self.eightbit_call = lambda x: x
            self.rgb_call = lambda r, g, b: (r, g, b)

    from .types import RgbFg

    register_object = TestClass()

    RgbFgCall = RgbFg(10, 10, 10)

    register_object.set_renderfunc(RgbFg, lambda *args: f"RgbFg({args})")
    register_object.set_eightbit_call(RgbFg)

    assert register_object.eightbit_call(10, 20) == "RgbFg((10, 20))"



# Generated at 2022-06-21 23:55:35.229974
# Unit test for method unmute of class Register
def test_Register_unmute():
    reg = Register()
    reg.is_muted = True

    # Create testcase
    reg.red = Style(Sgr(0xD0))
    assert reg.red == ""

    # Execute test
    reg.unmute()

    # Evaluate results
    assert reg.red == "\x1b[91m"

# Generated at 2022-06-21 23:55:36.626717
# Unit test for constructor of class Register
def test_Register():
    assert Register() is not None



# Unit tests for method copy

# Generated at 2022-06-21 23:55:43.644344
# Unit test for constructor of class Style
def test_Style():
    s = Style(value="hello1")
    assert str(s) == "hello1"

    s = Style(42, value="hello")
    assert str(s) == "hello"

    s = Style(value="hello")
    assert str(s) == "hello"

    with pytest.raises(TypeError):
        # Wrong type in rules.
        s = Style(42, value="hello")



# Generated at 2022-06-21 23:55:47.385657
# Unit test for method unmute of class Register
def test_Register_unmute():
    fg = Register()
    fg.test = Style('')
    fg.mute()
    fg.unmute()
    assert fg.is_muted is False
    assert fg.test == fg.test


# Generated at 2022-06-21 23:55:56.763535
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Color-codes are are identical in this case, because this is the
    # default register.
    r1 = fg
    d1 = r1.as_dict()

    # Check if keys are identical
    assert set(d1.keys()) == set(fg.colors.keys())

    # Check if values at the same keys are identical
    for color in fg.colors:
        assert str(getattr(r1, color)) == d1[color]



# Generated at 2022-06-21 23:56:04.263915
# Unit test for method mute of class Register
def test_Register_mute():
    class RgbFg(RenderType):
        fmt = '\x1b[38;2;%d;%d;%dm'
    class RgbBg(RenderType):
        fmt = '\x1b[48;2;%d;%d;%dm'
    class Sgr(RenderType):
        fmt = '\x1b[%dm'

    class FakeRegister(Register):
        pass
    fg = FakeRegister()

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return RgbFg.fmt % (r, g, b)
    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return RgbBg.fmt % (r, g, b)


# Generated at 2022-06-21 23:56:24.839388
# Unit test for method __new__ of class Style
def test_Style___new__():
    # No value
    sty = Style(RgbFg(1,5,10), Sgr(1))

    assert sty == ""
    assert sty.rules == (RgbFg(1,5,10), Sgr(1))
    assert not isinstance(sty, str)
    assert isinstance(sty, Style)

    # With value
    sty = Style(RgbFg(1,5,10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m")

    assert sty == "\x1b[38;2;1;5;10m\x1b[1m"
    assert sty.rules == (RgbFg(1,5,10), Sgr(1))
    assert isinstance(sty, str)

# Generated at 2022-06-21 23:56:35.824926
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class CustomRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbBg(255, 0, 0))
            self.green = Style(RgbBg(0, 255, 0))
            self.blue = Style(RgbBg(0, 0, 255))

    cr = CustomRegister()

    assert cr.red == "\x1b[48;2;255;0;0m"
    assert cr.green == "\x1b[48;2;0;255;0m"
    assert cr.blue == "\x1b[48;2;0;0;255m"

    cr.set_rgb_call(RgbFg)
    assert cr.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-21 23:56:44.300806
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    def renderfunc(x):
        return "!"

    reg = Register()
    reg.set_eightbit_call(RgbFg, renderfunc)
    rgb = RgbFg(10, 20, 30)
    reg.rgb = rgb

    reg.set_eightbit_call(Sgr, renderfunc)
    sgr = Sgr(1)
    bold = Style(sgr)
    reg.bold = bold

    assert reg.rgb == "!"
    assert reg.bold == "!"
    assert reg.rgb is not rgb
    assert reg.bold is not bold



# Generated at 2022-06-21 23:56:45.780856
# Unit test for constructor of class Register
def test_Register():
    temp = Register()
    assert isinstance(temp, Register)

# Generated at 2022-06-21 23:56:57.046135
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RenderType
    from .rendertype.sgr import Sgr

    r1 = Register()

    # Initial state
    assert len(r1.renderfuncs) == 0
    assert r1._Register__setattr__ is Register.__setattr__

    # set_renderfunc, case 1:
    def renderfunc1(x: int) -> str:
        return f"\x1b[{x}m"

    r1.set_renderfunc(RenderType, renderfunc1)
    assert len(r1.renderfuncs) == 1
    assert r1._Register__setattr__ is not Register.__setattr__
    assert r1._Register__setattr__ is not Register.__setattr__

    # set_renderfunc, case 2:

# Generated at 2022-06-21 23:57:04.063774
# Unit test for method mute of class Register
def test_Register_mute():
    r: Register = Register()
    Style
    r.blue = Style(RgbFg(0x00, 0xff, 0x00))
    r.mute()
    assert str(r.blue) == ""
    r.unmute()
    assert str(r.blue) == "\033[38;2;0;255;0m"



# Generated at 2022-06-21 23:57:06.987208
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    renderfuncs = {RgbFg: lambda x: "RgbFg", RgbBg: lambda x: "RgbBg"}

    r1 = Register()
    r1.renderfuncs = renderfuncs
    r1.set_eightbit_call(RgbFg)

    res1 = r1(1337)
    assert res1 == "RgbFg"

    r1.set_eightbit_call(RgbBg)
    res2 = r1(1337)
    assert res2 == "RgbBg"



# Generated at 2022-06-21 23:57:07.540279
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    pass

# Generated at 2022-06-21 23:57:17.865486
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbBg, Sgr

    # Create style-object with one render-type
    color1 = Style(RgbBg(0, 0, 0), value="\x1b[48;2;0;0;0m")
    assert color1 == "\x1b[48;2;0;0;0m"

    # Create style-object with two render-types.
    color2 = Style(RgbBg(0, 0, 0), Sgr(1), value="\x1b[48;2;0;0;0m\x1b[1m")
    assert color2 == "\x1b[48;2;0;0;0m\x1b[1m"



# Generated at 2022-06-21 23:57:20.545742
# Unit test for constructor of class Register
def test_Register():
    r1 = Register()
    assert r1.renderfuncs == {}
    assert r1.is_muted == False



# Generated at 2022-06-21 23:57:34.854734
# Unit test for method __call__ of class Register
def test_Register___call__():

    def test_1():
        """
        Test class Register for cases when passed exactly one argument.
        """
        reg = Register()
        setattr(reg, "test", "")

        assert reg("test") == ""

        class Rule1(RenderType, NamedTuple):
            renderfunc: Callable = lambda x: x

        setattr(reg, "test", Style(Rule1("123")))

        assert reg("test") == "123"

    def test_2():
        """
        Test class Register for cases when passed exactly three arguments.
        """
        reg = Register()

        class Rule1(RenderType, NamedTuple):
            renderfunc: Callable = lambda x, y, z: (x, y, z)

        setattr(reg, "test", Style(Rule1("123")))

# Generated at 2022-06-21 23:57:36.514850
# Unit test for method unmute of class Register
def test_Register_unmute():
    # TODO: Test class Register
    ...

# Generated at 2022-06-21 23:57:41.657476
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert(reg.renderfuncs == {})
    assert(reg.is_muted == False)

# Generated at 2022-06-21 23:57:46.068203
# Unit test for method __call__ of class Register
def test_Register___call__():
    from . import fg, Sgr

    fg.red = Style(Sgr(1))
    assert fg("red") == str(Sgr(1)) == "\x1b[31m\x1b[1m"

    assert fg(9) == "\x1b[38;5;9m"



# Generated at 2022-06-21 23:57:49.163878
# Unit test for method copy of class Register
def test_Register_copy():

    from .modules import BaseModule

    class TestModule(BaseModule):
        fg = Register()

    m1 = TestModule()
    m2 = m1.copy()

    assert m1 is not m2
    assert m1.fg is not m2.fg

# Generated at 2022-06-21 23:57:59.395970
# Unit test for method unmute of class Register
def test_Register_unmute():

    class MockRender(RenderType):
        code = "x"

    # Create a Register
    reg_mock = Register()

    # Define a style for the register
    reg_mock.foo = Style(MockRender(42, 49, 210))
    assert str(reg_mock.foo) == ""

    # Register is muted by default
    assert reg_mock.is_muted is True
    assert str(reg_mock.foo) == ""

    # Test unmuting
    reg_mock.unmute()
    assert reg_mock.is_muted is False
    assert isinstance(reg_mock.foo, Style)
    assert str(reg_mock.foo) == "x"

    return True

# Generated at 2022-06-21 23:58:10.267250
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .sgr import Sgr

    renderfuncs = {Sgr: lambda x: "SGR_CALL_TEST_SUCCEEDED:" + x}

    def render_function_test(x: int, y: int, z: int) -> str:
        return "RENDER_FUNCTION_TEST_SUCCEEDED:" + str(x) + str(y) + str(z)

    rg = Register()
    rg.set_renderfunc(Sgr, lambda x: "SGR_CALL_TEST_SUCCEEDED:" + x)

    # Assert set_renderfunc works
    assert rg.renderfuncs[Sgr].__doc__ == (
        "renderfunc: `lambda x: \"SGR_CALL_TEST_SUCCEEDED:\" + x`"
    )

   

# Generated at 2022-06-21 23:58:13.986878
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbFg(1,2,3))
    assert isinstance(s, Style)
    assert s.rules == (RgbFg(1,2,3),)


# Generated at 2022-06-21 23:58:21.778313
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty import fg, RgbFg

    assert fg(42).startswith("\x1b[")

    assert fg(42) == "\x1b[38;5;42m"

    assert fg(10, 42, 255) == "\x1b[38;2;10;42;255m"

    fg.set_eightbit_call(RgbFg)

    assert fg(42) == "\x1b[38;2;16;16;16m"

    fg.set_rgb_call(RgbFg)

    assert fg(10, 42, 255) == "\x1b[38;2;10;42;255m"



# Generated at 2022-06-21 23:58:26.483929
# Unit test for method copy of class Register
def test_Register_copy():
    a = Register()
    a.red = Style(ForegroundColor(1))
    b = a.copy()

    # Test object identity to ensure that copy is made
    assert a is not b

    # Test that content of copy is the same as original
    assert a == b


# Generated at 2022-06-21 23:58:35.295584
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Sty's fg object is a register object that uses SgrFg as default rendertype.
    This test changes the rendertype to RgbFg.
    """
    from sty import fg, RgbFg
    fg.set_eightbit_call(RgbFg)
    assert fg(3) == "\x1b[38;2;200;100;100m"



# Generated at 2022-06-21 23:58:41.478704
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Initialize a new TestRegister with a dummy renderfunc.
    class TestRegister(Register):
        def __setattr__(self, name, value):
            return super().__setattr__(name, value)

    t = TestRegister()
    t.set_renderfunc(RenderType, lambda x: "Test")

    # Test if the new renderfunc works.
    assert(isinstance(t.set_renderfunc, Callable))

    assert(str(t.Test) == "Test")

    # Test if the renderfunc can be overwritten by a new renderfunc.
    t.set_renderfunc(RenderType, lambda x: "TEST")

    assert(str(t.Test) == "TEST")


# Generated at 2022-06-21 23:58:43.439752
# Unit test for method copy of class Register
def test_Register_copy():
    a = Register()
    a.foo = Style(1)
    b = a.copy()
    assert a.foo == b.foo
    assert a is not b

# Generated at 2022-06-21 23:58:47.585820
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    
    r1 = Register()
    
    r1.red = Style(RgbFg(255,0,0))
    r1.blue = Style(RgbFg(0,0,255))
    
    assert r1.as_dict() == {
        'red':'\x1b[38;2;255;0;0m',
        'blue':'\x1b[38;2;0;0;255m',
    }

# Generated at 2022-06-21 23:58:55.834964
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.is_muted == False
    assert callable(r.eightbit_call)
    assert callable(r.rgb_call)
    assert r.eightbit_call(1) == 1
    assert r.rgb_call(1, 2, 3) == (1, 2, 3)
    assert r.renderfuncs == {}
    assert r.as_namedtuple().__class__.__name__ == 'StyleRegister'
    assert r.as_dict() == {}


# Generated at 2022-06-21 23:59:04.163185
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Setup
    def rendertype_one(*args):
        return "1"

    def rendertype_two(*args):
        return "2"

    r1 = Register()
    r1.set_renderfunc(RenderType, rendertype_one)
    r1.set_renderfunc(RenderType, rendertype_two)

    # Test case 1:
    test_style = Style(RenderType(), RenderType(), RenderType())
    r1.test_style = test_style
    assert r1.test_style == "111"

    # Test case 2:
    r2 = r1.copy()
    assert r1.test_style == r2.test_style

    # Test case 3:
    r1.mute()
    assert r1.test_style == Style(*test_style.rules, value="")

# Generated at 2022-06-21 23:59:15.478666
# Unit test for constructor of class Style
def test_Style():

    from sty import Sgr

    assert issubclass(Style, str)
    assert isinstance(Style(), str)

    fg_red = Style(**{'value': '\x1b[31m', 'rules': (Sgr(31),)})
    assert isinstance(fg_red, Style)
    assert isinstance(fg_red, str)
    assert str(fg_red) == '\x1b[31m'
    assert fg_red.rules == (Sgr(31),)

    fg_blue = Style(**{'value': '\x1b[34m', 'rules': (Sgr(34),)})
    assert isinstance(fg_blue, Style)
    assert isinstance(fg_blue, str)
    assert str(fg_blue) == '\x1b[34m'


# Generated at 2022-06-21 23:59:25.868505
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MyRenderType(RenderType):
        # No renderfunc needed. Just want to test instances of class RenderType.
        pass

    # Create a test-register with a dummy render-func
    register = Register()
    register.set_renderfunc(MyRenderType, lambda r: "ANSI-CODE")

    # Create a test style
    style = Style(
        MyRenderType(), value=""
    )  # Has to be done in this way to ensure that an __init__ call
    # will be made in the __new__ method.

    # Set attr to test-value
    register.test = style

    # Check
    assert isinstance(register.test, str)
    assert register.test == "ANSI-CODE"
    assert isinstance(register.test, Style)

# Generated at 2022-06-21 23:59:36.643128
# Unit test for method unmute of class Register
def test_Register_unmute():
    # Given
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.test = Style(RgbFg(0,0,0))

        def render(self, *args, **kwargs) -> str:
            return f"{args[0]}{args[1]}{args[2]}"

    register = MyRegister()
    register.set_eightbit_call(RgbFg)
    register.set_rgb_call(RgbFg)
    register.set_renderfunc(RgbFg, register.render)

    # When
    register.mute()
    register.unmute()
    result = register.test
    result2 = register(0,0,0)

    # Then
    assert result == "000"

# Generated at 2022-06-21 23:59:48.109311
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class TestRegister(Register):
        # There are some underscores in the test-attributes because otherwise pyCharm's
        # auto-completion messes with the tests.
        __col1 = Style("\x1b[38;5;13;48;5;11m")
        __col2 = Style("\x1b[38;5;13m", "")
        __col3 = Style("\x1b[38;5;13m")
        __col4 = Style("\x1b[38;5;13m", "\x1b[1m")
        __col5 = Style("\x1b[38;5;13m")
        __col6 = Style("\x1b[38;5;13m", "\x1b[1m")

    r = TestRegister()
    d = r.as_dict

# Generated at 2022-06-22 00:00:09.573395
# Unit test for method copy of class Register
def test_Register_copy():

    class MyRegister(Register):

        def __init__(self):
            super().__init__()

    r1 = MyRegister()
    r1.red = Style(Sgr(1))
    r1.blue = Style(Sgr(2))

    r2 = r1.copy()
    r2.red = Style(Sgr(3))
    r2.blue = Style(Sgr(4))

    assert str(r1.red) == "\x1b[1m"
    assert str(r2.red) == "\x1b[3m"
    assert str(r1.blue) == "\x1b[2m"
    assert str(r2.blue) == "\x1b[4m"


# Generated at 2022-06-22 00:00:19.303507
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def func1(*args, **kwargs):
        return "\x1b[38;2;{};{};{}m".format(*args)

    def func2(*args, **kwargs):
        return "\x1b[48;2;{};{};{}m".format(*args)

    reg = Register()
    reg.set_renderfunc(RgbFg, func1)
    reg.set_renderfunc(RgbBg, func2)

    assert reg.blue == "\x1b[38;2;0;0;255m"
    assert reg.bg.green == "\x1b[48;2;0;255;0m"



# Generated at 2022-06-22 00:00:28.776845
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    
    # Setup
    fg = Register()

    def function_wrapper(eightbit: int) -> str:
        return "\\x1b[38;5;" + str(eightbit) + "m"

    fg.set_eightbit_call(eightbit=function_wrapper)

    fg.black = Style(eightbit=38)
    fg.white = Style(eightbit=48)
    fg.mute()

    # Test
    d = fg.as_dict()
    assert isinstance(d, dict)
    assert len(d) == 1
    assert d["white"] == ""



# Generated at 2022-06-22 00:00:36.391536
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    r = Register()
    r.sgr = Sgr(1)
    # print(r.sgr)  # '\x1b[1m'
    assert r.sgr == '\x1b[1m'
    r.sgr = Sgr(0)
    # print(r.sgr)  # '\x1b[0m'
    assert r.sgr == '\x1b[0m'

    r.is_muted = True
    r.sgr = Sgr(1)
    # print(r.sgr)  # ''
    assert r.sgr == ''

    r.is_muted = False
    r.sgr = Sgr(1)
    # print(r.sgr)  # '\x1b[1m'
    assert r.sgr

# Generated at 2022-06-22 00:00:39.632571
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()
    reg.y = Style(1, 2)
    reg.z = Style(1, 2, 3)

    d = {"y": "\x01\x02", "z": "\x01\x02\x03"}

    assert reg.as_dict() == d



# Generated at 2022-06-22 00:00:42.187200
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RenderType()), Style)

# Generated at 2022-06-22 00:00:49.721510
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test 'unmute' on register objects.
    """
    def test_renderfunc_muted(code):
        return "muted"

    class RenderTypeMuted(RenderType):
        name = "MutedRenderType"
        renderfunc = staticmethod(test_renderfunc_muted)

    k = Register()
    k.set_renderfunc(type(RenderTypeMuted), RenderTypeMuted.renderfunc)

    # Test mute and unmute on style attribute
    k.test_muted = Style(RenderTypeMuted(5))
    assert str(k.test_muted) == "muted"
    k.mute()
    assert str(k.test_muted) == ""
    k.unmute()
    assert str(k.test_muted) == "muted"

    #

# Generated at 2022-06-22 00:00:51.570154
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_eightbit_call(Ansi)
    assert r.eightbit_call(43) == "\x1b[43m"



# Generated at 2022-06-22 00:00:54.555306
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        pass

    tr = TestRegister()

    tr.red = Style(RgbFg(1, 0, 0))
    tr.set_rgb_call(RgbFg)

    assert tr(1, 0, 0) == "\\x1b[38;2;1;0;0m"
    assert tr("red") == "\\x1b[38;2;1;0;0m"

# Generated at 2022-06-22 00:01:00.926219
# Unit test for constructor of class Style
def test_Style():
    s1 = Style(RgbFg(10,20,30), Sgr(1), Sgr(2))

    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert s1 == '\x1b[38;2;10;20;30m\x1b[1m\x1b[2m'



# Generated at 2022-06-22 00:01:23.001847
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register.
    """
    from pygments.formatters import TerminalFormatter

    fmt: TerminalFormatter = TerminalFormatter(bg="black", fg="white")
    fg_copy: Register = fmt.style.fg.copy()

    assert fmt.style.fg.red == fg_copy.red

# Generated at 2022-06-22 00:01:30.484561
# Unit test for method __new__ of class Style
def test_Style___new__():

    class Testclass(RenderType):
        renderfunc = False

        def __new__(cls, value: str):
            cls.renderfunc = True
            return str.__new__(cls, value)  # type: ignore

    reg = Register()
    reg.set_renderfunc(Testclass, lambda x: x)

    val = Style(Testclass("Hello"))
    assert val == "Hello"

    assert isinstance(val, Style)
    assert isinstance(val, str)
    assert val.rules[0].renderfunc



# Generated at 2022-06-22 00:01:39.118356
# Unit test for method mute of class Register
def test_Register_mute():
    a = Style("\x1b[42m")
    b = Style("\x1b[43;1m")

    r1 = Register()
    r1.foo = a
    r1.bar = b

    assert r1.foo == "\x1b[42m"
    assert r1.bar == "\x1b[43m\x1b[1m"

    r1.mute()

    assert r1.foo == ""
    assert r1.bar == ""

    r1.unmute()

    assert r1.foo == "\x1b[42m"
    assert r1.bar == "\x1b[43m\x1b[1m"

# Generated at 2022-06-22 00:01:40.564090
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    fg = Register()
    fg.set_eightbit_call(RenderType)



# Generated at 2022-06-22 00:01:48.020773
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()

    r.test_attribute_1 = Style(value="test value 1")
    r.test_attribute_2 = Style(value="test value 2")
    r.test_attribute_3 = Style(value="test value 3")

    nt = r.as_namedtuple()

    assert nt.test_attribute_1 == "test value 1"
    assert nt.test_attribute_2 == "test value 2"
    assert nt.test_attribute_3 == "test value 3"


# Generated at 2022-06-22 00:01:56.061018
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Foo(RenderType):
        pass

    class Bar(RenderType):
        pass

    class Abc(RenderType):
        pass

    r = Register()

    r.set_eightbit_call(Foo)
    r.set_rgb_call(Abc)

    r.fuchsia = Style(Foo(2))
    r.navy = Style(Abc(200, 200, 200))

    r(2)
    r(200, 200, 200)
    r("fuchsia")
    r("navy")

    r.set_eightbit_call(Bar)
    r.set_rgb_call(Bar)

    r(2)
    r(200, 200, 200)
    r("fuchsia")
    r("navy")

# Generated at 2022-06-22 00:02:02.241795
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbEf, RgbFg
    from .funcs import RenderTypeFunc

    class DummyRegister(Register):
        pass

    dummy_register = DummyRegister()

    dummy_register.renderfuncs = {RgbBg: RenderTypeFunc("bg"), RgbEf: RenderTypeFunc("ef"), RgbFg: RenderTypeFunc("fg")}

    dummy_register.set_rgb_call(RgbBg)

    assert dummy_register.rgb_call("x", "y", "z") == "bgxyz"


# Generated at 2022-06-22 00:02:06.053584
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    fg = Register()
    fg.bold = Style(Sgr(1), RgbFg(1, 0, 0))

    fg.set_renderfunc(Sgr, lambda x: "")
    fg.set_renderfunc(RgbFg, lambda r, g, b: "")

    assert str(fg.bold) == ""


# Generated at 2022-06-22 00:02:15.088426
# Unit test for method copy of class Register
def test_Register_copy():

    # Create a new Register-object
    r1 = Register()

    # Set some attributes
    r1.attr1 = Style()
    r1.attr2 = Style()
    r1.attr3 = Style()

    # Make a deepcopy of r1
    r2 = r1.copy()

    # Change some attributes of r1
    r1.attr1 = Style()
    r1.attr2 = Style()
    r1.attr3 = Style()
    r1.attr4 = Style()

    # Check if attributes of r2 have changed.
    assert r2.attr1.rules == tuple()
    assert r2.attr2.rules == tuple()
    assert r2.attr3.rules == tuple()
    assert r2.attr4 is None

    # Check if attributes of r1 have changed correctly.
    assert r1

# Generated at 2022-06-22 00:02:20.842640
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg, Sgr

    fg = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(fg, Style)
    assert isinstance(fg, str)
    assert str(fg) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-22 00:03:07.044624
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test method Register.__call__
    """

    # Test Eightbit-call with an int
    r1 = Register()

    r1.set_eightbit_call(RenderType("8bit-render-func"))

    r1.renderfuncs[RenderType("8bit-render-func")] = lambda x: x * 2

    assert r1(5) == 10

    # Test RGB-call with a tuple
    r1 = Register()

    r1.set_rgb_call(RenderType("RGB-render-func"))

    r1.renderfuncs[RenderType("RGB-render-func")] = lambda a, b, c: a * b * c

    assert r1(5, 2, 3) == 30

    # Test attribute call with string
    r1 = Register()

    r1.some_styling

# Generated at 2022-06-22 00:03:18.748697
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(RenderType):
        fg: str
        attr: str

        def __init__(self, fg: str, attr: str):
            self.fg = fg
            self.attr = attr

        def __repr__(self) -> str:
            return f"RgbFg({self.fg}, {self.attr})"

        def __str__(self) -> str:
            return f"{self.fg}{self.attr}"

    class RgbBg(RenderType):
        bg: str
        attr: str

        def __init__(self, bg: str, attr: str):
            self.bg = bg
            self.attr = attr


# Generated at 2022-06-22 00:03:30.447631
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .render.eightbit_render import EightbitRender
    from .render.rgb_render import RgbfgRender

    class RegisterTest(Register):
        pass

    r = RegisterTest()

    # Set renderfunc for RgbFg
    r.set_renderfunc(RgbFg, lambda *x: "")

    # Set renderfunc for Sgr
    r.set_renderfunc(Sgr, lambda *x: "")

    r.style1 = Style(RgbFg(1, 2, 3), Sgr(1))
    r.style2 = Style(RgbFg(6, 7, 8), Sgr(2))


# Generated at 2022-06-22 00:03:37.308334
# Unit test for method unmute of class Register
def test_Register_unmute():

    from sty.rendertype import Sgr

    register = Register()
    register.unmute()

    # Check, if this issue is fixed
    # https://github.com/timofurrer/sty/issues/2

    # Create a style
    style = Style(Sgr(1))  # '\x1b[1m'

    assert style == '\x1b[1m'

    # Add style to register
    setattr(register, "foo", style)
    assert getattr(register, "foo") == style == '\x1b[1m'

    # Mute the register
    register.mute()
    assert getattr(register, "foo") == ''

    # Unmute the register
    register.unmute()

# Generated at 2022-06-22 00:03:47.825301
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        pass

    class Eightbit(RenderType):
        pass

    class Rgb(RenderType):
        pass

    class Eightbit2(RenderType):
        pass

    class Rgb2(RenderType):
        pass

    def func(x):
        return str(x)

    def func2(r, g, b):
        return f"RGB: {r}, {g}, {b}"

    reg = Register()

    # Add renderfuncs and set default rendertypes.
    reg.set_renderfunc(Eightbit, func)
    reg.set_eightbit_call(Eightbit)

    reg.set_renderfunc(Rgb, func2)
    reg.set_rgb_call(Rgb)

    # Add syntax for new rendertypes.

# Generated at 2022-06-22 00:03:58.372571
# Unit test for method __call__ of class Register
def test_Register___call__():

    register = Register()

    assert register(42) == ""

    assert register(10, 2, 3) == ""

    register.is_muted = False

    class RgbFg(RenderType):
        rendertype = "fg"

    def renderfunc(*args):
        return "\x1b[38;2;%i;%i;%im" % (args)

    register.set_renderfunc(RgbFg, renderfunc)

    assert register(42) == ""

    assert register(10, 2, 3) == "\x1b[38;2;10;2;3im"

    register.is_muted = False

    register.set_eightbit_call(RgbFg)

    assert register(42) == "\x1b[38;2;42;42;42im"

# Generated at 2022-06-22 00:04:03.608481
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .eightbit import Eightbit, EightbitBg, EightbitFg
    from .sgr import ResetStyle

    rules_1 = [ResetStyle(), EightbitFg(42), EightbitBg(144)]
    rules_2 = [EightbitFg(42), EightbitBg(144), ResetStyle()]

    assert Style(*rules_1) == Style(*rules_2)
    assert Style(*rules_1) != Style(*rules_1, value="\x1b[0m")

# Generated at 2022-06-22 00:04:08.255542
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    # Create new Test-Register
    register = TestRegister()

    # Define new style for test-register
    register.foreground = Style(RgbFg(10, 20, 30))

    from sty.ansi import RgbFg

    assert isinstance(register.foreground, Style)
    assert register.foreground == "\x1b[38;2;10;20;30m"
    assert register.foreground.rules[0] == RgbFg(10, 20, 30)



# Generated at 2022-06-22 00:04:14.609492
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    rgb_call = lambda r, g, b: (r, g, b)
    eightbit_call = lambda x: x
    r.set_rgb_call(rgb_call)
    r.set_eightbit_call(eightbit_call)
    assert r(0) == 0
    assert r(255, 44, 145) == (255, 44, 145)

# Generated at 2022-06-22 00:04:20.021175
# Unit test for constructor of class Style
def test_Style():
    result = Style(RgbFg(255, 255, 255), value='\x1b[38;2;255;255;255m')
    assert str(result) == '\x1b[38;2;255;255;255m'
    assert isinstance(result, Style)
    assert isinstance(result, str)
