

# Generated at 2022-06-21 23:55:20.499175
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    register = Register()

    register.test = Style(value="test-value", rules=[RenderType])
    register.test2 = Style(value="test-value", rules=[RenderType])

    assert isinstance(register.as_dict(), dict)

# Generated at 2022-06-21 23:55:30.893056
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():


    class CustomStyle(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.r = r
            self.g = g
            self.b = b
            self.args = (r, g, b)

    class CustomRegister(Register):
        CYAN = Style(CustomStyle(10, 42, 255))
        PURPLE = Style(CustomStyle(153, 10, 153))

    c = CustomRegister()

    def render_a(r: int, g: int, b: int): return f"A{r}{g}{b}"

    def render_b(r: int, g: int, b: int): return f"B{r}{g}{b}"

    c.set_renderfunc(CustomStyle, render_a)

# Generated at 2022-06-21 23:55:39.341254
# Unit test for constructor of class Style
def test_Style():
    """
    A test to check if the constructor of the Style class works as expected.
    """

    _ = Style("\033[38;2;42;42;42m", "\033[1m", "bright")

    assert isinstance(_, Style)
    assert isinstance(_, str)
    assert str(_) == "\033[38;2;42;42;42m\033[1m"
    assert _.rules == ("\033[38;2;42;42;42m", "\033[1m", "bright")

# Generated at 2022-06-21 23:55:49.191932
# Unit test for method __call__ of class Register
def test_Register___call__():

    class DummyRegister(Register):

        red = Style(RgbFg(1, 5, 10))
        orange = Style(RgbFg(2, 5, 7))
        black = Style(EightFg(0))
        white = Style(EightFg(255))
        blue = Style(EightFg(39))

    r = DummyRegister()
    assert r("orange") == '\x1b[38;2;2;5;7m'
    assert r("red") == '\x1b[38;2;1;5;10m'
    assert r("black") == '\x1b[38;5;0m'
    assert r("white") == '\x1b[38;5;255m'
    assert r("blue") == '\x1b[38;5;39m'

# Generated at 2022-06-21 23:56:00.961872
# Unit test for method mute of class Register
def test_Register_mute():

    from .renders import EightBit, RgbFg, RgbBg, Sgr
    from .register import RenderType, Register

    reg = Register()

    # XXX: Rendering functions need to be defined before the attributes are set.
    # TODO: This bug needs to be fixed.

    def render_func_eightbit(register, val):
        return "\x1b[%im" % val

    def render_func_rgb(register, *args):
        return "\x1b[%i;%i;%im" % args

    reg.set_renderfunc(RenderType.EIGHTBIT, render_func_eightbit)
    reg.set_renderfunc(RenderType.RGB_FG, render_func_rgb)

    reg.red = Style(EightBit(1), Sgr(1))

# Generated at 2022-06-21 23:56:02.730082
# Unit test for constructor of class Style
def test_Style():
    style = Style("style")
    assert issubclass(style.__class__, str)

# Generated at 2022-06-21 23:56:11.235160
# Unit test for constructor of class Register
def test_Register():

    class TestRegister(Register):
        pass

    r = TestRegister()

    assert isinstance(r, Register)

    def render_func(r, g, b):
        return f"{r} {g} {b}"

    r.set_renderfunc(RgbFg, render_func)

    r.blue = Style(RgbFg(0, 0, 255))

    assert r.blue == "0 0 255"

    r.set_rgb_call(RgbBg)

    assert r(0, 255, 0) == "0 255 0"

    # TODO: Test set_eightbit_call


# Generated at 2022-06-21 23:56:16.396939
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .fg import fg
    from .rendertype import RgbFg

    fg.blue = Style( RgbFg(0, 0, 255) )
    expected = {'blue': '\x1b[38;2;0;0;255m'}
    assert fg.as_dict() == expected


# Generated at 2022-06-21 23:56:27.025008
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    new register: 'RgbFg', 'RgbBg', 'EightbitFg', 'EightbitBg', 'EightbitBold', 'Reset'

    old register: 'RgbFg', 'RgbBg', 'EightbitFg', 'EightbitBg', 'Reset'

    expected results:

    Eightbit-call of new register: EightbitFg()
    RGB-call of new register: RgbFg()
    Rgb-call of old register: RgbFg()
    Eightbit-call of old register: EightbitFg()
    """

    from .rendertypes import EightbitFg, EightbitBg, RgbFg, RgbBg, EightbitBold, Reset

    new_register = Register()

# Generated at 2022-06-21 23:56:37.420472
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .basic import Basic
    from .effects import Effects
    from .rendertype import RgbFg, RgbBg, Reset
    from .standard import Standard

    d1 = Basic(0, "red", 0)
    d2 = Standard(0, "red", 0)

    d1.set_eightbit_call(RgbFg)
    d1.set_rgb_call(RgbFg)

    d2.set_eightbit_call(RgbBg)
    d2.set_rgb_call(RgbBg)

    d1.red = Style(RgbFg(200, 0, 0))
    d1.bg_red = Style(RgbBg(200, 0, 0))

    d2.red = Style(RgbBg(200, 0, 0))
    d

# Generated at 2022-06-21 23:56:46.774664
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.test_attr = Style(RgbFg(1, 2, 3))
    r.set_eightbit_call(RgbFg)
    assert r(10) == '\x1b[38;2;10;10;10m'  # type: ignore


# Generated at 2022-06-21 23:56:57.859271
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import AnsiEightBit, AnsiRgb

    def render_eight(num: int, *args, **kwargs):
        return "\x1b[38;5;" + str(num) + "m"

    def render_rgb(r: int, g: int, b: int, *args, **kwargs):
        return "\x1b[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m"

    r = Register()
    r.set_renderfunc(AnsiRgb, render_rgb)
    r.set_renderfunc(AnsiEightBit, render_eight)

    r.set_eightbit_call(AnsiEightBit)
    assert r.eightbit_call == render_eight

    # Set attribute

# Generated at 2022-06-21 23:57:07.059183
# Unit test for method unmute of class Register
def test_Register_unmute():
    import pytest
    register = Register()
    register.test_attribute = Style(Sgr("1"))
    assert hasattr(register, "test_attribute")
    assert not isinstance(register.test_attribute, str)
    assert not register.is_muted
    register.mute()
    assert register.is_muted
    with pytest.raises(AttributeError):
        assert register.test_attribute
    register.unmute()
    assert not register.is_muted
    assert isinstance(register.test_attribute, str)
    assert register.test_attribute == "\x1b[1m"

# Generated at 2022-06-21 23:57:11.123085
# Unit test for constructor of class Register
def test_Register():
    r = Register()

    # Test defining a rule.
    r.rules = [r.rgb_call, r.eightbit_call]

    # Test defining a style.
    r.green = Style("green", r.rgb_call, r.eightbit_call)


# Generated at 2022-06-21 23:57:22.170117
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    import random

    r = Register()
    s = Style(RgbBg(1, 5, 10))
    s2 = Style(RgbFg(1, 5, 10), Sgr(1))
    s3 = Style(RgbBg(1, 5, 10), Sgr(1))

    setattr(r, "s1", s)
    setattr(r, "s2", s2)
    setattr(r, "s3", s3)

    r.set_eightbit_call(RgbBg)

    old_a = getattr(r, "s1")
    old_b = getattr(r, "s2")
    old_c = getattr(r, "s3")

    r.set_eightbit_call(RgbFg)

    assert old_a == getattr

# Generated at 2022-06-21 23:57:33.259540
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Set up register
    fg_register = Register()
    fg_register.set_renderfunc(RgbFg, lambda x, y, z: "test-rgb-fg")
    fg_register.set_renderfunc(Sgr, lambda *args: "test-sgr")

    # Define style
    fg_register.green = Style(RgbFg(10, 10, 10))

    # Check style attribute
    assert isinstance(fg_register.green, Style)
    assert fg_register.green.rules == (RgbFg(10, 10, 10),)
    assert fg_register.green == "test-rgb-fg"



# Generated at 2022-06-21 23:57:38.759075
# Unit test for constructor of class Register
def test_Register():
    def renderfunc1(x: int, y: int) -> str:
        return ""

    def renderfunc2(x: int, y: int) -> str:
        return ""

    register = Register()
    register.set_renderfunc(RenderType, renderfunc1)
    register.set_renderfunc(RenderType, renderfunc2)

# Generated at 2022-06-21 23:57:43.001593
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg
    style = fg.as_namedtuple()

    assert callable(style.red)
    assert callable(style.blue)
    assert type(style.red) == str
    assert type(style.blue) == str

# Generated at 2022-06-21 23:57:52.981293
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class MyRegister(Register):
        pass

    register = MyRegister()
    assert len(register.renderfuncs.keys()) == 0

    class MyRenderType(RenderType):
        pass

    @staticmethod
    def render_myrendertype(x, y, z):
        return f"\x1b[{x};{y};{z}m"

    register.set_renderfunc(MyRenderType, render_myrendertype)

    assert len(register.renderfuncs.keys()) == 1

    register.set_rgb_call(MyRenderType)
    assert register(10, 10, 10) == "\x1b[10;10;10m"

    register.set_eightbit_call(MyRenderType)
    assert register(15) == "\x1b[15;15;15m"

# Generated at 2022-06-21 23:57:57.816455
# Unit test for method copy of class Register
def test_Register_copy():
    """
    This is a test method to check if the copy method works properly.
    """
    from .defaults import fg

    f: Register = fg.copy()

    assert f.copy() is not fg
    assert f.copy() is not f
    assert f.eightbit_call is fg.eightbit_call



# Generated at 2022-06-21 23:58:14.786666
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define a new render type
    class TestRenderType(RenderType):

        def render(self) -> str:
            return "Test"

    # Create a new register with a render-func
    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.set_renderfunc(TestRenderType, TestRenderType.render)

        teal = Style(TestRenderType())

    r = TestRegister()

    # Test, if the render func is correct
    assert r.teal == "Test"

    def new_func(self: TestRenderType) -> str:
        return "Foo"

    r.set_renderfunc(TestRenderType, new_func)

    # Test, if the new render func is correct.
    assert r.teal == "Foo"


# Unit

# Generated at 2022-06-21 23:58:21.779593
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register = Register()
    register.set_renderfunc(RenderType, lambda x: f"{x}!")

    # Set style attribute
    register.mystyle = Style(RenderType(1,2), RenderType(3,4))
    assert register.mystyle == "1!2!3!4!"

    # Mute register
    register.mute()
    assert register.mystyle == ""

    # Unmute register
    register.unmute()
    assert register.mystyle == "1!2!3!4!"

    # Mute register again
    register.mute()
    assert register.mystyle == ""


# Generated at 2022-06-21 23:58:25.479628
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    c = Register()
    c.test = Style(RgbFg(42, 10, 144))
    assert isinstance(c.as_namedtuple(), namedtuple)

# Generated at 2022-06-21 23:58:33.345404
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .register.rendertype import Sgr, RgbBg

    class Reg(Register):
        pass

    r = Reg()
    r.set_renderfunc(Sgr, lambda x: "SGR:{}".format(x))
    r.set_renderfunc(RgbBg, lambda r, g, b: "RGB_BG:{}-{}-{}".format(r, g, b))
    r.set_eightbit_call(Sgr)
    r.set_rgb_call(RgbBg)

    assert r(42, 21, 255) == "RGB_BG:42-21-255"
    assert r(42) == "SGR:42"



# Generated at 2022-06-21 23:58:40.635433
# Unit test for constructor of class Style
def test_Style():
    valid_inp = Style(RgbFg(1, 2, 3), RgbBg(3, 2, 1), Sgr(1, 2, 4))
    assert valid_inp.rules == (RgbFg(1, 2, 3), RgbBg(3, 2, 1), Sgr(1, 2, 4))
    assert str(valid_inp) == "\x1b[38;2;1;2;3m\x1b[48;2;3;2;1m\x1b[1;2;4m"

    invalid_inp = Style(RgbFg(1, 2, 3), (1), Sgr(1, 2, 4))
    try:
        assert invalid_inp
    except ValueError:
        pass
    else:
        assert False


# Unit test

# Generated at 2022-06-21 23:58:42.438824
# Unit test for constructor of class Register
def test_Register():
    r = Register()

# Generated at 2022-06-21 23:58:44.970288
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    value: Style = Style(value="\x1b[1;2;3;4m")

    reg = Register()
    reg.test = value

    assert isinstance(reg.test, Style)
    assert reg.test == value



# Generated at 2022-06-21 23:58:47.367820
# Unit test for constructor of class Register
def test_Register():
    reg_obj = Register()
    assert isinstance(reg_obj, Register)
    assert isinstance(reg_obj.renderfuncs, dict)
    assert isinstance(reg_obj.eightbit_call, type(lambda x: x))
    assert isinstance(reg_obj.rgb_call, type(lambda x: x))



# Generated at 2022-06-21 23:58:53.432318
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import X11Fg

    fg = Register()
    fg.red = Style(X11Fg("red"))
    assert fg.red == "\x1b[38;5;9m"

    # Fail: Type must be Style.
    fg.orange = 3
    try:
        fg.orange

    except TypeError as e:
        assert str(e) == "The value of an attribute must be of type 'Style'."



# Generated at 2022-06-21 23:59:02.919804
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import RgbBg, Sgr

    class MyRegister(Register):
        pass

    myreg = MyRegister()
    myreg.set_renderfunc(RgbBg, lambda r, g, b: "\x1b[48;2;" + ";".join([str(r), str(g), str(b)]) + "m")
    myreg.set_renderfunc(Sgr, lambda x: "\x1b[{}m".format(x))

    myreg.muted_color = Style(RgbBg(1, 2, 3), Sgr(0))

    assert getattr(myreg, "muted_color") == ""

    myreg.unmute()


# Generated at 2022-06-21 23:59:20.873932
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RGB, RGB_BG, RGB_FG, SGR, SGR_BG, SGR_FG

    r1 = Register()

    r1.set_renderfunc(RenderType, lambda x: "<RenderType>")
    r1.set_renderfunc(RGB, lambda x: "<RGB>")
    r1.set_renderfunc(RGB_BG, lambda x: "<RGB_BG>")
    r1.set_renderfunc(RGB_FG, lambda x: "<RGB_FG>")
    r1.set_renderfunc(SGR, lambda x: "<SGR>")
    r1.set_renderfunc(SGR_BG, lambda x: "<SGR_BG>")
    r1.set_renderfunc(SGR_FG, lambda x: "<SGR_FG>")


# Generated at 2022-06-21 23:59:27.054467
# Unit test for constructor of class Style
def test_Style():
    class TestClass(RenderType):
        pass

    tests = [
        (Style(TestClass(None), TestClass(None)), 2),
        (Style(TestClass(None), TestClass(None), "Hello"), 2),
        (Style(TestClass(None)), 1),
        (Style("Hello"), 0),
    ]

    for t in tests:
        style = t[0]
        assert len(style.rules) == t[1]

# Generated at 2022-06-21 23:59:37.890055
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype.rendertypes.rgbfg import RgbFg
    from .rendertype.rendertypes.rgbabg import RgbaBg
    from .rendertype.rendertypes.rgbafg import RgbaFg
    from .rendertype.rendertypes import sgr

    my_register = Register()

    my_register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    my_register.set_renderfunc(RgbaFg, lambda r, g, b, a: f"\x1b[38;2;{r};{g};{b}m")

# Generated at 2022-06-21 23:59:49.207048
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test method mute of class Register.
    """
    from . import ANSIColor
    from .rendertype import Sgr, RgbFg
    from .settings import register_settings

    ANSIColor.setup(register_settings)

    fg = ANSIColor.fg
    bg = ANSIColor.bg

    fg.red = Style(Sgr(31), RgbFg(1, 0, 0))
    bg.blue = Style(Sgr(44), RgbFg(0, 0, 1))

    assert fg.red == "\033[31m\033[38;2;1;0;0m"
    assert bg.blue == "\033[44m\033[38;2;0;0;1m"

    fg.mute()
    bg.m

# Generated at 2022-06-21 23:59:55.804266
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Setup
    r = Register()
    r.white = Style(Bg(255), RgbFg(255, 255, 255))
    r.red = Style(Bg(255), RgbFg(255, 0, 0))

    # Execute
    nt = r.as_namedtuple()

    # Verify
    assert nt.white == "\x1b[48;2;255;255;255m\x1b[38;2;255;255;255m"
    assert nt.red == "\x1b[48;2;255;255;255m\x1b[38;2;255;0;0m"

    # Cleanup
    del r

# Generated at 2022-06-22 00:00:08.718558
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg, rs, sgr
    from sty.eightbit import BrightFg, BrightBg
    from sty.rgb import RgbFg, RgbBg

    test_color_name = "Lavender"

    # Create new register-object
    class RGBColor(Register):
        ...

    rgb_color = RGBColor()

    rgb_color.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m")

# Generated at 2022-06-22 00:00:19.098284
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    def func_returns_parameter1(parameter1: int) -> str:
        return str(parameter1)

    # Create a new register.
    r = Register()

    # Register renderfunc for 8bit color codes.
    r.set_renderfunc(EightBit, func_returns_parameter1)
    r.set_eightbit_call(EightBit)

    # Create style with two rules.
    setattr(r, "my_style", Style(EightBit(255), EightBit(42)))

    # Check type of style.
    assert isinstance(r.my_style, Style)

    # Check, if renderfunc got applied to the style.
    assert str(r.my_style) == "25542"

# Generated at 2022-06-22 00:00:22.856577
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class R(Register):
        attr1 = Style(Sgr(2))
        attr2 = Style(Sgr(3))
    r = R()
    assert r.as_namedtuple().attr1 == r.attr1
    assert r.as_namedtuple().attr2 == r.attr2

# Generated at 2022-06-22 00:00:34.711265
# Unit test for constructor of class Register
def test_Register():
    # Create a new custom register
    custom = Register()
    # Add a renderfunc for Sgrs
    custom.set_renderfunc(Sgr, lambda x: f'\x1b[{x}m')
    # Add a renderfunc for 8bit colors
    custom.set_renderfunc(EightbitFg, lambda x: f'\x1b[38;5;{x}m')
    # Define how the register shall be called.
    custom.set_eightbit_call(EightbitFg)
    # Set some styles/rules
    custom.custom_style1 = Style(EightbitFg(116), Sgr(1))
    custom.custom_style2 = Style(EightbitFg(82), Sgr(1))
    # Test if styles have been rendered.

# Generated at 2022-06-22 00:00:43.002784
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class Rgb(RenderType):
        render_type = "rgb"

        def to_ansi(self, *args):
            return '\x1b[38;2;{};{};{}m'.format(*args)

    renderfunc = Rgb.to_ansi
    r: Register = Register()
    r.set_renderfunc(Rgb, renderfunc)
    r.set_rgb_call(Rgb)

    assert repr(r(10, 20, 30)) == repr(Rgb.to_ansi(10, 20, 30))

# Generated at 2022-06-22 00:00:55.863884
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbType1(RenderType):
        def render(self, r: int, g: int, b: int) -> str:
            return ""

    class RgbType2(RenderType):
        def render(self, r: int, g: int, b: int) -> str:
            return ""

    register = Register()
    register.set_renderfunc(RgbType1, RgbType1.render)
    register.set_renderfunc(RgbType2, RgbType2.render)

    register.set_rgb_call(RgbType1)
    assert callable(register.rgb_call)

    register.set_rgb_call(RgbType2)
    assert callable(register.rgb_call)


# Generated at 2022-06-22 00:00:57.327326
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r


# Generated at 2022-06-22 00:01:02.661246
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_renderfunc(RenderType, lambda x: "unmute")
    r.new_style = Style(RenderType(1))
    r.mute()
    assert r.new_style == ""
    r.unmute()
    assert r.new_style == "unmute"



# Generated at 2022-06-22 00:01:10.028539
# Unit test for method __call__ of class Register
def test_Register___call__():

    import sty
    import sty.builtins
    sty.builtins.modifiers.reset()

    fg = sty.builtins.register.fg
    test_attrs = {}
    test_attrs["red"] = Style(sty.builtins.modifiers.fg.red)
    test_attrs["magenta"] = Style(sty.builtins.modifiers.fg.magenta)

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            for k, v in test_attrs.items():
                setattr(self, k, v)

    my_reg = MyRegister()

    # Test __call__ with single string argument.
    assert fg("red") == sty.fg.red
    assert my_reg("magenta") == sty.fmt.magenta

    #

# Generated at 2022-06-22 00:01:22.354812
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Test if call of first render type is working
    f = lambda r, g, b: "1;" + str(r) + ";" + str(g) + ";" + str(b) + "m"
    r1 = Register()
    r1.set_rgb_call(RenderType)
    r1.set_renderfunc(RenderType, f)
    assert r1(1, 2, 3) == "\x1b1;1;2;3m"
    # Test if call of second render type is working
    f = lambda r, g, b: "2;" + str(r) + ";" + str(g) + ";" + str(b) + "m"
    r1.set_rgb_call(RenderType)
    r1.set_renderfunc(RenderType, f)
    assert r1

# Generated at 2022-06-22 00:01:30.966246
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .render.ansi8 import Ansi8RenderType
    import re

    register = Register()
    func = lambda x: f"\x1b[48;5;{x}m"
    register.set_renderfunc(Ansi8RenderType, func)
    register.green = Style(Ansi8RenderType(2))

    assert str(register.green) == "\x1b[48;5;2m"

    register.mute()

    assert str(register.green) == ""

    register.unmute()

    assert str(register.green) == "\x1b[48;5;2m"



# Generated at 2022-06-22 00:01:36.536272
# Unit test for method mute of class Register
def test_Register_mute():
    register = Register()
    register.set_renderfunc(RenderType.SGR, lambda x: f"SGR({x})")

    register.black = Style(RenderType.SGR(0), value=f"SGR(0)")
    assert register.black == "SGR(0)"

    register.mute()
    assert register.black == ""

    register.unmute()
    assert register.black == "SGR(0)"



# Generated at 2022-06-22 00:01:41.325757
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertypes import RgbFg, Sgr

    style = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-22 00:01:46.402010
# Unit test for method __new__ of class Style
def test_Style___new__():
    new_cls = Style.__new__(Style, value="abc")  # type: ignore

    # New style only contains the string 'abc'
    assert isinstance(new_cls, Style)
    assert new_cls == "abc"
    assert new_cls.rules == tuple()
    assert new_cls == "abc"

# Generated at 2022-06-22 00:01:52.247076
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbBg

    r = Register()
    assert hasattr(r, "eightbit_call")
    assert callable(r.eightbit_call)

    r.set_renderfunc(RgbBg, lambda r, g, b: "")
    r.set_eightbit_call(RgbBg)
    assert r.eightbit_call == r.renderfuncs[RgbBg]



# Generated at 2022-06-22 00:02:11.560782
# Unit test for method mute of class Register
def test_Register_mute():
    # Test 1
    r = Register()
    r.mute()
    assert r.is_muted is True
    assert r.red == ""

    # Test 2
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.mute()
    assert r.red == ""
    assert r.is_muted is True



# Generated at 2022-06-22 00:02:21.825267
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class DummyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(100, 0, 0))
            self.green = Style(RgbFg(0, 100, 0))
            self.blue = Style(RgbFg(0, 0, 100))
            self.bold = Style(Sgr(1))
            self.red_bold = Style(RgbFg(100, 0, 0), Sgr(1))

    r = DummyRegister()

# Generated at 2022-06-22 00:02:24.883366
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()
    setattr(reg, "name", Style(1, 2))

    assert reg.as_dict() == {"name": str(Style(1, 2))}



# Generated at 2022-06-22 00:02:27.661404
# Unit test for constructor of class Style
def test_Style():
    style = Style(1, 2)
    assert style.rules == [1, 2]

    style2 = Style(style, 3)
    assert style2.rules == [1, 2, 3]


# Generated at 2022-06-22 00:02:30.620496
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_renderfunc(RenderType1, lambda x: f"{x}a")
    r.set_eightbit_call(RenderType1)
    assert r(42) == "42a"


# Generated at 2022-06-22 00:02:37.950354
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .render import Register

    from .rendertype import RgbBg, RgbFg, Sgr

    fg = Register()
    fg.calm = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(fg.calm, Style)

    assert isinstance(fg.as_namedtuple(), NamedTuple)

# Generated at 2022-06-22 00:02:45.651210
# Unit test for method __call__ of class Register
def test_Register___call__():
    assert Register()(42) == ''
    assert Register()('red') == ''
    assert Register()(42, 232, 10) == ''

    # From Sty()
    r = Register()
    r.renderfuncs.update({RenderType: lambda *args, **kwargs: RgbFg(*args, **kwargs)})
    assert r(42, 232, 10) == '\x1b[38;2;42;232;10m'

    r = Register()
    r.renderfuncs.update({RenderType: lambda *args, **kwargs: RgbFg(*args, **kwargs)})
    r.red = Style(RgbFg(255, 0, 0))
    assert r('red') == '\x1b[38;2;255;0;0m'  # red

# Generated at 2022-06-22 00:02:54.090819
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Use case 1
    a = Style()
    assert isinstance(a, Style)
    assert isinstance(a, str)
    assert str(a) == ""

    # Use case 2
    b = Style(value="Test")
    assert isinstance(b, Style)
    assert isinstance(b, str)
    assert str(b) == "Test"

    # Use case 3
    c = Style(value="Test", rules=["a", "b", "c"])
    assert isinstance(c, Style)
    assert isinstance(c, str)
    assert str(c) == "Test"
    assert c.rules == ["a", "b", "c"]



# Generated at 2022-06-22 00:03:05.473113
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test for method set_eightbit_call.
    """

    from .rendertypes import RgbFg, EightbitFg, EightbitBg, RgbBg

    from .style import fg, bg

    fg.black = Style(EightbitFg(0))
    bg.black = Style(RgbBg(10, 20, 30))

    # Eightbit calls should render EightbitFg.
    fg.set_eightbit_call(EightbitFg)
    assert fg(0) == "\x1b[30m"

    bg.set_eightbit_call(EightbitFg)
    assert bg(0) == "\x1b[40m"

    # Eightbit calls should render RgbFg.

# Generated at 2022-06-22 00:03:09.374021
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .registers import fg

    assert isinstance(fg.as_dict(), dict)

    assert len(fg.as_dict()) == 30

    for name, code in fg.as_dict().items():
        assert isinstance(name, str)
        assert isinstance(code, str)
        assert code.startswith("\x1b[")



# Generated at 2022-06-22 00:03:43.596852
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .ansi import RgbFg

    class FakeRenderType:
        def __init__(self, *args):
            self.args = args

    f1 = lambda *args: "\x1b[32m"
    f2 = lambda *args: "\x1b[33m"

    r1 = Register()
    r1.set_renderfunc(FakeRenderType, f1)
    assert r1.renderfuncs.get(FakeRenderType) == f1

    # Update renderfunc
    r1.set_renderfunc(FakeRenderType, f2)
    assert r1.renderfuncs.get(FakeRenderType) == f2

    # Append new renderfunc
    f3 = lambda *args: "\x1b[34m"
    r1.set_renderfunc(RgbFg, f3)


# Generated at 2022-06-22 00:03:54.106159
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()
    r.set_eightbit_call(type(r.eightbit_call))
    r.set_rgb_call(type(r.rgb_call))
    r.set_renderfunc(type(r.renderfuncs[type(r.eightbit_call)]), lambda: lambda x: x)
    r.set_renderfunc(type(r.renderfuncs[type(r.rgb_call)]), lambda: lambda r, g, b: (r, g, b))

    r2 = r.copy()

    assert isinstance(r2, Register)

    assert r.eightbit_call is not r2.eightbit_call
    assert r.renderfuncs == r2.renderfuncs
    assert r.renderfuncs[type(r.eightbit_call)] is not r2.render

# Generated at 2022-06-22 00:03:56.727785
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    register = Register()

    register.set_eightbit_call(RenderType)

    assert register.eightbit_call(144) == "144"



# Generated at 2022-06-22 00:04:04.932175
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register
    """
    import pytest
    from sty import fg, bg, Style
    from sty.ansi.rgb_fg import RgbFg

    Color = namedtuple('Color', ['r', 'g', 'b'])

    # Create test object
    custom_style = Style(RgbFg(10, 20, 30))
    custom_register = fg.copy()
    custom_register.custom_style = custom_style

    # Test Class
    assert isinstance(custom_register, Register)

    # Test custom style
    assert isinstance(custom_register.custom_style, Style)
    assert custom_register.custom_style.rules[0].args == ((10, 20, 30),)

    # Test default styles

# Generated at 2022-06-22 00:04:09.800701
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MyRegister(Register):
        # Custom register
        pass

    r: MyRegister = MyRegister()
    r.test1 = "test1"
    r.test2 = "test2"

    assert r("test1") == "test1"
    assert r("test2") == "test2"
    assert r("test3") == ""

    # Test call that raises a ValueError because we didn't set a callable
    # for rgb color codes yet.
    try:
        r(10, 20, 30)
        raise "Should not have arrived here."
    except ValueError:
        pass

# Generated at 2022-06-22 00:04:21.539367
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Test setup
    class FakeRenderTypeOne(RenderType):
        def __init__(self, *args, **kwargs):
            pass

    class FakeRenderTypeTwo(RenderType):
        def __init__(self, *args, **kwargs):
            pass

    def render_one(param1, param2):
        return "RenderFunctionOne"

    def render_two(param1, param2):
        return "RenderFunctionTwo"

    register = Register()
    register.set_renderfunc(FakeRenderTypeOne, render_one)
    register.set_renderfunc(FakeRenderTypeTwo, render_two)

    # Test
    register.set_eightbit_call(FakeRenderTypeOne)
    assert render_one(1, 2) == register(1, 2)


# Generated at 2022-06-22 00:04:31.566198
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import EightbitFg, EightbitBg, RgbFg, RgbBg

    def render_eightbit(
        ansi_code: str,
        has_leading_zero: bool,
        arg_val: int,
        is_foreground: bool,
    ) -> str:
        return ansi_code + str(arg_val)

    def render_rgb(
        ansi_code: str,
        red: int,
        green: int,
        blue: int,
        is_foreground: bool,
    ) -> str:
        return ansi_code + str(red) + ";" + str(green) + ";" + str(blue)

    r = Register()
    r.set_renderfunc(rendertype=EightbitFg, func=render_eightbit)
   

# Generated at 2022-06-22 00:04:42.692393
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr
    from .style_register import StyleRegister
    from .sty import Sty

    sty = Sty()
    sty.register(StyleRegister())

    orig = sty.fg.orange

    sty.fg.orange = Style(RgbFg(1, 2, 3), Sgr(1))

    sty.fg.orange = Style(RgbFg(4, 5, 6), Sgr(1))

    sty.fg.orange = Style(RgbFg(1, 2, 3), Sgr(1))

    sty.fg.orange = Style(RgbFg(1, 2, 3))

    sty.fg.orange = Style(Sgr(1))

    sty.fg.orange = Style(RgbFg(1, 2, 3), Sgr(1))

    sty.fg

# Generated at 2022-06-22 00:04:49.987677
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .renderfuncs import SgrFunc
    from .rendertype import Sgr

    reg = Register()
    reg.set_renderfunc(Sgr, SgrFunc())
    reg.set_eightbit_call(Sgr)

    reg._red = Style(Sgr(1))

    assert str(reg._red) == "\x1b[1m"
    reg.mute()
    assert str(reg._red) == ""
    reg.unmute()
    assert str(reg._red) == "\x1b[1m"



# Generated at 2022-06-22 00:05:01.241282
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Foo(RenderType):
        pass

    class Bar(RenderType):
        pass

    f1 = lambda *args, **kwargs: f"Foo({args}, {kwargs})"
    f2 = lambda *args, **kwargs: f"Bar({args}, {kwargs})"

    r = Register()

    # Add two (possible) renderfunctions to the register.
    r.set_renderfunc(Foo, f1)
    r.set_renderfunc(Bar, f2)

    # Store some Style-Objects in the register.
    r.foo = Style(Foo(1, 2, 3))
    r.bar = Style(Bar(1, 2, 3))
    r.baz = Style(Foo(1, 2, 3), Bar(1, 2, 3))

    # Assert that