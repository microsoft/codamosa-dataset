

# Generated at 2022-06-21 23:55:25.247258
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.green = Style(RgbFg(10, 255, 0))
    r.red = Style(RgbFg(255, 0, 0))

    assert r.green == "\x1b[38;2;10;255;0m"
    assert r.red == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-21 23:55:28.440879
# Unit test for method unmute of class Register
def test_Register_unmute():
    x = Register()
    x.mute()
    x.red = "asdf"
    assert str(x.red) == ""
    x.unmute()
    assert str(x.red) == "asdf"

# Generated at 2022-06-21 23:55:40.471234
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from . import renders
    from .registers import ef, fg

    rendertype = renders.Sgr
    shapes = {
        "blink": "blink",
        "bold": "bold",
        "conceal": "conceal",
        "crossed_out": "crossed_out",
        "inverse_fg_bg": "inverse_fg_bg",
        "reset": "reset",
    }

    def render_func(shape: str, *args):
        return f"\x1b[{shape}m"

    # Add a renderfunc for all shapes of ef.
    for shape in shapes.keys():

        style = Style(rendertype(shapes[shape]))

        ef.set_renderfunc(rendertype, render_func)


# Generated at 2022-06-21 23:55:42.376713
# Unit test for constructor of class Register
def test_Register():
    "Check if constructor creates correct object"

    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-21 23:55:47.102826
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    
    from sty import fg, bg
    fg.blue = Style(210)
    assert str(fg.blue) == '\x1b[38;5;12m'
    fg.set_renderfunc(RenderType, lambda code: f'{code}')
    assert str(fg.blue) == '210'

# Generated at 2022-06-21 23:56:00.536371
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr, SgrFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: "RgbFg{},{},{}".format(r, g, b))
    r.set_renderfunc(Sgr, lambda *args: "Sgr{}".format(*args))
    r.set_eightbit_call(RgbFg)

    setattr(r, "red", Style(RgbFg(255, 0, 0), Sgr(1)))

    assert callable(r.as_namedtuple)
    assert callable(r.as_dict)
    assert callable(r.copy)
    assert callable(r.set_rgb_call)

# Generated at 2022-06-21 23:56:10.076488
# Unit test for constructor of class Style
def test_Style():
    Style(1, 2, 3, value="a")
    Style(1, 2, 3, 4, value="a")
    Style(Style(1, 2), value="a")
    Style(Style(1, 2, 3, value="a"), value="b")

    # s = Style(value="a")
    # assert s == ""

    # s = Style(1, value="a")
    # assert s == "a"

    # s = Style(1, 2, value="a")
    # assert s == "a"

    # s = Style(1, 2, 3, value="a")
    # assert s == "a"



# Generated at 2022-06-21 23:56:14.225767
# Unit test for constructor of class Style
def test_Style():
    s1 = Style("fg", "red")
    s2 = Style("fg", "blue")
    s1.red = Style("fg", "red")
    s1.blue = Style("fg", "blue")
    assert s1.red == "\x1b[38;5;9mfg"
    assert s1.blue == "\x1b[38;5;4mfg"
    assert s1 == "\x1b[38;5;9mfg"
    assert s2 == "\x1b[38;5;4mfg"
    return True


# Generated at 2022-06-21 23:56:19.637855
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbFg(1, 2, 3))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert not hasattr(s, 'rules')
    assert str(s) == '\x1b[38;2;1;2;3m'



# Generated at 2022-06-21 23:56:23.339255
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.foo = Style(RgbFg(0,0,0))
    r1 = r.copy()
    assert id(r.foo) != id(r1.foo)
    assert r.foo == r1.foo
    assert r == r1


# Generated at 2022-06-21 23:56:34.897536
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)



# Generated at 2022-06-21 23:56:45.319120
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()

    # Create fake attribute with default name.
    class FakeRule(RenderType):
        def __init__(self, args: Tuple[int, ...] = ()):
            self.args = args

        def __call__(self, *args: int, **kwargs: int) -> str:
            return ""

    r1 = FakeRule(args=(1, 2))
    r.set_renderfunc(FakeRule, r1)
    r.red = Style(r1)

    # Should match default __call__ method.
    assert r("red") == ""
    assert r(1) == ""
    assert r(1, 2, 3) == ""
    assert r(1, 2, 3, 4) == ""
    assert r() == ""

# Generated at 2022-06-21 23:56:55.333742
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class CustomRegister(Register):
        pass

    reg = CustomRegister()
    reg.green = Style(RgbFg(0, 255, 0))
    reg.blue = Style(RgbFg(0, 0, 255))
    reg.purple = Style(RgbFg(0, 255, 255))

    nt = reg.as_namedtuple()

    assert nt.green == "\x1b[38;2;0;255;0m"
    assert nt.blue == "\x1b[38;2;0;0;255m"
    assert nt.purple == "\x1b[38;2;0;255;255m"

# Generated at 2022-06-21 23:56:58.517927
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class CustomRegister(Register):
        red = Style(RgbFg(101, 100, 50))
        blue = Style(RgbFg("blue"))

    one = CustomRegister()
    nt = one.as_namedtuple()

    assert nt.blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-21 23:57:05.958756
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .sgr import Sgr

    # Set up test object
    class FakeRegister(Register):
        pass

    reg = FakeRegister()
    reg.renderfuncs.update({Sgr: lambda x: str(x)})

    # Create a Style object
    style: Style = Style(Sgr(1), Sgr(2))

    # Set Style as attribute
    reg.blue = style

    # Verify style was correctly set
    assert style == reg.blue


# Unit tests for method __call__ of class Register

# Generated at 2022-06-21 23:57:10.352757
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Test creation of Style.
    """
    # Test normal behavior
    style = Style(1, 2, 3)
    assert style == "123"

    # Test that value argument overwrites other arguments.
    style = Style(1, 2, 3, value="42")
    assert style == "42"


# Generated at 2022-06-21 23:57:21.362425
# Unit test for constructor of class Register
def test_Register():

    r = Register()

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, lambda x: x)

    assert r.eightbit_call is not None
    assert r.rgb_call is not None

    assert hasattr(r, "renderfuncs")

    assert isinstance(r.renderfuncs, dict)
    assert not r.renderfuncs

    assert not r.is_muted

    r.set_renderfunc(RenderType, lambda x: x)
    assert r.renderfuncs == {RenderType: lambda x: x}

    r.mute()
    assert r.is_muted

    r.unmute()
    assert not r.is_muted

test_Register()

# Generated at 2022-06-21 23:57:33.380735
# Unit test for method mute of class Register
def test_Register_mute():
    from .default_register import Ef, Fg, Bg, Rs
    from .rendertype import Sgr, RgbFg, RgbBg

    reg = Register()

    # Test mute (not muted)
    reg.set_renderfunc(Sgr, lambda x, y: f"\x1b[{y}m")
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    reg.red = Style(RgbFg(255, 0, 0))

# Generated at 2022-06-21 23:57:43.630993
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg, RgbBg, EightBitBg, EightBitFg

    rg = Register()
    rg.set_renderfunc(RgbFg, lambda r, g, b: f"{r}-{g}-{b}")
    rg.set_renderfunc(RgbBg, lambda r, g, b: f"{r}|{g}|{b}")

    rg.set_eightbit_call(RgbFg)

    assert rg(255, 127, 0) == "255-127-0"
    assert rg(13, 183, 125, bg=True) == "13|183|125"



# Generated at 2022-06-21 23:57:46.110584
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .render import ConsoleRender

    cr = ConsoleRender()
    my_reg = cr.fg
    my_reg.unmute()

    assert my_reg.is_muted == False



# Generated at 2022-06-21 23:58:10.507473
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test register copy method.
    """
    import sty
    import pytest

    # Create a simple Fg-Register with 3 Styles.
    fg = sty.Fg()
    fg.test1 = sty.Style(fg.red)
    fg.test2 = sty.Style(fg.green)
    fg.test3 = sty.Style(fg.blue)

    # Create a copy of the Fg-Register
    fg_copy = sty.Fg()
    fg_copy = fg_copy.copy()

    # Check if copy is identical to original.
    for name in dir(fg):
        if isinstance(getattr(fg, name), Style):
            assert getattr(fg, name) == getattr(fg_copy, name)

    # Change a color in the fg-copy and

# Generated at 2022-06-21 23:58:19.789321
# Unit test for method copy of class Register
def test_Register_copy():
    class Dummy(RenderType):
        pass

    curr_reg = Register()
    curr_reg.set_renderfunc(Dummy, lambda x: "dummy")
    curr_reg.a = Style(Dummy(5), value="aaa")

    new_reg = curr_reg.copy()
    new_reg.b = Style(Dummy(7), value="bbb")
    new_reg.set_renderfunc(Dummy, lambda x: "dummy-new")

    assert curr_reg.a == "aaa"
    assert curr_reg.b == ""
    assert new_reg.a == "aaa"
    assert new_reg.b == "bbb"



# Generated at 2022-06-21 23:58:21.149114
# Unit test for constructor of class Style
def test_Style():
    s = Style("test")
    assert isinstance(s, Style)
    assert str(s) == "test"
    assert s.rules == ()

# Generated at 2022-06-21 23:58:29.002754
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RenderType

    class RandomRenderType(RenderType):
        def __init__(self):
            self.args = ()
            pass

    class RandomRenderType2(RenderType):
        def __init__(self):
            self.args = ()
            pass


    s = Style(RandomRenderType(), RandomRenderType2())
    assert isinstance(s, Style)
    assert isinstance(s, str)

    s2 = Style(s)
    assert isinstance(s2, Style)
    assert isinstance(s2, str)
    assert s2.rules == s.rules

# Generated at 2022-06-21 23:58:35.579232
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import ResetStyle

    r = Register()
    r.renderfuncs.update({ResetStyle: lambda: "test"})

    style_a = Style(ResetStyle())
    r.sty_a = style_a

    style_b = Style(ResetStyle())
    r.sty_b = style_b

    assert (
        getattr(r, "sty_b")
        == Style(ResetStyle(), value="test")
    ) or (
        getattr(r, "sty_b")
        == Style(ResetStyle(), value="")
    )



# Generated at 2022-06-21 23:58:42.319725
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, RgbBg, RgbEffects

    reg = Register()
    
    fg = Style(RgbFg(100,100,100), RgbEffects(0,0,100))
    bg = Style(RgbBg(100,100,100), RgbEffects(0,0,100))

    setattr(reg, 'fg', fg)
    setattr(reg, 'bg', bg)

    reg.set_eightbit_call(RgbFg)
    reg.set_rgb_call(RgbBg)

    reg2 = reg.copy()

    assert (reg2 is not reg)
    assert (reg2.fg is not reg.fg)
    assert (reg2.bg is not reg.bg)

# Generated at 2022-06-21 23:58:48.988323
# Unit test for method mute of class Register
def test_Register_mute():

    from .render import eightbit, rgb, _reset_style

    from .rendertype import Sgr
    from .style import fg, bg

    redFg = Style(eightbit(1), Sgr(1))
    fg.red = redFg

    fg.green = Style(eightbit(2), Sgr(1))

    assert(fg.red == "\x1b[38;5;1m\x1b[1m")
    assert(fg.green == "\x1b[38;5;2m\x1b[1m")

    fg.mute()

    assert(fg.red == "")
    assert(fg.green == "")

    fg.redFg = Style(eightbit(3), Sgr(1))
    assert(fg.redFg == "")

    f

# Generated at 2022-06-21 23:58:51.310277
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    r = Register()

    r.set_rgb_call(RgbFg)

    assert r.rgb_call == RgbFg

# Generated at 2022-06-21 23:59:00.955366
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test method as_dict of class Register.
    """
    register = Register()

    register.foo = Style(RgbFg(1, 2, 3))
    register.bar = Style(RgbBg(4, 5, 6))
    register.foobar = Style(RgbFg(1, 2, 3), RgbBg(4, 5, 6))

    assert register.as_dict() == {
        "foo": "\x1b[38;2;1;2;3m",
        "bar": "\x1b[48;2;4;5;6m",
        "foobar": "\x1b[38;2;1;2;3m\x1b[48;2;4;5;6m",
    }



# Generated at 2022-06-21 23:59:08.073643
# Unit test for constructor of class Style
def test_Style():
    # The styling rules are set correctly
    t1 = Style(1)
    t2 = Style(1, 2)
    t3 = Style(1, 2, 3)

    assert isinstance(t1, Style)
    assert isinstance(t2, Style)
    assert isinstance(t3, Style)

    assert t1.rules == (1,)
    assert t2.rules == (1, 2)
    assert t3.rules == (1, 2, 3)

    # The string value is set correctly.
    assert len(t1) == 0
    assert len(t2) == 0
    assert len(t3) == 0

# Generated at 2022-06-21 23:59:23.663298
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Test method set_eightbit_call.
    """

    # Create a mock rendertype
    class FakeRendertype(RenderType):
        def __init__(self, colorcode: int, *args):
            self.colorcode = colorcode
            self.args = args

        @property
        def args(self) -> Tuple[int]:
            return (self.colorcode,)

        @args.setter
        def args(self, value: Tuple[int]):
            self.colorcode = value[0]

        def __str__(self):
            return f"\x1b[{self.colorcode:03d}m"

    # Create new Register-object
    r = Register()

    # Add renderfunc for new rendertype to register

# Generated at 2022-06-21 23:59:35.964950
# Unit test for method mute of class Register
def test_Register_mute():

    # Create register
    reg = Register()

    # Set all render methods to a mock-function
    for render_type in RenderType:
        reg.set_renderfunc(render_type, lambda *args: f"f{render_type.__name__}")

    # Set dummy style attribute
    reg.ts1 = Style(RgbBg(1, 1, 1), RgbFg(2, 2, 2))

    # Check if normal output matches
    assert str(reg.ts1) == "fRgbFg" + "fRgbBg"

    # Mute the register
    reg.mute()

    # Check that muted register returns empty string
    assert str(reg.ts1) == ""

    # Unmute the register
    reg.unmute()

    # Check if normal output matches

# Generated at 2022-06-21 23:59:39.512971
# Unit test for method mute of class Register
def test_Register_mute():

    from .fg import fg
    from .eightbit import RgbFg

    f = fg.copy()
    f.set_eightbit_call(RgbFg)

    assert f.eightbit_call == RgbFg
    assert str(fg.red) == '\x1b[38;2;255;0;0m'

    f.mute()

    assert f.eightbit_call is None
    assert str(fg.red) == ""

    f.unmute()

    assert f.eightbit_call == RgbFg
    assert str(fg.red) == '\x1b[38;2;255;0;0m'



# Generated at 2022-06-21 23:59:50.826589
# Unit test for method __call__ of class Register
def test_Register___call__():

    from sty import fg, bg, sgr

    reg = Register()

    assert reg("") == ""

    # Test function as styles
    def _do_nothing(*args):
        pass

    reg.set_renderfunc(fg, _do_nothing)
    reg.set_renderfunc(bg, _do_nothing)
    reg.set_renderfunc(sgr, _do_nothing)

    reg.set_eightbit_call(fg)
    reg.set_rgb_call(fg)

    assert reg(10, 20, 30) == (10, 20, 30)
    assert reg(42) == 42

    # Test styles as attributes
    reg.red = Style(fg(255, 0, 0))
    reg.green = Style(fg(0, 255, 0))

# Generated at 2022-06-21 23:59:53.896311
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted is False
    assert r.eightbit_call(123) == 123
    assert r.rgb_call(10, 20, 30) == (10, 20, 30)



# Generated at 2022-06-21 23:59:54.780068
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)



# Generated at 2022-06-22 00:00:06.886629
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbBg, RgbFg, Sgr

    r = Register()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)
    r.set_renderfunc(Sgr, lambda x: "Sgr({})".format(x))
    r.blau = Style(RgbBg(0, 0, 255), RgbFg("purple"), Sgr(1, 2, 3))

    assert r("blau") == "RgbBg(0, 0, 255)RgbFg(255, 0, 255)Sgr(1, 2, 3)"
    assert r("blue") == ""
    assert r(42) == "RgbFg(42)"

# Generated at 2022-06-22 00:00:12.975328
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg, Sgr

    r = Register()
    r.test = Style(RgbFg(100, 100, 100), Sgr(1))
    assert str(r.test) == "\x1b[38;2;100;100;100m\x1b[1m"
    r.mute()
    assert str(r.test) == ""


# Generated at 2022-06-22 00:00:17.337682
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from sty.rendertype import RgbFg

    from sty.renderfuncs import render_ansi

    r = Register()

    r.set_renderfunc(RgbFg, render_ansi)

    assert r.renderfuncs[RgbFg] == render_ansi

# Generated at 2022-06-22 00:00:28.536193
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .register_defaults import fg

    nt = fg.as_namedtuple()

# Generated at 2022-06-22 00:00:46.589044
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    r1 = Register()
    r1.set_renderfunc(RenderType, lambda x: x)
    r1.black = Style(RenderType("test"))

    assert str(r1.black) == "test"

    r1.set_renderfunc(RenderType, lambda x: x*2)
    r1.black = Style(RenderType("test"))
    
    assert str(r1.black) == "testtest"

# Generated at 2022-06-22 00:00:53.883323
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .sgr import RgbFg, Sgr

    fg = Register()

    fg.black = Style(RgbFg(0, 0, 0))
    fg.black = Style(Sgr(1))
    fg.grey = Style(RgbFg(102, 102, 102))

    assert fg.black == "\x1b[38;2;0;0;0m\x1b[1m"
    assert fg.grey == "\x1b[38;2;102;102;102m"

    fg.set_rgb_call(Sgr)

    assert fg(0, 0, 0) == "\x1b[1m"
    assert fg(102, 102, 102) == "\x1b[38;2;102;102;102m"

# Unit test

# Generated at 2022-06-22 00:01:04.471320
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RenderType, Sgr, RgbFg, RgbBg

    # Check if str is suclass of Style
    # --------------------------------
    test_list = Style(Sgr(1), "test")

    assert isinstance(test_list, Style)

    assert isinstance(test_list, str)

    assert isinstance(test_list, RenderType)

    assert test_list == "test"

    # Check if subclass of RenderType is subclass of str
    # ----------------------------------------------------
    test_list = Style(RgbFg(1, 1, 1), "test")

    assert isinstance(test_list, Style)

    assert isinstance(test_list, str)

    assert isinstance(test_list, RenderType)

    assert test_list == "test"

    # Check if parameter 'rules' is set correctly


# Generated at 2022-06-22 00:01:04.961276
# Unit test for constructor of class Register
def test_Register():

    r = Register()



# Generated at 2022-06-22 00:01:09.743666
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .render import Sgr, RgbFg

    s: Style = Style(RgbFg(1,5,10), Sgr(1))

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"


# Generated at 2022-06-22 00:01:16.925073
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import RgbFg, Sgr

    k1 = Style(RgbFg(255,255,255))
    k2 = Style(Sgr(1, RgbFg(255,255,255)))

    assert k1 == '\x1b[38;2;255;255;255m'
    assert k2 == '\x1b[1m\x1b[38;2;255;255;255m'

# Generated at 2022-06-22 00:01:27.399022
# Unit test for method copy of class Register
def test_Register_copy():

    # Setup
    RgbBg = NamedTuple("RgbBg", [("r", int), ("g", int), ("b", int)])
    Sgr = NamedTuple("Sgr", [("number", int)])

    renderfuncs = {RgbBg: lambda r, g, b: "RGB", Sgr: lambda n: "SGR"}
    renderfuncs_copy = {RgbBg: lambda r, g, b: "RGB_COPY", Sgr: lambda n: "SGR_COPY"}

    r = Register()
    r.set_renderfunc(RgbBg, renderfuncs[RgbBg])
    r.set_renderfunc(Sgr, renderfuncs[Sgr])

# Generated at 2022-06-22 00:01:29.570108
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    assert isinstance(register, Register)

# Generated at 2022-06-22 00:01:33.691372
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbBg, RgbFg, RgbSeq

    c = Register()
    c.set_eightbit_call(RgbBg)
    c.set_eightbit_call(RgbFg)
    c.set_eightbit_call(RgbSeq)

# Generated at 2022-06-22 00:01:42.538860
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test Register.__setattr__
    """
    fg = Register()

    def test_func():
        return "\x1b[1m"

    fg.set_renderfunc(Sgr, test_func)

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    assert str(fg.orange) == "\x1b[38;2;1;5;10m\x1b[1m"
    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    assert str(fg.orange) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-22 00:02:42.989216
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    def f1(num: int) -> str:
        return "f1"

    def f2(num: int) -> str:
        return "f1"

    r = Register()

    # Test set_renderfunc
    r.set_renderfunc(int, f1)
    assert r.renderfuncs == {int: f1}
    assert r.eightbit_call == f1

    # Test set_eightbit_call
    r.set_eightbit_call(int)
    assert r.eightbit_call == f1
    r.set_eightbit_call(int)
    assert r.eightbit_call == f1
    r.set_eightbit_call(int)
    assert r.eightbit_call == f1

    # Test set_rgb_call
    r.set_rgb_call

# Generated at 2022-06-22 00:02:44.485362
# Unit test for method copy of class Register
def test_Register_copy():
    a = Register()
    a.foo = "bar"
    b = a.copy()
    assert a.foo == b.foo

# Generated at 2022-06-22 00:02:51.081999
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr
    from .style import fg

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(fg.orange, Style)
    assert isinstance(fg.orange, str)
    assert str(fg.orange) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-22 00:02:55.091903
# Unit test for constructor of class Style
def test_Style():
    try:
        s = Style(1)
        print("Error. Style constructor should raise an error.")
    except ValueError:
        print("ValueError catched.")
    r = RenderType()
    s = Style(r)
    s = Style(r, r)
    s = Style(1, 2, 3, 4, 5, 6, 7)


# Unit tests for method _render_rules.

# Generated at 2022-06-22 00:03:05.193364
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # 1. Create a new Register object.
    newRegister = Register()

    # 2. Add colors to register.
    newRegister.black = Style(RgbFg(0, 0, 0))
    newRegister.white = Style(RgbFg(255, 255, 255))

    # 3. Assert that as_dict() returns a dictionary containing the colors.
    assert isinstance(newRegister.as_dict(), dict)
    assert newRegister.as_dict() == {"black": "\x1b[38;2;0;0;0m", "white": "\x1b[38;2;255;255;255m"}



# Generated at 2022-06-22 00:03:08.163754
# Unit test for method __call__ of class Register
def test_Register___call__():
    fg = Register()
    assert fg(123) == ""

    fg.set_eightbit_call(RenderType)
    fg.set_rgb_call(RenderType)
    assert fg(123) == "28;41"


# Generated at 2022-06-22 00:03:20.441555
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class TestRgb(RenderType):
        def __init__(self, red: int, green: int, blue: int):
            self.red = red
            self.green = green
            self.blue = blue

        def as_str(self) -> str:
            return "TestRGB({},{},{})".format(self.red, self.green, self.blue)

    class TestEight(RenderType):
        def __init__(self, color: int):
            self.color = color

        def as_str(self) -> str:
            return "TestEight({})".format(self.color)

    def render_TestRgb(red: int, green: int, blue: int) -> str:
        return "TestRgbFunc({},{},{})".format(red, green, blue)


# Generated at 2022-06-22 00:03:31.633154
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit test for method __call__ of class Register.
    """
    from ..rendertype import Sgr
    from ..renders import render_sgr as sgr_render

    # Create a register object with a dummy renderfunc
    reg = Register()
    reg.set_eightbit_call(Sgr)
    reg.set_rgb_call(Sgr)
    reg.set_renderfunc(Sgr, sgr_render)

    # Create style
    style = Style(Sgr(1))

    # Add style to register
    setattr(reg, "test", style)

    # Test calls with 8bit inputs
    assert reg(1) == "\x1b[1m"

    # Test calls with named color inputs
    assert reg("test") == "\x1b[1m"

    # Test calls with 24bit

# Generated at 2022-06-22 00:03:33.466811
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """test_Register___setattr__"""

    # TODO:
    # Test if style attributes are stored as Style objects.

    pass

# Generated at 2022-06-22 00:03:36.963404
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert not r.is_muted

# Generated at 2022-06-22 00:04:06.091712
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    def rgb_call(r: int, g: int, b: int) -> str:
        return f"rgb({r}, {g}, {b})"

    r1 = Register()

    r1.set_rgb_call(AnsiRGB)

    r1.set_renderfunc(AnsiRGB, rgb_call)

    assert str(r1(10, 10, 255)) == "rgb(10, 10, 255)"

# Generated at 2022-06-22 00:04:09.881034
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import RgbEf
    from .colorfuncs import rgb_ef_color

    r = Register()
    r.set_eightbit_call(RgbEf)
    r.set_renderfunc(RgbEf, rgb_ef_color)

    r.blue = Style(RgbEf(0,0,255))

    r2 = r.copy()

    assert r2.blue == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-22 00:04:21.578263
# Unit test for constructor of class Style
def test_Style():
    class Rgb(RenderType):
        args = ("r", "g", "b")
        ansi = "\x1b[38;2;{r};{g};{b}m"

    class Bold(RenderType):
        args = ()
        ansi = "\x1b[1m"

    r1 = Style(Rgb(42, 57, 12), Bold())
    r2 = Style(r1, Rgb(1, 5, 10))

    assert isinstance(r1, Style)
    assert isinstance(r2, Style)
    assert str(r1) == "\x1b[38;2;42;57;12m\x1b[1m"

# Generated at 2022-06-22 00:04:31.603747
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbBg, Sgr

    rule = RgbBg(10, 5, 2)

    style = Style(rule)
    assert isinstance(style, Style)
    assert style.rules == (rule, )
    assert style == '\x1b[48;2;10;5;2m'

    style = Style(rule, rule)
    assert isinstance(style, Style)
    assert style.rules == (rule, rule)
    assert style == '\x1b[48;2;10;5;2m\x1b[48;2;10;5;2m'

    sgr = Sgr(1)
    style = Style(rule, rule, sgr)
    assert isinstance(style, Style)
    assert style.rules == (rule, rule, sgr)

# Generated at 2022-06-22 00:04:40.935022
# Unit test for constructor of class Style
def test_Style():
    """
    Unit test for constructor of class Style
    """
    class Test1(RenderType):
        pass

    class Test2(RenderType):
        pass

    example = Style(
        Test1(1),
        Test2(2),
        value="01\x1b[3;2;1m\x1b[1m",
        rules=[Test1(1), Test2(2)],
    )

    assert isinstance(example, Style)
    assert isinstance(example, str)
    assert example == "01\x1b[3;2;1m\x1b[1m"
    assert example.rules == [Test1(1), Test2(2)]



# Generated at 2022-06-22 00:04:44.942110
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Test 1
    result1 = Register()
    result1.set_eightbit_call(RenderType.EightbitFg)
    assert result1.eightbit_call.__name__ == "eightbit_fg_renderfunc"

    # Test 2
    result2 = Register()
    result2.set_eightbit_call(RenderType.HexFg)
    assert result2.eightbit_call.__name__ == "hex_fg_renderfunc"

    # Test 3
    result3 = Register()
    result3.set_eightbit_call(RenderType.HexBg)
    assert result3.eightbit_call.__name__ == "hex_bg_renderfunc"



# Generated at 2022-06-22 00:04:49.437240
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r1 = Register()
    r1.renderfuncs["Test"] = lambda x: x
    r1.reset = Style(RenderType("Test"))
    r1.red = Style(RenderType("Test"))

    class Test(NamedTuple):
        reset: str
        red: str

    assert isinstance(r1.as_namedtuple(), Test)

# Generated at 2022-06-22 00:05:00.720749
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    import sys
    import unittest

    import sty

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.set_eightbit_call(sty.Sgr)
            self.set_rgb_call(sty.RgbFg)

    RED = sty.Style(sty.RgbFg(255, 0, 0))
    GREEN = sty.Style(sty.RgbFg(0, 255, 0))
    BLUE = sty.Style(sty.RgbFg(0, 0, 255))

    my_register = MyRegister()
    my_register.red = RED
    my_register.green = GREEN
    my_register.blue = BLUE


# Generated at 2022-06-22 00:05:05.511303
# Unit test for constructor of class Register
def test_Register():
    """
    Unit test for constructor of class Register
    """
    # Arrange
    import sys

    # Act
    reg = Register()

    # Assert
    assert isinstance(reg, Register)
    if sys.version_info > (3, 8):
        assert isinstance(reg.__init__, Callable)


# Generated at 2022-06-22 00:05:11.194321
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.attr1 = Style(value="attr1")
    r.attr2 = Style(value="attr2")
    r.attr3 = "attr3"

    assert r.as_namedtuple() == namedtuple("StyleRegister", "attr1 attr2")(
        "attr1", "attr2"
    )
    assert isinstance(r.as_namedtuple(), NamedTuple)

