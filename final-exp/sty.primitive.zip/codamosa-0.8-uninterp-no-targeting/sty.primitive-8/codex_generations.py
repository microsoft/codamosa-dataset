

# Generated at 2022-06-21 23:55:22.975569
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import EightBit, RgbFg, Sgr

    def eightbit(color):
        sgr = Sgr(1)
        eightbit = EightBit(color)
        return sgr + eightbit

    def rgb(r, g, b):
        sgr = Sgr(1)
        rgb = RgbFg(r, g, b)
        return sgr + rgb

    reg = Register()
    reg.set_eightbit_call(EightBit)
    reg.set_rgb_call(RgbFg)

    reg.set_renderfunc(EightBit, eightbit)
    reg.set_renderfunc(RgbFg, rgb)

    reg.red = Style(EightBit(1))
    reg.green = Style(EightBit(2))

    test_value1 = reg(1)

# Generated at 2022-06-21 23:55:33.292398
# Unit test for method copy of class Register
def test_Register_copy():

    from .rendertype import RgbFg, RgbBg, Sgr, Attr

    class RenderType1(RenderType):
        number: int = 100

    r = RenderType1(10)

    def dummy(x):
        return "dummy"

    R = Register()

    R.set_renderfunc(RenderType1, dummy)

    R.test = Style(r)

    R.test2 = Style(r, RgbFg(10, 20, 30), RgbBg(40, 50, 60), Sgr(1), Attr(1))

    print(R.test)
    print(R.test2)

    R2 = R.copy()

    print(R2.test)
    print(R2.test2)

    print(R2.test2.rules)

# Generated at 2022-06-21 23:55:35.632629
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert Style("a", "b") == "ab"
    assert Style("a", "b").rules == ("a", "b")



# Generated at 2022-06-21 23:55:47.054292
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .effect import Effect
    from .fg import Fg
    from .bg import Bg
    from .rgb import RgbFg, RgbBg

    class R:
        """
        This is only used for testing.
        """
        fg = Fg("#CCC")
        black = Fg(0)
        white = Fg(255)
        red = RgbFg(10, 20, 30)
        blue = Fg("blue")
        bold_blue = Fg("blue", Effect("bold"))
        bold_red_bg = Style(Fg("red"), Effect("bold"), Bg("red"))


# Generated at 2022-06-21 23:55:59.144588
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RGbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class CustomRegister(Register):
        pass

    c = CustomRegister()

    c.set_renderfunc(RGbFg, lambda r, g, b: "STY-RGB-RENDERFUNC")
    c.set_renderfunc(Sgr, lambda *args: "STY-SGR-RENDERFUNC")

    c.red = Style(RGbFg(255, 0, 0), Sgr(1))

    assert c.red == "STY-RGB-RENDERFUNCSTY-SGR-RENDERFUNC"


# Generated at 2022-06-21 23:56:01.616770
# Unit test for constructor of class Style
def test_Style():
    s = Style(10, value='asdf')
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s.rules == (10,)
    assert str(s) == 'asdf'

# Generated at 2022-06-21 23:56:09.383082
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MyRegister(Register):
        pass

    r: MyRegister = MyRegister()
    r.renderfuncs.update({int: lambda x: f"8bit{x}", tuple: lambda r, g, b: f"rgb{r}{g}{b}"})
    r.test = Style(sgr(1))

    assert r("test") == "\x1b[1m"
    assert r(10) == "8bit10"
    assert r(255, 255, 255) == "rgb255255255"



# Generated at 2022-06-21 23:56:12.407752
# Unit test for constructor of class Style
def test_Style():
    from sty.rendertype import Sgr 
    fg.red = Style(Sgr(31), value='test')
    assert str(fg.red) == 'test'

    # fg.red = Style(Sgr(31), value='test')
    # assert str(fg.red) == 'test'



# Generated at 2022-06-21 23:56:13.544763
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    pass


# Generated at 2022-06-21 23:56:20.683125
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class Abc(RenderType):
        pass

    class Def(RenderType):
        pass

    reg = Register()
    reg.set_renderfunc(Abc, lambda x: "a")
    reg.set_renderfunc(Def, lambda x: "d")
    reg.set_eightbit_call(Abc)
    reg.set_rgb_call(Def)

    assert reg(42) == "a"
    assert reg(1,2,3) == "d"

# Generated at 2022-06-21 23:56:30.894094
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.red = Style(RgbFg(1,0,0))
    nt = r.as_namedtuple()
    assert hasattr(nt, "red")
    assert str(nt.red) == "\x1b[38;2;1;0;0m"


# Generated at 2022-06-21 23:56:31.750474
# Unit test for constructor of class Register
def test_Register():

    assert Register().is_muted is False

# Generated at 2022-06-21 23:56:43.735777
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        """ SGR-escape-code. """
        def __init__(self, *args):
            self.args = args

    class RgbFg(RenderType):
        """ Foreground color as RGB-code """
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    # Define two styles:
    sgr_style = Style(Sgr(1))
    rgb_style = Style(RgbFg(104, 205, 230))

    # Create register object and set styles to attributes of register.
    # This will run the default render-functions.
    reg = Register()
    reg.sgr = sgr_style
    reg.rgb = rgb_style

    # Check if attributes sgr and rgb don't contain a Style object

# Generated at 2022-06-21 23:56:51.217165
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbBg
    from .register import Style
    from .consts import FG, BG, EF, RS

    style = Style(RgbBg(1, 5, 0))
    assert isinstance(style, Style)

    style2 = Style(FG(42), BG(50), EF("1"), RS("reset_all"), value="")
    assert isinstance(style2, Style)

    style3 = Style(FG("blue"), BG("yellow"), value="")
    assert isinstance(style3, Style)



# Generated at 2022-06-21 23:56:59.775723
# Unit test for method __new__ of class Style
def test_Style___new__():

    class RgbFg(RenderType):
        def render_8bit(self, n: int):
            return f"\x1b[38;5;{n}m"

    fg = Register()

    fg.set_renderfunc(RgbFg, RgbFg.render_8bit)

    fg.orange = Style(RgbFg(1, 5, 10), value="\x1b[38;2;1;5;10m")

    assert str(fg.orange) == "\x1b[38;2;1;5;10m"
    assert len(fg.orange.rules) == 1
    assert isinstance(fg.orange.rules[0], RenderType)
    assert fg.orange.rules[0].args == (1, 5, 10)



# Generated at 2022-06-21 23:57:11.048271
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, EightBitFg, RgbBg, EightBitBg

    fg = Register()
    bg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    bg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    fg.set_renderfunc(EightBitFg, lambda x: f"\x1b[38;5;{x}m")
    bg.set_renderfunc(EightBitBg, lambda x: f"\x1b[48;5;{x}m")

    # Test

# Generated at 2022-06-21 23:57:20.804494
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Unit test for method Register.set_rgb_call

        fg = Register()
        bg = Register()
        ef = Register()
        rs = Register()

        fg.set_rgb_call(RgbFg)
        bg.set_rgb_call(RgbBg)
        ef.set_rgb_call(RgbFg)
        rs.set_rgb_call(RgbFg)

        fg(10, 20, 30)
        bg(10, 20, 30)
        ef(10, 20, 30)
        rs(10, 20, 30)

    """


# Generated at 2022-06-21 23:57:32.722625
# Unit test for method mute of class Register
def test_Register_mute():

    # Create a test type for the register
    class TestType(RenderType):
        def __init__(self, *args):
            super().__init__(*args)

        def render(self, *args):
            return f"\x1b[{','.join(self.args)}m"

    # Create test renderfuncs
    renderfuncs: Renderfuncs = {TestType: TestType.render}

    # Create test register and style
    reg = Register()
    reg.set_renderfunc(TestType, renderfuncs[TestType])
    reg.test_attr = Style(TestType(1, 2, 3), TestType(5, 4, 3))

    # Assert that style is empty after changing if muted
    reg.mute()
    assert reg.test_attr == ""
    # Assert that style is not empty

# Generated at 2022-06-21 23:57:44.297109
# Unit test for constructor of class Style
def test_Style():
    r1 = RenderType("foo", (1, 2, 3))
    r2 = RenderType("bar", (4, 5, 6))
    r3 = RenderType("baz", (5, 6, 7))
    r4 = RenderType("zoo", (6, 7, 8))

    s1 = Style(r1, r2, r3, "foo")

    assert isinstance(s1, Style)
    assert s1.rules == (r1, r2, r3)

    s2 = Style(r1, r2, s1, r3, r4)

    assert isinstance(s2, Style)
    assert s2.rules == (r1, r2, r1, r2, r3, r4)

    s3 = Style(r4)

    assert isinstance(s3, Style)


# Generated at 2022-06-21 23:57:53.216784
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestType(RenderType):
        pass

    def f1(x: int) -> str:
        return str(x)

    def f2(x: int) -> str:
        return str(x - 1)

    r1 = Register()
    r1.set_renderfunc(TestType, f1)

    assert r1.renderfuncs[TestType] == f1

    assert r1.renderfuncs[TestType](1) == "1"

    r1.set_renderfunc(TestType, f2)

    assert r1.renderfuncs[TestType] == f2

    assert r1.renderfuncs[TestType](1) == "0"



# Generated at 2022-06-21 23:58:09.836769
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, EightbitFg

    class EightbitCall(Register):
        def __init__(self):
            super().__init__()

        def render_eightbit(self, n: int) -> str:
            return f"\x1b[38;5;{n}m"

        def render_rgb(self, r: int, g: int, b: int) -> str:
            return f"\x1b[38;2;{r};{g};{b}m"

    # Create instance of EightbitCall
    test = EightbitCall()

    # Set renderfunc for RgbFg
    test.set_renderfunc(RgbFg, test.render_rgb)

    # Set renderfunc for EightbitFg

# Generated at 2022-06-21 23:58:17.955734
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    Register().as_dict()

    assert fg.black == '\x1b[38;5;16m'
    assert fg.black.as_dict() == {'black': '\x1b[38;5;16m'}

    assert fg.black == '\x1b[38;5;16m'
    assert fg.black.as_namedtuple().black == '\x1b[38;5;16m'

    assert fg.copy().black == '\x1b[38;5;16m'
    assert fg.copy() == fg



# Generated at 2022-06-21 23:58:21.438245
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from . import ef

    ef.bold = Style(ef.bold)

    assert isinstance(ef.bold, Style)

    ef.bold_italic = Style(ef.bold, ef.italic)

    assert isinstance(ef.bold_italic, Style)



# Generated at 2022-06-21 23:58:26.484145
# Unit test for constructor of class Style
def test_Style():
    rt = RenderType("Sgr", 1)
    s = Style(rt)
    assert isinstance(s, Style) is True
    assert isinstance(s, str) is True
    assert s.rules == (rt,)
    assert str(s) == "\x1b[1m"



# Generated at 2022-06-21 23:58:35.087720
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    @test
    def returns_namedtuple():
        r = Register()
        nt = r.as_namedtuple()
        assert nt.__class__ is namedtuple("StyleRegister", []).__class__
        expect(nt.__dict__).to_equal({"_asdict": r.as_dict, "_fields": (), "_field_defaults": {}})

    @test
    def returns_namedtuple_with_values():
        r = Register()
        r.name = Style(RgbFg(2, 3, 4), Sgr(1), value="\x1b[38;2;2;3;4m\x1b[1m")
        nt = r.as_namedtuple()
        assert nt.__class__ is namedtuple("StyleRegister", ["name"]).__class

# Generated at 2022-06-21 23:58:41.995049
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from sty import ef, fg, bg

    # Set up fg-register with default renderfuncs
    fg.set_renderfunc(ef.reset, lambda: "0")
    fg.set_renderfunc(ef.bold, lambda: "1")
    fg.set_renderfunc(fg.eightbit, lambda x: f"38;5;{x}")
    fg.set_renderfunc(fg.rgb, lambda r, g, b: f"38;2;{r};{g};{b}")

    assert fg.eightbit_call(42) == "38;5;42"
    assert fg.rgb_call(10, 20, 30) == "38;2;10;20;30"

    # Assert that new renderfuncs are used
    fg.set_

# Generated at 2022-06-21 23:58:44.543219
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class MyRegister(Register):
        """A Custom Register Class"""
        blue = Style(Fg(68))

    reg = MyRegister()
    nt = reg.as_namedtuple()

    assert nt.blue == reg.blue

# Generated at 2022-06-21 23:58:50.511848
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class Red(RenderType):
        def as_ansi_sequence(self):
            return "\x1b[31m"

    class Green(RenderType):
        def as_ansi_sequence(self):
            return "\x1b[32m"

    def red():
        return "\x1b[31m"

    def green():
        return "\x1b[32m"

    r = Register()
    r.set_renderfunc(Red, red)
    r.set_renderfunc(Green, green)

    r.red = Style(Red())
    assert str(r.red) == "\x1b[31m"

    # Note: You can not change the type of the render-type of an existing style
    r.green = Style(Red())

# Generated at 2022-06-21 23:58:53.093086
# Unit test for constructor of class Style
def test_Style():
    assert Style(fg='red', bg='blue').value == '\x1b[31m\x1b[44m'
    assert Style(fg='red', bg='blue').rules == (fg, bg)


# Generated at 2022-06-21 23:59:01.237305
# Unit test for method mute of class Register
def test_Register_mute():

    class MyRegister(Register):
        def __init__(self):
            super().__init__()

            self.something = Style(RgbFg(1, 2, 3), Sgr(5))

    r: MyRegister = MyRegister()
    assert r.something == "\x1b[38;2;1;2;3m\x1b[5m"

    r.mute()
    assert r.something == ""

    r.unmute()
    assert r.something == "\x1b[38;2;1;2;3m\x1b[5m"



# Generated at 2022-06-21 23:59:16.781320
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from . import RgbFg as rgb

    fg = Register()
    fg.set_renderfunc(rgb, lambda r,g,b: "")
    fg.set_rgb_call(rgb)
    fg.rgb_call = lambda r,g,b: (r, g, b)
    assert fg.rgb_call(10, 42, 255) == (10, 42, 255)


# Generated at 2022-06-21 23:59:22.052348
# Unit test for constructor of class Style
def test_Style():
    # Test construction of Style
    my_rule = Style(RenderType(5, 6), RenderType(1, 2, 3))

    # Test proper type handling
    assert(isinstance(my_rule, Style))
    assert(isinstance(my_rule, str))

    # Test if str yields the expected value
    assert(str(my_rule) == "\x1b[5;6m\x1b[1;2;3m")



# Generated at 2022-06-21 23:59:32.837619
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.x = Style(RgbBg(0, 10, 20), Sgr(1))
    r.y = Style(RgbFg(10, 20, 30), RgbBg(30, 20, 10))
    r.z = Style(EightbitFg(0))
    
    assert r.as_dict() == {
        'x': '\x1b[48;2;0;10;20m\x1b[1m',
        'y': '\x1b[38;2;10;20;30m\x1b[48;2;30;20;10m',
        'z': '\x1b[30m'
    }
    

# Generated at 2022-06-21 23:59:43.389045
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import Eightbit

    class MockRenderType(RenderType):
        pass

    class MockRegister(Register):
        pass

    mock = MockRegister()
    mock.set_renderfunc(MockRenderType, lambda x: 123)

    mock.set_eightbit_call(MockRenderType)
    assert mock.eightbit_call(0) == 123
    assert mock.eightbit_call(0, True) == 123
    assert mock.eightbit_call(0, False) == 123

    mock.set_eightbit_call(Eightbit)
    assert mock.eightbit_call(0) == ""
    assert mock.eightbit_call(0, True) == "\x1b[38;5;0m"

# Generated at 2022-06-21 23:59:48.026550
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """Test method as_namedtuple of class Register."""
    rs = Register()
    rs.foo = Style("")
    rs.bar = Style("")
    assert rs.as_namedtuple() == rs.as_namedtuple()



# Generated at 2022-06-21 23:59:55.970045
# Unit test for method set_renderfunc of class Register

# Generated at 2022-06-21 23:59:59.857196
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r: Register = Register()
    r.set_eightbit_call(RBG)


# Generated at 2022-06-22 00:00:04.397357
# Unit test for method copy of class Register
def test_Register_copy():
    original = Register()
    copied = original.copy()
    original.test = "test"
    assert getattr(original, "test", None) == "test"
    assert getattr(copied, "test", None) != "test"

# Generated at 2022-06-22 00:00:15.745663
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class A(RenderType):
        def fmt(self):
            return "A"

    class B(RenderType):
        def fmt(self):
            return "B"

    RenderfuncsForRegister = Renderfuncs

    def renderfunc_for_A(rendertype: RenderType) -> str:
        return rendertype.fmt()

    def renderfunc_for_B(rendertype: RenderType) -> str:
        return rendertype.fmt()

    RenderfuncsForRegister.update({A: renderfunc_for_A, B: renderfunc_for_B})

    register = Register()
    register.set_renderfunc(A, renderfunc_for_A)
    register.set_renderfunc(B, renderfunc_for_B)
    assert register.renderfuncs[A] == renderfunc_for_A

# Generated at 2022-06-22 00:00:22.855790
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    import pytest
    from .rendertype import Sgr
    from .style_registers import fg, bg
    from pytest import raises

    # Set on bg-register
    bg.black = Style(Sgr(40), value="\x1b[40m")
    assert bg.black == "\x1b[40m"

    # Set on fg-register
    fg.red = Style(Sgr(31), value="\x1b[31m")
    assert fg.red == "\x1b[31m"

    # Set with raised exception
    with raises(ValueError):
        fg.yellow = 42

# Generated at 2022-06-22 00:01:10.265736
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()
    r.renderfuncs.update({
        "A": lambda a: "A{}".format(a),
        "B": lambda b: "B{}".format(b)
    })

    r.set_eightbit_call("A")
    r.set_rgb_call("B")

    r.ascii = Style(RenderType("A", 1), RenderType("B", 2, 3, 4))

    r2 = r.copy()

    assert r2.eightbit_call == r.eightbit_call
    assert r2.rgb_call == r.rgb_call
    assert r2.renderfuncs == r.renderfuncs
    assert r2.ascii.rules == r.ascii.rules

# Generated at 2022-06-22 00:01:16.504138
# Unit test for constructor of class Style
def test_Style():
    style = Style(RgbFg(1, 2, 3))
    assert isinstance(style, str)
    assert isinstance(style, Style)
    assert style == "\x1b[38;2;1;2;3m"
    assert style.rules == (RgbFg(1, 2, 3),)



# Generated at 2022-06-22 00:01:20.299188
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    assert r.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-22 00:01:30.704523
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg, bg
    fg_0 = fg(0)
    fg_red = fg.red
    fg_black = fg.black
    fg_rgb_yellow = fg(255, 255, 0)

    assert fg.is_muted is False
    assert fg_0 == "\033[38;5;0m"
    assert fg_red == "\033[38;5;1m"
    assert fg_black == "\033[38;5;0m"

    # Mute
    fg.mute()
    assert fg.is_muted is True
    assert fg_0 == ""
    assert fg_red == ""
    assert fg_black == ""

    # Unmute
    fg.unmute()
    assert f

# Generated at 2022-06-22 00:01:40.570136
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Testing the unmute method of the Register class.
    """
    import sty
    sty.rs()

    reg = Register()
    reg.set_eightbit_call(sty.RgbFg)
    reg.mute()

    reg.red = sty.Style(sty.RgbFg(255, 0, 0))
    reg.blue = sty.Style(sty.RgbFg(0, 0, 255))

    res_muted = reg.red + "MUTED" + reg.rs + reg.blue + "MUTED" + reg.rs

    assert res_muted == "MUTEDMUTED"

    reg.unmute()

    res_unmuted = reg.red + "UNMUTED" + reg.rs + reg.blue + "UNMUTED" + reg.rs

# Generated at 2022-06-22 00:01:51.087907
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register = Register()

    class A(RenderType):
        pass

    class B(RenderType):
        pass

    register.set_renderfunc(A, lambda: "a")
    register.set_renderfunc(B, lambda: "b")

    # Test 1: 'AaBb' == register.test
    register.test = Style(A, B)
    assert register.test == "ab"

    # Test 2: 'Aa' == register.test
    register.test = Style(A)
    assert register.test == "a"

    # Test 3: 'Bb' == register.test
    register.test = Style(B)
    assert register.test == "b"

    # Test 4: 'AaBbCc' == register.test

# Generated at 2022-06-22 00:01:54.462307
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import Sgr
    from .registers import fg

    fg.black = Style(Sgr(30))
    fg.white = Style(Sgr(37))

    assert fg.as_dict() == {"black": Sgr(30).ansi, "white": Sgr(37).ansi}

# Generated at 2022-06-22 00:01:57.332595
# Unit test for method mute of class Register
def test_Register_mute():

    r = Register()
    r.foo = Style(value="\x1b[1m")

    r.mute()
    assert r.foo == ""

    r.unmute()
    assert r.foo == "\x1b[1m"


# Generated at 2022-06-22 00:02:04.505942
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class TestRegister(Register):
        pass

    R = TestRegister()
    R.black = Style(RgbFg(0,0,0))
    R.white = Style(RgbFg(255, 255, 255))
    R.red = Style(RgbFg(255, 0, 0))

    R_dict = R.as_dict()

    assert len(R_dict) == 3
    assert R_dict["black"] == "\x1b[38;2;0;0;0m"
    assert R_dict["white"] == "\x1b[38;2;255;255;255m"
    assert R_dict["red"] == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-22 00:02:12.565979
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import RgbFg
    from .rendertype import Sgr

    s = Style(RgbFg(1, 5, 10), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"

    s2 = Style(s)
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;5;10m\x1b[1m"

    with pytest.raises(ValueError):
        s3 = Style(1)



# Generated at 2022-06-22 00:02:45.651357
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .renderbase import RenderBase
    from .rendertype import EightBit, RgbFg

    # Create a renderbase-instance that we can use for testing.
    rb = RenderBase()

    # Create a style for testing.
    rgb_style = Style(RgbFg(60, 80, 120))

    # Create a register object with two rendertypes.
    r1 = Register()
    r1.renderfuncs.update(
        {RgbFg: rb.render_rgb_fg, EightBit: rb.render_eightbit})

    # Set the previous created style to foreground-red
    r1.red = rgb_style

    # Mutate the register object
    r1.mute()

    # The value of r1.red should now return empty str.
    assert r1.red == ""

    #

# Generated at 2022-06-22 00:02:55.122180
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    d = Register()

    d.test = Style(RgbFg(12, 34, 56))

    assert d.test == "\x1b[38;2;12;34;56m"

    d.test2 = Style(RgbFg(12, 34, 56), Sgr(1))

    assert d.test2 == "\x1b[38;2;12;34;56m\x1b[1m"

    d.test3 = Style(
        RgbFg(12, 34, 56), Sgr(1), Style(RgbFg(12, 34, 56), Sgr(1))
    )


# Generated at 2022-06-22 00:02:57.316535
# Unit test for constructor of class Register
def test_Register():
    """
    This test does not do anything yet.
    """
    pass

# Generated at 2022-06-22 00:03:06.620982
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg

    def fg_rgb_r(r, g, b):
        return f"\\x1b[38;2;{r};{g};{b}m"

    r1: Register = Register()
    r1.set_renderfunc(RgbFg, fg_rgb_r)
    r1.red = Style(RgbFg(255, 0, 0))
    assert r1(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert r1("red") == "\x1b[38;2;255;0;0m"



# Generated at 2022-06-22 00:03:08.051547
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    import sty

    sty.rs.as_namedtuple().black # '\x1b[30m'

# Generated at 2022-06-22 00:03:20.226122
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import AnsiFg, RgbFg, RgbBg

    class MyRegister(Register):
        reset: Style
        foo: Style

    my_render_type: Type[RenderType] = RgbBg

    my_register = MyRegister()

    my_register.set_renderfunc(
        rendertype=my_render_type, func=lambda r, g, b: f"{r}{g}{b}"
    )

    my_register.reset = Style(RgbFg(10, 20, 30))
    my_register.foo = Style(AnsiFg(124), RgbBg(10, 20, 30))

    assert my_register.reset == "102030"
    assert my_register.foo == "\x1b[38;5;124m102030"



# Generated at 2022-06-22 00:03:31.439472
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .render.eightbit import Eightbit

    from .render.sgr import SgrBold

    r = Register()

    r.set_renderfunc(Eightbit, lambda x: str(x))
    r.set_renderfunc(SgrBold, lambda x: str(x) + "b")

    r.black = Style(Eightbit(0))
    r.bold = Style(SgrBold())

    r.mute()
    r.black = Style(Eightbit(41))
    r.bold = Style(SgrBold())

    assert str(r.black) == ""
    assert str(r.bold) == ""

    r.unmute()
    assert str(r.black) == "41"
    assert str(r.bold) == "1b"

# Generated at 2022-06-22 00:03:36.584534
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.set_renderfunc(RenderType, lambda x: "Rendering " + x + " !")

        def set_renderfunc(self, rendertype: Type[RenderType], func: Callable) -> None:
            super().set_renderfunc(rendertype, func)

    R = MyRegister()

    R.custom_style = Style(RenderType=RenderType)

    assert getattr(R, "custom_style") == "Rendering RenderType !"



# Generated at 2022-06-22 00:03:42.813148
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.set_renderfunc(RenderType, lambda a: "")
    r.bold = Style(RenderType(1))

    # Mute the object
    r.mute()

    # Test for correct empty styled string
    assert r.bold == ""

    # Unmute the object
    r.unmute()

    # Test for correct styled string
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-22 00:03:46.040532
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False
    assert r.eightbit_call is r.rgb_call



# Generated at 2022-06-22 00:04:42.453124
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.one = Style(Sgr(1))
            self.two = Style(Sgr(2))
            self.three = Style(Sgr(3))

    items = MyRegister().as_dict()

    assert len(items) == 3
    assert "one" in items
    assert "two" in items
    assert "three" in items

# Generated at 2022-06-22 00:04:52.144775
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr
    from .renderrules import default_renderfuncs

    # Setup
    fg = Register()
    fg.set_renderfunc(RenderType, lambda *x: "")
    fg.black = Style(Sgr(30))
    fg.red = Style(Sgr(31))
    fg.green = Style(Sgr(32))

    # Test
    assert fg.black == "", "Test1 failed"
    assert fg.red == "", "Test2 failed"
    assert fg.green == "", "Test3 failed"

    # Setup
    fg_new = Register()
    fg_new.set_renderfunc(RenderType, lambda *x: "Sty")
    fg_new.black = Style(Sgr(30))

# Generated at 2022-06-22 00:04:58.140254
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .ansi import Sgr, RgbFg

    style = Style(Sgr(1), RgbFg(1,2,3))

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[38;2;1;2;3m\x1b[1m"

# Generated at 2022-06-22 00:05:07.697187
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .register import fg, bg, ef
    import pytest

    fg.blue = Style(RgbFg(10, 20, 30))
    fg.yellow = Style(RgbFg(40, 50, 60))
    bg.red = Style(RgbFg(70, 80, 90))

    # When
    namedtuple_fg = fg.as_namedtuple()

    # Then
    assert len(namedtuple_fg) == 2
    assert namedtuple_fg.blue == '\x1b[38;2;10;20;30m'
    assert namedtuple_fg.yellow == '\x1b[38;2;40;50;60m'

    # When
    namedtuple_bg = bg.as_namedtuple()

    # Then
   