

# Generated at 2022-06-21 23:55:12.693266
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    bg = Register()
    bg.set_eightbit_call(RenderType)
    return bg.eightbit_call

# Generated at 2022-06-21 23:55:18.112287
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class MockRenderType(RenderType):
        pass

    def render_function(red, green, blue):
        return "Test"

    register = Register()
    register.set_renderfunc(MockRenderType, render_function)
    register.set_rgb_call(MockRenderType)

    assert register(42, 69, 87) == "Test"


# Generated at 2022-06-21 23:55:23.797884
# Unit test for constructor of class Register
def test_Register():
    import pytest
    from sty import fg, bg, ef, rs

    assert isinstance(fg, Register)
    assert isinstance(bg, Register)
    assert isinstance(ef, Register)
    assert isinstance(rs, Register)

    with pytest.raises(TypeError):
        Register()



# Generated at 2022-06-21 23:55:34.236135
# Unit test for method __new__ of class Style
def test_Style___new__():

    # We need this to register RenderTypes as constructors for the Style class.
    renderfuncs: Renderfuncs = {}

    # This is the dummy render function for test purposes.
    def render_function(*args: List[int]):
        return args

    # This is our dummy RenderType.
    class Dummy(RenderType):
        _renderfunction = render_function
        _renderargs: List[int]

        def __init__(self, *args: int):
            self._renderargs = args

        @property
        def args(self) -> Tuple[int]:
            return self._renderargs

    # Register dummy rendertype.
    renderfuncs[Dummy] = render_function

    # Create dummy style.

# Generated at 2022-06-21 23:55:39.484433
# Unit test for method copy of class Register
def test_Register_copy():

    a = Register()
    s = Style(sgr("0"), reset=True)
    a.test = s

    b = a.copy()
    assert a.test == b.test
    assert a.test is not b.test
    assert id(a.test) is not id(b.test)

# Generated at 2022-06-21 23:55:43.033233
# Unit test for method copy of class Register
def test_Register_copy():

    sgr = Register()
    sgr.bold = Style(Sgr(1))

    assert not isinstance(sgr, Register)

    sgr_new = sgr.copy()

    assert isinstance(sgr_new, Register)

# Generated at 2022-06-21 23:55:44.888317
# Unit test for constructor of class Style
def test_Style():

    st: Style
    st = Style("value", "value")

    assert isinstance(st, str)
    assert isinstance(st, Style)
    assert len(st.rules) == 2
    assert st.rules[0] == "value"
    assert st.rules[1] == "value"



# Generated at 2022-06-21 23:55:48.411410
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Unit test for method set_rgb_call of class Register
    """
    reg = Register()
    reg.set_rgb_call(RenderType.NONE)
    assert None == reg.rgb_call(255, 255, 255)


# Generated at 2022-06-21 23:55:58.477991
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Sgr(RenderType):
        code: int

        def __init__(self, code: int):
            self.code = code

        def __str__(self):
            return f"\x1b[{self.code}m"

    class FakeRegister(Register):
        pass

    color_register = FakeRegister()

    color_register.renderfuncs = {Sgr: lambda x: f"Sgr({x.code})"}

    color_register.orange = Style(Sgr(1))

    assert str(color_register.orange) == "Sgr(1)"

# Generated at 2022-06-21 23:56:03.942182
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    s = Sty()
    s.fg.red = Style(RgbFg(255, 0, 0))
    s.bg.blue = Style(RgbBg(0, 0, 255))
    s.fg.set_eightbit_call(RgbFg)
    s.bg.set_eightbit_call(RgbBg)
    assert s.fg(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert s.bg(0, 0, 255) == "\x1b[48;2;0;0;255m"



# Generated at 2022-06-21 23:56:12.964157
# Unit test for method __call__ of class Register
def test_Register___call__():
    import pytest
    r1 = Register()
    r1.set_renderfunc(RgbFg, lambda r,g,b: "rgb(" + str(r) + "," + str(g) + "," + str(b) + ")")
    r1.set_renderfunc(EightbitFg, lambda code: "eightbit(" + str(code) + ")")
    r1.set_eightbit_call(EightbitFg)
    r1.set_rgb_call(RgbFg)

    assert r1(144) == "eightbit(144)"
    assert r1(255, 0, 0) == "rgb(255,0,0)"


# Generated at 2022-06-21 23:56:23.580993
# Unit test for method __call__ of class Register
def test_Register___call__():

    class DummyRender(RenderType):
        def render(self) -> str:
            return f"{self.args[0]}"

    register = Register()

    def _renderfunc1(*args) -> str:
        return f"{args[0]};{args[1]};{args[2]}"

    register.set_renderfunc(DummyRender, _renderfunc1)

    # Test with args as int
    register.color = Style(DummyRender(144))
    assert register(144) == "144"

    # Test with args as tuple
    register.color = Style(DummyRender(10, 42, 255))
    assert register(10, 42, 255) == "10;42;255"

    # Test with args as string
    register.color = Style(DummyRender("color"))
    assert register("color")

# Generated at 2022-06-21 23:56:29.240483
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, bg, RenderType

    sty = fg.black
    sty.renderfuncs.update({RenderType.RGB: lambda r, g, b: f"[{r}:{g}:{b}]"})
    sty.set_rgb_call(RenderType.RGB)

    assert sty(10, 20, 30) == f"[10:20:30]"


# Generated at 2022-06-21 23:56:39.945859
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Create test register and style names
    register = Register()
    attr_name1 = "attr1"
    attr_name2 = "attr2"
    attr_name3 = "attr3"
    # Append styles to test register
    register.attr1 = Style()
    register.attr2 = Style()
    register.attr3 = Style()
    # Execute method test: as_namedtuple
    styles = register.as_namedtuple()
    # Check if attributes of namedtuple are the same as attributes in test register.
    assert hasattr(styles, attr_name1), "as_namedtuple(): Register's attribute 'attr1' is not in returned namedtuple"

# Generated at 2022-06-21 23:56:44.591221
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr

    fg = Register()
    fg.red = Style(Sgr(31))

    assert isinstance(fg.red, Style)

    assert isinstance(fg.red, str)

    assert str(fg.red) == "\x1b[31m"



# Generated at 2022-06-21 23:56:50.040650
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    # Set renderfunc
    r.set_renderfunc(RgbFg, lambda *args, **kwargs: "test")
    # set eightbit_call
    r.set_eightbit_call(RgbFg)
    # test eightbit_call
    assert(r(42) == "test")

# Generated at 2022-06-21 23:56:56.164562
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertypes import Sgr

    register = Register()
    register.set_renderfunc(Sgr, lambda x: "\x1b[{}m".format(x))
    register.bold = Style(Sgr(1))

    assert register(1) == ""
    assert register("bold") == "\x1b[1m"
    assert register(1, 2, 3) == ""



# Generated at 2022-06-21 23:57:00.931857
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .rendertype import RgbFg, RgbBg, Sgr

    # Create register
    register = Register()

    # Define styles
    register.red = Style(RgbFg(255, 0, 0))
    register.blue = Style(RgbBg(0, 0, 255))
    register.solid = Style(Sgr(1))

    # Export as namedtuple
    styles = register.as_namedtuple()

    assert styles.red == "\x1b[38;2;255;0;0m"
    assert styles.blue == "\x1b[48;2;0;0;255m"
    assert styles.solid == "\x1b[1m"

# Generated at 2022-06-21 23:57:06.395718
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    import sty

    r = sty.Register()
    r.red = sty.Style(sty.RgbFg(255, 0, 0))
    r.set_rgb_call(sty.RgbFg)

    assert r(255, 0, 0) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-21 23:57:17.445877
# Unit test for method __call__ of class Register
def test_Register___call__():

    from sty import RenderType, fg, bg
    from sty.modes import no_color

    rt = RenderType
    f = fg
    b = bg

    f1 = None
    f2 = None
    f3 = None

    def func1(x: int) -> str:
        nonlocal f1
        f1 = x
        return "func1"

    def func2(r: int, g: int, b: int) -> str:
        nonlocal f2
        f2 = (r, g, b)
        return "func2"

    def func3(x: int) -> str:
        nonlocal f3
        f3 = x
        return "func3"

    fg.set_renderfunc(rt, func1)

# Generated at 2022-06-21 23:57:33.543032
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))
    r2 = r.copy()

    assert r2.red == "[38;2;255;0;0m"
    assert r2.green == "[38;2;0;255;0m"

    r2.green = Style(RgbFg(222, 0, 0))

    assert r2.green == "[38;2;222;0;0m"
    assert r.green == "[38;2;0;255;0m"

# Generated at 2022-06-21 23:57:44.460472
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .ansi import RgbFg, Sgr

    r1 = Register()
    r1.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r1.set_renderfunc(Sgr, lambda code: f"\x1b[{code}m")

    r1.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(r1.orange, Style)
    assert isinstance(r1.orange, str)
    assert str(r1.orange) == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-21 23:57:54.329667
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Here we define a simple rendertype RgbFg.
    class RgbFg(RenderType):
        name: str = "rgb-fg"
        renderseq: str = "\x1b[38;2;{r};{g};{b}m"

    Sty = namedtuple("Sty", "fg")
    fg = Register()

    # Define a simple renderfunc for RgbFg.
    def renderfunc_RgbFg(self, r, g, b):
        return self.renderseq.format(r=r, g=g, b=b)

    renderfunc_RgbFg = renderfunc_RgbFg.__get__(RgbFg)

    # Add renderfunc to class RgbFg
    RgbFg.render = renderfunc_RgbFg

    # Tell

# Generated at 2022-06-21 23:57:59.185849
# Unit test for method unmute of class Register
def test_Register_unmute():
    reg = Register()
    reg.is_muted = True
    reg.black = Style(RgbFg(0, 0, 0))
    reg.unmute()
    assert reg.black == "\x1b[38;2;0;0;0m"
    assert reg.is_muted == False




# Generated at 2022-06-21 23:58:04.945883
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.rs = Style(Sgr(1))
    r.blue = Style(Sgr(34))
    r.mute()
    assert str(r.rs) == ""
    assert str(r.blue) == ""
    r.unmute()
    assert str(r.rs) == "\x1b[1m"
    assert str(r.blue) == "\x1b[34m"


# Generated at 2022-06-21 23:58:11.862042
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    reg = Register()
    reg.a = Style(ColorFg(1), ColorBg(2))
    reg.b = Style(BrightFg(2), BrightBg(1))

    namedtuple = reg.as_namedtuple()

    assert namedtuple.a == "\x1b[38;5;1m\x1b[48;5;2m"
    assert namedtuple.b == "\x1b[38;5;9m\x1b[48;5;8m"

# Generated at 2022-06-21 23:58:21.332250
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Input is a 8-Bit code.
    r1 = Register()
    r1.eightbit_call = lambda x: str(x)
    assert r1(42) == "42"

    # Input is a RGB-color code
    r2 = Register()
    r2.rgb_call = lambda r, g, b: "".join(map(str, [r, g, b]))
    assert r2(42, 37, 2) == "42237"

    # Input is a string.
    r3 = Register()
    r3.red = Style(value="red")
    assert r3("red") == "red"

    # Input is invalid.
    r4 = Register()
    assert r4() == ""

# Generated at 2022-06-21 23:58:31.707048
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Create dummy register
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.test1 = Style(value="abc")
            self.test2 = Style(value="def")
            self.test3 = Style(value="ghi")

    r = TestRegister()

    # Test 1: return value of intialized attribute
    expected = "abc"
    actual = r.test1
    assert expected == actual

    # Test 2: return "" if register muted
    r.mute()
    expected = ""
    actual = r.test1
    assert expected == actual

    # Test 3: return initialized attribute if called by name
    expected = "abc"
    actual = r("test1")
    assert expected == actual

    # Test 4: return initialized attribute if called by name and register muted

# Generated at 2022-06-21 23:58:39.289463
# Unit test for method unmute of class Register
def test_Register_unmute():

    import pytest

    from .rendertypes import Sgr, RgbFg, RgbBg

    fg = Register()

    # Set up test values
    fg.test1 = Style(Sgr(1))  # bold
    fg.test2 = Style(Sgr(2))  # dim
    fg.test3 = Style(RgbBg(0, 42, 42))

    # Mute regitser
    fg.mute()

    # Check if all Style-attrs have been muted.
    assert str(fg.test1) == ""
    assert str(fg.test2) == ""
    assert str(fg.test3) == ""

    # Unmute register
    fg.unmute()

    # Check if all Style-attrs have been unmuted.

# Generated at 2022-06-21 23:58:45.782519
# Unit test for method mute of class Register
def test_Register_mute():
    from .core import fg, bg
    from .rendertype import Sgr, RgbBg

    fg.mute()
    assert fg.is_muted == True
    assert str(fg.green) == ""
    assert str(bg.blue) == ""

    fg.set_rgb_call(RgbBg)
    assert str(fg(100,100,100)) == ""

    fg.unmute()
    assert fg.is_muted == False
    assert str(fg.green) == "\x1b[38;2;0;127;0m"
    assert str(bg.blue) == "\x1b[48;2;0;0;127m"

# Generated at 2022-06-21 23:58:57.092456
# Unit test for method __call__ of class Register
def test_Register___call__():

    def func(*args):
        return f"call({args[0]}, {args[1]}, {args[2]})"

    class RGB(RenderType):
        """
        Test class fpr rendertype
        """

        def renderfunc(self):
            pass

    cls = Register()
    cls.set_eightbit_call(RGB)
    cls.set_rgb_call(RGB)
    cls.set_renderfunc(RGB, func)

    assert cls(1) == "call(1, None, None)"
    assert cls(2, 3, 4) == "call(2, 3, 4)"
    assert cls("red") == ""


# Generated at 2022-06-21 23:59:06.289565
# Unit test for constructor of class Register
def test_Register():
    from unittest.mock import Mock, MagicMock

    mock: Mock = Mock()
    mock.renderfuncs = {Mock: MagicMock()}
    r = Register()
    r.renderfuncs = mock.renderfuncs
    setattr(r, "testvar", Style())
    assert r.testvar == ""

    # Mute the register object
    r.mute()
    assert r.testvar == ""
    assert getattr(r, "testvar", Style()) == ""

    # Unmute the register object
    r.unmute()
    assert r.testvar == ""
    assert getattr(r, "testvar", Style()) == ""

    # Test eightbit_call
    assert r.eightbit_call == 0
    r.set_eightbit_call(Mock)
    assert r

# Generated at 2022-06-21 23:59:16.894999
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Style(Register):
        pass

    style = Style()

    style.test = Style()

    assert style.test == Style()

    style.test = Style(
        "test", Sgr(1), Sgr(2), Sgr(3), Sgr(4), Sgr(5), Sgr(6), Sgr(7), Sgr(8)
    )

    assert style.test == Style(
        "test", Sgr(1), Sgr(2), Sgr(3), Sgr(4), Sgr(5), Sgr(6), Sgr(7), Sgr(8)
    )


# Generated at 2022-06-21 23:59:23.264006
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    import sty

    # Set every register to have one callable rendertype
    for register_name in sty.attrs.SGR_REGISTERS + sty.attrs.EIGHTBIT_REGISTERS:
        register = getattr(sty, register_name)
        rendertype_name = sty.attrs.RENDER_ORDER[0]
        rendertype = getattr(sty, rendertype_name)
        register.set_eightbit_call(rendertype)
        assert isinstance(register.eightbit_call, Callable)



# Generated at 2022-06-21 23:59:26.973217
# Unit test for constructor of class Style
def test_Style():
    style = Style(RenderType(), RenderType())
    assert style.rules[0] == style.rules[1]
    assert isinstance(style.rules[0], RenderType)

# Generated at 2022-06-21 23:59:30.433293
# Unit test for method __new__ of class Style
def test_Style___new__():
    r1 = RenderType(9)
    s1 = Style(r1)
    assert s1.rules == (r1,)
    assert isinstance(s1, str)
    assert isinstance(s1, Style)



# Generated at 2022-06-21 23:59:37.553186
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # The code for this test was copied from the tests for the ColorRegister

    # Create new empty register
    r1: Register = Register()

    # Create and add new style to register.
    s1: Style = Style(RgbBg(255, 0, 0, 1))
    r1.red = s1

    # Export register as namedtuple
    n1: NamedTuple = r1.as_namedtuple()

    # Check whether the code works
    assert n1.red == s1



# Generated at 2022-06-21 23:59:48.885656
# Unit test for method mute of class Register
def test_Register_mute():
    s = Style(RgbFg(1, 2, 3), Sgr(1))
    r = Register()
    r.x = s

    assert isinstance(s, Style)
    assert isinstance(s, str)
    s = r.x
    assert not isinstance(s, str)
    assert isinstance(s, Style)
    assert str(s) == "\x1b[38;2;1;2;3m\x1b[1m"
    r.mute()
    assert str(r.x) == ""
    assert str(s) == ""
    r.unmute()
    assert str(r.x) == "\x1b[38;2;1;2;3m\x1b[1m"

# Generated at 2022-06-21 23:59:55.837515
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .colorcodes import (
        Eightbit,
        RgbFg,
        RgbBg,
        RgbEf,
        RgbRs,
        EightbitFg,
        EightbitBg,
        EightbitEf,
        EightbitRs,
    )

    fg = Register()
    fg.red = Style(EightbitFg(1))
    assert isinstance(fg.red, Style)
    assert fg.red == "\u001b[38;5;1m"

    fg.set_rgb_call(RgbFg)
    assert fg(1, 2, 3) == "\u001b[38;2;1;2;3m"

# Generated at 2022-06-22 00:00:08.437309
# Unit test for method __call__ of class Register
def test_Register___call__():
    class RgbRenderType(RenderType):
        pass

    class EightBitRenderType(RenderType):
        pass

    fg = Register()
    fg.set_renderfunc(RgbRenderType, lambda x, y, z: f"{x} {y} {z}")
    fg.set_renderfunc(EightBitRenderType, lambda x: f"{x}")

    fg.set_eightbit_call(EightBitRenderType)
    fg.set_rgb_call(RgbRenderType)

    assert fg(1) == "1"
    assert fg(2, 3, 4) == "2 3 4"

    fg.mute()
    assert fg(5) == ""
    assert fg(6, 7, 8) == ""

# Generated at 2022-06-22 00:00:21.440886
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbBg, RgbEf, RgbFg

    fg = Register()
    ef = Register()

    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_rgb_call(RgbFg)

    ef.set_renderfunc(RgbEf, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    ef.set_rgb_call(RgbEf)

    fg.red = Style(RgbFg(255, 0, 0))
    ef.blue = Style(RgbEf(0, 0, 255))


# Generated at 2022-06-22 00:00:33.971348
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .render import Ansi, RgbFg
    from .fg import fg

    f = Ansi()
    fg.renderfuncs = {RgbFg: f.render}

    fg.red = Style(RgbFg(255, 0, 0))

    assert fg.red == "\x1b[38;2;255;0;0m"

    fg.blue = Style(RgbFg(0, 0, 255))

    assert fg.blue == "\x1b[38;2;0;0;255m"

    fg.mute()

    assert fg.red == ""
    assert fg.blue == ""

    fg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-22 00:00:44.929460
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Sgr, RgbFg, RgbBg

    # Test Register Class
    reg = Register()

    # Test Sgr function
    reg.set_renderfunc(Sgr, lambda x: f"\x1b[{x}m")
    reg.red = Style(Sgr(1))
    assert str(reg.red) == "\x1b[1m"

    # Test RgbFg function
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.orange = Style(RgbFg(1, 5, 10))
    assert str(reg.orange) == "\x1b[38;2;1;5;10m"

    # Test Style and S

# Generated at 2022-06-22 00:00:47.241474
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register = Register()
    register.set_rgb_call(RenderType.RgbFg)
    assert register.rgb_call == register.renderfuncs[RenderType.RgbFg]



# Generated at 2022-06-22 00:00:48.042714
# Unit test for method mute of class Register
def test_Register_mute():
    pass



# Generated at 2022-06-22 00:00:50.223796
# Unit test for method copy of class Register
def test_Register_copy():
    RegisterClass = namedtuple("RegisterClass", ["foo"])
    reg1 = RegisterClass("bar")
    reg2 = reg1.copy()
    assert reg2 == reg1 # type: ignore

# Generated at 2022-06-22 00:00:55.684281
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertypes.eightbit import Eightbit

    register = Register()
    register.set_eightbit_call(Eightbit)
    register.set_renderfunc(Eightbit, lambda x: "EightbitCall")

    assert register(1) == "EightbitCall"
    assert register(2) == "EightbitCall"
    assert register(42) == "EightbitCall"

    assert register(10, 42, 255) == (10, 42, 255)



# Generated at 2022-06-22 00:01:05.529028
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import RgbBg, RgbFg
    from .ansi import RgbFgRenderType, RgbBgRenderType

    # Create new Register
    reg = Register()

    # Add renderfunc
    reg.set_renderfunc(RgbBgRenderType, lambda r,g,b: "RgbBg: " + str(r) + str(g) + str(b))
    reg.set_renderfunc(RgbFgRenderType, lambda r,g,b: "RgbFg: " + str(r) + str(g) + str(b))

    # Mute all calls
    reg.mute()

    # Set new styles
    reg.red = Style(RgbFg(1, 1, 1))

# Generated at 2022-06-22 00:01:16.386981
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test method is_muted of class Register.
    """
    class TestRegister(Register):
        def __init__(self):
            self.a = 42
            self.b = 144
            self.c = "42"
            self.d = Style(a="42")


    reg = TestRegister()
    reg_copy = reg.copy()

    assert id(reg) != id(reg_copy)
    assert id(reg.a) != id(reg_copy.a)
    assert id(reg.b) != id(reg_copy.b)
    assert id(reg.c) != id(reg_copy.c)
    assert id(reg.d) != id(reg_copy.d)



# Generated at 2022-06-22 00:01:26.765967
# Unit test for method __new__ of class Style
def test_Style___new__():
    class MockRenderType:
        def __init__(self, value):
            self.value = value
    A = MockRenderType("A")
    B = MockRenderType("B")
    C = MockRenderType("C")

    # Test with Style object Rule
    s1 = Style(A)
    assert hasattr(s1, "rules")
    assert s1.rules == (A,)

    # Test with Style object
    s2 = Style(s1)
    assert hasattr(s2, "rules")
    assert s2.rules == (s1,)

    # Test with Style object (multiple args)
    s3 = Style(A, s1)
    assert hasattr(s3, "rules")
    assert s3.rules == (A, s1)

    # Test with Style object (multiple args)
    s4

# Generated at 2022-06-22 00:01:34.031150
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    register = Register()

    # Test empty register
    assert register.as_dict() == {}

    # Test register with one style attribute
    register.test = Style(RenderType.Foreground, Sgr(1))

    assert register.as_dict() == {"test": "\x1b[38;5;246m\x1b[1m"}


# Generated at 2022-06-22 00:01:44.240976
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbBg, Sgr
    from .ansi import ansi_render_rgb_24bit_bg, ansi_render_sgr

    rg: Register = Register()
    rg.set_renderfunc(RgbBg, ansi_render_rgb_24bit_bg)
    rg.set_renderfunc(Sgr, ansi_render_sgr)

    assert rg.red == "\x1b[38;2;255;0;0m"
    assert rg.green == "\x1b[38;2;0;255;0m"
    assert rg.blue == "\x1b[38;2;0;0;255m"
    assert rg.magenta == "\x1b[38;2;255;0;255m"

# Generated at 2022-06-22 00:01:51.860073
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Test with a custom register.
    class CustomRegister(Register):
        def __init__(self):
            super().__init__()
            self.foo = Style(RgbFg(1, 5, 10))

    r = CustomRegister()
    assert str(r.foo) == "\x1b[38;2;1;5;10m"
    r.mute()
    assert str(r.foo) == ""
    r.unmute()
    assert str(r.foo) == "\x1b[38;2;1;5;10m"

# Generated at 2022-06-22 00:01:59.385283
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .style.style import base
    from .style.style import register

    base.rs = Style(base.rs_sgr)
    base.rs_sgr = Style(base.rs_sgr)

    r = Register()
    r.is_muted = False

    for k, v in base.__dict__.items():
        if not k.startswith("_"):
            setattr(r, k, v)

    for k, v in register.__dict__.items():
        if not k.startswith("_"):
            setattr(r, k, v)

    nt = r.as_namedtuple()
    assert nt.red == "\x1b[31m"

# Generated at 2022-06-22 00:02:02.481709
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import Sgr, RgbFg

    r1 = Sgr(1)
    r2 = RgbFg(123, 1, 2)
    s = Style(r1, r2)

    assert s.rules == (r1, r2)
    assert s.count("\x1b") == 2


# Generated at 2022-06-22 00:02:04.273448
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(value="test")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s == "test"

# Generated at 2022-06-22 00:02:12.912903
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    fg.black = Style(RgbFg(0, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))

    bg = fg.copy()
    bg.set_rgb_call(RgbBg)

# Generated at 2022-06-22 00:02:23.235013
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Test for one style
    style: Style = Style(RgbFg(10, 20, 30))
    assert style == "\x1b[38;2;10;20;30m"
    assert style.rules == (RgbFg(10, 20, 30),)
    assert isinstance(style, str)
    assert isinstance(style, Style)

    # Test for two styles
    style: Style = Style(RgbFg(10, 20, 30), Sgr(2))
    assert style == "\x1b[38;2;10;20;30m\x1b[2m"
    assert style.rules == (RgbFg(10, 20, 30), Sgr(2))
    assert isinstance(style, str)
    assert isinstance(style, Style)

    # Test for three styles
    style

# Generated at 2022-06-22 00:02:29.549885
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import RgbBg

    class MyRegister(Register):
        pass

    register = MyRegister()
    register.red = Style(RgbBg(10, 42, 255))

    def render_func(*args, **kwargs):
        return '\x1b[48;2;%s;%s;%sm' % args

    register.set_renderfunc(RgbBg, render_func)

    assert register.red == "\x1b[48;2;10;42;255m"

# Generated at 2022-06-22 00:02:31.686152
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r.as_dict(), dict)
    assert isinstance(r.as_namedtuple(), NamedTuple)
    assert isinstance(r.copy(), Register)

# Generated at 2022-06-22 00:02:44.781295
# Unit test for constructor of class Register
def test_Register():
    # Create test object
    name = "my_register"

# Generated at 2022-06-22 00:02:46.580659
# Unit test for method __new__ of class Style
def test_Style___new__():
    
    obj = Style("")

    assert isinstance(obj, str)
    assert isinstance(obj, Style)

# Generated at 2022-06-22 00:02:52.535389
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .effects import Ef, RgbFg, Sgr

    style: Style = Style(RgbFg(0, 128, 0), Sgr(1))

    assert isinstance(style, Style)
    assert isinstance(style, str)

    assert style[0:3] == "\x1b["
    assert style[-1] == "m"
    assert style[-2] == "1"

# Generated at 2022-06-22 00:02:55.980932
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from Sty import Colors as style_colors
    from Sty.Rendertypes import RgbFg

    style_colors.bg.set_eightbit_call(RgbFg)

    assert(style_colors.bg(42) == "\x1b[48;2;42;42;42m")



# Generated at 2022-06-22 00:03:04.278305
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()

    r.rgb_call = lambda r, g, b: None
    r.eightbit_call = lambda c: None
    assert r(10, 42, 255) is None

    r.rgb_call = lambda r, g, b: None
    r.eightbit_call = lambda c: None
    assert r(69) is None

    r.rgb_call = lambda r, g, b: None
    r.eightbit_call = lambda c: None
    assert r('green') == ""

# Generated at 2022-06-22 00:03:05.947296
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.test_style = Style(value="test")

    assert r("test") == "test"



# Generated at 2022-06-22 00:03:08.624470
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class A(Register):
        pass
    a = A()
    a.muted = Style(value="\x1b[24m")
    assert a.as_dict() == {'muted': '\x1b[24m'}

# Generated at 2022-06-22 00:03:12.747957
# Unit test for method unmute of class Register
def test_Register_unmute():
    from . import (
        RgbBg,
        RgbFg,
        Sgr,
        fg,
        def_fg,
        def_bg,
        def_ef,
        def_rs,
    )

    # Create new registers
    ex_fg = Register()
    ex_fg.red = Style(RgbFg(255, 0, 0))

    # Mute register
    ex_fg.mute()

    # Check if red is empty str
    assert ex_fg.red == ""

    # Unmute register
    ex_fg.unmute()

    # Check if red is the original style
    assert ex_fg.red == Style(RgbFg(255, 0, 0), value="\x1b[38;2;255;0;0m")

    return

# Generated at 2022-06-22 00:03:19.697350
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    register = Register()

    register.red = Style(RgbFg(255, 0, 0))
    register.green = Style(RgbBg(0, 255, 0))

    d = register.as_dict()

    assert d["red"] == "\x1b[38;2;255;0;0m"
    assert d["green"] == "\x1b[48;2;0;255;0m"



# Generated at 2022-06-22 00:03:26.484191
# Unit test for method __new__ of class Style
def test_Style___new__():
    class MyRenderType(RenderType):
        args: NamedTuple("RenderTypeArgs", [("sample_arg1", int), ("sample_arg2", str)])

    s: Style = Style(MyRenderType(123, "test"))
    assert isinstance(s, str)
    assert isinstance(s, Style)
    assert getattr(s, "rules") == (MyRenderType(123, "test"),)



# Generated at 2022-06-22 00:03:43.598524
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertypes import EightBit

    class TestType(RenderType):
        pass

    # Create a register and modify it
    r = Register()
    r.set_eightbit_call(EightBit)
    r.set_rgb_call(TestType)

    r.foo = Style(TestType(240))
    r.bar = Style(EightBit(100))

    assert (
        r(42)
        == r.eightbit_call(42)
        == r.eightbit_call(42)
        == r.eightbit_call(42)
    ) == ""

    assert (r("foo") == r.foo) == ""
    assert (r("bar") == r.bar) == ""

    assert (r("foo", "bar") == r.foo) == ""

# Generated at 2022-06-22 00:03:47.444622
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class R(Register):
        pass

    r = R()
    r.blau = "blue"
    r.rot = "red"

    d = r.as_dict()

    assert d == {
        "blau": "blue",
        "rot": "red",
    }

# Generated at 2022-06-22 00:03:50.895574
# Unit test for method __new__ of class Style
def test_Style___new__():
    Style.rules = None
    s = Style(value="test")
    assert isinstance(s, Style)
    assert s == "test"
    assert s.rules == tuple()

# Generated at 2022-06-22 00:03:58.494716
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    A = RenderType("A", 42)
    B = RenderType("B", 42)

    def a_to_str(a: A) -> str:
        return str(a)

    def b_to_str(a: B) -> str:
        return str(a)

    a: A = A("a")
    b: B = B("b")

    sty = Style(a, b)

    reg = Register()
    reg.set_renderfunc(A, a_to_str)
    reg.set_renderfunc(B, b_to_str)

    reg.foo = sty

    assert reg.foo == "ab"

# Generated at 2022-06-22 00:04:06.162405
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertypes import Ef, RgbFg, Sgr

    r1 = Register()
    assert len(r1.renderfuncs) == 0

    r1.renderfuncs.update({Ef: lambda x: x + "test_1", RgbFg: lambda r, g, b: (r, g, b)})
    assert len(r1.renderfuncs) == 2

    s1 = Style(RgbFg(10, 20, 30), Ef(33))

    assert str(s1) == ""
    assert s1.rules[0].__class__ == RgbFg
    assert s1.rules[1].__class__ == Ef

    r1.test_1 = s1

    assert str(r1.test_1) == "test_1"
    assert r1.test_

# Generated at 2022-06-22 00:04:11.075839
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .render import Sgr, RgbFg

    class MyRegister(Register): pass

    reg1 = MyRegister()
    reg1.test1 = Style(Sgr(2), RgbFg(0, 0, 255))

    reg2 = MyRegister()
    reg2.test1 = reg1.test1

    named_tuple = reg1.as_namedtuple()

    assert len(named_tuple) == len(reg1.as_dict())

    # Change the named tuple.
    named_tuple.test1 = "Test"

    # Check that the change has not been done for the original register (reg1).
    assert reg1.test1 == reg2.test1

# Generated at 2022-06-22 00:04:21.841420
# Unit test for method mute of class Register
def test_Register_mute():

    from .render import RgbBg, Sgr
    from .rendertype import RgbBgRenderType

    # Test not muted
    rg = Register()
    rg.red = Style(RgbBg(255,0,0))
    assert rg.red == '\x1b[48;2;255;0;0m'

    # Test muted
    rg.mute()
    assert rg.red == ''

    # Test unmuted
    rg.unmute()
    assert rg.red == '\x1b[48;2;255;0;0m'

    # test not muted with SGR
    rg.bold = Style(Sgr(1))
    assert rg.bold == '\x1b[1m'

    # Test muted SGR
    rg.mute()
    assert rg.bold == ''



# Generated at 2022-06-22 00:04:27.297197
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    MiniAnsiType = NamedTuple("MiniAnsiType", [("name", str)])

    class MiniAnsi(RenderType):

        renderfunc: Callable

        args: Tuple[str,]

        def __init__(self, name: str) -> None:
            self.args = (name,)

    def _render_MiniAnsi(name: str) -> str:
        return "{}".format(name)

    reg = Register()
    reg.set_renderfunc(MiniAnsi, _render_MiniAnsi)
    reg.red = Style(MiniAnsi("red"))

    assert str(reg.red) == "red"

    reg.blue = Style(reg.red, MiniAnsi("blue"))
    assert str(reg.blue) == "redblue"

test_Register_set_renderfunc()

# Generated at 2022-06-22 00:04:36.165047
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test that registering styles in muted Register objects via attribute access and via
    direct call of the setter method, unmutes the Register.
    """

    def renderfunc(x):
        return f"{x}"

    # Setup
    reg = Register()
    reg.set_renderfunc(RenderType, renderfunc)
    reg.mute()

    # Test attributes
    reg.test = Style(RenderType(1))
    assert reg.test == ""
    assert reg.is_muted

    # Test direct setter call
    reg.set_style(test=Style(RenderType(1)))
    assert reg.test == "1"
    assert reg.is_muted



# Generated at 2022-06-22 00:04:37.064681
# Unit test for method unmute of class Register
def test_Register_unmute():
    assert Register().unmute() == None

# Generated at 2022-06-22 00:05:02.538684
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        pass

    class RgbFg(RenderType):
        pass

    def _sgr(*args):
        return "\x1b[%dm" % args[0]

    def _rgb(*args):
        return "\x1b[38;2;%d;%d;%dm" % (args[0], args[1], args[2])

    r = Register()
    r.set_renderfunc(Sgr, _sgr)
    r.set_renderfunc(RgbFg, _rgb)
    r.black = Style(Sgr(30))
    r.rgb_black = Style(RgbFg(0, 0, 0))

    assert str(r.black) == "\x1b[30m"
    assert str(r.rgb_black)

# Generated at 2022-06-22 00:05:09.775662
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import (
        RgbBg,
        RgbFg,
        Sgr,
    )

    def eightbit(color: int) -> str:
        return "\x1b[38;5;{}m".format(color)

    fg = Register()
    fg.set_eightbit_call(RgbFg)
    fg.set_renderfunc(RgbFg, eightbit)

    fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(fg.orange, Style)
    assert isinstance(fg.orange, str)
    assert str(fg.orange) == "\x1b[38;5;202m\x1b[1m"
