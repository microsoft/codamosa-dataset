

# Generated at 2022-06-21 23:55:21.128989
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Setting up a simple test case.
    def renderfunc_sgr(n: int) -> str:
        return f"\x1b[{n}m"

    def renderfunc_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    # Creating a new register-object.
    register = Register()

    # Setting render functions for Sgr and Rgb render-types.
    register.set_renderfunc(Sgr, renderfunc_sgr)
    register.set_renderfunc(RgbFg, renderfunc_rgb)

    # Creating a style using the newly defined render functions.
    style = Style(Sgr(1), RgbFg(1, 2, 3))

    # Test if

# Generated at 2022-06-21 23:55:23.707053
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    register = r()
    assert register == "", "Register should return empty string"



# Generated at 2022-06-21 23:55:27.949684
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg = Register()

    reg.red = "red"
    reg.blue = "blue"
    reg.green = "green"
    reg.yellow = "yellow"

    NamedTest = reg.as_namedtuple()
    assert NamedTest.red == "red"
    assert NamedTest.yellow == "yellow"


# Generated at 2022-06-21 23:55:30.793486
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sty import fg
    DummyTuple = fg.as_namedtuple()
    assert DummyTuple.blue == '\x1b[38;5;4m'


# Generated at 2022-06-21 23:55:42.986088
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import rich
    import rich.text
    import stylist
    stylist.use("default")
    from stylist import bg
    from stylist import fg

    assert fg.red == rich.text.Text("\u001b[38;5;1m")._formatted_text

    fg_dict = fg.as_dict()

    assert isinstance(fg_dict, dict)
    assert fg_dict["red"] == rich.text.Text("\u001b[38;5;1m")._formatted_text
    assert fg_dict["black"] == rich.text.Text("\u001b[38;5;0m")._formatted_text

    assert bg.red == rich.text.Text("\u001b[48;5;1m")._formatted_text

    bg

# Generated at 2022-06-21 23:55:49.701220
# Unit test for method mute of class Register
def test_Register_mute():
    # Create test-register.
    class TestRegister(Register):
        pass

    # Register with one attribute.
    test_register = TestRegister()
    test_register.red = Style(value="\x1b[1m\x1b[31m")

    # Test that the string value of red is correct.
    assert test_register.red == "\x1b[1m\x1b[31m"

    # Mute the test-register.
    test_register.mute()

    # Test that the string value of red is now empty.
    assert test_register.red == ""

# Generated at 2022-06-21 23:56:01.366832
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import *
    fg = Register()
    fg.red = Style(SgrFg(1), SgrBold(1))
    fg.green = Style(SgrFg(2), SgrDim(1))
    fg.blue = Style(SgrFg(4), SgrItalic(1))
    fg.yellow = Style(SgrFgBg(3,3), SgrItalic(1))


# Generated at 2022-06-21 23:56:06.801752
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class MyRegister(Register):
        pass

    def render_type(r, g, b) -> str:
        return str((r, g, b))

    my_register = MyRegister()

    my_register.set_rgb_call(render_type)

    assert my_register(10, 30, 50) == "(10, 30, 50)"

# Generated at 2022-06-21 23:56:13.382329
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .render import SGR
    from .rendertype import Sgr

    # Create register with two styles
    fg = Register()
    fg.blue = Style(Sgr(38, 5, 26))
    fg.red = Style(Sgr(38, 5, 124))

    fg.set_renderfunc(Sgr, SGR)

    # Mute register and add a new style
    fg.mute()
    fg.black = Style(Sgr(38, 5, 0))

    # Try to unmute register
    fg.unmute()

    # Check that all three styles have a value
    assert isinstance(fg.blue, Style)
    assert isinstance(fg.red, Style)
    assert isinstance(fg.black, Style)

# Generated at 2022-06-21 23:56:22.368356
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):

        pass

    x = TestRegister()
    s = Style(RenderType())

    x.red = s

    assert isinstance(x.red, Style)
    assert isinstance(x.red, str)
    assert len(x.red) == 2

    def new_renderfunc(rendertype, *args):
        return f"<{rendertype.name}>"

    x.set_renderfunc(RenderType, new_renderfunc)

    assert isinstance(x.red, Style)
    assert isinstance(x.red, str)
    assert len(x.red) == 5
    assert x.red == "<RenderType>"

# Generated at 2022-06-21 23:56:37.350830
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    register = Register()

    class Test(RenderType):
        def __init__(self, *args):
            self.args = args

    register.set_rgb_call(Test)
    assert callable(register.rgb_call)
    assert register.rgb_call == register.renderfuncs[Test]



# Generated at 2022-06-21 23:56:46.620869
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import sty

    sty.fg.orange = Style(RenderType.RgbFg(1, 5, 10), RenderType.Sgr(1))
    sty.fg.blue = Style(RenderType.RgbFg(0, 0, 150), RenderType.Sgr(1))

    sty_color_register = sty.fg.as_namedtuple()

    assert sty_color_register.orange == '\x1b[38;2;1;5;10m\x1b[1m'
    assert sty_color_register.blue == '\x1b[38;2;0;0;150m\x1b[1m'

# Generated at 2022-06-21 23:56:57.799118
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RenderTypeA(RenderType):

        def __call__(*args) -> str:
            return "A"

    class RenderTypeB(RenderType):

        def __call__(*args) -> str:
            return "B"

    class Style_(Style):
        pass

    r1 = Style_(RenderTypeA())
    r2 = Style_(RenderTypeA())

    register = Register()
    register.renderfuncs.update({RenderTypeA: lambda x: "A"})
    register.rgba_red = r1

    assert str(r1) == str(r2)

    register.set_renderfunc(RenderTypeA, lambda x: "B")
    assert str(r1) == str(r2)

    register.set_renderfunc(RenderTypeB, lambda x: "B")
    assert str(r1)

# Generated at 2022-06-21 23:57:06.038666
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

        # Set up
        fg = Register()

        # Test if instance is properly updated with new renderfunc
        fg.set_rgb_call(RgbFg)
        assert fg.rgb_call(100, 100, 100) == fg(100, 100, 100)

        fg.set_rgb_call(AnsiFg)
        assert fg.rgb_call(100, 100, 100) != fg(100, 100, 100)

        # Clean up
        del fg



# Generated at 2022-06-21 23:57:09.436521
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    r = Register()

    r.red = Style()

    setattr(r, "blue", Style())

    assert hasattr(r, "red")
    assert hasattr(r, "blue")

# Generated at 2022-06-21 23:57:15.667022
# Unit test for method __new__ of class Style
def test_Style___new__():
    """Test for method __new__."""
    rule1 = Style()
    rule2 = Style(Sgr(1))
    rule3 = Style(Sgr(1), RgbFg(50, 100, 200))

    assert rule1.rules == tuple()
    assert rule2.rules == (Sgr(1),)
    assert rule3.rules == (Sgr(1), RgbFg(50, 100, 200))



# Generated at 2022-06-21 23:57:20.105736
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test the Register::set_rgb_call method.
    """
    from .sty import Sgr, RgbFg, fg, bg, ef

    assert str(fg.red) == "\x1b[31m"
    assert str(bg.red) == "\x1b[41m"

    assert str(fg.rgb(10, 20, 30)) == "\x1b[38;2;10;20;30m"
    assert str(bg.rgb(10, 20, 30)) == "\x1b[48;2;10;20;30m"
    assert str(ef.rgb(10, 20, 30)) == "\x1b[38;2;10;20;30m"

    fg.set_rgb_call(Sgr)
    bg.set_r

# Generated at 2022-06-21 23:57:27.947570
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Colors

    class MyRegister(Register):
        pass

    reg = MyRegister()
    reg.red = Style(Colors(1))
    reg.black = Style(Colors(0))
    reg.blue = Style(Colors(2))

    nt = reg.as_namedtuple()
    assert nt.red == "\x1b[31m"
    assert nt.black == "\x1b[30m"
    assert nt.blue == "\x1b[34m"


# Generated at 2022-06-21 23:57:39.614001
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class R1(RenderType):
        def __init__(self, code: int):
            self.code = code

        def __eq__(self, other):
            if isinstance(other, R1):
                return self.code == other.code
            else:
                return False

        def args(self) -> Tuple[int]:
            return (self.code,)

        def __repr__(self) -> str:
            return f"R1({self.code})"

        def renderfunc(self, *args: int) -> str:
            return f"R1({args[0]})"

    r1 = R1(1)
    r2 = R1(2)

    reg = Register()
    reg.set_renderfunc(R1, R1.renderfunc)

# Generated at 2022-06-21 23:57:49.342744
# Unit test for method unmute of class Register
def test_Register_unmute():

    from sty import Style as S, fg, bg, ef, rs

    fg.red = S(fg(255,0,0))
    fg.blue = S(fg(0,255,0), ef.underlined)
    bg.green = S(bg(0,255,0), ef.bold)

    assert fg.red == '\x1b[38;2;255;0;0m'
    assert fg.blue == '\x1b[38;2;0;255;0m\x1b[4m'
    assert bg.green == '\x1b[48;2;0;255;0m\x1b[1m'

    fg.mute()
    bg.mute()

    assert fg.red == ''
    assert fg

# Generated at 2022-06-21 23:58:06.421459
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertypes import RGB, SGR

    def render_sgr(*args, **kwargs):
        return "SGR"

    def render_rgb(*args, **kwargs):
        return "RGB"

    r = Register()
    r.set_renderfunc(SGR, render_sgr)
    r.set_renderfunc(RGB, render_rgb)
    r.__setattr__("test", Style(SGR(), RGB()))

    assert str(r.test) == "SGRRGB"

    r.set_rgb_call(SGR)

    assert r(1, 2, 3) == "SGR"
    assert r("test") == "SGR"

    r.set_rgb_call(RGB)
    assert r(1, 2, 3) == "RGB"

# Generated at 2022-06-21 23:58:13.904279
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Test Namedtuple-Name (This is strange. Test maybe location
    # is not right.
    assert Register().as_namedtuple().__class__.__name__ == "StyleRegister"

    # Test members
    assert hasattr(Register().as_namedtuple(), "fg25")

    # Test values.
    assert Register().as_namedtuple().fg25 == "\x1b[38;5;25m"


# Generated at 2022-06-21 23:58:20.895577
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.test = Style(RgbFg(1, 5, 2))
    assert r("test") == '\x1b[38;2;1;5;2m'
    assert r(1) == ''

    r.set_eightbit_call(RgbFg)
    r.test2 = Style(RgbFg(1, 5, 2))
    assert r("test2") == '\x1b[38;2;1;5;2m'
    assert r(1) == '\x1b[38;2;1;5;2m'

# Generated at 2022-06-21 23:58:26.693000
# Unit test for method copy of class Register
def test_Register_copy():

    r1 = Register()
    r1.set_renderfunc(RenderType, lambda r,g,b: "")

    r1.red = Style(RgbFg(1,2,3))
    r1.blue = Style(RgbBg(1,2,3))

    r2 = r1.copy()

    assert r2.red == r1.red
    assert r2.blue == r1.blue

# Generated at 2022-06-21 23:58:28.849516
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r2 = r1.copy()

    assert type(r1) == type(r2)
    assert r1.__dict__ == r2.__dict__

# Generated at 2022-06-21 23:58:37.195464
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Test Eightbit-call
    fg = Register()
    fg.yellow = Style(RgbFg(1,5,10))
    assert fg(42) == ""
    assert fg("yellow") == "\x1b[38;2;1;5;10m"
    fg.set_eightbit_call(RgbFg)
    assert fg(42) == "\x1b[38;2;1;5;10m"

    # Test RGB-call
    assert fg(10, 42, 255) == "\x1b[38;2;1;5;10m"
    fg.set_rgb_call(RgbFg)
    assert fg(10, 42, 255) == "\x1b[38;2;10;42;255m"
    fg.m

# Generated at 2022-06-21 23:58:44.863390
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .sgr import Sgr
    from .rgb_fg import RgbFg

    # Setup test case
    dummy_register = Register()
    dummy_register.test_style = Style("test", Sgr(0))

    # Mute dummy object
    dummy_register.mute()

    # Verify that renderfunc has changed
    assert dummy_register.test_style == ""

    # Unmute dummy object
    dummy_register.unmute()

    # Set new renderfunc
    dummy_register.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))

    # Verify that renderfunc has changed
    assert dummy_register.test_style == Style("test", Sgr(0), RgbFg(0, 0, 0))

# Generated at 2022-06-21 23:58:50.157874
# Unit test for method copy of class Register
def test_Register_copy():

    reg1 = Register()
    reg2 = reg1.copy()

    reg1. eightbit_call = lambda x: x

    reg1.rgb_call = lambda x, y, z: (x, y, z)

    reg1.renderfuncs = {str: lambda x: ("r", "r")}

    reg1.is_muted = True

    assert reg1 is not reg2
    assert reg1.eightbit_call is not reg2.eightbit_call
    assert reg1.rgb_call is not reg2.rgb_call
    assert reg1.renderfuncs is not reg2.renderfuncs
    assert reg1.is_muted is not reg2.is_muted


# Generated at 2022-06-21 23:58:56.843910
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertypes import Eightbit, Sgr

    r = Register()
    r.red = Style(Eightbit(124))
    r.mute()

    assert r.red is ""
    assert r.is_muted

    r.unmute()
    assert not r.is_muted
    assert r.red == Style(Eightbit(124)).value

    r.green = Style(Eightbit(124), Sgr(1))
    assert r.green is not None


# Generated at 2022-06-21 23:59:06.057895
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class StyleRule(RenderType):
        """
        Make a custom Rendertype
        """

        def __init__(self, x: int):
            self.args = (x,)

        def to_ansi(self, *args) -> str:
            return f"\x1b[{args[0]}m"

    r = Register()
    assert list(r.renderfuncs.keys()) == []

    # With no renderfuncs defined, exception is raised.
    try:
        r.set_renderfunc(StyleRule, lambda x: f"\x1b[{x}h")
    except KeyError:
        pass
    else:
        raise AssertionError("set_renderfunc should raise KeyError if there are no renderfuncs defined.")

    # Define renderfunc

# Generated at 2022-06-21 23:59:20.602643
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Create default style object.
    s = Register()


    # Add a style to the object.
    s.test_style = Style()


    # Test result
    assert s.as_dict() == {
        "test_style": ""
    }



# Generated at 2022-06-21 23:59:29.174502
# Unit test for method copy of class Register
def test_Register_copy():

    # NOTE: This test is important because if fails it leads to unexpected
    # behaviour. If a copy of a register is manipulated, the original register
    # is also manipulated.

    # Create new register instance.
    r = Register()

    # Set attribute of register.
    r.test = Style(value="test")

    # Copy register.
    r_copy = r.copy()

    # Manipulate original register.
    r.test = Style(value="test2")

    # Check if changes of original register appeared in copy.
    if r_copy.test != "test":
        raise RuntimeError("Method copy of class Register is broken.")


if __name__ == "__main__":

    test_Register_copy()

# Generated at 2022-06-21 23:59:34.650894
# Unit test for method __new__ of class Style
def test_Style___new__():
    c = Style(*list(map(lambda x: x * 2, range(5))))
    assert not isinstance(c, str)
    assert isinstance(c, Style)
    assert c.value == ""
    assert c.rules == tuple([x * 2 for x in range(5)])



# Generated at 2022-06-21 23:59:45.778570
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Sgr(RenderType):
        """
        This is just a dummy type to test the method.
        """
        args: NamedTuple
        render_type: str = "Sgr"

    sgr_call = lambda *args: f"{Sgr(*args)}", Sgr(*args)

    r = Register()

    # Add a dummy renderfunc.
    r.set_renderfunc(Sgr, sgr_call)

    # Change the renderfunc for eightbit-calls.
    r.set_eightbit_call(Sgr)

    # Check if the new renderfunc is used for eightbit calls.
    assert r(144) == "\x1b[38;5;144m"

    # Check if the old renderfunc is stil avaiable.

# Generated at 2022-06-21 23:59:54.702305
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .sgr import Sgr
    from .rgb import RgbFg

    renderer = Register()

    renderer.renderfuncs = {
        RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
        Sgr: lambda x: f"\x1b[{x}m",
    }

    renderer.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert renderer.red == "\x1b[38;2;255;0;0m\x1b[1m"

    sr: NamedTuple = renderer.as_namedtuple()

    assert sr.red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-21 23:59:58.064644
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()
    s = Style(value="\x1b[1m", rules=[])
    setattr(r, "asdf", s)
    s2 = r.asdf

    r2 = Register()
    r2 = r.copy()

    s3 = r2.asdf

    assert s is not s2
    assert s2 is not s3
    assert s == s2
    assert s2 == s3

# Generated at 2022-06-22 00:00:06.576205
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()

    # Initial callfunc is set to lambda-function
    assert r.rgb_call(1,2,3) == (1,2,3)

    @r.set_rgb_call
    def rgb_call(r:int, g:int, b:int) -> str:
        return str(r) + str(g) + str(b)

    # After function call, the callfunc is set to the testfunction
    a = r.rgb_call(3,2,1)

    assert a == "321"

# Generated at 2022-06-22 00:00:17.971482
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbBg, RgbFg

    # -- Setup --
    r = Register()
    r.some_style = Style(RgbFg(0, 0, 0))

    def new_rgb_bg(*args, **kwargs) -> str:
        #print("Args:", args, "kwargs", kwargs)
        return "\x1b[38;2;%d;%d;%dm" % args

    def new_rgb_fg(*args, **kwargs) -> str:
        #print("Args:", args, "kwargs", kwargs)
        return "\x1b[48;2;%d;%d;%dm" % args

    # -- Test --
    r.set_renderfunc(RgbFg, new_rgb_fg)

# Generated at 2022-06-22 00:00:28.085055
# Unit test for method mute of class Register
def test_Register_mute():
    """
    This test checks if mute() and unmute() methods of class Register work as intended.
    """

    reg = Register()
    reg.is_muted = False

    class SgrBold(RenderType):
        args = ()
        name = "Bold"

    reg.set_renderfunc(SgrBold, lambda *_: '\x1b[1m')
    reg.bold = Style(SgrBold())

    reg.mute()
    assert reg.is_muted is True
    assert len(str(reg.bold)) == 0

    reg.unmute()
    assert reg.is_muted is False
    assert str(reg.bold) == '\x1b[1m'

# Generated at 2022-06-22 00:00:35.502280
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.test1 = "test1"
    r.test2 = "test2"

    nt = r.as_namedtuple()

    # Test if str was converted to str(str).
    assert type(getattr(nt, 'test1')) == str
    assert type(getattr(nt, 'test2')) == str

    # Test if returned namedtuple has all expected values.
    assert getattr(nt, 'test1') == 'test1'
    assert getattr(nt, 'test2') == 'test2'
    try:
        getattr(nt, 'test3')
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-22 00:00:53.328214
# Unit test for method unmute of class Register
def test_Register_unmute():
    from . import enums, rendertype
    from .sty import Sty, StyError

    sty_obj = Sty(StyError("test"))

    sty_obj.fg.red = "foo"
    sty_obj.fg.green = "bar"
    sty_obj.fg.blue = "baz"

    sty_obj.mute()

    sty_obj.fg.red = sty_obj.fg("red")
    sty_obj.fg.green = sty_obj.fg("green")
    sty_obj.fg.blue = sty_obj.fg("blue")

    sty_obj.unmute()

    assert sty_obj.fg.red == "\x1b[38;2;255;0;0mfoo", "Expect ANSI sequence"

# Generated at 2022-06-22 00:01:02.421546
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    _register = Register()
    _register.red = Style(Sgr(1), RgbFg(254, 0, 0))
    _register.green = Style(Sgr(1), RgbFg(0, 254, 0))
    _namedtuple = _register.as_namedtuple()
    assert isinstance(_namedtuple, namedtuple)
    assert _namedtuple.red == "\x1b[38;2;254;0;0m\x1b[1m"
    assert _namedtuple.green == "\x1b[38;2;0;254;0m\x1b[1m"

# Generated at 2022-06-22 00:01:04.216341
# Unit test for constructor of class Register
def test_Register():  # type: ignore

    # Test init of register
    reg = Register()

    assert isinstance(reg, Register)


# Generated at 2022-06-22 00:01:09.116818
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register.
    """
    reg = Register()
    reg.test = Style("test")
    reg.test2 = Style("test2")

    reg2 = reg.copy()

    assert reg2.test == "test"
    assert reg2.test2 == "test2"

    reg.test = Style("spam")
    reg.test2 = Style("eggs")

    assert reg.test != reg2.test
    assert reg.test2 != reg2.test2

# Generated at 2022-06-22 00:01:15.464328
# Unit test for constructor of class Style
def test_Style():
    s = Style(fg(42), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert not isinstance(s, int)
    assert not isinstance(s, RenderType)
    assert str(s) == "\x1b[38;5;42m\x1b[1m"

# Generated at 2022-06-22 00:01:26.001524
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test function for method as_dict of class Register.
    """

# Generated at 2022-06-22 00:01:36.495284
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbBg, RgbFg, Sgr

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: str((r, g, b)))
    r.set_renderfunc(RgbBg, lambda r, g, b: str((r, g, b)))
    r.set_rgb_call(RgbBg)

    black = Style(RgbBg(0, 0, 0))
    red = Style(RgbBg(255, 0, 0))

    r.black = black
    r.red = red

    assert r(0, 0, 0) == r.black
    assert r(255, 0, 0) == r.red
    assert r("black") == r.black
    assert r("red") == r.red



# Generated at 2022-06-22 00:01:46.861996
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, EightBitFg, Sgr

    styles = Register()
    styles.set_renderfunc(EightBitFg, lambda x: "".join(["EIGHTBIT", str(x)]))
    styles.set_renderfunc(RgbFg, lambda r, g, b: "".join(["RGB", str(r), str(g), str(b)]))
    styles.set_renderfunc(Sgr, lambda x: "".join(["SGR", str(x)]))

    style_name = "test_style"

    styles.test_style = Style(EightBitFg(42), Sgr(8), value="")
    init_value = str(getattr(styles, style_name))
    assert init_value == ""


# Generated at 2022-06-22 00:01:55.668345
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class A(RenderType):
        pass

    class B(RenderType):
        pass

    class C(RenderType):
        pass

    def f1(*args):
        return "1"

    def f2(*args):
        return "2"

    def f3(*args):
        return "3"

    r = Register()
    r.set_renderfunc(A, f1)
    r.set_renderfunc(B, f2)
    r.set_renderfunc(C, f3)

    r.a = Style(A(1))
    r.b = Style(B(2, 3))
    r.c = Style(Style(C(4), C(5)))

    assert str(r.a) == "1"
    assert str(r.b) == "23"

# Generated at 2022-06-22 00:01:57.197722
# Unit test for constructor of class Register
def test_Register():

    rg = Register()
    assert isinstance(rg, Register)


# The following code is used in unit tests.

# Generated at 2022-06-22 00:02:18.228677
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg

    def f1(x):
        return "\x1b[48;2;" + str(x) + "m"

    reg = Register()
    reg.set_renderfunc(RgbFg, f1)
    assert str(reg.red) == "\x1b[38;2;255;0;0m"

    def f2(x):
        return "\x1b[48;2;" + str(x) + "m "

    reg.set_renderfunc(RgbFg, f2)
    assert str(reg.red) == "\x1b[38;2;255;0;0m "

    reg.two_tone.red = reg.red, reg.black

# Generated at 2022-06-22 00:02:24.714879
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, RgbBg

    r = Register()
    r.set_renderfunc(RgbFg, lambda x: "1")
    r.set_renderfunc(RgbBg, lambda x: "2")
    r.set_eightbit_call(RgbFg)
    assert r(144) == "1"

    r.set_eightbit_call(RgbBg)
    assert r(144) == "2"



# Generated at 2022-06-22 00:02:32.402175
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .ansi import RgbBg, RgbFg, Sgr
    from .types import Rgb

    def _f(index, *args):
        return str(RgbBg(0, index, 0)) + str(RgbFg(0, index, 0)) + str(Sgr(index))

    color = Register()
    setattr(color, "green", Rgb)

    for i in range(1, 255):
        color.set_renderfunc(RgbFg, lambda *args: _f(i))
        assert color(i) == str(RgbBg(0, i, 0)) + str(RgbFg(0, i, 0)) + str(Sgr(i))

    assert color("green") == str(Rgb)



# Generated at 2022-06-22 00:02:43.434453
# Unit test for method __new__ of class Style
def test_Style___new__():

    # We define three different registers to use. Each register has an eight-bit and a rgb render-function.

    StyleRegister = namedtuple("StyleRegister", "name eightbit rgb")

# Generated at 2022-06-22 00:02:54.194620
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """Test the method as_namedtuple of the class Register"""

    from . import fg, ef, create_style

    create_style("red", fg=166)

    class DummyRegister(Register):

        blue = Style(fg.blue)
        green = Style(fg.green)
        red = Style(fg.red)
        bold = Style(ef.bold)
        underline = Style(ef.underline)

        def set_renderfuncs(self):
            from . import fg, ef, Sgr
            self.renderfuncs[Sgr] = lambda *args: f"[SGR-{args[0]}]"
            self.renderfuncs[fg.foreground] = lambda *args: f"[fg-{args[0]}]"

# Generated at 2022-06-22 00:03:04.720354
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from . import fg

    # Create namedtuple
    namedtuple = fg.as_namedtuple()

    # Access items of namedtuple
    for name in dir(fg):

        if not name.startswith("_") and isinstance(getattr(fg, name), str):

            style = getattr(fg, name)
            assert style == getattr(namedtuple, name)

    # Test updating values
    fg.darkred = fg.darkgreen
    namedtuple = fg.as_namedtuple()
    assert fg.darkred == fg.darkgreen
    assert getattr(namedtuple, "darkred") == getattr(namedtuple, "darkgreen")

# Generated at 2022-06-22 00:03:07.969210
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert Style().rules == ()
    assert Style(value="").rules == ()
    assert Style(value="", *(1, 2)).rules == (1, 2)

    assert Style(1).rules == (1,)
    assert Style(1, 2, 3).rules == (1, 2, 3)

# Generated at 2022-06-22 00:03:19.825319
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbBg
    reg = Register()
    reg.set_eightbit_call(RgbBg)
    reg.set_rgb_call(RgbBg)
    reg.red = Style(RgbBg(255, 0, 0))
    reg.cyan = Style(RgbBg(0, 255, 255))
    reg.black = Style(RgbBg(0, 0, 0))
    reg.unmute()
    reg2 = reg.copy()
    reg2.green = Style(RgbBg(0, 255, 0))
    assert reg.green is not reg2.green
    assert reg.green == reg.black
    assert reg2.green != reg2.black
    assert reg2.green != reg2.cyan

# Generated at 2022-06-22 00:03:27.205193
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register = Register()
    renderfuncs = {"Type1": lambda: None, "Type2": lambda: None}
    register.renderfuncs = renderfuncs
    rule = RenderType("Type1")
    style = Style(rule)
    register.z = style
    register.set_renderfunc(rule.__class__, renderfunc2)
    assert register.z == ""
    register.unmute()
    assert register.z == "I'm type 2"


# Mock renderfunc for unit test

# Generated at 2022-06-22 00:03:35.899287
# Unit test for method copy of class Register
def test_Register_copy():

    register: Register = Register()
    register.set_renderfunc(RenderType, lambda *args: f"\x1b[{args[0]}m")

    register.color_a = Style(RenderType(30))
    register.color_b = Style(RenderType(31))

    register.color_c = Style(register.color_a, register.color_b)

    register.color_d = Style(register.color_c, register.color_b)

    register.color_x = Style(register.color_a, register.color_b)

    register.color_y = Style(register.color_x, register.color_b)

    copy1 = register.copy()
    copy2 = register.copy()

    assert copy1.color_x == register.color_x
    assert copy1.color_y == register

# Generated at 2022-06-22 00:04:04.898205
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def f1(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    def f2(x: int, y: int) -> str:
        return f"\x1b[{x};{y}m"

    r1 = Register()

    r1.renderfuncs.update({RgbFg: f1, Sgr: f2})

    r1.red = Style(RgbFg(1), Sgr(1))

    # r1.red is a Style-object.
    assert isinstance(r1.red, Style)

    # r1.red is a Style-object.
    assert isinstance(r1.red, str)

   

# Generated at 2022-06-22 00:04:10.948193
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRenderType(RenderType):
        def __init__(self):
            self.args = ("1",)

    # create dict with render-functions
    renderfuncs: Renderfuncs = {
        TestRenderType: lambda x: f"\x1b[{x}m"
    }

    r = Register()

    # Test: Add render-func to register
    r.set_renderfunc(TestRenderType, renderfuncs[TestRenderType])

    # Test: Add style attr to register object
    r.red = Style(TestRenderType(), value="\x1b[1m")

    # Test: render attr
    assert str(r.red) == "\x1b[1m"

    # Test: mute style
    r.mute()
    assert str(r.red) == ""

    #

# Generated at 2022-06-22 00:04:21.130749
# Unit test for method mute of class Register
def test_Register_mute():

    # Create a test class which inherits Register
    class FakeRegister(Register):
        pass

    # Mock a register object
    test_reg = FakeRegister()

    # Set a style value and a normal value
    test_reg.test_style = Style(RgbFg(1, 2, 3))
    test_reg.test_value = "test_value"

    test_reg.mute()

    # Check if values are empty
    assert getattr(test_reg, "test_style") == ""
    assert getattr(test_reg, "test_value") == "test_value"

    # Check if unmute does work
    test_reg.unmute()
    assert getattr(test_reg, "test_style") != ""

# Generated at 2022-06-22 00:04:24.400415
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Create a temporary Register class that uses the style-attribute 'this'.
    class TempReg(Register):
        this = Style(Sgr(1))

    temp1 = TempReg()
    temp1.mute()
    temp1.unmute()

    assert not temp1.is_muted
    assert str(temp1.this) == "\x1b[1m"

# Generated at 2022-06-22 00:04:34.803112
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import Sgr, RgbFg
    from .constants import COLORS_8

    def sgr_func(code: int) -> str:
        return Sgr(code).render()

    def rgb_func(r: int, g: int, b: int) -> str:
        return RgbFg(r, g, b).render()

    r = Register()
    r.set_renderfunc(Sgr, sgr_func)
    r.set_renderfunc(RgbFg, rgb_func)

    r.set_eightbit_call(RgbFg)

    r.set_rgb_call(RgbFg)

    r.red = Style(RgbFg(255, 0, 0))

    assert isinstance(r.red, Style)


# Generated at 2022-06-22 00:04:42.741251
# Unit test for method unmute of class Register
def test_Register_unmute():
    a = Register()
    a.set_eightbit_call(RenderType.sgr)
    a.set_rgb_call(RenderType.sgr)
    a.black = Style(RenderType.sgr(30))
    a.black = Style(RenderType.sgr(30), RenderType.sgr(1))

    a.mute()
    assert a.black == ""
    a.unmute()
    assert a.black != ""



# Generated at 2022-06-22 00:04:44.122161
# Unit test for constructor of class Register
def test_Register():

    # Create a register object.
    r = Register()


# Generated at 2022-06-22 00:04:53.812526
# Unit test for method copy of class Register
def test_Register_copy():
    # New register with custom rules
    _register = Register()
    _register.bold = Style(Sgr(1))
    _register.new_color = Style(Sgr(38, 2, 200, 100, 40))

    # Make a deepcopy
    register = _register.copy()

    # Check if deepcopy is an instance of Register
    assert isinstance(register, Register)

    # Check if deepcopy has the same attributes as original.
    for attr_name in dir(_register):
        assert hasattr(register, attr_name)

    # Values should be different, but attributes should be equal.
    assert _register.bold != register.bold
    assert _register.bold.rules == register.bold.rules

    assert _register.new_color != register.new_color
    assert _register.new_color.rules == register.new

# Generated at 2022-06-22 00:05:05.668104
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .colors import fg, bg, ef, rs
    Sty = (fg + bg + ef + rs).as_namedtuple()

    assert type(Sty.red) is str, "Wrong type for Sty.red"
    assert Sty.red == '\x1b[38;2;255;0;0m', "Wrong ANSI sequence for Sty.red"

    assert type(Sty.bg_red) is str, "Wrong type for Sty.bg_red"
    assert Sty.bg_red == '\x1b[48;2;255;0;0m', "Wrong ANSI sequence for Sty.bg_red"

    assert type(Sty.red_bg_blue) is str, "Wrong type for Sty.red_bg_blue"