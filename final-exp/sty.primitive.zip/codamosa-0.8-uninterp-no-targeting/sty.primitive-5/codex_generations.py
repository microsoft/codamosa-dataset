

# Generated at 2022-06-21 23:55:28.037997
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class NewRenderType(RenderType):
        def __init__(self, **kwargs):
            self.args = list(kwargs.values())

    def new_render_func(self, test_value):
        return f"[{test_value}]"

    register = Register()
    register.set_renderfunc(NewRenderType, new_render_func)

    new_style = Style(NewRenderType(test_value="foo"))
    register.new_style = new_style

    assert str(register.new_style) == "[foo]"

# Generated at 2022-06-21 23:55:39.900546
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Example: Create a new register, add a single style attribute, convert
    # register to dict and check wheter the attribute is properly stored in the
    # dict.
    reg = Register()
    reg.foo = Style("\x1b[38;2;1;2;3m")
    d = reg.as_dict()
    assert d == {"foo": "\x1b[38;2;1;2;3m"}

    # Example2: Create a new register, add a single style attribute, convert
    # register to dict and check wheter the attribute is properly stored in the
    # dict.
    reg = Register()
    reg.bar = Style("\x1b[38;2;1;2;3m")
    d = reg.as_dict()

# Generated at 2022-06-21 23:55:48.661836
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .style import fg, bg

    assert fg.red.as_dict() == {"red": "\x1b[31m"}
    assert bg.red.as_dict() == {"red": "\x1b[41m"}

    assert fg.white.as_dict() == {"white": "\x1b[97m"}

    assert bg.white.as_dict() == {"white": "\x1b[107m"}

    assert fg.white_on_red.as_dict() == {"white_on_red": "\x1b[37;41m"}

    assert bg.white_on_red.as_dict() == {"white_on_red": "\x1b[97;41m"}

# Generated at 2022-06-21 23:55:56.145587
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(1, 5, 10), Sgr(1)), str)
    assert str(Style(RgbFg(1, 5, 10), Sgr(1))) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-21 23:56:03.995011
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    The method unmute of class Register usually is called for all default registers
    when a Sty object is instantiated.
    """
    from .default_palette import bg, fg, ef, rs, tmux_fg, tmux_bg

    # Check if muting and unmuting works
    fg.mute()
    assert fg.is_muted == True

    fg.unmute()
    assert fg.is_muted == False

    # Check if colors got unmuted correctly
    assert fg.blue == fg("blue")

    # Check if colors got muted correctly
    fg.mute()
    assert fg.blue == ""

    # Check if all colors of all registers are unmuted
    fg.mute()
    rs.mute()
    bg.mute()

# Generated at 2022-06-21 23:56:09.796271
# Unit test for method copy of class Register
def test_Register_copy():
    # set up
    from sty import fg
    from sty import rs

    fg.red = Style(fg.red)
    reg_fg = fg.copy()

    reg_fg.red = Style(fg.blue)

    # test
    assert(reg_fg.red == rs.blue)
    assert(fg.red == rs.red)



# Generated at 2022-06-21 23:56:11.786487
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)
    assert reg.is_muted == False
    assert reg.renderfuncs == {}



# Generated at 2022-06-21 23:56:23.180387
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register()

    class RgbFg(RenderType):
        pass

    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.set_rgb_call(RgbFg)

    reg.blue_10 = Style(RgbFg(0, 0, 255), value="\x1b[38;2;0;0;255m")

    reg2 = reg.copy()
    assert reg2.blue_10 == reg.blue_10

    # Change attr of reg
    reg.blue_10 = Style(RgbFg(255, 255, 255), value="\x1b[38;2;255;255;255m")

    # Attr should now be different
   

# Generated at 2022-06-21 23:56:26.125360
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from sty import fg

    my_fg_register = fg()
    my_fg_register.my_color = "test"

    assert my_fg_register.as_dict() == {"my_color": "\x1b[39mtest"}



# Generated at 2022-06-21 23:56:31.826158
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Test whether the as_namedtuple()-method of class Register returns a namedtuple
    # with correct attributes.
    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0))

    nt = reg.as_namedtuple()

    assert nt.red == "\x1b[38;2;255;0;0m"
    assert len(nt._fields) == 1

# Generated at 2022-06-21 23:56:47.710121
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .core import fg, bg, ef, rs

    assert fg.black is fg.black
    assert fg.black is not fg.red
    assert fg.black is not bg.black
    assert fg.black is not ef.black
    assert fg.black is not rs.black

    rs.red = Style(rs.red)

    fg.set_renderfunc(rs.red.rules[0].__class__, lambda x: f"{x}me")
    fg.set_renderfunc(bg.red.rules[0].__class__, lambda x: f"other{x}")

    assert fg.black is not fg.red
    assert fg.black is not bg.black
    assert fg.black is not ef.black

# Generated at 2022-06-21 23:56:58.491257
# Unit test for method mute of class Register
def test_Register_mute():
    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int) -> None:
            self.args = (r, g, b)

        def __str__(self):
            return f"\x1b[38;2;{self.args[0]};{self.args[1]};{self.args[2]}m"

    rfg = RgbFg(255, 100, 0)
    sgr = RenderType(Sgr(1))

    def rgb_fg_factory(r, g, b):
        return RgbFg(r, g, b)

    def sgr_factory(arg):
        return RenderType(Sgr(arg))

    my_reg = Register()


# Generated at 2022-06-21 23:57:06.278758
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()
    r.test = Style(RgbBg(255, 255, 255), Sgr(1, 2, 3))
    rr = r.copy()

    assert isinstance(r, Register)
    assert isinstance(rr, Register)
    assert r.test == '\x1b[48;2;255;255;255m\x1b[1;2;3m'
    assert rr.test == '\x1b[48;2;255;255;255m\x1b[1;2;3m'

# Generated at 2022-06-21 23:57:17.316779
# Unit test for constructor of class Register
def test_Register():
    from . import ansi
    from .color import register
    from .rendertype import EightBit, ExtendedFg, RgbBg

    assert isinstance(register.fg, Register)
    assert isinstance(register.rgb_style, Register)

    register.rgb_style.set_renderfunc(RgbBg, ansi.rgb_bg)
    register.rgb_style.set_rgb_call(RgbBg)

    tmp = register.rgb_style(1,1,1)
    assert isinstance(tmp, str)
    assert tmp == "\x1b[48;2;1;1;1m"

    register.rgb_style.set_eightbit_call(EightBit)
    register.rgb_style.set_renderfunc(EightBit, ansi.eight_bg)

   

# Generated at 2022-06-21 23:57:20.144376
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class MyRenderType(RenderType):
        pass

    # Create register object
    r = Register()

    # Set renderfunc for MyRenderType
    r.set_renderfunc(MyRenderType, lambda x: "MyRenderType")

    # Set the call for 8bit color codes
    r.set_eightbit_call(MyRenderType)

    # Test if renderfunc maped correctly
    assert r.eightbit_call(42) == "MyRenderType"



# Generated at 2022-06-21 23:57:25.178142
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .color import Color
    from .rendertype import RgbBg
    from .rendertype import Sgr

    c = Color()

    c.fg.rgb_call = RgbBg

    assert c.fg(42, 43, 44) == "\x1b[48;2;42;43;44m"

# Generated at 2022-06-21 23:57:27.518226
# Unit test for method __new__ of class Style
def test_Style___new__():
    r: Style = Style(1, 2, value="")
    assert r.value == ""
    assert r.rules == (1, 2)

# Generated at 2022-06-21 23:57:36.676485
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.blue = Style(RgbFg(0, 0, 255))
    fg.green = Style(RgbFg(0, 255, 0))

    NT = fg.as_namedtuple()
    assert NT.red == '\x1b[38;2;255;0;0m'
    assert NT.blue == '\x1b[38;2;0;0;255m'
    assert NT.green == '\x1b[38;2;0;255;0m'

# Generated at 2022-06-21 23:57:47.339723
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, Sgr

    def rgb_fg(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;%i;%i;%im" % (r, g, b)

    def sgr(arg: int) -> str:
        return "\x1b[%im" % arg

    class MyRegister(Register):
        pass

    mr = MyRegister()

    mr.red = Style(RgbFg(255, 0, 0), Sgr(1))
    mr.screen = Style(RgbFg(0, 0, 0), Sgr(2))

    mr.set_renderfunc(RgbFg, rgb_fg)
    mr.set_renderfunc(Sgr, sgr)

    assert mr

# Generated at 2022-06-21 23:57:58.373853
# Unit test for method mute of class Register
def test_Register_mute():
    class RgbEf(RenderType):
        args = ("r", "g", "b")

    class Ef(RenderType):
        pass

    class RgbFg(RenderType):
        args = ("r", "g", "b")

    class Fg(RenderType):
        pass

    class RgbBg(RenderType):
        args = ("r", "g", "b")

    class Bg(RenderType):
        pass

    class Rs(RenderType):
        pass

    r = Register()

    r.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))
    r.set_renderfunc(Fg, lambda x: x)
    r.set_renderfunc(RgbEf, lambda x: x)

# Generated at 2022-06-21 23:58:11.060186
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import EightBit, RgbFg, Sgr

    fg_red = Style(Sgr(1), EightBit(31))

    reg: Register = Register()
    reg.set_renderfunc(EightBit, lambda x: "")
    reg.set_renderfunc(RgbFg, lambda x, y, z: "")

    reg.x = fg_red
    reg.y = fg_red
    reg.z = fg_red

    print(reg.x)
    print(reg.y)
    print(reg.z)



# Generated at 2022-06-21 23:58:16.859085
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        args: Iterable[int]

    def render_func(*args):
        return "Test"

    test_register = Register()

    test_register.set_renderfunc(TestRenderType, render_func)

    test_register.set_eightbit_call(TestRenderType)

    assert test_register(42) == "Test"



# Generated at 2022-06-21 23:58:22.362275
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .ansi import RgbFg, Sgr, Register, fg
    fg.test = Style(RgbFg(1, 2, 3), Sgr(1))

    fg.mute()
    assert fg.test == ""

    fg.unmute()
    assert fg.test == "\x1b[38;2;1;2;3m\x1b[1m"

    del fg.test
    fg.unmute()  # should not raise an error

# Generated at 2022-06-21 23:58:32.990855
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Unit test for method set_renderfunc of class Register
    """

    global test_renderfunc_counter
    test_renderfunc_counter: int = 0

    def new_renderfunc(x, y, z):
        global test_renderfunc_counter
        test_renderfunc_counter += 1
        return f"{x}{y}{z}"

    from .rendertype import RgbBg

    # Create a new Register object
    r = Register()

    # No renderfunc for RgbBg should be set.
    if type(RgbBg) in r.renderfuncs:
        raise AssertionError("Unexpected renderfunc at RgbBg")

    # Set the renderfunc
    r.set_renderfunc(RgbBg, new_renderfunc)

    # Check if renderfunc was set

# Generated at 2022-06-21 23:58:36.647677
# Unit test for constructor of class Style
def test_Style():
    """
    >>> Style(1, value="\x1b[1m")
    Style(1, value='\x1b[1m')

    >>> Style(1, value=2)
    Traceback (most recent call last):
        ...
    ValueError: Parameter 'value' must be of type str.
    """
    ...



# Generated at 2022-06-21 23:58:40.002565
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.purple = Style(RgbFg(1, 5, 10))
    r.green = Style(RgbFg(2, 6, 11))
    r2 = r.copy()

    assert r.purple.rules == r2.purple.rules
    assert r.green.rules == r2.green.rules

# Generated at 2022-06-21 23:58:43.986553
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .fg import fg
    from .bg import bg
    from .ef import ef
    from .rs import rs

    assert isinstance(fg.as_namedtuple(), NamedTuple)
    assert isinstance(bg.as_namedtuple(), NamedTuple)
    assert isinstance(ef.as_namedtuple(), NamedTuple)
    assert isinstance(rs.as_namedtuple(), NamedTuple)

# Generated at 2022-06-21 23:58:50.159812
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test method set_rgb_call().
    """
    from ..render import RgbFg, Sgr

    mock_func_1 = lambda x: f"{x}"
    mock_func_2 = lambda r, g, b: f"{r},{g},{b}"

    r = Register()
    r.set_renderfunc(RgbFg, mock_func_1)
    r.set_renderfunc(Sgr, mock_func_2)

    r.set_rgb_call(RgbFg)

    assert r(100, 10, 0) == "100"
    assert r(255, 0, 255) == "255"

    r.set_rgb_call(Sgr)

    assert r(100, 10, 0) == "100,10,0"

# Generated at 2022-06-21 23:59:00.086119
# Unit test for method copy of class Register
def test_Register_copy():
    """
    This is the unittest for the method copy of class Register. Make sure that
    this test is executed before any register attributes are set.
    """
    r1 = Register()
    r2 = r1.copy()

    assert r1 is not r2, "Method Register.copy does not return a new object."

    r1.test = Style(value="test")
    assert hasattr(r1, "test"), "Failed to add new attribute to register object."
    assert not hasattr(r2, "test"), "Failed to copy register object."

    r2.test = Style(value="test")
    assert getattr(r1, "test") == getattr(r2, "test"), "Failed to change value of copied register object."

    r1.set_eightbit_call(None)
    r2.test

# Generated at 2022-06-21 23:59:00.894516
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r

# Generated at 2022-06-21 23:59:16.194964
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if muted and unmuted register-objects are equal to their original.
    """
    from sty.fg import fg
    from sty.rs import rs
    from sty.rendertype import RgbFg, Reset
    from sty.style import Style

    # Make a backup of original register and styles.
    fg_bkp = fg
    red_bkp = fg.red
    rs_bkp = rs
    rs_reset_bkp = rs.reset

    # Create muted register-objects.
    fg_muted = fg.copy()
    fg_muted.mute()

    rs_muted = rs.copy()
    rs_muted.mute()

    # Test that there is no difference in styles between original and muted
    # register-object.

# Generated at 2022-06-21 23:59:26.605580
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .parsetpl import RgbBg, RgbFg, Sgr

    s0 = Style(RgbFg(1, 2, 3), Sgr(1), RgbBg(4, 5, 6))

    assert isinstance(s0, Style)
    assert isinstance(s0, str)
    assert s0.rules == (RgbFg(1, 2, 3), Sgr(1), RgbBg(4, 5, 6))
    assert str(s0) == "\x1b[38;2;1;2;3m\x1b[1m\x1b[48;2;4;5;6m"

    s1 = Style(s0, Sgr(0))

    assert isinstance(s1, Style)
    assert isinstance(s1, str)

# Generated at 2022-06-21 23:59:30.390928
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Test if method as_dict works.
    r = Register()
    r.test = Style()
    r.test2 = Style()
    r.as_dict()

    assert r.as_dict() == {'test': '', 'test2': ''}

# Generated at 2022-06-21 23:59:39.534452
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertypes import RgbFg, Sgr
    r = Register()
    r.renderfuncs = {}

    r.red = Style(RgbFg(255, 0, 0))

    assert r.red == "\x1b[38;2;255;0;0m"

    r.bold = Style(Sgr(1))

    assert r.bold == "\x1b[1m"

    r.boldred = Style(Sgr(1), r.red)

    assert r.boldred == "\x1b[1m\x1b[38;2;255;0;0m"

    r.new = r.boldred

    assert r.new == r.boldred

# Generated at 2022-06-21 23:59:45.529494
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    renderfuncs = {"a": lambda x: x}
    r = Register()
    r.renderfuncs = renderfuncs
    r.set_eightbit_call("a")
    assert r.eightbit_call == renderfuncs["a"]
    assert r.rgb_call == renderfuncs["a"]



# Generated at 2022-06-21 23:59:54.465657
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import pytest

    def as_dict_test(register):
        d = register.as_dict()
        assert isinstance(d, dict)
        for name, value in d.items():
            assert isinstance(name, str)
            assert isinstance(value, str)
            assert name in dir(register)
            assert value == str(getattr(register, name))
        assert set(dir(register)) - set(d.keys()) == set(["as_dict", "as_namedtuple", "copy"])

    # Test main register classes
    from sty import fg
    from sty import bg
    from sty import ef
    from sty import rs

    for register_class in [fg, bg, ef, rs]:
        register = register_class()
        as_dict_test(register)

    # Test Register

# Generated at 2022-06-21 23:59:59.583314
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .ansi import Bg, Rs, Sgr

    # Create sample register object
    class r(Register):
        pass

    r.renderfuncs.update({Bg: lambda *args: "".join([str(a) for a in args]),
                          Sgr: lambda *args: "".join([str(a) for a in args]),
                          Rs: lambda: "0"})

    # Define background color red
    s = Style(Bg(1, 0, 0), Sgr(1))
    assert s == "\x1b[48;2;1;0;0m\x1b[1m"

    # Test attribute setting
    r.red = s
    assert r.red == "\x1b[48;2;1;0;0m\x1b[1m"

# Generated at 2022-06-22 00:00:10.204213
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define a new render func for no render type.
    def f(x: int) -> str:
        return "f_{}".format(str(x))

    # Create register-object.
    r1 = Register()

    # Set render func.
    r1.set_renderfunc(RenderType.NO_RENDER, f)

    # Set render func.
    r1.set_renderfunc(RenderType.NO_RENDER, lambda x: "")

    class T1(RenderType):
        pass

    # Set render func.
    r1.set_renderfunc(T1, lambda x: "")

    class T2(RenderType):
        pass

    # Set render func.
    r1.set_renderfunc(T2, lambda x: "")

    # Define style with render type T1.

# Generated at 2022-06-22 00:00:17.971693
# Unit test for method __new__ of class Style
def test_Style___new__():

    class FakeRenderType1:
        pass

    class FakeRenderType2:
        pass

    FakeRenderType1.args = (1, 2, 3)
    FakeRenderType2.args = (42, None, 43)

    rules = [FakeRenderType1, FakeRenderType2, "Spam"]

    style = Style(*rules)

    assert style == "1, 2, 3, 42, None, 43"
    assert style.rules == rules



# Generated at 2022-06-22 00:00:29.638743
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class A:
        pass

    class B:
        pass

    class C:
        pass

    r = Register()
    r.set_renderfunc(A, lambda x: f"<{x}>")
    r.set_renderfunc(B, lambda x, y: f"<{x}/{y}>")
    r.set_renderfunc(C, lambda x, y, z: f"<{x}/{y}/{z}>")

    assert r.eightbit_call(A(), 42) == "<42>"
    assert r.rgb_call(A(), 42, 54, 87) == "<42/54/87>"

    r.set_eightbit_call(A)
    assert r.__call__(42) == "<42>"

    r.set_rgb_call(A)


# Generated at 2022-06-22 00:00:44.968132
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg, Sgr

    register = Register()

    register.black = Style(RgbFg(0,0,0), Sgr(1))
    register.red = Style(RgbFg(255,0,0), Sgr(1))
    register.green = Style(RgbFg(0,255,0), Sgr(1))
    register.blue = Style(RgbFg(0,0,255), Sgr(1))

    assert str(register.black) == "\x1b[38;2;0;0;0m\x1b[1m"
    assert str(register.red) == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-22 00:00:50.932489
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    import sty

    fg = sty.fg
    EightBit = sty.sgr.EightBit
    RgbFg = sty.rgb.RgbFg

    # Set register fg to a non-standard 8Bit render-type.
    fg.set_eightbit_call(EightBit)
    assert fg(144) == "\033[38;5;144m"

    # Set register fg to a non-standard RGB render-type.
    fg.set_rgb_call(RgbFg)
    assert fg(144, 153, 10) == "\033[38;2;144;153;10m"

# Generated at 2022-06-22 00:00:53.402501
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(), Style)
    assert isinstance(Style("foo"), Style)
    assert isinstance(Style("foo", "bar"), Style)
    assert isinstance(Style(1, 2, 3), Style)



# Generated at 2022-06-22 00:00:58.844996
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r1 = Register()

    r1.test = Style(RenderType(), RenderType())

    assert r1.test == '\x1b[0m\x1b[0m'

    assert r1.as_dict() == {"test": '\x1b[0m\x1b[0m'}



# Generated at 2022-06-22 00:01:06.139090
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .render import render_function
    from .rendertype import ColorFg, ColorBg

    r = Register()
    r.renderfuncs.update({ColorFg: render_function})

    r.test = Style(ColorFg(10))

    assert str(r.test) == "\x1b[38;5;10m"

    r.set_renderfunc(ColorFg, lambda fg: f"\x1b[38;2;{fg};{fg + 1};{fg + 4}m")

    assert str(r.test) == "\x1b[38;2;10;11;14m"



# Generated at 2022-06-22 00:01:09.816521
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Test if set_rgb_call changes rgb_call correctly
    import sty
    r = Register()
    r.set_rgb_call(sty.RgbBg)
    assert r.rgb_call == sty.RgbBg


# Generated at 2022-06-22 00:01:21.788888
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import RgbFg, Sgr
    from .registers import fg, style

    s = Style(RgbFg(1, 50, 100), Sgr(1))
    assert isinstance(s, Style)
    assert s.rules == (RgbFg(1, 50, 100), Sgr(1))

    g = fg.green
    assert isinstance(g, Style)
    assert g.rules == (fg.rendertype, RgbFg(0, 255, 0))

    c1 = style.custom1
    assert isinstance(c1, Style)
    assert c1.rules == (style.rendertype, Sgr(1), fg.rendertype, RgbFg(255, 0, 0))



# Generated at 2022-06-22 00:01:32.073344
# Unit test for method __call__ of class Register
def test_Register___call__():
    import pytest

    class Fg(Register):
        pass

    fg = Fg()

    # Test direct call.
    return_value = fg(8)
    assert return_value is None

    # Test calls on style-attributes.
    assert isinstance(fg.red, str)
    assert isinstance(fg.green, str)
    assert isinstance(fg.blue, str)
    assert fg.red == fg("red")
    assert fg.green == fg("green")
    assert fg.blue == fg("blue")
    assert fg.red != fg.blue

    # Test inputs.
    with pytest.raises(AttributeError):
        fg("nonsense")
    with pytest.raises(TypeError):
        fg(1, 1)

# Generated at 2022-06-22 00:01:41.879826
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Sgr, Fg256, Bg256

    r = Register()
    r.renderfuncs = {Sgr: lambda *args: "".join(map(str, args)), Fg256: lambda *args: "".join(map(str, args))}

    # Muted
    r.mute()
    s0 = Style(Sgr(1), Fg256(67))
    r.s0 = s0

    assert isinstance(r.s0, Style)
    assert r.s0.value == ""

    # Unmuted
    r.unmute()
    s1 = Style(Sgr(1), Fg256(67))
    r.s1 = s1

    assert isinstance(r.s1, Style)
    assert r.s1.value == "167"

   

# Generated at 2022-06-22 00:01:46.303947
# Unit test for method copy of class Register
def test_Register_copy():
    from .defaults import fg

    fg2 = fg.copy()

    fg2.black = Style(RgbFg(0,0,0))

    assert not hasattr(fg, "black")
    assert hasattr(fg2, "black")

# Generated at 2022-06-22 00:02:07.226828
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty import ansi
    import pytest
    ansi.set_eightbit_call(ansi.SgrFg)
    ansi.set_rgb_call(ansi.RgbFg)

    ansi.fg.yellow = ansi.Style(ansi.SgrFg(3))

    assert ansi.fg(3) == "\x1b[38;5;3m"
    assert ansi.fg(3, 5) == ""
    assert ansi.fg.yellow == "\x1b[38;5;3m"
    assert ansi.fg("yellow") == "\x1b[38;5;3m"
    assert ansi.fg(2, 3, 10) == "\x1b[38;2;2;3;10m"

# Generated at 2022-06-22 00:02:12.984489
# Unit test for method mute of class Register
def test_Register_mute():
    # Create a register with a style called 'my_style'
    register = Register()
    register.my_style = Style(RgbBg(0, 0, 0))
    # Check initial value of my_style
    assert register.my_style == '\x1b[48;2;0;0;0m'
    # Mute the register
    register.mute()
    # Check that the value of my_style changed
    assert register.my_style == ''


# Generated at 2022-06-22 00:02:23.288705
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty import fg, bg, ef, rs
    from sty.ansi import SgrFgBg
    from sty.ansi.rgb import RgbFgBg, TrueColor240
    from sty.ansi.rgb import DisallowedColor, AllowedColor
    from sty.ansi.special import SgrStyle

    class RegisterTest(Register):
        pass

    register: RegisterTest = RegisterTest()

    style: Style = Style(SgrFgBg(42), TrueColor240(44, 11, 2))
    style_test: Style = Style(SgrStyle(AllowedColor()), SgrStyle(DisallowedColor()))

    register.test = style

    register.set_eightbit_call(SgrFgBg)
    register.set_rgb_call(RgbFgBg)

# Generated at 2022-06-22 00:02:32.061381
# Unit test for method __call__ of class Register
def test_Register___call__():

    FakeRegister = Register

    FakeRegister.red = Style(RgbFg(255, 0, 0))
    FakeRegister.green = Style(RgbFg(0, 255, 0))

    renderfuncs = {RgbFg: lambda *args: f"RgbFg{args}"}

    FakeRegister.set_renderfunc(RgbFg, renderfuncs[RgbFg])

    fake = FakeRegister()
    fake.set_rgb_call(RgbFg)

    assert f"{fake(123, 1, 5)}" == "RgbFg(123, 1, 5)"
    assert f"{fake('red')}" == "RgbFg(255, 0, 0)"

    fake.mute()

    assert f"{fake(123, 1, 5)}" == ""

# Generated at 2022-06-22 00:02:43.133172
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Sgr
    from .ansi import sgr_escape, apply_sgr

    # Define dummy render-function
    def f(x):
        return sgr_escape([x])

    # Create register-object
    r = Register()

    # Add dummy render-function to register
    r.set_renderfunc(Sgr, f)

    # Add dummy style attr to register
    r.name = Style(Sgr(1), Sgr(2))

    # Set sgr-render-function as eightbit_call function
    r.set_eightbit_call(Sgr)

    # Test if r(1) returns sgr_escape([1])
    assert r(1) == sgr_escape([1])

    # Test if r.name returns sgr_escape([1, 2])
    assert r

# Generated at 2022-06-22 00:02:45.903142
# Unit test for constructor of class Style
def test_Style():
    assert Style(fg=30, bg=41, kwarg=1) == '\x1b[38;5;30m\x1b[48;5;41m'
    assert Style(fg=30, bg=41, kwarg=1, value='test') == 'test'
    assert Style(RenderType(), RenderType(), kwarg=1).value == ''

# Generated at 2022-06-22 00:02:50.568838
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(RgbBg(1, 2, 3), Sgr(4))
    assert s == '\x1b[48;2;1;2;3m\x1b[4m'
    assert type(s) == Style


# Generated at 2022-06-22 00:02:53.018934
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Setup Test
    r = Register()
    r.is_muted = True

    # Test
    r.unmute()

    assert r.is_muted is False


# Generated at 2022-06-22 00:02:56.725569
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg
    from .renderfunc import rgb_fg_renderfunc

    fg = Register()
    fg.set_renderfunc(RgbFg, rgb_fg_renderfunc)
    fg.set_rgb_call(RgbFg)
    fg.red = Style(RgbFg(255, 0, 0))

    assert str(fg.red) == "\x1b[38;2;255;0;0m"
    fg.mute()
    assert str(fg.red) == ""

    fg.unmute()
    assert str(fg.red) == "\x1b[38;2;255;0;0m"
    fg.mute()
    assert str(fg.red) == ""

    fg.unmute()
   

# Generated at 2022-06-22 00:03:02.085111
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    import sys

    if sys.version_info[0] < 3 or sys.version_info[1] < 6:
        return

    from sty import ef

    NT = ef.as_namedtuple()

    assert isinstance(NT.black, str)
    assert isinstance(NT, NamedTuple)

# Generated at 2022-06-22 00:03:26.746522
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def func1(*args):
        return "func1"

    def func2(*args):
        return "func2"

    class R1(RenderType):
        pass

    class R2(RenderType):
        pass

    reg = Register()

    # Before calling set_renderfunc, register should render with
    # empty string for R1 and R2
    assert reg(R1(3)) == ""
    assert reg(R2(3)) == ""

    # After calling set_renderfunc, register should render with
    # func1 for R1 and empty string for R2
    reg.set_renderfunc(R1, func1)
    assert reg(R1(3)) == "func1"
    assert reg(R2(3)) == ""

    # Now register should render with func1 for R1 and func2 for R2
   

# Generated at 2022-06-22 00:03:31.828982
# Unit test for method unmute of class Register
def test_Register_unmute():
    # Given
    s = Register()

    s.test = Style(RgbFg(1, 2, 3), Sgr(6))

    # When
    s.mute()
    s.unmute()

    # Then
    assert s.test == "\x1b[38;2;1;2;3m\x1b[6m"


# Generated at 2022-06-22 00:03:32.679026
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r



# Generated at 2022-06-22 00:03:34.150346
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r.renderfuncs == {}
    assert r.is_muted == False

# Generated at 2022-06-22 00:03:43.748859
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    assert fg.as_namedtuple().fg_gray == str(fg.gray)
    assert fg.as_namedtuple().fg_red == str(fg.red)
    assert fg.as_namedtuple().fg_green == str(fg.green)
    assert fg.as_namedtuple().fg_yellow == str(fg.yellow)
    assert fg.as_namedtuple().fg_blue == str(fg.blue)
    assert fg.as_namedtuple().fg_purple == str(fg.purple)
    assert fg.as_namedtuple().fg_teal == str(fg.teal)
    assert fg.as_namedtuple().fg_white == str(fg.white)

# Generated at 2022-06-22 00:03:50.736679
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import Sgr, RgbFg

    style = Style(RgbFg(1, 2, 3), Sgr(1))

    assert isinstance(style, Style)

    assert isinstance(style, str)

    assert style.rules == (RgbFg(1, 2, 3), Sgr(1))

    assert str(style) == "\x1b[38;2;1;2;3m\x1b[1m"


# Generated at 2022-06-22 00:03:54.949845
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()

    register.blau = Style(Fg(10))
    register.rot = Style(Fg(1), Sgr(1))

    assert register.as_dict() == {'blau': '\x1b[38;5;10m', 'rot': '\x1b[38;5;1m\x1b[1m'}

# Generated at 2022-06-22 00:04:01.142025
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Test __setattr__ method of class Register.
    """
    import sty
    sty._sty_ctx.setup()

    sty.register.fg.k = sty.Style(sty.RgbFg(1, 5, 10))

    assert sty.register.fg.k == "\x1b[38;2;1;5;10m"
    assert isinstance(sty.register.fg.k, str)
    assert isinstance(sty.register.fg.k, sty.Style)

# Generated at 2022-06-22 00:04:08.258690
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class MyRegister(Register):
        pass

    my_r = MyRegister()
    my_r.set_rgb_call(AnsiFg)
    my_r.set_eightbit_call(AnsiFg)

    my_r.red = Style(RgbFg(255, 0, 0))
    my_r.green = Style(RgbFg(0, 255, 0))
    my_r.blue = Style(RgbFg(0, 0, 255))

    t = my_r.as_namedtuple()

    assert isinstance(t, namedtuple)
    assert t.red == '\x1b[38;2;255;0;0m'
    assert t.green == '\x1b[38;2;0;255;0m'

# Generated at 2022-06-22 00:04:14.165684
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import RenderType, Sgr

    from .renderfunc import render_sgr

    rs = Register()
    rs.set_renderfunc(Sgr, render_sgr)
    rs.bold = Style(Sgr(1))

    rs.mute()

    rs.unmute()

    assert rs.bold == '\x1b[1m'

# Generated at 2022-06-22 00:04:43.203121
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r is not None
    assert isinstance(r, Register)

# Generated at 2022-06-22 00:04:52.733137
# Unit test for method __call__ of class Register
def test_Register___call__():
    register = Register()

    assert register("r") == ""
    assert register(42) == ""
    assert register("r", 42, "g", 7) == ""

    register.set_eightbit_call(RenderType)
    register.set_rgb_call(RenderType)

    assert register("r") == ""
    assert register(42) == "42"
    assert register(42, "a", "b", "c") == "42"
    assert register(0, 0, 0) == "0,0,0"
    assert register(0, 0, 0, "a", "b", "c") == "0,0,0"
    assert register(0, 0, 0, "a", "b", "c", "d", "e", "f") == "0,0,0"



# Generated at 2022-06-22 00:04:57.109512
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.foo = Style()
    r.bar = Style()

    assert r.as_namedtuple().foo == ""
    assert r.as_namedtuple().bar == ""


# Generated at 2022-06-22 00:05:04.300601
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertypes import RgbFg

    class MyRegister(Register):
        blau = Style(RgbFg(0, 0, 255))

    r = MyRegister()
    assert str(r.blau) == "\x1b[38;2;0;0;255m"
    r.mute()
    assert r.blau == ""
    r.unmute()
    assert str(r.blau) == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-22 00:05:08.723514
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test to verify that all predefined registers work as expected.
    """

    register = Register()
    setattr(register, "pointer_color", Style("\x1b[38;5;243m"))

    assert register("pointer_color") == "\x1b[38;5;243m"
    assert register(243) == "\x1b[38;5;243m"
    assert register(255, 255, 255) == ""
    assert register() == ""



# Generated at 2022-06-22 00:05:18.197096
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertypes import Sgr, RgbFg

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.lightred = Style(Sgr(1, 38, 5, 1))
    r.darkred = Style(Sgr(38, 5, 9))

    assert len(r.renderfuncs) == 0
    assert r.lightred == "m\x1b[1;38;5;1"
    assert r.darkred == "m\x1b[38;5;9"

    r.set_eightbit_call(RgbFg)

    assert len(r.renderfuncs) == 1
    assert r.lightred == "m\x1b[1;38;5;1"
    assert r.darkred == "m\x1b[38;5;9"