

# Generated at 2022-06-21 23:55:25.980794
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg

    fg = Register()
    fg.renderfuncs[RgbFg] = lambda r, g, b: f"{r},{g},{b}"
    fg.set_rgb_call(RgbFg)

    assert fg(37, 41, 69) == "37,41,69"


# Generated at 2022-06-21 23:55:37.448630
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    # TODO: Also test rgb
    r.light_red = Style(RgbFg(255, 160, 160))
    r.light_red_bold = Style(RgbFg(255, 160, 160), Sgr(1))

    # Eightbit
    assert r(200) == r("light_red")
    assert r(200) == r("light_red_bold")

    r.set_eightbit_call(RgbFg)
    assert r("light_red") == r("light_red_bold")

    r.set_eightbit_call(Sgr)
    assert r("light_red") != r("light_red_bold")

    # RGB
    assert r(255, 160, 160) == r("light_red")
    assert r(255, 160, 160) == r

# Generated at 2022-06-21 23:55:41.541563
# Unit test for method __new__ of class Style
def test_Style___new__():
    rule_1 = object()
    rule_2 = object()
    value = object()
    r = Style(rule_1, rule_2, value=value)
    assert r.rules == (rule_1, rule_2)
    assert str(r) is value


# Generated at 2022-06-21 23:55:48.446793
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertype import Sgr, RgbBg

    assert str(Style(Sgr(1), "hello")) == "\x1b[1mhello"

    assert str(Style(Sgr(1), RgbBg(10, 15, 20), "hello")) == "\x1b[48;2;10;15;20m\x1b[1mhello"

    with pytest.raises(ValueError):
        Style(1,2)

    with pytest.raises(ValueError):
        Style(Style(1,2), "hello")

# Generated at 2022-06-21 23:55:52.729940
# Unit test for constructor of class Style
def test_Style():
    assert style_1 == Style(Sgr(1), RgbBg(0, 1, 2))
    assert style_2 == Style(style_1)

style_1 = Style(Sgr(1), RgbBg(0, 1, 2))
style_2 = Style(style_1)



# Generated at 2022-06-21 23:55:56.194878
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-21 23:56:03.877573
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .renderfunc import ansi_color_seq
    from .rendertype import RgbFg

    rgb_print = lambda r, g, b: "".join(str(e) for e in (r, g, b))

    register = Register()

    register.set_renderfunc(RgbFg, ansi_color_seq)

    register.set_eightbit_call(RgbFg)
    register.set_rgb_call(RgbFg)

    assert register.eightbit_call(42) == ansi_color_seq(42)
    assert register.rgb_call(10, 20, 30) == ansi_color_seq(10, 20, 30)

    assert register(42) == register.eightbit_call(42)
    assert register(10, 20, 30) == register.rgb

# Generated at 2022-06-21 23:56:09.713037
# Unit test for method mute of class Register
def test_Register_mute():
    class R(RenderType):
        pass

    register = Register()

    register.set_renderfunc(R, lambda: "\x1b[999m")

    register.a = Style(R)

    assert str(register.a) == "\x1b[999m"

    register.mute()

    assert str(register.a) == ""



# Generated at 2022-06-21 23:56:18.904210
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class FakeRenderType(RenderType):
        pass

    class Register(Register):
        pass

    rendertype = FakeRenderType

    def eightbit_func(x):
        return x

    test_register = Register()
    test_register.set_renderfunc(rendertype, eightbit_func)
    test_register.set_eightbit_call(rendertype)

    assert test_register(42) == eightbit_func(42)
    assert test_register(99) == eightbit_func(99)
    assert test_register(137) == eightbit_func(137)



# Generated at 2022-06-21 23:56:25.457189
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import RgbFg

    rf: Renderfuncs = {RgbFg: lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m"}

    r = Register()
    r.set_renderfunc(RgbFg, rf[RgbFg])

    r.orange = Style(RgbFg(255, 165, 0))

    assert "\x1b[38;2;255;165;0m" == r.orange

    r.mute()

    assert "" == r.orange



# Generated at 2022-06-21 23:56:39.659659
# Unit test for method unmute of class Register
def test_Register_unmute():
    import pytest
    from .ansi import Sgr

    reg = Register()

    style = Style(Sgr(1))
    assert style != '\x1b[1m'
    assert style.rules == (Sgr(1),)

    reg.bold = style
    assert reg.bold != '\x1b[1m'

    reg.mute()

    style = Style(Sgr(1))
    assert style != '\x1b[1m'
    assert style.rules == (Sgr(1),)

    reg.bold = style
    assert reg.bold != '\x1b[1m'
    assert reg.bold == ''

    reg.unmute()

    style = Style(Sgr(1))
    assert style != '\x1b[1m'

# Generated at 2022-06-21 23:56:45.552788
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .style import fg, Sgr, RgbFg

    fg.green = Style(RgbFg(0, 255, 0), Sgr(1))

    nt: NamedTuple = fg.as_namedtuple()

    assert isinstance(nt, NamedTuple)
    assert nt.green == "\x1b[38;2;0;255;0m\x1b[1m"

# Generated at 2022-06-21 23:56:56.866425
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    r = Register()
    r.set_renderfunc(RenderType.Sgr, lambda x: "\x1b[{}m".format(x))

    r.lol = Style(RenderType.Sgr(1), RenderType.Sgr(2), RenderType.Sgr(3))
    assert str(r.lol) == "\x1b[1m\x1b[2m\x1b[3m"

    r.fun = Style(r.lol, RenderType.Sgr(4), r.lol, RenderType.Sgr(5), r.lol)

# Generated at 2022-06-21 23:57:04.614664
# Unit test for method unmute of class Register
def test_Register_unmute():

    r1 = Register()

    r1.set_renderfunc(RenderType, lambda *args, **kwargs: "mocked: " + str(args))
    r1.mute()

    r1.default = Style(RenderType(1), RenderType(2))
    assert r1.default == ""
    r1.unmute()
    assert r1.default == "mocked: (1,)mocked: (2,)"

# Generated at 2022-06-21 23:57:10.162104
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertypes import RgbFg, Sgr

    class R(Register):
        orange = Style(RgbFg(255, 128, 0), Sgr(1))

    r = R()
    assert str(r.orange) == "\x1b[38;2;255;128;0m\x1b[1m"
    r.mute()
    assert str(r.orange) == ""

# Generated at 2022-06-21 23:57:14.079660
# Unit test for constructor of class Register
def test_Register():
    """
    Test constructor of class Register
    """
    # This test is only for testing the correct handling of the class Register.
    # No tests for the actual functionality, because all necessary methods
    # are not yet implemented.

    r = Register()

    assert isinstance(r, Register)

# Generated at 2022-06-21 23:57:20.251365
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    def test_renderfunc(s):
        return s

    r = Register()

    r.set_renderfunc(RenderType, test_renderfunc)

    t = Style(RenderType("Hello"))

    r.test = t
    assert r.test == "Hello"

    r.mute()

    assert r.test == ""

    r.unmute()

    assert r.test == "Hello"



# Generated at 2022-06-21 23:57:22.754744
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .render import RgbBg, RgbFg, Sgr

    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))



# Generated at 2022-06-21 23:57:34.814011
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    import sty

    def test_setup():

        class CustomRegister(Register):
            def __init__(self):
                super(CustomRegister, self).__init__()

        register = CustomRegister()

        register.set_renderfunc(
            sty.RgbFg,
            lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m",
        )

        register.set_renderfunc(
            sty.RgbBg,
            lambda r, g, b: f"\x1b[48;2;{r};{g};{bm}m",
        )

        register.set_renderfunc(
            sty.Sgr,
            lambda sgr: f"\x1b[{sgr}m",
        )

        return register

    register = test_

# Generated at 2022-06-21 23:57:43.718728
# Unit test for constructor of class Style
def test_Style():
    rules: Iterable[StylingRule] = (RgbFg(1, 2, 3), Sgr(4),)
    value: str = "\x1b[38;2;1;2;3m\x1b[4m"

    style = Style(*rules, value=value)
    assert isinstance(style, str)
    assert style == "\x1b[38;2;1;2;3m\x1b[4m"

    assert isinstance(style, Style)
    assert style.rules == list(rules)



# Generated at 2022-06-21 23:58:01.749549
# Unit test for method copy of class Register
def test_Register_copy():

    import sty

    a1 = sty.fg
    a2 = sty.bg
    c1 = a1.copy()
    c2 = a2.copy()

    # Check if references are different
    assert id(a1) != id(c1)
    assert id(a2) != id(c2)

    # Check if register-contenes are different
    assert a1.black != c1.black
    assert a2.black != c2.black

    # Change register-attributes of original register-object
    a1.black = sty.Style(sty.RgbFg(10,20,30))
    a2.black = sty.Style(sty.RgbBg(220,210,200))

    # Check if register-contenes of copied register-objects are untouched
    assert c1.black != a1.black

# Generated at 2022-06-21 23:58:05.439135
# Unit test for constructor of class Style
def test_Style():
    s = Style(value="Sty is cool")
    assert s.rules == tuple()
    assert str(s) == "Sty is cool"

    s2 = Style(value="Sty is cool", rules=[])
    assert s2.rules == tuple()
    assert str(s2) == "Sty is cool"



# Generated at 2022-06-21 23:58:16.584302
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .registertypes import Fg, RgbFg, Sgr
    from .rendertype import RenderType

    class CustomRenderType(RenderType):
        def __init__(self, a: int, b: str):
            self.args = (a, b)

    r = Register()
    r.set_renderfunc(CustomRenderType, lambda a, b: f"{a}{b}")
    r.set_renderfunc(RgbFg, lambda r, g, b: f"\033[38;2;{r};{g};{bm}m")
    r.set_renderfunc(Fg, lambda idx: f"\033[38:5:{idx}m")

# Generated at 2022-06-21 23:58:23.812494
# Unit test for method unmute of class Register
def test_Register_unmute():

     def rgb_render_func(r: int, g: int, b: int) -> str:
         return "rgb(" + str(r) + "," + str(g) + "," + str(b) + ")"

     from .rendertype import RgbFg

     # Create a simple register with a single rgb rendertype.
     custom_fg = Register()
     custom_fg.set_renderfunc(RgbFg, rgb_render_func)
     custom_fg.orange = Style(RgbFg(1, 5, 10))
     custom_fg.red = Style(RgbFg(10, 0, 0))
     custom_fg.mute()

     assert custom_fg.orange == ""
     custom_fg.unmute()
     assert custom_fg.orange == "rgb(1,5,10)"

# Generated at 2022-06-21 23:58:31.350578
# Unit test for method unmute of class Register
def test_Register_unmute():
    class TestRenderType(RenderType):
        pass

    renderfunc: Callable = lambda x: x

    register = Register()
    register.set_renderfunc(TestRenderType, renderfunc)
    register.set_eightbit_call(TestRenderType)
    register.set_rgb_call(TestRenderType)
    register.style = Style(TestRenderType(42))
    register.mute()
    assert not register.style
    register.unmute()
    assert register.style == "42"
    assert register(128) == "128"
    assert register(10, 20, 30) == "102030"

# Generated at 2022-06-21 23:58:37.655286
# Unit test for method __new__ of class Style
def test_Style___new__():

    class Sgr(RenderType): pass
    class RgbFg(RgbRenderType): pass

    # Test different calls to __new__
    assert (Style(RgbFg(1,5,10)).value == "\x1b[38;2;1;5;10m")

    assert Style(
        RgbFg(1,5,10),
        Sgr(1),
        value="\x1b[38;2;1;5;10m\x1b[1m"
    ) == Style(RgbFg(1,5,10), Sgr(1))

    # TODO: Test that Style is also a str



# Generated at 2022-06-21 23:58:41.528678
# Unit test for method copy of class Register
def test_Register_copy():
    import pytest
    from sty import fg

    fg = fg.copy()
    assert isinstance(fg, Register)
    assert isinstance(fg.white, Style)
    assert hasattr(fg, "white")
    assert fg.white == "\x1b[37m"



# Generated at 2022-06-21 23:58:43.477269
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit-test for method ``__call__`` of class ``Register``.
    """
    # TODO: Write testcases.
    pass



# Generated at 2022-06-21 23:58:50.726355
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test that setting a new render-func actually changes the attribute of a Style.
    """
    r = Register()

    r.bg.red = Style(RgbBg(255, 0, 0))
    assert str(r.bg.red) == "\x1b[48;2;255;0;0m"

    r.mute()
    assert str(r.bg.red) == ""

    r.set_renderfunc(RgbBg, lambda r, g, b: f"RGB{r}{g}{b}")
    assert str(r.bg.red) == "RGB255000"

    r.unmute()
    assert str(r.bg.red) == "\x1b[48;2;255;0;0m"



# Generated at 2022-06-21 23:59:00.672867
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbFgAnsi256, RgbBgAnsi256

    class RgbFgTest(RgbFg):
        """This is a dummy rendertype for testing purposes"""
        format_string = '\x1b[38;2;'
        format_suffix = "m"

    class RgbBgTest(RgbBg):
        """This is a dummy rendertype for testing purposes"""
        format_string = '\x1b[48;2;'
        format_suffix = "m"

    class RgbFgAnsi256Test(RgbFgAnsi256):
        """This is a dummy rendertype for testing purposes"""
        format_string = '\x1b[38;5;'
        format_suffix = "m"

# Generated at 2022-06-21 23:59:18.745816
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Create new RenderType
    class MyRgb(RenderType):
        def __init__(self, r: int, g: int, b: int, val: str = "") -> None:
            super().__init__(r, g, b, val)

        def render_rgb(self, r: int, g: int, b: int) -> str:
            return "render_rgb"

    # Create a new register
    r = Register()

    # Register new renderfunc for MyRgb:
    r.set_renderfunc(MyRgb, MyRgb.render_rgb)

    # Set default renderfunc for RGB-calls
    r.set_rgb_call(MyRgb)

    # Test
    assert r(12, 34, 56) == "render_rgb"

    # Reset
    r

# Generated at 2022-06-21 23:59:28.543738
# Unit test for constructor of class Style
def test_Style():
    # Test with no parameters
    no_rules = Style()
    assert isinstance(no_rules, Style)
    assert no_rules.rules == ()
    # Test with one parameter
    rule = "Foo"
    one_rule = Style(rule)
    assert isinstance(one_rule, Style)
    assert one_rule.rules == (rule,)
    # Test with multiple parameters
    rules = ("Foo", "Bar")
    many_rules = Style(*rules)
    assert isinstance(many_rules, Style)
    assert many_rules.rules == rules
    # Test with wrong parameters
    wrong = "Wrong type"
    try:
        Style(wrong)
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError expected.")



# Generated at 2022-06-21 23:59:39.534259
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertypes import RgbFg, RgbBg, SetFg, Sgr

    fg = Register()

    fg.renderfuncs.update({RgbFg: lambda r, g, b: (r, g, b)})

    # print(fg(3,4,5)) # AttributeError: 'Register' object has no attribute 'rgb_call'
    fg.set_rgb_call(RgbFg)
    assert fg(3, 4, 5) == (3, 4, 5)

    fg.set_rgb_call(RgbBg)
    assert fg(3, 4, 5) == (3, 4, 5)

    # fg.set_rgb_call(Sgr) # TypeError: 'Sgr' object is not callable
    # assert f

# Generated at 2022-06-21 23:59:50.827865
# Unit test for constructor of class Register
def test_Register():

    def _test_set_renderfunc(register):

        def test_func(arg1, arg2):
            return "test_func({}, {})".format(arg1, arg2)

        register.set_renderfunc(RenderType, test_func)
        assert hasattr(register, "renderfuncs")
        assert register.renderfuncs[RenderType] == test_func

        register.set_renderfunc(RenderType, test_func)
        assert hasattr(register, "renderfuncs")
        assert register.renderfuncs[RenderType] == test_func

    def _test_set_eightbit_call(register):

        register.set_eightbit_call(RenderType)
        assert hasattr(register, "eightbit_call")


# Generated at 2022-06-21 23:59:54.537069
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .sgr import Sgr
    from .rgb import RgbFg

    reg = Register()
    reg.fourtytwo = Style(Sgr(1), RgbFg(10, 11, 12), value="\x1b[1m\x1b[38;2;10;11;12m")

    reg.set_eightbit_call(Sgr)
    reg.set_rgb_call(RgbFg)

    assert reg(42) == "\x1b[1m\x1b[38;5;42m"
    assert reg(42, bold=True) == "\x1b[1;1m\x1b[38;5;42m"
    assert reg("fourtytwo") == "\x1b[1m\x1b[38;2;10;11;12m"

# Generated at 2022-06-21 23:59:56.561268
# Unit test for method copy of class Register
def test_Register_copy():
    rg = Register()

    rg.red = Style(RgbFg(255, 0, 0))

    r2 = rg.copy()

    assert r2 == rg
    assert r2 is not rg



# Generated at 2022-06-22 00:00:06.964896
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .register import fg

    assert str(fg(42)) == str(fg.blue)

    # Test on unmuted register
    fg.unmute()
    assert fg(42) == fg.blue
    assert fg('blue') == fg.blue
    assert fg(10, 100, 200) == fg.orange
    assert fg.blue == Fg(42)

    # Test on muted register
    fg.mute()
    assert fg(42) == ""
    assert fg('blue') == ""
    assert fg(10, 100, 200) == ""

# Generated at 2022-06-22 00:00:18.349808
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .render import Eightbit, Rgb
    from .stys import fg

    fg.white = Style(Eightbit(255))
    fg.white = Style(Eightbit(255))

    assert str(fg.white) == "\x1b[38;5;255m"

    # Create new register
    test = Register()

    # Add method that generates ANSI strings to rendertype Eightbit
    test.set_renderfunc(Eightbit, lambda x: f"\x1b[38;5;{x}m")

    # Add Eightbit-call-function
    test.set_eightbit_call(Eightbit)

    # Add new style
    test.white = Style(Eightbit(255))

    # Verify rendered style
    assert str(test.white) == "\x1b[38;5;255m"



# Generated at 2022-06-22 00:00:21.929257
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class MyRenderType(RenderType):
        pass

    def my_renderfunc(*args):
        return "rendered string"

    r = Register()
    r.set_renderfunc(MyRenderType, my_renderfunc)

    assert (r.renderfuncs[MyRenderType] == my_renderfunc)


# Generated at 2022-06-22 00:00:26.034167
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.renderfuncs == {}
    assert register.is_muted is False


# Generated at 2022-06-22 00:00:42.146890
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RT(RenderType):
        __slots__ = ["arg"]

    renderfuncs = {RT: lambda x: f"\x1b[{x}m"}

    r = Register()
    r.set_renderfunc(RT, renderfuncs[RT])

    r.a = Style(RT(41))

    assert "a" in dir(r)
    assert isinstance(r.a, Style)
    assert r.a == "\x1b[41m"

# Generated at 2022-06-22 00:00:45.671955
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(value="\x1b[38;2;1;5;10m\x1b[1m")
    s_ruled = Style(value="\x1b[38;2;1;5;10m\x1b[1m", rules=())

    assert s == str(s)
    assert s == s_ruled

# Generated at 2022-06-22 00:00:48.204295
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Tests for method `copy` of class `sty.Register`.
    """

    a = Register()
    setattr(a, "test", Style("Test"))
    b = a.copy()
    assert a.test == b.test

# Generated at 2022-06-22 00:00:51.733495
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Tests the rules-attribute for correct content.
    """
    from .rendertype import Sgr

    s = Style(Sgr(1), value="")

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert len(s.rules) == 1
    assert isinstance(s.rules[0], Sgr)



# Generated at 2022-06-22 00:01:02.263984
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .base import Sgr, RgbFg, RgbBg
    from .rendertype import Eightbit, Rgb
    from .internal import _get_rgb_func, _get_eightbit_seq

    r = Register()

    r.renderfuncs = {Eightbit: _get_eightbit_seq, Rgb: _get_rgb_func}

    r.black = Style(RgbFg(0, 0, 0), Sgr(1))
    r.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(r.black) == "\x1b[38;2;0;0;0m\x1b[1m"

# Generated at 2022-06-22 00:01:09.787977
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        def __init__(self, x: int):
            self.args = (x,)

    class RgbFg(RenderType):
        def __init__(self, x: int, y: int, z: int):
            self.args = (x, y, z)

    class RgbBg(RenderType):
        def __init__(self, x: int, y: int, z: int):
            self.args = (x, y, z)

    def render_sgr(x: int) -> str:
        return f"\x1b[{x}m"


# Generated at 2022-06-22 00:01:12.683580
# Unit test for method copy of class Register
def test_Register_copy():

    r = Register()

    r.foo = "bar"

    w = r.copy()

    assert r is not w
    assert r.foo is w.foo



# Generated at 2022-06-22 00:01:23.002291
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .render import Sgr, RgbFg, RgbBg

    class CustomRegister(Register):
        pass

    custom = CustomRegister()
    custom.red = Style(RgbFg(255, 0, 0), Sgr(1))
    custom.set_rgb_call(RgbBg)

    # print(custom(255, 0, 0))
    assert str(custom(255, 0, 0)) == str(RgbBg(255, 0, 0))
    assert str(custom("red")) == str(custom.red)
    assert str(custom(42)) == ""
    assert str(custom([1, 2, 3])) == ""



# Generated at 2022-06-22 00:01:30.484304
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register = Register()
    register.renderfuncs = {type: lambda x: ""}

    class Sgr(RenderType):
        rend_str = ""

    sgr = Sgr()

    register.bold = Style(sgr)
    assert hasattr(register, "bold")
    assert register.bold == ""

    register.mute()
    assert hasattr(register, "bold")
    assert register.bold == ""

    register.unmute()
    assert hasattr(register, "bold")
    assert register.bold == ""

# Generated at 2022-06-22 00:01:39.769120
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class EightBit(RenderType):
        _rgb = False

        def _renderfunc(self, *args, **kwargs) -> str:
            return "EightBit"

    class RGB(RenderType):
        _rgb = True

        def _renderfunc(self, *args, **kwargs) -> str:
            return "RGB"

    r = Register()
    r.set_renderfunc(EightBit, EightBit._renderfunc)
    r.set_renderfunc(RGB, RGB._renderfunc)

    assert r(42) == ""

    r.set_eightbit_call(EightBit)

    assert r(42) == "EightBit"

    r.set_eightbit_call(RGB)

    assert r(42) == "RGB"

# Generated at 2022-06-22 00:02:00.311345
# Unit test for method mute of class Register

# Generated at 2022-06-22 00:02:07.588918
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .register import namedtuple_to_style, fg
    new_fg = fg.copy()
    new_fg.red = Style(RgbFg(255, 0, 0))

    new_namedtuple = new_fg.as_namedtuple()
    assert new_namedtuple.red == "\x1b[38;2;255;0;0m"

    # Check if styledict is converted to an unmodified
    # register-object.
    same_fg = namedtuple_to_style(new_namedtuple)
    assert same_fg.red == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-22 00:02:12.489341
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    def renderer(r: int, g: int, b: int) -> str:
        return f"{r}, {g}, {b}"

    r = Register()

    r.set_renderfunc(RenderType, renderer)

    r.set_rgb_call(RenderType)

    assert r(10, 20, 30) == "10, 20, 30"

# Generated at 2022-06-22 00:02:19.156938
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    A simple unit test for method as_dict.
    """
    register = Register()

    register.green = Style(RgbFg(42, 128, 33))
    register.red = Style(RgbFg(200, 42, 42))

    assert register.as_dict() == {
        "red": "\x1b[38;2;200;42;42m",
        "green": "\x1b[38;2;42;128;33m",
    }

# Generated at 2022-06-22 00:02:28.877798
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .style import fg
    from .util import RgbFg, Sgr

    assert str(Style(RgbFg(1,5,10), Sgr(1))) == '\x1b[38;2;1;5;10m\x1b[1m'
    assert str(Style(fg.orange, Sgr(1))) == '\x1b[38;2;249;139;0m\x1b[1m'
    assert str(Style(fg.orange, fg.red)) == '\x1b[38;2;249;139;0m\x1b[38;2;255;0;0m'
    assert str(fg.orange) == '\x1b[38;2;249;139;0m\x1b[1m'

# Generated at 2022-06-22 00:02:33.587824
# Unit test for constructor of class Style
def test_Style():

    # TODO: Why do we need the first line?
    from .rendertype import RenderType  # pylint: disable=import-outside-toplevel
    from .fg import SgrFg, RgbFg  # pylint: disable=import-outside-toplevel

    style: Style = Style(SgrFg(1), RgbFg(1, 2, 3))
    assert style.rules[0].number == 1
    assert style.rules[1].r == 1
    assert style.rules[1].g == 2
    assert style.rules[1].b == 3


# Generated at 2022-06-22 00:02:44.256170
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Unit-test for Register.set_renderfunc()
    """
    from .rendertype import Sgr

    def num_to_string(x: int) -> str:
        return str(x + 1)

    r = Register()
    r.style1 = r.style2 = Style(Sgr(1))
    r.style3 = Style(Sgr(2))

    assert str(r.style1) == "\x1b[1m"
    assert str(r.style2) == "\x1b[1m"
    assert str(r.style3) == "\x1b[2m"

    r.set_renderfunc(Sgr, num_to_string)

    assert str(r.style1) == "2"
    assert str(r.style2) == "2"

# Generated at 2022-06-22 00:02:54.288874
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .sgr import Sgr

    # Test simple setattr call
    r1 = Register()
    black = Style(Sgr(30))

    assert hasattr(r1, "black") == False
    r1.black = black
    assert hasattr(r1, "black") == True
    assert r1.black == "\x1b[30m"

    # Test setting a Style instance
    r2 = Register()
    bold = Style(Sgr(1))
    r2.bold = bold
    assert r2.bold == "\x1b[1m"
    black_bold = Style(Sgr(30), bold)
    assert black_bold == "\x1b[30m\x1b[1m"
    r2.black_bold = black_bold

# Generated at 2022-06-22 00:03:05.705698
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .. import registers
    from .rendertype import RgbBg, RgbFg
    from .style import RenderFuncs

    reg = Register()
    reg.set_renderfunc(RgbFg, RenderFuncs.rgb_fg)
    reg.set_renderfunc(RgbBg, RenderFuncs.rgb_bg)

    reg.red = Style(RgbFg(255, 0, 0))
    reg.blue = Style(RgbBg(0, 0, 255))

    # Testing
    assert reg.as_dict() == {"red": "\x1b[38;2;255;0;0m", "blue": "\x1b[48;2;0;0;255m"}

# Generated at 2022-06-22 00:03:06.885831
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-22 00:03:46.418475
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    assert Register().as_namedtuple() == namedtuple("StyleRegister", "")()

# Generated at 2022-06-22 00:03:55.963186
# Unit test for constructor of class Style
def test_Style():
    s = Style(
        RgbFg(1, 2, 3),
        RgbBg(5, 6, 7),
        Sgr(0, 1, 4),
        style_to_copy,
    )

    assert s == '\x1b[38;2;1;2;3m\x1b[48;2;5;6;7m\x1b[0;1;4m\x1b[31;42;4m'
    assert s.rules == (
        RgbFg(1, 2, 3),
        RgbBg(5, 6, 7),
        Sgr(0, 1, 4),
        style_to_copy,
    )


# Unit Test for constructor of class Register

# Generated at 2022-06-22 00:03:59.376845
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    def callee():

        import sty

        r = sty.fx.Register()
        r.set_eightbit_call(sty.ef)
        return r.eightbit_call

    cl = callee()
    assert cl is not None
    assert callable(cl)


# Generated at 2022-06-22 00:04:05.303723
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class R1(RenderType):
        pass

    class R2(RenderType):
        pass

    r = Register()
    r.set_renderfunc(R1, lambda: "F1")
    r.set_renderfunc(R2, lambda: "F2")

    r.foo = Style(R1())
    r.bar = Style(R2())

    assert str(r.foo) == "F1"
    assert str(r.bar) == "F2"

    r.set_renderfunc(R1, lambda: "F3")

    assert str(r.foo) == "F3"

# Generated at 2022-06-22 00:04:11.215787
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg
    print(fg.red)
    print(fg.as_dict())

# Generated at 2022-06-22 00:04:19.727273
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # A fixture
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.val_1 = Style(value="\x1b[1m")
            self.val_2 = Style(value="\x1b[38;2;10;20;30m")

    # Test
    r1 = MyRegister()
    assert isinstance(r1, Register)
    assert r1.as_dict() == {"val_1": "\x1b[1m", "val_2": "\x1b[38;2;10;20;30m"}



# Generated at 2022-06-22 00:04:26.333360
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test that the method Register.copy works.
    """
    from . import render

    class MyRegister(Register):
        """
        A test class used in the unit testing for copy.
        """

        default = Style(render.Sgr(1))

    rg1 = MyRegister()
    rg2 = rg1.copy()
    assert not hasattr(rg2, "my_color_123")
    rg1.my_color_123 = Style(render.Sgr(1))
    assert hasattr(rg1, "my_color_123")
    assert not hasattr(rg2, "my_color_123")
    rg2.my_color_123 = Style(render.Sgr(1))
    assert hasattr(rg1, "my_color_123")

# Generated at 2022-06-22 00:04:29.967360
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from sty import fg

    # Generate the sty-object for this test.
    sty = fg.white

    # Obtain the named tuple
    nt = sty.as_namedtuple()

    # Test that the attributes are obtained correctly.
    assert nt.white == str(fg.white)

    return

# Generated at 2022-06-22 00:04:41.869648
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # create a test register
    r = Register()

    # add a test style
    r.orange = Style("orange")

    # check that the style was added and the method __setattr__ was invoked
    assert r.orange == "orange"

    # set the muted flag
    setattr(r, "is_muted", True)

    # add a new style
    r.blue = Style("blue")

    # check that the style was added but the method __setattr__ was not invoked
    assert r.blue == ""

    # mute the test register
    r.mute()

    # add a new style
    r.yellow = Style("yellow")

    # check that the style was added but the method __setattr__ was not invoked
    assert r.yellow == ""

    # unmute the register
    r.unmute()

    #

# Generated at 2022-06-22 00:04:51.587947
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import fg, bg, ef, rs

    # Create an empty register to test __setattr__
    test_reg = Register()

    # Add renderfuncs
    test_reg.set_renderfunc(fg.RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    test_reg.set_renderfunc(fg.Sgr, lambda sgr: f"\x1b[{sgr}m")
    test_reg.set_renderfunc(bg.RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")