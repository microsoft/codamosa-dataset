

# Generated at 2022-06-21 23:55:20.441748
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class MyRegister(Register):
        pass

    register = MyRegister()
    register.my_color = "my_color_ANSI"
    register.my_color2 = "my_color_ANSI2"
    namedtuple_register = register.as_namedtuple()

    assert namedtuple_register.my_color == register.my_color
    assert namedtuple_register.my_color2 == register.my_color2



# Generated at 2022-06-21 23:55:28.532379
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import sty

    def compare_dict(d1, d2):
        if type(d1) != type(d2):
            return False

        keys = set(d1.keys()).union(set(d2.keys()))
        for key in keys:
            if d1.get(key) != d2.get(key):
                return False

        return True

    d1 = sty.fg.orange.as_dict()
    d2 = {"orange": "\x1b[38;2;255;165;0m"}

    assert compare_dict(d1, d2)



# Generated at 2022-06-21 23:55:35.483044
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    r = Register()

    r.white = Style(Sgr(1))

    assert r.white == "\x1b[1m"

    assert type(r.white) is str

    # Test: if `r` is muted, setattr still works but do not render.
    r.is_muted = True

    r.white = Style(Sgr(1))

    assert r.white == ""

    assert type(r.white) is str



# Generated at 2022-06-21 23:55:46.955899
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test for method copy of class Register.
    """

    from .rendertype import Sgr

    def dummy_renderfunc(x: int) -> str:
        return ""

    r: Register = Register()
    r.set_eightbit_call(Sgr)
    r.set_renderfunc(Sgr, dummy_renderfunc)
    r.test = Style(Sgr(1), Sgr(2))
    r.test = Style(Sgr(3), Sgr(4))
    r.mute()

    r2 = r.copy()

    assert r2.renderfuncs == r.renderfuncs
    assert r2.test == r.test
    assert r2.is_muted == r.is_muted
    assert r2.eightbit_call == r.eightbit_call
    assert r2

# Generated at 2022-06-21 23:56:00.536143
# Unit test for method __new__ of class Style
def test_Style___new__():
    class TestRenderType(RenderType):
        fmt = "{0} = {0}m"

    f1 = lambda x: x

    rt = TestRenderType(1)
    r1 = Style(rt)

    rt.fmt = "{0} = {0};{0}m"
    rt.args = (1, 2)
    r2 = Style(rt)

    assert isinstance(r1, Style)
    assert isinstance(r2, Style)
    assert isinstance(r1, str)
    assert isinstance(r2, str)
    assert str(r1) == "1 = 1m"
    assert str(r2) == "1 = 1;2m"
    assert r1.rules == (rt,)
    assert r2.rules == (rt,)



# Generated at 2022-06-21 23:56:07.357506
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    import pytest
    from ..rc import rc

    rg = Register()
    rg.test = Style(rc.fg.orange)
    assert rg.test == '\x1b[38;2;255;165;0m'  # orange

    rg.test = Style(rc._mute, rc.fg.orange)
    assert rg.test == ""


# Generated at 2022-06-21 23:56:12.646578
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    test_register = Register()
    test_register.black = Style(Fg8(0))
    test_register.white = Style(Fg8(15))
    test_register.transparent = Style(Fg8(16))

    nt = test_register.as_namedtuple()

    assert nt.black == "\x1b[38;5;0m"
    assert nt.white == "\x1b[38;5;15m"
    assert nt.transparent == "\x1b[38;5;16m"

# Generated at 2022-06-21 23:56:14.003955
# Unit test for constructor of class Register
def test_Register():
    r = Register()

    assert isinstance(r, Register)


# Generated at 2022-06-21 23:56:24.582455
# Unit test for method mute of class Register
def test_Register_mute():

    renderfuncs = {
        RenderType: lambda x: x,
        RenderType.Fg: lambda x, y: f"{x} {y}",
        RenderType.TwoFg: lambda x, y, z: f"{x} {y} {z}",
    }

    rg = Register()

    rg.set_renderfunc(RenderType, lambda x: x)
    rg.set_renderfunc(RenderType.Fg, lambda x, y: f"{x} {y}")
    rg.set_renderfunc(RenderType.TwoFg, lambda x, y, z: f"{x} {y} {z}")

    rg.test = Style(RenderType.Fg(150, 200), value="150 200")

# Generated at 2022-06-21 23:56:35.579774
# Unit test for method unmute of class Register
def test_Register_unmute():

    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b
            self.args = (r, g, b)

        def render(self, *args):
            r, g, b = args
            return f"\x1b[38;2;{r};{g};{b}m"

    def render(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render)

    assert reg.red_1 == Style(RgbFg(1, 1, 1))

    reg.red_1 = 42  # This should go well.

# Generated at 2022-06-21 23:56:45.907393
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register = Register()
    register.set_renderfunc(RenderType, lambda x: x)
    register.set_eightbit_call(RenderType)
    assert register.eightbit_call(42) == 42


# Generated at 2022-06-21 23:56:57.189453
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute works properly.
    """

    from .register import bg
    from .rendertype import Sgr, RgbBg

    bg.set_renderfunc(Sgr, lambda f: "\x1b[48;5;{}m".format(f))
    bg.set_renderfunc(RgbBg, lambda r, g, b: "\x1b[48;2;{};{};{}m".format(r, g, b))

    bg.red = Style(Sgr(1))
    bg.rgb_green = Style(RgbBg(0, 255, 0))

    bg.mute()

    assert str(bg.red) == ""
    assert str(bg.rgb_green) == ""

    bg.unmute()

    assert str

# Generated at 2022-06-21 23:57:07.212983
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test register.as_dict method.
   """
    class MyRegister(Register):
        foo = Style(Sgr(1))
        bar = Style(Sgr(2))
        baz = Style(Sgr(3))

    myreg = MyRegister()
    myreg_dict = myreg.as_dict()
    assert "foo" in myreg_dict
    assert "bar" in myreg_dict
    assert "baz" in myreg_dict
    assert isinstance(myreg_dict["foo"], str)
    assert isinstance(myreg_dict["bar"], str)
    assert isinstance(myreg_dict["baz"], str)

# Generated at 2022-06-21 23:57:10.622073
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RenderTypeMock:
        pass

    register = Register()
    register.set_renderfunc(RenderTypeMock, lambda x: "")
    assert "RenderTypeMock" in register.renderfuncs

# Generated at 2022-06-21 23:57:15.539722
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This function tests the method __setattr__ of the class Register.
    """
    from sty import register

    attr = "fake_attr"
    value = Style()

    register.fg.__setattr__(attr, value)

    assert getattr(register.fg, attr) == value



# Generated at 2022-06-21 23:57:16.608983
# Unit test for method __call__ of class Register
def test_Register___call__():

    # TODO: Implement unit test
    ...

# Generated at 2022-06-21 23:57:19.653537
# Unit test for method mute of class Register
def test_Register_mute():
    new_Register = Register()
    assert new_Register.is_muted == False
    new_Register.mute()
    assert new_Register.is_muted == True


# Generated at 2022-06-21 23:57:31.584345
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.set_renderfunc(RenderType, lambda x, y: x + y)
    r._test_1 = Style(RenderType("A", "B"))
    assert str(r._test_1) == "AB"

    r = Register()
    r.set_renderfunc(RenderType, lambda x, y: x + y)
    r._test_2 = Style(RenderType("A", "B"), Style(RenderType("C", "D")))
    assert str(r._test_2) == "ABCD"

    r = Register()
    r.set_renderfunc(RenderType, lambda x, y: x + y)
    r._test_3 = Style(Style(RenderType("A", "B")))
    assert str(r._test_3) == "AB"


# Unit test

# Generated at 2022-06-21 23:57:40.854190
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RegisterMock(Register):
        def __init__(self):
            super().__init__()

    RendertypeMock = RenderType
    RendertypeMock.seq = "MOCK"

    func = lambda *args: "MOCK"
    reg = RegisterMock()
    reg.set_renderfunc(RendertypeMock, func)

    reg.set_eightbit_call(RendertypeMock)
    reg.set_rgb_call(RendertypeMock)
    assert reg(123) == "MOCK"
    assert reg(1,2,3) == "MOCK"

# Generated at 2022-06-21 23:57:44.062215
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.is_muted is False

register = Register()
register.set_eightbit_call(RenderType)
register.set_rgb_call(RenderType)

# Generated at 2022-06-21 23:57:57.820022
# Unit test for constructor of class Register
def test_Register():
    test_obj = Register()

    test_obj.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))
    test_obj.set_eightbit_call(RgbFg)
    test_obj.set_rgb_call(RgbFg)

    test_obj.blue = Style(RgbFg(0, 0, 255))

    assert test_obj(0) == (0, 0, 0)
    assert test_obj(42) == (0, 0, 0)
    assert test_obj(255) == (0, 0, 0)

    assert test_obj(0, 0, 0) == (0, 0, 0)
    assert test_obj(42, 42, 42) == (42, 42, 42)

# Generated at 2022-06-21 23:58:03.524625
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r1 = Register()
    setattr(r1, "red", Style(RgbFg(255, 0, 0), Sgr(1)))
    r1.set_eightbit_call(RgbFg)
    assert r1(1) == "\x1b[38;2;255;0;0m"
    assert r1("red") == "\x1b[1m\x1b[38;2;255;0;0m"



# Generated at 2022-06-21 23:58:15.063604
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, Rgb
    from .colortable import fg

    # Test 8bit call
    fg.eightbit_call = lambda x: x
    assert fg(243) == 243

    # Test RGB call
    fg.rgb_call = lambda r, g, b: (r, g, b)
    assert fg(1, 2, 3) == (1, 2, 3)

    # Test string call
    fg.red = Style(Eightbit(10))
    assert str(fg("red")) == "\x1b[38;5;10m"

    # Test string call with multiple rendertypes
    fg.bold_red = Style(Eightbit(10), Rgb(1, 2, 3))

# Generated at 2022-06-21 23:58:22.617733
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import EightBit, RgbFg

    class MyRegister(Register):
        pass

    myreg = MyRegister()

    # Test Eightbit-call
    myreg.set_eightbit_call(EightBit)
    myreg.eightbit = Style(EightBit(42))

    # Test RGB-call
    myreg.set_rgb_call(RgbFg)
    myreg.rgb = Style(RgbFg(10, 42, 255))

    # Test string-call
    myreg.string = Style(EightBit(42))

    assert myreg(42) == myreg.eightbit
    assert myreg(10, 42, 255) == myreg.rgb
    assert myreg("string") == myreg.string

# Generated at 2022-06-21 23:58:33.028456
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class Sgr(RenderType):
        def render(*args, **kwargs) -> str:
            return f"\x1b[{args[0]}m"

    class RgbFg(RenderType):
        def render(*args, **kwargs) -> str:
            return f"\x1b[38;2;{args[0]};{args[1]};{args[2]}m"

    # Create Register
    reg = Register()

    # Create style attr
    reg.b = Style(Sgr(1), RgbFg(10, 20, 30))

    # Check if renderfuncs are correctly activated
    assert str(reg.b) == "\x1b[1m\x1b[38;2;10;20;30m"

    # Define new render function for RgbFg

# Generated at 2022-06-21 23:58:40.377066
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr, RgbBg, RgbFg, SetBg, Reset

    # Setup new register
    register = Register()

    # Render function for Sgr
    renderfunc_sgr = lambda *args: "SGR{}".format("".join(str(i) for i in args))

    # Render function for RgbFg
    renderfunc_rgb_fg = lambda r, g, b: "RgbFg{}/{}/{}".format(r, g, b)

    register.set_renderfunc(Sgr, renderfunc_sgr)
    register.set_renderfunc(RgbFg, renderfunc_rgb_fg)

    bg = Style(RgbBg(200, 100, 50), Sgr(1), SetBg(-1), Sgr(2))

# Generated at 2022-06-21 23:58:47.528988
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Foobar(Style):
        pass

    class TestRegister(Register):

        def __init__(self):

            super().__init__()

            self.foobar = Foobar(
                "foo",
                "bar",
                value="\x1b[38;2;42;42;42m" + "foo" + "\x1b[39m" + "\x1b[48;2;24;24;24m" + "bar" + "\x1b[49m",
            )

    tr: TestRegister = TestRegister()

    # test if 'foobar' is successfully created

# Generated at 2022-06-21 23:58:49.976124
# Unit test for constructor of class Style
def test_Style():
    style = Style(Sgr(0), Sgr(1))

# Generated at 2022-06-21 23:58:59.894373
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, Sgr

    class RendfuncTest(NamedTuple):
        args: Tuple[int]
        kwargs: Dict[str, int]
        rendered: str

    def render_test(r, g, b):
        return RendfuncTest((r, g, b), {}, "")

    rgbfg = RgbFg(1, 2, 3)
    sgr = Sgr(1)
    style = Style(rgbfg, sgr)

    assert str(style) == "\x1b[38;2;1;2;3m\x1b[1m"

    reg = Register()
    reg.set_renderfunc(RgbFg, render_test)
    reg.set_renderfunc(Sgr, render_test)

# Generated at 2022-06-21 23:59:06.879419
# Unit test for constructor of class Style
def test_Style():
    style = Style(RenderType())
    assert isinstance(style, str)
    assert isinstance(style, Style)
    assert style.rules == (RenderType(),)
    assert style == ""

    style = Style(RenderType(), "foo")
    assert isinstance(style, str)
    assert isinstance(style, Style)
    assert style.rules == (RenderType(),)
    assert style == "foo"

    style = Style(RenderType(), Style(RenderType(), "foo"))
    assert isinstance(style, str)
    assert isinstance(style, Style)
    assert style.rules == (RenderType(), RenderType())
    assert style == "foo"

# Generated at 2022-06-21 23:59:21.623077
# Unit test for method mute of class Register
def test_Register_mute():
    from . import fg, bg

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert bg.red == "\x1b[48;2;255;0;0m"

    fg.mute()
    bg.mute()

    assert fg.red == ""
    assert bg.red == ""

    fg.unmute()
    bg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert bg.red == "\x1b[48;2;255;0;0m"


# Generated at 2022-06-21 23:59:31.807195
# Unit test for method copy of class Register
def test_Register_copy():
    """
    This unit test checks the functionality of the Register.copy method.
    """
    import unittest

    # Setup
    class TestRegister(Register):

        style: Style

    testreg = TestRegister()

    testreg.style1 = Style(1)
    testreg.style2 = Style(2)
    testreg.style3 = Style(3)

    # Test
    copyreg = testreg.copy()

    for name in dir(testreg):
        if not name.startswith("_") and isinstance(getattr(testreg, name), Style):
            assert testreg.name == copyreg.name

    # Tear down



# Generated at 2022-06-21 23:59:41.471079
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.foo = Style(value="\x1b[38;2;255;0;0m\x1b[48;2;0;255;0m")
    r.bar = Style(value="\x1b[48;2;255;0;0m\x1b[38;2;0;255;0m")
    T = r.as_namedtuple()

    assert isinstance(T, NamedTuple)
    assert T.foo == "\x1b[38;2;255;0;0m\x1b[48;2;0;255;0m"
    assert T.bar == "\x1b[48;2;255;0;0m\x1b[38;2;0;255;0m"

# Generated at 2022-06-21 23:59:48.766238
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    expected = {
        "red": "\x1b[38;2;255;0;0m",
        "blue": "\x1b[38;2;0;0;255m",
    }

    assert fg.as_dict() == expected



# Generated at 2022-06-21 23:59:56.502516
# Unit test for method copy of class Register
def test_Register_copy():

    from .colorregister import ColorRegister
    from .fg import Fg
    from .bg import Bg
    from .ef import Ef
    from .rs import Rs
    from .rendertype import RgbBg
    from .rendertype import RgbFg
    from .rendertype import Sgr

    cr = ColorRegister()

    # Create style-object
    s1 = Style(RgbFg(1, 5, 10), Sgr(1))

    # Save style-object in register fg
    cr.fg.red = s1

    # Make a copy of ColorRegister
    cr_copy = cr.copy()

    # Assert that fg.red has equal objects, but are not equal objects.
    assert (cr.fg.red == cr_copy.fg.red)

# Generated at 2022-06-22 00:00:09.287468
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    rf = Register()

    class RgbFg2:
        def get_ansi_string(self, r: int, g: int, b: int) -> str:
            return f"\x1b[{r},{g},{b}\x1b[38m"

    class RgbBg2:
        def get_ansi_string(self, r: int, g: int, b: int) -> str:
            return f"\x1b[{r},{g},{b}\x1b[48m"

    def f1(r: int, g: int, b: int) -> str:
        return f"\x1b[{r};{g};{b}\x1b[38m"


# Generated at 2022-06-22 00:00:20.371193
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty import fg
    assert fg(100) == "\033[38;5;100m"
    assert fg(100.0) == "\033[38;5;100m"
    assert fg("red") == "\033[38;5;9m"
    assert fg(9) == "\033[38;5;9m"
    assert fg(0, 0, 0) == "\033[38;2;0;0;0m"
    assert fg(0.0, 0, 0) == "\033[38;2;0;0;0m"
    assert fg(0, 0.0, 0) == "\033[38;2;0;0;0m"
    assert fg(0, 0, 0.0) == "\033[38;2;0;0;0m"

# Generated at 2022-06-22 00:00:33.108935
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import sty
    import json

    assert isinstance(sty.fg.as_dict(), dict)

    # Read register as dict
    fg_dict_as_json = json.dumps(sty.fg.as_dict(), ensure_ascii=False, indent=4)

    # Read register as namedtuple
    fg_namedtuple = sty.fg.as_namedtuple()

    # Read register as dict again
    fg_dict_as_json_as_dict = json.loads(fg_dict_as_json)

    # Read register as namedtuple again
    fg_dict_as_json_as_namedtuple = namedtuple("StyleRegister", fg_dict_as_json_as_dict.keys())(**fg_dict_as_json_as_dict)

    # Check if fg

# Generated at 2022-06-22 00:00:43.958107
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class Nocolor(RenderType):
        @property
        def args(self):
            return []

    reg = Register()
    reg.set_renderfunc(Nocolor, lambda: "")
    
    reg.orange = Style(Nocolor())
    assert isinstance(reg.orange, Style)
    assert isinstance(reg.orange, str)
    assert str(reg.orange) == ""


###############################################################################
#                                                                             #
#                                    fg64                                     #
#                                                                             #
###############################################################################
fg64 = Register()

fg64.set_renderfunc(RenderType, lambda x: f"\x1b[38;5;{x}m")
fg64.set_eightbit_call(RenderType)


# Generated at 2022-06-22 00:00:51.341490
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    reg = Register()
    Sty = Style
    Rgb = RenderType()
    Rgb2 = RenderType()
    reg.set_renderfunc(Rgb, lambda *args: f"Rgb{args}")
    reg.set_renderfunc(Rgb2, lambda *args: f"Rgb2{args}")
    reg.test_style = Sty(Rgb(1, 2, 3))
    reg.test_style2 = Sty(Rgb2(1, 2, 3))
    reg.set_rgb_call(Rgb2)
    assert (reg(1, 2, 3) == reg.test_style2 == "Rgb21,2,3")
    assert (reg.test_style == "Rgb1,2,3")

# Generated at 2022-06-22 00:01:09.452591
# Unit test for method mute of class Register
def test_Register_mute():
    import sty

    # Create a simple register
    r = sty.Register()
    r.red = sty.Style(sty.RgbFg(255, 0, 0))
    r.blue = sty.Style(sty.RgbFg(0, 255, 0))
    r.green = sty.Style(sty.RgbBg(0, 255, 0))

    assert str(r.red) == '\x1b[38;2;255;0;0m'

    # Mute register and test if it is muted
    r.mute()
    assert r.is_muted is True
    assert str(r.red) == ''
    assert str(r.blue) == ''
    assert str(r.green) == ''

    # Unmute register and test if it is un-muted
    r.unm

# Generated at 2022-06-22 00:01:21.873252
# Unit test for method __new__ of class Style
def test_Style___new__():

    # Test if Style returns string
    style = Style('\x1b[38;2;1;5;10m\x1b[1m')
    assert isinstance(style, str)

    # Test if Style returns a Style
    style = Style(1, 2, 3, value='\x1b[38;2;1;5;10m\x1b[1m')
    assert isinstance(style, Style)

    # Test if Style stores rules in attribute
    style = Style(1, 2, 3, 4)
    assert style.rules == (1, 2, 3, 4)

    # Test if Style stores value in attribute
    style = Style(1, 2, 3, value=5)
    assert style.value == 5

    # Test if Style returns a Style

# Generated at 2022-06-22 00:01:27.587569
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    >>> r = Register()
    >>> r.foo = Style(RgbFg(1,2,3))
    >>> r.bar = Style(RgbFg(3,2,1))
    >>> d = r.as_dict()
    >>> assert d['foo'] == '\x1b[38;2;1;2;3m'
    >>> assert d['bar'] == '\x1b[38;2;3;2;1m'
    """


# Generated at 2022-06-22 00:01:29.761239
# Unit test for constructor of class Register
def test_Register():
    """
    Test for constructor of class Register.
    """
    Register()

# Generated at 2022-06-22 00:01:39.884639
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import re

    r = Register()

    class TestRgbFg(RenderType):
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b

        def __repr__(self):
            return f"TestRgbFg({self.r}, {self.g}, {self.b})"


        def __str__(self):
            return f"\x1b[38;2;{self.r};{self.g};{self.b}m"

    def test_rgb_renderer(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    r.set_renderfunc(TestRgbFg, test_rgb_renderer)

# Generated at 2022-06-22 00:01:45.142525
# Unit test for method mute of class Register
def test_Register_mute():
    class TestRegister(Register):
        pass

    r = TestRegister()

    r.set_renderfunc(RenderType, lambda x: f"{x}")

    r.test = Style(RenderType(1), RenderType(2))

    r.mute()

    assert (r.test == "")

    r.unmute()

    assert (r.test == "12")

# Generated at 2022-06-22 00:01:49.194571
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .render import Render
    from .sty import StyleRegister

    Render.register(StyleRegister())
    r = Render.fg.copy()
    r.mute()

    assert r.red == ""
    r.unmute()
    assert r.red != ""

# Generated at 2022-06-22 00:01:53.506638
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg

    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))
    r.set_rgb_call(RgbFg)
    assert r.rgb_call(1, 2, 3) == (1, 2, 3)


# Generated at 2022-06-22 00:01:54.294667
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert bool(r) is True

# Generated at 2022-06-22 00:02:02.086808
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert Style(value="\x1b[94m", rules=(RgbFg(1, 5, 10))) == "\\x1b[94m"
    assert Style(value="\x1b[94m", rules=(RgbFg(1, 5, 10), Sgr(1))) == "\\x1b[94m"
    assert Style(
        value="\x1b[38;2;1;5;10m\x1b[1m", rules=(RgbFg(1, 5, 10), Sgr(1))
    ) == "\\x1b[38;2;1;5;10m\\x1b[1m"


# Generated at 2022-06-22 00:02:23.255122
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test the Register.__call__ method.
    """
    from .rendertype import Sgr, EightbitFg, SixteenbitFg, RgbFg

    from .rendertypes import WINDOWS

    fg = Register()
    fg.set_renderfunc(Sgr, lambda *args: f"SGR:{args[0]}")
    fg.set_renderfunc(EightbitFg, lambda x: f"8bit:" + str(x))
    fg.set_renderfunc(SixteenbitFg, lambda x: f"16bit:" + str(x))
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"RGB:{r},{g},{b}")
    fg.set_eightbit_call(RgbFg)

# Generated at 2022-06-22 00:02:32.040264
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def f1(x):
        return f"{x}"

    def f2(x):
        return f"{x}2"

    def f3(x):
        return f"{x}3"

    def f4(x):
        return f"{x}4"

    class M1(RenderType):
        """ABC"""

        pass

    class M2(RenderType):
        """ABC"""

        pass

    class M3(RenderType):
        """ABC"""

        pass

    class M4(RenderType):
        """ABC"""

        pass

    r = Register()

    r.set_renderfunc(M1, f1)
    r.set_renderfunc(M2, f2)

    r.rules = {M1: M1(1), M2: M2(2)}

    #

# Generated at 2022-06-22 00:02:43.097135
# Unit test for method mute of class Register
def test_Register_mute():
    from .stylers import fg, bg, ef

    fg.eightbit_call = lambda x: f"{RgbFg(*x)}"
    fg.rgb_call = lambda r, g, b: f"{RgbFg(*(r, g, b))}"

    fg.orange = Style(RgbFg(255, 165, 0), Sgr(1))

    assert fg.orange == "\x1b[38;2;255;165;0m\x1b[1m"

    fg.mute()

    assert fg.orange == ""

    fg.unmute()

    assert fg.orange == "\x1b[38;2;255;165;0m\x1b[1m"

    del fg.orange

    fg(144)

# Generated at 2022-06-22 00:02:45.554482
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .style import fg

    d = fg.as_dict()

    assert isinstance(d, dict)
    assert all(isinstance(v, str) for v in d.values())
    assert all(isinstance(k, str) for k in d.keys())



# Generated at 2022-06-22 00:02:55.061392
# Unit test for method mute of class Register
def test_Register_mute():

    class RgbTest(RenderType):
        pass
    class SgrTest(RenderType):
        pass

    # Set up register
    rgb = RgbTest()
    sgr = SgrTest()

    r = Register()
    r.test_style = Style(rgb(128, 128, 128), sgr(1))
    r.test_style_2 = Style(rgb(1, 2, 3), sgr(2))

    # The color is rendered
    assert str(r.test_style) == "\x1b[38;2;128;128;128m\x1b[1m"

    # Mute the register
    r.mute()

    # The color is not rendered and the muting is set
    assert str(r.test_style) == ""
    assert r.is_muted == True



# Generated at 2022-06-22 00:03:06.660151
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from sty import fg, bg, ef, rs, RgbFg, RgbBg, RgbEf
    from sty import Style

    fg.blue = Style(RgbFg(0, 0, 255))
    bg.green = Style(RgbBg(0, 255, 0))
    ef.bold = Style(RgbEf(1))

    r = Register()

    r.__setattr__("blue", Style(RgbFg(0, 0, 255)))
    r.__setattr__("green", Style(RgbBg(0, 255, 0)))
    r.__setattr__("bold", Style(RgbEf(1)))

    assert fg.blue == r.blue
    assert bg.green == r.green
    assert ef.bold == r.bold



# Generated at 2022-06-22 00:03:18.361535
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import Eightbit, RgbFg, Sgr
    from .sty import sty

    sty.fg.red = Style(Eightbit(9), Sgr(1))
    sty.bg.red = Style(Eightbit(9))

    sty.fg.brown = Style(Eightbit(94))
    sty.bg.brown = Style(Eightbit(94), Sgr(1))

    sty.fg.rgb.red = Style(RgbFg(255, 0, 0))
    sty.bg.rgb.red = Style(RgbFg(255, 0, 0), Sgr(1))

    sty.fg.rgb.brown = Style(RgbFg(94, 0, 0))
    sty.bg.rgb.brown = Style(RgbFg(94, 0, 0), Sgr(1))

# Generated at 2022-06-22 00:03:26.873131
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .fg import fg
    from .f3 import RgbFg

    fg.blue = Style(RgbFg(0, 0, 255))
    fg.yellow = Style(RgbFg(255, 255, 0))

    t = fg.as_namedtuple()

    assert isinstance(t, NamedTuple)
    assert t.blue == '\x1b[38;2;0;0;255m'
    assert t.yellow == '\x1b[38;2;255;255;0m'



# Generated at 2022-06-22 00:03:32.918876
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register = Register()
    register.renderfuncs = {RenderType: lambda x: x}
    register.is_muted = True

    class CustomRenderType(RenderType):
        pass

    rendertype = CustomRenderType(1, 2, 3)
    style = Style(rendertype)

    # Run test
    register.a = style

    assert str(register.a) == ""
    assert register.a.rules[0].args == (1, 2, 3)

# Generated at 2022-06-22 00:03:43.597730
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        def __init__(self, val):
            self.args = (val,)
            self.value = "\x1b[{}m".format(val)

    class SgrFg(RenderType):
        def __init__(self, val):
            self.args = ("38;2;" + str(val),)
            self.value = "\x1b[" + self.args[0] + "m"

    def dummy_renderfunc(val: int) -> str:
        return "\x1b[" + str(val) + "m"

    def dummy_renderfunc_sgr(arg: Tuple[int]) -> str:
        return "\x1b[" + str(arg[0]) + "m"

    # Setup test-register with two dummy renderfuncs

# Generated at 2022-06-22 00:04:02.313479
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .ansi import fg, bg
    from .rendertype import Sgr

    print("Test method __setattr__ of class Register...")

    default_red = fg.red

    fg.test_style = Style(Sgr(1))
    print("setattr 'test_style' as Style: ", fg.test_style)

    fg.test_style = Style(Sgr(1), Sgr(2))
    print("setattr 'test_style' as Style: ", fg.test_style)

    fg.test_style = Style(Sgr(1), Style(Sgr(2)))
    print("setattr 'test_style' as Style: ", fg.test_style)

    fg.test_style = default_red

# Generated at 2022-06-22 00:04:08.200726
# Unit test for method unmute of class Register
def test_Register_unmute():

    from . import rst

    register = Register()
    register.set_eightbit_call(rst.Sgr)
    register.set_rgb_call(rst.RgbFg)
    register.red = Style(rst.RgbFg(255, 0, 0))
    register.orange = Style(rst.RgbFg(255, 165, 0))

    assert str(register.red) == "\x1b[38;2;255;0;0m"

    register.mute()

    assert register.red == ""
    assert register.orange == ""

    register.unmute()

    assert str(register.red) == "\x1b[38;2;255;0;0m"

# Generated at 2022-06-22 00:04:20.019088
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Create an instance of class Register
    dummyreg = Register()

    # Create two dummy render-functions for different render-types.
    # This function checks, if a call to `dummyreg(10, 20, 30)`
    # creates the expected output.
    def renderfunc1(_, __, ___):
        return "The call to renderfunc1 was successful."

    def renderfunc2(_, __, ___):
        return "The call to renderfunc2 was successful."

    # Add the two dummy render-functions to the dummyreg
    dummyreg.set_renderfunc(RenderType, renderfunc1)
    dummyreg.set_renderfunc(RenderType, renderfunc2)

    # Set the renderfunc for rgb-calls to renderfunc1
    dummyreg.set_rgb_call(RenderType)

    # Call the dummyreg

# Generated at 2022-06-22 00:04:24.984029
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    setattr(r, "green", "sty")
    assert r(0) == r(0, 0, 0) == ""
    assert r("green") == "sty"
    r.mute()
    assert r(0) == r(0, 0, 0) == r("green") == ""
    r.unmute()
    assert r(0) == r(0, 0, 0) == ""
    assert r("green") == "sty"
    assert r.green == "sty"



# Generated at 2022-06-22 00:04:34.955186
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()

    r.RED_EIGHT = Style(RgbFg(255, 0, 0))
    r.BLUE_RGB = Style(RgbFg(0, 0, 255))

    r.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))

    assert r(255, 0, 0) == (255, 0, 0)
    assert r(0, 0, 255) == (255, 0, 0)
    assert r('RED_EIGHT') == (255, 0, 0)
    assert r('BLUE_RGB') == (255, 0, 0)
    assert r(5) is None
    assert r(5, 5, 5) is None

    r.set_eightbit_call(RgbFg)

# Generated at 2022-06-22 00:04:47.329045
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test the method Register.copy.
    """

    from .sty import Sty
    from .rendertype import Sgr

    class SgrType(RenderType):
        pass

    reg = Register()
    # The two attributes below are used for testing the copy method.
    reg.black = Style(SgrType(30))
    reg.reset = Style(SgrType(0))
    reg.set_renderfunc(SgrType, Sty.render_sgr)
    assert reg.black == "\x1b[30m"
    assert reg.reset == "\x1b[0m"
    reg.mute()
    assert reg.black == ""
    assert reg.reset == ""
    # Remove attributes for the copy test.
    delattr(reg, "black")
    delattr(reg, "reset")
    reg_

# Generated at 2022-06-22 00:04:51.375139
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import RgbFg, Ef
    from .type import Fg, Ef

    Style(RgbFg(1,5,10), Ef())
    Style(Fg(255), Ef())
    Style(Fg(255), Ef())
    Style(Ef())
    Style(Ef(), value=str(Ef()))



# Generated at 2022-06-22 00:04:58.188666
# Unit test for constructor of class Style
def test_Style():
    # Type: Style = Style(RgbFg(10,42,255),Sgr(1))
    Type = Style(RgbFg(10, 42, 255), Sgr(1))
    assert isinstance(Type, Style)
    assert isinstance(Type, str)
    assert str(Type) == "\x1b[38;2;10;42;255m\x1b[1m"

# Generated at 2022-06-22 00:05:04.876001
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    rs = Register()
    rs.set_renderfunc(Sgr, lambda *args: (args, ))
    rs.underlined = Style(Sgr(4))
    rs.set_renderfunc(Sgr, lambda *args: (args, "new"))
    rs.bold = Style(Sgr(1))

    assert rs.underlined.rules[0][0] == (4,)
    assert rs.bold.rules[0][0] == (1, "new")

# Generated at 2022-06-22 00:05:09.143753
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class CustomRegister(Register):
        pass

    cr = CustomRegister()

    cr.red = Style(RgbFg(10, 0, 0))
    cr.blue = Style(RgbFg(0, 0, 10))

    tup = cr.as_namedtuple()

    assert tup.red == "\x1b[38;2;10;0;0m"
    assert tup.blue == "\x1b[38;2;0;0;10m"