

# Generated at 2022-06-21 23:55:24.943200
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import ansi

    fn_ansi = Register()
    fn_ansi.set_renderfunc(ansi.AnsiType, ansi.AnsiStyle.render)
    fn_ansi.set_eightbit_call(ansi.AnsiType)

    fn_ansi.red = Style(ansi.FgRed)
    assert str(fn_ansi.red) == ansi.FgRed.ANSI_ESCAPE_SEQUENCE

    fn_ansi.mute()
    assert str(fn_ansi.red) == ""



# Generated at 2022-06-21 23:55:33.937883
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbBg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)
    def render_func(r: int, g: int, b: int) -> str:
        return f"\033[48;2;{r};{g};{b}m"

    a = Register()
    a.set_renderfunc(RgbBg, render_func)
    a.set_rgb_call(RgbBg)

    assert a(1,1,1) == "\033[48;2;1;1;1m"


# Generated at 2022-06-21 23:55:45.462784
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty import fg, Sgr, Rgb
    from sty.utils import _make_rgbfg
    from sty.rendertype import RgbFg, rendertype

    renderfuncs: Dict[Type[RenderType], Callable] = {
        Sgr: lambda x: "\x1b[%dm" % x,
        RgbFg: lambda r, g, b: "\x1b[38;2;%d;%d;%dm" % (r, g, b),
    }

    style = Style(
        Sgr(1),
        RgbFg(1, 5, 10),
    )

    style2 = Style(style, fg.black)

    assert style.rules == (Sgr(1), RgbFg(1, 5, 10))


# Generated at 2022-06-21 23:55:52.245221
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test for set_rgb_call method of class Register.
    """

    class DummyRenderType(RenderType):
        """
        Dummy render type for test.
        """

        def __init__(self, n: int) -> None:
            self.n = n

        @property
        def args(self):
            return (self.n,)

    def my_render_func(n: int) -> str:
        return f"{n}"

    reg = Register()
    reg.set_renderfunc(DummyRenderType, my_render_func)
    reg.set_rgb_call(DummyRenderType)

    assert reg(10) == "10"
    assert reg(1337) == "1337"


# Generated at 2022-06-21 23:55:58.231175
# Unit test for method copy of class Register
def test_Register_copy():

    from sty.registers import *

    temp = fg.red.copy()

    assert(fg.red == temp)
    assert(id(fg.red) != id(temp))
    assert(id(fg.red.red) != id(temp.red))


# Generated at 2022-06-21 23:56:04.886236
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    This function tests the set_renderfunc method of the class Register.
    """

    from .rendertype import RgbBg
    from .rendertype import RgbFg

    def f1(r, g, b):
        return f"{r}.{g}.{b}"

    def f2(r, g, b):
        return f"{r},{g},{b}"

    # init
    r1 = Register()
    r2 = Register()

    r1.set_renderfunc(RgbFg, f1)
    r1.set_renderfunc(RgbBg, f2)

    r2.set_renderfunc(RgbBg, f2)
    r2.set_renderfunc(RgbFg, f1)

    sgr = Sgr(1)
    sty1

# Generated at 2022-06-21 23:56:13.628778
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbSgr(RenderType):
        pass

    class RgbEf(RenderType):
        pass

    def rgb_sgr_renderfunc(r, g, b):
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    def rgb_ef_renderfunc(r, g, b):
        return "\x1b[38;5;{};{};{}m".format(r, g, b)

    register = Register()

    register.set_renderfunc(RgbSgr, rgb_sgr_renderfunc)

    assert register.renderfuncs[RgbSgr] == rgb_sgr_renderfunc

    register.set_renderfunc(RgbEf, rgb_ef_renderfunc)


# Generated at 2022-06-21 23:56:19.430132
# Unit test for method copy of class Register
def test_Register_copy():
    from .styles import get_style

    style1 = get_style()

    style2 = style1.copy()

    assert style1.register.as_dict() == style2.register.as_dict()
    assert style1.register.as_namedtuple() == style2.register.as_namedtuple()



# Generated at 2022-06-21 23:56:22.531435
# Unit test for method mute of class Register
def test_Register_mute():

    # Test pre-conditions
    r: Register = Register()
    assert not r.is_muted

    # Test
    r.mute()

    # Test assertions
    assert r.is_muted



# Generated at 2022-06-21 23:56:28.758135
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.option_one = "Hello"
    r.option_two = "World"

    assert r.as_dict() == {"option_one": "Hello", "option_two": "World"}

    r_ = r.copy()
    r_.option_one = "Another World"
    r_.option_two = "Another Hello"

    assert r_.as_dict() == {"option_one": "Another World", "option_two": "Another Hello"}

# Generated at 2022-06-21 23:56:45.827385
# Unit test for method mute of class Register
def test_Register_mute():
    from .sgr import Sgr
    from .rgb_fg import RgbFg

    class DummyRendertype(RenderType):
        ANSI = "This is a dummy Rendertype."
        args = ()

    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.bold_red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert fg.red == "\x1b[38;2;255;0;0m"
    assert fg.red.rules == (RgbFg(255, 0, 0),)
    assert fg.bold_red == "\x1b[38;2;255;0;0m\x1b[1m"

# Generated at 2022-06-21 23:56:57.115953
# Unit test for method __call__ of class Register
def test_Register___call__():
    r1: Register = Register()

    class R1(RenderType):
        def ansi(self, i: int) -> str:
            return f"\033[3{i}m"

    def _render(i: int) -> str:
        return f"\033[38;2;{i};{i};{i}m"

    r1.set_renderfunc(R1, _render)

    r1.a = Style(R1(42))
    assert r1.a == "\033[3;42m"
    assert r1.a == r1("a")
    assert r1(42) == "\033[38;2;42;42;42m"
    assert r1(10, 42, 255) == "\033[38;2;10;42;255m"

# Generated at 2022-06-21 23:57:09.436547
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg

    # Muting with fg
    r = fg(255, 255, 0)
    assert r == '\x1b[38;2;255;255;0m'
    fg.mute()
    r = fg(255, 255, 0)
    assert r == ''

    # Unmute fg
    fg.unmute()
    r = fg(255, 255, 0)
    assert r == '\x1b[38;2;255;255;0m'

    # Muting with fg.orange
    r = fg.orange
    assert r == '\x1b[38;2;255;165;0m'
    fg.mute()
    r = fg.orange
    assert r == ''
    fg.unmute()

# Generated at 2022-06-21 23:57:20.462289
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.set_eightbit_call(RenderType)

    def r1(x):
        return str(x)

    r.set_renderfunc(RenderType, r1)
    assert r(1) == "1"
    assert r(2) == "2"
    assert r(3) == "3"
    assert r(4) == "4"
    assert r(5) == "5"
    assert r(6) == "6"
    assert r(7) == "7"
    assert r(8) == "8"
    assert r(9) == "9"

    # Unit test for method mute() of class Register
    def test_Register_mute():

        r = Register()
        r.set_eightbit_call(RenderType)


# Generated at 2022-06-21 23:57:31.413310
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.blue = Style(RgbFg(0, 99, 255))

    r1 = r.copy()

    assert r1.blue == "\x1b[38;2;0;99;255m"

    r2 = Register()
    r2.btn = Style(r.blue, RgbBg(1, 2, 3))

    r3 = r2.copy()

    assert r3.blue == "\x1b[38;2;0;99;255m"
    assert r3.btn == "\x1b[38;2;0;99;255m\x1b[48;2;1;2;3m"
    assert not r3.is_muted



# Generated at 2022-06-21 23:57:43.290980
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RenderType

    class RgbFg(RenderType):
        TYPE = "RGB"
        ARGS = "r g b"

    class Sgr(RenderType):
        TYPE = "SGR"
        ARGS = "args"

    class RgbBg(RenderType):
        TYPE = "RGB"
        ARGS = "r g b"

    def render_any(*args):
        return "".join(str(arg) for arg in args)


    reg = Register()
    reg.renderfuncs = {RgbFg: render_any, Sgr: render_any, RgbBg: render_any}
    reg.rgb_call = lambda *args: args
    reg.set_rgb_call(RgbBg)


# Generated at 2022-06-21 23:57:44.218328
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r


# Generated at 2022-06-21 23:57:54.041611
# Unit test for method unmute of class Register
def test_Register_unmute():
    import sty
    import sys

    print("Test unmute")
    print("-" * 30)

    class RGB(RenderType):
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b

    c1 = sty.fg(sty.rgb(49, 90, 143))
    c2 = sty.bg(sty.rgb(255, 92, 101))
    c3 = sty.fg(sty.rgb(255, 255, 255))

    colors = sty.stylize("{c1}Hello {c2}World! {c3}Testing.", colors={
        "c1": c1,
        "c2": c2,
        "c3": c3
    })

    print(colors)

    sty.fg.m

# Generated at 2022-06-21 23:58:00.739552
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register
    """

    class TestRegister(Register):
        """
        Register-Object with additional attribute x.
        """

    # Create Testregister r1.
    r1 = TestRegister()
    r1.x = 42

    # Make and check copy of r1.
    r2 = r1.copy()

    assert r1.x == r2.x
    assert r1 != r2

# Test method mute of class Register

# Generated at 2022-06-21 23:58:10.943492
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Define test environment.
    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class Rgb(RenderType):
        pass

    class Fg(RenderType):
        pass

    class Bg(RenderType):
        pass

    # Define new register-object.
    register = Register()

    def eightbit_fg_call(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    def eightbit_bg_call(x: int) -> str:
        return f"\x1b[48;5;{x}m"

    def rgb_fg_call(r: int, g: int, b: int) -> str:
        return f

# Generated at 2022-06-21 23:58:18.391480
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbBg(1, 2, 3), Sgr(1))
    assert isinstance(s, Style)



# Generated at 2022-06-21 23:58:28.613420
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Test that eightbit_call gets set correctly.
    class RenderTypeA(RenderType):
        pass

    class RenderTypeB(RenderType):
        pass

    def render_A(**kwargs) -> str:
        return "1"

    def render_B(**kwargs) -> str:
        return "2"

    register = Register()

    register.set_renderfunc(RenderTypeA, render_A)
    register.set_renderfunc(RenderTypeB, render_B)

    register.set_eightbit_call(RenderTypeA)
    assert register.eightbit_call == render_A
    assert register(17) == "1"

    register.set_eightbit_call(RenderTypeB)
    assert register.eightbit_call == render_B
    assert register(17) == "2"


#

# Generated at 2022-06-21 23:58:36.968746
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # TODO: This should go into a unit testfile
    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    # test object
    red = Style(RgbFg(255, 0, 0))

    # create register
    register = Register()

    # mock renderfuncs
    register.set_renderfunc(RgbFg, lambda x, y, z, r=False: f"{x},{y},{z},{r}")
    register.set_renderfunc(RgbBg, lambda x, y, z, r=False: f"bg-{x},{y},{z},{r}")

    # set eightbit call
    register.set_eightbit_call(RgbFg)

    # check if new 8bit call is set
   

# Generated at 2022-06-21 23:58:42.269809
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, EightbitFg

    # Pre
    def renderfunc1(x: int) -> str:
        return f"{x}"

    def renderfunc2(x: int) -> str:
        return f"{x*2}"

    reg = Register()
    reg.set_renderfunc(EightbitFg, renderfunc1)
    reg.set_renderfunc(RgbFg, renderfunc2)

    reg.set_eightbit_call(EightbitFg)

    # Execute
    s = reg.eightbit_call(42)

    # Post
    assert s == "42"



# Generated at 2022-06-21 23:58:47.191731
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Setup
    class Sgr(RenderType):
        args: NamedTuple

    class RgbFg(RenderType):
        args: NamedTuple

    # ---
    r = Register()
    r.set_renderfunc(Sgr, lambda x: "sgr{x}".format(x=x))
    r.set_renderfunc(RgbFg, lambda r, g, b: "rgb{r}{g}{b}".format(r=r, g=g, b=b))
    # ---

    # Action
    r.test_rule = Style(Sgr(1), RgbFg(10, 20, 30))
    # ---

    # Assertion
    assert r.test_rule == "sgr1rgb102030"

# Generated at 2022-06-21 23:58:49.587754
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-21 23:58:52.461134
# Unit test for method __new__ of class Style
def test_Style___new__():

    s1 = Style(value="\x1b[1m")

    assert isinstance(s1, str)
    assert isinstance(s1, Style)
    assert str(s1) == "\x1b[1m"
    assert s1.rules == tuple()



# Generated at 2022-06-21 23:59:02.223178
# Unit test for method copy of class Register
def test_Register_copy():
    import pytest

    def test_correct_copy():
        """
        Test if the deepcopy contains the right data.
        """
        original = Register()

        # Set some arbitrary data.
        original.renderfuncs = {"foo": "bar"}
        original.is_muted = True
        original.rs = Style("rs")
        original.rgb_call = lambda r, g, b: 42
        original.eightbit_call = lambda x: 42

        copy = original.copy()

        assert copy.renderfuncs == {"foo": "bar"}
        assert copy.is_muted == True
        assert copy.rs == Style("rs")
        assert copy.rgb_call(10, 20, 30) == 42
        assert copy.eightbit_call(1) == 42

        # The two objects should not be the same.


# Generated at 2022-06-21 23:59:04.224244
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from . import eightbit
    from . import fg
    assert hasattr(fg.as_namedtuple(), "black")


# Generated at 2022-06-21 23:59:15.465482
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            setattr(self, "red", Style(fg.red))
            setattr(self, "yellow", Style(fg.yellow))
            setattr(self, "blue", Style(fg.blue))
            setattr(self, "green", Style(fg.green))

    r = MyRegister()
    d = r.as_dict()
    assert isinstance(d, dict)
    assert d["red"] == "\x1b[38;2;255;0;0m"
    assert d["yellow"] == "\x1b[38;2;255;255;0m"
    assert d["blue"] == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-21 23:59:34.398478
# Unit test for method __new__ of class Style
def test_Style___new__():
    class Rgb(RenderType):
        def __init__(self, r, g, b):
            self.r = r
            self.g = g
            self.b = b
            self.args = [r, g, b]

    def f1(r, g ,b):
        return "hi"

    r = Register()
    r.set_renderfunc(Rgb, f1)

    s = Style(
        Rgb(1,2,3),
        Style(
            Rgb(4,5,6),
            "yes")
    )

    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "hihi"
    assert s.rules == (Rgb(1,2,3), Rgb(4,5,6), "yes")


# Generated at 2022-06-21 23:59:45.570599
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        SGR_CODE = 38
        as_str = "Color"

    class RgbBg(RenderType):
        SGR_CODE = 48
        as_str = "BgColor"

    class Sgr(RenderType):
        SGR_CODE = 0
        as_str = "NoAction"

    class RgbEf(RenderType):
        SGR_CODE = 0
        as_str = "Ef"

    rgb_fg_renderfn: Callable = lambda r, g, b: f"{RgbFg(r,g,b)}{Sgr(0)}"
    rgb_bg_renderfn: Callable = lambda r, g, b: f"{RgbBg(r,g,b)}{Sgr(0)}"
   

# Generated at 2022-06-21 23:59:49.794855
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from sty.rendertype import RgbFg

    r = Register()

    r.set_renderfunc(RgbFg, lambda x, y, z: "OK")

    r.set_eightbit_call(RgbFg)

    assert r.eightbit_call(1, 3, 3) == "OK"

# Generated at 2022-06-21 23:59:57.167439
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        """
        Rendertype for SGR commands.
        """

        def __init__(self, *args):
            super().__init__(args)


    def renderfunc1(arg1, arg2):
        return f"\x1b[{arg1};{arg2}m"

    r1 = Register()
    r1.set_renderfunc(Sgr, renderfunc1)

    r2 = Register()
    r2.set_renderfunc(Sgr, renderfunc1)

    assert r1.renderfuncs[Sgr] == r2.renderfuncs[Sgr]

    def renderfunc2(arg1, arg2):
        return f"\x1b[{arg1};{arg2}m"


# Generated at 2022-06-22 00:00:09.327084
# Unit test for constructor of class Style
def test_Style():
    style_rule_list = [RgbFg(1,5,10), Sgr(1)]
    style = Style(*style_rule_list)

    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style.rules == style_rule_list
    assert str(style) == '\x1b[38;2;1;5;10m\x1b[1m'

# Create empty Register() object.
none = Register()

# Set up function calls
from .rgb import RgbFg, RgbBg, RgbEf, RgbRs
from .eightbit import EightbitFg, EightbitBg, EightbitEf, EightbitRs
from .sgr import SgrFg, SgrBg, SgrEf, SgrRs

# Generated at 2022-06-22 00:00:18.723408
# Unit test for method copy of class Register
def test_Register_copy():

    # Create test register
    rg = Register()

    setattr(rg, "foo", Style(value="\x1b[42m"))

    setattr(rg, "bar", Style(value="\x1b[43m"))

    # Make a copy of the register
    rg_c = rg.copy()

    # Check if attributes are the same
    assert rg_c.foo == rg.foo
    assert rg_c.bar == rg.bar

    # Check if elementwise copying worked
    assert id(rg_c.foo) != id(rg.foo)
    assert id(rg_c.bar) != id(rg.bar)

# Generated at 2022-06-22 00:00:27.060932
# Unit test for method unmute of class Register
def test_Register_unmute():

    from sty import RenderType

    fg = Register()

    fg.set_renderfunc(RenderType.SGR, lambda x: "MOCK")

    fg.red = Style(Sgr(255))

    assert fg.red == "\x1b[38;2;255;0;0mMOCK"

    fg.mute()

    assert fg.red == ""

    fg.unmute()

    assert fg.red == "\x1b[38;2;255;0;0mMOCK"


# Generated at 2022-06-22 00:00:31.831381
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    register = Register()
    register.set_eightbit_call(RenderType)

    # Check if function object has been added to the object.
    func_obj = register.eightbit_call

    # TODO: Add more checks.
    assert func_obj is not None


# Generated at 2022-06-22 00:00:33.172113
# Unit test for constructor of class Register
def test_Register():
    assert Register().is_muted == False



# Generated at 2022-06-22 00:00:43.998931
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr
    from .renderfunc import render_sgr

    sgr = Sgr(1)
    renderfunc = "not_a_callable"
    reg = Register()

    reg.set_renderfunc(Sgr, renderfunc)
    assert reg.renderfuncs[Sgr] == renderfunc

    reg.set_renderfunc(Sgr, render_sgr)
    assert reg.renderfuncs[Sgr] == render_sgr

    assert reg.blink_bold == Style(sgr)
    assert reg.blink_bold == "\x1b[1m"

    reg.set_renderfunc(Sgr, lambda *args, **kwargs: "")
    assert reg.blink_bold == Style(sgr)
    assert reg.blink_bold == ""



# Generated at 2022-06-22 00:01:03.789194
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    attr_dic = {
        "foo": Style("foocode"),
        "bar": Style("barcode"),
        "spam": Style("spamcode")
    }

    reg = Register()

    for name in attr_dic:
        setattr(reg, name, attr_dic[name])

    StyleClass = reg.as_namedtuple()

    assert isinstance(StyleClass, namedtuple)

    for name in attr_dic:
        assert isinstance(getattr(StyleClass, name), str)


# test_Register_as_namedtuple()

# Generated at 2022-06-22 00:01:04.631731
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(), Style)


# Generated at 2022-06-22 00:01:11.243075
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        def __init__(self):

            super().__init__()

            # Setup renderfuncs for Rgb- and Eightbit calls.
            self.set_rgb_call(RenderType.Rgb)
            self.set_eightbit_call(RenderType.Eightbit)

    r = TestRegister()

    r.eightbit_call = lambda x: str(x)
    r.rgb_call = lambda r, g, b: str(r) + str(g) + str(b)

    # Test eightbit call.
    assert r(89) == "89"

    # Test rgb call.
    assert r(10, 42, 255) == "1024255"

    # Test attribute call.
    r.my_style = Style("my-style")
    assert r("my_style")

# Generated at 2022-06-22 00:01:19.878432
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        fg = 0

    class TestRegister(Register):
        pass

    test_register = TestRegister()

    # Add render function to render-type.
    test_register.set_renderfunc(TestRenderType, lambda value: str(value))

    test_register.set_eightbit_call(TestRenderType)

    assert test_register(100) == "100"



# Generated at 2022-06-22 00:01:24.018239
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r1 = Register()
    r1.black = Style("black")
    r1.white = Style("white")

    actual = r1.as_namedtuple()
    expected = namedtuple("StyleRegister", ["black", "white"])("black", "white")
    assert actual == expected



# Generated at 2022-06-22 00:01:27.556320
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .sty import Register

    class reg(Register):
        r = 30
        g = 40
        b = 50

    d = reg().as_dict()
    assert d['r'] == '30'
    assert d['g'] == '40'
    assert d['b'] == '50'


# Generated at 2022-06-22 00:01:33.919951
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from .render import rgb24bit_ansi

    r = Register()

    r.set_renderfunc(RgbFg, rgb24bit_ansi)
    r.set_rgb_call(RgbFg)
    r.blue = Style(RgbFg(0, 0, 255))

    assert r.blue == r(0, 0, 255)

# Generated at 2022-06-22 00:01:44.164635
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class TestRegister(Register):
        pass

    renderfuncs = {
        RenderType: lambda *a, **kw: "",
        int: lambda x: f"setattr:int: {x}",
        float: lambda x: f"setattr:float: {x}",
    }

    tr = TestRegister()

    tr.renderfuncs = renderfuncs

    class TestRenderType(RenderType):
        pass

    tr.set_renderfunc(TestRenderType, lambda x, y, z: f"setattr:TestRenderType: {x} {y} {z}")

    tr.new_style = Style(TestRenderType(1, 2, 3), 42)

    assert tr.new_style == "setattr:TestRenderType: 1 2 3setattr:int: 42"


# Generated at 2022-06-22 00:01:53.992403
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    This unit test relies on the class defintions and global settings of the source file
    in which this function is defined.
    """
    from .rendertype import Sgr, RgbFg
    from .styles import StyleFactory, style_factory

    sf = StyleFactory(fg=fg, bg=bg, ef=ef, rs=rs)
    sf.add_style("apple", fg=fg(1), bg=bg(2), ef=ef(3))

    sf.apple.as_dict() == {"apple": "\x1b[38;5;1m\x1b[48;5;2m\x1b[3m"}

    sf_ = style_factory()

# Generated at 2022-06-22 00:02:01.796095
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """Unit test for method set_renderfunc of class Register."""
    from .rendertype import SgrBold as FgBold

    def render_func1(x: int) -> str:
        return "rendered with render_func1"

    def render_func2(x: int, y: int) -> str:
        return "rendered with render_func2"

    # Test Register-object for test.
    r = Register()
    r.set_renderfunc(FgBold, render_func1)

    # Test result and that no error is raised.
    assert r.renderfuncs[FgBold] == render_func1

    r.set_renderfunc(FgBold, render_func2)

    # Test result and that no error is raised.

# Generated at 2022-06-22 00:02:16.568107
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    reg = Register()
    reg.set_eightbit_call(RenderType)
    assert reg.eightbit_call(5) == 5



# Generated at 2022-06-22 00:02:24.581399
# Unit test for method copy of class Register
def test_Register_copy():

    # Source object
    r = Register()
    r.red = Style(RgbFg(1, 2, 3))

    # Target object
    t = r.copy()

    assert t.red == r.red
    assert t.red == "\x1b[38;2;1;2;3m"

    # This should have no effect on the target object
    r.red = Style(RgbFg(42, 42, 42))

    assert t.red != r.red
    assert t.red == "\x1b[38;2;1;2;3m"

# Generated at 2022-06-22 00:02:27.706017
# Unit test for method __new__ of class Style
def test_Style___new__():

    class MockedRule:
        def __init__(self, *args, **kwargs):
            pass

    assert Style(MockedRule()).rules[0].__class__.__name__ == 'MockedRule'


# Generated at 2022-06-22 00:02:33.181806
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr, RgbFg, RgbBg

    # Setup
    sgr = Sgr(1)
    rgb_fg = RgbFg(10, 20, 30)
    rgb_bg = RgbBg(40, 50, 60)
    style = Style(sgr, rgb_fg, rgb_bg)
    rules = (sgr, rgb_fg, rgb_bg)

    # Asserting basics
    assert style         # asserts if non-empty
    assert style.rules   # asserts if non-empty
    assert style == style.rules
    assert isinstance(style, Style)



# Generated at 2022-06-22 00:02:35.780903
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    fg = Register()
    # TODO: implement test-case
    assert True



# Generated at 2022-06-22 00:02:39.381206
# Unit test for method copy of class Register
def test_Register_copy():

    register = Register()
    register.set_eightbit_call(lambda x: x)

    assert register.copy() == register



# Generated at 2022-06-22 00:02:44.571734
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Define a mock class to use in the unittest
    class MockRegister(Register):
        def __init__(self):
            # Need to call super init
            super().__init__()

            # Set some attributes
            self.orange = Style("orange", value="faked")
            self.green = Style("green", value="faked")

    # Create an instance of MockRegister
    r = MockRegister()

    # Create the namedtuple
    nt = r.as_namedtuple()
    assert nt.orange == "faked"

# Generated at 2022-06-22 00:02:53.315796
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Define fixture
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.green = Style(RgbFg(42, 90, 255))
            self.blue = Style(Sgr(5), RgbFg(9, 69, 214))
    # Invoke function under test
    reg = MyRegister()
    # Check result
    nt = reg.as_namedtuple()
    assert nt.green == "\x1b[38;2;42;90;255m"
    assert nt.blue == "\x1b[5m\x1b[38;2;9;69;214m"

# Generated at 2022-06-22 00:02:57.807638
# Unit test for method copy of class Register
def test_Register_copy():
    fg = Register()
    fg.one = Style(RgbFg(1, 2, 3))

    fg_copy = fg.copy()

    assert fg is not fg_copy
    assert fg.one is not fg_copy.one
    assert fg.one == fg_copy.one



# Generated at 2022-06-22 00:03:04.877318
# Unit test for method __new__ of class Style
def test_Style___new__():

    class TestStyle(Style):
        pass

    assert TestStyle("test") == "test"
    assert TestStyle(value="test") == "test"
    assert TestStyle(1, 2, 3, value=1) == 1

    assert isinstance(TestStyle("test"), TestStyle)
    assert isinstance(TestStyle(value="test"), TestStyle)
    assert isinstance(TestStyle(1, 2, 3, value=1), TestStyle)

# Generated at 2022-06-22 00:03:29.104801
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class RgbFg(RenderType):
        """
        Simply return ``'38;2;'``
        """
        def __str__(self):
            return "38;2;"

    class Sgr(RenderType):
        """
        Simply return ``'26m'``
        """
        def __str__(self):
            return "26m"

    # Create register object
    register = Register()

    # Define render function for RenderType RgbFg
    def render_RgbFg(*args):
        return "38;2;{};{};{}m".format(*args)

    # Define render function for RenderType Sgr
    def render_Sgr(*args):
        return "1;{}m".format(*args)

    # Save render functions for RgbFg and Sgr in register
    register

# Generated at 2022-06-22 00:03:35.480755
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from . import ef, fg
    from .rules import RgbFg

    red = Style(RgbFg(255, 0, 0))

    fg.xyz = red
    assert getattr(fg, "xyz") == red
    assert str(fg.xyz) == "\x1b[38;2;255;0;0m"

    delattr(fg, "xyz")
    ef.xyz = red
    assert getattr(ef, "xyz") == red
    assert str(ef.xyz) == "\x1b[38;2;255;0;0m"

    delattr(ef, "xyz")

# Generated at 2022-06-22 00:03:46.005133
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    rgbf = RenderType(3, "2;{};{};{}m")
    rgbb = RenderType(4, "2;{};{};{}m")
    bold = RenderType(1)
    underlined = RenderType(4)
    fg = Register()
    fg.set_renderfunc(rgbf, lambda r, g, b: f"\x1b[38;{r};{g};{b}m")
    fg.set_renderfunc(rgbb, lambda r, g, b: f"\x1b[48;{r};{g};{b}m")
    fg.set_renderfunc(bold, lambda: f"\x1b[1m")
    fg.set_renderfunc(underlined, lambda: f"\x1b[4m")
    f

# Generated at 2022-06-22 00:03:54.140000
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class X(RenderType):
        pass

    class Y(RenderType):
        pass

    f1 = lambda x: 1 / x
    f2 = lambda x: x * 2

    r1 = Register()
    r1.set_renderfunc(X, f1)
    assert r1.renderfuncs[X] == f1

    r2 = Register()
    r2.set_renderfunc(X, f1)
    r2.set_renderfunc(Y, f2)

    assert r2.renderfuncs[X] == f1
    assert r2.renderfuncs[Y] == f2



# Generated at 2022-06-22 00:04:03.095125
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import RenderType

    class RenderType1(RenderType):
        pass

    class RenderType2(RenderType):
        pass

    class RenderType3(RenderType):
        pass

    render_rule1: Dict[Type[RenderType], Callable] = {}
    render_rule2: Dict[Type[RenderType], Callable] = {
        RenderType1: lambda: "1",
        RenderType2: lambda: "2",
        RenderType3: lambda: "3",
    }

    # Check if renderfuncs is empty by default.
    reg1: Register = Register()
    assert not reg1.renderfuncs
    assert reg1.renderfuncs == render_rule1

    # Check if set_renderfunc works as expected.
    reg2: Register = Register()
    reg2.set_render

# Generated at 2022-06-22 00:04:05.533643
# Unit test for method unmute of class Register
def test_Register_unmute():

    import termcolor  # type: ignore

    r = Register()
    r.__dict__.update(termcolor.__dict__)

    termcolor.rs.unmute()

    assert str(termcolor.rs) == "\x1b[0m"

# Generated at 2022-06-22 00:04:10.832271
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test for method ``__call__`` of class Register.
    """
    from .rendertype import Eightbit, Rgb

    def testfunc(*args, **kwargs):
        return "Test"

    register = Register()
    register.set_renderfunc(Eightbit, func=testfunc)
    register.set_renderfunc(Rgb, func=testfunc)
    register.set_eightbit_call(Eightbit)
    register.set_rgb_call(Rgb)

    assert register(42) == "Test"
    assert register(1, 2, 3) == "Test"
    assert register(42, muted=True) == ""
    assert register(1, 2, 3, muted=True) == ""

# Generated at 2022-06-22 00:04:21.766651
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if we can deepcopy a register object.
    """

    # Create register object
    r = Register()

    # Create style rules and set as attribute
    rules1 = [RgbFg(10,20,30), Sgr(1)]
    r.test_style = Style(*rules1)

    # Set render functions
    renderfuncs = {RgbFg:lambda r,g,b: r+g+b, Sgr:lambda *args: args[0]}
    r.set_renderfunc(RgbFg, renderfuncs[RgbFg])
    r.set_renderfunc(Sgr, renderfuncs[Sgr])

    # Set renderfunc for 8bit calls
    r.set_eightbit_call(RgbFg)

# Generated at 2022-06-22 00:04:31.945739
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class Foo(RenderType):
        pass

    class Bar(RenderType):
        pass

    def bar_func(bar: Bar) -> str:
        return "This is the renderfunc for Bar."

    def foo_func(foo: Foo) -> str:
        return "This is the renderfunc for Foo."

    reg = Register()
    reg.set_renderfunc(type(Foo()), foo_func)
    reg.set_renderfunc(type(Bar()), bar_func)

    st1 = Style(Foo())
    st2 = Style(Bar())

    reg.foo = st1
    reg.bar = st2

    # assert 'foo' in dir(reg)
    assert "This is the renderfunc for Foo." == reg.foo
    assert "This is the renderfunc for Bar." == reg.bar

    # Replace

# Generated at 2022-06-22 00:04:43.288247
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    Reg1 = Register()
    Reg1.red = Style('\x1b[38;2;255;0;0m')
    Reg1.red_bold = Style('\x1b[38;2;255;0;0m', '\x1b[1m')
    Reg1.green = Style('\x1b[38;2;0;128;0m')
    Reg1.white = Style('\x1b[38;2;255;255;255m')

    nt = Reg1.as_namedtuple()
    assert nt.red == '\x1b[38;2;255;0;0m'
    assert nt.red_bold == '\x1b[38;2;255;0;0m\x1b[1m'