

# Generated at 2022-06-21 23:55:26.341932
# Unit test for constructor of class Style
def test_Style():

    rules: List[StylingRule] = [
        "Hello",
        Style("World", "!"),
    ]
    style1 = Style(*rules)

    assert isinstance(style1, Style)
    assert isinstance(style1, str)
    assert style1.rules == ("Hello", Style("World", "!"))
    assert str(style1) == "HelloWorld!"


# Generated at 2022-06-21 23:55:38.117258
# Unit test for method __call__ of class Register
def test_Register___call__():

    from sty import fg, bg

    class C:

        c: Register
        d: str
        f: int

        def __init__(self):
            self.c = Register()
            self.d = fg(42)
            self.f = 42

    c = C()

    assert c.c("blue") == ""
    assert c.c(42) == ""
    assert c.c(10, 42, 255) == ""
    assert c.d == fg(42)
    assert c.f == 42

    c.c.set_renderfunc(RenderType.NONE, lambda: "yay!")

    assert c.c("blue") == "yay!"
    assert c.c(42) == "yay!"
    assert c.c(10, 42, 255) == "yay!"
   

# Generated at 2022-06-21 23:55:41.960290
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class TestRegister(Register):
        _ansi_red = Style(RgbFg(255, 0, 0))

    test_reg = TestRegister()
    assert test_reg.as_dict() == {"_ansi_red": str(test_reg._ansi_red)}

# Generated at 2022-06-21 23:55:50.866806
# Unit test for method __new__ of class Style
def test_Style___new__():

    assert isinstance(Style(), Style)
    assert isinstance(Style(), str)
    assert Style() == ""
    assert Style('red') == ""
    assert Style('red').rules == ('red',)

    assert isinstance(Style('red'), Style)
    assert isinstance(Style('red'), str)
    assert Style('red') == ""
    assert Style('red').rules == ('red',)

    assert isinstance(Style(1), Style)
    assert isinstance(Style(1), str)
    assert Style(1) == ""
    assert Style(1).rules == (1,)

    assert isinstance(Style(1, 2, 3), Style)
    assert isinstance(Style(1, 2, 3), str)
    assert Style(1, 2, 3) == ""

# Generated at 2022-06-21 23:56:02.185806
# Unit test for method copy of class Register
def test_Register_copy():
    # Setup
    r1 = Register()
    r1.set_eightbit_call(RenderType.SgrFg)
    r1.set_rgb_call(RenderType.RgbFg)
    r1.set_renderfunc(RenderType.SgrFg, lambda x: f"\x1b[{x}m")
    r1.set_renderfunc(RenderType.RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r1.test = Style(RenderType.SgrBg(44), RenderType.SgrFg(45))

    # Test
    r2 = r1.copy()

    # Assert
    assert r1.is_muted is r2.is_muted


# Generated at 2022-06-21 23:56:12.132111
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import Sgr, RgbFg, RgbBg

    class MyRegister(Register):
        pass

    r = MyRegister()

    r.reset = Style(Sgr(0))

    r.blue = Style(RgbFg(0, 0, 255))
    r.bg_blue = Style(RgbBg(0, 0, 255))

    assert str(r.blue) == r.blue  # Test without rgb-call-overwrite
    assert str(r.bg_blue) == r.bg_blue  # Test without rgb-call-overwrite

    r.set_rgb_call(RgbFg)
    r.set_rgb_call(RgbBg)

    assert str(r.blue) == r(0, 0, 255)  # Test with rgb-call-overwrite

# Generated at 2022-06-21 23:56:21.543316
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    renderfunc: Callable = lambda x: x
    renderfuncs: Renderfuncs = {
        RenderType: renderfunc
    }

    # Create register
    r = Register()
    r.set_renderfunc(RenderType, renderfunc)

    # Test 1
    r.simple = Style(RenderType(1))
    assert isinstance(r.simple, Style)
    assert str(r.simple) == "1"

    # Test 2
    r.nested = Style(Style(RenderType(2)))
    assert isinstance(r.nested, Style)
    assert str(r.nested) == "2"



# Generated at 2022-06-21 23:56:24.440794
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.red = Style(RgbFg(255, 0, 0))
    assert register.as_dict() == {"red": "\x1b[38;2;255;0;0m"}



# Generated at 2022-06-21 23:56:30.996779
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Create test object
    r = Register()

    # Create rendertype and renderfunc
    class T1(RenderType): pass

    def rf1(*args, **kwargs):
        return "1"

    # Save renderfunc in test object
    r.renderfuncs.update({T1: rf1})

    # Set rendertype for 8bit calls
    r.set_eightbit_call(T1)

    # Call test object and check result
    assert r(42) == "1"



# Generated at 2022-06-21 23:56:42.342001
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .rendertype import RenderType, Sgr, Xterm

    class Rgb(RenderType):
        code = "38;2"
        args = ("r", "g", "b")
        base = Xterm.base

        def as_tuple(self):
            return tuple(map(str, self.args))

        def render(self):
            return f"\x1b[{self.code};{';'.join(self.as_tuple())}m"

    class Bold(RenderType):
        code = Sgr.bold
        args = ()
        base = Xterm.base

        def as_tuple(self):
            return ()

        def render(self):
            return f"\x1b[{self.code}m"

    fg = Register()
    fg.eightbit_call = Rgb

# Generated at 2022-06-21 23:56:56.348969
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from build import bg, fg, ef, rs, s

    class MockRenderType:
        """
        Mock class for RenderType.
        As long as the __init__ always returns the same string and instace of MockRenderType
        is not used as a base-class of a Style, we can use this as a replacement for Rendertype
        for unit testing.
        """
        def __init__(self, *args, **kwargs):
            return "MOCK_RENDER_TYPE"

    fg.mock_type1 = Style(MockRenderType(3), s(1))
    assert getattr(fg, "mock_type1") == "MOCK_RENDER_TYPE\x1b[1m"


# Generated at 2022-06-21 23:57:06.983297
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class TestRenderTypeA(RenderType):
        code = 42

    class TestRenderTypeB(RenderType):
        code = 100

    class TestRegA(Register):
        pass

    class TestRegC(Register):
        pass

    TestRegA.set_renderfunc(TestRenderTypeA, lambda x: f"\x1b[{x}")

    TestRegC.set_renderfunc(TestRenderTypeB, lambda x: f"\x1b[{x}")

    TestRegA.set_rgb_call(TestRenderTypeB)

    assert TestRegA.rgb_call(144) == "\x1b[100"
    assert TestRegC.rgb_call(144) == "\x1b[42"

# Generated at 2022-06-21 23:57:15.455339
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class DummyRenderType(RenderType):
        def __repr__(self) -> str:
            return str(self.args)

    def dummy_renderfunc(*args) -> str:
        return str(args)

    # Setup a dummy register.
    r = Register()
    r.renderfuncs[DummyRenderType] = dummy_renderfunc

    c = DummyRenderType(1, 2)
    s = Style(c)

    r.new_style = s

    assert getattr(r, "new_style").startswith("(1, 2)")



# Generated at 2022-06-21 23:57:20.461570
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from sty import fg, bg, Style

    class Foo(Register):
        bar = Style(fg.red + bg.blue)
        foobar = Style(bg.yellow)

    f = Foo()
    assert f.bar == "foo"
    assert f.as_namedtuple().bar == "foo"


# Generated at 2022-06-21 23:57:27.252650
# Unit test for method mute of class Register
def test_Register_mute():
    import sty
    
    sty.register_theme('test', {'test': sty.fg8(4)})
    sty.set_theme('test')
    sty.fg.mute()
    sty.set_theme('default')
    
    sty.register_theme('test2', {'test2': sty.fg8(4)})
    sty.set_theme('test2')
    sty.set_theme('default')


# Generated at 2022-06-21 23:57:34.653458
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .render import Sty
    from .types import Sgr

    sty = Sty()

    sty.register.fg.set_renderfunc(Sgr, lambda x: "")

    sty.register.fg.blue = Style(Sgr(1))

    sty.register.fg.mute()

    color = sty.register.fg.blue
    assert color == ""

    sty.register.fg.unmute()

    color = sty.register.fg.blue
    assert color == "\x1b[1m"


# Generated at 2022-06-21 23:57:42.877503
# Unit test for method unmute of class Register
def test_Register_unmute():
    # arrange
    reg = Register()
    reg.red = Style(RgbFg(1, 0, 0))
    assert str(reg.red) == "\x1b[38;2;1;0;0m"
    # act
    reg.mute()
    assert str(reg.red) == ""
    reg.unmute()
    # assert
    assert str(reg.red) == "\x1b[38;2;1;0;0m"

# Generated at 2022-06-21 23:57:52.862118
# Unit test for constructor of class Register
def test_Register():
    """
    Test if creation of register-object works properly.
    """
    # Creation + add attributes
    reg = Register()
    reg.blue = "blue"
    reg.red = "red"
    reg.green = "green"

    # Check if attributes exist
    assert "blue" in dir(reg)
    assert "red" in dir(reg)
    assert "green" in dir(reg)

    # Check if attributes are accessible
    assert getattr(reg, "blue") == "blue"
    assert getattr(reg, "red") == "red"
    assert getattr(reg, "green") == "green"

    # Check if attributes are writable.
    setattr(reg, "red", "orange")
    assert getattr(reg, "red") == "orange"

    return True



# Generated at 2022-06-21 23:57:55.785228
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Simple test that ensures that the method `Register.as_dict()` works correctly.
    """
    foo = Register()
    setattr(foo, "bar", Style(value="ABC"))
    assert foo.as_dict() == dict(bar="ABC")

# Generated at 2022-06-21 23:57:58.298364
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)

# Generated at 2022-06-21 23:58:08.525446
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    d1 = dict(
        a="\x1b[38;5;16m",
        b="\x1b[38;5;17m",
        c="\x1b[38;5;18m",
    )

    r1 = Register()
    r1.a = Style(d1["a"])
    r1.b = Style(d1["b"])
    r1.c = Style(d1["c"])

    d2 = r1.as_dict()
    assert d1 == d2


# Generated at 2022-06-21 23:58:18.789540
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg():
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    class Sgr():
        def __init__(self):
            self.args = ()

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(sgr: int) -> str:
        return f"\x1b[{sgr}m"

    r = Register()
    r.set_renderfunc(RgbFg, render_rgb)
    r.set_renderfunc(Sgr, render_sgr)

    # Create a style that ist rendered with rgb-render

# Generated at 2022-06-21 23:58:28.698150
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """Test Register.__setattr__ method."""
    class R(RenderType, NamedTuple):
        args: Tuple[int, int]
    def rf1(*args, **kwargs):
        return "rf1"
    def rf2(*args, **kwargs):
        return "rf2"
    reg = Register()
    reg.set_renderfunc(R, rf1)
    reg.set_eightbit_call(R)
    reg.set_rgb_call(R)

    styreg = Register()
    styreg.set_renderfunc(R, rf2)
    styreg.set_eightbit_call(R)
    styreg.set_rgb_call(R)

    sty = Style(R(1,2), R(3,4), R(5,6))
   

# Generated at 2022-06-21 23:58:31.988336
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    r = Register()
    r.set_renderfunc(RenderType, lambda *args: "a")
    r.set_renderfunc(RenderType, lambda *args: "b")

    assert r.renderfuncs[RenderType]() == "b"

# Generated at 2022-06-21 23:58:38.138854
# Unit test for method copy of class Register
def test_Register_copy():

    from .builder import Builder
    import sys

    builder = Builder(8, sys.stderr)
    fg = builder.fg
    bg = builder.bg
    ef = builder.ef
    rs = builder.rs

    fg_red = fg.red

    fg_copy = fg.copy()

    assert fg_red in fg_copy.as_dict().values()
    fg_copy.red = fg_copy.green
    assert fg_red not in fg_copy.as_dict().values()
    assert fg_red in fg.as_dict().values()



# Generated at 2022-06-21 23:58:40.591349
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    def func(index):
        pass

    rf = Register()
    rf.set_eightbit_call(RenderType)
    assert rf.eightbit_call == func



# Generated at 2022-06-21 23:58:42.960620
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    s = Register()
    d = s.as_dict()
    nt = namedtuple("StyleRegister", d.keys())(*d.values())
    assert nt == s.as_namedtuple()

# Generated at 2022-06-21 23:58:49.440484
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        num = 38

        def __init__(self, r, g, b):
            self.args = (r, g, b)

    r1 = Register()
    r1.set_eightbit_call(RgbFg)
    r1.set_rgb_call(RgbFg)

    r1.red = Style(RgbFg(255, 0, 0))
    assert r1.red == "\x1b[38;2;255;0;0m"
    assert r1.is_muted == False

    r1.mute()
    r1.red = Style(RgbFg(255, 0, 0))
    assert r1.red == ""
    assert r1.is_muted == True

    r1.unmute()


# Generated at 2022-06-21 23:58:58.847718
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    
    from .sgr import Sgr
    from .rgb import RgbFg, RgbBg

    class Styrenderer:

        def __init__(self):

            def sgr_renderfunc(arg):
                return "\x1b[{}m".format(arg)

            def rgb_renderfunc(r, g, b):
                return "\x1b[38;2;{};{};{}m".format(r, g, b)

            self.fg = Register()
            self.fg.set_renderfunc(Sgr, sgr_renderfunc)
            self.fg.set_renderfunc(RgbFg, rgb_renderfunc)

            self.bg = Register()
            self.bg.set_renderfunc(Sgr, sgr_renderfunc)

# Generated at 2022-06-21 23:59:07.898361
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertypes import RgbFg
    from .rendertypes import RgbBg

    rgbfg = RgbFg(1, 1, 1, 10)

    style = Style(rgbfg)
    r = Register()
    r.asdf = style
    assert isinstance(r.asdf, Style)

    r1 = Register()
    r1.set_renderfunc(RgbFg, lambda r, g, b: "f")
    r1.set_renderfunc(RgbBg, lambda r, g, b: "b")
    r1.asdf = Style(rgbfg)
    assert r1.asdf == "f"

    r2 = Register()
    r2.set_renderfunc(RgbFg, lambda r, g, b: "b")
    r2.set_

# Generated at 2022-06-21 23:59:21.086896
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    For example:

        rgb(10, 42, 255)  # This is the default rgb-call.
        fg(10, 42, 255)   # If set, this is the fg-call.

    What is tested:

        1. If the renderfunc of an register is set, it should be used for the
        rgb-call of the register.

        2. The rgb-call of the register does not affect other registers.

    """

    class RgbFg(RenderType):
        rendertype_name = "RgbFg"
        rendertype_func = "\\x1b[38;2;{};{};{}m"

    class RgbBg(RenderType):
        rendertype_name = "RgbBg"

# Generated at 2022-06-21 23:59:31.272917
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RuleTest(RenderType):
        render_type = 10
        format = "Your ANSI sequence: {0}"

        args: NamedTuple

        def __init__(self, name: str) -> None:
            self.args = self.args_class(name=name)

        def render(self) -> str:
            return self.format.format(self.args.name)

    register = Register()
    register.set_renderfunc(RuleTest, RuleTest.render)

    fg_red: Style = Style(RuleTest("fg_red"))
    register.fg_red = fg_red

    assert str(register.fg_red) == "Your ANSI sequence: fg_red"

# Generated at 2022-06-21 23:59:36.283962
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
  register = Register()

  register.black = Style(RgbFg(0,0,0))
  register.red = Style(RgbFg(255,0,0))

  expected_namedtuple = namedtuple("StyleRegister", ["black", "red"])(register.black, register.red)
  assert register.as_namedtuple() == expected_namedtuple

# Generated at 2022-06-21 23:59:44.146556
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test method Register.unmute.
    """
    class SmallRegister(Register):
        def __init__(self):
            super().__init__()
            self.green = Style(RgbFg(13, 42, 17))

    # Create register and verify that it is muted
    reg = SmallRegister()
    reg.is_muted = True
    assert reg.is_muted == True
    assert reg.green == ""

    # Verify that unmute works
    reg.unmute()
    assert len(reg.green) > 0



# Generated at 2022-06-21 23:59:53.700660
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from sty import fg, bg, ef, rs, RgbFg, RgbBg

    fg.set_eightbit_call(RgbFg)
    bg.set_eightbit_call(RgbBg)

    def test_fg_call(eightbit_rendertype: Type[RenderType]) -> bool:
        if fg(1) == eightbit_rendertype(1):
            return True

    def test_bg_call(eightbit_rendertype: Type[RenderType]) -> bool:
        if bg(1) == eightbit_rendertype(1):
            return True

    assert test_fg_call(RgbFg)
    assert test_bg_call(RgbBg)

    # Test other eightbit colors
    assert fg(255) == RgbFg(255)


# Generated at 2022-06-21 23:59:54.380824
# Unit test for method unmute of class Register
def test_Register_unmute():
    pass

# Generated at 2022-06-21 23:59:59.118945
# Unit test for method mute of class Register
def test_Register_mute():
    register = Register()

    register.set_renderfunc(RenderType, lambda x: f"{x}(")

    register.a = Style(RenderType(), RenderType())
    register.b = Style(RenderType(), RenderType())

    assert str(register.a) == "RenderType()(RenderType()("
    assert str(register.b) == "RenderType()(RenderType()("

    register.mute()

    assert str(register.a) == ""
    assert str(register.b) == ""

    register.unmute()

    assert str(register.a) == "RenderType()(RenderType()("
    assert str(register.b) == "RenderType()(RenderType()("


# Generated at 2022-06-22 00:00:04.394069
# Unit test for constructor of class Style
def test_Style():
    s = Style(RgbFg(1, 2, 3))

    assert(isinstance(s, Style))
    assert(isinstance(s, str))
    assert(str(s) == "\x1b[38;2;1;2;3m")



# Generated at 2022-06-22 00:00:06.622022
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(RgbFg(10, 10, 10)), Style)
    assert isinstance(Style(RgbFg(10, 10, 10)), str)
    assert isinstance(Style(RgbFg(10, 10, 10), Sgr(1)), Style)
    assert isinstance(Style(RgbFg(10, 10, 10), Sgr(1)), str)



# Generated at 2022-06-22 00:00:14.678972
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r1 = Register()
    ColorRgb = NamedTuple("ColorRgb", [("r", int), ("g", int), ("b", int)])
    r1.set_renderfunc(ColorRgb, lambda r, g, b: f"<ColorRgb: {r}, {g}, {b}>")
    r1.set_rgb_call(ColorRgb)

    assert r1(42, 255, 0) == "<ColorRgb: 42, 255, 0>"

# Generated at 2022-06-22 00:00:28.085459
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg
    from .sty import fg
    from .constants import RESET

    fg.set_rgb_call(RgbFg)

    assert fg(10, 30, 50) == "\x1b[38;2;10;30;50m"
    assert fg(10, 30, 50, bold=True) == "\x1b[38;2;10;30;50;1m"
    assert fg(10, 30, 50, bold=True) + "Text" + RESET == fg.rgb10_30_50.bold + "Text" + RESET

    fg.set_rgb_call(RgbBg)


# Generated at 2022-06-22 00:00:34.634654
# Unit test for constructor of class Style
def test_Style():
    Style(1, 3, 5)
    Style(1, Style(3, 5))
    Style(Style(1, 3, 5))
    Style(Style(1, Style(3, 5)))
    Style(Style(Style(1, 3, 5)))
    Style(Style(Style(1, Style(3, 5))))

    # Create invalid styles
    try:
        Style()
    except ValueError:
        pass

    try:
        Style(Style(), Style())
    except ValueError:
        pass



# Generated at 2022-06-22 00:00:37.302582
# Unit test for constructor of class Register
def test_Register():
    """
    Test constructor of class Register.
    """
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-22 00:00:46.410603
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        """
        This is a custom Rendertype with a property ``name``.
        """
        name = "rgb-fg"

    class RgbBg(RenderType):
        """
        This is another custom Rendertype with a property ``name``.
        """
        name = "rgb-bg"

    # Define two test functions.
    func1 = lambda *args, **kwargs: "func1_called"
    func2 = lambda *args, **kwargs: "func2_called"

    # Create registers.
    r1 = Register()
    r2 = Register()

    # Set renderfunc for given rendertypes.
    r1.set_renderfunc(RgbFg, func1)
    r2.set_renderfunc(RgbBg, func2)

   

# Generated at 2022-06-22 00:00:49.770073
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Unit test for method as_dict of class Register.
    """
    reg = Register()
    setattr(reg, "a", Style(1))
    setattr(reg, "b", Style(2))

    assert reg.as_dict() == {"a": "1", "b": "2"}



# Generated at 2022-06-22 00:00:59.952526
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Test method mute of class Register.
    """

    # create test-register
    test_register = Register()

    # add two styles to the register
    test_register.red = Style(RgbFg(10, 0, 0))
    test_register.blue = Style(RgbFg(0, 10, 0))

    # assert that the string values of the attributes red and blue are
    # not empty
    assert str(test_register.red)
    assert str(test_register.blue)

    # mute the register
    test_register.mute()

    # assert that the string values of the attributes red and blue are
    # now empty
    assert not str(test_register.red)
    assert not str(test_register.blue)

    # unmute the mutted register
    test_register.unmute

# Generated at 2022-06-22 00:01:04.631629
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.is_muted = True
    r.black = Style(fg(0))
    r.black.value = "foo"

    r2 = Register()
    r2.is_muted = False
    r2.black = Style(fg(0))
    r2.black.value = ""

    r.unmute()
    assert r.black.value == r2.black.value



# Generated at 2022-06-22 00:01:11.261200
# Unit test for method copy of class Register
def test_Register_copy():
    class SomeRegister(Register):
        pass

    rg = SomeRegister()
    rg.n1 = Style(RgbFg(1, 1, 1), Sgr(1))
    rg.n2 = Style(RgbFg(0, 0, 0))

    rg2 = rg.copy()
    rg2.n1 = Style(Sgr(2))
    rg2.n2 = Style(Sgr(4))

    assert str(rg.n1) == "\033[38;2;1;1;1m\033[1m"
    assert str(rg.n2) == "\033[38;2;0;0;0m"

    assert str(rg2.n1) == "\033[2m"
    assert str(rg2.n2) == "\033[4m"

# Generated at 2022-06-22 00:01:20.549030
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import sty

    r = sty.fg.RED
    r2 = sty.bg.LIGHTYELLOW_EX
    reg = sty.Register()
    reg.HELLO = r
    reg.WORLD = r2
    d = reg.as_dict()
    assert d == {'HELLO': '\x1b[38;2;255;0;0m', 'WORLD': '\x1b[48;2;255;255;224m'}



# Generated at 2022-06-22 00:01:30.966117
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import RenderType, RgbFg, RgbBg, ef, rs, Rgb

    class Rgbfg(RenderType):
        alias = (RgbFg.alias, "fgx")
        args = ("r", "g", "b")

    class Rgbbg(RenderType):
        alias = (RgbBg.alias, "bgx")
        args = ("r", "g", "b")

    renderfuncs = {
        Rgbfg: lambda x, y, z: f"\x1b[38;2;{x};{y};{z}m",
        Rgbbg: lambda x, y, z: f"\x1b[48;2;{x};{y};{z}m",
    }

    reg1 = Register()
    reg1.set

# Generated at 2022-06-22 00:01:46.114045
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define a dummy rendertype
    class Dummy(RenderType):
        def __init__(self, *args, **kwargs):
            pass

    # Define a dummy renderfunc
    def dummy(arg: str) -> None:
        return str(arg)

    # Init a Register instance
    r = Register()

    # Set a renderfunc for Dummy rendertype
    r.set_renderfunc(Dummy, dummy)

    # Init a Style instance with Dummy rendertype
    s = Style(Dummy("Hello"))

    # Set s as attribute for r
    setattr(r, "hello", s)

    # Finally, this call should return the string "Hello", since the renderfunc
    # was defined and invoked correctly.
    assert str(getattr(r, "hello")) == "Hello"

# Generated at 2022-06-22 00:01:51.954174
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    fg = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.blue = Style(RgbFg(0, 0, 255))

    assert fg.as_dict() == {'red': '\x1b[38;2;255;0;0m', 'blue': '\x1b[38;2;0;0;255m'}



# Generated at 2022-06-22 00:01:59.966418
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    # Initialize test register with an empty renderfuncs dict
    test_rg = TestRegister()
    assert test_rg.renderfuncs == {}

    def rgb_fg_renderfunc(r, g, b):
        return f"\033[38;2;{r};{g};{b}m"

    def sgr_renderfunc(x):
        return f"\033[{x}m"

    # Add two renderfuncs with set_renderfunc.
    test_rg.set_renderfunc(RgbFg, rgb_fg_renderfunc)
    test_rg.set_renderfunc(Sgr, sgr_renderfunc)

    # Assert that renderfuncs dict was updated correctly. Just for the sake of testing

# Generated at 2022-06-22 00:02:07.258682
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import EightbitFg, TwoBitFg

    register: Register = Register()

    register.eightbit = Style(EightbitFg(15))
    register.twobit = Style(TwoBitFg(10))

    assert str(register.eightbit) == "\x1b[38;5;15m"
    assert str(register.twobit) == "\x1b[38;2;10m"

    def new_renderfunc_eightbit_fg(value: int) -> str:
        return "\x1b[38;5;" + str(value) + "new"

    def new_renderfunc_twobit_fg(value: int) -> str:
        return "\x1b[38;2;" + str(value) + "new"


# Generated at 2022-06-22 00:02:14.901312
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    # Make test object
    register = Register()

    # Define test render-func
    def new_func(*args):
        return "new " + args[0]
    register.set_renderfunc(Sgr, new_func)

    # Create style
    class StylingRules(NamedTuple):
        SGR_01 = Sgr(1)
        SGR_04 = Sgr(4)

    register.new_style = Style(StylingRules.SGR_01, StylingRules.SGR_04)

    assert str(register.new_style) == "new new 1new 4"



# Generated at 2022-06-22 00:02:25.461715
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    # TODO: This test is not working due to dynamic mapping of object attributes.
    """

    # import inspect

    # register = Register()

    # register.red = Style(RgbFg(255, 0, 0), Sgr(1))
    # register.yellow = Style(RgbFg(255,255, 0))

    # assert register.red == "\x1b[38;2;255;0;0m\x1b[1m"
    # assert register.yellow == "\x1b[38;2;255;255;0m"
    # assert register.red.rules == (RgbFg(255,0,0), Sgr(1))

    # assert inspect.getmembers(register)[0] == ("red", "\x1b[38;2;255;0;0m\x1b

# Generated at 2022-06-22 00:02:31.401182
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    f1 = lambda a, b, c: a + b + c
    reg.set_renderfunc(RenderType, f1)
    reg.some_style = Style(RenderType(1, 2, 3))
    assert reg.some_style == "6"
    assert reg.some_style.rules == (RenderType(1, 2, 3),)
    reg.set_renderfunc(RenderType, f1)
    assert reg.some_style.rules == (RenderType(1, 2, 3),)

# Generated at 2022-06-22 00:02:33.356109
# Unit test for constructor of class Register
def test_Register():
    """
    Test constructor of Register.
    """
    r: Register = Register()



# Generated at 2022-06-22 00:02:40.330169
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from . import fg
    d: Dict[str, str] = fg.as_dict()
    assert "white" in d.keys()
    assert d["white"] == "\x1b[38;5;15m"
    assert "black" in d.keys()
    assert d["black"] == "\x1b[38;5;0m"



# Generated at 2022-06-22 00:02:43.856340
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .colorcodes import fg, bg, ef, rs

    s = Style(fg.red,fg.bg.yellow,rs)
    assert isinstance(s, Style) == True
    assert isinstance(s, str) == True
    assert s == "\x1b[31m\x1b[43m\x1b[0m"

# Generated at 2022-06-22 00:03:04.361160
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbBg)

    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255))
    r.bold = Style(Sgr(1))

    assert r(1) == "\x1b[38;2;255;0;0m"  # 8bit foreground call
    assert r(155, 0, 255) == "\x1b[48;2;155;0;255m"
    assert r.red == "\x1b[38;2;255;0;0m"
    assert r.blue == "\x1b[48;2;0;0;255m"

# Generated at 2022-06-22 00:03:10.334843
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class MockType:
        pass

    class MockRegister(Register):
        pass

    # Create a mock register and add a renderfunc
    r = MockRegister()
    r.renderfuncs = {MockType: lambda x: "Mock"}

    # Check that the renderfunc has been added correctly
    assert r.renderfuncs == {MockType: lambda x: "Mock"}

    # Set the new Eightbit-call
    r.set_eightbit_call(MockType)

    # Check if Eightbit-call was set correctly
    assert r.eightbit_call(42) == "Mock"



# Generated at 2022-06-22 00:03:21.572908
# Unit test for method __new__ of class Style
def test_Style___new__():

    # Can initialize a style
    style = Style("test", value="TEST")
    assert isinstance(style, Style)
    assert style.value == "TEST"
    assert len(style.rules) == 1

    # All initializing rules are saved in attribute 'rules'
    style = Style("test", "test2", value="TEST")
    assert len(style.rules) == 2
    assert style.rules == ("test", "test2")

    # Value of style is just its string representation
    # In this case the result will be an empty string since the
    # rules are no rendertypes.
    style = Style("test", "test2")
    assert style == ""

# Generated at 2022-06-22 00:03:32.401172
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class MockRenderType(RenderType):
        pass

    class MockRegister(Register):
        pass

    class TestRenderType(RenderType):
        pass

    r = MockRegister()
    r.set_renderfunc(MockRenderType, lambda *args: "MockRenderType({})".format(args))
    r.set_rgb_call(MockRenderType)
    assert r(42, 54, 12) == "MockRenderType((42, 54, 12))"

    r.set_renderfunc(TestRenderType, lambda *args: "TestRenderType({})".format(args))
    r.set_rgb_call(TestRenderType)
    assert r(42, 54, 12) == "TestRenderType((42, 54, 12))"


# Generated at 2022-06-22 00:03:38.301401
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from pprint import pprint
    from .rendertype import EightbitBg, EightbitFg, RgbBg, RgbFg, Sgr

    class MyRegister(Register):
        pass

    fg = MyRegister()
    fg.set_renderfunc(EightbitFg, lambda x: "fg" + str(x))
    fg.set_renderfunc(RgbFg, lambda r, g, b: "rgb_fg" + str((r, g, b)))
    fg.set_renderfunc(Sgr, lambda x: "sgr" + str(x))

    fg.set_eightbit_call(EightbitFg)

    fg.green = Style(EightbitFg(42), Sgr(1))

# Generated at 2022-06-22 00:03:42.771509
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def func(a: int, b: int) -> str:
        return f"{a+b}m"

    class TestRegister(Register):
        pass

    reg = TestRegister()

    reg.set_renderfunc(TypeA, func)

    assert reg.renderfuncs[TypeA] == func



# Generated at 2022-06-22 00:03:52.844225
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg
    from .styles import rgb8_to_rgb24_dict

    def rgb8_to_rgb24(x):
        return rgb8_to_rgb24_dict[x]

    class CustomRegister(Register):
        pass

    myreg = CustomRegister()
    myreg.set_rgb_call(RgbFg)
    myreg.renderfuncs.update(
        {
            RgbFg: lambda r, g, b: "\x1b[38;2;%d;%d;%dm" % (r, g, b),
            type: lambda x: "\x1b[%dm" % x,
        }
    )
    myreg.purple = Style(RgbFg(153, 0, 204))


# Generated at 2022-06-22 00:03:56.117969
# Unit test for constructor of class Style
def test_Style():
    test_style = Style(RgbFg(0, 0, 0))
    assert isinstance(test_style, Style)
    assert isinstance(test_style, str)



# Generated at 2022-06-22 00:04:04.465510
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style("red")
            self.yellow = Style("yellow")
            self.default_fg = Style("default_fg")
            self.default_bg = Style("default_bg")
            self.default_ef = Style("default_ef")
            self.default_rs = Style("default_rs")

    t = TestRegister()
    assert t.yellow == "yellow"
    assert t.red == "red"

    class RenderTypeMock(RenderType):
        pass

    def renderfunc_mock(value) -> str:
        return value

    t.set_renderfunc(RenderTypeMock, renderfunc_mock)

    assert t.yellow == "yellow"
    assert t.red == "red"

# Generated at 2022-06-22 00:04:13.381708
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test method unmute of class Register.
    """
    from .render import render_sgr, render_rgb, render_eightbit, render_rgbfg, render_rgbef

    reg = Register()
    reg.set_rgb_call(RenderType.rgb)
    reg.set_eightbit_call(RenderType.eightbit)
    reg.set_renderfunc(RenderType.rgbef, lambda *args: render_rgbef(*args, **{"fg": False}))
    reg.set_renderfunc(RenderType.sgr, render_sgr)
    reg.set_renderfunc(RenderType.rgb, render_rgb)
    reg.set_renderfunc(RenderType.eightbit, render_eightbit)

# Generated at 2022-06-22 00:04:37.924618
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class CustomRegister(Register):

        very_important = Style(...)
        very_very_important = Style(...)

    r: CustomRegister = CustomRegister()
    nt: NamedTuple = r.as_namedtuple()

    # CustomRegister has two attributes
    assert len(dir(r)) == 2

    # As namedtuple has same number of attributes as CustomRegister
    assert len(dir(nt)) == 2

    # Check that the attributes have the correct names
    assert dir(nt) == dir(r)

    # Check that the attributes are str
    for name in dir(nt):

        assert isinstance(getattr(nt, name), str)



# Generated at 2022-06-22 00:04:42.454533
# Unit test for method copy of class Register
def test_Register_copy():

    # Test case: Copy a simple render-func
    def fg_func(c):
        return '\x1b[31m'

    reg = Register()
    reg.set_eightbit_call(RenderType.FG)
    reg.set_renderfunc(RenderType.FG, fg_func)
    reg.red = Style(RenderType.FG(42))

    c = reg.copy()
    c.red = Style(RenderType.FG(1))

    assert reg.red == '\x1b[31m'
    assert c.red == '\x1b[31m'

# Generated at 2022-06-22 00:04:48.200959
# Unit test for method copy of class Register
def test_Register_copy():
    from . import fg, Style, RgbFg, Sgr
    fg.red = Style(Sgr(1), RgbFg(1, 0, 0))

    new_fg = fg.copy()
    fg.mute()

    assert new_fg.red == "\x1b[38;2;1;0;0m\x1b[1m"

# Generated at 2022-06-22 00:04:57.787537
# Unit test for constructor of class Register
def test_Register():

    r = Register()

    # Check if register-object has attribute 'rendertype'
    assert hasattr(r, "renderfuncs")

    # Check if register-object has attribute 'is_muted'
    assert hasattr(r, "is_muted")

    # Check if register-object has attribute 'eightbit_call'
    assert hasattr(r, "eightbit_call")

    # Check if register-object has attribute 'rgb_call'
    assert hasattr(r, "rgb_call")

    assert r.renderfuncs == {}

    assert r.is_muted == False

    assert callable(r.eightbit_call)

    assert callable(r.rgb_call)


# Generated at 2022-06-22 00:05:07.472121
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    class CustomRegister(Register):
        pass

    r = CustomRegister()

    # Check default values
    assert r.rgb_call(10, 20, 30) == (10, 20, 30)
    assert r.eightbit_call(101) == 101

    # Test set_rgb_call
    r.set_rgb_call(RgbFg)
    assert r.rgb_call(10, 20, 30) == "\x1b[38;2;10;20;30m"

    # Test set_rgb_call
    r.set_eightbit_call(RgbBg)
    assert r.eightbit_call(101) == "\x1b[48;5;101m"

    # Test that this doesn't change 8bit_

# Generated at 2022-06-22 00:05:09.367258
# Unit test for method mute of class Register
def test_Register_mute():
    from . import fg, sgr

    fg.mute()

    assert str(fg.blue + sgr.bold) == ""

