

# Generated at 2022-06-21 23:55:25.290306
# Unit test for method copy of class Register
def test_Register_copy():
    reg1 = Register()
    reg1.orange = Style(RenderType.Foreground(10, 42, 255))
    reg1.black = Style(RenderType.Foreground(0, 0, 0))
    reg2 = reg1.copy()

    assert reg1 is not reg2
    assert reg1.orange == reg2.orange
    assert reg1.black == reg2.black
    assert True


# Generated at 2022-06-21 23:55:31.139205
# Unit test for constructor of class Style
def test_Style():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    fg.orange = Style(RgbFg(1,5,10), Sgr(1))

    assert isinstance(fg.orange, Style)
    assert isinstance(str(fg.orange), str)

    assert str(fg.orange) == '\x1b[38;2;1;5;10m\x1b[1m'


# Generated at 2022-06-21 23:55:43.509534
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit-test for Method __call()__ of the base class Register.
    """
    import pytest

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.set_eightbit_call(int)
    r.set_rgb_call(int)

    # call register with one argument (expected output is a string)
    assert isinstance(r(14), str)
    assert isinstance(r(15), str)

    # call register with three arguments (expected output is a string)
    assert isinstance(r(1, 2, 3), str)

    # call register with zero arguments (expected output is a string)
    assert isinstance(r(), str)

    # call register with more than three arguments (expected output is a string)

# Generated at 2022-06-21 23:55:49.794912
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Create default register
    register = Register()

    # Add renderfunc for rendertype 'RgbBg'
    def renderfunc(register, n):
        return "\x1b[48;2;{};{};{}m".format(n, n, n)

    register.set_renderfunc(RgbBg, renderfunc)

    # Set rendertype for 8bit-calls to 'RgbBg'
    register.set_eightbit_call(RgbBg)

    # Color 100 should now be rendered via renderfunc of rendertype 'RgbBg'
    assert register(100) == "\x1b[48;2;100;100;100m"


# Generated at 2022-06-21 23:55:56.345595
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.red = '\x1b[31m'
    r.green = '\x1b[32m'
    d = r.as_dict()
    assert d == {'red': '\x1b[31m', 'green': '\x1b[32m'}


# Generated at 2022-06-21 23:56:00.369823
# Unit test for method __new__ of class Style
def test_Style___new__():
    r = RenderType("Sgr")
    r1 = Style(r, value="value")
    r2 = Style(r)

    assert r1 == "value"
    assert r1.rules == (r,)
    assert r2 == ""
    assert r2.rules == (r,)


# Generated at 2022-06-21 23:56:10.975157
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # This is a custom renderfunc for testing purposes:
    def custom_renderfunc(*, val: int, bold: bool = False) -> str:
        return f"custom func called: val: {val}; bold: {bold}"


    # Create a new Register-object and define the renderfunc for RgbBg
    register = Register()
    register.set_renderfunc(RgbBg, custom_renderfunc)

    # Replace the value 'red' to test if the new renderfunc is used.
    register.red = Style(RgbBg(42, 75, 11, bold=True))

    # Compare the rendered strings.
    assert str(register.red) == "custom func called: val: 759; bold: True"



# Generated at 2022-06-21 23:56:20.683021
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    __name__: str = "sty.Register"
    __file__: str = "sty/register.py"

    import doctest
    doctest.testmod()

    from .sty_config import StyConfig
    StyConfig.Cfg.update(StyConfig.default_cfg)

    from .factory import make_sty
    from .style import STYLES

    sty = make_sty(STYLES)

    namedtuple_sty = sty.fg.as_namedtuple()

    assert getattr(namedtuple_sty, "black") == "\x1b[30m"



# Generated at 2022-06-21 23:56:30.417957
# Unit test for method copy of class Register
def test_Register_copy():
    """Unit test for method copy of class Register"""
    from .core import STY

    STY.fg.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    assert STY.fg.orange is STY.fg.orange
    STY.bg.green = Style(RgbBg(2, 3, 4))

    STY2 = STY.copy()
    assert STY is not STY2
    assert STY.fg.orange is not STY2.fg.orange
    assert STY.bg.green is not STY2.bg.green

    # The following statement is important to see that isinstance()-checks
    # still work after we have copied the style.
    assert isinstance(STY.fg.orange, STY.fg.orange)

# Generated at 2022-06-21 23:56:35.356125
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from sty import fg, RenderType, Style

    fg.white = Style(fg(255))

    assert isinstance(fg.white, Style)
    assert isinstance(fg.white, str)
    assert fg.white == "\x1b[38;2;255;255;255m"



# Generated at 2022-06-21 23:56:44.440972
# Unit test for method unmute of class Register
def test_Register_unmute():

    class MyRenderType(RenderType):
        pass

    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.test = Style(MyRenderType(1))

    test = TestRegister()
    test.mute()

    assert test._is_muted

    test.unmute()
    assert test._is_muted == False

# Generated at 2022-06-21 23:56:46.185260
# Unit test for constructor of class Register
def test_Register():
    a = Register()
    assert isinstance(a, Register)
    return a



# Generated at 2022-06-21 23:56:48.160529
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.red = Style(RenderType(1))

    assert r(1) == "\x1b[1m"
    assert r(5, 10, 255) == "\x1b[5;10;255m"
    assert r("red") == "\x1b[1m"

# Generated at 2022-06-21 23:56:51.683373
# Unit test for method __call__ of class Register
def test_Register___call__():

    def call_test(render_type: Type[RenderType]) -> None:
        # Create register
        reg = Register()

        # Add renderfunc

# Generated at 2022-06-21 23:56:59.987253
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Test(RenderType):
        def __str__(self) -> str:
            return "TEST"

    reg = Register()
    reg.set_renderfunc(Test, Test)

    d1 = Test()

    reg.dummy = Style(d1)

    d2 = reg.dummy

    # Test call with Style-object

    assert d2(fg('red')) == '\x1b[38;2;255;0;0mTEST\x1b[0m'
    assert d2(fg('red'), bg(255)) == '\x1b[38;2;255;0;0m\x1b[48;5;255mTEST\x1b[0m'


# Generated at 2022-06-21 23:57:11.273206
# Unit test for method mute of class Register
def test_Register_mute():

    # build a test register
    r1 = Register()
    r1.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    r1.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    r1.set_renderfunc(Sgr, lambda *sgrs: "".join([f"\x1b[{sgr}m" for sgr in sgrs]))
    r1.set_renderfunc(Reset, lambda: "\x1b[0m")

    r1.red = Style(RgbFg(1, 5, 10))

# Generated at 2022-06-21 23:57:22.316517
# Unit test for method mute of class Register
def test_Register_mute():
    """
    Tests the mute method of the Register class.
    """

    from sty import fg
    from sty import ef
    from sty import bg
    from sty import rs

    fg.resetall()
    bg.resetall()
    ef.resetall()
    rs.resetall()

    fg.black = Style(fg.rgb(1, 2, 3))
    fg_black_str = str(fg.black)

    fg.mute()
    assert not fg_black_str == str(fg.black)

    fg.unmute()
    assert fg_black_str == str(fg.black)

    bg.red = Style(bg.rgb(10, 20, 30))
    bg_red_str = str(bg.red)


# Generated at 2022-06-21 23:57:34.361265
# Unit test for method mute of class Register
def test_Register_mute():
    from sty.rendertypes import RgbFg

    r1 = Register()
    r1.set_renderfunc(RgbFg, lambda *args: "rgb_renderfunc_was_called")

    r1.test1 = Style(RgbFg(100,100,100))
    r1.test2 = Style(RgbFg(100,100,100))
    r1.test3 = Style(RgbFg(100,100,100))

    # Test1
    r1.mute()

    assert r1.test1 == ""
    assert r1.test2 == ""
    assert r1.test3 == ""

    # Test2
    r1.unmute()

    assert r1.test1 == "rgb_renderfunc_was_called"

# Generated at 2022-06-21 23:57:45.866045
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Make sure that calls with invalid input return an empty string
    reg = Register()

    assert reg("red") == ""
    assert reg("blue") == ""
    assert reg(42) == ""
    assert reg(102, 49, 42) == ""

    # Make sure that the return string is an ANSI SGR sequence.
    reg.set_rgb_call(RgbFg)
    reg.set_eightbit_call(Sgr)
    reg.red = Style(Sgr(1))
    reg.blue = Style(RgbFg(0, 0, 255))

    assert reg("red") == "\x1b[1m"
    assert reg("blue") == "\x1b[38;2;0;0;255m"

# Generated at 2022-06-21 23:57:51.379849
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .enums import Color
    from .rendertype import RgbBg, RgbFg, Sgr

    # RdBk is a special register (red on black) for which we implement a custom
    # __call__ method.
    class RdBk(Register):
        def __call__(self, *args, **kwargs):
            return self.fg(255, 20, 20) + self.bg(0, 0, 0)

    # Create a new register
    rdbk = RdBk()

    # Add renderfuncs to register
    rdbk.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

# Generated at 2022-06-21 23:58:03.012076
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define renderfunc for rendertype
    def renderfunc(param1: int, param2: int) -> str:
        return f"{param1}-{param2}"

    # Define rendertype
    RenderType2 = NamedTuple("RenderType2", [("param1", int), ("param2", int)])

    # Create register
    register = Register()

    # Add rendertype
    register.set_renderfunc(RenderType2, renderfunc)

    # Create a style with the new rendertype
    style = Style(RenderType2(6, 9))

    # Print style
    print(style)  # Should print "6-9"


# Generated at 2022-06-21 23:58:14.548092
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # test_dict is used to compare the result of as_dict with a expected result
    test_dict = {'black': '\x1b[30m', 'red': '\x1b[31m', 'green': '\x1b[32m', 'yellow': '\x1b[33m', 'blue': '\x1b[34m', 'magenta': '\x1b[35m', 'cyan': '\x1b[36m', 'white': '\x1b[37m'}
    # test_register is used to test the as_dict method of Register class
    test_register = Register()
    # test_register_dict is used to store the result of as_dict method
    test_register_dict = test_register.as_dict()
    # compare the test_register_dict with test_

# Generated at 2022-06-21 23:58:22.693616
# Unit test for method copy of class Register
def test_Register_copy():
    class TestRegister(Register):
        blue1 = Style(RgbFg(42, 42, 42))
        blue2 = Style(RgbFg(42, 42, 42))

    # Create new register instance:
    foo = TestRegister()

    # Create copy of register instance:
    bar = foo.copy()

    # Make sure that they are different objects:
    assert id(foo) != id(bar)

    # Make sure that the .rules attribute is a different object:
    assert id(foo.blue1.rules) != id(bar.blue1.rules)

    # Make sure that the .rules attribute is the same object:
    assert id(foo.blue1.rules[0]) == id(bar.blue1.rules[0])

    # Make sure that the .rules attribute is a different object:

# Generated at 2022-06-21 23:58:33.027844
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .sty import sty

    sty_copy = sty.copy()

    sty_copy.set_eightbit_call(RgbFg)
    sty_copy.set_rgb_call(RgbFg)

    sty_copy.orange = Style(RgbFg(1, 5, 10), Sgr(1))
    sty_copy.gray = Style(RgbFg(42, 42, 42))

    assert sty_copy.orange == '\x1b[38;2;1;5;10m\x1b[1m'
    assert sty_copy.gray == '\x1b[38;2;42;42;42m'


# Generated at 2022-06-21 23:58:36.838780
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    def func(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    reg = Register()
    reg.set_renderfunc(RenderType, func)

    reg.set_eightbit_call(RenderType)

    value = reg(42)

    assert value == "\x1b[38;5;42m"


# Generated at 2022-06-21 23:58:41.753954
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    renderfuncs = dict()
    renderfuncs[RgbFg] = lambda r, g, b: "renderfunc1"
    renderfuncs[RgbBg] = lambda r, g, b: "renderfunc2"

    register = Register()
    register.set_eightbit_call(RgbFg)

    register.renderfuncs = renderfuncs

    assert register(1,1,1) == "renderfunc1"
    assert register(1,1) == ""
    assert register(1) == ""
    assert register("asdf") == ""



# Generated at 2022-06-21 23:58:45.472292
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert hasattr(r, "renderfuncs")
    assert isinstance(r.renderfuncs, dict)
    assert hasattr(r, "eightbit_call")
    assert hasattr(r, "rgb_call")
    assert hasattr(r, "is_muted")
    assert not r.is_muted



# Generated at 2022-06-21 23:58:46.238352
# Unit test for constructor of class Register
def test_Register():
    assert isinstance(Register(), Register)


# Generated at 2022-06-21 23:58:51.587264
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    # Define a new renderfunc
    renderfunc: Renderfuncs = {
        RgbFg: lambda x, y, z: f"\x1b[38;2;{x};{y};{z}m",
        Sgr: lambda x: f"\x1b[{x}m",
    }

    # Create a new register
    my_register = Register()

    # Add the defined renderfunc for the rendertypes used in the stylingrules:
    my_register.set_renderfunc(RgbFg, renderfunc[RgbFg])
    my_register.set_renderfunc(Sgr, renderfunc[Sgr])

    # Create a new style-attribute for this register-object
    my_register

# Generated at 2022-06-21 23:59:01.480466
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .sty import fg, bg, ef, rs

    # Create dict from register
    rg: Dict[str, str] = fg.red.as_dict()

    # Create namedtuple from dict
    tup: NamedTuple = namedtuple("TestTup", rg.keys())(*rg.values())

    # Test if register-dict can be converted to namedtuple
    assert tup.red == "\x1b[38;2;255;0;0m"

    # Test if namedtuple can be converted to register-dict
    assert rg == {"red": "\x1b[38;2;255;0;0m"}

    # Create dict from register
    rg: Dict[str, str] = bg.green.as_dict()

    # Create namedtuple from dict

# Generated at 2022-06-21 23:59:18.594271
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RenderTypeA(RenderType):
        pass

    class RenderTypeB(RenderType):
        pass


    def renderfuncA(a):
        return "renderfuncA"

    def renderfuncB(b, c):
        return "renderfuncB"

    class StyleA(RenderTypeA, Style):
        pass

    class StyleB(RenderTypeB, Style):
        pass

    # Initialize register-object
    r = Register()

    # Set first renderfuncs
    r.set_renderfunc(RenderTypeA, renderfuncA)
    r.set_renderfunc(RenderTypeB, renderfuncB)

    # Define Styles with rendertypes set in renderfuncs
    r.styleA = StyleA(4)

    # Test if Style is created correctly.

# Generated at 2022-06-21 23:59:28.507621
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.none = Style()
    r.none_set_renderfunc = r.set_renderfunc('\033[0m')
    r.red = Style(RgbFg(255, 0, 0))
    r.red_set_renderfunc = r.set_renderfunc('\033[38;2;255;0;0m')
    r.blue = Style(RgbBg(0, 0, 255))
    r.blue_set_renderfunc = r.set_renderfunc('\033[48;2;0;0;255m')
    r.bold = Style(Sgr(1))
    r.bold_set_renderfunc = r.set_renderfunc('\033[1m')


# Generated at 2022-06-21 23:59:39.495858
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test functionality of method set_rgb_call of class Register.

    """
    Register_test = Register()
    Register_test.set_renderfunc(RenderType_test1, render_test1)
    Register_test.set_renderfunc(RenderType_test2, render_test2)

    assert Register_test.eightbit_call(*(4,)) == ""
    Register_test.set_eightbit_call(RenderType_test1)
    assert Register_test.eightbit_call(*(4,)) == "1"

    assert Register_test.rgb_call(*(4, 4, 4)) == ""
    Register_test.set_rgb_call(RenderType_test2)
    assert Register_test.rgb_call(*(4, 4, 4)) == "2"


# Unit tests for

# Generated at 2022-06-21 23:59:50.786187
# Unit test for constructor of class Register
def test_Register():
    """Test case of Register"""

    register = Register()

    # not render
    assert register.as_dict() == {}

    # set renderfuncs
    rtype = RenderType
    renderfuncs: Renderfuncs = {
        rtype: lambda *args, **kwargs: "\x1b[{}".format(args),
    }
    register.set_renderfunc(rtype, renderfuncs[rtype])
    register.set_eightbit_call(rtype)
    register.set_rgb_call(rtype)

    # add style
    register.test = Style(rtype(1), Sgr(1))

    # render
    assert register.as_dict() == {'test': '\x1b[1\x1b[1'}

    # not render
    register.mute()
   

# Generated at 2022-06-21 23:59:57.752637
# Unit test for method unmute of class Register
def test_Register_unmute():

    def func(*args, **kwargs) -> str:
        return ""

    r1 = Register()
    r1.set_eightbit_call(func)
    r1.set_rgb_call(func)
    r1.set_renderfunc(func, func)

    assert isinstance(r1.eightbit_call, Callable)
    assert r1.eightbit_call == func
    assert isinstance(r1.rgb_call, Callable)
    assert r1.rgb_call == func
    assert r1.renderfuncs[func] == func

    r1.mute()

    assert r1.is_muted

# Generated at 2022-06-22 00:00:09.246497
# Unit test for method __new__ of class Style
def test_Style___new__():

    # 1. Testing normal execution

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    fg = Register()

    setattr(fg, "renderfuncs", {RgbFg: lambda a, b, c: f"\x1b[38;2;{a};{b};{c}m", Sgr: lambda d: f"\x1b[{d}m"})

    fg.orange = Style(RgbFg(1,5,10), Sgr(1))
    assert str(fg.orange) == '\x1b[38;2;1;5;10m\x1b[1m'
    assert isinstance(fg.orange, Style)
    assert isinstance(fg.orange, str)

# Generated at 2022-06-22 00:00:20.372360
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, Sgr
    from .importcolor import ImportColor
    from .colorlib import ColorLib

    col = ColorLib()

    # Create a register from scratch
    r1 = Register()
    r1.set_eightbit_call(RgbFg)
    r1.set_rgb_call(RgbBg)

    # Load a whole color-library
    r2 = ImportColor.load_color_lib(col)

    # Add a few styles
    r1.bright_red = Style(RgbBg(1, 2, 3), Sgr(1))
    r2.bright_red(40)

    assert str(r1.bright_red) == "\x1b[48;2;1;2;3m\x1b[1m"



# Generated at 2022-06-22 00:00:33.109670
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbFg, Sgr

    class TestRegister(Register):
        pass

    sr = TestRegister()
    sr.test: Style = Style(RgbFg(10, 42, 255))

    assert not isinstance(sr.test, str)
    assert isinstance(str(sr.test), str)
    assert str(sr.test) == "\x1b[38;2;10;42;255m"

    sr.test2 = Style(RgbFg(10, 42, 255), Sgr(1))
    assert str(sr.test2) == "\x1b[38;2;10;42;255m\x1b[1m"

    sr.test3: Style = Style(Sgr(1))
    assert str(sr.test3) == "\x1b[1m"

# Generated at 2022-06-22 00:00:38.888713
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    with open('sty_tests/sty_tests/sty_tests.sty', 'r') as f:
        sty_tests_dict = eval(f.read())

    sty_tests = Register()
    sty_tests.__dict__.update(sty_tests_dict)

    sty_tests_dict_copy = sty_tests.as_dict()

    assert sty_tests_dict == sty_tests_dict_copy

# Generated at 2022-06-22 00:00:45.671828
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.test_key = "test_value"

    my_register = MyRegister()
    assert hasattr(my_register, "test_key")
    assert my_register.test_key == "test_value"

    my_style = Style()
    my_register.new_style = my_style
    assert hasattr(my_register, "new_style")
    assert my_register.new_style == my_style


# Generated at 2022-06-22 00:01:06.062572
# Unit test for method unmute of class Register
def test_Register_unmute():

    from .render import SGR_RENDER
    from .rendertype import Sgr

    r = Register()

    r.set_renderfunc(Sgr, SGR_RENDER)

    r.bold = Sgr(1)
    r.italic = Sgr(3)

    assert str(r.bold) == "\x1b[1m"
    assert str(r.italic) == "\x1b[3m"

    r.mute()

    assert str(r.bold) == ""
    assert str(r.italic) == ""

    r.unmute()

    assert str(r.bold) == "\x1b[1m"
    assert str(r.italic) == "\x1b[3m"



# Generated at 2022-06-22 00:01:17.358769
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Only run this test if is_muted is True
    def test_renderfunc(r, g, b):
        return "\x1b[48;2;{0};{1};{2}m".format(str(r), str(g), str(b))


    rf = Register()
    rf.set_renderfunc(RenderType.RGB_BG, test_renderfunc)

    assert rf.rgb_call(1, 2, 3) == "\x1b[48;2;1;2;3m"

    # Test if set_renderfunc() updates styles correctly
    rf.bg = Style(RenderType.RGB_BG(1, 2, 3))
    rf.set_renderfunc(RenderType.RGB_BG, test_renderfunc)

# Generated at 2022-06-22 00:01:27.865379
# Unit test for constructor of class Style
def test_Style():
    class MyRule1(RenderType):
        """
        Example for a render-type class.
        """

    class MyRule2(RenderType):
        """
        Example for a render-type class.
        """

    myfunc1: Callable = lambda *args: "foo"
    myfunc2: Callable = lambda *args: "bar"

    r = Register()

    r.set_renderfunc(MyRule1, myfunc1)
    r.set_renderfunc(MyRule2, myfunc2)

    value = Style(rule1=MyRule1(), rule2=MyRule2())

    assert value.rules == (MyRule1(), MyRule2())
    assert str(value) == "foobar"

# Generated at 2022-06-22 00:01:38.949826
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, RgbBg

    reg = Register()

    # Initial register-object with a RgbFg-call and a RgbBg-call.
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    reg.blue = Style(RgbFg(1, 2, 3))
    reg.red = Style(RgbBg(2, 3, 4))

    # Test initial state.
    assert not hasattr(reg, "rgb")

# Generated at 2022-06-22 00:01:40.417665
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register
    """
    from . import sty
    sty.rs.copy()

# Generated at 2022-06-22 00:01:50.925676
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg, Sgr
    from .fg import RgbFg
    from .sgr import Sgr

    # Define a custom render function
    def my_rgb_fg_renderfunc(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    # Create a new register
    my_register = Register()

    # Set the default renderfunc for RgbFg for the register
    my_register.set_renderfunc(RgbFg, my_rgb_fg_renderfunc)

    # Make the register object callable.
    # Calls like f(144) will render a colored background.
    my_register.set_rgb_call(RgbFg)

    # Set a new style rule for the register
    my

# Generated at 2022-06-22 00:01:59.280875
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    class TestRegister(Register):
        pass

    r = TestRegister()
    r.renderfuncs = {RgbFg: lambda *args: "\x1b[38;2;{};{};{}m".format(*args), Sgr: lambda *args: "\x1b[{}m".format(*args)}
    r.fg_orange = Style(RgbFg(1,5,10), Sgr(1))
    assert(r.fg_orange == Style(RgbFg(1,5,10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m"))

# Generated at 2022-06-22 00:02:06.547917
# Unit test for constructor of class Style
def test_Style():
    def _check_rules(rules, expected_rules):
        for rule, expected_rule in zip(rules, expected_rules):
            assert rule == expected_rule

    def _check_styling_rule(styling_rule, str_styling_rule):
        assert str(styling_rule) == str_styling_rule

    expected_rules = [
        RgbFg(1, 5, 10),
        RgbFg(42, 42, 42),
        Sgr(1),
        Sgr(0),
    ]
    rules = [
        Style(RgbFg(1, 5, 10), RgbFg(42, 42, 42), Sgr(1), Sgr(0))
    ]

    for rule, expected_rule in zip(rules, expected_rules):
        assert rule == expected_rule

   

# Generated at 2022-06-22 00:02:07.556039
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)



# Generated at 2022-06-22 00:02:14.938179
# Unit test for method unmute of class Register
def test_Register_unmute():

    class MyRenderType(RenderType):
        pass


    class MyRegister(Register):

        def __init__(self):
            super().__init__()
            self.muted_a = Style(MyRenderType(42))


    reg: Register = MyRegister()
    reg.set_renderfunc(MyRenderType, lambda x: f"RENDERED ANSI-CODE: {x}")

    reg.mute()
    assert not reg.muted_a
    reg.unmute()
    assert reg.muted_a == "RENDERED ANSI-CODE: 42"


# Generated at 2022-06-22 00:02:36.360050
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import TestRegister
    
    TestRegister.test_Register_as_dict()

# Generated at 2022-06-22 00:02:43.060535
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .render import sgr

    class Foo(Register):

        bar = Style("m")
        _baz = "n"
        __foobar = "o"

    f = Foo()
    f.renderfuncs = {str: lambda x: x}
    assert f.as_dict() == {"bar": "m"}

    f.set_renderfunc(str, sgr)
    assert f.as_dict() == {"bar": "\x1b[m"}

# Generated at 2022-06-22 00:02:47.695623
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MyRegister(Register):
        pass

    r = MyRegister()

    class MyRenderType1(RenderType):
        def __str__(self):
            return "MyRenderType1"

    class MyRenderType2(RenderType):
        pass

    r.set_eightbit_call(MyRenderType1)
    r.set_rgb_call(MyRenderType2)

    r.set_renderfunc(MyRenderType1, lambda x: "Eightbit: {}".format(x))
    r.set_renderfunc(MyRenderType2, lambda r, g, b: "RGB: {}; {}; {}".format(r, g, b))

    assert r(42) == "Eightbit: 42"
    assert r(42, 42, 42) == "RGB: 42; 42; 42"

# Generated at 2022-06-22 00:02:57.097614
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .typing import Eightbit

    from .rendertype import Ansi, RgbFg, RgbBg

    from .registertype import RegisterType

    from .colors.eightbitextended import eightbitextended

    from .colors.solarized import solarized

    # Create test-register with Ansi render type for both eightbit and rgb render type.
    class TestRegister(Register):
        pass

    tr1 = TestRegister()
    tr1.set_eightbit_call(Ansi)
    tr1.set_rgb_call(Ansi)

    # Add renderfunc for Ansi render-type.
    tr1.set_renderfunc(
        Ansi,
        lambda *args: Sty.ansi_render_func(*args, rendertype=Eightbit),
    )

    # Add test attributes to test register.

# Generated at 2022-06-22 00:03:04.273147
# Unit test for constructor of class Style
def test_Style():
    r1 = RenderType("bla")
    r2 = RenderType("blub")
    rule1 = Style(r1, r2)
    rule2 = Style(rule1, r1)
    rule3 = Style(rule2, r2)
    assert rule3.rules == (rule2, r1, r2)
    assert isinstance(rule3, Style)
    assert isinstance(rule3, str)
    assert str(rule3) == ""

# Generated at 2022-06-22 00:03:15.092095
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    import sys
    import unittest

    class Rs(RenderType):

        def __init__(self, *args):
            self.args = args

    class Fg(RenderType):

        def __init__(self, *args):
            self.args = args

    class Bg(RenderType):

        def __init__(self, *args):
            self.args = args

    class Ef(RenderType):

        def __init__(self, *args):
            self.args = args

    def renderfunc(param):
        return "{0}".format(param)

    def renderfunc_rs(param):
        return "{0}".format(param)

    class Tests(unittest.TestCase):

        def test_renderfunc_setter(self):
            # arrange
            reg = Register()

# Generated at 2022-06-22 00:03:20.025378
# Unit test for constructor of class Register
def test_Register():
    """
    Test that constructor of class Register works as expected.
    """

    class TestRegister(Register):
        pass
    w = TestRegister()
    w.a = 1
    w.b = 1
    w.c = 1
    assert w.a == 1
    assert w.b == 1
    assert w.c == 1


# Generated at 2022-06-22 00:03:31.321478
# Unit test for method __call__ of class Register
def test_Register___call__():

    import pytest

    # Define a custom render type with a corresponding render func.
    class Custom(RenderType):
        def render(self) -> str:
            return "".join(self.args)

    def render_custom(arg: str) -> str:
        return f"({arg})"

    # Create register
    r = Register()
    r.custom_color = Style(Custom("#123456"))
    r.set_renderfunc(Custom, render_custom)

    # Test call with color name
    assert r("custom_color") == "(#123456)"

    # Test call with 8bit color code
    r.set_eightbit_call(Custom)
    assert r(42) == "(42)"

    # Test call with 24bit color code
    r.set_rgb_call(Custom)

# Generated at 2022-06-22 00:03:37.776373
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Check if the rendering process works in method __setattr__ of class Register.
    """
    from .eightbit import EightBit
    from .sgr import Sgr

    def render_sgr(code: int) -> str:
        return "\x1b[{}m".format(code)

    def render_eightbit(code: int) -> str:
        return "\x1b[38;5;{}m".format(code)

    r = Register()

    r.set_renderfunc(Sgr, render_sgr)
    r.set_renderfunc(EightBit, render_eightbit)

    r.set_eightbit_call(EightBit)
    r.set_rgb_call(EightBit)

    r.red = Style(EightBit(1), Sgr(1))


# Generated at 2022-06-22 00:03:43.718233
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg
    d = fg.as_dict()
    assert isinstance(d, dict)
    assert type(d) == dict
    assert len(d) == len(dir(fg))
    assert isinstance(d['blue'], str)
    assert type(d['blue']) == str
    assert d['blue'].startswith('\033[38;')


# Generated at 2022-06-22 00:04:22.092935
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Unit test for method __call__ of class Register
    """
    import pytest

    r = Register()
    r.blue = Style(RgbFg(0, 0, 200))

    assert isinstance(r("blue"), str)
    assert str(r("blue")) == "\x1b[38;2;0;0;200m"

    with pytest.raises(TypeError):
        r("blue", "orange")

    with pytest.raises(AttributeError):
        r("orange")

    assert isinstance(r(255), str)
    assert str(r(255)) == ""

    r.set_renderfunc(RgbFg, lambda x, y, z: "")

    assert isinstance(r(255), str)
    assert str(r(255)) == ""

    r.set_

# Generated at 2022-06-22 00:04:26.339709
# Unit test for method copy of class Register
def test_Register_copy():
    import pytest

    r1: Register = Register()
    r1.blue = Style(Sgr(1))

    r2: Register = r1.copy()

    assert r1 is not r2
    assert r1.blue is not r2.blue
    assert r1.blue == r2.blue

# Generated at 2022-06-22 00:04:31.983336
# Unit test for method copy of class Register
def test_Register_copy():

    # Create register object
    r1 = Register()

    # Set color for r1
    r1.abc = Style(Sgr(1,2,3))

    # Copy r1
    r2 = r1.copy()

    # Check if copy works:
    assert r1 is not r2
    assert r1.abc is not r2.abc
    assert r1.abc == r2.abc

# Generated at 2022-06-22 00:04:38.347303
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()

    reg.red = Style(RgbFg(1,1,1), Sgr(2))
    reg.green = Style(RgbFg(3,3,3), Sgr(1))

    assert reg.as_dict() == {"red": "\x1b[38;2;1;1;1m\x1b[2m", "green": "\x1b[38;2;3;3;3m\x1b[1m"}



# Generated at 2022-06-22 00:04:49.804041
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test if as_dict() method of Register class works as expected.
    """
    from .style import fg, reset, bg, ef, es, rs

    # Test working with sensible input

# Generated at 2022-06-22 00:04:52.049047
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(value="abcd"), Style)
    assert isinstance(Style(value="abcd"), str)
    assert str(Style(value="abcd")) == "abcd"

# Generated at 2022-06-22 00:05:04.178669
# Unit test for method mute of class Register
def test_Register_mute():

    from .builder import Builder

    b = Builder()
    b.tint_index = 7
    b.set_base_colors()
    b.set_tints()
    b.set_format_functions()
    b.set_render_functions()
    b.register_fg()
    b.register_bg()
    b.register_ef()
    b.register_rs()

    assert not b.fg.is_muted
    assert not b.bg.is_muted
    assert not b.ef.is_muted
    assert not b.rs.is_muted

    b.fg.mute()
    b.bg.mute()
    b.ef.mute()
    b.rs.mute()

    assert b.fg.is_muted

# Generated at 2022-06-22 00:05:10.197513
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    Unit test for method __new__ of class Style

    Input:

        rules: Rule(param1, ..., paramN)

    Output:

        ANSI-string: '\x1b[param1;...;paramNm\x1b[param1;...;paramNm'
    """
    from .rendertype import Sgr
    from .renderfunc import render_Sgr

    sgr_instance = Sgr(1, 3)
    style_instance = Style(sgr_instance)

    assert isinstance(style_instance, str)
    assert style_instance == "\x1b[1;3m"  # type: ignore
    assert style_instance.rules == (sgr_instance, )

