

# Generated at 2022-06-21 23:55:28.219156
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class RgbFg(RenderType): pass
    class Sgr(RenderType): pass
    class Fg(RenderType): pass
    class Bg(RenderType): pass

    reg = Register()
    reg.t1 = Style(RgbFg(1,5,10), Sgr(1))

    assert isinstance(reg.t1, Style)
    assert issubclass(RgbFg, RenderType)
    assert issubclass(Sgr, RenderType)
    assert reg.t1.value == "\x1b[38;2;1;5;10m\x1b[1m"
    # Test if _rules of an style-attribute is updated properly
    assert reg.t1.rules == (RgbFg(1,5,10), Sgr(1))

    # Test if ValueError is raised if parameter

# Generated at 2022-06-21 23:55:40.232473
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create a test register
    class RegisterTest(Register):
        def __init__(self):
            super().__init__()
            # Define 8bit and 24bit rendertypes
            self.renderfuncs[Ansi8bit] = lambda x: x
            self.renderfuncs[RgbFg] = lambda r, g, b: (r, g, b)
            # Define 8bit and 24bit render-functions
            self.set_renderfunc(Ansi8bit, lambda x: x)
            self.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))

            # Define 8bit-call and 24bit-call rendertypes
            self.set_eightbit_call(Ansi8bit)
            self.set_rgb_call(RgbFg)



# Generated at 2022-06-21 23:55:49.734731
# Unit test for method __new__ of class Style
def test_Style___new__():

    def f1(arg1):
        return arg1

    def f2(arg1, arg2):
        return arg1 + arg2

    class R1(RenderType):
        renderfunc = f1

    class R2(RenderType):
        renderfunc = f2

    r1 = R1(1)
    r2 = R2(2, 3)

    s1 = Style(r1, r2)

    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == f1(1) + f2(2, 3)

    s2 = Style(s1, r1)

    assert isinstance(s2, Style)
    assert isinstance(s2, str)

# Generated at 2022-06-21 23:55:57.081321
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class TestRegister(Register):
        red = Style(RgbFg(255, 0, 0))
        green = Style(RgbFg(0, 255, 0))

    r = TestRegister()
    assert r.as_dict() == {"red": "\x1b[38;2;255;0;0m", "green": "\x1b[38;2;0;255;0m"}

# Generated at 2022-06-21 23:56:02.550094
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import NoRgb

    fg = Register()
    fg.set_renderfunc(NoRgb, lambda: "\x1b[38m")

    # Set Eightbit rendertype for fg
    assert fg.eightbit_call == fg.renderfuncs[NoRgb]

    fg.set_rgb_call(NoRgb)
    # Set RGB rendertype for fg
    assert fg.rgb_call == fg.renderfuncs[NoRgb]



# Generated at 2022-06-21 23:56:12.352636
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .register import Register
    from .rendertype import Sgr

    r = Register()
    r.teststyle = Style(Sgr(1))
    r.teststyle = Style(Sgr(0), str="test")

    r.teststyle = Style(Sgr(1))
    r.teststyle = Style(Sgr(0), str="test")
    assert r.teststyle == "\x1b[1mtest"

    r.mute()
    r.teststyle = Style(Sgr(1))
    r.teststyle = Style(Sgr(0), str="test")
    assert r.teststyle == "test"

    r.unmute()
    r.teststyle = Style(Sgr(1))
    r.teststyle = Style(Sgr(0), str="test")
    assert r.teststyle

# Generated at 2022-06-21 23:56:19.762336
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute() works as expected.
    """
    r1 = Register()
    r1.set_renderfunc(RenderType, lambda x: x)

    r1.fg.orange = Style(RenderType("\x1b[38;5;208m"))
    assert len(r1.fg.orange) == 0

    r1.unmute()
    assert r1.fg.orange == "\x1b[38;5;208m"



# Generated at 2022-06-21 23:56:29.557960
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test the method ``__call__`` of the class ``Register``.
    """
    # Test case 1

    # Define register
    class Fg(Register):
        red = Style(RgbFg(255, 0, 0))
        bg = Style(RgbFg(255, 0, 0))

    f = Fg()

    # Define render functions
    def render_eightbit(rendertype):
        def func(color):
            return "1_" + str(color)
        return func

    def render_rgb(rendertype):
        def func(r, g, b):
            return "2_" + str((r, g, b))
        return func

    # Set render functions
    f.set_renderfunc(RgbFg, render_rgb)
    f.set_eight

# Generated at 2022-06-21 23:56:40.196185
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import Sgr, EightBit, NoColor
    fg = Register()
    fg.set_renderfunc(Sgr, lambda *args: "".join(["✓"] * len(args)))
    fg.set_renderfunc(EightBit, lambda *args: "".join(["☑️"] * len(args)))
    fg.set_renderfunc(NoColor, lambda: "")
    fg.set_eightbit_call(EightBit)
    fg.set_rgb_call(NoColor)

    fg.black = Style(EightBit(0))
    fg.red = Style(EightBit(1))
    fg.green = Style(Sgr(30), Sgr(1))


# Generated at 2022-06-21 23:56:45.086168
# Unit test for method mute of class Register
def test_Register_mute():
    reg = Register()
    reg.foo = Style(value="\x1b[1m", rules=[Sgr(1)])
    reg.mute()
    assert reg.foo == ""
    reg.unmute()
    assert reg.foo == "\x1b[1m"



# Generated at 2022-06-21 23:56:51.550431
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    R = Register()
    R.black = Style(Sgr(0))
    R.set_renderfunc(Sgr, lambda *args: "")

    assert R.black == ""


# Generated at 2022-06-21 23:56:59.924994
# Unit test for constructor of class Register
def test_Register():
    """
    Create a basic register class and add some attributes.
    """
    def render_eightbit(val: int) -> str:
        return f"\x1b[38;5;{val}m"

    def render_rgb(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_sgr(val: int) -> str:
        return f"\x1b[{val}m"

    r = Register()
    r.set_eightbit_call(RenderType.EightBit)
    r.set_renderfunc(RenderType.EightBit, render_eightbit)
    r.set_rgb_call(RenderType.RgbFg)
    r.set_renderfunc

# Generated at 2022-06-21 23:57:04.977199
# Unit test for constructor of class Style
def test_Style():
    test_style = Style(value="\x1b[38;2;1;5;10m\x1b[1m")
    assert test_style == "\x1b[38;2;1;5;10m\x1b[1m"



# Generated at 2022-06-21 23:57:10.467799
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Test failed
    try:
        test = Style(1)
    except ValueError as e:
        assert e.args[0] == "Parameter 'rules' must be of type Iterable[Rule]."

    # Test successful
    try:
        test = Style(RgbFg(1,2,3), RgbBg(4,5,6))
    except ValueError as e:
        assert False


# Generated at 2022-06-21 23:57:18.401921
# Unit test for method __call__ of class Register
def test_Register___call__():

    r: Register = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.testcall = Style(RenderType(42))

    assert r(42) == "\x1b[42m"
    assert r(10, 42, 255) == "\x1b[10;42;255m"
    assert r("testcall") == "\x1b[42m"
    assert r(12345678) == "12345678"
    assert r("nonexistentcall") == ""



# Generated at 2022-06-21 23:57:25.178134
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .rendertypes.standard import RgbFg, Sgr

    s1: Style = Style(RgbFg(1,5,10), Sgr(1))
    s2: Style = Style("red")

    assert isinstance(s1, Style)
    assert isinstance(s2, Style)

    assert isinstance(s1, str)
    assert isinstance(s2, str)


# Generated at 2022-06-21 23:57:36.473916
# Unit test for method copy of class Register
def test_Register_copy():
    from .ansi_rendertype import AnsiFg
    from .sgr_rendertype import Sgr
    from .ansi_rendertype import AnsiEscape

    fg = Register()
    fg.red = Style(AnsiFg(2), Sgr(1))
    fg.blue = Style(AnsiFg(4), Sgr(1))

    fg.set_renderfunc(AnsiEscape, lambda x: "asdf")
    fg.set_eightbit_call(AnsiEscape)
    fg.set_rgb_call(AnsiEscape)

    fg.mute()

    assert fg.red == "asdf"
    assert fg.blue == "asdf"

    fg2: Register = fg.copy()


# Generated at 2022-06-21 23:57:40.595437
# Unit test for constructor of class Style
def test_Style():
    style = Style(fg.red)
    assert isinstance(style, str), "Style is not of type str"
    assert isinstance(style, Style), "Style is not of type Style"



# Generated at 2022-06-21 23:57:49.621039
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbFg

    # Set style register up
    r = Register()
    r.renderfuncs = {RgbFg: lambda r, g, b: f"{r}{g}{b}"}
    r.render = lambda r, g, b: f"{r}{g}{b}"
    r.red = Style(RgbFg(1, 3, 3))

    # Make sure the call of r.red returns the correct value
    assert r.red == "133"

    # Let's change the render function for Eightbit-calls.
    r.set_eightbit_call(RgbFg)

    # Check if this change was effective.
    assert r(14) == "134"
    assert r.red != "133"
    assert r.red == "134"



# Generated at 2022-06-21 23:57:58.051131
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    def f1(x):
        return f"{x}"

    def f2(a, b):
        return f"{a} {b}"

    r = Register()
    r.set_renderfunc(rendertype=int, func=f1)
    assert r.renderfuncs[int] == f1 # type: ignore

    r = Register()
    r.set_renderfunc(rendertype=NamedTuple, func=f2) # type: ignore
    assert r.renderfuncs[NamedTuple] == f2 # type: ignore

# Generated at 2022-06-21 23:58:18.667962
# Unit test for method mute of class Register
def test_Register_mute():
    from .fg import Fg
    from .rendertype import RgbFg
    from .sgr import Sgr

    fg = Fg()

    # Set two styles with renderfunc.
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda sgr: f"\x1b[{sgr}m")

    # Set two styles.
    fg.red = Style(RgbFg(255, 0, 0))
    fg.green = Style(RgbFg(0, 255, 0))

    # Muting the register renders both styles to an empty string.
    fg.mute()

# Generated at 2022-06-21 23:58:21.305943
# Unit test for method __new__ of class Style
def test_Style___new__():

    class A():
        pass

    a = A()
    a.b = Style(1, 2)

    assert a.b == Style(1, 2)
    assert isinstance(a.b, str)

# Generated at 2022-06-21 23:58:27.637008
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Unit tests for unmute() method fo Register class
    """
    from .sty import fg

    style = fg.red + "It's a red text"
    style_old = style
    style_old.rules = (style.rules)
    fg.mute()
    assert style == ""
    style.rules = (style_old.rules)
    fg.unmute()
    assert style == style_old


# Generated at 2022-06-21 23:58:29.122831
# Unit test for constructor of class Register
def test_Register():
    new_register = Register()
    assert isinstance(new_register, Register)



# Generated at 2022-06-21 23:58:32.761511
# Unit test for method mute of class Register
def test_Register_mute():
    from . import style
    before = style.fg.red
    style.fg.red = style.fg.red + style.Sgr(1)
    after = style.fg.red
    assert before != after
    style.fg.mute()
    assert before == style.fg.red

# Generated at 2022-06-21 23:58:40.135537
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .render import RgbFg, RgbBg
    from .rendertype import RenderType

    class RgbFg2(RgbFg, RenderType):
        pass

    class RgbBg2(RgbBg, RenderType):
        pass

    class MyRegister(Register):
        pass

    r = MyRegister()
    r.red = Style(RgbFg2(255, 0, 0))
    r.blue = Style(RgbBg2(0, 0, 255))
    r.green = Style(RgbFg2(0, 255, 0))

    d = r.as_dict()

    assert isinstance(d, dict)

# Generated at 2022-06-21 23:58:44.435573
# Unit test for method unmute of class Register
def test_Register_unmute():
    class MyRegister(Register):
        red = Style(RgbFg(10, 42, 255), RgbBg(5, 5, 5))

    reg = MyRegister()

    reg.mute()

    assert reg.red == ""

    reg.unmute()

    assert reg.red == "\x1b[38;2;10;42;255m\x1b[48;2;5;5;5m"

# Generated at 2022-06-21 23:58:50.444806
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Create a new Register-object, add a new render-function,
    create a style and check that the new render-function is used.
    """
    def func_1(*args):
        return f"\x1b[{args[0]};{args[1]}m"

    class RenderType1(RenderType):
        pass

    class RenderType2(RenderType):
        pass

    r = Register()
    r.set_renderfunc(RenderType1, func_1)

    r.blue_1 = Style(RenderType1(38, 5), RenderType2(1))

    assert r.blue_1 == "\x1b[38;5m\x1b[1m"


if __name__ == "__main__":
    test_Register_set_renderfunc()

# Generated at 2022-06-21 23:59:00.383616
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg

    new_register = Register()
    new_register.renderfuncs = {RgbFg: RgbFg.render, RgbBg: RgbBg.render}

    assert new_register(10, 20, 30) == ""
    assert new_register('test') == ''

    new_register.test = Style(RgbFg(10, 20, 30))
    new_register.mute()

    assert new_register(10, 20, 30) == ""
    assert new_register('test') == ''

    new_register.unmute()

    assert new_register(10, 20, 30) == "\x1b[38;2;10;20;30m"

# Generated at 2022-06-21 23:59:08.803152
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test method copy of Register-object.
    """
    from .sty import fg, bg

    rg = fg.copy()
    assert fg != rg
    assert fg.red != rg.red
    assert str(fg.red) == str(rg.red)

    bg.set_rgb_call(RgbBg)
    rgb = bg.copy()
    assert bg != rgb
    assert bg.test1 != bg.test1
    assert bg.test1(10, 20, 30) == bg.test1(10, 20, 30)

    assert rgb.test1(10, 20, 30) == "\x1b[48;2;10;20;30m"

# Generated at 2022-06-21 23:59:26.221634
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, RgbBold
    import textwrap

    register = Register()
    register.set_renderfunc(RgbFg, lambda r,g,b: textwrap.dedent(f"""
        \\x1b[38;2;{r};{g};{b}m"""))

    register.set_renderfunc(RgbBg, lambda r,g,b: textwrap.dedent(f"""
        \\x1b[48;2;{r};{g};{b}m"""))

    register.set_renderfunc(RgbBold, lambda r,g,b: textwrap.dedent(f"""
        \\x1b[38;2;{r};{g};{b}m\\x1b[1m"""))

    register.set

# Generated at 2022-06-21 23:59:37.007509
# Unit test for method __call__ of class Register
def test_Register___call__():

    from sty import fg
    from sty.rendertype import rendertype
    from sty.rendertype import RenderType

    class RgbFg(RenderType):
        rendertype_name = "RgbFg"
        rendertype_code = 38

    class Sgr(RenderType):
        rendertype_name = "Sgr"
        rendertype_code = 0

    @rendertype(name=RgbFg.rendertype_name, code=RgbFg.rendertype_code)
    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"


# Generated at 2022-06-21 23:59:48.394077
# Unit test for method mute of class Register

# Generated at 2022-06-21 23:59:52.759856
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .style import StyleRegister

    x = Register()
    x.blue = "blue"
    x.green = "green"
    y = StyleRegister(blue="blue", green="green")
    assert x.as_namedtuple() == y
    assert x.as_namedtuple().blue == y.blue == "blue"
    assert x.as_namedtuple().green == y.green == "green"

# Generated at 2022-06-21 23:59:54.537739
# Unit test for constructor of class Style
def test_Style():
    s1 = Style(RgbFg(1, 5, 10))
    assert isinstance(s1, Style)



# Generated at 2022-06-22 00:00:06.499695
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    import pytest
    from sty import ef, RgbFg, fg, Fg
    from sty.rendertype import RegisterType

    fg = fg.copy()

    fg.set_eightbit_call(RenderType)
    assert fg.eightbit_call == fg.renderfuncs[RenderType]

    with pytest.raises(KeyError):
        fg.set_eightbit_call(RegisterType)

    fg.set_eightbit_call(RgbFg)
    assert fg.eightbit_call == fg.renderfuncs[RgbFg]

    fg.set_eightbit_call(Fg)
    assert fg.eightbit_call == fg.renderfuncs[Fg]

    assert fg.eightbit_call(1) == ef.r

# Generated at 2022-06-22 00:00:10.011507
# Unit test for constructor of class Register
def test_Register():
    colors = Register()
    colors.red = "red"
    colors.green = "green"
    colors.blue = "blue"

    assert colors.red == "red"
    assert colors.green == "green"
    assert colors.blue == "blue"



# Generated at 2022-06-22 00:00:14.062630
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg = Register()
    t = reg.as_namedtuple()
    print(type(t))
    print(t)

# Generated at 2022-06-22 00:00:17.463530
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg

    fg.red = "red"
    fg.green = "green"
    fg.blue = "blue"

    assert fg.as_dict() == {"red": "red", "green": "green", "blue": "blue"}



# Generated at 2022-06-22 00:00:28.657215
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test if method copy of Register creates a new object with the same attributes
    of the previous object.
    """
    r1 = Register()
    r2 = Register()

    # Set attributes in both register-objects.
    r1.red = "red"
    r2.red = "red"

    r1.green = "green"
    r2.green = "green"

    r1.blue = "blue"
    r2.blue = "blue"

    # Mute r1.
    r1.mute()

    # Make a copy of r2.
    r3 = r2.copy()

    # Check if id() is not equal.
    assert id(r1) == id(r2)
    assert id(r2) != id(r3)

    # Check all attributes.
    assert r

# Generated at 2022-06-22 00:00:51.473154
# Unit test for method __call__ of class Register
def test_Register___call__():

    def assert_equal(input, expected):
        assert actual == expected

    register = Register()
    register.set_eightbit_call(RenderType)
    register.set_rgb_call(RenderType)
    register.default = Style(RenderType(42), value="\x1b[42m")
    register.red = Style()

    actual = register("default")
    expected = "\x1b[42m"
    assert_equal(actual, expected)

    actual = register(42)
    expected = "\x1b[42m"
    assert_equal(actual, expected)

    actual = register(1, 2, 3)
    expected = "\x1b[38;2;1;2;3m"
    assert_equal(actual, expected)

# Generated at 2022-06-22 00:01:01.940929
# Unit test for method mute of class Register
def test_Register_mute():

    rgb = RenderType()
    sgr = RenderType()

    def f1(*args):
        return "1"

    def f2(*args):
        return "2"

    def f3(*args):
        return "3"

    def f4(*args):
        return "4"

    rgf = Register()
    rgf.set_renderfunc(rgb, f1)
    rgf.set_renderfunc(sgr, f2)
    rgf.set_eightbit_call(rgb)
    rgf.set_rgb_call(sgr)

    rgf.test = Style(rgb(10))


# Generated at 2022-06-22 00:01:09.568645
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg
    from .sty import fg

    rgbfg = RgbFg(100, 100, 100)
    rgb = fg(100, 100, 100)
    assert rgb == fg.renderfuncs[RgbFg](*rgbfg.args)
    assert fg.rgb_call(100, 100, 100) == rgb

    fg.set_rgb_call(RgbBg)
    rgb = fg(100, 100, 100)
    assert rgb == fg.renderfuncs[RgbBg](*rgbfg.args)
    assert fg.rgb_call(100, 100, 100) == rgb

    fg.set_rgb_call(RgbFg)
    rgb = fg(100, 100, 100)

# Generated at 2022-06-22 00:01:12.916006
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    reg = Register()
    reg.fg_blue = Style()
    reg.set_eightbit_call(RgbFg)
    assert reg(4,2,2) == reg.fg_blue

register = Register()

# Generated at 2022-06-22 00:01:24.980880
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class StyleObject(RenderType):

        def get_sequence(self, *args):
            return f"{args[0]}"

    class StyleObject2(RenderType):

        def get_sequence(self, *args):
            return f"{args[0]}-{args[1]}"

    class StyleObject3(RenderType):

        def get_sequence(self, *args):
            return f"{args[0]}-{args[1]}-{args[2]}"

    from .rendertype import Sgr

    register = Register()
    register.set_renderfunc(StyleObject, lambda x: x)
    register.set_renderfunc(StyleObject2, lambda x, y: f"{x}-{y}")

# Generated at 2022-06-22 00:01:32.626327
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import RgbFg, RgbBg, Sgr

    r = Register()

    r.a = Style(RgbFg(10, 20, 30), Sgr(1, 2), Sgr(3, 4))

    assert isinstance(r.a, Style)

    assert isinstance(r.a, str)

    assert str(r.a) == "\x1b[38;2;10;20;30m\x1b[1;2m\x1b[3;4m"

    assert hasattr(r, "set_renderfunc")



# Generated at 2022-06-22 00:01:42.499827
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .rendertype import Sgr
    from .colorscheme import Colorscheme

    s = Colorscheme()

    s["fg"]["red"] = Style(Sgr(1), Sgr(38, 2, 10, 10, 10))
    s["bg"]["green"] = Style(Sgr(48, 2, 10, 10, 10))
    s["ef"]["yellow"] = Style(Sgr(48, 2, 10, 10, 10))

    nt1 = s["fg"].as_namedtuple()
    nt2 = s["bg"].as_namedtuple()
    nt3 = s["ef"].as_namedtuple()

    assert nt1.red == "\x1b[1m\x1b[38;2;10;10;10m"
    assert nt2

# Generated at 2022-06-22 00:01:48.922093
# Unit test for constructor of class Style
def test_Style():

    from sty import colors

    colors.fg.orange = Style(RgbFg(1,5,10), Sgr(1))

    assert isinstance(colors.fg.orange, Style)
    assert isinstance(colors.fg.orange, str)
    assert str(colors.fg.orange) == '\x1b[38;2;1;5;10m\x1b[1m'

# Generated at 2022-06-22 00:01:57.059479
# Unit test for method copy of class Register
def test_Register_copy():

    import sty

    r1 = Register()
    r1.set_eightbit_call(sty.SgrFg)
    r1.set_rgb_call(sty.RgbFg)
    r1.KEY = Style(sty.SgrEf(1), sty.RgbFg(10, 100, 200))

    r2 = r1.copy()

    assert r1 is not r2
    assert r1.KEY is not r2.KEY
    assert r1.KEY.rules is not r2.KEY.rules

    assert r1.__dict__ == r2.__dict__

if __name__ == "__main__":

    import doctest

    doctest.testmod(
        optionflags=doctest.NORMALIZE_WHITESPACE, verbose=False, report=True
    )

# Generated at 2022-06-22 00:02:00.568407
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    rf: RenderType = namedtuple("RenderFunc", [])(args=[])

    def renfunc(self, rf):
        return ""

    r = Register()
    r.set_renderfunc(rf, renfunc)
    assert r.renderfuncs[rf] == renfunc



# Generated at 2022-06-22 00:02:31.158482
# Unit test for method __new__ of class Style
def test_Style___new__():
    rules = [Sgr(1)]
    value = ""
    style = Style(*rules, value=value)
    assert style.rules == rules

    assert isinstance(style, Style) is True
    assert isinstance(style, str) is True

    assert style == value



# Generated at 2022-06-22 00:02:42.879433
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from . import rendertype as RenderType

    class RgbFg(RenderType):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class RgbBg(RenderType):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    def rgb_fg_func(*args) -> str:
        return "\x1b[38;2;{};{};{}m".format(*args)

    def rgb_bg_func(*args) -> str:
        return "\x1b[48;2;{};{};{}m".format(*args)

    r = Register()
    r.set_renderfunc(RgbFg, rgb_fg_func)
    r.set_

# Generated at 2022-06-22 00:02:44.397714
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg
    cls = fg.red
    assert isinstance(cls, str)
    return


# Generated at 2022-06-22 00:02:52.613931
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Fg(Register):
        _red = Style(RgbFg(255, 0, 0))

    fg = Fg()
    fg.set_rgb_call(RgbFg)
    fg.set_eightbit_call(TrueColorFg)

    assert fg(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert fg("red") == "\x1b[38;2;255;0;0m"
    assert fg(1) == "\x1b[38;2;1;1;1m"

# Generated at 2022-06-22 00:02:59.919735
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbBg, Sgr

    # Set up test attributes without using __setattr__
    class TestStyle(Style):
        def __init__(self, *args: StylingRule, value: str) -> None:
            super().__setattr__("rules", args)
            super().__setattr__("value", value)

    s = TestStyle(Sgr(1), RgbBg(255, 0, 0))
    assert isinstance(s, Style)
    assert isinstance(s, str)



# Generated at 2022-06-22 00:03:05.365285
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import unittest

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.key1 = "value1"
            self.key2 = "value2"

    register = TestRegister()

    assert register.as_dict() == {"key1": "value1", "key2": "value2"}



# Generated at 2022-06-22 00:03:15.365806
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .rendertypes import Sgr, RgbBg, RgbFg

    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbBg(0, 0, 255), Sgr(5))

    styles = r.as_namedtuple()

    assert isinstance(styles, NamedTuple)
    assert isinstance(styles.red, str)
    assert isinstance(styles.blue, str)
    assert styles.red == "\x1b[38;2;255;0;0m"
    assert styles.blue == "\x1b[48;2;0;0;255m\x1b[5m"

# Generated at 2022-06-22 00:03:19.571778
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    x = Register()
    x.red = Style(Sgr(1))
    namedtuple_obj = x.as_namedtuple()
    assert_namedtuple(namedtuple_obj, "red", "\x1b[1m")



# Generated at 2022-06-22 00:03:30.862183
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class R1(RenderType):
        pass

    class R2(RenderType):
        pass

    def f1(x: int) -> str:
        return f"\x1b[38;5;{x}m"

    def f2(x: int) -> str:
        return f"\x1b[48;5;{x}m"

    r: Register = Register()
    r.set_renderfunc(R1, f1)
    r.set_renderfunc(R2, f2)

    assert r.renderfuncs[R2] == f2

    r2: Register = r.copy()
    r2.set_renderfunc(R1, f2)
    r2.set_renderfunc(R2, f1)

    assert r.renderfuncs[R2] == f2


# Generated at 2022-06-22 00:03:35.086295
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg = Register()
    reg.one = Style(value="one")
    reg.two = Style(value="two")

    NT = reg.as_namedtuple()

    assert hasattr(NT, "one")
    assert hasattr(NT, "two")
    assert "one" == getattr(NT, "one")
    assert "two" == getattr(NT, "two")



# Generated at 2022-06-22 00:04:29.370391
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # TODO: Test
    pass



# Generated at 2022-06-22 00:04:40.424608
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Setup dummy renderfunc and register object
    def dummy_render(color: int) -> str:
        return f"\x1b[1;38;5;{color}m"

    fg = Register()
    fg.renderfunc = dummy_render

    # Define new renderfunc
    def dummy_render2(color: int) -> str:
        return f"\x1b[1;38;5;{color}m"

    # Replace renderfunc
    # fg.set_renderfunc(dummy_render2)

    # Check if new renderfunc is used for existing style
    assert fg.test == "\x1b[1;38;5;100m"

    # Setup new style
    fg.test2 = Style("test")

    # Check if new renderfunc is used for new style
    assert f

# Generated at 2022-06-22 00:04:50.978202
# Unit test for method __call__ of class Register
def test_Register___call__():

    class MyRegister(Register):
        pass

    renderfuncs: Renderfuncs = {
        int: lambda x: f"a{x}a",
        str: lambda x: f"b{x}b",
        tuple: lambda x, y, z: f"c{x}{y}{z}c",
    }

    rg = MyRegister()
    for rt, func in renderfuncs.items():
        rg.set_renderfunc(rt, func)

    setattr(rg, "int", Style(1, 2, 3))
    setattr(rg, "str", Style("abc"))
    setattr(rg, "tuple", Style((1, 1, 1), "abc"))

    assert rg(1) == "a1a"
    assert rg(1, 2, 3) == "c123c"
    assert rg

# Generated at 2022-06-22 00:04:54.679458
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class MyRegister(Register):
        test = Style(RgbFg(5,5,5))

    reg = MyRegister()

    assert reg.as_dict() == {"test": "\x1b[38;2;5;5;5m"}


# Generated at 2022-06-22 00:05:06.271144
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import Eightbit, RgbFg

    c1: Style = Style("style1")
    c2: Style = Style("style2", "style3")

    assert isinstance(c1, Style)
    assert isinstance(c2, Style)
    assert str(c1) == "style1"
    assert str(c2) == "style2"
    assert c2.rules == ("style3",)

    c3: Style = Style(RgbFg(1, 2, 3), Eightbit(200))
    assert isinstance(c3, Style)
    assert str(c3) == "\x1b[38;2;1;2;3m\x1b[38;5;200m"
    assert c3.rules[0].__class__ == RgbFg
    assert c3.rules

# Generated at 2022-06-22 00:05:14.755417
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():


    class MySgr(RenderType):
        def as_ansi(self):
            return "FOO"

    class MyRgbFg(RenderType):
        def as_ansi(self):
            return "BAR"

    myrgb = MyRgbFg()
    mysgr = MySgr()

    fg = Register()
    fg.red = Style(myrgb)
    fg.bold = Style(mysgr)

    fg.set_eightbit_call(MyRgbFg)
    assert fg("red") == "BAR"

    fg.set_eightbit_call(MySgr)
    assert fg("red") == "FOO"

