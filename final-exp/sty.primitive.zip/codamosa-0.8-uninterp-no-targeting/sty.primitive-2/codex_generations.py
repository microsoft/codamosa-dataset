

# Generated at 2022-06-21 23:55:23.610045
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.blue = "blue"
    assert isinstance(r.as_namedtuple(), NamedTuple)

# Generated at 2022-06-21 23:55:31.677174
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr, RgbBg, RgbFg

    def testfunc(x: int) -> str:
        return "testfunc"

    register1 = Register()
    register1.set_renderfunc(Sgr, testfunc)
    register2 = Register()
    register2.set_renderfunc(RgbBg, testfunc)
    register3 = Register()
    register3.set_renderfunc(RgbFg, testfunc)

    assert register1.renderfuncs[Sgr] == testfunc
    assert register2.renderfuncs[RgbBg] == testfunc
    assert register3.renderfuncs[RgbFg] == testfunc

# Generated at 2022-06-21 23:55:43.957763
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sty import fg

    from .rendertype import Sgr, RgbFg

    fg.red = Style(Sgr(1), RgbFg(255, 0, 0))
    fg.green = Style(Sgr(1), RgbFg(0, 255, 0))
    fg.blue = Style(Sgr(1), RgbFg(0, 0, 255))

    assert fg.as_namedtuple() == namedtuple('StyleRegister', ('red', 'green', 'blue'))('\x1b[1m\x1b[38;2;255;0;0m', '\x1b[1m\x1b[38;2;0;255;0m', '\x1b[1m\x1b[38;2;0;0;255m')

# Generated at 2022-06-21 23:55:51.780669
# Unit test for method unmute of class Register
def test_Register_unmute():

    class RgFg(RenderType):  # This is the rendertype for Foreground colors.
        cmd = 38

    class Bg(RenderType):  # This is the rendertype for Background colors.
        cmd = 48

    class Sgr(RenderType):  # This is the rendertype for SGR commands.
        cmd = 0

    def render_rgbfg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{bm}m"

    def render_bgrgb(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{bm}m"


# Generated at 2022-06-21 23:56:00.653456
# Unit test for method __new__ of class Style
def test_Style___new__():

    s = Style(value="\x1b[38;2;255;255;255m")

    assert s == "\x1b[38;2;255;255;255m"
    assert s.rules == ()

    s2 = Style(RgbFg(255, 255, 255), value="\x1b[38;2;255;255;255m")

    assert s2 == "\x1b[38;2;255;255;255m"
    assert s2.rules == (RgbFg(255, 255, 255),)

# Generated at 2022-06-21 23:56:10.707670
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Test rendertype class
    class Test1(RenderType): pass
    class Test2(RenderType): pass

    # Test function
    def f1(*args): return "Hallo"
    def f2(*args): return "Welt"

    r = Register()
    r.set_renderfunc(Test1, f1)
    r.set_renderfunc(Test2, f2)

    r.set_eightbit_call(Test1)

    assert r(42) == "Hallo"
    assert r(42) != "Welt"

    r.set_eightbit_call(Test2)
    assert r(42) != "Hallo"
    assert r(42) == "Welt"



# Generated at 2022-06-21 23:56:22.821180
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, EightBg, EightBgBright

    # Setup
    fg: Register = Register()
    fg.red = Style(RgbFg(255, 0, 0))
    fg.orange = Style(RgbFg(255, 128, 0))
    fg.set_rgb_call(RgbBg)

    # Run
    result_1: str = str(fg(192, 64, 0))
    result_2: str = str(fg("orange"))
    result_3: str = str(fg(255, 128, 0))

    # Assert
    assert result_1 == "\x1b[48;2;192;64;0m"
    assert result_2 == fg.orange

# Generated at 2022-06-21 23:56:29.768061
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Tests the method `Register.as_namedtuple`
    """
    fg = Register()
    setattr(fg, "red", Style(RgbFg(255, 0, 0)))
    setattr(fg, "green", Style(RgbFg(0, 255, 0)))
    nt = fg.as_namedtuple()
    assert nt.red == "\x1b[38;2;255;0;0m"
    assert nt.green == "\x1b[38;2;0;255;0m"

# Generated at 2022-06-21 23:56:34.939038
# Unit test for constructor of class Style
def test_Style():

    from .sgr import Sgr
    from .rgb_fg import RgbFg

    style_1: Style = Style(RgbFg(10, 20, 30))
    style_2: Style = Style(style_1, Sgr(1))  # type: ignore

    assert len(style_2.rules) == 2

# Generated at 2022-06-21 23:56:38.387110
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test the set_rgb_call-method.
    """
    reg = Register()
    reg.set_rgb_call(RgbFg)

    assert reg.rgb_call == reg.renderfuncs[RgbFg]



# Generated at 2022-06-21 23:56:46.113474
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()

    s = Style(RgbFg(1, 2, 3), Sgr(0))
    setattr(r, "orange", s)

    r.set_rgb_call(RgbFg)

    assert str(r(1, 2, 3)) == str(r(rgb=True, rgb_fg=(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(r.orange) == str(r(rgb=True, rgb_fg=(1, 2, 3))) == "\x1b[38;2;1;2;3m"

# Generated at 2022-06-21 23:56:56.201323
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    r = Register()
    r.set_eightbit_call(type(RgbFg(1, 2, 3)))
    r.set_rgb_call(type(RgbFg(1, 2, 3)))

    r.red = Style(RgbFg(255, 0, 0))
    r.green = Style(RgbFg(0, 255, 0))

    a = r.as_dict()

    assert isinstance(a, Dict)
    assert a["red"] == "\x1b[38;2;255;0;0m"
    assert a["green"] == "\x1b[38;2;0;255;0m"



# Generated at 2022-06-21 23:56:58.909753
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .register_fg import fg

    t1 = fg.red

    fg_red: Dict[str, str] = fg.red.as_dict()

    assert "red" in fg_red.keys()
    assert str(t1) == fg_red["red"]



# Generated at 2022-06-21 23:57:10.240772
# Unit test for method unmute of class Register
def test_Register_unmute():
    eightbit = {
        "pink": Style(EightbitFg(61), Bold()),
        "green": Style(EightbitBg(68), Underline()),
        "bright": Style(Light()),
    }
    rendertype = EightbitFg
    test = Register()
    test._eightbit_call_ = lambda x, y: y
    test.set_eightbit_call(EightbitFg)

    for key, value in eightbit.items():
        setattr(test, key, value)

    test.mute()
    for key in eightbit.keys():
        assert getattr(test, key) == ""
    test.unmute()
    for key, value in eightbit.items():
        assert getattr(test, key) == rendertype(*value.rules).call()

# Generated at 2022-06-21 23:57:21.285171
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .render import Sgr, RgbFg, RgbBg

    def _render_sgr(num, _):
        return f"\033[{num}m"

    def _render_rgb(num, r, g, b):
        return f"\033[{num};2;{r};{g};{b}m"

    r = Register()
    r.set_renderfunc(Sgr, _render_sgr)
    r.set_renderfunc(RgbFg, _render_rgb)
    r.set_renderfunc(RgbBg, _render_rgb)
    r.set_eightbit_call(Sgr)
    r.set_rgb_call(RgbFg)

    # set some styles

# Generated at 2022-06-21 23:57:31.284365
# Unit test for method __call__ of class Register
def test_Register___call__():

    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.styling_rule_name = Style(RenderType(42))
    assert r("styling_rule_name") == "\x1b[38;5;42m"
    assert r(42) == "\x1b[38;5;42m"
    assert r(42, 43, 44) == "\x1b[38;2;42;43;44m"
    assert r("43") == ""
    assert r(1, 2, 3, 4) == ""


# Generated at 2022-06-21 23:57:40.897620
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .sgr import SgrFg

    class NewRegister(Register):
        pass

    r = NewRegister()
    r.renderfuncs.update({SgrFg: lambda x: f"\x1b[38;5;{x}m"})
    r.set_eightbit_call(SgrFg)

    r.red = Style(SgrFg(1))

    assert r.red == "\x1b[38;5;1m"
    assert r(1) == "\x1b[38;5;1m"
    assert r("red") == "\x1b[38;5;1m"



# Generated at 2022-06-21 23:57:47.626468
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .rendertype import Sgr, RgbEf
    from .register import Register

    new_reg = Register()
    new_reg.style1 = Style(Sgr(1))
    new_reg.style2 = Style(Sgr(1), RgbEf(255, 255, 255))

    reg_namedtuple = new_reg.as_namedtuple()

    assert isinstance(reg_namedtuple, NamedTuple)
    assert hasattr(reg_namedtuple, "style1")
    assert hasattr(reg_namedtuple, "style2")



# Generated at 2022-06-21 23:57:50.085512
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style('hi')
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert style == 'hi'
    assert style.rules == ('hi',)


# Generated at 2022-06-21 23:58:01.790722
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .standard_register import StandardRegister
    from .rendertype import RenderType

    def my_render_func(r: int, g: int, b: int) -> str:
        return f"{r}{g}{b}"

    my_reg = StandardRegister()

    # Set new renderfunc for 24bit colors:
    my_reg.set_renderfunc(rendertype=RenderType.RGB_FG, func=my_render_func)

    # Set a new rendertype for rgb-calls:
    my_reg.set_rgb_call(rendertype=RenderType.RGB_FG)

    # Make sure that the new render-function is used:
    assert my_reg(42, 255, 9) == "422559"

    # Make sure that the new render-function is also used for style attributes:
    my_reg.my

# Generated at 2022-06-21 23:58:14.825698
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg
    _r1 = Register()
    _r1.rgb_fg = Style(RgbFg(0,0,0))
    _r1.rgb_fg.mute()
    assert _r1.rgb_fg == ""
    _r1.unmute()
    assert _r1.rgb_fg == "\x1b[38;2;0;0;0m"



# Generated at 2022-06-21 23:58:22.861402
# Unit test for method mute of class Register
def test_Register_mute():

    from ..rendertype import Rgb8bit, RgbFg, SgrFg, Sgr

    # Create a register object instance and give it some attributes
    r = Register()
    rgb_func = lambda r, g, b: (r, g, b)
    setattr(r, "red", Style(RgbFg(255, 0, 0)))
    setattr(r, "blue", Style(RgbFg(0, 0, 255), Sgr(1)))

    # Set render function for RgbFg and Sgr
    r.set_renderfunc(RgbFg, rgb_func)
    r.set_renderfunc(Sgr, lambda *args, **kwargs: args)

    # Set calls
    r.set_rgb_call(Rgb8bit)

# Generated at 2022-06-21 23:58:26.020132
# Unit test for method copy of class Register
def test_Register_copy():
    class RegisterCopy(Register):
        pass
    r = RegisterCopy()
    assert type(r.copy()) == RegisterCopy


# Generated at 2022-06-21 23:58:30.277470
# Unit test for method __new__ of class Style
def test_Style___new__():

    def f():
        pass

    # Test reference equality of Style objects
    style1 = Style(f, value="\x1b[0m")
    style2 = Style(f, value="\x1b[0m")

    assert style1 == style2
    assert id(style1) == id(style2)


# Generated at 2022-06-21 23:58:38.103425
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Test(Register):

        def __init__(self):
            super().__init__()
            self.default: Style = Style(Sgr(1))
            self.value = Style(Sgr(1))

    t = Test()
    t.value = Style(Sgr(0))

    assert t.value == "\x1b[0m"

    t.value = Style(Sgr(2))

    assert t.value == "\x1b[2m"

    t.value = Style(Sgr(0))
    assert t.value == "\x1b[0m"

    t.default.rules = [Sgr(2)]

    assert t.default == "\x1b[2m"
    assert t.value == "\x1b[0m"

    t.value = t.default


# Generated at 2022-06-21 23:58:45.880977
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    import sty

    reg = sty.register.get_by_name("ansi")

# Generated at 2022-06-21 23:58:50.800321
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Test(RenderType):
        pass

    def func(a, b):
        return f"{a}{b}"

    reg = Register()
    reg.set_renderfunc(Test, func)
    assert reg.renderfuncs[Test] == func
    assert Test(1, 2) == "12"
    assert reg.renderfuncs[Test](1, 2) == "12"
    assert Test == Test(1, 2)

# Generated at 2022-06-21 23:59:00.743818
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def func1(val):
        return "F1-%d" % val

    def func2(r, g, b):
        return "F2-%d-%d-%d" % (r, g, b)

    RenderFuncTest = namedtuple("RenderFuncTest", ["func", "args", "result"])

    TestValues: List[RenderFuncTest] = [
        RenderFuncTest(func=func1, args=(42,), result="F1-42"),
        RenderFuncTest(func=func2, args=(42, 23, 17), result="F2-42-23-17")
    ]

    reg = Register()
    for t in TestValues:
        reg.set_renderfunc(RenderType, t.func)

        res = reg(42)  # Eightbit-Call
       

# Generated at 2022-06-21 23:59:08.134513
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Test method as_dict of class Register.
    """

    from .sty.ansi import fg, bg, Style, Sgr

    reset = Style(Sgr(0))
    fg.red = Style(Sgr(31), reset=reset)
    bg.blue = Style(Sgr(44), reset=reset)

    d = fg.as_dict()
    assert d["red"] == "\x1b[31m\x1b[0m"

    d = bg.as_dict()
    assert d["blue"] == "\x1b[44m\x1b[0m"

test_Register_as_dict()

# Generated at 2022-06-21 23:59:13.717564
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    import sty

    class A(Register):
        pass

    a = A()

    a.one = Style(sty.reset)
    a.two = Style(sty.fg.orange)

    assert isinstance(a.one, Style)
    assert isinstance(a.one, str)
    assert isinstance(a.two, Style)
    assert isinstance(a.two, str)

# Generated at 2022-06-21 23:59:21.790422
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg, ef, rs

    ef.set_rgb_call(fg)
    assert ef.rgb_call == fg.rgb

    rs.set_rgb_call(fg)
    assert rs.rgb_call == fg.rgb


# Generated at 2022-06-21 23:59:33.540672
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test the unmute method of class Register. The basic idea is that we set up a register
    with a render function that changes the style to orange. Then we mute the register and
    finally unmute it again.

    If this is working as expected we should see unormally orange text ignoring the
    mute/unmute calls.
    """
    # Set up register with renderfunc
    myreg = Register()
    myreg.set_renderfunc(RenderType, lambda x: f"{x}test")

    # Create some styles
    myreg.blue = Style(
        RenderType(1),
        RenderType(2),
        Style(
            RenderType(3),
            RenderType(4),
            Style(
                RenderType(5),
                RenderType(6),
            ),
        ),
    )
    myreg.orange

# Generated at 2022-06-21 23:59:40.982656
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RenderType
    from .rendertypes.rgb import RgbBg, RgbFg

    r = Register()
    f = lambda r,g,b: "..."

    r.set_renderfunc(RgbBg, f)

    assert r.eightbit_call is r.rgb_call
    assert r.eightbit_call is not f

    r.set_rgb_call(RgbFg)
    assert r.rgb_call is not r.eightbit_call
    assert r.rgb_call is f



# Generated at 2022-06-21 23:59:50.864029
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg

    class RegisterMock(Register):
        pass

    # First define test renderfunc.
    def f(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    register = RegisterMock()
    register.set_renderfunc(RgbFg, f)

    # Test if rgb-call is disabled by default.
    assert register(41, 42, 43) == ""

    # Test if rgb-call is enabled.
    register.set_rgb_call(RgbFg)
    assert register(41, 42, 43) == "\x1b[38;2;41;42;43m"

# Generated at 2022-06-21 23:59:53.622773
# Unit test for constructor of class Register
def test_Register():
    style = RenderType(0, 0, 0)
    r = Register()
    r.set_renderfunc(RenderType, lambda x, y, z: "")
    r.red = Style(style, "A")
    assert r.red == ""

# Generated at 2022-06-21 23:59:58.111265
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    import random

    from . import fg, bg, ef, rs

    def get_random_register():
        regs = (fg, bg, ef, rs)
        return regs[random.randint(0, len(regs)-1)]

    for _ in range(42):
        reg = get_random_register()
        nt1 = reg.as_namedtuple()
        nt2 = reg.as_namedtuple()
        assert nt1 == nt2
        assert nt1.__hash__() == nt2.__hash__()

# Generated at 2022-06-22 00:00:00.975514
# Unit test for method copy of class Register
def test_Register_copy():
    fg = Register()
    assert fg.copy() is not fg, "The copied object is still the same."

# Generated at 2022-06-22 00:00:06.770241
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    renderfuncs: Renderfuncs = {int: lambda *a: f"<{a}>"}
    test_register = Register()
    test_register.set_renderfunc(int, renderfuncs[int])

    style_test = Style(2, 3, 4)

    test_register.test_style = style_test

    assert test_register.test_style == "<2><3><4>"

# Generated at 2022-06-22 00:00:11.308827
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style(fg.red, bg.black), Style)

    assert isinstance(Style(fg.red, bg.black), str)

    assert str(Style(fg.red, bg.black)) == "\x1b[31m\x1b[40m"



# Generated at 2022-06-22 00:00:17.509306
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Register.set_eightbit_call(rendertype) -> None
    """
    from .rendertype import EightBit
    from .renderfunc import render_eightbit_color

    r = Register()
    r.set_rgb_call(EightBit)
    r.set_renderfunc(EightBit, render_eightbit_color)
    assert r(12) == "\x1b[38;5;12m"

# Generated at 2022-06-22 00:00:34.561890
# Unit test for method __call__ of class Register
def test_Register___call__():

    reg = Register()
    rendered = reg.__call__(144)
    assert rendered == ""

    reg = Register()
    reg.set_eightbit_call(RenderType)
    rendered = reg.__call__(144)
    assert rendered == "\x1b[38;5;144m"

    reg = Register()
    reg.set_rgb_call(RenderType)
    rendered = reg.__call__(144, 255, 102)
    assert rendered == "\x1b[38;2;144;255;102m"

    reg = Register()
    reg.set_rgb_call(RenderType)
    rendered = reg.__call__("red")
    assert rendered == ""

# Generated at 2022-06-22 00:00:37.599370
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r1 = Register()
    r1.set_renderfunc(RenderType.ANSI, lambda x: x)



# Generated at 2022-06-22 00:00:46.733839
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import Bold, EightbitBg, EightbitFg, RgbBg, RgbFg, RgbMode

    class DummyRegister(Register):
        """
        Dummy class for unit test for method as_dict of class Register
        """

        def __init__(self):
            super().__init__()
            self.red = Style(RgbBg(255, 0, 0))
            self.green = Style(RgbFg(0, 255, 0))
            self.blue = Style(Bold, EightbitFg(17))

    dummy_register = DummyRegister()

# Generated at 2022-06-22 00:00:54.256031
# Unit test for method __call__ of class Register
def test_Register___call__():
    from . import fg, bg, ef, rs
    from .rendertype import EightBitFg, EightBitBg
    from .rendertype import RgbFg, RgbBg
    from .rendertype import EightBitEffect, ResetSequence

    #8bit:
    assert fg(10) == "\x1b[38;5;10m"
    assert bg(42) == "\x1b[48;5;42m"
    assert ef(0) == EightBitEffect(0)()
    assert rs(1) == ResetSequence(1)()

    #8bit-str lookup:
    assert fg("black") == "\x1b[38;5;0m"
    assert bg("light_green") == "\x1b[48;5;154m"

    #rgb:


# Generated at 2022-06-22 00:01:04.787683
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # a dummy color register
    class MyRegister(Register):
        pass

    r = MyRegister()

    # a dummy rendertype
    class RenderType1:
        def __init__(self, arg1):
            self.arg1 = arg1

        def __str__(self):
            return "RENDERTYPE1"

    # a dummy rendertype
    class RenderType2:
        def __init__(self, arg1):
            self.arg1 = arg1

        def __str__(self):
            return "RENDERTYPE2"

    RenderType1.__name__ = "RenderType1"
    RenderType2.__name__ = "RenderType2"

    # a dummy style, consisting of two rendertypes
    style = Style(RenderType1(1), RenderType2(2))

    # add a renderfunc

# Generated at 2022-06-22 00:01:14.699595
# Unit test for method mute of class Register
def test_Register_mute():
    class TestClass(Register):
        def __init__(self):
            self.test = Style(RgbFg(0, 0, 0), Sgr(1))
            super().__init__()

        def test_func():
            pass

    r = TestClass()
    test_str = r.test
    r.mute()
    assert str(r.test) == ""
    assert r.test.rules == r.test.rules
    assert r.test_func == r.test_func
    r.unmute()
    assert str(test_str) == str(r.test)
    assert r.test.rules == r.test.rules
    assert r.test_func == r.test_func

# Generated at 2022-06-22 00:01:25.621297
# Unit test for constructor of class Style
def test_Style():
    # Test with constructor only
    s1 = Style()
    assert isinstance(s1, str)
    assert isinstance(s1, Style)
    assert str(s1) == ""
    
    # Test with constructor and parameter value
    s2 = Style(value="\x1b[1m")
    assert isinstance(s2, str)
    assert isinstance(s2, Style)
    assert str(s2) == "\x1b[1m"

    # Test with constructor, rules and value
    from .rendertype import RgbBg
    s3 = Style(RgbBg(10,20,30), RgbBg(40,50,60), value="\x1b[48;2;40;50;60m\x1b[48;2;10;20;30m")

# Generated at 2022-06-22 00:01:35.605645
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Test1(RenderType):
        name = "Test1"
        args = ()

    class Test2(RenderType):
        name = "Test2"
        args = ()

    r = Register()
    r.set_renderfunc(Test1, lambda: "ANSI1")
    r.set_renderfunc(Test2, lambda: "ANSI2")

    r.test = Style(Test1())
    r.test2 = Style(Test2())

    str(r.test) == "ANSI1"
    str(getattr(r, "test")) == "ANSI1"
    str(r.test2) == "ANSI2"
    str(getattr(r, "test2")) == "ANSI2"
    isinstance(r.test, str)
    isinstance(r.test2, str)

# Generated at 2022-06-22 00:01:46.353955
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import EightbitFg, EightbitBg, EightbitRs, RgbFg, RgbBg

    # Create a register
    register = Register()

    # Create dummy renderfuncs
    render_eightbit_fg = lambda x: "1;38;5;{}m".format(x)
    render_rgb_fg = lambda r, g, b: "2;38;2;{};{};{}m".format(r, g, b)

    # Add renderfuncs
    register.set_renderfunc(EightbitFg, render_eightbit_fg)
    register.set_renderfunc(EightbitBg, render_eightbit_fg)
    register.set_renderfunc(EightbitRs, lambda: "0m")

# Generated at 2022-06-22 00:01:53.992016
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Register is subclass of Register
    assert issubclass(Register, Register)

    # Create a new Register
    r = Register()

    # Add some styles
    r.green = Style(value="\x1b[32m")
    r.brown = Style(value="\x1b[33;1m")

    # Convert register to namedtuple
    nt = r.as_namedtuple()

    # Check that we have the namedtuple we expected
    assert isinstance(nt, NamedTuple)
    assert nt.green == "\x1b[32m"
    assert nt.brown == "\x1b[33;1m"

# Generated at 2022-06-22 00:02:07.968846
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style(value="Oh my god!")
    assert style == "Oh my god!"
    assert len(style) == 11
    assert str(style) == "Oh my god!"
    assert style.rules == ()
    style2 = Style(value="Oh my god 2!")
    assert style2 == "Oh my god 2!"
    assert str(style2) == "Oh my god 2!"
    assert len(style2) == 13
    assert style2.rules == ()



# Generated at 2022-06-22 00:02:12.259824
# Unit test for method __call__ of class Register
def test_Register___call__():

    class TestRegister(Register):
        red: Style = Style(RgbFg(255, 0, 0))

    tr = TestRegister()

    # Test call with int
    assert tr(255, 0, 0) == tr.red

    # Test call with string
    assert tr("red") == tr.red


# Generated at 2022-06-22 00:02:22.552337
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Create Register
    register = Register()

    # Add render func for color type RgbFg
    register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Add render func for color type RgbBg
    register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    # Set RgbFg as default render func for RGB-calls
    register.set_rgb_call(RgbFg)

    # Make rgb-call
    register(1, 2, 3) == "\x1b[38;2;1;2;3m"

    # Set RgbBg as default

# Generated at 2022-06-22 00:02:28.023930
# Unit test for method mute of class Register
def test_Register_mute():


    class SomeRenderType:
        def __init__(self, val):
            self.val = val

    class SomeOtherRenderType:
        def __init__(self, val):
            self.val = val

    def render1(x: SomeRenderType) -> str:
        return x.val + "1"

    def render2(x: SomeOtherRenderType) -> str:
        return x.val + "2"

    '''
    Because our register has been muted with Register.mute, it will only
    return an empty string.
    '''
    reg = Register()
    reg.set_renderfunc(SomeRenderType, render1)
    reg.set_renderfunc(SomeOtherRenderType, render2)

    reg.test1 = Style(SomeRenderType("t1"))

# Generated at 2022-06-22 00:02:33.644404
# Unit test for method mute of class Register
def test_Register_mute():

    from .sgr import Sgr

    # Test case mute
    m1 = Register()
    m1.set_renderfunc(Sgr, lambda x: "mute_" + str(x))
    m1.underline = Style(Sgr(4))
    assert m1.underline == "mute_4"

    m1.mute()
    assert m1.underline == ""

    m1.unmute()
    assert m1.underline == "mute_4"

    # Test case unmute
    m1.mute()
    assert m1.underline == ""

    m1.unmute()
    assert m1.underline == "mute_4"



# Generated at 2022-06-22 00:02:40.712508
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .ansi import fg
    from .ansi_extended import ef
    from .colors import colors

    ef.green = colors.green

    MyStyleRegister = fg.as_namedtuple()
    MyExtendedRegister = ef.as_namedtuple()

    assert MyStyleRegister.blue == fg.blue
    assert MyExtendedRegister.green == ef.green

# Generated at 2022-06-22 00:02:44.652550
# Unit test for method copy of class Register
def test_Register_copy():

    from .sgr import Sgr

    r1 = Register()
    r1.bold = Style(Sgr(1))

    assert r1.bold == "\x1b[1m"

    r2 = r1.copy()

    assert r2.bold == r1.bold

    r2.bold = ""

    assert r1.bold != ""
    assert r2.bold == ""



# Generated at 2022-06-22 00:02:48.354424
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import RgbFg, Sgr
    rules = [RgbFg(10, 20, 30), Sgr(1)]
    style = Style(*rules)
    assert style.rules == rules

# Generated at 2022-06-22 00:02:51.274032
# Unit test for method __new__ of class Style
def test_Style___new__():
    ret: Style = Style(RgbFg(0, 0, 0))
    assert ret == ""
    assert ret.rules == (RgbFg(0, 0, 0),)


# Generated at 2022-06-22 00:03:01.957908
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .ansi import (
        RenderType,
        fg,
        bg,
        rs,
        Sgr,
        RgbFg,
        RgbBg,
        EightBitFg,
        EightBitBg,
    )

    fg.black = Style(EightBitFg(30), Sgr(1), value="\x1b[38;5;30m\x1b[1m")
    fg.red = Style(EightBitFg(31), Sgr(1), value="\x1b[38;5;31m\x1b[1m")
    fg.green = Style(EightBitFg(32), Sgr(1), value="\x1b[38;5;32m\x1b[1m")

# Generated at 2022-06-22 00:03:24.405537
# Unit test for method mute of class Register
def test_Register_mute():

    r1 = Register()

    r1.set_eightbit_call(RenderType.html)
    r1.set_rgb_call(RenderType.eightbit)
    r1.set_renderfunc(RenderType.sgr, lambda x: "SGR-" + str(x))

    r1.test = Style(RenderType.sgr(1))

    assert r1.test == "SGR-1"

    r1.mute()

    assert r1.test == ""



# Generated at 2022-06-22 00:03:33.961037
# Unit test for method __call__ of class Register
def test_Register___call__():
    register = Register()

    # Test 1: Single parameter is int
    def render_8bit_int(val):
        return val

    register.set_eightbit_call(int)
    register.set_renderfunc(int, render_8bit_int)
    register.red = Style(int(3), int(10))

    assert register(3) == "3"
    assert register("red") == "3"

    # Test 2: Single parameter is int but renderfunc expects str
    def render_8bit_str(val):
        return val

    register.set_eightbit_call(str)
    register.set_renderfunc(str, render_8bit_str)

    assert register(3) == "3"
    assert register("red") == "3"



# Generated at 2022-06-22 00:03:43.658415
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    import pytest

    from .render import (
        EightbitFg,
        EightbitBg,
        RgbFg,
        RgbBg,
        Sgr,
        Render,
        EightbitRender,
        RgbRender,
    )

    # Define render funcs
    eightbit_render = Render(EightbitRender())
    rgb_render = Render(RgbRender())

    # Build fg and bg registers
    fg = Register()
    fg.set_eightbit_call(EightbitFg)
    fg.set_rgb_call(RgbFg)
    fg.set_renderfunc(Sgr, eightbit_render)
    fg.set_renderfunc(EightbitFg, eightbit_render)

# Generated at 2022-06-22 00:03:49.336669
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()

    r1.test1 = Style("Test1")
    r1.test2 = Style("Test2")

    r2 = r1.copy()

    assert r1.test1 == r2.test1
    assert r1.test2 == r2.test2

    r2.test2 = Style("NewTest2")

    assert r2.test2 != r1.test2

# Generated at 2022-06-22 00:03:59.297117
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import SgrFg, SgrBg

    r = Register()
    r.set_renderfunc(SgrFg, lambda x: x)
    r.set_renderfunc(SgrBg, lambda x: x)

    r.test = Style(SgrFg(11), SgrBg(12))

    assert str(r.test) == "\x1b[38;5;11m\x1b[48;5;12m"

    r.mute()
    assert str(r.test) == ""
    assert r.is_muted == True

    r.unmute()
    assert str(r.test) == "\x1b[38;5;11m\x1b[48;5;12m"
    assert r.is_muted == False

# Generated at 2022-06-22 00:04:07.011724
# Unit test for constructor of class Style
def test_Style():

    from sty.rendertype import RgbFg, Sgr

    class Fg(Register):
        pass
    fg = Fg()

    assert isinstance(Style(RgbFg(180, 42, 63), Sgr(1)), Style)

    assert isinstance(Style(RgbFg(180, 42, 63), Sgr(1)), str)

    assert not isinstance(Style(RgbFg(180, 42, 63), Sgr(1)), Fg)

    assert str(Style(RgbFg(180, 42, 63), Sgr(1))) == "\x1b[38;2;180;42;63m\x1b[1m"

    assert isinstance(Style(RgbFg(180, 42, 63), Sgr(1), value="123"), str)


# Generated at 2022-06-22 00:04:07.604427
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    assert Register().as_dict() == {}

# Generated at 2022-06-22 00:04:08.450707
# Unit test for constructor of class Register
def test_Register():
    r: Register = Register()
    assert r


# Generated at 2022-06-22 00:04:18.183699
# Unit test for method mute of class Register
def test_Register_mute():

    # Mock a register-object with a single style attribute
    class _Register(Register):

        style: Style = Style(value="\x1b[38;2;1;5;10m\x1b[1m")

    reg: _Register = _Register()

    # Check rendered value
    assert str(reg.style) == "\x1b[38;2;1;5;10m\x1b[1m"

    # Mute register-object
    reg.mute()

    # Check if attribute was re-rendered to empty string
    assert str(reg.style) == ""



# Generated at 2022-06-22 00:04:25.387807
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .registers import fg, bg

    style_fg = fg("red")
    style_bg = bg("red")

    new_style_fg = style_fg.copy()
    new_style_bg = style_bg.copy()

    style_fg.red
    style_bg.red

    assert new_style_fg.red == style_fg.red
    assert new_style_bg.red == style_bg.red

    assert new_style_fg.as_namedtuple() == style_fg.as_namedtuple()
    assert new_style_bg.as_namedtuple() == style_bg.as_namedtuple()


if __name__ == "__main__":
    test_Register_as_namedtuple()

# Generated at 2022-06-22 00:04:59.777497
# Unit test for constructor of class Register
def test_Register():
    """
    Tests the constructor of class Register.
    """
    r = Register()

    assert isinstance(r, Register)
    assert isinstance(r.__class__.__dict__, Dict)



# Generated at 2022-06-22 00:05:03.387431
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(value="foo")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert s == "foo"
    assert s.rules == tuple()


# Generated at 2022-06-22 00:05:10.138230
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from functools import wraps

    def start_decorator(start: str) -> Callable:
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs) -> str:
                return start + func(*args, **kwargs)

            return wrapper
        return decorator

    # Create register with a custom renderfunc.
    reg = Register()
    reg.set_renderfunc(RenderType, start_decorator("$"))

    # Test if the custom renderfunc is applied.
    start = "$"
    assert str(Style(RenderType("some string"))) == start + "some string"

    # Test if the custom renderfunc is not applied to other registers.
    assert str(Style(RenderType("other string"))) == "other string"


# Unit test

# Generated at 2022-06-22 00:05:13.622991
# Unit test for constructor of class Register
def test_Register():

    r1 = Register()

    assert r1.renderfuncs == {}
    assert r1.is_muted is False
    assert r1.eightbit_call == r1(255)
    assert r1.rgb_call == r1(255, 0, 0)

