

# Generated at 2022-06-21 23:55:31.042279
# Unit test for method copy of class Register
def test_Register_copy():

    reg = Register()

    # Test basic property copying
    reg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    reg.r = reg.red
    reg.green = Style(RgbFg(0, 255, 0))
    reg.g = reg.green
    reg.blue = Style(RgbFg(0, 0, 255))
    reg.b = reg.blue
    reg.cyan = Style(RgbFg(0, 255, 255))
    reg.magenta = Style(RgbFg(255, 0, 255))
    reg.yellow = Style(RgbFg(255, 255, 0))
    reg.black = Style(RgbFg(0, 0, 0))
    reg.white = Style(RgbFg(255, 255, 255))



# Generated at 2022-06-21 23:55:43.452654
# Unit test for constructor of class Register
def test_Register():
    rg = Register()

    # Test that default register has no renderfuncs.
    assert(len(rg.renderfuncs) == 0)

    # Test that default register is not muted.
    assert(rg.is_muted is False)

    # Test that default register return empty string on call.
    assert(rg() == "")

    # Test that default register return empty string on call with 8bit integer.
    assert(rg(42) == "")

    # Test that default register return empty string on call with 24bit color tuple.
    assert(rg(102, 49, 240) == "")

    # Test that default register return empty string on call with string.
    assert(rg("foo") == "")

    # Test that default register has no attributes.
    assert(len(dir(rg)) == 0)



# Generated at 2022-06-21 23:55:51.128271
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .fg import fg

    fg_tuple = fg.as_namedtuple()

    assert fg_tuple.black == "\x1b[38;5;0m"
    assert fg_tuple.red == "\x1b[38;5;1m"
    assert fg_tuple.green == "\x1b[38;5;2m"
    assert fg_tuple.yellow == "\x1b[38;5;3m"
    assert fg_tuple.blue == "\x1b[38;5;4m"
    assert fg_tuple.magenta == "\x1b[38;5;5m"
    assert fg_tuple.cyan == "\x1b[38;5;6m"
    assert fg_tuple.light_gray

# Generated at 2022-06-21 23:56:00.412048
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    sgr_bold = Sgr(1)
    fg_white = Fg(255)

    r = Register()
    r.set_renderfunc(Sgr, lambda a: "\x1b[{}m".format(a))
    r.set_renderfunc(Fg, lambda a: "\x1b[38;5;{}m".format(a))

    r.bold_white = Style(fg_white, sgr_bold)

    assert r.bold_white == "\x1b[38;5;255m\x1b[1m"

# Generated at 2022-06-21 23:56:04.123828
# Unit test for method __call__ of class Register
def test_Register___call__():
    test_register = Register()
    test_register.green = 0
    test_register.set_eightbit_call(RenderType)
    assert test_register(42) == ""


# Generated at 2022-06-21 23:56:13.206831
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    foreground = Register()
    foreground.red = Style(RgbFg(10, 10, 10), RgbBg(20, 20, 20))
    assert isinstance(foreground.red, Style), "Test 1 failed"

    foreground.green = Style(RgbFg(10, 10, 10), RgbBg(20, 20, 20))
    assert isinstance(foreground.green, Style), "Test 2 failed"
    assert len(str(foreground.green)) == len(str(foreground.red)), "Test 3 failed"

    foreground.red = Style(RgbFg(42, 42, 42), RgbBg(20, 20, 20))
    assert isinstance(foreground.red, Style), "Test 4 failed"

# Generated at 2022-06-21 23:56:14.893757
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)
    assert type(r) is Register


# Generated at 2022-06-21 23:56:24.943448
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Test empty str return.
    r = Register()
    assert r() == ""
    assert r(1) == ""
    assert r(1, 2, 3) == ""

    # Test style return.
    r.red = Style(RgbFg(255, 0, 0))
    assert r("red") == "\x1b[38;2;255;0;0m"

    # Test 8bit-call.
    r.set_eightbit_call(Sgr)
    assert r(1) == "\x1b[1m"

    # Test RGB-call.
    r.set_rgb_call(RgbFg)
    assert r(1, 2, 3) == "\x1b[38;2;1;2;3m"



# Generated at 2022-06-21 23:56:35.980177
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    renderfuncs: Renderfuncs = {}

    # Define the render-functions for rendertypes
    renderfuncs.update({Sgr: lambda *args: "\x1b[{}m".format(";".join(map(str, args)))})
    renderfuncs.update({RgbFg: lambda *args: "\x1b[38;2;{}m".format(";".join(map(str, args)))})
    renderfuncs.update({RgbBg: lambda *args: "\x1b[48;2;{}m".format(";".join(map(str, args)))})

    red = Style(RgbFg(255, 0, 0))
    blue = Style(RgbBg(0, 100, 255))

    # Init register
    reg = Register()
    reg.set_renderfunc

# Generated at 2022-06-21 23:56:46.700755
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Set up new Register
    r = Register()
    # Define some rendertypes
    renderfuncs: Dict[Type[RenderType], Callable] = {
        int: lambda x: "int",
        str: lambda x: "str",
    }
    r.renderfuncs.update(renderfuncs)

    assert hasattr(r, "renderfuncs")

    # Set attribute with Style object
    r.black = Style(int(30), str("bold"))

    assert isinstance(r.black, Style)
    assert r.renderfuncs[type(r.black.rules[0])](r.black.rules[0]) == "int"
    assert r.renderfuncs[type(r.black.rules[1])](r.black.rules[1]) == "str"

# Generated at 2022-06-21 23:57:00.044730
# Unit test for method mute of class Register
def test_Register_mute():

    from sty import fg, bg
    from sty.ansi import Sgr, RgbFg, RgbBg

    def _test(rgb_is_muted, eightbit_is_muted):

        assert rgb_is_muted == fg(10, 20, 30).startswith("\x1b[39m")
        assert rgb_is_muted == bg(10, 20, 30).startswith("\x1b[49m")

        assert eightbit_is_muted == fg(42).startswith("\x1b[39m")
        assert eightbit_is_muted == bg(42).startswith("\x1b[49m")

        assert eightbit_is_muted == fg.red.startswith("\x1b[39m")
       

# Generated at 2022-06-21 23:57:11.346807
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .ansi import Ansi
    from .rendertypes import AnsiFgBg, AnsiFgBgBright, AnsiFgBgBright256

    register = Register()

    # Test if default renderfunc for AnsiFgBg is working.
    assert str(register.set_renderfunc(AnsiFgBg, Ansi.ansi_render_fg_bg)(AnsiFgBg(10), AnsiFgBg(42))) == "\x1b[38;5;10;48;5;42m"

    # Replace the renderfunc.
    register.set_renderfunc(AnsiFgBg, Ansi.ansi_render_fg_bg_bright)

    # Test if new renderfunc is working.

# Generated at 2022-06-21 23:57:17.316868
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class MockRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))

    register = MockRegister()
    nt = register.as_namedtuple()
    assert nt.red == "\x1b[38;2;255;0;0m"


# Generated at 2022-06-21 23:57:22.280446
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.red = Style(Sgr(1), RgbFg(255, 0, 0))
    r.blue = Style(Sgr(1), RgbFg(0, 0, 255))
    nt = r.as_namedtuple()
    assert nt.red == r.red
    assert nt.blue == r.blue


# Generated at 2022-06-21 23:57:26.734571
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    r = Register()

    r.test = Style(RgbFg(1, 5, 10), Sgr(1))

    assert isinstance(r.test, Style)
    assert isinstance(r.test, str)

# Generated at 2022-06-21 23:57:33.137424
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Dummy:
        def __init__(self):
            self.renderfuncs = {}
            self.is_muted = False
            self.eightbit_call = lambda x: x
            self.rgb_call = lambda r, g, b: (r, g, b)

    d: Register = Dummy()
    d.set_eightbit_call(type)

    assert d.eightbit_call is type


# Generated at 2022-06-21 23:57:44.701644
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class Sgr(RenderType):

        renderfunc = lambda *x: "SGR_CALL"

    class RgbFg(RenderType):

        renderfunc = lambda *x: "RGB_CALL"

    class CustomRegister(Register):

        def __init__(self):
            super().__init__()
            self.set_renderfunc(RgbFg, lambda *x: "RGB_CALL")
            self.set_renderfunc(Sgr, lambda *x: "SGR_CALL")

    fg = CustomRegister()

    fg.red = Style(RgbFg(1, 0, 0), Sgr(1))
    fg.blue = Style(RgbFg(0, 0, 1))

    assert fg.red == "RGB_CALLSGR_CALL"
    assert fg

# Generated at 2022-06-21 23:57:54.500137
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.red = Style(RgbFg(255, 0, 0))
    r.blue = Style(RgbFg(0, 0, 255))

    r.mute()
    assert str(r.red) == ""
    assert str(r.blue) == ""

    r.unmute()
    assert str(r.red) == "\x1b[38;2;255;0;0m"
    assert str(r.blue) == "\x1b[38;2;0;0;255m"
    #
    # # Unit test for method mute of class Register
    # def test_Register_mute():
    #     r = Register()
    #     r.red = Style(RgbFg(255, 0, 0))
    #     r.blue = Style(Rgb

# Generated at 2022-06-21 23:58:04.523887
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty import fg, rendertype

    def my_func(one: int, two: str) -> str:
        return f"{one + 1} {two}"

    fg.set_eightbit_call(rendertype.Sgr)
    fg.set_rgb_call(rendertype.Sgr)
    fg.set_renderfunc(rendertype.Sgr, my_func)

    assert fg(42) == my_func(42, "")
    assert fg(22, "red") == my_func(22, "red")
    assert fg(1, 5, 10) == my_func(1, 5, 10)
    assert fg(255,255,255) == my_func(255, 255, 255)

# Generated at 2022-06-21 23:58:08.897714
# Unit test for method __new__ of class Style
def test_Style___new__():

    from .sgr import Sgr

    style = Style(Sgr(1))
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "\x1b[1m"


# Generated at 2022-06-21 23:58:22.884087
# Unit test for method copy of class Register
def test_Register_copy():

    r1 = Register()
    r1.set_rgb_call(RenderType.rgb)
    r1.renderfuncs = dict(a=1, b=2)

    # Make deepcopy
    r2 = r1.copy()

    # After copying, the objects should be separated.
    r1.renderfuncs.update(c=3)
    assert dict(a=1,b=2,c=3) == r1.renderfuncs
    assert dict(a=1,b=2) == r2.renderfuncs

    r2.renderfuncs.update(d=4)
    assert dict(a=1,b=2,c=3) == r1.renderfuncs
    assert dict(a=1,b=2,d=4) == r2.renderfuncs


# Generated at 2022-06-21 23:58:33.062145
# Unit test for method copy of class Register
def test_Register_copy():
    def str_get_style(style: Style) -> str:
        return style

    null_renderfunc = str_get_style

    # Create test register.
    test_register = Register()
    test_register.renderfuncs.update({type(Style): null_renderfunc})
    test_register.set_rgb_call(type(Style))
    test_register.set_eightbit_call(type(Style))

    # Dummy style
    test_register.test_style = Style(value="test_style")

    # Dummy styles
    test_register.test_style_1 = Style("test_style_1")
    test_register.test_style_2 = Style("test_style_2")

    # Dummy style to test copy of non-string attribute
    test_register.test_attr = 123

    #

# Generated at 2022-06-21 23:58:36.452384
# Unit test for method __new__ of class Style
def test_Style___new__():

    from sty import fg, bg, ef, rs
    import re

    assert isinstance(fg.red, Style)
    assert isinstance(bg.blue, Style)
    assert isinstance(ef.bold, Style)
    assert isinstance(rs.reset, Style)
    assert not isinstance(re, Style)


# Generated at 2022-06-21 23:58:39.527900
# Unit test for method __new__ of class Style
def test_Style___new__():

    # Create styling rule
    rule = RenderType(1,2,3,4)

    # Create new style
    style = Style(rule)

    # Check if it is an instance of class Style and if it has the given styling rule
    assert isinstance(style, Style) and style.rules[0] == rule


# Generated at 2022-06-21 23:58:41.837919
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    r = Register()

    r.set_renderfunc(RenderType, lambda x: "")
    s = Style(RenderType())
    assert str(s) == ""

    r.set_renderfunc(RenderType, lambda x: "foo")
    assert str(s) == "foo"

# Generated at 2022-06-21 23:58:42.628952
# Unit test for constructor of class Register
def test_Register():
    s = Register()

# Generated at 2022-06-21 23:58:49.205206
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .common import fg, bg, ef, rs
    from .rendertype import Eightbit, RgbFg, Sgr, X

    def renderfunc(rendertype: Type[RenderType], *args) -> str:
        """
        This is an example for the renderfunc for the rendertype Eightbit. It
        converts the integer color code to a hex-string that is prefixed with
        '\x1b[' and has no suffix appended.

        :param rendertype: The rendertype passed to the renderfunc.
        :param args: The args passed to the renderfunc.
        :return: The string that will be formatted.
        """
        return f"\x1b[{args[0]:02x}"

    fg2 = fg.copy()

# Generated at 2022-06-21 23:58:50.353016
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)

# Generated at 2022-06-21 23:58:57.599428
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Create a new Register-object.
    fg = Register()

    # Set a dummy render-function for rgb and eightbit-calls.
    fg.set_renderfunc(RgbFg, lambda r, g, b: "dummy")
    fg.set_renderfunc(EightBitFg, lambda x: "dummy")

    # Change the render-function for rgb-calls and run rgb-call.
    fg.set_rgb_call(RgbFg)

    assert fg(210, 42, 130) == "dummy"



# Generated at 2022-06-21 23:59:01.609767
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def rend_func(x: int) -> str:
        return "mystr"

    class X(RenderType):
        pass

    r = Register()
    r.set_renderfunc(X, rend_func)
    assert(r.renderfuncs[X] == rend_func)
    assert(r(42) == "mystr")


# Generated at 2022-06-21 23:59:19.434802
# Unit test for constructor of class Style
def test_Style():

    m = Style(value='a')
    assert m.rules == ()

    n = Style(RgbFg(255, 0, 0), value='b')
    assert n.rules == (RgbFg(255, 0, 0),)

    o = Style(m, value='c')
    assert o.rules == (m,)



# Generated at 2022-06-21 23:59:22.352234
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test unmute method of Register.
    """
    r = Register()
    r.Muted = Style(Mute(), Sgr(1))
    r.mute()

    assert r.Muted == ""

    r.unmute()

    assert r.Muted == "\x1b[22m\x1b[1m"

# Generated at 2022-06-21 23:59:27.868841
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Simple test for the method
    """
    fg = Register()
    fg.red = Style(RgbFg(255,0,0))
    fg.blue = Style(RgbFg(0,0,255))
    n_tuple = fg.as_namedtuple()

    assert isinstance(n_tuple, NamedTuple)


# Generated at 2022-06-21 23:59:38.808136
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Define two simple renderfunctions.
    def rgb_renderfunc(red: int, green: int, blue: int):
        return f"{red}{green}{blue}"

    def bg_renderfunc():
        return "B"

    # Create a Register-object and add the renderfunctions.
    rg = Register()
    rg.set_renderfunc(RenderType.RGB, rgb_renderfunc)
    rg.set_renderfunc(RenderType.BG, bg_renderfunc)

    # Define a simple style.

# Generated at 2022-06-21 23:59:50.111875
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class A(RenderType):
        pass

    class B(RenderType):
        pass

    def renderfunc_a(a):
        return "A"

    def renderfunc_b(b):
        return "B"

    register = Register()

    register.set_renderfunc(A, renderfunc_a)
    assert register.renderfuncs[A] == renderfunc_a

    register.set_renderfunc(B, renderfunc_b)
    assert register.renderfuncs[A] == renderfunc_a
    assert register.renderfuncs[B] == renderfunc_b

    register.set_renderfunc(A, renderfunc_b)
    assert register.renderfuncs[A] == renderfunc_b
    assert register.renderfuncs[B] == renderfunc_b



# Generated at 2022-06-21 23:59:57.359761
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    import sty
    import sys
    import platform

    renderer = sty.get_default_renderer()

    register: Register = Register()

    # Add renderfuncts
    register.set_renderfunc(sty.RgbFg, renderer.render_rgb_fg)

    register.set_rgb_call(sty.RgbFg)

    register.set_eightbit_call(sty.Sgr)  # This line should not have an impact on the test.

    renderParam = sty.RgbFg(1, 2, 3)
    assert register(1, 2, 3) == renderParam(*renderParam.args)

    # Test palette rendering
    renderParam = sty.RgbFg(255, 255, 255)
    assert register(255, 255, 255) == renderParam(*renderParam.args)


#

# Generated at 2022-06-22 00:00:09.443108
# Unit test for method __new__ of class Style
def test_Style___new__():
    """
    The behavior of the method __new__ is a bit more complicated than it may
    seem. This test is to make sure we don't break anything.
    """
    class c: pass

    def rule_func(arg0, arg1):
        return "rule_func"

    RenderRule = namedtuple("RenderRule", ["args", "renderfunc"])
    renderrules = [RenderRule(args=(1, 2), renderfunc=rule_func)]

    style = Style(*renderrules)
    style_cls = style.__class__
    style_cls.rules == renderrules
    style == ""

    style = Style(*renderrules, value="hello")
    style_cls == style.__class__
    style_cls.rules == renderrules
    style == "hello"

    style2 = Style(*renderrules)


# Generated at 2022-06-22 00:00:19.180384
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from . import stylebase

    Sgr = stylebase.Sgr
    RgbFg = stylebase.RgbFg

    fg = Register()
    fg.set_renderfunc(Sgr, lambda *args: "\x1b[{}m".format(*args))
    fg.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;{};{};{}m".format(r, g, b))

    fg.set_rgb_call(RgbFg)

    assert fg(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-22 00:00:21.758149
# Unit test for constructor of class Style
def test_Style():

    from sty import Style

    a = Style(RgbFg(255, 255, 255))

    assert str(a) == "\x1b[38;2;255;255;255m"



# Generated at 2022-06-22 00:00:27.470047
# Unit test for method unmute of class Register
def test_Register_unmute():
    import sty

    r = sty.fg.copy()
    r.unmute()
    r.mute()
    r.unmute()

    # Test if styles are mutable
    assert len(str(r.red)) > 0



# Generated at 2022-06-22 00:01:00.887287
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class MyRegister(Register):
        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(255, 0, 0))
            self.blue = Style(RgbFg(0, 0, 255))

    reg = MyRegister()
    nt = reg.as_namedtuple()

    assert nt.red == Style(RgbFg(255, 0, 0))
    assert nt.blue == Style(RgbFg(0, 0, 255))
    assert len(nt._fields) == 2
    assert len(nt) == 2



# Generated at 2022-06-22 00:01:08.691504
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Eightbit, RgbFg, Sgr

    def test_renderer(x: int) -> str:
        return str(x)

    r = Register()
    r.set_renderfunc(Eightbit, test_renderer)
    r.set_renderfunc(RgbFg, test_renderer)
    r.set_eightbit_call(Eightbit)
    r.set_rgb_call(RgbFg)
    r.blue = Style(Eightbit(10), Sgr(1))
    r.red = Style(RgbFg(10, 42, 255), Sgr(1))

    assert r(10) == "10"
    assert r(10, 42, 255) == "10"
    assert r("blue") == "10"

# Generated at 2022-06-22 00:01:20.998851
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)

    def rgb_fg_renderfunc(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    class Sgr(RenderType):
        def __init__(self, *args):
            self.args = args

    def sgr_renderfunc(*args):
        return f"\x1b[{';'.join(map(str, args))}m"

    register = Register()

    register.set_eightbit_call(RgbFg)
    register.set_rgb_call(RgbFg)

    assert register.eightbit_call is None
    assert register.rgb_

# Generated at 2022-06-22 00:01:31.571837
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)
            super().__init__()

        def render(self, r, g, b):
            r = r if 0 <= r <= 255 else 255
            g = g if 0 <= g <= 255 else 255
            b = b if 0 <= b <= 255 else 255
            return f"\033[38;2;{r};{g};{b}m"

    class RgbBg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)
            super().__init__()

        def render(self, r, g, b):
            r = r if 0 <= r <= 255 else 255
            g = g

# Generated at 2022-06-22 00:01:41.321691
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Tests whether the call unmute restores all previously muted styles.

    The following code is tested:

        .. code-block:: python


            from sty import fg, bg, Style
            fg.red = Style(fg.rgb(255,0,0), fg.bold)
            bg.green = Style(bg.rgb(0,255,0), bg.bold)
            fg.red
            bg.green
            fg.red + bg.green
            fg.mute()
            fg.red
            bg.green
            fg.red + bg.green
            fg.unmute()
            fg.red
            bg.green
            fg.red + bg.green
    """
    from sty import fg, bg, Style


# Generated at 2022-06-22 00:01:50.823962
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    renderfuncs = {
        RenderType1: lambda: "one",
        RenderType2: lambda: "two",
    }

    r = Register()
    r.set_renderfunc(RenderType1, renderfuncs[RenderType1])

    assert r.renderfuncs[RenderType1] == renderfuncs[RenderType1]

    # Renderfuncs should not change when renderfunc for RenderType1 is replaced.
    r.set_renderfunc(RenderType1, renderfuncs[RenderType2])

    assert r.renderfuncs[RenderType1] == renderfuncs[RenderType2]
    assert r.renderfuncs[RenderType2] == renderfuncs[RenderType2]



# Generated at 2022-06-22 00:01:56.158963
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Create a ColorRegister
    register = Register()
    register.red = Style(RgbFg(255, 0, 0))
    register.blue = Style(RgbFg(0, 0, 255))

    assert register.as_namedtuple().red == register.red
    assert register.as_namedtuple().blue == register.blue

    # Check that names of the attributes in namedtuple and the dict are
    # the same.
    assert set(register.as_dict().keys()) == set(register.as_namedtuple()._fields)

# Generated at 2022-06-22 00:02:02.825620
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    test_RenderType = namedtuple("RenderType", ["name", "args"])

    def test_func(name: str, *args):
        return name + ":" + ",".join(map(str, args))

    test_render_func = {test_RenderType: test_func}

    test_register = Register()

    test_register.set_renderfunc(test_RenderType, test_func)

    test_style = Style(test_RenderType("my_name", 1, 2, 3))

    assert test_register.renderfuncs == test_render_func
    assert str(test_style) == "my_name:1,2,3"

# Generated at 2022-06-22 00:02:11.353001
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbBg, RgbFg, SetAttr

    import pytest

    rs = Register()
    rs.red = Style(RgbFg(255, 0, 0))
    rs.blue = Style(RgbFg(0, 0, 255))
    rs.yellow = Style(RgbBg(255, 255, 0))
    rs.bold = Style(SetAttr(1))

    # Test Eightbit-call.
    assert rs.red == rs(1)
    assert rs.blue == rs(4)
    assert rs.red == rs("red")
    assert rs.blue == rs("blue")
    assert rs.bold == rs("bold")

    with pytest.raises(ValueError):
        rs(1, 2)

    # Test RGB-call.
    assert rs.red

# Generated at 2022-06-22 00:02:16.134011
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from sty import fg, bg, ef, fx

    # Test as_namedtuple
    assert isinstance(fg.as_namedtuple(), namedtuple)
    assert isinstance(bg.as_namedtuple(), namedtuple)
    assert isinstance(ef.as_namedtuple(), namedtuple)
    assert isinstance(fx.as_namedtuple(), namedtuple)



# Generated at 2022-06-22 00:03:26.998692
# Unit test for constructor of class Style
def test_Style():

    from .animator import Sgr
    from .color import RgbFg

    style = Style(RgbFg(1,2,3),Sgr(1))
    print(style)

# Generated at 2022-06-22 00:03:30.819923
# Unit test for constructor of class Style
def test_Style():
    class Dummy(RenderType):
        args: Tuple[int]

    s = Style(Dummy(1), Dummy(2), Dummy(3))

    assert s == "f1f2f3"



# Generated at 2022-06-22 00:03:37.506158
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test __call__ of class Register.
    """

    # Create dummy functions and register-object.
    f1 = lambda x: f"{x}_INT"
    f2 = lambda r, g, b: f"{r}|{g}|{b}_RGB"
    f3 = lambda s: f"{s}_STR"

    r1 = Register()
    r1.set_eightbit_call(int)
    r1.set_rgb_call(str)
    r1.set_renderfunc(int, f1)
    r1.set_renderfunc(str, f3)

    r2 = Register()
    r2.set_eightbit_call(int)
    r2.set_rgb_call(str)

# Generated at 2022-06-22 00:03:42.813012
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .defaults import fg
    from .rendertypes import SgrFg, RgbFg

    assert fg.eightbit_call == SgrFg.render
    fg.set_eightbit_call(RgbFg)
    assert fg.eightbit_call == RgbFg.render



# Generated at 2022-06-22 00:03:49.769662
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg
    from .rendertype import Sgr

    s = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "\x1b[38;2;1;2;3m\x1b[1m"

    s = Style()
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == ""



# Generated at 2022-06-22 00:03:56.159780
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.foo = "bar"
    r.bar = "foo"
    nt = r.as_namedtuple()
    assert nt.foo == "bar"
    assert nt.bar == "foo"
    r.foo = "baz"
    nt2 = r.as_namedtuple()
    assert nt2.foo == "baz"
    assert nt2.bar == "foo"
    assert nt.foo == "bar"

# Generated at 2022-06-22 00:04:04.498789
# Unit test for method mute of class Register
def test_Register_mute():

    from .rendertype import Sgr, RgbFg

    r = Register()

    r.red = Style(Sgr(1), RgbFg(10, 20, 30))
    r.blue = Style(Sgr(2), RgbFg(12, 22, 32))

    assert str(r.red) == "\x1b[38;2;10;20;30m\x1b[1m"
    assert str(r.blue) == "\x1b[38;2;12;22;32m\x1b[2m"

    r.mute()

    assert str(r.red) == ""
    assert str(r.blue) == ""

    r.unmute()


# Generated at 2022-06-22 00:04:10.667392
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """

    """
    class R1(RenderType):
        """
        This is only used to test if we can reset the methods properly.
        """

        def render(self, *args: int) -> str:
            return "\x1b[38;2;42;42;42m"

    class R2(RenderType):
        """
        This is only used to test if we can reset the methods properly.
        """

        def render(self, *args: int) -> str:
            return "\x1b[48;2;42;42;42m"

    # Create a Register
    r: Register = Register()

    # Set renderfuncs for different rendertypes.
    r.set_renderfunc(R1, lambda *args: "\x1b[38;2;42;42;42m")
    r.set_

# Generated at 2022-06-22 00:04:13.610678
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import Sgr

    r = Register()
    r.bold = Style(Sgr(1))
    assert r.bold == "\x1b[1m"

# Generated at 2022-06-22 00:04:22.779232
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class CustomRegister(Register):
        pass

    custom_reg = CustomRegister()

    custom_reg.set_renderfunc(RenderType, lambda x: "RENDER!")

    custom_reg.test1 = Style(RenderType(1))
    custom_reg.test2 = Style(RenderType(2))
    custom_reg.test3 = Style(RenderType(3))

    custom_reg_namedtuple = custom_reg.as_namedtuple()

    assert(custom_reg_namedtuple.test1 == "RENDER!")
    assert(custom_reg_namedtuple.test2 == "RENDER!")
    assert(custom_reg_namedtuple.test3 == "RENDER!")