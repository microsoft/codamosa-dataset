

# Generated at 2022-06-21 23:55:24.150851
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    register.red = Style(RgbFg(255, 0, 0))
    register.green = Style(RgbFg(0, 255, 0))
    register.blue = Style(RgbFg(0, 0, 255))

    NT1 = register.as_namedtuple()
    assert NT1.red == register.red
    assert NT1.green == register.green
    assert NT1.blue == register.blue

# Generated at 2022-06-21 23:55:34.683478
# Unit test for method mute of class Register
def test_Register_mute():

    # Mock render functions
    def _fg(color: int) -> str:
        return f"{color}-fg"

    def _bg(color: int) -> str:
        return f"{color}-bg"

    # Create a test object
    tr = Register()
    tr.set_renderfunc(Fg, _fg)
    tr.set_renderfunc(Bg, _bg)

    # Make some attributes
    tr.set_eightbit_call(Fg)
    tr.red = Style(Fg(1))
    tr.green = Style(Bg(2), Fg(3))
    tr.orange = Style(Fg(4), Bg(3))

    # Test str-values of attributes.
    assert str(tr.red) == "1-fg"
    assert str(tr.green)

# Generated at 2022-06-21 23:55:43.820479
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class R(RenderType):  # noqa: WPS306
        render_type = "r"
        args = (1,)

    r = Register()
    r.set_renderfunc(R, lambda x: "\x1b[1m")

    # Add a new style attribute and check if string representation
    # is as expected.
    r.foo = Style(R())
    assert str(r.foo) == "\x1b[1m"

    r.bar = Style(R(), R())
    assert str(r.bar) == "\x1b[1m\x1b[1m"

# Generated at 2022-06-21 23:55:51.711663
# Unit test for method __call__ of class Register
def test_Register___call__():
    rf = lambda code: chr(code)
    renderfuncs = {type(RgbFg): rf}

    r = Register()
    r.set_renderfunc(RgbFg, rf)
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    r.red = Style(RgbFg(255, 0, 0))
    u = Style(RgbFg(0, 0, 1))
    r.blue = u

    assert r(144) == chr(144)
    assert r(255, 0, 0) == chr(255)
    assert r("red") == chr(255)
    assert r.red == chr(255)
    assert r.blue == chr(0)

    r.m

# Generated at 2022-06-21 23:55:56.864069
# Unit test for method mute of class Register
def test_Register_mute():
    from sty import fg
    fg.mute()
    assert fg.is_muted == True
    fg.unmute()
    assert fg.is_muted == False

# Generated at 2022-06-21 23:56:04.309565
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    def render_example_rgb(r, g, b):
        return f"\x1b[38;2;{r};{2};{b:1}m"

    def render_example_eightbit(x):
        return f"\x1b[{x:1}m"

    def render_example_sgr(x):
        return f"\x1b[{x}m"

    class ExampleRgbFg(RenderType):
        pass

    class ExampleEightbitFg(RenderType):
        pass

    class ExampleSgrFg(RenderType):
        pass

    class ExampleColorRegister(Register):
        """
        Example register.
        """

        def __init__(self):
            super().__init__()

# Generated at 2022-06-21 23:56:13.326950
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr, RgbFg

    # Create register object
    register = Register()

    # Add render-functions to register:
    register.set_renderfunc(Sgr, lambda x: "\x1b[%sm" % x)
    register.set_renderfunc(RgbFg, lambda r, g, b: "\x1b[38;2;%d;%d;%dm" % (r, g, b))

    # Create style attribute in register
    register.orange = Style(RgbFg(1, 5, 10), Sgr(1))

    # Test that the renderfunc was used to create the string representation of the Style-object:
    assert str(register.orange) == "\x1b[38;2;1;5;10m\x1b[1m"

    # Change

# Generated at 2022-06-21 23:56:23.955177
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .register import rs, fg, bg, ef
    from .register.rendertype import Sgr, RgbFg, RgbBg
    from .register.register import Style

    fg.red = Style(RgbFg(255,0,0), Sgr(1))
    bg.yellow = Style(RgbBg(255,255,0), Sgr(1))
    ef.bold = Style(Sgr(1))
    assert {'red': '\x1b[38;2;255;0;0m\x1b[1m',
            'yellow': '\x1b[48;2;255;255;0m\x1b[1m',
            'bold': '\x1b[1m'} == fg.as_dict()

# Generated at 2022-06-21 23:56:34.897509
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import Attribute
    from .render import sgr, reset

    rg = Register()
    rg.renderfuncs.update({Attribute: sgr, Reset: reset})
    rg.ob = Style(Attribute(42), Attribute(2))
    rg.ah = Style(Reset())

    assert rg.is_muted is False
    assert rg.ob == "\x1b[42;2m"
    assert rg.ah == "\x1b[0m"

    rg.mute()

    assert rg.is_muted is True

    assert rg.ob == ""
    assert rg.ah == ""

    rg.unmute()

    assert rg.is_muted is False

    assert rg.ob == "\x1b[42;2m"
    assert rg.ah == "\x1b[0m"

# Generated at 2022-06-21 23:56:45.632134
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import Sgr
    from .builtin import sgr

    class CustomRegister(Register):
        pass

    c = CustomRegister()
    c.one = Style(sgr.bold)
    c.two = Style(sgr.underline)

    assert c.one == "\\x1b[1m"
    assert c.two == "\\x1b[4m"
    assert c.one == c("one")
    assert c.two == c("two")
    assert c("one") == c("one")

    d = CustomRegister()
    c.set_renderfunc(Sgr, lambda *args: f"MyCustomRenderfunc-{args}")

    assert c.one == "MyCustomRenderfunc-(1,)"
    assert c("one") == "MyCustomRenderfunc-(1,)"

    assert d

# Generated at 2022-06-21 23:56:56.789698
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import Sgr
    from .register import Register

    r = Register()
    r.set_renderfunc(Sgr, lambda sgr_code: f"\x1b[{sgr_code}m")
    r.bold = Style(Sgr(1))

    print(r.bold)
    #  '\x1b[1m'

    r.mute()

    print(r.bold)
    #  ''

    r.unmute()

    print(r.bold)
    # '\x1b[1m'

# Generated at 2022-06-21 23:57:08.497703
# Unit test for constructor of class Style
def test_Style():
    # Test 1
    style: Style = Style(RgbFg(1, 2, 3), Sgr(2))
    assert style.rules == (RgbFg(1, 2, 3), Sgr(2))
    assert style.value == "\x1b[38;2;1;2;3m\x1b[2m"

    # Test 2
    rule1 = Style(RgbFg(1, 2, 3), Sgr(2))
    style2: Style = Style(rule1)
    assert style2.rules == rule1.rules
    assert style2.value == "\x1b[38;2;1;2;3m\x1b[2m"

    # Test 3
    r1: Style = Style(RgbFg(1, 2, 3), Sgr(2))
    r2

# Generated at 2022-06-21 23:57:15.625114
# Unit test for constructor of class Style
def test_Style():

    s1 = Style('foo')
    assert type(s1) == str

    s2 = Style(Style('foo'), 'bar')
    assert type(s2) == str

    s3 = Style(Style(), 'foo')
    assert type(s3) == str

    s4 = Style(Style('foo'), Style('bar'))
    assert type(s4) == str

    s5 = Style(Style(), Style('foo'))
    assert type(s5) == str

# Generated at 2022-06-21 23:57:25.430343
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Given a register with different attributes and styles,
    When the method as_dict is called,
    Then it returns a dict with the names and style-strings for each attribute.
    """

    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.blue = Style(RgbFg(0, 0, 255))
            self.yellow = Style(Sgr(3))

    r = TestRegister()
    d = r.as_dict()

    assert d["blue"] == "\x1b[38;2;0;0;255m"
    assert d["yellow"] == "\x1b[3m"


# Generated at 2022-06-21 23:57:26.630197
# Unit test for constructor of class Register
def test_Register():
    reg = Register()

# Generated at 2022-06-21 23:57:36.836556
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    reg = Register()
    bg_rules = RgbBg(10, 20, 30), RgbFg(10, 20, 30)
    reg.test_bg = Style(*bg_rules)
    assert "test_bg" in dir(reg)
    assert isinstance(reg.test_bg, Style)

    reg.set_rgb_call(RgbBg)
    assert reg(10, 20, 30) == "\x1b[48;2;10;20;30m"

    assert reg.test_bg == "\x1b[48;2;10;20;30m\x1b[38;2;10;20;30m"

# Generated at 2022-06-21 23:57:39.582429
# Unit test for method __new__ of class Style
def test_Style___new__():
    Style("foo", "bar", value="baz")
    Style("foo", value="baz")
    Style(value="baz")

# Generated at 2022-06-21 23:57:44.818605
# Unit test for method __call__ of class Register
def test_Register___call__():
    from sty import fg, rs
    assert fg(255) == fg.s255
    assert fg(10, 42, 255) == fg.s10_42_255
    assert fg(rs) == ''
    assert fg('white') == fg.white
    assert fg('invalid') == ''



# Generated at 2022-06-21 23:57:54.612843
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg
    from sty.rendertype import RgbFg, RgbBg
    from sty.effects import Sgr

    fg.green = Style(RgbFg(0, 255, 0))
    assert fg.green == '\x1b[38;2;0;255;0m'

    fg.set_rgb_call(RgbFg)
    assert fg(0, 255, 0) == '\x1b[38;2;0;255;0m'

    fg.set_rgb_call(RgbBg)
    assert fg(0, 255, 0) == '\x1b[48;2;0;255;0m'

    fg.green.rules = (RgbFg(0, 255, 0), Sgr(1))
   

# Generated at 2022-06-21 23:58:02.828828
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    styled = Register()

    styled.set_renderfunc(RenderType.ANSI, lambda r: f"{r}")
    styled.set_eightbit_call(RenderType.ANSI)
    styled.set_rgb_call(RenderType.ANSI)

    styled.green = Style(RenderType.ANSI(10))
    styled.red = Style(RenderType.ANSI(20))
    styled.yellow = Style(RenderType.ANSI(30))

    assert styled.as_namedtuple() == namedtuple("StyleRegister", "green red yellow")(
        "10", "20", "30"
    )

# Generated at 2022-06-21 23:58:13.739169
# Unit test for method copy of class Register
def test_Register_copy():
    from .rendertype import RgbFg, Sgr
    from .registers import fg
    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))
    fg_copy = fg.copy()
    assert fg.red == fg_copy.red
    assert fg.red is not fg_copy.red

# Generated at 2022-06-21 23:58:22.282556
# Unit test for method unmute of class Register
def test_Register_unmute():
    class RgbFg(RenderType):
        def __str__(self):
            return "RgbFg"

    def _render(r: int, g: int, b: int) -> str:
        return ""

    class TestRegister(Register):

        def __init__(self):
            super().__init__()
            self.red = Style(RgbFg(1, 0, 0))
            self.green = Style(RgbFg(0, 1, 0))
            self.blue = Style(RgbFg(0, 0, 1))

    # Create new Register object
    r = TestRegister()

    # mute it
    r.mute()

    color_names = ["red", "green", "blue"]

    # Check if style is muted
    assert r.is_muted

    # Check if all

# Generated at 2022-06-21 23:58:32.838041
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr

    def func(self):
        return f"\x1b[38;2;{self.r};{self.g};{self.b}m"

    RgbFg.render = func

    fg = Register()

    fg.red: Style = Style(RgbFg(255, 0, 0))

    fg.blue: Style = Style(RgbFg(0, 0, 255))

    fg.set_eightbit_call(RgbFg)

    assert str(fg(200)) == "\x1b[38;2;130;43;130m"
    assert str(fg(201)) == "\x1b[38;2;141;50;141m"

# Generated at 2022-06-21 23:58:36.956193
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    class TestType(RenderType):
        pass

    test1 = Register()
    test2 = Register()
    test2.set_renderfunc(TestType, lambda: "")

    test1.test = Style(TestType())
    test2.test = Style(TestType())

    assert str(test1.test) == ""
    assert str(test2.test) == "TestType"

# Generated at 2022-06-21 23:58:41.392036
# Unit test for method __new__ of class Style
def test_Style___new__():

    class Color:

        def __init__(self, name, code):
            self.name = name
            self.code = code

        def __str__(self):
            return self.name

    rule = Color("red", 883)

    style = Style(rule)

    assert isinstance(style, Style) is True
    assert isinstance(style, str) is True
    assert len(style.rules) == 1
    assert style.rules[0] is rule
    assert str(style) == "red"

# Generated at 2022-06-21 23:58:46.416915
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    import sty
    import os

    class Test(RenderType):
        pass

    # Define register
    r = Register()

    # Define style
    r.test = Style(Test(144))

    # Define renderfunc
    @sty.rendertype(Test)
    def StyTest(n: int) -> str:
        return f"\x1b[{n}m"

    # Define eightbit call renderfunc
    @sty.rendertype(sty.Eightbit)
    def StyEightbit(n: int) -> str:
        return f"\x1b[{n}m"

    # Assert that 'test' is not callable
    assert not callable(r.test)

    # Assert that 'test' is not callable
    assert not callable(r.test)

    r.set_

# Generated at 2022-06-21 23:58:56.665038
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbFg1(RenderType): pass
    class RgbFg2(RenderType): pass

    register = Register()
    register.set_renderfunc(RgbFg1, lambda x, y, z: f"RgbFg1({x})")
    register.set_rgb_call(RgbFg1)

    # Call the register object with three parameters and test the result.
    assert register(42, 55, 99) == "RgbFg1(42)"

    register.set_renderfunc(RgbFg2, lambda x, y, z: f"RgbFg2({x}, {y}, {z})")
    register.set_rgb_call(RgbFg2)

    # Call the register object with three parameters and test the result.
    assert register(42, 55, 99)

# Generated at 2022-06-21 23:59:01.577172
# Unit test for constructor of class Style
def test_Style():

    from .rendertype import RgbFg

    s = Style(RgbFg(1,2,3), value="\x1b[38;2;1;2;3m")
    assert isinstance(s, Style)
    assert isinstance(s, str)

    assert str(s) == "\x1b[38;2;1;2;3m"
    assert s.rules == (RgbFg(1,2,3),)

# Generated at 2022-06-21 23:59:11.334798
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    ## Create a new Register
    test_reg = Register()

    ## Add a renderfunc for the rendertype RenderType1
    test_reg.set_renderfunc(RenderType1, lambda x: f">{x}")

    ## Set rendertype for eightbit-calls to RenderType1
    test_reg.set_eightbit_call(RenderType1)

    ## Define a style attribute
    test_reg.style_attribute = Style(RenderType1(42))

    assert str(test_reg.style_attribute) == ">42"
    assert test_reg(42) == ">42"

    ## Re-Define the renderfunc for RenderType1
    test_reg.set_renderfunc(RenderType1, lambda x: f"<{x}")

    assert str(test_reg.style_attribute) == "<42"

# Generated at 2022-06-21 23:59:21.790809
# Unit test for method __call__ of class Register
def test_Register___call__():
    reg = Register()
    reg.red = Style(RgbFg(255, 0, 0))

    assert reg(255, 0, 0) == ""
    assert reg(255, 0, 0, w=255) == ""
    assert reg("red") == "\x1b[38;2;255;0;0m"
    assert reg.red == "\x1b[38;2;255;0;0m"
    assert reg() == ""
    assert reg(12) == ""
    assert reg(255, 0) == ""

    reg.set_rgb_call(RgbFg)
    assert reg(255, 0, 0) == "\x1b[38;2;255;0;0m"
    assert reg(255, 0) == ""

    reg.set_eightbit_call(RgbFg)

# Generated at 2022-06-21 23:59:40.985711
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute is working.
    """
    val = Style(RgbBg(3, 5, 4))

    def func(colnum: int) -> str:
        return ""

    reg = Register()
    reg.set_renderfunc(Rgb, func)
    reg.set_rgb_call(RgbBg)

    # If unmuted, a call to the register should return the right ANSI-sequence.
    assert str(val) == "\x1b[48;2;3;5;4m"

    # If muted, a call to the register should return an empty string.
    reg.mute()
    assert str(val) == ""

    # If then unmuted, a call to the register should return the right ANSI-sequence.
    reg.unmute()
    assert str(val)

# Generated at 2022-06-21 23:59:51.506168
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    - A register object with methods set_renderfunc and render_type.
    - set_renderfunc adds renderfunc to renderfuncs.
    - test with rendertype Sgr which is already in renderfuncs before.
    - test with rendertype RgbBg which is not in renderfuncs before.
    """


    class Sgr(RenderType):
        args: Tuple[int, ...]

        def __init__(self, *args: int):
            self.args = args

    class RgbBg(RenderType):
        args: Tuple[int, int, int]

        def __init__(self, red: int, green: int, blue: int):
            self.args = (red, green, blue)


# Generated at 2022-06-21 23:59:56.620734
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    from .rendertype import RgbFg

    fg = Register()
    fg.black = Style(RgbFg(0,0,0))
    fg.white = Style(RgbFg(255,255,255))

    fg_nt = fg.as_namedtuple()

    assert fg_nt.black == '\x1b[38;2;0;0;0m'
    assert fg_nt.white == '\x1b[38;2;255;255;255m'

# Generated at 2022-06-22 00:00:09.287700
# Unit test for method __new__ of class Style
def test_Style___new__():

    class MockRenderType(RenderType):
        pass

    class MockRenderType2(RenderType):
        pass

    class MockRenderType3(RenderType):
        pass

    class MockRenderType4(RenderType):
        pass

    # Create some test objects

    m_mock_render_type = MockRenderType()
    m_mock_render_type2 = MockRenderType2()
    m_mock_render_type3 = MockRenderType3()
    m_mock_render_type4 = MockRenderType4()
    m_style = Style(m_mock_render_type, value="\x1b[38;2;1;5;10m\x1b[1m")

# Generated at 2022-06-22 00:00:16.619721
# Unit test for method mute of class Register
def test_Register_mute():
    fg = Register()
    fg.set_renderfunc(RenderType, lambda x: x * 2)
    fg.red = Style(RenderType())

    assert fg.red == fg.red
    assert not (fg.red == fg.red * 2)

    fg.mute()
    assert not(fg.red == fg.red)

    fg.unmute()
    assert fg.red == fg.red

# Generated at 2022-06-22 00:00:21.890638
# Unit test for method __new__ of class Style
def test_Style___new__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    r1 = RgbFg(1, 5, 10)
    r2 = Sgr(1)

    s1 = Style(r1, r2)

    assert isinstance(s1, Style)
    assert isinstance(s1, str)
    assert str(s1) == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-22 00:00:34.229024
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def eightbit_renderfunc(colornumber):
        return "\x1b[38;5;" + str(colornumber) + "m"

    def sgr_renderfunc(status):
        return "\x1b[" + str(status) + "m"

    class Sgr(RenderType):
        pass

    class RgbFg(RenderType):
        pass

    fg = Register()
    fg.set_renderfunc(Sgr, sgr_renderfunc)
    fg.set_renderfunc(RgbFg, eightbit_renderfunc)

    fg.bold = Style(Sgr(1))
    fg.red = Style(Sgr(31))
    fg.white = Style(Sgr(37))
    fg.orange = Style(RgbFg(1, 5, 10))



# Generated at 2022-06-22 00:00:37.564459
# Unit test for constructor of class Style
def test_Style():
    f = Style(Sgr(1))
    assert isinstance(f, Style)
    assert isinstance(f, str)



# Generated at 2022-06-22 00:00:46.698231
# Unit test for method __call__ of class Register
def test_Register___call__():

    """
    This function tests that all inputs supported by the built-in register methods
    return the right ANSI-Sequence and the right error messages for all other inputs.
    """

    from .rendertype import RgbFg, SgrFg, RgbBg, SgrBg
    from .colors import fg, bg

    # Test single number
    assert fg(42) == "\x1b[38;5;42m"
    assert bg(102) == "\x1b[48;5;102m"

    # Test single string
    assert fg("red") == "\x1b[38;5;196m"
    assert bg("orange") == "\x1b[48;5;208m"

    # Test number tuple

# Generated at 2022-06-22 00:00:48.361240
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r._foo_ = "bar"
    r.baz = Style(value="baz")
    r.fizz = Style(value="fizz")

    assert r.as_dict() == {'baz': 'baz', 'fizz': 'fizz'}

# Generated at 2022-06-22 00:01:08.481258
# Unit test for constructor of class Register
def test_Register():
    """
    Unit test for constructor of class Register
    """
    sty = Register()
    sty.foo_bar = Style()
    sty.abc = Style()
    sty.foobar = Style()
    sty.bar_baz = Style()
    sty.abc = Style()
    sty.bar = Style()

    assert set(sty.as_dict().keys()) == {
        'bar',
        'bar_baz',
        'abc',
        'foo_bar',
        'foobar'
    }

# Generated at 2022-06-22 00:01:16.347620
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    def func(x):
        return f"\x1b[38;5;{x}m"

    register = Register()
    register.set_renderfunc(RenderType, func)

    register.set_eightbit_call(RenderType)

    assert register.eightbit_call(1) == "\x1b[38;5;1m"
    assert register.eightbit_call(2) == "\x1b[38;5;2m"



# Generated at 2022-06-22 00:01:26.728862
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test for method copy of class Register.
    """

    from .render import Render

    r = Render()

    bold_red = Style(Sgr(1), RgbFg(255, 0, 0))

    register = Register()
    register.__name__ = "test_register"

    # Test the normal case
    assert hasattr(register, "test_register") == False, "there is not test_register attribute"
    register.test_register = bold_red
    assert register.test_register == bold_red, "there is a test_register attribute and it is the same bold_green"

    # Copy of this register
    new_register = register.copy()
    assert hasattr(new_register, "test_register") == True, "there is a test_register attribute in new register"
    assert new_register.test

# Generated at 2022-06-22 00:01:32.255991
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    class MyRegister(Register):
        pass

    r = MyRegister()
    s = Style(RgbFg(2, 3, 4))
    r.foo = s

    assert isinstance(r.foo, Style)
    assert isinstance(r.foo, str)
    assert str(r.foo) == "\x1b[38;2;2;3;4m"


# Generated at 2022-06-22 00:01:42.090828
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRegister(Register):
        pass

    reg = TestRegister()
    
    reg.red = Style(Sgr(1))
    reg.blue = Style(RgbBg(0,0,255))

    assert str(reg.red) == "\x1b[1m"
    assert str(reg.blue) == "\x1b[48;2;0;0;255m"

    reg.red = Style(Sgr(1), value="\x1b[1m")
    reg.blue = Style(RgbBg(0,0,255), value="\x1b[48;2;0;0;255m")

    assert str(reg.red) == "\x1b[1m"
    assert str(reg.blue) == "\x1b[48;2;0;0;255m"

# Generated at 2022-06-22 00:01:52.811986
# Unit test for method mute of class Register
def test_Register_mute():
    from .fg import fg
    fg.mute()
    assert fg.is_muted
    assert fg.muted
    assert fg.red == ""
    assert fg.rgb_red == ""
    assert fg(1) == ""
    assert fg(204, 102, 153) == ""
    assert fg.bright.red == ""
    assert fg.bright.rgb_red == ""
    assert fg.bright(1) == ""
    assert fg.bright(204, 102, 153) == ""
    fg.unmute()
    assert not fg.is_muted
    assert not fg.muted
    assert fg.red != ""
    assert fg.rgb_red != ""
    assert fg(1) != ""

# Generated at 2022-06-22 00:01:59.895353
# Unit test for method mute of class Register
def test_Register_mute():

    class TestRegister(Register):
        """
        This class is used for testing muting.
        """

        red = Style(Sgr(1))

    reg = TestRegister()

    fmt_str = "Hello {}"

    assert fmt_str.format(reg.red) == "Hello \x1b[1m"
    assert fmt_str.format(reg.red + "World") == "Hello \x1b[1mWorld"

    reg.mute()
    assert fmt_str.format(reg.red) == "Hello "

    reg.unmute()
    assert fmt_str.format(reg.red + "World") == "Hello \x1b[1mWorld"

# Generated at 2022-06-22 00:02:02.691525
# Unit test for method unmute of class Register
def test_Register_unmute():
    """Test if muted style works."""
    extend_style = Style(RgbFg(1, 5, 10))
    extend_style.mute()
    extend_style.unmute()
    assert str(extend_style) == "\x1b[38;2;1;5;10m"

# Generated at 2022-06-22 00:02:07.091602
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.hello = Style(r"h\x1bel\x1blo")
    r.world = Style(r"wo\x1brld")
    n = r.as_namedtuple()
    assert isinstance(n, NamedTuple)
    assert n.hello == r"h\x1bel\x1blo"
    assert n.world == r"wo\x1brld"

# Generated at 2022-06-22 00:02:15.964592
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert isinstance(Style(RgbFg(1, 2, 3)), Style)
    assert isinstance(Style(RgbFg(1, 2, 3)), str)
    assert str(Style(RgbFg(1, 2, 3))) == "\x1b[38;2;1;2;3m"
    assert str(Style(RgbFg(1, 2, 3), Sgr(1))) == "\x1b[38;2;1;2;3m\x1b[1m"
    assert str(Style(Style(RgbFg(1, 2, 3)), RgbBg(1, 2, 3))) == "\x1b[38;2;1;2;3m\x1b[48;2;1;2;3m"

# Generated at 2022-06-22 00:02:55.151461
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.args = [r, g, b]

    class Sgr(RenderType):
        def __init__(self, code: int):
            self.args = [code]

    register = Register()

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2:{r};{g};{b}m"

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    register.set_renderfunc(RgbFg, render_rgb_fg)
    register.set_renderfunc(Sgr, render_sgr)



# Generated at 2022-06-22 00:03:03.985821
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg1 = Register()
    reg1.my_red = Style(RgbFg(255, 0, 0))
    reg1.my_blue = Style(RgbFg(0, 0, 255))

    reg2 = Register()
    reg2.my_red = Style(RgbFg(255, 0, 0))
    reg2.my_blue = Style(RgbFg(0, 0, 255))

    assert reg1.as_namedtuple() == reg2.as_namedtuple()

# Generated at 2022-06-22 00:03:14.759055
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .style import stylize
    from .rendertype import RgbBg
    from .fb import fg, bg

    fg.blue = Style(RgbBg(0, 0, 150))
    fg.red = Style(RgbBg(150, 0, 0))

    fg_nt = fg.as_namedtuple()

    assert fg_nt.blue == "\x1b[48;2;0;0;150m"
    assert fg_nt.red == "\x1b[48;2;150;0;0m"


# Generated at 2022-06-22 00:03:22.152717
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Unit test for method copy of class Register.
    """

    class MyRegister(Register):
        pass

    rf = fg.red
    rm = MyRegister()
    rm.blue = fg.blue
    rm.copper = fg.copper

    rf_copy = rf.copy()
    rm_copy = rm.copy()

    assert rf is not rf_copy
    assert rm is not rm_copy
    assert rm.blue is not rm_copy.blue
    assert rm.copper is not rm_copy.copper



# Generated at 2022-06-22 00:03:33.308859
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Eightbit(RenderType):
        pass

    class RGB(RenderType):
        pass

    class EightbitTest(Eightbit):
        pass

    # Create a register object and add a renderfunc.
    r = Register()
    r.set_eightbit_call(EightbitTest)
    r.set_renderfunc(EightbitTest, lambda x: f"\x1b[{x}m")
    r.set_renderfunc(RGB, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Assert that method call() uses the new renderfunc.
    assert r(42) == "\x1b[42m"

    # Assert that method call() still works with the old renderfunc.

# Generated at 2022-06-22 00:03:36.962904
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()

    reg.red = Style(RgbFg(0, 255, 0), Sgr(1))

    assert reg.as_dict() == {"red": "\x1b[38;2;0;255;0m\x1b[1m"}

# Generated at 2022-06-22 00:03:47.480976
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Test method copy of class register.
    """
    from .utils import fg, bg, ef, rs
    from .rendertype import Sgr
    from .color import Color, Eightbit, Rgb
    from .sty import Sty
    from .colorlist import ColorList

    def render_sgr_bold(params):
        return "".join(["\x1b[%sm" % param for param in params])

    def render_sgr1_bold_and_white(params):
        return "\x1b[47m" + "\x1b[1m" + "\x1b[37m"

    fg_copy = fg.copy()

    # Test that the render functions are the same
    assert fg.renderfuncs == fg_copy.renderfuncs

    # Test that the eightbit_

# Generated at 2022-06-22 00:03:48.316586
# Unit test for constructor of class Register
def test_Register():
    assert isinstance(Register(), Register)

# Generated at 2022-06-22 00:03:58.897681
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class Rule(RenderType):
        """This class is only used for test purposes."""

        def __init__(self, *args):
            self.args = args

    # Create test register
    r = Register()

    # Set renderfunc for Rule class.
    @r.set_renderfunc(Rule)
    def render1(a, b, c):
        return f"\x1b[{a};{b};{c}m"

    # Set Rul-class for eightbit calls for register r.
    r.set_eightbit_call(Rule)

    # Add style for red color
    r.red = Style(Rule(1, 2, 3))

    # Test eightbit call
    assert r(1, 2, 3) == "\x1b[1;2;3m"

    # Test style attribute

# Generated at 2022-06-22 00:04:06.491414
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .register import fg

    assert isinstance(fg.as_namedtuple(), NamedTuple)
    assert isinstance(fg.as_namedtuple().black, str)
    assert isinstance(fg.as_namedtuple().snow, str)

    fg.black = Style(Sgr(1, 5, 4))
    assert fg.as_namedtuple().black == "\x1b[1;5;4m"

    fg.black = Style(Sgr(1, 5, 4), sgr_21)
    assert fg.as_namedtuple().black == "\x1b[1;5;4m"

    fg.black = Style(value=fg.black, rules=(Sgr(0), sgr_21))