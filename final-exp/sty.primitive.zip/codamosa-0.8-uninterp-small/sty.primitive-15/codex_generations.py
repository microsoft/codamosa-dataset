

# Generated at 2022-06-26 04:19:27.890399
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_1 = Register()
    register_1.set_rgb_call(RenderType.SGR)


# Generated at 2022-06-26 04:19:32.790353
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Setup
    register_0 = Register()

    # Test case
    register_0.set_rgb_call(rendertype=RgbBg)

    # Check
    assert register_0.rgb_call == render_rgb_bg


# Generated at 2022-06-26 04:19:36.129739
# Unit test for constructor of class Register
def test_Register():
    try:
        register_0 = Register()
    except Exception:
        print("Register() has raised an Exception")


# Generated at 2022-06-26 04:19:47.669289
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import typing
    import dataclasses
    import abc

    def test_return_type():
        r = Register()
        if typing.TYPE_CHECKING:
            assert isinstance(r.set_rgb_call, typing.Callable)

    def test_return_value():
        r = Register()
        assert issubclass(r.rgb_call, abc.ABC)
        class Foobar(metaclass=abc.ABCMeta):
            @abc.abstractmethod
            def __call__(r, g, b):
                pass
        r.set_rgb_call(Foobar)
        assert issubclass(r.rgb_call, abc.ABC)
        assert issubclass(r.rgb_call, Foobar)

    test_return_type()
    test_return_value()

# Generated at 2022-06-26 04:19:49.093006
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    pass


# Generated at 2022-06-26 04:19:58.116769
# Unit test for constructor of class Register
def test_Register():
    # Test the constructor (e.g. the init function).
    register_0 = Register()
    # Test the function set_eightbit_call() of class Register
    register_1 = Register()
    register_1.set_eightbit_call("fg")
    # Test the function set_rgb_call() of class Register
    register_2 = Register()
    register_2.set_rgb_call("fg")
    # Test the function set_renderfunc() of class Register
    register_3 = Register()
    register_3.set_renderfunc("fg")
    # Test the function mute() of class Register
    register_4 = Register()
    register_4.mute()
    # Test the function unmute() of class Register
    register_5 = Register()
    register_5.unmute()
    # Test the function

# Generated at 2022-06-26 04:20:04.343894
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Test case 0
    register_0 = Register()
    register_0.set_rgb_call(RgbBg)
    assert register_0.rgb_call(10,20,30) == '\x1b[48;2;10;20;30m'


# Generated at 2022-06-26 04:20:07.045600
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_1 = Register()
    assert register_1(42, 49, 200) == (42, 49, 200)


# Generated at 2022-06-26 04:20:18.024020
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg, AnsiFg, AnsiBg

    r0 = Register()
    r1 = Register()
    r1.set_rgb_call(RgbFg)

    r0("blue") == r1("blue")  # True

    r2 = Register()
    r2.set_rgb_call(AnsiFg)

    r0("blue") == r2("blue")  # False

    r3 = Register()
    r3.set_rgb_call(RgbBg)

    r0("blue") == r3("blue")  # False

    r4 = Register()
    r4.set_rgb_call(AnsiBg)

    r0("blue") == r4("blue")  # False



# Generated at 2022-06-26 04:20:21.168577
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    assert(register_0() == "")


test_case_0()

# Generated at 2022-06-26 04:20:28.526945
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(Type[RenderType])


# Generated at 2022-06-26 04:20:31.524220
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(rendertype=None)


# Generated at 2022-06-26 04:20:36.959605
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Given
    from sty.rs import RgbFg
    register_0 = Register()
    register_1 = Register()
    register_1.set_rgb_call(RgbFg)

    # When
    some_red = register_1(10, 42, 255)

    # Then
    assert some_red == "\x1b[38;2;10;42;255m"


# Generated at 2022-06-26 04:20:47.611082
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from io import StringIO
    from contextlib import redirect_stdout

    from .rendertype import RgbFg
    from .constants import CSI

    ## Test Register object has right attributes
    register_0 = Register()

    assert hasattr(register_0, "renderfuncs")
    assert hasattr(register_0, "is_muted")
    assert hasattr(register_0, "eightbit_call")
    assert hasattr(register_0, "rgb_call")

    assert isinstance(register_0.renderfuncs, dict)
    assert isinstance(register_0.is_muted, bool)
    assert isinstance(register_0.eightbit_call, Callable)
    assert isinstance(register_0.rgb_call, Callable)

    assert register_0.renderfuncs == {}

# Generated at 2022-06-26 04:20:49.572177
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(type(None))



# Generated at 2022-06-26 04:20:52.773711
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    Register_0 = Register()
    Register_0.set_rgb_call(Type[RenderType])


# Generated at 2022-06-26 04:21:02.117051
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import sty

    register_0 = Register()

    # Testcase 1
    register_0 = sty.fg
    register_0.set_renderfunc(sty.RgbEf, lambda r, g, b: f"{r}{g}{b}")
    register_0.rgb(1, 2, 3)
    assert register_0.rgb(1, 2, 3) == f"{1}{2}{3}"
    register_0.set_rgb_call(sty.RgbBg)
    assert register_0.rgb(1, 2, 3) == f"\033[48;2;1;2;3m"


# Generated at 2022-06-26 04:21:13.852174
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Tests the set_rgb_call method of the Register class
    """
    # Setup classes and func
    class Sgr(RenderType):
        args = ()

    class RgbFg(RenderType):
        args = ("r", "g", "b")

        def as_sgr(self, r: int, g: int, b: int) -> str:
            return f"\x1b[38;2;{r};{g};{b}m"

    def sgr_render(x: str) -> str:
        return f"\x1b[{x}m"

    register_0 = Register()
    register_0.set_renderfunc(Sgr, sgr_render)
    register_0.set_renderfunc(RgbFg, RgbFg.as_sgr)


# Generated at 2022-06-26 04:21:15.712845
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    pass # TODO


# Generated at 2022-06-26 04:21:26.240390
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    register_0 = Register()

# Generated at 2022-06-26 04:21:43.344187
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Test for method set_rgb_call of class Register
    """
    from sty.colored import RgbFg
    class Register():
        def __init__(self):
            self.eightbit_call = lambda x: x
            self.rgb_call = lambda r, g, b: (r, g, b)
        def set_eightbit_call(self, rendertype):
            func = self.renderfuncs[rendertype]
            self.eightbit_call = func
        def set_rgb_call(self, rendertype):
            func = self.renderfuncs[rendertype]
            self.rgb_call = func
        def set_renderfunc(self, rendertype, func):
            self.renderfuncs.update({rendertype: func})

# Generated at 2022-06-26 04:21:45.055884
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(RenderType)



# Generated at 2022-06-26 04:21:53.601790
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    RgbFg = namedtuple("RgbFg", "red, green, blue")

    # Register
    register = Register()

    # Define renderfuncs for rendertype RgbFg.
    register.set_renderfunc(
        RgbFg,
        lambda r, g, b: "#%02x%02x%02x" % (r, g, b),
    )

    # Define the rendertype that is used for rgb-calls.
    register.set_rgb_call(RgbFg)

    # This call should return "#AABBCC".
    assert register(170, 187, 204) == "#AABBCC"



# Generated at 2022-06-26 04:21:56.907941
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    obj_0 = Register()
    val_0 = obj_0.set_rgb_call(RenderType)
    assert val_0 == None


# Generated at 2022-06-26 04:22:01.694753
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_1 = Register()
    assert not hasattr(register_1, "rgb_call")
    register_1.set_rgb_call(None)
    assert hasattr(register_1, "rgb_call")


# Generated at 2022-06-26 04:22:02.628512
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    pass


# Generated at 2022-06-26 04:22:04.424523
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    Register_0 = Register()
    Register_0.set_rgb_call(RgbFg)



# Generated at 2022-06-26 04:22:06.974156
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import pytest
    register_1 = Register()
    assert register_1.__call__(10, 42, 255) == ""


# Generated at 2022-06-26 04:22:14.301515
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg, Sgr
    register_0 = Register()
    def r0(*args: Union[int, str], **kwargs) -> str:
        return "\x1b[48;2;{};{};{}m".format(*args)
    register_0.set_renderfunc(RgbBg, r0)
    register_0.set_rgb_call(RgbBg)
    assert "\x1b[48;2;100;100;100m" == register_0(100, 100, 100)


# Generated at 2022-06-26 04:22:22.940077
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Create default color register.
    register = Register()

    # Save something in the register.
    register.color = Style(RgbFg(255, 255, 255), Sgr(1))

    # Check if something is in the register.
    assert str(register.color) == '\x1b[38;2;255;255;255m\x1b[1m'

    # Set a new render function for a render-type that is in the register.
    register.set_renderfunc(RgbFg, lambda r, g, b: "")

    # Check if the color keeped in the register is rendered correctly.
    assert str(register.color) == '\x1b[38;2;255;255;255m\x1b[1m'


# Generated at 2022-06-26 04:22:37.230834
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    def my_rgb_function(r: int, g: int, b: int):
        return "my_rgb_function"

    def my_eightbit_function(c: int):
        return "my_eightbit_function"

    register_0 = Register()
    register_0.set_rgb_call(my_rgb_function)
    register_0.set_eightbit_call(my_eightbit_function)
    assert type(register_0) is Register
    assert register_0.rgb_call(1,2,3) == 'my_rgb_function'
    assert register_0.eightbit_call(4) == 'my_eightbit_function'


# Generated at 2022-06-26 04:22:40.243263
# Unit test for constructor of class Style
def test_Style():
    Style(value="1234", rules=["abc", Style(value="9876", rules=["zxy", "123"])])

# Generated at 2022-06-26 04:22:46.630433
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    register_0 = Register()
    register_0.set_eightbit_call(type(register_0)) #?
    register_0.set_eightbit_call(type(register_0)) #?
    register_0.set_eightbit_call(type(register_0)) #?
    register_0.set_eightbit_call(type(register_0)) #?
    register_0.set_eightbit_call(type(register_0)) #?



# Generated at 2022-06-26 04:22:50.269850
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0 is not None


# Generated at 2022-06-26 04:22:53.070513
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    namedtuple_0 = register_0.as_namedtuple()


# Generated at 2022-06-26 04:23:05.648734
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_0 = Register()

    assert register_0.__call__() == ''

    assert register_0.__call__(100) == ''

    assert register_0.__call__(100, 200, 300) == ''

    assert register_0.__call__('red') == ''

    register_0.set_eightbit_call(RenderType.Sgr)
    register_0.set_rgb_call(RenderType.RgbBg)

    assert register_0.__call__(200, 0, 0) == '\x1b[48;2;200;0;0m'

    assert register_0.__call__(100) == '\x1b[100m'

    return 'test_Register___call__ ok'


# Generated at 2022-06-26 04:23:11.826098
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Expected output:

    StyleRegister(blue='\x1b[34m', green='\x1b[32m', grey='\x1b[38;2;200;200;200m')
    """
    register_0 = Register()
    register_0.blue = Style(RgbFg(0, 0, 255))
    register_0.green = Style(RgbFg(0, 128, 0))
    register_0.grey = Style(RgbFg(200, 200, 200))

    print(register_0.as_namedtuple())



# Generated at 2022-06-26 04:23:21.804775
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Case 0: All Style args are Styles
    style_0 = _style_0()
    style_1 = Style(style_0, value="\x1b[42m")
    assert style_1.rules == (style_0,)
    assert str(style_1) == "\x1b[42m"

    # Case 1:
    style_0 = Style(value="\x1b[42m")
    style_1 = Style(style_0, value="\x1b[43m")
    assert style_0.rules == ()
    assert style_0.value == "\x1b[42m"
    assert style_1.rules == (style_0,)
    assert style_1.value == "\x1b[43m"

    # Case 2:

# Generated at 2022-06-26 04:23:23.108857
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert isinstance(register_0, Register)

# Generated at 2022-06-26 04:23:26.073825
# Unit test for constructor of class Register
def test_Register():
    r0 = Register()
    assert(isinstance(r0, Register))
    assert(r0)


# Generated at 2022-06-26 04:23:37.467345
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.test = Style("test")
    register.test2 = Style("test2")
    result = register.as_dict()
    expected = {"test": "test", "test2": "test2"}
    assert(result == expected)


# Generated at 2022-06-26 04:23:39.844425
# Unit test for method mute of class Register
def test_Register_mute():
    Register_0 = Register()
    Register_0.mute()
    assert not Register_0.is_muted


# Generated at 2022-06-26 04:23:49.512324
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    assert (register_0() == "")
    assert (register_0(98) == "")
    register_1 = Register()
    register_1.eightbit_call = lambda x: "8bit-render-function"
    assert (register_1(108) == "8bit-render-function")
    register_2 = Register()
    register_2.rgb_call = lambda r, g, b: "RGB-render-function"
    assert (register_2(10, 20, 30) == "RGB-render-function")
    register_3 = Register()
    assert (register_3(51) == "")
    assert (register_3(151) == "")
    assert (register_3(255) == "")
    assert (register_3(256) == "")


# Generated at 2022-06-26 04:23:54.713623
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Register.set_eightbit_call() should be able to change the rendertype
    for Eightbit-calls.
    """
    from .rendertype import RgbBg, RgbFg, Sgr
    from .ansi import ansi
    from .colors import rgb
    from .utility import render_8bit, render_24bit

    register_0 = Register()

    register_0.set_renderfunc(RgbBg, render_24bit)

    register_0.set_renderfunc(RgbFg, render_24bit)

    register_0.set_renderfunc(Sgr, ansi.sgr)

    register_0.set_eightbit_call(RgbFg)


# Generated at 2022-06-26 04:23:56.557780
# Unit test for method unmute of class Register
def test_Register_unmute():
    register = Register()
    register.unmute()


# Generated at 2022-06-26 04:23:57.711937
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:24:01.337076
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Ensure that a new instance of class Register is created.
    register_0 = Register()

    # Ensure that a new instance of a namedtuple is created.
    register_1 = register_0.as_namedtuple()

    # Ensure that the namedtuple has the same length as the dict returned by the method as_dict of register_0.
    assert len(register_0.as_dict()) == len(register_1)


# Generated at 2022-06-26 04:24:06.548834
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr
    from .render import SGR

    register_0 = Register()
    assert register_0.renderfuncs == {}
    register_0.set_renderfunc(Sgr, SGR)
    assert register_0.renderfuncs == {Sgr: SGR}
    return


# Generated at 2022-06-26 04:24:08.667142
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)


# Generated at 2022-06-26 04:24:13.854947
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Arrange
    r = Register()

    # Act
    r.set_renderfunc(RenderType, lambda x: f"RenderType: {str(x)}")
    style = Style(RenderType("EMPTY"))

    # Assert
    assert style.value == "RenderType: EMPTY"


# Generated at 2022-06-26 04:24:42.443126
# Unit test for method __new__ of class Style
def test_Style___new__():
    register_0 = Register()
    style_0 = Style(*(), value='')
    style_1 = Style(*(), value='')
    assert (style_0 is style_1)
    style_2 = Style(*(), value='')
    assert (style_0 is style_2)
    style_3 = Style(*(), value='')
    assert (style_0 is style_3)
    style_4 = Style(*(), value='')
    assert (style_0 is style_4)
    assert (style_0 is not None)
    assert (not (hasattr(style_0, '__dict__')))
    style_5 = Style(*(), value='')
    assert (style_0 is style_5)


# Generated at 2022-06-26 04:24:47.116576
# Unit test for constructor of class Style
def test_Style():
    reg_test = Register()
    reg_test.test_Style = Style(fg.red, bg.yellow, value="\x1b[31m\x1b[43m")

    assert reg_test.test_Style == "\x1b[31m\x1b[43m"


# Generated at 2022-06-26 04:24:49.345576
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0: Register = Register()
    assert hasattr(register_0, "set_eightbit_call")


# Generated at 2022-06-26 04:24:58.280656
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from sty import fg
    register_0 = Register()

    def test_func(rendertype: Type[RenderType], func: Callable) -> None:
        
        # Test that the rendertype was saved in self.renderfuncs
        assert(register_0.renderfuncs[rendertype] == func)

        # Test that the attribute of the register-object got the new render-function.
        assert(register_0.rgb_call == func)

    from sty.rendertypes import Sgr, RgbFg, RgbBg
    from sty.ansitowin32 import AnsiToWin32 

    register_0.set_renderfunc(Sgr, AnsiToWin32.sgr)
    register_0.set_renderfunc(RgbFg, AnsiToWin32.rgb_fg)
    register_0

# Generated at 2022-06-26 04:25:02.203065
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_1 = Register()
    register_1.set_eightbit_call(RenderType)
    # TODO: More tests needed here.


# Generated at 2022-06-26 04:25:13.109118
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Test call with 1 Parameter and 1 Parameter of type int
    register_0 = Register()
    register_0.set_eightbit_call(RgbFg)
    register_0.rgb_0 = Style(RgbFg(0, 0, 0))
    assert(register_0(0) == "\x1b[38;2;0;0;0m")

    # Test call with 1 Parameter and 1 Parameter of type str
    register_1 = Register()
    register_1.set_eightbit_call(RgbFg)
    register_1.rgb_0 = Style(RgbFg(0, 0, 0))
    assert(register_1('rgb_0') == "\x1b[38;2;0;0;0m")

    # Test call with 3 Parameter
   

# Generated at 2022-06-26 04:25:19.659950
# Unit test for constructor of class Style
def test_Style():

    class RgbFg(RenderType):
        pass

    class Bold(RenderType):
        pass

    new_style: Style = Style(RgbFg(1, 5, 10), Bold())

    assert isinstance(new_style, Style)
    assert isinstance(new_style, str)



# Generated at 2022-06-26 04:25:26.840503
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .sty import sty
    from .ansi import RgbFg
    
    r0 = Register()
    
    sty.set_rgb_call(sty.fg, RgbFg)
    sty.set_rgb_call(sty.bg, RgbFg)
    
    sty.fg(100,100,100)
    sty.bg(100,100,100)

# Generated at 2022-06-26 04:25:35.077922
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Test case 1. Setting attributes of type `Style`
    rendertype_1 = RenderType()
    rule_1 = Style(rendertype_1)

    register_1 = Register()
    register_1.test_1 = rule_1

    assert isinstance(register_1.test_1, Style)

    # Test case 2. Setting attributes of type `Style`
    rendertype_2 = RenderType()
    rule_2 = Style(rendertype_2)

    register_2 = Register()
    register_2.test_2 = rule_2

    assert isinstance(register_2.test_2, Style)

    # Test case 3. Setting attributes of type not `Style`
    register_3 = Register()
    register_3.test_3 = "abc"

    assert isinstance(register_3.test_3, str)

# Generated at 2022-06-26 04:25:46.437286
# Unit test for constructor of class Style
def test_Style():
    style_check = Style(42, value="\x1b[42m")
    style_check_rules = Style(42, value="\x1b[42m").rules
    style_check_rgb = Style(RgbFg(1, 2, 3), value="\x1b[38;2;1;2;3m")
    style_check_rgb_rules = Style(RgbFg(1, 2, 3), value="\x1b[38;2;1;2;3m").rules
    style_check_rgb_sgr = Style(RgbFg(1, 2, 3), Sgr(1), value="\x1b[38;2;1;2;3m\x1b[1m")

# Generated at 2022-06-26 04:26:19.038836
# Unit test for method unmute of class Register
def test_Register_unmute():
    rm = Register()  # create an instance of the Register class
    rm.mute()  # mute the register
    assert rm.is_muted == True
    rm.unmute()  # unmute the register
    assert rm.is_muted == False


# Generated at 2022-06-26 04:26:30.046443
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType.SGR_EIGHTBIT)

    register_0.black = Style(RenderType.SGR_EIGHTBIT(30))
    register_0.red = Style(RenderType.SGR_EIGHTBIT(31))
    register_0.green = Style(RenderType.SGR_EIGHTBIT(32))
    register_0.yellow = Style(RenderType.SGR_EIGHTBIT(33))
    register_0.blue = Style(RenderType.SGR_EIGHTBIT(34))
    register_0.magenta = Style(RenderType.SGR_EIGHTBIT(35))
    register_0.cyan = Style(RenderType.SGR_EIGHTBIT(36))

# Generated at 2022-06-26 04:26:32.169300
# Unit test for constructor of class Style
def test_Style():
    Style1 = Style(1)
    assert isinstance(Style1, Style)
    assert isinstance(Style1, str)

    Style2 = Style((1, 2), (1, 3))
    assert isinstance(Style2, Style)
    assert isinstance(Style2, str)



# Generated at 2022-06-26 04:26:35.804112
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    fg = Register()
    fg.red = Style()
    assert isinstance(fg.red, str)


# Generated at 2022-06-26 04:26:40.829640
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Rgb, Eightbit
    from .renderfunc import renderfunc_xterm

    register_ = Register()

    register_.renderfuncs = {Rgb: renderfunc_xterm, Eightbit: renderfunc_xterm}

    register_.red = Style(Rgb(255, 0, 0))
    assert isinstance(register_.red, Style)

    register_.my_red = register_.red
    assert isinstance(register_.my_red, Style)



# Generated at 2022-06-26 04:26:51.231925
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class RgbFg(NamedTuple):
        r: int
        g: int
        b: int

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    register = Register()
    register.set_renderfunc(RgbFg, render_rgb_fg)
    register.set_eightbit_call(RgbFg)
    ret = str(register(42))
    assert ret == "\x1b[38;2;42;42;42m"



# Generated at 2022-06-26 04:27:01.421361
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()

    def renderfun1(x):
        return f"\x1b[38;2;{x};{x};{x}m"

    def renderfun2(x):
        return f"\x1b[30;2;{x};{x};{x}m"

    register_0.set_renderfunc(RenderType, renderfun1)
    register_0.set_renderfunc(RenderType, renderfun2)

    def renderfunc3(x):
        return f"\x1b[38;2;{x};{x};{x}m"

    register_0.set_renderfunc(RenderType, renderfunc3)


# Generated at 2022-06-26 04:27:03.305578
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RenderType0(RenderType):
        pass

    register_0 = Register()
    register_0.set_rgb_call(RenderType0)


# Generated at 2022-06-26 04:27:13.116824
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class Render0(RenderType):
        def __str__(self):
            return str(self.args[0])

    class Render1(RenderType):
        def __str__(self):
            return str(self.args[0] * 10)

    register_0 = Register()
    register_0.set_renderfunc(Render0, lambda x, y, z: f"{x} {y} {z}")
    register_0.set_rgb_call(Render0)

    assert str(register_0(10,20,30)) == "10 20 30"
    assert str(register_0(Render0(10,20,30))) == "10 20 30"

    register_0.set_renderfunc(Render1, lambda x, y, z: f"{x} {y} {z}")
    register_

# Generated at 2022-06-26 04:27:14.608050
# Unit test for constructor of class Register
def test_Register():
    assert Register()


# Generated at 2022-06-26 04:28:15.776304
# Unit test for constructor of class Register
def test_Register():
    test_case_0()


# Generated at 2022-06-26 04:28:25.999596
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r0 = Register()
    r0.fg = Style(RgbFg(11, 22, 33))
    r0.bg = Style(RgbBg(44, 55, 66))

    r0.set_eightbit_call(RgbFg)
    r0.set_rgb_call(RgbFg)

    d0 = r0.as_dict()

    d1 = {"fg": "\x1b[38;2;11;22;33m", "bg": "\x1b[48;2;44;55;66m"}

    assert d0 == d1

# Generated at 2022-06-26 04:28:29.375863
# Unit test for method unmute of class Register
def test_Register_unmute():
    register = Register()
    register.mute()
    register.unmute()
    assert register.is_muted == False


# Generated at 2022-06-26 04:28:34.939714
# Unit test for method mute of class Register
def test_Register_mute():

    # Fixture
    register_0 = Register()
    register_0.set_eightbit_call(RenderType.Sgr)
    register_0.set_rgb_call(RenderType.RgbFg)

    # Test
    register_0.mute()
    assert register_0.is_muted == True
    assert register_0(144) == ""
    assert register_0(42, 12, 99) == ""


# Generated at 2022-06-26 04:28:37.084026
# Unit test for constructor of class Style
def test_Style():
    # instantiate Style variable
    Style1 = Style()


# Generated at 2022-06-26 04:28:47.211590
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Setup
    register_0 = Register()

    # Define new renderfuncs
    renderfunc_0: Callable = lambda x: ""
    renderfunc_1: Callable = lambda x: ""

    rendertype_0: Type[RenderType] = RenderType
    rendertype_1: Type[RenderType] = RenderType

    # Set render funcs for render types
    register_0.set_renderfunc(rendertype_0, renderfunc_0)
    register_0.set_renderfunc(rendertype_1, renderfunc_1)


# Generated at 2022-06-26 04:28:54.174913
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    s = Sty()
    s.rgb_off()
    fg_0 = s.fg
    fg_1 = fg_0.copy()
    NamedtupleType_0 = fg_1.as_namedtuple()
    assert isinstance(NamedtupleType_0, namedtuple)

# Generated at 2022-06-26 04:28:58.411264
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_1 = Register()
    register_1.test_style_0 = Style("Test", "")
    register_1.test_style_1 = Style("Test", "")

    nt_0 = register_1.as_namedtuple()
    assert nt_0.test_style_0 == "Test"
    assert nt_0.test_style_1 == "Test"


# Generated at 2022-06-26 04:29:01.165124
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class TestRenderType(RenderType):
        render_func = lambda *args, **kwargs: "Hello World!"

    register_0 = Register()
    assert register_0.renderfuncs == {}
    register_0.set_renderfunc(TestRenderType, TestRenderType.render_func)
    assert register_0.renderfuncs == {TestRenderType: TestRenderType.render_func}


# Generated at 2022-06-26 04:29:02.498117
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
