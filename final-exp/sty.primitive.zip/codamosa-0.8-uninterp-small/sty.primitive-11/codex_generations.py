

# Generated at 2022-06-26 04:19:31.986223
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    var_0 = register_0.as_namedtuple()
    test_0 = var_0.bold
    register_0.set_eightbit_call(register_0.rendertype.format)
    test_1 = var_0.bold

    if test_0 != test_1:
        raise AssertionError()


# Generated at 2022-06-26 04:19:43.928382
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Create a new instance of Register
    register_1 = Register()

    # Use method setattr to set some attributes (mostly style-objects)
    register_1.setattr('somevar', Style('\x1b[38;2;1;5;10m\x1b[1m'))
    register_1.setattr('someothervar', Style('\x1b[38;2;1;5;10m\x1b[1m'))

    # Use method as_dict to export the attributes as dictionary
    dictionary1 = register_1.as_dict()
    assert isinstance(dictionary1, dict)


# Generated at 2022-06-26 04:19:46.290386
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(int)
    register_0.set_eightbit_call(Type[RenderType])


# Generated at 2022-06-26 04:19:48.889859
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)


# Generated at 2022-06-26 04:19:51.423227
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()

    r.set_eightbit_call()


# Generated at 2022-06-26 04:19:54.398581
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    try:
        register_0.set_eightbit_call((Type))
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-26 04:19:57.201318
# Unit test for method mute of class Register
def test_Register_mute():
    register_1 = Register()
    register_1.mute()
    assert register_1.is_muted == True


# Generated at 2022-06-26 04:20:00.330488
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()

    assert register_0.as_dict() == {}



# Generated at 2022-06-26 04:20:03.383393
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()
    # No assert statements


# Generated at 2022-06-26 04:20:08.070366
# Unit test for method unmute of class Register
def test_Register_unmute():
    # Setup
    register_0 = Register()
    # AssertionError: AttributeError: 'Register' object has no attribute 'is_muted'
    # AssertionError: AttributeError: 'Register' object has no attribute 'is_muted'
    # AssertionError: AttributeError: 'Register' object has no attribute 'is_muted'
    # AssertionError: AssertionError: AssertionError: AssertionError: AssertionError: AssertionError:  is not false
    assert (not register_0.is_muted)


# Generated at 2022-06-26 04:20:20.943634
# Unit test for method mute of class Register
def test_Register_mute():
    r0 = Register()
    assert hasattr(r0, "is_muted") == True
    r0.mute()
    assert r0.is_muted == True
    r0.unmute()
    assert r0.is_muted == False


# Generated at 2022-06-26 04:20:25.043157
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    str_0 = register_0()
    str_1 = register_0(10)
    str_2 = register_0(10, 20, 30)
    str_3 = register_0('black')


# Generated at 2022-06-26 04:20:29.354507
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import RgbFg, Sgr

    Sty1 = Style(RgbFg(1,5,10), Sgr(1))
    Sty2 = Style(RgbFg(1,5,10), Sgr(1))

    assert Sty1 == Sty2
    assert Sty1.rules[0] == Sty2.rules[0]
    assert Sty1.rules[1] == Sty2.rules[1]


# Generated at 2022-06-26 04:20:40.155574
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .register import RenderType, Renderfuncs, Style, Register
    from .styles import RgbBg, Sgr

    class TestObject:
        pass

    register_0 = Register()

    styling_rule = Style(RgbBg(144, 144, 144), Sgr(1))

    register_0.set_eightbit_call(RgbBg)

    register_0.set_rgb_call(RgbBg)

    def func(*args):
        return args

    register_0.set_renderfunc(RgbBg, func)

    register_0.is_muted = False

    register_0.test_0 = styling_rule

    assert register_0.test_0 == '\x1b[48;2;144;144;144m\x1b[1m'


# Unit test

# Generated at 2022-06-26 04:20:45.234424
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_1 = Register()
    register_1.set_rgb_call(RenderType.RgbFg)

    assert type(register_1(255, 0, 0)) == str


# Generated at 2022-06-26 04:20:56.039397
# Unit test for constructor of class Style
def test_Style():
    register = Register()
    register.set_renderfunc(RenderType.EightBit, lambda x: str(x))
    register.set_renderfunc(RenderType.RgbFg, lambda x, y, z: str(x) + str(y) + str(z))
    register.set_eightbit_call(RenderType.EightBit)
    register.set_rgb_call(RenderType.RgbFg)
    register.fg.yellow = Style(RenderType.EightBit(10), RenderType.RgbFg(1, 2, 3))
    assert isinstance(register.fg.yellow, Style)
    assert register.fg.yellow == '1030120'


# Generated at 2022-06-26 04:21:02.004493
# Unit test for method __new__ of class Style
def test_Style___new__():

    # Test 0
    # Tested method: StylingRule
    # Tested value: rule_0
    rule_0 = Style(value="rule_0")

    # Test 1
    # Tested method: StylingRule
    # Tested value: rule_1
    rule_1 = Style(value="rule_1")

    # Test 2
    # Tested method: StylingRule
    # Tested value: rule_2
    rule_2 = Style(value="rule_1")


# Generated at 2022-06-26 04:21:09.033898
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    register_0 = Register()
    register_0.set_renderfunc(str, lambda x: x)

    assert "str" in register_0.renderfuncs.keys()



# Generated at 2022-06-26 04:21:10.180778
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()


# Generated at 2022-06-26 04:21:11.538119
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    assert type(register_0.copy()) == Register



# Generated at 2022-06-26 04:21:22.237177
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    assert register_0('') == ''
    assert register_0('red') == ''
    assert register_0('') == ''
    assert register_0(42) == ''
    assert register_0(10, 42, 255) == ''


# Generated at 2022-06-26 04:21:25.400643
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    assert register_0.as_namedtuple() == namedtuple("StyleRegister", [])()


# Generated at 2022-06-26 04:21:33.078677
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_1 = Register()
    register_0.set_eightbit_call(int)
    register_0.set_renderfunc(int, lambda x: x)
    register_1.set_rgb_call(int)
    register_1.set_renderfunc(int, lambda x, y, z: (x, y, z))
    assert register_0(42) == 42
    assert register_1(42, 69, 99) == (42, 69, 99)



# Generated at 2022-06-26 04:21:35.942079
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    style_1 = Style(None)
    assert isinstance(style_0, Style)
    assert isinstance(style_1, Style)



# Generated at 2022-06-26 04:21:41.118034
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg, Sgr
    from .fg import fg
    from .bg import bg

    register: Register = Register()
    register.renderfuncs = {RgbFg: lambda r, g, b: "R" * (r + g + b),  # type: ignore
                            Sgr: lambda s: "S" * s}  # type: ignore

    register.red = Style(RgbFg(255, 0, 0), Sgr(1))
    register.pale_blue = Style(RgbFg(10, 20, 30))

    assert register.red == "SR255"
    assert register.pale_blue == "R60"

    assert register.as_namedtuple() == fg.as_namedtuple()

# Generated at 2022-06-26 04:21:44.714145
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    assert isinstance(register_1, Register)
    assert isinstance(register_1, Register)


# Generated at 2022-06-26 04:21:48.384040
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda x: x)
    register_0.fg="red"
    assert (register_0.fg) == ""



# Generated at 2022-06-26 04:21:56.908228
# Unit test for constructor of class Style
def test_Style():

    class RType(RenderType):
        name: str = "X"
        args: Tuple = ()

    rtype = RType()

    style = Style(rtype)

    assert isinstance(style, str)
    assert isinstance(style, Style)
    assert style.rules == (rtype,)



# Generated at 2022-06-26 04:21:59.282652
# Unit test for method __new__ of class Style
def test_Style___new__():

    register_0 = Register()
    assert str(register_0) == ""



# Generated at 2022-06-26 04:22:00.828905
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    return register_0



# Generated at 2022-06-26 04:22:21.814220
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Initialize
    register_1 = Register()
    # Setup test case
    rendertype_1 = RenderType
    func_1 = lambda r, g, b: (r, g, b)
    # Execute method
    return_1 = register_1.set_eightbit_call(rendertype_1)
    return_2 = register_1.set_rgb_call(rendertype_1)
    register_1.set_renderfunc(rendertype_1, func_1)
    # Evaluate results
    if ((return_1 is not None)):
        raise AssertionError("Register return_1: Got {0}, expected {1}".format(return_1, None))

# Generated at 2022-06-26 04:22:33.831684
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.set_renderfunc(RenderType.EIGHTBIT_256, lambda x: f"\x1b[38;5;{x}m")
    register_0.set_eightbit_call(RenderType.EIGHTBIT_256)
    register_0.set_rgb_call(RenderType.RGB)

    register_0.blue = Style("\x1b[34m")

    register_0.blueish_azure = Style("\x1b[34m", "\x1b[44m")

    register_0.deep_sky_blue = Style(RenderType.RGB(0, 191, 255))

    register_0.pale_azure = Style(RenderType.RGB(170, 240, 253))


# Generated at 2022-06-26 04:22:34.434953
# Unit test for constructor of class Register
def test_Register():
    Register()



# Generated at 2022-06-26 04:22:38.466427
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class TestRenderType(RenderType):
        pass

    def testfunc(reg, *args):
        return f"<{reg} {str(args)}>"

    register_0 = Register()
    # Test init
    assert(register_0.renderfuncs == {})

    # Test setting renderfunc
    register_0.set_renderfunc(TestRenderType, testfunc)

    # Test if new renderfunc was set
    assert(register_0.renderfuncs[TestRenderType] == testfunc)


# Generated at 2022-06-26 04:22:40.880871
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:22:48.836495
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .defaults import fg, bg, ef, rs
    from .rendertype import Sgr, SetFg

    assert fg.as_namedtuple().black == '\x1b[30m'
    assert fg.as_namedtuple().white == '\x1b[97m'

    class Custom(RenderType):
        def __init__(self, x: int):
            self.args = [x]

    register_0 = Register()
    register_0.set_renderfunc(Custom, lambda x: f"{{Custom({x})}}")
    register_0.set_eightbit_call(Custom)

    register_0.blue = Style(Custom(3))
    register_0.green = Style(Custom(4))


# Generated at 2022-06-26 04:22:55.038495
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .format import fg

    # Test if method as_dict works
    assert fg.black.as_dict() ==  {"black":"\x1b[38;5;0m"}

    # Test if method as_dict works with muted register
    fg.mute()
    assert fg.black.as_dict() == {"black": ""}
    fg.unmute()

# Generated at 2022-06-26 04:22:57.138387
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert isinstance(register_0, Register)



# Generated at 2022-06-26 04:23:04.268946
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    test_attr_value_0_0 = Style(*[])
    assert isinstance(test_attr_value_0_0, Style)
    register_0.test_attr_0 = test_attr_value_0_0
    assert isinstance(register_0.test_attr_0, Style)
    assert register_0.test_attr_0.rules == []


# Generated at 2022-06-26 04:23:10.393382
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.eightbit_call = lambda x: x
    register_0.rgb_call = lambda r, g, b: (r, g, b)

    # Call with string
    assert register_0('red') == ''

    # Call with 8-bit color code
    assert register_0(144) == ''

    # Call with 24-bit color code
    assert register_0(10, 42, 255) == ''



# Generated at 2022-06-26 04:23:34.579123
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    assert(len(register_0.as_dict()) == 0)



# Generated at 2022-06-26 04:23:39.939884
# Unit test for method copy of class Register
def test_Register_copy():

    register_0 = Register()
    register_1 = register_0.copy()

    assert register_0 == register_1
    assert register_0.eightbit_call == register_1.eightbit_call
    assert register_0.as_dict() == register_1.as_dict()
    assert register_0.is_muted == register_1.is_muted



# Generated at 2022-06-26 04:23:42.123044
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.mute()
    register_0.unmute()


# Generated at 2022-06-26 04:23:44.942719
# Unit test for method __new__ of class Style
def test_Style___new__():
    rule1 = RenderType()
    rule2 = Style(value="test string", rules=[])
    style = Style(rule1, rule2)
    assert isinstance(style, Style)



# Generated at 2022-06-26 04:23:46.302312
# Unit test for constructor of class Register
def test_Register():
    test_case_0()


# Generated at 2022-06-26 04:23:52.292825
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_0.set_eightbit_call("eightbit")
    register_0.set_rgb_call("rgb")
    register_0.set_renderfunc("rendertype", "func")
    register_0.is_muted = False

    register_1: Register = register_0.copy()

    assert register_0.renderfuncs == register_1.renderfuncs
    assert register_0.is_muted == register_1.is_muted
    assert register_0.eightbit_call == register_1.eightbit_call
    assert register_0.rgb_call == register_1.rgb_call



# Generated at 2022-06-26 04:23:56.510023
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    setattr(register, "red", Style())
    setattr(register, "blue", Style())
    assert register.as_namedtuple().red == ""
    assert register.as_namedtuple().blue == ""


# Generated at 2022-06-26 04:24:03.693884
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_1 = Register()
    assert hasattr(register_1, "fg")
    register_2 = Register()
    register_2.fg = Style(RgbFg(1,5,10), Sgr(1))
    assert isinstance(register_2.fg, Style)
    assert isinstance(register_2.fg, str)
    assert register_2.fg == '\x1b[38;2;1;5;10m\x1b[1m'


# Generated at 2022-06-26 04:24:08.583540
# Unit test for method unmute of class Register
def test_Register_unmute():
    # Instanciate a new register-object
    register_0 = Register()
    # Mute the register object
    register_0.mute()
    # Unmute the register object
    register_0.unmute()



# Generated at 2022-06-26 04:24:19.961433
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sgr import Sgr
    from .ansi import Fg, Bg, Ef, Rs

    register_0 = Register()
    nt_0 = register_0.as_namedtuple()
    assert nt_0 == namedtuple("StyleRegister", [])()

    register_1 = Register()
    register_1.test_1 = Style(Sgr(1, 2, 3), value="\x1b[1;2;3m")
    register_1.test_2 = Style(Sgr(4, 5, 6), value="\x1b[4;5;6m")
    register_1.test_3 = Style(Sgr(7, 8, 9), value="\x1b[7;8;9m")
    nt_1 = register_1.as_namedtuple()


# Generated at 2022-06-26 04:24:47.926061
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()
    assert register_0.is_muted == True


# Generated at 2022-06-26 04:24:49.432903
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()


# Generated at 2022-06-26 04:24:53.084551
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()

    assert not register_0.is_muted

    register_0.mute()

    assert register_0.is_muted


# Generated at 2022-06-26 04:25:05.647013
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int) -> None:
            self.args = (r, g, b)

    @RgbFg.renderer
    def render(r: int, g: int, b: int) -> str:
        return "render_rgb_fg"

    register_0 = Register()

    register_0.set_renderfunc(RgbFg, render)

    register_0.set_rgb_call(RgbFg)

    register_0_result = register_0(10, 20, 30)

    assert register_0_result == "render_rgb_fg"

# Generated at 2022-06-26 04:25:08.837159
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Case 0:
    try:
        register_0 = Register()
        register_0.set_rgb_call("x")
    except Exception as e:
        print(f"Case 0: {type(e)}\n")


# Generated at 2022-06-26 04:25:12.700433
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType.Sgr)
    register_1 = register_0.copy()
    assert register_0.eightbit_call is render_sgr_eightbit



# Generated at 2022-06-26 04:25:18.968298
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)
    register_0.set_eightbit_call(RenderType)


test_Register_set_eightbit_call()


# Generated at 2022-06-26 04:25:31.451239
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RgbFg, EightBitFg, RgbBg, EightBitBg

    register_0 = Register()
    setattr(register_0, "color_0", Style(rendertype_0))

    # Test the callable return value.
    assert callable(register_0(0)) is True
    assert register_0(0) == ""

    register_0.set_renderfunc(EightBitFg, renderfunc_0)
    assert callable(register_0(0)) is True
    assert register_0(0) == "\x1b[38;5;0m"

    register_0.set_renderfunc(EightBitBg, renderfunc_0)
    assert callable(register_0(0)) is True

# Generated at 2022-06-26 04:25:33.372103
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()

    register_0.mute()

    assert register_0.is_muted == True


# Generated at 2022-06-26 04:25:35.477066
# Unit test for method mute of class Register
def test_Register_mute():
    register_1 = Register()
    register_1.mute()


# Generated at 2022-06-26 04:27:14.817957
# Unit test for method __new__ of class Style
def test_Style___new__():
    Style("", "", "")
    Style("", "", "", value="")


# Generated at 2022-06-26 04:27:18.607801
# Unit test for constructor of class Register
def test_Register():

    # Test constructor
    register = Register()
    assert isinstance(register, Register)



# Generated at 2022-06-26 04:27:22.652973
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.newattr = Style(value='my string')
    temp_0 = register_0.as_namedtuple()
    assert temp_0.newattr == 'my string'
    register_0.newattr = Style(value='my string')
    assert register_0.newattr == 'my string'


# Generated at 2022-06-26 04:27:26.198766
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    # Should return "" or default style?
    assert register_0() == ""


# Generated at 2022-06-26 04:27:34.831846
# Unit test for method copy of class Register
def test_Register_copy():
    import pytest
    register_0 = Register()
    register_0.set_eightbit_call("some_str")
    register_0.set_eightbit_call("some_other_str")
    register_0.mute()
    register_0.mute()
    register_0.mute()
    register_0.mute()
    register_0.mute()
    register_0.mute()
    with pytest.raises(Exception):
        register_0.set_eightbit_call("some_other_str")
    register_0.copy()
    register_0.copy()
    register_0.copy()

# Generated at 2022-06-26 04:27:46.273578
# Unit test for method __new__ of class Style
def test_Style___new__():
    # case 1
    styles = [
        Style(RgbFg(1, 2, 3), Sgr(1), RgbBg(1, 2, 3)),
        Style(
            Style(RgbFg(1, 2, 3), RgbBg(1, 2, 3)),
            Style(RgbFg(1, 2, 3), RgbBg(1, 2, 3)),
        ),
    ]

    # case 2
    try:
        Style(1)
    except ValueError as e:
        _ = e

    # case 3
    try:
        Style(Style(1))
    except ValueError as e:
        _ = e

    # case 4

# Generated at 2022-06-26 04:27:53.710636
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # setUp
    register = Register()
    register.set_renderfunc(RenderType.NEXT_RGB_FG, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    # test
    register.set_rgb_call(RenderType.NEXT_RGB_FG)
    # assert
    assert register.rgb_call(34,21,3) == '\x1b[38;2;34;21;3m'

# Generated at 2022-06-26 04:28:00.625169
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    register_0.color = Style(RgbFg(4,4,4))
    assert register_0.as_dict() == {'color': '\x1b[38;2;4;4;4m'}


# Generated at 2022-06-26 04:28:08.864830
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    register_0 = Register()
    register_1 = Register()

    assert isinstance(register_0, Register)
    assert isinstance(register_1, Register)

    register_1.set_eightbit_call(lambda x: x)
    register_1.set_rgb_call(lambda r, g, b: (r, g, b))

    assert register_1.eightbit_call(1) == 1
    assert register_1.rgb_call(2, 3, 4) == (2, 3, 4)

    register_0.eightbit = Style(register_1.eightbit_call(1))
    register_0.rgb = Style(register_1.rgb_call(2, 3, 4))

    register_0_dict = register_0.as_dict()

# Generated at 2022-06-26 04:28:17.162344
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.renderfuncs = {type(RenderType): lambda: 1}
    register_0.is_muted = False
    register_0.eightbit_call = lambda x: x
    register_0.rgb_call = lambda r, g, b: (r, g, b)

    assert register_0.is_muted == False
    assert register_0.eightbit_call(37) == 37
    assert register_0.rgb_call(1,2,3) == (1,2,3)

    # Test case 0