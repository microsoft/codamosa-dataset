

# Generated at 2022-06-26 04:19:36.404578
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    @RenderType
    def RgbFg(r: int, g: int, b: int) -> str:
        return "rgb({r},{g},{b})".format(r=r, g=g, b=b)

    @RenderType
    def Sgr(value: int) -> str:
        return "sgr({value})".format(value=value)

    def render_rgb_fg_call(r: int, g: int, b: int) -> str:
        return "render_rgb_fg_call({r},{g},{b})".format(r=r, g=g, b=b)

    def render_sgr_call(value: int) -> str:
        return "render_sgr_call({value})".format(value=value)

    # Initialize a new Register

# Generated at 2022-06-26 04:19:43.787722
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    RenderType0 = RenderType("RenderType0", "s")
    RenderType1 = RenderType("RenderType1", "s")

    func = lambda x: ""

    register = Register()

    register.set_renderfunc(RenderType0, func)
    register.set_renderfunc(RenderType1, func)

    assert register.renderfuncs == {RenderType0: func, RenderType1: func}



# Generated at 2022-06-26 04:19:46.442100
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    rendertype = type("RenderType", (), {})
    func = lambda: None
    register_0.set_renderfunc(rendertype, func)



# Generated at 2022-06-26 04:19:53.318541
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Check if dictionary set_renderfunc works
    """
    register_0 = Register()

    RenderType_0 = namedtuple('RenderType', ['renderfunc', ])
    renderfunc_0 = lambda: (Register()).mute()

    rendertype_0 = RenderType_0(renderfunc_0)
    func_0 = lambda: (Register()).mute()
    register_0.set_renderfunc(rendertype_0, func_0)



# Generated at 2022-06-26 04:19:59.409559
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr, RgbFg, RgbBg

    def func1(*args):
        return "\033[1m"

    def func2(*args):
        return "\033[38;2;{};{};{}".format(args[0], args[1], args[2])

    register_1 = Register()
    register_1.set_renderfunc(rendertype=Sgr, func=func1)
    register_1.set_renderfunc(rendertype=RgbFg, func=func2)
    register_1.set_renderfunc(rendertype=RgbBg, func=func2)

    register_1.msg_bold = Style(Sgr(1))

    assert register_1.msg_bold == "\033[1m"


# Generated at 2022-06-26 04:20:06.716110
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Given an instance of class Register
    (i) Call set_renderfunc with valid arguments
    (ii) Call the renderfunction that was added for the rendertype with an argument
    (iii) Assert that the result is equal to the argument
    """

    # Given
    render_type = RenderType
    render_func = lambda x: x

    # When
    register = Register()
    register.set_renderfunc(render_type, render_func)

    # Then
    assert render_func("test") == "test"


# Generated at 2022-06-26 04:20:17.894640
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import RgbFg, RgbBg, RgbEf, Sgr
    from .rendertype import EightBitFg, EightBitBg, EightBitEf, Reset

    class TestRegister(Register):
        pass

    register = TestRegister()
    register.set_renderfunc(RgbBg, lambda *args: "123")
    register.set_renderfunc(EightBitFg, lambda x: f"{x:03}")
    register.set_renderfunc(RgbFg, lambda *args: "456")
    register.set_renderfunc(EightBitBg, lambda x: f"{x:03}")
    register.set_renderfunc(RgbEf, lambda *args: "789")

# Generated at 2022-06-26 04:20:26.056918
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    class RenderType_0(RenderType):
        def __init__(self, val0 : int, val1 : int, val2 : int):
            super().__init__()
            self.arg0 = val0
            self.arg1 = val1
            self.arg2 = val2

    def func_0(*args, **kwargs):
        return "func_0"

    register_0.set_renderfunc(RenderType_0, func_0)


# Generated at 2022-06-26 04:20:31.386753
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Arrange
    def rendertype_1(*args):
        return "A"
    def rendertype_2(*args):
        return "B"
    register_0 = Register()
    register_0.set_renderfunc(RenderType, rendertype_1)
    register_0.set_renderfunc(RenderType, rendertype_2)

    # Act
    rendered = register_0.renderfuncs.get(RenderType)

    # Assert
    assert rendered == rendertype_2


# Generated at 2022-06-26 04:20:35.502301
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    register_0.set_renderfunc(Style, lambda x: x)

# Generated at 2022-06-26 04:20:49.338382
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    def render_8bit_color(color: int) -> str: return "\033[38;5;" + str(color) + "m"

    register1 = Register()
    register1.set_renderfunc(EightbitFg, render_8bit_color)

    assert register1.set_eightbit_call.__closure__[
        1].cell_contents(1) == "\033[38;5;1m"

    def render_24bit_color(color: int) -> str: return "\033[38;2;" + str(color) + "m"

    register2 = Register()
    register2.set_renderfunc(RgbFg, render_24bit_color)


# Generated at 2022-06-26 04:20:52.690946
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda: "")


# Generated at 2022-06-26 04:21:02.276483
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def render_type_to_ansi_seq(rendertype: RenderType) -> str:
        # TODO: Create register test class.
        if isinstance(rendertype, RenderType):
            return str(rendertype)
        else:
            # TODO: Change ValueError to TypeError
            raise ValueError("The parameter 'rendertype' must be of type 'RenderType'.")

    register_2 = Register()
    register_2.set_renderfunc(RenderType, render_type_to_ansi_seq)

    r1, r2 = register_2.renderfuncs[RenderType](RenderType())
    assert r1 == "\x1b[0m\x1b[m"



# Generated at 2022-06-26 04:21:11.717387
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    register_0.set_renderfunc(str, lambda x: x)
    assert isinstance(register_0.renderfuncs, Renderfuncs)
    assert len(register_0.renderfuncs) == 1
    register_0.set_renderfunc(str, lambda x: x)
    assert len(register_0.renderfuncs) == 1
    assert isinstance(register_0.renderfuncs[str], Callable)


# Generated at 2022-06-26 04:21:24.439426
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Create register and add rendertype
    register_1 = Register()
    rendertype_1 = object()
    renderfunc_1 = lambda: ""
    register_1.set_renderfunc(rendertype_1, renderfunc_1)

    # Create style and add rendertype to style
    style_1 = Style(rendertype_1, value="")

    # Set style as attribute of register
    register_1.style_1 = style_1

    def test_1(style) -> bool:
        return style.value == ""

    assert test_1(register_1.style_1)

    # Create new renderfunc
    renderfunc_2 = lambda: "ASD"
    register_1.set_renderfunc(rendertype_1, renderfunc_2)

    def test_2(style) -> bool:
        return style.value

# Generated at 2022-06-26 04:21:28.125692
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    rendertype = RenderType
    func = lambda: None
    register_0.set_renderfunc(rendertype, func)


# Generated at 2022-06-26 04:21:31.149716
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    register_0.set_renderfunc(RenderType, func=lambda *args, **kwargs: "")
    assert True


# Generated at 2022-06-26 04:21:43.100200
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    Register_0 = Register()

    # Check if set_renderfunc is set attribute 'renderfuncs'
    assert getattr(Register_0, 'renderfuncs') is not None

    # Check if set_renderfunc is set renderfuncs[Type[RenderType]]:
    assert list(Register_0.renderfuncs.keys()) == []

    # Add value to renderfuncs through set_renderfunc
    Register_0.set_renderfunc(0, 1)

    # Check if set_renderfunc has added value to renderfuncs[Type[RenderType]]:
    assert Register_0.renderfuncs[0] == 1

    # Check if set_renderfunc raises ValueError when given rendertype is not a subclass of RenderType

# Generated at 2022-06-26 04:21:47.598146
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register = Register()
    test_attr = Style(RgbBg(1, 5, 10), Sgr(1))
    setattr(register, "test_attr", test_attr)
    register.set_renderfunc(RgbBg, lambda *args: f"\x1b[38;2;{args[0]};{args[1]};{args[2]}m\x1b[1m")
    register.set_renderfunc(Sgr, lambda *args: f"\x1b[{args[0]}m")
    assert register.test_attr == "\x1b[38;2;1;5;10m\x1b[1m"

# Generated at 2022-06-26 04:21:56.274235
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr
    from .sty import Sty
    from .constants import ANSI_RESET

    sgr = Sgr(10)
    func = sgr.to_ansi
    renderfuncs = {Sgr: func}

    # Test set_renderfunc and set_eightbit_call
    sgr.set_renderfunc(Sgr, func)
    sgr.set_eightbit_call(Sgr)

    # Check the work of set_renderfunc
    sgr_test_string = func(*sgr.args)

    assert sgr_test_string == sgr.to_ansi(*sgr.args)
    assert sgr_test_string == sgr.fg(1)
    assert sgr_test_string == sgr.bg(1)



# Generated at 2022-06-26 04:22:17.631718
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class Sgr(RenderType):
        def render(self) -> str:
            return ""

    class RgbBg(RenderType):
        def render(self) -> str:
            return ""

    class RgbFg(RenderType):
        def render(self) -> str:
            return ""

    register_0 = Register()

    # Register must be muted if renderfuncs is empty.
    assert register_0.is_muted is True

    # Register must be muted if only RgbFg renderfunc is set.
    register_0.set_renderfunc(RgbFg, lambda: None)
    assert register_0.is_muted is True

    # Register must be muted if only RgbBg renderfunc is set.
    register_0.set_renderfunc(RgbBg, lambda: None)

# Generated at 2022-06-26 04:22:19.549898
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda x: x)


# Generated at 2022-06-26 04:22:21.191602
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    RenderType_0 = RenderType # type: ignore
    assert "test" == "test"


# Generated at 2022-06-26 04:22:32.151779
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    register = Register()
    register.set_renderfunc(int, lambda x: str(x))

    # Check that renderfunc is set
    assert register.renderfuncs == {int: lambda x: str(x)}

    # Use newly set renderfunc to render a Style
    style = Style(123)
    register.set_renderfunc(int, lambda x: str(x))
    expected = Style(123, value="123")
    assert style == expected

    # Use newly set renderfunc to render a Style
    style = Style(123)
    register.set_renderfunc(int, lambda x: str(x))
    expected = Style(123, value="123")
    assert style == expected


# Generated at 2022-06-26 04:22:38.868546
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # We start by creating a new Register-object.
    test_register: Register = Register()

    # Now we need a rendertype that is not used by default.
    class MyRendertype(RenderType):
        _format_ansi = "RENDERFUNC_TEST"

    # Finally, we add the new renderfunc.
    def renderfunc(*args):
        return "RENDERFUNC_TEST"

    test_register.set_renderfunc(MyRendertype, renderfunc)

    # If everything was successful, the rendered Style-attribute should now start with
    # the string 'RENDERFUNC_TEST'.
    assert test_register.test.startswith("RENDERFUNC_TEST")



# Generated at 2022-06-26 04:22:45.316660
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Test: rendertype-key is missing
    rendertype = "rendertype_missing"
    func = lambda: 1
    register = Register()
    register.set_renderfunc(rendertype, func)
    assert (
        register.renderfuncs[rendertype] == func
    ), "rendertype key does not exist."



# Generated at 2022-06-26 04:22:57.499717
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class StyleRule(RenderType):

        def __init__(self, some_value: int):
            self.some_value = some_value

    renderfunc = lambda *a: a

    def set_and_check_renderfunc(register: Register, rendertype: Type[RenderType], renderfunc: Callable) -> None:
        register.set_renderfunc(rendertype, renderfunc)
        assert register.renderfuncs[rendertype] == renderfunc  # Check if the renderfunc was stored correctly.
        assert register.eightbit_call == renderfunc  # Check if the eightbit_call was updated correctly.
        assert register.rgb_call == renderfunc  # Check if the rgb_call was updated correctly.
        assert register.eightbit_call(0) == renderfunc(0)  # Check if the eightbit_call is actually executed correctly.

# Generated at 2022-06-26 04:23:09.279181
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    def func_8bit():
        return "\x1b[38;5;%im"

    def func_rgb():
        return "\x1b[38;2;%i;%i;%im"

    # Create a new register
    r1 = Register()
    # Add renderfunctions
    r1.set_renderfunc(8, func_8bit)
    r1.set_renderfunc(24, func_rgb)
    # Define the rendertypes for direct calls
    r1.set_eightbit_call(8)
    r1.set_rgb_call(24)

    # Assert that the rendertypes are correct
    assert r1.eightbit_call is func_8bit
    assert r1.rgb_call is func_rgb

    # Set a style

# Generated at 2022-06-26 04:23:12.891003
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_1 = Register()

    rendertype = "test_rendertype"
    func = lambda: "test_func"

    # Add renderfunc
    register_1.set_renderfunc(rendertype, func)
    assert register_1.renderfuncs[rendertype] == func

    # Update renderfunc
    register_1.set_renderfunc(rendertype, None)
    assert register_1.renderfuncs[rendertype] is None



# Generated at 2022-06-26 04:23:15.113640
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    register_1 = Register()
    register_1.set_renderfunc(RenderType, lambda x: str(x))


# Generated at 2022-06-26 04:23:46.559746
# Unit test for method copy of class Register
def test_Register_copy():

    from sty import fg, bg, ef, rs
    register_1 = Register()
    register_1.set_renderfunc(ef.italic, lambda: '*italic_func*')
    register_1.italic = Style(ef.italic)
    register_1.mute()
    register_2 = register_1.copy()
    register_1.unmute()
    register_2.unmute()

    assert register_1.italic == '\x1b[3m'
    assert register_2.italic == '*italic_func*'

# Generated at 2022-06-26 04:23:50.315588
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Test-case 0: Method __call__, call with only one parameter.
    register_0 = Register()
    assert isinstance(register_0("bold"), str)

    # Test-case 1: Method __call__, call with three parameters.
    register_1 = Register()
    assert isinstance(register_1(1, 2, 3), str)

    # Test-case 2: Method __call__, call with a mute-object.
    register_2 = Register()
    register_2.mute()
    assert register_2(1, 2, 3) == ""

    # Test-case 3: Method __call__, call with wrong number of parameters.
    register_3 = Register()
    try:
        _ = register_3(1,2,3,4)
    except Exception:
        return
    assert False

    #

# Generated at 2022-06-26 04:24:02.446534
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    
    #  ----  test case 0 ----
    register_0: Register = Register()
    register_0.set_renderfunc(RenderType, lambda x: x)
    
    #  ----  test case 1 ----
    register_1: Register = Register()
    register_1.set_renderfunc(RenderType, lambda x: x)
    
    #  ----  test case 2 ----
    register_2: Register = Register()
    register_2.set_renderfunc(RenderType, lambda x: x)
    
    #  ----  test case 3 ----
    register_3: Register = Register()
    register_3.set_renderfunc(RenderType, lambda x: x)
    
    #  ----  test case 4 ----
    register_4: Register = Register()

# Generated at 2022-06-26 04:24:16.263374
# Unit test for method __new__ of class Style
def test_Style___new__():

    register_0 = Register()

    print("\n>>> g = lambda x: f'foo{x}bar'\n>>> r = Register()\n>>> s = Style(RgbFg(255, 255, 255))\n>>> r.set_renderfunc(RgbFg, g)\n>>> r.red = s\n>>>  r.red\n'foo(255, 255, 255)bar'\n>>> r.set_renderfunc(RgbFg, lambda x, y, z: (x, y, z))\n>>> r.red\n'\x1b[38;2;255;255;255m'\n")

    register_0 = Register()
    s = Style(RgbFg(255, 255, 255))

# Generated at 2022-06-26 04:24:27.510012
# Unit test for method copy of class Register
def test_Register_copy():
    # Create original test object
    register_0 = Register()
    register_0.mute()
    # Create copy of test object
    register_1 = register_0.copy()
    # Check that copy is not just a reference of original object
    assert register_0 is not register_1
    # Check that __dict__ of copy is not a reference to original object
    assert register_0.__dict__ is not register_1.__dict__
    # Check that __dict__ of copy is not a reference to original object
    assert register_0.__dict__["is_muted"] == register_1.__dict__["is_muted"]
    return register_0, register_1


if __name__ == '__main__':
    # Run test case
    test_case_0()
    # Run unit tests
    register_0,

# Generated at 2022-06-26 04:24:28.134817
# Unit test for constructor of class Register
def test_Register():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 04:24:34.070600
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .renderfuncs import Sgr, RgbFg

    register_0 = Register()
    register_0.mute()

    register_0.set_eightbit_call(Sgr)
    register_0.set_rgb_call(RgbFg)

    register_0.blue = Style(Sgr(1), RgbFg(3, 5, 7))

    blue_str: str = "\x1b[1m\x1b[38;2;3;5;7m"

    assert register_0.blue == blue_str

    register_1 = Register()
    register_1.set_renderfunc(Sgr, lambda x: x ** x)

    register_1.green = Style(Sgr(2), RgbBg(1, 2, 3))


# Generated at 2022-06-26 04:24:47.964643
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        pass

    class Sgr(RenderType):
        pass

    def rgb_renderfunc(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def sgr_renderfunc(n: int) -> str:
        return f"\x1b[{n}m"

    register0 = Register()
    register0.set_renderfunc(RgbFg, rgb_renderfunc)
    register0.set_renderfunc(Sgr, sgr_renderfunc)

    register0.red = Style(RgbFg(255, 0, 0))
    register0.green = Style(RgbFg(0, 255, 0))

# Generated at 2022-06-26 04:24:57.653057
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    register_1 = Register() # Initialize a Register object

    register_1.style0 = Style(RgbFg(0, 0, 0)) # Set new attribute style0 to a Style object

    assert isinstance(register_1.style0, Style)
    assert register_1.style0.rules == (RgbFg(0, 0, 0),)
    assert isinstance(register_1.as_namedtuple(), namedtuple)
    assert isinstance(register_1.as_namedtuple().style0, str)

    register_1.style1 = Style(RgbFg(255, 0, 0)) # Set new attribute style1 to a Style object
    assert isinstance(register_1.style1, Style)
    assert register_1.style1.rules == (RgbFg(255, 0, 0),)



# Generated at 2022-06-26 04:25:08.837261
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test if set_renderfunc method works correctly
    """
    register_0: Register = Register()
    register_0.set_renderfunc(type(RenderType._8bit), RenderType.render_8bit)
    register_0.set_renderfunc(type(RenderType.Sgr), RenderType.render_sgr)
    register_0.set_renderfunc(type(RenderType.Decsgr), RenderType.render_decsgr)
    assert register_0.renderfuncs == {type(RenderType._8bit): RenderType.render_8bit, type(RenderType.Sgr): RenderType.render_sgr, type(RenderType.Decsgr): RenderType.render_decsgr}


# Generated at 2022-06-26 04:26:03.328996
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .renderfuncs import eightbit_call
    from .rendertype import SetFg, Eightbit

    register_0 = Register()

    # Register is set to ANSI-Style
    assert register_0.eightbit_call(1) == "\x1b[38;5;1m"

    # Now it is set to xterm256-style
    register_0.set_eightbit_call(Eightbit)
    assert register_0.eightbit_call(1) == "\x1b[38;5;1m"
    assert register_0.eightbit_call(1) != "\x1b[38;2;1m"

    # Change to ANSI style
    register_0.set_eightbit_call(SetFg)

# Generated at 2022-06-26 04:26:10.469805
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.mute()
    register_0.set_eightbit_call(RenderType)
    register_0.set_rgb_call(RenderType)
    register_0.set_renderfunc(RenderType, lambda r, g, b: (r, g, b))
    register_0.unmute()
    register_0.red = Style(RenderType())
    register_0.orange = Style(RenderType(), RenderType())
    register_0.yellow = Style(RenderType(), RenderType(), RenderType())
    register_0.green = Style(RenderType(), RenderType(), RenderType(), RenderType())
    register_0.blue = Style(RenderType(), RenderType(), RenderType(), RenderType(), RenderType())

# Generated at 2022-06-26 04:26:11.974513
# Unit test for constructor of class Register
def test_Register():
    register_1 = Register()


# Generated at 2022-06-26 04:26:19.653000
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import Sgr

    register = Register()
    func = lambda x: x
    register.set_renderfunc(Sgr, func)

    register.set_eightbit_call(Sgr)
    register.set_rgb_call(Sgr)
    register.set_renderfunc(Sgr, func)

    rule = Sgr(10)
    style = Style(rule, "red_style")

    register.red = style
    register.red_style = style


# Generated at 2022-06-26 04:26:22.724194
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Test if dictionary is returned

    # Test if dictionary only contains values that are of type Style
    assert 1 == 1

# Generated at 2022-06-26 04:26:28.825677
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    color_register = Register()
    color_register.mute()

    color_register.black = Style(RgbBg(0, 0, 0))
    color_register.white = Style(RgbBg(255, 255, 255))

    assert color_register.as_dict() == {'black': '', 'white': ''}


# Generated at 2022-06-26 04:26:33.596081
# Unit test for method mute of class Register
def test_Register_mute():
    global register_0  # a register initialized to mute
    register_0.mute()
    assert register_0.is_muted == True


# Generated at 2022-06-26 04:26:41.610255
# Unit test for constructor of class Style
def test_Style():

    # creating a style object and check if its attribute 'rules' is of
    # type tuple and if the str-representation of the object is empty
    style_0 = Style()
    assert isinstance(style_0.rules, tuple)
    assert str(style_0) == ""

    # creating a style object with a single rule and check if its attribute
    # 'rules' is of type tuple
    style_1 = Style(21)
    assert isinstance(style_1.rules, tuple)

    # creating a style object with several rules and check if its attribute
    # 'rules' is of type tuple
    style_2 = Style(3, 4, 5)
    assert isinstance(style_2.rules, tuple)


# Generated at 2022-06-26 04:26:54.077215
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .boldertype import BolderType
    from .rendertype import RenderType
    from .sty import Sty
    from .stylename import StyleName

    register_0 = Register()
    register_0.mute()

    def renderfunc(*args: int, **kwargs) -> str:
        return "foo"

    sty: Sty = Sty(StyleName.LIGHT)
    sty._init_renderfuncs()

    register_0.set_renderfunc(BolderType, renderfunc)

    assert renderfunc == register_0.renderfuncs[
        BolderType
    ], "Test for Sty, method set_renderfunc, var 'renderfunc' failed."

    register_0.set_rgb_call(BolderType)


# Generated at 2022-06-26 04:27:00.278451
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.blue = Style("blue")
    register_0.green = Style("green")
    namedtuple_object_0 = register_0.as_namedtuple()
    assert namedtuple_object_0.blue == register_0.blue
    assert namedtuple_object_0.green == register_0.green


# Generated at 2022-06-26 04:28:05.499251
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.red = Style(RgbFg(255, 0, 0), Sgr(1))
    register_0.blue = Style(RgbFg(0, 0, 255))
    assert register_0.as_namedtuple() == namedtuple("StyleRegister", ("red", "blue"))("\033[38;2;255;0;0m\033[1m", "\033[38;2;0;0;255m")



# Generated at 2022-06-26 04:28:08.205215
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()

    assert isinstance(register_0, Register)



# Generated at 2022-06-26 04:28:14.722757
# Unit test for constructor of class Style
def test_Style():
    # Testtuple with (1) expected output, (2) input
    testtupel = (
        "",
        "",
    )
    # Create Object
    style = Style()
    # Test if the input matches the output
    assert str(style) == testtupel[0]
    assert style.rules == testtupel[1]



# Generated at 2022-06-26 04:28:26.769616
# Unit test for method copy of class Register
def test_Register_copy():
    # Create reference register.
    register_0 = Register()
    register_0.set_eightbit_call(RenderType.SGR)
    register_0.set_rgb_call(RenderType.RGB)
    register_0.unmute()
    register_0.red = Style(RenderType.SGR(31))
    register_0.forest = Style(RenderType.RGB(102, 51, 0))

    # Test the copy
    register_1 = register_0.copy()

    assert register_1.eightbit_call is register_0.eightbit_call
    assert register_1.rgb_call is register_0.rgb_call
    assert register_1.renderfuncs is register_0.renderfuncs
    assert register_1.red is not register_0.red
    assert register_1.forest

# Generated at 2022-06-26 04:28:36.288603
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    r0: Register = Register()

    rules_1: Tuple[RenderType, ...] = (RgbFg(100, 100, 100),)
    rules_2: Tuple[RenderType, ...] = (EightbitFg(250),)

    s1: Style = Style(*rules_1)
    s2: Style = Style(*rules_2)

    r0.hello = s1
    r0.world = s2

    assert isinstance(r0.hello, Style)

    assert isinstance(r0.world, Style)

    assert isinstance(r0.hello, str)

    assert isinstance(r0.world, str)

    assert str(r0.hello) == "\x1b[38;2;100;100;100m"


# Generated at 2022-06-26 04:28:48.010368
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()

    # Test: Add an new render-function
    def renderfunc_0(code: int) -> str:
        return f"{code}\x1b[0m"
    
    register_0.set_renderfunc(RenderType, renderfunc_0)
    assert register_0.renderfuncs[RenderType] == renderfunc_0

    # Test: Override an existing render-function
    def renderfunc_1(code: int) -> str:
        return f"{code}\x1b[1m"

    register_0.set_renderfunc(RenderType, renderfunc_1)
    assert register_0.renderfuncs[RenderType] == renderfunc_1



# Generated at 2022-06-26 04:28:56.712408
# Unit test for constructor of class Style
def test_Style():
    style1 = Style(str(Style("123", "456")))
    style2 = Style(str(Style("789")))
    style3 = Style("123", "456", "789")
    assert str(style1) + str(style2) == style3
    assert Style("123", "456").rules == ("123", "456")
    assert Style("123", "456", str(Style("789"))).rules == ("123", "456", "789")



# Generated at 2022-06-26 04:29:02.741389
# Unit test for constructor of class Style
def test_Style():

    assert str(Style(Sgr(0), Sgr(1), value="\x1b[0m\x1b[1m")) == "\x1b[0m\x1b[1m"
    assert str(Style(Sgr(0), value="\x1b[0m")) == "\x1b[0m"
    assert str(Style(Sgr(39), Sgr(49), value="\x1b[39m\x1b[49m")) == "\x1b[39m\x1b[49m"
    assert str(Style(Sgr(90), Sgr(100), value="\x1b[90m\x1b[100m")) == "\x1b[90m\x1b[100m"

# Generated at 2022-06-26 04:29:05.777398
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()
    assert register_0.is_muted


# Generated at 2022-06-26 04:29:08.247144
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    print("Test Register.set_eightbit_call()")
    register = Register()

    register.set_eightbit_call(RgbFg)
    assert register.eightbit_call == RgbFg
    print("\tSuccess")

