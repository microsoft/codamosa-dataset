

# Generated at 2022-06-26 04:19:35.406813
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Rgbc(RenderType):
        def __init__(self, r: int, g: int, b: int) -> None:
            self.args = (r, g, b)

    style_0 = Style("A", "B", "C")
    style_1 = Style("D", "E", "F")
    style_2 = Style("G", "H", "I")
    style_3 = Style("K", "L", "M")

    def _rgbc_render(r: int, g: int, b: int) -> str:
        return f"R({r},{g},{b})"

    obj_0 = Register()
    obj_0.set_renderfunc(Rgbc, _rgbc_render)
    obj_0.set_rgb_call(Rgbc)

    obj

# Generated at 2022-06-26 04:19:39.506631
# Unit test for constructor of class Register
def test_Register():
    test_r = Register()
    test_r2 = Register()
    assert test_r.renderfuncs == test_r2.renderfuncs


# Generated at 2022-06-26 04:19:49.317541
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RenderType(RenderType):
        def render(*args):
            pass

    def _test_register(reg):

        assert reg(2) == ""
        assert reg(10, 23, 34) == ""
        assert reg(10, 45) == ""

    rendertype = RenderType()
    renderfuncs = {rendertype: rendertype.render}

    reg = Register()

    setattr(reg, 'red', Style(rendertype))
    setattr(reg, 'blue', Style(rendertype))
    setattr(reg, 'green', Style(rendertype))

    # Reg is muted, so all of the above in this block should return ""
    reg.mute()
    _test_register(reg)

    # Unmute reg for this block
    reg.unmute()
    _test_register(reg)

    #

# Generated at 2022-06-26 04:19:56.455153
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Sgr, RgbBg, RgbFg
    from .register import Register

    register = Register()
    register.set_eightbit_call(Sgr)
    assert register(1, 2) == "\x1b[22m"
    assert register(7, 1) == "\x1b[21m"

    register.set_rgb_call(RgbBg)
    assert register(12, 123, 26) == "\x1b[48;2;12;123;26m"



# Generated at 2022-06-26 04:19:57.860202
# Unit test for method __call__ of class Register
def test_Register___call__():
    pass



# Generated at 2022-06-26 04:20:03.611002
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    assert register is not None
    assert register.is_muted is False
    assert register.eightbit_call is not None
    assert register.rgb_call is not None
    assert register.renderfuncs is not None

# Generated at 2022-06-26 04:20:06.203764
# Unit test for constructor of class Register
def test_Register():
    """
    The constructor of a Register object must not fail.
    """
    register = Register()

    assert register is not None



# Generated at 2022-06-26 04:20:07.500909
# Unit test for constructor of class Register
def test_Register():
    # Test constructor
    Register()

# Generated at 2022-06-26 04:20:12.105420
# Unit test for constructor of class Register
def test_Register():
    # test constructor
    res = Register()
    assert(res.is_muted == False)

# Generated at 2022-06-26 04:20:19.958926
# Unit test for method __call__ of class Register
def test_Register___call__():

    class Dummy(RenderType):
        def __init__(self, x: int):
            self.args = (x,)

    def dummy_eightbit_renderfunc(x: int) -> str:
        return f"{x}"

    def dummy_rgb_renderfunc(r: int, g: int, b: int) -> str:
        return f"{r}, {g}, {b}"

    register = Register()
    register.set_renderfunc(Dummy, dummy_eightbit_renderfunc)

    register.set_eightbit_call(Dummy)
    assert register(42) == "42"

    register.set_rgb_call(Dummy)
    assert register(42, 13, 13) == "42, 13, 13"



# Generated at 2022-06-26 04:20:26.810739
# Unit test for method mute of class Register
def test_Register_mute():
    sty_register = Register()
    sty_register.mute()
    assert sty_register.is_muted == True


# Generated at 2022-06-26 04:20:37.518608
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr, RgbFg

    def render_func_0(rule_0: RenderType, rule_1: RenderType) -> str:
        return ""

    def render_func_1(rule_0: RenderType) -> str:
        return ""

    register = Register()

    register.set_renderfunc(Sgr, render_func_1)

    assert Sgr in register.renderfuncs
    assert render_func_1 == register.renderfuncs[Sgr]

    register.set_renderfunc(RgbFg, render_func_0)

    assert RgbFg in register.renderfuncs
    assert render_func_0 == register.renderfuncs[RgbFg]


# Generated at 2022-06-26 04:20:48.216616
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Rgb0(RenderType):
        pass

    class Rgb1(RenderType):
        pass

    # Test 8bit-call
    fg = Register()
    fg.set_renderfunc(Rgb0, lambda x: "\x1b[38;2;1;5;10m")
    fg.set_renderfunc(Rgb1, lambda x: "\x1b[38;2;10;5;1m")
    assert fg(144) == "\x1b[38;2;1;5;10m"

    # Test set_eightbit_call.
    fg.set_eightbit_call(Rgb1)
    assert fg(144) == "\x1b[38;2;10;5;1m"

    # Test that 24bit-call is not affected.

# Generated at 2022-06-26 04:21:01.561369
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg
    test_case = fg.blue
    assert test_case == "\x1b[34m"
    assert test_case.__str__() == "\x1b[34m"
    assert test_case.__repr__() == "\x1b[34m"
    assert isinstance(test_case, str) == True
    assert isinstance(test_case, Style) == True
    assert test_case.rules == ()
    assert test_case.is_muted == False
    assert test_case.as_dict() == {'blue': '\x1b[34m'}
    assert test_case.as_namedtuple() == StyResult(blue='\x1b[34m')

# Generated at 2022-06-26 04:21:10.833517
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    style_0 = Style()
    style_1 = Style(style_0)
    style_2 = Style(style_1)
    style_3 = Style(style_2)
    style_4 = Style(style_0, style_1)
    style_5 = Style(style_2, style_3)
    style_6 = Style(style_4, style_5)


test_Register___setattr__()

# Generated at 2022-06-26 04:21:23.187798
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .render import sgr_no_args
    r = Register()
    r.set_renderfunc(Sgr, sgr_no_args)
    r.bold = Style(Sgr(1))
    r.bold2 = Style(Sgr(1))
    r.bold3 = Style(Sgr(1))
    r.bold4 = Style(Sgr(1))
    r.underline = Style(Sgr(1))
    r.italic = Style(Sgr(1))
    r.blink = Style(Sgr(1))
    r.blink2 = Style(Sgr(1))
    nt = r.as_namedtuple()

# Generated at 2022-06-26 04:21:25.721465
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    r.set_rgb_call(RenderType)


# Generated at 2022-06-26 04:21:40.998775
# Unit test for method __call__ of class Register
def test_Register___call__():

    rg = Register()
    rg.caution = Style()

    # Call with string argument
    x = rg("caution")
    assert x == ""

    style_0 = Style()

    rg = Register()
    rg.caution = style_0

    # Call with named attributes
    x = rg("caution")
    assert x == ""

    # Call with string argument
    x = rg("caution")
    assert x == ""

    # Call with string argument
    rg = Register()
    style_0 = Style()

    rg.caution = style_0
    x = rg("caution")
    assert x == ""

    rg.set_eightbit_call("eight_bit")
    x = rg("caution")
    assert x == ""

    # Call with string argument
    rg = Register()

# Generated at 2022-06-26 04:21:48.383905
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.test = Style()
    r.test = Style(value="teststyle")

    assert r.as_dict() == {"test": "teststyle"}
    assert r.as_namedtuple() == namedtuple("StyleRegister", ["test"])("teststyle")


# Now check if all those tests pass and test them with pytest
# if __name__ == '__main__':
#     import sys
#     pytest.main(sys.argv)

# Generated at 2022-06-26 04:21:55.729813
# Unit test for method unmute of class Register
def test_Register_unmute():

    # Create new Register
    reg = Register()
    reg.is_muted = False

    # Check if method unmute did not change values
    assert reg.is_muted == False


# Generated at 2022-06-26 04:22:01.539316
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    Reg = Register()
    Reg.set_rgb_call(RenderType)

# Generated at 2022-06-26 04:22:02.454247
# Unit test for constructor of class Register
def test_Register():
    assert isinstance(Register(), Register)



# Generated at 2022-06-26 04:22:09.094196
# Unit test for method copy of class Register
def test_Register_copy():
    r1 = Register()
    r1.set_rgb_call(RenderType.rgb_fg)
    r1.set_eightbit_call(RenderType.eightbit_bg)

    r2 = r1.copy()

    assert id(r1) != id(r2)
    assert r1.rgb_call == r2.rgb_call
    assert r1.eightbit_call == r2.eightbit_call



# Generated at 2022-06-26 04:22:19.984112
# Unit test for method copy of class Register
def test_Register_copy():
    # Setup
    reg = Register()
    reg.set_eightbit_call(RenderType)
    reg.set_rgb_call(RenderType)
    reg.set_renderfunc(RenderType, lambda *a: '')

    # Execute
    reg_copy = reg.copy()

    # Verify
    assert reg_copy.renderfuncs == reg.renderfuncs
    assert reg_copy.is_muted == reg.is_muted
    assert reg_copy.eightbit_call == reg.eightbit_call
    assert reg_copy.rgb_call == reg.rgb_call



# Generated at 2022-06-26 04:22:23.232704
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style() == style_0
    style_1 = Style("", "", "") == style_1
    style_2 = Style("\x1b[31m", "\x1b[3m") == style_2
    style_3 = Style("\x1b[37m", "\x1b[3m", "") == style_3


# Generated at 2022-06-26 04:22:33.933540
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(NamedTuple):
        r: int
        g: int
        b: int

    class RgbBg(NamedTuple):
        r: int
        g: int
        b: int

    def render_rgb_fg(r, g, b):
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r, g, b):
        return f"\x1b[48;2;{r};{g};{b}m"

    reg = Register()
    assert reg.rgb_call((0, 255, 0)) == ""

    reg.set_renderfunc(RgbFg, render_rgb_fg)

# Generated at 2022-06-26 04:22:35.687154
# Unit test for method copy of class Register
def test_Register_copy():
    # r_0 = Register()
    # r_1 = r_0.copy()

    # assert r_0 != r_1

    # TODO: Fix this.
    assert True

# Generated at 2022-06-26 04:22:45.965158
# Unit test for method copy of class Register
def test_Register_copy():
    renderfuncs = {
        int: lambda *args, **kw: (args, kw)
    }

    register_0 = Register()
    register_0.set_renderfunc(int, renderfuncs[int])

    register_0.test1 = Style(1, 2)

    assert (1, 2) == register_0.test1

    register_1 = register_0.copy()
    assert (1, 2) == register_1.test1

    register_1.test1 = Style(3, 4)
    assert (3, 4) == register_1.test1
    assert (1, 2) == register_0.test1



# Generated at 2022-06-26 04:22:50.521822
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    style_0 = Style("\x1b[38;2;255;255;255m", "\x1b[48;2;0;0;0m")
    r_main = Register()
    setattr(r_main, "style_0", style_0)
    # r_main.style_0 = style_0
    r_main_dict = r_main.as_dict()
    assert "style_0" in r_main_dict.keys()


# Generated at 2022-06-26 04:22:58.139917
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    #Define test values
    valid_input = [RgbFg, RgbBg, RgbEf]
    invalid_input = [Bold, Italic]

    # Create register object
    register_0 = Register()
    register_1 = Register()

    # Check if valid input is accepted
    for rendertype in valid_input:

        # Mock method _render_rules to check if method was called
        register_0._render_rules = mock.Mock(return_value=None)
        register_0.set_rgb_call(rendertype)
        register_0._render_rules.assert_called_once()

    # Check if invalid input raises an error
    for rendertype in invalid_input:
        with pytest.raises(ValueError):
            register_1.set_rgb_call(rendertype)



# Generated at 2022-06-26 04:23:07.408643
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Check if it makes an instance.
    style_0 = Style()


# Generated at 2022-06-26 04:23:11.058497
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register = Register()
    register.set_renderfunc(RenderType, lambda x: "\x1b[38;5;%im" % x)
    register.set_eightbit_call(RenderType)
    assert register(42) == "\x1b[38;5;42m"


# Generated at 2022-06-26 04:23:14.495022
# Unit test for method __call__ of class Register
def test_Register___call__():
    fg = Register()
    style = Style(Sgr(0), Sgr(91))
    fg.red = style
    fg.red  # Should equal '\x1b[0m\x1b[91m'


# Generated at 2022-06-26 04:23:19.643004
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Init register-instances.
    reg = Register()

    # Set style attribute.
    reg.style_0 = Style("style_0")

    # Test cases for method call.
    assert reg("style_0") == "style_0"


# Generated at 2022-06-26 04:23:21.381593
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    style = Register()
    style.color = Style("color")

    with pytest.raises(TypeError):
        style.as_namedtuple()



# Generated at 2022-06-26 04:23:22.929413
# Unit test for method copy of class Register
def test_Register_copy():
    reg = Register().copy()
    assert reg == Register()
    assert reg is not Register()

# Generated at 2022-06-26 04:23:29.703525
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Test without parameters
    # style_0 = Style()
    # style_0.set_eightbit_call()

    # Test with correct parameters
    style_1 = Style()
    style_1.set_eightbit_call(1)

    # style_2 = Style()
    # style_2.set_eightbit_call(bool)


# Generated at 2022-06-26 04:23:30.584656
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    pass


# Generated at 2022-06-26 04:23:41.334559
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # initialize the object
    test_object = Register()
    assert isinstance(test_object, Register)

    # test attribute name
    name = "test_attribute"
    Style_value = Style()
    test_object.__setattr__(name, Style_value)
    result = test_object.__getattribute__(name)
    assert result == Style_value
    assert isinstance(result, Style)

    # test attribute name
    name = "test_attribute_2"
    Style_value = Style()
    test_object.__setattr__(name, Style_value)
    result = test_object.__getattribute__(name)
    assert result == Style_value
    assert isinstance(result, Style)



# Generated at 2022-06-26 04:23:50.352478
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class MyRegister(Register):
        pass

    @rendertype(name="my_rgb_fg")
    def my_rgb_fg(r: int, g: int, b: int) -> str:
        return f"{r};{g};{b}"

    r = MyRegister()
    r.set_rgb_call(my_rgb_fg)

    r_as_dict = r.as_dict()

    assert r_as_dict == {}

    # call with three in-parameters should invoke renderfunc my_rgb_fg
    assert r(10, 20, 30) == "10;20;30"
    assert r.eightbit_call(10) == "10"

    # call with one in-parametere should invoke renderfunc that was previously
    # defined for Eightbit-call (should not be

# Generated at 2022-06-26 04:24:17.763843
# Unit test for method copy of class Register
def test_Register_copy():
    def renderfunc(x, y):
        return f"{x}{y}"
    
    render_dict = {
        'rendertype': renderfunc
    }

    r1 = Register()
    r1.set_renderfunc('rendertype', renderfunc)

    r2 = Register()

    # Add a style attribute to register r1
    r1.sty = Style('sty', rendertype=5)

    # Check if r2 does not contain the style attribute 'sty'
    if r2.sty != Style():
        return 1

    # copy register r1 to register r2
    r2 = r1.copy()

    # check if r2 contains the same style attribute 'sty'
    if r2.sty != Style('sty', rendertype=5):
        return 1



# Generated at 2022-06-26 04:24:25.744785
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class FakeRenderType(RenderType):
        def __init__(self):
            pass

    class FakeRegister(Register):
        def __init__(self):
            super().__init__()
            self.set_renderfunc(FakeRenderType, lambda x: "some string")

    reg = FakeRegister()
    assert reg("some_name") == ""
    assert reg(20) == ""

    reg.set_eightbit_call(FakeRenderType)
    assert reg("some_name") == ""
    assert reg(20) == "some string"

# Generated at 2022-06-26 04:24:31.326432
# Unit test for method __new__ of class Style
def test_Style___new__():
    args_expected_value = [
        ([1], Style(1)),
        ([1, 2, "test_str"], Style(1, 2, "test_str")),
    ]

    for args, expected_value in args_expected_value:
        # Call the method with `*args` as arguments
        result: Style = Style(*args)

        assert result == expected_value
        assert result.rules == args



# Generated at 2022-06-26 04:24:43.845099
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    class RenderType_0(RenderType):
        __slots__ = ('args',)
        def __init__(self, *args):
            self.args = args
        def __repr__(self):
            return (super(RenderType_0, self).__repr__()
                    + '('
                    + ', '.join(map(repr, self.args))
                    + ')'
                    )
        def __str__(self):
            return '\x1b[' + ';'.join(map(str, self.args)) + 'm'

    def renderfunc_0(*args):
        return '\x1b[' + ';'.join(map(str, args)) + 'm'

    renderfuncs: Dict[Type[RenderType], Callable] = {}

# Generated at 2022-06-26 04:24:46.909417
# Unit test for method mute of class Register
def test_Register_mute():
    r0 = Register()
    r0.mute()
    assert r0.is_muted == True, "Register should be muted after method mute() is called."


# Generated at 2022-06-26 04:24:51.902282
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Setup
    def renderfunc(x):
        return "This is a renderfunc!"

    # Test
    r = Register()
    r.set_renderfunc(Style, renderfunc)
    assert r.renderfuncs[Style] == renderfunc


# Generated at 2022-06-26 04:25:02.880573
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    def rendertype_0(x):
        return '\x1b[' + str(x) + 'm'

    class RenderType_0():
        pass

    rendertype_0_type = RenderType_0()

    print(rendertype_0(42))
    print(rendertype_0_type)

    reg = Register()
    reg.set_renderfunc(RenderType_0, rendertype_0)
    reg.set_eightbit_call(RenderType_0)

    print(reg(42))


# Generated at 2022-06-26 04:25:12.767113
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)
    assert len(style_0) == 0

    style_1 = Style(value='abc')
    assert isinstance(style_1, Style)
    assert isinstance(style_1, str)
    assert len(style_1) == 3

    style_2 = Style(value='abc', rules=[])
    assert isinstance(style_2, Style)
    assert isinstance(style_2, str)
    assert len(style_2) == 3

if __name__ == "__main__":
    test_case_0()
    test_Style___new__()

# Generated at 2022-06-26 04:25:15.639888
# Unit test for method copy of class Register
def test_Register_copy():
    import copy
    reg = Register()
    reg.style_name = Style()
    reg_copy = reg.copy()
    assert reg is not reg_copy
    assert reg.style_name is not reg_copy.style_name
    assert isinstance(reg, Register)
    assert isinstance(reg_copy, Register)



# Generated at 2022-06-26 04:25:19.777638
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)
    assert not hasattr(style_0, "rules")


# Generated at 2022-06-26 04:26:22.185600
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    If a register is intialized with a method, then this method should be the one
    that is returned.

    Note: The order of the items may change. Therefore we only check that the
    right key-value-pairs are in the dict.
    """

    register = Register()
    register.set_eightbit_call(Sgr)
    register.set_rgb_call(RgbFg)

    # Register to be tested.
    r = register
    r.blue = Style(Sgr(34), RgbFg(10, 20, 30), RgbBg(40, 50, 60))
    r.green = Style(Sgr(32), RgbFg(0, 255, 0))

    d = r.as_dict()

    # Check that all style-attrs are in dict.

# Generated at 2022-06-26 04:26:27.118122
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    assert isinstance(fg.as_namedtuple(), namedtuple)



# Generated at 2022-06-26 04:26:33.670025
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Test basic usage.
    register_instance = Register()
    register_instance.foo = Style("foo")
    register_instance.bar = Style("bar")
    assert register_instance.as_dict() == {'foo': 'foo', 'bar': 'bar'}


# Generated at 2022-06-26 04:26:38.318664
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    style_0 = Style()
    register_0 = Register()
    register_0.testcase_0 = style_0
    assert isinstance(register_0.testcase_0, Style) is True


# Generated at 2022-06-26 04:26:41.709189
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style(str)
    assert style == ''
    assert isinstance(style, Style)
    assert isinstance(style, str)


# Generated at 2022-06-26 04:26:42.075616
# Unit test for method __call__ of class Register
def test_Register___call__():
    r0 = Register()

# Generated at 2022-06-26 04:26:54.178331
# Unit test for method mute of class Register
def test_Register_mute():

    renderfuncs = {
        # rendertype: render_function
    }

    r = Register()
    r.set_renderfunc(RenderType.RgbFg, lambda r, g, b: "")
    r.set_renderfunc(RenderType.Sgr, lambda x: "")

    r.green = Style(RenderType.RgbFg(0, 255, 0))
    r.red = Style(RenderType.RgbFg(255, 0, 0))
    r.bold = Style(RenderType.Sgr(1))

    assert str(r.green) == "\x1b[38;2;0;255;0m"
    assert str(r.green + r.bold) == "\x1b[38;2;0;255;0m\x1b[1m"

    r.mute

# Generated at 2022-06-26 04:26:57.824785
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()

    assert not r.is_muted

    r.mute()

    assert r.is_muted



# Generated at 2022-06-26 04:26:59.413787
# Unit test for constructor of class Register
def test_Register():
    _ = Register()


# Generated at 2022-06-26 04:27:06.334472
# Unit test for constructor of class Register
def test_Register():
    test_register = Register()
    assert test_register.renderfuncs == {}
    assert test_register.is_muted == False
    assert callable(test_register.eightbit_call)
    assert callable(test_register.rgb_call)



# Generated at 2022-06-26 04:28:58.290673
# Unit test for method copy of class Register
def test_Register_copy():
    from .colors import bg, fg, ef, rs

    # Test a register-object with a value that gets created from the class constructor.
    bg_copy = bg.copy()

    assert bg_copy.blue is not bg.blue
    assert bg.blue is not bg.blue
    assert bg_copy.blue is bg.blue
    assert bg_copy.blue == bg.blue

    assert bg_copy.renderfuncs == bg.renderfuncs

    # Test a register-object with a value that gets created with __setattr__.
    bg_copy.red_blue = Style(fg.red, bg.blue)

    assert bg_copy.red_blue is not bg.red_blue
    assert bg.red_blue is not bg.red_blue

# Generated at 2022-06-26 04:29:08.689029
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    """
    Create a new Register object, create a new RenderType, set the new RenderType as
    eightbit-rendertype and test if the expected function-call happens in the register
    object.
    """

    r = Register()

    class ColorType(RenderType):
        """
        This is a test class, that is used to check if the register-object calls
        a given renderfunc correctly.
        """

        def __init__(self, color, *args):
            self.color = color
            self.args = args


# Generated at 2022-06-26 04:29:16.694332
# Unit test for method mute of class Register
def test_Register_mute():
    style_0 = Style(foreground=12)
    reg = Register()
    reg.mute()
    reg.lightblue = style_0

    if str(reg.lightblue) != "":
        raise AssertionError("Mute_0 failed.")

