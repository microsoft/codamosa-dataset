

# Generated at 2022-06-26 04:19:24.016972
# Unit test for constructor of class Register
def test_Register():
    assert Register()


# Generated at 2022-06-26 04:19:36.000285
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()

    class R1(RenderType):
        pass

    def r1(*args, **kwargs):
        return "R1"

    r.set_renderfunc(R1, r1)

    assert r(R1()) == "R1"

    class R2(RenderType):
        pass

    def r2(*args, **kwargs):
        return "R2"

    r.set_renderfunc(R2, r2)

    assert r(R2()) == "R2"

    class R3(RenderType):
        pass

    def r3(*args, **kwargs):
        return "R3"

    r.set_renderfunc(R3, r3)

    assert r(R3()) == "R3"


# Generated at 2022-06-26 04:19:45.541662
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    Test __call__ of Register-class.
    """
    from sty import fg, bg, ef, rs

    # Test for calling a color
    assert (fg(1) == "\x1b[38;2;255;0;0m")

    # Test for calling a color
    assert (bg(1) == "\x1b[48;2;255;0;0m")

    # Test for calling effect
    assert (ef.bold == "\x1b[1m")

    # Test for calling reset
    assert (rs.all == "\x1b[0m")



# Generated at 2022-06-26 04:19:46.920701
# Unit test for constructor of class Register
def test_Register():
    reg: Register = Register()

    assert isinstance(reg, Register)



# Generated at 2022-06-26 04:19:49.034146
# Unit test for constructor of class Register
def test_Register():
    # Create test object.
    test_register = Register()

    # Test for correct creation and type.
    assert isinstance(test_register, Register)



# Generated at 2022-06-26 04:19:58.064436
# Unit test for method __call__ of class Register
def test_Register___call__():
    _style_0 = Style()
    _style_1 = Style()
    _style_2 = Style()
    _style_3 = Style()

    _register_0 = Register()
    (Register.__init__)(_register_0)
    (_register_0.set_renderfunc)(int, (lambda x, *args, **kwargs: str((x > 0))))
    (_register_0.set_renderfunc)(str, (lambda x, *args, **kwargs: str((x == 'potato'))))
    (_register_0.set_eightbit_call)(int)
    (_register_0.set_rgb_call)(str)
    (Register.__setattr__)(_register_0, '_tmp__0', _style_0)

# Generated at 2022-06-26 04:19:58.961430
# Unit test for constructor of class Register
def test_Register():
    Register()

# Generated at 2022-06-26 04:20:00.861348
# Unit test for constructor of class Register
def test_Register():
    reg = Register()


# Generated at 2022-06-26 04:20:03.738749
# Unit test for constructor of class Register
def test_Register():
    try:
        test_case_0()
        assert True
    except Exception:
        assert False



# Generated at 2022-06-26 04:20:09.165315
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)
    assert reg.renderfuncs
    assert reg.is_muted == False

# Generated at 2022-06-26 04:20:20.072133
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import Bg, Fg, Rs
    from .defaults import bg, fg, rs

    # create a custom register
    class MyRegister(Register):
        pass

    StyTest = MyRegister()

    StyTest.bg_blue = Style(Bg(3))
    StyTest.fg_red = Style(Fg(1))
    StyTest.rs_blink_red_bg_blue = Style(Rs(), Fg(1), Bg(3))

    StyTestDict = StyTest.as_dict()

# Generated at 2022-06-26 04:20:23.699344
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register = Register()

    def renderfunc(*args):
        return "RgbFg({},{},{})".format(*args)

    register.set_rgb_call(RgbFg)

    register.set_renderfunc(RgbFg, renderfunc)

    assert register(0, 10, 10)
    assert register.rgbfg(0, 10, 10) == "RgbFg(0,10,10)"


# Generated at 2022-06-26 04:20:24.740772
# Unit test for constructor of class Register
def test_Register():
    reg_0 = Register()


# Generated at 2022-06-26 04:20:28.523546
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    style_0 = Style()
    style_1 = Style(fg.red)


# Generated at 2022-06-26 04:20:39.764460
# Unit test for constructor of class Register
def test_Register():

    # test case 1
    try:
        register_0 = Register()
    except Exception as e:
        print(f"Testcase 1: {e}")
        return False

    # test case 2
    try:
        register_1 = Register()
    except Exception as e:
        print(f"Testcase 2: {e}")
        return False

    # test case 3
    if len(register_0.renderfuncs) != len(register_1.renderfuncs):
        print("Testcase 3: Both register-object do not have the same initial state.")
        return False

    # test case 4
    if not hasattr(register_0, "mute"):
        print("Testcase 4: register-object does not have the attribute 'mute'.")
        return False

    # test case 5

# Generated at 2022-06-26 04:20:41.729068
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    r.set_rgb_call(RgbFg)
    assert r.rgb_call.__name__ == 'rgb_fg'


# Generated at 2022-06-26 04:20:51.211587
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .styletypes import RgbFg, RgbBg
    from .buildinrenderfuncs import render_rgb_fg, render_rgb_bg

    # Create Register-Object
    r = Register()

    # Add renderfunction via set_renderfunc-methode
    r.set_renderfunc(RgbFg, render_rgb_fg)
    r.set_renderfunc(RgbBg, render_rgb_bg)

    # Set rgb_call to renderfunction for RgbFg
    r.set_rgb_call(RgbFg)

    # Call with rgb-values
    res = r(42, 12, 150)
    expected_res = render_rgb_fg(42, 12, 150)

    assert res == expected_res



# Generated at 2022-06-26 04:21:01.827991
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import unittest
    r = Register()
    nt = r.as_namedtuple()
    # called asattribute
    assert isinstance(nt.test, str)
    r.test = "test"
    nt = r.as_namedtuple()
    assert nt.test == "test"
    assert isinstance(nt.test, str)
    # called asexplicit
    assert isinstance(Register.as_namedtuple(r).test, str)
    r.test = "test"
    assert Register.as_namedtuple(r).test == "test"
    assert isinstance(Register.as_namedtuple(r).test, str)


# Generated at 2022-06-26 04:21:08.187231
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.abc = Style(Sgr(1))
    r.defg = Style(Sgr(2))
    assert r.as_dict() == {"abc": "\x1b[1m", "defg": "\x1b[2m"}



# Generated at 2022-06-26 04:21:12.405109
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.foo = Style()
    r.bar = Style()
    r.foobar = Style()
    namedtup = r.as_namedtuple()
    assert hasattr(namedtup, "foo") is True
    assert hasattr(namedtup, "bar") is True
    assert hasattr(namedtup, "foobar") is True

# Generated at 2022-06-26 04:21:24.478798
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg, bg, ef, rs

    # Export fg register to namedtuple
    nt = fg.as_namedtuple()

    # Named tuple should contain all elements of fg-register
    assert set(nt._asdict().keys()) == set(fg.as_dict().keys())

    # Test if nt is really a namedtuple.
    assert isinstance(nt, tuple)

    # Test if nt is really a namedtuple.
    assert isinstance(nt, NamedTuple)

    # Test if nt is really a namedtuple.
    assert type(nt).__name__ == "StyleRegister"


# Generated at 2022-06-26 04:21:29.297774
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import Sgr

    from .vendor.emoji import emoji

    sgr = Sgr()
    r = Register()

    # You can add a renderfunc, to add custom formatting to your register
    r.set_renderfunc(Sgr, lambda x: f"{emoji.black_heart}")

    # To keep the resulting string short, we set Sgr class
    # to a short representation:
    sgr.set_short("")

    # With the custom renderfunc, we can now turn on the heart
    r.heart = Style(sgr(1))

    # assert
    if r.heart != f"{emoji.black_heart}":
        raise AssertionError("'heart' style object does not contain expected value")



# Generated at 2022-06-26 04:21:33.663071
# Unit test for method mute of class Register
def test_Register_mute():
    r1 = Register()
    r2 = Register()
    r1.mute()
    assert r1.is_muted == True
    assert r2.is_muted == False


# Generated at 2022-06-26 04:21:39.071975
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    r = Register()
    r.a = Style(RgbFg(9, 9, 9))

    assert isinstance(r.as_dict(), dict)
    assert isinstance(r.as_namedtuple(), NamedTuple)
    assert r.as_dict() == {'a': '\x1b[38;2;9;9;9m'}



# Generated at 2022-06-26 04:21:44.976324
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg_0 = Register()

    reg_0.a = Style()
    reg_0.b = Style()

    sty_named_tuple = reg_0.as_namedtuple()

    assert hasattr(sty_named_tuple, "a")
    assert hasattr(sty_named_tuple, "b")

    assert len(sty_named_tuple._fields) == 2



# Generated at 2022-06-26 04:21:46.700484
# Unit test for method unmute of class Register
def test_Register_unmute():
    style_0 = Style()
    style_0.unmute()


# Generated at 2022-06-26 04:21:52.628199
# Unit test for method __call__ of class Register
def test_Register___call__():

    def dummy_renderfunc(x):
        return "\x1b[38;2;{};{};{}m".format(x, x, x)

    r = Register()
    r.set_eightbit_call(int)
    r.set_renderfunc(int, dummy_renderfunc)

    assert str(r(128)) == "\x1b[38;2;128;128;128m"



# Generated at 2022-06-26 04:21:59.161947
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    import pytest
    from sty import fg, bg, ef, rs
    subprocess = pytest.importorskip("subprocess")

    register = fg
    register.blue = Style(fg=240)

    style_tuple = register.as_namedtuple()

    assert style_tuple.blue == '\x1b[38;5;240m'

    # Run os-command that writes to stdout and test, if the styling is working.
    subprocess.call(['echo', style_tuple.blue + 'Hello world!' + rs.all])


# Generated at 2022-06-26 04:22:03.805274
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()

    setattr(reg, "foo", Style())
    assert reg.as_dict() == {"foo": ""}

    setattr(reg, "bar", Style(value="\x1b[1m"))
    assert reg.as_dict() == {"foo": "", "bar": "\x1b[1m"}



# Generated at 2022-06-26 04:22:06.132885
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    assert isinstance(style_0, Style)



# Generated at 2022-06-26 04:22:13.169572
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Create mock object of class Register
    mock_Reg = Register()
    mock_Reg.test = Style()
    test_dict = {"test": Style()}

    # Assert if test_dict = as_dict()
    assert test_dict == mock_Reg.as_dict()
    return


# Generated at 2022-06-26 04:22:17.226295
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class FakeRegister(Register):
        attribute_0 = Style()
        attribute_1 = Style()

    target = FakeRegister()

    assert isinstance(target.as_namedtuple(), NamedTuple) == True

# Generated at 2022-06-26 04:22:21.221345
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbBg
    from .bg import bg

    bg.set_eightbit_call(RgbBg)
    bg.set_renderfunc(RgbBg, lambda *args, **kwargs: args)

    assert bg.eightbit_call(1,2,3) == (8, 1, 2, 3)


# Generated at 2022-06-26 04:22:29.616260
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    style_0 = Style()
    register_0 = Register()
    register_0.style_0 = style_0
    register_0.style_1 = style_0
    def set_eightbit_call(x):
        style_0.value += x

    register_0.set_eightbit_call(set_eightbit_call)


# Generated at 2022-06-26 04:22:36.426811
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class Eightbit(RenderType):
        pass

    class Rgb(RenderType):
        pass

    class OtherRenderType(RenderType):
        pass

    reg = Register()
    reg.set_renderfunc(Eightbit, lambda x : x)
    reg.set_renderfunc(Rgb, lambda r, g, b : (r, g, b))
    reg.set_renderfunc(OtherRenderType, lambda x: x)

    reg.set_eightbit_call(Eightbit)
    reg.set_rgb_call(Rgb)

    assert reg(1) == 1
    assert reg(19, 29, 38) == (19, 29, 38)



# Generated at 2022-06-26 04:22:44.130834
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    test_register = Register()

    test_register.test_fg = Style(RenderType.Fg(9))
    test_register.test_bg = Style(RenderType.Bg(9))

    assert test_register.as_dict() == {"test_fg": "\033[38;5;9m", "test_bg": "\033[48;5;9m"}



# Generated at 2022-06-26 04:22:46.317178
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    style_0 = Style()
    register_0 = Register()
    assert not hasattr(register_0, "attribute_0")
    register_0.attribute_0 = style_0



# Generated at 2022-06-26 04:22:50.270061
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register != None


# Generated at 2022-06-26 04:22:55.236830
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0_expected = Style()
    style_0_actual = Style()
    assert style_0_actual == style_0_expected

    style_1_expected = Style()
    style_1_actual = Style()
    assert style_1_actual == style_1_expected



# Generated at 2022-06-26 04:23:02.535191
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Create a new register object
    r1 = Register()

    # A new style object
    s1 = Style(value="\x1b[0m")

    # Set style object as attribute of register object
    setattr(r1, 'reset', s1)

    # Verify style object is actually an attribute of register object
    assert hasattr(r1, 'reset') is True



# Generated at 2022-06-26 04:23:10.903552
# Unit test for method __new__ of class Style
def test_Style___new__():

    style_0 = Style()
    assert isinstance(style_0, Style)


# Generated at 2022-06-26 04:23:17.830239
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbFg

    myRegister = Register()
    myRegister.renderfuncs = {
        RgbFg: lambda r, g, b: (r, g, b),
    }

    myRegister.set_rgb_call(RgbFg)

    assert myRegister.rgb_call(3, 5, 7) == (3, 5, 7)



# Generated at 2022-06-26 04:23:26.709818
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    my_r = Register()

    my_r.set_renderfunc(RenderType, lambda x: 1)


# Generated at 2022-06-26 04:23:27.914874
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()


# Generated at 2022-06-26 04:23:31.821453
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    R = Register()
    rendertype = RenderType
    func = lambda x: x

    R.set_renderfunc(rendertype, func)

    assert R.renderfuncs.get(rendertype) == func


# Generated at 2022-06-26 04:23:38.834029
# Unit test for constructor of class Style
def test_Style():
    # Built-in function id() returns the “identity” of an object. This is an integer
    # which is guaranteed to be unique and constant for this object during its lifetime.
    # Two objects with non-overlapping lifetimes may have the same id() value.
    Style1 = Style()
    Style2 = Style()
    assert id(Style1) != id(Style2), "Constructor of class Style works"


# Generated at 2022-06-26 04:23:48.907444
# Unit test for constructor of class Register
def test_Register():

    from .renders import EightBit, RgbFg, Sgr

    assert issubclass(Register, object)

    assert hasattr(Register(), "renderfuncs")
    assert hasattr(Register(), "is_muted")
    assert hasattr(Register(), "set_renderfunc")
    assert hasattr(Register(), "set_rgb_call")
    assert hasattr(Register(), "set_eightbit_call")
    assert hasattr(Register(), "mute")
    assert hasattr(Register(), "unmute")
    assert hasattr(Register(), "as_dict")
    assert hasattr(Register(), "as_namedtuple")
    assert hasattr(Register(), "copy")

    reg = Register()

    assert isinstance(reg.renderfuncs, dict)
    assert isinstance(reg.is_muted, bool)

# Generated at 2022-06-26 04:23:56.041413
# Unit test for constructor of class Register
def test_Register():
    reg_0 = Register()
    reg_0.set_eightbit_call(RenderType.SGR)
    reg_0.set_rgb_call(RenderType.SGR)
    reg_0.set_renderfunc(RenderType.SGR, lambda x: "")



# Generated at 2022-06-26 04:24:07.443410
# Unit test for method copy of class Register
def test_Register_copy():

    # Test case 0
    Register_0 = Register()
    Register_1 = Register_0.copy()

    # Test case 1
    Register_2 = Register()
    Register_2.set_renderfunc(RenderType, lambda x: "\u001b[3m")
    Register_3 = Register_2.copy()
    Register_4 = Register_2.copy()
    Register_4.set_renderfunc(RenderType, lambda x: "\u001b[2m")
    Register_5 = Register_2.copy()
    Register_5.mute()
    Register_6 = Register_2.copy()
    Register_6.unmute()
    Register_7 = Register_2.copy()
    Register_7.set_eightbit_call(RenderType)
    Register_8 = Register_2.copy()
    Register

# Generated at 2022-06-26 04:24:18.298014
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import os
    import sys
    # Clear screen
    os.system('cls' if os.name == 'nt' else 'clear')
    # Get path of the file and its parent directory
    root_path = os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
    sys.path.append(root_path)
    import Sty
    # Start test
    print("Test Register.as_dict()")
    Sty.DEFAULT_STYLE_REGISTER = Sty.DEFAULT_STYLE_REGISTER.copy()
    Sty.DEFAULT_STYLE_REGISTER.set_eightbit_call(Sty.SgrFg)
    Sty.DEFAULT_STYLE_REGISTER.set_rgb_call(Sty.RgbFg)

# Generated at 2022-06-26 04:24:26.772367
# Unit test for constructor of class Register
def test_Register():

    register = Register()
    assert isinstance(register, Register)



# Generated at 2022-06-26 04:24:29.508610
# Unit test for method unmute of class Register
def test_Register_unmute():
    style_0 = Style()
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:24:31.836157
# Unit test for method mute of class Register
def test_Register_mute():
    fg = Register()
    assert (hasattr(fg, "is_muted")), "mute test 0 failed!"
    return True



# Generated at 2022-06-26 04:24:37.758955
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    register_0.set_renderfunc(RenderType(0), lambda a, **kwargs: str(a))
    style_0 = Style(RenderType(0), RenderType(0))
    str(style_0) == "\x1b[0m\x1b[0m"


# Generated at 2022-06-26 04:24:40.570451
# Unit test for method copy of class Register
def test_Register_copy():
    style_0 = Register()
    style_1 = style_0.copy()
    assert style_0 is not style_1



# Generated at 2022-06-26 04:24:52.586238
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .defaults import bg, fg


# Generated at 2022-06-26 04:24:54.496777
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    print("Test: Register.__setattr__")

    print("Case 0")
    sty_0 = Register()
    sty_0.attr_0 = Style()
    sty_0.att

# Generated at 2022-06-26 04:25:02.461161
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    The method should modify a non-muted Register object and change its rgb_call
    function.
    """
    from .encoding import Ansi256Encoder
    from .rendertype import Sgr

    register = Register()
    register.set_renderfunc(Sgr, lambda x: "foo")
    register.set_rgb_call(Sgr)
    assert register.rgb_call(10, 20, 30) == "foo"


# Generated at 2022-06-26 04:25:05.437246
# Unit test for method copy of class Register
def test_Register_copy():
    test_0 = Register()
    test_1 = test_0.copy()
    assert test_1 is not test_0


# Generated at 2022-06-26 04:25:09.572030
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    def test_func(value):
        return "test"

    register_0 = Register()
    register_0.set_eightbit_call(RenderType)

    register_0.set_renderfunc(RenderType, test_func)

    assert str(register_0()) == "test"


# Generated at 2022-06-26 04:25:20.608023
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    pass


# Generated at 2022-06-26 04:25:32.188729
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    style_0 = Style()
    reg_0 = Register()
    def test_func_0():
        style_0 = Style()
        return style_0._value
    style_0._value = test_func_0()
    style_0.rules = (('#' + '#' + (((('#' + '#') + '#') + '#') + '#') + (('#' + '#') + '#')),)
    reg_0.is_muted = style_0._value
    setattr(reg_0, ((('#' + '#') + '#') + '#'), style_0)
    reg_0.is_muted = True

# Generated at 2022-06-26 04:25:34.861138
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class T(RenderType): pass
    class U(RenderType): pass
    r = Register()
    r.set_renderfunc(T, lambda x: x)
    r.set_eightbit_call(U)
    r.set_eightbit_call(T)



# Generated at 2022-06-26 04:25:43.616094
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    reg = Register()
    setattr(reg, "some_attribute", "value")
    setattr(reg, "_some_attribute_2", "value")
    reg_dict = reg.as_dict()

    assert "some_attribute" in reg_dict
    assert "some_attribute_2" not in reg_dict
    assert reg_dict["some_attribute"] == "value"



# Generated at 2022-06-26 04:25:44.763587
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.unmute()

# Generated at 2022-06-26 04:25:58.157303
# Unit test for constructor of class Style
def test_Style():
    # Initialization
    style_0 = Style()
    style_1 = Style(*[RenderType()])
    style_2 = Style(*[style_1, Style(*[RenderType(), RenderType()])])

    # Test of isinstance
    assert isinstance(style_0, Style)
    assert isinstance(style_1, Style)
    assert isinstance(style_2, Style)
    # Test of rules
    assert style_0.rules == []
    assert style_1.rules == [RenderType()]
    assert style_2.rules == [style_1, Style(*[RenderType(), RenderType()])]
    # Test of inheritance
    assert isinstance(style_0, str)
    assert isinstance(style_1, str)
    assert isinstance(style_2, str)



# Generated at 2022-06-26 04:26:07.260739
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Test case with SGR (Fixed)
    r = Register()
    r.set_rgb_call(RenderType.SGR)
    assert r.set_rgb_call(RenderType.SGR) == None
    assert r.rgb_call == r.renderfuncs[RenderType.SGR]

    # Test case with RgbFg (Fixed)
    r = Register()
    r.set_rgb_call(RenderType.RgbFg)
    assert r.set_rgb_call(RenderType.RgbFg) == None
    assert r.rgb_call == r.renderfuncs[RenderType.RgbFg]


# Generated at 2022-06-26 04:26:09.832412
# Unit test for constructor of class Register
def test_Register():
    _r = Register()
    assert _r


# Generated at 2022-06-26 04:26:13.394264
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_1 = Style()
    assert isinstance(style_1, Style)
    assert style_1.rules == ()


# Generated at 2022-06-26 04:26:18.206186
# Unit test for method __new__ of class Style
def test_Style___new__():

    style_0 = Style(str="str", value=str)
    style_1 = Style(value=str)
    assert isinstance(style_0, Style)
    assert isinstance(style_1, Style)



# Generated at 2022-06-26 04:26:40.088546
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()


# Generated at 2022-06-26 04:26:41.709250
# Unit test for method __call__ of class Register
def test_Register___call__():
    pass


# Generated at 2022-06-26 04:26:43.515959
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()



# Generated at 2022-06-26 04:26:49.725889
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()

    assert isinstance(register_0, Register)
    assert register_0.is_muted == register_1.is_muted
    assert register_0.eightbit_call == register_1.eightbit_call



# Generated at 2022-06-26 04:27:01.585220
# Unit test for method copy of class Register
def test_Register_copy():
    style_0 = Style()
    style_1 = Style(Sgr(1))
    style_2 = Style(Sgr(2))
    style_3 = Style(style_1, style_2)

    fg_0 = Register()
    fg_0.red = style_0
    fg_0.orange = style_1
    fg_0.green = style_2
    fg_0.blue = style_3

    fg_1 = fg_0.copy()

    assert fg_0 is not fg_1
    assert fg_0.red is not fg_1.red
    assert fg_0.orange is not fg_1.orange
    assert fg_0.green is not fg_1.green
    assert fg_0.blue is not fg_1

# Generated at 2022-06-26 04:27:11.028259
# Unit test for method mute of class Register
def test_Register_mute():

    r = Register()
    r.set_eightbit_call(RgbFg)
    r.set_rgb_call(RgbFg)

    assert r(42) == "\x1b[38;2;0;255;0m"
    assert r(102, 49, 42) == "\x1b[38;2;102;49;42m"

    r.mute()
    assert r(42) == ""
    assert r(102, 49, 42) == ""


# Generated at 2022-06-26 04:27:19.442858
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    color_register = Register()
    color_register.blue = Style()
    color_register.red = Style()

    color_dict = color_register.as_dict()

    assert isinstance(color_dict, dict)
    assert len(color_dict) == 2
    assert color_dict["blue"] == ""
    assert color_dict["red"] == ""

# Generated at 2022-06-26 04:27:24.756534
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Constructor test
    style_0 = Style()

    # Type test
    assert isinstance(style_0, Style)

    # Method test

    # Type test
    assert isinstance(style_0.rules, Iterable)

    # Boundary test
    # Test for an empty style rule.
    style_0 = Style()

    assert str(style_0) == ""

    # Test for one style rule
    style_0 = Style("test")

    assert str(style_0) == "test"

    # Test for two style rules
    style_0 = Style("test", "test")

    assert str(style_0) == "testtest"

    # Test for multiple style rules
    style_0 = Style("test", "test", "test")

    assert str(style_0) == "testtesttest"


# Unit

# Generated at 2022-06-26 04:27:35.304290
# Unit test for method unmute of class Register
def test_Register_unmute():
    from .rendertype import RgbFg, RgbBg, Sgr
    style_0 = Style(RgbFg(10, 20, 30))
    style_1 = Style(RgbBg(10, 20, 30))
    style_2 = Style(Sgr(0))
    fg = Register()
    fg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    fg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    fg.set_renderfunc(Sgr, lambda i: f"\x1b[{i}m")

# Generated at 2022-06-26 04:27:43.644984
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class TestRegister(Register):
        def __init__(self):
            super().__init__()
            self.renderfuncs.update({"Rend1": lambda x: str(x)})
            self.set_eightbit_call(Rend1)

    register_0: TestRegister = TestRegister()
    assert register_0(42) == "42"



# Generated at 2022-06-26 04:28:15.297753
# Unit test for constructor of class Register
def test_Register():
    test_case_0()

# Generated at 2022-06-26 04:28:20.726626
# Unit test for method mute of class Register
def test_Register_mute():
    style_register = Register()
    style_register.mute()
    assert style_register.is_muted == True



# Generated at 2022-06-26 04:28:24.272326
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    assert isinstance(style_0, Style)
    assert isinstance(str(style_0), str)


# Generated at 2022-06-26 04:28:29.866166
# Unit test for method copy of class Register
def test_Register_copy():
    # Create a new instance of the register
    register = Register()

    # Create a new style attribute for the new register and mute the register
    register.style_0 = Style()
    register.mute()

    # Create a copy of the register
    register_copy = register.copy()

    # Test if the register attribute 'style_0' is equal for the original and the copy
    assert register.style_0 == register_copy.style_0

    # Test if the registers are muted
    assert register.is_muted == True
    assert register_copy.is_muted == True


# Generated at 2022-06-26 04:28:36.141132
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    style_0 = Style()
    style_1 = Style()
    style_2 = Style()

    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda *a: a)
    register_0.pink = style_0
    register_0.blue = style_1
    register_0.green = style_2

    m_0 = register_0.as_namedtuple()

    assert m_0.pink == style_0
    assert m_0.blue == style_1
    assert m_0.green == style_2


# Generated at 2022-06-26 04:28:38.948009
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    r.set_rgb_call(r.rgb_call)


# Generated at 2022-06-26 04:28:49.495676
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    style_0 = Style()
    style_1 = Style()
    style_2 = Style()
    style_3 = Style()
    style_4 = Style()
    style_5 = Style()
    style_6 = Style()
    style_7 = Style()
    style_8 = Style()
    style_9 = Style()
    style_10 = Style()
    style_11 = Style()
    style_12 = Style()
    style_13 = Style()
    style_14 = Style()
    style_15 = Style()
    style_16 = Style()
    style_17 = Style()
    style_18 = Style()
    style_19 = Style()
    style_20 = Style()
    style_21 = Style()
    style_22 = Style()
    style_23 = Style()
    style_24 = Style()

# Generated at 2022-06-26 04:28:52.969299
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()

    assert register_0 != register_1
    assert register_0.is_muted == register_1.is_muted
    assert register_0.renderfuncs == register_1.renderfuncs
    assert register_0.rgb_call == register_1.rgb_call
    assert register_0.eightbit_call == register_1.eightbit_call
    assert isinstance(register_1, Register)
    assert isinstance(register_1, object)
    assert "Register" == register_1.__class__.__name__



# Generated at 2022-06-26 04:28:58.590619
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertypes import Sgr

    r = Register()
    r.set_renderfunc(Sgr, lambda *args: "SGR: " + (";".join([str(x) for x in args])))

    r.set_eightbit_call(Sgr)

    assert r.eightbit_call(1, 2, 3) == "SGR: 1;2;3"
    assert r.eightbit_call(7, 8)    == "SGR: 7;8"


# Generated at 2022-06-26 04:28:59.374727
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert type(reg) is Register
