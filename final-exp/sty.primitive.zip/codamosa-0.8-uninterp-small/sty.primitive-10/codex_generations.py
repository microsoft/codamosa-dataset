

# Generated at 2022-06-26 04:19:30.091625
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call("rgb_fg")
    assert register_0.rgb_call == "rgb_fg"


# Generated at 2022-06-26 04:19:33.763769
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    func = lambda r,g,b: "NEWRGBFUNC"
    r.set_rgb_call(preset.rgb, func)
    assert r.rgb_call(1, 2, 3) == "NEWRGBFUNC"


# Generated at 2022-06-26 04:19:43.369746
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """The Register.set_rgb_call method has to be tested."""
    print("[*] Unit test for Register.set_rgb_call")
    register_0 = Register()
    def func_0(a_0, b_0, c_0):
        return (a_0, b_0, c_0)
    class RenderType_0:
        ARGS = None
    register_0.set_rgb_call(RenderType_0, func_0)


# Generated at 2022-06-26 04:19:47.316285
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from packaging.version import Version
    from sty import fg
    if Version(sty.__version__) >= Version("0.4.0"):
        register_0 = Register()
        register_0.set_rgb_call(fg.rgb)
        assert fg.rgb == register_0.rgb_call


# Generated at 2022-06-26 04:19:55.688076
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import ColorRgbFg, ColorRgbBg

    register_1 = Register()

    register_1.set_eightbit_call(ColorRgbFg)
    register_1.set_rgb_call(ColorRgbFg)

    res_1 = register_1(240, 120, 1)
    res_2 = register_1(5)

    assert res_1 == "\x1b[38;2;240;120;1m"
    assert res_2 == "\x1b[38;5;5m"


# Generated at 2022-06-26 04:20:01.898495
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Test set_rgb_call with an invalid render type
    register_1 = Register()
    with TestRunner.create(False):
        TestRunner.assert_raises(AttributeError,
                                 register_1.set_rgb_call, 'FooType')



# Generated at 2022-06-26 04:20:05.473995
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import rendertype
    rendertype_0 = rendertype.RenderType(None)
    register_0 = Register()
    register_0.set_renderfunc(rendertype_0, lambda: None)
    register_0.set_rgb_call(rendertype_0)


# Generated at 2022-06-26 04:20:17.377258
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Test 0: Verify that method set_rgb_call works if class is empty.
    register_0 = Register()

    register_0.set_rgb_call(RgbFg)
    assert register_0.rgb_call == register_0.renderfuncs[RgbFg]

    register_0.set_rgb_call(RgbBg)
    assert register_0.rgb_call == register_0.renderfuncs[RgbBg]

    # Test 1: Verify that method set_rgb_call works if class is not empty.
    register_1 = Register()

    register_1.set_rgb_call(RgbFg)
    assert register_1.rgb_call == register_1.renderfuncs[RgbFg]

    register_1.set_rgb_call

# Generated at 2022-06-26 04:20:27.624949
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Sample class
    class RenderType0():
        args = ()
        kwargs = {}
        def to_ansi(self, *args, **kwargs):
            return "rendertype0"

    # Sample function
    def func0(rendertype0):
        return "test"

    # Instantiate register
    register_0 = Register()

    # Register callable for sample rendertype
    register_0.set_renderfunc(RenderType0, func0)

    # Execute tested method
    register_0.set_rgb_call(RenderType0)

    # Assert that it works as expected
    assert register_0(10, 20, 30) == "test"



# Generated at 2022-06-26 04:20:35.041775
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()

    def f1(r, g, b):
        return "Test"

    register_0.set_renderfunc(RgbFg, f1)
    register_0.set_rgb_call(RgbFg)
    result = register_0(1, 2, 3)
    assert result == "Test"


# Generated at 2022-06-26 04:20:45.501079
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(type(1))
    assert register_0.rgb_call(0, 1, 2) == (0, 1, 2)


# Generated at 2022-06-26 04:20:49.339894
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_1 = Register()
    rendertype_0 = RenderType()
    func_0 = lambda r, g, b: None
    assert callable(func_0)
    register_1.set_rgb_call(rendertype_0, func_0)
    assert register_1.rgb_call(1, 1, 1) is None


# Generated at 2022-06-26 04:20:58.671235
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg
    register = Register()
    assert register.rgb_call(10,20,30) == (10,20,30)
    register.set_rgb_call(RgbBg)
    assert register.rgb_call(10,20,30) == '\x1b[48;2;10;20;30m'


# Generated at 2022-06-26 04:21:00.889080
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    rendertype_0 = type(None)
    func_0 = lambda: None
    register_0.set_rgb_call(rendertype_0)



# Generated at 2022-06-26 04:21:05.700995
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    rendertype_0 = RenderType.RgbBg
    register_0.set_rgb_call(rendertype_0)


# Generated at 2022-06-26 04:21:10.327799
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call((lambda r, g, b: (r, g, b)))


# Generated at 2022-06-26 04:21:16.067567
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import pytest
    from helperlib import sgr

    # Create Register-Object.
    register_0 = Register()

    # Create new renderfunc-mapping.
    renderfuncs = {
        sgr.RgbFg: lambda r, g, b: f"{r}{g}{b}",
        sgr.RgbBg: lambda r, g, b: f"{r}{g}{b}",
        sgr.RgbFg256: lambda r, g, b: f"{r}{g}{b}",
        sgr.RgbBg256: lambda r, g, b: f"{r}{g}{b}",
    }

    RenderType = sgr.RgbFg256

    # Set renderfunc_map in register_0.
    register_0.renderfuncs = renderfuncs



# Generated at 2022-06-26 04:21:22.094115
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .sgr import RgbBg

    register_0 = Register()
    register_0.set_rgb_call(RgbBg)
    assert register_0.rgb_call(255, 0, 0) == "\u001b[48;2;255;0;0m"



# Generated at 2022-06-26 04:21:29.742837
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    class TestRenderType(RenderType):
        name = "TestRenderType"
        args = []

    def test_func(*args):
        pass

    register_0.set_renderfunc(TestRenderType, test_func)
    register_0.set_rgb_call(TestRenderType)
    assert(register_0.rgb_call == test_func)


# Generated at 2022-06-26 04:21:33.915259
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Case: Register is a instance of class Register.
    register_0 = Register()
    # Case: Return None
    assert register_0.set_rgb_call(RenderType) == "None"



# Generated at 2022-06-26 04:21:41.175310
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    RenderType_0 = RenderType
    register_0.set_rgb_call(RenderType_0)


# Generated at 2022-06-26 04:21:52.658370
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg:

        def __init__(self, r: int, g: int, b: int):
            self.r = r
            self.g = g
            self.b = b

        def __str__(self):
            return f"\x1b[38;2;{self.r};{self.g};{self.b}m"

    class RgbBg:

        def __init__(self, r: int, g: int, b: int):
            self.r = r
            self.g = g
            self.b = b

        def __str__(self):
            return f"\x1b[48;2;{self.r};{self.g};{self.b}m"

    # Define 'render functions':

# Generated at 2022-06-26 04:21:58.275074
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import Rgb24bitFg, Rgb24bitBg, Rgb8bitFg, Rgb8bitBg, TruecolorRgbFg, TruecolorRgbBg
    
    def call_render_function(x):
        return '\x1b[38;2;' + str(x[0]) + ';' + str(x[1]) + ';' + str(x[2]) + 'm'

    register_0 = Register()
    register_0.set_rgb_call(Rgb24bitFg)
    register_0.rgb_call = call_render_function   
    assert (register_0.rgb_call((1, 2, 3)) == '\x1b[38;2;1;2;3m')
    register_0.set_rgb

# Generated at 2022-06-26 04:22:07.281542
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg
    from .ansi import render_rgb_fg

    # Test without given rendertype
    test_register_0 = Register()
    try:
        test_register_0.set_rgb_call()
        assert False
    except TypeError:
        assert True

    # Test with given rendertype
    test_register_1 = Register()
    test_register_1.set_rgb_call(RgbFg)
    assert test_register_1.rgb_call(123, 123, 123) == render_rgb_fg(123, 123, 123)


# Generated at 2022-06-26 04:22:21.756093
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from .rendertype import RgbBg, RgbFg

    register_0 = Register()
    register_0.set_renderfunc(RgbFg, lambda r, g, b: "RgbFg")
    register_0.set_renderfunc(RgbBg, lambda r, g, b: "RgbBg")

    register_0.set_rgb_call(RgbFg)

    if register_0.rgb_call != register_0.renderfuncs[RgbFg]:
        raise AssertionError()

    if register_0.rgb_call("r", "g", "b") != "RgbFg":
        raise AssertionError()

    register_0.set_rgb_call(RgbBg)


# Generated at 2022-06-26 04:22:31.496698
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # test muting
    fg = Register()
    fg.set_rgb_call(RgbFg)
    fg("green")
    assert fg("green") == "\x1b[38;2;0;255;0m"
    fg.mute()
    assert fg("green") == ""
    fg.unmute()
    assert fg("green") == "\x1b[38;2;0;255;0m"
    fg.mute()
    assert fg("green") == ""


# # Unit test for method set_eightbit_call of class Register

# Generated at 2022-06-26 04:22:34.633524
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    register_0 = Register()
    register_0.set_rgb_call(RgbBg)


# Generated at 2022-06-26 04:22:38.216094
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg

    register = Register()

    def renderfunc_0(r, g, b):
        # Testcase 0
        return (1, 2, 3)

    register.set_renderfunc(RgbFg, renderfunc_0)
    register.set_rgb_call(RgbFg)

    assert register(1, 2, 3) == (1, 2, 3)



# Generated at 2022-06-26 04:22:48.014722
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg
    from . import sgr

    register_1 = Register()
    register_1.set_rgb_call(RgbFg)
    assert register_1.rgb_call(10, 20, 30) == "\x1b[38;2;10;20;30m"

    register_2 = Register()
    register_2.set_rgb_call(RgbBg)
    assert register_2.rgb_call(10, 20, 30) == "\x1b[48;2;10;20;30m"

    register_3 = Register()
    register_3.set_rgb_call(sgr.Sgr)

# Generated at 2022-06-26 04:22:55.967367
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Setup
    register_0 = Register()
    rendertype_0 = RgbFg
    def func(arg0: int, arg1: int, arg2: int) -> str:
        return f"{arg0},{arg1},{arg2}"

    # Call method
    register_0.set_rgb_call(rendertype_0, func)

    # Check results
    assert (register_0.rgb_call(255, 48, 3) == "255,48,3")

# Generated at 2022-06-26 04:23:19.433889
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertype import RgbBg, RgbFg, Sgr

    fg = Register()

    fg.set_renderfunc(Sgr, lambda *args: f"SGR({args})")
    fg.set_renderfunc(RgbFg, lambda *args: f"RGBFG({args})")

    fg.set_eightbit_call(RgbFg)

    assert fg(12) == "RGBFG(12)"


# Generated at 2022-06-26 04:23:23.058957
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    register_1 = Register()

    assert register_0 != register_1


# Generated at 2022-06-26 04:23:26.997942
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Case 0:
    # expectation:
    #   |> {}
    register_0 = Register()
    assert register_0.as_dict() == {}
    return

# Generated at 2022-06-26 04:23:34.438509
# Unit test for constructor of class Style
def test_Style():
    Sty = Style("arg1", value="value1")
    assert(Sty == "value1")
    assert(Sty.value == "value1")
    assert(Sty.rules == ("arg1",))
    Sty = Style("arg1", "arg2", value="value1")
    assert(Sty == "value1")
    assert(Sty.value == "value1")
    assert(Sty.rules == ("arg1", "arg2"))

# Generated at 2022-06-26 04:23:37.280201
# Unit test for constructor of class Style
def test_Style():
    assert isinstance(Style('RgbFg(1,10,100)', 'Sgr(1)'), Style), 'Style constructor not working.'


# Generated at 2022-06-26 04:23:42.749169
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.mute()
    register_0.colorname = 'red'
    test_case_0()
    fr = {}
    fg = Register()
    fg.mute()
    try:
        fg.red = Style()
    except:
        fr['success'] = False
    else:
        fr['success'] = True
    return fr


# Generated at 2022-06-26 04:23:48.937978
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class DummyRenderType(RenderType):
        pass

    # create dummy render method
    def renderfunc_dummy(rt: RenderType) -> str:
        return "dummy"

    register_0 = Register()

    # Try to add a renderfunc for an unsupported render type
    try:
        register_0.set_renderfunc(DummyRenderType, renderfunc_dummy)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-26 04:23:51.724797
# Unit test for method mute of class Register
def test_Register_mute():

    # Initialize Register class object
    register = Register()

    # Set attribute 'green'
    register.green = Style(value="\x1b[32m")

    # Call reset method
    register.mute()

    # Test whether setting an attribute
    # still returns expected result
    # assert register.green == ""



# Generated at 2022-06-26 04:23:57.517334
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_1 = Register()
    register_1.a = Style(RenderType)
    register_1.b = Style(RenderType)
    register_1.c = Style(RenderType)
    dict_1 = {'a': '', 'b': '', 'c': ''}
    assert register_1.as_dict() == dict_1



# Generated at 2022-06-26 04:24:00.848570
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    assert(register_0 == register_1)



# Generated at 2022-06-26 04:24:19.289960
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg

    r = Register()
    r.set_rgb_call(RgbBg)
    assert r.rgb_call.__name__ == "rgb_bg"



# Generated at 2022-06-26 04:24:25.791263
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    style = Style(fg.rgb(0,0,0), bg.rgb(255,255,255), sgr.bold)
    register_0.bold = style
    register_0.bg_red = Style(bg.red, sgr.italic)
    assert register_0("bold") == style
    assert register_0("bg_red") == register_0.bg_red


# Generated at 2022-06-26 04:24:32.150070
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    for attr_name in dir(register_0):
        val = getattr(register_0, attr_name)
        if isinstance(val, Style):
            val = Style(*val.rules, value="modified")
            setattr(register_0, attr_name, val)

    register_0.mute()

    for attr_name in dir(register_0):
        val = getattr(register_0, attr_name)
        if isinstance(val, Style):
            assert val.value == ""


# Generated at 2022-06-26 04:24:33.287477
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0 is not None

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:24:47.159770
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_0.set_renderfunc(
        RenderType.EIGHTBIT,
        lambda x: f"\x1b[38;5;{x}m",
    )
    register_0.set_renderfunc(
        RenderType.RGB,
        lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m",
    )
    register_0.set_eightbit_call(RenderType.EIGHTBIT)
    register_0.set_rgb_call(RenderType.RGB)
    register_0.blue = Style(RenderType.EIGHTBIT(4))
    register_0.gray = Style(RenderType.RGB(0.5, 0.5, 0.5))
    register_0_copy_1 = register_

# Generated at 2022-06-26 04:24:54.774653
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    register_0.color_0 = "style_00"
    register_0.color_1 = "style_01"
    register_0.color_2 = "style_02"
    register_0.color_3 = "style_03"
    expected_dict = {"color_0": "style_00", "color_1": "style_01", "color_2": "style_02", "color_3": "style_03"}
    actual_dict = register_0.as_dict()
    assert actual_dict == expected_dict


# Generated at 2022-06-26 04:25:02.114566
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Test case for single 8bit value as argument.
    register_0 = Register()
    expected = ""
    actual = register_0('')
    assert actual == expected
    assert isinstance(actual, str)
    # Test case for single RGB value as argument.
    register_1 = Register()
    expected = ""
    actual = register_1('')
    assert actual == expected
    assert isinstance(actual, str)


# Generated at 2022-06-26 04:25:03.289962
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()


# Generated at 2022-06-26 04:25:08.373850
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    register_0 = Register()

    def render(code):
        return "foo"

    register_0.set_renderfunc(RenderType, render)
    expected = render
    actual = register_0.renderfuncs[RenderType]

    assert actual == expected, f"Excepted: {expected}, Actual: {actual}"


# Generated at 2022-06-26 04:25:12.664880
# Unit test for constructor of class Style
def test_Style():
    style = Style(fg=10, sgr=44)
    assert isinstance(style, Style)
    assert str(style) == "\x1b[38;5;10m\x1b[44m"

# Unit test if Style-type is also of type str:

# Generated at 2022-06-26 04:25:45.995927
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()



# Generated at 2022-06-26 04:25:57.536678
# Unit test for method copy of class Register
def test_Register_copy():
    register_1 = Register()
    register_0 = register_1.copy()
    register_0.rs = Style(value = "\x1b[0m")
    assert register_1.rs == "\x1b[0m"
    assert register_0.rs == "\x1b[0m"
    #assert not isinstance(register_0.rs, Style)
    assert register_0.rs != "\x1b[m"
    assert not isinstance(register_0.rs, str)

if __name__ == "__main__":
    test_case_0()  # Registers created
    test_Register_copy()

# Generated at 2022-06-26 04:26:02.368778
# Unit test for method unmute of class Register
def test_Register_unmute():

    '''
    Sometimes it is useful to disable the formatting for a register-object. You can
    do so by invoking this method.
    '''

    register_0 = Register()

    register_0.unmute()

    assert True

# Generated at 2022-06-26 04:26:07.468394
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    # Case '1':
    # No output

    # Case '2':
    # No output

    # Case '3':
    # No output

    # Case '4':
    # No output



# Generated at 2022-06-26 04:26:10.178439
# Unit test for constructor of class Style
def test_Style():
    fg = Register()
    style = Style(fg)


# Generated at 2022-06-26 04:26:15.590097
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.__call__(42)
    register_0.__call__(42)
    register_0.__call__(10, 42, 255)


# Generated at 2022-06-26 04:26:18.051571
# Unit test for constructor of class Register
def test_Register():
    test_case_0()

if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-26 04:26:26.403733
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbBg, RgbFg

    register = Register()
    register.set_renderfunc(RgbFg, lambda r, g, b: f"RgbFg({r},{g},{b})")
    register.set_renderfunc(RgbBg, lambda r, g, b: f"RgbBg({r},{g},{b})")

    register.set_rgb_call(RgbFg)
    register.set_eightbit_call(RgbBg)

    assert register(255, 42, 0) == "RgbFg(255,42,0)"
    assert register(102) == "RgbBg(102,None,None)"


# Generated at 2022-06-26 04:26:29.540657
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Test case #0
    register_0 = Register()
    StyleRegister = namedtuple('StyleRegister', ['_', '__', '___', '____', '_____', 'd', 'e', 'f', 'g'])
    StyleRegister_test = register_0.as_namedtuple()
    assert (StyleRegister_test == StyleRegister('', '', '', '', '', '', '', '', ''))


# Generated at 2022-06-26 04:26:38.353744
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType.RgbFg)
    register_1 = register_0.copy()
    assert register_0.eightbit_call == register_1.eightbit_call
    register_0.set_eightbit_call(RenderType.Sgr)
    assert register_0.eightbit_call != register_1.eightbit_call

# Generated at 2022-06-26 04:27:44.038955
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:27:51.382974
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # Arrange
    rendertype_0 = RenderType
    func_0 = lambda: None
    register_0 = Register()
    # Act
    register_0.set_renderfunc(rendertype_0, func_0)
    # Assert
    assert register_0.renderfuncs[rendertype_0] == func_0



# Generated at 2022-06-26 04:27:55.124157
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()

    # Function for set_renderfunc test:
    def func(param0: str, *_) -> str:
        return param0

    # Add string and function to register.
    register_0.set_renderfunc(str, func)

    # Invoke set_renderfunc by one of the register's attributes.
    register_0.red.rules[0]("test")


test_Register_set_renderfunc()

# Generated at 2022-06-26 04:28:05.026623
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # 1.
    rendertype = RenderType
    func = lambda *args: args
    r0 = Register()
    r0.set_renderfunc(rendertype, func)
    assert r0.renderfuncs[rendertype] == func

    # 2.
    rendertype = RenderType
    func = lambda *args: args
    r0 = Register()
    r0.set_renderfunc(rendertype, func)
    assert r0.renderfuncs[rendertype] == func


# Unit tests for method mute of class Register.

# Generated at 2022-06-26 04:28:10.682447
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg, Sgr
    register_0 = Register()
    register_0.set_eightbit_call(RgbFg)
    assert RgbFg == register_0.eightbit_call


# Generated at 2022-06-26 04:28:23.838554
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    def test_case_1():

        register_1 = Register()
        register_1.green = Style(RgbFg(100, 150, 200))

        len(register_1.as_dict()) == 1

        register_1_dict = register_1.as_dict()

        assert "green" in register_1_dict.keys()
        assert register_1_dict["green"] == Style(RgbFg(100, 150, 200))

        assert len(register_1_dict.keys()) == 1

    def test_case_2():

        register_2 = Register()
        register_2.green = Style(RgbFg(100, 150, 200))
        register_2.red = Style(RgbFg(50, 100, 250))

        len(register_2.as_dict()) == 2

        register_

# Generated at 2022-06-26 04:28:28.979044
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_1 = Register()
    rendertype_1 = RenderType

    def func_1(x: int) -> str:
        return str(1)

    register_1.set_eightbit_call(rendertype_1)
    register_2 = Register()
    rendertype_2 = RenderType
    register_2.set_renderfunc(rendertype_2, func_1)
    register_2.set_eightbit_call(rendertype_2)


# Generated at 2022-06-26 04:28:36.215416
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Create a new register-object
    register_1 = Register()

    # Define a new style.
    register_1.blue = Style(RgbFg(0, 0, 255))

    # Check that attribute 'blue' is a Style instance
    assert(isinstance(register_1.blue, Style))

    # Check that attribute 'blue' is a str instance
    assert(isinstance(register_1.blue, str))

    # Check that attribute 'blue' is string equal to '\x1b[38;2;0;0;255m'
    assert(str(register_1.blue) == "\x1b[38;2;0;0;255m")



# Generated at 2022-06-26 04:28:38.257194
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    register.as_namedtuple()


# Generated at 2022-06-26 04:28:48.523220
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    old_register_0_dict = {"red": "\033[0;31m", "light_red": "\033[1;31m"}
    register_0.red = "\033[0;31m"
    register_0.light_red = "\033[1;31m"
    try:
        assert old_register_0_dict == register_0.as_dict()
    except AssertionError:
        raise AssertionError(f"Expected: {old_register_0_dict}\nActual  : {register_0.as_dict()}")
    del register_0.red
    del register_0.light_red
