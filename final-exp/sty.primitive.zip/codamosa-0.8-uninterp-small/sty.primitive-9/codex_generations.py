

# Generated at 2022-06-26 04:19:27.525864
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    test_register = Register()
    test_register.set_eightbit_call()



if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:19:37.929557
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class RenderTypeA(RenderType):
        def __init__(self, *args, **kwargs):
            super().__init__("A", *args, **kwargs)

    class RenderTypeB(RenderType):
        def __init__(self, *args, **kwargs):
            super().__init__("B", *args, **kwargs)

    def render_func(x: int) -> str:
        s = "A" * x
        return s

    registry = Register()
    registry.set_renderfunc(RenderTypeA, render_func)
    registry.set_eightbit_call(RenderTypeA)

    assert registry(3) == "AAA"
    assert registry.eightbit_call == render_func

    registry.set_eightbit_call(RenderTypeB)

    assert registry(3) == ""



# Generated at 2022-06-26 04:19:46.417182
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbFg

    class MyRegister(Register):
        pass

    my_register = MyRegister()

    assert hasattr(my_register, "set_eightbit_call")
    assert callable(my_register.set_eightbit_call)

    assert hasattr(my_register, "eightbit_call")
    assert callable(my_register.eightbit_call)

    my_register.set_eightbit_call(RgbFg)

    assert "RgbFg" in str(my_register.eightbit_call)



# Generated at 2022-06-26 04:19:56.739389
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Mocked rendertypes used in this unit test
    class r1(RenderType):
        @staticmethod
        def render_func(x: int) -> str:
            return "render_func_r1(x)"

    class r2(RenderType):
        @staticmethod
        def render_func(x: int) -> str:
            return "render_func_r2(x)"

    # Create register for unit test
    register = Register()

    # Test that render-function is attached to correct rendertype
    register.set_renderfunc(r1, r1.render_func)
    register.set_renderfunc(r2, r2.render_func)

    # Test that rendertype r1 is called if r1 is set as rendertype
    register.set_eightbit_call(r1)
    assert register(42)

# Generated at 2022-06-26 04:20:07.514989
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import Sgr, RgbFg

    # Create Test-Register
    reg = Register()

    # Check that the default register-call works
    assert reg(42) == "\x1b[38;5;42m"

    # Set new renderfunc for RgbFg
    reg.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # Check that new renderfunc works if called directly
    assert reg.rgb_call(0, 5, 10) == "\x1b[38;2;0;5;10m"

    # Set new renderfunc for Sgr
    reg.set_renderfunc(Sgr, lambda _: "")

    # Set new rgb-call
    reg.set_r

# Generated at 2022-06-26 04:20:15.121860
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg

    style_0 = Style()

    reg = Register()
    reg.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    assert reg.set_rgb_call(RgbFg) == TypeError
    assert reg.set_rgb_call(RgbBg) == None

# Generated at 2022-06-26 04:20:24.133661
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class TestRenderType(RenderType):
        def __init__(self, value_0: int) -> None:
            self.args = (value_0,)
            self.value = value_0

    def render_func(value: int) -> str:
        return str(value)

    test_register = Register()

    test_register.set_renderfunc(TestRenderType, render_func)

    test_register.set_eightbit_call(TestRenderType)

    # Test if renderfunc was used.
    assert test_register(0) == "0"
    assert test_register(42) == "42"

    assert test_register("testattr") == ""



# Generated at 2022-06-26 04:20:37.292260
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Create register
    r1 = Register()

    # Define dummy functions
    def f1(r, g, b): return "rgb_" + str(r) + "_" + str(g) + "_" + str(b)

    def f2(r, g, b): return "rgb_" + str(r) + "_" + str(g) + "_" + str(b)

    # Define dummy rendertype classes
    class Rt1(RenderType):
        pass

    class Rt2(RenderType):
        pass

    # Assign function to rendertypes
    r1.set_renderfunc(Rt1, f1)
    r1.set_renderfunc(Rt2, f2)

    # Set renderfunc for RGB-calls

# Generated at 2022-06-26 04:20:42.769751
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    r1 = Register()
    r1.rgb_call = None

    def test_func(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    r1.set_rgb_call(test_func)

    result = r1.rgb_call(1, 2, 3)

    assert result == "\x1b[38;2;;;m"



# Generated at 2022-06-26 04:20:47.686785
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    fg.set_rgb_call(RgbBg(255, 0, 0))
    assert fg.rgb_call == fg.renderfuncs[RgbBg]
    """


# Generated at 2022-06-26 04:21:02.198089
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    style_1 = Style(RgbFg(255, 255, 255))
    style_2 = Style(RgbBg(255, 255, 255))

    rg = Register()
    rg.set_renderfunc(RgbFg, lambda r, g, b: f"F({r}, {g}, {b})")
    rg.set_renderfunc(RgbBg, lambda r, g, b: f"B({r}, {g}, {b})")

    rg.set_eightbit_call(RgbBg)

    rg.white = style_1
    rg.black = style_2

    assert str(rg.white) == "F(255, 255, 255)"
    assert str(rg.black) == "B(255, 255, 255)"

# Generated at 2022-06-26 04:21:10.321882
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRegister(Register):
        pass

    tr = TestRegister()
    tr.set_eightbit_call(RenderType)

    assert isinstance(tr, TestRegister)
    assert not isinstance(tr, Register)
    assert isinstance(tr.eightbit_call, Callable)



# Generated at 2022-06-26 04:21:14.746719
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Create register-object
    reg0 = Register()

    # Create render-type
    from .rendertype import RgbBg as RenderType

    # Assign renderfunc to rendertype
    renderfunc = lambda r, g, b: ""
    reg0.set_renderfunc(RenderType, renderfunc)

    # Set rendertype to be used for rgb-calls
    reg0.set_rgb_call(RenderType)

    # Make some calls
    assert reg0(1, 2, 3) == ""
    assert reg0(3, 4, 5) == ""



# Generated at 2022-06-26 04:21:25.900646
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Testcase 1
    style_0 = register_0 = Register()
    style_0.set_rgb_call(rendertype_0)
    style_0()
    # Testcase 2
    style_0 = register_0 = Register()
    style_0.set_rgb_call(rendertype_0)
    style_0(args_0)
    # Testcase 3
    style_0 = register_0 = Register()
    style_0.set_rgb_call(rendertype_0)
    style_0(kwargs_0)
    # Testcase 4
    style_0 = register_0 = Register()
    style_0.set_rgb_call(rendertype_0)
    style_0()
    # Testcase 5
    style_0 = register_0 = Register()
    style_0

# Generated at 2022-06-26 04:21:33.238728
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Test rgb_call with renderfunc from instance
    from sty import fg
    from sty.rendertype import RgbFg

    def test_renderfunc(red: int, green: int, blue: int) -> str:
        return f"expected {red}, {green}, {blue}"

    expected = "expected 15, 42, 255"

    fg.set_renderfunc(RgbFg, test_renderfunc)
    fg.set_rgb_call(RgbFg)

    assert fg(15, 42, 255) == expected



# Generated at 2022-06-26 04:21:44.342403
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    registered_rendertypes = [RenderType]
    rendertype_0 = RgbFg
    rendertype_1 = RgbBg
    rendertype_2 = RgbBold
    rendertype_3 = RgbUnderline
    rendertype_4 = RgbCrossedOut

    renderfuncs_0 = {rendertype_1: lambda r, g, b: (r, g, b)}
    renderfuncs_1 = {
        rendertype_1: lambda r, g, b: (r, g, b),
        rendertype_2: lambda r, g, b: (r, g, b),
    }

    register_0 = Register()
    register_0.renderfuncs = renderfuncs_0


# Generated at 2022-06-26 04:21:54.580487
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Create class with init
    reg = Register()
    # Test of class Register that has not been initialized
    assert reg.renderfuncs == {}
    assert reg.is_muted == False
    # Test of lambda()
    assert reg.eightbit_call(0,0,0) == (0,0,0)
    assert reg.rgb_call(0,0,0) == (0,0,0)
    # Test of set renderfunc for class rendertype
    rt = RenderType(0,0,0)
    func = lambda: 0
    reg.set_renderfunc(RenderType, func)
    assert 'RenderType' in reg.renderfuncs
    assert reg.renderfuncs['RenderType'] == func
    # Test of set_eightbit_call()

# Generated at 2022-06-26 04:22:02.266516
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Setup
    fg = Register()
    fg.set_renderfunc(RgbFg, lambda x: "rgb_fg")

    # Test
    fg.set_eightbit_call(RgbFg)
    assert fg.eightbit_call(42) == "rgb_fg"


# Generated at 2022-06-26 04:22:06.468335
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertypes import Sgr

    rg = Register()
    rg.set_renderfunc(Sgr, lambda x: '\x1b[{}m'.format(x))

    assert isinstance(rg.set_rgb_call, Callable)


# Generated at 2022-06-26 04:22:14.153528
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    RgbFg = RenderType("RgbFg")
    Sgr = RenderType("Sgr")

    # Build test-register and add two render-functions for RgbFg and Sgr
    r = Register()
    r.set_renderfunc(RgbFg, lambda r, g, b: "a")
    r.set_renderfunc(Sgr, lambda r: "b")
    r.set_rgb_call(RgbFg) # We are only interested in the RgbFg-render-func

    # Call register object with RGB-colors
    assert r(12,34,56) == 'a'



# Generated at 2022-06-26 04:22:31.495709
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    renderfuncs = {type(RenderType): lambda *x: ""}

    register_object = Register()
    register_object.renderfuncs = renderfuncs


# Generated at 2022-06-26 04:22:34.987732
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class TempRenderType(RenderType):
        pass

    # Test with 8bit call.
    register = Register()
    register.set_rgb_call(TempRenderType)


# Generated at 2022-06-26 04:22:38.998041
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r0 = Register()
    RgbFg = RenderType(code=38, prefix=2)
    func = lambda r, g, b: f"\033[38;2;{r};{g};{b}m"
    r0.set_renderfunc(RgbFg, func)
    r0.set_rgb_call(RgbFg)
    # Test that correct funciton is called
    assert r0.rgb_call(10, 20, 30) == "\033[38;2;10;20;30m"

# Generated at 2022-06-26 04:22:46.143460
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    import pytest

    # Import rendertypes
    from sty.rendertype import RgbFg, RgbBg, Rgb, RgbBold, RgbEf

    # Import colorz
    from sty import colors as c

    # Set new RenderType
    c.fg.set_rgb_call(RgbFg)

    # Set new color and get assertion
    c.fg(10, 42, 255)



# Generated at 2022-06-26 04:22:49.680511
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    x = Register()
    x.set_rgb_call(RGBFg)


# Generated at 2022-06-26 04:22:54.954200
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Setup
    from .rendertype import RGB, RgbBg, RgbFg

    renderfuncs: Renderfuncs = {RGB: lambda r, g, b: f"{r}{g}{b}"}
    reg = Register()
    reg.set_renderfunc(rendertype=RGB, func=renderfuncs[RGB])
    reg.set_rgb_call(RgbFg)

    # Test
    assert reg(10, 42, 255) == "1042255"



# Generated at 2022-06-26 04:23:06.376611
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RenderType_0(RenderType):
        args: Tuple
        __slots__ = ("args",)

        def __init__(self, *args) -> None:
            self.args = args

    rendertype_0 = RenderType_0

    # No exception is raised

    # Arguments for the function call
    rendertype = rendertype_0
    func = lambda r, g, b: (r, g, b)

    register_0 = Register()
    register_0.set_renderfunc(rendertype, func)
    register_0.set_rgb_call(rendertype)
    assert register_0.rgb_call(1, 2, 3) == (1, 2, 3)



# Generated at 2022-06-26 04:23:10.611203
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)

    print(inspect.formatargvalues(args, values))
    write_test_results(True, True, 'test_Register_set_rgb_call', inspect.getframeinfo(frame)[2], args, values, values)



# Generated at 2022-06-26 04:23:21.382829
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    #### Case 0: Normal Case
    rtype = RenderType()
    rtype.func = lambda *args, **kwargs: f"\x1b[{args[0]}m"
    renderfuncs = {rtype: lambda *args, **kwargs: f"\x1b[{args[0]}m"}
    custom_register = Register()
    custom_register.set_renderfunc(rtype, renderfuncs[rtype])

    # Test that renderfunc was set to 'custom_register'
    assert custom_register.renderfuncs[rtype] == renderfuncs[rtype]

    # Test that custom_register.eightbit_call is set to the set function
    custom_register.set_eightbit_call(rtype)
    assert custom_register.eightbit_call == renderfuncs[rtype]

   

# Generated at 2022-06-26 04:23:23.280596
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    reg = Register()
    reg.set_rgb_call(TypeError)


# Generated at 2022-06-26 04:23:33.651457
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    str(style_0) == "";


# Generated at 2022-06-26 04:23:41.834760
# Unit test for constructor of class Register
def test_Register():
    reg_0 = Register()

    # Test for initialization of attribute renderfuncs
    assert isinstance(reg_0.renderfuncs, dict)
    assert reg_0.renderfuncs == {}

    # Test for initialization of attribute is_muted
    assert isinstance(reg_0.is_muted, bool)
    assert reg_0.is_muted == False

    # Test for initialization of attribute eightbit_call
    assert callable(reg_0.eightbit_call)

    # Test for initialization of attribute rgb_call
    assert callable(reg_0.rgb_call)



# Generated at 2022-06-26 04:23:43.398387
# Unit test for method unmute of class Register
def test_Register_unmute():
    reg = Register()
    reg.unmute()
    assert reg.is_muted == False


# Generated at 2022-06-26 04:23:45.269488
# Unit test for constructor of class Style
def test_Style():
    style_1 = Style()
    assert isinstance(style_1, Style)


# Generated at 2022-06-26 04:23:52.713518
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    
    renderfuncs = {}

    # renderfunc for RgbBg
    def f1(r, g, b):
        return "\x1b[48;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m"

    # renderfunc for RgbFg
    def f2(r, g, b):
        return "\x1b[38;2;" + str(r) + ";" + str(g) + ";" + str(b) + "m"

    renderfuncs[type(RgbFg())] = f1
    renderfuncs[type(RgbBg())] = f2

    register_0 = Register()
    register_0.set_renderfunc(RgbFg, f1)

# Generated at 2022-06-26 04:24:03.892211
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()

    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)

    try:
        r(1)
    except TypeError:
        # TODO: TypeError raised if argument is not an instance of int, str or (int,int,int)
        pass
    try:
        r('a')
    except TypeError:
        # TODO: TypeError raised if argument is not an instance of int, str or (int,int,int)
        pass
    try:
        r('a', 1)
    except TypeError:
        # TODO: TypeError raised if argument is not an instance of int, str or (int,int,int)
        pass

# Generated at 2022-06-26 04:24:06.086300
# Unit test for constructor of class Style
def test_Style():

    style_0 = Style()

    if style_0.rules != tuple():
        raise Exception("Test failed.")
    else:
        print("Test passed.", end="\n\n")

# Generated at 2022-06-26 04:24:17.658433
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Test if as_namedtuple() method works correctly
    """
    reg = Register()   
    # Test if as_namedtuple returns a namedtuple
    assert isinstance(reg.as_namedtuple(), namedtuple)  # assert type is correct
    assert reg.as_namedtuple()._fields == ()            # check if the namedtuple is empty

    # Test if as_namedtuple returns a namedtuple with one field
    reg.test_style = Style()
    assert reg.as_namedtuple()._fields == ("test_style",)  # check if the namedtuple has correct field names
    assert getattr(reg.as_namedtuple(), "test_style") == ""    # check if the namedtuple has correct field values

    # Test if as_namedtuple returns a namedtuple with multiple

# Generated at 2022-06-26 04:24:29.641705
# Unit test for constructor of class Register
def test_Register():

    try:
        from .rendertype import RgbFg, RgbBg, RgbEf, RgbRs
        from .helper import _render_rgb, _render_rgb_bg
    except ImportError:
        print(f"{__file__} : {test_Register.__name__}")
        print(f"{__file__} : {test_case_0.__name__}")
        print(f"{__file__} : {test_case_1.__name__}")
        print(f"{__file__} : {test_case_2.__name__}")
        exit(1)

    def render_rgb(r: int, g: int, b: int) -> str:
        return _render_rgb(r, g, b)


# Generated at 2022-06-26 04:24:33.767695
# Unit test for constructor of class Style
def test_Style():
    style_args: Tuple[StylingRule] = (1, 2, 3)
    style_kwargs: Dict = {"value" : "value attribute"}
    style_0 = Style(*style_args, **style_kwargs)
    assert(style_0.rules == style_args)
    assert(str(style_0) == "value attribute")


# Generated at 2022-06-26 04:24:52.549316
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    """
    Tests the method set_rgb_call of class Register.
    """
    class MyRegister(Register):
        def __init__(self):

            super().__init__()
            self.red = Style(RgbFg(102, 0, 0))
            self.green = Style(RgbFg(0, 102, 0))
            self.blue = Style(RgbFg(0, 0, 102))

    r = MyRegister()

    r.set_rgb_call(RgbFg)

    assert r(102, 0, 0) == "\x1b[38;2;102;0;0m"

    assert r("red") == "\x1b[38;2;102;0;0m"


# Generated at 2022-06-26 04:24:59.825449
# Unit test for method mute of class Register
def test_Register_mute():
    test_Register = Register()
    assert test_Register.is_muted == False, "Test failed"
    test_Register.mute()
    assert test_Register.is_muted == True, "Test failed"
    test_Register.unmute()
    assert test_Register.is_muted == False, "Test failed"


# Generated at 2022-06-26 04:25:01.624666
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert reg.renderfuncs == {}


# Generated at 2022-06-26 04:25:05.353523
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Testcase 1
    r0 = Register()
    r0.set_eightbit_call(RenderType)
    assert isinstance(r0, Register)



# Generated at 2022-06-26 04:25:12.595203
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r.set_renderfunc(RenderType, lambda _: "")
    r.eightbit_call(1)
    r.rgb_call(1, 2, 3)
    r.mute()
    r.unmute()

    assert r.as_dict() == {}
    assert r.as_namedtuple() == namedtuple("StyleRegister")()

    assert r.copy() == r

# Generated at 2022-06-26 04:25:23.174311
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import sys
    import pickle

    style_8 = Style(RgbFg(10, 20, 30))
    style_32 = Style(TruecolorFg(10, 20, 30))

    from .rendertype import RgbFg

    # Create a new register
    register = Register()

    # Set renderfunc for RgbFg-type to a function, that does not return any string.
    register.set_renderfunc(RgbFg, lambda *x: None)

    # Set RgbFg as the rgb-call renderer
    register.set_rgb_call(RgbFg)

    if not (style_8.rules == register.rebeccapurple.rules):
        print("Style is not identical after mutation!")
        sys.exit(1)

    # Check if style_8 is not equal to

# Generated at 2022-06-26 04:25:33.886554
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    style_0 = Style(
        RgbFg(10, 23, 45),
        Sgr(1)
    )

    style_1 = Style(
        RgbFg(10, 23, 45),
        Sgr(1),
        Sgr(3)
    )

    style_2 = Style(
        RgbFg(10, 23, 45),
        RgbBg(110, 20, 210),
        Sgr(1),
        Sgr(3)
    )

    fg_test = Register()

    fg_test.black = style_0
    fg_test.black_bold = style_1
    fg_test.black_italic_bg_red = style_2


# Generated at 2022-06-26 04:25:37.756678
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)


# Generated at 2022-06-26 04:25:41.997282
# Unit test for constructor of class Style
def test_Style():
    try:
        test_case_0()
        print("Style constructor is working correctly.")
    except:
        print("Style constructor is broken.")



# Generated at 2022-06-26 04:25:48.505320
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    rgb_call_0 = lambda r, g, b: (r, g, b)
    # Test for calling set_rgb_call without passing any
    # parameters.
    def test_0(test_obj_0):
        try:
            test_obj_0.set_rgb_call()
        except TypeError:
            pass
        else:
            raise AssertionError('Argument "rendertype" is required.')

    # Test for calling set_rgb_call with the wrong order
    # of the arguments
    def test_1(test_obj_0):
        try:
            test_obj_0.set_rgb_call(rendertype=rgb_call_0)
        except TypeError:
            pass

# Generated at 2022-06-26 04:26:09.339559
# Unit test for method copy of class Register
def test_Register_copy():

    # Create new Register object
    r = Register()

    # Create new Rendertypes
    r1 = RgbBg(10, 20, 30)
    r2 = Sgr(1)

    # Define  color
    r.red = Style(r1, r2)
    r2.args + (2,)

    # Test
    assert r.red == "\x1b[48;2;10;20;30m\x1b[1m"
    assert r.copy().red == "\x1b[48;2;10;20;30m\x1b[1m"



# Generated at 2022-06-26 04:26:11.492354
# Unit test for method __call__ of class Register
def test_Register___call__():
    _register = Register()
    assert _register(42, 10, 22) is not None

# Generated at 2022-06-26 04:26:17.984434
# Unit test for method mute of class Register
def test_Register_mute():
    style_0 = Style()
    sty_1 = Register()
    sty_1.mute()
    sty_1.mute()
    sty_1.set_renderfunc(rendertype=False)
    sty_1.set_renderfunc(rendertype=True)


# Generated at 2022-06-26 04:26:27.170384
# Unit test for method unmute of class Register
def test_Register_unmute():
    style_0 = Style(Bold())
    style_1 = Style(Blink())
    rs = Register()
    rs.set_renderfunc(type(Bold()), lambda *args: '\x1b[1m')
    rs.set_renderfunc(type(Blink()), lambda *args: '\x1b[2m')
    setattr(rs, "test_0", style_0)
    setattr(rs, "test_1", style_1)
    rs.mute()
    assert rs.test_0 == ''
    assert rs.test_1 == ''
    rs.unmute()
    assert rs.test_0 == '\x1b[1m'
    assert rs.test_1 == '\x1b[2m'



# Generated at 2022-06-26 04:26:40.382282
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class DummyRenderType(RenderType):
        def __init__(self):
            self.args = None
        def __call__(self, *args, **kwargs) -> None:
            self.args = args
            self.kwargs = kwargs
    class TestEightBit(RenderType):
        def __call__(self, *args, **kwargs) -> str:
            return str(args)

    test_register = Register()
    test_register.set_renderfunc(TestEightBit, TestEightBit)
    test_register.set_eightbit_call(TestEightBit)
    test_register.set_rgb_call(DummyRenderType)

    assert test_register(42) == "(42,)"
    assert test_register.eightbit_call.args == (42,)
    assert test_register.r

# Generated at 2022-06-26 04:26:52.225921
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .sty import fg, bg, rs, Style, Reset
    sty_reg = fg.__class__()
    sty_reg_copy = sty_reg.copy()
    sty_reg.set_eightbit_call(bg.__class__)
    sty_reg.set_rgb_call(bg.__class__)
    sty_reg.sty_style_1 = Style(fg.red, bg.green, style_0)
    sty_reg.sty_style_2 = Style(fg.red)
    sty_reg.sty_style_3 = Style(bg.green)
    sty_reg.sty_style_4 = Style(rs.__class__)
    sty_reg.sty_style_5 = Style(rs.__class__())

# Generated at 2022-06-26 04:26:59.910758
# Unit test for constructor of class Style
def test_Style():
    
    from .rendertype import Fg, Sgr

    style_0 = Style()
    
    style_1 = Style("Hello", "World")
    assert style_1 == "HelloWorld"
    
    style_2 = Style("Hello", Style("World", "!!"))
    assert style_2 == "HelloWorld!!"

    style_3 = Style(Fg(1), Sgr(1))
    
    

# Generated at 2022-06-26 04:27:01.202855
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert r


# Generated at 2022-06-26 04:27:08.602229
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_test = Register()

# Generated at 2022-06-26 04:27:14.512220
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # Create a new TestRegister object.
    reg = Register()

    # Define some render-function
    def test_rgb_func(r: int, g: int, b: int) -> str:
        return f"OK{r},{g},{b}"

    # Add the render-function to Register
    reg.set_renderfunc(RgbFg, test_rgb_func)

    # Define an rgb-call.
    def reg_call(r: int, g: int, b: int) -> str:
        return reg(r, g, b)

    # Check if "set_rgb_call" works as expected.
    assert reg_call(255, 0, 0) == f"OK{255},{0},{0}"

    # Update render function.

# Generated at 2022-06-26 04:28:08.313569
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    # Instantiate a new Register
    test_case_0 = Register()

    # Check that object 'test_case_0' was instantiated.
    assert isinstance(
        test_case_0, Register
    )

    # Check that 'Style' was instantiated.
    assert isinstance(
        style_0, Style
    )

    # Check that Style-object is a Style (str)
    assert isinstance(
        style_0, str
    )

    # Check that fg.green is a Style-object.
    assert isinstance(
        test_case_0.green, Style
    )

# Generated at 2022-06-26 04:28:12.936736
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    rs = Register()
    rs.set_renderfunc(RenderType, lambda x: f"{x}{x}")
    rs.set_eightbit_call(RenderType)

    assert (rs(0) == "00")

# Generated at 2022-06-26 04:28:23.878500
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    style_0 = Style()

    m = Register()

    f0 = lambda x: '\x1b[38;5;%dm' % (x)
    m.set_renderfunc(rendertype=EightbitFg, func=f0)

    f1 = lambda x: '\x1b[48;5;%dm' % (x)
    m.set_renderfunc(rendertype=EightbitBg, func=f1)

    m.set_rgb_call(rendertype=RgbFg)

    # Test EightbitBg-call
    m.black = Style(EightbitBg(0), value="\x1b[48;5;0m")
    assert m.black == m(0)

    # Test RgbFg-call

# Generated at 2022-06-26 04:28:25.007141
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()


# Generated at 2022-06-26 04:28:26.804393
# Unit test for method mute of class Register
def test_Register_mute():
    register = Register()
    register.is_muted = False
    register.mute()
    assert register.is_muted == True


# Generated at 2022-06-26 04:28:28.810148
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    test_reg = Register()
    test_reg.set_eightbit_call(RenderType)
    assert test_reg.eightbit_call(RenderType) == RenderType


# Generated at 2022-06-26 04:28:36.874144
# Unit test for method __call__ of class Register
def test_Register___call__():

    r0 = Register()

    assert r0(42) == ""
    assert r0(42, 43, 44) == ""
    assert r0("red") == ""

    r0.set_eightbit_call(RenderType)
    assert r0(42) == "\x1b[38;5;42m"

    r0.set_rgb_call(RenderType)
    assert r0(42, 43, 44) == "\x1b[38;2;42;43;44m"

    r0.mute()
    assert r0(42) == ""
    assert r0(42, 43, 44) == ""

    r0.unmute()
    assert r0(42) == "\x1b[38;5;42m"

# Generated at 2022-06-26 04:28:41.442967
# Unit test for constructor of class Style
def test_Style():
    # Test case 0: Create style object without any parameters.
    test_case_0()


register = Register()


# Generated at 2022-06-26 04:28:43.992049
# Unit test for constructor of class Register
def test_Register():
    r = Register()
    assert isinstance(r, Register)


# Generated at 2022-06-26 04:28:49.558341
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """Test case for method __setattr__ of class Register"""
    style_0 = Style()
    style_1 = Style()
    style_2 = Style()
    style_3 = Style()

    def test_function_0():
        style_1 = Style(style_2)
        style_2 = Style(style_3)
        style_3 = Style(style_1)

    test_function_0()
    style_1 = Style(style_2)
    style_2 = Style(style_3)
    style_3 = Style(style_1)


if __name__ == "__main__":

    test_case_0()