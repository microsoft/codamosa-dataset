

# Generated at 2022-06-26 04:19:36.457547
# Unit test for method __call__ of class Register
def test_Register___call__():

    import pytest
    from .rendertype import RgbFg
    from .renderfuncs import render_rgb_fg

    my_register = Register()

    my_register.set_eightbit_call(rendertype=RgbFg)
    my_register.set_renderfunc(rendertype=RgbFg, func=render_rgb_fg)
    my_register.set_rgb_call(rendertype=RgbFg)

    my_register.bright_magenta = Style(
        RgbFg(rgb=(255, 0, 255)), value="\x1b[38;2;255;0;255m"
    )

    assert my_register.bright_magenta == "\x1b[38;2;255;0;255m"


# Generated at 2022-06-26 04:19:40.801160
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    # Check if register is instance of Register
    assert isinstance(register, Register)

test_Register()


# # Unit test for setattr of class Register

# Generated at 2022-06-26 04:19:41.739420
# Unit test for constructor of class Register
def test_Register():
    assert isinstance(Register(), Register) is True

# Generated at 2022-06-26 04:19:49.308209
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.set_renderfunc(RenderType.SGR, lambda *_: "")
    register_0.fg = Style(RenderType.SGR(0))
    register_0.bg = Style(RenderType.SGR(0))
    register_0.ef = Style(RenderType.SGR(0))
    register_0._red = Style(RenderType.SGR(0))
    register_0(42)
    register_0((255, 255, 255))
    register_0("red")

    register_1 = Register()
    register_1.set_eightbit_call(RenderType.EIGHTBIT)
    register_1(3)


# Generated at 2022-06-26 04:19:57.848443
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType.Sgr)
    register_0.set_rgb_call(RenderType.RgbFg)

    # Test Eightbit call.
    assert register_0(144) == "\x1b[38;5;144m\x1b[0m"

    # Test RGB call
    assert register_0(144, 200, 100) == "\x1b[38;2;144;200;100m\x1b[0m"

    # Test String call.
    register_0.red = Style(RenderType.Sgr(31))
    assert register_0("red") == "\x1b[31m\x1b[0m"

# Generated at 2022-06-26 04:20:07.501825
# Unit test for constructor of class Register
def test_Register():
    """
    Example for unit test.
    """

    reg = Register()
    assert reg.is_muted is False
    reg.eightbit_call = lambda x: x
    reg.rgb_call = lambda r, g, b: (r, g, b)

    assert hasattr(reg, "eightbit_call")
    assert hasattr(reg, "rgb_call")
    assert "eightbit_call" in dir(reg)
    assert reg.eightbit_call(0) == 0
    assert reg.rgb_call(0, 0, 0) == (0, 0, 0)
    assert not hasattr(reg, "mute")
    assert "mute" not in dir(reg)



# Generated at 2022-06-26 04:20:18.196349
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbBg, RgbFg, RgbFgBg, Sgr
    from .style import bg, fg, ef, rs
    
    register_0 = Register()
    register_0.set_renderfunc(RgbBg, lambda r, g, b: f'\x1b[48;2;{r};{g};{b}m')
    register_0.set_eightbit_call(RgbBg)
    register_0.set_rgb_call(RgbBg)
    register_0(1)
    register_0(2, 3)
    register_0(2, 3, 4)
    
    register_1 = Register()

# Generated at 2022-06-26 04:20:19.881133
# Unit test for constructor of class Register
def test_Register():
    assert type(Register()) == Register


# Generated at 2022-06-26 04:20:20.825876
# Unit test for constructor of class Register
def test_Register():
    Register()


# Generated at 2022-06-26 04:20:22.384425
# Unit test for constructor of class Register
def test_Register():
    assert Register()



# Generated at 2022-06-26 04:20:32.773369
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.fg = Style(RgbFg(255, 255, 255), Sgr(1))
    register_0.bg = Style(RgbBg(0, 0, 0))
    register_0.set_renderfunc(RgbBg, lambda r, g, b: f"{r}{g}{b}")
    register_0.set_rgb_call(RgbBg)
    register_0.set_eightbit_call(RgbBg)
    assert register_0(255, 255, 255) == "255255255"
    assert register_0(0, 0, 0) == "000000"
    assert register_0(128, 128, 128) == "128128128"


# Generated at 2022-06-26 04:20:38.890811
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register() # This is fine
    # register_1 = Register(renderfuncs) # This should fail
    # register_2 = Register(renderfuncs, muted) # This should fail
    # register_3 = Register(renderfuncs, muted, eightbit_call) # This should fail
    # register_4 = Register(renderfuncs, muted, eightbit_call, rgb_call) # This should fail


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:20:40.334572
# Unit test for constructor of class Register
def test_Register():
    assert Register()


# Generated at 2022-06-26 04:20:41.789217
# Unit test for constructor of class Register
def test_Register():
    try:
        test_case_0()
    except:
        raise AssertionError('Constructor test failed.')

test_Register()

# Generated at 2022-06-26 04:20:42.932718
# Unit test for constructor of class Register
def test_Register():
    register = Register()



# Generated at 2022-06-26 04:20:48.903633
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_0 = Register()
    register_0.set_eightbit_call = lambda x: x
    register_0.set_rgb_call = lambda r, g, b: (r, g, b)
    print(register_0(3)) # '3'
    print(register_0(1, 2, 3)) # (1, 2, 3)
    print(register_0("test")) # ''


# Generated at 2022-06-26 04:20:55.196161
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert type(register_0) is Register
    assert register_0.is_muted == False
    assert register_0.eightbit_call == None
    assert register_0.rgb_call == None


# Generated at 2022-06-26 04:21:03.245429
# Unit test for constructor of class Register
def test_Register():
    # Import library & create styledata
    from .sty import Sty
    from . import rgb

    st = Sty()

    # Test the creation of a new register object
    register_0 = Register()
    assert register_0 != None

    # Test the creation of a new register object
    # method muted()
    register_0.mute()
    assert register_0.is_muted == True

    # Test the creation of a new register object
    # method muted()
    register_0.unmute()
    assert register_0.is_muted == False

    # Test the creation of a new register object
    # method set_renderfunc()
    register_0.set_renderfunc(rgb.RgbFg, st._render_rgb_fg)

# Generated at 2022-06-26 04:21:10.972795
# Unit test for constructor of class Register
def test_Register():
    # Test initialization of Renderfuncs attribute
    register_0 = Register()
    assert register_0.renderfuncs == {}
    assert register_0.is_muted == False

# Generated at 2022-06-26 04:21:12.576978
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()

# Generated at 2022-06-26 04:21:26.784509
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_0 = Register()

    # INPUT: Eight bit call
    # 1) Eight bit call with exact setup 
    # 2) Eight bit call with muted register, this should not throw
    # 3) Eight bit call with one additional kwarg, this should not throw

    # 1)
    register_0.set_eightbit_call(RgbFg)
    register_0.rgb_black = Style(RgbFg(0,0,0))
    assert register_0("rgb_black") == "\x1b[38;2;0;0;0m"

    # 2)
    register_0.mute()
    assert register_0("rgb_black") == ""

    # 3)
    assert register_0("rgb_black", __something_weird=123) == ""

    # INPUT

# Generated at 2022-06-26 04:21:31.624921
# Unit test for constructor of class Register
def test_Register():
    register_0: Register = Register()
    assert isinstance(register_0, Register)


# Generated at 2022-06-26 04:21:33.360940
# Unit test for constructor of class Register
def test_Register():
    test_case_0()


# Generated at 2022-06-26 04:21:34.942761
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    register_0.is_muted = False

# Generated at 2022-06-26 04:21:46.198598
# Unit test for method __call__ of class Register
def test_Register___call__():

    def test_Register___call__0():
        register_0 = Register()
        register_0.set_eightbit_call(RenderType.sgr)
        register_0.set_rgb_call(RenderType.rgb_fg)
        register_0.set_renderfunc(RenderType.sgr, lambda x: "")
        register_0.set_renderfunc(RenderType.rgb_fg, lambda r, g, b: "")

# Generated at 2022-06-26 04:21:50.774828
# Unit test for constructor of class Register
def test_Register():
    assert (test_case_0())


test_case_1 = Register()
test_case_1.set_renderfunc(RenderType, lambda x: str(x))
test_case_1.blue = Style(RenderType(42))


# Generated at 2022-06-26 04:21:53.192429
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()


# Generated at 2022-06-26 04:21:55.046480
# Unit test for constructor of class Register
def test_Register():
    test_case_0()

# Generated at 2022-06-26 04:22:08.748465
# Unit test for constructor of class Register
def test_Register():
    """
    This is a simple unit test for the class Register. It tests all basic methods.
    """
    from .constants import Cfg, Ef, RgbFg, RgbBg, Rs, Sgr

    # Create a new register.
    register = Register()

    # Define some renderfuncs for the register (SGR stands for SelectGraphicRendition)

# Generated at 2022-06-26 04:22:16.294960
# Unit test for constructor of class Register
def test_Register():

    from .rendertype import Sgr, Rgb
    from .sgr import SgrReset

    def render_sgr(code: int) -> str:
        return f"\x1b[{code}m"

    register_0 = Register()
    register_0.set_renderfunc(rendertype=Sgr, func=render_sgr)

    register_0.red = Style(Sgr(1))
    register_0.red = Style(Sgr(1), Sgr(3))

    assert str(register_0.red) == "\x1b[1m\x1b[3m"

    register_0.red = Style(Sgr(1), Sgr(3), Sgr(4))


# Generated at 2022-06-26 04:22:33.325256
# Unit test for method copy of class Register
def test_Register_copy():
    # Test specific initial configuration
    test_Register = Register()

    # Test method copy of class Register
    test_Register_copy = test_Register.copy()

    # Test unwanted side effects
    assert test_Register == test_Register_copy


# Generated at 2022-06-26 04:22:38.037760
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Test as_dict on empty register
    register_0 = Register()
    assert register_0.as_dict() == {}

    # Test as_dict on register with Style objects
    register_1 = Register()
    register_1.test_style_0 = Style()
    register_1.test_style_1 = Style()
    dict_1 = register_1.as_dict()
    assert dict_1 == {'test_style_0': '', 'test_style_1': ''}
    assert type(dict_1) == dict


# Generated at 2022-06-26 04:22:38.816708
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    pass


# Generated at 2022-06-26 04:22:42.123375
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    assert isinstance(register_1, Register)


# Generated at 2022-06-26 04:22:48.247742
# Unit test for method __new__ of class Style
def test_Style___new__():
    register_0 = Register()
    style_0 = Style(Sgr(1), RgbFg(1, 5, 10), bg.red)
    style_1 = Style(Sgr(1), Sgr(1))
    style_2 = Style(RgbBg(1, 5, 10))
    style_3 = Style(RgbFg(1, 5, 10))


    assert isinstance(style_0, Style)
    assert isinstance(style_1, Style)
    assert isinstance(style_2, Style)
    assert isinstance(style_3, Style)



# Generated at 2022-06-26 04:22:50.520365
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    copy_0 = register_0.copy()
    assert copy_0 == register_0


# Generated at 2022-06-26 04:22:56.272376
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Test 1
    r1 = RenderType.r0
    r2 = RenderType.r1
    s0 = Style(r1, r2, value="")
    s0 = Style(r1, r2, value="")
    assert isinstance(s0, Style) == True

    # Test 2
    s1 = Style(s0, value="")
    assert isinstance(s1, Style) == True



# Generated at 2022-06-26 04:23:02.535023
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    register_0.red = Style(RgbFg(255, 0, 0))  # type: ignore
    assert register_0.as_dict() == {'red': '\x1b[38;2;255;0;0m'}



# Generated at 2022-06-26 04:23:11.932089
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_1 = Register()
    register_1.red = Style(Sgr(1, 31), Sgr(4))
    register_1.green = Style(Sgr(1, 32), Sgr(4))
    register_1.blue = Style(Sgr(1, 34), Sgr(4))
    assert register_1.as_namedtuple().red == '\x1b[1m\x1b[31m\x1b[4m'
    assert register_1.as_namedtuple().green == '\x1b[1m\x1b[32m\x1b[4m'
    assert register_1.as_namedtuple().blue == '\x1b[1m\x1b[34m\x1b[4m'


# Generated at 2022-06-26 04:23:13.227135
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:23:18.525101
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0.is_muted == False

# Generated at 2022-06-26 04:23:27.202684
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Setup
    register_1 = Register()

    # Test
    register_1.set_rgb_call(RenderType.VideoAttributes)
    res_1 = register_1.rgb_call
    assert res_1(10, 42, 255) == "\x1b[10;42;255m"


# Generated at 2022-06-26 04:23:29.063742
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert isinstance(register_0, Register)


# Generated at 2022-06-26 04:23:37.360954
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr
    from collections import namedtuple

    register_0 = Register()
    _func = lambda x: "some rendered data"

    register_0.set_renderfunc(Sgr, _func)

    # Assert that the dict, renderfuncs, in the register contains an entry with
    # the rendertype as key and the function as value.
    assert (
        Sgr,
        _func,
    ) in register_0.renderfuncs.items()



# Generated at 2022-06-26 04:23:42.825033
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.a = Style("\x1b[38;2;0;0;0m")
    register_0.b = Style("\x1b[38;2;0;0;1m")
    register_0.c = Style("\x1b[38;2;0;0;2m")
    test_case_0()


# Generated at 2022-06-26 04:23:51.322114
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.red = Style(Sgr(1))
    assert str(register_0.red) == "\x1b[1m"
    assert hasattr(register_0, "red")
    register_0.set_renderfunc(RgbBg, lambda r, g, b: "RgbBg({}, {}, {})".format(r, g, b))
    register_0.blue = Style(RgbBg(1, 2, 3))
    assert str(register_0.blue) == "RgbBg(1, 2, 3)"
    register_0.blue = Style(RgbBg(2, 3, 4))
    assert str(register_0.blue) == "RgbBg(2, 3, 4)"
    # Test that int is not allowed as attribute

# Generated at 2022-06-26 04:23:53.352615
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    assert not register_0.is_muted

    register_0.mute()
    assert register_0.is_muted

    register_0.unmute()
    assert not register_0.is_muted



# Generated at 2022-06-26 04:24:04.763738
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    TestRegister = Register()
    TestRegister.red = Style(RgbFg(255, 0, 0))
    TestRegister.blue = Style(RgbFg(0, 0, 255))
    TestRegister.set_eightbit_call(RgbFg)
    TestRegister.set_renderfunc(RgbFg, lambda *args, **kwargs: '\x1b[38;2;%s;%s;%sm' % (args[0], args[1], args[2]))
    result = TestRegister.as_namedtuple()
    assert result.red == '\x1b[38;2;255;0;0m'


# Generated at 2022-06-26 04:24:17.039547
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_1 = Register()

    def renderfunc_1(r, g, b):
        return "I'm renderfunc one."

    def renderfunc_2(r, g, b):
        return "I'm renderfunc two."

    register_0.set_renderfunc(type(RgbFg()), renderfunc_1)
    register_1.set_renderfunc(type(RgbFg()), renderfunc_2)

    register_0.set_rgb_call(RgbFg)
    register_1.set_rgb_call(RgbFg)

    str_0 = register_0(10, 42, 255)
    assert isinstance(str_0, str)
    assert str_0 == "I'm renderfunc one."


# Generated at 2022-06-26 04:24:28.862504
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()

    class T0(RenderType):
        args = ()
        code = 1, 2, 3

    class T1(T0):
        code = 4, 5, 6

    def render_0(*args, **kwargs):
        return "render_0"

    def render_1(*args, **kwargs):
        return "render_1"

    register_0.set_renderfunc(T0, render_0)
    register_0.set_renderfunc(T1, render_1)
    register_0.set_rgb_call(T0)
    assert register_0(10, 20, 30) == "render_0"
    register_0.set_rgb_call(T1)
    assert register_0(10, 20, 30) == "render_1"


#

# Generated at 2022-06-26 04:24:49.060933
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()

    register_0.set_renderfunc(RgbFg, lambda r,g,b: "mock")
    register_0.set_renderfunc(Bg, lambda r,g,b: "mock")
    register_0.set_renderfunc(RgbBg, lambda r,g,b: "mock")

    register_0.set_eightbit_call(RgbFg)
    assert(register_0.eightbit_call(12) == "mock")
    assert(register_0.eightbit_call(12, 12, 12) == "mock")
    assert(register_0.eightbit_call("red") == "red")

    register_0.set_eightbit_call(Bg)

# Generated at 2022-06-26 04:24:58.139226
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Case 1: Test an error if renderfunc is not a function.
    Case 2: Test an error if renderfunc is a function.
    Case 3: Test an error if rendertype is not an instance of class RenderType.
    Case 4: Test an error if rendertype is an instance of class RenderType.
    Case 5: Test correct behaviour of register_0.
    Case 6: Test correct behaviour of register_1.
    """

    # Case 1:
    # Test an error if renderfunc is not a function.
    register_0 = Register()

    class renderfunc_0: pass       #type: ignore

    def test_function_0():
        register_0.set_renderfunc(rendertype_0, renderfunc_0)

    rendertype_0 = RenderType("type_0", [])

# Generated at 2022-06-26 04:25:10.276077
# Unit test for method mute of class Register
def test_Register_mute():
    StylingRule = Union["Style", RenderType]
    register_0 = Register()
    register_0.mute()
    # test register_0 attributes
    assert getattr(register_0, 'is_muted') == True
    assert getattr(register_0, 'renderfuncs') == {}

# Generated at 2022-06-26 04:25:13.551665
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    register_0 = Register()
    register_0.set_eightbit_call(RgbFg)
    assert(register_0.eightbit_call.__name__ == "render_rgb_fg_ansi")



# Generated at 2022-06-26 04:25:19.053901
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.yellow = Sty(RgbFg(10, 10, 10), Sgr(1))
    register_0.yellow = "abc"

    assert register_0.yellow == "abc"



# Generated at 2022-06-26 04:25:21.557681
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()
    pass

# Generated at 2022-06-26 04:25:32.946529
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    register_0 = Register()
    register_0.set_renderfunc(RenderType.Sgr, lambda x, y: '_Sgr')
    register_0.set_renderfunc(RenderType.RgbBg, lambda x, y, z: '_RgbBg')
    register_0.set_renderfunc(RenderType.RgbFg, lambda x, y, z: '_RgbFg')


# Generated at 2022-06-26 04:25:35.122184
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    namedtuple_0: NamedTuple = register_0.as_namedtuple()
    assert len(namedtuple_0) == 0


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:25:44.800131
# Unit test for constructor of class Style
def test_Style():

    style = Style(1, 1, 1, 1, 1, value = "\x1b[1m\x1b[1m\x1b[1m\x1b[1m\x1b[1m")
    assert style == "\x1b[1m\x1b[1m\x1b[1m\x1b[1m\x1b[1m"
    assert isinstance(style, str)
    assert style.rules == (1,1,1,1,1)


# Generated at 2022-06-26 04:25:58.181293
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import pytest

# Generated at 2022-06-26 04:26:17.984055
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    setattr(register_0, "test", Style("a"))
    print("test" in register_0.__dict__)
    print(getattr(register_0, "test") == "a")


# Generated at 2022-06-26 04:26:23.022724
# Unit test for constructor of class Style
def test_Style():
    '''
    Test the initial constructor of class Style.
    '''
    desired_output = Style(name="default")
    assert '\x1b[0m' == str(desired_output)


# Generated at 2022-06-26 04:26:24.647224
# Unit test for constructor of class Register
def test_Register():
    test_case_0()


# Generated at 2022-06-26 04:26:31.756456
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty import fg

    def add_one(*args):
        # type: (int, int, int) -> str
        new_color = []
        for val in args:
            new_color.append((val + 1) % 256)
        return fg(*new_color)

    # create new register
    register_1 = Register()

    # register_1 doesn't have a render function for color type RGB
    assert "RgbFg" not in register_1.renderfuncs

    assert register_1.rgb_call(*(1, 2, 3)) == ""

    # set render func
    register_1.set_renderfunc(RgbFg, add_one)

    # register_1 now has a render function for color type RGB
    assert "RgbFg" in register_1.renderfuncs

    # set

# Generated at 2022-06-26 04:26:41.656590
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    from .rendertype import RgbFg, RgbBg, Sgr

    register = Register()

    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f"\x1b[38;2;{r};{g};{b}m"

    def render_rgb_bg(r: int, g: int, b: int) -> str:
        return f"\x1b[48;2;{r};{g};{b}m"

    register.set_renderfunc(RgbFg, render_rgb_fg)
    register.set_renderfunc(RgbBg, render_rgb_bg)

    assert register.rgb_call(2, 3, 4) == "\x1b[38;2;2;3;4m"

# Generated at 2022-06-26 04:26:46.043140
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    assert style_0.rules == []
    style_0 = Style('a')
    assert style_0.rules == ['a']


# Generated at 2022-06-26 04:26:49.181856
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()


# Generated at 2022-06-26 04:26:57.801310
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    from sty.rendertype import RgbBg

    register_0 = Register()

    assert register_0.rgb_call(0,0,0) == (0,0,0)

    register_0.set_rgb_call(RgbBg)

    assert register_0.rgb_call(0,0,0) == '\x1b[48;2;0;0;0m'



# Generated at 2022-06-26 04:27:04.120601
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_0 = Register()
    register_0.set_eightbit_call(RenderType)

    # Test case 1
    args_1 = (100, )
    kwargs_1 = {}
    result_1 = register_0(*args_1, **kwargs_1)
    assert type(result_1) == str
    assert result_1 == ""

    # Test case 2
    args_2 = (-1, )
    kwargs_2 = {}
    result_2 = register_0(*args_2, **kwargs_2)
    assert type(result_2) == str
    assert result_2 == ""

    # Test case 3
    args_3 = (256, )
    kwargs_3 = {}
    result_3 = register_0(*args_3, **kwargs_3)

# Generated at 2022-06-26 04:27:11.719872
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    register_0 = Register()
    register_0.set_eightbit_call(lambda x: x)
    register_0.set_rgb_call(lambda x, y, z: (x, y, z))

    register_0.blue = Style(RgbFg(0, 0, 255))

    namedtuple_result = register_0.as_namedtuple()

    assert namedtuple_result.blue == '\x1b[38;2;0;0;255m'


# Generated at 2022-06-26 04:27:45.794922
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)
    register_0.set_rgb_call(RenderType)
    register_0.set_renderfunc(RenderType, lambda r, g, b: (r, g, b))
    assert register_0.renderfuncs[RenderType] == RenderType
    assert isinstance(register_0.copy(), Register)
    
test_Register_copy()


# Generated at 2022-06-26 04:27:53.393573
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    expected = namedtuple('StyRegister', ['test_name_0', 'test_name_1'])
    expected = expected('test_value_0', 'test_value_1')
    register_0 = Register()
    register_0.test_name_0 = 'test_value_0'
    register_0.test_name_1 = 'test_value_1'
    actual = register_0.as_namedtuple()
    assert (actual == expected)



# Generated at 2022-06-26 04:28:01.782013
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Setup
    register_0 = Register()
    register_0.attr_name = Style(RenderType1(), RenderType2(), RenderType3(), RenderType4(), value="")

    # Test
    expected = {"attr_name": ""}
    actual = register_0.as_dict()

    # Assert
    assert actual == expected



# Generated at 2022-06-26 04:28:04.909046
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    result = Register().set_eightbit_call('\x1b[38;2;144;0;0m')
    assert result is None


# Generated at 2022-06-26 04:28:16.171043
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    Testing method __setattr__ of class Register
    """

    register_0 = Register()
    Style.__init__(Style("test_val3901"), System("test_val3901"))
    Style.__init__(Style("test_val5901"), System("test_val5901"))
    Style.__init__(Style("test_val7901"), System("test_val7901"))
    Style.__init__(Style("test_val8901"), System("test_val8901"))
    Style.__init__(Style("test_val9901"), System("test_val9901"))
    Style.__init__(Style("test_val1901"), System("test_val1901"))
    Style.__init__(Style("test_val2901"), System("test_val2901"))
    Style.__init__

# Generated at 2022-06-26 04:28:26.983673
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import pytest
    from sty import RenderType, ansi_style, fg, rs
    from sty.utils import RgbFg
    import sys

    # check the default init
    register_0 = RenderType()
    assert type(register_0) == RenderType

    # use ansi_style
    ansi_style('RgbFg(0, 0, 0)')
    sys.stdout.write('test for method set_rgb_call of class Register')
    sys.stdout.write('\n')
    rs.__call__()
    sys.stdout.write('\n')

    # use ansi_style
    ansi_style('fg(0, 0, 0)')
    sys.stdout.write('test for method set_rgb_call of class Register')
    sys.stdout.write

# Generated at 2022-06-26 04:28:29.104462
# Unit test for constructor of class Style
def test_Style():
    rule_0 = Style(fg=SgrFg(0))



# Generated at 2022-06-26 04:28:35.258215
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.is_muted = False
    register_0.eightbit_call = lambda r, g, b: (r, g, b)
    register_0.rgb_call = lambda r, g, b: (r, g, b)
    register_0.set_rgb_call(rendertype=RenderType)
    assert register_0.rgb_call(r=1, g=2, b=3) == (1, 2, 3)


# Generated at 2022-06-26 04:28:37.963662
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    assert isinstance(register_0, Register)


# Generated at 2022-06-26 04:28:49.222866
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Setup
    from sty import fg, bg, ef, rs

    registers: Dict[str, Register] = {
        "fg": fg,
        "bg": bg,
        "ef": ef,
        "rs": rs,
    }

    for reg_name, reg in registers.items():
        def d1():
            return getattr(reg, "blue")[-2:]

        def d2():
            return getattr(reg, "green")[-2:]

        def d3():
            return getattr(reg, "red")[-2:]

        def d4():
            return getattr(reg, "orange")[-2:]

        def d5():
            return getattr(reg, "yellow")[-2:]
