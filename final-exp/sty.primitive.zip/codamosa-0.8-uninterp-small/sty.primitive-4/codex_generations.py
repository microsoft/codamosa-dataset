

# Generated at 2022-06-26 04:19:27.747630
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert (isinstance(register_0, Register))



# Generated at 2022-06-26 04:19:33.651214
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    assert register_0("") == ""

    # TODO: This will change once we have color names.
    # assert register_0("red") == ""

    assert register_0(int()) == ""

    assert register_0(int(), int()) == ""

    assert register_0(int(), int(), int()) == ""



# Generated at 2022-06-26 04:19:35.226815
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()


# Generated at 2022-06-26 04:19:39.345759
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    assert register.eightbit_call is not None
    assert register.rgb_call is not None
    assert register.is_muted is False



# Generated at 2022-06-26 04:19:44.445592
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()

    assert register_0.renderfuncs == {}
    assert register_0.is_muted == False

# Generated at 2022-06-26 04:19:46.224295
# Unit test for constructor of class Register
def test_Register():
    test_case_0()

    reg = Register()
    assert not reg.is_muted


# Generated at 2022-06-26 04:19:48.256334
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert register.renderfuncs == {}


# Generated at 2022-06-26 04:19:50.293629
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()

    assert register_0 is not None

# Generated at 2022-06-26 04:19:52.210804
# Unit test for constructor of class Register
def test_Register():
    test_case_0()
    assert True


# Generated at 2022-06-26 04:19:54.679357
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0, "register_0 should have an instance."



# Generated at 2022-06-26 04:20:08.305632
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.fake_red = Style('\x1b[41m')
    register_0.fake_yellow = Style('\x1b[43m')
    register_0.fake_blue = Style('\x1b[44m')
    # Test with 8bit color
    assert(register_0(32) == '\x1b[32m')
    # Test with 24bit color
    assert(register_0(10, 42, 255) == '\x1b[38;2;10;42;255m')
    # Test with string
    assert(register_0('fake_red') == '\x1b[41m')
    # Test with string
    assert(register_0('fake_blue') == '\x1b[44m')
    # Test with string
   

# Generated at 2022-06-26 04:20:18.640196
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r: Register = Register()

    # Assert that the renderfuncs of a new register object is empty
    try:
        r.renderfuncs[RenderType]
    except KeyError:
        print("Passed unit test")
        pass
    else:
        print("Failed unit test")

    def f1(x):
        return str(x)

    # Add custom render-type to register
    r.set_renderfunc(RenderType, f1)

    # Assert that the custom render-type is added to the register
    try:
        r.renderfuncs[RenderType] == f1
    except KeyError:
        print("Failed unit test")
    else:
        print("Passed unit test")

    # Assert that the new Eightbit-call is now the given custom rendertype

# Generated at 2022-06-26 04:20:21.144783
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.black = Style()
    register_0.red = Style()
    register_0.orange = Style()
    nt = register_0.as_namedtuple()

    assert nt.black == ''
    assert nt.red == ''
    assert nt.orange == ''


# Generated at 2022-06-26 04:20:26.331410
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Set up test
    register_0 = Register()

    # Test
    register_0.set_renderfunc(RenderType, lambda x: "Test")

    # Check

# Generated at 2022-06-26 04:20:38.082849
# Unit test for constructor of class Style
def test_Style():
    from sty.rendertype import Ef, Fg, Sgr, RgbEf, RgbFg

    rule = Sgr(1)
    style = Style(rule)

    assert isinstance(style, str)
    assert isinstance(style, Style)
    assert style.rules == (rule,)
    assert str(style) == "\x1b[1m"

    style2 = Style(rule, rule)
    assert style2.rules == (rule, rule)
    assert str(style2) == "\x1b[1m\x1b[1m"

    style3 = Style(Sgr(2), Sgr(1), Sgr(0))
    assert str(style3) == "\x1b[2m\x1b[1m\x1b[0m"


# Generated at 2022-06-26 04:20:48.423259
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Unit test for method set_eightbit_call of class Register
    def test_case_0():
        register_0 = Register()

    def test_case_1():
        register_0 = Register()
        register_0.set_eightbit_call(RenderType)
        fg = register_0
        fg.red = Style(RenderType)
        str(fg.red)

    def test_case_2():
        register_0 = Register()
        register_0.set_eightbit_call(RenderType)
        fg = register_0
        fg(42)

    def test_case_3():
        register_0 = Register()
        register_0.set_rgb_call(RenderType)
        fg = register_0
        fg(42, 42, 42)



# Generated at 2022-06-26 04:20:59.847551
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    Test if unmute method works.
    """
    register_0 = Register()

    # Test if atribute 'is_muted' is False
    assert register_0.is_muted == False

    # Apply method unmute()
    register_0.unmute()

    # Check if register is not muted
    assert register_0.is_muted == False

    # Test if method does not raise any error
    try:
        register_0.unmute()
    except:
        raise Exception("Method 'unmute' raised an error.")



# Generated at 2022-06-26 04:21:05.845657
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    rendertype: Type[RenderType]
    register_0 = Register()
    try:
        register_0.set_eightbit_call(rendertype)
    except:
        register_0.set_eightbit_call(rendertype)


# Generated at 2022-06-26 04:21:12.457462
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    copy0 = register_0.copy()
    register_0.set_renderfunc(RenderType, lambda x, y: None)
    copy1 = register_0.copy()
    assert(register_0 is not copy0)
    assert(register_0 is not copy1)
    assert(copy0 is not copy1)
    assert(copy0.renderfuncs != register_0.renderfuncs)
    assert(copy1.renderfuncs == register_0.renderfuncs)

# Generated at 2022-06-26 04:21:20.880144
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    reg1 = Register()
    reg1.test = Style(RenderType.RenderType1(1,2,3), RenderType.RenderType2(4), 
                    value="94")
    assert reg1.test == "94"
    reg1.test = Style(RenderType.RenderType3(), 
                    value="34")
    assert reg1.test == "34"


# Generated at 2022-06-26 04:21:34.353863
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    from .rendertype import RgbFg, Sgr

    register_0 = Register()

    # Test case 0: __setattr__ with 'is_muted' set to True.
    register_1 = register_0.copy()
    register_1.is_muted = True
    register_1.test = Style(RgbFg(0, 0, 0), Sgr(1))
    assert register_1.test == ""

    # Test case 1: __setattr__ with 'is_muted' set to False.
    register_1 = register_0.copy()
    register_1.test = Style(RgbFg(0, 0, 0), Sgr(1))
    assert register_1.test == "\x1b[38;2;0;0;0m\x1b[1m"

    # Test

# Generated at 2022-06-26 04:21:40.140724
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.black = Style("black")
    register_0.purple = Style("purple")
    register_0.yellow = Style("yellow")

    A = register_0.as_namedtuple()

    assert A.black == register_0.black
    assert A.purple == register_0.purple
    assert A.yellow == register_0.yellow



# Generated at 2022-06-26 04:21:41.097676
# Unit test for constructor of class Register
def test_Register():
    assert Register()


# Generated at 2022-06-26 04:21:46.159701
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def sty_render(a):
        return a

    register_0 = Register()
    assert len(register_0.renderfuncs) == 0
    register_0.set_renderfunc(int, sty_render)
    assert len(register_0.renderfuncs) == 1



# Generated at 2022-06-26 04:21:47.942764
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()



# Generated at 2022-06-26 04:21:50.697097
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()

    assert register_0 is not register_1

# Generated at 2022-06-26 04:21:57.827109
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    register_0.red = "red_str"
    register_0.green = "green_str"
    register_0.blue = "blue_str"
    expect = {"red": "red_str", "green": "green_str", "blue": "blue_str"}

    actual = register_0.as_dict()

    assert actual == expect



# Generated at 2022-06-26 04:22:02.487542
# Unit test for constructor of class Style
def test_Style():

    def test_0():
        Style()

    def test_1():
        Style(RgbFg(1, 5, 10))

    def test_2():
        Style(RgbFg(1, 5, 10), Sgr(1))


# Generated at 2022-06-26 04:22:06.802656
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .sgr import Sgr

    style_0 = Style(Sgr(1))

    # Assertions:
    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)
    assert style_0 == "\x1b[1m"



# Generated at 2022-06-26 04:22:08.489960
# Unit test for method __new__ of class Style
def test_Style___new__():

    rule_0 = Style(value="")



# Generated at 2022-06-26 04:22:33.908923
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Input variables
    rendertype = None # <class 'syt.rendertype.RgbFg'>
    func = None # TODO
    r = None
    g = None
    b = None
    args = [None]
    kwargs = {}
    # Output variables
    output = None
    # Instantiate register_0 from class Register
    register_0 = Register()
    # Set attribute renderfuncs of register_0
    register_0.renderfuncs = {}
    # Set attribute is_muted of register_0
    register_0.is_muted = False
    # Set attribute eightbit_call of register_0
    register_0.eightbit_call = lambda x: x
    # Set attribute rgb_call of register_0

# Generated at 2022-06-26 04:22:36.898554
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(type(RgbFg(r=1,g=1,b=1)))
    assert register_0.rgb_call(rgbf=RgbFg(r=1,g=1,b=1))


# Generated at 2022-06-26 04:22:40.671401
# Unit test for method __new__ of class Style
def test_Style___new__():
    s = Style(value="hello")
    assert isinstance(s, Style)
    assert isinstance(s, str)
    assert str(s) == "hello"



# Generated at 2022-06-26 04:22:45.353992
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Arrange
    register = Register()
    register.set_renderfunc(RenderType, lambda a: a)

    # Act
    register.set_eightbit_call(RenderType)

    # Assert
    assert register.eightbit_call(1) == 1



# Generated at 2022-06-26 04:22:56.246848
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from sty.ansi import set_renderfuncs
    from sty.ansi.sgr import Sgr

    register_0 = Register()
    register_0.is_muted = True
    register_0.renderfuncs = set_renderfuncs()
    register_0.set_renderfunc(Sgr, lambda *args: "My new render functiok")

    rule = Style(Sgr(1, 3, 4))
    register_0.black = rule

    assert str(register_0.black) == "My new render functiok"


# Generated at 2022-06-26 04:23:07.259827
# Unit test for method copy of class Register
def test_Register_copy():

    class TestRegister(Register):
        """
        This class is used in the test below.
        """

        def __init__(self):
            super().__init__()
            self.red = Style(Sgr(1), RgbFg(1, 5, 10))
            self.green = Style(Sgr(1), RgbFg(1, 5, 10))

    register_0 = TestRegister()

    register_1 = register_0.copy()

    assert register_0.red == register_1.red
    assert register_0.green == register_1.green


if __name__ == "__main__":
    test_case_0()
    test_Register_copy()

# Generated at 2022-06-26 04:23:12.144925
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register_0 = Register()
    register_0.is_muted = False
    stack_0: List[Style] = []
    stack_0.append(Style(Sgr(1), value='\x1b[1m'))
    register_0.bold = stack_0[-1]
    try:
        assert getattr(register_0, 'bold') == stack_0[-1]
    except AssertionError as e:
        print(e)


# Generated at 2022-06-26 04:23:19.258028
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    # assert isinstance(register_0, register_1.__class__)
    register_1.x = "abc"
    # assert hasattr(register_0, "x") == False
    assert hasattr(register_1, "x") == True
    register_0.y = "xyz"
    assert hasattr(register_1, "y") == False


# Generated at 2022-06-26 04:23:29.310006
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    class FG(Register):
        black = Style()
        blue = Style()
        cyan = Style()
        green = Style()
        magenta = Style()
        red = Style()
        white = Style()
        yellow = Style()

    fg = FG()
    assert fg.as_dict() == {"black": "", "blue": "", "cyan": "", "green": "", "magenta": "", "red": "", "white": "", "yellow": ""}


# Generated at 2022-06-26 04:23:31.606597
# Unit test for constructor of class Style
def test_Style():
    Style(test_case_0)
    style = Style(test_case_0)



# Generated at 2022-06-26 04:24:09.382816
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    len0 = len(register_0.__call__())
    assert len0 == 0
    len1 = len(register_0.__call__("foo"))
    assert len1 == 0
    len2 = len(register_0.__call__("nothing"))
    assert len2 == 0
    len3 = len(register_0.__call__("foo", "bar"))
    assert len3 == 0
    len4 = len(register_0.__call__("foo", "no_such_attribute"))
    assert len4 == 0
    len5 = len("\x1b[31m")
    assert len5 == 5
    len6 = len(register_0.__call__(31))
    assert len6 == 5
    len7 = len(register_0.__call__("red"))


# Generated at 2022-06-26 04:24:18.047369
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .eightbit import Eightbit
    from .rgb import Rgb
    from .sgr import Sgr

    register_0 = Register()
    register_1 = Register()

    register_1.set_eightbit_call(Eightbit)
    register_1.set_rgb_call(Rgb)

    test_style = Style(Rgb(10, 20, 30), Sgr(1))

    register_0.test_style = test_style
    register_1.test_style = test_style

    assert str(register_0.test_style) == str(register_1.test_style)


# Generated at 2022-06-26 04:24:24.323065
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()

    # Asserting register_0.__dict__ == register_1.__dict__
    register_1 = register_0.__class__()
    assert register_0.__dict__ == register_1.__dict__
    register_1 = register_0.copy()
    assert register_0.__dict__ == register_1.__dict__


# Generated at 2022-06-26 04:24:26.323007
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    
    register_0 = Register()
    
    renderfunc_0: Callable


# Generated at 2022-06-26 04:24:32.714249
# Unit test for method copy of class Register
def test_Register_copy():
    register_13 = Register()

    sgr_0 = Sgr(1)

    register_13.set_renderfunc(Sgr, sgr_0)

    register_13.bold = Style(sgr_0)
    register_13.reset = Style(sgr_0)

    register_13.as_dict()
    register_13.as_namedtuple()
    register_13.copy()
    register_13.mute()
    register_13.unmute()


# Unit tests for the render-functions of the default registers (Fg, Bg, Effective and Reset).

# Generated at 2022-06-26 04:24:44.178307
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    expected: str = "\x1b[38;2;1;5;10m\x1b[1m"
    rule_0: NamedTuple = (1, 5, 10)
    rule_1: NamedTuple = (1,)
    rule_2: Tuple[NamedTuple, ...] = (rule_0, rule_1)
    style_0: StylingRule = Style(rule_2)
    name: str = "orange"
    setattr(register_0, name, style_0)
    assert str(getattr(register_0, name)) == expected


# Generated at 2022-06-26 04:24:47.361847
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    assert register_0.is_muted == False

    register_0.mute()
    assert register_0.is_muted == True



# Generated at 2022-06-26 04:24:55.365551
# Unit test for constructor of class Style
def test_Style():

    s = Style(RgbFg(1,2,3), Sgr(1))
    assert isinstance(s, Style), "Class 'Style' instance is not a instance of class Style."
    assert isinstance(s, str), "Class 'Style' instance is not a instance of class str."
    assert(str(s) == "\033[38;2;1;2;3m\033[1m"), "Style attribute 'value' has to be a str."
    assert(s.rules == (RgbFg(1,2,3), Sgr(1))), "Style attribute 'rules' has to be an Iterable[StylingRule]."


# Generated at 2022-06-26 04:25:05.720930
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Create test register.
    register = Register()

    # Define new renderfunc.
    def renderfunc(n) -> str:
        return "\\x1b[9" + str(n) + "m"

    # Add renderfunc to register.
    register.set_renderfunc(Eightbit, renderfunc)

    # Set renderfunc for eightbit-calls to new renderfunc.
    register.set_eightbit_call(Eightbit)

    # Call register object with eightbit-renderfunc.
    s = register(100)

    # Check value of return value.
    assert s == "\\x1b[910m"


# Generated at 2022-06-26 04:25:08.549914
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    val = str(register_0)
    assert val == ""
    register_0.unmute()
    val = str(register_0)
    assert val == ""


# Generated at 2022-06-26 04:26:37.034036
# Unit test for method copy of class Register
def test_Register_copy():
    """
    copy(self)
    """

    register_0 = Register()
    Register_copy = register_0.copy()
    assert Register_copy is not None



# Generated at 2022-06-26 04:26:39.078501
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    with pytest.raises(TypeError):
        register_0.set_rgb_call()


# Generated at 2022-06-26 04:26:42.128739
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()

if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-26 04:26:49.523315
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_1 = Register()
    register_1.set_renderfunc(RenderType, lambda *args: "foo")

    # Only 1 renderfunc is in register
    assert 1 == len(register_1.renderfuncs)

    # Test if renderfunc has been registered correctly
    assert "foo" == register_1.renderfuncs[RenderType]()



# Generated at 2022-06-26 04:26:54.426112
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style("hallo")
    assert style_0 == "hallo"
    assert style_0.rules == ()
    assert isinstance(style_0, Style)



# Generated at 2022-06-26 04:27:01.324860
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(RgbBg)
    assert register_0.rgb_call(144, 53, 255) == "\x1b[48;2;144;53;255m"

    register_1 = Register()
    register_1.set_rgb_call(Sgr)
    assert register_1.rgb_call(2, 3, 255) == "\x1b[2;3;255m"


# Generated at 2022-06-26 04:27:05.189348
# Unit test for constructor of class Style
def test_Style():
    register_1 = Register()
    result = Style(register_1)
    assert(result)



# Generated at 2022-06-26 04:27:11.924916
# Unit test for method unmute of class Register
def test_Register_unmute():
    sty01 = Register()
    sty02 = Register()
    sty02.mute()
    sty01.unmute()
    sty02.unmute()
    sty02.unmute()
    sty02.unmute()


# Generated at 2022-06-26 04:27:15.627570
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    assert register_0 != register_1


# Generated at 2022-06-26 04:27:24.389774
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Setup
    from .rendertypes import RgbFg
    from .standard import fg
    from .register import Register
    from .rendertype import RenderType

    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda : "\x1b[38;2;")
    register_0.set_eightbit_call(RenderType)

    # Test
    attr_0 = str(register_0(42))
    assert attr_0 == "\x1b[38;2;42m"

    attr_1 = str(fg.red)
    assert attr_1 == "\x1b[38;2;255;0;0m"

    attr_2 = str(fg.magenta)

# Generated at 2022-06-26 04:28:15.450365
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()

    assert register_0.mute()


# Generated at 2022-06-26 04:28:20.143046
# Unit test for method __new__ of class Style
def test_Style___new__():
    # Calling object with no args
    # Type error expected
    try:
        Style()
    except TypeError:
        pass
    else:
        assert False

test_Style___new__()


# Generated at 2022-06-26 04:28:23.261314
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()


# Generated at 2022-06-26 04:28:31.986274
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .render import RgbFg, Sgr

    # Define a function that returns the ANSI sequence for a given 8bit color.
    def rgb_fg_func(color_code: int) -> str:
        r, g, b = color_code % 6, color_code % 5, color_code % 8
        return f"{RgbFg(r, g, b)} {Sgr(1)}"  # bold

    # Create a register
    register = Register()

    # Add renderfunction for the rendertype RgbFg
    register.set_renderfunc(RgbFg, rgb_fg_func)

    # Assign rendertype RgbFg to be used for 8bit-calls.
    # This means that now calls of `register(color_code)` are
    # rendered as RgbFg(color_

# Generated at 2022-06-26 04:28:37.321726
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.is_muted = True
    register_0.eightbit_call = lambda x: x
    register_0.rgb_call = lambda r, g, b: (r, g, b)
    assert isinstance(register_0.a, Style)



# Generated at 2022-06-26 04:28:47.530517
# Unit test for method mute of class Register
def test_Register_mute():

    register_0 = Register()
    register_0._set_render_funcs_()
    register_0.null = Style(Sgr(38))
    assert str(register_0.null) == '\x1b[38;5;0m'

    register_0.mute()
    assert str(register_0.null) == ''

    register_1 = Register()
    register_1._set_render_funcs_()
    register_1.null = Style(Sgr(38))

    register_1.mute()
    assert str(register_1.null) == ''


# Generated at 2022-06-26 04:28:54.547742
# Unit test for method __new__ of class Style
def test_Style___new__():
    a = Style()
    assert isinstance(a, Style)
    assert isinstance(a, str)
    assert str(a) == ''
    a = Style('a')
    assert isinstance(a, Style)
    assert isinstance(a, str)
    assert str(a) == 'a'


# Generated at 2022-06-26 04:28:58.334052
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    rendertype_0 = Sgr(1)
    Register.set_rgb_call(register_0, rendertype_0)
    assert rendertype_0.renderfunc == rendertype_0.renderfunc


# Generated at 2022-06-26 04:29:02.465813
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import RgbFg, Sgr

    style_0 = Style(RgbFg(30, 31, 32), Sgr(1)) # Initialize style_0

    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)
    assert str(style_0) == '\x1b[38;2;30;31;32m\x1b[1m' # Checks if ANSI sequence is correct
    assert style_0.rules[0] == RgbFg(30, 31, 32) # Check if ANSI code is stored in Rule
    assert style_0.rules[1] == Sgr(1)


# Generated at 2022-06-26 04:29:06.859278
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # given
    register = Register()
    register.red = Style("\033[31m")

    # when
    d = register.as_dict()

    # then
    assert d == {"red": "\033[31m"}
