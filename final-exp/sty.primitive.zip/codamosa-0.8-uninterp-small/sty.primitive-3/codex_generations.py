

# Generated at 2022-06-26 04:19:23.892052
# Unit test for constructor of class Register
def test_Register():
    reg_0 = Register()



# Generated at 2022-06-26 04:19:35.968980
# Unit test for constructor of class Register
def test_Register():

    # Test case 1
    r1 = Register()

    assert isinstance(r1, Register)

    # Test case 2
    def rendertype1(param1: int) -> str:
        return "test"

    r2 = Register()
    r2.set_eightbit_call(rendertype1)

    assert r2.eightbit_call(10) == "test"

    # Test case 3
    def rendertype2(param1: int, param2: int) -> str:
        return "test"

    r3 = Register()
    r3.set_rgb_call(rendertype2)

    assert r3.rgb_call(1, 4) == "test"

    # Test case 4
    r4 = Register()
    r4.set_renderfunc(rendertype1, rendertype2)
    r4

# Generated at 2022-06-26 04:19:47.564971
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Check that the call with only a single argument works.
    class TestRegister(Register):

        attr = Style(RgbFg(10, 20, 30))

    test_reg = TestRegister()
    rst = test_reg("attr")
    expected = "\x1b[38;2;10;20;30m"
    assert rst == expected, "Unexpected result."

    # Check that the call with only three arguments works.
    func = lambda r, g, b: "".join(["\x1b[38;2;", str(r), ";", str(g), ";", str(b), "m"])
    test_reg.set_rgb_call(RgbFg)
    test_reg.set_renderfunc(RgbFg, func)


# Generated at 2022-06-26 04:19:49.024160
# Unit test for constructor of class Register
def test_Register():
    reg_0 = Register()


# Generated at 2022-06-26 04:19:52.220972
# Unit test for constructor of class Register
def test_Register():
    
    register_0 = Register()
    assert register_0.is_muted == False


# Generated at 2022-06-26 04:19:54.691323
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0.is_muted == False



# Generated at 2022-06-26 04:19:56.468606
# Unit test for constructor of class Register
def test_Register():
    Register()


# Unit tests for method set_eightbit_call

# Generated at 2022-06-26 04:20:00.689782
# Unit test for method __call__ of class Register
def test_Register___call__():
    r = Register()
    r.set_eightbit_call(RenderType)
    r.set_rgb_call(RenderType)
    r()


# Generated at 2022-06-26 04:20:03.105395
# Unit test for constructor of class Register
def test_Register():
    reg = Register()
    assert isinstance(reg, Register)

# Generated at 2022-06-26 04:20:09.089688
# Unit test for method __call__ of class Register
def test_Register___call__():
    '''
    Unit test for method `__call__` of class `Register`:
    '''

    register_0 = Register()
    assert register_0() == ""

    register_0.set_eightbit_call(lambda x: "A")
    assert register_0(121) == "A"

    register_0.set_rgb_call(lambda r, g, b: "B")
    register_0(4, 5, 6) == "B"

    register_0.set_eightbit_call(lambda x: "C")
    register_0.set_rgb_call(lambda r, g, b: "D")
    assert register_0(4, 5, 6) == "D"
    assert register_0(121) == "C"


# Generated at 2022-06-26 04:20:23.432115
# Unit test for method mute of class Register
def test_Register_mute():
    reg_0 = Register()
    reg_0.mute()
    style_0 = Style()


# Generated at 2022-06-26 04:20:24.861808
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)

# Generated at 2022-06-26 04:20:26.555444
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    test_case_0()


if __name__ == "__main__":
    test_Register_set_eightbit_call()

# Generated at 2022-06-26 04:20:36.750694
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from typing import Dict, Type
    from .rendertype import RenderType, RgbFg

    class CustomRegister(Register):
        pass

    def renderfunc(r: int, g: int, b: int) -> str:
        return f"{r}.{g}.{b}"

    register: CustomRegister = CustomRegister()
    register.set_renderfunc(RgbFg, renderfunc)

    renderfunc_dict: Dict[Type[RenderType], Callable]

    register.set_rgb_call(RgbFg)
    assert register.rgb_call(100, 100, 100) == "100.100.100"



# Generated at 2022-06-26 04:20:40.650229
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    test_str = "\x1b[38;2;50;50;50m"

    reg = Register()
    setattr(reg, "test_style", Style(RgbFg(50, 50, 50)))

    test_result = reg.as_dict()["test_style"] == test_str
    assert test_result == True



# Generated at 2022-06-26 04:20:50.930765
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Setup
    style_register_name_0: str = "some_name"
    style_register_args_0: List[str] = list()
    style_register_args_0.append("\x1b[31m")
    style_register_args_0.append("\x1b[44m")
    style_register_args_0.append("\x1b[35m")
    style_register_args_0.append("\x1b[48;2;255;255;255m")
    style_register_args_0.append("\x1b[1m")
    style_register_args_0.append("\x1b[33m")
    style_register_args_0.append("\x1b[31m")

# Generated at 2022-06-26 04:20:59.336460
# Unit test for method mute of class Register
def test_Register_mute():
    style_0 = Register()
    style_0.mute()


# Generated at 2022-06-26 04:21:08.458824
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    style_1 = Style(value="\x1b[38;2;1;5;10m\x1b[1m")

# Generated at 2022-06-26 04:21:10.057577
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    assert style_0 is not None


# Generated at 2022-06-26 04:21:15.741401
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style(Sgr(0, 1, 2), Sgr(4, 5, 6), value="0123456789")
    style_1 = Style()
    assert style_0 == "0123456789"
    assert repr(style_0) == "Style('0123456789', Sgr(0), Sgr(1), Sgr(2), Sgr(4), Sgr(5), Sgr(6))"
    assert not style_0 == style_1
    style_0_ = style_0.copy()
    assert style_0 == style_0_
    assert style_0.rules == (Sgr(0), Sgr(1), Sgr(2), Sgr(4), Sgr(5), Sgr(6))


# Generated at 2022-06-26 04:21:27.709441
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .register import Register
    from .rendertype import RgbBg, RgbFg

    register = Register()
    register.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{bm}m")
    register.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{bm}m")

    register.one = Style(RgbFg(144,44,55), RgbBg(102,49,42))
    register.two = Style(RgbFg(144,44,55))
    register.three = Style(RgbBg(102,49,42))

    d = register.as_dict()


# Generated at 2022-06-26 04:21:30.982993
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Test case 1: Style()
    style_1 = Style()

    # Test case 2: Register()
    style_2 = Register()

# Generated at 2022-06-26 04:21:34.022641
# Unit test for method unmute of class Register
def test_Register_unmute():

    register = Register()
    register.mute()
    register.unmute()
    assert register.is_muted == False


# Generated at 2022-06-26 04:21:42.040005
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)
    assert str(style_0) == ''

    style_1 = Style('a')
    assert isinstance(style_1, Style)
    assert isinstance(style_1, str)
    assert str(style_1) == 'a'

    style_2 = Style('')
    assert isinstance(style_2, Style)
    assert isinstance(style_2, str)
    assert str(style_2) == ''


# Generated at 2022-06-26 04:21:46.042386
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    r = Register()
    r.set_eightbit_call(RgbFg)

    # Make sure, that attribute 'eightbit_call' is set.
    assert hasattr(r, "eightbit_call")



# Generated at 2022-06-26 04:21:49.567698
# Unit test for method unmute of class Register
def test_Register_unmute():
    r = Register()
    r.is_muted = True
    r.unmute()
    assert r.is_muted == False

# Generated at 2022-06-26 04:21:53.504221
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()


# Generated at 2022-06-26 04:21:56.834275
# Unit test for constructor of class Style
def test_Style():

    test_case_0() # -> Should not raise Exception.

    try:
        Style("hi")
    except:
        return True

    return False



# Generated at 2022-06-26 04:21:58.654661
# Unit test for method unmute of class Register
def test_Register_unmute():
    assert True


# Generated at 2022-06-26 04:22:04.812827
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    # Create a new Register
    r: Register = Register()

    # Define a new renderfunc
    renderfunc = lambda x: x + "!"

    # Add renderfunc to register
    r.set_renderfunc(RenderType, renderfunc)

    # Set attribute with Style
    r.test = Style(RenderType, value="World")

    # Call attribute
    str(r.test) == "World!"



# Generated at 2022-06-26 04:22:17.370814
# Unit test for method __new__ of class Style
def test_Style___new__():

    StylingRuleSet = NamedTuple("StylingRuleSet", [("rule_0", StylingRule), ("rule_1", StylingRule)])
    Rule0 = TypeVar("Rule0", bound=StylingRule)
    Rule1 = TypeVar("Rule1", bound=StylingRule)
    styling_rules: StylingRuleSet[Rule0, Rule1] = StylingRuleSet(RgbFg(1,2,3), Sgr(1))

    style = Style(*styling_rules)
    assert style == "\\x1b[38;2;1;2;3m\\x1b[1m"
    assert style.rules == [RgbFg(1,2,3), Sgr(1)]


# Generated at 2022-06-26 04:22:24.067970
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Create a new register
    r = Register()

    # Define a new render type
    class RgbFg(RenderType):
        pass

    # Create a new renderfunc that can render the RGB-Fg-render-type
    def rgb_fg_renderfunc(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)

    # Add the renderfunc to the register
    r.set_renderfunc(RgbFg, rgb_fg_renderfunc)

    # Define a style attribute that uses the RGB-Fg-render-type
    r.red = Style(RgbFg(255, 0, 0))

    # Print the string of the style attribute
    print(r.red)  # '\

# Generated at 2022-06-26 04:22:29.514694
# Unit test for method __new__ of class Style
def test_Style___new__():
    pass
    # style_0 = Style()
    # style_1 = Style(RgbFg(1,5,10), Sgr(1))
    # style_2 = Style(1,5,10)
    # style_3 = Style(1)


# Generated at 2022-06-26 04:22:38.459095
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    """
    Test if the renderfuncs of a register object is updated properly.

    Implementation:

        - Create a register object with a renderfunc for the rendertype `RgbFg`
        - Check if the renderfunc for `RgbFg` is the same as the renderfunc for `RgbBg`

        - Create a new register object
        - Set new renderfunc for rendertype `RgbBg`
        - Check if the renderfunc for `RgbBg` is the same as the renderfunc for `RgbFg`

        - Call as_dict() method of register object
        - Check if all values are empty (empty string)
    """

    ###########################################################################
    # Setup
    ###########################################################################

    # Create basic register object with a renderfunc for the rendertype `RgbFg`

# Generated at 2022-06-26 04:22:41.253209
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    assert Register().as_namedtuple() == namedtuple('StyleRegister', tuple())(*tuple())

# Generated at 2022-06-26 04:22:44.868436
# Unit test for constructor of class Style
def test_Style():
    a = Style()
    assert isinstance(a, Style)
    assert isinstance(a, str)
    assert str(a) == ""


# Generated at 2022-06-26 04:22:51.279543
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    from .rendertype import Sgr
    from .sgr import default_render_sgr

    rg = Register()
    rg.set_renderfunc(Sgr, default_render_sgr)
    assert rg.renderfuncs[Sgr] == default_render_sgr


# Generated at 2022-06-26 04:22:58.457576
# Unit test for method __call__ of class Register
def test_Register___call__():

    style_0 = Style(RgbFg(255, 20, 50), Sgr(1))

    register_0 = Register()
    register_0.set_eightbit_call(RgbFg)
    register_0.set_rgb_call(RgbFg)

    assert register_0.eightbit_call(1, 2, 3) == "\x1b[38;2;1;2;3m"
    assert register_0.rgb_call(1, 2, 3) == "\x1b[38;2;1;2;3m"
    assert register_0(1) == "\x1b[38;2;1;2;3m"
    assert register_0(1, 2, 3) == "\x1b[38;2;1;2;3m"
    assert register_0

# Generated at 2022-06-26 04:23:05.481654
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    style_0 = Style()
    reg_0 = Register()

    reg_0.style_0 = style_0

    assert isinstance(reg_0.style_0, Style)
    assert reg_0.style_0 == style_0
    assert reg_0.style_0.rules == style_0.rules

    assert isinstance(reg_0.style_0, str)


# Generated at 2022-06-26 04:23:06.782160
# Unit test for method mute of class Register
def test_Register_mute():
    reg = Register()
    reg.unmute()
    reg.mute()

# Generated at 2022-06-26 04:23:20.620423
# Unit test for method copy of class Register
def test_Register_copy():
    r = Register()
    r.mute()
    r.set_eightbit_call(None)
    r.set_rgb_call(None)
    assert hasattr(r, "set_renderfunc")

    c = r.copy()
    assert hasattr(c, "set_renderfunc")

# Generated at 2022-06-26 04:23:23.607732
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    r1 = Register()

    r1.set_rgb_call(RgbFg)

    assert r1.rgb_call == RgbFg.render


# Generated at 2022-06-26 04:23:34.000690
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register0 = Register()

    assert hasattr(register0, '__setattr__')
    assert callable(register0.__setattr__)
    assert isinstance(register0.__setattr__, types.MethodType)

    register0.set_renderfunc(RgbBg, lambda r,g,b: "")
    register0.bg_red = Style(RgbBg(255, 0, 0))

    assert hasattr(register0, 'bg_red')
    assert isinstance(register0.bg_red, Style)

    return None


# Generated at 2022-06-26 04:23:44.074118
# Unit test for method mute of class Register
def test_Register_mute():

    r: Register = Register()

    # Create a test style.
    style_0 = Style(RgbFg(1, 5, 10), Sgr(1), Sgr(4))
    setattr(r, "test_style_0", style_0)

    # Create a test style.
    style_1 = Style(RgbBg(42, 49, 102), Sgr(1))
    setattr(r, "test_style_1", style_1)

    # Mute register object.
    r.mute()

    # Check if the style-attributes are still the same.
    assert r.test_style_0 == style_0
    assert r.test_style_1 == style_1

    # Check if the styles are now empty strings.
    assert str(r.test_style_0) == ""
   

# Generated at 2022-06-26 04:23:50.754852
# Unit test for method copy of class Register
def test_Register_copy():
    """
    Input:
    sty = sty.Register()
    sty_copy = sty.copy()

    Expected output:
    assert sty_copy == sty
    """

    sty = Register()
    sty_copy = sty.copy()
    #sty_copy = sty.copy()
    #sty_copy.set_eightbit_call(RgbFg)
    #sty_copy.mute()
    #sty_copy.set_renderfunc(RgbFg, lambda r, g, b: str(r) + str(g) + str(b))
    assert sty_copy == sty



# Generated at 2022-06-26 04:23:51.462495
# Unit test for constructor of class Register
def test_Register():
    reg = Register()

    assert isinstance(reg, Register)



# Generated at 2022-06-26 04:24:01.335713
# Unit test for method mute of class Register
def test_Register_mute():

    # Create a new register and save its attributes before muting it.
    reg = Register()
    reg_before_mute = reg.copy()

    # Mute the register.
    reg.mute()

    # Compare the attribute of the muted register with the attributes of
    # the unmuted register.
    attr_names = dir(reg)
    for attr_name in attr_names:
        before_mute = getattr(reg_before_mute, attr_name)
        after_mute = getattr(reg, attr_name)

        assert after_mute == before_mute

    print("\tTest 'mute' of class Register passed.")


# Generated at 2022-06-26 04:24:09.640298
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    style_3 = Style()
    style_8 = Style()

    r_0 = Register()
    Fg8 = r_0.renderfuncs[RenderType.Fg8]
    Fg24 = r_0.renderfuncs[RenderType.Fg24]

    r_0.set_eightbit_call(RenderType.Fg8)
    r_0.set_rgb_call(RenderType.Fg24)

    r_0.black = Style(RenderType.Fg8(0))
    r_0.white = Style(RenderType.Fg8(7), RenderType.Bold(True), RenderType.Underline(True))
    r_0.red = Style(RenderType.Fg24(255, 0, 0))

# Generated at 2022-06-26 04:24:12.216509
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    style_0.__new__(Style)
    style_1 = Style()


# Generated at 2022-06-26 04:24:14.632588
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    r = Register()

    # Test for correct return type
    assert isinstance(r.set_renderfunc(RenderType, lambda x: x), type(None))


# Generated at 2022-06-26 04:24:39.128838
# Unit test for constructor of class Style
def test_Style():

    # Test valid constructor call
    try:
        style_0 = Style()
    except:
        raise ValueError('Style constructor does not accept and argument.')



# Generated at 2022-06-26 04:24:42.022560
# Unit test for method mute of class Register
def test_Register_mute():
    reg_0 = Register()
    reg_0.mute()
    assert reg_0.is_muted


# Generated at 2022-06-26 04:24:44.555093
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    # TODO: Now we can add more tests.


if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-26 04:24:54.954139
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    RenderType0 = RenderType("RenderType0")

    class RenderType0:
        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)

    def render_type_0_func(r: int, g: int, b: int) -> str:
        return f"{r:1d}-{g:1d}-{b:1d}"

    r = Register()
    r.set_renderfunc(RenderType0, render_type_0_func)

    # We can use the register object directly.
    r.set_rgb_call(RenderType0)

    # Check if the renderfunc is used via the register object.
    assert r(1, 2, 3) == "1-2-3"

    # Check if the renderfunc

# Generated at 2022-06-26 04:25:05.051460
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    class MyRegister(Register):
        orange = Style(Sgr(1), Foreground(200))
        blue = Style(Sgr(1), Foreground(255))

    myreg = MyRegister()

    StyleRegister = myreg.as_namedtuple()

    assert StyleRegister.orange == "\x1b[38;5;200m\x1b[1m"
    assert StyleRegister.blue == "\x1b[38;5;255m\x1b[1m"

    assert StyleRegister.orange == myreg.orange
    assert StyleRegister.blue == myreg.blue



# Generated at 2022-06-26 04:25:07.464969
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    rg = Register()
    assert rg.as_dict() == {}
    rg.blue = Style()
    assert rg.as_dict() == {"blue": ""}

# Generated at 2022-06-26 04:25:10.131659
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    assert isinstance(style_0, Style)

    style_1 = Style(*[])
    assert isinstance(style_1, Style)



# Generated at 2022-06-26 04:25:15.470026
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from . import fg
    # Basic test for the namedtuple representing the color register fg
    t = fg.as_namedtuple()

    assert(isinstance(t, namedtuple))
    assert(t.red.endswith("m\x1b[0m"))
    assert(t.white.endswith("m\x1b[1m"))

    # Resulting namedtuple should be read-only
    with pytest.raises(AttributeError):
        t.red = "red"

# Generated at 2022-06-26 04:25:26.287385
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Create a register.
    r0 = Register()

    # Add some values.
    r0.red = Style("\x1b[1m")

    r0.green = Style("\x1b[7m")

    r0.blue = Style("\x1b[9m")

    # Check if registering of values worked.
    assert hasattr(r0, "red")
    assert hasattr(r0, "green")
    assert hasattr(r0, "blue")

    # Check if values are Style objects.
    assert isinstance(r0.red, Style)
    assert isinstance(r0.green, Style)
    assert isinstance(r0.blue, Style)

    # Now lets run as_dict method
    a0: Dict = r0.as_dict()

    # Check if the names are

# Generated at 2022-06-26 04:25:30.059719
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    r = Register()
    def test_rgb_call(*args, **kwargs):
        return ''.join(map(str,args))
    r.set_rgb_call(test_rgb_call)
    assert r(1, 2, 3) == '123'


# Generated at 2022-06-26 04:26:16.954350
# Unit test for method mute of class Register
def test_Register_mute():
    # Setting up some test data
    renderfuncs = {}
    r = Register()
    r.renderfuncs = renderfuncs

    # Test case 1: no attributes
    r.mute()
    assert r.is_muted == True


# Generated at 2022-06-26 04:26:27.847570
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    #Create new Register object
    test = Register()
    #Define as_dict method
    test_dict = test.as_dict()
    #Convert register object to namedtuple
    test_namedtuple = test.as_namedtuple()

    #Test that the namedtuple is of the correct type
    assert type(test_namedtuple).__name__ == "StyleRegister"

    #Test that all attributes of namedtuple are of the correct type
    for attr in test_namedtuple._fields:
        assert type(getattr(test_namedtuple, attr)).__name__ == "str"

# Generated at 2022-06-26 04:26:30.477356
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()


# Generated at 2022-06-26 04:26:40.314211
# Unit test for method unmute of class Register
def test_Register_unmute():

    r = Register()
    setattr(r, "test", Style(RgbFg(200, 200, 200), RgbBg(1, 2, 3)))
    r.mute()
    t = getattr(r, "test")

    assert t == ""
    assert r.is_muted
    assert isinstance(t, Style)

    r.unmute()
    t = getattr(r, "test")

    assert t == "\x1b[38;2;200;200;200m\x1b[48;2;1;2;3m"
    assert not r.is_muted



# Generated at 2022-06-26 04:26:41.694990
# Unit test for method mute of class Register
def test_Register_mute():
    obj = Register()

    obj.mute()

    # If a mute-flag is present in the object, everything is fine.
    assert hasattr(obj, "is_muted")

# Generated at 2022-06-26 04:26:53.998317
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Create a custom register
    R = Register()
    # Add a new renderfunction to the custom register
    R.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    # Set the renderfunc as the renderfunc for RGB-calls
    R.set_rgb_call(RgbFg)
    # Create a style
    S = Style(RgbFg(1,2,3), Sgr(1))
    # Add the style as attribute to the register
    R.test_style = S
    # Call the style on the register and check the result
    # Should be: '\x1b[38;2;1;2;3m\x1b[1m'

# Generated at 2022-06-26 04:27:02.750864
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty.mapping import Mapping
    from sty.types import RgbFg
    from sty.utils import fg, bg, ef, rs

    # Create a copy of the default Mapping object
    mapping = Mapping().copy()

    # Update colors
    mapping.colors.fg.red = Style(RgbFg(255, 0, 0))

    # Update register objects
    mapping.registers.fg = fg.copy()
    mapping.registers.fg.set_eightbit_call(RgbFg)
    mapping.registers.fg.set_rgb_call(RgbFg)
    mapping.registers.fg.set_renderfunc(RgbFg, lambda r, g, b: f'\x1b[38;2;{r};{g};{b}m')
   

# Generated at 2022-06-26 04:27:04.783940
# Unit test for method __call__ of class Register
def test_Register___call__():
    pass # TODO: Implement test or mock the decorator.



# Generated at 2022-06-26 04:27:12.507322
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    style_0 = Style()
    register_0 = Register()
    register_0.style_0 = "style_0"
    register_0.style_1 = "style_1"
    style_dict = register_0.as_dict()
    assert "style_0" in style_dict.keys()
    assert "style_1" in style_dict.keys()
    assert style_dict["style_0"] == "style_0"
    assert style_dict["style_1"] == "style_1"
    assert style_dict["style_0"] != style_0


# Generated at 2022-06-26 04:27:18.327904
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    r = Register()
    r.set_eightbit_call(RgbFg)
    assert r.renderfuncs[RgbFg] == r.eightbit_call


# Generated at 2022-06-26 04:28:15.603445
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()

    assert isinstance(style_0, Style)



# Generated at 2022-06-26 04:28:20.209364
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert Style.__new__ == str.__new__
    style_0 = Style()
    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)


# Generated at 2022-06-26 04:28:21.506505
# Unit test for constructor of class Register
def test_Register():
    Register_0 = Register()


# Generated at 2022-06-26 04:28:24.104608
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    assert isinstance(style_0, Style)


# Generated at 2022-06-26 04:28:31.591110
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # The register must have attributes to return.
    style_0 = Register()
    style_0.__setattr__("red", Style("\x1b[31m"))
    style_0.__setattr__("green", Style("\x1b[32m"))
    style_0.__setattr__("blue", Style("\x1b[34m"))

    # Get the register data in an object of type namedtuple
    StyleRegister = style_0.as_namedtuple()

    # test that all attributes are present
    assert StyleRegister.red == "\x1b[31m"
    assert StyleRegister.green == "\x1b[32m"
    assert StyleRegister.blue == "\x1b[34m"



# Generated at 2022-06-26 04:28:32.703771
# Unit test for constructor of class Register
def test_Register():
    parent = Register()
    assert parent


# Generated at 2022-06-26 04:28:39.518936
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    reg = Register()
    reg.test = Style(RgbFg(1,5,10), Sgr(1))

    assert getattr(reg, 'test') == Style(RgbFg(1,5,10), Sgr(1))
    assert isinstance(getattr(reg, 'test'), Style)
    assert reg.test == '\x1b[38;2;1;5;10m\x1b[1m'


# Generated at 2022-06-26 04:28:45.812567
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    assert style_0 == ""
    style_1 = Style("black")
    assert style_1 == "black"
    style_2 = Style("black", "bold")
    assert style_2 == "black\x1b[1m"



# Generated at 2022-06-26 04:28:48.974539
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)

# Generated at 2022-06-26 04:28:51.755777
# Unit test for method mute of class Register
def test_Register_mute():
    style_0 = Style()
    reg_1 = Register()
    reg_1.mute()
