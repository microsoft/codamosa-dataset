

# Generated at 2022-06-26 04:19:24.495543
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()



# Generated at 2022-06-26 04:19:31.278991
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_1 = Register()
    register_1.set_renderfunc(RenderType, lambda x,y:str(f"New Render function for {x} {y}"))
    assert "New Render function for RenderType" == register_1.renderfuncs[RenderType](RenderType,"")



# Generated at 2022-06-26 04:19:37.929296
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Setup
    # Make a new register.
    register_0 = Register()

    # Call the '__call__'-method of register_0 with an 8bit color code.
    actual_result_0 = register_0(14)

    # Call the '__call__'-method of register_0 with a color name.
    actual_result_1 = register_0('red')

    # Assert
    assert actual_result_0 == '\x1b[38;5;14m'
    assert actual_result_1 == '\x1b[38;2;255;0;0m'


# Generated at 2022-06-26 04:19:43.962679
# Unit test for constructor of class Style
def test_Style():
    from .rendertype import Sgr
    class TestSgr(Sgr):
        pass
    style_0 = Style(TestSgr(4))
    name_0 = "rules"
    assert hasattr(style_0, name_0), f"{name_0} attribute should be in {style_0}"


# Generated at 2022-06-26 04:19:45.136813
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:19:48.360293
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = Register()
    register_2 = register_0.copy()

    assert register_0 is not register_1
    assert register_1 is not register_2
    assert register_0 is not register_2



# Generated at 2022-06-26 04:19:57.717865
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register_0 = Register()
    register_0.renderfuncs = {
        Style: lambda x: x,
    }
    register_0.is_muted = False
    register_0.eightbit_call = lambda x: x
    register_0.rgb_call = lambda r, g, b: (r, g, b)

    register_0.myColor = Style("")

    assert register_0.myColor == ""

    register_0.myColor = Style(1)
    assert register_0.myColor == "1"

    register_0.myColor = Style(1, 2)
    assert register_0.myColor == "12"

    register_0.myColor = Style(Style(Style(1, 2), Style(3,4)))
    assert register_0.myColor == "1234"



# Generated at 2022-06-26 04:20:03.901627
# Unit test for constructor of class Register
def test_Register():
    assert hasattr(Register(), "is_muted") == True
    assert hasattr(Register(), "eightbit_call") == True
    assert hasattr(Register(), "rgb_call") == True
    assert hasattr(Register(), "renderfuncs") == True
    


# Generated at 2022-06-26 04:20:07.628079
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_1 = Register()
    register_1.set_eightbit_call(RgbFg)
    register_1.rgb_call.assert_called_once()


# Generated at 2022-06-26 04:20:13.321437
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    class_name = "Register"
    method_name = "as_namedtuple"
    register_0 = Register()
    output = register_0.as_namedtuple()
    assert isinstance(output, namedtuple)


# Generated at 2022-06-26 04:20:24.964364
# Unit test for constructor of class Register
def test_Register():
    register_0 = test_case_0()


if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-26 04:20:26.712991
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import sty

    register_0 = Register()
    register_0.set_rgb_call(sty.RgbFg)


# Generated at 2022-06-26 04:20:38.650415
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    global test_case_0

    print("Testing __setattr__() ...")

    register_0 = Register()

    register_0.muted = True

    register_0.muted = False

    register_0.mute()

    register_0.unmute()

    color_red = Style(RgbFg(255, 0, 0))

    register_0.red = color_red

    color_black = Style(RgbFg(0, 0, 0))

    register_0.black = color_black

    color_blue = Style(RgbFg(0, 0, 255))

    register_0.blue = color_blue

    color_green = Style(RgbFg(0, 255, 0))

    register_0.green = color_green


# Generated at 2022-06-26 04:20:40.829347
# Unit test for constructor of class Style
def test_Style():

    test_case_0()
    test_case_1()


# Generated at 2022-06-26 04:20:50.998539
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    import pytest
    from sty import bg
    from sty.types import RgbBg
    register_0 = Register()
    rendertype_0 = RgbBg
    def renderfunc_0(red: int, green: int, blue: int) -> str:
        _ = red + green + blue

    register_0.set_rgb_call(rendertype_0=rendertype_0)
    class StylingRule_0(str):
        def __init__(self, str_0: str, rules_0: Iterable[StylingRule_0]):
            self.rules = rules_0
            str.__init__(self, str_0=str_0)
        pass
    StylingRule_0 = StylingRule_0
    Style_0 = Style

# Generated at 2022-06-26 04:20:55.064194
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()
    assert register_0.is_muted is False


# Generated at 2022-06-26 04:20:59.035253
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)
    assert isinstance(register_0, Register)



# Generated at 2022-06-26 04:21:08.338967
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Test case 0
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)

    # Test case 0
    register_1 = Register()
    register_1.set_eightbit_call(RenderType)

    # Test case 0
    register_2 = Register()
    register_2.set_eightbit_call(RenderType)



# Generated at 2022-06-26 04:21:14.054591
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    r: Register = Register()

    assert isinstance(r.black, Style)

    assert r.black == "\x1b[30m"

    red: Style = Style(RgbFg(255, 0, 0))

    r.red = red

    assert isinstance(r.red, Style)

    assert r.red == "\x1b[38;2;255;0;0m"

    # Check if rendering still works for 8bit-color codes.
    r.set_eightbit_call(RgbFg)

    assert r(1) == "\x1b[38;2;68;68;68m"



# Generated at 2022-06-26 04:21:19.537459
# Unit test for method __new__ of class Style

# Generated at 2022-06-26 04:21:30.142581
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()
    assert register_0.is_muted


# Generated at 2022-06-26 04:21:31.645868
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register = Register()
    register.set_rgb_call(RenderType)



# Generated at 2022-06-26 04:21:43.478116
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    StyReg = Register()
    #
    StyReg.test_name_1 = '\x1b[0m\x1b[2m'
    StyReg.test_name_2 = '\x1b[1m'
    StyReg.test_name_3 = '\x1b[3m'
    StyReg.test_name_4 = '\x1b[4m'
    StyReg.test_name_5 = '\x1b[5m'
    StyReg.test_name_6 = '\x1b[7m'
    StyReg.test_name_7 = '\x1b[8m'
    StyReg.test_name_8 = '\x1b[9m'
    StyReg.test_name_9 = '\x1b[22m'
    #

# Generated at 2022-06-26 04:21:49.667394
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()  # type: Register
    register_0.eightbit_call = lambda *args: args[0]
    register_0.rgb_call = lambda *args: args
    assert register_0(144) == 144
    assert register_0(10, 42, 255) == (10, 42, 255)

# Generated at 2022-06-26 04:21:55.763804
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    assert register_0.as_namedtuple() == register_1.as_namedtuple()


# Generated at 2022-06-26 04:22:02.660182
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    register_0 = Register()
    register_0.set_renderfunc(RgbFg, lambda *x: "#")
    register_0.set_rgb_call(RgbFg)

    assert register_0(0, 123, 255) == "#"


# Generated at 2022-06-26 04:22:03.805288
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style()
    assert isinstance(style, Style)


# Generated at 2022-06-26 04:22:14.212982
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType.RgbFg)
    register_0.set_rgb_call(RenderType.RgbFg)
    register_0.set_renderfunc(RenderType.RgbFg, lambda r, g, b: f'\x1b[38;2;{r};{g};{b}m')
    # Case 0
    assert register_0(1, 2, 3) == '\x1b[38;2;1;2;3m'
    # Case 1
    assert register_0(4) == '\x1b[38;2;4;4;4m'
    # Case 2
    assert register_0('c') == '\x1b[38;2;127;127;127m'



# Generated at 2022-06-26 04:22:18.733340
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_1 = Register()
    register_1.red = Style(RgbFg(255,0,0))
    assert (register_1.as_dict()=={'red': '\x1b[38;2;255;0;0m'})


# Generated at 2022-06-26 04:22:19.620334
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()


# Generated at 2022-06-26 04:22:35.415464
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def f(a: str) -> str:
        return a + "foo"

    register_0 = Register()
    register_0.set_renderfunc(str, f)

    assert (register_0.renderfuncs[str] == f)



# Generated at 2022-06-26 04:22:40.432692
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.mute()
    assert register_0.is_muted == True
    register_0.unmute()
    assert register_0.is_muted == False


# Generated at 2022-06-26 04:22:44.594737
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(int)
    assert type(register_0.rgb_call) == type(lambda x: x)


# Generated at 2022-06-26 04:22:55.715207
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_1 = Register()
    register_1.bold = Style()
    register_1.standout = Style()
    register_0 = register_1.copy()
    assert isinstance(register_0, Register)
    assert isinstance(register_1, Register)
    assert id(register_0) != id(register_1)
    assert register_0 != register_1
    assert type(register_0) == type(register_1)



# Generated at 2022-06-26 04:23:01.916917
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    attrs = {'a': 1, 'b': 10, 'c': 20}
    register = Register()
    for attr in attrs:
        setattr(register, attr, attrs[attr])
    assert register.as_dict() == {'a': 1, 'b': 10, 'c': 20}


# Generated at 2022-06-26 04:23:11.826263
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RgbFg(RenderType):
        @staticmethod
        def render(r, g, b):
            return f"\x1b[38;2;{r};{g};{b}m"

    class RgbBg(RenderType):
        @staticmethod
        def render(r, g, b):
            return f"\x1b[48;2;{r};{g};{b}m"

    # 1. Create register object.
    register_0 = Register()

    # 2. Set renderfunc for 8bit foreground color.
    register_0.set_rgb_call(RgbFg)

    # 3. Test rgb-call.
    assert register_0(42, 43, 44) == "\x1b[38;2;42;43;44m"

    # 4. Change render

# Generated at 2022-06-26 04:23:21.381369
# Unit test for method copy of class Register
def test_Register_copy():

    register_0 = Register()
    register_1 = Register()

    register_1.set_renderfunc(RenderType.Sgr, lambda x: x)

    assert not register_0.renderfuncs == register_1.renderfuncs

    register_2 = register_1.copy()

    assert register_2.renderfuncs == register_1.renderfuncs

    register_3 = register_0.copy()

    assert register_3.renderfuncs == register_0.renderfuncs

    register_2.set_renderfunc(RenderType.Sgr, lambda x: x)

    assert register_1.renderfuncs == register_2.renderfuncs

    assert not register_3.renderfuncs == register_2.renderfuncs



# Generated at 2022-06-26 04:23:23.280216
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    assert register_0.as_dict() == {}


# Generated at 2022-06-26 04:23:30.734071
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    fg = Register()
    fg.set_renderfunc(
        RenderType,
        lambda x: "\x1b[38;2;{0};{1};{2}m".format(x[0], x[1], x[2]))
    assert(fg.rgb_call(1, 5, 10) == "\x1b[38;2;1;5;10m")


# Generated at 2022-06-26 04:23:40.881070
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from . import helper
    from .rendertype import Sgr, RgbFg

    # Given
    register = Register()
    register.set_renderfunc(Sgr, Sgr.render)
    register.set_renderfunc(RgbFg, RgbFg.render)
    register.eightbit = Style(Sgr(1))
    register.rgb = Style(RgbFg(1, 2, 3))

    # When
    d = register.as_dict()

    # Then

    assert(d['eightbit'] == '\x1b[1m')
    assert(d['rgb'] == '\x1b[38;2;1;2;3m')



# Generated at 2022-06-26 04:24:12.045214
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register_0 = Register()
    register_0.test_style = Style("test_value")

    # Assert that type of test_style is Style
    assert(True == isinstance(register_0.test_style, Style))



# Generated at 2022-06-26 04:24:15.957085
# Unit test for method __new__ of class Style
def test_Style___new__():
    from .rendertype import Sgr
    from .style import Style
    r = RenderType()
    s = Style(Sgr(1))
    assert (isinstance(s, str))
    assert (isinstance(s, Style))
    assert (s != "")


# Generated at 2022-06-26 04:24:16.636577
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()


# Generated at 2022-06-26 04:24:24.553823
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    register_0.black = Style("\x1b[38;5;234m")
    register_0.bg_black = Style("\x1b[48;5;234m")
    register_0.white = Style("\x1b[38;5;255m")

    assert register_0.as_dict() == {'black': "\x1b[38;5;234m", 'bg_black': "\x1b[48;5;234m", 'white': "\x1b[38;5;255m"}



# Generated at 2022-06-26 04:24:33.075906
# Unit test for method __new__ of class Style
def test_Style___new__():

    # Testcase 0
    Style(value="")

    # Testcase 1
    Style(value="\x1b[38;5;202m")

    # Testcase 2
    StylingRule() # TypeError
    Style(StylingRule) # TypeError
    Style(RgbFg(1,2,3),Sgr(1))

    # Testcase 3
    Style(RgbFg(1,2,3), RgbFg(1, 2, 3))

    # Testcase 4
    style = Style(RgbBg(1, 2, 3), RgbFg(1, 2, 3))
    Style(style)

    # Testcase 5
    Style(Style(RgbBg(1, 2, 3), RgbFg(1, 2, 3)))


# Generated at 2022-06-26 04:24:41.387931
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    reg = Register()
    rendered = reg(44)
    # Test if rendered string is empty and
    # if a default renderfunc was not set
    assert rendered == ""
    reg.set_eightbit_call(EightbitFg)
    # Test if set_eightbit_call set a new callable for the next call
    assert reg.eightbit_call
    assert reg(44) != ""


# Generated at 2022-06-26 04:24:43.018750
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:24:51.674135
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    assert(register_0.renderfuncs == register_1.renderfuncs)
    assert(register_0.is_muted == register_1.is_muted)
    assert(register_0.eightbit_call == register_1.eightbit_call)
    assert(register_0.rgb_call == register_1.rgb_call)
    assert(register_0 == register_1)
    assert(register_0 is not register_1)


# Generated at 2022-06-26 04:25:00.940485
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.blue = Style(RenderType, RenderType)
    register_0.red = Style(RenderType)
    namedtuple_ = register_0.as_namedtuple()
    assert namedtuple_.blue == "\\x1b[0]\\x1b[0]"
    assert namedtuple_.red == "\\x1b[0]"


# Generated at 2022-06-26 04:25:09.331769
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty.named_colors import NamedColorRegister
    from sty.named_styles import NamedStyleRegister
    from sty import colors
    from sty import styles
    colors.eightbit_register.as_namedtuple()
    colors.rgb_register.as_namedtuple()
    colors.gray_register.as_namedtuple()
    colors.rgb_register.as_namedtuple()
    styles.default_register.as_namedtuple()
    NamedColorRegister.as_namedtuple()
    NamedStyleRegister.as_namedtuple()



# Generated at 2022-06-26 04:26:13.661358
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.blue = Style("\x1b[34m")
    register_0.bold = Style("\x1b[1m")
    register_0.fg_blue = Style(1)
    register_0.bold_blue = Style(Style("\x1b[34m"), Style("\x1b[1m"))



# Generated at 2022-06-26 04:26:21.815871
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_1 = Register()
    register_2 = Register()
    register_3 = Register()
    register_4 = Register()

    register_0.mute()

    register_1.mute()
    register_2.mute()
    register_3.mute()
    register_4.mute()

    register_0.mute()
    register_1.mute()
    register_2.mute()
    register_3.mute()
    register_4.mute()

    register_0.mute()
    register_1.mute()
    register_2.mute()
    register_3.mute()
    register_4.mute()

    register_0.mute()
    register_1.mute()
    register_2.m

# Generated at 2022-06-26 04:26:29.768406
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def myrenderfunc(param_0: str, param_1: int, param_2: float) -> str:
        return ""

    class MyRenderType(RenderType):
        args: Tuple[str, int, float]

        def __new__(
            cls,
            arg_0: str,
            arg_1: int,
            arg_2: float
        ):
            args = arg_0, arg_1, arg_2
            return super().__new__(cls, args)

    register_0 = Register()

    register_0.set_renderfunc(MyRenderType, myrenderfunc)


# Generated at 2022-06-26 04:26:41.136245
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_1 = Register()
    assert register_0.eightbit_call == register_1.eightbit_call
    import pytest
    with pytest.raises(KeyError):
        register_0.set_eightbit_call(RenderType)
    class RgbFg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)
    def render_function(r, g, b):
        return F"{r}, {g}, {b}"
    register_0.set_renderfunc(RgbFg, render_function)
    class RgbBg(RenderType):
        def __init__(self, r, g, b):
            self.args = (r, g, b)

# Generated at 2022-06-26 04:26:44.348532
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    assert isinstance(register.as_namedtuple(), namedtuple)


# Generated at 2022-06-26 04:26:48.759562
# Unit test for method mute of class Register
def test_Register_mute():

    # Setup
    register_0 = Register()

    # Test
    register_0.mute()
    assert register_0.is_muted


# Generated at 2022-06-26 04:26:51.368606
# Unit test for method __new__ of class Style
def test_Style___new__():

    # test 1
    rule_0 = RenderType
    rule_1 = RenderType
    rules_0 = (rule_0, rule_1)

    style_0 = Style(*rules_0)

    assert isinstance(style_0, Style) is True


# Generated at 2022-06-26 04:26:53.493367
# Unit test for method mute of class Register
def test_Register_mute():

    register_0 = Register()

    register_0.mute()



# Generated at 2022-06-26 04:26:56.972651
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()



# Generated at 2022-06-26 04:27:00.887136
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    def dummyfunc_0(*args_0, **kwargs_0):
        pass

    register_0.set_renderfunc(str, dummyfunc_0)
