

# Generated at 2022-06-26 04:19:25.265645
# Unit test for constructor of class Register
def test_Register():
    # assert all([True, True])
    assert test_case_0() is None

# Generated at 2022-06-26 04:19:31.359989
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()

    assert register_0.eightbit_call is None
    assert register_0.rgb_call is None
    assert register_0.is_muted is False
    assert register_0.renderfuncs == {}


# Generated at 2022-06-26 04:19:32.594033
# Unit test for constructor of class Register
def test_Register():
    register_0: Register = test_case_0()


# Generated at 2022-06-26 04:19:36.671824
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda x: x)
    assert register_0(0) == ""


# Generated at 2022-06-26 04:19:41.408309
# Unit test for constructor of class Register
def test_Register():
    setattr(Register, "test", Style(value="test"))
    register_0 = Register()
    assert "test" in dir(register_0)



# Generated at 2022-06-26 04:19:46.301836
# Unit test for method __call__ of class Register
def test_Register___call__():
    sty: Register = Register()
    sty.renderfuncs = {type(None): lambda x: x}

    sty.set_eightbit_call(None)
    sty.set_rgb_call(None)

    assert sty(42) == 42
    assert sty(10, 20, 30) == (10, 20, 30)

    sty.rs = Style(None)
    sty.r = Style(None)
    sty.s = Style(None)

    assert sty("rs") == "rs"
    assert sty("r", "s") == ("r", "s")

    sty.mute()

    assert sty(42) == ""
    assert sty(10, 20, 30) == ""

    assert sty("rs") == ""
    assert sty("r", "s") == ""

    sty.unmute()

    assert sty

# Generated at 2022-06-26 04:19:51.197860
# Unit test for constructor of class Register
def test_Register():

    # This is an empty test.

    # If Register() creates a valid object, everything should be fine.
    register_0 = Register()

    # Test result should be output to console.
    assert True is True


# Generated at 2022-06-26 04:19:57.782551
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_0 = Register()
    register_0.set_renderfunc(str, lambda x: x)
    register_0.set_eightbit_call(str)
    register_0.set_rgb_call(str)
    register_0.black = Style(value="black")
    register_0.red = Style(value="red")
    register_0.green = Style(value="green")
    register_0.yellow = Style(value="yellow")
    register_0.blue = Style(value="blue")
    register_0.purple = Style(value="purple")
    register_0.cyan = Style(value="cyan")
    register_0.white = Style(value="white")
    register_0.gray = Style(value="gray")

    register_1 = Register()

# Generated at 2022-06-26 04:20:00.330529
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0 != None


# Generated at 2022-06-26 04:20:05.959896
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.reset = Style(RenderType.sgr_reset)
    assert str(register_0.reset) == "\x1b[0m"
    assert register_0.reset == register_0()
    assert register_0(register_0.reset) == register_0()
    assert register_0("reset") == register_0()



# Generated at 2022-06-26 04:20:15.723790
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0.eightbit_call.__name__ == '<lambda>'
    assert register_0.is_muted == False
    assert register_0.rgb_call.__name__ == '<lambda>'
    assert register_0.renderfuncs == {}



# Generated at 2022-06-26 04:20:27.659048
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.set_renderfunc(RenderType.eightbit_fg, lambda x: '\x1b[38;5;%dm' % x)
    register_0.set_renderfunc(RenderType.eightbit_bg, lambda x: '\x1b[48;5;%dm' % x)
    register_0.set_renderfunc(RenderType.rgb_fg, lambda r, g, b: '\x1b[38;2;%d;%d;%dm' % (r, g,  b))
    register_0.set_renderfunc(RenderType.rgb_bg, lambda r, g, b: '\x1b[48;2;%d;%d;%dm' % (r, g,  b))
    register_0.set_

# Generated at 2022-06-26 04:20:31.262207
# Unit test for constructor of class Register
def test_Register():
    test_case_0()


if __name__ == "__main__":
    register_0 = Register()
    print(register_0)

# Generated at 2022-06-26 04:20:40.766039
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import RgbFg, RgbBg, Sgr

    # Test for Eightbit-calls.
    register_1 = Register()
    register_1.set_eightbit_call(RgbFg)
    register_1.set_rgb_call(RgbFg)

    # Define a simple style attribute
    register_1.blue = Style(RgbFg(0, 0, 255), Sgr(1))

    assert str(register_1.blue) == "\x1b[38;2;0;0;255m\x1b[1m"
    assert register_1(133) == "\x1b[38;2;255;255;255m"
    assert register_1(10, 42, 255) == "\x1b[38;2;10;42;255m"

# Generated at 2022-06-26 04:20:46.285777
# Unit test for constructor of class Register
def test_Register():

    register_0 = Register()

    assert(register_0.is_muted == False)
    assert(register_0.eightbit_call != None)
    assert(register_0.rgb_call != None)


# Generated at 2022-06-26 04:20:48.626434
# Unit test for constructor of class Register
def test_Register():
    assert test_case_0() == None



# Generated at 2022-06-26 04:20:50.643434
# Unit test for constructor of class Register
def test_Register():
    assert Register()



# Generated at 2022-06-26 04:21:02.275081
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.eightbit_call = lambda x: x
    register_0.rgb_call = lambda r, g, b: (r, g, b)
    register_0.is_muted = False
    assert register_0(23) == 23
    assert register_0(13, 14, 15) == (13, 14, 15)
    register_0.is_muted = True
    assert register_0(13, 14, 15) == ""
    register_0.is_muted = False

    register_0 = Register()
    register_0.eightbit_call = lambda x: x
    register_0.rgb_call = lambda r, g, b: (r, g, b)
    register_0.is_muted = False
    register_0.is_m

# Generated at 2022-06-26 04:21:09.969807
# Unit test for method __call__ of class Register
def test_Register___call__():
    t = Register()

# Generated at 2022-06-26 04:21:11.120148
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    assert register_0() == ""


# Generated at 2022-06-26 04:21:19.182860
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0(0)



# Generated at 2022-06-26 04:21:27.202903
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_0 = Register()

    # Test 'register_0.__call__(int(arg0))'
    arg0 = 101
    arg0_0 = register_0.__call__(int(arg0))

    # It should return ""
    assert arg0_0 == ""

    # Test 'register_0.__call__(str(arg2))'
    arg2 = 'black'
    arg2_0 = register_0.__call__(str(arg2))

    # It should return ""
    assert arg2_0 == ""

    # Test 'register_0.__call__(int(arg3), int(arg4), int(arg5))'
    arg3 = 101
    arg4 = 99
    arg5 = 99

# Generated at 2022-06-26 04:21:30.154627
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)



# Generated at 2022-06-26 04:21:41.691354
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()

    # Test 1
    instance = register_0
    output = instance.__call__(0)
    assert output == "", "SyntaxError: invalid syntax"

    # Test 2
    instance = register_0
    output = instance.__call__(0, 0)
    assert output == "", "SyntaxError: invalid syntax"

    # Test 3
    instance = register_0
    output = instance.__call__(0, 0, 0)
    assert output == "", "SyntaxError: invalid syntax"

    # Test 4
    instance = register_0
    output = instance.__call__(0, 0, 0, 0)
    assert output == "", "SyntaxError: invalid syntax"

    # Test 5
    instance = register_0

# Generated at 2022-06-26 04:21:52.914450
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Create new register.
    fg = Register()

    # Add renderfunc for ANSI-Style SGR.
    fg.set_renderfunc(RenderType.SGR, lambda code: f"\033[{code}m")

    # Define style: black text.
    style_0 = Style(RenderType.SGR(30), value="\033[30m")

    # Assign style_0 to attribute attribute 'black'
    setattr(fg, "black", style_0)

    # Create more styles in different ways.
    style_1 = Style(RenderType.SGR(1), value="\033[1m")
    fg.green = Style(RenderType.SGR(32), value="\033[32m")

# Generated at 2022-06-26 04:21:56.070117
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    assert str(register_0(42)) == ""
    assert str(register_0(10, 42, 255)) == ""


# Generated at 2022-06-26 04:22:01.980557
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()

    assert "" == (register_0())
    assert "" == (register_0(144))
    assert "" == (register_0(102, 49, 42))
    assert "a" == (register_0('a'))



# Generated at 2022-06-26 04:22:02.857654
# Unit test for constructor of class Register
def test_Register():

    test_case_0()

# Generated at 2022-06-26 04:22:08.851898
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)
    register_0.set_rgb_call(RenderType)
    register_0.reset = Style(RenderType())
    str_1: str = register_0(144)
    str_2: str = register_0(102, 49, 42)
    str_3: str = register_0("reset")

# Generated at 2022-06-26 04:22:16.201370
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Setup test env
    register_0 = Register()
    register_0.renderfuncs.update({RgbFg: lambda x, y, z: f"rgb{x}{y}{z}"})
    register_0.blue = Style(RgbFg(0, 0, 255))
    register_0.set_rgb_call(RgbFg)

    # Replace render-func for rgb-calls.
    register_0.renderfuncs.update({RgbFg: lambda x, y, z: f"{x};{y};{z}"})

    # Test
    assert register_0.blue == "rgb00255"
    assert str(register_0(0, 0, 255)) == "0;0;255"



# Generated at 2022-06-26 04:22:34.480007
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_1 = Register()
    register_0.set_rgb_call(rendertype=RenderType)
    if hasattr(register_0, 'rgb_call'):
        assert type(register_0.rgb_call) is Callable
    else:
        raise AssertionError(
            'Attribute `rgb_call` was not defined.')
    if hasattr(register_1, 'rgb_call'):
        assert type(register_1.rgb_call) is Callable
    else:
        raise AssertionError(
            'Attribute `rgb_call` was not defined.')

# Generated at 2022-06-26 04:22:39.472168
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    sty = Style(RgbFg(10,42,255))
    register_0 = Register()
    register_0.new_style = sty
    result = register_0.as_dict()
    assert result == {'new_style': '\x1b[38;2;10;42;255m'}
    register_1 = Register()
    register_1._test = sty
    register_1._testtest = sty
    result = register_1.as_dict()
    assert result == {'_test': '\x1b[38;2;10;42;255m', '_testtest': '\x1b[38;2;10;42;255m'}


# Generated at 2022-06-26 04:22:41.833873
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)



# Generated at 2022-06-26 04:22:44.047180
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()


# Generated at 2022-06-26 04:22:47.132782
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0.renderfuncs == {}
    assert register_0.is_muted == False

# Generated at 2022-06-26 04:22:55.655615
# Unit test for method __new__ of class Style
def test_Style___new__():

    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda *x: x)

    #TODO: Test with RenderType
    # Test with Style
    style_1 = Style(style_0)
    register_0.style_0 = style_1
    style_0 = Style()

    assert style_0 is not style_1
    assert type(style_1) is Style
    assert type(style_0) is Style


# Generated at 2022-06-26 04:23:00.016999
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_1 = Register()
    register_1.mute()
    register_0.unmute()


# Generated at 2022-06-26 04:23:03.091880
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    assert (register_0.is_muted == False)
    register_0.mute()
    assert (register_0.is_muted == True)


# Generated at 2022-06-26 04:23:09.054319
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    r.test = Style(RenderType.rgb_fg(255, 0, 0), RenderType.rgb_bg(0, 255, 0))
    assert r.as_dict() == {'test': '\x1b[38;2;255;0;0m\x1b[48;2;0;255;0m'} # True


# Generated at 2022-06-26 04:23:13.745918
# Unit test for method copy of class Register
def test_Register_copy():

    # Arrange
    r = Register()
    r.set_eightbit_call(1)
    r.set_rgb_call(2)
    r.set_renderfunc(3, 4)
    r.mute()

    # Act
    r2 = r.copy()

    # Assert
    assert r2.renderfuncs[1] == r.renderfuncs[1]
    assert r2.eightbit_call == r.eightbit_call
    assert r2.rgb_call == r.rgb_call
    assert r2.is_muted == r.is_muted


# Generated at 2022-06-26 04:23:33.666198
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg
    from collections import namedtuple

    register_0 = Register()
    register_0.fg = Style(fg.red)
    t = register_0.as_namedtuple()
    assert isinstance(t, namedtuple) == True
    assert t.fg == fg.red
    assert t.bg == ""
    assert t.ef == ""
    assert t.rs == "\x1b[0m"


# Generated at 2022-06-26 04:23:34.787236
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    assert not register_0.is_muted
    register_0.mute()
    assert register_0.is_muted


# Generated at 2022-06-26 04:23:37.634194
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    styling_rules_1: Iterable[StylingRule] = (
        RenderType,
        Style,
    )
    val_0: Style = Style(*styling_rules_1, value="")

# Generated at 2022-06-26 04:23:44.000679
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Setup
    reg = Register()
    reg.white = Style(RgbFg(5,5,5), Sgr(1))
    reg.yellow = Style(EightBitFg(5), Sgr(4))

    # Test
    color = reg.as_namedtuple()

    # Assert
    assert color.white == Style(RgbFg(5,5,5), Sgr(1))
    assert color.yellow == Style(EightBitFg(5), Sgr(4))


# Generated at 2022-06-26 04:23:46.227373
# Unit test for constructor of class Style
def test_Style():
    expected_result = bool(Style(""))
    result = True
    assert(expected_result == result)


# Generated at 2022-06-26 04:23:49.511889
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)

    style_1 = Style("")
    assert isinstance(style_1, Style)
    assert isinstance(style_1, str)


# Generated at 2022-06-26 04:24:01.502884
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .register import Register
    from .rendertype import RgbFg, RgbBg, Sgr
    register_1 = Register()
    register_1.set_eightbit_call(RgbFg)
    register_1.set_rgb_call(RgbFg)
    register_1.set_eightbit_call(RgbBg)
    register_1.set_rgb_call(RgbBg)
    register_1.set(RgbFg(124, 134, 144))
    register_1.set(RgbBg(124, 134, 144))
    register_1.set(Sgr(0))
    assert register_1.as_dict() == {'reset': '\x1b[0m'}

# Generated at 2022-06-26 04:24:04.824040
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.as_namedtuple()


# Generated at 2022-06-26 04:24:17.073746
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbFg(RenderType):
        def __init__(self, r: int, g: int, b: int):
            self.r = r
            self.g = g
            self.b = b

        def args(self):
            return (self.r, self.g, self.b)

        def ansi(self, r: int, g: int, b: int):
            return f"\x1b[38;2;{r};{g};{b}m"

    def renderfunc_rgb(r: int, g: int, b: int):
        return f"{r};{g};{b}"

    r = Register()

    r.set_renderfunc(RgbFg, renderfunc_rgb)


# Generated at 2022-06-26 04:24:26.772119
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Test for method set_renderfunc of class Register.
    """

    from .rendertype import Sgr

    # Create new Register
    register_0 = Register()

    # Create mock renderfunc
    render_func_0 = lambda x: "MockSgr_{}".format(x)

    # Register new render-func for Sgr
    register_0.set_renderfunc(Sgr, render_func_0)

    style_0 = Style(Sgr(1))
    setattr(register_0, "style_0", style_0)

    # Check if renderfunc has changed
    assert str(getattr(register_0, "style_0")) == "MockSgr_1"


# Generated at 2022-06-26 04:24:41.773240
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()
    assert getattr(register_0, "is_muted", False) == False


# Generated at 2022-06-26 04:24:44.683243
# Unit test for constructor of class Register
def test_Register():
    try:
        register_0 = Register()
    except:
        print("Error in constructor of class Register")
        return False
    return True


# Generated at 2022-06-26 04:24:47.440046
# Unit test for method mute of class Register
def test_Register_mute():

    register_0 = Register()

    # Calls the method 'mute' of class Register
    assert not register_0.is_muted == True


# Generated at 2022-06-26 04:24:57.312071
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Create new register object
    register_1 = Register()

    # Check that the register object has no eightbit_call function.
    assert not hasattr(register_1, 'eightbit_call')

    # Create new rendertype class
    class RgbFg(RenderType):

        def __init__(self, r: int, g: int, b: int):
            self.args = (r, g, b)


    # Create a new renderfunction for the new rendertype
    def render_rgb_fg(r: int, g: int, b: int) -> str:
        return f'\x1b[38;2;{r};{g};{b}m'

    # Add the new renderfunction to the register
    register_1.set_renderfunc(RgbFg, render_rgb_fg)



# Generated at 2022-06-26 04:25:01.751300
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    test_0 = 0
    try:
        register_0.__call__(0)
        test_0 = 1
    except NotImplementedError:
        pass
    assert test_0 == 1


# Generated at 2022-06-26 04:25:07.109894
# Unit test for method __new__ of class Style
def test_Style___new__():

    style_0 = Style(RgbFg(1,5,10), Sgr(1))

    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)
    assert str(style_0) == '\x1b[38;2;1;5;10m\x1b[1m'


# Generated at 2022-06-26 04:25:08.515937
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:25:09.756588
# Unit test for constructor of class Style
def test_Style():
    assert Style() is not None


# Generated at 2022-06-26 04:25:12.414451
# Unit test for constructor of class Register
def test_Register():
    # Test if instance of class Register is created
    test_case_0()

if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-26 04:25:15.650659
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()



# Generated at 2022-06-26 04:25:28.216215
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.test_0 = Style()
    assert isinstance(register_0.test_0, Style)


# Generated at 2022-06-26 04:25:35.862803
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from .sgr import Sgr

    rg_0 = Register()
    rg_0.set_eightbit_call(Sgr)
    rg_0.set_rgb_call(Sgr)

    for i in range(0, 16):

        name = f"c{i}"
        setattr(rg_0, name, Style(Sgr(i)))
        assert rg_0.as_dict() == {name: f"\x1b[{i}m"}


# Generated at 2022-06-26 04:25:39.936032
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_1 = Register()
    # TODO: write unit test
    register_1.set_eightbit_call(RenderType)


# Generated at 2022-06-26 04:25:48.445341
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_0 = Register()
    register_0.unmute()
    register_0.set_eightbit_call(None)
    register_0.set_rgb_call(None)
    register_0.set_renderfunc(None, None)
    register_0.mute()
    register_0.unmute()
    register_0.as_dict()
    register_0.as_namedtuple()
    register_0.copy()
    register_0.update(None)
    register_0.fromkeys(None, None)
    register_0.setdefault(None, None)
    register_0.pop(None, None)
    register_0.popitem()
    register_0.get(None, None)
    register_0.clear()

# Generated at 2022-06-26 04:25:51.533096
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RgbFg)


# Generated at 2022-06-26 04:25:55.483210
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(type(RenderType.ANSI))


# Generated at 2022-06-26 04:25:59.851030
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    assert str(register_0)  == "<class 'sty.Register'>"


# Generated at 2022-06-26 04:26:02.671742
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert isinstance(register_0, Register), "Register Object is not of type Register"



# Generated at 2022-06-26 04:26:08.715572
# Unit test for constructor of class Register
def test_Register():
    import pytest

    register = Register()

    assert isinstance(register, Register)
    assert register.as_dict() == {}
    assert type(register.as_namedtuple()) == namedtuple("StyleRegister", []).__class__

    with pytest.raises(AttributeError):
        register.eightbit_call(42)

    with pytest.raises(AttributeError):
        register.rgb_call(42, 42, 42)



# Generated at 2022-06-26 04:26:12.887901
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    assert style_0.rules == tuple()
    assert str(style_0) == ''
    assert isinstance(style_0, Style)



# Generated at 2022-06-26 04:26:36.460262
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    assert(register_0.is_muted == False)
    register_0.mute()
    assert(register_0.is_muted == True)
    register_0.unmute()
    assert(register_0.is_muted == False)


# Generated at 2022-06-26 04:26:41.451352
# Unit test for constructor of class Style
def test_Style():
    mystyle = Style(RgbFg(1, 2, 3), Sgr(1))
    assert isinstance(mystyle, Style)
    assert isinstance(mystyle, str)
    assert str(mystyle) == '\x1b[38;2;1;2;3m\x1b[1m'
    assert mystyle.rules == (RgbFg(1, 2, 3), Sgr(1))
    assert mystyle == "\\x1b[38;2;1;2;3m\\x1b[1m"

# Generated at 2022-06-26 04:26:44.631400
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_1 = Register()
    register_1.set_rgb_call(42)


# Generated at 2022-06-26 04:26:55.115297
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_0.eightbit_call = lambda x: x
    register_0.rgb_call = lambda r, g, b: (r, g, b)
    register_0.set_renderfunc(RenderType, lambda r: r)
    copy_of_register_0 = register_0.copy()

    register_0.set_eightbit_call(RenderType)
    register_0.set_rgb_call(RenderType)
    register_0.set_renderfunc(RenderType, lambda r: r)

    assert register_0 == register_0
    assert register_0 is not copy_of_register_0
    assert register_0.eightbit_call != copy_of_register_0.eightbit_call
    assert register_0.rgb_call != copy_of_register

# Generated at 2022-06-26 04:27:03.386545
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .bg import bg
    from .rendertype import RgbBg

    def ok(x, y):
        assert x == y

    # A Register object with attributes color_1-color_6
    register = Register()
    register.color_1 = Style(RgbBg(0, 0, 0))
    register.color_2 = Style(RgbBg(1, 2, 3))
    register.color_3 = Style(RgbBg(2, 3, 4))
    register.color_4 = Style(RgbBg(3, 4, 5))
    register.color_5 = Style(RgbBg(4, 5, 6))
    register.color_6 = Style(RgbBg(5, 6, 7))


# Generated at 2022-06-26 04:27:13.441938
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    register.red = Style('\x1b[31m')
    register.green = Style('\x1b[32m')
    register.blue = Style('\x1b[34m')
    register.yellow = Style('\x1b[33m')
    register.magenta = Style('\x1b[35m')
    register.cyan = Style('\x1b[36m')
    register.white = Style('\x1b[37m')
    register.black = Style('\x1b[30m')
    # Run test
    result = register.as_namedtuple()
    # Make assertions
    assert result.red == '\x1b[31m'
    assert result.green == '\x1b[32m'

# Generated at 2022-06-26 04:27:14.977219
# Unit test for method copy of class Register
def test_Register_copy():
    test_case_0()


# Generated at 2022-06-26 04:27:22.485143
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    """
    This function tests the __setattr__ method of the Register class.
    """
    register_0 = Register()
    register_0.set_renderfunc(RenderType.ANSI_256, lambda x: f"\x1b[38;5;{x}m")
    register_0.fg = Style(RenderType.ANSI_256(150))
    assert register_0.fg == "\x1b[38;5;150m"

# Generated at 2022-06-26 04:27:32.702345
# Unit test for constructor of class Style
def test_Style():
    # We need this so that 'pytest' does not try to
    # import the imported classes.
    import sty.rgb256_rgb as rgb256_rgb
    import sty.sgr as sgr
    import sty.rgb256_fg as rgb256_fg
    import sty.rgb256_bg as rgb256_bg

    Style(rgb256_rgb.RgbFg(1, 5, 10), sgr.Sgr(1))



# Generated at 2022-06-26 04:27:44.537350
# Unit test for constructor of class Style
def test_Style():
    bg = Register()
    bg.red = Style(RgbBg(255, 0, 0))
    assert str(bg.red) == "\x1b[48;2;255;0;0m"
    assert list(bg.red.rules) == [RgbBg(255, 0, 0)]

    bg.blue = Style(RgbBg(0, 0, 255))
    assert str(bg.blue) == "\x1b[48;2;0;0;255m"
    assert list(bg.blue.rules) == [RgbBg(0, 0, 255)]


# Generated at 2022-06-26 04:28:24.604864
# Unit test for constructor of class Style
def test_Style():
    Style()



# Generated at 2022-06-26 04:28:35.143190
# Unit test for method __setattr__ of class Register

# Generated at 2022-06-26 04:28:48.299298
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_1 = Register()
    style_0 = Style(value="")
    style_1 = Style(value="")
    style_2 = Style(value="")
    style_3 = Style(value="")
    style_4 = Style(value="")
    style_5 = Style(value="")
    style_6 = Style(value="")
    style_7 = Style(value="abc")
    style_8 = Style(value="abc")
    style_9 = Style(value="abc")
    style_10 = Style(value="abc")
    style_11 = Style(value="abc")
    style_12 = Style(value="abc")
    style_13 = Style(value="abc")
    style_14 = Style(value="abc")
    style_15 = Style(value="abc")
    style_16 = Style

# Generated at 2022-06-26 04:28:53.149493
# Unit test for constructor of class Style
def test_Style():
    test_style = Style("a", "b", value="c")
    assert repr(test_style).startswith("Style")
    assert test_style.rules == ("a", "b")


# Generated at 2022-06-26 04:28:58.668676
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    from .rendertypes import Xf256
    from .color.eightbitcolor import EightbitFg
    from . import render_to_ansi

    register_0 = Register()
    register_0.renderfuncs.update({
        EightbitFg: render_to_ansi.fg_8bit_ansi_code,
    })
    register_0.set_eightbit_call(Xf256)

    assert isinstance(register_0.eightbit_call, Callable)



# Generated at 2022-06-26 04:29:00.246775
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    style_register = register_0.as_namedtuple()
    assert isinstance(style_register, namedtuple)


# Unit Test for method as_dict of class Register

# Generated at 2022-06-26 04:29:09.307560
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    register_1 = Register()
    register_2 = Register()
    register_3 = Register()
    register_4 = Register()

    RenderType_0 = RenderType
    RenderType_1 = RenderType
    RenderType_2 = RenderType
    RenderType_3 = RenderType
    RenderType_4 = RenderType

    def func_0(arg_0: RenderType):
        return
    
    register_0.set_renderfunc(RenderType_0, func_0)
    register_1.set_renderfunc(RenderType_1, func_0)
    register_0.set_renderfunc(RenderType_2, func_0)
    register_0.set_renderfunc(RenderType_3, func_0)

# Generated at 2022-06-26 04:29:14.609273
# Unit test for method mute of class Register
def test_Register_mute():
    register_1 = Register()
    register_1.mute()
    assert register_1.is_muted == True
