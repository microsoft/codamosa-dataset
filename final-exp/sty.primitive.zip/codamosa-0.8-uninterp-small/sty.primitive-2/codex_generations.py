

# Generated at 2022-06-26 04:19:26.893400
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.__call__('')


# Generated at 2022-06-26 04:19:28.919564
# Unit test for constructor of class Register
def test_Register():
    register_0: Register

    register_0 = Register()



# Generated at 2022-06-26 04:19:32.387233
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0.is_muted == False
    assert isinstance(register_0, Register)
    assert register_0 is not None


# Generated at 2022-06-26 04:19:33.837608
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)

# Unit tests for method Register.__setattr__

# Generated at 2022-06-26 04:19:35.436429
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()



# Generated at 2022-06-26 04:19:42.698640
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    assert(register_0("test") == "")
    assert(register_0(0, 2) == "")
    assert(register_0(0, 2, 3, 4, keep=3) == "")
    assert(register_0(0, 2, 3, 4, keep=4) == "")


# Generated at 2022-06-26 04:19:46.602380
# Unit test for constructor of class Register
def test_Register():
    register_1 = Register()
    assert(isinstance(register_1, Register))


# Generated at 2022-06-26 04:19:47.977841
# Unit test for constructor of class Register
def test_Register():
    test_case_0()

# Generated at 2022-06-26 04:19:55.462196
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    new_instance = register_0.copy()
    assert isinstance(new_instance, Register)
    register_0.mute()
    assert register_0.is_muted == True
    register_0.unmute()
    assert register_0.is_muted == False
    register_0.__call__(144)
    register_0.as_dict()

if __name__ == "__main__":
    test_case_0()
    test_Register()

# Generated at 2022-06-26 04:20:02.179128
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0.renderfuncs == {}
    assert register_0.is_muted == False
    assert register_0.eightbit_call == register_0.eightbit_call
    assert register_0.rgb_call == register_0.rgb_call


# Generated at 2022-06-26 04:20:17.114410
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Test if function raises error if initialized with input of wrong type
    register = Register()
    assert isinstance(register, Register)
    try:
        register.set_eightbit_call(1)
        assert False
    except TypeError:
        assert True
    try:
        register.set_eightbit_call(1.1)
        assert False
    except TypeError:
        assert True
    try:
        register.set_eightbit_call([1])
        assert False
    except TypeError:
        assert True
    try:
        register.set_eightbit_call({"a": 1})
        assert False
    except TypeError:
        assert True
    
    # Test if function raises error if initialized with input of wrong type
    register = Register()
    assert isinstance(register, Register)

# Generated at 2022-06-26 04:20:28.236562
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from .Sty import Sty
    from .rendertype import RgbFg, RgbBg, Ef, Rs

    fg = Sty().fg
    register_0 = Register()
    register_0.renderfuncs = {RgbFg: lambda r, g, b: (f"{r}, {g}, {b}")}

    register_0.red = Style(RgbFg(255,0,0))
    register_0.blue = Style(RgbFg(0,0,255))

    namedtuple_0 = register_0.as_namedtuple()
    assert namedtuple_0.red == "255, 0, 0"
    assert namedtuple_0.blue == "0, 0, 255"


# Generated at 2022-06-26 04:20:33.388716
# Unit test for method __new__ of class Style
def test_Style___new__():
    Style(
        RenderType.Foreground(color=8),
        RenderType.Background(color=16),
        value="\x1b[38;5;8m\x1b[48;5;16m",
    )

# Generated at 2022-06-26 04:20:36.122939
# Unit test for constructor of class Style
def test_Style():
    style = Style("foo")
    assert isinstance(style, Style)
    assert isinstance(style, str)
    assert str(style) == "foo"


# Generated at 2022-06-26 04:20:40.269751
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    assert isinstance(register_0.copy(), type(register_0))


# Generated at 2022-06-26 04:20:43.477862
# Unit test for method mute of class Register
def test_Register_mute():
    # Test 1
    register_0 = test_case_0()
    register_0.mute()


# Generated at 2022-06-26 04:20:53.702440
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)
    register_0.set_rgb_call(RenderType)
    register_0.bla = Style(RenderType("a"))
    register_0.blub = Style(RenderType("b"))
    result = register_0.as_namedtuple()
    assert result == namedtuple('StyleRegister', ['bla', 'blub'])('\x1b[a', '\x1b[b')


# Generated at 2022-06-26 04:21:01.916819
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style("foo", value="\x1b[38;2;1;5;10m\x1b[1m")
    style_0.rules = ("foo",)
    style_1 = Style(value="\x1b[38;2;1;5;10m\x1b[1m")
    style_1.rules = ()
    style_2 = Style(value="\x1b[38;2;1;5;10m\x1b[1m", *("foo",))
    style_2.rules = ("foo",)


# Generated at 2022-06-26 04:21:11.442746
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # test for 
    register_0 = Register()
    register_0.set_eightbit_call("RgbFg")
    register_0.set_eightbit_call("RgbFg")
    register_0.set_eightbit_call("RgbFg")
    register_0.set_eightbit_call("RgbFg")
    register_0.set_eightbit_call("RgbFg")
    assert register_0.eightbit_call("RgbFg")


# Generated at 2022-06-26 04:21:16.157044
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.mute()
    register_0.unmute()
    assert register_0.is_muted == False


# Generated at 2022-06-26 04:21:27.119839
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Unit test: Test function set_renderfunc of class Register.
    """
    from aiosty.rendertype import Ascii256Fg, Ascii256Bg, RgbFg, RgbBg, Sgr

    def render_func_0(*args, **kwargs) -> str:
        return "<<RENDERFUNC-0>>"

    def render_func_1(*args, **kwargs) -> str:
        return "<<RENDERFUNC-1>>"

    def render_func_2(*args, **kwargs) -> str:
        return "<<RENDERFUNC-2>>"

    register_0 = Register()

    register_0.set_renderfunc(Ascii256Fg, render_func_0)

# Generated at 2022-06-26 04:21:34.310217
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    def rgb_color(*args):
        return True

    register_0.set_rgb_call(rendertype = RenderType, func = rgb_color)
    assert(register_0.rgb_call(1, 2, 3) == True)

# Generated at 2022-06-26 04:21:37.779408
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_1 = Register()
    register_1.asdf = Style(value="asdf")
    assert getattr(register_1, "asdf") == "asdf"


# Generated at 2022-06-26 04:21:39.998245
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()
    assert register_0.is_muted == True


# Generated at 2022-06-26 04:21:41.640121
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.mute()
    assert(r.is_muted == True)


# Generated at 2022-06-26 04:21:44.098553
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register = Register()

    register.foo = Style()
    assert register.foo == ""


# Generated at 2022-06-26 04:21:48.095480
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.mute()
    register_0.is_muted = True
    register_0.unmute()
    assert register_0.is_muted == False


# Generated at 2022-06-26 04:21:55.918238
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_1 = Register()
    register_1.fg = Style(RgbFg(10,20,30),Sgr(1)) # bold
    register_1.bg = Style(RgbBg(20,30,40),Sgr(1))
    assert register_1.as_dict() == {'fg': '\x1b[38;2;10;20;30m\x1b[1m', 'bg': '\x1b[48;2;20;30;40m\x1b[1m'}
    # Test for muted register
    register_1.mute()
    assert register_1.as_dict() == {'fg': '', 'bg': ''}


# Generated at 2022-06-26 04:22:02.380193
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class DummyRenderType(RenderType):
        pass

    register_0 = Register()

    def func(line):
        return line

    register_0.set_renderfunc(DummyRenderType, func)

    assert register_0.renderfuncs[DummyRenderType] == func



# Generated at 2022-06-26 04:22:05.972800
# Unit test for method __call__ of class Register
def test_Register___call__():
    assert repr(Register.__call__.__name__) == repr("__call__")
    assert callable(getattr(Register, Register.__call__.__name__, None))


# Generated at 2022-06-26 04:22:14.762272
# Unit test for constructor of class Style
def test_Style():
    o = Style(fg=3, bg=5)
    assert(str(o)=='\x1b[38;5;3m\x1b[48;5;5m')


# Generated at 2022-06-26 04:22:18.254280
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_1 = Register()
    register_1.test_attr = Style()
    assert isinstance(register_1.test_attr, Style)


# Generated at 2022-06-26 04:22:23.137240
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    # set default renderfuncs
    register_0 = Register()
    register_1 = Register()
    register_2 = Register()


    def func(r=None, g=None, b=None):
        return b

    register_0.set_renderfunc(RenderType, func)
    assert register_0.renderfuncs.get(RenderType) == func
    assert register_1.renderfuncs.get(RenderType) != func
    assert register_2.renderfuncs.get(RenderType) != func



# Generated at 2022-06-26 04:22:28.168407
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    import pytest
    register_0 = Register()
    register_0.set_eightbit_call(RgbFg)
    assert register_0.eightbit_call == register_0.renderfuncs.get(RgbFg)



# Generated at 2022-06-26 04:22:31.429063
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()
    assert register_0.is_muted == True


# Generated at 2022-06-26 04:22:36.955366
# Unit test for method __new__ of class Style
def test_Style___new__():

    def _test():
        # Test0: test if instance is subclass of str.
        s0 = Style(value="\x1b[38;2;1;5;10m\x1b[1m")
        assert isinstance(s0, Style)
        assert isinstance(s0, str)
        assert str(s0) == "\x1b[38;2;1;5;10m\x1b[1m"

    _test()



# Generated at 2022-06-26 04:22:41.528327
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def func_0() -> str:
        return "RENDER FUNC 0"

    register = Register()

    register.set_renderfunc(Type, func_0)

    assert register.renderfuncs[Type] == func_0



# Generated at 2022-06-26 04:22:47.279371
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style(RgbFg(1, 5, 10), Sgr(1))
    style_1 = Style(RgbFg(2, 3, 4), RgbEf(5, 6, 7), Sgr(1))
    style_2 = Style(RgbFg(1, 5, 10), Sgr(1), value="\x1b[38;2;1;5;10m\x1b[1m")


# Generated at 2022-06-26 04:22:52.404063
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    assert register_0('', ) == ''
    assert register_0(1, 2) == ''
    assert register_0(5) == ''
    assert register_0(str()) == ''
    assert register_0(str(), str(), 8) == ''
    assert register_0() == ''
    assert register_0(str(), str(), str()) == ''


# Generated at 2022-06-26 04:22:57.266960
# Unit test for constructor of class Style
def test_Style():
    style_obj = Style("\x1b[1m")
    style_obj2 = Style("\x1b[2K", "\x1b[1m")

    assert style_obj == "\x1b[1m"
    assert style_obj2 == "\x1b[2K\x1b[1m"
    assert style_obj2.rules == ("\x1b[2K", "\x1b[1m")
    assert isinstance(style_obj, Style)
    assert isinstance(style_obj, str)



# Generated at 2022-06-26 04:23:05.075468
# Unit test for constructor of class Style
def test_Style():
    s0 = Style()
    assert isinstance(s0, Style), f"Style() is not of type Style type."



# Generated at 2022-06-26 04:23:12.891335
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # create new object
    register_0 = Register()
    # set the ansi sequence for black (standard)
    register_0.black = Style('\x1b[30m')
    # set the ansi sequence for red (standard)
    register_0.red = Style('\x1b[31m')
    # set the ansi sequence for green (standard)
    register_0.green = Style('\x1b[32m')
    # set the ansi sequence for yellow (standard)
    register_0.yellow = Style('\x1b[33m')
    # set the ansi sequence for blue (standard)
    register_0.blue = Style('\x1b[34m')
    # set the ansi sequence for magenta (standard)

# Generated at 2022-06-26 04:23:18.644159
# Unit test for method __call__ of class Register
def test_Register___call__():
    """Runs the unit test for method __call__ of class Register"""

    register_0 = Register()
    register_0.set_renderfunc(RenderType.SGR_EIGHT_BIT_FOREGROUND, lambda x: x)
    str_0 = register_0(42)
    assert str_0 == 42


# Generated at 2022-06-26 04:23:24.366217
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    # Python 3.6+ guarantees dict order
    # So it is safe to test the dict keys
    register_0.set_renderfunc(RenderType, lambda x: x)
    for i in range(0x10):
        setattr(register_0, f"attr_{i:x}", f"attr_{i:x}")
    register_0.mute()
    assert not set(register_0.as_dict().keys()) - {'attr_0', 'attr_1', 'attr_2', 'attr_3', 'attr_4', 'attr_5', 'attr_6', 'attr_7', 'attr_8', 'attr_9', 'attr_a', 'attr_b', 'attr_c', 'attr_d', 'attr_e', 'attr_f'}
    register_

# Generated at 2022-06-26 04:23:28.336775
# Unit test for method mute of class Register
def test_Register_mute():
    register = Register()
    setattr(register, "a", Style(Sgr(1)))
    register.mute()
    assert register.a == ""


# Generated at 2022-06-26 04:23:39.689140
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Define a new render type.
    class RenderType_0(RenderType):
        pass

    # Create a new register.
    register_0 = Register()

    # Add a new render funcion to the render func dict.
    register_0.renderfuncs.update({RenderType_0: lambda r, g, b: ("Arguments", r, g, b)})

    # Set the render func for RGB calls to RenderType
    register_0.set_rgb_call(RenderType_0)

    # Make a RGB call.
    var_1 = register_0(1, 2, 3)

    # Check if fg was called with the correct arguments.

# Generated at 2022-06-26 04:23:43.287775
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    from .rendertype import RgbBg

    register_0.set_rgb_call(RgbBg)
    assert register_0.rgb_call == register_0.renderfuncs[RgbBg]



# Generated at 2022-06-26 04:23:48.843059
# Unit test for method unmute of class Register
def test_Register_unmute():
    
    from .render import EraseScreen, EraseFromCursorDown, EraseFromCursorUp, EraseLine

    sgr = EraseScreen()
    register = Register()
    register.set_renderfunc(EraseScreen, lambda: sgr.ansi)
    
    register.unmute()
    assert register.is_muted == False, 'The mute state was not set correctly'
    

# Generated at 2022-06-26 04:23:54.283430
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbFg, Rgb256Fg
    from .rendertype import Style8BitBg, Style8BitFg
    from .rendertype import Bg, Fg

    # Make a copy of the default foreground register which uses the
    # default rendertype-classes:
    fg = Fg.copy()
    bg = Bg.copy()

    def rgb_fg_renderfunc(r: int, g: int, b: int) -> str:
        return "\x1b[38;2;{};{};{}m".format(r, g, b)


# Generated at 2022-06-26 04:23:57.490059
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    namedtuple_0 = register_0.as_namedtuple()
    assert(namedtuple_0 == register_0.as_namedtuple())


# Generated at 2022-06-26 04:24:18.505481
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # create and fill register
    register = Register()
    register.set_eightbit_call(lambda x: "")
    register.set_rgb_call(lambda r, g, b: "")
    register.set_renderfunc(
        lambda a, b, c, d: "",
        lambda a, b, c, d: "",
    )
    register.a = "a"
    register.b = "b"
    register.c = "c"
    register.d = "d"
    # create namedtuple
    nt = register.as_namedtuple()
    # check that all entries are found in the namedtuple
    assert nt.a == "a"
    assert nt.b == "b"
    assert nt.c == "c"

# Generated at 2022-06-26 04:24:26.245254
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_1 = Register()
    register_1.rule_1 = Style(value="style_1")
    register_1.rule_2 = Style(value="style_2")
    register_1.rule_1 = Style(value="modified_1")
    assert(register_1.rule_1 == "modified_1")
    assert(register_1.rule_2 == "style_2")


if __name__ == "__main__":
    test_case_0()
    test_Register___setattr__()

# Generated at 2022-06-26 04:24:32.490377
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    func_0 = lambda *a: '.'.join(str(v) for v in a)
    register_0.set_renderfunc(RgbFg, func_0)
    assert register_0.renderfuncs[RgbFg] == func_0
    assert register_0.renderfuncs[RgbBg] == func_0
    assert register_0.renderfuncs[RgbEf] == func_0
    assert register_0.renderfuncs[RgbRs] == func_0


# Generated at 2022-06-26 04:24:40.105417
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    rendertype_0: Type[RenderType] = RenderType

    # Test case 0
    register_0 = Register()
    register_0.set_renderfunc(rendertype_0, lambda x: x)

    # Test case 1
    register_1 = Register()
    register_1.set_renderfunc(rendertype_0, lambda x: x)


# Generated at 2022-06-26 04:24:46.402359
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    test_register = Register()

    test_register.set_renderfunc(RenderType, lambda x: "test")
    test_register.test_1 = Style(RenderType(), Sgr(7))
    test_register.test_2 = Style(RenderType(), Sgr(1))

    assert test_register.as_dict() == {'test_1': 'testtest', 'test_2': 'testtest'}

# Generated at 2022-06-26 04:24:48.467866
# Unit test for constructor of class Register
def test_Register():
    register_0 = test_case_0()
    # Test if created object is of type Register
    assert isinstance(register_0, Register)



# Generated at 2022-06-26 04:24:57.921043
# Unit test for method copy of class Register
def test_Register_copy():
    from copy import copy

    # Test copy copy method
    reg0 = Register()
    reg1 = reg0.copy()

    # Assert that a set item on reg0 does not alter reg1
    reg0.black = "foo"
    assert reg1.black != reg0.black

    # Test attribute is_muted
    reg0.mute()
    reg1 = reg0.copy()

    assert reg0.is_muted == reg1.is_muted

    # Test attribute eightbit_call
    reg0.set_eightbit_call(RgbFg)
    reg1 = reg0.copy()

    assert reg0.eightbit_call != reg1.eightbit_call

    # Test attribute rgb_call
    reg0.set_rgb_call(RgbFg)
    reg1 = reg0

# Generated at 2022-06-26 04:25:10.055973
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import RgbBg, RgbFg, RgbEf, RgbRs

    register_0 = Register()

    register_0.set_renderfunc(RgbBg, lambda r, g, b: (r, g, b))
    register_0.set_renderfunc(RgbFg, lambda r, g, b: (r, g, b))
    register_0.set_renderfunc(RgbEf, lambda r, g, b: (r, g, b))
    register_0.set_renderfunc(RgbRs, lambda r, g, b: (r, g, b))

    register_0.set_eightbit_call(RgbBg)
    register_0.set_eightbit_call(RgbFg)
    register_0.set_eightbit_call

# Generated at 2022-06-26 04:25:15.219564
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    # Create register
    register_0 = Register()

    # Create style attribute
    register_0.style_0 = Style(value="\x1b[38;2;255;255;255m")

    # Create named tuple from register
    namedtuple_0: namedtuple = register_0.as_namedtuple()

    # Assert attributes
    assert namedtuple_0.style_0 == "\x1b[38;2;255;255;255m"


# Generated at 2022-06-26 04:25:26.146289
# Unit test for constructor of class Style
def test_Style():
    from .sgr import Sgr
    from .rgb import RgbFg
    fg = Register()
    colour = Style( RgbFg(1,5,10), Sgr(1) )
    assert isinstance(colour, Style), "Needs to be of type Style"
    assert isinstance(colour, str), "Needs to be of type str"
    assert str(colour) == '\x1b[38;2;1;5;10m\x1b[1m', "Wrong ANSI sequence"
    fg.orange = Style(RgbFg(1,5,10), Sgr(1))
    colour2 = Style(RgbFg(1,5,10), Sgr(1))
    assert isinstance(fg.orange, Style), "Needs to be of type Style"

# Generated at 2022-06-26 04:25:58.943769
# Unit test for constructor of class Style
def test_Style():

    print("Testing Style...")
    print()

    class Sgr(RenderType):

        def __init__(self, value):
            self.args = (value,)

        @staticmethod
        def render(value):
            return f"\x1b[{value}m"

    class RgbFg(RenderType):

        def __init__(self, r, g, b):
            self.args = (r, g, b)

        @staticmethod
        def render(r, g, b):
            return f"\x1b[38;2;{r};{g};{b}m"

    class RgbBg(RenderType):

        def __init__(self, r, g, b):
            self.args = (r, g, b)


# Generated at 2022-06-26 04:26:03.771690
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbFg, RgbBg

    register_0 = Register()

    register_0.set_rgb_call(RgbFg)

    assert(register_0.rgb_call == register_0.renderfuncs[RgbFg])


# Generated at 2022-06-26 04:26:07.875171
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    class RgbFg(RenderType):
        pass

    class RgbBg(RenderType):
        pass

    register_0 = Register()
    register_0.set_eightbit_call(RgbBg)
    register_0.set_eightbit_call(RgbFg)


# Generated at 2022-06-26 04:26:09.908048
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()


# Generated at 2022-06-26 04:26:12.717467
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(RgbFg)


# Generated at 2022-06-26 04:26:16.912187
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()
    assert register_0.is_muted == False


# Generated at 2022-06-26 04:26:23.152373
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_0.eightbit_call = lambda *args, **kwargs: 'abc'
    copy_1 = register_0.copy()
    assert copy_1.eightbit_call == register_0.eightbit_call


# Generated at 2022-06-26 04:26:27.488064
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    assert isinstance(test_case_0().as_namedtuple(), NamedTuple)


# Generated at 2022-06-26 04:26:32.846274
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_1 = Register()
    register_1.set_eightbit_call(RenderType)
    assert register_1.set_eightbit_call(RenderType) is None


# Generated at 2022-06-26 04:26:38.982187
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    copy_0 = register_0.copy()
    # Check if object created via copy method is same type as original object.
    assert type(register_0) == type(copy_0)
    # Check if object created via the copy method is different from original object.
    assert register_0 != copy_0


# Generated at 2022-06-26 04:28:06.294200
# Unit test for constructor of class Style
def test_Style():

    Style(RgbFg(10, 20, 30), RgbFg(40, 50, 60))

    # Test if rendertype args are passed correctly
    rendertype = RgbFg(10, 20, 30)
    rendertype.args = (10, 20, 30)

    Style(rendertype, RgbFg(40, 50, 60))

    try:
        Style(10, 20, 30)
        raise AssertionError("__init__() takes 1 positional argument but 3 were given")
    except TypeError:
        pass


# Generated at 2022-06-26 04:28:14.745471
# Unit test for method mute of class Register
def test_Register_mute():

    register_1 = Register()

    register_1.magenta = Style("\x1b[38;5;201m")

    assert isinstance(register_1.magenta, Style)
    assert register_1.magenta == Style("\x1b[38;5;201m")

    register_1.mute()

    assert isinstance(register_1.magenta, Style)
    assert register_1.magenta == Style("")


# Generated at 2022-06-26 04:28:26.789455
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.fg = Style("\x1b[38;5;23m")
    assert register_0('fg') == "\x1b[38;5;23m"
    register_0.bg = Style("\x1b[48;5;42m")
    assert register_0('fg') == "\x1b[38;5;23m"
    register_0.ef = Style("\x1b[1m")
    assert register_0('fg') == "\x1b[38;5;23m"
    register_0.ef = Style("\x1b[1m", "\x1b[3m")
    assert register_0('fg') == "\x1b[38;5;23m"

# Generated at 2022-06-26 04:28:31.775178
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.__setattr__("is_muted", False)
    register_0.__setattr__("eightbit_call", lambda x: x)
    register_0.__setattr__("rgb_call", lambda r, g, b: (r, g, b))
    register_0.__setattr__("_Register__renderfuncs", {RenderType: lambda: None})
    StylingRule.__setattr__(Style, "rules", [])


# Generated at 2022-06-26 04:28:37.674992
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    from .rendertype import RgbBg, RgbFg, SgrFg, SgrBg, Reset, EightBitFg, EightBitBg
    from .renderfunc import render_sgr_fg, render_sgr_bg, render_rgb_fg, render_rgb_bg, render_reset
    from .eightbit import ANSIColor

    register = Register()
    register.set_renderfunc(SgrFg, render_sgr_fg)
    register.set_renderfunc(SgrBg, render_sgr_bg)
    register.set_renderfunc(RgbFg, render_rgb_fg)
    register.set_renderfunc(RgbBg, render_rgb_bg)
    register.set_renderfunc(Reset, render_reset)

    # Test muted register


# Generated at 2022-06-26 04:28:44.078282
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)
    assert register_0.eightbit_call == register_0.renderfuncs[RenderType]


# Generated at 2022-06-26 04:28:50.418251
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    """
    Unit test for method as_dict of class Register
    """

    import sty

    sty.rgb = sty.Register()
    sty.rgb.red = sty.Style(sty.RgbFg(255, 0, 0))
    sty.rgb.green = sty.Style(sty.RgbFg(0, 255, 0))
    sty.rgb.blue = sty.Style(sty.RgbFg(0, 0, 255))

    assert sty.rgb.as_dict() == {'red': '\x1b[38;2;255;0;0m', 
                                     'green': '\x1b[38;2;0;255;0m', 
                                     'blue': '\x1b[38;2;0;0;255m'}


# Generated at 2022-06-26 04:28:53.656797
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.set_rgb_call(int)
    assert register_0.rgb_call == int

# Generated at 2022-06-26 04:28:56.282741
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0.renderfuncs == dict() and register_0.is_muted == False


# Generated at 2022-06-26 04:28:58.126372
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.__call__(1)
    register_0.__call__(2, 3)
    register_0.__call__(4, 5, 6)

