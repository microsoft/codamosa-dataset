

# Generated at 2022-06-26 04:19:32.224774
# Unit test for constructor of class Style
def test_Style():
    style = Style(1, 2, 3)  # type: ignore
    v: int = style.rules[0]
    assert v == 1

    rules: Iterable[StylingRule] = (1,  Style(2, 3))
    style2 = Style(*rules)    # type: ignore
    assert style2.rules[0] == 1
    assert style2.rules[1].rules[0] == 2

# Generated at 2022-06-26 04:19:35.448747
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_0.set_eightbit_call(rendertype=None)
    # No errors

# Generated at 2022-06-26 04:19:40.311390
# Unit test for constructor of class Register
def test_Register():
    assert_exception(test_case_0, "Style has no attribute 'renderfuncs'")


RegisterCase = namedtuple("RegisterCase", ["register", "name_attr", "expected_value"])



# Generated at 2022-06-26 04:19:43.967564
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    register.blue = Style(Ef("blue"))
    register.green = Style(Ef("green"))

    t = register.as_namedtuple()
    assert t._fields == ("blue", "green")
    assert t.blue == "\x1b[94m"
    assert t.green == "\x1b[92m"



# Generated at 2022-06-26 04:19:45.137011
# Unit test for constructor of class Register
def test_Register():

    register = Register()
    assert isinstance(register, Register)

# Generated at 2022-06-26 04:19:48.360733
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()

    # All attributes should be ''
    for name in dir(register_0):
        val = getattr(register_0, name)
        if isinstance(val, str):
            assert val == ''


# Generated at 2022-06-26 04:19:51.344664
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    reg = Register()
    reg.test = Style(value="test", rules=[])
    assert(reg.test == "test")


# Generated at 2022-06-26 04:19:58.837568
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    def test_func_0(x: int) -> str:
        return f"A {x}"

    def test_func_1(x: int) -> str:
        return f"B {x}"

    class TestRenderType_0(RenderType):
        pass

    class TestRenderType_1(RenderType):
        pass

    register_0 = Register()

    #  First set rendertype 0
    register_0.set_renderfunc(TestRenderType_0, test_func_0)

    # Check if renderfunc for rendertype 0 was set correctly
    assert register_0.renderfuncs[TestRenderType_0] == test_func_0, "Renderfunc was not set correctly"
    # Check if renderfunc for rendertype 1 was not set

# Generated at 2022-06-26 04:20:06.515516
# Unit test for method __new__ of class Style
def test_Style___new__():

    # Empty class Style
    class Style_test_0(Style):
        pass

    # Instance initialisation:
    style_0 = Style_test_0()

    # Check if object is initialised and of type Style_test_0
    assert isinstance(style_0, Style_test_0)

    # Check if Style_test_0 and Style_test_0.__str__() are of type str
    assert isinstance(Style_test_0, str)
    assert isinstance(Style_test_0.__str__(), str)


# Generated at 2022-06-26 04:20:08.349485
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    assert style_0 == ''


# Generated at 2022-06-26 04:20:13.653699
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    style_register_0 = Register()
    style_register_namedtuple_0 = style_register_0.as_namedtuple()


# Generated at 2022-06-26 04:20:17.521234
# Unit test for method mute of class Register
def test_Register_mute():
    register = Register()
    register.mute()
    assert register.is_muted == True


# Generated at 2022-06-26 04:20:25.893725
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    class TestRenderType(RenderType):
        """
        A test render-type for fg, bg, ef and rs.
        """
        call_str = "test"

    register = Register()
    register.set_renderfunc(TestRenderType, lambda x: f"{TestRenderType.call_str}{x}")
    register.set_eightbit_call(TestRenderType)

    assert register(0) == "test0"
    assert register(42) == "test42"



# Generated at 2022-06-26 04:20:35.625368
# Unit test for method copy of class Register
def test_Register_copy():
    reg0 = Register()
    reg1 = Register()
    reg1.set_eightbit_call(str)
    reg0.mute()
    reg1.set_renderfunc(str, lambda x:  x + "test")
    reg0.set_renderfunc(str, lambda x:  x + "test")
    reg1.__setattr__("test", Style("", Sgr(1)))
    reg0.test = reg1.test
    reg2 = reg0.copy()


# Generated at 2022-06-26 04:20:40.931988
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.hello = Style("\x1b[38;2;1;5;10m", "hello")
    register_0.world = Style("\x1b[38;2;1;5;10m", "world")
    assert register_0.as_namedtuple() == namedtuple("StyleRegister", ['hello', 'world'])("\x1b[38;2;1;5;10m", "\x1b[38;2;1;5;10m")


# Generated at 2022-06-26 04:20:44.268669
# Unit test for constructor of class Style
def test_Style():
    style = Style()
    assert style is not None
    assert style.rules == ()


# Generated at 2022-06-26 04:20:52.297106
# Unit test for method __new__ of class Style
def test_Style___new__():

    s: Style = Style("a")
    assert (
        s == "a"
    ), "The initialization of Style fails when using a string as argument."

    s = Style(Style("a"))
    assert s == "a", "The initialization of Style fails when using a Style."



# Generated at 2022-06-26 04:21:02.809518
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    import json
    register_0 = Register()
    register_0.red = Style(value='\x1b[31m')
    register_0.blue = Style(value='\x1b[34m')
    register_0.green = Style(value='\x1b[32m')
    register_0.white = Style(value='\x1b[37m')
    register_0.yellow = Style(value='\x1b[33m')
    register_0.magenta = Style(value='\x1b[35m')
    register_0.cyan = Style(value='\x1b[36m')
    register_0._black = Style(value='\x1b[30m')
    d = register_0.as_dict()

# Generated at 2022-06-26 04:21:10.016377
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    r = Register()

    try:
        r.test = 21
    except ValueError:
        pass

    try:
        r.test2 = Style("Test")
    except ValueError:
        pass


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:21:13.199609
# Unit test for method __new__ of class Style
def test_Style___new__():

    register_0 = Register()

    # Prepare fg.red as Style reference
    fg_red = getattr(getattr(register_0, "fg"), "red")

    assert isinstance(fg_red, Style)
    assert isinstance(fg_red, str)
    assert str(fg_red) == '\x1b[38;5;9m'



# Generated at 2022-06-26 04:21:19.031380
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.a = Style()
    assert isinstance(register_0.a, Style)


# Generated at 2022-06-26 04:21:24.521748
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_1 = Register()
    register_1.renderfuncs = {RgbFg: lambda r, g, b: (r, g, b)}
    register_1.set_eightbit_call(RgbFg)
    setattr(register_1, "registerblue", Style(RgbFg(144, 0, 255), Sgr(1)))
    expected = fg(144)
    assert register_1.registerblue == expected


# Generated at 2022-06-26 04:21:27.657943
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style('\x1b[0m')
    assert(style_0 == '\x1b[0m')


# Generated at 2022-06-26 04:21:41.097712
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from copy import deepcopy

    # Create a dummy render-function that returns '@' for every call.
    def _render_function(arg) -> str:
        return "@"

    # Create a dummy RenderType that takes a int as argument.
    class Dummy(RenderType):
        @classmethod
        def render(cls, *args) -> str:
            return _render_function(*args)

    register_0 = Register()

    # Register a render function for the render-type Dummy.
    register_0.set_renderfunc(Dummy, _render_function)

    # Create three styles named 'test_0', 'test_1' and 'test_2'.
    register_0.test_0 = Style(Dummy(42))
    register_0.test_1 = Style(Dummy(42), Dummy(42))

# Generated at 2022-06-26 04:21:43.100425
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()


# Generated at 2022-06-26 04:21:51.919470
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from .rendertype import RgbFg
    register_0 = Register()
    test_register = Register()
    test_register.test = RgbFg(0,0,0)
    test_register.test2 = Style(RgbFg(0,0,0),value="\x1b[38;2;0;0;0m")
    assert test_register.as_dict() == {"test": "\x1b[38;2;0;0;0m", "test2": "\x1b[38;2;0;0;0m"}, "Register.as_dict() returned unexpected value"


# Generated at 2022-06-26 04:21:54.095024
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.mute()
    assert(r.is_muted == True)



# Generated at 2022-06-26 04:22:02.556970
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    rendertype_0 = RenderType
    renderfunc_0 = lambda: None
    register_0 = Register()
    register_0.set_renderfunc(rendertype_0, renderfunc_0)
    register_0.set_eightbit_call(rendertype_0)
    assert register_0.eightbit_call == renderfunc_0


# Generated at 2022-06-26 04:22:06.210637
# Unit test for constructor of class Style
def test_Style():
    s: Style = Style("test", "test2")
    assert isinstance(s, Style)
    assert s.rules == ("test", "test2")
    assert str(s) == ""



# Generated at 2022-06-26 04:22:09.131608
# Unit test for constructor of class Style
def test_Style():
    new_style= Style("test", "test1", value="test")
    assert new_style.rules == ("test", "test1")
    assert str(new_style) == "test"


# Generated at 2022-06-26 04:22:15.532678
# Unit test for constructor of class Style
def test_Style():
    rule_0 = Style()


register_0 = Register()
register_0.set_eightbit_call(RenderType)
register_0.set_rgb_call(RenderType)
register_0.set_renderfunc(RenderType, lambda : None)
register_0.mute()
register_0.unmute()
register_0.as_dict()
register_0.as_namedtuple()
register_0.copy()

register_0()



# Generated at 2022-06-26 04:22:19.621566
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register = Register()
    register.test = "a"
    register.abc = "b"
    assert register.as_namedtuple() == namedtuple("StyleRegister", ["test", "abc"])("a", "b")



# Generated at 2022-06-26 04:22:22.358001
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    register_1 = Register()
    register_1.set_rgb_call(RgbFg)

    assert type(register_1.rgb_call) == type(register_1.eightbit_call) == type(lambda x:x)



# Generated at 2022-06-26 04:22:24.721863
# Unit test for constructor of class Style
def test_Style():
    rules = [""]
    style = Style(*rules)
    assert style.rules == rules



# Generated at 2022-06-26 04:22:29.886175
# Unit test for constructor of class Style
def test_Style():
    rule_0 = Style("test")
    assert isinstance(rule_0, Style) == True
    assert isinstance(rule_0, str) == True
    assert str(rule_0) == "test"


# Generated at 2022-06-26 04:22:30.891723
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()



# Generated at 2022-06-26 04:22:38.799807
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    class TestType0(RenderType):
        pass
    class TestType1(RenderType):
        pass
    mock_func: Callable = lambda x: x

    # Set new renderfunc
    register_0.set_renderfunc(TestType0, mock_func)
    assert register_0.renderfuncs == {TestType0: mock_func}

    # Overwrite renderfunc
    register_0.set_renderfunc(TestType0, mock_func)
    assert register_0.renderfuncs == {TestType0: mock_func}

    # Set other renderfunc
    register_0.set_renderfunc(TestType1, mock_func)
    assert register_0.renderfuncs == {TestType0: mock_func, TestType1: mock_func}



# Generated at 2022-06-26 04:22:45.869790
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_1 = Register()

    # Verify that an expected key error is thrown if you try to update
    # a renderfunc for a rendertype that was not registered before.
    try:
        register_1.set_renderfunc("Klasse", lambda x: x)
    except KeyError:
        pass
    else:
        raise ValueError("Expected 'KeyError' was not thrown.")


# Generated at 2022-06-26 04:22:49.648550
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():

    register_0 = Register()
    register_0.as_namedtuple()

    assert True

# Generated at 2022-06-26 04:22:55.737689
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Create a new register object
    register_1 = Register()
    
    # Define the rendertype and renderfunc for the new register object.
    rendertype = namedtuple("RenderType", ["name"])(name="foo")
    renderfunc = lambda: "bar"
    
    # Set rendertype and renderfunc
    register_1.set_renderfunc(rendertype, renderfunc)
    register_1.set_eightbit_call(rendertype)

    # Check if register_1 is callable with integers.
    assert register_1(1) == "bar"


# Generated at 2022-06-26 04:23:00.016349
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()


# Generated at 2022-06-26 04:23:10.544497
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # create a register object
    r1 = Register()
    # create some dummy style rules
    s1 = Style(rgbFg(102, 65, 49))
    s2 = Style(rgbFg(65, 178, 179))
    # assign dummy rules to register object
    r1.s1 = s1
    r1.s2 = s2
    # check if dummy rules are assigned
    assert getattr(r1, 's1') is s1
    assert getattr(r1, 's2') is s2
    # check if rules are exported as dict
    assert r1.as_dict() == {'s1': '\x1b[38;2;102;65;49m', 's2': '\x1b[38;2;65;178;179m'}


# Generated at 2022-06-26 04:23:12.440192
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()


# Generated at 2022-06-26 04:23:13.888058
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.mute()


# Generated at 2022-06-26 04:23:14.738075
# Unit test for constructor of class Register
def test_Register():
    assert test_case_0() == None

# Generated at 2022-06-26 04:23:22.817568
# Unit test for method __call__ of class Register
def test_Register___call__():

    class RgbType(RenderType):

        def __init__(self, r: int, g: int, b: int):
            self.r, self.g, self.b = r, g, b

    class Rgb24Fg(RgbType):
        pass

    class Rgb24Bg(RgbType):
        pass

    def render24(r, g, b):
        return f"{r}{g}{b}"

    register_0 = Register()
    register_0.set_renderfunc(Rgb24Fg, render24)
    register_0.set_renderfunc(Rgb24Bg, render24)
    assert register_0(102, 20, 34) == "1022034"

# Generated at 2022-06-26 04:23:35.899135
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Test case 0
    style_0 = Style()
    register_0 = Register()
    register_0.style_0 = style_0

    expected_0: Dict[str, str] = {
        'style_0': ''
    }
    result_0 = register_0.as_dict()

    assert result_0 == expected_0, 'style_0'

    # Test case 1
    style_1 = Style()
    register_1 = Register()
    register_1.style_1 = style_1

    expected_1: Dict[str, str] = {
        'style_1': ''
    }
    result_1 = register_1.as_dict()

    assert result_1 == expected_1, 'style_1'

    # Test case 2
    style_2 = Style()
    register_

# Generated at 2022-06-26 04:23:39.520654
# Unit test for method mute of class Register
def test_Register_mute():

    register_1 = Register()
    register_1.mute()

    assert register_1.is_muted == True, "Error in method 'mute' of class Register."



# Generated at 2022-06-26 04:23:41.334737
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    print(register_0.eightbit_call())


# Generated at 2022-06-26 04:23:43.288525
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_1 = Register()
    register_1.mute()
    register_1.unmute()


# Generated at 2022-06-26 04:23:51.009942
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    fg = Register()

    fg.red = Style(RgbFg(1, 5, 10), Sgr(1))

    fg.as_namedtuple()
    # assert fg.as_namedtuple() == StyleRegister(red='\x1b[38;2;1;5;10m\x1b[1m')


# Generated at 2022-06-26 04:23:57.451512
# Unit test for constructor of class Style
def test_Style():
    Style("\x1b[38;2;1;5;10m\x1b[1m")
    Style("\x1b[38;2;1;5;10m\x1b[1m", "\x1b[38;2;1;5;10m\x1b[1m")

# Generated at 2022-06-26 04:24:05.376532
# Unit test for constructor of class Style
def test_Style():
    assert Style(value='\x1b[1;30m\x1b[1;31m\x1b[1;32m\x1b[1;33m', rules=(Sgr(1), RgbFg(0, 0, 0), Sgr(1), RgbFg(12, 12, 12), Sgr(1), RgbFg(0, 42, 0), Sgr(1), RgbFg(42, 42, 0))) == '\x1b[1;30m\x1b[1;31m\x1b[1;32m\x1b[1;33m'


# Generated at 2022-06-26 04:24:08.123154
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    style_1 = Style(*(None,))
    style_2 = Style(value="")


# Generated at 2022-06-26 04:24:15.784656
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():

    # Create register
    register_0 = Register()

    # Add new renderfunc to register
    test_rendertype_1 = RenderType("test_rt_1")
    register_0.set_renderfunc(test_rendertype_1, lambda x: "rt1" + str(x))

    # Change eightbit_call
    register_0.set_eightbit_call(test_rendertype_1)

    # Test call of register_0
    assert register_0(10) == "rt110"


# Generated at 2022-06-26 04:24:16.596504
# Unit test for constructor of class Style
def test_Style():
    Style()

# Generated at 2022-06-26 04:24:18.083207
# Unit test for constructor of class Style
def test_Style():
    fg = Style()
    expected = Style()
    assert fg == expected


# Generated at 2022-06-26 04:24:22.168521
# Unit test for method __new__ of class Style
def test_Style___new__():
    from sty import fg as register_1
    assert isinstance(register_1, Register)
    assert isinstance(register_1.red, Style)
    assert isinstance(register_1.red, str)


# Generated at 2022-06-26 04:24:23.242464
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    pass


# Generated at 2022-06-26 04:24:29.345859
# Unit test for constructor of class Register
def test_Register():

    register_0 = Register()

    assert isinstance(register_0, Register)

    assert isinstance(register_0.renderfuncs, dict)

    assert register_0.eightbit_call is not None
    assert register_0.rgb_call is not None

    assert register_0.is_muted is False



# Generated at 2022-06-26 04:24:42.781533
# Unit test for method unmute of class Register
def test_Register_unmute():
    # Create object
    register = Register()
    # Check if register is muted
    assert register.is_muted == False
    # Mute
    register.mute()
    # Check if register is now muted
    assert register.is_muted == True
    # Unmute
    register.unmute()
    # Check if register is unmuted
    assert register.is_muted == False



# Generated at 2022-06-26 04:24:53.971453
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    reg = Register()
    reg.set_eightbit_call(RenderType.EIGHTBIT)
    reg.set_rgb_call(RenderType.RGB)
    reg.red = Style(RenderType.BOLD, RenderType.FG_8, 1)
    reg.green = Style(RenderType.BOLD, RenderType.FG_8, 2)
    reg.blue = Style(RenderType.BOLD, RenderType.FG_8, 4)

    style_register_tuple = reg.as_namedtuple()

    assert style_register_tuple.red == "\x1b[1m\x1b[38;5;1m"
    assert style_register_tuple.green == "\x1b[1m\x1b[38;5;2m"

# Generated at 2022-06-26 04:24:59.919832
# Unit test for method mute of class Register
def test_Register_mute():

    # Test case 0
    style_0 = Style()
    reg_0 = Register()
    reg_0.set_renderfunc(RenderType.STYLE_NONE, render_no_formatting)
    reg_0.set_renderfunc(RenderType.SGR, render_sgr)
    reg_0.set_renderfunc(RenderType.RGB_FG, render_rgb_fg)
    reg_0.set_renderfunc(RenderType.RGB_BG, render_rgb_bg)
    reg_0.set_renderfunc(RenderType.EIGHTBIT_FG, render_eightbit_fg)
    reg_0.set_renderfunc(RenderType.EIGHTBIT_BG, render_eightbit_bg)
    reg_0.test = Style(fg="red", bg="blue")
    reg_0

# Generated at 2022-06-26 04:25:03.595104
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    from sty import fg
    assert fg.red == "\x1b[38;2;255;0;0m"
    assert fg.as_dict()["red"] == fg.red



# Generated at 2022-06-26 04:25:05.354472
# Unit test for constructor of class Style
def test_Style():
    test_case_0()

# Generated at 2022-06-26 04:25:09.462471
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    style_1 = Style()
    style_2 = Style(Sgr(1))

    r = Register()

    r.set_renderfunc(Style, lambda x: "Style")
    assert str(style_1) == "Style"
    assert str(style_2) == "Style"

    r.set_renderfunc(Sgr, lambda *x: "Sgr")
    assert str(style_2) == "Sgr"

    r.set_eightbit_call(Sgr)
    assert r(1) == "Sgr"

    r.set_rgb_call(Sgr)
    assert r(1, 2, 3) == "Sgr"

    r.set_renderfunc(RgbBg, lambda *x: "RgbBg")
    assert str(RgbBg(1, 2, 3))

# Generated at 2022-06-26 04:25:16.367936
# Unit test for method __call__ of class Register
def test_Register___call__():
    import sys
    import io

    #  Create a sys.stdout capture context in order to test prints
    #  to stdout. For example:
    #  sys.stdout.write("Hello world.")

    with io.StringIO() as buffer, contextlib.redirect_stdout(buffer):
        Register().__call__()

        # Setup: Create objects and/or use stubs/mocks if needed. For example:
        #
        # stub = Stub()
        #
        # obj = Class(stub)


        # Exercise: run code, call function, etc

        # Verify: check for expected results. For example:
        #
        #
        # obj.some_method()
        # assert obj.some_attribute == "expected"

# Generated at 2022-06-26 04:25:20.995162
# Unit test for constructor of class Style
def test_Style():
    # Test for Style with empty arguments does not raise
    test_case_0()
    # style_1 = Style(RgbFg(42, 24, 189), Sgr(1))
    # style_2 = Style(style_1, Sgr(4))
    # style_3 = Style(style_2)

# Generated at 2022-06-26 04:25:25.978167
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.test = "sty.fg.white"
    expected = {"test": "sty.fg.white"}

    assert register.as_dict() == expected


# Generated at 2022-06-26 04:25:28.216520
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    test_case_0() # 0 style_0 = Style()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 04:25:45.034615
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from typing import NamedTuple

    from sty import fg

    # GIVEN a non-empty style register
    assert fg.white

    # WHEN the method as_namedtuple is called
    nt = fg.as_namedtuple()

    # THEN the returned value is of type NamedTuple
    assert isinstance(nt, NamedTuple)

    # AND the namedtuple has an attribute 'black'
    assert hasattr(nt, "black")



# Generated at 2022-06-26 04:25:46.934364
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_1 = Style()
    assert style_1 == ""


# Generated at 2022-06-26 04:25:58.904599
# Unit test for method __call__ of class Register
def test_Register___call__():

    from .rendertype import RenderType
    from .sgr import Sgr

    class RgbFg(RenderType):
        pass

    from .ansi_codes import fg, bg
    from pprint import pprint

    sgr_type = Sgr
    sgr_renderfunc = lambda x: "SGR_RENDERFUNC"

    fg.set_renderfunc(RgbFg, lambda r, g, b: "RGB_FG_RENDERFUNC")
    fg.set_eightbit_call(sgr_type)
    fg.set_rgb_call(RgbFg)
    fg.set_renderfunc(sgr_type, sgr_renderfunc)

    setattr(fg, "magenta", Style(sgr_type(5)))

# Generated at 2022-06-26 04:26:06.285105
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()
    style_1 = Style("bold")
    style_2: Style = Style("bold", "reset")
    style_3 = Style("bold", "red")
    style_4 = Style("bold", "red", "reset")
    style_5 = Style("bold", "orange")
    style_6 = Style("bold", "orange", "reset")
    style_7 = Style("bold", "reset", "orange")


# Generated at 2022-06-26 04:26:11.183504
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    style_0 = Style("")
    style_0 = Style("", "")
    style_0 = Style("", "", constant_value_=None)


# Generated at 2022-06-26 04:26:12.718326
# Unit test for method unmute of class Register
def test_Register_unmute():
    assert True


# Generated at 2022-06-26 04:26:13.878559
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()
    assert(type(style_0) is Style)


# Generated at 2022-06-26 04:26:17.607771
# Unit test for constructor of class Style
def test_Style():
    print('Testing style constructor')
    test_case_0()
    print('PASS')


# Generated at 2022-06-26 04:26:19.416310
# Unit test for constructor of class Style
def test_Style():
    test_case_0()
    assert True

# Generated at 2022-06-26 04:26:28.230548
# Unit test for method mute of class Register
def test_Register_mute():
    from . import fg

    fg.red = Style(RgbFg(255, 0, 0), Sgr(1))

    assert str(fg.red) == "\x1b[38;2;255;0;0m\x1b[1m"

    fg.mute()

    assert str(fg.red) == ""

    fg.unmute()

    assert str(fg.red) == "\x1b[38;2;255;0;0m\x1b[1m"



# Generated at 2022-06-26 04:26:50.531059
# Unit test for constructor of class Style
def test_Style():
    style = Style(
        Sgr(1),
        BgColor(42),
        style_b = Style(
            RgbBg(255,0,0)
        )
    )
    assert str(style) == "\x1b[42m\x1b[1m"
    assert str(style.style_b) == "\x1b[48;2;255;0;0m"


# Generated at 2022-06-26 04:27:00.114733
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    class RenderA(RenderType):
        pass

    class RenderB(RenderType):
        pass

    def render_a(value):
        return f"{value}"

    def render_b(value):
        return f"{value}"

    r0 = Register()
    r0.set_renderfunc(RenderA, render_a)
    r0.set_renderfunc(RenderB, render_b)

    assert r0.renderfuncs == {RenderA: render_a, RenderB: render_b}



# Generated at 2022-06-26 04:27:12.334409
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    # Create new Register object
    reg_0 = Register()
    # Create new Style object
    style_0 = Style("\x1b[0m")
    # Add style_0 to reg_0
    reg_0.reset = style_0
    # Create namedtuple of reg_0
    reg_0_namedtuple = reg_0.as_namedtuple()
    test_result = reg_0_namedtuple.reset
    # Assert that reg_0_namedtuple is of type namedtuple
    assert(isinstance(reg_0_namedtuple, namedtuple))
    # Assert that test_result is equal to "\x1b[0m"
    assert(test_result == "\x1b[0m")
    return True


# Generated at 2022-06-26 04:27:21.082118
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    class RenderType_0(RenderType):

        renderfunc = lambda *args: "".join([str(i) for i in args])

    register_0 = Register()
    register_0.set_rgb_call(RenderType_0)
    assert register_0.rgb_call(10, 20, 30) == "102030"


# Generated at 2022-06-26 04:27:22.927415
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style()

    assert isinstance(style_0, Style) is True
    assert isinstance(style_0, str) is True
    assert str(style_0) == ""
    assert style_0.rules == ()

# Generated at 2022-06-26 04:27:26.695911
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    style_0 = Style()
    res = Register.as_dict(style_0)
    assert res == {}

# Generated at 2022-06-26 04:27:34.187411
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    style_1 = Style()
    style_2 = Style("a", "b")

    style_3 = Style("a")

    assert style_1.as_namedtuple() == namedtuple("StyleRegister", [""])()
    assert style_2.as_namedtuple() == namedtuple("StyleRegister", ["", ""])("a", "b")
    assert style_3.as_namedtuple() == namedtuple("StyleRegister", [""])("a")



# Generated at 2022-06-26 04:27:35.624629
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()



# Generated at 2022-06-26 04:27:39.765256
# Unit test for method mute of class Register
def test_Register_mute():
    r = Register()
    r.mute()
    assert r.is_muted == True



# Generated at 2022-06-26 04:27:44.943104
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    r = Register()
    r.a = Style("Test")
    r.b = Style("Test2")

    assert r.as_namedtuple().a == r.a
    assert r.as_namedtuple().b == r.b
    assert isinstance(r.as_namedtuple(), NamedTuple)

    assert isinstance(r.copy(), Register)

# Generated at 2022-06-26 04:28:34.101712
# Unit test for method mute of class Register
def test_Register_mute():

    r = Register()
    r.fg = Style(RgbFg(255, 0, 0))
    r.bg = Style(RgbBg(255, 0, 0))

    assert str(r.fg) == "\x1b[38;2;255;0;0m"
    assert str(r.bg) == "\x1b[48;2;255;0;0m"

    r.mute()

    assert str(r.fg) == ""
    assert str(r.bg) == ""



# Generated at 2022-06-26 04:28:37.158075
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    reg = Register()
    reg.set_rgb_call(RgbFg)
    assert reg.rgb_call is not None


# Generated at 2022-06-26 04:28:48.580976
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    """
    Create a new Register-Object and add render-functions to it.
    """

    renderfunc0 = lambda x: "\x1b[{};20m".format(x)
    renderfunc1 = lambda x, y, z: "\x1b[38;2;{};{};{}m".format(x, y, z)
    renderfuncs = {
        Sgr: renderfunc0,
        RgbFg: renderfunc1,
    }

    r = Register()
    for k, v in renderfuncs.items():
        r.set_renderfunc(k, v)

    assert r.renderfuncs[Sgr] == renderfunc0
    assert r.renderfuncs[RgbFg] == renderfunc1



# Generated at 2022-06-26 04:28:56.243710
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    class TestClass:
        pass

    class TestRenderType(RenderType):
        def __init__(self):
            pass

    r0 = Register()
    r1 = Register()
    r1.set_renderfunc(TestRenderType, TestClass)

    assert TestClass == r1.renderfuncs[TestRenderType]
    assert TestClass != r0.renderfuncs[TestRenderType]


# Generated at 2022-06-26 04:28:58.718163
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    renderfuncs: Renderfuncs = {
        RenderType: lambda x: "I am rendertype"}
    new_register = Register()
    new_register.set_renderfunc(RenderType, lambda x: "I am rendertype")
    assert new_register.renderfuncs == renderfuncs


# Generated at 2022-06-26 04:29:06.469914
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
  """
  Ensure the set_renderfunc method is working as expected.
  """
  class Foo:
    pass

  class Bar:
    pass

  style_a = Style(Foo(), Bar())
  style_b = Style(Foo(), Bar())
  style_c = Style(Foo(), Bar())

  style_d = Style(Foo(), Bar(), Foo())
  style_e = Style(Foo(), Bar(), Foo())
  style_f = Style(Foo(), Bar(), Foo())

  reg = Register()
  reg.style_a = style_a
  reg.style_b = style_b
  reg.style_c = style_c
  reg.style_d = style_d
  reg.style_e = style_e
  reg.style_f = style_f

  reg.set_renderfunc

# Generated at 2022-06-26 04:29:08.336188
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    reg = Register()
    reg.set_eightbit_call(RgbFg(1,2,3))
    # TODO: Test this call if method is implemented properly
    reg.set_eightbit_call(RgbFg(1,2,3))


# Generated at 2022-06-26 04:29:21.063959
# Unit test for method copy of class Register
def test_Register_copy():

    # Create new Register-object.
    # Register-object has a dict called renderfuncs.
    # This dict contains the render functions for the different render types.
    # In this case only for the render type RgbFg.
    # Add one render function for render type RgbFg.
    rendertype = RenderType.rgb_fg

    def test_func(*args, **kwargs):
        return f"{str(*args, **kwargs)}"

    register = Register()
    register.set_renderfunc(rendertype, test_func)

    # Create new style-objects.
    sty_0 = Style(*(RenderType.bold,))
    sty_1 = Style(*(RenderType.rgb_fg(1, 5, 10),))

    # Add style-objects to register-object as attributes.
    register.test_sty