

# Generated at 2022-06-26 04:19:27.061464
# Unit test for constructor of class Register
def test_Register():
    register_1 = Register()
    assert register_1 is not None, "Register is NoneType!"


# Generated at 2022-06-26 04:19:30.557082
# Unit test for constructor of class Register
def test_Register():
    test_case_0()
    print("Testing Register")

if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-26 04:19:33.419486
# Unit test for constructor of class Register
def test_Register():
    """
    The constructor of the class Register should return
    an instance of the class Register.
    """
    register_0 = Register()
    assert isinstance(register_0, Register)


# Generated at 2022-06-26 04:19:35.015585
# Unit test for constructor of class Register
def test_Register():
    test_case_0()

# Generated at 2022-06-26 04:19:41.409344
# Unit test for constructor of class Register
def test_Register():
    register = Register()

# Generated at 2022-06-26 04:19:46.516192
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0.eightbit_call == register_0.eightbit_call
    assert register_0.rgb_call == register_0.rgb_call
    assert register_0.renderfuncs == register_0.renderfuncs
    assert register_0.is_muted == register_0.is_muted
    assert register_0.__dict__ == register_0.__dict__


# Generated at 2022-06-26 04:19:47.919735
# Unit test for constructor of class Register
def test_Register():
    assert type(Register()) == Register


# Generated at 2022-06-26 04:19:56.412657
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.set_rgb_call(RgbFg)
    register_0.set_eightbit_call(EightbitFg)
    assert str(register_0(255, 255, 255)) == '\x1b[38;2;255;255;255m'
    assert str(register_0(239)) == '\x1b[38;5;239m'
    assert str(register_0('white')) == '\x1b[38;5;15m'
    assert str(register_0('nope')) == ''
    assert str(register_0(1, 2, 3, 4)) == ''


# Generated at 2022-06-26 04:19:57.771271
# Unit test for constructor of class Register
def test_Register():
    a = Register()
    assert a



# Generated at 2022-06-26 04:20:00.917218
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert(isinstance(register_0, Register))



# Generated at 2022-06-26 04:20:08.156136
# Unit test for constructor of class Register
def test_Register():
    assert test_case_0() == None

# Generated at 2022-06-26 04:20:11.021879
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)


# Generated at 2022-06-26 04:20:18.340558
# Unit test for constructor of class Register
def test_Register():
    # base case for creating an instance of Register
    register_0 = Register()
    assert register_0
    # case for when a method is added to Register
    register_0.new_method = "test"
    assert register_0.new_method == "test"
    # case for when a method is added to a Style
    register_0.new_style = Style("test", "test")
    assert register_0.new_style.rules == "test"
    # case for when an attribute is added to Register
    register_0.new_attribute = Style("test", "test")
    assert register_0.new_attribute.rules == "test"


# Generated at 2022-06-26 04:20:20.943034
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0


# Generated at 2022-06-26 04:20:23.635359
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert issubclass(Register, object)
    assert isinstance(register, Register)


# Generated at 2022-06-26 04:20:24.695818
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()



# Generated at 2022-06-26 04:20:27.931206
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert isinstance(register, Register)



# Generated at 2022-06-26 04:20:30.881679
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert type(register_0) == Register


# Generated at 2022-06-26 04:20:32.827455
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert(register_0)



# Generated at 2022-06-26 04:20:33.882816
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert True


# Generated at 2022-06-26 04:20:52.287299
# Unit test for method __call__ of class Register
def test_Register___call__():

    # Initialize object
    register_0 = Register()

    # Test 0
    assert register_0() == ""

    # Test 1
    assert register_0(1) == ""

    # Test 2
    assert register_0(1, 1, 1) == ""



# Generated at 2022-06-26 04:20:56.108745
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.x = "rgb"
    assert register_0.x == "rgb"


# Generated at 2022-06-26 04:20:57.574438
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    assert register_0.as_namedtuple() == namedtuple("StyleRegister", register_0.as_dict().keys())(*register_0.as_dict().values())


# Generated at 2022-06-26 04:21:02.821175
# Unit test for constructor of class Style
def test_Style():
    # Create a Style object and test it's type.
    style_0 = Style()

    assert isinstance(style_0, Style)
    assert isinstance(style_0, str)

    # Test style rendering.
    style_0.rules = [2]
    assert str(style_0) == "2"

    # Create another Style object.
    style_1 = Style()

    # Append style_0 to style_1.
    style_1.rules = [1, style_0]
    assert str(style_1) == "12"


# Generated at 2022-06-26 04:21:12.972417
# Unit test for method as_namedtuple of class Register

# Generated at 2022-06-26 04:21:25.450233
# Unit test for method copy of class Register
def test_Register_copy():
    from copy import deepcopy
    from .render import render_term256_fg, render_term256_bg

    register_0 = Register()
    register_0.set_eightbit_call(render_term256_fg)
    register_0.set_rgb_call(render_term256_bg)
    register_0.fuchsia = Style(render_term256_fg(5), render_term256_bg(1, 2, 3))
    register_0.aqua = Style(render_term256_fg(6), render_term256_bg(4, 5, 6))

    register_1 = register_0.copy()

    # Mute register 0
    register_0.mute()
    # Make sure register 0 is muted
    assert register_0.fuchsia == ""

# Generated at 2022-06-26 04:21:31.684037
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()

    register_0.blue = Style(RgbFg(0, 0, 255))

    assert register_0.blue == "\x1b[38;2;0;0;255m"



# Generated at 2022-06-26 04:21:35.631086
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = test_case_0()
    register_0.unmute()

    # Test if instance attribute is_muted has changed
    assert register_0.is_muted == False



# Generated at 2022-06-26 04:21:38.440906
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.test_0 = Style(test_0=None)
    register_0.test_0



# Generated at 2022-06-26 04:21:41.062252
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    register_1 = register_0.copy()
    assert register_1 == register_0, "Copies of a Register-object should have the same values."

# Generated at 2022-06-26 04:21:59.914796
# Unit test for constructor of class Style
def test_Style():
    rule_0 = RenderType()
    rule_1 = RenderType()
    rule_2 = RenderType()

    style_1 = Style(rule_0, rule_1)
    style_2 = Style(rule_1)

    assert isinstance(style_1, str) == True
    assert isinstance(style_1, Style) == True

    assert (style_1 == style_2) == False
    assert style_2.rules == (rule_1,)
    assert style_1.rules == (rule_0, rule_1)



# Generated at 2022-06-26 04:22:03.006862
# Unit test for method unmute of class Register
def test_Register_unmute():
    from sty import fg, bg, ef, rs
    register_0 = Register()
    register_0.unmute()
    assert register_0.is_muted == False


# Generated at 2022-06-26 04:22:08.111454
# Unit test for method mute of class Register
def test_Register_mute():

    rg = Register()
    a = Style(Sgr(1), Sgr(4))

    rg.a = a

    rg.mute()

    b = Style(Sgr(1), Sgr(4))

    rg.b = b

    assert rg.a == rg.b


# Generated at 2022-06-26 04:22:14.707568
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register = Register()

    assert register.eightbit_call is not None
    register.set_eightbit_call(RenderType.EIGHTBIT)
    assert register.eightbit_call is not None



# Generated at 2022-06-26 04:22:23.324748
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    The method 'as_namedtuple' returns a namedtuple with the name 'StyleRegister'
    and the color attributes as members in the tuple.
    """
    class ExampleAttributeWithTypeHint(RenderType):
        pass

    render_func = lambda *args, **kwargs: ""

    register_0 = Register()
    register_0.set_renderfunc(ExampleAttributeWithTypeHint, render_func)
    register_0.example_attribute_with_type_hint = Style(ExampleAttributeWithTypeHint(0))

    expected_namedtuple_class = namedtuple("StyleRegister", ("example_attribute_with_type_hint", ))
    expected_namedtuple = expected_namedtuple_class("")
    received_namedtuple = register_0.as_namedtuple()

    assert received_

# Generated at 2022-06-26 04:22:25.191818
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    assert id(register_0) != id(register_0.copy())
test_Register_copy()


# Generated at 2022-06-26 04:22:35.274244
# Unit test for method __call__ of class Register
def test_Register___call__():

    renderfuncs = {type: lambda: 'test'}
    rules = [1, 2, 3]

    Style.rules = rules

    register = Register()
    register.renderfuncs = renderfuncs

    register.set_eightbit_call(int)
    register.set_rgb_call(tuple)

    assert register(100) == 'test'
    assert register(100, 101, 102) == 'test'
    assert register(100, 101, 102) == 'test'

    register.mute()
    assert register(100) == ''
    assert register(100, 101, 102) == ''
    assert register(100, 101, 102) == ''

    register.unmute()
    assert register(100) == 'test'
    assert register(100, 101, 102) == 'test'

# Generated at 2022-06-26 04:22:36.593781
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_1 = Register()
    assert isinstance(register_1.as_namedtuple(), namedtuple)



# Generated at 2022-06-26 04:22:44.548592
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.a = Style(value='a')
    register.b = Style(value='b')
    # print(f"a={register.a} b={register.b}")
    dict = register.as_dict()
    assert len(dict) == 2
    assert dict['a'] == 'a'
    assert dict['b'] == 'b'


# Generated at 2022-06-26 04:22:50.710592
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    assert register_0.is_muted == False
    register_0.mute()
    assert register_0.is_muted == True


# Generated at 2022-06-26 04:23:43.287832
# Unit test for method copy of class Register
def test_Register_copy():
    register_0 = Register()
    assert isinstance(register_0.copy(), Register)


# Generated at 2022-06-26 04:23:49.570696
# Unit test for constructor of class Register
def test_Register():
    r0 = Register()
    r0.set_eightbit_call(RenderType)
    r0.set_rgb_call(RenderType)
    r0.set_renderfunc(RenderType, lambda x: x)
    r0.mute()
    r0.unmute()
    d0 = r0.as_dict()
    nt0 = r0.as_namedtuple()
    test_case_0()


if __name__ == "__main__":
    test_Register()

# Generated at 2022-06-26 04:23:51.174867
# Unit test for constructor of class Style
def test_Style():
    #Test case 0
    s0: Style = Style()
    s1: Style = Style('a')
    s2: Style = Style('a', 'b')


# Generated at 2022-06-26 04:23:56.179343
# Unit test for method unmute of class Register
def test_Register_unmute():
    """
    un-/mute Register object
    """
    register_0 = Register()
    register_0.mute()
    assert register_0.is_muted
    register_0.unmute()
    assert not register_0.is_muted


# Generated at 2022-06-26 04:24:00.117372
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_1 = Register()
    register_1.set_eightbit_call(lambda x, y: x + y)
    assert register_1.eightbit_call(1, 1) == 2


# Generated at 2022-06-26 04:24:06.462039
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # arrange
    register_0 = Register()
    rendertype = RenderType
    func_0 = lambda *args: "test"

    # act
    register_0.set_renderfunc(rendertype, func_0)
    register_0.set_eightbit_call(rendertype)

    # assert
    assert register_0.eightbit_call == func_0


# Generated at 2022-06-26 04:24:10.893794
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # put your test-code here
    register_0 = Register()
    register_0.set_rgb_call(RgbFg)
    # register_0.set_rgb_call()
    pass



# Generated at 2022-06-26 04:24:14.003082
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RgbFg)
    assert type(register_0.eightbit_call) is Callable


# Generated at 2022-06-26 04:24:18.505834
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    fg = Register()
    fg.red = Style(RgbFg(10, 42, 255))
    fg.green = Style(EightbitFg(12))
    assert fg.as_dict()["red"] == fg.red
    assert fg.as_dict()["green"] == fg.green


# Generated at 2022-06-26 04:24:21.591177
# Unit test for constructor of class Register
def test_Register():
    register = Register()

    assert (register.renderfuncs == {})
    assert (register.is_muted == False)



# Generated at 2022-06-26 04:25:32.269293
# Unit test for method mute of class Register
def test_Register_mute():

    register_0 = Register()

    str_0 = str(register_0)

    register_0.mute()

    str_1 = str(register_0)

    str_0 != str_1


# Generated at 2022-06-26 04:25:33.538090
# Unit test for constructor of class Register
def test_Register():
    assert isinstance(test_case_0(), Register)


# Generated at 2022-06-26 04:25:45.987117
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_1 = Register()
    register_2 = Register()

    # RenderType for testing.
    class _RenderType(RenderType):
        fg = True
        args = ["r", "g", "b"]

    register_1.set_renderfunc(_RenderType, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    # RenderType for testing.
    class _RenderType(RenderType):
        bg = True
        args = ["r", "g", "b"]

    register_2.set_renderfunc(_RenderType, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")

    register_1.set_rgb_call(_RenderType)
    register_2.set_

# Generated at 2022-06-26 04:25:57.284348
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    # Set up
    register_0 = Register()
    register_0.foo = Style(RgbBg(10, 42, 255))
    register_0.bar = Style(Bold())
    register_0.baz = Style(Underline())
    register_0.foo.rules
    expected = {"bar": "\x1b[1m", "baz": "\x1b[4m", "foo": "\x1b[48;2;10;42;255m"}

    # Test
    actual = register_0.as_dict()

    # Assert
    assert actual == expected


# Generated at 2022-06-26 04:26:07.704568
# Unit test for method as_dict of class Register
def test_Register_as_dict():

    from . import fg

    assert isinstance(fg, Register) is True

    assert isinstance(fg.as_dict(), dict) is True

# Generated at 2022-06-26 04:26:11.088961
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    assert not (register_0.unmute())


# Generated at 2022-06-26 04:26:13.299414
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:26:18.416466
# Unit test for constructor of class Style
def test_Style():
    a = Style("a")
    print("STYLE_STR", id(a))
    assert(isinstance(a, Style))
    assert(isinstance(a, str))
    assert(a == "a")


# Generated at 2022-06-26 04:26:24.521684
# Unit test for constructor of class Register
def test_Register():
    from .rendertype import RgbFg, Sgr
    assert isinstance(register_0, Register)
    assert not isinstance(register_0, str)
    assert not isinstance(register_0, int)
    assert not isinstance(register_0, float)


# Generated at 2022-06-26 04:26:31.714616
# Unit test for constructor of class Style
def test_Style():
    Style("",)
    assert isinstance(Style(""), Style)
    Style("\x1b[1m\x1b[38;2;1;2;3m",)
    assert isinstance(Style("\x1b[1m\x1b[38;2;1;2;3m"), Style)

    Style(Style("\x1b[1m",))
    assert isinstance(Style(Style("\x1b[1m",)), Style)

    Style(Style("\x1b[1m\x1b[38;2;1;2;3m",))
    assert isinstance(Style(Style("\x1b[1m\x1b[38;2;1;2;3m",)), Style)

    # Subclass
    class StyleA(Style):
        pass
    StyleA

# Generated at 2022-06-26 04:28:20.474633
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    from sty import fg

    assert isinstance(fg.as_namedtuple(), namedtuple("StyleRegister", fg.as_dict().keys()))



# Generated at 2022-06-26 04:28:24.251910
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    # Case 0
    register_0 = Register()
    dict_0 = register_0.as_dict()
    assert isinstance(dict_0, dict) == True
    assert dict_0 == {}


# Generated at 2022-06-26 04:28:29.841054
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    test_cases_0 = (
        (
            1,
            "",
            False,
        ),
        (
            1,
            "",
            True,
        ),
    )
    for (args_0, expected_0, is_muted) in test_cases_0:
        register_0.is_muted = is_muted
        actual_0 = register_0(*args_0)
        assert expected_0 == actual_0, f"{actual_0} != {expected_0}"



# Generated at 2022-06-26 04:28:37.166343
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg, RgbEf, RgbFg


    register_0 = Register()

    register_0.set_renderfunc(RgbBg, lambda r, g, b: f"\x1b[48;2;{r};{g};{b}m")
    register_0.set_renderfunc(RgbEf, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")
    register_0.set_renderfunc(RgbFg, lambda r, g, b: f"\x1b[38;2;{r};{g};{b}m")

    register_0.set_rgb_call(RgbBg)

    register_0(0, 0, 0)
    register_0

# Generated at 2022-06-26 04:28:48.982528
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_0 = Register()
    expected_0: str = ""
    actual_0: str = register_0()

    assert actual_0 == expected_0

    register_0.reset = Style(RgbFg(10, 20, 30))
    expected_1: str = "\x1b[38;2;10;20;30m"
    actual_1: str = register_0(10, 20, 30)

    assert actual_1 == expected_1

    register_0.reset = Style(Sgr(10), RgbFg(10, 20, 30))
    expected_2: str = "\x1b[10;38;2;10;20;30m"
    actual_2: str = register_0(10, 20, 30)

    assert actual_2 == expected_2

    register_0.set_

# Generated at 2022-06-26 04:28:51.868207
# Unit test for constructor of class Register
def test_Register():
    assert test_case_0() == None

# Unit test: If object is muted, call returns empty str.

# Generated at 2022-06-26 04:28:54.546957
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()


"""
The ScrollRegister is a Register with a 'scroll' property.
"""



# Generated at 2022-06-26 04:28:55.889451
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    pass


# Generated at 2022-06-26 04:29:08.461312
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert (hasattr(register_0, "renderfuncs"))
    assert (hasattr(register_0, "is_muted"))
    assert (hasattr(register_0, "eightbit_call"))
    assert (hasattr(register_0, "rgb_call"))
    assert isinstance(register_0.renderfuncs, dict)
    assert isinstance(register_0.is_muted, bool)
    assert isinstance(register_0.eightbit_call, type(lambda : None))
    assert isinstance(register_0.rgb_call, type(lambda : None))
    assert register_0.is_muted is False
    assert register_0.eightbit_call(0) is 0

# Generated at 2022-06-26 04:29:12.902893
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)
