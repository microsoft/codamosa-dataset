

# Generated at 2022-06-26 04:19:34.468009
# Unit test for method mute of class Register
def test_Register_mute():
    x = Register()
    x.set_eightbit_call(RenderType.sgr_eightbit_foreground)
    x.set_rgb_call(RenderType.sgr_rgb_foreground)
    x.red = Style(RenderType.sgr_eightbit_foreground.value(9))
    x.orange = Style(RenderType.sgr_eightbit_foreground.value(202))
    x.mute()
    assert x.red == ""
    assert x.orange == ""
    assert x(9) == ""
    assert x(9,9,9) == ""
    assert x('red') == ""


# Generated at 2022-06-26 04:19:46.814035
# Unit test for method __call__ of class Register
def test_Register___call__():
    """
    This test verifies that the __call__ method of class Register works as expected.
    """

    # Create register
    register_0 = Register()

    # Add an attribute 'orange' of type Style
    register_0.orange = Style()

    # Add a render function.
    def dummy_func(self, c: int):
        return ""

    register_0.set_renderfunc(RenderType, dummy_func)

    # Call register as function.
    assert (register_0(42) == register_0.orange)
    assert (register_0("orange") == register_0.orange)

    # Add attribute 'red' of type string
    register_0.red = "blabla"

    # Call register as function.
    assert (register_0("red") == "blabla")


test_case_0

# Generated at 2022-06-26 04:19:48.797893
# Unit test for method __new__ of class Style
def test_Style___new__():
    style_0 = Style(value="", rules=[])


# Generated at 2022-06-26 04:19:54.690261
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.is_muted = True
    register_0.fg = Style(RenderType())
    if not isinstance(register_0.fg, Style):
        raise AssertionError("ValueError: register_0.__setattr__(register_0.fg, Style(RenderType()))")


# Generated at 2022-06-26 04:19:58.824716
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    fg_1 = Style(1, 2)
    register_0.blue = fg_1
    assert hasattr(register_0, 'blue')



# Generated at 2022-06-26 04:20:01.602743
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()

# Generated at 2022-06-26 04:20:07.050947
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """ Tests the as_namedtuple method of the Register class """
    register_0 = Register()
    setattr(register_0, "blue", Style("\u001b[34m"))
    setattr(register_0, "red", Style("\u001b[31m"))
    assert register_0.as_namedtuple() == namedtuple("StyleRegister", ["blue", "red"])(
        "\u001b[34m", "\u001b[31m"
    )


# Generated at 2022-06-26 04:20:12.170450
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register = Register()
    register.foo = Style(fg=(255, 0, 0))
    assert register.as_dict() == {"foo": "\x1b[38;2;255;0;0m"}


# Generated at 2022-06-26 04:20:25.102834
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType2)
    register_0.set_rgb_call(RenderType3)
    register_0.set_renderfunc(RenderType4, renderfunc_1)
    register_0.set_renderfunc(RenderType5, renderfunc_2)
    assert not hasattr(register_0, 'red')
    register_0.red = Style(RenderType0(), RenderType1())
    assert register_0.red == '\x1b[38;2;255;0;0m\x1b[48;2;0;255;0m'
    assert register_0.red == register_0("red")
    assert register_0.red == register_0(1)

# Generated at 2022-06-26 04:20:28.426859
# Unit test for constructor of class Style
def test_Style():
    register_0 = Register()
    register_0.bold = Style(
        RenderType.Fg.magenta, RenderType.Bg.rgb(255, 255, 0),
    )

    assert isinstance(register_0.bold, Style)


# Generated at 2022-06-26 04:20:33.861769
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert str(Style(1, value = "foo")) == "foo"


# Generated at 2022-06-26 04:20:35.594687
# Unit test for method mute of class Register
def test_Register_mute():

    register_0 = Register()

    register_0.mute()



# Generated at 2022-06-26 04:20:39.589797
# Unit test for method __new__ of class Style
def test_Style___new__():
    assert Style("a", value="b") == "b"


# Generated at 2022-06-26 04:20:50.634286
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    # Test case 0
    register_0 = Register()

    reg_0_0 = Style(RgbFg(1,2,3), Sgr(1))
    register_0.red = reg_0_0
    assert register_0.red == '\x1b[38;2;1;2;3m\x1b[1m'

    reg_0_1 = Style(Sgr(1))
    register_0.bold = reg_0_1
    assert register_0.bold == '\x1b[1m'

    # Test case 1
    register_1 = Register()

    reg_1_0 = Style(RgbFg(1,2,3), Sgr(1))
    register_1.red = reg_1_0

# Generated at 2022-06-26 04:21:02.275101
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():

    # We do not test the standard rendering functions.
    # Therfore, we use dummy functions.
    dummy = lambda *args: args
    dummy_bg = lambda *args: f"bg{args}"
    dummy_fg = lambda *args: f"fg{args}"

    # Create an empty Register.
    register_0 = Register()

    # Set some render-functions for a test.
    register_0.set_renderfunc(RgbBg, dummy_bg)
    register_0.set_renderfunc(RgbFg, dummy_fg)
    register_0.set_renderfunc(Reset, dummy)

    # Set renderfunc for RGB-calls on register.
    register_0.set_rgb_call(RgbBg)

    # Check that the RGB-call function was updated correctly.
    assert register_

# Generated at 2022-06-26 04:21:12.848979
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    register_0 = Register()
    register_0.a = Style(CreateRgbFg(10,11,12))
    register_0.b = Style(CreateRgbFg(30,31,32))
    register_0.c = Style(CreateRgbFg(33,34,35))

    assert (str(register_0.as_namedtuple()) == "StyleRegister(a='\\x1b[38;2;10;11;12m', b='\\x1b[38;2;30;31;32m', c='\\x1b[38;2;33;34;35m')")


# Generated at 2022-06-26 04:21:23.485500
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_1 = Register()

    def my_render_func(arg1: int, arg2: int, arg3: int) -> str:
        return f"\x1b[{arg1}m\x1b[{arg2}m\x1b[{arg3}m"

    my_rendertype: Type[RenderType] = namedtuple("MockRenderType", ["args"])
    register_1.set_renderfunc(my_rendertype, my_render_func)

    assert register_1.renderfuncs[my_rendertype] == my_render_func


# Generated at 2022-06-26 04:21:31.551730
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    # Test: create a new Register object and check its eightbit_call attribute is a function
    register_0 = Register()
    assert callable(register_0.eightbit_call)

    # Test: create a new Register object and assign it a new function.
    #       Check if new function was assigned.
    register_1 = Register()
    func = lambda x: x
    register_1.set_eightbit_call(func)
    assert register_1.eightbit_call == func



# Generated at 2022-06-26 04:21:35.896778
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_1: Register = Register()
    register_1.eightbit = Style(EightbitFg(23))

    assert register_1.as_dict() == {"eightbit": "\x1b[38;5;23m"}


# Generated at 2022-06-26 04:21:40.331364
# Unit test for constructor of class Register
def test_Register():
    # Given
    register_0 = Register()
    # When
    first_attribute = dir(register_0)[0]
    # Then
    assert first_attribute == "eightbit_call"
    assert register_0.eightbit_call == register_0.eightbit_call


# Generated at 2022-06-26 04:21:46.330003
# Unit test for constructor of class Style
def test_Style():
    Style()

# Generated at 2022-06-26 04:21:51.565513
# Unit test for method __call__ of class Register
def test_Register___call__():
    register_0 = Register()
    register_0.set_renderfunc(RenderType.Sgr, lambda *args, **kwargs: "\x1b[1m")
    register_0.red = Style(RenderType.Sgr(1))
    assert str(register_0("red")) == "\x1b[1m"



# Generated at 2022-06-26 04:21:52.582510
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()


# Generated at 2022-06-26 04:21:57.923410
# Unit test for method __call__ of class Register
def test_Register___call__():
    # Prepare the test case
    register_0 = Register()

    # Execute the test case
    # result__call__0 = register_0.__call__(145)

    # Assert the result
    # print(result__call__0)
    # assert result__call__0 == "\x1b[38;5;145m"
    pass



# Generated at 2022-06-26 04:22:00.869376
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # sample testcase
    register_0 = Register()
    register_0.set_rgb_call(RgbFg)



# Generated at 2022-06-26 04:22:08.602610
# Unit test for constructor of class Register
def test_Register():

    # check if constructor creates object of correct type
    test_case_0()

    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()


# test set_eightbit_call: RenderType is a class

# Generated at 2022-06-26 04:22:14.376271
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    reg = Register()
    reg.foo = Style(value = "Mock_String")
    assert reg.as_dict() == {'foo':'Mock_String'}



# Generated at 2022-06-26 04:22:18.563783
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.mute()

    assert register_0.is_muted
    
    register_0.unmute()

    assert not register_0.is_muted



# Generated at 2022-06-26 04:22:23.808891
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():
    register_0 = Register()
    str_0 = ""

    # Create Style-Object from "raw" rules.
    style_0 = Style(value=str_0)
    style_1 = Style(value=str_0)

    # Set style_0 to attribute 'one'.
    register_0.one = style_0

    # Set 'one' to style_1
    register_0.one = style_1

    # Compare register 0 to register 1
    assert isinstance(register_0, Register)
    assert isinstance(register_0.one, Style)
    assert register_0.one == style_1


# Generated at 2022-06-26 04:22:34.421623
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    class RgbFg(RenderType):
        args = "red", "green", "blue"
    class RgbBg(RenderType):
        args = "red", "green", "blue"

    def render_rgb_fg_8bit(red, green, blue):
        return f"\033[38;2;{red};{green};{blue}m"

    def render_rgb_bg_8bit(red, green, blue):
        return f"\033[48;2;{red};{green};{blue}m"

    register_fg = Register()
    register_fg.set_renderfunc(rendertype=RgbFg, func=render_rgb_fg_8bit)
    register_fg.set_rgb_call(RgbFg)

    register_bg = Register()
    register

# Generated at 2022-06-26 04:22:41.252917
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert isinstance(register_0, Register)

# Generated at 2022-06-26 04:22:45.735970
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register = Register()
    register.set_renderfunc(RenderType, lambda x: x)
    register.set_eightbit_call(RenderType)
    assert callable(register.eightbit_call)
    assert register.eightbit_call(1) == 1


# Generated at 2022-06-26 04:22:50.269681
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()


# Generated at 2022-06-26 04:22:52.188628
# Unit test for constructor of class Register
def test_Register():
    register = Register()
    assert(register.as_namedtuple())

if __name__ == "__main__":
    test_case_0()
    test_Register()

# Generated at 2022-06-26 04:22:56.535207
# Unit test for method as_namedtuple of class Register
def test_Register_as_namedtuple():
    """
    Unit test for method as_namedtuple of class Register
    """
    print("Testing method as_namedtuple")

    register_0 = Register()
    register_0.test_attr_0 = Style(value="test value")
    print(register_0.as_namedtuple())


if __name__ == '__main__':

    test_Register_as_namedtuple()

# Generated at 2022-06-26 04:22:59.651389
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert isinstance(register_0, Register)


# Generated at 2022-06-26 04:23:00.690700
# Unit test for method mute of class Register
def test_Register_mute():
    r0 = Register()
    r0.mute()

# Generated at 2022-06-26 04:23:10.999997
# Unit test for method __call__ of class Register
def test_Register___call__():

    register_1 = Register()
    register_1.set_eightbit_call(rendertype=RenderType.EightBit)
    register_1.set_rgb_call(rendertype=RenderType.TrueColor)

    assert register_1(1) == 1
    assert register_1(16) == 16
    assert register_1(2, 3, 4) == (2, 3, 4)
    assert register_1() == ""

    register_2 = Register()
    register_2.set_eightbit_call(rendertype=RenderType.TrueColor)
    register_2.set_rgb_call(rendertype=RenderType.EightBit)

    assert register_2(1) == (1, 1, 1)
    assert register_2(16) == (16, 16, 16)

# Generated at 2022-06-26 04:23:13.265781
# Unit test for method __new__ of class Style
def test_Style___new__():
    f = Style(value_0='string', value_1='string', value_2='string')
    assert isinstance(f, Style)


# Generated at 2022-06-26 04:23:20.652467
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import Sgr, SgrFg
    register_1 = Register()
    register_1.set_renderfunc(Sgr, lambda x: "sgr" + str(x))
    register_1.set_renderfunc(SgrFg, lambda x: "sgrfg" + str(x))

    assert register_1(1) == ''
    register_1.set_eightbit_call(SgrFg)
    assert register_1(1) == 'sgrfg1'



# Generated at 2022-06-26 04:23:32.653042
# Unit test for method __new__ of class Style
def test_Style___new__():
    register_0 = Register()
    Style(register_0, register_0)


# Generated at 2022-06-26 04:23:34.645759
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)


# Generated at 2022-06-26 04:23:44.979255
# Unit test for method __new__ of class Style
def test_Style___new__():
    from sty.rendertype import Sgr, RgbFg

    pass_value = Style(Sgr(1), RgbFg(1, 2, 3), value='{0}{1}')
    pass_args = Style(Sgr(1), value='{0}')

    def fail_value():
        Style(Sgr(1), RgbFg(1, 2, 3), value=0)

    def fail_args():
        Style('callable')

    assert isinstance(pass_value, Style)
    assert isinstance(pass_args, Style)

    try:
        fail_value()
    except TypeError:
        pass
    else:
        assert False

    try:
        fail_args()
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-26 04:23:48.413010
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda x: "")

# Generated at 2022-06-26 04:24:00.815373
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    sty = Register()
    sty.set_renderfunc(RenderType, lambda x, y: "RenderType")
    sty.set_renderfunc(RenderType, lambda x, y: "Changing")
    sty.set_renderfunc(RenderType, lambda x, y: "RenderType")
    sty.set_renderfunc(NamedTuple("RenderType", []), lambda x, y: "RenderType")
    sty.set_renderfunc(NamedTuple("RenderType", []), lambda x, y: "Changing")
    sty.set_renderfunc(NamedTuple("RenderType", []), lambda x, y: "RenderType")


# Generated at 2022-06-26 04:24:08.915451
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    # Success case
    register_0 = Register()
    register_1 = Register()
    register_0.set_renderfunc(RenderType, lambda r, g, b: (r, g, b))
    register_0.set_rgb_call(RenderType)
    assert register_0.rgb_call == register_0.renderfuncs[RenderType]
    # Failure case
    register_1.set_renderfunc(object, lambda r, g, b: (r, g, b))
    try:
        register_1.set_rgb_call(RenderType)
    except TypeError:
        return "TypeError"
    else:
        return "No exception raised"


# Generated at 2022-06-26 04:24:14.038486
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    v = register_0.as_dict()
    assert v == {}
    register_0.test_0 = "test_string"

    v = register_0.as_dict()
    assert v == {"test_0" : "test_string"}


# Generated at 2022-06-26 04:24:16.142169
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    register_0 = Register()
    register_0.set_eightbit_call(RenderType)


# Generated at 2022-06-26 04:24:27.509724
# Unit test for method mute of class Register
def test_Register_mute():
    from .ansi import *
    from .rendertype import *

    # Save original render functions for later reuse
    old_funcs = fg.renderfuncs.copy()

    # Mute effect-register
    ef.mute()

    # Do assert test:
    assert ef.is_muted == True
    assert fg.is_muted == False

    # Unmute effect-register
    ef.unmute()

    # Do assert test:
    assert ef.is_muted == False
    assert fg.is_muted == False

    # Reset muted attribute of ef.
    ef.is_muted = False

    # Update renderfuncs for fg after testing.
    fg.renderfuncs.update(old_funcs)

    # Do assert test:
    assert fg

# Generated at 2022-06-26 04:24:29.642504
# Unit test for constructor of class Style
def test_Style():
    style = Style(fg="Hello")
    assert style.rules[0] == "Hello"


# Generated at 2022-06-26 04:24:46.158635
# Unit test for constructor of class Style
def test_Style():
    style_0 = Style()


# Generated at 2022-06-26 04:24:47.490255
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    register_0.unmute()



# Generated at 2022-06-26 04:24:48.555508
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    sty_instance = register_0
    sty_instance.mute()
    assert sty_instance.is_muted == True


# Generated at 2022-06-26 04:24:53.121371
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_1 = Register()

    register_1.set_rgb_call(RgbFg)
    assert register_1.rgb_call(10, 20, 30) == (10, 20, 30)



# Generated at 2022-06-26 04:24:55.625877
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    register_1 = Register()
    def test_0():
        assert isinstance(register_0, Register)
    def test_1():
        assert isinstance(register_1, Register)
    test_0()
    test_1()


# Generated at 2022-06-26 04:24:59.790046
# Unit test for method set_eightbit_call of class Register
def test_Register_set_eightbit_call():
    from .rendertype import EightBit

    register_0 = Register()
    register_0.set_renderfunc(EightBit, lambda code: "Foo")
    assert register_0.eightbit_call(42) == "Foo"



# Generated at 2022-06-26 04:25:11.864019
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    r = Register()
    # Set attributes
    r.test1 = Style("\x1b[0m\x1b[48;2;154;205;50m\x1b[38;2;46;139;87m")
    r.test2 = Style("\x1b[0m\x1b[48;2;154;205;50m\x1b[38;2;46;139;87m")
    r.test3 = Style("\x1b[0m\x1b[48;2;154;205;50m\x1b[38;2;46;139;87m")
    r.test4 = Style("\x1b[0m\x1b[48;2;154;205;50m\x1b[38;2;46;139;87m")


# Generated at 2022-06-26 04:25:18.922615
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    register_1 = Register()

    # Check if no error occurs
    try:
        register_1.test = Style("test")
    except:
        raise ValueError("Error in Register.__setattr__")


# Generated at 2022-06-26 04:25:28.025625
# Unit test for method __call__ of class Register
def test_Register___call__():
    from .rendertype import Sgr

    Sgr0 = Sgr(0)
    Sgr1 = Sgr(1)
    Sgr2 = Sgr(2)

    register_0 = Register()
    register_0.a = Style(Sgr0)
    str_0 = "Hello World"
    str_1 = "Hello World"
    str_2 = "#000000"
    str_3 = "Hello World"

    for name in dir(register_0):
        print(name)


# Generated at 2022-06-26 04:25:35.723994
# Unit test for method copy of class Register
def test_Register_copy():
    class rendertype_0(RenderType):
        def render(self):
            return "rendertype_0()"
    class rendertype_1(RenderType):
        def render(self):
            return "rendertype_1()"

    register_0 = Register()
    register_0.set_renderfunc(rendertype_0, lambda *args: "rendertype_0()")
    register_0.set_eightbit_call(rendertype_1)
    register_0.set_rgb_call(rendertype_1)
    register_1 = register_0.copy()

    if id(register_0) == id(register_1):
        raise AssertionError()
    if id(register_0.renderfuncs) == id(register_1.renderfuncs):
        raise AssertionError()

# Generated at 2022-06-26 04:25:50.992545
# Unit test for constructor of class Style
def test_Style():
    rule_0 = Style(*[], value="")

# Unit Test for method '__setattr__' in class Register

# Generated at 2022-06-26 04:25:52.518317
# Unit test for constructor of class Register
def test_Register():
    test_case_0()
    return 0

# Generated at 2022-06-26 04:25:55.276962
# Unit test for constructor of class Register
def test_Register():
    register_0 = Register()
    assert register_0 is not None

# Generated at 2022-06-26 04:25:58.030233
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()

    register_0.unmute()

    if not register_0.is_muted:
        print('test_Register_unmute: Test passed')
    else:
        print('test_Register_unmute: Test failed')


# Generated at 2022-06-26 04:26:00.170920
# Unit test for method __new__ of class Style
def test_Style___new__():
    style0 = Style()


test_case_0()
test_Style___new__()

# Generated at 2022-06-26 04:26:07.806660
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():
    register_1 = Register()
    rendertype_0 = RenderType
    def func_0(arg_0, arg_1, arg_2):
        return arg_0 + arg_1 + arg_2
    register_1.set_renderfunc(rendertype_0, func_0)



# Generated at 2022-06-26 04:26:14.428538
# Unit test for method set_renderfunc of class Register
def test_Register_set_renderfunc():

    R1 = RenderType()

    register_1 = Register()
    register_1.set_renderfunc(R1, lambda x: str(x))

    rendered_1 = register_1(R1(42))

    assert rendered_1 == "42"



# Generated at 2022-06-26 04:26:22.018285
# Unit test for method __call__ of class Register
def test_Register___call__():
    r1 = Register()
    setattr(r1, "red", Style(value="\x1b[31m"))
    setattr(r1, "green", Style(value="\x1b[32m"))
    setattr(r1, "blue", Style(value="\x1b[34m"))

    assert r1("red") == "\x1b[31m"
    assert r1("green") == "\x1b[32m"
    assert r1("blue") == "\x1b[34m"

    r2 = Register()
    setattr(r2, "red", Style(value="\x1b[31m"))
    setattr(r2, "green", Style(value="\x1b[32m"))

# Generated at 2022-06-26 04:26:29.126904
# Unit test for method as_dict of class Register
def test_Register_as_dict():
    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda x: "test")
    register_0.test_0 = Style(RenderType(42))
    register_0.test_1 = Style(RenderType(42), RenderType(42))
    register_0.test_2 = Style(RenderType(42), RenderType(42), RenderType(42))
    result = register_0.as_dict()
    assert result == {'test_0': 'test', 'test_1': 'testtest', 'test_2': 'testtesttest'}

# Generated at 2022-06-26 04:26:41.061598
# Unit test for constructor of class Style
def test_Style():
    # Create mockup renderfunc
    rendertype = RenderType

    def renderfunc(*args, **kwargs):
        return ''.join(map(str, args))

    renderfuncs = {rendertype: renderfunc}
    rules = [RenderType('red', 'green', 'blue')]
    style = Style(*rules)

    assert style == 'redgreenblue'

    # Create mockup renderfunc
    rendertype = RenderType

    def renderfunc(*args, **kwargs):
        return ''.join(map(str, args)) + ':'

    renderfuncs = {rendertype: renderfunc}

# Generated at 2022-06-26 04:27:10.496117
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    register_0 = Register()
    register_0.rgb_call
    register_0.rgb_call(100,200,50)
    register_0.set_rgb_call(RenderType)
    register_0.rgb_call(100,200,50)


# Generated at 2022-06-26 04:27:23.177305
# Unit test for method unmute of class Register
def test_Register_unmute():
    register_0 = Register()
    assert True == register_0.is_muted
    assert '\x1b[1m' == register_0.bold
    register_0.unmute()
    assert False == register_0.is_muted
    assert '\x1b[1m' == register_0.bold
    register_0.mute()
    assert True == register_0.is_muted
    style_0 = Style(RenderType(1))
    assert '\x1b[1m' == str(style_0)
    assert '\x1b[1m' == register_0.bold
    register_0.unmute()
    assert False == register_0.is_muted
    style_0 = Style(RenderType(1))
    assert '\x1b[1m'

# Generated at 2022-06-26 04:27:35.102742
# Unit test for constructor of class Style
def test_Style():
    # SGR
    r0 = Style(value="\x1b[0m")
    assert isinstance(r0, Style)
    assert str(r0) == "\x1b[0m"

    # SGR with value

# Generated at 2022-06-26 04:27:46.345659
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    
    from .rendertypes import SgrFg, RgbFg
    from .colorrgb import RgbFgColor

    renderfunc1 = lambda r, g, b: "renderfunc1"

    def renderfunc2(r: int, g: int, b: int) -> str: return "renderfunc2"

    register_0 = Register()

    register_0.set_renderfunc(SgrFg, renderfunc1)
    register_0.set_renderfunc(RgbFg, renderfunc2)

    register_0.set_rgb_call(SgrFg)

    assert register_0(1, 2, 3) == "renderfunc1", "test_Register_set_rgb_call: ERROR"

    register_0.set_rgb_call(RgbFg)

    assert register_0

# Generated at 2022-06-26 04:27:53.758558
# Unit test for method set_rgb_call of class Register
def test_Register_set_rgb_call():
    from .rendertype import RgbBg

    class FakeRenderType(RenderType):
        pass

    register_0 = Register()

    register_0.set_rgb_call(FakeRenderType)
    assert register_0.rgb_call is register_0.renderfuncs[FakeRenderType]

    register_0.set_rgb_call(RgbBg)
    assert register_0.rgb_call is register_0.renderfuncs[RgbBg]


# Generated at 2022-06-26 04:28:05.972467
# Unit test for method mute of class Register
def test_Register_mute():
    # Setup
    register_0 = Register()
    register_0.set_renderfunc(RenderType.Sgr, lambda *args: "1")
    register_0.set_renderfunc(RenderType.RgbBg, lambda *args: "2")
    register_0.x = Style(RenderType.RgbBg(3,3,3)) # type: ignore
    register_0.y = Style(RenderType.RgbBg(3,3,3), RenderType.Sgr(1)) # type: ignore

    # Exercise
    register_0.mute()

    # Verify
    assert register_0.x == ""
    assert register_0.y == ""



# Generated at 2022-06-26 04:28:08.057767
# Unit test for method __new__ of class Style
def test_Style___new__():
    style = Style("test")
    assert style == "test"



# Generated at 2022-06-26 04:28:16.966651
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    f1 = lambda x: x
    f2 = lambda x: x
    f3 = lambda x: x

    register_0 = Register()
    register_0.set_renderfunc(RgbFg, f1)
    register_0.set_renderfunc(RgbBg, f2)
    register_0.set_renderfunc(Sgr, f3)

    register_0.a = Style(RgbFg(1, 2, 3), Sgr(1))
    register_0.b = Style(RgbBg(4, 5, 6), Sgr(7))
    register_0.c = Style(RgbFg(1, 2, 3), Sgr(8))
    register_0.d = Style(RgbBg(4, 5, 6), Sgr(9))


# Generated at 2022-06-26 04:28:23.352421
# Unit test for method __setattr__ of class Register
def test_Register___setattr__():

    def test_0():
        register_0 = Register()
        register_0.string_0 = "string_0"

    def test_1():
        register_0 = Register()
        register_0.style_0 = Style()

    test_0()
    test_1()



# Generated at 2022-06-26 04:28:25.946595
# Unit test for method mute of class Register
def test_Register_mute():
    register_0 = Register()
    register_0.set_renderfunc(RenderType, lambda x: x)
    register_0.mute() # We call the mute function here
    assert register_0.is_muted == True
