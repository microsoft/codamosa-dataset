

# Generated at 2022-06-17 23:32:33.935119
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('def f():\n    return 1')

# Generated at 2022-06-17 23:32:45.526212
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty(self):
            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON)
            self.assertEqual(result.count, 0)

# Generated at 2022-06-17 23:32:50.315665
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result
    from .utils.test_helpers import assert_compilation_error
    from .utils.test_helpers import assert_transformation_error
    from .utils.test_helpers import assert_transformation_error_on_code
    from .utils.test_helpers import assert_transformation_error_on_tree
    from .utils.test_helpers import assert_transformation_error_on_code_and_tree
    from .utils.test_helpers import assert_transformation_error_on_code_and_tree_and_dependencies

# Generated at 2022-06-17 23:32:59.170757
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .transformers import transformers

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6

    result = compile_files(input_, output, target)
    assert result.count == 3
    assert result.target == target
    assert result.dependencies == []

    for transformer in transformers:
        if transformer.target < target:
            continue
        assert transformer.__name__ in result.dependencies

    for paths in get_input_output_paths(input_, output):
        assert Path(paths.output).is_file()

# Generated at 2022-06-17 23:33:08.483618
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('print(1)')


# Generated at 2022-06-17 23:33:15.412092
# Unit test for function compile_files
def test_compile_files():
    from .utils.test_utils import assert_compilation_result
    from .utils.test_utils import assert_compilation_error
    from .utils.test_utils import assert_transformation_error

    assert_compilation_result(compile_files, 'tests/data/compile_files',
                              'tests/data/compile_files_output',
                              CompilationTarget.PYTHON)

    assert_compilation_result(compile_files, 'tests/data/compile_files',
                              'tests/data/compile_files_output',
                              CompilationTarget.PYTHON,
                              'tests/data/compile_files/a.py')


# Generated at 2022-06-17 23:33:20.011522
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_compiled
    from .utils.test_data import test_data_dependencies
    from .utils.test_data import test_data_dependencies_compiled
    from .utils.test_data import test_data_dependencies_compiled_with_root
    from .utils.test_data import test_data_dependencies_compiled_with_root_and_target
    from .utils.test_data import test_data_dependencies_compiled_with_target
    from .utils.test_data import test_data_dependencies_with_root
    from .utils.test_data import test_data_dependencies_with_root_and_target

# Generated at 2022-06-17 23:33:23.249076
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_compilation_result
    assert_compilation_result(compile_files(get_test_path('input'),
                                            get_test_path('output'),
                                            CompilationTarget.PYTHON))

# Generated at 2022-06-17 23:33:32.508175
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1')


# Generated at 2022-06-17 23:33:41.694470
# Unit test for function compile_files
def test_compile_files():
    """Test compile_files function."""
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    result = compile_files(input_, output, CompilationTarget.PYTHON)
    assert_compilation_result(result, CompilationTarget.PYTHON, 2,
                              ['a.py', 'b.py'])

    assert Path(output, 'a.py').read_text() == 'a = 1\n'
    assert Path(output, 'b.py').read_text() == 'b = 2\n'

# Generated at 2022-06-17 23:33:55.058292
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.test_dir, 'input')
            self.output_dir = os.path.join(self.test_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_compile_files(self):
            input_file = os.path.join(self.input_dir, 'test.py')

# Generated at 2022-06-17 23:34:04.735933
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:34:11.544795
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')

            compile

# Generated at 2022-06-17 23:34:21.881862
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal

    debug(lambda: 'Compiling files')
    input_ = Path(__file__).parent.parent / 'tests' / 'input'
    output = Path(__file__).parent.parent / 'tests' / 'output'
    target = CompilationTarget.PYTHON_3_7
    result = compile_files(input_, output, target)
    assert_equal(result.count, 2)
    assert_equal(result.target, target)
    assert_equal(result.dependencies, [])
    assert_equal(result.time, 0)

# Generated at 2022-06-17 23:34:32.335171
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:34:41.354831
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:51.899238
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .exceptions import CompilationError
    from .utils.helpers import get_test_path

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        input_ = get_test_path('compiler', 'input')
        output = tmpdir / 'output'
        result = compile_files(input_, output, CompilationTarget.PYTHON)
        assert result.count == 2
        assert result.target == CompilationTarget.PYTHON
        assert result.dependencies == ['numpy']
        assert result.time > 0
        assert (output / 'file1.py').exists()
        assert (output / 'file2.py').exists()


# Generated at 2022-06-17 23:35:01.744952
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_compile_files(self):
            input_ = os.path.join(self.temp_dir, 'input')
            output = os.path.join(self.temp_dir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'a.py'), 'w') as f:
                f.write('a = 1')


# Generated at 2022-06-17 23:35:11.925467
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:35:16.781924
# Unit test for function compile_files
def test_compile_files():
    from .utils.test_helpers import assert_compilation_result
    from .utils.test_helpers import assert_compilation_error
    from .utils.test_helpers import assert_transformation_error
    from .utils.test_helpers import assert_compilation_target
    from .utils.test_helpers import assert_compilation_result_equal
    from .utils.test_helpers import assert_compilation_result_not_equal
    from .utils.test_helpers import assert_compilation_result_less
    from .utils.test_helpers import assert_compilation_result_less_equal
    from .utils.test_helpers import assert_compilation_result_greater
    from .utils.test_helpers import assert_compilation_result_greater_equal

# Generated at 2022-06-17 23:35:37.510873
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import importlib
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)
            self.input_file = os.path.join(self.input_dir, 'test.py')
            self.output_file = os.path.join(self.output_dir, 'test.py')
            self.input_

# Generated at 2022-06-17 23:35:44.726828
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal_files
    from .utils.test_helpers import assert_equal_dependencies
    from .utils.test_helpers import assert_equal_count
    from .utils.test_helpers import assert_equal_time
    from .utils.test_helpers import assert_equal_target

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6

    result = compile_files(input_, output, target)

    assert_equal_files(input_, output)

# Generated at 2022-06-17 23:35:55.379103
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.tmp_dir, 'input')
            self.output_dir = os.path.join(self.tmp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)

        def test_compile_files(self):
            input_file = os.path.join(self.input_dir, 'test.py')
            output

# Generated at 2022-06-17 23:36:04.923416
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:36:16.454493
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:36:23.072172
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')


# Generated at 2022-06-17 23:36:34.030807
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:36:39.147382
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.tmpdir, 'input')
            self.output_dir = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-17 23:36:48.251546
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import get_input_output_paths
    from .utils.helpers import debug
    from .transformers import transformers

    # Create temporary directories
    input_ = 'test_input'
    output = 'test_output'
    os.mkdir(input_)
    os.mkdir(output)

    # Create test files
    with open(os.path.join(input_, 'test.py'), 'w') as f:
        f.write('def f():\n    print(1)\n')
    with open(os.path.join(input_, 'test2.py'), 'w') as f:
        f.write('def f():\n    print(1)\n')

    # Compile files

# Generated at 2022-06-17 23:36:57.529545
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary file
    temp_file = os.path.join(temp_dir, 'test.py')
    with open(temp_file, 'w') as f:
        f.write('print("Hello world!")')

    # Compile file
    compile_files(temp_dir, temp_dir, CompilationTarget.ES5)

    # Check that compiled file exists
    assert os.path.exists(os.path.join(temp_dir, 'test.js'))

    # Run compiled file

# Generated at 2022-06-17 23:37:42.117862
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import assert_same_files
    from .utils.test_helpers import assert_same_dirs
    from .utils.test_helpers import assert_same_dirs_recursive
    from .utils.test_helpers import assert_same_dirs_recursive_with_excludes
    from .utils.test_helpers import assert_same_dirs_recursive_with_includes
    from .utils.test_helpers import assert_same_dirs_recursive_with_includes_excludes
    from .utils.test_helpers import assert_same_dirs_recursive_with

# Generated at 2022-06-17 23:37:46.674020
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')
            compile

# Generated at 2022-06-17 23:37:56.935141
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:38:07.795334
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:38:18.118114
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:38:27.518765
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    input_ = os.path.join(os.path.dirname(__file__), '..', 'tests', 'data', 'compile')
    output = tempfile.mkdtemp()
    try:
        result = compile_files(input_, output, CompilationTarget.PYTHON)
        assert result.count == 2
        assert result.target == CompilationTarget.PYTHON
        assert result.dependencies == ['math', 'random']
    finally:
        shutil.rmtree(output)

# Generated at 2022-06-17 23:38:37.386243
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug

# Generated at 2022-06-17 23:38:46.139934
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test

# Generated at 2022-06-17 23:38:49.227844
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 23:38:57.711115
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    from .utils.helpers import get_test_path

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_compile_files(self):
            from .exceptions import CompilationError
            from .types import CompilationTarget

           