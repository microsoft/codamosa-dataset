

# Generated at 2022-06-17 23:32:35.815861
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty_input(self):
            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON)
            self.assertEqual(result.count, 0)
            self

# Generated at 2022-06-17 23:32:47.461540
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_utils import get_test_path

    debug(lambda: 'Compiling files')
    result = compile_files(get_test_path('input'),
                           get_test_path('output'),
                           CompilationTarget.ES5)
    debug(lambda: 'Compiled {} files in {}s'.format(result.count, result.time))
    debug(lambda: 'Dependencies: {}'.format(result.dependencies))

    debug(lambda: 'Checking files')

# Generated at 2022-06-17 23:32:55.915589
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    result = compile_files(input_, output, CompilationTarget.PYTHON)
    assert_compilation_result(result, CompilationTarget.PYTHON,
                              [Path('a.py'), Path('b.py'), Path('c.py')],
                              [Path('a.py'), Path('b.py'), Path('c.py')])

# Generated at 2022-06-17 23:33:07.013280
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')


# Generated at 2022-06-17 23:33:18.352175
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import subprocess

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_with_root(input_: str, output: str, target: CompilationTarget,
                                 root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:33:25.808149
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_data_path
    from .utils.test_helpers import get_test_output_path
    from .utils.test_helpers import get_test_input_path
    from .utils.test_helpers import assert_files_equal
    from .utils.test_helpers import assert_files_not_equal
    from .utils.test_helpers import assert_files_not_exist
    from .utils.test_helpers import assert_files_exist
    from .utils.test_helpers import assert_files_exist_and_equal
    from .utils.test_helpers import assert_files_exist_and_not_equal

# Generated at 2022-06-17 23:33:35.518297
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()
            self.input_file = os.path.join(self.input_dir, 'test.py')
            self.output_file = os.path.join(self.output_dir, 'test.py')

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)


# Generated at 2022-06-17 23:33:44.362091
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:54.367275
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .transformers import transformers
    from .types import CompilationTarget

    def _get_test_path(name: str) -> Path:
        return get_test_path('compiler', name)

    def _get_compilation_result(input_: str, output: str, target: CompilationTarget) -> CompilationResult:
        return compile_files(_get_test_path(input_), _get_test_path(output), target)

    def _get_transformer_names(transformers: List[type]) -> List[str]:
        return [transformer.__name__ for transformer in transformers]

    def _get_dependencies(result: CompilationResult) -> List[str]:
        return result.dependencies


# Generated at 2022-06-17 23:34:04.304893
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .utils.helpers import get_test_data_path

    input_ = get_test_data_path('compile_files', 'input')
    output = tempfile.mkdtemp()

# Generated at 2022-06-17 23:34:21.936595
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()
            self.root = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)
            shutil.rmtree(self.root)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:34:32.331977
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug

    def _transform(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:
        """Applies all transformation for passed target."""
        debug(lambda: 'Compiling "{}"'.format(path))
        dependencies = []  # type: List[str]
        tree = ast.parse(code, path)
        debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))

        for transformer in transformers:
            if transformer.target < target:
                debug(lambda: 'Skip transformer "{}"'.format(transformer.__name__))
               

# Generated at 2022-06-17 23:34:38.725862
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_compiled
    from .utils.test_data import test_data_dependencies

    for target in CompilationTarget:
        result = compile_files(get_test_path('input'),
                               get_test_path('output'),
                               target)

        assert result.count == len(test_data)
        assert result.target == target
        assert result.dependencies == test_data_dependencies[target]

        for path in test_data:
            with open(get_test_path('output', path)) as f:
                assert f.read() == test_data_compiled[target][path]

# Generated at 2022-06-17 23:34:47.173890
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    input_ = os.path.join(os.path.dirname(__file__), '..', 'tests', 'input')
    output = tempfile.mkdtemp()
    try:
        result = compile_files(input_, output, CompilationTarget.PYTHON)
        assert result.count == 3
        assert result.target == CompilationTarget.PYTHON
        assert result.dependencies == ['a.py', 'b.py']
    finally:
        shutil.rmtree(output)

# Generated at 2022-06-17 23:34:57.291897
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write('a = 1\n')

            compile_files(self.input_dir, self.output_dir,
                          CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:35:06.974663
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write('a = 1\n')

            compile_files(self.input_dir, self.output_dir,
                          CompilationTarget.PYTHON_TO_PYTHON)

# Generated at 2022-06-17 23:35:16.168107
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write('print(1)')

            compile_files(self.input_dir, self.output_dir,
                          CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:35:22.256576
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'a.py'), 'w') as f:
                f.write('def f():\n    return 1\n')


# Generated at 2022-06-17 23:35:28.151268
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')


# Generated at 2022-06-17 23:35:36.205745
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_with_exception(input_: str, output: str, target: CompilationTarget,
                                      root: Optional[str] = None) -> CompilationResult:
        with pytest.raises(CompilationError):
            return compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:35:57.205607
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:36:05.578115
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal_files

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path('compile_files', 'root')

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        assert_equal_files(paths.input, paths.output)

# Generated at 2022-06-17 23:36:16.746385
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def test():\n    pass\n')
           

# Generated at 2022-06-17 23:36:23.256815
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .files import get_input_output_paths
    from .transformers import transformers

    def _create_file(path: str, content: str) -> None:
        with open(path, 'w') as f:
            f.write(content)

    def _assert_file(path: str, content: str) -> None:
        with open(path, 'r') as f:
            assert f.read() == content


# Generated at 2022-06-17 23:36:34.109966
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal
    from .utils.test_helpers import assert_exception
    from .utils.test_helpers import assert_not_exception
    from .utils.test_helpers import assert_true
    from .utils.test_helpers import assert_false
    from .utils.test_helpers import assert_in
    from .utils.test_helpers import assert_not_in
    from .utils.test_helpers import assert_is_instance
    from .utils.test_helpers import assert_is_not_none
    from .utils.test_helpers import assert_is_none

# Generated at 2022-06-17 23:36:39.251442
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def _compile_file(input_: str, output: str, target: CompilationTarget,
                      root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _run_file(path: str) -> str:
        return subprocess.check_output([sys.executable, path]).decode()


# Generated at 2022-06-17 23:36:48.300435
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data

    for test in test_data:
        input_ = get_test_path(test['input'])
        output = get_test_path(test['output'])
        target = test['target']
        expected_result = test['result']
        result = compile_files(input_, output, target)
        assert result.count == expected_result['count']
        assert result.time >= expected_result['time']
        assert result.target == expected_result['target']
        assert result.dependencies == expected_result['dependencies']


# Generated at 2022-06-17 23:36:57.621411
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty(self):
            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON)
            self.assertEqual(result.count, 0)

# Generated at 2022-06-17 23:37:05.132088
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    def _create_file(path: str, content: str) -> None:
        with open(path, 'w') as f:
            f.write(content)

    def _assert_file(path: str, content: str) -> None:
        with open(path, 'r') as f:
            assert f.read() == content

    def _assert_dir(path: str, content: List[str]) -> None:
        for name in content:
            assert os.path.exists(os.path.join(path, name))

    def _assert_not_dir(path: str, content: List[str]) -> None:
        for name in content:
            assert not os.path.exists(os.path.join(path, name))


# Generated at 2022-06-17 23:37:12.745625
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_output
    from .utils.test_data import test_data_output_py3
    from .utils.test_data import test_data_output_py35
    from .utils.test_data import test_data_output_py36
    from .utils.test_data import test_data_output_py37
    from .utils.test_data import test_data_output_py38
    from .utils.test_data import test_data_output_py39
    from .utils.test_data import test_data_output_py310
    from .utils.test_data import test_data_output_py311
    from .utils.test_data import test_data_

# Generated at 2022-06-17 23:37:55.851443
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .transformers import transformers
    from .types import CompilationTarget
    from .exceptions import CompilationError

    test_path = get_test_path()
    input_ = test_path / 'input'
    output = test_path / 'output'
    target = CompilationTarget.PYTHON_3_6

    # Test compilation
    result = compile_files(input_, output, target)
    assert result.count == 2
    assert result.target == target
    assert result.dependencies == []
    assert result.time > 0

    # Test compilation with dependencies
    result = compile_files(input_, output, target, root=test_path)
    assert result.count == 2
    assert result.target == target

# Generated at 2022-06-17 23:38:00.554107
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_equal_files
    from .utils.test_utils import assert_equal_files_in_dir
    from .utils.test_utils import assert_equal_files_in_dir_recursive
    from .utils.test_utils import assert_equal_files_recursive
    from .utils.test_utils import assert_equal_files_recursive_in_dir
    from .utils.test_utils import assert_equal_files_recursive_in_dir_recursive
    from .utils.test_utils import assert_equal_files_recursive_in_dir_recursive_with_root
    from .utils.test_utils import assert_equal

# Generated at 2022-06-17 23:38:10.420948
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass\n')

           

# Generated at 2022-06-17 23:38:19.551312
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest

    from .exceptions import CompilationError
    from .types import CompilationTarget

    def run_compile_files(input_, output, target):
        return compile_files(input_, output, target,
                             os.path.dirname(__file__))

    def run_python(path):
        return subprocess.check_output([sys.executable, path],
                                       universal_newlines=True)

    def assert_compile_files(input_, output, target, expected_output,
                             expected_dependencies):
        result = run_compile_files(input_, output, target)
        assert result.count == 1
        assert result.target == target
        assert result.dependencies == expected

# Generated at 2022-06-17 23:38:22.067665
# Unit test for function compile_files
def test_compile_files():
    from .tests.test_compiler import test_compile_files
    test_compile_files()

# Generated at 2022-06-17 23:38:29.578239
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.test_helpers import assert_equal
    from .utils.test_helpers import assert_raises
    from .exceptions import CompilationError
    from .types import CompilationTarget

    # Test compilation of a single file
    input_ = Path(__file__).parent / 'test_data' / 'input' / 'simple.py'
    output = Path(__file__).parent / 'test_data' / 'output' / 'simple.py'
    result = compile_files(input_, output, CompilationTarget.PYTHON_TO_PYTHON)
    assert_equal(result.count, 1)
    assert_equal(result.target, CompilationTarget.PYTHON_TO_PYTHON)
    assert_equal(result.dependencies, [])


# Generated at 2022-06-17 23:38:40.286558
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path

# Generated at 2022-06-17 23:38:46.780680
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal_files

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    expected = get_test_path('compile_files', 'expected')

    compile_files(input_, output, CompilationTarget.PYTHON)

    for path in Path(input_).rglob('*.py'):
        assert_equal_files(Path(output) / path.relative_to(input_),
                           Path(expected) / path.relative_to(input_))

# Generated at 2022-06-17 23:38:54.000341
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:39:02.655234
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.root = tempfile.mkdtemp()
            self.input_ = os.path.join(self.root, 'input')
            self.output = os.path.join(self.root, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.root)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:40:18.971626
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug

    debug(lambda: 'Compile files')
    input_ = Path(__file__).parent / 'test_files'
    output = Path(__file__).parent / 'test_files_output'
    target = CompilationTarget.PYTHON_TO_PYTHON
    result = compile_files(input_, output, target)
    debug(lambda: 'Compiled {} files in {} seconds'.format(result.count, result.time))
    debug(lambda: 'Dependencies: {}'.format(result.dependencies))

# Generated at 2022-06-17 23:40:25.974380
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:40:35.400941
# Unit test for function compile_files
def test_compile_files():
    from .test.test_transformers import test_transformers
    from .test.test_utils import get_test_path
    from .test.test_files import test_get_input_output_paths
    from .test.test_types import test_compilation_result
    from .test.test_exceptions import test_compilation_error
    from .test.test_utils import test_debug
    from .test.test_helpers import test_debug as test_debug_helper

    test_transformers()
    test_get_input_output_paths()
    test_compilation_result()
    test_compilation_error()
    test_debug()
    test_debug_helper()

    input_ = get_test_path('compile_files/input')

# Generated at 2022-06-17 23:40:41.393491
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal_files

    input_ = get_test_path('test_compile_files', 'input')
    output = get_test_path('test_compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6

    compile_files(input_, output, target)

    for paths in get_input_output_paths(input_, output):
        assert_equal_files(paths.output, paths.input)

# Generated at 2022-06-17 23:40:47.752579
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:40:58.576144
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass\n')
           

# Generated at 2022-06-17 23:41:05.625240
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_5

    result = compile_files(input_, output, target)
    assert result.count == 3
    assert result.target == target
    assert result.dependencies == ['sys', 'typing']
    assert result.time > 0


# Generated at 2022-06-17 23:41:10.694243
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:41:20.185289
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')
            compile_files

# Generated at 2022-06-17 23:41:29.064600
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)
