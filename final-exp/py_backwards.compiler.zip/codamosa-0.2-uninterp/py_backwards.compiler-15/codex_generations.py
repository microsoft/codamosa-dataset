

# Generated at 2022-06-17 23:32:32.494428
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()

# Generated at 2022-06-17 23:32:43.357359
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:32:54.559544
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess

    def run_tests(target: CompilationTarget):
        with tempfile.TemporaryDirectory() as tmpdirname:
            input_ = os.path.join(tmpdirname, 'input')
            output = os.path.join(tmpdirname, 'output')
            os.mkdir(input_)
            os.mkdir(output)
            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('print("Hello, World!")')
            compile_files(input_, output, target)
            assert os.path.isfile(os.path.join(output, 'test.py'))

# Generated at 2022-06-17 23:33:05.739388
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            input_path = os.path.join(self.input_dir, 'test.py')
            output_path = os.path.join(self.output_dir, 'test.py')


# Generated at 2022-06-17 23:33:16.464184
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal, assert_not_equal, assert_in
    from .utils.test_helpers import assert_not_in, assert_is_instance, assert_is_not_none
    from .utils.test_helpers import assert_is_none, assert_true, assert_false
    from .utils.test_helpers import assert_greater_equal, assert_less_equal, assert_greater
    from .utils.test_helpers import assert_less, assert_is, assert_is_not, assert_is_in
    from .utils.test_helpers import assert_is_not_in
    from .utils.test_helpers import assert_

# Generated at 2022-06-17 23:33:25.256015
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    from .exceptions import CompilationError

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> CompilationResult:
        """Compiles all files from input_ to output."""
        dependencies = set()
        start = time()
        count = 0
        for paths in get_input_output_paths(input_, output, root):
            count += 1
            dependencies.update(_compile_file(paths, target))
        return CompilationResult(count, time() - start, target,
                                 sorted(dependencies))


# Generated at 2022-06-17 23:33:35.106927
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:33:43.991100
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:33:54.218579
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('print(1)')


# Generated at 2022-06-17 23:34:04.213448
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    debug(lambda: 'Created temporary directory "{}"'.format(tmpdir))

    # Create input directory
    input_ = os.path.join(tmpdir, 'input')
    os.mkdir(input_)
    debug(lambda: 'Created input directory "{}"'.format(input_))

    # Create output directory
    output = os.path.join(tmpdir, 'output')
    os.mkdir(output)
    debug(lambda: 'Created output directory "{}"'.format(output))

    # Create input file

# Generated at 2022-06-17 23:34:21.908088
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:34:32.333180
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_data_path
    from .exceptions import CompilationError
    from .types import CompilationTarget

    input_ = get_test_data_path('compile_files', 'input')
    output = get_test_data_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6

    result = compile_files(input_, output, target)
    assert result.count == 2
    assert result.target == target
    assert result.dependencies == ['os', 'sys', 'time']

    with Path(output, 'a.py').open() as f:
        assert f.read() == 'import os\nimport sys\nimport time\n'


# Generated at 2022-06-17 23:34:38.967421
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from .exceptions import CompilationError
    from .types import CompilationTarget

    def _test(input_: str, output: str, target: CompilationTarget,
              root: Optional[str] = None,
              expected_dependencies: Optional[List[str]] = None,
              expected_error: Optional[CompilationError] = None):
        try:
            result = compile_files(input_, output, target, root)
        except CompilationError as e:
            assert expected_error is not None
            assert e == expected_error
        else:
            assert expected_error is None
            assert result.dependencies == expected_dependencies

    # Test for correct compilation
    tmp_dir = mkdtemp()

# Generated at 2022-06-17 23:34:49.785166
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_output_path
    from .utils.helpers import remove_test_output_path
    from .utils.helpers import assert_files_equal

    remove_test_output_path()
    input_ = get_test_data_path('compile_files')
    output = get_test_output_path()
    target = CompilationTarget.PYTHON_3_6
    result = compile_files(input_, output, target)
    assert result.count == 4
    assert result.target == target
    assert result.dependencies == ['os', 'sys']

# Generated at 2022-06-17 23:35:00.561030
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:35:10.679061
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal

    debug(lambda: 'Start unit test for function compile_files')

    input_ = os.path.join(os.path.dirname(__file__), '..', 'test', 'input')
    output = os.path.join(os.path.dirname(__file__), '..', 'test', 'output')
    target = CompilationTarget.PYTHON_3_6

    shutil.rmtree(output, ignore_errors=True)

    result = compile_files(input_, output, target)

    assert_equal(result.count, 3)

# Generated at 2022-06-17 23:35:17.882966
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _create_file(path: str, content: str) -> None:
        with open(path, 'w') as f:
            f.write(content)

    def _assert_file_content(path: str, content: str) -> None:
        with open(path) as f:
            assert f.read() == content

    def _assert_result(result: CompilationResult, count: int,
                       dependencies: List[str]) -> None:
        assert result.count == count
        assert result.target == CompilationTarget.PY

# Generated at 2022-06-17 23:35:24.612510
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'a.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:35:29.902713
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys

    def run_compile_files(input_: str, output: str, target: CompilationTarget,
                          root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def run_compile_files_with_root(input_: str, output: str, target: CompilationTarget,
                                    root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:35:36.870113
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1')


# Generated at 2022-06-17 23:35:49.585118
# Unit test for function compile_files
def test_compile_files():
    from .tests.test_compile_files import test_compile_files
    test_compile_files()

# Generated at 2022-06-17 23:35:59.927551
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()
            self.target = CompilationTarget.PYTHON_3_6

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

            result = compile_files(self.input_, self.output, self.target)
            self.assertE

# Generated at 2022-06-17 23:36:07.214667
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('x = 1\n')

# Generated at 2022-06-17 23:36:17.509750
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .utils.files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .utils.files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .utils.files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import Comp

# Generated at 2022-06-17 23:36:23.658618
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .exceptions import CompilationError

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:36:34.312388
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.tempdir, 'input')
            self.output_dir = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:36:39.404810
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:36:48.470837
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty(self):
            result = compile_files(self.input, self.output,
                                   CompilationTarget.PYTHON)
            self.assertEqual(result.count, 0)


# Generated at 2022-06-17 23:36:57.742258
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result
    from .utils.test_helpers import assert_compilation_error
    from .utils.test_helpers import assert_transformation_error
    from .utils.test_helpers import assert_compilation_target
    from .utils.test_helpers import assert_compilation_result_equal
    from .utils.test_helpers import assert_compilation_result_not_equal
    from .utils.test_helpers import assert_compilation_result_less
    from .utils.test_helpers import assert_compilation_result_less_equal

# Generated at 2022-06-17 23:37:05.210880
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_output_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_output_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_output_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_output_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_output_path
    from .utils.helpers import get_test_data_path
