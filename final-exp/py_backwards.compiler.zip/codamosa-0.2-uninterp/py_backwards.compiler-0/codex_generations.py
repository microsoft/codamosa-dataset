

# Generated at 2022-06-17 23:32:32.202183
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .files import get_input_output_paths
    from .types import CompilationTarget

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        input_ = tmpdir / 'input'
        output = tmpdir / 'output'
        input_.mkdir()
        output.mkdir()

        (input_ / 'a.py').write_text('a = 1')
        (input_ / 'b.py').write_text('b = 2')

        result = compile_files(input_, output, CompilationTarget.PYTHON)
        assert result.count == 2
        assert result.target == CompilationTarget.PYTHON
        assert result.dependencies == []

        assert (output / 'a.py').read_text()

# Generated at 2022-06-17 23:32:43.073090
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import subprocess

    def run_test(input_: str, output: str, target: CompilationTarget,
                 root: Optional[str] = None) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            input_path = os.path.join(temp_dir, input_)
            output_path = os.path.join(temp_dir, output)
            os.makedirs(os.path.dirname(input_path))
            os.makedirs(os.path.dirname(output_path))
            with open(input_path, 'w') as f:
                f.write('print("Hello, world!")')
            compile_files(input_path, output_path, target, root)
            subprocess.check_call

# Generated at 2022-06-17 23:32:54.301818
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1')
            compile

# Generated at 2022-06-17 23:33:01.491246
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result

    result = compile_files(get_test_path('input'),
                           get_test_path('output'),
                           CompilationTarget.PYTHON)
    assert_compilation_result(result, CompilationTarget.PYTHON,
                              [get_test_path('output/test.py')],
                              [get_test_path('input/test.py')])

# Generated at 2022-06-17 23:33:10.099707
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .types import CompilationTarget
    from .exceptions import CompilationError

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 23:33:20.387017
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:33:26.687025
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f(x):\n    return x + 1\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:33:36.241239
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import json

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Copy test files to temporary directory
    shutil.copytree(os.path.join(os.path.dirname(__file__), 'test'),
                    os.path.join(tmpdir, 'test'))
    # Change working directory to temporary directory
    os.chdir(tmpdir)
    # Run tests
    result = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'test'],
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # Remove temporary directory
    shutil.rmtree(tmpdir)
   

# Generated at 2022-06-17 23:33:44.918726
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)
            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('print(1)')

# Generated at 2022-06-17 23:33:54.464701
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.mocks import mock_compile_file
    from .utils.test_helpers import assert_compilation_result

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.ES5
    root = get_test_path('root')
    paths = list(get_input_output_paths(input_, output, root))
    result = compile_files(input_, output, target, root)

    assert_compilation_result(result, target, paths)
    for paths in paths:
        mock_compile_file.assert_any_call(paths, target)

# Generated at 2022-06-17 23:34:08.010265
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .transformers import transformers
    from .types import CompilationTarget

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON
    root = get_test_path('compile_files')

    result = compile_files(input_, output, target, root)
    assert result.count == 2
    assert result.target == target
    assert result.dependencies == []

    for transformer in transformers:
        if transformer.target < target:
            continue

        assert transformer.__name__ in result.dependencies


# Generated at 2022-06-17 23:34:13.488001
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest
    from .files import get_input_output_paths

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, World!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:22.064706
# Unit test for function compile_files
def test_compile_files():
    from .utils.test_helpers import assert_compilation_result
    from .utils.test_helpers import assert_compilation_error
    from .utils.test_helpers import assert_transformation_error
    from .utils.test_helpers import assert_compilation_target
    from .utils.test_helpers import assert_compilation_dependencies
    from .utils.test_helpers import assert_compilation_time
    from .utils.test_helpers import assert_compilation_count
    from .utils.test_helpers import assert_compilation_output
    from .utils.test_helpers import assert_compilation_input
    from .utils.test_helpers import assert_compilation_root
    from .utils.test_helpers import assert_compilation_result_equal

# Generated at 2022-06-17 23:34:32.332344
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'file.py'), 'w') as f:
                f.write('print("Hello, world!")')


# Generated at 2022-06-17 23:34:41.354818
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .transformers import transformers
    from .types import CompilationTarget

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_TO_JAVASCRIPT
    root = get_test_path('root')

    result = compile_files(input_, output, target, root)
    assert result.count == 2
    assert result.target == target

# Generated at 2022-06-17 23:34:51.898475
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            os.mkdir(self.input_)
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')


# Generated at 2022-06-17 23:35:01.746029
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')
            compile

# Generated at 2022-06-17 23:35:11.925547
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result
    from .utils.test_helpers import assert_compilation_error
    from .utils.test_helpers import assert_transformation_error
    from .utils.test_helpers import assert_compilation_result_equal
    from .utils.test_helpers import assert_compilation_result_not_equal
    from .utils.test_helpers import assert_compilation_result_less
    from .utils.test_helpers import assert_compilation_result_less_equal
    from .utils.test_helpers import assert_compilation_result_greater

# Generated at 2022-06-17 23:35:16.781800
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:35:23.557246
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')


# Generated at 2022-06-17 23:35:44.421083
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_test(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> CompilationResult:
        with tempfile.TemporaryDirectory() as tmpdir:
            input_path = os.path.join(tmpdir, input_)
            output_path = os.path.join(tmpdir, output)
            os.makedirs(input_path)
            result = _compile_files(input_path, output_path, target, root)
            assert result

# Generated at 2022-06-17 23:35:55.259480
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 42\n')



# Generated at 2022-06-17 23:36:04.823737
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_and_run(input_: str, output: str, target: CompilationTarget,
                               root: Optional[str] = None) -> CompilationResult:
        result = _compile_files(input_, output, target, root)
        subprocess.run([sys.executable, output], check=True)
        return result


# Generated at 2022-06-17 23:36:16.396185
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_equal_files
    from .utils.test_utils import assert_equal_dependencies
    from .utils.test_utils import assert_equal_result
    from .utils.test_utils import assert_equal_target

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6

    result = compile_files(input_, output, target)

    assert_equal_result(result, count=2, time=0.0, target=target,
                        dependencies=['a', 'b', 'c'])


# Generated at 2022-06-17 23:36:22.599984
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal_files

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_TO_PYTHON
    root = get_test_path('compile_files')

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        assert_equal_files(paths.input, paths.output)

# Generated at 2022-06-17 23:36:33.875916
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import filecmp

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 23:36:38.985655
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:36:47.880986
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test

# Generated at 2022-06-17 23:36:57.210278
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1\n')


# Generated at 2022-06-17 23:37:04.734875
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug

    def _transform(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:
        """Applies all transformation for passed target."""
        debug(lambda: 'Compiling "{}"'.format(path))
        dependencies = []  # type: List[str]
        tree = ast.parse(code, path)
        debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))
