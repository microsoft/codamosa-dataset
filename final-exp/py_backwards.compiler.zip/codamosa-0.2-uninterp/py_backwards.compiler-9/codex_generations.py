

# Generated at 2022-06-17 23:32:36.418262
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:32:48.146779
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import unittest
    import re

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            self.input_file = os.path.join(self.input_dir, 'test.py')
            self.output_file = os.path.join(self.output_dir, 'test.py')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

# Generated at 2022-06-17 23:32:57.520824
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')

            compile

# Generated at 2022-06-17 23:33:07.927265
# Unit test for function compile_files
def test_compile_files():
    from . import __file__ as module_path
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .utils.helpers import get_test_data_path

    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        result = compile_files(get_test_data_path('test_compile_files'),
                               temp_dir, CompilationTarget.PYTHON)
        assert result.count == 2
        assert result.target == CompilationTarget.PYTHON
        assert result.dependencies == [module_path]
        assert (temp_dir / 'test_compile_files' / 'test.py').is_file()
        assert (temp_dir / 'test_compile_files' / 'test2.py').is_file()

# Generated at 2022-06-17 23:33:18.608036
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:33:25.929280
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:33:35.622912
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .transformers import transformers
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug

# Generated at 2022-06-17 23:33:44.442772
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .exceptions import CompilationError

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:33:54.392192
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, World!")')

            result

# Generated at 2022-06-17 23:34:04.332676
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty(self):
            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON)
            self.assertEqual(result.count, 0)

# Generated at 2022-06-17 23:34:15.311157
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path

# Generated at 2022-06-17 23:34:23.012663
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test

# Generated at 2022-06-17 23:34:32.475636
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> CompilationResult:
        tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 23:34:40.256623
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create test files
    with open(os.path.join(temp_dir, 'test.py'), 'w') as f:
        f.write('print("Hello, World!")')

    # Compile files
    result = compile_files(temp_dir, temp_dir, CompilationTarget.PYTHON27)

    # Check result
    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON27
    assert result.dependencies == []

    # Remove temporary directory
    shutil.rmtree(temp_dir)

# Generated at 2022-06-17 23:34:50.217034
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> CompilationResult:
        """Compiles all files from input_ to output."""
        dependencies = set()
        start = time()
        count = 0
        for paths in get_input_output_paths(input_, output, root):
            count += 1
            dependencies.update(_compile_file(paths, target))
        return CompilationResult(count, time() - start, target,
                                 sorted(dependencies))


# Generated at 2022-06-17 23:35:01.053977
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def run_py_file(path: str) -> str:
        return subprocess.check_output([sys.executable, path]).decode()

    def run_js_file(path: str) -> str:
        return subprocess.check_output(['node', path]).decode()

    def run_file(path: str, target: CompilationTarget) -> str:
        if target == CompilationTarget.PYTHON:
            return run_py_file(path)
        elif target == CompilationTarget.JAVASCRIPT:
            return run_js_file(path)


# Generated at 2022-06-17 23:35:11.227287
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:35:18.367054
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_paths_equal
    from .utils.test_helpers import assert_files_equal

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    root = get_test_path('compile_files')

    compile_files(input_, output, CompilationTarget.PYTHON_3)

    for paths in get_input_output_paths(input_, output, root):
        assert_paths_equal(paths.input, paths.output)
        assert_files_equal(paths.input, paths.output)

# Generated at 2022-06-17 23:35:25.002117
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .transformers import transformers
    from .utils.helpers import debug
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path

# Generated at 2022-06-17 23:35:34.761686
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.helpers import debug
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_

# Generated at 2022-06-17 23:35:55.260735
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input, 'a.py'), 'w') as f:
                f.write('def f():\n    pass')

# Generated at 2022-06-17 23:36:04.823418
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path

    debug(True)
    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path()
    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        with paths.output.open() as f:
            code = f.read()
        assert code == 'print("Hello, world!")\n'

    shutil.rmtree(output)

# Generated at 2022-06-17 23:36:16.368379
# Unit test for function compile_files
def test_compile_files():
    from . import __version__
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result

    input_ = get_test_path('test_compile_files')
    output = get_test_path('test_compile_files_output')
    result = compile_files(input_, output, CompilationTarget.PYTHON)

# Generated at 2022-06-17 23:36:22.975768
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result_equal
    from .utils.test_helpers import assert_compilation_results_equal
    from .utils.test_helpers import assert_compilation_results_not_equal
    from .utils.test_helpers import assert_compilation_results_similar
    from .utils.test_helpers import assert_compilation_results_not_similar
    from .utils.test_helpers import assert_compilation_results_similar_by_time
    from .utils.test_helpers import assert_compilation_results_not_similar_by_time

# Generated at 2022-06-17 23:36:33.974704
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal

    debug(lambda: 'Compiling "{}"'.format('test.py'))
    dependencies = []  # type: List[str]
    tree = ast.parse('print(1)', 'test.py')
    debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))

    for transformer in transformers:
        if transformer.target < CompilationTarget.PYTHON_TO_PYTHON:
            debug(lambda: 'Skip transformer "{}"'.format(transformer.__name__))
            continue


# Generated at 2022-06-17 23:36:42.015815
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import get_test_data_path

    def test_compile_files_helper(input_: str, output: str, target: CompilationTarget,
                                  root: Optional[str] = None):
        result = compile_files(input_, output, target, root)
        assert result.count == 1
        assert result.target == target
        assert result.dependencies == []
        assert result.time > 0
        assert Path(output).read_text() == Path(input_).read_text()


# Generated at 2022-06-17 23:36:51.068618
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.makedirs(self.input_dir)
            os.makedirs(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:36:59.447498
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_utils import assert_equal, assert_not_equal, assert_true, assert_false, assert_in, assert_not_in, assert_is_instance, assert_not_is_instance, assert_is_none, assert_is_not_none, assert_is, assert_is_not, assert_raises, assert_not_raises

# Generated at 2022-06-17 23:37:06.870035
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path
    from .utils.test import assert_equal_files
    from .utils.test import assert_equal_ast
    from .utils.test import assert_equal_dependencies
    from .utils.test import assert_equal_result

    def _transform(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:
        """Applies all transformation for passed target."""
        debug(lambda: 'Compiling "{}"'.format(path))
        dependencies = []  # type: List[str]
        tree = ast.parse(code, path)

# Generated at 2022-06-17 23:37:13.972044
# Unit test for function compile_files
def test_compile_files():
    from . import __path__ as package_path
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    root = Path(package_path[0])

    result = compile_files(input_, output, CompilationTarget.PYTHON, root)
    assert_compilation_result(result, 3, CompilationTarget.PYTHON,
                              ['test_compile_files.py'])

if __name__ == '__main__':
    test_compile_files()