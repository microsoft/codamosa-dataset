

# Generated at 2022-06-17 23:32:36.314180
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .exceptions import CompilationError
    from .files import get_input_output_paths

    def _create_file(path: str, content: str) -> None:
        with open(path, 'w') as f:
            f.write(content)

    def _assert_file_content(path: str, content: str) -> None:
        with open(path, 'r') as f:
            assert f.read() == content


# Generated at 2022-06-17 23:32:48.045136
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:32:56.354837
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal_files

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    expected = get_test_path('compile_files', 'expected')

    compile_files(input_, output, CompilationTarget.PYTHON)

    for paths in get_input_output_paths(input_, expected):
        assert_equal_files(paths.output, paths.input)

# Generated at 2022-06-17 23:33:07.382931
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_output
    from .utils.test_data import test_data_output_py3
    from .utils.test_data import test_data_output_py35
    from .utils.test_data import test_data_output_py36
    from .utils.test_data import test_data_output_py37
    from .utils.test_data import test_data_output_py38
    from .utils.test_data import test_data_output_py39
    from .utils.test_data import test_data_output_py310
    from .utils.test_data import test_data_output_py311
    from .utils.test_data import test_data_

# Generated at 2022-06-17 23:33:18.351461
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:33:25.808255
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:35.518588
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import assert_equal, assert_not_equal

    debug(True)
    input_ = 'tests/input'
    output = 'tests/output'
    target = CompilationTarget.PYTHON
    result = compile_files(input_, output, target)
    assert_equal(result.count, 1)
    assert_equal(result.target, target)
    assert_equal(result.dependencies, [])

    target = CompilationTarget.JAVASCRIPT
    result = compile_files(input_, output, target)
    assert_equal(result.count, 1)
    assert_equal(result.target, target)

# Generated at 2022-06-17 23:33:44.389599
# Unit test for function compile_files
def test_compile_files():
    from . import __file__ as module_path
    from .utils.helpers import get_test_data_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .transformers import transformers
    from .utils.helpers import debug
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path

# Generated at 2022-06-17 23:33:54.366857
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import assert_equal

    debug(True)
    input_ = Path(__file__).parent / 'test_files'
    output = Path(__file__).parent / 'test_files_compiled'
    target = CompilationTarget.PYTHON_2
    result = compile_files(input_, output, target)
    assert_equal(result.count, 6)
    assert_equal(result.target, target)
    assert_equal(result.dependencies, [])

# Generated at 2022-06-17 23:34:04.334459
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .types import CompilationTarget

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def test():\n    pass\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:21.937585
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug

    def _create_file(path: str, content: str) -> None:
        with open(path, 'w') as f:
            f.write(content)

    def _compile_files(input_: str, output: str, target: CompilationTarget) -> None:
        compile_files(input_, output, target)

    def _assert_file_content(path: str, content: str) -> None:
        with open(path, 'r') as f:
            assert f.read() == content

    def _assert_file_exists(path: str) -> None:
        assert os.path.exists(path)

# Generated at 2022-06-17 23:34:32.341931
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:34:41.354769
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('def f(x):\n    return x + 1\n')


# Generated at 2022-06-17 23:34:51.897371
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug

# Generated at 2022-06-17 23:35:01.746481
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.tempdir import TempDir

    with TempDir() as tempdir:
        tempdir.mkdir('input')
        tempdir.mkdir('output')
        tempdir.mkdir('input/dir')
        tempdir.mkdir('output/dir')
        tempdir.mkdir('input/dir/subdir')
        tempdir.mkdir('output/dir/subdir')
        tempdir.mkdir('input/dir/subdir/subsubdir')
        tempdir.mkdir('output/dir/subdir/subsubdir')
        tempdir.mkdir('input/dir/subdir/subsubdir/subsubsubdir')

# Generated at 2022-06-17 23:35:11.925338
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_compile_files(self):
            input_ = os.path.join(self.temp_dir, 'input')
            output = os.path.join(self.temp_dir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1')


# Generated at 2022-06-17 23:35:16.782015
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:35:22.530477
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal_files

    input_ = get_test_path('compile_files/input')
    output = get_test_path('compile_files/output')
    expected = get_test_path('compile_files/expected')
    compile_files(input_, output, CompilationTarget.PYTHON)
    for paths in get_input_output_paths(output, expected):
        assert_equal_files(paths.output, paths.input)

# Generated at 2022-06-17 23:35:28.320206
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:35:36.273079
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import json
    import sys

    def _get_test_files(path):
        return [os.path.join(path, f) for f in os.listdir(path)
                if os.path.isfile(os.path.join(path, f))]

    def _get_test_dirs(path):
        return [os.path.join(path, f) for f in os.listdir(path)
                if os.path.isdir(os.path.join(path, f))]

    def _get_test_files_recursive(path):
        files = []