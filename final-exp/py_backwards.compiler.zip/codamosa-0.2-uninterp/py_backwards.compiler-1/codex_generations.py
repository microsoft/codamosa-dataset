

# Generated at 2022-06-17 23:32:36.850371
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_compilation_result
    from .types import CompilationTarget

    result = compile_files(get_test_path('test_compile_files'),
                           get_test_path('test_compile_files_output'),
                           CompilationTarget.PYTHON_TO_PYTHON)
    assert_compilation_result(result, 1, 0, CompilationTarget.PYTHON_TO_PYTHON,
                              [])

    result = compile_files(get_test_path('test_compile_files'),
                           get_test_path('test_compile_files_output'),
                           CompilationTarget.PYTHON_TO_JS)

# Generated at 2022-06-17 23:32:48.241088
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')


# Generated at 2022-06-17 23:32:57.588983
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:33:07.956073
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:14.960923
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)
            with open(os.path.join(input_, 'a.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:33:24.238784
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON_3_6)

# Generated at 2022-06-17 23:33:33.948844
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:33:40.785323
# Unit test for function compile_files
def test_compile_files():
    from . import __file__ as module_path
    from . import __version__ as module_version
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6

    result = compile_files(input_, output, target)
    assert_compilation_result(result, target,
                              [module_path, module_version])

# Generated at 2022-06-17 23:33:47.048288
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .transformers import transformers
    from .utils.helpers import debug

    # Compile all files from input_ to output
    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON
    result = compile_files(input_, output, target)

    # Check that all files are compiled
    assert result.count == 4

    # Check that all files are compiled with all transformers
    for transformer in transformers:
        if transformer.target < target:
            continue
        assert transformer.__name__ in result.dependencies

    # Check that all files are compiled with all transformers


# Generated at 2022-06-17 23:33:55.173859
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result_equal
    from .utils.test_helpers import assert_compilation_results_equal
    from .utils.test_helpers import assert_compilation_results_not_equal
    from .utils.test_helpers import assert_compilation_target_equal
    from .utils.test_helpers import assert_compilation_target_not_equal
    from .utils.test_helpers import assert_compilation_targets_equal
    from .utils.test_helpers import assert_compilation_targets_not_equal
    from .utils.test_helpers import assert_input_

# Generated at 2022-06-17 23:34:03.116392
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .utils.helpers import debug
    from .utils.testing import get_test_path
    from tempfile import TemporaryDirectory
    import os
    import shutil

    with TemporaryDirectory() as temp_dir:
        input_ = get_test_path('test_files')
        output = os.path.join(temp_dir, 'output')
        compile_files(input_, output, CompilationTarget.PYTHON)
        for paths in get_input_output_paths(input_, output):
            with paths.input.open() as f:
                code = f.read()
            with paths.output.open() as f:
                transformed = f.read()

# Generated at 2022-06-17 23:34:08.170683
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("test")')

            result = compile_files

# Generated at 2022-06-17 23:34:13.640450
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            self.target = CompilationTarget.PYTHON
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty(self):
            result = compile_files(self.input_, self.output, self.target)

# Generated at 2022-06-17 23:34:22.158997
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)
            self.input_file = os.path.join(self.input_dir, 'test.py')
            self.output_file = os.path.join(self.output_dir, 'test.py')

# Generated at 2022-06-17 23:34:32.367727
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_path

# Generated at 2022-06-17 23:34:41.362740
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import json
    import sys

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None,
                            expected_result: Optional[CompilationResult] = None):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tmp_input = tmpdir / 'input'
            tmp_output = tmpdir / 'output'
            tmp_input.mkdir()
            tmp_output.mkdir()
            for path in Path(input_).rglob('*'):
                shutil.copy(path, tmp_input)
            result = compile_files(tmp_input, tmp_output, target, root)

# Generated at 2022-06-17 23:34:45.579814
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:34:55.816011
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')
            compile_files(self.input_, self.output, CompilationTarget.PYTHON)

# Generated at 2022-06-17 23:35:05.550023
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'file.py'), 'w') as f:
                f.write('print("Hello, world!")')


# Generated at 2022-06-17 23:35:13.727151
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug

    def _compile_files(input_: str, output: str, target: CompilationTarget):
        try:
            shutil.rmtree(output)
        except FileNotFoundError:
            pass
        compile_files(input_, output, target)
        return get_input_output_paths(input_, output)

    def _test_compile_files(input_: str, output: str, target: CompilationTarget):
        paths = _compile_files(input_, output, target)
        for input_, output in paths:
            with input_.open() as f:
                input_code = f.read()

# Generated at 2022-06-17 23:35:34.739161
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('print("Hello, World!")')


# Generated at 2022-06-17 23:35:44.366592
# Unit test for function compile_files
def test_compile_files():
    from . import __version__
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result
    from .types import CompilationTarget

    input_ = get_test_path('input')
    output = get_test_path('output')

    result = compile_files(input_, output, CompilationTarget.PYTHON_3_6)

# Generated at 2022-06-17 23:35:55.217294
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result_equal
    from .utils.test_helpers import assert_compilation_results_equal

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    root = get_test_path('compile_files')
    target = CompilationTarget.PYTHON
    result = compile_files(input_, output, target, root)

# Generated at 2022-06-17 23:36:04.788694
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass\n')

            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON)

# Generated at 2022-06-17 23:36:16.369306
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import json
    import pytest

    def run_compile_files(input_, output, target):
        compile_files(input_, output, target)
        with open(os.path.join(output, '__compiled__.json'), 'r') as f:
            return json.load(f)

    def run_compile_files_with_root(input_, output, target, root):
        compile_files(input_, output, target, root)
        with open(os.path.join(output, '__compiled__.json'), 'r') as f:
            return json.load(f)


# Generated at 2022-06-17 23:36:22.975852
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('def f():\n    return 1')

# Generated at 2022-06-17 23:36:33.968268
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import get_test_data
    from .utils.test_data import get_test_data_path
    from .utils.test_data import get_test_data_output_path
    from .utils.test_data import get_test_data_output_path_py2
    from .utils.test_data import get_test_data_output_path_py3
    from .utils.test_data import get_test_data_output_path_py35
    from .utils.test_data import get_test_data_output_path_py36
    from .utils.test_data import get_test_data_output_path_py37
    from .utils.test_data import get_test_data_output_path_py38

# Generated at 2022-06-17 23:36:39.102678
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result
    from .utils.test_helpers import assert_compilation_error
    from .utils.test_helpers import assert_compilation_error_type

    # Test for empty input
    assert_compilation_result(compile_files('', '', CompilationTarget.PYTHON),
                              0, 0, CompilationTarget.PYTHON, [])

    # Test for empty output

# Generated at 2022-06-17 23:36:48.158665
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.tmp_dir, 'input')
            self.output_dir = os.path.join(self.tmp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)


# Generated at 2022-06-17 23:36:57.462609
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug
    from .utils.helpers import debug