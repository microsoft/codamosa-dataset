

# Generated at 2022-06-17 23:32:32.238615
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path

    input_ = get_test_path('compiler', 'input')
    output = get_test_path('compiler', 'output')
    target = CompilationTarget.PYTHON_3_6
    result = compile_files(input_, output, target)
    assert result.count == 3
    assert result.target == target
    assert result.dependencies == ['os', 'sys']

    for paths in get_input_output_paths(input_, output):
        with paths.output.open() as f:
            assert f.read() == 'print("Hello, world!")\n'

# Generated at 2022-06-17 23:32:43.134820
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_path, get_test_output_path
    from .utils.test_helpers import assert_files_equal
    from .utils.test_helpers import assert_files_not_equal
    from .utils.test_helpers import assert_files_not_exist
    from .utils.test_helpers import assert_files_exist
    from .utils.test_helpers import assert_files_not_exist
    from .utils.test_helpers import assert_files_exist
    from .utils.test_helpers import assert_files_not_exist
    from .utils.test_helpers import assert_files_exist

# Generated at 2022-06-17 23:32:54.394437
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_dir, self.output_dir, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:33:05.548962
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .utils.helpers import get_test_path
    from .types import CompilationTarget

    input_ = get_test_path('input')
    output = get_test_path('output')
    shutil.rmtree(output, ignore_errors=True)
    compile_files(input_, output, CompilationTarget.PYTHON)
    assert os.path.exists(output)
    assert os.path.exists(os.path.join(output, 'test.py'))
    assert os.path.exists(os.path.join(output, 'test2.py'))
    assert os.path.exists(os.path.join(output, 'test3.py'))

# Generated at 2022-06-17 23:33:16.316676
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import subprocess
    import sys
    import pytest
    import json

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create temporary input directory
    input_dir = os.path.join(temp_dir, 'input')
    os.mkdir(input_dir)

    # Create temporary output directory
    output_dir = os.path.join(temp_dir, 'output')
    os.mkdir(output_dir)

    # Create temporary file
    input_file = os.path.join(input_dir, 'test.py')
    with open(input_file, 'w') as f:
        f.write('print("Hello world!")')

    # Compile file

# Generated at 2022-06-17 23:33:24.545991
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_equal_files

    input_ = get_test_path('compile_files_input')
    output = get_test_path('compile_files_output')
    target = CompilationTarget.PYTHON
    root = get_test_path('compile_files_root')

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        assert_equal_files(paths.input, paths.output)

# Generated at 2022-06-17 23:33:34.321993
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

# Generated at 2022-06-17 23:33:43.263187
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:33:52.801799
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_files_equal

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6

    compile_files(input_, output, target)

    for paths in get_input_output_paths(input_, output):
        assert_files_equal(paths.input, paths.output)

# Generated at 2022-06-17 23:34:03.528683
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass\n')

           

# Generated at 2022-06-17 23:34:15.107424
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers
    from .transformers import transformers

# Generated at 2022-06-17 23:34:22.739682
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create temporary file
    tmp_file = os.path.join(tmp_dir, 'test.py')
    with open(tmp_file, 'w') as f:
        f.write('print("Hello, World!")')

    # Compile file
    compile_files(tmp_dir, tmp_dir, CompilationTarget.PYTHON)

    # Run compiled file
    output = subprocess.check_output([sys.executable, tmp_file])
    assert output == b'Hello, World!\n'

    # Remove temporary directory
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-17 23:34:32.404855
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-17 23:34:37.529232
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .utils.helpers import get_test_path

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        compile_files(get_test_path('test_compile_files'),
                      tmpdir, CompilationTarget.PYTHON)
        assert (tmpdir / 'test_compile_files.py').read_text() == \
            get_test_path('test_compile_files.py').read_text()

# Generated at 2022-06-17 23:34:42.411022
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    import sys
    sys.path.append('..')
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            self.root = os.path.join(self.tempdir, 'root')
            os.mkdir(self.input_)
            os.mkdir(self.output)
           

# Generated at 2022-06-17 23:34:52.330898
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .utils.helpers import get_test_data_path

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(get_test_data_path(input_),
                             get_test_data_path(output),
                             target,
                             get_test_data_path(root))


# Generated at 2022-06-17 23:35:01.881003
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:35:12.035221
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .utils.helpers import debug_on
    from .utils.helpers import debug_off
    from .utils.helpers import debug_reset
    from .utils.helpers import debug_print
    from .utils.helpers import debug_print_on
    from .utils.helpers import debug_print_off
    from .utils.helpers import debug_print_reset
    from .utils.helpers import debug_print_print
    from .utils.helpers import debug_print_print_on
    from .utils.helpers import debug_print_print_off
    from .utils.helpers import debug_print_print_reset

# Generated at 2022-06-17 23:35:16.871766
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import tempfile
    import shutil
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

# Generated at 2022-06-17 23:35:23.646251
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .files import get_input_output_paths

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f