

# Generated at 2022-06-17 23:32:34.799974
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import subprocess
    import json

    input_ = os.path.join(os.path.dirname(__file__), 'test_files')
    output = tempfile.mkdtemp()

# Generated at 2022-06-17 23:32:44.581392
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_compilation_result
    from .types import CompilationTarget

    assert_compilation_result(
        compile_files(get_test_path('compile_files/input'),
                      get_test_path('compile_files/output'),
                      CompilationTarget.PYTHON),
        CompilationResult(
            count=2,
            time=0,
            target=CompilationTarget.PYTHON,
            dependencies=['test_compile_files/input/a.py',
                          'test_compile_files/input/b.py']))

# Generated at 2022-06-17 23:32:52.993229
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.compare import compare_files
    from .utils.files import get_input_output_paths
    from .types import CompilationTarget

    input_ = get_test_path('compiler', 'input')
    output = get_test_path('compiler', 'output')
    target = CompilationTarget.PYTHON_3_6

    compile_files(input_, output, target)

    for paths in get_input_output_paths(input_, output):
        compare_files(paths.input, paths.output)

# Generated at 2022-06-17 23:32:59.995195
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_equal_files
    from .utils.test_utils import assert_equal_dependencies

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path('compile_files')

    result = compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:33:09.241725
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import subprocess
    import sys
    import pytest

    def run_test(input_, output, target, root=None):
        result = compile_files(input_, output, target, root)
        assert result.count == 1
        assert result.target == target
        assert result.dependencies == []
        assert result.time > 0
        assert os.path.exists(output)
        with open(output) as f:
            assert f.read() == 'print("Hello, world!")\n'

    def run_test_with_root(input_, output, target, root):
        result = compile_files(input_, output, target, root)
        assert result.count == 1
        assert result.target == target
        assert result.dependencies == []
       

# Generated at 2022-06-17 23:33:19.458000
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')
            compile_

# Generated at 2022-06-17 23:33:26.333216
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.helpers import assert_equal
    from .utils.helpers import assert_in
    from .utils.helpers import assert_not_in
    from .utils.helpers import assert_is_instance
    from .utils.helpers import assert_is_not_none
    from .utils.helpers import assert_is_none
    from .utils.helpers import assert_is_not_none
    from .utils.helpers import assert_is_none
    from .utils.helpers import assert_is_not_none
    from .utils.helpers import assert_is_none
    from .utils.helpers import assert_is_not_none
    from .utils.helpers import assert_is_none
    from .utils.helpers import assert_is_not

# Generated at 2022-06-17 23:33:35.951802
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug

# Generated at 2022-06-17 23:33:44.668663
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:54.464620
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test

# Generated at 2022-06-17 23:34:07.362309
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import subprocess
    import sys
    import re

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, path = tempfile.mkstemp(dir=tmpdir)
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('print("Hello World")')

    # Compile the file
    compile_files(tmpdir, tmpdir, CompilationTarget.PYTHON)

    # Run the compiled file
    output = subprocess.check_output([sys.executable, path + 'c'])
    assert re.match(b'Hello World\n', output)

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-17 23:34:12.998894
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import assert_equal_files
    from .utils.test_helpers import assert_equal_files_in_dir
    from .utils.test_helpers import assert_equal_files_in_dir_recursive
    from .utils.test_helpers import assert_equal_files_in_dir_recursive_with_root
    from .utils.test_helpers import assert_equal_files_in_dir_recursive_with_root_and_ext
    from .utils.test_helpers import assert_equal_files_in_dir_recursive_with_root_and_ext_and_

# Generated at 2022-06-17 23:34:21.962804
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.tempdir, 'input')
            self.output_dir = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)
            self.test_file = os.path.join(self.input_dir, 'test.py')
            with open(self.test_file, 'w') as f:
                f.write('print("Hello world!")')


# Generated at 2022-06-17 23:34:32.332536
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal, assert_true, assert_false

    debug(lambda: 'Compile files')
    input_ = 'tests/data/compile_files'
    output = 'tests/data/compile_files_output'
    target = CompilationTarget.PYTHON_2
    result = compile_files(input_, output, target)
    assert_equal(result.count, 2)
    assert_true(result.time > 0)
    assert_equal(result.target, target)
    assert_equal(result.dependencies, [])

    debug(lambda: 'Check files')

# Generated at 2022-06-17 23:34:41.364345
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-17 23:34:50.215781
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_files_equal

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON
    root = get_test_path('compile_files')

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        assert_files_equal(paths.output, paths.expected)

# Generated at 2022-06-17 23:34:54.189001
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            result = compile_files

# Generated at 2022-06-17 23:35:04.022963
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers

    debug(lambda: 'Compiling "{}"'.format('test'))
    dependencies = []  # type: List[str]
    tree = ast.parse('print(1)', 'test')
    debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))

    for transformer in transformers:
        if transformer.target < CompilationTarget.PYTHON:
            debug(lambda: 'Skip transformer "{}"'.format(transformer.__name__))
            continue

        debug(lambda: 'Use transformer "{}"'.format(transformer.__name__))


# Generated at 2022-06-17 23:35:13.361055
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass')

            compile_

# Generated at 2022-06-17 23:35:21.015874
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1')

            compile

# Generated at 2022-06-17 23:35:43.527334
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:35:54.726867
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_path

# Generated at 2022-06-17 23:36:04.293786
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:36:16.123207
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import os
    import shutil
    import tempfile
    from .utils.helpers import get_test_data_path

    test_data_path = get_test_data_path('compiler')
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-17 23:36:22.627177
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:36:33.874878
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            self.root = os.path.join(self.tempdir, 'root')
            os.mkdir(self.input_)
            os.mkdir(self.output)
            os.mkdir(self.root)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:36:38.961565
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None):
        debug(lambda: 'Compile files from "{}" to "{}"'.format(input_, output))
        try:
            result = compile_files(input_, output, target, root)
        except CompilationError as e:
            debug(lambda: 'Compilation error: {}'.format(e))
            return False
        else:
            debug(lambda: 'Compilation result: {}'.format(result))
            return True


# Generated at 2022-06-17 23:36:47.849474
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_dir
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .transformers import transformers

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> CompilationResult:
        return compile_files(get_test_dir(input_), get_test_dir(output), target, root)


# Generated at 2022-06-17 23:36:57.211665
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:37:03.927495
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal_files

    input_ = get_test_path('compile', 'input')
    output = get_test_path('compile', 'output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path('compile')

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        assert_equal_files(paths.input, paths.output)

# Generated at 2022-06-17 23:37:42.212450
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .utils.helpers import get_test_path
    from .utils.files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug

    def _transform(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:
        """Applies all transformation for passed target."""
        debug(lambda: 'Compiling "{}"'.format(path))
        dependencies = []  # type: List[str]
        tree = ast.parse(code, path)
        debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))

        for transformer in transformers:
            if transformer.target < target:
                debug

# Generated at 2022-06-17 23:37:52.155058
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.tempdir import TempDir
    from .utils.helpers import assert_equal
    from .utils.helpers import assert_not_equal
    from .utils.helpers import assert_in
    from .utils.helpers import assert_not_in
    from .utils.helpers import assert_is_instance
    from .utils.helpers import assert_is_not_none
    from .utils.helpers import assert_is_none
    from .utils.helpers import assert_true
    from .utils.helpers import assert_false
    from .utils.helpers import assert_raises
    from .utils.helpers import assert_raises_regex

# Generated at 2022-06-17 23:37:59.174141
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.testing import assert_compilation_result

    debug(lambda: 'Compiling "{}"'.format('test.py'))
    dependencies = []  # type: List[str]
    tree = ast.parse('x = 1', 'test.py')
    debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))

    for transformer in transformers:
        if transformer.target < CompilationTarget.PYTHON:
            debug(lambda: 'Skip transformer "{}"'.format(transformer.__name__))
            continue

        debug(lambda: 'Use transformer "{}"'.format(transformer.__name__))


# Generated at 2022-06-17 23:38:09.506062
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_2
    from .utils.test_data import test_data_3
    from .utils.test_data import test_data_4
    from .utils.test_data import test_data_5
    from .utils.test_data import test_data_6
    from .utils.test_data import test_data_7
    from .utils.test_data import test_data_8
    from .utils.test_data import test_data_9
    from .utils.test_data import test_data_10
    from .utils.test_data import test_data_11
    from .utils.test_data import test_data_12

# Generated at 2022-06-17 23:38:18.866389
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

# Generated at 2022-06-17 23:38:28.909778
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path

# Generated at 2022-06-17 23:38:39.304661
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')
            compile

# Generated at 2022-06-17 23:38:47.118503
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .utils.helpers import get_test_path

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            tmp_input = tmpdir / 'input'
            tmp_output = tmpdir / 'output'
            shutil.copytree(get_test_path(input_), tmp_input)
            compile_files(tmp_input, tmp_output, target, root)
            assert tmp_output.exists()
            assert tmp_output.is_dir()
            assert os.path.samefile(get_test_path(output), tmp_output)



# Generated at 2022-06-17 23:38:54.670024
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty(self):
            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON)
            self.assertEqual(result.count, 0)

# Generated at 2022-06-17 23:39:02.766662
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .files import get_input_output_paths
    from .types import CompilationTarget

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def test():\n    pass\n')


# Generated at 2022-06-17 23:40:04.781581
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')

            compile

# Generated at 2022-06-17 23:40:14.854590
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    from .files import get_input_output_paths
    from .utils.helpers import debug

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            self.root = os.path.join(self.tempdir, 'root')
            os.mkdir(self.input_)
            os.mkdir(self.output)
            os.mkdir(self.root)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

       

# Generated at 2022-06-17 23:40:21.935182
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result

    debug(lambda: 'Compiling "{}"'.format('test'))
    dependencies = []  # type: List[str]
    tree = ast.parse('test', 'test')
    debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))

    for transformer in transformers:
        if transformer.target < CompilationTarget.PYTHON:
            debug(lambda: 'Skip transformer "{}"'.format(transformer.__name__))
            continue

        debug(lambda: 'Use transformer "{}"'.format(transformer.__name__))


# Generated at 2022-06-17 23:40:27.720471
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from .exceptions import CompilationError
    from .transformers import transformers
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_paths

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None):
        result = compile_files(input_, output, target, root)
        assert result.target == target
        assert result.count > 0
        assert result.time > 0
        assert len(result.dependencies) > 0

        for paths in get_input_output_paths(input_, output, root):
            with paths.input.open() as f:
                code = f.read()

# Generated at 2022-06-17 23:40:35.776144
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_files_equal

    input_ = get_test_path('compiler', 'input')
    output = get_test_path('compiler', 'output')
    target = CompilationTarget.PYTHON
    root = get_test_path('compiler')

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        assert_files_equal(paths.input, paths.output)

# Generated at 2022-06-17 23:40:43.662618
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def _run_test(input_: str, output: str, target: CompilationTarget,
                  root: Optional[str] = None,
                  expected_error: Optional[str] = None) -> None:
        try:
            result = compile_files(input_, output, target, root)
            assert expected_error is None
            assert result.count == 1
            assert result.target == target
            assert result.dependencies == []
        except CompilationError as e:
            assert expected_error is not None
            assert e.path == expected_error

# Generated at 2022-06-17 23:40:48.973589
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test

# Generated at 2022-06-17 23:40:59.320479
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.files import get_input_output_paths
    from .types import CompilationTarget
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .utils.files import get_input_output_paths
    from .types import CompilationTarget
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .utils.files import get_input_output_paths
    from .types import CompilationTarget
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .utils.files import get_input_output_path

# Generated at 2022-06-17 23:41:05.658216
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal

    debug(True)
    paths = get_input_output_paths('test/data/compile', 'test/data/compile_out')
    compile_files('test/data/compile', 'test/data/compile_out', CompilationTarget.PYTHON)

# Generated at 2022-06-17 23:41:15.041255
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)
