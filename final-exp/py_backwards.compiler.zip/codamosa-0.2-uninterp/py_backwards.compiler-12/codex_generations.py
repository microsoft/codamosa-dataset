

# Generated at 2022-06-17 23:32:36.015960
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6

    result = compile_files(input_, output, target)

    assert_equal(result.count, 3)
    assert_equal(result.target, target)

# Generated at 2022-06-17 23:32:47.745664
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test

# Generated at 2022-06-17 23:32:57.265037
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')


# Generated at 2022-06-17 23:33:07.749999
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input, 'test.py'), 'w') as f:
                f.write('print(1)')

# Generated at 2022-06-17 23:33:18.478054
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError
    from .utils.helpers import get_test_path

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6

    result = compile_files(input_, output, target)

    assert result.count == 2
    assert result.target == target
    assert result.dependencies == ['os', 'sys']

    with Path(output, 'test.py').open() as f:
        assert f.read() == 'import os\nimport sys\n\n\n'


# Generated at 2022-06-17 23:33:25.881502
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_output
    from .utils.test_data import test_data_dependencies
    from .utils.test_data import test_data_dependencies_output
    from .utils.test_data import test_data_dependencies_output_2
    from .utils.test_data import test_data_dependencies_output_3
    from .utils.test_data import test_data_dependencies_output_4
    from .utils.test_data import test_data_dependencies_output_5
    from .utils.test_data import test_data_dependencies_output_6
    from .utils.test_data import test_data_dependencies_output_7

# Generated at 2022-06-17 23:33:35.592576
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_path

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = get_test_path('compile_files', 'input')
            self.output = os.path.join(self.tempdir, 'output')

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:44.443382
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')

            result

# Generated at 2022-06-17 23:33:54.393553
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import re

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> CompilationResult:
        """Compiles all files from input_ to output."""
        dependencies = set()
        start = time()
        count = 0
        for paths in get_input_output_paths(input_, output, root):
            count += 1
            dependencies.update(_compile_file(paths, target))
        return CompilationResult(count, time() - start, target,
                                 sorted(dependencies))


# Generated at 2022-06-17 23:34:04.344764
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_path

    test_path = get_test_path()
    input_ = test_path / 'input'
    output = test_path / 'output'
    target = CompilationTarget.PYTHON_3_6
    root = test_path

    try:
        shutil.rmtree(output)
    except FileNotFoundError:
        pass

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        with paths.input.open() as f:
            input_code = f.read()

# Generated at 2022-06-17 23:34:21.882028
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal

    debug(lambda: 'Compile files')

    input_ = Path('tests/data/compile_files/input')
    output = Path('tests/data/compile_files/output')
    target = CompilationTarget.PYTHON_3_5

    result = compile_files(input_, output, target)

    assert_equal(result.count, 3)
    assert_equal(result.target, target)
    assert_equal(result.dependencies, [])


# Generated at 2022-06-17 23:34:32.334955
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import subprocess

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _run_pytest(path: str) -> None:
        subprocess.check_call(['pytest', path])

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            shutil.copytree(input_, tmpdir / 'input')

# Generated at 2022-06-17 23:34:41.354758
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path
    from .utils.test_helpers import get_test_path

# Generated at 2022-06-17 23:34:45.597811
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_empty(self):
            result = compile_files(self.input_, self.output, CompilationTarget.PYTHON)
            self.assertEqual(result.count, 0)

# Generated at 2022-06-17 23:34:55.860107
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import pytest

    def run_test(input_: str, output: str, target: CompilationTarget,
                 root: Optional[str] = None) -> None:
        temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 23:35:05.590732
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()
            self.target = CompilationTarget.PYTHON
            self.root = tempfile.mkdtemp()
            self.path = os.path.join(self.input_, 'test.py')
            with open(self.path, 'w') as f:
                f.write('def test():\n    pass')

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)
            shutil.rmtree(self.root)


# Generated at 2022-06-17 23:35:13.753742
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:35:21.551078
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write('def foo(x):\n    return x + 1\n')

# Generated at 2022-06-17 23:35:27.559412
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_compile_files(self):
            input_ = os.path.join(self.temp_dir, 'input')
            output = os.path.join(self.temp_dir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'a.py'), 'w') as f:
                f.write('def f(x):\n    return x\n')


# Generated at 2022-06-17 23:35:35.883488
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_with_tempdir(input_: str, target: CompilationTarget,
                                    root: Optional[str] = None) -> CompilationResult:
        with tempfile.TemporaryDirectory() as tmpdir:
            return compile_files(input_, tmpdir, target, root)


# Generated at 2022-06-17 23:35:52.505593
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_files_equal

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6

    compile_files(input_, output, target)

    for paths in get_input_output_paths(input_, output):
        assert_files_equal(paths.input, paths.output)

# Generated at 2022-06-17 23:36:02.707872
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .exceptions import CompilationError

    input_ = get_test_path('input')
    output = get_test_path('output')
    result = compile_files(input_, output, CompilationTarget.PYTHON)
    assert result.count == 4
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['sys']
    assert result.time > 0

    assert (Path(output) / 'test.py').exists()
    assert (Path(output) / 'test2.py').exists()
    assert (Path(output) / 'test3.py').exists()
    assert (Path(output) / 'test4.py').exists()


# Generated at 2022-06-17 23:36:08.962308
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import unittest
    import pathlib
    import json

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input, 'test.py'), 'w') as f:
                f

# Generated at 2022-06-17 23:36:18.472566
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import get_test_path
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import get_test_path
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import get_test_path
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import get_test_path
    from .utils.helpers import debug
    from .transformers import transformers
   

# Generated at 2022-06-17 23:36:24.069273
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1')


# Generated at 2022-06-17 23:36:34.435875
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result
    from .utils.test_helpers import assert_compilation_error
    from .utils.test_helpers import assert_transformation_error
    from .utils.test_helpers import assert_compilation_target
    from .utils.test_helpers import assert_compilation_dependencies
    from .utils.test_helpers import assert_compilation_count
    from .utils.test_helpers import assert_compilation_time
    from .utils.test_helpers import assert_compilation_input_output

# Generated at 2022-06-17 23:36:42.545251
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            self.target = CompilationTarget.PYTHON_3_6

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            os.mkdir(self.input_)
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

# Generated at 2022-06-17 23:36:51.713452
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .transformers.base import Transformer
    from .transformers.base import TransformationResult

    class TestTransformer(Transformer):
        target = CompilationTarget.PYTHON

        def transform(self, tree: ast.AST) -> TransformationResult:
            return TransformationResult(tree_changed=True)

    transformers.append(TestTransformer)

    debug(lambda: 'Test compile_files')
    input_ = Path(__file__).parent / 'test' / 'input'
    output = Path(__file__).parent / 'test' / 'output'
    target = Compilation

# Generated at 2022-06-17 23:37:00.093135
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path

    input_ = get_test_path('data/compile_files')
    output = get_test_path('data/compile_files_output')
    target = CompilationTarget.PYTHON_3_6

    compile_files(input_, output, target)

    for paths in get_input_output_paths(input_, output):
        with paths.output.open() as f:
            code = f.read()
        assert code == 'print("Hello, World!")\n'


# Generated at 2022-06-17 23:37:07.392316
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_data_path
    from .utils.test_helpers import assert_compilation_result

    input_ = get_test_data_path('compile_files', 'input')
    output = get_test_data_path('compile_files', 'output')
    result = compile_files(input_, output, CompilationTarget.PYTHON)
    assert_compilation_result(result, CompilationTarget.PYTHON,
                              [Path('a.py'), Path('b.py')],
                              [Path('a.py'), Path('b.py')])

    input_ = get_test_data_path('compile_files', 'input')
    output = get_test_data_path('compile_files', 'output')
   

# Generated at 2022-06-17 23:37:31.023038
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write('def f(x):\n    return x + 1\n')


# Generated at 2022-06-17 23:37:40.695804
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:37:46.035953
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:37:53.457947
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError
    from .types import CompilationTarget
    from .utils.helpers import get_test_path

    input_ = get_test_path('input')
    output = get_test_path('output')
    result = compile_files(input_, output, CompilationTarget.PYTHON_2)
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON_2
    assert result.dependencies == ['six']

# Generated at 2022-06-17 23:37:59.848762
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1')
            compile

# Generated at 2022-06-17 23:38:09.755905
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:38:19.051007
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_temp_dir
    from .utils.test_helpers import assert_equal_files
    from .utils.test_helpers import assert_equal_ast
    from .utils.test_helpers import assert_equal_dependencies
    from .utils.test_helpers import assert_equal_result
    from .utils.test_helpers import assert_equal_code
    from .utils.test_helpers import assert_equal_code_with_dependencies
    from .utils.test_helpers import assert_equal_code_with_dependencies_and_result
    from .utils.test_helpers import assert_equal_code_with_result
    from .utils.test_helpers import assert_equal_code

# Generated at 2022-06-17 23:38:28.909281
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

            result = compile_files

# Generated at 2022-06-17 23:38:39.304669
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.tempdir import TempDir
    from .utils.test_utils import assert_equal
    from .utils.test_utils import assert_raises
    from .utils.test_utils import assert_true
    from .utils.test_utils import assert_false
    from .utils.test_utils import assert_in
    from .utils.test_utils import assert_not_in
    from .utils.test_utils import assert_is_instance
    from .utils.test_utils import assert_is_not_none
    from .utils.test_utils import assert_is_none
    from .utils.test_utils import assert_is
    from .utils.test_utils import assert_is_not

# Generated at 2022-06-17 23:38:47.118894
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()
            self.input_file = os.path.join(self.input_dir, 'test.py')
            self.output_file = os.path.join(self.output_dir, 'test.py')

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)


# Generated at 2022-06-17 23:39:22.542869
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_compile_files(self):
            input_ = os.path.join(self.temp_dir, 'input')
            output = os.path.join(self.temp_dir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'a.py'), 'w') as f:
                f.write('a = 1')


# Generated at 2022-06-17 23:39:30.563698
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:39:38.423380
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            self.target = CompilationTarget.PYTHON
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)


# Generated at 2022-06-17 23:39:42.560914
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result
    from .types import CompilationTarget
    from .exceptions import CompilationError

    # Test for correct compilation
    assert_compilation_result(
        compile_files(get_test_path('compile_files/input'),
                      get_test_path('compile_files/output'),
                      CompilationTarget.PYTHON),
        CompilationResult(
            count=2,
            time=0,
            target=CompilationTarget.PYTHON,
            dependencies=['a.py', 'b.py']
        )
    )

    # Test for correct compilation with root

# Generated at 2022-06-17 23:39:52.188194
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .transformers import transformers

    debug(lambda: 'Compiling "{}"'.format('test'))
    dependencies = []  # type: List[str]
    tree = ast.parse('print(1)', 'test')
    debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))

    for transformer in transformers:
        if transformer.target < CompilationTarget.PYTHON:
            debug(lambda: 'Skip transformer "{}"'.format(transformer.__name__))
            continue

        debug(lambda: 'Use transformer "{}"'.format(transformer.__name__))

        working_tree = deepcopy(tree)

# Generated at 2022-06-17 23:39:59.228946
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_paths

    for data in test_data:
        input_ = get_test_path(data.input_)
        output = get_test_path(data.output)
        target = data.target
        root = get_test_path(data.root) if data.root else None

        compile_files(input_, output, target, root)

        for paths in test_data_paths(data):
            assert paths.output.exists()
            with paths.output.open() as f:
                assert f.read() == paths.expected.read_text()

        for paths in test_data_paths(data):
            paths

# Generated at 2022-06-17 23:40:04.492896
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:40:14.822329
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .types import CompilationTarget

    def _compile(input_: str, output: str, target: CompilationTarget):
        compile_files(input_, output, target)

    def _assert_equal(input_: str, output: str):
        with open(input_) as f:
            input_code = f.read()
        with open(output) as f:
            output_code = f.read()
        assert input_code == output_code

    def _assert_not_equal(input_: str, output: str):
        with open(input_) as f:
            input_code = f.read()
        with open(output) as f:
            output_code = f.read()
        assert input_code != output_code


# Generated at 2022-06-17 23:40:21.908229
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path
    from .utils.helpers import get_test_data_path

# Generated at 2022-06-17 23:40:27.696568
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .files import get_input_output_paths
    from .utils.helpers import get_test_path

    debug(lambda: 'Start unit test for function compile_files')
    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path('compile_files')


# Generated at 2022-06-17 23:41:33.052595
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_compiled
    from .utils.test_data import test_data_compiled_py3
    from .utils.test_data import test_data_compiled_py2
    from .utils.test_data import test_data_compiled_py2_3
    from .utils.test_data import test_data_compiled_py2_3_js
    from .utils.test_data import test_data_compiled_py2_3_js_ts
    from .utils.test_data import test_data_compiled_py2_3_js_ts_dart
    from .utils.test_data import test_data_compiled_py2_3_

# Generated at 2022-06-17 23:41:43.281893
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_simple(self):
            with open(os.path.join(self.input, 'a.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:41:49.628784
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    def _compile(input_: str, output: str, target: CompilationTarget,
                 root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_and_check(input_: str, output: str, target: CompilationTarget,
                           root: Optional[str] = None) -> CompilationResult:
        result = _compile(input_, output, target, root)
        assert result.count == 1
        assert result.target == target
        assert result.dependencies == []
        assert result.time > 0
        return result


# Generated at 2022-06-17 23:41:58.840242
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('a = 1')

# Generated at 2022-06-17 23:42:03.826025
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .transformers import transformers

    def _test_compile_files(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None):
        """Compiles all files from input_ to output."""
        dependencies = set()
        start = time()
        count = 0
        for paths in get_input_output_paths(input_, output, root):
            count += 1
            dependencies.update(_compile_file(paths, target))
        return CompilationResult(count, time() - start, target,
                                 sorted(dependencies))


# Generated at 2022-06-17 23:42:08.881142
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .utils.helpers import get_test_path
    from .types import CompilationTarget

    input_ = get_test_path('input')
    output = get_test_path('output')
    shutil.rmtree(output, ignore_errors=True)
    compile_files(input_, output, CompilationTarget.PYTHON)
    assert os.path.exists(output)

# Generated at 2022-06-17 23:42:18.281023
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)
            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1')

# Generated at 2022-06-17 23:42:27.838545
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import subprocess
    import sys
    import re
    import json

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary input directory
    tmpdir_input = os.path.join(tmpdir, 'input')
    os.mkdir(tmpdir_input)
    # Create temporary output directory
    tmpdir_output = os.path.join(tmpdir, 'output')
    os.mkdir(tmpdir_output)

    # Create temporary input file
    tmpfile_input = os.path.join(tmpdir_input, 'test.py')