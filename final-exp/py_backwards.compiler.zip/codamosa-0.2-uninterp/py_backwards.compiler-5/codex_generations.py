

# Generated at 2022-06-17 23:32:34.861689
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal, assert_not_equal
    from .utils.test_helpers import assert_raises, assert_not_raises
    from .utils.test_helpers import assert_in, assert_not_in
    from .utils.test_helpers import assert_true, assert_false
    from .utils.test_helpers import assert_is_instance, assert_is_not_instance
    from .utils.test_helpers import assert_is, assert_is_not
    from .utils.test_helpers import assert_is_none, assert_is_not_none
    from .utils.test_helpers import assert_greater, assert_less

# Generated at 2022-06-17 23:32:46.235174
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug

    debug(lambda: 'Compiling files')
    input_ = os.path.join(os.path.dirname(__file__), '..', 'tests', 'input')
    output = os.path.join(os.path.dirname(__file__), '..', 'tests', 'output')
    shutil.rmtree(output, ignore_errors=True)
    compile_files(input_, output, CompilationTarget.ES5)
    for paths in get_input_output_paths(input_, output):
        with paths.input.open() as f:
            input_code = f.read()

# Generated at 2022-06-17 23:32:56.246988
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()
            self.root = os.path.join(os.path.dirname(__file__), '..')
            self.target = CompilationTarget.PYTHON_3_6

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)


# Generated at 2022-06-17 23:33:07.327545
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:18.352829
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('x = 1\n')
            compile_files(self.input_, self.output, CompilationTarget.PYTHON)

# Generated at 2022-06-17 23:33:25.809451
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .transformers import transformers

    input_ = get_test_path('input')
    output = get_test_path('output')
    result = compile_files(input_, output, CompilationTarget.PYTHON)

    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON

# Generated at 2022-06-17 23:33:35.516834
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:44.361184
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal, assert_not_equal
    from .utils.test_helpers import assert_exception, assert_no_exception
    from .utils.test_helpers import assert_in, assert_not_in
    from .utils.test_helpers import assert_is_instance, assert_not_is_instance
    from .utils.test_helpers import assert_true, assert_false
    from .utils.test_helpers import assert_is, assert_is_not
    from .utils.test_helpers import assert_is_none, assert_is_not_none
    from .utils.test_helpers import assert_greater, assert_less

# Generated at 2022-06-17 23:33:54.368840
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .files import get_input_output_paths
    from .types import CompilationTarget

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:34:04.332975
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')

            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:21.860126
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:34:32.332605
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:34:41.354727
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_expected_output
    from .utils.test_data import test_data_expected_dependencies
    from .utils.test_data import test_data_expected_count
    from .utils.test_data import test_data_expected_time
    from .utils.test_data import test_data_expected_target
    from .utils.test_data import test_data_expected_result

    result = compile_files(get_test_path(test_data),
                           get_test_path(test_data_expected_output),
                           test_data_expected_target)

    assert result.count == test_data_expected_count
    assert result.time >= test_data

# Generated at 2022-06-17 23:34:51.898963
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6
    result = compile_files(input_, output, target)

    assert result.count == 3
    assert result.target == target
    assert result.dependencies == ['os', 'sys']

    for paths in get_input_output_paths(input_, output):
        with paths.input.open() as f:
            input_code = f.read()

# Generated at 2022-06-17 23:35:01.745949
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_dir, self.output_dir,
                          CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:35:11.924284
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            self.target = CompilationTarget.PYTHON

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            os.mkdir(self.input_)
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')


# Generated at 2022-06-17 23:35:16.781516
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths, InputOutput
    from .transformers import transformers
    from .types import CompilationTarget, CompilationResult
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug

    def _transform(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:
        """Applies all transformation for passed target."""
        debug(lambda: 'Compiling "{}"'.format(path))
        dependencies = []  # type: List[str]
        tree = ast.parse(code, path)
        debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))


# Generated at 2022-06-17 23:35:23.568344
# Unit test for function compile_files
def test_compile_files():
    from .files import InputOutput
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        input_ = tmpdir / 'input'
        output = tmpdir / 'output'
        input_.mkdir()
        output.mkdir()
        (input_ / 'a.py').write_text('a = 1')
        (input_ / 'b.py').write_text('b = 2')
        (input_ / 'c.py').write_text('c = 3')
        (input_ / 'd.py').write_text('d = 4')
        (input_ / 'e.py').write_

# Generated at 2022-06-17 23:35:29.177088
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result

    debug(True)
    assert_compilation_result(
        compile_files('tests/data/compile/input',
                      'tests/data/compile/output',
                      CompilationTarget.PYTHON_3_6),
        CompilationResult(
            count=2,
            time=0.0,
            target=CompilationTarget.PYTHON_3_6,
            dependencies=['tests/data/compile/input/a.py',
                          'tests/data/compile/input/b.py']))


# Generated at 2022-06-17 23:35:36.706269
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_paths
    from .utils.helpers import get_test_paths_with_output
    from .utils.helpers import get_test_paths_with_output_and_root
    from .utils.helpers import get_test_paths_with_root
    from .utils.helpers import get_test_paths_with_target
    from .utils.helpers import get_test_paths_with_target_and_root
    from .utils.helpers import get_test_paths_with_target_and_output