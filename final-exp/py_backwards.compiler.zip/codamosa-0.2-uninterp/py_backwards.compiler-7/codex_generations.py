

# Generated at 2022-06-17 23:32:33.800644
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_output
    from .utils.test_data import test_data_output_py2
    from .utils.test_data import test_data_output_py3
    from .utils.test_data import test_data_output_py35
    from .utils.test_data import test_data_output_py36
    from .utils.test_data import test_data_output_py37
    from .utils.test_data import test_data_output_py38
    from .utils.test_data import test_data_output_py39
    from .utils.test_data import test_data_output_py310
    from .utils.test_data import test_data_

# Generated at 2022-06-17 23:32:45.525816
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_utils import assert_paths_equal, assert_paths_not_equal
    from .utils.test_utils import assert_paths_not_exist
    from .utils.test_utils import assert_paths_exist
    from .utils.test_utils import assert_paths_not_exist
    from .utils.test_utils import assert_paths_exist
    from .utils.test_utils import assert_paths_not_exist
    from .utils.test_utils import assert_paths_exist
    from .utils.test_utils import assert_paths_not_exist
    from .utils.test_utils import assert_path

# Generated at 2022-06-17 23:32:55.763448
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')
            compile

# Generated at 2022-06-17 23:33:06.830806
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

# Generated at 2022-06-17 23:33:18.302958
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('x = 1')


# Generated at 2022-06-17 23:33:25.780610
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        """Compiles all files from input_ to output."""
        dependencies = set()
        start = time()
        count = 0
        for paths in get_input_output_paths(input_, output, root):
            count += 1
            dependencies.update(_compile_file(paths, target))
        return CompilationResult(count, time() - start, target,
                                 sorted(dependencies))


# Generated at 2022-06-17 23:33:35.481024
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .types import CompilationTarget

    def _create_file(path: str, content: str):
        with open(path, 'w') as f:
            f.write(content)

    def _assert_file_content(path: str, content: str):
        with open(path, 'r') as f:
            assert f.read() == content

    def _assert_file_exists(path: str):
        assert os.path.exists(path)

    def _assert_file_not_exists(path: str):
        assert not os.path.exists(path)

    def _assert_dir_exists(path: str):
        assert os.path.exists(path) and os.path.isdir(path)


# Generated at 2022-06-17 23:33:44.328377
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')


# Generated at 2022-06-17 23:33:54.338007
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')

            compile

# Generated at 2022-06-17 23:34:04.306174
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f(x):\n    return x + 1\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:20.572748
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_files_equal

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path('root')

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        assert_files_equal(paths.input, paths.output)

# Generated at 2022-06-17 23:34:30.909184
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers

    debug(lambda: 'Start test')
    input_ = Path(__file__).parent / 'test' / 'input'
    output = Path(__file__).parent / 'test' / 'output'
    target = CompilationTarget.PYTHON_TO_PYTHON
    result = compile_files(input_, output, target)
    debug(lambda: 'Result: {}'.format(result))
    assert result.count == 3
    assert result.target == target
    assert result.dependencies == []
    assert result.time > 0

    debug(lambda: 'Start test')

# Generated at 2022-06-17 23:34:37.921163
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f(x):\n    return x + 1\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:42.718142
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .utils.helpers import get_test_path
    from .types import CompilationTarget

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(get_test_path(input_),
                             get_test_path(output),
                             target,
                             root=get_test_path(root) if root else None)

    def _compare_files(input_: str, output: str) -> None:
        with open(get_test_path(input_)) as f:
            input_code = f.read()
        with open(get_test_path(output)) as f:
            output_code = f.read()
        assert input

# Generated at 2022-06-17 23:34:52.670613
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()
            self.target = CompilationTarget.PYTHON

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f(x):\n    return x + 1\n')


# Generated at 2022-06-17 23:35:02.118671
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:35:12.250747
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            input_file = os.path.join(self.input_dir, 'test.py')
            output_file = os.path.join(self.output_dir, 'test.py')
            with open(input_file, 'w') as f:
                f.write('print("Hello, world!")')

           

# Generated at 2022-06-17 23:35:16.998359
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:35:23.796478
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:35:29.381735
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1')

            compile