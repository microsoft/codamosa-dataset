

# Generated at 2022-06-17 23:32:33.795325
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1')

            compile

# Generated at 2022-06-17 23:32:45.537085
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_simple(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:32:50.314777
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_equal_files
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from typing import List

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> List[str]:
        with TemporaryDirectory() as temp_dir:
            temp_input = Path(temp_dir) / 'input'
            temp_output = Path(temp_dir) / 'output'
            temp_input.mkdir()
            temp_output.mkdir()

# Generated at 2022-06-17 23:32:58.687170
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            self.target = CompilationTarget.PYTHON

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            os.mkdir(self.input_)
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')
            compile_

# Generated at 2022-06-17 23:33:02.668323
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')
            compile_

# Generated at 2022-06-17 23:33:10.674354
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            input_file = os.path.join(self.input_dir, 'test.py')
            output_file = os.path.join(self.output_dir, 'test.py')

# Generated at 2022-06-17 23:33:20.921831
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:31.199121
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_files_equal
    from .utils.test_helpers import assert_files_not_equal
    import os
    import shutil

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path()

    for paths in get_input_output_paths(input_, output, root):
        if paths.output.exists():
            paths.output.unlink()

    compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:33:41.128528
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug

# Generated at 2022-06-17 23:33:47.256308
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.root = tempfile.mkdtemp()
            self.input_ = os.path.join(self.root, 'input')
            self.output = os.path.join(self.root, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.root)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass\n')


# Generated at 2022-06-17 23:34:02.744458
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        debug(lambda: 'Compile files')
        return compile_files(input_, output, target, root)

    def _compile_files_error(input_: str, output: str, target: CompilationTarget,
                             root: Optional[str] = None) -> CompilationResult:
        debug(lambda: 'Compile files')

# Generated at 2022-06-17 23:34:08.073916
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.makedirs(self.input_dir)
            os.makedirs(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_compile_files(self):
            with open(os.path.join(self.input_dir, 'test.py'), 'w') as f:
                f.write

# Generated at 2022-06-17 23:34:13.555275
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:34:22.089939
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .transformers import transformers
    from .utils.helpers import debug

    # Disable debug output
    debug(lambda: None)

    # Compile all files
    result = compile_files(get_test_path('input'),
                           get_test_path('output'),
                           CompilationTarget.PYTHON)

    # Check result
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['os', 'sys']

    # Check output

# Generated at 2022-06-17 23:34:30.714365
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_files_equal

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path()

    compile_files(input_, output, target, root)

    for paths in get_input_output_paths(input_, output, root):
        assert_files_equal(paths.input, paths.output)

# Generated at 2022-06-17 23:34:37.730000
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:42.561625
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)

            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')


# Generated at 2022-06-17 23:34:52.532963
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()
            self.target = CompilationTarget.PYTHON
            self.root = None

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1\n')
            compile_files(self.input_, self.output, self.target, self.root)

# Generated at 2022-06-17 23:35:02.025920
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)')

            result = compile_files

# Generated at 2022-06-17 23:35:12.170090
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path

# Generated at 2022-06-17 23:35:35.436966
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_test(input_: str, output: str, target: CompilationTarget,
                            root: Optional[str] = None) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            input_ = tmpdir / input_
            output = tmpdir / output
            input_.parent.mkdir(parents=True)
            output.parent.mkdir(parents=True)

# Generated at 2022-06-17 23:35:44.368007
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_paths
    from .utils.test import get_test_path

# Generated at 2022-06-17 23:35:55.216974
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers
    from .utils.helpers import debug
    from .transformers import transformers

# Generated at 2022-06-17 23:36:04.788264
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import re
    import json
    import pytest
    import pathlib
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_and_run(input_: str, output: str, target: CompilationTarget,
                               root: Optional[str] = None) -> CompilationResult:
        result = compile_files(input_, output, target, root)

# Generated at 2022-06-17 23:36:16.368685
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_utils import assert_equal_files
    from pathlib import Path
    import os
    import shutil

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    expected = get_test_path('compile_files', 'expected')
    target = CompilationTarget.PYTHON_3_6

    shutil.rmtree(output, ignore_errors=True)
    compile_files(input_, output, target)


# Generated at 2022-06-17 23:36:22.976006
# Unit test for function compile_files
def test_compile_files():
    from . import __version__
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.paths import get_test_paths
    from .utils.test_helpers import assert_equal, assert_raises
    from .utils.test_helpers import assert_in, assert_not_in
    from .utils.test_helpers import assert_is_instance, assert_is_not_none
    from .utils.test_helpers import assert_is_none, assert_is_not_none
    from .utils.test_helpers import assert_is_not_empty, assert_is_empty
    from .utils.test_helpers import assert_is_not_empty, assert_is_

# Generated at 2022-06-17 23:36:33.969210
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:36:42.017226
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_2_7

    result = compile_files(input_, output, target)
    assert result.count == 3
    assert result.target == target
    assert result.dependencies == ['__future__', 'typing']

    paths = list(get_input_output_paths(input_, output))
    assert paths[0].input.as_posix() == get_test_path('input/a.py').as_posix()
    assert paths[0].output.as_posix() == get_

# Generated at 2022-06-17 23:36:51.069775
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            self.target = CompilationTarget.PYTHON
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:36:59.476766
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test_path
    from .utils.test import get_test

# Generated at 2022-06-17 23:37:42.551448
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:37:52.327112
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:37:59.286438
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_with_sys_path(input_: str, output: str, target: CompilationTarget,
                                     root: Optional[str] = None) -> CompilationResult:
        sys.path.append(input_)
        return compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:38:09.548383
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    print("Hello, World!")\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:38:18.895349
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def test():\n    pass\n')

           

# Generated at 2022-06-17 23:38:28.380205
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_temp_dir

    with get_temp_dir() as temp_dir:
        input_ = temp_dir / 'input'
        output = temp_dir / 'output'
        input_.mkdir()
        output.mkdir()

        with (input_ / 'file.py').open('w') as f:
            f.write('print("Hello, world!")')

        compile_files(input_, output, CompilationTarget.PYTHON)

        with (output / 'file.py').open() as f:
            assert f.read() == 'print("Hello, world!")\n'

# Generated at 2022-06-17 23:38:38.737488
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError
    from .utils.helpers import get_test_path

    input_ = get_test_path('compile_files')
    output = get_test_path('compile_files_output')
    target = CompilationTarget.PYTHON

    compile_files(input_, output, target)

    assert Path(output, 'a.py').exists()
    assert Path(output, 'b.py').exists()
    assert Path(output, 'c.py').exists()
    assert Path(output, 'd.py').exists()
    assert Path(output, 'e.py').exists()

    assert Path(output, 'a.py').read_text() == Path(input_, 'a.py').read_text()

# Generated at 2022-06-17 23:38:46.755494
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tmpdir, 'input')
            self.output = os.path.join(self.tmpdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:38:53.998545
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)

        def test_compile_files(self):
            # Create a file in the input directory
            file_path = os.path.join(self.input_dir, 'test.py')
            with open(file_path, 'w') as f:
                f.write('print("Hello, world!")')

            # Compile the file

# Generated at 2022-06-17 23:39:02.655329
# Unit test for function compile_files
def test_compile_files():
    from .utils.test_helpers import assert_compilation_result
    from .utils.test_helpers import assert_compilation_error
    from .utils.test_helpers import assert_transformation_error
    from .utils.test_helpers import assert_compilation_result_with_dependencies
    from .utils.test_helpers import assert_compilation_result_without_dependencies
    from .utils.test_helpers import assert_compilation_result_with_dependencies_in_order
    from .utils.test_helpers import assert_compilation_result_without_dependencies_in_order
    from .utils.test_helpers import assert_compilation_result_with_dependencies_in_order_with_root
    from .utils.test_helpers import assert_compilation_result_without_dependencies_