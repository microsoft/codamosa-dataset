

# Generated at 2022-06-17 23:32:35.535313
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.mkdtemp()
            self.output_dir = tempfile.mkdtemp()
            self.input_file = os.path.join(self.input_dir, 'test.py')
            self.output_file = os.path.join(self.output_dir, 'test.py')

        def tearDown(self):
            shutil.rmtree(self.input_dir)
            shutil.rmtree(self.output_dir)


# Generated at 2022-06-17 23:32:47.125089
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_compiled
    from .utils.test_data import test_data_compiled_with_dependencies
    from .utils.test_data import test_data_compiled_with_dependencies_and_imports
    from .utils.test_data import test_data_compiled_with_dependencies_and_imports_and_types
    from .utils.test_data import test_data_compiled_with_dependencies_and_imports_and_types_and_classes
    from .utils.test_data import test_data_compiled_with_dependencies_and_imports_and_types_and_classes_and_functions

# Generated at 2022-06-17 23:32:56.811752
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import unittest
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 23:33:07.507968
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import subprocess
    import sys
    import re
    import json

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Copy files to temporary directory
    shutil.copytree(os.path.join(os.path.dirname(__file__), '..', 'test', 'data'),
                    os.path.join(tmpdir, 'data'))
    # Change current directory
    os.chdir(tmpdir)
    # Compile files
    compile_files('data', 'output', CompilationTarget.PYTHON_3)
    # Run tests

# Generated at 2022-06-17 23:33:18.393191
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_paths, get_test_output_paths
    from .utils.test_helpers import get_test_files, get_test_output_files

    # Test compile_files
    def test_compile_files(input_: str, output: str, target: CompilationTarget,
                           root: Optional[str] = None):
        debug(lambda: 'Test compile_files')
        result = compile_files(input_, output, target, root)
        assert result.count == len(get_test_paths(input_, root))
        assert result.target == target

# Generated at 2022-06-17 23:33:25.835035
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .transformers import transformers
    from .utils.helpers import debug

    def _transform(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:
        """Applies all transformation for passed target."""
        debug(lambda: 'Compiling "{}"'.format(path))
        dependencies = []  # type: List[str]
        tree = ast.parse(code, path)
        debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))

        for transformer in transformers:
            if transformer.target < target:
                debug(lambda: 'Skip transformer "{}"'.format(transformer.__name__))
                continue


# Generated at 2022-06-17 23:33:35.517185
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import re
    import pytest
    import pathlib
    import importlib

    def _compile_and_run(code: str, target: CompilationTarget,
                         expected: str) -> None:
        """Compiles and runs code."""
        with tempfile.TemporaryDirectory() as tmpdir:
            input_ = pathlib.Path(tmpdir) / 'input'
            output = pathlib.Path(tmpdir) / 'output'
            input_.mkdir()
            output.mkdir()
            (input_ / 'main.py').write_text(code)
            result = compile_files(input_, output, target)
            assert result.count == 1
            assert result.target == target
            assert result.dependencies == []

# Generated at 2022-06-17 23:33:44.390289
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import json
    import pytest
    import pathlib
    from .exceptions import CompilationError
    from .types import CompilationTarget

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_with_error(input_: str, output: str, target: CompilationTarget,
                                  root: Optional[str] = None) -> CompilationResult:
        with pytest.raises(CompilationError):
            return compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:33:54.366504
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:04.332445
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)\n')
            compile_files