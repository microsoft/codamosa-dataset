

# Generated at 2022-06-17 23:32:41.588387
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_utils import assert_compilation_result
    from .utils.test_utils import assert_compilation_error
    from .utils.test_utils import assert_transformation_error
    from .utils.test_utils import assert_compilation_target
    from .utils.test_utils import assert_compilation_dependencies
    from .utils.test_utils import assert_compilation_count
    from .utils.test_utils import assert_compilation_time
    from .utils.test_utils import assert_compilation_output
    from .utils.test_utils import assert_compilation_input
    from .utils.test_utils import assert_compilation_root

# Generated at 2022-06-17 23:32:53.121990
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from pathlib import Path
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = Path(self.tempdir, 'input')
            self.output = Path(self.tempdir, 'output')
            self.input_.mkdir()
            self.output.mkdir()

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:00.067282
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.testing import assert_equal

    debug(True)

    input_ = Path(__file__).parent / 'test_files' / 'input'
    output = Path(__file__).parent / 'test_files' / 'output'
    target = CompilationTarget.PYTHON_3_6

    result = compile_files(input_, output, target)
    assert_equal(result.count, 3)
    assert_equal(result.target, target)
    assert_equal(result.dependencies, [])


# Generated at 2022-06-17 23:33:09.271886
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:33:19.458034
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:26.333689
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import shutil
    import sys
    import subprocess
    import pytest

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-17 23:33:35.949146
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('print("Hello, world!")')

# Generated at 2022-06-17 23:33:44.668449
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import pytest

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _compile_files_with_tempdir(input_: str, output: str,
                                    target: CompilationTarget,
                                    root: Optional[str] = None) -> CompilationResult:
        with tempfile.TemporaryDirectory() as tempdir:
            input_ = os.path.join(tempdir, input_)
            output = os.path.join(tempdir, output)
            return compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:33:54.464375
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:34:04.356866
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_equal

    input_ = get_test_path('compiler/input')
    output = get_test_path('compiler/output')
    target = CompilationTarget.PYTHON
    root = get_test_path('compiler')

    paths = get_input_output_paths(input_, output, root)
    assert_equal(len(paths), 2)
    assert_equal(paths[0].input, get_test_path('compiler/input/a.py'))
    assert_equal(paths[0].output, get_test_path('compiler/output/a.py'))
   

# Generated at 2022-06-17 23:34:20.673699
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .utils.helpers import get_test_data_path

    input_ = get_test_data_path('input')
    output = get_test_data_path('output')
    shutil.rmtree(output, ignore_errors=True)
    os.makedirs(output, exist_ok=True)
    result = compile_files(input_, output, CompilationTarget.PYTHON)
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['a.py', 'b.py']
    assert result.time > 0

# Generated at 2022-06-17 23:34:31.061567
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    debug(lambda: 'Test compile_files')

    input_ = 'tests/data/compile_files/input'
    output = 'tests/data/compile_files/output'
    target = CompilationTarget.PYTHON_3_7

    shutil.rmtree(output, ignore_errors=True)
    compile_files(input_, output, target)

    for paths in get_input_output_paths(input_, output):
        with paths.input.open() as f:
            input_code = f.read()
        with paths.output.open() as f:
            output_

# Generated at 2022-06-17 23:34:38.014025
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import assert_compilation_result_equal
    from .utils.test_helpers import assert_compilation_result_not_equal
    from .utils.test_helpers import get_test_data_path
    from .utils.test_helpers import get_test_output_path
    from .utils.test_helpers import get_test_output_path_for_target
    from .utils.test_helpers import get_test_output_path_for_target_and_file
    from .utils.test_helpers import get_test_output_path_for_target_and_file_and_transformer

# Generated at 2022-06-17 23:34:48.900817
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print(1)\n')


# Generated at 2022-06-17 23:34:58.711226
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f():\n    return 1\n')



# Generated at 2022-06-17 23:35:08.622633
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_paths
    from .utils.test_data import test_data_dependencies
    from .utils.test_data import test_data_compilation_results
    from .utils.test_data import test_data_compilation_results_with_dependencies
    from .utils.test_data import test_data_compilation_results_with_dependencies_and_time

    for test_case in test_data:
        result = compile_files(get_test_path(test_case, 'input'),
                               get_test_path(test_case, 'output'),
                               test_data_compilation_results[test_case].target)
        assert result == test_

# Generated at 2022-06-17 23:35:17.213528
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('x = 1\n')


# Generated at 2022-06-17 23:35:24.026220
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        debug(lambda: 'Compile files from "{}" to "{}"'.format(input_, output))
        return compile_files(input_, output, target, root)

    def _compile_file(paths: InputOutput, target: CompilationTarget) -> List[str]:
        debug(lambda: 'Compile file "{}" to "{}"'.format(paths.input, paths.output))
        return _compile_file(paths, target)


# Generated at 2022-06-17 23:35:29.523292
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.files import get_input_output_paths
    from .utils.test_helpers import assert_compilation_result
    from .transformers import transformers

    input_ = get_test_path('compile_files')
    output = get_test_path('compile_files_output')
    target = CompilationTarget.PYTHON_TO_PYTHON

    result = compile_files(input_, output, target)

# Generated at 2022-06-17 23:35:36.844594
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1\n')
