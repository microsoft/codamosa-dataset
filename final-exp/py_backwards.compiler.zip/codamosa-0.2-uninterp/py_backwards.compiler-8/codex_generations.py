

# Generated at 2022-06-17 23:32:32.126491
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    from .files import get_input_output_paths

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files_empty(self):
            result = compile_files(self.input_, self.output,
                                   CompilationTarget.PYTHON)

# Generated at 2022-06-17 23:32:42.974711
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON_3_6

    def _test_compile_files(input_: str, output: str, target: CompilationTarget):
        result = compile_files(input_, output, target)
        assert result.count == 3
        assert result.target == target
        assert result.dependencies == ['a.py', 'b.py']

    _test_compile_files(input_, output, target)
    _test_compile_files(input_, output, target)


# Generated at 2022-06-17 23:32:54.220386
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from .transformers import transformers
    from .files import get_input_output_paths
    from .utils.helpers import debug
    from .transformers import transformers
    from .files import get_input_output_paths
    from .utils.helpers import debug
    from .transformers import transformers
    from .files import get_input_output_paths
    from .utils.helpers import debug
    from .transformers import transformers
    from .files import get_input_output_paths
    from .utils.helpers import debug
    from .transformers import transformers
    from .files import get_input_output_

# Generated at 2022-06-17 23:33:05.362828
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.test_helpers import get_test_paths
    from .utils.test_helpers import get_test_paths
    from .utils.test_helpers import get_test_paths
    from .utils.test_helpers import get_test_paths
    from .utils.test_helpers import get_test_paths
    from .utils.test_helpers import get_test_paths
    from .utils.test_helpers import get_test_paths
    from .utils.test_helpers import get_test_paths
    from .utils.test_helpers import get_test_paths

# Generated at 2022-06-17 23:33:16.235915
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import re
    import json

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Copy test files to temporary directory
    shutil.copytree('tests/data/input', tmpdir + '/input')
    # Compile files
    compile_files(tmpdir + '/input', tmpdir + '/output', CompilationTarget.ES5)
    # Run tests
    os.chdir(tmpdir + '/output')
    subprocess.check_call([sys.executable, '-m', 'unittest', 'discover'])
    # Check dependencies
    with open(tmpdir + '/output/dependencies.json') as f:
        dependencies = json.load(f)

# Generated at 2022-06-17 23:33:25.174515
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .files import get_input_output_paths
    from .types import CompilationTarget

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:33:34.996700
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:33:43.884507
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    from .files import get_input_output_paths

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            from .transformers import transformers
            from .types import CompilationTarget


# Generated at 2022-06-17 23:33:54.185384
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1')

# Generated at 2022-06-17 23:34:04.182719
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:34:21.881584
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('a = 1\n')

# Generated at 2022-06-17 23:34:32.336835
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:34:41.360554
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass')

            compile_

# Generated at 2022-06-17 23:34:51.900095
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest
    from .files import get_input_output_paths
    from .types import CompilationTarget

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'a.py'), 'w') as f:
                f.write('def f():\n    return 1')


# Generated at 2022-06-17 23:35:01.746051
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError

    input_ = get_test_path('input')
    output = get_test_path('output')
    target = CompilationTarget.PYTHON

    result = compile_files(input_, output, target)
    assert result.count == 2
    assert result.target == target
    assert result.dependencies == ['sys', 'os']

    with get_test_path('input', 'error.py').open() as f:
        code = f.read()


# Generated at 2022-06-17 23:35:11.924435
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:35:16.782249
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import json
    import pytest

    def _compile_files(input_: str, output: str, target: CompilationTarget,
                       root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def _check_compilation_result(result: CompilationResult,
                                  expected_count: int,
                                  expected_time: float,
                                  expected_target: CompilationTarget,
                                  expected_dependencies: List[str]):
        assert result.count == expected_count
        assert result.time >= expected_time
        assert result.target == expected_target
        assert result.dependencies == expected_dependencies


# Generated at 2022-06-17 23:35:21.482271
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    input_ = os.path.join(os.path.dirname(__file__), '..', 'tests', 'input')
    output = tempfile.mkdtemp()
    try:
        result = compile_files(input_, output, CompilationTarget.PYTHON)
        assert result.count == 3
        assert result.target == CompilationTarget.PYTHON
        assert result.dependencies == ['os', 'sys']
    finally:
        shutil.rmtree(output)

# Generated at 2022-06-17 23:35:30.403555
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()
            self.root = tempfile.mkdtemp()
            self.target = CompilationTarget.PYTHON_3

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)
            shutil.rmtree(self.root)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

# Generated at 2022-06-17 23:35:37.291350
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    pass\n')
           

# Generated at 2022-06-17 23:35:52.312360
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_path
    from .exceptions import CompilationError
    from .types import CompilationTarget
    from .transformers import transformers
    from .utils.helpers import debug

    def _transform(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:
        """Applies all transformation for passed target."""
        debug(lambda: 'Compiling "{}"'.format(path))
        dependencies = []  # type: List[str]
        tree = ast.parse(code, path)
        debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))


# Generated at 2022-06-17 23:35:54.232499
# Unit test for function compile_files
def test_compile_files():
    from .tests.test_compiler import test_compile_files
    test_compile_files()

# Generated at 2022-06-17 23:36:03.871613
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')
            compile_files(self.input_, self.output, CompilationTarget.PYTHON)

# Generated at 2022-06-17 23:36:09.610984
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .utils.helpers import get_test_path

    input_ = get_test_path('input')
    output = get_test_path('output')
    shutil.rmtree(output, ignore_errors=True)
    compile_files(input_, output, CompilationTarget.PYTHON)
    assert os.path.exists(output)
    assert os.path.exists(os.path.join(output, 'test.py'))
    assert os.path.exists(os.path.join(output, 'test2.py'))
    assert os.path.exists(os.path.join(output, 'test3.py'))
    assert os.path.exists(os.path.join(output, 'test4.py'))
    assert os

# Generated at 2022-06-17 23:36:18.559371
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import debug
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_paths
    from .utils.helpers import get_test_paths_from_file
    from .utils.helpers import get_test_paths_from_file_with_root
    from .utils.helpers import get_test_paths_with_root
    from .utils.helpers import get_test_path_with_root
    from .utils.helpers import get_test_path_with_root_and_file
    from .utils.helpers import get_test_path_with_root_and_file_and_line
    from .utils.helpers import get_

# Generated at 2022-06-17 23:36:24.106157
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.temp_dir, 'input')
            self.output_dir = os.path.join(self.temp_dir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-17 23:36:34.458666
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:36:42.572211
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys
    import subprocess
    import json

    def run_compile_files(input_: str, output: str, target: CompilationTarget,
                          root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    def run_compile_files_with_root(input_: str, output: str, target: CompilationTarget,
                                    root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)


# Generated at 2022-06-17 23:36:51.781807
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def f(x):\n    return x + 1\n')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:37:00.154546
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import get_test_path
    from .utils.test_helpers import assert_compilation_result

    input_ = get_test_path('compile_files', 'input')
    output = get_test_path('compile_files', 'output')
    target = CompilationTarget.PYTHON_3_6
    root = get_test_path('compile_files')

    result = compile_files(input_, output, target, root)
    assert_compilation_result(result, target,
                              [get_test_path('compile_files', 'input', 'a.py')])

    paths = get_input_output_paths(input_, output, root)
    assert len

# Generated at 2022-06-17 23:37:41.256702
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('a = 1')

# Generated at 2022-06-17 23:37:46.322218
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.tempdir, 'input')
            self.output_dir = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_dir)
            os.mkdir(self.output_dir)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 23:37:56.493332
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_test_data_path
    from .transformers import transformers

    input_ = get_test_data_path('compile_files')
    output = Path('/tmp/compile_files')
    result = compile_files(input_, output, CompilationTarget.PYTHON_3_6)

    assert result.count == 3
    assert result.target == CompilationTarget.PYTHON_3_6
    assert result.dependencies == []

    assert (output / 'a.py').read_text() == 'print("Hello, World!")\n'
    assert (output / 'b.py').read_text() == 'print("Hello, World!")\n'

# Generated at 2022-06-17 23:38:00.860538
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .utils.helpers import get_test_path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .transformers import transformers
    from .utils.helpers import debug
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path
    from .utils.helpers import get_test_path

# Generated at 2022-06-17 23:38:10.655721
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')

            compile_

# Generated at 2022-06-17 23:38:19.732391
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_path
    from .utils.test_data import test_data
    from .utils.test_data import test_data_dependencies
    from .utils.test_data import test_data_transformed
    from .utils.test_data import test_data_transformed_dependencies

    for target in CompilationTarget:
        result = compile_files(get_test_path('test_data'),
                               get_test_path('test_data_transformed'),
                               target)
        assert result.count == len(test_data)
        assert result.dependencies == test_data_transformed_dependencies[target]

        for path, code in test_data.items():
            transformed, _ = _transform(path, code, target)

# Generated at 2022-06-17 23:38:28.930006
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .types import CompilationTarget

    input_ = Path('tests/data/input')
    output = Path('tests/data/output')
    target = CompilationTarget.PYTHON_3_6
    root = Path('tests/data')
    result = compile_files(input_, output, target, root)
    assert result.count == 3
    assert result.target == target
    assert result.dependencies == ['a.py', 'b.py']
    assert result.time > 0

    paths = get_input_output_paths(input_, output, root)
    assert len(paths) == 3
    assert paths[0].input == Path('tests/data/input/a.py')

# Generated at 2022-06-17 23:38:39.306058
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('def foo():\n    return 1')

            compile_files(self.input_, self.output, CompilationTarget.PYTHON)


# Generated at 2022-06-17 23:38:47.118449
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input_ = os.path.join(self.tempdir, 'input')
            self.output = os.path.join(self.tempdir, 'output')
            os.mkdir(self.input_)
            os.mkdir(self.output)

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            with open(os.path.join(self.input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')
            compile_

# Generated at 2022-06-17 23:38:54.964056
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile_files(self):
            input_ = os.path.join(self.tempdir, 'input')
            output = os.path.join(self.tempdir, 'output')
            os.mkdir(input_)
            os.mkdir(output)
            with open(os.path.join(input_, 'test.py'), 'w') as f:
                f.write('print("Hello, world!")')