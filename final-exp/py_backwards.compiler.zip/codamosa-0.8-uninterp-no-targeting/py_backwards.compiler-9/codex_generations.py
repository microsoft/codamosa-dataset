

# Generated at 2022-06-21 16:58:01.730247
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from . import __version__
    from io import StringIO
    from subprocess import PIPE, Popen
    from sys import executable
    from contextlib import contextmanager
    from .files import compile_files as cfiles

    @contextmanager
    def redirect_stderr(target):
        original = sys.stderr
        sys.stderr = target
        yield
        sys.stderr = original

    with TemporaryDirectory() as temp:
        root = Path(temp)
        (root / '__init__.py').touch()
        (root / 'foo').mkdir()
        (root / 'foo/a.py').touch()
        (root / 'bar').mkdir()
        (root / 'bar/b.py').touch()


# Generated at 2022-06-21 16:58:11.330445
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import sys

    tmpdir = tempfile.mkdtemp()

    src = os.path.join(tmpdir, 'src', 'main.py')
    os.makedirs(os.path.dirname(src))
    with open(src, 'w') as f:
        f.write('#!/usr/bin/env python\n')
        f.write('print("hello world")\n')

    pydir = os.path.join(tmpdir, 'py')
    os.makedirs(pydir)

    pyxdir = os.path.join(tmpdir, 'pyx')
    os.makedirs(pyxdir)

    os.chmod(src, 0o755)

# Generated at 2022-06-21 16:58:21.166105
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError, TransformationError
    from .utils.tempdir import TempDir
    from .utils.helpers import assert_raises
    from .examples.src.foo.bar import Bar, baz  # type: ignore
    from .examples.src.foo.bar import bar_hello  # type: ignore
    from .examples.src.foo.bar import bar_hello2  # type: ignore
    from .examples.src import missing_import  # type: ignore
    from .examples.src.foo import missing_import2  # type: ignore
    import os
    import sys
    import io

    class SilentOutput(io.TextIOWrapper):
        def write(self, s):
            pass


# Generated at 2022-06-21 16:58:28.039152
# Unit test for function compile_files
def test_compile_files():
    from .files import Path
    from .types import CompilationTarget
    import os
    import shutil
    import tempfile

    # Create a temporary directory and put a test file in it
    workdir = tempfile.mkdtemp()
    test_module = os.path.join(workdir, "module.py")
    with open(test_module, 'w') as f:
        f.write("""
a = 1
for i in range(a):
    print(i)
        """)

    # Compile the test file and test the result
    result = compile_files(test_module, workdir, CompilationTarget.WEB, workdir)
    assert result.count == 1
    assert result.success == True
    assert result.target == CompilationTarget.WEB

# Generated at 2022-06-21 16:58:40.000615
# Unit test for function compile_files
def test_compile_files():
    # Create temp dir
    temp_dir = '.'.join(__file__.split('.')[0:-1])
    temp_dir = temp_dir + '.' + 'temp'
    input_ = temp_dir + '/' + 'source'
    output = temp_dir + '/' + 'compiled'
    if not os.path.isdir(temp_dir):
        os.makedirs(temp_dir)
        os.makedirs(input_)
        os.makedirs(output)
    else:
        import shutil
        shutil.rmtree(temp_dir)
        os.makedirs(temp_dir)
        os.makedirs(input_)
        os.makedirs(output)
    # Write test files:
    # file1.py

# Generated at 2022-06-21 16:58:52.273385
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os
    import tempfile
    import subprocess

    # Creates a temporary directory
    if os.path.exists('tests'):
        temp_directory = tempfile.mkdtemp()
        shutil.copytree('tests/input', temp_directory + '/input')
    else:
        temp_directory = os.getcwd()

    # Sets input and output directories
    input_ = temp_directory + '/input'
    output = temp_directory + '/output'

    # Compiles files from input directory to output directory
    result = compile_files(input_, output, CompilationTarget.py2)
    assert result.count == 2

    # Compiles files from input directory to output directory
    result = compile_files(input_, output, CompilationTarget.py3)
    assert result.count == 2



# Generated at 2022-06-21 16:59:03.659522
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    from .utils.helpers import log
    input_ = 'tests/input'
    output = 'tests/output/compile_files'

    log.info('compiling {} to {}'.format(input_, output))

    result = compile_files(input_, output, CompilationTarget.STUB,
                           'tests/input/site-packages/pandas')
    log.info('compiled {} files in {:.2f} seconds'.format(result.count,
                                                          result.time))
    log.info('dependencies: {}'.format(', '.join(result.dependencies)))

    assert subprocess.call(['diff', '-r', 'tests/expected/compile_files',
                            'tests/output/compile_files']) == 0

# Generated at 2022-06-21 16:59:12.024892
# Unit test for function compile_files
def test_compile_files():
    import pytest

    try:
        compile_files('tests/fixtures/simple-native/src',
                      'tests/fixtures/simple-native/output/src',
                      CompilationTarget.NATIVE,
                      'tests/fixtures/simple-native')
    except Exception as e:
        pytest.fail(e)



# Generated at 2022-06-21 16:59:17.428622
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/assets/uncompilable/', 'tests/output/', CompilationTarget.PYTHON27)
    assert compile_files('tests/assets/ast/', 'tests/output/', CompilationTarget.PYTHON27)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:59:23.476012
# Unit test for function compile_files
def test_compile_files():
    """Runs test on compile_files"""

    # import json
    # import os
    # import subprocess
    # import sys

    # sys.path.append(os.path.join(os.path.dirname(
    #     __file__), "..", "..", "..", "..", "target", "debug"))

    # from pygen import compile_files
    # from pygen.types import CompilationTarget
    # from pygen.utils.helpers import debug
    # from pygen.examples import SUM_PATH, PRINT_PATH, FACTORIAL_PATH

    # with open(SUM_PATH, 'r') as f:
    #     sum_code = f.read()
    # with open(PRINT_PATH, 'r') as f:
    #     print_code = f.read()
   

# Generated at 2022-06-21 16:59:40.206724
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    import subprocess

    test_path = os.path.dirname(__file__) + '/tests/files/compile_files/'
    result = compile_files(test_path + 'input', test_path + 'output',
                           CompilationTarget.PYTHON27, test_path)
    assert result.count == 4
    assert result.target == CompilationTarget.PYTHON27

    expected = json.loads(subprocess.check_output(['python', '-c',
                                                   'import json, os; json.dump(sorted(os.listdir("{}")), open("{}", "w"))'.format(
                                                       test_path + 'output',
                                                       test_path + 'output.json')]))


# Generated at 2022-06-21 16:59:42.198801
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./tests/fixtures/', '/tmp/test-out/', CompilationTarget.MPYTHON)

test_compile_files()

# Generated at 2022-06-21 16:59:53.315786
# Unit test for function compile_files
def test_compile_files():
    import os
    import os.path
    import shutil
    import sys
    import tempfile


# Generated at 2022-06-21 17:00:03.636681
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import os
    import json

    test_directory = Path(os.getcwd())

    # Example from README.md
    log_file = test_directory / "tests/data/log-on-debug.js"
    compile_files("src", "lib", CompilationTarget.ES5,
                  test_directory / "tests/data")

    # Tests
    with (test_directory / "lib/log-on-debug.js").open() as f:
        contents = f.read()
        assert(len(contents) > 0)

    with (test_directory / "lib/log-on-debug-on-debug.js").open() as f:
        contents = f.read()
        assert(len(contents) > 0)


# Generated at 2022-06-21 17:00:10.835049
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/files/test_compile_files',
                           'result/files',
                           CompilationTarget.ES5)
    assert result.target == CompilationTarget.ES5
    assert result.duration > 0.0
    assert len(result.dependencies) == 3
    assert result.dependencies == ['file1.js', 'file2.js', 'file3.js']

# Generated at 2022-06-21 17:00:18.485736
# Unit test for function compile_files

# Generated at 2022-06-21 17:00:23.785067
# Unit test for function compile_files
def test_compile_files():
    import sys
    from .context import Context, get_context
    from .transformers import transform_ast_to_cpp, transform_ast_to_js

    # Creating a new context and register the python script
    context = Context()
    context.register_python_script('input', 'main.py')

    # Compiling to C++
    result_cpp = compile_files('input', 'output', target='cpp', root=context.root_path)

    # Compiling to JavaScript
    result_js = compile_files('input', 'output', target='js', root=context.root_path)

    # Compiling to JavaScript using the global context
    result_js = compile_files('input', 'output', target='js', root=get_context().root_path)

    from .test_module.test_mypy_resolver import _test_

# Generated at 2022-06-21 17:00:27.728616
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('test/test_files/test_input', 'test/test_files/test_output', 0)
    except:
        raise Exception('test_compile_files failed')


# Generated at 2022-06-21 17:00:32.240496
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError, TransformationError
    from .transformers import _get_transformer_for_name
    from .config import get_transformer_config
    from .types import Target
    from .utils.helpers import init_logging

    init_logging()

    # Copy a test file to temporary location
    import tempfile
    import shutil
    temp_dir = tempfile.TemporaryDirectory()
    source_path = Path(__file__).parent / 'test_files'
    path_compiled = Path(temp_dir.name) / source_path.name

    shutil.copytree(source_path, path_compiled)

    # Compile test files and check that they were compiled correctly
    compile_files(source_path, path_compiled, Target.PY2)

# Generated at 2022-06-21 17:00:37.040327
# Unit test for function compile_files
def test_compile_files():
    compile_files("../compiler/../compiler/core/transformers/example_files/input/","../compiler/core/transformers/example_files/output/",CompilationTarget.JS)
    assert True


# Generated at 2022-06-21 17:00:56.677655
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as temp_dir:

        # Prepare test data
        input_dir = Path(temp_dir, 'input')
        output_dir = Path(temp_dir, 'output')
        input_dir.mkdir()
        output_dir.mkdir()

# Generated at 2022-06-21 17:01:03.526943
# Unit test for function compile_files
def test_compile_files():
    class MockIO:
        @staticmethod
        def open(*args):
            return io.StringIO("")

    class MockPath:
        @staticmethod
        def as_posix():
            return ""

        @staticmethod
        def parent():
            return MockPath()

        @staticmethod
        def mkdir(**kwargs):
            pass

    class MockInputOutput:
        def __init__(self):
            self.input = MockPath()
            self.output = MockPath()

    assert(compile_files("", "", CompilationTarget.ES5) ==
           CompilationResult(0, 0, CompilationTarget.ES5, []))
    assert(compile_files("", "", CompilationTarget.ES2015) ==
           CompilationResult(0, 0, CompilationTarget.ES2015, []))

# Generated at 2022-06-21 17:01:07.641109
# Unit test for function compile_files
def test_compile_files():
    output = 'tests/output/'
    input_ = 'tests/input/'
    target = CompilationTarget.PYTHON2
    root = 'tests/'
    compile_files(input_, output, target, root)


# Generated at 2022-06-21 17:01:17.537676
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import sys
    if sys.version_info[:2] == (3, 5):
        # There is an error with this polyfill
        # https://github.com/zvvo/type-hints/blob/master/typed_ast/ast3.py#L1062
        return
    input_ = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'input')
    output = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'output')
    shutil.rmtree(output, ignore_errors=True)
    compile_files(input_, output, CompilationTarget.PY36)
    # check that all types are correct
    # check that all files

# Generated at 2022-06-21 17:01:27.801289
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    import tempfile
    import shutil
    import os
    import sys

    base_path = os.path.dirname(__file__)
    input_ = os.path.join(base_path, 'test/test_data/test_compile_files')
    output = tempfile.mkdtemp()
    try:
        print('Input: {}, output: {}'.format(input_, output))
        print('Compilation result: {}'.format(
            compile_files(input_, output, CompilationTarget.ES5)))
        sys.path.append(output)
        import test_file
        assert test_file.test_value == 10
    finally:
        shutil.rmtree(output, ignore_errors=True)

# Generated at 2022-06-21 17:01:33.480373
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import pytest

    from .exceptions import CompilationError
    from .files import CWD, input_output_paths

    with tempfile.TemporaryDirectory() as tempdir:
        pass

    with CWD(tempdir), pytest.raises(CompilationError):
        compile_files(input_=tempdir, output=tempdir, target=CompilationTarget.ES5)

    with CWD(tempdir):
        path = tempdir / 'source.js'
        path.write_text('1 + 1')
        compile_files(input_=tempdir, output=tempdir, target=CompilationTarget.ES5)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:01:43.162500
# Unit test for function compile_files
def test_compile_files():
    from .main import get_argparser, parse_args
    from .types import CompilationTarget

    def run_compilation(input_: str, output: str, target: CompilationTarget,
                        root: Optional[str] = None) -> CompilationResult:
        parser = get_argparser()
        args = parse_args(parser, [input_, output])
        args.target = target
        args.root = root
        return compile_files(args.input, args.output, args.target, args.root)

    import pathlib
    with (pathlib.Path('tests') / 'files' / 'main_py.py').open() as f:
        code = f.read()
    tree = ast.parse(code)

# Generated at 2022-06-21 17:01:48.096245
# Unit test for function compile_files
def test_compile_files():
    class CompilationResultExpected:
        count: int
        time: float
        target: CompilationTarget
        dependencies: List[str]

        def __init__(self, count, time, target, dependencies):
            self.count = count
            self.time = time
            self.target = target
            self.dependencies = dependencies

        def __eq__(self, other):
            return self.count == other.count and \
                   self.time == other.time and \
                   self.target == other.target and \
                   self.dependencies == other.dependencies

        def __repr__(self):
            return 'CompilationResult(count={}, time={}, target={}, ' \
                   'dependencies={})'.format(self.count, self.time, self.target,
                                             self.dependencies)


# Generated at 2022-06-21 17:01:52.867379
# Unit test for function compile_files
def test_compile_files():
    compile_files('./test/test_input', './test/test_output', CompilationTarget.PY2)



# Generated at 2022-06-21 17:02:01.445384
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import json
    import difflib
    from io import StringIO
    from contextlib import contextmanager

    # Redirects stdout to a buffer to capture it
    @contextmanager
    def capture_stdout():
        oldout, olderr = sys.stdout, sys.stderr
        try:
            out=[StringIO(), StringIO()]
            sys.stdout, sys.stderr = out
            yield out
        finally:
            sys.stdout, sys.stderr = oldout, olderr
            out[0] = out[0].getvalue()
            out[1] = out[1].getvalue()

    # print and interpret
    def diff(src, dst):
        src_lines = src.splitlines()
        dst_lines = dst.splitlines()
        diff