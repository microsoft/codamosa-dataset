

# Generated at 2022-06-21 16:58:10.957031
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .exceptions import CompilationError
    from .utils.helpers import tmp_dir_fixture, subprocess_fixture
    from .utils.testdata import get_project, get_data_file
    from subprocess import Popen, PIPE, STDOUT

    data_dir = get_data_file('fixtures').as_posix()


# Generated at 2022-06-21 16:58:14.582206
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/fixtures', 'test/output/compilation', CompilationTarget.CODE)


# Generated at 2022-06-21 16:58:23.773803
# Unit test for function compile_files
def test_compile_files():
    with NamedTemporaryFile(suffix='.py') as f:
        f.write(b'# auto-py-compiler: skip-file\nprint("Test")')
        f.seek(0)
        result = compile_files(f.name, 'output', CompilationTarget.PY_TO_PY)

        assert result.file_count == 0
        assert result.time > 0
        assert result.target == CompilationTarget.PY_TO_PY
        assert not result.dependencies

    with NamedTemporaryFile(suffix='.py') as f:
        f.write(b'import math; print(math.sqrt(9))')
        f.seek(0)
        result = compile_files(f.name, 'output', CompilationTarget.PY_TO_PY_OUT)


# Generated at 2022-06-21 16:58:32.977312
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    import os
    import tempfile
    import shutil

    test_dir = Path(tempfile.mkdtemp())
    test_dir.joinpath("src").mkdir()

    input_ = test_dir.joinpath("src")
    output = test_dir.joinpath("out")
    root = test_dir.as_posix()

    with open(input_.joinpath("test.py").as_posix(), "w") as f:
        f.write("create_fob(o)\n")

    compile_files(input_.as_posix(), output.as_posix(), CompilationTarget.python, root)
    assert shutil.os.path.exists(output.joinpath("test.py").as_posix())


# Generated at 2022-06-21 16:58:37.519854
# Unit test for function compile_files
def test_compile_files():
    input_ = "test/test_examples/input"
    output = "test/test_examples/output"

    result = compile_files(input_, output, CompilationTarget.PYTHON)

    assert(result.dependencies == ['test/test_examples/input\\test_file.py'])

# Generated at 2022-06-21 16:58:44.743139
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    def make_parent_dirs_for(path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)
        
        source_dir = temp_dir / 'src'
        source_dir.mkdir()
        source_file = source_dir / 'main.py'
        with source_file.open('w') as fp:
            fp.write('print("Hello, world!")')
        assert source_file.exists()
        
        target_dir = temp_dir / 'target'
        target_dir.mkdir()
        target_file = target_dir / 'main.py'
        
        make_parent_dir

# Generated at 2022-06-21 16:58:50.568961
# Unit test for function compile_files
def test_compile_files():
    import sys
    input_ = "./test_data/testcases_src"
    output = "./test_data/tests"
    target = "python3.3"
    count, t, target, dependencies = compile_files(input_, output, target)
    print("Total number of files compiled:",count)
    print("Took {:.2f} seconds".format(t),file=sys.stderr)
    print("Compiles to:",target)
    print("Dependencies:",dependencies)


# Generated at 2022-06-21 16:58:55.490405
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from . import __file__ as module
    from .config import get_config
    from .simulate import simulate

    directory = Path(module).parent / 'example' / 'compile'
    conf

# Generated at 2022-06-21 16:58:59.160409
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory


# Generated at 2022-06-21 16:59:03.163518
# Unit test for function compile_files
def test_compile_files():
    from uuid import uuid4

    project_id = uuid4()
    path_input = 'tests/fixtures/input_{}'.format(project_id)
    path_output = 'tests/fixtures/output_{}'.format(project_id)

    compile_files(path_input, path_output, CompilationTarget.PYTHON)

# Generated at 2022-06-21 16:59:13.185517
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/fixtures/input/', 'tests/fixtures/output/',
                         CompilationTarget.ES5) == \
        CompilationResult(3, 0, CompilationTarget.ES5,
                          ['assert', 'itertools', 'os'])

# Generated at 2022-06-21 16:59:17.351361
# Unit test for function compile_files
def test_compile_files():
    compilation_result = compile_files(r"unit_tests/file_compiler/input/",
                                       r"unit_tests/file_compiler/output",
                                       CompilationTarget.CPP)
    assert compilation_result.count == 3
    assert compilation_result.target == CompilationTarget.CPP
    assert compilation_result.dependencies == [
        r'iostream', r'vector', r'cmath', r'math', r'complex', r'numeric']

# Generated at 2022-06-21 16:59:22.662677
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    
    target = 'HEAD'
    input_ = 'mypy/data'
    output = 'mypy/data2/mypy/data'
    root = 'mypy'
    
    result = compile_files(input_, output, target, root)
    
    expected_dependencies = ['typing']
    assert sorted(result.dependencies) == expected_dependencies
    assert result.target == target
    assert isinstance(result.time, float)
    assert isinstance(result.count, int)
    assert result.count == 80

    import shutil
    shutil.rmtree('mypy/data2/mypy/data')


# Generated at 2022-06-21 16:59:32.950350
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile

    def _create(name: str, content: str) -> pathlib.Path:
        p = pathlib.Path(tempfile.gettempdir()) / name
        with open(p, 'w') as f:
            f.write(content)
        return p

    with tempfile.TemporaryDirectory() as tempdir:
        tempdir = pathlib.Path(tempdir)
        a = _create('a.py', '''
import b
print('a')
''')
        b = _create('b.py', '''
print('b')
''')

        result = compile_files(tempdir, tempdir, CompilationTarget.python45)
        shutil.rmtree(tempdir)

    assert result.compiled_files == 2
    assert result.time >= 0

# Generated at 2022-06-21 16:59:42.411202
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from pathlib import Path
    from glob import glob
    from importlib import import_module
    shutil.rmtree('./output', ignore_errors=True)
    compile_files('./input', './output', CompilationTarget.PYTHON)

    out_files = list(
        map(lambda x: x.replace('output', 'input'), glob('output/*.py')))
    assert len(out_files) == len(glob('input/*.py'))

    for file in out_files:
        out_file = Path(file)
        assert out_file.is_file()
        # Make sure file can be imported
        import_module(file[:-3].replace('/', '.'))

# Generated at 2022-06-21 16:59:49.578457
# Unit test for function compile_files
def test_compile_files():
    from tempfile import mkdtemp
    from os import stat, makedirs
    import shutil

    input_ = mkdtemp()
    makedirs(input_ + '/lib/flask.py')

# Generated at 2022-06-21 16:59:50.283920
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:00:02.924081
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import shutil
    import os
    os.makedirs('testdir')
    with open('testdir/test.py', 'w') as fout:
        fout.write('print(1)\n'
                   'print(2)\n'
                   'print(3)')
    print('testdir', 'testdir/compiled', 'script')
    compile_files('testdir', 'testdir/compiled', 'script', root='./')
    assert(os.path.isfile('testdir/compiled/test.py'))
    output = subprocess.check_output(['python3', 'testdir/compiled/test.py'])
    assert(output == b'1\n2\n3\n')
    shutil.rmtree('testdir')

# Generated at 2022-06-21 17:00:12.009649
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .transformers.array_ops import ArrayOpsTransformer

    def get_code(name: str) -> str:
        path = Path(__file__).parent.joinpath(
            'tests', 'files', '{}.py'.format(name))
        return path.read_text()

    def assert_result(result: CompilationResult):
        assert result.count == 4
        assert result.time > 0.0
        assert len(result.dependencies) == 2
        assert result.dependencies[0] == 'numpy'
        assert result.dependencies[1] == 'scipy'

    target = CompilationTarget.Python3

# Generated at 2022-06-21 17:00:13.833814
# Unit test for function compile_files
def test_compile_files():
    compile_files("pycalc", "compile", "js")

# Generated at 2022-06-21 17:00:28.289641
# Unit test for function compile_files
def test_compile_files():
    compile_files("./tests/unit/compile_files/input", "./tests/unit/compile_files/output", CompilationTarget.ES5)

# Generated at 2022-06-21 17:00:33.681134
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from os.path import join, dirname, abspath, exists
    from .utils.helpers import assert_equal, assert_exception

    def assert_compiled(input_, output):
        assert exists(input_)
        assert exists(output)

    # Test that files in input directory get compiled
    # to files of same name in output directory
    test_output_root = join(dirname(abspath(__file__)), 'test_output')
    test_input_root = join(dirname(abspath(__file__)), 'test_src')
    assert_compiled(join(test_input_root, 'test_yield.py'),
                    join(test_output_root, 'test_yield.py'))

# Generated at 2022-06-21 17:00:41.952966
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .files import get_input_output_paths, InputOutput
    from .transformers import CallTransformer
    input_ = Path(__file__).parent.joinpath('test_files')
    calltransformer = CallTransformer()

    with TemporaryDirectory() as dir:
        output = Path(dir)
        paths = get_input_output_paths(input_, output)

        for paths in paths:
            assert paths.input.name.endswith('.py')
            assert paths.output.name.endswith('.py')

            calltransformer.transform(ast.parse(paths.input.read_text()))
            assert paths.input.read_text() == paths.output.read_text()

# Generated at 2022-06-21 17:00:43.793222
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from .transformers import Function, Assignment
    from .transformers.types import Tuple
    from .types import CompilationTarget
    from .utils.string import dedent


# Generated at 2022-06-21 17:00:49.141158
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class TestCompileFiles(unittest.TestCase):

        def setUp(self):
            self.tmp = tempfile.mkdtemp()
            os.makedirs(os.path.join(self.tmp, 'input'))
            os.makedirs(os.path.join(self.tmp, 'output'))

        def tearDown(self):
            shutil.rmtree(self.tmp)

        def test_compile(self):
            shutil.copy(
                os.path.join('test', 'resources', 'test_1.py'),
                os.path.join(self.tmp, 'input'),
            )

# Generated at 2022-06-21 17:00:50.814752
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass
 
if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:00:59.371812
# Unit test for function compile_files
def test_compile_files():
    class CompilationResultStub:
        def __init__(self, count: int, time: float, target: CompilationTarget,
                    dependencies: List[str]):
            self.count = count
            self.time = time
            self.target = target
            self.dependencies = dependencies
    class CompilationErrorStub:
        pass
    class TransformationErrorStub:
        pass

    # compile_files should call get_input_output_path and compile_file on every
    # input/output paths pair
    def get_input_output_paths_stub(input_: str, output: str, root: Optional[str] = None):
        return [('a.py', '1.py'), ('b.py', '2.py')]

# Generated at 2022-06-21 17:01:04.463118
# Unit test for function compile_files
def test_compile_files():
    # Get the path of current file
    base_path = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                             "sebi")
    # Search for our test file named test.py
    input_file_path = os.path.join(base_path, "test.py")
    output_file_path = os.path.join(base_path, "test_compiled.py")
    # Compile the input file
    compile_files(input_file_path, output_file_path, CompilationTarget.PYTHON)
    # Try to import the compiled file
    importlib.import_module(output_file_path.replace("/", ".")[:-3])
    
if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-21 17:01:15.275868
# Unit test for function compile_files
def test_compile_files():
    from .files import get_unit_test_paths, get_unit_test_expected_paths, \
        round_to_precision_compile_files
    from .types import CompilationTarget
    from .utils.helpers import set_debug
    
    set_debug(True)
    paths = get_unit_test_paths('compile_files')
    expected_paths = get_unit_test_expected_paths('compile_files')
    
    compile_files(paths.input.as_posix(), paths.output.as_posix(), CompilationTarget.target)
    
    assert round_to_precision_compile_files(paths.expected, expected_paths.output) == True

# Generated at 2022-06-21 17:01:23.216480
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/1', './results', CompilationTarget.PYTHON)
    diff = subprocess.check_output(['diff', '-rc', './tests/1', './results']).decode()
    assert diff.strip() == ''
    assert result.code == 1
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['builtins']

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:01:50.877703
# Unit test for function compile_files
def test_compile_files():
    """Tests if compile_files works as expected."""
    import os
    input_ = os.path.join(os.path.dirname(__file__), '..', 'test', 'input')
    output = os.path.join(input_, 'output')
    target = CompilationTarget.html
    result = compile_files(input_, output, target)
    assert result.count == 4
    assert result.target == target
    assert result.dependencies == []
    assert result.time >= 0

# Generated at 2022-06-21 17:02:00.707763
# Unit test for function compile_files
def test_compile_files():
    import astunparse
    import glob
    import json
    import os
    import struct
    absolute_path = os.path.dirname(os.path.realpath(__file__))
    data_path = os.path.join(absolute_path, "../data")
    input_path = os.path.join(data_path, "input")
    output_path = os.path.join(data_path, "output")
    files = glob.glob(input_path + '/*.py')
    if len(files) != 10:
        print("FAILURE: input files are not equal to 10")
        exit(1)
    if len(os.listdir(output_path)) != 0:
        print("FAILURE: existing output files")
        exit(1)

# Generated at 2022-06-21 17:02:05.457997
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .exceptions import CompilationError
    from .types import CompilationTarget

    def test(code: str, result: str, target: CompilationTarget, expected: str) -> None:
        with TemporaryDirectory() as t:
            input_ = Path(t) / 'in'
            output = Path(t) / 'out'
            file_in = input_ / 'file.py'

            with file_in.open('w') as f:
                f.write(code)

            compile_files(str(input_), str(output), target)

            file_out = output / result
            with file_out.open() as f:
                assert f.read() == expected

    # No transformation needed

# Generated at 2022-06-21 17:02:11.566050
# Unit test for function compile_files
def test_compile_files():
    print("TEST compile_files")
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from copy import copy

    inp = Path('tests/fixtures/transpile/')
    out = Path('tests/fixtres/transpile/')

    input_dir = TemporaryDirectory()
    output_dir = TemporaryDirectory()
    input_dir.cleanup()
    output_dir.cleanup()
    try:
        new_input = copy(inp)
        new_input.parent = input_dir
        new_output = copy(out)
        new_output.parent = output_dir
        res = compile_files(new_input, new_output, CompilationTarget.ES5)
        print(res)
    finally:
        input_dir.cleanup()
        output_dir.cleanup()


# Generated at 2022-06-21 17:02:18.596100
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    input_ = pathlib.Path.cwd() / 'tests/data'
    output = pathlib.Path.cwd() / 'tests/data/output'
    result = compile_files(input_, output, CompilationTarget.PYTHON27)
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON27
    assert result.difference > 0
    assert result.dependencies == ['typing']

# Generated at 2022-06-21 17:02:19.583659
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:02:31.075224
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./test/data/in', './test/data/out', 'js')
    dependencies = sorted(result.dependencies)
    assert dependencies == [
        './test/data/in/a.js',
        './test/data/in/b.js',
        './test/data/in/c.js',
        './test/data/in/d.js',
        './test/data/in/e.js',
        './test/data/in/f.js',
        './test/data/in/g.js'
    ]
    assert result.count == 4, result.count
    assert result.time > 0, result.time
    assert result.target == 'js', result.target


# Generated at 2022-06-21 17:02:34.797670
# Unit test for function compile_files
def test_compile_files():

    # Invoke main function
    compile_files('examples', '_compiled_files', CompilationTarget.PYTHON)

# Run unit test
if __name__ == '__main__':
    test_compile_files()
    print('Test completed!')

# Generated at 2022-06-21 17:02:46.816074
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    try:
        root = tempfile.mkdtemp()
        dirs = ['input', 'output']
        for d in dirs:
            os.makedirs(os.path.join(root, d))

        for i in range(0, 5):
            with open(os.path.join(root, 'input', 'file' + str(i) + '.py'), 'w') as f:
                f.write('print("Hello World")')
        compile_files(os.path.join(root, 'input'), os.path.join(root, 'output'), CompilationTarget.PYTHON, root)
    finally:
        shutil.rmtree(root)



# Generated at 2022-06-21 17:02:58.839936
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import pathlib
    root = pathlib.Path('test_compile_files')
    if root.exists():
        root.rmdir()

    with tempfile.TemporaryDirectory(prefix=str(root)) as tmp:
        input_ = pathlib.Path(tmp) / 'input'
        input_.mkdir()
        (input_ / 'a.py').write_text('#hello!')
        (input_ / 'b.py').write_text('#there!')
        output = pathlib.Path(tmp) / 'output'
        result = compile_files(input_, output, CompilationTarget.python36)
        assert result.target == CompilationTarget.python36
        assert result.dependencies == []
        assert result.count == 2
