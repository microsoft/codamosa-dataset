

# Generated at 2022-06-21 16:58:00.432073
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    def get_file_contents(path):
        with open(path, 'r') as f:
            return f.read()


# Generated at 2022-06-21 16:58:05.006948
# Unit test for function compile_files
def test_compile_files():

    import pytest
    from pathlib import Path
    from tempfile import TemporaryDirectory

    from .exceptions import CompilationError
    from .transformers import AllTransformerAstVisitor

    def _get_different_lines(code1: str, code2: str) -> List[str]:
        lines1 = code1.splitlines()
        lines2 = code2.splitlines()

        assert len(lines1) == len(lines2)

        diff = []
        for i, (line1, line2) in enumerate(zip(lines1, lines2)):
            if line1 != line2:
                diff.append('{:2}: {}  !=  {}'.format(i + 1, line1, line2))
        return diff


# Generated at 2022-06-21 16:58:12.589816
# Unit test for function compile_files
def test_compile_files():
    """Compiles files in test_suite_input and compares them with files
    in test_suite_output."""
    input_path = Path(__file__).parent / '..' / 'test_suite_input'
    output_path = Path(__file__).parent / '..' / 'test_suite_output'

    with open(str(input_path / 'test_expr1.py')) as f:
        input_str = f.read()
    for target in [CompilationTarget.BASIC, CompilationTarget.EXPERIMENTAL]:
        compile_files(input_path, output_path, target)
        with open(str(output_path / 'test_expr1.py')) as f:
            output_str = f.read()
        assert input_str == output_str
    return

# Generated at 2022-06-21 16:58:19.264257
# Unit test for function compile_files
def test_compile_files():

    from .test_data import TEST_DATA_DIR
    from pprint import pprint

    paths = get_input_output_paths(TEST_DATA_DIR, TEST_DATA_DIR, TEST_DATA_DIR)
    result = compile_files(TEST_DATA_DIR, TEST_DATA_DIR, CompilationTarget.PYTHON, TEST_DATA_DIR)
    pprint(result)

# Generated at 2022-06-21 16:58:31.727940
# Unit test for function compile_files
def test_compile_files():
    import os
    os.mkdir("tmp")
    os.mkdir("tmp/test")
    os.mkdir("tmp/test/in")
    os.mkdir("tmp/test/out")
    f = open("tmp/test/in/test.py","w+")
    f.write("def foo(a):\n    if a == 1:\n        return True\n    return False")
    f.close()
    #print("here")

    res = compile_files("tmp/in","tmp/out", CompilationTarget.NODE)
    f = open("tmp/test/out/test.js","r")
    result = f.read()
    f.close()

# Generated at 2022-06-21 16:58:42.307452
# Unit test for function compile_files
def test_compile_files():
    """Tests compilation of files."""
    import tempfile
    import pytest
    import shutil

    @pytest.fixture(scope='module')
    def base_dir(request):
        dir = tempfile.mkdtemp()
        def fin():
            shutil.rmtree(dir)
        request.addfinalizer(fin)
        return dir

    def _write_file(dir, *path, content):
        path = Path(dir).joinpath(*path)
        path.parent.mkdir(parents=True)
        with path.open('w') as f:
            f.write(content)

    def _read_file(dir, *path):
        with Path(dir).joinpath(*path).open() as f:
            return f.read()


# Generated at 2022-06-21 16:58:47.236950
# Unit test for function compile_files
def test_compile_files():
    """Compiles all files from input_ to output."""
    compile_files('test/sample/input/', 'test/sample/output/', CompilationTarget.BROWSER)


# Generated at 2022-06-21 16:58:51.398691
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/source', 'output', CompilationTarget.PYTHON27).count == 1
    assert compile_files('tests/data/source', 'output', CompilationTarget.PYTHON34).count == 1

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:59.157314
# Unit test for function compile_files
def test_compile_files():
    paths = get_input_output_paths("example/", "example/compiled")
    for paths in paths:
        print(paths.input)
        print(paths.output)
        _compile_file(paths, CompilationTarget.Py2)
    
test_compile_files()

# Generated at 2022-06-21 16:59:00.467625
# Unit test for function compile_files
def test_compile_files():
    # TODO: find a way to unit test this function
    pass