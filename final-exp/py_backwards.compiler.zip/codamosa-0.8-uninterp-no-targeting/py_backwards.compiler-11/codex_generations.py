

# Generated at 2022-06-21 16:58:05.637050
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationResult
    from .utils.helpers import UnitTest
    from .utils.fileutils import path_abs, path_rel


# Generated at 2022-06-21 16:58:06.250931
# Unit test for function compile_files
def test_compile_files():
    # TODO: DO
    pass

# Generated at 2022-06-21 16:58:12.789394
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    fd, dir = tempfile.mkdtemp()
    try:
        with open(os.path.join(dir, 'test.py'), 'w') as f:
            f.write('def foo():\n\tpass')
        assert compile_files(dir, dir, CompilationTarget.OPERATOR_OVERLOADS).count == 0
        assert compile_files(dir, dir, CompilationTarget.MULTIPLE_INHERITANCE).count == 0
        assert compile_files(dir, dir, CompilationTarget.INHERITANCE_SUPPORT).count == 1
        with open(os.path.join(dir, 'test.cpy'), 'r') as f:
            assert 'super' in f.read()
    finally:
        shutil.rmtree(dir)

# Generated at 2022-06-21 16:58:20.144209
# Unit test for function compile_files
def test_compile_files():
    from shutil import rmtree
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        input_ = Path(d, 'input')
        input_.mkdir()
        (input_ / 'test.py').write_text('import re')

        output = Path(d, 'output')
        output.mkdir()

        compile_files(input_, output, CompilationTarget.BIOPYTHON1)

        with (output / 'test.py').open() as f:
            assert 'import re' in f.read()

# Generated at 2022-06-21 16:58:27.172845
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.LATEST
    input_ = Path('test/testdata/simple')
    output = Path('test/output')
    root = "test/testdata"
    result = compile_files(input_, output, target, root)
    #print(result)
    assert bool(result)

# Generated at 2022-06-21 16:58:31.164403
# Unit test for function compile_files
def test_compile_files():
    test_input = './tests/test_fixtures/compile_files/'
    test_output = './tests/test_fixtures/compile_files_output/'
    res = compile_files(test_input, test_output, CompilationTarget.PY_2_7)
    assert(res.count == 3)


# Generated at 2022-06-21 16:58:41.733191
# Unit test for function compile_files
def test_compile_files():
    """Compile files and test output"""
    input_ = 'tests/input'
    output = 'tests/output'
    rc, path = compile_files(input_, output, CompilationTarget.PY2)
    assert rc.count == 3
    assert path == 'tests/output/tests/source/__init__.py'
    assert (output + '/tests/source/module/__init__.py').is_file()
    assert (output + '/tests/source/module/file.py').is_file()
    with (output + '/tests/source/module/file.py').open() as f:
        code = f.read()
        assert code == '# -*- coding: iso-8859-15 -*-\n'

# Generated at 2022-06-21 16:58:52.786040
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import os
    import shutil
    import pathlib

    def patch_path_exists(func):
        exists_orig = os.path.exists

        def exists_mock(path):
            if path == '__DELETED':
                return False
            return exists_orig(path)

        def func_wrapper(*args, **kwargs):
            os.path.exists = exists_mock
            r = func(*args, **kwargs)
            os.path.exists = exists_orig
            return r

        return func_wrapper

    @patch_path_exists
    def prepare_test(tests_dir, tmpdir):
        input_path = pathlib.Path(str(tmpdir / 'input'))
        output_path = pathlib.Path(str(tmpdir / 'output'))

# Generated at 2022-06-21 16:59:04.127155
# Unit test for function compile_files
def test_compile_files():
    from .files import InputOutput
    from .config import find_project_root
    from .transformers import transformers
    from .exceptions import CompilationError, TransformationError
    from .types import CompilationTarget
    from .utils.helpers import debug, debug_off
    from .utils.assertions import assert_true, assert_equal

    root = find_project_root()

    for transformer in transformers:
        if transformer.target >= CompilationTarget.AfterTypeCheck:
            transformer.enabled = True
        else:
            transformer.enabled = False

    input_ = root / 'test/test_files/simple_test'
    output = root / 'test/test_files/output'

    debug_off()


# Generated at 2022-06-21 16:59:05.658378
# Unit test for function compile_files
def test_compile_files():
    pass