

# Generated at 2022-06-21 16:58:02.925032
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from re import findall
    import pytest
    from .types import CompilationTarget
    with TemporaryDirectory() as tempdir:
        result = compile_files(str(Path(__file__).parent / 'example'),
                               str(Path(tempdir)),
                               CompilationTarget.TRACE)
        assert result.count == 3
        assert result.target == CompilationTarget.TRACE
        with open(str(Path(tempdir) / 'example1.html')) as f:
            example1 = f.read()
            assert '<span class="source-code-string">\n    \'\'\'\n' in example1
            assert '<span class="source-code-string">\n    \'\'\'\n</span>' in example1

# Generated at 2022-06-21 16:58:11.737735
# Unit test for function compile_files
def test_compile_files():
    from .test_data import test_data
    from pathlib import Path
    import shutil

    # Build test data
    data_root = Path('test_data')
    if data_root.exists():
        print('Removing {}'.format(data_root))
        shutil.rmtree(data_root)
    data_root.mkdir()

    for test_name in test_data:
        test = test_data[test_name]
        data_path = data_root.joinpath(test_name)
        data_path.mkdir()
        for package in test:
            if package == '__init__.py':
                (data_path / package).touch()
            else:
                (data_path / package).mkdir()

# Generated at 2022-06-21 16:58:21.240581
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from shutil import rmtree
    from ..contrib.checker import check_code, check_file
    from ..contrib.fixtures import (
        make_compilation_error_text, make_program_to_compile_text,
        make_program_to_compile_error_text
    )

    # check_code() tests
    assert check_code(make_program_to_compile_text, 'Program', 'Code')
    with pytest.raises(CompilationError):
        check_code(make_program_to_compile_error_text, 'Program', 'Code')

    # check_file() tests
    output = Path('tests/data/output')
    # Remove output directory if exists
    rmtree(output, ignore_errors=True)

# Generated at 2022-06-21 16:58:28.093490
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path

    path = Path('./test.py').resolve()
    out_path = Path('./test.py.out')

    def callback(_: List[str], output_path: Path):
        code = output_path.read_text()
        assert code == open('./test.py.out.good').read()

    def fail_callback(_: List[str], output_path: Path):
        with pytest.raises(CompilationError):
            output_path.read_text()

    compile_files(path, out_path, CompilationTarget.PYTHON38,
                  callback=callback)
    compile_files(path, out_path, CompilationTarget.PYTHON36,
                  callback=callback)

# Generated at 2022-06-21 16:58:34.975269
# Unit test for function compile_files
def test_compile_files():
    from tempfile import mkdtemp
    input_ = mkdtemp()
    output = mkdtemp()
    input_path = input_ + '/a.py'
    output_path = output + '/a.py'
    with open(input_path, 'w') as f:
        f.write("print(max(1, 2))")
    compile_files(input_, output, CompilationTarget.PY2)
    with open(output_path, 'r') as f:
        assert f.read() == "from __future__ import print_function\nprint(max(1, 2))"

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:36.039039
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    print(compile_files(tempfile.TemporaryDirectory(),
                        tempfile.TemporaryDirectory(),
                        CompilationTarget.PYTHON_MIN))

# Generated at 2022-06-21 16:58:43.529816
# Unit test for function compile_files
def test_compile_files():
    import pytest, tempfile
    tempdir = tempfile.TemporaryDirectory()

    @pytest.fixture
    def input_dir(self, request):
        return tempdir.name

    @pytest.fixture
    def output_dir(self, request):
        return tempdir.name

    @pytest.fixture
    def target(self, request):
        return CompilationTarget(0)


# Generated at 2022-06-21 16:58:49.582889
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import pytest
    from .transformers import EnvTransformer

    input_ = pathlib.Path(__file__).parent.parent / 'fixtures' / 'test_files'
    output = pathlib.Path(__file__).parent.parent / 'output'
    results = compile_files(input_, output, target=EnvTransformer.target)

    assert results.count == 1
    assert results.target == EnvTransformer.target
    assert len(results.dependencies) == 4

    result = output / 'test.py'
    with result.open() as f:
        code = f.read()

# Generated at 2022-06-21 16:58:54.972667
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import sys
    import shutil
    import os.path
    import subprocess
    from pathlib import Path
    import tempfile

    here = Path(__file__).parent

    def run(python, name):
        # print('Run:', name, '\n', '-'*20)
        # python_path = shutil.which('python3')
        # current_path = os.getcwd()
        tmp_dir = Path(tempfile.mkdtemp())
        source_path = tmp_dir / 'source'
        target_path = tmp_dir / 'target'
        source_path.mkdir()
        target_path.mkdir()

        input_path = here / name
        output_path = target_path / 'output.py'


# Generated at 2022-06-21 16:59:04.776554
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .transformers import NameTransformer, AssignmentTransformer,\
                               CallTransformer, ExpressionTransformer,\
                               ImportTransformer, AttributeTransformer,\
                               RaiseTransformer, DeleteTransformer,\
                               FunctionDefTransformer, ForTransformer,\
                               WhileTransformer, IfTransformer,\
                               WithTransformer, TryTransformer,\
                               ClassDefTransformer

    # Switch off debugging for unittest
    global debug
    debug = lambda: lambda: lambda: None

    ROOT = os.path.abspath('.')

# Generated at 2022-06-21 16:59:20.250901
# Unit test for function compile_files
def test_compile_files():
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def assertValidResult(self, result: CompilationResult, comp_time: float, target: CompilationTarget, count: int, files: List[str]):
            self.assertEqual(result.time_used_in_seconds, comp_time)
            self.assertEqual(result.target, target)
            self.assertEqual(result.count, count)
            self.assertEqual(result.dependencies, files)



# Generated at 2022-06-21 16:59:23.727246
# Unit test for function compile_files
def test_compile_files():
    from .utils.assertions import assert_compilation_result
    from .utils.test_data import get_test_data
    from .utils.assertions import assert_directory_equal

    result = compile_files(get_test_data(), 'test/test_data_out',
                           CompilationTarget.PYTHON2)

    assert_directory_equal(get_test_data(), 'test/test_data_out')
    assert_compilation_result(result, CompilationTarget.PYTHON2)

# Generated at 2022-06-21 16:59:26.758067
# Unit test for function compile_files
def test_compile_files():
    from .utils.testing import compile_files_test
    compile_files_test(compile_files)



# Generated at 2022-06-21 16:59:30.744385
# Unit test for function compile_files
def test_compile_files():
    compile_files('../test/test_data/test_1/input',
                  '../test/test_data/test_1/output',
                  'python')

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 16:59:31.818601
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 16:59:42.675331
# Unit test for function compile_files
def test_compile_files():
    # Fails for default target
    try:
        compile_files('tests/data/source', 'tests/data/output', CompilationTarget.X)
        assert False
    except TransformationError as e:
        assert e.ast.start_lineno == 3
        assert e.ast.start_col_offset == 2

    # Fails for ipython target
    try:
        compile_files('tests/data/source', 'tests/data/output', CompilationTarget.IPYTHON)
        assert False
    except TransformationError as e:
        assert e.ast.start_lineno == 3
        assert e.ast.start_col_offset == 2

    # Works for python2 target
    compile_files('tests/data/source', 'tests/data/output', CompilationTarget.PYTHON2)



# Generated at 2022-06-21 16:59:50.284509
# Unit test for function compile_files
def test_compile_files():
    from .test.test_data.test_compile_files.module import Module
    expected = Module(2, 3)
    actual = compile_files('./test/test_data/test_compile_files/input',
                           './test/test_data/test_compile_files/output',
                           CompilationTarget.ES5)
    assert expected == actual



# Generated at 2022-06-21 16:59:56.490641
# Unit test for function compile_files
def test_compile_files():
    print(compile_files('./compiler/test/test_input','./compiler/test/test_output',CompilationTarget.PY2))

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:00:01.336654
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from pkgutil import get_data

    with TemporaryDirectory() as tmpdir:
        input_ = tmpdir + '/input/'
        output = tmpdir + '/output/'

        pkg = 'obfuscapy.test.test_files'
        data = [('test', 'test.py'),
                ('test_files', '__init__.py'),
                ('test_files', 'test_files.py'),
                ('test_files', 'foo/__init__.py'),
                ('test_files', 'foo/foo.py')]
        for path, file in data:
            print('Writting', path + '/' + file)
            file = input_ + '/' + path + '/' + file

# Generated at 2022-06-21 17:00:04.985767
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/input'
    output = 'tests/output'
    target = CompilationTarget.BASIC

    compile_files(input_, output, target)

# Generated at 2022-06-21 17:00:21.457807
# Unit test for function compile_files
def test_compile_files():
    from . import templates
    from .exceptions import CompilationError
    from .utils import tmpdir
    from os.path import abspath, join, dirname
    from json import load
    with tmpdir() as d:
        input_ = join(d, 'input')
        output = join(d, 'output')
        templates.setup(input_, d)
        templates.write(input_)
        result = compile_files(input_, output, CompilationTarget.PRIVATE)
        assert result.count == 6
        assert result.target == CompilationTarget.PRIVATE
        assert result.time >= 0
        assert dirname(abspath(result.dependencies[0])) == d
        assert 0 < len(result.dependencies) < 6

# Generated at 2022-06-21 17:00:22.426486
# Unit test for function compile_files
def test_compile_files():
    pass


# Generated at 2022-06-21 17:00:31.207859
# Unit test for function compile_files
def test_compile_files():
    from os import remove, path
    CompileResult = CompilationResult
    compile_files("input/", "output/", CompilationTarget.es5)
    assert(CompileResult != None)
    assert(path.exists("output/__init__.py") == True)
    assert(path.exists("output/test.py") == True)
    assert(path.exists("output/module/__init__.py") == True)
    assert(path.exists("output/module/module.py") == True)
    remove("output/__init__.py")
    remove("output/test.py")
    remove("output/module/__init__.py")
    remove("output/module/module.py")

# Generated at 2022-06-21 17:00:41.901620
# Unit test for function compile_files
def test_compile_files():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    out_dir_path = os.path.join(dir_path, 'tests/data/output')
    import shutil
    shutil.rmtree(out_dir_path)   # clear output directory
    assert(not os.path.exists(out_dir_path))
    # compile all tests in test directory
    res = compile_files(os.path.join(dir_path, 'tests/data'), out_dir_path,
                        target=CompilationTarget.PYTHON_TO_PYTHON)
    assert(res.count > 0)
    assert(res.target in [CompilationTarget.PYTHON_TO_PYTHON, CompilationTarget.TRANSFORM_AND_EVALUATE])

# Generated at 2022-06-21 17:00:48.656277
# Unit test for function compile_files
def test_compile_files():
    def do_test(file_name):
        import os
        import shutil
        import tempfile
        import pathlib
        import pytest

        test_dir = tempfile.TemporaryDirectory()

        script_dir = os.path.dirname(os.path.realpath(__file__))
        input_ = os.path.join(script_dir, file_name)
        output = os.path.join(test_dir.name,
                              'output/' + os.path.basename(file_name))
        compile_files(input_, output, CompilationTarget.PYMOJI_BUILTINS)

        #unit test for function compile_files
        bat_path = pathlib.Path(script_dir) / 'test_output' / file_name

# Generated at 2022-06-21 17:00:57.683151
# Unit test for function compile_files
def test_compile_files():
    import os.path
    from .tests.fixtures import (
        generate_code, generate_root,
        get_fixture, INPUT_DIR, OUTPUT_DIR, expected_dependencies
    )
    from .utils.helpers import clear_dirs

    # Create temp folder
    clear_dirs([INPUT_DIR, OUTPUT_DIR])
    root = generate_root()

    generate_code(root, 'int', '', 'a = 1')
    generate_code(root, 'int', '', 'a = 1\nprint(a)')
    generate_code(root, 'int', '', 'def f():\n    return 1\n')
    generate_code(root, 'int', '', 'def f():\n    return 1\nf()\n')

# Generated at 2022-06-21 17:00:59.492300
# Unit test for function compile_files
def test_compile_files():
    compile_files('example/input', 'example/output', CompilationTarget.JAVASCRIPT)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:01:05.205679
# Unit test for function compile_files
def test_compile_files():
    from .files import INPUT_PWD, OUTPUT_PWD, TEST_TARGET

    result = compile_files(INPUT_PWD.as_posix(), OUTPUT_PWD.as_posix(),
                           TEST_TARGET, INPUT_PWD.as_posix())
    print('Compilation:')
    print('  Compiled: {} file(s)'.format(result.compiled))
    print('  Time:     {:.2f}s'.format(result.time))
    print('  Target:   {}'.format(result.target.name))
    print('  Dependencies:')
    print('\n'.join(['    ' + dep for dep in result.dependencies]))

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:01:09.998467
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import temp_dir, cwd
    from io import StringIO
    from os import remove, makedirs

    def test_steps(input: str, output: str, target: CompilationTarget,
                   root: Optional[str] = None) -> None:
        """Performs a test using temporary dir and current working dir."""
        with temp_dir() as td:
            makedirs(td+"/input")
            with open(td+"/input/file.py", "w") as f:
                f.write(input)

            with cwd(td):
                result = compile_files("input", "output", target, root)
                assert result.target == CompilationTarget.Python35
                assert result.dependencies == ["", "file"]
                assert result.count == 1


# Generated at 2022-06-21 17:01:18.293012
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from tempfile import TemporaryDirectory
    from os import path
    from .exceptions import CompilationError
    from .utils.helpers import find_file_in_path

    test_code = '''\
    readline()
    try:
        print(1, 2)
    except:
        pass
    '''
    expect_code = '''\
    readline();
    try {
        print(1,
              2);
    } catch (...) {
        ;
    }
    '''

    with TemporaryDirectory() as tmp_dir:
        with open(path.join(tmp_dir, 'test.py'), 'w') as f:
            f.write(test_code)

        find_file_in_path(tmp_dir, 'test.py')


# Generated at 2022-06-21 17:01:34.199354
# Unit test for function compile_files
def test_compile_files():
    input_ = "tests/multitarget/input"
    output = "output"
    target = CompilationTarget.PYPY
    assert compile_files(input_, output, target).target == target

# Generated at 2022-06-21 17:01:44.202213
# Unit test for function compile_files
def test_compile_files():
    from .compile import compile_files
    from .types import CompilationResult
    from .parser import parse_args
    from .utils.helpers import debug
    from .constants import DEFAULT_OUTPUT_FOLDER, DEFAULT_INPUT_FOLDER, DEFAULT_TARGET
    from pathlib import Path

    # Here we have to put our test files
    # <test-path>/tmp/input/<test-file>.py
    TEST_PATH = Path(__file__).parent.parent.parent
    TEST_INPUT = TEST_PATH / 'tmp/input'
    TEST_OUTPUT = TEST_PATH / 'tmp/output'

    # We create our arguments
    args = parse_args([str(TEST_INPUT), str(TEST_OUTPUT), '--debug'])

# Generated at 2022-06-21 17:01:54.689433
# Unit test for function compile_files
def test_compile_files():
    from os import mkdir

    def do_test(input_: str, output: str,
                target: CompilationTarget, root: str,
                expected_count: int, expected_lines: List[str]):
        from tempfile import mkdtemp
        from shutil import copytree, rmtree


# Generated at 2022-06-21 17:02:02.074733
# Unit test for function compile_files
def test_compile_files():
    input_ = '/Users/jesse/Documents/Divergent/divergent-compiler/test/input/test_input'
    output = '/Users/jesse/Documents/Divergent/divergent-compiler/test/output/test_output'
    target = CompilationTarget.PY2
    root = '/Users/jesse/Documents/Divergent/divergent-compiler/'
    cr = compile_files(input_, output, target, root)



# def test_compile_files():
#     input_ = '/Users/jesse/Documents/Divergent/divergent-compiler/test/input/test_input'
#     output = '/Users/jesse/Documents/Divergent/divergent-compiler/test/output/test_output'
#     target = CompilationTarget

# Generated at 2022-06-21 17:02:08.687372
# Unit test for function compile_files
def test_compile_files():
    """Tests compile_files."""
    import pytest
    import shutil
    import tempfile
    from .files import mkdir_recursive
    from . import __root__
    from .transformers import reexporter

    temp_dir = tempfile.mkdtemp()
    root_sub_dir = tempfile.mkdtemp(dir=temp_dir)

    source_dir = __root__.parent
    for source in source_dir.glob('*.py'):
        destination = root_sub_dir + source.relative_to(source_dir).as_posix()
        mkdir_recursive(destination.parent)
        shutil.copy2(source, destination)

    result = compile_files(root_sub_dir.as_posix(), temp_dir, CompilationTarget.REEXPORT)
    assert result

# Generated at 2022-06-21 17:02:17.711056
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        input_ = './tests'
        output = tmpdir
        comp_result = compile_files(input_, output, CompilationTarget.PYTHON)
        assert comp_result.count == 3
        assert comp_result.duration > 0
        assert comp_result.dependencies == ['astunparse', 'typed_ast']



# Generated at 2022-06-21 17:02:19.866426
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('.', '.build', CompilationTarget.LEVEL_1)
    assert len(result.dependencies) == 0, 'No dependencies expected'
    assert result.count > 0, 'Some files expected'
    assert result.count == result.files_processed, 'All files must be processed'

# Generated at 2022-06-21 17:02:31.269923
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from pytest import raises
    from .types import CompilationTarget
    from .exceptions import CompilationError
    try:
        compile_files("", "", CompilationTarget.ES6)
        raise ValueError("compile_files must raise error")
    except CompilationError as e:
        assert str(e) == 'File "" not found'
    try:
        compile_files("qwert", "qwert", CompilationTarget.ES6)
        raise ValueError("compile_files must raise error")
    except CompilationError:
        pass

# Generated at 2022-06-21 17:02:33.014809
# Unit test for function compile_files

# Generated at 2022-06-21 17:02:36.292821
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./test-input', './test-output', CompilationTarget.PERCENT) == CompilationResult(4, 0.0, CompilationTarget.PERCENT, [])