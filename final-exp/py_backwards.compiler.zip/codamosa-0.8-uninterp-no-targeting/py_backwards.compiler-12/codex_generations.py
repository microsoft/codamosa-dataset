

# Generated at 2022-06-21 16:58:09.832422
# Unit test for function compile_files
def test_compile_files():
    from .tests.fixtures import setup_test_case
    from .tests.testing import run_tests
    from .types import TestCase

    def test_cases():
        for use_directory in [True, False]:
            for target in CompilationTarget:
                for path in ['non-existent', 'invalid.py']:
                    case = deepcopy(TestCase(path, CompilationError))
                    case.use_directory = use_directory
                    case.target = target
                    yield case

                for path in ['simple.py']:
                    case = deepcopy(TestCase(path, None))
                    case.use_directory = use_directory
                    case.target = target
                    yield case

    run_tests(test_cases(), setup_test_case, compile_files)

# Generated at 2022-06-21 16:58:20.597178
# Unit test for function compile_files
def test_compile_files():
    class Mock:
        pass
    paths = Mock()
    paths.input = Mock()
    paths.input.open = lambda: None
    paths.input.as_posix = lambda: 'input'
    paths.output = Mock()
    paths.output.parent = Mock()
    paths.output.parent.mkdir = lambda **kwargs: None
    paths.output.open = lambda _: None
    result = compile_files(None, None, None, paths)
    assert result.source_count == 1
    assert isinstance(result.time, float) and result.time >= 0
    assert result.target == None
    assert result.dependencies == []
    # TODO: test result.target
    # TODO: test result.dependencies

# Generated at 2022-06-21 16:58:29.258229
# Unit test for function compile_files
def test_compile_files():
    input_ = '/Users/rongxinzhu/Desktop/learn_to_code/compiler/tests/source'
    output = '/Users/rongxinzhu/Desktop/learn_to_code/compiler/tests/compiled'
    target = 'python38'
    print(compile_files(input_, output, target))


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:41.391448
# Unit test for function compile_files
def test_compile_files():
    import sys, os
    import subprocess
    import tempfile
    import shutil

    def compile_files_run(f):
        check_output = subprocess.check_output
        if sys.version_info < (3,):
            check_output = lambda x: subprocess.check_output(x,
                                                             env={"PYTHONPATH": "."}).decode("ascii")

        with tempfile.TemporaryDirectory() as tmp:
            input_ = os.path.join(tmp, "input")
            output = os.path.join(tmp, "output")
            shutil.copytree("tests/examples", input_)
            compile_files(input_, output, CompilationTarget.PY3)

            py2_input = os.path.join(input_, "python_2")

# Generated at 2022-06-21 16:58:51.016513
# Unit test for function compile_files
def test_compile_files():
    import os

    input_ = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../input')
    output = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../output')

    result = compile_files(input_, output, CompilationTarget.C)
    assert(result.count == 3)
    assert(result.target == CompilationTarget.C)
    assert(len(result.dependencies) == 2)

# Generated at 2022-06-21 16:59:02.637751
# Unit test for function compile_files
def test_compile_files():
    import logging
    import sys
    import tempfile
    import shutil
    from .parser import PARSE_TARGET

    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
    shutil.rmtree('.compiled/', ignore_errors=True)

    result = compile_files('./tests/', './tests/.compiled/', PARSE_TARGET)
    assert result.compiled > 0
    assert result.time > 0

    tmp = tempfile.mkdtemp()
    result = compile_files('.', tmp, PARSE_TARGET, root='./tests/')
    assert result.compiled > 0
    assert result.time > 0

# Generated at 2022-06-21 16:59:14.032358
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from pathlib import Path
    from unittest import TestCase

    empty = CompilationResult(0, 0, CompilationTarget.PYTHON, [])

    class CompileFilesTestCase(TestCase):
        def setUp(self):
            _, input_ = tempfile.mkstemp(dir='.')
            _, output = tempfile.mkstemp(dir='.')
            self.input_ = Path(input_)
            self.output = Path(output)

        def tearDown(self):
            for path in [self.input_, self.output]:
                if path.exists():
                    path.unlink()


# Generated at 2022-06-21 16:59:20.051038
# Unit test for function compile_files
def test_compile_files():
    import distutils.dir_util
    distutils.dir_util.mkpath('./test_output')
    compile_files('./test_files', './test_output', CompilationTarget.RUNTIME)
    compile_files('./test_files', './test_output', CompilationTarget.TRANSFORMER)
    compile_files('./test_files', './test_output', CompilationTarget.TESTING)
    compile_files('./test_files', './test_output', CompilationTarget.TYPE_CHECK)



# Generated at 2022-06-21 16:59:21.398405
# Unit test for function compile_files
def test_compile_files():
    from ..test.helpers import run_fixture_test
    run_fixture_test(__file__, '_test_compile_files')

# Generated at 2022-06-21 16:59:28.191229
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(input_='test-files/test1/src',
                           output='test-files/test1/result',
                           target=CompilationTarget.SELF)
    assert result.files == 3
    assert result.dependencies == []
    assert result.target == CompilationTarget.SELF

# Generated at 2022-06-21 16:59:38.447234
# Unit test for function compile_files
def test_compile_files():
    from pytest import raises
    with raises(CompilationError):
        compile_files('./test/data/compile', '/tmp/output', 'c')
    compile_files('./test/data/compile', '/tmp/output', 'c', './test/data/compile')

# Generated at 2022-06-21 16:59:47.470680
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os
    # pylint: disable=global-statement
    global _transform, _compile_file

    # Unit test for function _transform
    def test_transform():
        # pylint: disable=global-statement
        global _transform

        class Transformer:
            target = 3

            @staticmethod
            def transform(tree: ast.AST) -> None:
                pass

        def transform_func(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:  # pylint: disable=unused-argument
            return 'transformed', {'deps'}

        old_transform = _transform
        _transform = transform_func


# Generated at 2022-06-21 16:59:48.233240
# Unit test for function compile_files
def test_compile_files():
    pass



# Generated at 2022-06-21 16:59:54.024989
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./tests/input/empty', './tests/output', CompilationTarget.ES5) == CompilationResult(3, 0.0, CompilationTarget.ES5, [])
    assert compile_files('./tests/input/empty', './tests/output', CompilationTarget.ES6) == CompilationResult(3, 0.0, CompilationTarget.ES6, [])
    assert compile_files('./tests/input/empty', './tests/output', CompilationTarget.ES6_STRICT) == CompilationResult(3, 0.0, CompilationTarget.ES6_STRICT, [])
    assert compile_files('./tests/input/empty', './tests/output', CompilationTarget.ES7) == CompilationResult(3, 0.0, CompilationTarget.ES7, [])
   

# Generated at 2022-06-21 17:00:03.868634
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    current_dir = pathlib.Path(__file__).parent.resolve()
    input_dir = current_dir / 'input'
    output_dir = current_dir / 'output'
    expected_output_dir = current_dir / 'expected_output'
    result = compile_files(input_dir, output_dir, CompilationTarget.ES5)
    for file in input_dir.glob('*'):
        if file.is_dir():
            continue
        output_file = output_dir / file.name
        expected_output_file = expected_output_dir / file.name
        assert output_file.read_text() == expected_output_file.read_text(), \
            '{} failed'.format(file.name)
    print('Passed unit test')


# Generated at 2022-06-21 17:00:09.373150
# Unit test for function compile_files
def test_compile_files():
    from .utils import get_test_file_path
    result = compile_files(get_test_file_path('input'),
                           get_test_file_path('output'),
                           CompilationTarget.to_html)
    # TODO: check result
    assert isinstance(result, CompilationResult)

# Generated at 2022-06-21 17:00:17.064439
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths, InputOutput
    from pathlib import Path
    import os
    import shutil
    if os.path.exists('test'):
        shutil.rmtree('test')

    result = compile_files('test/test_directory', 'test/test_directory_output', CompilationTarget.PYTHON)
    assert result.count == 5
    assert os.path.exists('test/test_directory_output')
    assert os.path.exists('test/test_directory_output/__init__.py')
    assert os.path.exists('test/test_directory_output/my_module.py')
    assert os.path.exists('test/test_directory_output/__pycache__')

# Generated at 2022-06-21 17:00:19.751002
# Unit test for function compile_files
def test_compile_files():
    results = compile_files('/lustre/backup/test/test.py', '/lustre/backup/test/test_py36.py', CompilationTarget.PY36)
    assert results.files_compiled == 1
    assert results.duration >= 0
    assert results.target == CompilationTarget.PY36

# Generated at 2022-06-21 17:00:31.227538
# Unit test for function compile_files
def test_compile_files():
    import io
    import os
    import shutil
    input_ = os.path.join('.', 'input')
    output = os.path.join('.', 'output')
    html = '<!DOCTYPE html><html><head><head><body>test</body></html>'
    try:
        shutil.rmtree(input_)
    except FileNotFoundError:
        pass
    try:
        shutil.rmtree(output)
    except FileNotFoundError:
        pass
    os.mkdir(input_)
    with io.open(os.path.join(input_, 'index.html'), 'w') as f:
        f.write(html)
    compile_files(input_, output, CompilationTarget.dev)

# Generated at 2022-06-21 17:00:33.420014
# Unit test for function compile_files
def test_compile_files():
    compile_files("/home/igorek/Desktop/mipt-diht/KT2/src/main", "/home/igorek/Desktop/mipt-diht/KT2/src/output", CompilationTarget.TO_PYTHON)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:00:55.608978
# Unit test for function compile_files
def test_compile_files():
    import sys, os
    import tempfile
    import pytest
    import shutil
    import subprocess

    def ls(dir):
        file_lst = []
        for filename in os.listdir(dir):
            file_lst.append(os.path.join(dir, filename))
        return file_lst

    here = os.path.abspath(os.path.dirname(__file__))
    test_dir = os.path.join(here, 'tests/buildtest')


# Generated at 2022-06-21 17:01:01.499738
# Unit test for function compile_files
def test_compile_files():
    from .test_cases import test_cases
    from random import choice
    from os.path import join
    from tempfile import TemporaryDirectory

    for name, case in test_cases.items():
        if not case.expect_success:  # don't run fail tests
            continue

        with TemporaryDirectory() as tempdir:
            compile_files(
                join(case.path, case.file),
                join(tempdir, choice(['.', '', 'samples'])),
                case.target,
                case.path,
            )


if __name__ == '__main__':
    import sys

    test_compile_files()

    compile_files(*sys.argv[1:])

# Generated at 2022-06-21 17:01:06.814144
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import sys

    input_ = 'tests/data/cases'
    output = 'test_output'
    target = CompilationTarget(sys.version_info.major, sys.version_info.minor)

    assert compile_files(input_, output, target)

    output_path = Path(output)
    test_cases = ['__init__.py', '__main__.py',
                  'main_impl.py', 'lib_impl.py', 'defaults.py']


# Generated at 2022-06-21 17:01:17.255285
# Unit test for function compile_files
def test_compile_files():
    import coverage
    import glob
    import os
    import sys
    import unittest

    # Run coverage using this script
    cov = coverage.Coverage(config_file=True,
                            source=['..', '../nordlib'])
    cov.start()
    from nord.compiler import compile_files
    from nord.files import get_input_output_paths

    class CompileFilesTester(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.result = None  # type: CompilationResult

        def setUp(self):
            self.timer = time()

        def tearDown(self):
            self.timer = time() - self.timer


# Generated at 2022-06-21 17:01:20.446905
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/test_compiler', 'tests/test_compiler_result',
                  CompilationTarget.LIBRARY, 'tests')

# Generated at 2022-06-21 17:01:29.607275
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    from .constants import DEFAULT_TARGET

    input_ = 'input'
    input_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir, input_)
    output = 'output'
    output_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir, output)

    try:
        shutil.rmtree(output_path)
    except FileNotFoundError:
        pass

    compile_files(input_, output, DEFAULT_TARGET)


# Generated at 2022-06-21 17:01:39.370450
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    paths = os.path.split(__file__)

    with tempfile.TemporaryDirectory() as directory:
        shutil.copyfile(os.path.join(paths[0], 'tests', 'test.py'),
                        os.path.join(directory, 'test.py'))
        compile_files(directory, 'src', CompilationTarget.PYTHON_C,
                      root=directory)

        with open(os.path.join(directory, 'src', 'test.c')) as f:
            code = f.read()

    assert len(code) > 0
    assert all([target in code for target in ('py2c', 'PY2C')])
test_compile_files()

# Generated at 2022-06-21 17:01:40.059832
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:01:50.565243
# Unit test for function compile_files
def test_compile_files():
    from .fixtures._test_compile_files import *
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from pathlib import Path
    from os import remove
    from tempfile import mkdtemp
    import pytest

    set_transformers()

    target = CompilationTarget.PYTHON_27
    tmp = Path(mkdtemp())
    input_ = tmp.joinpath('input/')
    output = tmp.joinpath('output/')
    input_.mkdir()
    output.mkdir()

# Generated at 2022-06-21 17:01:57.995055
# Unit test for function compile_files
def test_compile_files():
    import os
    from .transformers import targets
    from .transformers.transformers import transformers as all_transformers
    
    from . import utils
    
    
    error_mapping = {
        # message, line, column
    }
    
    for filename in utils.list_compilation_test_cases():
        
        for target in targets:
            with open(os.path.join(utils.test_dir(), 'compile', filename), 'r') as f:
                test_code = f.read()
            
            for transformer in all_transformers:
                if transformer.target > target:
                    break
                
                transformer.required = True
            
            # make sure the file is not compiled