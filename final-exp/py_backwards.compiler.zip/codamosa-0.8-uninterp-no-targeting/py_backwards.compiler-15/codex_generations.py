

# Generated at 2022-06-21 16:57:59.328614
# Unit test for function compile_files
def test_compile_files():
    class Result:
        def __init__(self, func, *args):
            self.count = 0
            self.func = func
            self.args = args
            self.duration = 0
            self.target = CompilationTarget.ES6
            self.dependencies = []

    assert compile_files(None, None, CompilationTarget.JS) == Result(
        compile_files, None, None, CompilationTarget.JS)

# Generated at 2022-06-21 16:58:10.711090
# Unit test for function compile_files
def test_compile_files():
    import json
    import shutil
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir, \
            tempfile.NamedTemporaryFile(mode='w') as reportfile:
        shutil.copytree('../tests/data', tempdir + '/src')
        compile_files(input_=tempdir + '/src', output=tempdir + '/src',
                      root=tempdir + '/src', target=CompilationTarget.ES5)
        with open(tempdir + '/src/test.js') as f:
            result = f.read()
            reportfile.write(json.dumps(result, indent=2))

# Generated at 2022-06-21 16:58:21.047255
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from .utils.helpers import delete_dir

    output_dir = Path(__file__).absolute().parent.parent / 'tmp'
    delete_dir(output_dir)
    output_dir.mkdir()

    result = compile_files('tests/data', output_dir, CompilationTarget.nodejs)
    assert result.count == 5
    assert result.target == CompilationTarget.nodejs
    assert result.time > 0
    assert len(result.dependencies) == 0

    result = compile_files('tests/data', output_dir, CompilationTarget.browsers)
    assert result.count == 4
    assert result.target == CompilationTarget.browsers
    assert result.time > 0
    assert len(result.dependencies) == 0

    result = compile_

# Generated at 2022-06-21 16:58:27.954063
# Unit test for function compile_files
def test_compile_files():
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def test_compile_files_blank(self):
            for target in CompilationTarget:
                input_ = 'tests/data/empty'
                output = 'tests/data/empty2'
                result = compile_files(input_, output, target)
                self.assertEqual(result.count, 0)
                self.assertEqual(result.dependencies, [])
                self.assertEqual(result.target, target)
                self.assertGreater(result.elapsed, 0)

        def test_compile_files_one(self):
            for target in CompilationTarget:
                input_ = 'tests/data/hello-world'
                output = 'tests/data/hello-world2'

# Generated at 2022-06-21 16:58:32.917744
# Unit test for function compile_files
def test_compile_files():
    """Test for compile_files"""
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from pprint import pprint
    input_ = 'tests/test_compile.in'
    output = 'tests/test_compile.out'
    result = compile_files(input_, output, CompilationTarget.PY2)
    assert result.count == 5
    assert result.target == CompilationTarget.PY2
    assert result.dependencies == ['typing']

    print(result.time)

# Generated at 2022-06-21 16:58:39.167438
# Unit test for function compile_files
def test_compile_files():
    from .files import get_test_paths, TEST_ROOT
    result = compile_files(get_test_paths()[0].input.parent,
                           get_test_paths()[0].output.parent,
                           CompilationTarget.CYTHON, TEST_ROOT)
    assert result.count == 1
    assert result.elapsed > 0
    assert result.target == CompilationTarget.CYTHON
    assert len(result.dependencies) > 0

# Generated at 2022-06-21 16:58:44.887773
# Unit test for function compile_files
def test_compile_files():
    """Compiles all files from input_ to output."""
    compile_files('tests/data/python_source/',
                  'tests/data/compiled/',
                  CompilationTarget.PYTHON_3_3)

# Generated at 2022-06-21 16:58:53.531296
# Unit test for function compile_files
def test_compile_files():
    # Fuses two blocks
    assert compile_files(input_="tests/fixture/code/test_compile_files.py",
                         output="tests/output/compile_files/test_compile_files",
                         target=CompilationTarget.native) == \
           CompilationResult(
               1, 0.0, CompilationTarget.native, [])

    # Compiles a loop containing an if
    assert compile_files(input_="tests/fixture/code/if_with_loop_in_code.py",
                         output="tests/output/compile_files/if_with_loop_in_code",
                         target=CompilationTarget.native) == \
           CompilationResult(
               1, 0.0, CompilationTarget.native, [])

    # Compiles an if with a while containing a for loop

# Generated at 2022-06-21 16:59:03.128096
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from .common_code import test_file_content, test_file_path
    import os.path

    with TemporaryDirectory() as tempdir:
        compile_files(test_file_path, tempdir, CompilationTarget.FULL)
        paths = list(get_input_output_paths(test_file_path, tempdir))
        assert len(paths) == 1
        assert paths[0].input == test_file_path
        assert paths[0].output == os.path.join(tempdir, 'test.py')
        assert paths[0].output.read_text() == test_file_content


# Generated at 2022-06-21 16:59:14.217846
# Unit test for function compile_files
def test_compile_files():
    from .files import path_input, path_output
    from .utils.helpers import get_test_files, get_test_text_file
    from typing import Dict
    import os.path

    os.makedirs(path_output)

    expected_compiled_files = {
        'compile',
        'main',
        'constants',
        'compile_errors',
        'aliases',
        'primes',
        'math',
        'import2',
        'import',
        'py_compile',
        'bignum',
        'compare',
        'functions'
    }

    def compile_files(path_input: str, path_output: str):
        """Compiles all files from path_input to path_output."""
        from pathlib import Path

# Generated at 2022-06-21 16:59:32.633895
# Unit test for function compile_files
def test_compile_files():
    from .test_helpers import compile_input_output, assert_target
    from .test_helpers import get_compiled


    # Tests that only file is compiled
    def _test_non_recursive(target: CompilationTarget):
        _, output = compile_input_output('./', './')
        assert_target(output / 'file.py', target)
        assert_target(output / 'folder', target)
        assert not (output / 'folder').exists()


    # Tests that all files are compiled
    def _test_recursive():
        _, output = compile_input_output('./', './', recursive=True)
        assert_target(output / 'file.py', CompilationTarget.PY3)

# Generated at 2022-06-21 16:59:33.453040
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 16:59:43.286840
# Unit test for function compile_files
def test_compile_files():
    import io
    import tempfile

    def get_code(name: str) -> str:
        with io.StringIO(code) as f:
            return f.readlines()[name]


# Generated at 2022-06-21 16:59:54.701708
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    tempdir = tempfile.TemporaryDirectory()
    try:
        test_file = tempdir.name + '/test.py'
        with open(test_file, 'w') as f:
            f.write("""
        if foo == False:
            print("Boolean")
            raise Exception("String")
            raise SystemExit()
        """)
        result = compile_files(test_file, tempdir.name, CompilationTarget.CPYTHON)
    finally:
        tempdir.cleanup()
    assert result.count == 1
    assert result.target == CompilationTarget.CPYTHON

# Generated at 2022-06-21 16:59:59.404336
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import pytest

    @pytest.fixture
    def tmp(tmpdir):
        return str(tmpdir)

    def test_basic(tmp):
        input_ = os.path.join(tmp, 'input')
        output = os.path.join(tmp, 'output')

        os.makedirs(input_)
        with open(os.path.join(input_, 'test.txt'), 'w') as f:
            f.write('hello world!')

        shutil.rmtree(output, ignore_errors=True)

        compile_files(input_, output, CompilationTarget.PYTHON)
        with open(os.path.join(output, 'test.txt')) as f:
            assert f.read() == 'hello world!'

# Generated at 2022-06-21 17:00:00.967292
# Unit test for function compile_files
def test_compile_files():
    #!TODO: Implement compile files tests
    return True

# Generated at 2022-06-21 17:00:05.058086
# Unit test for function compile_files
def test_compile_files():
    test_input = 'tests/input_files'
    test_output = 'tests/output_files'
    target = CompilationTarget.TARGET_1
    compile_files(test_input, test_output, target)

# Generated at 2022-06-21 17:00:08.474527
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('./test_data/input', './test_data/output', CompilationTarget.ES5)
    except:
        return False

    return True

# Generated at 2022-06-21 17:00:16.201608
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(
        'tests/exampleProject/src',
        'tests/exampleProject/out',
        CompilationTarget.JAVA) == CompilationResult(
        count=4, elapsed=0.0, target=CompilationTarget.JAVA, dependencies=['stdio'])

# This file is almost the same as compile.py,
# but compiles a single file instead of all files.
# I don't want to duplicate code, but I don't see another way.
if __name__ == '__main__':
    import sys
    if len(sys.argv) not in (3, 4):
        print('Usage: {} input output [target]'.format(sys.argv[0]))
        exit(1)


# Generated at 2022-06-21 17:00:16.969209
# Unit test for function compile_files
def test_compile_files():
    # TODO: implement
    pass

# Generated at 2022-06-21 17:00:29.208934
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('src/compiler/test_data/input', 'src/compiler/test_data/output', CompilationTarget.PYTHON27)
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON27
    assert result.time >= 0
    assert len(result.dependencies) == 3
    assert result.dependencies[0] == 'typed_ast.ast3'

# Generated at 2022-06-21 17:00:41.902078
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import subprocess
    import pytest
    from pathlib import Path
    from .exceptions import CompilationError
    from .types import CompilationResult

    def run_test(python_version: str, input_: str, output: str, target: str,
                 root: Optional[str] = None) -> CompilationResult:
        root_arg = '--root={0}'.format(root) if root else ''
        cmd = 'python{0} -m bpylist.main {1} {2} {3} {4}'.format(
            python_version, input_, output, target, root_arg)
        debug(lambda: '{}'.format(cmd))
        output = subprocess.check_output(cmd, shell=True)

# Generated at 2022-06-21 17:00:48.654742
# Unit test for function compile_files
def test_compile_files():
    from .files import get_test_paths
    from .config import get_config, Config
    from .utils.types import CompilationTarget
    from .utils.helpers import clear_directory
    from .exceptions import CompilationError
    from .test_utils import (
        _test_compile_file, _test_compilation,
        _test_compilation_with_non_existing_input,
        _test_compilation_with_non_existing_output
    )

    def _compile_files(input_: str, output: str, root: Optional[str] = None) -> CompilationResult:
        try:
            return compile_files(input_, output, Config.compilation_target, root)
        except CompilationError as e:
            print(e)

# Generated at 2022-06-21 17:00:53.320869
# Unit test for function compile_files
def test_compile_files():
    class CompilationResultMock(object):
        def __init__(self, target, dependencies):
            self.target = target
            self.dependencies = dependencies

    compilation_result = CompilationResultMock(CompilationTarget.NODE, ["test"])

    assert compile_files("test", "test", CompilationTarget.NODE) == compilation_result



# Generated at 2022-06-21 17:01:00.884139
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./tests/files/simple/input/', './tests/files/simple/output/', CompilationTarget.Py2).dependencies == ['time', 'difflib', 'six.moves.input', 'six.moves.urllib_parse', 'six.moves.urllib_request', 'six.moves.urllib_response']
    assert compile_files('./tests/files/simple/input/', './tests/files/simple/output/', CompilationTarget.Py3).dependencies == ['time', 'six.moves.urllib_request', 'six.moves.urllib_response']

# Generated at 2022-06-21 17:01:03.517728
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('input', 'output', CompilationTarget.ES5)
    assert result.count == 24
    assert result.time > 0
    assert result.target == CompilationTarget.ES5
    assert len(result.dependencies) == 6

# Generated at 2022-06-21 17:01:15.357302
# Unit test for function compile_files
def test_compile_files():

    import os
    import shutil
    from tempfile import mkdtemp
    from .examples.numpy_array import numpy_array

    tmp = mkdtemp()
    os.chdir(tmp)

# Generated at 2022-06-21 17:01:27.047925
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .tests.constants import TEST_MODULE_DIR
    import shutil
    import tempfile
    import pytest
    import logging

    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    temp_dir = Path(tempfile.mkdtemp())
    try:
        shutil.copytree(TEST_MODULE_DIR / 'test_module',
                        temp_dir / 'test_module')
        assert compile_files(temp_dir, temp_dir,
                             CompilationTarget.RUNTIME).files == 8
    finally:
        shutil.rmtree(temp_dir)


# Generated at 2022-06-21 17:01:29.293757
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests', 'tests_output', CompilationTarget.PYTHON)
    assert compile_files('tests', 'tests_output', CompilationTarget.NODEJS)


# Generated at 2022-06-21 17:01:34.815373
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from .utils.helpers import temp_dir

    with temp_dir() as tmp:
        input_ = str(Path(tmp) / 'input')
        output = str(Path(tmp) / 'output')

        # Just one file, without any transformations
        (Path(input_) / 'a.py').write_text('')
        result = compile_files(input_, output, CompilationTarget.TYPE_COMMENTS)
        assert result.count == 1
        assert result.target == CompilationTarget.TYPE_COMMENTS
        assert not result.dependencies

        # One file and a directory
        (Path(input_) / 'foo' / 'a.py').write_text('')
        result = compile_files(input_, output, CompilationTarget.TYPE_COMMENTS)

# Generated at 2022-06-21 17:01:46.232200
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('tests/project/src/', 'tests/project/target/', CompilationTarget.GOLANG)
    except:
        print('Compile failed')
    return

# Generated at 2022-06-21 17:01:58.945079
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import assert_code_equal, assert_code_not_equal

    from os import path, getcwd
    from shutil import rmtree
    from tempfile import mkdtemp

    d = path.join(getcwd(), 'tests')
    input_ = path.join(d, 'input')
    output = path.join(d, 'output')

    # Clean up previusly generated files
    rmtree(output)

    # Test time
    result = compile_files(input_, output, CompilationTarget.PYTHON3)
    assert result.compiled == 2
    assert result.time > 0
    assert result.target == CompilationTarget.PYTHON3
    assert result.dependencies == ['it.unimi.dsi.fastutil', 'java.util']

    # Test

# Generated at 2022-06-21 17:02:02.503790
# Unit test for function compile_files
def test_compile_files():
    from .utils.tests import assert_is_subset, assert_is_subset, assert_is_subset
    import os

    def assert_compiles_to(s: str, t: str, target: CompilationTarget,
                           deps: List[str], count: int):
        c = compile_files(s, t, target)
        assert c.count == count
        assert_is_subset(c.dependencies, deps)

    c = '''
    import a
    import b
    import c

    def d():
        ...
    '''

    try: os.mkdir('tests/compile')
    except FileExistsError: pass

    with open('tests/compile/foo.py', 'w') as f:
        f.write(c)


# Generated at 2022-06-21 17:02:06.648940
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.PYTHON_TO_PYTHON_COMPATIBLE
    input_ = 'tests/input'
    output = 'tests/output'
    result = compile_files(input_, output, target)
    assert result.count == 2
    assert result.duration >= 0
    assert result.target == target
    assert sorted(result.dependencies) == ['requests']

# Generated at 2022-06-21 17:02:07.816302
# Unit test for function compile_files
def test_compile_files():
    # TODO: Write unit test
    pass

# Generated at 2022-06-21 17:02:19.535206
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import tempfile
    import shutil
    for target in CompilationTarget:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            input_ = tmpdir / 'src'
            output = tmpdir / 'dist'
            try:
                input_.mkdir()
            except FileExistsError:
                pass
            with (input_ / 'main.py').open('w') as f:
                f.write('#!/usr/bin/env python\n')
                f.write('def foo():\n')
                f.write('\treturn 1\n')
            result = compile_files(input_, output, target, root=tmpdir)
            assert result
            assert result.target == target
            assert result.files == 1

# Generated at 2022-06-21 17:02:27.592894
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget

    result = compile_files('test/cases/basic',
                           'test/output/basic',
                           CompilationTarget.ES5,
                           'test/cases/basic')
    assert result is not None, "Result must not be None"
    assert result.count == 1, "Must be exactly one file in input"

# Generated at 2022-06-21 17:02:37.523000
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os
    import tempfile
    import pytest

    root_dir = tempfile.TemporaryDirectory()
    package_dir = os.path.join(root_dir.name, "package")
    os.mkdir(package_dir)
    shutil.copy2(os.path.join(os.path.dirname(__file__), '_testdata/compile_files/test.py'), package_dir)
    shutil.copy2(os.path.join(os.path.dirname(__file__), '_testdata/compile_files/call.py'), package_dir)

    package_path = os.path.join(package_dir, 'test.py')
    result = compile_files(package_dir, package_dir, CompilationTarget.BASIC)


# Generated at 2022-06-21 17:02:47.385431
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    INPUT_PY = """
        import os
        import time
        def f1(n):
            return n+1
        def f2(n):
            return n+2
        f2(f1(1))
    """
    INPUT_JY = """
        import os
        import time
        def f1(n):
            return n+1
        def f2(n):
            return n+2
        f2(f1(1))
    """
    OUTPUT_PY = """
        import os
        import time
        def f1(n):
            return n+1
        def f2(n):
            return n+2
        f2(f1(1))
    """

# Generated at 2022-06-21 17:02:48.878839
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:03:22.795379
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(__file__, __file__, CompilationTarget.PYTHON)
    assert result.files == 1


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Compiles a coco files to given target')
    parser.add_argument('input', help='input directory')
    parser.add_argument('output', help='output directory')
    parser.add_argument('-t', '--target', default=CompilationTarget.PYTHON,
                        type=CompilationTarget, choices=list(CompilationTarget),
                        help='target platform')
    parser.add_argument('-i', '--indent', type=int, help='number of spaces for indentation')

# Generated at 2022-06-21 17:03:32.345032
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from lib.compiler import compile_files
    from lib.exceptions import CompilationError
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from subprocess import check_call
    import os

    def _check_compilation_result(paths):
        assert (Path(paths.output).read_text()
                == Path(paths.input).read_text())

    def test_invalid_code(input_, output):
        try:
            compile_files(input_, output, 'mjolnir')
        except CompilationError as e:
            assert e.filename.endswith('invalid_code.py')
            assert e.code == Path(e.filename).read_text()
            assert e.line == 3
            assert e.pos == 6
            return

# Generated at 2022-06-21 17:03:39.812307
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import subprocess

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    test_file = 'a.py'
    test_code = 'import asyncio\nasyncio.get_event_loop()'
    test_output = ('import trollius as asyncio\n'
                   'import trollius_dummy_module_that_should_not_exist\n'
                   'asyncio.get_event_loop()')
    test_dependencies = frozenset({'trollius_dummy_module_that_should_not_exist'})

    with (input_ / test_file).open('w') as f:
        f.write(test_code)
    compile_files(input_, output, CompilationTarget.PYTHON35)

# Generated at 2022-06-21 17:03:50.280916
# Unit test for function compile_files
def test_compile_files():
    # Single run
    target = CompilationTarget.PY_TO_PYX
    input_ = 'tests/input'
    output = 'tests/output'
    result = compile_files(input_, output, target)
    assert result.target == target
    assert result.total_files == 1
    assert isinstance(result.total_time, float)
    assert sorted(result.dependencies) == [
        '_ast', 'ast', 'astunparse', 'dataclasses', 'typed_ast', 'typing'
    ]

    # Run again, with files already compiled
    result = compile_files(input_, output, target)
    assert result.total_files == 1

    # Run with different target
    target = CompilationTarget.PY_TO_RUN

# Generated at 2022-06-21 17:04:00.315196
# Unit test for function compile_files
def test_compile_files():
    from .compile_files import compile_files
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from pathlib import Path
    from shutil import copyfile
    import tempfile
    import os

    this_dir = Path(os.path.dirname(__file__))
    src_dir = this_dir / '..' / 'src'
    fns_dir = src_dir / 'fns'
    hello_fn = fns_dir / 'hello.js'
    capture_fn = fns_dir / 'capture.js'

    with tempfile.TemporaryDirectory() as tmpdir:
        copyfile(src_dir / 'package.json', Path(tmpdir) / 'package.json')

# Generated at 2022-06-21 17:04:08.623221
# Unit test for function compile_files
def test_compile_files():
    input_ = './tests/input'
    output = './tests/output'
    target = CompilationTarget.BROWSER
    root = './tests/root'
    result = compile_files(input_, output, target, root)
    assert result.duration > 0
    assert result.target == target
    assert result.count == 2
    assert len(result.dependencies) > 0

# Generated at 2022-06-21 17:04:18.471141
# Unit test for function compile_files
def test_compile_files():
    src_dir = pathlib.Path(__file__).resolve().parent.parent.parent / 'examples' / '../src/'
    bin_dir = pathlib.Path(__file__).resolve().parent.parent.parent / 'examples' / '../bin/'
    result = compile_files(src_dir, bin_dir, CompilationTarget.JS)
    assert result.count == 34
    assert result.target == CompilationTarget.JS



# Generated at 2022-06-21 17:04:32.353655
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .exceptions import CompilationError
    from pathlib import Path

    current_dir = Path(os.path.abspath(__file__)).parent
    input_dir = current_dir/'tests/compile_files'
    output_dir = current_dir/'tests/compile_files_output'

    files = [
        'empty.py',
        'simple.py',
    ]

    shutil.rmtree(output_dir, ignore_errors=True)
    os.makedirs(output_dir)

    for file in files:
        shutil.copyfile(input_dir/file, output_dir/file)


# Generated at 2022-06-21 17:04:38.344068
# Unit test for function compile_files
def test_compile_files():
    # Test that simple file is compiled
    input_ = 'tests/data/class.py'
    output = 'tests/data/results/class.py'
    result = compile_files(input_, output, CompilationTarget.ES5)
    assert result.count == 1
    assert result.duration > 0
    assert not result.dependencies

# Generated at 2022-06-21 17:04:43.204269
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('.', 'build', CompilationTarget.RUN, root=Path(__file__).parent.as_posix())
    assert result.files_compiled == 1



# Generated at 2022-06-21 17:05:26.500376
# Unit test for function compile_files
def test_compile_files():
    """Test for compile_files()."""
    try:
        compile_files(Path(__file__).parent / 'unit_tests' / 'input',
                      Path(__file__).parent / 'unit_tests' / 'output',
                      CompilationTarget.HANDOUT)
        raise AssertionError('compile_files() did not throw exception')
    except CompilationError:
        pass
    except:
        raise AssertionError('compile_files() threw exception of wrong type')

# Generated at 2022-06-21 17:05:28.093867
# Unit test for function compile_files
def test_compile_files():
    pass

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:05:28.992410
# Unit test for function compile_files
def test_compile_files(): # TODO
    assert False

# Generated at 2022-06-21 17:05:34.499605
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget
    from .exceptions import CompilationError

    import pytest

    root = Path(__file__).parent / 'tests'
    # Ensure output directory is clean
    (root / 'output').rmdir()
    result = compile_files(root / 'input', root / 'output', CompilationTarget.CPP)
    assert result.count == 2
    assert result.target == CompilationTarget.CPP
    assert set(result.dependencies) == {
        'stdio.h', 'test-lib.h',
        'stdlib.h', 'assert.h'
    }

    with pytest.raises(CompilationError):
        compile_files(root / 'input-dummy', root / 'output', CompilationTarget.CPP)

# Generated at 2022-06-21 17:05:39.084903
# Unit test for function compile_files
def test_compile_files():
    compile_files("test/test_data/test_compile", "test/test_data/test_compile/output", CompilationTarget.ALL)
    assert True

# Generated at 2022-06-21 17:05:51.126035
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError, TransformationError
    from .files import InputOutput
    from astunparse import dump
    from .transformers import transformers
    from .types import CompilationTarget, CompilationResult
    from .utils.helpers import DEBUG_MODE, debug

    def transform(tree: ast.AST, transformer: type) -> None:
        """Applies a single transformation."""
        if not transformer.target < target:
            transformer.transform(tree)

    input_ = '.'
    output = ''
    target = CompilationTarget.PYTHON_3_6

    dependencies = set()
    start = time()
    count = 0

# Generated at 2022-06-21 17:05:51.789993
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass

# Generated at 2022-06-21 17:06:04.164141
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .files import get_input_output_paths, InputOutput
    from .exceptions import CompilationError, TransformationError

    from .transformers.lexer import Lexer
    from .transformers.custom_operator import CustomOperator
    from .transformers.version import Version
    from .transformers.function import Function
    from .transformers.classes import Classes
    from .transformers.if_else import IfElse

    with pytest.raises(CompilationError):
        compile_files('compression/test_data/with_error/',
                      'compression/test_data/result/', CompilationTarget.PY2)


# Generated at 2022-06-21 17:06:09.096681
# Unit test for function compile_files
def test_compile_files():
    compile_files('./test/testdata/simple_functions', './test/testdata/compiled_code', CompilationTarget.VANILLA)

# Generated at 2022-06-21 17:06:16.930099
# Unit test for function compile_files
def test_compile_files():
    from click.testing import CliRunner
    from .cli import cli
    from .utils.helpers import temp_path

    WITH_INPUT_OUTPUT = ['--input', 'in', '--output', 'out']

    with temp_path(WITH_INPUT_OUTPUT) as (input_, output):
        input_, output = input_ / 'in', output / 'out'
        input_.mkdir()
        output.mkdir()

        with (input_ / 'a.py').open('w') as f:
            f.write('print("Hello")')
        with (input_ / 'b.py').open('w') as f:
            f.write('print("World")')

        runner = CliRunner()