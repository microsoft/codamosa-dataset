

# Generated at 2022-06-21 16:57:58.597044
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/test_data/simple/input_files',
                         'tests/test_data/simple/output_files',
                         CompilationTarget.PYTHON27_FIXED)

test_compile_files()

# Generated at 2022-06-21 16:58:05.063183
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/simple', 'build/simple', 'Py2_Py3')
    assert result.compiled_files == 5
    assert result.target == 'Py2_Py3'
    assert result.dependencies == ['builtins', 'os', 'sys']



# Generated at 2022-06-21 16:58:10.826982
# Unit test for function compile_files
def test_compile_files():
    from .utils.testing import (assert_compile_result,
                                assert_compile_sources)

    assert_compile_sources(compile_files, 'test_data/compiler/input',
                           'test_data/compiler/output', 'test_data/compiler/root')

    # Test with root path
    assert_compile_result(
        compile_files('test_data/compiler/input/a.py',
                      'test_data/compiler/output/a.py',
                      'test_data/compiler/output/b.py',
                      'test_data/compiler/root'),
        CompilationResult(2, 0, _transform))

    # Test errors
    sources = 'test_data/compiler/input/errors'

# Generated at 2022-06-21 16:58:11.905196
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 16:58:12.468996
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 16:58:17.031854
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("tests/test.py", "tests/build", CompilationTarget.Py37) \
        == CompilationResult(2, 3.3, CompilationTarget.Py37, ['typing'])

# Generated at 2022-06-21 16:58:24.602434
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationResult
    from .utils.helpers import d_file
    from .utils.tmpdir import tmpdir

    with tmpdir() as tmp:
        tmp.create_dir('d1')
        tmp.create_dir('d2')
        d_file('file1', tmp.join('d1').join('file1.py').as_posix())
        d_file('file2', tmp.join('d2').join('file2.py').as_posix())

        res = compile_files(tmp.join('d1').as_posix(),
                            tmp.join('out').as_posix(),
                            CompilationTarget.PY3,
                            root='source')

        assert res.target == CompilationTarget.PY3


# Generated at 2022-06-21 16:58:28.435503
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_data_path
    from .testing import test_compilation_result
    input_ = get_test_data_path() / "sample"
    output = get_test_data_path() / "output"
    result = compile_files(input_, output, CompilationTarget.ALL)
    test_compilation_result(result)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:40.516652
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .tests.helpers import (get_test_path,
                                get_expected_result,
                                clean_target_folder)
    from .types import CompilationTarget

    input_, output, root = get_test_path()
    clean_target_folder(output)

    targets = [CompilationTarget.JAVASCRIPT, CompilationTarget.WEBASSEMBLY]

# Generated at 2022-06-21 16:58:45.111115
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('compile', 'output', CompilationTarget.UNITTESTS) == \
        CompilationResult(0, 0, CompilationTarget.UNITTESTS, [])