

# Generated at 2022-06-21 16:58:10.712478
# Unit test for function compile_files
def test_compile_files():
    input_ = Path('tests/data/compiling')
    output = Path('tests/data/compiled')
    target = CompilationTarget.PYTHON_350
    result = compile_files(input_, output, target)
    assert result.count == 3
    assert result.target == target
    assert sorted(result.dependencies) == ['a', 'b', 'c', 'd']
    assert Path(output, 'source.py').read_text() == 'print(\'Python!\')'
    assert Path(output, 'modules', 'a.py').read_text() == 'import b\nprint(\'Hello\')'
    assert Path(output, 'modules', 'b.py').read_text() == 'print(\'World\')'
    assert Path(output, 'modules', 'c.py').read_text()

# Generated at 2022-06-21 16:58:16.473134
# Unit test for function compile_files
def test_compile_files():
    input_ = "/Users/dmitry/dev/magi/tests/data/input"
    output = "/Users/dmitry/dev/magi/tests/data/output"
    result = compile_files(input_, output, CompilationTarget.JS, None)
    pass

# Generated at 2022-06-21 16:58:27.172357
# Unit test for function compile_files
def test_compile_files():
    from .files import DEFAULT_INPUT_NAME, DEFAULT_OUTPUT_NAME
    from . import compile_files
    import pathlib
    print('===== test_compile_files =====')
    path = pathlib.Path(__file__).parent
    input_path = path / DEFAULT_INPUT_NAME
    output_path = path / DEFAULT_OUTPUT_NAME
    res = compile_files(input_path, output_path, CompilationTarget.C_CPP)
    print(res)
    assert res.count == 2
    assert res.target == CompilationTarget.C_CPP
    assert len(res.dependencies) == 0, 'Should not have dependencies'

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:32.393207
# Unit test for function compile_files
def test_compile_files():
    # type: () -> None
    if __name__ == '__main__':
        import os
        import sys
        import shutil

        sys.path.insert(0, os.path.abspath(
            os.path.join(os.path.dirname(__file__), '..')))
        from tests.test_compiler import compare_folder, compare_file
        from tests.helpers import remove_directory, join_paths
        from compiler.types import CompilationTarget

        SOURCE_FOLDER = '../data/compiler'
        OUTPUT_FOLDER = '../data/project'
        CORRECT_FOLDER = '../data/compiler_correct'

        # Remove old data
        remove_directory(OUTPUT_FOLDER)

        # Compile all files

# Generated at 2022-06-21 16:58:42.461911
# Unit test for function compile_files
def test_compile_files():
    from .files import make_files
    from .utils import get_tmp_dir
    from .exceptions import CompilationError
    from .transformers import add_imports

    path = get_tmp_dir()

    make_files(path, [('file1.py', ['import numpy', 'import pandas', 'a = 5']),
                      ('file2.py', ['from foo import bar', 'b = 6'])])

    try:
        compile_files(path / 'file1.py', path / 'output', add_imports)
        assert False  # pragma: nocover
    except CompilationError:
        pass

    result = compile_files(path / '*.py', path / 'output', add_imports)
    assert result.count == 2
    assert result.target == add_imports
    assert result

# Generated at 2022-06-21 16:58:46.600743
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/test_data/compile/input', 'test/test_data/compile/output', CompilationTarget.PYTHON)


# Generated at 2022-06-21 16:58:49.869213
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/data/transformer/input/', 'tests/data/transformer/output/', CompilationTarget.C)



# Generated at 2022-06-21 16:58:53.364353
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/fixtures/compile/input',
                           './tests/fixtures/compile/output',
                           CompilationTarget.PYTHON_36)

    assert result.processed == 5
    assert result.target == CompilationTarget.PYTHON_36
    assert result.dependencies == ['aiohttp', 'pyparsing', 'test_test_test']

# Generated at 2022-06-21 16:58:59.628138
# Unit test for function compile_files
def test_compile_files():
    """
    Compilation tests
    """
    test_input = Path("tests/data/input/")
    test_output = Path("tests/data/output/")
    test_root = Path("tests/data/root/")

    assert compile_files(str(test_input),
                         str(test_output), CompilationTarget.cc).count == 2

    assert compile_files(str(test_input),
                         str(test_output), CompilationTarget.py).count == 2

    assert compile_files(str(test_input),
                         str(test_output), CompilationTarget.py,
                         str(test_root)).count == 2

# Generated at 2022-06-21 16:59:03.358387
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile
    import os
    import importlib
    import sys


# Generated at 2022-06-21 16:59:14.164825
# Unit test for function compile_files
def test_compile_files():
    from .test.test_resources import EXAMPLE_PATH, remove_path
    from .files import create_fake_files

    create_fake_files()

    from .test.test_resources import OUTPUT_PATH
    remove_path(OUTPUT_PATH)

    result = compile_files(EXAMPLE_PATH, OUTPUT_PATH,
                           CompilationTarget.PY2)

    assert result.target == CompilationTarget.PY2
    assert result.count == 1
    assert result.time >= 0
    assert result.dependencies == [
        'asyncio'
    ]

# Generated at 2022-06-21 16:59:21.717435
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .utils.helpers import cd

    with cd('..'):
        with cd('examples'):
            with cd('test_data'):
                if not os.path.isdir('compiled'):
                    os.mkdir('compiled')
                assert compile_files('.', 'compiled', CompilationTarget.PYTHON36) == \
                    CompilationResult(2, 0.0, CompilationTarget.PYTHON36, [])
                assert compile_files('.', 'compiled', CompilationTarget.PYTHON35) == \
                    CompilationResult(2, 0.0, CompilationTarget.PYTHON35, [])

# Generated at 2022-06-21 16:59:25.988620
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/samples/test_source2', 'tests/samples/test_target2', CompilationTarget.PYTHON)

# Generated at 2022-06-21 16:59:32.995202
# Unit test for function compile_files
def test_compile_files():
    src = Path(__file__).parent / '..' / 'src'
    dest = Path(__file__).parent.parent / 'dist' / 'src'
    result = compile_files(src.as_posix(), dest.as_posix(),
                           CompilationTarget.BROWSER)
    assert result.duration < 0.1
    assert result.count > 100
    assert result.target == CompilationTarget.BROWSER
    assert len(result.dependencies) > 10
    assert result.dependencies[0] == 'cast/http.py'

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:59:43.002202
# Unit test for function compile_files
def test_compile_files():
    class CompilationResultStub:
        def __init__(self, count, elapsed, target, dependencies):
            self.count = count
            self.elapsed = elapsed
            self.target = target
            self.dependencies = dependencies
    from mypy.types import TypedDict
    result = TypedDict('result', {'count': int, 'elapsed': int, 'target': int, 'dependencies': list})
    r = compile_files('test.js', 'test.j2', 3) # type: result
    assert isinstance(r, CompilationResultStub)
    assert r.count > 0
    assert r.elapsed > 0
    assert r.target == 3
    assert isinstance(r.dependencies, list)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:59:49.622396
# Unit test for function compile_files
def test_compile_files():
    print(compile_files('test/input2', 'test/output2', CompilationTarget.PYTHON))
    print(compile_files('test/input', 'test/output', CompilationTarget.PYTHON))

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:00:01.953270
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    #import time

    abs_dir = Path(__file__).parent.resolve()
    input_dir = abs_dir / '..' / 'test' / 'input'
    output_dir = abs_dir / '..' / 'test' / 'output'

    # Start time
    #t0 = time()
    result = compile_files(input_dir, output_dir, CompilationTarget.EXECUTABLE)
    #print(time() - t0)

    assert result.count == 2
    assert result.dependencies == ['math', 'sys']

    pytest.fail('Waiting for the implementation')

# Generated at 2022-06-21 17:00:05.452955
# Unit test for function compile_files
def test_compile_files():
    compile_files(
        input_='./input/',
        output='./output/',
        target=CompilationTarget.remote)


# Generated at 2022-06-21 17:00:08.340486
# Unit test for function compile_files
def test_compile_files():
    import tempfile

    with tempfile.TemporaryDirectory() as d:
        compile_files(d, d, CompilationTarget.FRONTEND)

# Generated at 2022-06-21 17:00:16.202402
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import subprocess
    from pathlib import Path
    from pytest import fixture

    @fixture()
    def tmpdir(tmpdir):
        return Path(tmpdir)

    def py2js(script, tmpdir):
        cwd = os.path.dirname(os.path.abspath(__file__))
        inputs = os.path.join(cwd, 'test_cases', script, 'inputs')
        outputs = os.path.join(tmpdir, script, 'outputs')

        subprocess.check_call([sys.executable, '-m', 'py2js', inputs, outputs])
        return outputs

    def python(infile, outfile):
        subprocess.check_call([sys.executable, infile, '>', outfile])
        return outfile



# Generated at 2022-06-21 17:06:24.301208
# Unit test for function compile_files
def test_compile_files():
    # TODO: Use temporary directories and files
    raise NotImplementedError

# Generated at 2022-06-21 17:06:35.805159
# Unit test for function compile_files
def test_compile_files():
    def compile_file_test(path):
        with open(path) as f:
            code = f.read()
        transformed, dependencies = _transform(path, code, CompilationTarget.PYTHON)
        return transformed, dependencies

    def input_output(prefix, suffix):
        return os.path.join(prefix, f'{suffix}.tex'), os.path.join(prefix, f'{suffix}.py')

    from . import tests
    def test(input_file_name, target=CompilationTarget.PYTHON, dependencies=None):
        input_file_name, output_file_name = input_output(tests.INPUTS_DIR, input_file_name)
        output_file_name = input_output(tests.OUTPUTS_DIR, input_file_name)
        transformed, generated_

# Generated at 2022-06-21 17:06:47.257223
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import subprocess
    import sys
    from .types import CompilationTarget
    from .utils.helpers import mkdir_p, rmdir_p

    input_dir = 'tests/compiler/input'
    output_dir = 'tests/compiler/output'
    mkdir_p(input_dir)
    rmdir_p(output_dir)

    compile_files(input_dir, output_dir, CompilationTarget.NODE)
    assert 0 == subprocess.call([sys.executable, output_dir + os.sep + 'main.py'], stdout=subprocess.DEVNULL)

    assert 0 == subprocess.call(['python', 'tests/compiler/check_output.py', input_dir, output_dir], stdout=subprocess.DEVNULL)



# Generated at 2022-06-21 17:06:57.813748
# Unit test for function compile_files
def test_compile_files():
    from .apis import build_api
    from .utils.helpers import get_test_dir
    import subprocess

    test_dir = get_test_dir()
    build_api('test.json', test_dir, 'test', 'test.py')
    results = compile_files(test_dir / 'input', test_dir / 'output',
                            CompilationTarget.BOTH)

    output_dir = get_test_dir() / 'output'
    assert (subprocess.call(['diff', '-r', output_dir,
                             test_dir / 'test_output']) == 0)
    assert (results.compiled_files == 5)
    assert (results.compilation_time >= 0)
    assert (sorted(results.dependencies) == ['test'])

# Generated at 2022-06-21 17:07:06.549030
# Unit test for function compile_files
def test_compile_files():
    import sys
    import re
    result = compile_files(sys.argv[1],sys.argv[2],CompilationTarget.PYTHON)
    assert len(result.dependencies)==0
    with open(sys.argv[2]) as f:
        s = f.read()
    s = re.sub("#.+\n","\n",s)
    assert s == 'import sys\nprint(sys.argv[1])\n'

# Generated at 2022-06-21 17:07:08.853814
# Unit test for function compile_files
def test_compile_files():
    paths = get_input_output_paths('test', 'out')
    for p in paths:
        compile_files(p.input, p.output, 'js')

# Generated at 2022-06-21 17:07:09.260588
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:07:15.391534
# Unit test for function compile_files
def test_compile_files():
    from .files import get_dependency_order
    from os.path import join, isfile
    from typing import List

    class CompilationResult:
        def __init__(self,
                     files_processed: int,
                     compilation_time: float,
                     target: CompilationTarget,
                     dependencies: List[str]):
            self.files_processed = files_processed
            self.compilation_time = compilation_time
            self.target = target
            self.dependencies = dependencies

    def get_data(input_: str, output: str, target: CompilationTarget,
                 root: Optional[str] = None):
        paths = get_input_output_paths(input_, output, root)
        dependencies = set()
        files_processed = 0
        compilation_time = 0

# Generated at 2022-06-21 17:07:16.981702
# Unit test for function compile_files

# Generated at 2022-06-21 17:07:27.112400
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from time import time
    def timeit(f):
        start = time()
        ret = f()
        return (ret, time() - start)
