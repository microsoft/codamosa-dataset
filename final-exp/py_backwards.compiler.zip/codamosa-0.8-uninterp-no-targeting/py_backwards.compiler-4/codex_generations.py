

# Generated at 2022-06-21 16:58:05.927425
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(input_='./tests/input/',
                           output='./tests/output/',
                           target=CompilationTarget.CLIENT)
    print(result)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:12.694453
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .transformers import ImportReplace, IfCheck

    # Test case 1
    # Content of test.py:
    # import numpy as np
    # x = np.array([])
    # if True:
    #     x = np.array([1, 2, 3])
    # print(x)
    #
    # Expected:
    # import _numpy as np
    # x = np.array([])
    # if True:
    #     x = np.array([1, 2, 3])
    # print(x)
    #
    # import numpy as _numpy

    current_dir = Path().resolve()
    input_ = current_dir / 'test.py'
    output = current_dir / 'test-output.py'

# Generated at 2022-06-21 16:58:22.044283
# Unit test for function compile_files
def test_compile_files():
    # Checking that no exception is raised when everything is ok
    compile_files('test/input', 'test/output', CompilationTarget.es3)
    compile_files('test/input', 'test/output', CompilationTarget.es5)
    compile_files('test/input', 'test/output', CompilationTarget.es6)

    # Checking that exception will be raised if input directory doesn't exist
    try:
        compile_files('test/input__', 'test/output', CompilationTarget.es5)
        assert False
    except:
        assert True

    # Checking that exception will be raised if output directory doesn't exist
    try:
        compile_files('test/input', 'test/output__', CompilationTarget.es5)
        assert False
    except:
        assert True


# Generated at 2022-06-21 16:58:32.376015
# Unit test for function compile_files
def test_compile_files():
    import re
    import unittest
    import tempfile
    
    class CompileFileTest(unittest.TestCase):
        def test_comments(self):
            with tempfile.TemporaryDirectory() as temp:
                compiled = compile_files('test/fixtures/comments',
                                         temp, CompilationTarget.PYTHON)
                with open(temp + '/file.py') as f:
                    lines = f.readlines()
                    self.assertEqual(lines[0], '# Not a comment\n')
                    self.assertEqual(lines[1], '# Not a comment\n')
                    self.assertEqual(lines[2], '# Not a comment\n')
                    self.assertEqual(lines[3], '# Not a comment\n')

# Generated at 2022-06-21 16:58:35.637547
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/test_files/input', 'tests/test_files/output', CompilationTarget.TEST)
    assert 1 == 1

# Generated at 2022-06-21 16:58:43.435313
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    try:
        shutil.rmtree('test_compile_files')
    except:
        pass
    compile_files('test/test_data', 'test_compile_files',
                  CompilationTarget.PYTHON)
    assert os.path.exists('test_compile_files/test/test_data/test.py')
    assert os.path.exists('test_compile_files/test/test_data/__init__.py')
    assert os.path.exists('test_compile_files/test')
    assert os.path.exists('test_compile_files/test/__init__.py')

    try:
        shutil.rmtree('test_compile_files')
    except:
        pass

# Generated at 2022-06-21 16:58:49.757714
# Unit test for function compile_files
def test_compile_files():
    import numpy
    from .utils.helpers import get_module_path

    target = CompilationTarget.JYTHON
    input_ = get_module_path('tests/data')
    output = input_.parent.joinpath('output')
    root = get_module_path()

    compile_files(input_, output, target, root)
    assert output.joinpath('package', 'module1.py').exists()
    assert output.joinpath('package', 'module2.py').exists()
    assert output.joinpath('package', '__init__.py').exists()

    numpy.add_newdocs('package', numpy.lib.NumpyDocString)
    numpy.add_newdocs('package.module1', numpy.lib.NumpyDocString)

# Generated at 2022-06-21 16:58:54.775638
# Unit test for function compile_files
def test_compile_files():
    # This file is supposed to be tested
    assert compile_files('test', 'tmp/test-tmp', CompilationTarget.PYTHON, 'tmp')
    # Let's read the compiled file
    output_file = None
    with open('tmp/test-tmp/test/test_compile.py') as f:
        output_file = f.read()
    # So we have the output, let's compare it with the expected one
    with open('test/test_compile.py.expected') as f:
        assert output_file == f.read()
    # Remove the temp directory
    import shutil
    shutil.rmtree('tmp/test-tmp')

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-21 16:59:04.753667
# Unit test for function compile_files
def test_compile_files():
    from .utils.temporary_directory import TemporaryDirectory
    import json
    import os.path
    import re

    def check(path):
        with open(path) as f:
            tree = json.load(f)
        for key, value in tree.items():
            assert("class" not in key)
            if isinstance(value, list):
                expected = re.split("(\W+|_)", value[0])
                actual = re.split("(\W+|_)", value[1])
                assert(expected == actual)
    with TemporaryDirectory() as input_, TemporaryDirectory() as output:
        os.mkdir(os.path.join(input_, "target1"))

# Generated at 2022-06-21 16:59:12.875421
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('input/unit_test/test_compile_files',
                           'output/unit_test/test_compile_files/',
                           CompilationTarget.LIBRARY)
    assert result.count == 1
    assert result.target == CompilationTarget.LIBRARY
    assert result.dependencies == []

    with open('output/unit_test/test_compile_files/simple.py') as f:
        code = f.read()
    assert code == 'def func():\n    a:bool=True\n'