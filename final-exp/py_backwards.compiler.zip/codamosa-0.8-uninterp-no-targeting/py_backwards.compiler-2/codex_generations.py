

# Generated at 2022-06-21 16:58:10.569650
# Unit test for function compile_files
def test_compile_files():
    from .files import InputOutput
    from pathlib import Path
    from ast import parse
    import pytest
    import shutil

    temppath = Path("/tmp")

    input_ = "test/demo"
    output = "test/demo.output"
    target = CompilationTarget.NATIVE

    shutil.rmtree(output)
    compile_files(input_, output, target)

    def get_ast(path : Path) -> ast.AST:
        with open(path) as f:
            return parse(f.read())

    # test that files have been copied
    paths = list(get_input_output_paths(input_, output))
    assert len(paths) == 1
    assert paths[0].input.stat().st_mtime <= paths[0].output.stat().st_m

# Generated at 2022-06-21 16:58:14.783408
# Unit test for function compile_files
def test_compile_files():
    compile_files('test/testdata', 'test/testout', CompilationTarget.ES6)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:22.865913
# Unit test for function compile_files
def test_compile_files():
    print("\nFunc test compile_files()")
    input_dir = Path("test_files/test_compile_files")
    output_dir = Path("/tmp/test_compile_files_out")
    try:
        compile_files(input_dir, output_dir, CompilationTarget.SQL)
        assert Path("/tmp/test_compile_files_out/test.sql").is_file()
        with Path("/tmp/test_compile_files_out/test.sql").open() as f:
            assert f.read() == "SELECT 42;"
    finally:
        shutil.rmtree(output_dir)



# Generated at 2022-06-21 16:58:29.020083
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    # Create temporary folders to store files
    input_folder = tempfile.mkdtemp()
    output_folder = tempfile.mkdtemp()

    # Create a test file
    file_path = input_folder + '/test.py'

# Generated at 2022-06-21 16:58:41.242900
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    if os.path.exists('./test-output'):
        shutil.rmtree('./test-output')

    result = compile_files('./test-input', './test-output',
                           CompilationTarget.PYTHON)

    print('Compiled {} files in {:.3f} seconds'.format(result.count,
                                                       result.time))
    print('Compiled for {}'.format(result.target.name))
    print('List of dependencies')
    for dep in result.dependencies:
        print('- {}'.format(dep))


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()

# Generated at 2022-06-21 16:58:52.687341
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from tests.data.compile_files import (data, target,
                                          input_folder, output_folder,
                                          root_folder)

    for file_ in data:
        folder_ = file_ if file_ == 'expected_output' else input_folder

        with (Path(__file__).parent
              .joinpath('data')
              .joinpath('compile_files')
              .joinpath(folder_)
              .joinpath(file_ + '.py')
              .open()) as f:
            data[file_] = f.read()

    input_ = Path(__file__).parent \
        .joinpath('data') \
        .joinpath('compile_files') \
        .joinpath(input_folder)


# Generated at 2022-06-21 16:59:04.094606
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile

    from .types import Target
    from .exceptions import CompilationError

    with tempfile.TemporaryDirectory() as d:
        # create input directory with files
        i = os.path.join(d, 'in')
        os.mkdir(i)

        # create output directory
        o = os.path.join(d, 'out')
        os.mkdir(o)

        # create empty file
        e = os.path.join(i, 'empty.py')
        open(e, 'w').close()

        # create broken file
        b = os.path.join(i, 'broken.py')
        f = open(b, 'w')
        f.write('Hello world\n')
        f.close()

        # create file with syntax error

# Generated at 2022-06-21 16:59:14.721169
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os

    # Root test
    d_root = tempfile.mkdtemp()
    d_input_root = os.path.join(d_root, 'input')
    d_output_root = os.path.join(d_root, 'output')
    os.mkdir(d_input_root)
    os.mkdir(d_output_root)
    with open(os.path.join(d_input_root, 'f.py'), 'w') as f:
        f.write('print(42)')
    compile_files(d_input_root, d_output_root, CompilationTarget.PYTHON_BYTE, d_root)

# Generated at 2022-06-21 16:59:20.222262
# Unit test for function compile_files
def test_compile_files():
    compile_files("../res/input", "../res/output",
                  CompilationTarget.UNIT_TESTS)


if __name__ == '__main__':
    import sys
    if (len(sys.argv) != 3):
        print("Usage: compile_files.py <root_input_dir> <output_dir>")
        sys.exit(1)
    compile_files(sys.argv[1], sys.argv[2], CompilationTarget.UNIT_TESTS, sys.argv[1])

# Generated at 2022-06-21 16:59:32.214957
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_data
    from .transformers import set_transform_debug
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from pathlib import Path
    from tempfile import TemporaryDirectory

    set_transform_debug(True)

    with TemporaryDirectory() as tempdir:
        tempdir = Path(tempdir)
        result = compile_files(get_test_data('01-simple/01-error.py'),
                               tempdir, CompilationTarget.DEV,
                               root=get_test_data())
        assert result.count == 1
        assert result.target == CompilationTarget.DEV
        assert result.dependencies == [
            'typing', 'operator', 'sys', 'functools', 'builtins']

# Generated at 2022-06-21 16:59:46.217911
# Unit test for function compile_files
def test_compile_files():
    from os import path as p
    from pytest import raises
    from .files import InputPath, OutputPath

    def _assert_compile_files(input: str, output: str, expected_result: CompilationResult):
        result = compile_files(
            p.join(p.dirname(__file__), 'test_data', 'input', input),
            p.join(p.dirname(__file__), 'test_data', 'output', output),
            CompilationTarget.ALL
        )
        assert result == expected_result

    _assert_compile_files('single_file.py', 'single_file.js', CompilationResult(
        1, 0.0, CompilationTarget.ALL, ['single_file.js']))

# Generated at 2022-06-21 16:59:50.338074
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(input_='static/', output='tests/compiled/', root='tests/', target=CompilationTarget.JAVASCRIPT)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:00:02.749187
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./tests', './tests/build', CompilationTarget.TEST) == CompilationResult(1, 0.0, CompilationTarget.TEST, [])
    assert compile_files('./tests', './tests/build', CompilationTarget.JIT) == CompilationResult(1, 0.0, CompilationTarget.JIT, [])
    assert compile_files('./tests', './tests/build', CompilationTarget.WEB) == CompilationResult(1, 0.0, CompilationTarget.WEB, [])
    assert compile_files('./tests', './tests/build', CompilationTarget.WASM) == CompilationResult(1, 0.0, CompilationTarget.WASM, [])

test_compile_files()

# Generated at 2022-06-21 17:00:11.969867
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from .files import copy_dir
    from .types import CompilationTarget

    with TemporaryDirectory() as td:
        copy_dir('tests/scenarios/minimal_source', td)
        result = compile_files(input_='{}/source'.format(td),
                               output='{}/output'.format(td),
                               target=CompilationTarget.JAVASCRIPT)

        assert result.count == 2
        assert result.target == CompilationTarget.JAVASCRIPT
        assert result.duration > 0

        scenario = 'tests/scenarios/minimal'
        assert open('{}/output/x.js'.format(td)).read() == open('{}/expected/output/x.js'.format(scenario), encoding='utf-8').read()
        assert open

# Generated at 2022-06-21 17:00:19.422039
# Unit test for function compile_files
def test_compile_files():
    source = """
        from typing import Iterable
        import os

        def greet(names: Iterable[str]) -> str:
            return ', '.join(names)
    """
    expected = """
        import os

        def greet(names):
            return ', '.join(names)
    """
    assert compile_files('./test', './test', 'dev') == \
        CompilationResult(1, 0, 'dev', [])


# TODO: update unit tests accordingly

# Generated at 2022-06-21 17:00:31.179904
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    with open(input_ + '/file1.lua', 'w') as f:
        f.write('print(42)')
    with open(input_ + '/dir1/file2.lua', 'w') as f:
        f.write('print(24)')
    result = compile_files(input_, output, CompilationTarget.py)
    assert result == CompilationResult(
        2, 0, CompilationTarget.py, [])
    assert open(output + '/file1.py').read() == 'print(42)\n'
    assert open(output + '/dir1/file2.py').read() == 'print(24)\n'

# Generated at 2022-06-21 17:00:41.903055
# Unit test for function compile_files
def test_compile_files():
    def remove_dir_recursively(dir: str) -> None:
        import shutil
        import os
        for root, dirs, files in os.walk(dir, topdown=False):
            for name in files:
                os.remove(os.path.join(root, name))
            for name in dirs:
                os.rmdir(os.path.join(root, name))

    try:
        compile_files('tests/data/src', 'tests/data/dst', 'full')
        assert(True)
    except CompilationError:
        assert(False)
    except:
        assert(False)

    remove_dir_recursively('tests/data/dst')

# Generated at 2022-06-21 17:00:48.303429
# Unit test for function compile_files
def test_compile_files():
    output = '/tmp/compiled'
    input_ = '/tmp/compiled/tmp.py'
    input_content = "print(1)"
    root = '/tmp'
    target = 'python'

    # Setting up the test
    with open(input_, 'w') as f:
        f.write(input_content)

    # Cleaning up
    try:
        compile_files(input_, output, target, root)
        with open(output) as f:
            assert f.read() == "print(1)"
    finally:
        remove(input_)
        rmtree(output)


if __name__ == "__main__":
    print(compile_files(*sys.argv[1:]))

# Generated at 2022-06-21 17:00:52.461588
# Unit test for function compile_files
def test_compile_files():
    compile_files('/Users/amitjain/PycharmProjects/ast_rewrite/tests/files/input',
                  '/Users/amitjain/PycharmProjects/ast_rewrite/tests/files/output2',
                  CompilationTarget.PYTHON3_7,
                  None)

# Generated at 2022-06-21 17:00:52.981693
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:01:02.379516
# Unit test for function compile_files
def test_compile_files():
    """For testing if compile_files is working properly."""
    import pytest
    from pathlib import Path
    from .utilities.compile_files_utilities import Helper
    import os

    # The path to the folder with this script
    file_path = os.path.realpath(__file__)
    file_path = Path(file_path)
    file_path = file_path.parent
    helper = Helper(file_path, "file_to_compile.py")
    compile_files(helper.input_file_path, helper.output_file_path, CompilationTarget.PYTHON_NO_ARGUMENT)
    with open(helper.output_file_path, 'r') as file:
        file_content = file.read()
    assert helper.output_file_content == file

# Generated at 2022-06-21 17:01:05.545235
# Unit test for function compile_files
def test_compile_files():
    from .experiment import load_experements
    for experiment in load_experements():
        if experiment.selected:
            compile_files(experiment.get_input_source(),
                          experiment.get_output_source(),
                          experiment.target)

# Generated at 2022-06-21 17:01:16.868134
# Unit test for function compile_files
def test_compile_files():
    from .files import get_test_files
    from .types import SimpleCompilationResult
    from . import __version__

    compile_files(
        get_test_files('nuke_compile_test_in'),
        get_test_files('nuke_compile_test_out'),
        CompilationTarget.NUKE_PYTHON)


# Generated at 2022-06-21 17:01:21.896619
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    result = compile_files(Path(__file__).parent, 'test_output', CompilationTarget.PYTHON3)
    code = open('test_output/tests/test_compile.py').read()

# Generated at 2022-06-21 17:01:30.527940
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from .utils import test_dir
    from .exceptions import CompilationError


# Generated at 2022-06-21 17:01:39.797789
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import subprocess
    import shutil
    project_dir = os.path.dirname(os.path.realpath(__file__))
    os.chdir(project_dir)
    input_dir = os.path.join(project_dir, '../input')
    output_dir = os.path.join(project_dir, '../output')
    report_dir = os.path.join(project_dir, '../report')
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    if not os.path.exists(report_dir):
        os.mkdir(report_dir)
    test_file = os.path.join(input_dir, 'test.py')
    print('Uncompiled:')

# Generated at 2022-06-21 17:01:45.305315
# Unit test for function compile_files
def test_compile_files():
    print(compile_files('python-examples/', 'python-examples/compiled/', CompilationTarget.JS))

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:01:50.564191
# Unit test for function compile_files
def test_compile_files():
    import argparse
    parser = argparse.ArgumentParser(description='Compiles a single file.')
    parser.add_argument('input_', help='input file path')
    parser.add_argument('output', help='output file path')
    parser.add_argument('--target', type=str, choices=['2', '3'],
                        help='target Python version')
    args = parser.parse_args()
    compile_files(args.input_, args.output,
                  CompilationTarget.python2 if args.target == '2'
                  else CompilationTarget.python3)

# Generated at 2022-06-21 17:01:59.391665
# Unit test for function compile_files
def test_compile_files():
    assert len(compile_files('tests/data/input', 'tests/data/output', CompilationTarget.js_browser).dependencies) == 8
    assert len(compile_files('tests/data/input', 'tests/data/output', CompilationTarget.py_browser).dependencies) == 8
    assert len(compile_files('tests/data/input', 'tests/data/output', CompilationTarget.py_node).dependencies) == 8
    assert len(compile_files('tests/data/input', 'tests/data/output', CompilationTarget.py_source).dependencies) == 16

# Generated at 2022-06-21 17:02:08.138988
# Unit test for function compile_files
def test_compile_files():
    import os.path
    import tempfile

    def fix_path(path):
        return os.path.normpath(os.path.expanduser(path))

    # Create a temp folder, then create some test scripts under it
    dir = tempfile.mkdtemp()

    example_file_types = ['.py', '.js', '.pyi']
    example_files = [row[0] + row[1] for row in zip(['a', 'b', 'c'],
                                                    example_file_types)]
    for f in example_files:
        with open(fix_path(os.path.join(dir, f)), 'w') as file:
            if f.endswith('.py'):
                file.write('print("Hello World!")')