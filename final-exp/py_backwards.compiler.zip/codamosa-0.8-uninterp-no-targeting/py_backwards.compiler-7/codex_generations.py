

# Generated at 2022-06-21 16:58:06.367358
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .test_files.input import file
    input_ = Path(file).resolve().as_posix()
    output = Path('./test_files/test_output/test.html').resolve().as_posix()
    compile_files(input_, output, CompilationTarget.WEBBROWSER)


# Generated at 2022-06-21 16:58:11.420514
# Unit test for function compile_files
def test_compile_files():
    from . import main
    from .types import CompilationTarget
    result = main.compile_files('tests/examples/input/',
                                'tests/examples/output/',
                                CompilationTarget.PLAIN_PYTHON)
    assert result.count == 19
    assert result.time_spent > 0
    assert result.target == CompilationTarget.PLAIN_PYTHON

# Generated at 2022-06-21 16:58:18.649731
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/fixtures/input'
    output = 'tests/fixtures/output'
    target = CompilationTarget.ES5
    result = compile_files(input_, output, target)
    assert result.compiled == 6
    assert len(result.dependencies) == 3


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:25.873576
# Unit test for function compile_files
def test_compile_files():
    import os
    from .testsuite import load_test_case
    from .utils.helpers import is_ast_equal

    test_case = load_test_case('tests/samples/test_case.py')
    compile_files('input', 'output', test_case.target, test_case.root)
    compiled_paths = list(get_input_output_paths('output', 'output', test_case.root))
    for path in test_case.expected_outputs:
        path = path.relative_to(test_case.expected_output_dir)
        paths = [x for x in compiled_paths if x.output.name == path.name]
        assert len(paths) == 1
        compiled_content = paths[0].output.read_text()

# Generated at 2022-06-21 16:58:32.949592
# Unit test for function compile_files
def test_compile_files():
    def assert_targets(target: CompilationTarget, paths: List[InputOutput]):
        print('-' * 40)
        print(target)
        print('-' * 40)
        result = compile_files('Tests/InputFiles', 'Tests/OutputFiles', target)
        print(result)
        count = 0
        for paths in get_input_output_paths('Tests/OutputFiles'):
            with open(paths.output) as f:
                print(f.read())
                count += 1
        print('-' * 40)
        print()
        assert count == result.files

    for target in CompilationTarget:
        assert_targets(target, [])

# Generated at 2022-06-21 16:58:41.413296
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os

    tempdir = tempfile.TemporaryDirectory()

    os.makedirs(os.path.join(tempdir.name, 'input', 'dir1', 'dir2'))
    with open(os.path.join(tempdir.name, 'input', 'file.py'), 'w') as f:
        f.write('def a():\n\tpass\n')
    with open(os.path.join(tempdir.name, 'input', 'dir1', 'file1.py'), 'w') as f:
        f.write('def b():\n\tpass\n')

# Generated at 2022-06-21 16:58:47.022467
# Unit test for function compile_files
def test_compile_files():
    path = Path(__file__).parent

    print(compile_files(
        str(path / 'data' / 'pythran_simple.pyi'),
        str(path / 'data' / 'out'),
        CompilationTarget.HASKELL
    ))

    print(compile_files(
        str(path / 'data' / 'pythran_simple.pyi'),
        str(path / 'data' / 'out'),
        CompilationTarget.PYTHON
    ))


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 16:58:49.978218
# Unit test for function compile_files
def test_compile_files():
    compile_files('./tests/inputs/basic.py', './tests/outputs/', CompilationTarget.PYTHON)

# Generated at 2022-06-21 16:58:54.771895
# Unit test for function compile_files
def test_compile_files():
    #import io as io
    #from pathlib import Path
    from . import run_tests
    run_tests(['tests/gen/'], ['/output/'], CompilationTarget.HOST)

# Generated at 2022-06-21 16:59:03.127737
# Unit test for function compile_files
def test_compile_files():
    # compiles test under directory `tests/compile/`
    # and reports the running time and number of files compiled
    with open(os.getcwd() + '/tests/compile/test.py') as f:
        print(unparse(ast.parse(f.read())))
    r = compile_files(os.getcwd() + '/tests/compile/input',
                      os.getcwd() + '/tests/compile/output',
                      CompilationTarget.CPYTHON)
    assert r.count == 4 and r.time > 0

# Generated at 2022-06-21 16:59:09.330281
# Unit test for function compile_files

# Generated at 2022-06-21 16:59:15.574830
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from os.path import dirname, join
    from .utils.helpers import get_test_path
    target = 'python'
    root = join(dirname(dirname(dirname(get_test_path()))), 'test')
    input_ = join(root, 'input')
    output = join(root, 'output')
    result = compile_files(input_, output, target, root)
    assert result.count == 2
    assert result.target == target
    assert result.dependencies == []
    assert result.time > 0

# Generated at 2022-06-21 16:59:19.162053
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget

    result = compile_files(
        input_='tests/data/collections.py',
        output='/tmp/collections_pyj/collections.js',
        target=CompilationTarget.ALL)
    assert result.files == 1
    assert result.target == CompilationTarget.ALL
    assert Path('/tmp/collections_pyj/collections.js').is_file()

# Generated at 2022-06-21 16:59:32.161340
# Unit test for function compile_files
def test_compile_files():
    from tempfile import mkdtemp
    import shutil

    from .examples.simple import main

    def write_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    tmp_dir = mkdtemp()

# Generated at 2022-06-21 16:59:40.753010
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationResult
    from .utils.helpers import get_input_output_paths_mock
    with get_input_output_paths_mock() as get_input_output_paths:
        get_input_output_paths.return_value = ['path']
        res = compile_files('input', 'output', CompilationTarget.python2, 'root')
        assert res == CompilationResult(1, 0.0, CompilationTarget.python2, [])

# Generated at 2022-06-21 16:59:45.187104
# Unit test for function compile_files
def test_compile_files():
    with tempfile.TemporaryDirectory() as output:
        assert compile_files(input_='./tests/data', output=output, target=CompilationTarget.DEBUG).count == 2



# Generated at 2022-06-21 16:59:48.923579
# Unit test for function compile_files
def test_compile_files():
    from .utils.testing import get_test_folder
    from pathlib import Path

    input_folder = Path(__file__).parent.joinpath('tests', 'wasm')
    output_folder = get_test_folder('wasm_compiled', 'output')
    target = CompilationTarget.WASM

    compile_files(input_folder, output_folder, target, input_folder)


# Generated at 2022-06-21 16:59:51.645053
# Unit test for function compile_files
def test_compile_files():
    from .files import TEST_INPUT_D, TEST_OUTPUT_D

    result = compile_files(TEST_INPUT_D, TEST_OUTPUT_D,
                           CompilationTarget.PYTHON)
    assert result.file_count == 3
    assert result.dependencies == ['os', 'sys']

# Generated at 2022-06-21 16:59:56.292221
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import unittest
    import tempfile
    import io
    import sys

    def get_tree(code):
        return ast.parse(code)

    target = CompilationTarget.test
    test_dir = tempfile.mkdtemp()
    test_input = os.path.join(test_dir, 'input')
    test_output = os.path.join(test_dir, 'output')
    os.mkdir(test_input)
    os.mkdir(test_output)


# Generated at 2022-06-21 17:00:01.299950
# Unit test for function compile_files
def test_compile_files():
    input_ = Path('test/input/basic')
    output = Path('test/output/basic')
    target = CompilationTarget.JAVASCRIPT
    result = compile_files(str(input_), str(output), target)
    assert result.file_count == 3
    assert target == result.target

# Generated at 2022-06-21 17:00:12.749557
# Unit test for function compile_files
def test_compile_files():
    import json
    import os.path

    # path of directory to be compiled
    test_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                            '../test/data/example')
    # path of directory where the compilation result is
    result_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                              '../test/result')

    # compile the directory
    result = compile_files(test_dir, result_dir, CompilationTarget.JS)

    # check the number of files compiled
    assert result.files_copiled == 4

    # check the dependencies
    assert result.dependencies == ['os', 'sys']

    # check the compilation time
    assert result.time_taken > 0

    # read

# Generated at 2022-06-21 17:00:18.907488
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('unit_tests/data/foo.py',
                           'unit_tests/data/output',
                           CompilationTarget.PYTHON)
    assert result.count == 1
    assert result.dependencies == ['foo']
    assert result.target == CompilationTarget.PYTHON
    assert isinstance(result.elapsed, float)

# Generated at 2022-06-21 17:00:31.104315
# Unit test for function compile_files
def test_compile_files():
    # Create temp directory for tests
    tmp = Path(tempfile.mkdtemp(prefix='compile_files_'))

# Generated at 2022-06-21 17:00:41.902172
# Unit test for function compile_files
def test_compile_files():
    from io import StringIO
    def read_file(filename):
        with open(filename, 'r') as f:
            return f.read()

    input_ = './test_input'
    output = './test_output'
    target = 'PRODUCTION'
    root = './'

    compile_files(input_, output, target, root)

    assert read_file('./test_output/file1.py') == """\
if a:
    print(2)
    print(3)
    print(4)
else:
    print(2)
    print(3)
    print(4)
"""

# Generated at 2022-06-21 17:00:48.655269
# Unit test for function compile_files
def test_compile_files():
    from .testing.tempdir import TempDir
    from .utils.helpers import testing

    with testing(compile_files):
        with TempDir() as dir:
            dir.write('source/index.py', 'print(1)')
            dir.write('source/index.txt', '1')
            compile_files(dir.path('source'), dir.path('target'),
                          CompilationTarget.Python3)
            assert dir.read('target/index.py') == 'print(1)\n'
            assert 'index.txt' not in dir.listdir('target')

        with TempDir() as dir:
            dir.write('source/index.py', 'print(1)')
            dir.write('source/index.txt', '1')

# Generated at 2022-06-21 17:00:57.687103
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import tempfile
    import shutil
    import os

    source_dir = os.path.join(os.path.dirname(__file__), 'tests', 'kwargs')
    target_dir = os.path.join(tempfile.mkdtemp(), 'kwargs')
    result = compile_files(source_dir, target_dir,
                           CompilationTarget.PYTHON_36)
    assert result.count == 4
    assert result.target == CompilationTarget.PYTHON_36


# Generated at 2022-06-21 17:01:03.517724
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_files_by_ext
    from .utils.helpers import debug_stdout

    def _test(test_case: dict, root: Path) -> None:
        result = compile_files(Path(test_case['input']),
                               Path(test_case['output']),
                               CompilationTarget.LATEST,
                               root.as_posix())

        debug_stdout(lambda: "CompilationResult(paths={}, requires={}, "
                       "requires_index={})".format(result.paths, result.requires, result.requires_index))

        # Check paths
        input_ = get_files_by_ext(test_case['input'], '')
        output = get_files_by_ext(test_case['output'], '')
       

# Generated at 2022-06-21 17:01:05.174956
# Unit test for function compile_files
def test_compile_files():
    # TODO: Make some for checking that compilation is done propperly
    pass


# Generated at 2022-06-21 17:01:09.976171
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .exceptions import CompilationError
    from .transformers import transformers
    from .transformers.modifiers import to_py2
    from .transformers.compat import pycompat

    with pytest.raises(CompilationError):
        compile_files('examples/fail/compile',
                      'examples/fail/compile/output',
                      CompilationTarget.Python27)

    with pytest.raises(CompilationError) as e:
        compile_files('examples/fail/syntax',
                      'examples/fail/syntax/output',
                      CompilationTarget.Python27)

    assert e.value.path.endswith('examples/fail/syntax/example.py')
    assert e.value.lineno == 18
    assert e.value.offset == 15

   

# Generated at 2022-06-21 17:01:13.197777
# Unit test for function compile_files
def test_compile_files():
    from .tools.doctest import doctest

    doctest(compile_files, 'compile.compile_files.compile_files')

# Generated at 2022-06-21 17:01:28.106445
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    import subprocess
    import tempfile

    input_ = tempfile.mkdtemp()
    os.makedirs(f"{input_}/hello/world/foo")
    with open(f"{input_}/hello/world/foo/file.py", 'w') as f:
        f.write('def main() -> int:\n    foo')
    with open(f"{input_}/hello/world/main.py", 'w') as f:
        f.write('import foo\nfoo.main()')

    output = tempfile.mkdtemp()

    compile_files(input_, output, CompilationTarget.LIBRARY)
    
    # Check that import and type hint are removed

# Generated at 2022-06-21 17:01:38.841141
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import tempfile
    import subprocess as sp
    import pathlib as pl

    def get_code(input_:str, expected:str) -> sp.CompletedProcess:
        """Gets the code being tested and the expected output."""
        here = pl.Path(os.path.dirname(os.path.abspath(__file__)))
        with open(str(here.parent / 'files' / input_)) as f:
            code = f.read()
        with open(str(here.parent / 'files' / expected)) as f:
            expected = f.read()
        return code, expected

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-21 17:01:49.851942
# Unit test for function compile_files
def test_compile_files():
    import io
    import tempfile
    import os
    import sys
    import shutil
    from typing import List
    from .types import CompilationResult
    from .exceptions import CompilationError

    def compile(input_: str, output: str, target: str = 'js') -> CompilationResult:
        return compile_files(input_, output, CompilationTarget[target])

    def compile_file(input_: str, output: str, target: str = 'js') -> CompilationResult:
        return compile_files(
            input_, output, CompilationTarget[target], root=os.path.dirname(input_))

    def compile_error(input_: str, output: str, target: str = 'js') -> None:
        compile(input_, output, target)
        raise Exception('CompilationError expected')

   

# Generated at 2022-06-21 17:02:00.359625
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from os import walk
    import subprocess
    import sys
    sys.path.append("../incompyle/")
    from incompyle.scripts.parser import parser
    from incompyle.scripts.usage import add_commandline_args, check_commandline_args, process_commandline_args, get_commandline_args
    
    #input_ = './tests/tests_sources'
    #output = './tests/tests_sources_compiled'
    #target = CompilationTarget.PYTHON_35
    
    args = get_commandline_args(parser)
    add_commandline_args(parser)
    check_commandline_args(parser, args)
    input_ = args.input
    output = args.output
    target = args.target
    

# Generated at 2022-06-21 17:02:07.336446
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/compiler', '.build/tests/compiler', CompilationTarget.JS).count == 3
    assert compile_files('tests/compiler', '.build/tests/compiler', CompilationTarget.JS).target == CompilationTarget.JS
    assert compile_files('tests/compiler', '.build/tests/compiler', CompilationTarget.JS).time > 0

# Generated at 2022-06-21 17:02:09.792741
# Unit test for function compile_files
def test_compile_files():
    import os
    
    input_ = os.path.join(os.getcwd(), "test_input")
    output = os.path.join(os.getcwd(), "test_output")
    
    CompileResult = compile_files(input_, output, CompilationTarget.WEB)
    assert CompileResult[0] == 10

# Generated at 2022-06-21 17:02:12.156263
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass

# Generated at 2022-06-21 17:02:14.977527
# Unit test for function compile_files
def test_compile_files(): 
    compile_files('tests/data/examples', 'tests/data/compiled', CompilationTarget.py2)


# Generated at 2022-06-21 17:02:20.866901
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import tempfile
    from pygit2 import Repository
    from .utils.helpers import get_project_root
    from .utils.helpers import create_git_repository

    with Repository(create_git_repository()) as repository:
        with tempfile.TemporaryDirectory() as input_:
            with tempfile.TemporaryDirectory() as output:
                subprocess.run(['git', 'clone', repository.workdir, input_],
                               check=True)
                compile_files(input_, output, CompilationTarget.PY2)
                project_root = get_project_root()
                subprocess.run(['black', '--check', '--diff', output],
                               cwd=project_root, check=True)

# Generated at 2022-06-21 17:02:31.502497
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError, TransformationError, CompilerVersionError
    from .transformers import transformers
    from .utils.helpers import debug_mode

    import os
    import subprocess
    import sys
    import textwrap
    from tempfile import TemporaryDirectory

    from .types import CompilationTarget
    from . import __version__

    tmp = TemporaryDirectory()


# Generated at 2022-06-21 17:02:48.207168
# Unit test for function compile_files
def test_compile_files():
    import tempfile, shutil
    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()

    def assert_files_equal(path1: str, path2: str) -> None:
        with open(path1) as f1, open(path2) as f2:
            assert f1.read() == f2.read()

    def assert_dirs_equal(dir1: str, dir2: str) -> None:
        dir1 = tempfile.TemporaryDirectory(dir=dir1).name
        dir2 = tempfile.TemporaryDirectory(dir=dir2).name
        for path in get_input_output_paths(dir1, dir2, input_):
            assert_files_equal(path.input.as_posix(), path.output.as_posix())


# Generated at 2022-06-21 17:02:57.282503
# Unit test for function compile_files
def test_compile_files():
    from .files.fixtures import BASIC
    for f_ in [
        'out/basic.py',
        'out/basic/__init__.py',
        'out/basic/sub/__init__.py',
        'out/basic/sub/sub.py',
        'out/basic/sub/sub/__init__.py'
    ]:
        with open(f_) as f:
            print('----- {}'.format(f.name))
            print(f.read())

# Generated at 2022-06-21 17:03:09.476437
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.JS
    input_ = 'test/test_files/test_compile_files/input'
    output = 'test/test_files/test_compile_files/output'
    expected_code = '''\
'use strict';
var x = 42;
var y = function() {
    return x;
};
'''
    result = compile_files(input_, output, target)
    assert result.count == 2
    assert result.dependencies == ['math/__init__.py']
    assert result.target == target

    # Check compile generated output file
    file_output = pathlib.Path(output) / 'math.py'
    with file_output.open() as f:
        generated_code = f.read()
    assert generated_code == expected_code


# Generated at 2022-06-21 17:03:21.067411
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    input_ = 'tests/data/sample_project'
    output = 'tests/tmp/compile_files'
    result = compile_files(input_, output, CompilationTarget.PYPY)
    assert result.count == 3
    assert result.target == CompilationTarget.PYPY
    assert result.dependencies == ['numpy']
    assert Path(output).exists()
    assert Path(output, 'dirA', 'dirB', 'file3.py').exists()
    assert Path(output, 'dirA', 'file2.py').exists()
    assert Path(output, 'file1.py').exists()

# Generated at 2022-06-21 17:03:22.655667
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass

# Generated at 2022-06-21 17:03:30.988416
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    from .utils.helpers import assert_dirs_same
    from .utils import files
    import shutil
    temp_dir = tempfile.mkdtemp()
    try:
        files.copy('test/input', temp_dir,
                   exclude=['__pycache__', '*.pyo', '*.pyc'])
        output_dir = os.path.join(temp_dir, 'output')
        result = compile_files(temp_dir, output_dir,
                               CompilationTarget.SERVER)
        assert result.compiled_files == 7
        target_dir = os.path.abspath('test/output')
        assert_dirs_same(output_dir, target_dir)
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-21 17:03:34.351329
# Unit test for function compile_files
def test_compile_files():
    import io
    import os
    import tempfile
    from . import __version__


# Generated at 2022-06-21 17:03:40.354727
# Unit test for function compile_files
def test_compile_files():
    # Should compile all files from input_ to output
    input_ = 'test-files/input/'
    output = 'test-files/output/'
    target = CompilationTarget.PYTHON_39
    root = 'test-files/root/'
    result = compile_files(input_, output, target, root)
    assert result.count == 3
    assert result.target == target
    assert result.dependencies == ['typing']
    # [TODO]: check output

# Generated at 2022-06-21 17:03:50.469543
# Unit test for function compile_files
def test_compile_files():
    from .files import get_files, get_files_count
    from .types import CompilationTarget
    import os

    origin = os.path.join(os.path.dirname(__file__), "tests/data/origin")
    result = os.path.join(os.path.dirname(__file__), "tests/data/result")

    for target in [CompilationTarget.FOR_JAVASCRIPT,
                   CompilationTarget.FOR_PYTHON,
                   CompilationTarget.FOR_TESTS]:
        count = get_files_count(origin)
        target_str = CompilationTarget.str(target)
        result_target_folder = os.path.join(result, target_str)
        compilation_result = compile_files(origin, result_target_folder, target)


# Generated at 2022-06-21 17:03:57.064781
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/files', '/tmp/python_to_cpp/files', CompilationTarget.TESTS)
    assert result == CompilationResult(count=3, time=0.0, target=1, dependencies=[])

# Generated at 2022-06-21 17:04:32.863718
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug

    input_ = '/home/vagrant/minic/testsuite/test_compiler/input'
    output = '/home/vagrant/minic/testsuite/test_compiler/output'
    target = CompilationTarget.cpython

    dependencies = set()
    start = time()
    count = 0

    with Path(input_).open() as f:
        code = f.read()


# Generated at 2022-06-21 17:04:41.911288
# Unit test for function compile_files
def test_compile_files():
    import os
    # test1: if input directory contain no *.ts files,
    # it should compile all *.ts files in input directory.
    # test1: if input directory contains files, it should
    # compile only those files.
    # test1: *.ts files in subdirectories of input directory
    # should be compiled too.
    # test3: *.js files in subdirectories of input directory
    # should be ignored.
    # test4: *.js files in input directory should be ignored.
    # TODO: update this test to cover the cases above
    result = compile_files(os.path.join(os.path.abspath(__file__),
                                        "../../test/test_compile/input/"),
                           os.path.abspath(__file__), CompilationTarget.ES5)
    assert result

# Generated at 2022-06-21 17:04:48.591246
# Unit test for function compile_files
def test_compile_files():
    for target in CompilationTarget:
        compile_files('fixtures/input/general',
                      'fixtures/output/general',
                      target,
                      'fixtures')
        compile_files('fixtures/input/general',
                      'fixtures/output/general',
                      target.value,
                      'fixtures')



# Generated at 2022-06-21 17:04:49.870546
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:05:02.288438
# Unit test for function compile_files
def test_compile_files():
    from .test import Test
    from .utils.tempdir import TestDir
    from .exceptions import CompilationError
    from .types import CompilationTarget

    with TestDir() as d:
        Test(d / 'x.md', d / 'x.py') \
            .write('```python\ncode\n```') \
            .compile(CompilationTarget.STRIP) \
            .expect_file_to_exist(d / 'x.py') \
            .expect_file_to_equal(d / 'x.py', 'code\n') \
            .expect_result(1, 0, CompilationTarget.STRIP, [])


# Generated at 2022-06-21 17:05:12.984516
# Unit test for function compile_files
def test_compile_files():
    res = compile_files('../tests/compiler_test_files/input', '../tests/compiler_test_files/output/', CompilationTarget.MOBILE_AND_WEB)
    assert res.target == CompilationTarget.MOBILE_AND_WEB
    assert res.duration > 0.0
    assert res.file_count == 3
    assert len(res.dependencies) == 2
    assert '../tests/compiler_test_files/input/file1.py' in res.dependencies
    assert '../tests/compiler_test_files/input/file2.py' in res.dependencies

# Generated at 2022-06-21 17:05:16.626229
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(
        './tests/test_data/test_compile_files_input',
        './tests/test_data/test_compile_files_output',
        CompilationTarget.ES5
    ) == CompilationResult(
        2,
        0,
        CompilationTarget.ES5,
        [
            './tests/test_data/test_compile_files_input/klasses.py',
            './tests/test_data/test_compile_files_input/utils/klass.py'
        ]
    )

# Generated at 2022-06-21 17:05:23.349241
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from .transformers.abstract import BaseTransformer
    from .transformers.annotations import FunctionAnnotationsTransformer

    class TestTransformer(BaseTransformer):
        target = CompilationTarget.BASE

        class TransformResult(BaseTransformer.TransformResult):
            tree_changed = True

        def transform(self, tree: ast.AST) -> TransformResult:
            self.add_dependency('test')
            return self.TransformResult(tree, self.dependencies)

    class SkipTransformer(BaseTransformer):
        target = CompilationTarget.BASE
        tree_changed = False

    transformers.append(TestTransformer)
    transformers.append(SkipTransformer)
    input_dir = tempfile.TemporaryDirectory()
    output_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-21 17:05:24.150532
# Unit test for function compile_files
def test_compile_files():
    compile_files()

# Generated at 2022-06-21 17:05:25.297478
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/resources/examples', 'tests/resources/output_examples', CompilationTarget.c)
    assert True

# Generated at 2022-06-21 17:06:05.506293
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('', '', CompilationTarget.STATIC), \
        'compile_files should return a value'

# Generated at 2022-06-21 17:06:15.737675
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    input_ = os.path.join(os.path.dirname(__file__), 'tests/compiler')
    test_output = os.path.join(os.path.dirname(__file__),
                               'tests/output')
    with tempfile.TemporaryDirectory() as output:
        compile_files(input_, output, CompilationTarget.nodejs)
        for file in os.listdir(test_output):
            assert os.path.exists(os.path.join(output, file))
            assert os.path.isfile(os.path.join(output, file))
            assert open(os.path.join(test_output, file)).read() == open(os.path.join(output, file)).read()



# Generated at 2022-06-21 17:06:20.585556
# Unit test for function compile_files
def test_compile_files():
    def test_code(code, target, expected_code):
        with open('test_file.swift', 'w') as f:
            f.write(code)
        i = 'test_file.swift'
        o = 'test_file.js' # is not a problem, really
        compile_files(i, o, target)
        with open(o) as f:
            s = f.read()
        print(s)
        assert s == expected_code

    test_code('print("A")', CompilationTarget.WEB, 'print("A");')
    test_code('print("A")\nprint("B")\nprint("C")',
              CompilationTarget.WEB,
              'print("A");\nprint("B");\nprint("C");')

# Generated at 2022-06-21 17:06:26.065494
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/.test_input/simple_if.py'
    output = 'tests/.test_output'
    target = CompilationTarget.PYTHON
    root = 'tests/'
    result = compile_files(input_, output, target, root)
    assert result.target == CompilationTarget.PYTHON
    assert result.count_of_files == 1
    assert result.time is not None

# Generated at 2022-06-21 17:06:35.534825
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.CLIENT
    input_ = '../testdata/demo'
    output = '../build'
    root = '../lib'

    files = get_input_output_paths(input_, output, root)
    print(files)

    result = compile_files(input_, output, target, root)

    assert (result.elapsed_time > 0)
    assert (result.total_files == 2)
    assert (result.target == target)
    assert (result.dependencies == ['../lib/gevent/greenlet.py'])


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-21 17:06:46.667442
# Unit test for function compile_files
def test_compile_files():
    pass
    # import subprocess
    # import os
    # # python -m tstl.compiler.compile tests/compile/input tests/compile/run_result c
    # cmd = ['python', '-m', 'tstl.compiler.compile', 'tests/compile/input', 'tests/compile/result', 'c']
    # subprocess.run(cmd, check=True)
    # cmd = ['diff', 'tests/compile/result', 'tests/compile/expected_result']
    # subprocess.run(cmd, check=True)
    # os.system('diff tests/compile/result tests/compile/expected_result')

# Generated at 2022-06-21 17:06:57.814146
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from textwrap import dedent
    from .exceptions import CompilationError

    input_ = [
        (dedent("""\
            def fib(n):
                if n < 2:
                    return n
                return fib(n - 2) + fib(n - 1)

            print(fib(20))
            """), CompilationTarget.ES6, dedent("""\
                function fib(n) {
                    if (n < 2) {
                        return n;
                    }
                    return fib(n - 2) + fib(n - 1);
                }
                print(fib(20));
                """))
    ]

    for code, target, output in input_:
        assert compile_files(code, '.', target).code == output


# Generated at 2022-06-21 17:07:08.290777
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os
    import re
    assert re.search(r"^\d+\.\d+\.\d+$", __version__)
    root_dir = os.path.dirname(os.path.abspath(__file__))
    input_dir = os.path.join(root_dir, 'test', 'unit', 'case')
    output_dir = os.path.join(root_dir, 'test', 'unit', 'output')
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    result = compile_files(input_dir, output_dir, 'runtime')
    assert result.count == 1
    assert result.target == 'runtime'
    assert len(result.dependencies) == 1
    assert os.path.exists

# Generated at 2022-06-21 17:07:14.623120
# Unit test for function compile_files
def test_compile_files():
    # pylint: disable=import-outside-toplevel
    import pathlib
    import s3fs
    import os
    import sys
    # pylint: enable=import-outside-toplevel

    def find_files(path: pathlib.Path):
        for entry in path.iterdir():
            if entry.is_dir():
                yield from find_files(entry)
            elif entry.is_file():
                yield entry

    # pylint: disable=redefined-outer-name
    PYTHON_VERSION = '.'.join(map(str, sys.version_info))
    ARGPARSE_VERSION = '1.4.0'
    # pylint: enable=redefined-outer-name
    target = CompilationTarget.python36

    # Directory to test the function
    input_

# Generated at 2022-06-21 17:07:26.533247
# Unit test for function compile_files
def test_compile_files():
    """Test for function compile_files."""
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .transformers import transformers
    from .helpers import FunctionTransformer, list_to_minilist
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    import os

    expected_path = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                                 'tests', 'output.py'))
    expected = open(expected_path, 'r').read()
    expected_target = CompilationTarget.TARGET_3_4

    class UselessTransformer(FunctionTransformer):
        """Transformer which does nothing."""
        target = CompilationTarget.TARGET_2_7

