

# Generated at 2022-06-21 16:58:10.255633
# Unit test for function compile_files
def test_compile_files():
    import pytest, tempfile
    from .tests.data import FILES_MD, FILES_MIN
    from .utils.helpers import clear_directory
    from .transformers import transformers, Target
    from typing import Type

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        # Ensure that the output directory is clear
        clear_directory(tmp_dir)

        # Test for all compilation targets separately
        for target in Target:
            # Compile the source files
            result = compile_files(str(FILES_MD),
                                   str(tmp_dir),
                                   target)

            # Ensure that the resulting files are correct

# Generated at 2022-06-21 16:58:12.111105
# Unit test for function compile_files
def test_compile_files():
    assert True, "Unit test not implemented"

# Generated at 2022-06-21 16:58:15.889211
# Unit test for function compile_files
def test_compile_files():
    r = compile_files("./tests/fixtures/", "./tests/tmp/", CompilationTarget.BROWSER)
    print(r.dependencies)

# Generated at 2022-06-21 16:58:22.386147
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    with tempfile.TemporaryDirectory('tmp') as d:
        code = '10\n'
        input_ = os.path.join(d, 'in')
        output = os.path.join(d, 'out')
        with open(input_, 'w') as f:
            f.write(code)

        compile_files(input_, output, CompilationTarget.javascript)

        with open(os.path.join(output, 'in.js')) as f:
            assert f.read() == '"use strict";\n\n10\n'


# Generated at 2022-06-21 16:58:32.430756
# Unit test for function compile_files
def test_compile_files():
    # Test all files
    compile_files('programs/test', 'programs/test_top', CompilationTarget.TOP)
    compile_files('programs/test', 'programs/test_middle', CompilationTarget.MIDDLE)
    compile_files('programs/test', 'programs/test_bottom', CompilationTarget.BOTTOM)

    # And a single file
    compile_files('programs/test', 'programs/test_top', CompilationTarget.TOP,
                  'programs/test/another/Another.java')

    # Make sure it crashes on non-existing files
    try:
        compile_files('programs/test', 'programs/test_top', CompilationTarget.TOP,
                      'programs/test/non_existing')
        assert False
    except CompilationError:
        assert True

# Generated at 2022-06-21 16:58:41.393002
# Unit test for function compile_files
def test_compile_files():
    inputs = [
        'https://github.com/pybee/toga/archive/master.zip',
        'https://github.com/sentry/sentry/archive/master.zip',
        'https://github.com/getsentry/sentry/archive/master.zip'
    ]
    outputs = [
        './test_compile_files_toga',
        './test_compile_files_sentry1',
        './test_compile_files_sentry2'
    ]
    for input, output in zip(inputs, outputs):
        compile_files(input, output, CompilationTarget.PY2)

# Generated at 2022-06-21 16:58:52.737963
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    import os.path
    import shutil

    def get_result(args) -> CompilationResult:
        return compile_files(args.input, args.output,
                             CompilationTarget[args.target])

    def check_result(result: CompilationResult, expected: CompilationResult) -> bool:
        return (result.count == expected.count and
                result.time == expected.time and
                result.target == expected.target and
                sorted(result.dependencies) == sorted(expected.dependencies))

    def read_json(path: str) -> dict:
        with open(path) as f:
            return json.load(f)

    def check_output(output: str, expected: str):
        assert output == expected


# Generated at 2022-06-21 16:59:04.135832
# Unit test for function compile_files
def test_compile_files():
    from .files import SourceFile, TargetFile
    from .types import CompilationTarget, CompilationResult

    # Prepare files for test
    source = SourceFile('input/foo.js', 'contents')
    target = TargetFile('output/foo.js', 'expected')
    files = [source, target]

    # Mocks
    class Transformer:
        def transform(self, tree: ast.AST) -> None:
            pass

        def target(self) -> CompilationTarget:
            return CompilationTarget.RUNTIME

    class TransformerFailOnFirstFile:
        def transform(self, tree: ast.AST) -> None:
            raise ValueError('test Error')

    mock_get_input_output_paths = lambda input_, output, root: files
    mock_transform = lambda path: 'transformed'
    mock_comp

# Generated at 2022-06-21 16:59:06.478517
# Unit test for function compile_files
def test_compile_files():
    #TODO: implement this function
    pass

# Generated at 2022-06-21 16:59:16.293103
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(
        'tests/manual', 'tests/manual/out', CompilationTarget.STAGE1) == \
        CompilationResult(1, _, CompilationTarget.STAGE1,
                          ['logging', 'unittest', 'basics', 're'])
    assert compile_files(
        'tests/manual', 'tests/manual/out', CompilationTarget.STAGE2) == \
        CompilationResult(1, _, CompilationTarget.STAGE2,
                          ['logging', 'unittest', 'basics', 're'])

# Generated at 2022-06-21 16:59:32.806927
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from glob import glob
    from . import path
    import pytest
    from .types import CompilationTarget

    test_paths = (
        ('simple', 'py2', 'patched2'),
    )

    @pytest.mark.parametrize("src,patched,target", test_paths)
    def test(src, patched, target):

        for test_dir in glob(str(path / 'tests/*')):
            shutil.rmtree(test_dir)

        shutil.copytree(str(path.test_data / src),
                        str(path / 'tests/test' / src))
        compile_files(str(path / 'tests/test' / src),
                      str(path / 'tests/test' / patched),
                      CompilationTarget(target))



# Generated at 2022-06-21 16:59:41.503297
# Unit test for function compile_files
def test_compile_files():
    import sys
    import tempfile

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()

    test_file = 'test.py'
    with open("{}/{}".format(input_, test_file), "w") as f:
        f.write("import sys\nsys.stdin = open('{}/{}'.format(sys.path[0], test_file))".format(input_, test_file))

    result = compile_files(input_, output, CompilationTarget.PYTHON, str(sys.path[0]))

    assert result.count == 1

# Generated at 2022-06-21 16:59:53.078313
# Unit test for function compile_files
def test_compile_files():
    from tempfile import mkdtemp
    from shutil import rmtree
    from .exceptions import CompilationError, TransformationError

    input_ = mkdtemp()
    output = mkdtemp()


# Generated at 2022-06-21 17:00:02.012617
# Unit test for function compile_files
def test_compile_files():
    import os
    from pathlib import Path
    from . import __file__ as package_directory
    from .constants import TARGET_3_7, TARGET_3_6
    os.environ['ALTERED_STATE_TESTING'] = 'YES'
    result = compile_files(Path(package_directory).parent / 'tests' / 'data', 'build', TARGET_3_6)
    print('Files: {}, time: {}, dependencies: {}'.format(result.count, result.time, result.dependencies))
    assert result.count > 0

# Generated at 2022-06-21 17:00:02.721757
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:00:09.374509
# Unit test for function compile_files
def test_compile_files():
    from .utils.asserts import path_equal

    output_dir = 'tmp/test_compile_files'
    input_dir = 'tmp/test_compile_files/src'

    compile_files(input_dir, output_dir, CompilationTarget.PYTHON2)

    path_equal(output_dir, input_dir + '_expected')


# Generated at 2022-06-21 17:00:12.839208
# Unit test for function compile_files
def test_compile_files():
    compile_files('test/test_all/test_input_program',
                  'test/test_all/test_output_program',
                  CompilationTarget.PYTHON)
    compile_files('test/test_all/test_input_program2',
                  'test/test_all/test_output_program2',
                  CompilationTarget.PYTHON)



# Generated at 2022-06-21 17:00:21.626500
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import shutil
    import tempfile
    import unittest

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.input_)
            shutil.rmtree(self.output)

        def _test(self):
            compile_files(self.input_, self.output,
                          CompilationTarget.PY)

        def test_empty(self):
            self._test()

        def test_single_file(self):
            path = os.path.join(self.input_, 'a.py')

# Generated at 2022-06-21 17:00:31.882549
# Unit test for function compile_files
def test_compile_files():
    import os.path
    import pytest

    def test_build(input_, expected):
        output = input_ + '-output'
        assert os.path.exists(input_)
        compile_files(input_, output, CompilationTarget.model)
        assert os.path.exists(output)
        with open(output) as f:
            assert f.read() == expected

    def test_build_invalid(input_, expected):
        with pytest.raises(CompilationError):
            test_build(input_, expected)

    test_build('test/compilers/data/test_build0.py',
               'test/compilers/data/test_build0.py-expected')

# Generated at 2022-06-21 17:00:41.902053
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .types import CompilationTarget
    from .files import get_input_output_paths
    from .transformers import move_if_statements_to_function
    from pathlib import Path
    from os.path import join
    
    def test_move_if_statements_to_function(script):
        input_ = 'test/test_files/code/' + script
        output = 'test/test_files/output/' + script
        root = 'test/test_files'
        paths = get_input_output_paths(input_, output, root)
        _compile_file(paths[0], CompilationTarget.FUNCTION)

        with open(output, 'r') as f:
            actual = f.read()
