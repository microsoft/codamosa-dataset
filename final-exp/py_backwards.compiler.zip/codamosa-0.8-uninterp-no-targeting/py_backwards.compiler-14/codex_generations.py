

# Generated at 2022-06-21 17:00:53.361546
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    import os

    for t in (CompilationTarget.JS, CompilationTarget.HTML):
       assert isinstance(compile_files(os.path.join(Path(__file__).parent, "test_files"), "/tmp", t), CompilationResult)

# Generated at 2022-06-21 17:00:57.366953
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('test/fixtures/regex', 'test/fixtures/build', CompilationTarget.PYTHON)
    except Exception as e:
        print(e)
    # with open('test/build/regex.py') as f:
    #     code = f.read()
    #     print(code)

# Generated at 2022-06-21 17:01:02.666348
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import copytree
    from .types import CompilationResult

    temp_dir = TemporaryDirectory()
    input_dir = Path('tests') / 'fixtures'
    output_dir = Path(temp_dir.name)
    copytree(str(input_dir), str(output_dir))

    for target in CompilationTarget:
        compile_files(str(output_dir / 'input'),
                      str(output_dir / 'output'),
                      target)

    with (output_dir / 'output/index.py').open() as f:
        res = f.read()

    assert res == 'a = 1 + 2\n', res

# Generated at 2022-06-21 17:01:15.430042
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import json

    import pytest

    @pytest.fixture
    def test_project(tmpdir_factory):
        """
        Project with some files, which need to be compiled.
        """

        def create_file(path, content):
            """
            Creates a file with path and content (string) in test directory.
            """
            with open(path.as_posix(), 'w') as f:
                f.write(content)

        test_dir = Path(tmpdir_factory.mktemp('python_to_javascript'))
        input_paths = (
            'main.py',
            'source.py',
            'source/a/a.py',
            'source/b/b.py'
        )

# Generated at 2022-06-21 17:01:16.436615
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-21 17:01:18.479831
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('../tests/assets', '../tests/assets/output',
                         CompilationTarget.DOCKER)

# Generated at 2022-06-21 17:01:22.686804
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("test/test_compile/input", "test/test_compile/output",
                           CompilationTarget.POTENTIAL, "test/test_compile")
    assert result.count_files == 3


# Generated at 2022-06-21 17:01:31.080629
# Unit test for function compile_files
def test_compile_files():
    from os import getcwd
    from pytest import raises
    from tempfile import TemporaryDirectory
    from shutil import copy

    with TemporaryDirectory() as temp_dir:
        path2 = str(temp_dir)
        path = getcwd()
        copy(path + '/tests/data/compile/scripts/test.py', path2)
        result = compile_files(path + '/tests/data/compile/scripts',
                               path2, CompilationTarget.python36)
        assert result.count == 1
        assert result.target == CompilationTarget.python36
        # this will fail because it cannot find the OS module
        with raises(CompilationError):
            result = compile_files(path + '/tests/data/compile/scripts',
                                   path2, CompilationTarget.python36)

# Generated at 2022-06-21 17:01:39.940866
# Unit test for function compile_files
def test_compile_files():
    """Compiles all files from test_i to test_o."""
    import os
    import sys
    import glob

    def test_file(test: str, target: CompilationTarget):
        debug(lambda: 'Testing file {}'.format(test))
        sys.argv = [test, test_i, test_o, target.name]
        test_name = os.path.splitext(os.path.basename(test))[0]
        if test_name != 'test':
            print('Test {}:'.format(test_name))
        compile_files(sys.argv[1], sys.argv[2], target)

# Generated at 2022-06-21 17:01:40.752100
# Unit test for function compile_files
def test_compile_files():
    assert True