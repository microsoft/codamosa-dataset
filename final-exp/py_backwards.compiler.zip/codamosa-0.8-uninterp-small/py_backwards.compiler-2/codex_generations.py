

# Generated at 2022-06-25 21:30:12.538522
# Unit test for function compile_files
def test_compile_files():

    str_0 = 'string'
    str_1 = 'string'
    str_2 = 'string'
    str_3 = 'string'
    str_4 = 'string'
    str_5 = 'string'
    str_6 = 'string'
    str_7 = 'string'
    str_8 = 'string'
    str_9 = 'string'
    str_10 = 'string'
    str_11 = 'string'
    str_12 = 'string'
    str_13 = 'string'
    str_14 = 'string'
    str_15 = 'string'
    str_16 = 'string'
    str_17 = 'string'
    str_18 = 'string'
    str_19 = 'string'
    str_20 = 'string'
    str_21 = 'string'
   

# Generated at 2022-06-25 21:30:13.289957
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:30:14.812973
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except CompilationError as e:
        print(e)
        assert False


# Generated at 2022-06-25 21:30:16.331895
# Unit test for function compile_files
def test_compile_files():
    assert(test_case_0())
    print("Unit test for function compile_files done")

test_compile_files()

# Generated at 2022-06-25 21:30:17.890674
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        raise RuntimeError("Test case 0 failed")


# Generated at 2022-06-25 21:30:28.288089
# Unit test for function compile_files
def test_compile_files():
    with open(os.path.join(os.path.dirname(__file__), 'test_input', 'test_1.py')) as input_file, \
         open(os.path.join(os.path.dirname(__file__), 'test_input', 'test_1.pycopy')) as output_file:
        count = len(input_file.readlines())
        output_file.seek(0)
        compilation_result_0 = compile_files(
            os.path.join(os.path.dirname(__file__), 'test_input', 'test_1.py'),
            os.path.join(os.path.dirname(__file__), 'test_input', 'test_1.pycopy'),
            CompilationTarget.PYTHON2)
        assert count == compilation_result_

# Generated at 2022-06-25 21:30:33.481910
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = 3
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)

# Generated at 2022-06-25 21:30:43.695770
# Unit test for function compile_files
def test_compile_files():
    int_0 = 1
    int_1 = 2
    int_2 = 1
    int_3 = 2
    str_0 = '../tests/in/t0.sy'
    str_1 = '../tests/in/t1.sy'
    str_2 = '../tests/in/t2.sy'
    str_3 = '../tests/in/t3.sy'
    str_4 = '../tests/in/t4.sy'
    str_5 = '../tests/out/t0.py'
    str_6 = '../tests/out/t1.py'
    str_7 = '../tests/out/t2.py'
    str_8 = '../tests/out/t3.py'
    str_9 = '../tests/out/t4.py'
   

# Generated at 2022-06-25 21:30:50.089219
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == "__main__":
    import sys
    import doctest

    count, _ = doctest.testmod()
    if count == 0:
        print("All tests passed")

    sys.exit(count)

# Generated at 2022-06-25 21:30:56.976815
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = 3
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert tuple_0 == compilation_result_0.target
    assert len(compilation_result_0.dependencies) == 0
    assert compilation_result_0.compiled == 0
    assert compilation_result_0.time > 0


# Generated at 2022-06-25 21:31:02.877361
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

test_compile_files()

# Generated at 2022-06-25 21:31:04.410876
# Unit test for function compile_files
def test_compile_files():
    print('Unit test for function compile_files')
    str_0 = 'Hello from test!'
    print(str_0)

# Generated at 2022-06-25 21:31:07.704570
# Unit test for function compile_files
def test_compile_files():
    file_0 = 'test_files/test.py'
    file_1 = 'test_files/test.js'
    var_0 = compile_files(file_0, file_1, CompilationTarget.ES5, 'root')
    test_case_0()


# Generated at 2022-06-25 21:31:14.303118
# Unit test for function compile_files
def test_compile_files():
    input_ = './test_input'
    output = './test_output'

    # Create test folders
    Path(input_).mkdir(parents=True, exist_ok=True)
    Path(output).mkdir(parents=True, exist_ok=True)

    # Create test files
    for i in range(6):
        with open(input_+'/test_file_'+str(i)+'.py','w') as f:
            i += 1
            f.write('print(\"test_'+str(i)+'\")\n')

    Compile_result = compile_files(input_, output, CompilationTarget.UNIT_TEST_FIX)
    print('\nCreate test case #0')
    assert Compile_result.target == CompilationTarget.UNIT_TEST_FIX

# Generated at 2022-06-25 21:31:18.123486
# Unit test for function compile_files
def test_compile_files():
    input_ = 'library'
    output = 'output'
    target = CompilationTarget.PYTHON
    root = None
    compile_files(input_, output, target, root)
    str_0 = 'Unit test for function compile_files done'
    var_0 = print(str_0)

# Generated at 2022-06-25 21:31:32.423892
# Unit test for function compile_files
def test_compile_files():
    from os import makedirs
    from os.path import exists, join
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from typing import Tuple

    # type: Tuple[str, str, str]
    def create_files() -> Tuple[str, str, str]:
        tempdir = TemporaryDirectory(prefix='test-files')

        makedirs(join(tempdir.name, 'in', 'a', 'b', 'c'))

        files = [
            ('in/foo.py', 'print("Hello, World!")'),
            ('in/a/bar.py', 'print(1 + 1)'),
            ('in/a/b/c/baz.py', 'import sys; print(sys.platform)'),
        ]


# Generated at 2022-06-25 21:31:38.031015
# Unit test for function compile_files
def test_compile_files():
    # test case 0
    print('*** test case 0 ***')
    test_case_0()

# main function
if __name__ == '__main__':
    # test compile_files
    test_compile_files()

# Generated at 2022-06-25 21:31:41.594792
# Unit test for function compile_files
def test_compile_files():
    compile_files('/home/julien/dev/ojs/elixir/backend/elixir/compiler',
                  '/home/julien/dev/ojs/elixir/backend/elixir/compiler/output',
                  1)
    test_case_0()

test_compile_files()

# Generated at 2022-06-25 21:31:46.141416
# Unit test for function compile_files
def test_compile_files():
    start = time()
    assert compile_files('./data/pypackages', './out', CompilationTarget.WEB) == CompilationResult(3, time() - start, CompilationTarget.WEB, None)
    str_0 = 'Unit test for function compile_files done'
    var_0 = print(str_0)

test_compile_files()

# Generated at 2022-06-25 21:31:50.574700
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'Compiling file test/examples/test_a.py to test/examples/test_b.py ...'
    var_0 = print(str_0)
    var_1 = compile_files('test/examples/test_a.py', 'test/examples/test_b.py', 'js')
    str_1 = 'Compiled: ',
    str_2 = var_1
    str_3 = str_1 + str_2
    var_2 = print(str_3)


# Generated at 2022-06-25 21:32:03.492348
# Unit test for function compile_files
def test_compile_files():
    with TemporaryDirectory() as tmp_in, \
            TemporaryDirectory() as tmp_out:
        tmp_in_py = Path(tmp_in).joinpath('foo.py')
        tmp_in_py.write_text(dedent("""
            def foo():
                print('Hello, world!')
        """))

        result = compile_files(tmp_in, tmp_out, CompilationTarget.JS)
        assert result.count == 1
        assert result.target == CompilationTarget.JS
        assert result.time > 0

        tmp_out_js = Path(tmp_out).joinpath('foo.js')
        assert tmp_out_js.exists()


# Generated at 2022-06-25 21:32:06.038275
# Unit test for function compile_files
def test_compile_files():
  possible_values = [('', '', (0, 1)), ('/tmp/pyta/main/', '/tmp/pyta/main/', (1, 0)), ('', '', (0, 0))]
  for input, output, target in possible_values:
    assert compile_files(input, output, target) == expected

# Generated at 2022-06-25 21:32:13.638971
# Unit test for function compile_files
def test_compile_files():
    print('Testing for function compile_files')

    # ADD YOUR TEST CASES HERE...
    # test case 1
    str_0 = '{}/../data/test1-in.py'
    int_0 = 3
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    print(compilation_result_0)

    # test case 2
    str_0 = '{}/../data/test2-in.py'
    int_0 = 3
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    print(compilation_result_0)
    
    # test case 3
    str_0

# Generated at 2022-06-25 21:32:16.643903
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except (Exception) as e:
        print('Exception in test case "%s"' % test_case_0.__name__)
        raise e

if __name__ == "__main__":
    # Compile all test suites
    test_compile_files()

# Generated at 2022-06-25 21:32:21.317579
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = 3
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert (compilation_result_0.count == 0)
    assert (compilation_result_0.target == tuple_0)
    assert (len(compilation_result_0.dependencies) == 0)



# Generated at 2022-06-25 21:32:23.775127
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception:
        print('Exception: test_compile_files failed for test_case_0')

# Generated at 2022-06-25 21:32:24.571868
# Unit test for function compile_files
def test_compile_files():
    assert callable(compile_files)

# Generated at 2022-06-25 21:32:26.654845
# Unit test for function compile_files
def test_compile_files():
    assert test_case_0() == None

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:32:27.381349
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:32:28.129407
# Unit test for function compile_files
def test_compile_files():
    assert(test_case_0() == None)