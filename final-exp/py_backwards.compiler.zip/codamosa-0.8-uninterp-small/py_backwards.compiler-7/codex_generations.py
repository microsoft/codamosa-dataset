

# Generated at 2022-06-25 21:30:11.063433
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == '__main__':
    import sys
    import datetime
    from pprint import pprint

    sys.path.insert(0, '.')
    test_compile_files()

    print('Tests passed at {} UTC'.format(datetime.datetime.utcnow()))

# Generated at 2022-06-25 21:30:18.088970
# Unit test for function compile_files
def test_compile_files():
    # Initiates all vars for future use
    str_0 = 'n~-^0'
    int_0 = -604
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    int_1 = compilation_result_0.count
    int_2 = 3
    assert int_1 == int_2
    float_0 = compilation_result_0.elapsed
    float_1 = float_0
    assert float_1 == float_0
    compilation_target_0 = compilation_result_0.target
    int_3 = tuple_0[0]
    int_4 = tuple_0[1]
    compilation_target_1 = (int_3, int_4)
    assert compilation_target

# Generated at 2022-06-25 21:30:28.482179
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'n~-^0'
    int_0 = -604
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert compilation_result_0


# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.glob
# Test for Path.gl

# Generated at 2022-06-25 21:30:30.955132
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:30:39.364063
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'n~-^0'
    int_0 = -604
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert isinstance(compilation_result_0, CompilationResult)
    assert compilation_result_0.file_count == int_0
    assert isinstance(compilation_result_0.time, float)
    assert compilation_result_0.target == tuple_0
    assert isinstance(compilation_result_0.dependencies, list)

# Generated at 2022-06-25 21:30:43.257486
# Unit test for function compile_files
def test_compile_files():
    print("Testing function compile_files...", end="")
    assert_equal(compile_files("input.py", "output.py", 1, None),
                 CompilationResult(1, 0.0, 1, []))
    print("Passed!")


# Generated at 2022-06-25 21:30:57.065907
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'Ei'
    int_0 = 1
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert(compilation_result_0.target == tuple_0)

    str_1 = 'jY'
    int_1 = 1
    tuple_1 = (int_1, int_1)
    compilation_result_1 = compile_files(str_1, str_1, tuple_1)
    assert(compilation_result_1.target == tuple_1)

    str_2 = '9i'
    int_2 = 1
    tuple_2 = (int_2, int_2)

# Generated at 2022-06-25 21:31:02.327033
# Unit test for function compile_files
def test_compile_files():
    msg = ''
    n = -604
    input_ = 'n~-^0'
    output = 'n~-^0'
    target = (-604, -604)
    root = 'n~-^0'
    expected = CompilationResult(0, 0.0, target, [])
    actual = compile_files(input_, output, target, root)
    assert actual == expected



# Generated at 2022-06-25 21:31:03.554126
# Unit test for function compile_files
def test_compile_files():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 21:31:05.418737
# Unit test for function compile_files
def test_compile_files():
    print('in test')
    for i in range(100):
        print(test_case_0())

test_compile_files()

# Generated at 2022-06-25 21:31:15.075023
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        return False
    else:
        return True


if __name__ == '__main__':
    print(test_compile_files())

# Generated at 2022-06-25 21:31:32.418860
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


if __name__ == '__main__':
    # Run all tests
    for func in [obj for name, obj in inspect.getmembers(sys.modules[__name__]) if (inspect.isfunction(obj) and name.startswith('test_'))]:
        func()

    print('Everything looks good!')

# Generated at 2022-06-25 21:31:37.107698
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'n~-^0'
    int_0 = -604
    tuple_0 = (int_0, int_0)
    test_case_0()

# Generated at 2022-06-25 21:31:38.896809
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:31:42.565924
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'n~-^0'
    int_0 = -604
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)

    assert type(compilation_result_0) == CompilationResult


# Generated at 2022-06-25 21:31:43.794462
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Test for function compile_files

# Generated at 2022-06-25 21:31:44.811903
# Unit test for function compile_files
def test_compile_files():
    with pytest.raises(AttributeError):
        test_case_0()

# Generated at 2022-06-25 21:31:47.112458
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception as e:
        print(e)
    print("All test cases passed!")

# Generated at 2022-06-25 21:31:52.702252
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'n~-^0'
    int_0 = -604
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert compilation_result_0.target == tuple_0
    assert compilation_result_0.compiled_files == int_0
    assert compilation_result_0.compilation_time == int_0
    assert isinstance(compilation_result_0.dependencies, list)
    str_1 = 'n~-^0'
    int_1 = -604
    tuple_1 = (int_1, int_1)
    compilation_result_1 = compile_files(str_1, str_1, tuple_1, str_1)
    assert compilation_result

# Generated at 2022-06-25 21:31:53.417948
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


# Main function

# Generated at 2022-06-25 21:32:11.859435
# Unit test for function compile_files
def test_compile_files():
    # AssertionError: assert 0 == 1

    try:
        with pytest.raises(AssertionError):
            test_case_0()
    except AssertionError as e:
        assert str(e) == 'assert 0 == 1'


if __name__ == '__main__':
    try:
        test_compile_files()
    except Exception:
        raise

# Generated at 2022-06-25 21:32:13.903485
# Unit test for function compile_files
def test_compile_files():
    start_time = time()
    test_case_0()
    end_time = time()
    print("Time taken: ", end_time - start_time)

test_compile_files()

# Generated at 2022-06-25 21:32:17.621180
# Unit test for function compile_files
def test_compile_files():
    print("Test compile_files() function")
    input_ = "testing.py"
    output = "test_output.txt"
    root = "./compiler"
    target = (0, 1)
    result = compile_files(input_, output, target, root)
    assert result.count == 1



# Generated at 2022-06-25 21:32:18.377245
# Unit test for function compile_files
def test_compile_files():
    assert test_case_0() == None

# Generated at 2022-06-25 21:32:23.173448
# Unit test for function compile_files
def test_compile_files():
    print("Testing function: compile_files(str, str, CompilationTarget, str)")
    from .files import test_case_0, test_case_1, test_case_2
    test_case_0()
    test_case_1()
    test_case_2()
    print("Passed all tests!")


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:23.992125
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:32:31.543365
# Unit test for function compile_files
def test_compile_files():
    path_in = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'example', 'test_in')
    path_out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'example', 'test_out')
    path_expected = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'example', 'expected')
    result = compile_files(path_in, path_out, CompilationTarget.PY, path_in)
    import filecmp
    assert len(result.dependencies) == len(os.listdir(path_expected))

# Generated at 2022-06-25 21:32:39.470117
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'DJ'
    int_0 = 3
    tuple_0 = (int_0, int_0)
    string_0 = 'q'
    string_1 = 'file_0_in'
    string_2 = 'file_0_out'
    int_1 = 3
    int_2 = 9
    tuple_1 = (int_1, int_2)
    string_3 = 'file_1_in'
    string_4 = 'file_1_out'
    int_3 = 4
    int_4 = 4
    tuple_2 = (int_3, int_4)
    string_5 = 'file_2_in'
    string_6 = 'file_2_out'
    int_5 = 2
    int_6 = 6

# Generated at 2022-06-25 21:32:47.131073
# Unit test for function compile_files
def test_compile_files():
    # test_case_0
    str_0 = 'n~-^0'
    int_0 = -604
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    
    # test_case_1
    list_0 = [1, 2, 3, 4, 5]
    list_1 = [1, 2, 3]
    list_2 = [1, 2, 3]
    dict_0 = {1: 1, 2: 2, 3: 3}
    dict_1 = {1: 1, 2: 2, 3: 3}
    dict_2 = {1: 1, 2: 2, 3: 3}

# Generated at 2022-06-25 21:32:48.329423
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

test_compile_files()