

# Generated at 2022-06-25 21:30:05.780567
# Unit test for function compile_files
def test_compile_files():
    assert callable(compile_files)

# Generated at 2022-06-25 21:30:09.021850
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        print("Failed")

test_compile_files()

# Generated at 2022-06-25 21:30:10.688502
# Unit test for function compile_files
def test_compile_files():
    assert [1, 2, 3] == [1, 2, 3]
test_case_0()
test_compile_files()

# Generated at 2022-06-25 21:30:12.731322
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        print("Exception in test case {}".format(0))
        raise

# Generated at 2022-06-25 21:30:19.019327
# Unit test for function compile_files
def test_compile_files():
    str_0 = '&@\u254fW8k"s4\u9e78<\u38d7'
    str_1 = '/\u0b10l0'
    compilation_result_0 = compile_files(str_0, str_1, None)
    assert isinstance(compilation_result_0, CompilationResult)
    str_2 = 'E\u8b46f\u246f:\u5a5d'
    str_3 = '\u140c<\u04d8\u5aec'
    tuple_0 = None
    compilation_result_1 = compile_files(str_2, str_3, tuple_0, str_1)
    assert isinstance(compilation_result_1, CompilationResult)

# Generated at 2022-06-25 21:30:22.323896
# Unit test for function compile_files
def test_compile_files():
    str_0 = __file__
    str_1 = 'tests'
    compilation_result_0 = compile_files(str_0, str_1, None, str_1)
    print(compilation_result_0)

test_compile_files()

# Generated at 2022-06-25 21:30:23.143221
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:30:25.289735
# Unit test for function compile_files
def test_compile_files():
    print(test_case_0())

test_compile_files()

# Generated at 2022-06-25 21:30:29.990667
# Unit test for function compile_files
def test_compile_files():
    # Initial tests
    print('Initial Tests')
    test_case_0()


if __name__ == '__main__':
    # Unit tests for compile_files
    test_compile_files()

    # Example for compile_files usage

# Generated at 2022-06-25 21:30:40.901942
# Unit test for function compile_files
def test_compile_files():
    # Assignments
    # Set literals
    set_0 = set()
    # Assignments
    # Module attributes
    # Function calls
    # Type specifications
    # None
    # Infix operations
    # Return values
    # none
    # Module import
    # None
    # none
    # Function definitions
    # Type specifications
    # None
    # none
    # Function calls
    # Type specifications
    # None
    # Infix operations
    # Module attributes
    # Function calls
    # Type specifications
    # None
    # Infix operations
    # Return values
    # Module attributes
    # Function calls
    # Type specifications
    # None
    # Infix operations
    # Return values
    # none
    # Module import
    # None
    # none
    
test_case_0()

# Generated at 2022-06-25 21:30:48.699150
# Unit test for function compile_files
def test_compile_files():
    assert callable(compile_files)
    assert isinstance(compile_files(str(), str(), tuple()), CompilationResult)


# Generated at 2022-06-25 21:30:51.069967
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
        assert False
    except CompilationError:
        assert True
    except TransformationError:
        assert True

# Generated at 2022-06-25 21:30:59.717426
# Unit test for function compile_files
def test_compile_files():
    start_0 = time()
    str_0 = '+%N)qW|!8jKZ/['
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert compilation_result_0.count == 0, 'asserted'
    assert (compilation_result_0.duration == time() - start_0), 'asserted'
    assert compilation_result_0.dependencies == [], 'asserted'
    assert compilation_result_0.target == tuple_0, 'asserted'
    print('passed')

test_compile_files()

# Generated at 2022-06-25 21:31:08.633680
# Unit test for function compile_files

# Generated at 2022-06-25 21:31:09.426635
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:31:14.092753
# Unit test for function compile_files
def test_compile_files():
    str_0 = './main.py'
    str_1 = './output'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0)
    assert isinstance(compilation_result_0, (compilation_result_0, CompilationResult))
    assert compilation_result_0 is not None
    assert compilation_result_0.count == 1
    assert compilation_result_0.time >= 0
    assert compilation_result_0.target is None
    assert compilation_result_0.dependencies == []

# Generated at 2022-06-25 21:31:15.921596
# Unit test for function compile_files
def test_compile_files():
    debug(lambda: "Unit test for function compile_files")
    test_case_0()

# Main function for testing this module

# Generated at 2022-06-25 21:31:32.420769
# Unit test for function compile_files
def test_compile_files():
    str_0 = '+%N)qW|!8jKZ/['
    str_1 = 'G0y|!8jKZ/['
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)



# Generated at 2022-06-25 21:31:39.888253
# Unit test for function compile_files
def test_compile_files():
    str_0 = '+%N)qW|!8jKZ/['
    str_1 = '+%N)qW|!8jKZ/['
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)
    str_0 = 'sz:+il j_va'
    
    assert not compilation_result_0.errors


# Generated at 2022-06-25 21:31:42.204136
# Unit test for function compile_files
def test_compile_files():
    expected_error = "is not a valid input path"
    with pytest.raises(FileNotFoundError, match=expected_error):
        test_case_0()

# Generated at 2022-06-25 21:31:49.951785
# Unit test for function compile_files
def test_compile_files():
    test = 'from foo import Foo\nfrom bar import Bar\n\n' \
           'class MadeIn: pass\n' \
           'class MadeOut: pass'
    assert _transform('test.py', test, CompilationTarget.TEST)[0] == \
           'from foo import Foo\nfrom bar import Bar\n\n' \
           'class MadeIn: pass'

# Generated at 2022-06-25 21:31:52.305006
# Unit test for function compile_files
def test_compile_files():
    # Setup unit test case
    var_0 = str()

    # Run compile_files()
    compilation_result_0 = compile_files(var_0, var_0, var_0)

    # Assertion
    test_case_0()

# Generated at 2022-06-25 21:31:57.595755
# Unit test for function compile_files
def test_compile_files():
    test_cases = [
        # NOTE: The following test case has been generated,
        #       please add your test here.
        
    ]
    count_passes = 0
    for test_case in test_cases:
        try:
            test_case()
            count_passes += 1
        except:
            print('Test failed: ' + test_case.__name__)
            print(format_exc())
    print('{0}/{1} Test(s) Passed'.format(count_passes, len(test_cases)))

# Generated at 2022-06-25 21:32:04.556855
# Unit test for function compile_files
def test_compile_files():
    input_ = '/Users/daviting/PycharmProjects/skidl/skidl_transpiler/tests/fixtures'
    output = '/Users/daviting/PycharmProjects/skidl/skidl_transpiler/tests/fixtures'
    target = 'skidl'
    root = None
    compilation_result = compile_files(input_, output, target, root)
    assert compilation_result.count == 3
    assert compilation_result.output_path == output
    assert compilation_result.input_path == input_
    assert compilation_result.target == target
    assert compilation_result.time >= 0.0
    assert compilation_result.dependencies == ['skidl', 'kicadPcbWriter',
                                               'kicadNets']

# Generated at 2022-06-25 21:32:10.754629
# Unit test for function compile_files
def test_compile_files():
    my_input = "test_input"
    my_output = "test_output"
    my_root = "test_root"
    my_target = CompilationTarget.RUNTIME
    my_result = CompilationResult(0, 0.0, CompilationTarget.RUNTIME, [])
    try:
        result = compile_files(my_input, my_output, my_target, my_root)
        if result == my_result:
            print("Test case passed!")
        else:
            print("Test with given input failed")
    except Exception:
        print("Test case failed")

test_case_0()
test_compile_files()

# Generated at 2022-06-25 21:32:11.539682
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:32:15.430715
# Unit test for function compile_files
def test_compile_files():
    with open('sample.py', 'w') as f:
        f.write('def foo():\n  return 10')

    input_ = 'sample.py'
    output = 'output'
    target = 'Javascript'
    root = None

    compile_files(input_, output, target, root)
    pass

if __name__ == '__main__':
    test_compile_files()
    test_case_0()

# Generated at 2022-06-25 21:32:19.018196
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        import sys, traceback
        print("test_compile_files raised exception -> ", file=sys.stderr)
        traceback.print_exc()

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:32:27.650832
# Unit test for function compile_files
def test_compile_files():
    ext = 'py'
    test_case_0()

    test_path = Path(__file__).parent / 'tests'
    src = test_path / 'src'
    dest = test_path / 'dest'
    target = CompilationTarget.js
    compile_files(src, dest, target)

    assert (dest / 'js' / 'a.js').exists()
    assert (dest / 'js' / 'b.js').exists()
    assert (dest / 'js' / 'node_modules' / 'js' / 'a.js').exists()
    assert (dest / 'js' / 'node_modules' / 'js' / 'b.js').exists()


# Generated at 2022-06-25 21:32:30.238900
# Unit test for function compile_files
def test_compile_files():
    import traceback
    try:
        test_case_0()
    except:
        traceback.print_exc()
        return False
    
    return True


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:40.941636
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:32:42.823225
# Unit test for function compile_files
def test_compile_files():
    # Stop executing function if it takes more than 2 seconds
    assert timeit.timeit(test_case_0, number = 10) <= 2.0

# Generated at 2022-06-25 21:32:47.221712
# Unit test for function compile_files
def test_compile_files():
    var_0 = ""
    var_1 = ""
    var_2 = CompilationTarget.CSS
    var_3 = None
    var_4 = compile_files(var_0, var_1, var_2, var_3)
    assert var_4.duration >= 0.0
    assert var_4.count == 0
    assert var_4.target == var_2
    assert len(var_4.dependencies) == 0


# Generated at 2022-06-25 21:32:50.004494
# Unit test for function compile_files
def test_compile_files():
    import pythran
    import os

    ref = pythran.CompilationResult(0, 0.0, pythran.CompilationTarget.CPython, [])

    assert ref == pythran.compile_files(os.devnull, os.devnull, pythran.CompilationTarget.CPython)

# Generated at 2022-06-25 21:32:56.521600
# Unit test for function compile_files

# Generated at 2022-06-25 21:32:57.907170
# Unit test for function compile_files
def test_compile_files():
    # Check that compilation_result_0 is a CompilationResult
    assert isinstance(compilation_result_0, CompilationResult)



# Generated at 2022-06-25 21:33:01.263910
# Unit test for function compile_files
def test_compile_files():
    var_0 = 'u'
    var_1 = 'u'
    var_2 = 'u'
    collection_0 = compile_files(var_0, var_1, var_2)
    collection_1 = compile_files('test.in', 'test.out', 'test', 'test')
    test_case_0()
    test_case_0()



# Generated at 2022-06-25 21:33:02.359286
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:33:08.703361
# Unit test for function compile_files
def test_compile_files():
    code_0 = 'temp = str(12) + str(34) + str(56)'
    code_1 = 'temp = ""'
    code_2 = "'temp = str(12) + str(34) + str(56)'"
    code_3 = "'t''e\'mp = s\'t\'r(12) + s\'t\'r(34) + s\'tr(56)'"
    code_4 = 'temp = str(12) + str(34) + str(56)'
    code_5 = 'temp = ""'
    code_6 = "'temp = str(12) + str(34) + str(56)'"
    code_7 = "'t''e\'mp = s\'t\'r(12) + s\'t\'r(34) + s\'tr(56)'"

# Generated at 2022-06-25 21:33:14.270841
# Unit test for function compile_files
def test_compile_files():
    # Default case
    var_0 = "";
    var_1 = "";
    var_2 = CompilationTarget.JS;
    var_3 = compile_files(var_0, var_1, var_2);
    # Type case
    var_0 = str();
    var_1 = str();
    var_2 = CompilationTarget.JS;
    var_3 = compile_files(var_0, var_1, var_2);
    # Type case
    var_0 = int();
    var_1 = int();
    var_2 = CompilationTarget.JS;
    var_3 = compile_files(var_0, var_1, var_2);

# Generated at 2022-06-25 21:33:38.012200
# Unit test for function compile_files
def test_compile_files():
    """Test case for compile_files"""
    var_0 = str()
    compilation_result_0 = compile_files(var_0, var_0, var_0)



# Generated at 2022-06-25 21:33:38.919174
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

test_compile_files()

# Generated at 2022-06-25 21:33:44.306903
# Unit test for function compile_files
def test_compile_files():
    input = "./tests/files"
    output = "./tests/files_compiled"
    target = 0  # JS
    expected_count = 1
    expected_time = 0.0
    expected_dependencies = []
    actual_result = compile_files(input, output, target)
    actual_count = actual_result.count
    actual_time = actual_result.time
    actual_dependencies = actual_result.dependencies

    assert actual_count == expected_count
    assert actual_time != 0.0
    assert len(actual_dependencies) == len(expected_dependencies)
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:33:52.367381
# Unit test for function compile_files
def test_compile_files():
    func = compile_files
    assert func('', '', CompilationTarget.PYTHON_TO_PYTHON) == CompilationResult(0, 0.0, CompilationTarget.PYTHON_TO_PYTHON, [])
    assert func('input/tests/input_for_test_0.py', 'output/tests/output_for_test_0.py', CompilationTarget.PYTHON_TO_PYTHON) == CompilationResult(1, 1.0179643630981445, CompilationTarget.PYTHON_TO_PYTHON, [])
    assert func('input/tests/input_for_test_8.py', 'output/tests/output_for_test_8.py', CompilationTarget.PYTHON_TO_PYTHON) == CompilationResult

# Generated at 2022-06-25 21:33:58.717290
# Unit test for function compile_files
def test_compile_files():
    import os, shutil
    from .exceptions import CompilationError, TransformationError
    from .utils import paths

    def assert_compilation_error(expected, actual):
        assert expected.path == actual.path
        assert expected.code == actual.code
        assert expected.first_line == actual.first_line
        assert expected.first_offset == actual.first_offset

    def assert_transformation_error(expected, actual):
        assert expected.path == actual.path
        assert expected.name == actual.name
        assert expected.tree == actual.tree
        assert expected.error == actual.error

    def assert_result(expected, actual):
        assert expected.count == actual.count
        assert expected.elapsed == actual.elapsed
        assert expected.target == actual.target
        assert expected.dependencies == actual.dependencies

   

# Generated at 2022-06-25 21:34:04.184258
# Unit test for function compile_files
def test_compile_files():
    import os
    # Dictionary key is '<input> <output> <target>' and value is expected result

# Generated at 2022-06-25 21:34:09.603620
# Unit test for function compile_files
def test_compile_files():
    import unittest
    from os import makedirs, path

    class CompileFilesCase(unittest.TestCase):
        def setUp(self):
            makedirs('test_data/temp', exist_ok=True)

        def tearDown(self):
            from shutil import rmtree

            rmtree('test_data/temp')

        def test_empty(self):
            self.assertEqual(compile_files('test_data/empty',
                                           'test_data/temp/empty',
                                           CompilationTarget.WASM),
                             CompilationResult(0, 0.0,
                                               CompilationTarget.WASM, []))


# Generated at 2022-06-25 21:34:15.393281
# Unit test for function compile_files
def test_compile_files():
    var_0 = ''
    var_1 = ''
    var_2 = ''
    compilation_result_0 = compile_files(var_0, var_1, var_2)



# Generated at 2022-06-25 21:34:19.850158
# Unit test for function compile_files
def test_compile_files():
    var_0 = str()
    try:
        var_1 = compile_files(var_0, var_0, var_0)
    except:
        var_1 = None
    assert var_1 is None



# Generated at 2022-06-25 21:34:27.347478
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(var_0, var_0, var_0).code_count
    assert compile_files(var_1, var_1, var_1).code_count
    assert compile_files(var_2, var_2, var_2).code_count
    assert compile_files(var_3, var_3, var_3).code_count
    assert compile_files(var_4, var_4, var_4).code_count
    assert compile_files(var_5, var_5, var_5).code_count
    assert compile_files(var_6, var_6, var_6).code_count
    assert compile_files(var_7, var_7, var_7).code_count
    assert compile_files(var_8, var_8, var_8).code_count
   