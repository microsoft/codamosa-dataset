

# Generated at 2022-06-25 21:30:10.147001
# Unit test for function compile_files
def test_compile_files():
    str_0 = '\\#31(/h&9cekr>K@*'
    int_0 = 2
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)

if __name__ == '__main__':
    test_case_0()
    test_compile_files()

# Generated at 2022-06-25 21:30:12.505064
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


# End of test case for compile_files

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:30:13.566147
# Unit test for function compile_files
def test_compile_files():
    assert callable(compile_files), "Expected compile_files to be callable."
    test_case_0()
    print("Test test_compile_files passes.")


# Generated at 2022-06-25 21:30:19.196050
# Unit test for function compile_files
def test_compile_files():
    # Passing basic parameter test case 'str_0', 'str_0', tuple_0
    str_0 = '\\#31(/h&9cekr>K@*'
    int_0 = 2
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    print("{}".format(compilation_result_0.count))
    print("{}".format(compilation_result_0.time))
    print("{}".format(compilation_result_0.target))
    print("{}".format(compilation_result_0.dependencies))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:30:22.792070
# Unit test for function compile_files
def test_compile_files():
    str_0 = '\\#31(/h&9cekr>K@*'
    int_0 = 2
    tuple_0 = (int_0, int_0)
    test_case_0()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:30:32.529408
# Unit test for function compile_files
def test_compile_files():
    # Get the names of the input and output directories
    input_dir = os.path.join(test_dir, "input_dir")
    output_dir = os.path.join(test_dir, "output_dir")
    # Load the lines from all python files in the input directory
    input_files = list()
    for file in os.listdir(input_dir):
        if file.endswith(".py"):
            with open(os.path.join(input_dir, file)) as f:
                input_files.append(f.readlines())
    # If there are no python files found in the input directory, it's a failure
    if not input_files:
        print("Error: No python files found")
        return
    # Compile the input files

# Generated at 2022-06-25 21:30:33.982774
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:30:41.094219
# Unit test for function compile_files
def test_compile_files():
    str_0 = '\\#31(/h&9cekr>K@*'
    int_0 = 2
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert (len(compilation_result_0.dependencies) == 0)
    assert (compilation_result_0.took == 0)
    assert (compilation_result_0.compiled == 0)
    assert (compilation_result_0.target == (2, 2))


# Generated at 2022-06-25 21:30:43.741785
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('input/unit_test.py', '/tmp/unit_test.py', 'py3mypy') == None


# Generated at 2022-06-25 21:30:47.417656
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Mocking of function compile_files

# Generated at 2022-06-25 21:30:55.973877
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input/unit_test.py'
    str_1 = 'input/unit_test.py'
    str_2 = 'input/unit_test.py'
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 21:31:05.382546
# Unit test for function compile_files
def test_compile_files():
    input_ = 'input/unit_test.py'
    output = 'input/unit_test.py'
    target = 'input/unit_test.py'
    root = 'input/unit_test.py'


# Generated at 2022-06-25 21:31:06.958290
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except CompilationError as error:
        assert False
    except TransformationError as error:
        assert False
    except Exception as error:
        assert False


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:13.848411
# Unit test for function compile_files
def test_compile_files():
    # Type error
    with raises(TypeError):
        compile_files(1, 2.5, 3.5)
    with raises(TypeError):
        compile_files(1, 2.5, 'target')
    with raises(TypeError):
        compile_files('input', 'output', 3.5)

    # Value error
    with raises(ValueError):
        compile_files('input', 'output', 'other')

    # Compile files
    assert compile_files('input', 'output', 'py2').target == 'py2'
    assert compile_files('input', 'output', 'py3').target == 'py3'
    assert compile_files('input', 'output', 'py2', 'root').root == 'root'
    assert compile_files('input', 'output', 'py3', 'root').root == 'root'

# Generated at 2022-06-25 21:31:18.159333
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input/unit_test.py'
    compilation_result_0 = compile_files(str_0, str_0, 'annotations')
    print(compilation_result_0)


if __name__ == '__main__':
    # test_compile_files()
    # test_case_0()
    pass

# Generated at 2022-06-25 21:31:32.418273
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input/unit_test.py'
    compilation_result_0 = compile_files(str_0, str_0, str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:31:34.573512
# Unit test for function compile_files
def test_compile_files():
    with pytest.raises(AssertionError):
        test_case_0()

# Generated at 2022-06-25 21:31:44.541588
# Unit test for function compile_files
def test_compile_files():
    # AssertionError: 'input/unit_test.py' not in 'input/unit_test.py'
    try:
        test_case_0()
    except AssertionError as e:
        print(e)
    else:
        raise RuntimeError('Expected AssertionError')

if __name__ == '__main__':
    import os
    import shutil

    cwd = os.path.dirname(os.path.abspath(__file__))
    output_dir = os.path.join(cwd, 'output')

    try:
        # Remove the output directory and all its contents
        shutil.rmtree(output_dir)
    except FileNotFoundError:
        # Directory does not exist
        pass

    import pprint

# Generated at 2022-06-25 21:31:51.560180
# Unit test for function compile_files
def test_compile_files():
    import random
    import string
    import os
    import tempfile
        
    paths = list(get_input_output_paths('input/unit_test.py', 'output/unit_test.py', 'root'))
    path_ = paths[0]
    
    file = open(path_.input, 'r+')
    content = file.read()
    file.seek(0, 0)

# Generated at 2022-06-25 21:31:58.466415
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os

    print('Testing compile_files', file=sys.stderr)
    module_path = os.path.dirname(__file__)
    path_0 = 'input/unit_test.py'
    str_0 = 'input/unit_test.py'
    str_1 = 'input/unit_test.py'
    str_2 = 'input/unit_test.py'
    compilation_result_0 = compile_files(str_0, str_1, str_2)
    assert isinstance(compilation_result_0, CompilationResult)
    print('Testing complete', file=sys.stderr)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:08.879975
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py') is not None
    assert compile_files('input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py') is not None
    assert compile_files('input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py') is not None
    assert compile_files('input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py') is not None
    assert compile_files(str_0, str_0, str_0, str_0) is not None

# Generated at 2022-06-25 21:32:16.508203
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import sys
    import os

    def test_function_0(input_, output, target):
        unit_test_dir = os.path.dirname(os.path.dirname(__file__))
        str_0 = os.path.join(unit_test_dir, input_)
        str_1 = os.path.join(unit_test_dir, output)
        compile_files(str_0, str_1, target)
        # Get the actual file content.
        unit_test_dir = os.path.dirname(os.path.dirname(__file__))
        str_2 = os.path.join(unit_test_dir, 'expected/main.js')
        with open(str_2) as f:
            str_3 = f.read()
        # Get the expected

# Generated at 2022-06-25 21:32:17.963316
# Unit test for function compile_files
def test_compile_files():
    with pytest.raises(CompilationError):
        test_case_0()

# Generated at 2022-06-25 21:32:23.012478
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import io

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        result = compile_files('a.py', 'b.py', 'c.py')
        assert(str(result) == "Executed 1 transformers in: 0.0s")
    finally:
        sys.stdout = saved_stdout
    

# Generated at 2022-06-25 21:32:30.530412
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input/unit_test.py'
    str_1 = 'input/unit_test.py'
    str_2 = 'input/unit_test.py'
    str_3 = 'input/unit_test.py'
    int_0 = 0
    int_1 = 1
    float_0 = 0.0
    # Make sure function returns CompilationResult
    assert isinstance(compile_files(str_0, str_1, str_2), CompilationResult)
    # Make sure the CompilationResult.count is correct
    assert compile_files(str_0, str_1, str_2).count == int_1
    assert compile_files(str_0, str_1, str_2).time == float_0
    # Make sure the CompilationResult.target is correct
    assert compile_files

# Generated at 2022-06-25 21:32:32.945929
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception as err:
        raise
    else:
        print('test_compile_files pass')

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:40.941515
# Unit test for function compile_files
def test_compile_files():
    # Test for output type: int
    assert isinstance(compile_files('input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py'), CompilationResult)

    # Test for output count: 1
    assert compile_files('input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py').count == 1

    # Test for output time: 0
    assert compile_files('input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py').time == 0

    # Test for output target: ""
    assert compile_files('input/unit_test.py', 'input/unit_test.py', 'input/unit_test.py').target == ""

    # Test for output dependencies: []
    assert compile_files

# Generated at 2022-06-25 21:32:42.822770
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception as e:
        print('test compile_files failed')
        print(e)

# Generated at 2022-06-25 21:32:50.087739
# Unit test for function compile_files
def test_compile_files():
    import os

    os.mkdir('test_compile_files')
    os.mkdir('test_compile_files/input')
    os.mkdir('test_compile_files/output')
    with open('test_compile_files/input/test_file.py', 'w') as fh:
        fh.write('print(1+1)')

    compile_files('test_compile_files/input', 'test_compile_files/output', 0)

    assert os.path.isfile('test_compile_files/output/test_file.py')
    with open('test_compile_files/output/test_file.py', 'r') as fh:
        assert fh.read() == 'print(1 + 1)\n'


# Generated at 2022-06-25 21:32:55.208221
# Unit test for function compile_files
def test_compile_files():
    # Python 2
    import sys
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    target_path = sys.argv[3]
    compilation_result = compile_files(input_path, output_path, target_path)

    # Python 3
    from pathlib import Path
    input_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    target_path = Path(sys.argv[3])
    compilation_result = compile_files(input_path, output_path, target_path)

# Generated at 2022-06-25 21:33:01.489686
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/input/'
    output = 'expected/'
    target = 'test_target'
    root = '/'
    assert compile_files(input_, output, target, root) == 'CompilationResult'


# Generated at 2022-06-25 21:33:05.769855
# Unit test for function compile_files
def test_compile_files():
    input_ = 'sample/input/main.js'
    output = 'sample/output/main.py'
    target = CompilationTarget.Makespan
    root = None
    result = compile_files(input_, output, target, root)
    print(result)
    assert result.time > 0
    assert result.executed > 0
    assert result.target == CompilationTarget.Makespan
    if result.dependencies:
        assert len(result.dependencies) > 0

# Generated at 2022-06-25 21:33:12.061493
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file for testing
    tfile = open(os.path.join(tmp_dir, "test_file.py"), "w")
    tfile.write("# line 1\n")
    tfile.write("def foo(x):\n")
    tfile.write("    return x*5\n")
    tfile.write("    \n")
    tfile.write("def bar(x, y):\n")
    tfile.write("    return foo(x)*y\n")
    tfile.write("\n")
    tfile.write("print(foo(4))\n")
    tfile.write("print(bar(4, 5))\n")
    t

# Generated at 2022-06-25 21:33:13.454492
# Unit test for function compile_files
def test_compile_files():
    # Test case test_case_0
    str_0 = 'expected/main.js'

# Test case test_case_1

# Generated at 2022-06-25 21:33:20.872190
# Unit test for function compile_files

# Generated at 2022-06-25 21:33:25.916766
# Unit test for function compile_files
def test_compile_files():
    path_0 = 'examples/simple'
    path_1 = 'expected'
    path_2 = 'built'
    try:
        target_0 = CompilationTarget.ES5
        try:
            [_, _] = compile_files(path_2, path_1, target_0, path_0)
            return True
        except Exception as e:
            str_0 = str(e)
            print(str_0)
            return False
    except (Exception, e):
        str_0 = str(e)
        print(str_0)
        return False


# Generated at 2022-06-25 21:33:27.259051
# Unit test for function compile_files
def test_compile_files():

    test_case_0()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:33:34.851957
# Unit test for function compile_files
def test_compile_files():
    paths = get_input_output_paths("src/", "dist/", "src/")
    count = 0
    for paths in get_input_output_paths("src/", "dist/", "src/"):
        count += 1
    assert(count == 7)

# Generated at 2022-06-25 21:33:38.043564
# Unit test for function compile_files
def test_compile_files():
    # If
    target = CompilationTarget.ES6
    root = "abspath(__file__)"

    # When
    compile_files(input_, output, target, root)

    # Then
    assert str_0 == "expected/main.js"

test_compile_files()

# Generated at 2022-06-25 21:33:39.618457
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(str_0, str_0, str_0, str_0)
    assert( result == str_0 )




# Generated at 2022-06-25 21:33:48.279230
# Unit test for function compile_files
def test_compile_files():
    source_path_0 = 'tests/test_cases/test_case_0/main.py'
    dest_path_0 = 'tests/test_cases/test_case_0/expected/main.js'
    result_0 = compile_files(source_path_0, dest_path_0, CompilationTarget.ES5)
    assert result_0.compiled == 1
    assert result_0.time > 0
    assert result_0.target == CompilationTarget.ES5
    assert result_0.dependencies == []
    # assert result_0 == test_case_0()


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:33:48.993286
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-25 21:33:50.028441
# Unit test for function compile_files
def test_compile_files():
    assert test_case_0() == 'expected/main.js'

# Generated at 2022-06-25 21:33:52.598923
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'expected/main.js'
    str_1 = 'expected/main.js'
    str_2 = 'expected/main.js'

    assert str_0 == str_1
    assert str_0 == str_2
    assert str_1 == str_2

# Generated at 2022-06-25 21:33:55.023783
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    test_case_name = ['test_case_0']
    test_case_name.pop()
    while test_case_name:
        test_case()
        test_case_name.pop()


# Generated at 2022-06-25 21:33:58.432976
# Unit test for function compile_files
def test_compile_files():
    target_0 = CompilationTarget.JavaScript
    result_0 = compile_files('./examples/simple/main.py', './output/main.js', target_0)
    assert True
    assert (result_0.count == 1)
    assert (result_0.target == target_0)
    assert (result_0.target == target_0)
    assert (result_0.dependencies == [])


# Generated at 2022-06-25 21:34:00.187058
# Unit test for function compile_files
def test_compile_files():
    input_ = 'example_app/src'
    output = 'example_app/python'
    target = 1
    root = None

    result = compile_files(input_, output, target, root)


# Generated at 2022-06-25 21:34:05.435574
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'expected/main.js'
    str_1 = 'expected/module.js'
    str_2 = 'expected/submodule.js'
    str_3 = 'expected/submodule_missing.js'
    str_4 = 'expected/submodule_problematic.js'

    files = compile_files('tests/file_tests/input', 'tests/file_tests/output', 'ES5')

    str_5 = 'tests/file_tests/output/main.js'
    str_6 = 'tests/file_tests/output/module.js'
    str_7 = 'tests/file_tests/output/submodule.js'
    str_8 = 'tests/file_tests/output/submodule_missing.js'

# Generated at 2022-06-25 21:34:07.756340
# Unit test for function compile_files
def test_compile_files():
    # Testing wether the function is raising an exception or not.
    try:
        compile_files('', '', CompilationTarget.JAVASCRIPT)
    except CompilationError:
        pass
    except Exception:
        # An unexpected exception happened here
        raise AssertionError('Unexpected exception')
    

# Generated at 2022-06-25 21:34:15.135064
# Unit test for function compile_files
def test_compile_files():
    with open('tests/expected/main.js', 'rb') as f:
        expected = f.read()
    actual = compile_files('tests/fixtures', 'tests/results', CompilationTarget.BROWSER)
    assert actual.code == expected

if __name__ == '__main__':
    import sys

    test_compile_files()
    sys.exit(0)

# Generated at 2022-06-25 21:34:27.302458
# Unit test for function compile_files
def test_compile_files():

    # Test without root
    str_0 = '../../input/unit_test.py'
    str_1 = '../../output/unit_test.py'
    compilation_result_0 = compile_files(str_0, str_1, str_0, None)

    assert(compilation_result_0.count == 1)
    assert(compilation_result_0.target == '../../input/unit_test.py')

    # Test with root
    str_2 = '../../input/unit_test.py'
    str_3 = '../../output/unit_test.py'
    str_4 = '../../input'
    compilation_result_1 = compile_files(str_2, str_3, str_2, str_4)

    assert(compilation_result_1.count == 1)


# Generated at 2022-06-25 21:34:27.986322
# Unit test for function compile_files
def test_compile_files():
    test_case_0()



# Generated at 2022-06-25 21:34:39.678797
# Unit test for function compile_files
def test_compile_files():
    import sys
    import io
    import contextlib
    from mock import patch

    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    with patch('sys.argv', ['compiler.py', 'input', 'output', 'target']):
        # Call the function
        with stdoutIO() as s:
            test_case_0()
        # At this point check the out, assert, etc.
        output = s.getvalue().strip()


# Generated at 2022-06-25 21:34:42.086119
# Unit test for function compile_files
def test_compile_files():
    # Call function
    compilation_result_0 = compile_files('input/unit_test.py', 'output/unit_test.py', 'target')

    assert(compilation_result_0.file_count == 1)
    assert(compilation_result_0.time > 0)
    assert(compilation_result_0.target is 'target')
    assert(compilation_result_0.dependencies == [])

# Generated at 2022-06-25 21:34:49.485181
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input/unit_test.py'
    compilation_result_0 = compile_files(str_0, str_0, str_0)

# Unit test runtime output
# Note: the expected output includes the current path
#    and the following runtime output:
#    Compiling "input/unit_test.py"
#    Use transformer "FunctionTransformer"
#    Tree changed:
#    Module(body=[
#    Import(names=[
#    alias(
#    name='is_callable',
#    asname=None)])])
#    Code changed:
#    import is_callable as is_callable
#    Compiling "input/unit_test.py"
#    Use transformer "FunctionTransformer"
#    Tree not changed
#    Use transformer "ImportTransformer"
#    Tree not changed

# Generated at 2022-06-25 21:34:58.059567
# Unit test for function compile_files
def test_compile_files():
    import sys
    import typing
    import pytest
    from tests.utils import capture_stdout

    with pytest.raises(CompilationError) as exc:
        compile_files('', '', CompilationTarget.to_js)
    assert isinstance(exc.value.exception, TypeError)

    def _test(input_: str, output: str, target: str, *,
              root: Optional[str] = None) -> typing.Tuple[CompilationResult, str]:
        with capture_stdout() as s:
            result = compile_files(input_, output, target, root)
        print(result)
        return result, s.getvalue()

    # Test with no source files
    result, out = _test('input/non-existing-dir', 'output', CompilationTarget.to_py)

# Generated at 2022-06-25 21:35:04.420900
# Unit test for function compile_files
def test_compile_files():
    mock_input = 'input/unit_test.py'
    mock_output = 'output/unit_test.py'
    mock_target = 'py'
    mock_count = 9
    mock_time = 1.2
    mock_result = CompilationResult(mock_count, mock_time, mock_target, [])

    mock_get_input_output_paths = MagicMock()
    mock_get_input_output_paths.side_effect = [
        [InputOutput(mock_input, mock_output) for _ in range(mock_count)]
    ]

    with patch('main.compiler.get_input_output_paths', mock_get_input_output_paths):
        mock_compile_file = MagicMock(return_value=[])

# Generated at 2022-06-25 21:35:09.477398
# Unit test for function compile_files
def test_compile_files():
    # test_case_0
    str_0 = 'input/unit_test.py'
    compilation_result_0 = compile_files(str_0, str_0, CompilationTarget.UNIT_TEST)
    # Assertions
    assert compilation_result_0.target == CompilationTarget.UNIT_TEST
    assert compilation_result_0.processed == 1
    assert compilation_result_0.elapsed > 0
    assert compilation_result_0.dependencies == []
    # test_case_1
    str_0 = 'input/unit_test.py'
    str_1 = 'input/package_test.py'
    str_2 = 'input/functional_test_a.py'
    str_3 = 'input/functional_test_b.py'
    compilation_result_1 = compile_

# Generated at 2022-06-25 21:35:13.789630
# Unit test for function compile_files
def test_compile_files():
    assert test_case_0() is None

# Generated at 2022-06-25 21:35:15.454239
# Unit test for function compile_files
def test_compile_files():
    test_case_0()