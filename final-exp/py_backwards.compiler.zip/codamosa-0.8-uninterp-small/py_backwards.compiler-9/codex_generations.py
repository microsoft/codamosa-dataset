

# Generated at 2022-06-25 21:30:14.712646
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./input/', './output/', CompilationTarget.PY2) == CompilationResult(
        0, 6.079999923706055, CompilationTarget.PY2, [])
    assert compile_files('./tests/data/complex_class.py', './output/', CompilationTarget.PY2) == CompilationResult(
        1, 0.17000000029802322, CompilationTarget.PY2, [])
    assert compile_files('./tests/data/two_files', './output/', CompilationTarget.JYTHON) == CompilationResult(
        2, 0.23899998664855957, CompilationTarget.JYTHON, [])

# Generated at 2022-06-25 21:30:18.715110
# Unit test for function compile_files
def test_compile_files():
    # call compile_files
    result = compile_files("/home/robert/Documents/nuitka-master", "/home/robert/Documents/nuitka-master", "JUNK")
    assert result.count == 1, "Result.count is incorrect"
    assert result.dependencies == "none", "Result.dependencies is incorrect"
    assert result.target == "JUNK", "Result.target is incorrect"
    assert result.time == 0.0, "Result.time is incorrect"

# Generated at 2022-06-25 21:30:28.969394
# Unit test for function compile_files
def test_compile_files():
    str_0 = '\x0c\x1e0\x1b\x01\x00\x0c\x0e\x17\x00\x0c\x04\x00\x1b\x0c\x00'
    str_1 = '\x0c\x1e0\x1b\x01\x00\x0c\x14\x17\x00\x08\x04\x00\x1b\x0c\x00'
    int_0 = 297
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_1, tuple_0)
    tuple_1 = (int_0, int_0)

# Generated at 2022-06-25 21:30:31.063172
# Unit test for function compile_files
def test_compile_files():
    assert(test_case_0() == True)

# Generated at 2022-06-25 21:30:36.446153
# Unit test for function compile_files
def test_compile_files():
    print("test_compile_files")
    str_0 = 'TpY\x0b+*$8A'
    int_0 = 297
    tuple_0 = (int_0, int_0)
    test_case_0()


# Test
if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:30:37.573896
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


# Generated at 2022-06-25 21:30:46.069500
# Unit test for function compile_files
def test_compile_files():
    str_0 = '<P\x17\x1f\t\n\tS\x0c'
    str_1 = '>\n'
    int_0 = 335
    int_1 = 298
    tuple_0 = (int_0, int_1)
    tuple_1 = (int_0, int_1)
    tuple_2 = (int_1, str_1, tuple_0)
    compilation_result_0 = compile_files(str_1, str_1, tuple_0)
    try:
        compilation_result_1 = compile_files(str_0, str_1, tuple_1)
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-25 21:30:47.311003
# Unit test for function compile_files
def test_compile_files():
    assert False, 'Not implemented'

# Generated at 2022-06-25 21:30:58.277788
# Unit test for function compile_files
def test_compile_files():
    # Inputs
    str_0 = 'TpY\x0b+*$8A'
    str_1 = 'P\t_\x0b\x0b#\x19\x1d\x1c\x1e'
    #str_2 = 'P\t_\x0b\x0b#\x19\x1d\x1c\x1e'
    int_0 = 297
    tuple_0 = (int_0, int_0)
    tuple_1 = (int_0, int_0)
    #tuple_2 = (int_0, int_0)

    compilation_result_0 = compile_files(str_0, str_1, tuple_0)
    #compilation_result_1 = compile_files(str_0, str_1, tuple_

# Generated at 2022-06-25 21:30:59.121149
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:31:06.131086
# Unit test for function compile_files
def test_compile_files():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 21:31:09.106741
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except IOError as e:
        print(e)
    except Exception as e:
        print(e)

# Test and run
if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:10.243094
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


test_compile_files()

# Generated at 2022-06-25 21:31:11.839932
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-25 21:31:12.979735
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:31:32.418534
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input'
    str_1 = 'output'
    int_0 = 10
    int_1 = 1
    tuple_0 = (int_1, int_0)
    compilation_result_0 = compile_files(str_0, str_1, tuple_0)
    assert abs(compilation_result_0.execution_time - 0.0) <= 1e-06
    assert compilation_result_0.files_count == 1
    assert compilation_result_0.target == tuple_0
    assert compilation_result_0.dependencies == ['logging', 'os', 'shutil', 'tempfile', 'argparse', 'typing', '__future__', 'astunparse', '__main__']
    
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:31:43.542138
# Unit test for function compile_files

# Generated at 2022-06-25 21:31:46.404779
# Unit test for function compile_files
def test_compile_files():
    assert(test_case_0())


CompilationTarget.test_compile_files = CompilationTarget
CompilationResult.test_compile_files = CompilationResult
test_compile_files()

# Generated at 2022-06-25 21:31:47.957107
# Unit test for function compile_files
def test_compile_files():
    print ('test_compile_files ... ')
    test_case_0()
    print ('done')


# Main program

# Generated at 2022-06-25 21:31:50.519478
# Unit test for function compile_files
def test_compile_files():
    # Test for function compile_files
    str_0 = 'TpY\x0b+*$8A'
    int_0 = 297
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)

# Generated at 2022-06-25 21:32:07.842699
# Unit test for function compile_files
def test_compile_files():
    with mock.patch('compiler.files.get_input_output_paths', return_value=[
        InputOutput('', '')
    ]):
        with mock.patch('compiler._compile_file', return_value=[]) as _compile_file_mock:
            assert compile_files('', '', (1, )) == CompilationResult(
                1, _compile_file_mock.return_value, (1, ), _compile_file_mock.return_value)
            _compile_file_mock.assert_called_once_with(InputOutput('', ''), (1, ))


# Generated at 2022-06-25 21:32:09.282848
# Unit test for function compile_files
def test_compile_files():
    int_0 = 0
    compilation_result_0 = compile_files(int_0, int_0, int_0)

# Generated at 2022-06-25 21:32:11.018773
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:18.573733
# Unit test for function compile_files
def test_compile_files():
    # Test 0
    print('test 0')
    str_0 = 'tests/test_data/test_case_0_in'
    int_0 = 1
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert(compilation_result_0.files == 1)
    assert(compilation_result_0.s == 0.0)
    assert(compilation_result_0.target == tuple_0)
    assert(compilation_result_0.dependencies == ['typing'])

    # Test 1
    print('test 1')
    str_1 = 'tests/test_data/test_case_1_in'
    int_1 = 2

# Generated at 2022-06-25 21:32:20.546461
# Unit test for function compile_files
def test_compile_files():
    test_file = 'test.py'
    target = CompilationTarget("js")
    compile_files(test_file, test_file, target)


# Generated at 2022-06-25 21:32:23.292564
# Unit test for function compile_files
def test_compile_files():
    # TODO: Implement this test
    print('Testing compile_files')
    test_case_0()
    print('Test case 0 succeeded')


# Generated at 2022-06-25 21:32:29.456185
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'TpY\x0b+*$8A'
    int_0 = 297
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert isinstance(compilation_result_0, CompilationResult)
    assert compilation_result_0.target == (int_0, int_0)
    assert isinstance(compilation_result_0.dependencies, list)
    assert compilation_result_0.count == 0
    assert isinstance(compilation_result_0.duration, float)


# Generated at 2022-06-25 21:32:35.554549
# Unit test for function compile_files
def test_compile_files():
    print('Test #1')
    print('Expected Output: \n[CompilationResult(count=0, time=0.0, target=<CompilationTarget.STAGED_OPERABLE_BOOL_FUNCTIONS: 2>, dependencies=[]), CompilationResult(count=0, time=0.0, target=<CompilationTarget.STAGED_OPERABLE_NUM_FUNCTIONS: 3>, dependencies=[])]')
    print('Actual Output:')
    try:
        print(test_case_0())
    except Exception as e:
        print('Exception:', str(e))

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:41.713358
# Unit test for function compile_files
def test_compile_files():
    # Creating dummy files for unit test
    import os, tempfile
    input_ = os.path.join(tempfile.gettempdir(), "test.py")
    with open(input_, 'w') as f:
        f.write('x = 1\n')
    output = "output.py"
    target = (0, 1)

    # Get compilation_result
    compilation_result = compile_files(input_, output, target)

    # Reading output file
    with open(output) as f:
        result = f.read()

    # Checking the result
    assert result == 'x = 1\n'

# Generated at 2022-06-25 21:32:47.002894
# Unit test for function compile_files
def test_compile_files():
    try:
        os.mkdir(path.join(path.dirname(__file__), 'test-data'))
    except FileExistsError:
        pass
    try:
        test_case_0()
    except:
        raise
    finally:
        try:
            os.rmdir(path.join(path.dirname(__file__), 'test-data'))
        except:
            pass

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:33:11.787113
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'TpY\x0b+*$8A'
    int_0 = 297
    tuple_0 = (int_0, int_0)
    assert compile_files(str_0, str_0, tuple_0) == None


# Generated at 2022-06-25 21:33:13.396971
# Unit test for function compile_files
def test_compile_files():
    test_case_0()
    print("Unit tests for function compile_files have passed.")

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:33:15.973605
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'TpY\x0b+*$8A'
    int_0 = 297
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    print('Tests passed!')

# Generated at 2022-06-25 21:33:23.625563
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'b\n'
    tuple_0 = (None, None)
    int_0 = 3
    int_1 = 144
    tuple_0 = (int_0, int_1)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    str_1 = '\x0c'
    int_2 = 90
    int_3 = 45
    tuple_1 = (int_2, int_3)
    compilation_result_1 = compile_files(str_1, str_1, tuple_1)
    str_2 = 'v'
    int_4 = 207
    int_5 = 111
    tuple_2 = (int_4, int_5)

# Generated at 2022-06-25 21:33:32.218542
# Unit test for function compile_files

# Generated at 2022-06-25 21:33:36.634621
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        print("Exception in case 0")
        raise

test_compile_files()

# Generated at 2022-06-25 21:33:39.110489
# Unit test for function compile_files
def test_compile_files():
    # setup
    input_ = "/path/to/input/file"
    output = "/path/to/output/file"
    target = CompilationTarget.PRODUCTION
    root = None

    # Test body
    compile_files(input_, output, target)

# Generated at 2022-06-25 21:33:40.416580
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./tests/test1/input/src', './tests/test1/output', 'ts')
#     test_case_0()

# Generated at 2022-06-25 21:33:44.444180
# Unit test for function compile_files
def test_compile_files():
    # Dummy input and output path
    input_ = 'dummy_input'
    output = 'dummy_output'

    # Compilation target doesn't matter at this point
    target = CompilationTarget.WEB
    compilation_result = compile_files(input_, output, target)

    # Check that number of compiled files is 0
    assert compilation_result.compile_count == 0

    # Check that all dependencies are empty
    assert compilation_result.dependencies == []

# Generated at 2022-06-25 21:33:52.510731
# Unit test for function compile_files
def test_compile_files():
    template = ('\x16s\x1bH\x1e\x0bt\x04\x07\x17\x1a\x1bx\x0b\x06\x0c\x07\x0b'
                '\x1f\x12\x0b\x0dx\x0b\x06\x0c\x07\x0b\x1f\x12\x0b\x0ds\x1bH\x1e'
                '\x0b\x10\x07!\x1f\x12\x0b\x0d')
    int_0 = 0