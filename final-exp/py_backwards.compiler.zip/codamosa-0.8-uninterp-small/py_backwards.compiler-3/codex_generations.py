

# Generated at 2022-06-25 21:33:01.014779
# Unit test for function compile_files
def test_compile_files():
    files_0 = "test-data/test_files.tar"
    output_dir = "test-data/test_files_out"
    result = compile_files(files_0, output_dir, CompilationTarget.PYTHON_35)
    assert result.files == 1
    assert result.duration > 0
    assert result.target == CompilationTarget.PYTHON_35
    assert result.dependencies == ['/usr/local/lib/python3.5/dist-packages/typed_ast/__init__.py']

# Generated at 2022-06-25 21:33:07.350451
# Unit test for function compile_files
def test_compile_files():
    from random import random, randint
    from pathlib import Path
    from distutils import dir_util

    # Prepare test data
    source_path = Path('sources')
    correct_output_path = Path('correct_outputs')
    output_path = Path('outputs')
    ini_path = Path('tests.ini')
    tests = []

    # Read all tests
    with ini_path.open() as f:
        current_test = {}

        for line in f.readlines():
            line = line.strip()

            # Skip comments and empty lines
            if not line or line[0] == '#':
                continue

            # Parse test data
            if not line.startswith(' '):
                test_name, input_files, output_files, compilation_target = line.split('=')
               

# Generated at 2022-06-25 21:33:09.785643
# Unit test for function compile_files
def test_compile_files():
    path = Path(__file__).parent / 'files' / 'input'
    input_ = path.resolve().as_posix()
    output = path.parent / 'output'
    target = CompilationTarget.PYTHON_3
    compile_files(input_, output, target)

# Generated at 2022-06-25 21:33:16.545549
# Unit test for function compile_files
def test_compile_files():
    import random
    import string
    import os

    def _make_random_string(length):
        return ''.join(
            random.choice(string.ascii_lowercase) for _ in range(length))

    _input_dir = './' + _make_random_string(10)
    _output_dir = './' + _make_random_string(10)
    _input_file_name = _make_random_string(10)
    _output_file_name = _make_random_string(10)
    _input_file_path = os.path.join(_input_dir, _input_file_name)
    _output_file_path = os.path.join(_output_dir, _output_file_name)

# Generated at 2022-06-25 21:33:18.640662
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:33:25.165156
# Unit test for function compile_files
def test_compile_files():
    import dill
    import tempfile
    import shutil

    in_dir = tempfile.mkdtemp()
    out_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 21:33:28.351771
# Unit test for function compile_files
def test_compile_files():
    input_ = "./in.py"
    output = "./out.py"
    target = (None, None)
    root = "."
    result = compile_files(input_, output, target, root)

    assert result.total_files is 1
    assert result.compile_time is not None
    assert result.target == target
    assert result.dependencies == []


# Generated at 2022-06-25 21:33:34.854753
# Unit test for function compile_files
def test_compile_files():
    int_0 = 7193
    str_0 = 'yTvTb\n'
    str_1 = 'iL-BGNmD~V!q\n^G'
    int_1 = 1848
    tuple_0 = (int_0, int_1)
    int_2 = compile_files(str_1, str_1, tuple_0)
    print('Expected:')
    print('\t' + str(6))
    print('Received:')
    print('\t' + str(int_2))
    str_3 = 'yTvTb\n'
    int_3 = compile_files(str_3, str_3, tuple_0)
    print('Expected:')
    print('\t' + str(6))
    print('Received:')
   

# Generated at 2022-06-25 21:33:36.209635
# Unit test for function compile_files
def test_compile_files():
    assert callable(compile_files)

test_case_0()

# Generated at 2022-06-25 21:33:38.224104
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception as e:
        raise Exception(str(e))

if __name__=='__main__':
    test_compile_files()

# Generated at 2022-06-25 21:37:22.613112
# Unit test for function compile_files
def test_compile_files():
    # setup
    str_0 = 'test-data/test_files.tar'
    str_1 = 'test-data/test_files_out'
    # test
    test = compile_files(str_0, str_1, CompilationTarget('script', '3.0'))
    # assertions
    assert test.target.version == '3.0'
    assert test.target.type == 'script'
    assert test.duration > 0
    assert test.file_count > 0
    assert len(test.dependencies) > 0

# Generated at 2022-06-25 21:37:28.272795
# Unit test for function compile_files
def test_compile_files():
    path = '/home/pascal/project/python-3.8-branch/build/bin/python'
    args = ['/home/pascal/project/python-3.8-branch/Tools/compiler/compileall.py', '-f', '/home/pascal/project/python-3.8-branch/Lib', '/home/pascal/project/python-3.8-branch/build/lib/python3.8']

# Generated at 2022-06-25 21:37:34.979809
# Unit test for function compile_files
def test_compile_files():
    # We are going to compile the test files found in the test_files directory.
    # this data was taken from an actual user test case
    # To run this unit test, you need the test_files.tar file from
    # https://drive.google.com/open?id=1QxKb8VvY2Zth36hUhA4Fg_p-Xl-IySbS
    # Place test_files.tar in test-data/test_files.tar
    # Once this is done, run this test
    str_0 = 'test-data/test_files.tar'
    str_1 = 'test-data/test_files_out'
    test_files = tarfile.open(str_0)
    test_files.extractall('test-data/test_files')
    test_files.close

# Generated at 2022-06-25 21:37:40.062756
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'test-data/test_files.tar'
    str_1 = 'test-data/test_files_out'
    str_2 = 'test-data/test_files_out/test_files/test_data/test_files_out'
    str_3 = 'test-data/test_files_out/test_files/test_data/test_files_out/test0.py'
    str_4 = 'test-data/test_files_out/test_files/test_data/test_files_out/test1.py'
    str_5 = 'test-data/test_files_out/test_files/test_data/test_files_out/test2.py'

    ret = compile_files(str_0, str_1, 'a')

    assert ret.count == 3

# Generated at 2022-06-25 21:37:44.970194
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'test-data/test_files.tar'
    str_1 = 'test-data/test_files_out'
    CompilationTarget_0 = CompilationTarget.AOT
    test_compile_files_0 = compile_files(str_0, str_1, CompilationTarget_0)
    test_compile_files_1 = CompilationResult(1, 0.010029077529907227,
                                          CompilationTarget.AOT, [])
    if (test_compile_files_0 != test_compile_files_1):
        print('Expected:', test_compile_files_1, sep='\n')
        print('Received:', test_compile_files_0, sep='\n')
        return False
    return True


# Generated at 2022-06-25 21:37:47.266745
# Unit test for function compile_files
def test_compile_files():
    assert True == True

# Test case for function compile_files

# Generated at 2022-06-25 21:37:49.188723
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception:
        assert False


if __name__ == '__main__':
    print(compile_files('test-data/test_files', 'test-data/test_files_out',
                        CompilationTarget.ES5))

# Generated at 2022-06-25 21:37:50.434624
# Unit test for function compile_files
def test_compile_files():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()



# Generated at 2022-06-25 21:37:52.693267
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test-data/test_files.py'
    output = 'test-data/test_files_out'
    target = CompilationTarget.PYTHON
    result = compile_files(input_, output, target)

    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['os', 'cloudpickle', 'typing', 'ast', 'sys', 'inspect']


# Generated at 2022-06-25 21:37:54.829833
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'test-data/test_files.tar'
    str_1 = 'test-data/test_files_out'
    int_2 = 2
    str_3 = 'test-data/test_files_out/'
    compile_files(str_0, str_1, int_2, str_3)