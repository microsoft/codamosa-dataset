

# Generated at 2022-06-25 21:30:05.749147
# Unit test for function compile_files
def test_compile_files():
    str_0 = '_zJF3!*5v/'
    str_1 = '?N`)}!~g=?'
    tuple_0 = None
    try:
        test_case_0()
    except TransformationError as e:
        print(e)
    except CompilationError as e:
        print(e)

# Generated at 2022-06-25 21:30:09.849388
# Unit test for function compile_files
def test_compile_files():
    print("Testing compile_files")

    try:
        test_case_0()
    except:
        print("Error in test case 0")


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:30:17.141484
# Unit test for function compile_files
def test_compile_files():
    import dill
    from io import StringIO

    def mock_get_input_output(input_, output):
        return [InputOutput(Path(''), Path('./cache/examples/__init__.py'))]
    with mock.patch('phython.compiler.files.get_input_output_paths',
                    side_effect=mock_get_input_output):
        out = StringIO()
        with contextlib.redirect_stdout(out):
            test_case_0()

# Generated at 2022-06-25 21:30:19.204004
# Unit test for function compile_files
def test_compile_files():
    filename = 'tests/data/foo.py'

# Generated at 2022-06-25 21:30:22.193252
# Unit test for function compile_files
def test_compile_files():
    a = compile_files('./src/', './dst/', 1, None)
    print(a.elapsed, a.target, a.files_count)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:30:23.036404
# Unit test for function compile_files
def test_compile_files():
    assert True


# Generated at 2022-06-25 21:30:24.841706
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


# Generated at 2022-06-25 21:30:25.879627
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:30:27.784802
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: {}'.format(e))

# Generated at 2022-06-25 21:30:36.399582
# Unit test for function compile_files
def test_compile_files():
    str_0 = '{input}'
    str_1 = '{output}'
    tuple_0 = CompilationTarget.SYNC_TO_ASYNC
    try:
        assert(compile_files(str_0, str_1, tuple_0))
    except Exception as e:
        print(e)
    assert(True)

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:30:42.801408
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(str, str, CompilationTarget.PRODUCTION) is not None

# Generated at 2022-06-25 21:30:50.335194
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'code.py'
    str_1 = 'code.js'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)
    assert isinstance(compilation_result_0, CompilationResult)



# Generated at 2022-06-25 21:31:01.118419
# Unit test for function compile_files
def test_compile_files():
    filename = '%s/test.py' % (os.path.dirname(os.path.realpath(__file__)))
    input_dir = '%s/input' % (os.path.dirname(os.path.realpath(__file__)))
    output_dir = '%s/output' % (os.path.dirname(os.path.realpath(__file__)))
    root_dir = '%s/../../bin' % (os.path.dirname(os.path.realpath(__file__)))
    compile_files(filename, output_dir, 0, root_dir)
    with open(output_dir + '/test.py') as f:
        text = f.read()


# Generated at 2022-06-25 21:31:09.709768
# Unit test for function compile_files
def test_compile_files():
    print('Unit test for function compile_files')
    assert compile_files('test_input/test_case_0', 'test_output/test_case_0', CompilationTarget.C) == CompilationResult(1, 0.0004261493682861328, CompilationTarget.C, [])
    assert compile_files('test_input/test_case_1', 'test_output/test_case_1', CompilationTarget.CPP) == CompilationResult(1, 0.0043239593505859375, CompilationTarget.CPP, [])
    assert compile_files('test_input/test_case_2', 'test_output/test_case_2', CompilationTarget.CPYTHON) == CompilationResult(1, 0.0015141963958740234, CompilationTarget.CPYTHON, [])


# Generated at 2022-06-25 21:31:15.446380
# Unit test for function compile_files
def test_compile_files():
    str_0 = '_zJF3!*5v/'
    str_1 = '?N`)}!~g=?'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)
    print('compilation_result_0.count: ', compilation_result_0.count)
    print('compilation_result_0.time: ', compilation_result_0.time)
    print('compilation_result_0.target: ', compilation_result_0.target)
    print('compilation_result_0.dependencies')
    for element in compilation_result_0.dependencies:
        print('element: ', element)

#for i in range(10):
#    test_compile_files()

# Generated at 2022-06-25 21:31:32.418568
# Unit test for function compile_files
def test_compile_files():
    abs_path = os.path.abspath(__file__)
    dname = os.path.dirname(abs_path)
    os.chdir(dname)

    temp_path_1 = "temp_1.py"
    temp_path_2 = "temp_2.py"
    output_path_1 = "output_1.py"
    output_path_2 = "output_2.py"
    with open(temp_path_1, "w") as f:
        f.write("def foo(a) -> str :\n    return '123'")
    with open(temp_path_2, "w") as f:
        f.write("#from temp_1.py import foo")

    test_case_0()

    os.remove(temp_path_1)

# Generated at 2022-06-25 21:31:43.543257
# Unit test for function compile_files
def test_compile_files():
    from random import randint
    from unittest import TestCase

    class Test_compile_files(TestCase):
        def test_0(self):
            str_0 = '_zJF3!*5v/'
            str_1 = '?N`)}!~g=?'
            tuple_0 = None
            compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)

        def test_1(self):
            str_0 = 'WV`[5K(yE'
            str_1 = 'EkX#r%,BZ6'
            tuple_0 = None
            compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)


# Generated at 2022-06-25 21:31:44.303569
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:31:46.915002
# Unit test for function compile_files
def test_compile_files():
    test_case_0()
    # print(compilation_result_0)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:47.926251
# Unit test for function compile_files
def test_compile_files():
  assert callable(compile_files)
  test_case_0()

# Generated at 2022-06-25 21:32:00.944316
# Unit test for function compile_files
def test_compile_files():
    """
    Unit test for function compile_files
    """
    input_str = '/Users/jane/Desktop/typesense/src'
    output_str = '/Users/jane/Desktop/typesense/build/'
    target_tuple = None
    compilation_result_0 = compile_files(input_str, output_str, target_tuple, input_str)

# Generated at 2022-06-25 21:32:04.028713
# Unit test for function compile_files
def test_compile_files():
    str_0 = '_zJF3!*5v/'
    str_1 = '?N`)}!~g=?'
    tuple_0 = None
    try:
        compile_files(str_0, str_1, tuple_0, str_0)
    except CompilationError:
        return
    assert False

# Generated at 2022-06-25 21:32:06.292253
# Unit test for function compile_files
def test_compile_files():
    input_str = "test.py"
    output_str = "test.pyc"
    target_str = None
    root_str = input_str
    result = compile_files(input_str, output_str, target_str, root_str)
    assert result is not None

# Generated at 2022-06-25 21:32:07.468000
# Unit test for function compile_files
def test_compile_files():
    return None

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:11.359896
# Unit test for function compile_files
def test_compile_files():
    str_0 = '_zJF3!*5v/'
    str_1 = '?N`)}!~g=?'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)
    assert compilation_result_0 is not None


# Generated at 2022-06-25 21:32:12.154035
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:32:19.737847
# Unit test for function compile_files
def test_compile_files():
    str_0 = '?_ZR{}0/^6'
    str_1 = '9r7?fv'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)
    assert isinstance(compilation_result_0, CompilationResult)
    assert compilation_result_0.time_in_seconds==0.0
    assert compilation_result_0.target is None
    assert compilation_result_0.dependencies == []
    assert compilation_result_0.files_count == 0
    print('test #0: compile_files')
    for i in range(10):
        test_case_0()

if __name__ == '__main__':
    str_0 = 'a/b/c'
    str_1

# Generated at 2022-06-25 21:32:20.812086
# Unit test for function compile_files
def test_compile_files():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 21:32:23.253238
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:28.951113
# Unit test for function compile_files
def test_compile_files():
    str_0 = '_zJF3!*5v/'
    str_1 = '?N`)}!~g=?'
    tuple_0 = None
    assert_equals(compile_files(str_0, str_1, tuple_0, str_0), CompilationResult(0, 0, None, []))
    assert_equals(compile_files(str_0, str_1, tuple_0, str_1), CompilationResult(0, 0, None, []))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:32:48.267565
# Unit test for function compile_files
def test_compile_files():
  # no need to test, it just calls other functions, they are tested
  pass


# Generated at 2022-06-25 21:32:51.052848
# Unit test for function compile_files
def test_compile_files():
    str_0 = '__main__'
    str_1 = '*j^~?F-/;'
    str_2 = '/b>/f0@0N'
    compilation_result_0 = compile_files(str_0, str_1, str_2, str_2)
    assert False



# Generated at 2022-06-25 21:32:56.042501
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'xP*2H$sFDo'
    str_1 = '_pLBZ:}-cT'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)
    assert (compilation_result_0.compiled == 3)
    assert (compilation_result_0.time == 0.001682281494140625)
    assert (compilation_result_0.target == 'py')
    assert (compilation_result_0.dependencies == [])


# Generated at 2022-06-25 21:32:57.421311
# Unit test for function compile_files
def test_compile_files():
    try:
        if test_case_0:
            pass
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 21:32:59.468611
# Unit test for function compile_files
def test_compile_files():
    str_0 = "in"
    str_1 = "out"
    tuple_0 = None
    test_case_0()

# Testing compile_files
test_compile_files()

# Generated at 2022-06-25 21:33:05.944875
# Unit test for function compile_files

# Generated at 2022-06-25 21:33:12.232486
# Unit test for function compile_files
def test_compile_files():
    str_0 = '_zJF3!*5v/'
    str_1 = '?N`)}!~g=?'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)
    str_4 = '_zJF3!*5v/'
    str_5 = '?N`)}!~g=?'
    tuple_1 = None
    compilation_result_1 = compile_files(str_4, str_5, tuple_1, str_4)
    assert (compilation_result_0 == compilation_result_1)
    str_9 = '_zJF3!*5v/'
    str_10 = '?N`)}!~g=?'
    tuple_2 = None
    compilation_

# Generated at 2022-06-25 21:33:19.660519
# Unit test for function compile_files
def test_compile_files():
    from .utils.preprocess_test import test_preprocess, create_file
    from .transformers.full_name_transformer import FULL_NAME_TRANSFORMER
    from .transformers.unused_transformer import UNUSED_TRANSFORMER

    input_ = 'input'
    output = 'output'

    test_preprocess(create_file, input_, output)

    file = input_ + '/a/b/c/d.py'
    with open(file, 'w') as f:
        print("import z\nx=z.y", file=f)

    assert FULL_NAME_TRANSFORMER.target > UNUSED_TRANSFORMER.target
    result = compile_files(input_, output, FULL_NAME_TRANSFORMER.target)

# Generated at 2022-06-25 21:33:26.170517
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    x = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, x)
    import src

    # Expected Result:
    # Error on line 1
    # Expected:
    #
    #   a = 2
    #
    # Got:
    #
    #   a = '2'

    os.chdir(os.path.join(x, "tests/unit/cases"))

# Generated at 2022-06-25 21:33:34.854647
# Unit test for function compile_files
def test_compile_files():
    num_files_compiled = 100
    num_files_created = 100
    time_taken_to_compile = 10
    compilation_result_0 = CompilationResult(num_files_compiled, time_taken_to_compile, 'both', 'list')
    assert (compilation_result_0.number_of_files_compiled == num_files_compiled)
    assert (compilation_result_0.number_of_files_created == num_files_created)
    assert (compilation_result_0.time_taken_to_compile == time_taken_to_compile)
    assert (compilation_result_0.compilation_target == 'both')
    assert (compilation_result_0.dependencies == ['list'])