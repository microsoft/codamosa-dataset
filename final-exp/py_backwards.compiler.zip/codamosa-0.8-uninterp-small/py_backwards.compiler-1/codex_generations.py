

# Generated at 2022-06-25 21:30:11.140630
# Unit test for function compile_files
def test_compile_files():
    # Testcase #0
    str_0 = None
    int_0 = -2988
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    print(compilation_result_0)

# Generated at 2022-06-25 21:30:12.505151
# Unit test for function compile_files
def test_compile_files():
    with pytest.raises(TypeError):
        test_case_0()
# vim: set ft=python :

# Generated at 2022-06-25 21:30:15.112450
# Unit test for function compile_files
def test_compile_files():
    # str_0 = None
    # int_0 = -2988
    # tuple_0 = (int_0, int_0)
    # compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    test_case_0()



# Generated at 2022-06-25 21:30:20.389555
# Unit test for function compile_files
def test_compile_files():
    # Testing for inputs: (str, str, (int, int))
    str_0 = "inputs/samples/sample_0.py"
    str_1 = "outputs/samples/sample_0.js"
    int_0 = -2988
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_1, tuple_0)
    assert compilation_result_0.files == 1, "files of compilation_result_0 is incorrect"
    assert compilation_result_0.time == -106601, "time of compilation_result_0 is incorrect"
    assert compilation_result_0.target == tuple_0, "target of compilation_result_0 is incorrect"

# Generated at 2022-06-25 21:30:21.896090
# Unit test for function compile_files
def test_compile_files():
  print(compile_files(None, None, (-2988, -2988)))

test_compile_files()

# Generated at 2022-06-25 21:30:31.766615
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# if __name__ == "__main__":
#     import argparse
#     parser = argparse.ArgumentParser(description='Python script compiler.')

#     parser.add_argument('input_', help='path (directory) with source codes')
#     parser.add_argument('output', help='path (directory) with compiled codes')
#     parser.add_argument('-t', '--target', help='python or cpython version',
#                         choices=CompilationTarget.get_targets(),
#                         default='cpython-3.6')
#     parser.add_argument('-r', '--root', help='intended root directory',
#                         default=None)

#     args = parser.parse_args()
#     print(compile_files(args.input_, args.

# Generated at 2022-06-25 21:30:42.713586
# Unit test for function compile_files
def test_compile_files():
    # Create a temporary directory to test the compiler on
    temp_dir = tempfile.TemporaryDirectory()
    shutil.copy('./test/test_files/test_ops.py', temp_dir.name)
    shutil.copy('./test/test_files/test_functions.py', temp_dir.name)
    shutil.copy('./test/test_files/test_classes.py', temp_dir.name)
    shutil.copy('./test/test_files/test_modules.py', temp_dir.name)
    shutil.copy('./test/test_files/test_imports.py', temp_dir.name)
    shutil.copy('./test/test_files/test_decorators.py', temp_dir.name)

# Generated at 2022-06-25 21:30:50.005348
# Unit test for function compile_files
def test_compile_files():
    try:
        print('--- test_case_0 ---')
        test_case_0()
    except Exception as e:
        print('Failed: ' + str(e))

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:00.868166
# Unit test for function compile_files
def test_compile_files():
    # Test case 0
    try:
        test_case_0()
        assert False
    except CompilationError:
        assert True
    except:
        assert False
    # Test case 1
    try:
        compile_files(None, None, ('a', 'a'))
        assert False
    except CompilationError:
        assert True
    except:
        assert False
    # Test case 2
    try:
        compile_files(None, None, ('a', 'a'))
        assert False
    except CompilationError:
        assert True
    except:
        assert False
    # Test case 3
    try:
        compile_files(None, None, ('a', 'a'))
        assert False
    except CompilationError:
        assert True
    except:
        assert False
    # Test case 4

# Generated at 2022-06-25 21:31:09.463477
# Unit test for function compile_files
def test_compile_files():
    filename = 'test_compile.py'
    with open(filename, 'w') as f:
        f.write("# This is a comment\n"
                "# This is an another comment\n"
                "def func(x):\n"
                "    if True:\n"
                "        if True:\n"
                "            if True:\n"
                "                if True:\n"
                "                    if True:\n"
                "                        if True:\n"
                "                            return x + 1\n"
                "a = 1 + 1\n")
    for target in (CompilationTarget.BROWSER, CompilationTarget.SERVER):
        print('test_compile_files: target: {}'.format(target))
        result = compile_files(filename, filename + '.out', target)

# Generated at 2022-06-25 21:31:16.579548
# Unit test for function compile_files
def test_compile_files():
    print('--- test_compile_files ---')
    test_case_0()

# Generated at 2022-06-25 21:31:17.804089
# Unit test for function compile_files
def test_compile_files():
    compile_files('.', '.', 'PYTHON37')

# Generated at 2022-06-25 21:31:32.418042
# Unit test for function compile_files
def test_compile_files():
    str_0 = '--- test_compile_files ---'
    var_0 = print(str_0)

# Generated at 2022-06-25 21:31:38.421104
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.EXECUTABLE
    input_ = './samples/compile_file'
    output = "./samples/compile_file_output"
    root = None
    compile_files(input_, output, target, root)


# Generated at 2022-06-25 21:31:46.993375
# Unit test for function compile_files
def test_compile_files():
    import json, os
    os.remove("/Users/tianyudu/Documents/Academics/EECS_Courses/Winter2020/CSE_331/Term_Project/Test/source/output/test_case_0.py")
    os.remove("/Users/tianyudu/Documents/Academics/EECS_Courses/Winter2020/CSE_331/Term_Project/Test/source/compiled/test_case_0.py")    
    os.remove("/Users/tianyudu/Documents/Academics/EECS_Courses/Winter2020/CSE_331/Term_Project/Test/source/compiled/test_case_0.js")

# Generated at 2022-06-25 21:31:48.611197
# Unit test for function compile_files
def test_compile_files():
  # Test case 0 (unittest_config)
  debug(lambda: '--- test_compile_files ---')
  str_0 = '--- test_compile_files ---'
  var_0 = print(str_0)

# Generated at 2022-06-25 21:31:50.533143
# Unit test for function compile_files
def test_compile_files():
    var_0 = compile_files('', '', '')
    str_0 = '--- test_compile_files ---'
    print(str_0)

if __name__ == '__main__':
    test_case_0()
    test_compile_files()

# Generated at 2022-06-25 21:31:52.585194
# Unit test for function compile_files
def test_compile_files():
    paths = InputOutput('project/main.py', 'project/compiled/main.py')
    target = CompilationTarget.ANNOTATION
    dependencies = _compile_file(paths, target)
    print(dependencies)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:56.705048
# Unit test for function compile_files
def test_compile_files():
    print('--test_compile_files--')
    input_ = 'test_case_python_files'
    output = 'test_case_python_files_output'
    target_type = CompilationTarget
    target = CompilationTarget.PYTHON_TO_PYTHON
    root=None
    assert compile_files(input_, output, target, root) == ('--test_compile_files--',0)


# Generated at 2022-06-25 21:32:04.119188
# Unit test for function compile_files
def test_compile_files():
    # Tests the case that print a string
    str_1 = '--- test_print_a_string ---'
    var_0 = print(str_1)
    assert (var_0 == None)
    # Tests the case that for test_add_two_int
    var_1 = 12
    var_2 = 3
    var_3 = var_1 + var_2
    assert (var_3 == 15)
    # Tests the the case that for list
    var_4 = [1, 2, 3, 4]
    var_5 = var_4[0]
    assert (var_5 == 1)
    # Tests the case that for tuple
    var_6 = (1, 2, 3, 4)
    var_7 = var_6[0]
    assert (var_7 == 1)
    # Tests the case

# Generated at 2022-06-25 21:32:11.646421
# Unit test for function compile_files
def test_compile_files():
    if not hasattr(sys, '_called_from_test'):
        sys._called_from_test = True
        import pytest
        pytest.main([__file__])


# Generated at 2022-06-25 21:32:15.056527
# Unit test for function compile_files
def test_compile_files():
    input_ = 'input_folder'
    output = 'output_folder'
    target = CompilationTarget.ES5
    root = None

    result = compile_files(input_, output, target, root)

    print('Number of Files: ', result.count)
    print('Compiler Time: ', result.time)
    print('Target: ', result.target)


# Generated at 2022-06-25 21:32:18.308920
# Unit test for function compile_files
def test_compile_files():
    compile_files(
            'test.py',
            'test',
            CompilationTarget.BIN,
            root=None
    )


if __name__ == '__main__':
    test_case_0()
    test_compile_files()

# Generated at 2022-06-25 21:32:27.025034
# Unit test for function compile_files
def test_compile_files():
    import os
    test_case_0()
    test_file_path = os.path.join(os.path.dirname(__file__), 'tests', 'test_cases.py')
    input_ = test_file_path
    output = 'output_test'
    target = CompilationTarget.PYTHON_SCRIPT
    root = None
    test_file_path = os.path.join(os.path.dirname(__file__), 'tests', 'test_cases.py')
    compile_files(input_, output, target, root)
    test_file_path = os.path.join(os.path.dirname(__file__), 'output_test', 'tests', 'test_cases.py')
    with open(test_file_path, 'r') as f:
        line_count = 0

# Generated at 2022-06-25 21:32:29.313220
# Unit test for function compile_files
def test_compile_files():
    # Test case 0: /home/matthew/Documents/Programming/Python/pypefy/examples/simple_calculator
    test_case_0()
    # Test case 1: 
    test_case_1()

# Generated at 2022-06-25 21:32:30.359792
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Run all tests

# Generated at 2022-06-25 21:32:32.057242
# Unit test for function compile_files
def test_compile_files():
    str_0 = '--- test_compile_files ---'
    var_0 = print(str_0)


# Generated at 2022-06-25 21:32:33.142395
# Unit test for function compile_files
def test_compile_files():
    str_0 = "Dummy test function for function compile_files."
    var_0 = print(str_0)

# Generated at 2022-06-25 21:32:38.846554
# Unit test for function compile_files
def test_compile_files():
    target = 'C'
    input_ = ''
    output = ''
    root = ''
    result = compile_files(input_ = input_, output = output, target = target, root = root)
    print('Testing Function (compile_files)')
    print('target : ' + target)
    print('input_ : ' + input_)
    print('output : ' + output)
    print('root : ' + root)
    print('result : ' , result)

# Generated at 2022-06-25 21:32:45.851785
# Unit test for function compile_files
def test_compile_files():
    var_0 = compile_files('input', 'output', CompilationTarget.ES5, root)
    try:
        assert var_0.count == 0
    except AssertionError as var_1:
        print('Failed test_compile_files: Expected {}, got {}'.format(0, var_0.count))
        
    try:
        assert var_0.time == 0
    except AssertionError as var_2:
        print('Failed test_compile_files: Expected {}, got {}'.format(0, var_0.time))
        

# Generated at 2022-06-25 21:32:53.788618
# Unit test for function compile_files
def test_compile_files():
    test_target = "ast"
    test_root = None
    test_input = "./input_test"
    test_output = "./output_test"
    expected_result = CompilationResult(1, 0, test_target, [])
    actual_result = compile_files(test_input, test_output, test_target, test_root)
    assert expected_result == actual_result 
    test_case_0()

# Generated at 2022-06-25 21:32:55.797220
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('./test_case_0.py', './test_output', CompilationTarget.ES5)
    except SyntaxError:
        raise
    except:
        raise


# Generated at 2022-06-25 21:33:02.195450
# Unit test for function compile_files
def test_compile_files():
    import tempfile

    test_case_0()

    with tempfile.TemporaryDirectory() as temporary_directory:
        input_directory = Path(temporary_directory) / 'test'
        output_directory = Path(temporary_directory) / 'output'

        (input_directory / 'hello.py').write_bytes(b'print("Hello world")')
        (input_directory / 'main.py').write_bytes(b'import hello')

        compile_files(str(input_directory), str(output_directory),
                      CompilationTarget.PYTHON_3_5)

        assert (output_directory / 'hello.py').read_bytes() == b'print("Hello world")'


# Generated at 2022-06-25 21:33:08.537646
# Unit test for function compile_files
def test_compile_files():
    # Set up test environment
    str_0 = '--- test_compile_files ---'
    var_0 = print(str_0)

    # Set up the test files
    import os
    import pathlib
    test_path = os.path.join('tests', 'compiler')
    in_file = os.path.join(test_path, 'in.py')
    out_file = os.path.join(test_path, 'out.py')
    input_ = pathlib.Path(in_file)
    output = pathlib.Path(out_file)

    # Create a compilation target
    test_target = CompilationTarget.AST3
    target = test_target

    # Use compile_files to create a CompilationResult object
    compile_files(input_, output, target)
    test_result = Compilation

# Generated at 2022-06-25 21:33:11.603597
# Unit test for function compile_files
def test_compile_files():
    test_cases = [
        test_case_0,
    ]
    for index, test_case in enumerate(test_cases):
        print('=== test case {} ==='.format(index))
        test_case()
    print('=== all test cases ===')

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:33:12.258071
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


# Generated at 2022-06-25 21:33:14.626500
# Unit test for function compile_files
def test_compile_files():
    print("Testing compile_files")
    path = './test/test_compilation.py'
    output = './test/test_compilation.py'
    target = 'py'
    root = './test/'
    compile_files(path, output, target, root)

# Generated at 2022-06-25 21:33:15.307440
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


# Generated at 2022-06-25 21:33:16.205294
# Unit test for function compile_files
def test_compile_files():
    output = 1
    assert output == 1


# Generated at 2022-06-25 21:33:20.871302
# Unit test for function compile_files
def test_compile_files():
    input_ = 'input'
    output = 'output'
    target = 'python2'
    root = 'src'
    expected_result = CompilationResult(0, 0, 'python2', None)
    compile_files(input_, output, target, root)
    result = CompilationResult(0, 0, 'python3', None)
    assert result == expected_result
    print('test_compile_files passed')


# Generated at 2022-06-25 21:33:30.325872
# Unit test for function compile_files
def test_compile_files():
    compile_files('path', 'path', 'Python3')
    compile_files('path', 'path', 'Python3', 'root')
    compile_files('path', 'path', 'Python3', None)
    compile_files('path', 'path', 'Python2', None)
    compile_files(None, 'path', 'Python2', None)
    compile_files('path', None, 'Python2', None)
    compile_files('path', 'path', None, None)
    compile_files('path', 'path', 'Python3', 'root')

# Generated at 2022-06-25 21:33:38.862110
# Unit test for function compile_files
def test_compile_files():
    file_path_input = "tests_files/test0.py"
    file_path_output = "tests_out/test0.py"
    
    compile_files(file_path_input, file_path_output, CompilationTarget.JS)

    with open(file_path_output, 'r') as file:
        code = file.read()

        if code != "var int_0 = 1;":
            raise AssertionError()

# Generated at 2022-06-25 21:33:44.248241
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("./test_input/test_func.py", "./test_output/test_func.py", "py2js")
    #print(result)
    with open("./test_output/test_func.py", "r") as f:
        js_code = f.read()
    #print(js_code)
    assert(len(js_code) == 265)
    assert(result.dependencies == ['js2py', 'astunparse', 'typed_ast', 'typing', 'ast', 'astunparse'])

if __name__ == "__main__":
    test_case_0()
    test_compile_files()

# Generated at 2022-06-25 21:33:52.306103
# Unit test for function compile_files
def test_compile_files():
    import os
    import subprocess
    from .test.test_utils import test_path_0
    from .test.test_utils import test_path_1
    from .test.test_utils import test_path_2
    from .test.test_utils import test_path_3
    from .test.test_utils import test_path_4
    from .test.test_utils import test_path_5
    from .test.test_utils import test_path_6
    from .test.test_utils import test_path_7
    from .test.test_utils import test_path_8
    from .test.test_utils import test_path_9
    from .test.test_utils import test_path_10
    from .test.test_utils import test_path_11
    from .test.test_utils import test

# Generated at 2022-06-25 21:33:54.964677
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.JS
    input_ = './tests/test-data/test_compile_files.py'
    output = './tests/test-data/output_folder'
    root = None
    compile_files(input_, output, target, root)

# Generated at 2022-06-25 21:33:58.798857
# Unit test for function compile_files
def test_compile_files():
    """
    Unit test for function compile_files
    :return:
    """
    dirname = os.path.dirname(__file__)
    input_ = os.path.join(dirname, 'tests', 'examples')
    output = os.path.join(dirname, 'tests', 'output')
    compile_files(input_, output, CompilationTarget.JS)
    print('Compilation Result:')
    print(f'Src: {input_}\nDst: {output}')

# Generated at 2022-06-25 21:34:00.100885
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("test_cases/test_case_0.py", "output/test_case_0.py", CompilationTarget("Python3"))

# Generated at 2022-06-25 21:34:01.595920
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/test_in'
    output = 'tests/test_out'
    compile_files(input_, output, CompilationTarget.NODE)


# Generated at 2022-06-25 21:34:06.621638
# Unit test for function compile_files
def test_compile_files():
    # Check that function compile_files returns results that are similar to expected results
    import os
    import sys
    import subprocess
    directory_current = os.getcwd()
    print(directory_current)
    directory_input = os.path.join(directory_current, "py2nbcompiler/tests/input")
    directory_output = os.path.join(directory_current, "py2nbcompiler/tests/input")
    compile_files(input_ = directory_input, output = directory_output, target = CompilationTarget.notebook)
    print(directory_input)
    directory_input_files = os.listdir(directory_input)
    print(directory_input_files)
    directory_input_files.remove('.ipynb_checkpoints')
    for i in directory_input_files:
        input_

# Generated at 2022-06-25 21:34:15.135069
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("input", "output", CompilationTarget.PYTHON_TO_TYPED_PYTHON)
    assert result.success == True
    assert result.dependencies == [
        "astunparse",
        "exceptions",
        "files",
        "types",
        "typed_ast.ast3",
        "utils",
        "utils.helpers",
        "utils.tokenizer"
    ]

# Generated at 2022-06-25 21:34:27.429744
# Unit test for function compile_files
def test_compile_files():
    input_0 = 'PYTHN37'
    output_0 = 'PYTHN37'
    target_0 = 'PYTHN37'
    root_0 = 'PYTHN37'
    obj_0 = compile_files(input_0, output_0, target_0, root_0)
    bool_0 = bool([obj_0])
    bool_1 = bool([target_0])
    bool_2 = bool([obj_0])
    bool_3 = bool([root_0])
    bool_4 = bool([obj_0])
    bool_5 = bool([obj_0])
    bool_6 = bool([root_0])
    bool_7 = bool([target_0])
    bool_8 = bool([output_0])
    bool_9 = bool([obj_0])
   

# Generated at 2022-06-25 21:34:28.974178
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'PYTHN37'
    compilation_result_0 = compile_files(str_0, str_0, str_0)
    assert(compilation_result_0 is not None)



# Generated at 2022-06-25 21:34:29.502130
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:34:31.076430
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'PYTHN37'
    compilation_result_0 = compile_files(str_0, str_0, str_0)
    assert compilation_result_0 is not None # Assertion Error if result is None


# Generated at 2022-06-25 21:34:42.960744
# Unit test for function compile_files
def test_compile_files():
    # Test Params - input_: str, output: str, target: CompilationTarget
    test_params_0 = ('PYTHN37', 'PYTHN37', 'PYTHN37',)
    # Test Params - input_: str, output: str, target: CompilationTarget
    test_params_1 = ('PYTHN37', 'PYTHN37', 'PYTHN37',)
    # Test Params - input_: str, output: str, target: CompilationTarget
    test_params_2 = ('PYTHN37', 'PYTHN37', 'PYTHN37',)
    # Test Params - input_: str, output: str, target: CompilationTarget

# Generated at 2022-06-25 21:34:46.629178
# Unit test for function compile_files
def test_compile_files():
    """
    Test compile_files(input_, output, target)
    """
    print("Unit test for compile_files(input_, output, target)")
    # Test case 0
    print("Start test case 0")
    test_case_0()
    print("Test case 0 finished")


# Generated at 2022-06-25 21:34:49.600598
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'PYTHN37'
    compilation_result_0 = CompilationResult(0, 0, str_0, [])

    assert compile_files(str_0, str_0, str_0) == compilation_result_0


# Tests compilation with a simple Python 2-only code snippet

# Generated at 2022-06-25 21:34:54.294268
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception as ex:
        TracebackError()
        print('Caught exception: ' + str(ex))
        raise ex

# main() function
# TODO: This function should call test_compile_files()
# and print out error messages if the test fails

# Generated at 2022-06-25 21:35:01.087713
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'PYTHN37'
    compilation_result_0 = compile_files(str_0, str_0, str_0)
    assert len(str(compilation_result_0)) == 1185
    assert 'reformat' in str(compilation_result_0)
    str_1 = 'pythn37'
    compilation_result_2 = compile_files(str_1, str_1, str_1)
    assert len(str(compilation_result_2)) == 1185
    assert 'reformat' in str(compilation_result_2)
    str_2 = 'PYTHN37'
    str_3 = 'pythn37'
    str_4 = 'pythn37'

# Generated at 2022-06-25 21:35:05.695872
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'PYTHN37'
    compilation_result_0 = compile_files(str_0, str_0, str_0)


if __name__ == "__main__":
    for t in [test_case_0, test_compile_files]:
        try:
            print('Running {}'.format(t.__name__))
            t()
            print('PASS\n')
        except Exception as e:
            print('FAIL\n')
            print(e)

# Generated at 2022-06-25 21:35:22.300145
# Unit test for function compile_files
def test_compile_files():
    import pathlib as path_lib

    with path_lib.Path('tests/fixtures/compile_files/input').open() as file_0:
        str_0 = file_0.read()
    with path_lib.Path('tests/fixtures/compile_files/output').open() as file_1:
        str_1 = file_1.read()
    compilation_result_0 = compile_files(str_0, str_1)
    assert (compilation_result_0.file_count == 1)
    assert (compilation_result_0.time_elapsed > 0)
    assert (compilation_result_0.target == 'PYTHON37')
    assert (compilation_result_0.dependencies == ['typed_ast'])


# Generated at 2022-06-25 21:35:25.216943
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        print('ERROR: test_compile_files')
        print(format_exc())


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:35:30.445548
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import subprocess
	# compile a single file to make sure that the compiled version works
    input_ = pathlib.Path(__file__).parent / '..' / 'examples' / 'simple.py'
    output = input_.with_name('simple_compiled.py')
    target = CompilationTarget.PYTHON37
    result = compile_files(str(input_), str(output), target)
    subprocess.run(['python', str(output)])
    output.unlink()
    # run a simple test
    input_ = pathlib.Path(__file__).parent / '..' / 'examples'
    output = pathlib.Path(__file__).parent / '..' / 'examples' / 'compiled'
    target = CompilationTarget.PYTHON37
   

# Generated at 2022-06-25 21:35:35.710794
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'PYTHN37'
    compilation_result_0 = compile_files(str_0, str_0, str_0)
    assert compilation_result_0.count == 0
    assert compilation_result_0.run_time == 0.0
    assert compilation_result_0.target == 'PYTHN37'
    assert compilation_result_0.dependencies == []

    str_1 = 'PYTHN37'
    str_2 = 'PYTHN37'
    compilation_result_1 = compile_files(str_1, str_2, str_1)
    assert compilation_result_1.count == 0
    assert compilation_result_1.run_time == 0.0
    assert compilation_result_1.target == 'PYTHN37'
    assert compilation_result_1

# Generated at 2022-06-25 21:35:38.847432
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'PYTHN37'
    compilation_result_0 = compile_files(str_0, str_0, str_0)

    assert (compilation_result_0.count == 0)
    assert (compilation_result_0.target == 'PYTHN37')
    assert (compilation_result_0.dependencies == [])


# Generated at 2022-06-25 21:35:39.565319
# Unit test for function compile_files
def test_compile_files():
    assert (callable(compile_files))


# Generated at 2022-06-25 21:35:44.095226
# Unit test for function compile_files
def test_compile_files():
    with open('test_file.py', 'w') as f:
        f.write('def func(a):\n    return a * 2')
        f.flush()
    compile_files('test_file.py', 'test_file.js', 'TJS')
    with open('test_file.js', 'r') as f:
        code = f.read()
    os.remove('test_file.js')

    assert 'func' in code

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:35:47.250976
# Unit test for function compile_files
def test_compile_files():
    test_case_list_0 = [0]
    for case_id in test_case_list_0:
        print("Running test case {}".format(case_id))
        if case_id == 0:
            test_case_0()
        else:
            print("ERROR: Missing test case {}".format(case_id))

if __name__ == '__main__':
    for_test = True
    test_compile_files()

# Generated at 2022-06-25 21:35:54.241159
# Unit test for function compile_files
def test_compile_files():
    from hypothesis import given
    from hypothesis.strategies import integers, composite, text, sampled_from
    from pathlib import Path
    from subprocess import run, PIPE
    from tempfile import TemporaryDirectory

    import sys

    @given(input_=text(), output=text())
    def test(input_, output):
        with TemporaryDirectory(prefix='pythn37-test') as tmp_dir:
            mode = 'w'
            if sys.version_info[0] < 3:
                mode = 'wb'

            input_path = Path(tmp_dir, input_)
            input_path.touch()

            output_path = Path(tmp_dir, output)
            try:
                output_path.mkdir(parents=True)
            except FileExistsError:
                pass


# Generated at 2022-06-25 21:35:56.581561
# Unit test for function compile_files
def test_compile_files():
    str_1 = 'S1wZ'
    str_2 = 'cq3C'
    compilation_result_0 = compile_files(str_1, str_2, str_2)


if __name__ == '__main__':
    test_case_0()
    test_compile_files()