

# Generated at 2022-06-25 21:30:09.291818
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'QP'
    int_0 = -639
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert not bool_0


# Generated at 2022-06-25 21:30:12.471473
# Unit test for function compile_files
def test_compile_files():
    print('Running test...')
    start_time = time.time()
    test_case_0()
    print('Passed')
    elapsed_time = time.time() - start_time
    print('It took ' + str(elapsed_time) + ' seconds to run test cases')

# Generated at 2022-06-25 21:30:17.315736
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'TY'
    int_0 = -192
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    print(compilation_result_0.count)
    print(compilation_result_0.total_duration)
    print(compilation_result_0.target)
    print(compilation_result_0.dependencies)
    
if __name__ == '__main__':
    test_case_0()
    test_compile_files()

# Generated at 2022-06-25 21:30:23.248595
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'QP'
    int_0 = -639
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert compilation_result_0.target == tuple_0
    assert compilation_result_0.count == 0
    assert compilation_result_0.time == 0
    assert compilation_result_0.dependencies == []


# Generated at 2022-06-25 21:30:32.858021
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'QP'
    int_0 = -639
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    counter = 0
    for _ in range(1000):
        str_0 = 'QP'
        int_0 = -639
        tuple_0 = (int_0, int_0)
        compilation_result_0 = compile_files(str_0, str_0, tuple_0)
        counter += 1
        if counter > 100:
            break


# Generated at 2022-06-25 21:30:38.324123
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'wv'
    str_1 = 'f'
    tuple_0 = (str_0, str_1)
    compilation_result_0 = compile_files(str_0, str_1, tuple_0)
    assert compilation_result_0.duration == 0
    assert compilation_result_0.target == ('wv', 'f')


# Generated at 2022-06-25 21:30:39.512548
# Unit test for function compile_files
def test_compile_files():
    assert test_case_0()

test_compile_files()

# Generated at 2022-06-25 21:30:44.243524
# Unit test for function compile_files
def test_compile_files():
    in_0 = 'QP'
    out_0 = 'QP'
    target_0 = (-639, -639)
    result_0 = compile_files(in_0, out_0, target_0)
    assert result_0 == (10, 0.0, (-639, -639), [])

# Benchmark with profiling for function compile_files

# Generated at 2022-06-25 21:30:57.105155
# Unit test for function compile_files
def test_compile_files():
    # Create test case inputs
    str_0 = 'fWGp'
    str_1 = 'dMZ'
    tuple_0 = (-24, 28)
    bool_0 = False
    str_2 = 'C'
    path_0 = Path(str_2)
    str_3 = 'Jm'
    str_4 = 'Y'
    tuple_1 = (str_4, -1500)
    str_5 = 'OyL'
    str_6 = 'sTw'
    int_0 = -1791
    str_7 = 'A'
    tuple_2 = (str_7, str_7)
    str_8 = 'v'
    str_9 = 'y'
    str_10 = 'HrZ'
    str_11 = 'mqf'
    str_

# Generated at 2022-06-25 21:31:06.614639
# Unit test for function compile_files
def test_compile_files():
    int_0 = -59
    float_0 = float(int_0)
    float_1 = float(int_0)
    float_2 = float(int_0)
    str_0 = str()
    str_1 = str(str_0)
    str_2 = str(str_0)

# Generated at 2022-06-25 21:31:12.900529
# Unit test for function compile_files
def test_compile_files():
    print(test_case_0())


# Test case 0

# Generated at 2022-06-25 21:31:16.676224
# Unit test for function compile_files
def test_compile_files():
    # Setup
    input_ = 'str'
    output = 'str'
    target = None

    # Invocation
    compilation_result = compile_files(input_, output, target)

    # Verification
    assert type(compilation_result) == CompilationResult

# Generated at 2022-06-25 21:31:18.483877
# Unit test for function compile_files
def test_compile_files():
    # No exception should be thrown
    try:
        test_case_0()
    except Exception:
        raise AssertionError("Unexpected exception was thrown")

# Generated at 2022-06-25 21:31:32.418889
# Unit test for function compile_files
def test_compile_files():
    import os, sys

    if os.name == 'nt':
        os.environ['PYTHONPATH'] = ';'.join(
            os.path.join(os.path.dirname(sys.executable), 'Lib', 'site-packages')
            )
    else:
        os.environ['PYTHONPATH'] = ':'.join(
            os.path.join(os.path.dirname(sys.executable), 'lib', 'python%s' % sys.version[:3], 'site-packages')
            )

    from .test.data import input_1_2, output_1_2


# Generated at 2022-06-25 21:31:36.603527
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('input_titanic/titanic.py', 'output_titanic/titanic.py', 'cpython')



# Generated at 2022-06-25 21:31:39.192693
# Unit test for function compile_files
def test_compile_files():
    print()
    print('Test compile_files')



    test_case_0()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:44.509920
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input_'
    str_1 = 'output'
    tuple_0 = None
    str_2 = 'tests/input/example.py'
    str_3 = 'tests/output/example.py'

    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_2)
    assert str_3 in compilation_result_0.dependencies




# Generated at 2022-06-25 21:31:47.387778
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'str'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    return


# Generated at 2022-06-25 21:31:49.085990
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'str'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)

# Generated at 2022-06-25 21:31:50.050845
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:02.895049
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'str'
    str_1 = 'str'
    compilation_target_0 = None
    tree_0 = ast.parse(str_0)
    for transformer_0 in transformers:
        if transformer_0.target < compilation_target_0:
            continue
        working_tree_0 = deepcopy(tree_0)
        result_0 = transformer_0.transform(working_tree_0)
        if not result_0.tree_changed:
            continue
        tree_0 = working_tree_0
        unparse(tree_0)
    try:
        compilation_result_0 = compile_files(str_0, str_1, compilation_target_0)
    except SyntaxError:
        raise


# Generated at 2022-06-25 21:32:04.760459
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        raise

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:06.840672
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


if __name__ == '__main__':
    # test_compile_files()
    print('All unit tests successfully passed.')

# Generated at 2022-06-25 21:32:09.080994
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'str'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)

# Tests for compile_files

# Generated at 2022-06-25 21:32:16.709953
# Unit test for function compile_files
def test_compile_files():
    input_0 = 'input'
    output_0 = 'output'
    target_0 = None
    compilation_result_0 = compile_files(input_0, output_0, target_0)
    print(compilation_result_0)
    assert 1 == 2
    input_1 = 'input'
    output_1 = 'output'
    target_1 = None
    compilation_result_1 = compile_files(input_1, output_1, target_1)
    print(compilation_result_1)
    assert 0 == 0
    input_2 = 'input'
    output_2 = 'output'
    target_2 = None
    compilation_result_2 = compile_files(input_2, output_2, target_2)
    print(compilation_result_2)
    assert True
    input_

# Generated at 2022-06-25 21:32:23.662134
# Unit test for function compile_files
def test_compile_files():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old
# Test case with arguments: test_case_0
# Failure message: 
    test_case_0()
# Standard Output:
    # str
# Standard Error:
    # SyntaxError: unexpected EOF while parsing (<unknown>, line 1)
###

# Generated at 2022-06-25 21:32:31.306272
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'str'
    tuple_0 = None
    int_0 = 0
    str_1 = 'str'
    int_1 = 0
    str_2 = 'str'
    int_2 = 0
    int_3 = 0
    tuple_1 = None

    #Call the function
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert tuple_0 == compilation_result_0.target
    assert int_0 == compilation_result_0.count
    assert str_1 == compilation_result_0.time
    assert list_0 == list([])

    #Call the function
    compilation_result_1 = compile_files(str_2, str_2, int_2)
    assert int_2 == compilation_result_1.target
    assert int_

# Generated at 2022-06-25 21:32:33.833020
# Unit test for function compile_files
def test_compile_files():
    try:
        # print(compile_files.__name__)
        test_case_0()
    except Exception as ex:
        # print('Exception in: {}: {}'.format(compile_files.__name__, ex))
        return False

    return True


# Generated at 2022-06-25 21:32:36.020707
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'str'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    return


# Testing of initialization.

# Generated at 2022-06-25 21:32:39.320706
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        print('Unit test failed', file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:51.440081
# Unit test for function compile_files
def test_compile_files():
    import argparse
    parser = argparse.ArgumentParser()

    parser.add_argument('--input', default=None,
                        help='Input directory')
    parser.add_argument('--output', default=None,
                        help='Output directory')
    parser.add_argument('--root', default=None,
                        help='Root of the project')

    parser.add_argument('--target', choices=['js', 'wasm', 'node'],
                        default='js', help='Target platform')

    args = parser.parse_args()

    if args.target:
        args.target = CompilationTarget[args.target]

    initialize_compilation_target(args.target)
    result = compile_files(args.input, args.output, args.target, args.root)
    print(result)

# Generated at 2022-06-25 21:32:53.669751
# Unit test for function compile_files
def test_compile_files():

    test = compile_files('data/01_intro/05_function_call_tree', 'data/01_intro/05_function_call_tree', 'js')
    assert test.target == 'js'
    assert test.duration < 1

# Generated at 2022-06-25 21:33:01.040263
# Unit test for function compile_files

# Generated at 2022-06-25 21:33:07.377536
# Unit test for function compile_files
def test_compile_files():
    import os

    dir_path = os.path.dirname(os.path.realpath(__file__))
    input_ = dir_path + '/../qgis_server/qgis_request_handler.py'
    output = dir_path + '/../qgis_server/qgis_request_handler.out'
    target = 'Web'
    root = dir_path + '/../'

# Generated at 2022-06-25 21:33:08.003688
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


# Generated at 2022-06-25 21:33:09.376555
# Unit test for function compile_files
def test_compile_files():
    print(compile_files('inputcs3110', 'outputcs3110', CompilationTarget.C_CPP))


# Generated at 2022-06-25 21:33:15.160263
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/input/test_input.py', 'tests/output/test_output.js', CompilationTarget.BROWSER)
    compile_files('tests/input/test_input.py', 'tests/output/test_output.js', CompilationTarget.NODEJS)
    compile_files('tests/input/test_input.py', 'tests/output/test_output.js', CompilationTarget.PYTHON)
    compile_files('tests/input/test_input.py', 'tests/output/test_output.js', CompilationTarget.BROWSER)


# Testing
if __name__ == '__main__':
    test_case_0()
    test_compile_files()

# Generated at 2022-06-25 21:33:16.034740
# Unit test for function compile_files
def test_compile_files():
    assert test_case_0() == None, 'test_case_0() returns None'

# Generated at 2022-06-25 21:33:23.711031
# Unit test for function compile_files
def test_compile_files():
    # Original function return type reference
    original_func_type = type(compile_files)

    # Original function reference
    original_compile_files = compile_files

    # Store the parameters passed to the function
    compile_files_params = []

    # Store the return value of the function
    compile_files_retvals = []

    # Create a variable that will store the original value of the variable
    # "input_"
    original_input_ = input_

    # Create a variable that will store the original value of the variable
    # "output"
    original_output = output

    # Create a variable that will store the original value of the variable
    # "root"
    original_root = root

    # Define an initial value for the variable "input_"
    input_ = str()

    # Define an initial value for the variable

# Generated at 2022-06-25 21:33:24.630841
# Unit test for function compile_files
def test_compile_files():
    assert test_case_0() == None


# Generated at 2022-06-25 21:33:38.834407
# Unit test for function compile_files
def test_compile_files():
    compile_files('', '', CompilationTarget.ES2017)


# Generated at 2022-06-25 21:33:39.702113
# Unit test for function compile_files
def test_compile_files():
    compile_files(test_case_0(),"a","a")

# Generated at 2022-06-25 21:33:46.869464
# Unit test for function compile_files
def test_compile_files():
    test_cases = [
        {
            'args': {
                'input_': './test/input/solution/test_case.py',
                'output': './test/output/solution/',
                'target': 'pypy'
            },
            'result': {
                'count': 1,
                'target': 'pypy'
            }
        }
    ]

    for case in test_cases:
        result = compile_files(**case['args'])
        assert len(result.dependencies) == len(case['result']['dependencies'])
        assert result.count == case['result']['count']
        assert result.target == case['result']['target']
        print(result.count, result.target)

# Generated at 2022-06-25 21:33:54.045048
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil


# Generated at 2022-06-25 21:33:57.238960
# Unit test for function compile_files
def test_compile_files():
    input = os.getcwd() + '/test.py'
    #output = os.getcwd() + '/test.js'
    import filecmp
    original = os.getcwd() + '/test_0.js'
    compile_files(input, 'test_0.js' , CompilationTarget.JS)
    assert filecmp.cmp('test_0.js', original)

# Generated at 2022-06-25 21:33:59.247509
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("test_data/test_0.sht", "test_data/output",
                           CompilationTarget.JS)
    assert result.files == 1
    assert result.dependencies == ['bool']


# Generated at 2022-06-25 21:34:04.646669
# Unit test for function compile_files
def test_compile_files():
    fileName = ""
    try:
        with open('test_case_0_test.py') as f:
            fileName = f.readline().rstrip('\n')
    except Exception as e:
        print(e)
    result = compile_files(
            fileName,
            'test_compile_files_output.py',
            CompilationTarget.python,
            './')
    if result.dependency_count == 0 and result.file_count == 1:
        try:
            with open('test_compile_files_output.py') as f:
                lines = f.readlines()
            for line in lines:
                if line.find("import boolean") == -1:
                    raise Exception(line)
            return True
        except Exception as e:
            print(e)
    return False



# Generated at 2022-06-25 21:34:05.803443
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('boolean', 'boolean_result/',
                      CompilationTarget.CPYTHON)
    except Exception:
        print("fail")

# Generated at 2022-06-25 21:34:15.136581
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.PY2TO3
    input_ = "test/test_compile_files_input"
    output = "test/test_compile_files_output"
    root = None
    count = 1
    duration = True
    dependencies = ['bool']
    test_compile_files = compile_files(input_, output, target, root)
    assert test_compile_files.count == count
    assert test_compile_files.duration == duration
    assert test_compile_files.target == target
    assert test_compile_files.dependencies == dependencies


test_case_0()
test_compile_files()

# Generated at 2022-06-25 21:34:21.051120
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("../test_input/test_0.py", "../test_output/test_0.py", CompilationTarget.PYTHON)
    assert result.count == 1
    assert result.dependencies == []
    env = {}
    exec(open("../test_output/test_0.py").read(), env)
    assert env['bool_0'] == True


# Generated at 2022-06-25 21:34:42.769929
# Unit test for function compile_files
def test_compile_files():
    print("Unit test for function: compile_files")
    expected_result = None
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_

# Generated at 2022-06-25 21:34:44.854547
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        print('Compilation Error')

# Generated at 2022-06-25 21:34:53.562822
# Unit test for function compile_files
def test_compile_files():
    print('\n --- test_compile_files --- ')
    print('\nCreating fake files for compilation')
    input_dir = Path('input')
    output_dir = Path('output')
    if input_dir.exists():
        shutil.rmtree(input_dir)
    if output_dir.exists():
        shutil.rmtree(output_dir)

    input_dir.mkdir()
    output_dir.mkdir()

    (input_dir / 'main.py').write_text(
        """print(b'Hello, world!')"""
    )

    (input_dir / '__init__.py').write_text(
        """print(b'Hello, world!')"""
    )

    (input_dir / 'a' / 'b' / 'c.py').write_

# Generated at 2022-06-25 21:35:00.204420
# Unit test for function compile_files
def test_compile_files():
    from random import randint
    from os.path import exists
    import py_compile

# Generated at 2022-06-25 21:35:06.162356
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
        test_case_1()
    except Exception as e:
        unexpected_exception(e)

# Expected output:
# "paths.py"
# "fallback.py"
# "__init__.py"
# "__init__.py"
# "__init__.py"
# "__init__.py"
# "__init__.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops.py"
# "str_ops

# Generated at 2022-06-25 21:35:08.683960
# Unit test for function compile_files
def test_compile_files():
    assert True
    # for i in [0, 0]:
    #     try:
    #         test_case_0()
    #     except AssertionError as e:
    #         print(str(e))
    #         print('FAIL')
    #         break
    # else:
    #     print('PASS')

# Runs all tests

# Generated at 2022-06-25 21:35:17.923332
# Unit test for function compile_files
def test_compile_files():
    test_cases = [
        # (expected, args, kwargs)
        (('compile_files("input", "output", CompilationTargets.ES5)', ''),
         ('input', 'output', 'CompilationTargets.ES5',)),
    ]
    for tup in test_cases:
        test_func = compile_files
        retval = tup[0]
        args = tup[1]
        kwargs = tup[2]
        result = test_func(*args, **kwargs)
        # print(result)
        assert result == retval

# Generated at 2022-06-25 21:35:25.373371
# Unit test for function compile_files
def test_compile_files():
    from random import uniform, shuffle
    from string import ascii_lowercase, ascii_uppercase, ascii_letters, digits
    from pathlib import Path
    from tempfile import mkdtemp
    from shutil import rmtree
    from itertools import combinations, chain
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget, CompilationResult
    from .exceptions import CompilationError, TransformationError, NodeNotFound
    from .utils.helpers import debug
    # Preparing test data
    input_1 = ''
    output_1 = ''
    target_1 = ''
    root_1 = None
    # Stubbing
    # Expected result

# Generated at 2022-06-25 21:35:30.238795
# Unit test for function compile_files
def test_compile_files():
    import random

    # Test with random cases

# Generated at 2022-06-25 21:35:34.441664
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'str'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    # if compilation_result_0.count != 0:
    #     raise ValueError('Value for argument count was incorrect')
    # if compilation_result_0.duration != 0.0:
    #     raise ValueError('Value for argument duration was incorrect')
    # if not isinstance(compilation_result_0.target, CompilationTarget):
    #     raise ValueError('Value for argument target was incorrect')
    # if compilation_result_0.dependencies != []:
    #     raise ValueError('Value for argument dependencies was incorrect')