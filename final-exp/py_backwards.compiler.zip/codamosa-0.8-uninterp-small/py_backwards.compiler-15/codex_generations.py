

# Generated at 2022-06-25 21:30:12.505797
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    str_1 = ''
    tuple_1 = None
    compilation_result_1 = compile_files(str_1, str_1, tuple_1)
    str_2 = ''
    tuple_2 = None
    compilation_result_2 = compile_files(str_2, str_2, tuple_2)
    return

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:30:13.433587
# Unit test for function compile_files
def test_compile_files():
    # Call the function to ensure that it does not throw an exception
    print(compile_files(0, 0, 0))



# Generated at 2022-06-25 21:30:19.450403
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert type(compilation_result_0) == CompilationResult
    file_0 = open("test/test-cases/test-case-0.in", 'r')
    file_1 = open("test/test-cases/test-case-0.out", 'w')

    assert _compile_file(InputOutput(file_0, file_1), tuple_0) == []
    file_0.close()
    file_1.close()
    # Test exception for compile_files

# Generated at 2022-06-25 21:30:29.500127
# Unit test for function compile_files
def test_compile_files():
    # Root directory for input and output files
    dirname = 'temp'

    # Create root directory if it doesn't exist
    if not os.path.exists(dirname):
        os.makedirs(dirname)

    # Create input and output directories
    input_dir = os.path.join(dirname, 'input')
    output_dir = os.path.join(dirname, 'output')

    # Create input directory if it doesn't exist
    if not os.path.exists(input_dir):
        os.makedirs(input_dir)

    # Create output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Create input and output files and write to input

# Generated at 2022-06-25 21:30:31.345124
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:30:37.574044
# Unit test for function compile_files
def test_compile_files():
    # Unit test for compile_files
    path_0 = '../tests/data/sample.py'
    path_1 = '../tests/data/sample_output.py'
    assert compile_files(path_0, path_1,
                         CompilationTarget.standalone) == CompilationResult(1, 0.0,
                                                                           CompilationTarget.standalone, [])



# Generated at 2022-06-25 21:30:41.324305
# Unit test for function compile_files
def test_compile_files():
    import astunparse

    str_0 = ''
    str_1 = ''
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0)
    assert compilation_result_0.count == 0
    assert 0.0 <= compilation_result_0.duration
    assert astunparse.dump(compilation_result_0.target) == '<Constant value=None ctx=Load()>'
    assert compilation_result_0.dependencies == []



# Generated at 2022-06-25 21:30:49.104910
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(str, str, list)\
        == CompilationResult(int, float, list, list)
    assert compile_files(str, str, list)\
        == CompilationResult(int, float, list, list)
    assert compile_files(str, str, list)\
        == CompilationResult(int, float, list, list)
    assert compile_files(str, str, list)\
        == CompilationResult(int, float, list, list)
    assert compile_files(str, str, list)\
        == CompilationResult(int, float, list, list)
    assert compile_files(str, str, list)\
        == CompilationResult(int, float, list, list)
    assert compile_files(str, str, list)\
        == CompilationResult(int, float, list, list)
    assert compile

# Generated at 2022-06-25 21:30:52.989624
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    str_1 = ''
    compilation_target_0 = None
    CompilationResult_0 = compile_files(str_0, str_1, compilation_target_0)


test_case_0()

# Generated at 2022-06-25 21:30:58.068858
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    str_1 = 'test'
    tuple_1 = None
    compilation_result_1 = compile_files(str_1, str_1, tuple_1)
    assert compilation_result_0 == compilation_result_1