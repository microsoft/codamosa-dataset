

# Generated at 2022-06-25 21:30:15.145960
# Unit test for function compile_files
def test_compile_files():
    assert len(sys.argv) >= 3, 'Usage: {} <input> <output>'.format(sys.argv[0])
    input_ = sys.argv[1]
    output = sys.argv[2]
    target = CompilationTarget.PYTHON36
    root = None
    if len(sys.argv) > 3:
        root = sys.argv[3]
    assert compile_files(input_, output, target, root) is not None
    assert get_input_output_paths(input_, output, root) is not None
    assert len(sys.argv) >= 3, 'Usage: {} <input> <output>'.format(sys.argv[0])
    input_ = sys.argv[1]
    output = sys.argv[2]
    target = Comp

# Generated at 2022-06-25 21:30:18.005900
# Unit test for function compile_files
def test_compile_files():
    assert callable(compile_files)
    try:
        test_case_0()
    except:
        import sys
        print("test #0 failed: " + str(sys.exc_info()[0]))

# Test of function compile_files
test_compile_files()

# vim: set et sw=4 ts=4:

# Generated at 2022-06-25 21:30:26.837907
# Unit test for function compile_files
def test_compile_files():
    import assertpy
    str_0 = None
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assertpy.assert_that(compilation_result_0.count).is_equal_to(0)
    assertpy.assert_that(compilation_result_0.time).is_greater_than_or_equal_to(0.0)
    assertpy.assert_that(compilation_result_0.target).is_equal_to(tuple_0)
    assertpy.assert_that(compilation_result_0.dependencies).is_type_of(list)


# Generated at 2022-06-25 21:30:34.843934
# Unit test for function compile_files
def test_compile_files():
    # Testing for __main__.compose_(a_0, b_0)

    try:
        print('  Testing for __main__.compose_(a_0, b_0)')

        test_case_0()

        print('\n  Testing successful')

    except:
        print('  Testing failed')



# Generated at 2022-06-25 21:30:42.626924
# Unit test for function compile_files
def test_compile_files():
    # Setup inputs
    input_ = 'str_0'
    output = 'str_0'
    target = 'tuple_0'

    # Function call
    compilation_result_0 = compile_files(input_, output, target)

    # Output test
    assert compilation_result_0.count == 0
    assert compilation_result_0.time <= 0.0
    assert compilation_result_0.target == 'tuple_0'
    assert compilation_result_0.dependencies == []

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 21:30:50.887738
# Unit test for function compile_files
def test_compile_files():
    print('Testing compilation result')

    print('Testing the execution function')
    try:
        test_case_0()
    except ValueError as exc:
        print('Exception: ', exc)
    else:
        print('Passed!')
    print()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:01.446513
# Unit test for function compile_files
def test_compile_files():
    input_ = '.'
    output = '.'
    target = 'js'
    root = '.'
    count = None  # type: Optional[int]
    elapsed = None  # type: Optional[float]
    deps = None  # type: Optional[set]
    try:
        compilation_result_0 = compile_files(input_, output, target, root)
        count = compilation_result_0.count
        elapsed = compilation_result_0.elapsed
        deps = compilation_result_0.dependencies
    except CompilationError:
        assert True
    except TransformationError:
        assert True
    assert Count(count) >= 0
    assert Elapsed(elapsed) >= 0
    assert Dependencies(deps) >= 0


test_case_0()
test_compile_files()

# Generated at 2022-06-25 21:31:10.070152
# Unit test for function compile_files
def test_compile_files():
    # Input parameters
    input_ = './src/tests/test_project/'
    output = './src/tests/test_project_compiled/'
    target = ('JAVA', 'PYTHON', 'PYTHON')
    root = './src/tests/test_project/'

    # Expected result

# Generated at 2022-06-25 21:31:10.592027
# Unit test for function compile_files
def test_compile_files():
    assert 0

# Generated at 2022-06-25 21:31:18.645188
# Unit test for function compile_files
def test_compile_files():
    try:
        assert type(compile_files('input_', 'output', ('',))) == CompilationResult
        assert isinstance(compile_files('input_', 'output', ('',)), CompilationResult)
        assert type(compile_files('input_', 'output', ('',))) is CompilationResult
        assert (compile_files('input_', 'output', ('',)).count) == 0
        assert (compile_files('input_', 'output', ('',)).time_passed) >= 0.0
        assert (compile_files('input_', 'output', ('',)).target) == ('',)
        assert (compile_files('input_', 'output', ('',)).dependencies) == sorted([])
    except:
        print('test_compile_files failed!')
        assert False



# Generated at 2022-06-25 21:31:42.039918
# Unit test for function compile_files
def test_compile_files():
    input_ = ""
    output = ""
    target = ()
    root = ""
    compilation_result_0 = compile_files(input_, output, target, root)
    # line 8
    assert compilation_result_0.dependencies == []
    # line 10
    assert compilation_result_0.target == ()
    # line 12
    assert compilation_result_0.count == 0
    # line 14
    assert compilation_result_0.elapsed >= 0.0


# Generated at 2022-06-25 21:31:43.279896
# Unit test for function compile_files
def test_compile_files():
    assert False

# simple test
if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:31:50.739388
# Unit test for function compile_files
def test_compile_files():
    str1 = './test_files/test_file_1.py'
    str2 = './test_files/test_file_2.py'
    str3 = './test_files/test_file_3.py'
    str4 = '../output_file.py'
    str5 = None
    str6 = './output_file.py'
    tuple1 = 'tuple1'
    tuple2 = 'tuple2'
    int1 = 0
    int2 = 1
    int3 = 2
    int4 = 3
    float1 = 0.0
    float2 = 1.0
    float3 = 2.0
    float4 = 3.0
    list1 = []
    list2 = []
    set1 = set()
    set2 = set()
    dict1 = {}
    dict

# Generated at 2022-06-25 21:31:54.726666
# Unit test for function compile_files
def test_compile_files():
    str_0 = None
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert(len(compilation_result_0.dependencies) == 0)
    assert(compilation_result_0.count == 0)
    assert(compilation_result_0.target == tuple_0)
    test_case_0()

# Generated at 2022-06-25 21:32:02.466326
# Unit test for function compile_files
def test_compile_files():

    import os
    import shutil
    import tempfile

    def _assert(dir_, expected_files_and_contents):
        assert os.path.exists(dir_)
        assert os.listdir(dir_) == sorted(expected_files_and_contents.keys())
        for f, expected_content in expected_files_and_contents.items():
            full_f = os.path.join(dir_, f)
            assert os.path.isfile(full_f)
            with open(full_f) as fd:
                assert fd.read() == expected_content

    def _compile_and_assert(input_, output, expected_files_and_contents):
        compile_files(input_, output, CompilationTarget.PYTHON)

# Generated at 2022-06-25 21:32:03.173133
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:32:06.176649
# Unit test for function compile_files
def test_compile_files():
    assert (compile_files('/home/ryan/src/pytojs/tests/fixtures/input/tests',
                          '/home/ryan/src/pytojs/tests/fixtures/output/tests',
                          ('python/')), 'CompilationResult(count=4, time=1.188, target=python3, dependencies=[])') == compilation_result_0

# Generated at 2022-06-25 21:32:10.435577
# Unit test for function compile_files
def test_compile_files():
    inputs = [
        (None, None, None, None)
    ]
    
    outputs = []

    for i in range(len(inputs)):
        if len(outputs) > 0:
            print(outputs[i])
        else:
            print("No output")
        print('\n')

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:16.236967
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("node_modules\\pixi-layers", "build\\pixi-layers", (0, 1, 0)) == CompilationResult(6, 0, (0, 1, 0), [])
    assert compile_files("node_modules\\pixi-layers", "build\\pixi-layers", (0, 1, 0)) == CompilationResult(6, 0, (0, 1, 0), [])
    assert compile_files("node_modules\\pixi-layers", "build\\pixi-layers", (0, 1, 0)) == CompilationResult(6, 0, (0, 1, 0), [])

# Generated at 2022-06-25 21:32:25.253651
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'hello'
    str_1 = 'world'
    str_2 = 'result'
    str_3 = 'tests/input_files'
    str_4 = 'tests/output_files'
    tuple_0 = True
    compilation_result_0 = compile_files(str_3, str_4, tuple_0)
    assert compilation_result_0.files_compiled == 1
    compilation_result_1 = compile_files(str_0, str_1, tuple_0)
    assert compilation_result_1.files_compiled == 0
    compilation_result_2 = compile_files(str_0, str_2, tuple_0)
    assert compilation_result_2.files_compiled == 0

# Generated at 2022-06-25 21:32:38.846050
# Unit test for function compile_files
def test_compile_files():
    example_project_path = './examples/setuptools_example/'
    setup_py_path = example_project_path + 'setup.py'
    compiler_return = compile_files(example_project_path, 'output', CompilationTarget.TOY_PYTHON, None)
    assert compiler_return.target == CompilationTarget.TOY_PYTHON
    assert compiler_return.files_count == 3
    assert compiler_return.time >= 0
    assert compiler_return.dependencies == ['parse_version']

# Generated at 2022-06-25 21:32:41.440330
# Unit test for function compile_files
def test_compile_files():
    str_0 = None
    str_1 = None
    tuple_0 = None
    str_2 = None
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_2)
    test_case_0()


# Generated at 2022-06-25 21:32:43.047461
# Unit test for function compile_files
def test_compile_files():
    # Test case 0
    test_case_0()

# Call function compile_files
test_compile_files()

# Generated at 2022-06-25 21:32:45.488486
# Unit test for function compile_files
def test_compile_files():
    str_0 = None
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    compilation_result_0.print_summary()

# Generated at 2022-06-25 21:32:52.592761
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .utils.helpers import create_temp_folder, remove_temp_folder, copy_resource_tree, assert_paths_equal, to
    temp_folder = create_temp_folder()
    input_path = temp_folder / 'input'
    output_path = temp_folder / 'output'
    output_expected_path = to(__file__, 'compile_expected')
    copy_resource_tree(to(__file__, 'compile_input'), input_path)
    compile_files(input_path, output_path, CompilationTarget.FULL, input_path)
    assert_paths_equal(output_path, output_expected_path)
    remove_temp_folder(temp_folder)

test_case_0()
test_compile_files()

# Generated at 2022-06-25 21:32:56.720279
# Unit test for function compile_files
def test_compile_files():
    input_ = 'input'
    output = 'output'
    target = CompilationTarget.PYTHON_2
    # The first argument will never be None, so we can safely remove it
    arguments = [input_, output, target]
    for arg in arguments:
        assert compile_files(arg, output, target, input_) is not None
        test_case_0()


if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:32:57.392799
# Unit test for function compile_files
def test_compile_files():
    test_case_0()



# Generated at 2022-06-25 21:33:02.779585
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test/fixtures/compile/input'
    output = 'test/fixtures/compile/__pycache__'
    target = (1, 0)
    root = 'test/fixtures'

    dependencies = {'test/fixtures/compile/input/a.py',
                    'test/fixtures/compile/input/b.py',
                    'test/fixtures/compile/input/c.py'}
    result = compile_files(input_, output, target, root)
    assert result.files_compiled == 3
    assert result.elapsed_time > 0
    assert result.target == target
    assert result.dependencies == dependencies

# Generated at 2022-06-25 21:33:05.050691
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('fixtures/foo.py/in', 'fixtures/foo.py/out', (1, 0)) == (0, 0.0, (1, 0), [])


# Generated at 2022-06-25 21:33:11.296385
# Unit test for function compile_files
def test_compile_files():
    with patch('compiler.files.get_input_output_paths') as _get_input_output_paths, \
         patch('compiler._compile_file') as _compile_file:
        _get_input_output_paths.return_value = [
            InputOutput("", ""), InputOutput("", "")
        ]
        _compile_file.return_value = [
            "test1", "test2"
        ]
        start = time()
        original_stdout = sys.stdout
        sys.stdout = StringIO()
        result = compile_files("", "", ("",))
        sys.stdout = original_stdout
        assert result.time == time() - start
        assert result.target == ("",)

# Generated at 2022-06-25 21:33:28.241743
# Unit test for function compile_files
def test_compile_files():
    str_0 = None
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert True


# Generated at 2022-06-25 21:33:34.855465
# Unit test for function compile_files
def test_compile_files():
    str_1 = None
    str_2 = None
    tuple_1 = None
    tuple_2 = None
    tuple_3 = None
    tuple_4 = None
    tuple_5 = None
    tuple_6 = None
    tuple_7 = None
    tuple_8 = None
    tuple_9 = None
    tuple_10 = None
    tuple_11 = None
    tuple_12 = None
    tuple_13 = None
    tuple_14 = None
    tuple_15 = None
    tuple_16 = None
    tuple_17 = None
    tuple_18 = None
    tuple_19 = None
    compilation_result_1 = compile_files(str_1, str_2, tuple_1, str_1)

# Generated at 2022-06-25 21:33:41.619775
# Unit test for function compile_files
def test_compile_files():
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    pth_0 = None
    pth_1 = None
    int_0 = 0
    tuple_0 = None
    compilation_result_0 = CompilationResult(int_0, int_0, tuple_0, tuple_0)
    compilation_result_1 = compile_files(str_1, str_2, tuple_0, str_3)
    list_0 = list()
    pth_2 = Path(str_0)
    list_1 = list()
    list_1.append(compilation_result_1)
    list_0.append(compilation_result_0)

# Generated at 2022-06-25 21:33:42.236277
# Unit test for function compile_files
def test_compile_files():
    print("")
    test_case_0()

# Generated at 2022-06-25 21:33:44.334525
# Unit test for function compile_files
def test_compile_files():
    input_ = "test_input"
    output = "test_output"
    target = 'Python'
    root = None
    test_case_0()

test_compile_files()

# Generated at 2022-06-25 21:33:49.172815
# Unit test for function compile_files
def test_compile_files():
    compilation_result_0 = compile_files('input/python3', 'output/python3', CompilationTarget.python3, None)
    assert(compilation_result_0.files == 166)
    assert(compilation_result_0.time > 0)
    assert(compilation_result_0.target == CompilationTarget.python3)
    # print(compilation_result_0.dependencies)

# Generated at 2022-06-25 21:33:55.984306
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import sys
    import os
    from .types import CompilationTarget
    from .utils.helpers import set_up_logger
    from .config import (
        COMPILATION_SET_FOR_TESTS,
        COMPILATION_TARGET_FOR_TESTS,
    )
    from .functions import compile_files

    set_up_logger()

    def set_up_env():
        for i in range(1, len(sys.argv)):
            os.environ[f'COMPILATION_{i}'] = sys.argv[i].replace(',', ' ')
    set_up_env()


# Generated at 2022-06-25 21:34:01.744176
# Unit test for function compile_files
def test_compile_files():
    from .files import tests as files_tests
    from .transformers import tests as transformers_tests

    files_tests.test_get_input_output_paths()
    transformers_tests.test_skip_transformer()
    transformers_tests.test_transformers()

    # Check that nothing bad happens on empty input
    assert compile_files('/empty', '/empty', (2, 0)) == \
        CompilationResult(0, 0, (2, 0), [])

    # check that a simple file is compiled properly
    assert compile_files('/simple', '/dst', (2, 0)) == \
        CompilationResult(1, 0, (2, 0), [])

    # Check that package is compiled properly
    assert compile_files('/nested', '/dst', (2, 0)) == \
        CompilationResult

# Generated at 2022-06-25 21:34:04.155327
# Unit test for function compile_files
def test_compile_files():
    tests = [
        # TODO: Add your test cases here.
    ]
    for test in tests:
        try:
            test_case_0()
        except:
            print('Error raised for test case: {0}'.format(test))
        else:
            print('Test case passed: {0}'.format(test))
# -------------------------------------------------------------------------------------

if __name__ == '__main__':
    # Begin unit tests.
    test_compile_files()

# Generated at 2022-06-25 21:34:06.624914
# Unit test for function compile_files
def test_compile_files():
    arg0 = './test_data/test_1.py'
    arg1 = './test_data/output'
    arg2 = 'js'
    expect0 = CompilationResult(1, 0.0, 'js', [])
    actual0 = compile_files(arg0, arg1, arg2)
    b0 = str(actual0) == str(expect0)
    assert b0

# Generated at 2022-06-25 21:34:49.104402
# Unit test for function compile_files
def test_compile_files():
    input_ = ""
    output = "test_output/test_compile_files/output"
    target = (2018, 3) #TODO
    root = "test_output/test_compile_files"
    result = compile_files(input_, output, target, root)
    assert result is not None
    assert result.count == 0
    assert result.time > 0
    assert result.target == (2018, 3)
    assert result.dependencies == []

    input_ = "test_sources/test_0.py"
    output = "test_output/test_compile_files/output"
    target = (2018, 3) #TODO
    root = "test_output/test_compile_files"
    result = compile_files(input_, output, target, root)

# Generated at 2022-06-25 21:34:51.905672
# Unit test for function compile_files
def test_compile_files():
    str_0 = None
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)

# Generated at 2022-06-25 21:34:55.012123
# Unit test for function compile_files
def test_compile_files():
    try:
        assert test_case_0() == None
    except AssertionError as e:
        print("code: {}\nresult: {}".format(e.args[0], e.args[1]))

# Generated at 2022-06-25 21:35:01.086671
# Unit test for function compile_files
def test_compile_files():
    test_files_dir = os.path.dirname(__file__)
    inputs_dir = os.path.join(test_files_dir, "../inputs")
    outputs_dir = os.path.join(test_files_dir, "../outputs")
    compilation_result_0 = compile_files(inputs_dir, outputs_dir, CompilationTarget.NODE_JS)
    assert compilation_result_0.get_count() != 0
    assert compilation_result_0.get_time() != 0
    assert compilation_result_0.get_target() == CompilationTarget.NODE_JS
    assert compilation_result_0.get_dependencies() != []
    test_case_0()

# Generated at 2022-06-25 21:35:04.216303
# Unit test for function compile_files
def test_compile_files():
    __params = [
        ("-", "-", [], None),
        ("-", "-", [], "")
    ]
    for case in __params:
        input_ = case[0]
        output = case[1]
        target = case[2]
        root = case[3]
        try:
            test_case_0()
        except Exception as e:
            raise e


# Generated at 2022-06-25 21:35:09.327171
# Unit test for function compile_files
def test_compile_files():

    # Test for compilation success for all targets
    input_ = 'tests/data/demo/input'
    output = 'tests/data/demo/output'
    root = 'tests/data/demo'
    compilation_result = compile_files(input_, output, 'ALL', root)
    assert(compilation_result.duration > 0)
    assert(len(compilation_result.dependencies) > 0)

    # Test for compilation failure due to parser error
    input_ = 'tests/data/error_parser/input'
    output = 'tests/data/error_parser/output'
    root = 'tests/data/error_parser'

# Generated at 2022-06-25 21:35:19.804125
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .utils.helpers import create_file, get_cwd, remove_file

    dir_0 = 'jtetdwgv'
    str_0 = 'bgzlkxjv'
    remove_file(get_cwd(dir_0))


# Generated at 2022-06-25 21:35:20.871462
# Unit test for function compile_files
def test_compile_files():

  assert(compile_files('', '', ('',)) == None)

# Generated at 2022-06-25 21:35:22.876154
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except Exception:
        return False
    return True


if __name__ == '__main__':
    if not test_compile_files():
        print('=== TEST FAILED ===')

# Generated at 2022-06-25 21:35:29.100105
# Unit test for function compile_files
def test_compile_files():
    str_0 = None
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert compilation_result_0.count == 0.0, "compile_files: Expected 0.0, but got: " + str(compilation_result_0.count)
    assert compilation_result_0.duration == 0.0, "compile_files: Expected 0.0, but got: " + str(compilation_result_0.duration)
    assert compilation_result_0.target == tuple_0, "compile_files: Expected " + str(tuple_0) + ", but got: " + str(compilation_result_0.target)

# Generated at 2022-06-25 21:36:06.554382
# Unit test for function compile_files
def test_compile_files():
    # check to see if the compiler returns the correct values with the given inputs
    assert compile_files("test_cases/test_case_0", "test_cases/test_case_0", "test_cases/test_case_0") == CompilationResult(0, 0.0, "test_cases/test_case_0", sorted(set()))
    assert compile_files("test_cases/test_case_1", "test_cases/test_case_1", "test_cases/test_case_1", "test_cases/test_case_1") == CompilationResult(0, 0.0, "test_cases/test_case_1", sorted(set()))

# Generated at 2022-06-25 21:36:09.978085
# Unit test for function compile_files
def test_compile_files():
    # If you have improved this function, please report
    # this test might be unstable, as the file loading and ast parsing
    # are not itself deterministic
    pass
    # TODO:
    # assert_equal(expected, compile_files(input_, output, target, root))
    pass

# Generated at 2022-06-25 21:36:12.621329
# Unit test for function compile_files
def test_compile_files():
    path_0 = 'test_files'
    path_1 = 'output'
    str_0 = '3.5'
    compilation_result_0 = compile_files(path_0, path_1, str_0, path_0)
    assert len(compilation_result_0.dependencies) == 0
    assert compilation_result_0.target == str_0
    assert compilation_result_0.count == 14


# Generated at 2022-06-25 21:36:14.917541
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    compilation_result_0 = compile_files(str_0, str_0, str_0)

    assert compilation_result_0 is None

# Generated at 2022-06-25 21:36:20.518559
# Unit test for function compile_files
def test_compile_files():
    # Test call with parameters: 'test/test_files/test_1/test_1.py', 'test/test_files/test_1/test_1.py', 'js'
    assert compile_files('test/test_files/test_1/test_1.py', 'test/test_files/test_1/test_1.py', 'js') == CompilationResult(count=1,time=0.0013229846954345703,target='js',dependencies=[])
    # Test call with parameters: 'test/test_files/test_2/test_2.py', 'test/test_files/test_2/test_2.py', 'c'

# Generated at 2022-06-25 21:36:22.609893
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input'
    str_1 = 'output'
    str_2 = 'root'
    int_0 = 0
    float_0 = 0.0

    assert compile_files(str_0, str_1, str_2) == CompilationResult(int_0, float_0, str_2, [])

test_case_0()
test_compile_files()

# Generated at 2022-06-25 21:36:26.515395
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    compilation_result_0 = compile_files(str_0, str_0, str_0)
    assert compilation_result_0.count == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == 'py'
    assert compilation_result_0.dependencies == []

    compilation_result_1 = compile_files(str_0, str_0, str_0)
    assert compilation_result_1.count == 0
    assert compilation_result_1.time == 0.0
    assert compilation_result_1.target == 'py'
    assert compilation_result_1.dependencies == []


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:36:27.812172
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    str_1 = str_0
    str_2 = str_1
    compilation_result_0 = compile_files(str_0, str_1, str_2)

# Generated at 2022-06-25 21:36:32.542416
# Unit test for function compile_files
def test_compile_files():

    # Test empty files list
    str_0 = ''
    compilation_result_0 = compile_files(str_0, str_0, str_0)
    assert compilation_result_0.compiled_count == 0
    assert compilation_result_0.compilation_time == 0
    assert compilation_result_0.compilation_target == ''
    assert compilation_result_0.compiled_dependencies == []

    # Test with input and output files in a subfolder
    str_1 = 'sample/in'
    str_2 = 'sample/out'
    compilation_result_1 = compile_files(str_1, str_2, 'py2')
    assert compilation_result_1.compiled_count == 1
    assert compilation_result_1.compilation_time > 0
    assert compilation_result_1.compilation_

# Generated at 2022-06-25 21:36:36.304374
# Unit test for function compile_files
def test_compile_files():
    dirname = os.path.dirname(__file__)
    input_ = os.path.join(dirname, 'tests', 'compilation', 'for_compilation')
    output = os.path.join(dirname, 'tests', 'compilation', 'from_compilation')
    target = 'mixed'
    result = compile_files(input_, output, target)
    assert isinstance(result, CompilationResult)
    assert isinstance(result.dependencies, list)
    assert isinstance(result.time, float)
    assert isinstance(result.target, str)
    assert isinstance(result.processed_files, int)


# test for a single file