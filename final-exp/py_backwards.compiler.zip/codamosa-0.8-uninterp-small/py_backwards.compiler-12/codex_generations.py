

# Generated at 2022-06-25 21:30:02.997295
# Unit test for function compile_files
def test_compile_files():
    # check that the number of test files is set to 0
    test_case_0()


# Testing (runs the unit tests above)

# Generated at 2022-06-25 21:30:04.260961
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:30:04.972385
# Unit test for function compile_files
def test_compile_files():
    assert test_case_0() == None

# Generated at 2022-06-25 21:30:06.002909
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Compiling a single file

# Generated at 2022-06-25 21:30:13.613378
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'res/src/foo'
    str_1 = 'res/generate/foo'
    compilation_result_0 = compile_files(str_0, str_1, CompilationTarget.TO_JS)
    assert compilation_result_0 == CompilationResult(3, compilation_result_0.time, CompilationTarget.TO_JS,
                                                     ['res/src/foo/lib/utils.py', 'res/src/foo/lib/utils.py'])
    print(compilation_result_0)
    # Check if compilation result instance is similar to the expected one.



# Generated at 2022-06-25 21:30:19.568476
# Unit test for function compile_files
def test_compile_files():
    int_0 = -75
    int_1 = -54
    str_0 = 'input'
    str_1 = 'output'
    dict_0 = {
    }
    dict_1 = {
    }
    dict_2 = {
        'b': [False],
        'a': [False],
        'c': [None],
    }
    dict_3 = {
        'b': [False],
        'a': [False],
        'c': [None],
    }
    list_0 = [False]
    list_1 = [59]
    list_2 = [None]
    list_3 = [False, False]
    list_4 = [False]
    list_5 = [None, False]
    list_6 = [False]
    list_7 = [False, False]

# Generated at 2022-06-25 21:30:20.093525
# Unit test for function compile_files
def test_compile_files():
    assert None

# Generated at 2022-06-25 21:30:29.742317
# Unit test for function compile_files
def test_compile_files():
    # Setup:
    test_path = Path('./tests/compiler/')
    test_input = str(test_path/'input')
    test_output = str(test_path/'output')
    test_root = test_path
    test_target = (CompilationTarget.wasm, CompilationTarget.asmjs)

    # Execution:
    output = compile_files(test_input, test_output, test_target, test_root)
    # Assertion:
    assert output.dependencies == ['path/to/path/to/dep',
                                   'path/to/some/other/dep',
                                   'path/to/yet/another/dep']
    assert output.target == test_target
    assert output.count == 5

# Generated at 2022-06-25 21:30:37.491283
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert compilation_result_0.total_time >= 0
    assert compilation_result_0.total_files == 0
    assert compilation_result_0.target == tuple_0
    print("Test case 0: PASSED")


# Generated at 2022-06-25 21:30:39.126171
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:30:56.425430
# Unit test for function compile_files
def test_compile_files():
    input_ = ("module", "example", "c_examples", "std_vector")
    output = ("module", "example", "js_examples", "std_vector")
    target = ("c", "es5")
    root = "./example/c_examples/std_vector"
    func_return_value_0 = compile_files(input_, output, target, root)
    # Assertion 1
    assert (str(func_return_value_0) == "<CompilationResult count=13, " +
                                        "time=0.0012118816375732422, " +
                                        "target=(c, es5), " +
                                        "dependencies=['str', 'stdint', 'time']>")

# Generated at 2022-06-25 21:30:58.699980
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./tests/input/file0.py',
                         './tests/output/file0.py',
                         CompilationTarget.PYTHON37) == \
        CompilationResult(1, 0.45625905990600586, CompilationTarget.PYTHON37,
                          [])



# Generated at 2022-06-25 21:31:00.530365
# Unit test for function compile_files
def test_compile_files():
    assert callable(compile_files)


# test_case_0

# Generated at 2022-06-25 21:31:02.628072
# Unit test for function compile_files
def test_compile_files():
    # If compilation_result_0 is not called the code will not be generated (compile fails)
    test_case_0()



# Generated at 2022-06-25 21:31:04.494060
# Unit test for function compile_files
def test_compile_files():

    try:
        test_case_0()
    except SyntaxError as e:
        assert(e.lineno == 1 and e.offset == 0)

# Generated at 2022-06-25 21:31:05.379313
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:31:11.003176
# Unit test for function compile_files
def test_compile_files():
    import tempfile

    input_ = tempfile.TemporaryDirectory()
    output = tempfile.TemporaryDirectory()
    with open(input_.name+'/test.py', 'w') as f_in:
        f_in.write('a = 1\n'
                   'b = 2')

    compile_files(input_.name, output.name, 'test')
    assert output.name+'/test.py' in open(output.name+'/test.py').read()

# Generated at 2022-06-25 21:31:15.545981
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    print(compilation_result_0, '\n')
    compilation_result_1 = compile_files('C:/dev/python/cldocs-python/cldocs/input/decimal.py', 'C:/dev/python/cldocs-python/cldocs/output/decimal.py', tuple_0, str_0)
    print(compilation_result_1, '\n')
    pass

# Generated at 2022-06-25 21:31:32.418306
# Unit test for function compile_files
def test_compile_files():
  try:
    str_0 = ''
    int_0 = -317
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    assert True
  except (AssertionError, CompilationError, TransformationError) as e:
    print(e)
    assert False


# Generated at 2022-06-25 21:31:39.874561
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    # assert compilation_result_0 == CompilationResult(0, tuple_0, [], None)


if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:31:45.618027
# Unit test for function compile_files
def test_compile_files():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 21:31:48.296666
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)


# Generated at 2022-06-25 21:31:49.709866
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

test_compile_files()

# Generated at 2022-06-25 21:31:50.858624
# Unit test for function compile_files
def test_compile_files():
    test_case_0()
    print('Unit test for compile_files passed')


# Generated at 2022-06-25 21:31:58.441236
# Unit test for function compile_files
def test_compile_files():
    sys_path = sys.path

    current_path = os.path.dirname(os.path.realpath(__file__))
    py_path = os.path.join(current_path, "test_files")
    sys.path.insert(0, py_path)

    input_py = os.path.join(py_path, "input")
    output_py = os.path.join(py_path, "output")

    output_dir = os.path.join(output_py, "dir1")
    assert not os.path.exists(output_dir)

    result = compile_files(input_py, output_py, CompilationTarget.python)

    assert result.count == 6, "compile_files count failed"
    assert result.seconds > 0, "compile_files seconds failed"

# Generated at 2022-06-25 21:32:01.685492
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'test_input.txt'
    str_1 = 'test_output.txt'
    int_0 = 741
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_1, tuple_0, str_0)


# Main function

# Generated at 2022-06-25 21:32:05.924137
# Unit test for function compile_files
def test_compile_files():
    path_0 = Path.cwd() / 'test' / 'test-data' / 'test-case-0'
    str_0 = path_0.as_posix()
    compilation_result_0 = compile_files(str_0, str_0, CompilationTarget.C)

    res_0 = (compilation_result_0.count, compilation_result_0.time,
             compilation_result_0.dependencies)
    assert res_0 == (1, 0.0, [])



# Generated at 2022-06-25 21:32:13.506088
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    # AssertionError: Test Case: test_case_0: Failed: Execution Failed
    # Traceback (most recent call last):
    #   File "/Users/james/dev/pytype-imports/typized_exec.py", line 116, in <module>
    #     test_compile_files()
    #   File "/Users/james/dev/pytype-imports/typized_exec.py", line 108, in test_compile_files
    #     compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)

# Generated at 2022-06-25 21:32:14.498317
# Unit test for function compile_files
def test_compile_files():
    assert True

# Benchmark for function compile_files

# Generated at 2022-06-25 21:32:17.222429
# Unit test for function compile_files
def test_compile_files():
    try:
        str_0 = ''
        int_0 = -317
        tuple_0 = (int_0, int_0)
        compilation_result_0 = compile_files(str_0, str_0, tuple_0, str_0)
    except:
        pass


# Generated at 2022-06-25 21:32:23.952167
# Unit test for function compile_files
def test_compile_files():
    print('Run test for function compile_files')
    test_case_0()
    print('Success')


# Generated at 2022-06-25 21:32:30.558936
# Unit test for function compile_files
def test_compile_files():
    test_cases = [("", "", -317, "")]
    for tc in test_cases:
        try:
            assert(all(map(lambda x, y: x == y, test_case_0(), tc)))
        except:
            print("Function: compile_files")
            for i in range(len(tc)):
                print("\tinput [{}]: {}".format(i, tc[i]))
                print("\texpected output [{}]: {}".format(i, tc[i]))
                print("\tactual output [{}]: {}".format(i, test_case_0()[i]))
            return
    print("PASSED: Function: compile_files")


# Generated at 2022-06-25 21:32:35.085973
# Unit test for function compile_files
def test_compile_files():
    int_0 = 0  # type: int
    str_0 = ''  # type: str
    compilation_result_0 = compile_files(str_0, str_0, int_0, str_0)
    assert len(compilation_result_0.dependencies) == 0  # type: ignore
    assert compilation_result_0.target == 0  # type: ignore
    assert compilation_result_0.files_count == 0  # type: ignore

# Generated at 2022-06-25 21:32:36.265477
# Unit test for function compile_files
def test_compile_files():
    print(test_case_0())

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-25 21:32:42.788223
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    compilation_result_0 = compile_files(str_0, str_0, int_0, str_0)
    assert compilation_result_0.count == 0
    assert compilation_result_0.time == 0.0
    assert compilation_result_0.target == int_0
    assert compilation_result_0.dependencies == []
    assert compilation_result_0.__dict__ == {'count': 0,
                                             'time': 0.0,
                                             'target': int_0,
                                             'dependencies': []}

# Generated at 2022-06-25 21:32:43.495458
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:32:50.795192
# Unit test for function compile_files
def test_compile_files():
    int_0 = 1
    str_0 = 'path1.txt'
    str_1 = 'path1.txt'
    int_1 = -317
    str_2 = 'path1.txt'
    str_3 = ''
    compilation_result_0 = compile_files(str_2, str_3, int_1, str_0)
    assert compilation_result_0.count == int_0
    assert compilation_result_0.target == int_1
    assert compilation_result_0.duration >= float(0)
    assert all(v is True for v in map(lambda s: s in compilation_result_0.dependencies, [str_1]))
    assert all(v is False for v in map(lambda s: s in compilation_result_0.dependencies, [str_2]))

# Unit test

# Generated at 2022-06-25 21:32:57.231081
# Unit test for function compile_files
def test_compile_files():
    int_0 = -606
    str_0 = ''
    str_1 = ''
    int_1 = -606
    str_2 = ''
    compilation_result_0 = compile_files(str_0, str_1, int_0, str_2)
    assert compilation_result_0.count == 0
    assert compilation_result_0.duration >= 0
    assert compilation_result_0.target == int_1
    assert compilation_result_0.dependencies == []
    int_2 = -358
    compilation_result_1 = compile_files(str_0, str_1, int_1, str_2)
    assert compilation_result_1.count == 0
    assert compilation_result_1.duration >= 0
    assert compilation_result_1.target == int_2
    assert compilation_result_1.depend

# Generated at 2022-06-25 21:32:58.797478
# Unit test for function compile_files
def test_compile_files():
    assert str(compilation_result_0.time) == '0.0'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:33:01.232970
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    compilation_result_0 = compile_files(str_0, str_0, int_0, str_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:33:16.491637
# Unit test for function compile_files
def test_compile_files():
    filename = "tests/test_fixtures/js/add.js"
    filename_out = "tests/test_fixtures/out/add.js"
    with open(filename, 'r') as f:
        code = f.read()
    with open(filename_out, 'r') as f:
        code_out = f.read()
    paths = InputOutput(filename, filename_out)
    target = CompilationTarget.DEFAULT

    # Compile the file, then compare output to expected
    code, dependencies = _transform(paths.input.as_posix(), code, target)
    assert code == code_out

    # Make sure output file is generated
    assert paths.output.exists()

# Generated at 2022-06-25 21:33:23.914566
# Unit test for function compile_files
def test_compile_files():

    target_0 = 'x'
    source_path_0 = '/tmp/py_compile_source/'
    nb_0 = 288
    lst_0 = [1]
    str_0 = 'tree'
    compilation_result_0 = compile_files(target_0, source_path_0, nb_0, str_0)
    assert compilation_result_0 == lst_0, 'Test 0: wrong result'

    target_1 = 'n'
    source_path_1 = 'target'
    nb_1 = 0
    lst_1 = [1]
    str_1 = '/tmp/py_compile_source/'
    compilation_result_1 = compile_files(target_1, source_path_1, nb_1, str_1)
    assert compilation_result_

# Generated at 2022-06-25 21:33:26.309420
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    compilation_result_0 = compile_files(str_0, str_0, int_0, str_0)
    assert not compilation_result_0


# Benchmark for function compile_files

# Generated at 2022-06-25 21:33:34.854254
# Unit test for function compile_files
def test_compile_files():
    with open(r"tests/fixtures/source/source.py") as f:
        code = f.read()
    try:
        ast.parse(code, r"tests/fixtures/source/source.py")
    except Exception as e:
        raise CompilationError(r"tests/fixtures/source/source.py",
                               code, e.lineno, e.offset)
    # Test if the function raises an error when called with wrong parameters
    try:
        compile_files(-317, r"tests/fixtures/source/source.py")
    except TypeError:
        pass
    # Test if the function raises an error when called with wrong parameters
    try:
        compile_files(r"tests/fixtures/source/source.py", -317)
    except TypeError:
        pass
    # Test if the

# Generated at 2022-06-25 21:33:41.608288
# Unit test for function compile_files
def test_compile_files():

    # SyntaxError is raised only when some error occured

    try:
        # Empty source
        test_case_0()

    except SyntaxError:
        pass

    else:
        assert False, 'SyntaxError not raised'

    # Number of compiled files

    int_0 = 0
    int_1 = 0
    compilation_result_0 = compile_files('', '', int_0)

    int_0 = 1
    compilation_result_1 = compile_files('', '', int_0)

    if (compilation_result_0.statistics.number_of_compiled_files >
            compilation_result_1.statistics.number_of_compiled_files):
        assert False, 'Wrong number of compiled files'

    # Code compiles

    str_0 = 'test.py'

# Generated at 2022-06-25 21:33:45.807489
# Unit test for function compile_files
def test_compile_files():
    input_ = Path(__file__).parent.parent / 'input' / 'test_transform.py'
    output = Path(__file__).parent.parent / 'output' / 'test_transform.py'
    compile_files(input_, output, CompilationTarget.PY3_ONLY)
    if __name__ == '__main__':
        import unittest
        unittest.main()

# Generated at 2022-06-25 21:33:50.452945
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    int_0 = -317
    compilation_result_0 = compile_files(str_0, str_0, int_0, str_0)
    assert isinstance(compilation_result_0, CompilationResult)
    assert compilation_result_0.count == 0
    assert compilation_result_0.target == int_0
    assert isinstance(compilation_result_0.time_spent, float)
    assert compilation_result_0.dependencies == []

# Generated at 2022-06-25 21:33:51.335378
# Unit test for function compile_files
def test_compile_files():
    # test case 0
    test_case_0()
    return


# Generated at 2022-06-25 21:33:53.999378
# Unit test for function compile_files

# Generated at 2022-06-25 21:34:00.129908
# Unit test for function compile_files
def test_compile_files():
    python_code_0 = '\n#!/usr/bin/env python\n#\n# Script is generated. Do not edit manually.\n#\n\n\ndef \\() -> str: pass\n\n\n\n\n\n\n\n\n\n\n\n'
    string_0 = 'test'
    string_1 = 'test'
    compilation_target_0 = CompilationTarget.WINDOWS_STANDALONE_EXECUTABLE
    compilation_result_0 = compile_files(string_0, string_1, compilation_target_0)
    assert(compilation_result_0.dependencies == [])
    assert(compilation_result_0.target == compilation_target_0)
    assert(compilation_result_0.elapsed >= 0.0)