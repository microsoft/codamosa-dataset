

# Generated at 2022-06-25 21:30:15.306724
# Unit test for function compile_files

# Generated at 2022-06-25 21:30:22.791239
# Unit test for function compile_files
def test_compile_files():
    # Python syntax error in module 'mod.py', line 2, offset 3
    # def function_0():
    #        pass
    #    ^
    # SyntaxError: invalid syntax
    try:
        compile_files('mod.py', 'mod.py', 0)
        assert False
    except CompilationError as e:
        pass

    # Python syntax error in module 'mod.py', line 9, offset 3
    # def function_0():
    #        pass
    #    ^
    # SyntaxError: invalid syntax
    try:
        compile_files('mod.py', 'mod.py', 1)
        assert False
    except CompilationError as e:
        pass


# Generated at 2022-06-25 21:30:25.207249
# Unit test for function compile_files
def test_compile_files():
    test_case_0()
    test_case_1()

# Test # 0

# Generated at 2022-06-25 21:30:27.986771
# Unit test for function compile_files
def test_compile_files():
    str_0 = '0'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)


# Generated at 2022-06-25 21:30:36.446035
# Unit test for function compile_files
def test_compile_files():
    str_0 = '0'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    print(compilation_result_0.elapsed, compilation_result_0.target, compilation_result_0.dependencies, compilation_result_0.count)



# for test in [test_case_0]:
#     test()
test_compile_files()

# Generated at 2022-06-25 21:30:41.241895
# Unit test for function compile_files
def test_compile_files():
    # Setup for test case 0
    str_0 = '0'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)

    assert compilation_result_0.count == 0
    assert compilation_result_0.time >= 0
    assert compilation_result_0.target == tuple_0
    assert sorted(compilation_result_0.dependencies) == []

# Generated at 2022-06-25 21:30:49.064440
# Unit test for function compile_files

# Generated at 2022-06-25 21:30:50.088933
# Unit test for function compile_files
def test_compile_files():
    assert True == True


# Generated at 2022-06-25 21:30:53.177831
# Unit test for function compile_files
def test_compile_files():
    str_0 = '0'
    tuple_0 = None
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)


# Generated at 2022-06-25 21:30:56.881045
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'test/test_fixtures/inputs/test'
    str_1 = 'test/test_fixtures/outputs/test'
    tuple_0 = CompilationTarget.LOWER
    test_case_0()


# Generated at 2022-06-25 21:31:04.841411
# Unit test for function compile_files
def test_compile_files():
    with open('test_case', 'r') as f:
        lines = f.read().splitlines()

    for i in range(1, len(lines)):
        test_case_0(*lines[i].split(' '))

# Generated at 2022-06-25 21:31:12.628561
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    compilation_result_0 = compile_files(str_0, str_0, str_0)
    assert (str_0 == compilation_result_0.output_count)
    assert (str_0 == compilation_result_0.time)
    assert (str_0 == compilation_result_0.target)
    assert (str_0 == compilation_result_0.dependencies)
    str_3 = 'pjw{0y+L!&3'
    str_4 = '{R+f}'
    str_5 = '{R+f}'
    compilation_result_1 = compile_files(str_3, str_3, str_4)
    assert (str_5 == compilation_result_1.output_count)


# Generated at 2022-06-25 21:31:14.290059
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:32.418379
# Unit test for function compile_files
def test_compile_files():
    with pytest.raises(TypeError):
        compile_files(1, 1, 1)

    with pytest.raises(TypeError):
        compile_files(1.0, 1, 1)

    with pytest.raises(TypeError):
        compile_files(1, 1.0, 1)

    with pytest.raises(TypeError):
        compile_files(1, 1, 1.0)

    with pytest.raises(TypeError):
        compile_files(1, 1, 1, 1)

    with pytest.raises(TypeError):
        compile_files(1.0, 1, 1, 1)

    with pytest.raises(TypeError):
        compile_files(1, 1.0, 1, 1)

    with pytest.raises(TypeError):
        compile_

# Generated at 2022-06-25 21:31:41.443806
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(
        "input_test_compile/inputs/python-3.7/compile.py",
        "output_test_compile/python-3.7/compile.py",
        CompilationTarget.JS)
    assert compile_files(
        "input_test_compile/inputs/python-3.7/compile.py",
        "output_test_compile/python-3.7/compile.py",
        CompilationTarget.PY)

test_case_0()
test_compile_files()

# Generated at 2022-06-25 21:31:48.267798
# Unit test for function compile_files
def test_compile_files():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    compilation_result_0 = compile_files(str_0, str_0, str_0, str_0)
    assert isinstance(compilation_result_0, CompilationResult)
    compilation_result_1 = compile_files(str_1, str_1, str_1, str_1)
    assert isinstance(compilation_result_1, CompilationResult)
    compilation_result_2 = compile_files(str_2, str_2, str_2, str_2)
    assert isinstance(compilation_result_2, CompilationResult)



# Generated at 2022-06-25 21:31:52.357377
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'input_dir/source_file.py'
    str_1 = 'output_dir/source_file.py'
    compilation_result_0 = compile_files(str_0, str_1, 'COMPILATION_TARGET_UNKNOWN')
    assert compilation_result_0.dependencies == list
    assert compilation_result_0.time == float
    assert compilation_result_0.target == 'COMPILATION_TARGET_PYPY3'
    assert compilation_result_0.files_processed == int

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 21:31:54.164346
# Unit test for function compile_files
def test_compile_files():
    input_ = 'input'
    output = 'output'
    target = 'target'
    test_case_0()

# Generated at 2022-06-25 21:32:01.886954
# Unit test for function compile_files
def test_compile_files():
    # If a fluent interface (src https://en.wikipedia.org/wiki/Fluent_interface) was used
    # then assert_that(compile_files().with_input().with_output().with_target().get(), equal_to())
    # would be possible, but that would require using pytest-bdd
    str_0 = './tests/simple/simple_input'
    str_1 = './tests/simple/simple_output'
    str_2 = './tests/simple/simple_input/a.py'
    str_3 = './tests/simple/simple_output/a.js'
    str_4 = './tests/simple/simple_input/b.py'
    str_5 = './tests/simple/simple_output/b.js'

# Generated at 2022-06-25 21:32:03.490982
# Unit test for function compile_files
def test_compile_files():
    # Test for invalid type
    with pytest.raises(InvalidTypeError):
        compile_files(1, 1, 1)

