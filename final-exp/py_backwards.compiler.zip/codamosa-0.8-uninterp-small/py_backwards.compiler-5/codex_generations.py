

# Generated at 2022-06-25 21:30:12.364962
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    tuple_0 = (int_0, int_0)
    # Pre-conditions
    assert True

    # Execution under test
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)

    # Post-conditions
    assert compilation_result_0.count == int_0
    assert compilation_result_0.dependencies == tuple_0
    assert compilation_result_0.target == tuple_0


# Generated at 2022-06-25 21:30:16.026637
# Unit test for function compile_files
def test_compile_files():
    # Create Unittest object
    unittest_obj = unittest.TestCase()

    # Execute function
    test_case_0()

    # Check exception
    with unittest_obj.assertRaises(Exception):
        test_case_0()

# Run tests (only if the file is main)
if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:30:22.252422
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    tuple_1 = ('test_result_0', 'test_result_1', 'test_result_2')
    assert compilation_result_0 == tuple_1


# Generated at 2022-06-25 21:30:29.452483
# Unit test for function compile_files

# Generated at 2022-06-25 21:30:40.144523
# Unit test for function compile_files
def test_compile_files():
    from random import randint
    from random import seed
    from pathlib import Path

    tmp = Path.home() / '.cache' / 'pytonjs'
    tmp.mkdir(parents=True, exist_ok=True)
    seed(1)  # make tests deterministic
    input_ = f'{tmp}/{randint(0, 100000)}'
    output = f'{tmp}/{randint(0, 100000)}'
    target = CompilationTarget.RELEASE
    root = f'{tmp}/{randint(0, 100000)}'
    compilation_result_0 = compile_files(input_, output, target, root)
    assert(type(compilation_result_0) == CompilationResult)


# Generated at 2022-06-25 21:30:45.736935
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)
    assert compilation_result_0.total_time > 0
    assert compilation_result_0.target == tuple_0
    assert compilation_result_0.count == 0
    assert compilation_result_0.dependencies == []



# Generated at 2022-06-25 21:30:50.254192
# Unit test for function compile_files
def test_compile_files():
    # Minimal test case
    test_case_0()
    try:
        # Most common use case
        compile_files('.', '.', (3,))
    except CompilationError:
        print('Error when calling the function compile_files with file inputs')

# Generated at 2022-06-25 21:31:01.117463
# Unit test for function compile_files
def test_compile_files():
    # AssertionError: CompilationResult(count=4, duration=0.103467960357666, target=<CompilationTarget.javascript: 1>, dependencies=[]) == CompilationResult(count=4, duration=0.103467960357666, target=<CompilationTarget.javascript: 1>, dependencies=[])
    assert CompilationResult(4, 0.103467960357666, CompilationTarget.javascript, []) == CompilationResult(4, 0.103467960357666, CompilationTarget.javascript, [])

if __name__ == '__main__':
    import sys
    funcs = globals()
    print(sys.argv)

# Generated at 2022-06-25 21:31:06.655312
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    tuple_0 = (int_0, int_0)
    compilation_result_0 = compile_files(str_0, str_0, tuple_0)

if __name__ == '__main__':
    start = time()
    for i in range(100000):
        test_case_0()
    print("time = ", time() - start)

# Generated at 2022-06-25 21:31:08.025304
# Unit test for function compile_files
def test_compile_files():
    test_case_0()


if __name__ == '__main__':
    test_compile_files()
    print('Documentation: https://github.com/brython-dev/brython/issues/9')

# Generated at 2022-06-25 21:31:32.418336
# Unit test for function compile_files
def test_compile_files():
    with open('pytojs/tests/examples/files/hello.py') as file_0:
        str_0 = file_0.read(-1426)
    with open('pytojs/tests/examples/files/hello.out.py') as file_1:
        str_1 = file_1.read(-1513)
    int_0 = -2848
    compilation_result_0 = compile_files('pytojs/tests/examples/files/hello.py', 'pytojs/tests/examples/files/hello.out.py', int_0, None)
    assert repr(compilation_result_0.count) == repr(1)
    assert repr(compilation_result_0.time) == repr(0)
    assert compilation_result_0.target == CompilationTarget.pypy
   

# Generated at 2022-06-25 21:31:33.787882
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:31:38.179606
# Unit test for function compile_files
def test_compile_files():
    """Test if compile_files runs correctly

    >>> compile_files('/tmp/input', '/tmp/output', 18)
    """
    test_case_0()

# Generated at 2022-06-25 21:31:39.873711
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:31:43.725333
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    compilation_result_0 = compile_files(str_0, str_0, int_0)
    assert (compilation_result_0.target) == int_0
    assert (compilation_result_0.count) == 0


# Generated at 2022-06-25 21:31:50.984097
# Unit test for function compile_files
def test_compile_files():
    int_0 = -9127
    str_0 = 'Cookie'
    str_1 = 'http://www.google.com/search'
    result_0 = compile_files(str_0, str_1, int_0, None)

    # Ensure result_0's has the correct attribute types.
    assert isinstance(result_0, CompilationResult)
    assert isinstance(result_0.count, int)
    assert isinstance(result_0.time, float)
    assert isinstance(result_0.target, int)
    assert isinstance(result_0.dependencies, list)

    # Ensure result_0's attributes have the correct values.
    assert result_0.count == 0
    assert result_0.time > 0
    assert result_0.target == int_0

# Generated at 2022-06-25 21:31:51.866276
# Unit test for function compile_files
def test_compile_files():
    test_case_0()



# Generated at 2022-06-25 21:31:54.164807
# Unit test for function compile_files
def test_compile_files():
    import unittest

    import os
    import random

    try:
        import pathlib2
    except ImportError:
        import pathlib as pathlib2


# Generated at 2022-06-25 21:31:55.273894
# Unit test for function compile_files
def test_compile_files():
    test_case_0()

# Generated at 2022-06-25 21:32:02.772126
# Unit test for function compile_files
def test_compile_files():
    from sys import argv
    from argparse import ArgumentParser
    from .utils.helpers import parse_target
    from .errors import format_exception

    parser = ArgumentParser()
    parser.add_argument('input', help='the input directory')
    parser.add_argument('output', help='the output directory')
    parser.add_argument('target', help='the target (JS, CS2JS, CSS3JS, ...)')
    parser.add_argument('--root', help='the root directory')

    args, _ = parser.parse_known_args(argv[1:])

    target = parse_target(args.target)

    try:
        result = compile_files(args.input, args.output, target, args.root)
    except Exception as e:
        print(str(e))
        exit(1)

# Generated at 2022-06-25 21:32:09.913281
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Main function entrypoint

# Generated at 2022-06-25 21:32:12.484014
# Unit test for function compile_files
def test_compile_files():
    print('Testing compile_files')

    try:
        test_case_0()
    except:
        print('FAILED: Cannot run test case 0')
        raise

    print('PASSED: compile_files')

# Generated at 2022-06-25 21:32:15.056412
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        print('Exception in test_compile_files')
        import traceback
        traceback.print_exc()
        assert False

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:32:18.273046
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    compilation_result_0 = compile_files(str_0, str_0, int_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 21:32:26.992916
# Unit test for function compile_files
def test_compile_files():
    import random

    # Test
    input = './simple_input'
    output = './simple_output'
    target = CompilationTarget.PYTHON3
    root = './'
    result = compile_files(input, output, target, root)

    # Check
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON3
    assert './simple_input/foo1.py' in result.dependencies
    assert './simple_input/foo2.py' in result.dependencies

    # Test
    input = './simple_input/foo1.py'
    output = './simple_output'
    target = CompilationTarget.PYTHON3
    root = './'
    result = compile_files(input, output, target, root)

    # Check


# Generated at 2022-06-25 21:32:29.282999
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    compilation_result_0 = compile_files(str_0, str_0, int_0)

    assert compilation_result_0 is not None



# Generated at 2022-06-25 21:32:31.850868
# Unit test for function compile_files
def test_compile_files():
    debug(lambda: 'Starting function test_compile_files...')
    for i in range(300):
        test_case_0()
    debug(lambda: '\n')
    debug(lambda: 'Completed function test_compile_files...\n')

# Generated at 2022-06-25 21:32:34.137397
# Unit test for function compile_files
def test_compile_files():
    input_src = "input_src"
    output_src = "output_src"
    target = 1
    root = "root"
    compile_files(input_src, output_src, target, root)



# Generated at 2022-06-25 21:32:37.313333
# Unit test for function compile_files
def test_compile_files():
    paths_input = 'HTTPRedirectHandler'
    paths_output = 'HTTPRedirectHandler'
    target = -1517
    root = 'HTTPRedirectHandler'
    assert len(compile_files(paths_input, paths_output, target, root)) == 2


# Generated at 2022-06-25 21:32:45.144521
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    compilation_result_0 = compile_files(str_0, str_0, int_0)
    assert compilation_result_0.compiled_count == 0
    assert compilation_result_0.duration >= 0.0
    assert compilation_result_0.target == -1517
    assert compilation_result_0.dependencies == []

    str_0 = 'HTTPConnection'
    int_0 = -1263
    compilation_result_0 = compile_files(str_0, str_0, int_0)
    assert compilation_result_0.compiled_count == 0
    assert compilation_result_0.duration >= 0.0
    assert compilation_result_0.target == -1263
    assert compilation_result_0.dependencies

# Generated at 2022-06-25 21:32:55.861399
# Unit test for function compile_files
def test_compile_files():
    print("test_compile_files:")
    try:
        test_case_0()
    except Exception as e:
        print("Error:", str(e))

# Generated at 2022-06-25 21:32:58.428076
# Unit test for function compile_files
def test_compile_files():
    # Test for valid arguments:
    assert compile_files('HTTPRedirectHandler', 'HTTPRedirectHandler', -1517) != None
    # Test for invalid arguments, with no exceptions (this function is not aware of the arguments):
    assert compile_files('3', '3', '3') != None


# Generated at 2022-06-25 21:32:59.809333
# Unit test for function compile_files
def test_compile_files():
    try:
        test_case_0()
    except:
        return False

    return True


# Generated at 2022-06-25 21:33:01.689490
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    compilation_result_0 = compile_files(str_0, str_0, int_0)


# Generated at 2022-06-25 21:33:05.042413
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    compilation_result_0 = compile_files(str_0, str_0, int_0)
    print('compilation result:')
    print(compilation_result_0)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-25 21:33:06.177289
# Unit test for function compile_files
def test_compile_files():
    print("Unit test for function compile_files")
    test_case_0()


# Generated at 2022-06-25 21:33:12.414492
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('/useful/reports/config.json', '/useful/reports/config.json', 41).count == 0
    assert compile_files('/view/now/payments', '/view/now/payments', 1).count == 0
    assert compile_files('/my/file/path.go', '/my/file/path.go', 1).count == 0
    assert compile_files('/my/file/path.go/', '/my/file/path.go/', 1).count == 0
    assert compile_files('/my/file/path.go/something/else', '/my/file/path.go/something/else', 1).count == 0
    assert compile_files('/my/file/path.go/something', '/my/file/path.go/something', 1).count == 0
    assert compile_files

# Generated at 2022-06-25 21:33:19.824238
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    str_1 = 'urllib.request'
    str_2 = '=='
    str_3 = '=='
    str_4 = '__main__'
    str_5 = '=='
    str_6 = '!='
    str_7 = '!='
    str_8 = '=='
    str_9 = '!='
    str_10 = '=='
    str_11 = '!='
    str_12 = '__main__'
    str_13 = '!='
    str_14 = '=='
    str_15 = '!='
    str_16 = '!='
    str_17 = '__main__'
    str_18 = '__main__'
    str_19 = '!='
    str

# Generated at 2022-06-25 21:33:21.330396
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('http://www.google.com/', 'https://www.google.com/', 0) is None


# Generated at 2022-06-25 21:33:27.730996
# Unit test for function compile_files
def test_compile_files():
    str_0 = 'HTTPRedirectHandler'
    int_0 = -1517
    test_case_0()

# AddressSanitizer:DEADLYSIGNAL
#   ==3460==ERROR: AddressSanitizer: SEGV on unknown address 0x000000000000 (pc 0x0000004c4b4d bp 0x7ffd27b73a80 sp 0x7ffd27b739e8 T0)
#   ==3460==The signal is caused by a READ memory access.
#   ==3460==Hint: address points to the zero page.
#
# ===================SUMMARY==================================================
# ==3460==ERROR: AddressSanitizer: SEGV on unknown address 0x000000000000 (pc 0x0000004c4b4d bp 0x7ffd27b73a80 sp