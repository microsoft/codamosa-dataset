

# Generated at 2022-06-23 22:04:55.155877
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import is_close
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as d:
        assert compile_files('./dummy-input',
                             '{}/output'.format(d),
                             CompilationTarget.PY3,
                             './dummy-root') == \
            CompilationResult(1, is_close(0), CompilationTarget.PY3, [])

        assert compile_files('./dummy-input',
                             '{}/output'.format(d),
                             CompilationTarget.PY3,
                             './dummy-root') == \
            CompilationResult(0, is_close(0), CompilationTarget.PY3, [])

# Generated at 2022-06-23 22:05:06.521670
# Unit test for function compile_files
def test_compile_files():
    import io
    import os

    import pytest

    from .types import CompilationTarget

    from .mocks.mocked_config import Config
    from .mocks.mocked_logger import Logger
    from .mocks.mocked_dependencies import Dependencies

    from .mocks.mocked_settings import settings
    from .mocks.mocked_targets import targets
    from .mocks.mocked_transformers import transformers

    @pytest.mark.parametrize('target', targets.keys())
    def test_compile_target(target: CompilationTarget):
        def patch_config(settings_):
            settings_.config = Config()

        def patch_logger(settings_):
            settings_.logger = Logger()


# Generated at 2022-06-23 22:05:13.854451
# Unit test for function compile_files
def test_compile_files():
    # TODO: Test with root
    input_ = 'input/some_lib'
    output = 'output'
    target = CompilationTarget.py3
    result = compile_files(input_, output, target)
    assert result.count == 1
    assert result.target == target
    assert result.dependencies == list()

# Generated at 2022-06-23 22:05:16.689414
# Unit test for function compile_files
def test_compile_files():
    output = Path('test/temp')
    try:
          compile_files('test/test_data', output, CompilationTarget.PROGRAM)
    except:
        pass

test_compile_files()

# Generated at 2022-06-23 22:05:20.206676
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    tmp = TemporaryDirectory()
    open(tmp.name + "/a", "a").close()
    compile_files(tmp.name + "/a", tmp.name + "/b", CompilationTarget.PYTHON)


# Generated at 2022-06-23 22:05:29.074940
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import mkdtemp
    from .utils.temp_import import import_to_temp
    from .utils.helpers import init_logger
    from .exceptions import CompilationError

    init_logger()

    src = mkdtemp(prefix='hypothesis-')
    dst = mkdtemp(prefix='hypothesis-')
    Path(src, '__init__.py').touch()
    Path(dst, '__init__.py').touch()
    Path(src, 'test.py').write_text(
        test_compile_files.__doc__, encoding='utf-8')


# Generated at 2022-06-23 22:05:40.580571
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import create_file, capture_stdout
    from .console import compile_files as cf
    import os
    import shutil

    # Create temporary files
    tmpdir = 'tmpdir'
    os.mkdir(tmpdir)
    create_file(os.path.join(tmpdir, 'README.md'), '')
    create_file(os.path.join(tmpdir, 'a.py'), '')
    create_file(os.path.join(tmpdir, 'b.py'), '')
    create_file(os.path.join(tmpdir, 'c.py'), '')
    create_file(os.path.join(tmpdir, 'dir', 'aux.py'), '')

# Generated at 2022-06-23 22:05:44.190403
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(['__tests__/input.py', '__tests__/input2.py'], '__tests__/output', CompilationTarget.PYTHON3_7)



# Generated at 2022-06-23 22:05:47.852483
# Unit test for function compile_files
def test_compile_files():
    import tempfile, os, shutil
    d = tempfile.mkdtemp()
    print('Output is in {}'.format(d))

# Generated at 2022-06-23 22:05:49.669561
# Unit test for function compile_files
def test_compile_files():
    from .tests.compiler_test import test_compile_files
    test_compile_files()

# Generated at 2022-06-23 22:05:58.132511
# Unit test for function compile_files
def test_compile_files():
    import os
    import shlex
    import shutil
    import subprocess
    import tempfile

    # Test: compile
    tmpdir = tempfile.mkdtemp()
    try:
        subprocess.check_call(shlex.split(
            'git clone https://github.com/vim/vim.git {}'.format(tmpdir)))
        result = compile_files(tmpdir, tmpdir,
                               CompilationTarget.py_36)
        assert result.count == 4796
        assert result.target == CompilationTarget.py_36
        assert result.time > 0
        assert result.dependencies == ['_tkinter', 'os', 'shutil', 'subprocess']
    finally:
        shutil.rmtree(tmpdir)

    # Test: compile single file
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 22:06:05.539661
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .testing import test_input_dir, test_output_dir, test_input_dir2, test_output_dir2
    test_input_dir.mkdir(parents=True)
    test_output_dir.mkdir(parents=True)
    test_input_dir2.mkdir(parents=True)
    test_output_dir2.mkdir(parents=True)

# Generated at 2022-06-23 22:06:13.226620
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from pathlib import Path
    shutil.rmtree("out", ignore_errors=True)
    out = compile_files("src", "out", CompilationTarget.PY35)
    out.stat()
    tree = sorted(Path("out").glob("**/*"))
    assert tree == [Path("out/foo.py"), Path("out/sub/subsub.py"), Path("out/sub/sub.py")]
    with open("out/sub/subsub.py") as f:
        code = f.read()

# Generated at 2022-06-23 22:06:22.605365
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from pathlib import Path

    input_ = Path.cwd() / "tests"
    output = Path.cwd() / "tests" / "output"
    shutil.rmtree(output, ignore_errors=True)

    res = compile_files(input_, output, CompilationTarget.PYTHON)
    assert res.number_of_files == 3
    assert res.output_target == CompilationTarget.PYTHON

    from .utils.helpers import load_file
    for inp, out in get_input_output_paths(input_, output):
        assert load_file(out) == load_file(inp)

    shutil.rmtree(output, ignore_errors=True)


# Generated at 2022-06-23 22:06:33.868245
# Unit test for function compile_files
def test_compile_files():
    import tempfile, os

    test_input = tempfile.mkdtemp()
    test_output = tempfile.mkdtemp()

    def _test_file(name, input_content, output_content):
        with open(os.path.join(test_input, name), 'w') as f:
            f.write(input_content)
        compile_files(test_input, test_output, CompilationTarget.CPYTHON, root=None)
        with open(os.path.join(test_output, name)) as f:
            assert f.read() == output_content

    # Python only
    _test_file('a.py', 'print(5)', 'print(5)\n')

    # Syntax error

# Generated at 2022-06-23 22:06:38.758236
# Unit test for function compile_files
def test_compile_files():
    input_ = Path(__file__).parent / 'tests' / 'data' / 'input'
    output = Path(__file__).parent / 'tests' / 'data' / 'output'
    result = compile_files(input_, output, CompilationTarget.JS)
    assert result.count == 2
    assert set(result.dependencies) == \
           {'fs', 'os', 'sys', 'time'}

# Generated at 2022-06-23 22:06:45.343913
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import unittest
    from .samples import simple_program

    code = simple_program.simple_program

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.input_dir = tempfile.TemporaryDirectory()
            self.output_dir = tempfile.TemporaryDirectory()
            self.sample_file = os.path.join(self.input_dir.name, 'sample.py')

            with open(self.sample_file, 'w') as f:
                f.write(code)

        def tearDown(self):
            self.input_dir.cleanup()
            self.output_dir.cleanup()


# Generated at 2022-06-23 22:06:53.626500
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import tempfile
    import subprocess
    import shlex

    class TestCompile(unittest.TestCase):
        def test_compile(self):
            with tempfile.TemporaryDirectory() as tmpdir:

                # compile
                in_path = 'tests/compile/'
                out_path = tmpdir
                compile_files(in_path, out_path, CompilationTarget.TESTS)

                # run
                command = 'python -m unittest discover -s {}'.format(out_path)
                command = shlex.split(command)
                subprocess.check_call(command)

    unittest.main()

# Generated at 2022-06-23 22:07:04.075621
# Unit test for function compile_files
def test_compile_files():
    from .__main__ import _compile_files
    def _on_compile(target_):
        def wrapper(f):
            def wrapped():
                _compile_files('tests', 'tests.output', target_)
                return f()
            return wrapped
        return wrapper

    @_on_compile(CompilationTarget.PY2)
    def test_py2():
        with open('tests/compile_files/py2.output/test.py') as f:
            assert f.read() == 'a = [x for x in range(10)]\n'


# Generated at 2022-06-23 22:07:11.062816
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import os

    class CompileFilesTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            if os.path.exists('test/build/'):
                import shutil
                shutil.rmtree('test/build/')
            os.makedirs('test/build/')

        def test_compile_files_hello(self):
            compile_files('test/hello/', 'test/build/', 'auto')

            self.assertTrue(os.path.exists('test/build/hello.js'))
            with open('test/build/hello.js') as f:
                result = f.read()

# Generated at 2022-06-23 22:07:14.189069
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('../test_data/test_this',
                         '../test_data/transformers_output',
                         CompilationTarget.ES5).count == 5

# Generated at 2022-06-23 22:07:15.128126
# Unit test for function compile_files
def test_compile_files():
    assert False, 'Not implemented'

# Generated at 2022-06-23 22:07:19.148874
# Unit test for function compile_files
def test_compile_files():
    import os
    import pytest

    input_ = os.path.join(pytest.FIXTURES_ROOT, 'input')
    output = os.path.join(pytest.FIXTURES_ROOT, 'test_output')
    
    compile_files(input_, output, CompilationTarget.T3)

# Generated at 2022-06-23 22:07:28.119221
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import set_debug_output
    from .utils.mock_file_system import MockFileSystem

    with set_debug_output() as d:
        fs = MockFileSystem()
        assert fs.get_input(b'test1.py') == b'a = test'
        assert fs.get_input(b'test2.py') == b''
        assert fs.get_input(b'a/test1.py') == b'a = test'
        assert fs.get_input(b'a/test2.py') == b''
        assert fs.get_input(b'a/b/test1.py') == b'a = test'
        assert fs.get_input(b'a/b/test2.py') == b''

# Generated at 2022-06-23 22:07:31.057391
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    result = compile_files('./tests/sources/module1',
                           tempfile.mkdtemp() + '/module1',
                           CompilationTarget.MODULE)
    assert result.count == 2
    assert not result.dependencies


# Unit tests for function _transform

# Generated at 2022-06-23 22:07:37.258953
# Unit test for function compile_files
def test_compile_files():
    from envoy import run
    import requests
    import json
    from .types import CompilationResult

    with open('test.txt', 'w') as f:
        f.write('print(1)')

    compile_files('test.txt', '.', CompilationTarget.JS)

    r = requests.get('http://localhost:27182/test.txt')
    assert isinstance(r.json(), CompilationResult)
    assert r.json()['total'] == 1

    with open('test.py', 'w') as f:
        f.write('import test')

    compile_files('test.py', '.', CompilationTarget.JS)

    r = requests.get('http://localhost:27182/test.js')
    assert isinstance(r.json(), CompilationResult)

# Generated at 2022-06-23 22:07:40.466625
# Unit test for function compile_files
def test_compile_files():
    compile_files('./tests/compile', './tests/deleted', 'py2js')



# Generated at 2022-06-23 22:07:49.857957
# Unit test for function compile_files
def test_compile_files():
    class MockInputOutput:
        def __init__(self, input_, output):
            self.input = input_
            self.output = output

    import pytest
    from .types import CompilationTarget

    def _compile_file(*args, **kwargs):
        return ['a.py']

    def trans(tree):
        # print(dump(tree))
        return tree

    transformers.append(trans)

    import sys
    import os
    class MockInputFile:
        def open(self, *args, **kwargs):
            return open(self.filename)
        @property
        def as_posix(self):
            return self.filename
        def __init__(self, filename):
            self.filename = filename

# Generated at 2022-06-23 22:07:57.564848
# Unit test for function compile_files
def test_compile_files():
    from .utils.test_data import TEST_PROJECT_PATH
    from .utils.helpers import delete_dir_if_exists

    def _create_input_output_path(*path: str) -> InputOutput:
        return InputOutput(input_=TEST_PROJECT_PATH.joinpath(*path),
                           output=TEST_PROJECT_PATH.joinpath(*('output', *path)))

    delete_dir_if_exists(TEST_PROJECT_PATH.joinpath('output'))
    compile_files(TEST_PROJECT_PATH.joinpath('files'),
                  TEST_PROJECT_PATH.joinpath('output'),
                  CompilationTarget.WEB_DEVELOPMENT)

# Generated at 2022-06-23 22:08:07.517201
# Unit test for function compile_files
def test_compile_files():
    import os
    import hashlib
    import shutil
    import tempfile

    input_ = os.path.abspath('tests/input/')
    output = os.path.abspath('tests/output/')
    if os.path.exists(output):
        shutil.rmtree(output)
    target = CompilationTarget.PY27
    root = None
    # root = 'tests/'

    compile_files(input_, output, target, root)
    result = CompilationResult.from_path(output)

    with open('tests/manifest/py27.manifest', 'r') as f:
        expected_contents_hash = f.read()


# Generated at 2022-06-23 22:08:09.455158
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/py', 'tests/data/out', CompilationTarget.MJS)

# Generated at 2022-06-23 22:08:12.422943
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('example/input/', 'example/output/', 'ES5') == \
        CompilationResult(3, 0.00256443, 'ES5', ['http', 'fs'])

# Generated at 2022-06-23 22:08:21.962568
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import shutil
    import os
    import pytest
    import tempfile
    from more_itertools import take

    def test_compile(testcase):
        input_, output, error, target = testcase.split()
        if error:
            with pytest.raises(ValueError):
                compile_files(input_, output, target)
        else:
            try:
                shutil.rmtree(output)
            except:
                pass
            assert not os.path.exists(output)
            compile_files(input_, output, target)
            assert os.path.isdir(output)
            os.unlink(output)


# Generated at 2022-06-23 22:08:27.023303
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    output = tempfile.mkdtemp()
    debug(lambda: output)
    compiled = compile_files('test', output, CompilationTarget.ES6)
    import pprint
    pprint.pprint(compiled.dependencies)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:08:35.058958
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/test_compiler_data/input',
                         'test/test_compiler_data/output',
                         CompilationTarget.PYTHON) == CompilationResult(
                                                  count=4,
                                                  time=0.0783097743911743,
                                                  target=0,
                                                  dependencies=['stdint.py'])

    assert compile_files('test/test_compiler_data/input/',
                         'test/test_compiler_data/output/',
                         CompilationTarget.PYTHON) == CompilationResult(
                                                  count=4,
                                                  time=0.0783097743911743,
                                                  target=0,
                                                  dependencies=['stdint.py'])


# Generated at 2022-06-23 22:08:36.297403
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/fixtures/input', 'tests/fixtures/output',
                         CompilationTarget.PYTHON)

# Generated at 2022-06-23 22:08:43.090794
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    from .testing.utils import capture, remove_dir_contents
    from .main import compile
    from .exceptions import CompilationError

    input_dir = 'tests/data/compile_files/input/'
    output_dir = 'tests/data/compile_files/output/'
    target = CompilationTarget.ES5
    dependencies = set(['es5'])
    result = CompilationResult(2, 0, target, sorted(dependencies))

    with capture() as (stdout, stderr):
        remove_dir_contents(output_dir)
        assert compile_files(input_dir, output_dir, target) == result
        assert len(stdout.readlines()) == 2
        assert len(stderr.readlines()) == 0


# Generated at 2022-06-23 22:08:54.449172
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import shutil
    from .files import get_input_output_paths

    def write_file(path: str, content: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            f.write(content)

    input_dir = 'input'
    output_dir = '/tmp/output'
    write_file(os.path.join(input_dir, 'python.py'), '''
    # import sys
    print(sys.argv[1:])
    # print(sys.argv[1])
    # print(sys.argv[2])
    ''')

# Generated at 2022-06-23 22:09:03.429873
# Unit test for function compile_files
def test_compile_files():
    output = Path('output')
    output.mkdir()
    try:
        result = compile_files('sample', 'output', CompilationTarget.PYTHON27)
        assert result.compiled == 1
        assert result.time >= 0
        assert result.target == CompilationTarget.PYTHON27
        assert result.dependencies == []

        result = compile_files('sample', 'output', CompilationTarget.PYTHON33)
        assert result.compiled == 1
        assert result.time >= 0
        assert result.target == CompilationTarget.PYTHON33
        assert result.dependencies == ['__future__', 'abc']
    finally:
        shutil.rmtree('output')


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:13.632067
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    here = os.path.dirname(__file__)
    input_dir = os.path.join(here, '..', 'test_input')
    output_dir = os.path.join(here, '..', 'test_output')
    result = compile_files(input_dir, output_dir, CompilationTarget.STANDARD)
    assert len(result.dependencies) == 2
    assert 'astunparse' in result.dependencies
    assert 'typed_ast' in result.dependencies
    assert result.target == CompilationTarget.STANDARD
    assert result.files == 2
    with open(os.path.join(output_dir, 'basic_syntax.py')) as f:
        assert f.read() == 'print(1)\n'

# Generated at 2022-06-23 22:09:24.698060
# Unit test for function compile_files
def test_compile_files():
    import argparse
    import os
    import shutil
    import sys
    import tempfile

    parser = argparse.ArgumentParser(
        description='Compiles all files from input to output.')
    parser.add_argument('input', type=str,
                        help='input directory')
    parser.add_argument('output', type=str,
                        help='output directory')
    parser.add_argument('--target', type=str, choices=['py', 'js'],
                        help='target')
    parser.add_argument('--root', type=str,
                        help='root directory')
    args = parser.parse_args()

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 22:09:35.764650
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import os
    import shutil
    import sys
    test_dir = "test_dir"
    this_dir = os.path.dirname(os.path.realpath(__file__))
    test_dir = os.path.join(this_dir, test_dir)
    working_dir = os.getcwd()
    try:
        os.chdir(test_dir)
        subprocess.run("python3 build.py", shell=True)
        print("Done")
    except:
        print("Script failed")
    finally:
        print("Cleaning up")
        # Remove compiled files
        shutil.rmtree("out")
        # Remove compiled scripts
        shutil.rmtree("scripts")
        # Return to working directory
        os.chdir(working_dir)
   

# Generated at 2022-06-23 22:09:42.770739
# Unit test for function compile_files
def test_compile_files():

    from pathlib2 import Path
    from shutil import rmtree
    from .utils.helpers import get_temporary_path

    def assert_equal_files(file1: Path, file2: Path):
        assert file1.read_text() == file2.read_text(), 'files should be equal'

    # compile_files is tested in more general tests
    with get_temporary_path() as temp_path:

        input_path = temp_path / 'input'
        output_path = temp_path / 'output'

        input_path.mkdir()
        output_path.mkdir()

        (input_path / '10-1.py').touch()
        (input_path / '10-2.py').touch()
        (input_path / '10-3.py').touch()

# Generated at 2022-06-23 22:09:49.409482
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/compiler/input', 'tests/compiler/output',
                           CompilationTarget.ES5)
    assert 1 == result.compiled
    assert CompilationTarget.ES5 == result.target
    assert ['@nestjs/common/other-module'] == result.dependencies


if __name__ == '__main__':
    import sys
    compile_files(sys.argv[1], sys.argv[2],
                  CompilationTarget.ES5)

# Generated at 2022-06-23 22:09:55.483128
# Unit test for function compile_files
def test_compile_files():
    import pytest
    def test_compilation_result():
        nonlocal assert_result
        assert_result(CompilationResult(0, 4, CompilationTarget.TYPED, []))
    def check_compilation(input_: str, output: str, target: str, 
                          dependencies: List[str], **kwargs):
        nonlocal assert_result
        assert_result = pytest.approx if target.endswith("-py") else \
                       pytest.helpers.assert_result
        result = compile_files(input_, output, target, **kwargs)
        assert result.dependencies == dependencies
        assert os.path.exists(os.path.join(output, "_pythium.py"))
        assert os.path.exists(os.path.join(output, "a.py"))
       

# Generated at 2022-06-23 22:09:56.723355
# Unit test for function compile_files
def test_compile_files():
    from .testing import test_compile_files as test
    test()

# Generated at 2022-06-23 22:09:59.543483
# Unit test for function compile_files
def test_compile_files():
    input_ = Path('.', 'tests', 'source', 'project0')
    output = Path('.', 'tests', 'source', 'project0-compiled')
    compile_files(input_, output, CompilationTarget.PYTHON_37)

# Generated at 2022-06-23 22:10:04.135995
# Unit test for function compile_files
def test_compile_files():
    assert (compile_files('tests', 'out', 'python3')
            == CompilationResult(
                count=1,
                time_=0.0,
                target='python3',
                dependencies=['nose']
            ))


# Generated at 2022-06-23 22:10:13.575125
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from os import path
    import json
    import pytest
    with TemporaryDirectory() as tmpdir:
        compile_files(
            input_=path.abspath('tests/integration/input'),
            output=tmpdir,
            root=path.abspath('tests/integration/'),
            target=CompilationTarget.PYTHON_3,
        )
        with open(path.join(tmpdir, 'data.json'), 'r') as f:
            data = json.load(f)
            assert len(data) == 4
            assert 'python 3' in data
            assert 'python 2' in data
            assert 'javascript' in data
            assert '__python_2__' in data['python 3']
    with pytest.raises(FileNotFoundError):
        compile_

# Generated at 2022-06-23 22:10:22.566716
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    import tempfile
    from .types import CompilationTarget
    from .utils.helpers import which
    # Check if julia is in PATH
    if which('julia') is None:
        return
    tmp = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmp, 'test_files'))
    with open(os.path.join(tmp, 'test_files', 'test.jl'), 'w') as f:
        f.write('"""\nThis is a comment\n"""\n\n')
        f.write('println("Hello World")\n')
        f.write('println(2+2)\n')

    json_path = os.path.join(tmp, 'test_files', 'test.json')

# Generated at 2022-06-23 22:10:25.093456
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/fixtures/pkg', 'tests/tmp', CompilationTarget.PYTHON27)


# Generated at 2022-06-23 22:10:26.927330
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('test/test_files', 'tmp', CompilationTarget.py2)
    print(result)

# Generated at 2022-06-23 22:10:29.275494
# Unit test for function compile_files
def test_compile_files():
    compile_files('test/test-data/test_1', 'test/output', CompilationTarget.WEB)
    assert 0 == 0

# Generated at 2022-06-23 22:10:32.606499
# Unit test for function compile_files
def test_compile_files():
    compile_files('/home/maharana/Documents/Projects/uw/js2py/tests/tests', '/home/maharana/Documents/Projects/uw/js2py/tests/tests1', 'py')
    pass

# Generated at 2022-06-23 22:10:33.442421
# Unit test for function compile_files
def test_compile_files():
    # ...
    return


# Generated at 2022-06-23 22:10:40.801799
# Unit test for function compile_files
def test_compile_files():
    from py.path import local
    from .utils.helpers import assert_files_equal
    from .files import Files
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        tmp = local(tmp)
        tmp_input = tmp.join('input')
        tmp_output = tmp.join('output')
        tmp_input.mkdir()
        tmp_output.mkdir()

        Files.input_files.write(tmp_input)

        result = compile_files(str(tmp_input), str(tmp_output),
                               CompilationTarget.WEB, str(tmp))

        assert result.count == len(Files.output_files)
        assert_files_equal(tmp_input, tmp_output, Files.output_files)


# Generated at 2022-06-23 22:10:51.882835
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile as tmp
    from subprocess import run, check_output

    input_ = 'src'
    output = tmp.mkdtemp()

    def compile_file(target: str, path: str) -> str:
        return check_output([
            'python3', 'js_compiler.py',
            '-i', input_,
            '-o', output,
            '-t', target,
            '-f', path,
        ]).decode('utf-8')

    # Testing of compilation targets
    compile_file('auto', 'array.js')
    assert os.path.exists(os.path.join(output, 'array.js'))

    compile_file('es5', 'array.js')

# Generated at 2022-06-23 22:10:59.806087
# Unit test for function compile_files
def test_compile_files():
    import sys
    import tempfile
    assert compile_files('./tests/fixtures/hello', './tests/fixtures/out',
                         CompilationTarget.ES5, './tests').count == 1
    assert compile_files(sys.argv[0], sys.argv[0] + '_out',
                         CompilationTarget.ES5).count == 1
    assert compile_files('./tests/fixtures/hello', sys.argv[0] + '_out_2',
                         CompilationTarget.ES5).count == 1
    assert compile_files('./tests/fixtures/hello', '/tmp/out',
                         CompilationTarget.ES5).count == 1

# Generated at 2022-06-23 22:11:09.861904
# Unit test for function compile_files
def test_compile_files():
    """Test compile_files."""
    from tempfile import TemporaryDirectory
    from collections import Counter

    with TemporaryDirectory() as tmp:
        target = CompilationTarget.STATIC

# Generated at 2022-06-23 22:11:18.942236
# Unit test for function compile_files
def test_compile_files():
    from .compiler import compile_files
    from .types import CompilationTarget, CompilationResult
    from .files import CompileFile
    from .transformers import transformers

    input_, output, target = "test_input", "test_output", CompilationTarget.RELEASE

    result = compile_files(input_, output, target)

    assert result.file_count == 2
    assert result.target == CompilationTarget.RELEASE
    assert result.dependencies == ['math', 'os']

    expected_files = {
        CompileFile(Path(input_).joinpath('file1.py'),
                    Path(output).joinpath('file1.py')),
        CompileFile(Path(input_).joinpath('file2.py'),
                    Path(output).joinpath('file2.py'))
    }

    assert expected

# Generated at 2022-06-23 22:11:30.329686
# Unit test for function compile_files
def test_compile_files():
    from .examples.classes import C
    from .examples.compilable import A, B
    from .examples.descriptors import D
    from .examples.generators import G
    from .examples.inheritance import P
    from .examples.module import M
    from .examples.multiple_files import X, Y
    from .examples.mutability import K
    from .examples.numbers import Z
    from .examples.operators import O
    from .examples.types import T
    from .examples.bitwise import W
    from .examples.flow_control import E
    from .examples.scope import S
    from .examples.statements import L
    from .examples.transparency import S
    from .examples.magic import F
    from os import path

    input

# Generated at 2022-06-23 22:11:35.274605
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test/test_files/test_hello_world/'
    output = 'test/test_files/test_hello_world_compiled/'
    target = CompilationTarget.ES5
    result = compile_files(input_, output, target)
    assert result.files == 2
    assert result.dependencies == ['http-server']
    assert result.target == target



# Generated at 2022-06-23 22:11:40.386202
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import sys
    import tempfile
    import os

    class TestCompileFiles(unittest.TestCase):
        def test(self):
            target = CompilationTarget.DOTNET
            input_ = sys.path[0]
            output = tempfile.mkdtemp()

            try:
                compile_files(input_, output, target)
            except Exception as e:
                self.fail('compile_files() raises exception: {}'.format(e))
            finally:
                os.rmdir(output)

    unittest.main(argv=[sys.argv[0], __file__])

# Generated at 2022-06-23 22:11:51.000763
# Unit test for function compile_files
def test_compile_files():
    from .files import InputOutput
    from .types import CompilationTarget, CompilationResult
    from .compile import compile_files

    def assert_compilation(io: InputOutput, target: CompilationTarget,
                           expected_compilation_result: CompilationResult):
        actual_result = compile_files(io.input, io.output, target)
        assert actual_result == expected_compilation_result

    assert_compilation(InputOutput(
        './tests/source/unsupported/syntax.py',
        './build/unsupported/syntax.py'),
        CompilationTarget.PY2,
        CompilationResult(1, 0, CompilationTarget.PY2, []))


# Generated at 2022-06-23 22:11:59.221947
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from shutil import rmtree

    path = Path(__file__).parent / 'test'
    output = path / 'output'
    rmtree(output, ignore_errors=True)

    with (path / 'input' / 'test_file.py').open() as f:
        expected = f.read()
    result = compile_files(path / 'input', output, CompilationTarget.ALL)
    assert result.targets_built == 1
    with (path / 'output' / 'test_file.py').open() as f:
        assert f.read() == expected
    rmtree(output, ignore_errors=True)

# Generated at 2022-06-23 22:12:02.370799
# Unit test for function compile_files
def test_compile_files():
    from .tests.fixtures import test_basic
    path = test_basic.__file__
    assert test_basic.__doc__ == compile_files(path, path, CompilationTarget.CPYTHON).run()

# Generated at 2022-06-23 22:12:13.701671
# Unit test for function compile_files
def test_compile_files():
    import os
    import yaml
    import tempfile
    from .transformers import gm_transform

    tests = []

    # Helper methods to create tests
    def test_init(name, input_file, output_file, transformer, target=gm_transform.target):
        return {
            'name': name,
            'input': input_file,
            'output': output_file,
            'transformer': transformer,
            'target': target
        }

    def test_run(test):
        # Create input files
        input_files = []
        for f in test['input']:
            d = tempfile.mkdtemp()
            input_files.append(os.path.join(d, f))

# Generated at 2022-06-23 22:12:15.183556
# Unit test for function compile_files
def test_compile_files():
    from .tests.cases import run_tests
    run_tests(compile_files)

# Generated at 2022-06-23 22:12:21.268345
# Unit test for function compile_files
def test_compile_files():
    print('Testing function compile_files')
    # arrange
    input_ = 'tests/data/input'
    output = 'tests/data/output'
    target = CompilationTarget.ANY
    res = compile_files(input_, output, target)

    # act
    # assert
    assert res.count == 4, "Number of files should be 4"
    assert res.target == CompilationTarget.ANY
    assert 'functions' in res.dependencies
    assert 'src/typed_ast/transforms.py' in res.dependencies
    assert 'src/typed_ast/conversions.py' in res.dependencies

# Generated at 2022-06-23 22:12:30.308772
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files"""
    from .compiler import compile_files
    from .types import CompilationResult
    from pathlib import Path
    import os
    import pytest

    os.system('cp -r compile_files_test input')
    os.system('rm -r output')
    os.system('mkdir output')

    result = compile_files('input', 'output', CompilationTarget.PYTHON_37)
    assert result == CompilationResult(4, 0, CompilationTarget.PYTHON_37,
                                       ['four', 'three', 'two', 'one'])


# Generated at 2022-06-23 22:12:41.147857
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from pytest import raises
    from .files import get_input_output_paths
    from .utils.helpers import delete_files
    from .transformers import transformers as all_transformers
    from .transformers import ClassTransformer, FunctionTransformer
    import os

    input_ = os.path.join('.', 'tests', 'compile', 'input')
    output = os.path.join('.', 'tests', 'compile', 'output')

    def run(transformer_names: List[str]) -> List[int]:
        delete_files(output)
        transformers = [t for t in all_transformers
                        if t.__name__ in transformer_names]
        result = compile_files(input_, output, CompilationTarget.CLIENT, '.')

# Generated at 2022-06-23 22:12:47.178595
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(
        os.path.join(os.path.dirname(__file__), "..", "..", "test"),
        os.path.join(os.path.dirname(__file__), "..", "..", "test_outputs"),
        CompilationTarget.PY2C_LIBC,
    )

    # **TODO**: Add more tests, check if files are properly compiled

    print(result)
    assert result.count == 2 and result.target == CompilationTarget.PY2C_LIBC
    assert "libc.h" in result.dependencies
    assert "stdio.h" in result.dependencies
    assert "stdlib.h" in result.dependencies


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:12:54.636004
# Unit test for function compile_files
def test_compile_files():
    compile_files("../test/test_dir/test_dir_2/test_dir_3/test_file_1.js",
                  "../test/test_dir/test_dir_2/test_dir_3/test_output_dir/test_output_file_1.js",
                  CompilationTarget.UNIT_TEST
    )
    compile_files("../test/test_dir/test_dir_2/test_dir_3/test_file_2.js",
                  "../test/test_dir/test_dir_2/test_dir_3/test_output_dir/test_output_file_2.js",
                  CompilationTarget.UNIT_TEST
    )

# Generated at 2022-06-23 22:13:04.151822
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import tempfile
    import shutil

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.test_file_path = self.temp_dir + "/test.py"
            test_file = open(self.test_file_path, 'w')
            test_file.write('print("Hello, world!")')
            test_file.close()
            self.target = CompilationTarget.FOR_JS

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_successful_compilation(self):
            output_dir = self.temp_dir + "/output"

# Generated at 2022-06-23 22:13:10.100929
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(input_='./tests/data', output='./tests/data_compiled',
                           target=CompilationTarget.PYTHON_3_5)
    assert result.compilation_target == CompilationTarget.PYTHON_3_5
    assert result.files_compiled == 2
    assert result.time_spent > 0
    assert result.dependencies == ['./tests/data/decorator.py']



# Generated at 2022-06-23 22:13:20.281893
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    import multiprocessing

    def run_compilation(data: dict) -> CompilationResult:
        try:
            basepath = os.path.dirname(__file__)
            return compile_files(os.path.join(basepath, 'test', 'input'),
                                 data['output'],
                                 CompilationTarget.INTERNAL,
                                 os.path.dirname(__file__))
        finally:
            shutil.rmtree(data['output'])

    # Smoke test
    with tempfile.TemporaryDirectory() as tmpdir:
        pool = multiprocessing.Pool(processes=4)

# Generated at 2022-06-23 22:13:25.390343
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.TESTING
    source = 'tests/data/simple'
    result = compile_files(source, 'tmp', target)
    assert result.count == 1
    assert root not in result.dependencies
    assert os.path.isfile('tmp/simple.py')
    with open('tmp/simple.py') as f:
        content = f.read()
    assert 'import root' in content
    assert 'import testing' in content
    assert 'import testing.test' in content
    assert 'def test():' in content



# Generated at 2022-06-23 22:13:26.307736
# Unit test for function compile_files
def test_compile_files():
    pass


# Generated at 2022-06-23 22:13:34.216390
# Unit test for function compile_files
def test_compile_files():
    code1 = 'def f(x):\n    return x+1'
    code2 = 'def g(y):\n    return y+2'
    expected1 = 'def f(x):\n    return x+1\n'
    expected2 = 'def g(y):\n    return y+2\n'
    import tempfile
    tmp = tempfile.TemporaryDirectory()
    input_ = tmp.name + '/input'
    output = tmp.name + '/output'
    input_path1 = input_ + '/f.py'
    input_path2 = input_ + '/g.py'
    output_path1 = output + '/f.py'
    output_path2 = output + '/g.py'
    open(input_path1, 'w').write(code1)

# Generated at 2022-06-23 22:13:41.777938
# Unit test for function compile_files
def test_compile_files():
    from .test_transformers import transformers_test

    result = compile_files('./test/fixtures',
                           './test/result',
                           CompilationTarget.NODEJS)
    assert result.count > 0
    assert result.time_taken > 0
    assert result.target == CompilationTarget.NODEJS
    assert result.dependencies > 0
    assert result.dependencies[0] == './test/fixtures/main.py'

    transformers_test(result.dependencies)



# Generated at 2022-06-23 22:13:46.745492
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/fixtures/jinja2'
    output = './tmp'
    target = CompilationTarget.PYTHON3
    root = 'tests/fixtures'
    compile_files(input_, output, target, root)
    assert True

test_compile_files()

# Generated at 2022-06-23 22:13:49.842551
# Unit test for function compile_files
def test_compile_files():
    from .tests.data import compile_files_test_data
    for t in compile_files_test_data:
        print(t)
        compile_files(t[0], t[1], t[2], None)
test_compile_files()

# Generated at 2022-06-23 22:13:57.137061
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test_compile_files/input'
    output = 'test_compile_files/output'
    target = CompilationTarget.python3
    compile_files(input_, output, target)
    assert open('test_compile_files/output/foo/bar.js').read() == open('test_compile_files/expected/foo/bar.js').read()
    assert open('test_compile_files/output/foo/spam.js').read() == open('test_compile_files/expected/foo/spam.js').read()
    assert open('test_compile_files/output/baz.js').read() == open('test_compile_files/expected/baz.js').read()

# Entry point for running compiler

# Generated at 2022-06-23 22:13:59.954336
# Unit test for function compile_files
def test_compile_files():
    compile_files("tests", "D:/fmi/fsd/3_semestur/compilers/compilers-homework/tests", "strict_functions")


# Generated at 2022-06-23 22:14:06.381451
# Unit test for function compile_files
def test_compile_files():
    from .compiler import compile_files
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import get_path
    from .utils.text import print_compilation_result

    paths = compile_files(get_path('tests/data'),
                          get_path('tests/result'),
                          CompilationTarget.EXTENSION,
                          root=get_path('tests'))
    print_compilation_result(paths)

# Generated at 2022-06-23 22:14:07.003937
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:14:17.128413
# Unit test for function compile_files
def test_compile_files():
    from .testing import _base_path, _test_base_path
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from .transformers import InlineTransformer, DictTransformer, \
                              ImportTransformer, BuiltinTransformer
    from .utils.helpers import set_debug
    from logging import basicConfig, DEBUG
    basicConfig(level=DEBUG)
    set_debug()

    def _compile_and_assert(input_: str, output: str, target: CompilationTarget, dependencies: List[str],
                            errors: List[Tuple[str, str, int, int]] = []):
        result = compile_files(input_, output, target)
        assert target == result.target
        assert sorted(dependencies) == sorted(result.dependencies)


# Generated at 2022-06-23 22:14:26.629817
# Unit test for function compile_files
def test_compile_files():
    """Test that function compile_files works correctly."""
    import os
    import shutil
    import tempfile
    from .types import Target
    from .compile import compile_files, CompilationResult

    input_dir = tempfile.mkdtemp()
    output_dir = tempfile.mkdtemp()

    with open(os.path.join(input_dir, 'file.py'), 'w') as f:
        f.write(''
                'def foo(a):\n'
                '    a = a + 1\n'
                '    b = 2\n'
                '    return a + b\n'
                '\n'
                'def bar(a):\n'
                '    a = a + 1\n'
                '    return a + 3\n'
                '\n')

    result

# Generated at 2022-06-23 22:14:35.612903
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTester(unittest.TestCase):

        def setUp(self):
            self.root_dir = tempfile.mkdtemp(prefix='test_compile_files_')
            open(os.path.join(self.root_dir, 'x.py'), 'wb').close()
            open(os.path.join(self.root_dir, 'y.py'), 'wb').close()
            os.mkdir(os.path.join(self.root_dir, 'z'))
            open(os.path.join(self.root_dir, 'z', 'a.py'), 'wb').close()

# Generated at 2022-06-23 22:14:45.614457
# Unit test for function compile_files
def test_compile_files(): # pylint: disable=unused-function
    from .utils.helpers import random_string
    from .testing import random_project

    project = random_project()
    generated = project.generator()

    for _ in range(10):
        input_ = project.input / '{}.py'.format(random_string())
        input_.write_text(generated)
        output = project.output / '{}.py'.format(random_string())
        assert not output.is_file()
        result = compile_files(input = input_,
                               output = output,
                               target = CompilationTarget.DEVELOPMENT,
                               root = project.input,
                               )
        assert result.target == CompilationTarget.DEVELOPMENT
        assert result.count == 1
        assert output.is_file()
        assert output

# Generated at 2022-06-23 22:14:51.582791
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/resources/input', 'tests/resources/output',
                           CompilationTarget.PYTHON_NUMPY)
    assert result.target == CompilationTarget.PYTHON_NUMPY
    assert result.dependencies == ['numpy']
    assert result.output_files == 1
    assert result.elapsed_time > 0
