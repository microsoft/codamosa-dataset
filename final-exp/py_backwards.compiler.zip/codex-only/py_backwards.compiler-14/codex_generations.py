

# Generated at 2022-06-23 22:04:50.288534
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    import tempfile
    import shutil
    from .exceptions import CompilationError

    # Get paths from autopytest
    from . import _autopytest
    path = _autopytest.path
    path_to_root = _autopytest.path_to_root
    input_ = path / 'input'
    output = path / 'output'

    # Create temporary input and output directories
    input_ = tempfile.TemporaryDirectory()
    input_ = pathlib.Path(input_.name)
    output = tempfile.TemporaryDirectory()
    output = pathlib.Path(output.name)

    # Write some code and compile
    with (input_ / 'test.py').open('w') as f:
        f.write("a = 1")


# Generated at 2022-06-23 22:04:57.853957
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .utils.helpers import path_from_data
    from .types import CompilationTarget
    from .exceptions import CompilationError

    input_ = path_from_data('compile_files')
    output = path_from_data('compile_files_output')

    # Delete output dir if it already exists
    if os.path.exists(output):
        shutil.rmtree(output)

    compile_files(
        input_=input_,
        output=output,
        target=CompilationTarget.PYTHON27
    )



# Generated at 2022-06-23 22:05:09.536818
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from . import conf

    # compile_files function
    assert compile_files(conf.TEST_INPUT_DIR, 'test_compile_files1.py', conf.DEFAULT_TARGET).count == 2

    # get_input_output_paths function

# Generated at 2022-06-23 22:05:17.777457
# Unit test for function compile_files
def test_compile_files():
    def test(code, expected):
        result = compile_files('foo.py', 'bar.py', 'functions', '.')
        assert result.count == 1
        assert result.target == 'functions'
        with open('bar.py', 'r') as f:
            print(f.read())
            print('Expected:')
            print(expected)
            assert f.read() == expected

    test('def foo():\n    pass', 'foo = lambda: None')


if __name__ == '__main__':
    print(unparse(ast.parse('main.py', 'def foo(): pass')))

# Generated at 2022-06-23 22:05:29.044317
# Unit test for function compile_files
def test_compile_files():
    print('Start unit test.......')
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .files import InputOutput
    from .transformers import transformers
    from .utils.helpers import debug
    from .utils.compile_files import _transform
    from .utils.compile_files import _compile_file
    from .utils.compile_files import compile_files

    # Test for function _transform
    def test_transform():
        transformer_index = 0
        target = transformers[transformer_index].target
        code = r"""
                import os
                import time
                print('hello, world!')
                time.sleep(3)
                print(os.getpid())
                """

# Generated at 2022-06-23 22:05:40.580873
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_file_names
    from .exceptions import FileNotFoundError
    from .utils.helpers import dump_dict
    from .utils.constants import MODULE_ERROR_MESSAGE, TEST_JSC_PATH,\
        TEST_TARGET_PATH, TEST_JS_PATH
    try:
        compile_files(TEST_JSC_PATH, TEST_TARGET_PATH, CompilationTarget.JS)
    except FileNotFoundError as e:
        print(MODULE_ERROR_MESSAGE)
        return
    actual = get_input_output_file_names(TEST_JSC_PATH, TEST_TARGET_PATH)
    expected = get_input_output_file_names(TEST_JS_PATH, TEST_TARGET_PATH)

# Generated at 2022-06-23 22:05:45.876198
# Unit test for function compile_files
def test_compile_files():
    test_result = compile_files(input_='tests/test_project', output='tests/out', target=CompilationTarget.PYTHON27)
    assert test_result.files_count == 2
    assert test_result.time < 1
    assert test_result.compilation_target == CompilationTarget.PYTHON27
    assert test_result.dependencies == ['typed_ast']

# Generated at 2022-06-23 22:05:54.602711
# Unit test for function compile_files
def test_compile_files():
    import os
    import logging
    import pytest
    from tempfile import TemporaryDirectory
    from pathlib import Path
    logging.getLogger('make').addHandler(logging.NullHandler())
    input_path = Path(os.path.dirname(__file__)) / 'test-source'
    with TemporaryDirectory() as output_dir:
        output_path = Path(output_dir)
        CompilationResult = compile_files(input_path, output_path,
                                          CompilationTarget.BIN)
        assert CompilationResult.count == 5
        print(CompilationResult)
    with pytest.raises(CompilationError):
        compile_files(input_path, output_path,
                      CompilationTarget.BIN)

# Generated at 2022-06-23 22:06:01.447783
# Unit test for function compile_files
def test_compile_files():
    import os
    import time
    import shutil
    base = os.getcwd()
    input_dir = os.path.join(base, 'Tests', 'Inputs')
    output_dir = os.path.join(base, 'Tests', 'Outputs', 'Test_compile_files')
    root = os.path.join(base, 'Tests')
    try:
        shutil.rmtree(output_dir)
    except:
        pass
    result = compile_files(input_dir, output_dir, CompilationTarget.DEMO_TARGET, root)
    assert result.count == 2
    assert round(result.time) == 0
    assert result.target == CompilationTarget.DEMO_TARGET

# Generated at 2022-06-23 22:06:07.412755
# Unit test for function compile_files
def test_compile_files():
    compile_files('../_examples/input/calculator', '../_examples/output/calculator', CompilationTarget.PYTHON)
    # from .utils.helpers import debug
    # debug(lambda: compile_files('../_examples/input/calculator', '../_examples/output/calculator', CompilationTarget.PYTHON))


# Generated at 2022-06-23 22:06:13.040806
# Unit test for function compile_files
def test_compile_files():
    import pytest

    from .config import Config

    input_ = Config.get_project_root() / 'tests/resources/python'
    output = input_ / 'out'

    for target in [CompilationTarget.STDLIB,
                   CompilationTarget.PYTHON36,
                   CompilationTarget.PYTHON37]:
        compile_files(input_, output, target)
        execute_pytest(output)



# Generated at 2022-06-23 22:06:18.596344
# Unit test for function compile_files
def test_compile_files():
    import os
    import pytest
    import shutil
    import tempfile
    from .types import CompilationTarget, CompilationResult

    def test_compile(input_path):
        # pylint: disable=missing-docstring
        from .types import CompilationTarget
        from .utils import get_version
        from .utils.helpers import create_filename

        input_dir = tempfile.mkdtemp()
        output_dir = tempfile.mkdtemp()

        for filename in os.listdir(input_path):
            if not filename.endswith('.py'):
                continue

            input_filename = create_filename(input_dir,
                                             filename,
                                             version=None)

# Generated at 2022-06-23 22:06:22.709841
# Unit test for function compile_files
def test_compile_files():
    class MyCompilationTarget(CompilationTarget):
        pass
    result = compile_files("./files/input", "./files/output",
                           MyCompilationTarget())
    assert result.count == 3
    assert result.target == MyCompilationTarget()
    assert set(result.dependencies) == {'thingy.py', 'yadda.py'}

# Generated at 2022-06-23 22:06:28.973316
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    # import shutil
    current_path = os.path.abspath(__file__)
    current_dir = os.path.dirname(current_path)
    input_dir = os.path.join(current_dir, 'test')
    output_dir = os.path.join(current_dir, 'test_out')
    # shutil.rmtree(output_dir) # Delete output dir
    if os.path.exists(output_dir) is False:
        os.mkdir(output_dir)
    compile_files(input_dir, output_dir, CompilationTarget.PYTHON, None)
    sys.path.insert(0, output_dir)
    import test_imports
    assert test_imports.__x == 111

# Generated at 2022-06-23 22:06:38.133486
# Unit test for function compile_files
def test_compile_files():
    from os import listdir, remove
    from os.path import join
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        input_ = join(tmpdir, 'input')
        output = join(tmpdir, 'output')
        result = compile_files(input_, output, CompilationTarget.ES6, tmpdir)
        assert result.count == 0
        assert listdir(tmpdir) == ['input', 'output']
        assert listdir(input_) == []
        assert listdir(output) == []

        with open(join(input_, 'file.py'), 'w') as f:
            f.write('# Just a comment')

        result = compile_files(input_, output, CompilationTarget.ES6, tmpdir)
        assert result.count == 1
        assert listdir(tmpdir)

# Generated at 2022-06-23 22:06:41.154375
# Unit test for function compile_files
def test_compile_files():
    from .main import compile_files
    result = compile_files('tests/cases', 'tests/cases/output', 'headless')
    assert result.count == 1
    assert result.dependencies == ['regex', 'pyyaml']

# Generated at 2022-06-23 22:06:52.671716
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import os
    import tempfile
    # Create a new temporary folder
    dir = tempfile.mkdtemp()
    print('Temporary folder: ', dir)
    # Get the current working directory
    cwd = os.getcwd()
    # Move to the temporary folder
    os.chdir(dir)
    # Create the test file
    f = open('test.py', 'w')
    f.write("""def foo():
    return 'foo'

print(foo())
""")
    f.close()
    result = CompilationResult(1, 0, CompilationTarget.PYTHON)
    assert compile_files('test.py', 'output/', CompilationTarget.PYTHON, dir) == result
    # Make sure that the file was compiled

# Generated at 2022-06-23 22:06:58.955604
# Unit test for function compile_files
def test_compile_files():
    paths = get_input_output_paths('')
    res = compile_files('test/data/test.py', 'test/results', CompilationTarget.PYTHON)
    assert res.count == 1
    assert res.time > 0
    assert res.dependencies == []
    assert res.target == CompilationTarget.PYTHON


if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-23 22:07:05.627881
# Unit test for function compile_files
def test_compile_files():
    # This unit test is commented out as it doesn't support Python 3.7
    #assert compile_files('tests/testdata/numba',
    #                     'output/numba',
    #                     CompilationTarget.PY37).count == 3
    assert compile_files('tests/testdata/mypy',
                         'output/mypy',
                         CompilationTarget.PY37).count == 2
    assert compile_files('tests/testdata/sqlalchemy',
                         'output/sqlalchemy',
                         CompilationTarget.PY37).count == 3

# Generated at 2022-06-23 22:07:17.014788
# Unit test for function compile_files
def test_compile_files():
    from .tests import DATA
    from .utils.temp_dir import temp_dir

    # Happy path
    with temp_dir() as output:
        result = compile_files(DATA.path('files/input'), output,
                               CompilationTarget.ES2015)
        assert result.files == 8
        assert result.target == CompilationTarget.ES2015
        assert sorted(result.dependencies) == [
            'async',
            'async-await',
            'data-class',
            'dataclasses',
            'dataclass',
            'first',
            'pathlib',
            'typing',
        ]

    # Check that all created files are equal
    with temp_dir() as output:
        compile_files(DATA.path('files/input'), output, CompilationTarget.ES2015)

# Generated at 2022-06-23 22:07:21.642495
# Unit test for function compile_files
def test_compile_files():
    from .tests.helpers import get_compilation_result
    from .files import get_files
    result = get_compilation_result(
        get_files('compiler/tests/cases/standalone'),
        [],
        CompilationTarget.execute,
        __file__,
    )
    assert result.count == 1
    assert result.dependencies == []
    assert result.time > 0



# Generated at 2022-06-23 22:07:25.086998
# Unit test for function compile_files
def test_compile_files():
     compile_files('../test_code_dir/test_dir',
                   '../test_code_dir/test_dir_test',
                   CompilationTarget.STATIC, None)

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-23 22:07:33.706557
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from shutil import rmtree
    from tempfile import mkdtemp

    def _test(input_: str, output: str, target: CompilationTarget,
              expected: CompilationResult, root: Optional[str] = None):
        try:
            result = compile_files(input_, output, target, root)
        except:
            raise Exception('Input: "{}", Output: "{}", '
                            'Target: "{}", Root: "{}".'.format(
                input_, output, target, root)) from None

        assert result == expected

    with mkdtemp() as tmpdir:
        tmpdir = Path(tmpdir) / 'test'


# Generated at 2022-06-23 22:07:37.523796
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./compiler/test/data/input', './compiler/test/data/output_tests', CompilationTarget.CLIENT)
    assert(result.count == 3)
    assert(len(result.dependencies) == 0)
    assert(result.target == CompilationTarget.CLIENT)

# Generated at 2022-06-23 22:07:47.668957
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from datetime import timedelta
    from .code_providers import get_code_provider, CodeProvider
    from .files import get_input_output_paths

    test_file_name = 'test_file'
    code_provider: CodeProvider = get_code_provider('test')
    target = CompilationTarget.test

    with TemporaryDirectory(prefix='py2c') as tmpdir:
        path = Path(tmpdir)

        test_file_path = (path/test_file_name).with_suffix('.py')
        with test_file_path.open('w') as f:
            f.write(code_provider.code)

        result = compile_files(str(path),
                               str(path),
                               target)



# Generated at 2022-06-23 22:07:56.732356
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from tempfile import TemporaryDirectory
    from pathlib import PosixPath

    from .transformers import transformers
    from . import __version__

    targets = [t.target for t in transformers]

    with TemporaryDirectory() as _input:
        with TemporaryDirectory() as _output:
            with open(PosixPath(_input) / 'test.py', 'w') as f:
                f.write('#!/usr/bin/env python3\n'
                        'x = "hello"\n'
                        'print(x)\n')

            # Test targets
            for target in targets:
                assert compile_files(_input, _output,
                                     target).dependencies == []

            # Test version
            shutil.copytree(_output, _input)

# Generated at 2022-06-23 22:08:05.339436
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('../examples/for_tests', '../tests/for_tests', CompilationTarget.BROWSER)
    assert result.count == 3
    assert result.target == CompilationTarget.BROWSER
    assert '../examples/for_tests/sample.py' in result.dependencies
    assert '../examples/for_tests/file_import.py' in result.dependencies
    assert '../examples/for_tests/type_hints.py' in result.dependencies
    assert '../examples/for_tests/packages/sample.py' in result.dependencies

# Generated at 2022-06-23 22:08:12.692198
# Unit test for function compile_files
def test_compile_files():
    from .test.test_transformers import transform_program as compile
    paths = get_input_output_paths('test/data/input/', 'test/data/output/')
    sources = {}
    for paths in get_input_output_paths('test/data/input/', 'test/data/output/', 'test/data/input/'):
        sources[paths.output.as_posix()] = paths.input.as_posix()
    assert compile(sources) == 3
test_compile_files.__test__ = False

# Generated at 2022-06-23 22:08:18.803303
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/files/compile/success', 'tests/files/compile/output', CompilationTarget.SailfishOS) == CompilationResult(count=5, time=4.160661697387695, target=CompilationTarget.SailfishOS, dependencies=['telepathy-glib', 'telepathy-qt5', 'telepathy-farstream'], return_code=0)



# Generated at 2022-06-23 22:08:29.594563
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import sys
    import unittest
    import os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from .. import transformers

    class TestCompileFiles(unittest.TestCase):
        "Test suit for compile_files"
        def test_compile_files(self):
            """Test case for compile_files"""

            def _compile(code: str, target: CompilationTarget) -> str:
                """Compiles code using compile_files."""
                import tempfile
                with tempfile.TemporaryDirectory('_test_compile_files') as d:
                    in_ = pathlib.Path(d).joinpath('in')
                    out = pathlib.Path(d).joinpath('out')

# Generated at 2022-06-23 22:08:40.372674
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import shutil

    input_ = pathlib.Path(__file__).with_name('input')
    output = input_.with_name('output')
    root = input_.resolve()
    shutil.rmtree(str(output), ignore_errors=True)
    assert compile_files(str(input_), str(output), CompilationTarget.ISort)
    assert (output / 'py33' / 'module_class.py').exists()
    assert (output / 'py33' / 'module_function.py').exists()
    assert (output / 'py33' / 'module_module.py').exists()
    assert (output / 'py33' / 'module_namespace.py').exists()
    assert (output / 'py33' / 'test_test.py').exists()


# Generated at 2022-06-23 22:08:51.970400
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    sources = """# -*- coding: utf-8 -*-

import sys
import os

# TODO:
"""
    expected = """# -*- coding: utf-8 -*-

import sys
import os

if len(sys.argv) < 2:
    raise SystemExit('Path to input file is not specified.')

input = sys.argv[1]

with open(input, 'r', encoding='utf-8') as f:
    content = f.read()

print(content)

# TODO:
"""
    with tempfile.TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, 'input.py')
        with open(path, 'w') as f:
            f.write

# Generated at 2022-06-23 22:08:52.569568
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:09:02.338889
# Unit test for function compile_files
def test_compile_files():
    import os
    import glob
    import re
    import shutil
    import typing

    input_ = 'tests/data/tests'
    output = 'build/tests/data/tests'
    target = CompilationTarget.PYTHON
    root = 'tests'

    def assert_compiled(path: str, code: str):
        output_path = os.path.join(output, path)
        with open(output_path, 'r') as f:
            assert f.read() == code

    compile_files(input_, output, target, root)

    # Functions

# Generated at 2022-06-23 22:09:08.995061
# Unit test for function compile_files
def test_compile_files():
    input_ = './test/test_data'
    output = './test/test_output'
    result = compile_files(input_, output, CompilationTarget.PY2, './test')
    assert isinstance(result.count, int)
    assert isinstance(result.duration, float)
    assert result.target == CompilationTarget.PY2
    assert isinstance(result.dependencies, list)
    print('Success!')

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:12.796942
# Unit test for function compile_files
def test_compile_files():
    compiled_file = compile_files('./test/input', './test/output', 'python')
    assert compiled_file.count == 1
    assert compiled_file.target == 'python'
    assert compiled_file.time < 1

# Generated at 2022-06-23 22:09:18.189152
# Unit test for function compile_files
def test_compile_files():
    """
    Argument 1: path of the input directory

    Argument 2: path of the output directory as a string

    Argument 3: target language
    """
    compile_files('./tests/example', 
                 './tests/example_output_py',
                 CompilationTarget.PY)



# Generated at 2022-06-23 22:09:26.877237
# Unit test for function compile_files
def test_compile_files():
    import os
    import logging
    import pytest
    logging.disable(logging.CRITICAL)
    root = os.getcwd()
    input_ = os.path.join(root, 'tests', 'testdata', 'test_input')
    output = os.path.join(root, 'tests', 'testdata', 'test_output')

    def _get_result(target):
        return compile_files(input_, output, CompilationTarget[target])

    def _test_result(result, target):
        assert result.count == 5
        assert result.target == CompilationTarget[target]
        assert 'a.py' in result.dependencies
        if result.target == CompilationTarget.FOR_TESTING:
            assert 'test_a.py' in result.dependencies

# Generated at 2022-06-23 22:09:28.145213
# Unit test for function compile_files
def test_compile_files():
    compile_files('input', 'output', CompilationTarget.WEB)

# Generated at 2022-06-23 22:09:33.886555
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./input/hello_world.py', './output', CompilationTarget.COMMAND)
    assert result.count == 1
    assert result.target == CompilationTarget.COMMAND
    assert result.time > 0
    assert '__builtins__' in result.dependencies
    assert 'argparse' in result.dependencies
    assert 'time' in result.dependencies


# Generated at 2022-06-23 22:09:41.286631
# Unit test for function compile_files
def test_compile_files():
    from .utils.test_case import TestCase
    from .transformers import transformers as ts
    from .transformers.imports_transformer import ImportsTransformer as ImportsT
    from .transformers.types_transformer import TypesTransformer as TypesT
    from .transformers.all_transformer import AllTransformer as AllT
    from .transformers.__init__ import CompilationTarget as CT
    from pathlib import Path
    import json

    def open_file(path: str):
        with open(path) as f:
            return f.read()

    def test_case(input_: str, expected: str, target: CT) -> None:
        path = Path('tests/unit/test_compiler_compile_files')
        input_path = path / input_
        output_path = path / 'temp/'

# Generated at 2022-06-23 22:09:50.662030
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    import tempfile
    import shutil
    from .files import load_files
    from .transformers.base import BaseTransformer

    stage1_transformer = BaseTransformer()

    @stage1_transformer.on_module
    def stage1_transformer_on_module(node: ast.Module) -> ast.Module:
        return node

    stage2_transformer = BaseTransformer()

    @stage2_transformer.on_module
    def stage2_transformer_on_module(node: ast.Module) -> ast.Module:
        return node

    class TestTransformer(BaseTransformer):
        """ TestTransformer class is needed to access self.target """


# Generated at 2022-06-23 22:09:53.865232
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/files', 'tests/files-output',
                           CompilationTarget.ES6, 'tests/files')
    assert result.count == 2
    assert sorted(result.dependencies) == ['a.js']

# Generated at 2022-06-23 22:10:01.769381
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import os
    import shutil

    from .exceptions import CompilationError
    from .types import CompilationResult

    here = os.path.abspath(os.path.dirname(__file__))

    def compile_test(input_, output, target, code, expected=None):
        target = CompilationTarget.from_text(target)
        debug(lambda: 'Compile "{}"'.format(input_))
        with open(input_, 'w') as f:
            f.write(code)
        if expected is None:
            expected = code
        result = compile_files(
            Path(input_).parent, Path(output).parent, target)
        with open(output, 'r') as f:
            assert result.dependencies == []
            assert f.read() == expected


# Generated at 2022-06-23 22:10:10.445741
# Unit test for function compile_files
def test_compile_files():
    # pylint: disable=import-outside-toplevel
    from time import time
    from random import randint, shuffle
    from pytest import raises, mark
    from os import remove
    from shutil import rmtree
    from pathlib import Path

    def _create_file(path: Path, content: str) -> None:
        try:
            path.parent.mkdir(parents=True)
        except FileExistsError:
            pass
        with path.open('w') as f:
            f.write(content)

    def _remove_file(path: Path) -> None:
        if path.is_file():
            remove(str(path))


# Generated at 2022-06-23 22:10:14.420612
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test', 'output', CompilationTarget.BINARY,
                         root='.') == CompilationResult(3, 5.329174041748047, CompilationTarget.BINARY,
                                                        ['math', 'time'])

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:10:21.416909
# Unit test for function compile_files
def test_compile_files():
    old_target = CompilationTarget.PYTHON2
    new_target = CompilationTarget.PYTHON2_TO_3
    files = compile_files('../python3_sample_code', '../test_python3', new_target, os.getcwd())
    files2 = compile_files('../python3_sample_code', '../test_python3', old_target, os.getcwd())
    assert files.file_count == 11
    assert files2.file_count == 11
    assert len(files.dependencies) == 3


# Generated at 2022-06-23 22:10:22.823096
# Unit test for function compile_files
def test_compile_files():
    compile_files('.', '.', CompilationTarget.PY_TO_OBJC)
    assert False


# Generated at 2022-06-23 22:10:26.508698
# Unit test for function compile_files
def test_compile_files():
    # compile javascript file
    compilation_result = compile_files("test/resources/javascript",
                                       "test/resources/compiled/javascript",
                                       CompilationTarget.JAVASCRIPT)
    assert compilation_result.status == 0

# Generated at 2022-06-23 22:10:30.508723
# Unit test for function compile_files
def test_compile_files():
    compile_files('/Users/ilyarudyak/Desktop/temp/left/a.py', '/Users/ilyarudyak/Desktop/temp/right/a.py', 'pre')

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:10:38.329452
# Unit test for function compile_files
def test_compile_files():
    from shlex import split
    from tempfile import TemporaryDirectory
    from .compiler import compile_files
    from .parser import parse_command_line

    with TemporaryDirectory() as tmp:
        args = parse_command_line(split(
            '{0}/input {0}/output -i {1}'.format(tmp, __file__)))
        result = compile_files(input_=args.input, output=args.output,
                               target=args.target)
    assert result.count == 1
    assert result.dependencies == ['typed_ast']

# Generated at 2022-06-23 22:10:49.220161
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/compile/input', 'tests/compile/output', CompilationTarget.ES5)
    assert result.transformed_files == 3
    assert result.target == CompilationTarget.ES5

# ------------------------------------------------------------------------------

if __name__ == '__main__':
    from argparse import ArgumentParser
    from .__about__ import __version__
    from .__about__ import __author__
    from .__about__ import __email__
    from .exceptions import resolve_exception

    parser = ArgumentParser(description='Python to JavaScript compiler')
    parser.add_argument('-v', '--version', action='version', version='%(prog)s {}'.format(__version__))

# Generated at 2022-06-23 22:10:51.932433
# Unit test for function compile_files
def test_compile_files():
    compile_files("pyxelrest/tests/compiler/testdir", "pyxelrest/tests/resultdir", CompilationTarget.es5)
    assert False


# Generated at 2022-06-23 22:10:59.834194
# Unit test for function compile_files
def test_compile_files():
    from .helpers import reset_sys_path
    from .types import CompilationTarget
    from .types import CompilationResult
    from .files import get_input_output_paths
    from .helpers import fix_jedi_module_path
    from .helpers import assert_equal_files
    from .helpers import reset_cwd
    import tempfile

    expected_result = CompilationResult(
        1, 0, CompilationTarget.PYTHON_35,
        ['typing', 'typing_extensions', 'typing_inspect']
    )

# Generated at 2022-06-23 22:11:09.900599
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    fpath = os.path.dirname(os.path.abspath(__file__))
    input_folder = os.path.join(fpath, 'test_data/compile_input')
    output_folder = os.path.join(fpath, 'test_data/compile_output')
    shutil.rmtree(output_folder, ignore_errors=True)
    expected_result = {
        'compile_output/compile_output/__init__.py',
        'compile_output/compile_output/file1.py',
        'compile_output/compile_output/file2.py',
        'compile_output/compile_output/folder/file3.py',
    }

# Generated at 2022-06-23 22:11:12.827254
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/data/compile', 'tests/data/output', CompilationTarget.PY)
    print(result)
    assert result.count == 4

# Generated at 2022-06-23 22:11:20.831567
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    import os
    import shutil
    from subprocess import run, PIPE
    from pathlib import Path
    import pytest
    tempdir = TemporaryDirectory()
    os.chdir(tempdir.name)

# Generated at 2022-06-23 22:11:32.610746
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from io import StringIO
    import pytest
    from pytest import raises
    from .files import TempDir
    from .exceptions import CompilationError

    with TempDir('test-compile-files') as tmp_dir:
        with tmp_dir.join('input/file1.py').open('w') as f:
            f.write('a = 1\n')
        with tmp_dir.join('input/file2.py').open('w') as f:
            f.write('a = 1\n')
        with tmp_dir.join('input/file3.py').open('w') as f:
            f.write('a = 1\n')

        stderr = StringIO()


# Generated at 2022-06-23 22:11:41.743635
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    import shutil
    shutil.rmtree('temp')
    shutil.copytree('src', 'temp')
    result = compile_files('temp', 'temp', CompilationTarget.PY, 'temp')
    assert result.files_compiled == 4
    assert result.target == CompilationTarget.PY
    assert result.dependencies == ['mysqlclient', 'pymysql']

    shutil.rmtree('temp')
    shutil.copytree('src', 'temp')
    result = compile_files('temp', 'temp', CompilationTarget.PY, 'temp')
    assert result.files_compiled == 4
    assert result.target == CompilationTarget.PY
    assert result.dependencies == ['mysqlclient', 'pymysql']

    shut

# Generated at 2022-06-23 22:11:52.201560
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    # set up temp directories
    input_dir = tempfile.mkdtemp()
    output_dir = tempfile.mkdtemp()

    # set up test file
    with open(os.path.join(input_dir, "testfile.py"), "w") as testfile:
        testfile.write("""
if x:
    print("Hello, world!")
        """)

    # test
    compile_files(input_dir, output_dir, CompilationTarget.NODE)

    # clean up
    shutil.rmtree(input_dir)
    shutil.rmtree(output_dir)



if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Pylang compiler')


# Generated at 2022-06-23 22:12:01.291231
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .tests import example_file_tree
    from .exceptions import CompilationError
    from pathlib import Path
    from .utils.helpers import temporary_directory

    with temporary_directory() as tmpdir:
        tree = Path(tmpdir) / 'example'
        example_file_tree(tree)
        compile_files(tree / 'src', tree / 'compiled',
                      CompilationTarget.python_36, root=tree)
        assert (tree / 'compiled' / 'pyt' / 'a.py').exists()

# Generated at 2022-06-23 22:12:10.050787
# Unit test for function compile_files
def test_compile_files():
    # Create a temporary directory
    import tempfile
    from pathlib import Path
    
    temp_dir = tempfile.TemporaryDirectory()
    test_dir = Path(temp_dir.name)
    
    in_dir = test_dir / 'in'
    (in_dir / 'a').mkdir()
    in_dir.joinpath('b').mkdir()
    in_dir.joinpath('a', '1.py').touch()
    in_dir.joinpath('b', '2.py').touch()
    
    out_dir = test_dir / 'out'
    (out_dir / 'a').mkdir()
    out_dir.joinpath('b').mkdir()
    out_dir.joinpath('a', '1.py').touch()

# Generated at 2022-06-23 22:12:18.491272
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .util.helpers import get_test_data
    import os; os.chdir(get_test_data('data'))
    result = compile_files('input/a.py', 'output', CompilationTarget.PYTHON)
    assert result.files == 1
    result = compile_files('input/a.py', 'output', CompilationTarget.HTML)
    assert result.files == 1
    with pytest.raises(CompilationError):
        compile_files('input/b.py', 'output', CompilationTarget.PYTHON)
    os.chdir('..')

if __name__ == '__main__':
    import sys
    from .util.helpers import debug

    debug(sys.argv)
    compile_files(*sys.argv[1:])

# Generated at 2022-06-23 22:12:22.735951
# Unit test for function compile_files
def test_compile_files():
    res = compile_files('test/test_files/yaml/',
                        'test/test_files/compiled/',
                        CompilationTarget.ES5)
    assert res.count == 2
    assert res.duration > 0
    assert res.target == CompilationTarget.ES5
    assert res.dependencies == [
        pkg_resources.resource_filename('hermes', 'bower_components/yamljs/yaml.min.js')
    ]

# Test for all transformers

# Generated at 2022-06-23 22:12:31.458031
# Unit test for function compile_files
def test_compile_files():

    # Set up
    input_ = "./tests/files/input"
    output = "./tests/files/output"
    target = CompilationTarget.TARGET_BASE

    # Execute
    result = compile_files(input_, output, target)

    # Check
    if result.compiled != 2:
        raise Exception('Compiled number of files is incorrect. Expected: 2, actual: ' + str(result.compiled))
    if result.time < 0:
        raise Exception('Compiled time is incorrect. Expected: positive number, actual: ' + str(result.time))
    if result.target != target:
        raise Exception('Compiled target is incorrect. Expected: ' + str(target) + ', actual: ' + str(result.target))
    if len(result.dependencies) != 1:
        raise Exception

# Generated at 2022-06-23 22:12:42.209812
# Unit test for function compile_files
def test_compile_files():
    from .files import _TEST_RESOURCES
    from .utils.helpers import build_path
    from .exceptions import CompilationError

    for target in CompilationTarget:
        result = compile_files(build_path(_TEST_RESOURCES, 'input'),
                               build_path(_TEST_RESOURCES, 'output'),
                               target,
                               build_path(_TEST_RESOURCES))
        assert len(result.dependencies) == 0

    try:
        compile_files('some/input/path', 'some/output/path', CompilationTarget.PYTHON)
        assert False, 'CompilationError was not raised'
    except CompilationError:
        pass


# Generated at 2022-06-23 22:12:52.102766
# Unit test for function compile_files
def test_compile_files():
    input_ = './tests/test_compiler_input'
    output = './tests/test_compiler_output'
    target = CompilationTarget.ES5

    result = compile_files(input_, output, target)
    assert result.files == 2
    assert result.transformer == CompilationTarget.ES5

    # Code
    with open('./tests/test_compiler_output/__main__.js') as f:
        assert f.read() == 'function __main__(pi) {\n' +\
                           '  return pi * 7;\n' +\
                           '}\n\n' +\
                           'var pi = 3.14;\n' +\
                           'console.log(__main__(pi));\n'


# Generated at 2022-06-23 22:12:58.828946
# Unit test for function compile_files
def test_compile_files():
    from .utils import execute
    result = execute('python3 -m pyqo3.compiler . . .')
    assert result.count > 0
    assert result.target == '.'
    assert result.elapsed > 0
    assert isinstance(result.dependencies, list)
    assert all(isinstance(dep, str) for dep in result.dependencies)
    assert len(result.dependencies) > 0

# Generated at 2022-06-23 22:13:04.908501
# Unit test for function compile_files
def test_compile_files():
    import argparse
    import json
    parser = argparse.ArgumentParser()
    parser.add_argument('input_')
    parser.add_argument('output')
    parser.add_argument('target', choices=['Python2', 'Python3'])
    parser.add_argument('--root', default=None)
    args = parser.parse_args()

    result = compile_files(args.input_, args.output,
                           CompilationTarget[args.target], args.root)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:13:12.797632
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from pathlib import Path

    with tempfile.TemporaryDirectory() as tmp:
        print('Test compilation')
        tmp = Path(tmp)
        inp = tmp / 'input'
        out = tmp / 'output'
        inp.mkdir()
        inp.joinpath('__init__.py').touch()
        (inp / 'a.py').write_text('print(help())')
        (inp / 'b.py').write_text('print(dir())')
        (inp / 'c.py').write_text('print(vars())')
        out.mkdir()
        out.joinpath('__init__.py').touch()

# Generated at 2022-06-23 22:13:19.371084
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    import os
    import shutil
    import tempfile

    cwd = os.getcwd()
    output_dir = tempfile.mkdtemp()
    os.chdir(output_dir)

    def test_base(target: CompilationTarget, expected: str):
        with open("input.py", "w") as f:
            f.write("""
import json
print(json.dumps({"a": 1, "b": 2}))
with open("file.txt", "w") as f:
    f.write("Hello world!")
            """)
        result = compile_files("input.py", "output", target)
        assert result.count == 1
        assert result.target == target

# Generated at 2022-06-23 22:13:22.184766
# Unit test for function compile_files
def test_compile_files():
    # Tests that compilation succeeds.
    # We don't really care about the content of the result.
    compile_files('tests/examples/input', 'tests/examples/output',
                  CompilationTarget.TYPED_RUNTIME)

# Generated at 2022-06-23 22:13:28.541066
# Unit test for function compile_files
def test_compile_files():
    from .test import TEST_DIR
    from .utils.helpers import timeit
    from .types import CompilationTarget

    with timeit() as time_:
        result = compile_files(TEST_DIR / 'source', TEST_DIR / 'compiled',
                               CompilationTarget.PYTHON_37)

    assert result.compiled_count == 2
    assert result.time == time_.elapsed
    assert result.target == CompilationTarget.PYTHON_37
    assert result.dependencies == [
        'importlib.abc',
        'importlib._bootstrap_external',
        'importlib._bootstrap_internal',
        'itertools.count',
        'itertools.cycle',
        'itertools.repeat',
    ]
    assert isinstance(result.time, float)

# Generated at 2022-06-23 22:13:31.340430
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdirname:
        compile_files('./examples/coords.py', tmpdirname, CompilationTarget.PYTHON)
        assert False

# Generated at 2022-06-23 22:13:38.000838
# Unit test for function compile_files
def test_compile_files():
    import os
    import hashlib
    import shutil

    from .utils.helpers import get_test_root

    d = get_test_root()

    compile_files(
        os.path.join(d, 'input'),
        os.path.join(d, 'output'),
        CompilationTarget.ORIGINAL
    )

    with open(os.path.join(d, 'input', 'a')) as i:
        input_ = i.read()
    with open(os.path.join(d, 'output', 'a')) as o:
        output = o.read()

    assert hashlib.sha256(input_.encode()).hexdigest() == hashlib.sha256(output.encode()).hexdigest()


# Generated at 2022-06-23 22:13:38.965075
# Unit test for function compile_files
def test_compile_files():
    # todo add test
    ...

# Generated at 2022-06-23 22:13:50.288737
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import sys
    import tempfile
    import os
    import inspect

    def _print(*args, **kwargs):
        print(*args, **kwargs, file=sys.stdout)


# Generated at 2022-06-23 22:13:59.661777
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        input_path = os.path.join(tmpdirname, 'input')
        output_path = os.path.join(tmpdirname, 'output')
        os.mkdir(input_path)
        os.mkdir(output_path)
        with open(os.path.join(input_path, 'test.py'), 'w') as f:
            f.write('print("test")\n')
        compile_files(input_path, output_path, CompilationTarget.AUTOMATIC)
        assert os.path.exists(os.path.join(output_path, 'test.py'))

# Generated at 2022-06-23 22:14:00.811612
# Unit test for function compile_files
def test_compile_files():
    # TODO: Implement
    pass

# Generated at 2022-06-23 22:14:09.749057
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from .test_transformers import test_transformers
    from .utils.helpers import itervalues

    for transformer in itervalues(test_transformers):
        for target in transformer.target, transformer.target + 1:
            with TemporaryDirectory() as input_dir:
                with TemporaryDirectory() as output_dir:
                    debug(lambda: 'Transformer: {}, target: {}'.format(
                        transformer, target))

                    assert compile_files(input_dir, output_dir, target).count == 0

                    transformer.input_files(input_dir)
                    transformer.output_files(output_dir)

                    compile_files(input_dir, output_dir, target)
                    transformer.check(target)

# Generated at 2022-06-23 22:14:17.215985
# Unit test for function compile_files
def test_compile_files():
    from .testing import get_source_tree_as_zip
    from .testing import expected_compilation_result
    from .testing import TEST_ROOT, TEST_SOURCE, TEST_OUTPUT
    from .testing import TARGET_CALL_JS_FROM_JS
    from .testing import TARGET_CALL_JS_FROM_PY
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        source = get_source_tree_as_zip(TEST_SOURCE)

        result = compile_files(source,
                               tmp_dir, TARGET_CALL_JS_FROM_JS,
                               root=TEST_ROOT)

# Generated at 2022-06-23 22:14:18.162162
# Unit test for function compile_files
def test_compile_files():
    # TODO: Add unit test
    pass

# Generated at 2022-06-23 22:14:18.762347
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:14:20.667225
# Unit test for function compile_files
def test_compile_files():
    compile_files('../tests/resources/valid', '../out', CompilationTarget.CPython27)

# Generated at 2022-06-23 22:14:30.213788
# Unit test for function compile_files
def test_compile_files():
    """Test for function compile_files."""
    import os
    import os.path
    import shutil

    # Test data

# Generated at 2022-06-23 22:14:31.794993
# Unit test for function compile_files
def test_compile_files():
    input_ = 'input'
    output = 'output'
    target = 'js'
    result = compile_files(input_,output,target)
    assert(result != None)



# Generated at 2022-06-23 22:14:34.417600
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('./py_js/Tests/input/Module.py', './py_js/Tests/output/Module.js', CompilationTarget.IJS)
    except:
        print("Test failed")

# Generated at 2022-06-23 22:14:39.082977
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(pathlib.Path('./test/resources/test.py').as_posix(),
                          pathlib.Path('./test/resources/compiled/test.py').as_posix(),
                          CompilationTarget.PYTHON_35)
    assert result.count == 1

# Generated at 2022-06-23 22:14:41.682644
# Unit test for function compile_files
def test_compile_files():
    print('Testing compile_files')
    compile_files('./example/src',
                  './example/dist',
                  CompilationTarget.WEB)



# Generated at 2022-06-23 22:14:53.021132
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    from unittest.mock import patch
    from .files import FileData, get_input_output_paths
    from .transformers import transformers
    from .utils.helpers import debug
    from .utils.mocks import MockTransformer

    with patch('pythontransformer.compiler._compile_file') as mock_compile_file:
        mock_compile_file.side_effect = lambda params, target: (
            None if target == CompilationTarget.PYTHON23
            else [MockTransformer.__name__])

        with patch('pythontransformer.utils.helpers.debug') as mock_debug:
            mock_debug.return_value = debug

            with patch('pythontransformer.compiler.unparse') as mock_unparse:
                mock_un