

# Generated at 2022-06-23 22:04:42.649922
# Unit test for function compile_files
def test_compile_files():
    input_path = Path(__file__).parent.parent / 'test' / 'demo'
    output_path = Path(__file__).parent.parent / 'test' / 'output'

    result = compile_files(input_path.as_posix(),
                           output_path.as_posix(),
                           CompilationTarget.STANDARD)

    assert result.count == 3

    for input_file in input_path.glob('**/*.py'):
        output_file = output_path.joinpath(input_file.relative_to(input_path))
        assert input_file.read_text() == output_file.read_text()

# Generated at 2022-06-23 22:04:48.101825
# Unit test for function compile_files
def test_compile_files():
    """Tests compile_files"""
    # Setup
    input_ = Path('test/data/compile_files/input')
    output = Path('test/data/compile_files/output')
    target = CompilationTarget.BEAST

    # Exercise and verify
    result = compile_files(input_, output, target)

    assert result.count == 5
    assert result.target == target
    assert result.dependencies == []
    assert all(output.joinpath(p).is_file()
               for p in ['A.py', 'B.py', 'foo/C.py', 'foo/bar/D.py', 'foo/bar/haha/E.py'])



# Generated at 2022-06-23 22:04:50.972402
# Unit test for function compile_files
def test_compile_files():
    input_ = "../data/input"
    output = "../data/output"
    target = CompilationTarget.CONTRACT
    root = "."

    assert compile_files(input_, output, target)



# Generated at 2022-06-23 22:04:59.172942
# Unit test for function compile_files
def test_compile_files():
    code = """\
# Test

a = 1
a
"""
    files = [
        ('a.py', code),
    ]
    with TemporaryDirectory() as input_:
        with TemporaryDirectory() as output:
            for file_, content in files:
                with open(os.path.join(input_, file_), 'w') as f:
                    f.write(content)
            result = compile_files(input_, output, CompilationTarget.PY2)
            assert result.count == 1
            assert result.time > 0
            assert result.target == CompilationTarget.PY2
            assert result.dependencies == []
            assert os.listdir(output) == ['a.py']

# Generated at 2022-06-23 22:05:05.447026
# Unit test for function compile_files
def test_compile_files():
    import pytest

    @pytest.mark.parametrize(
        'params',
        [
            (['tests/import/input/a.py'],
             'tests/import/output',
             CompilationTarget.BROWSER)
        ]
    )
    def test(params):
        input_, output, target = params
        result = compile_files(input_, output, target)
        file_paths = get_input_output_paths(*params[:-1])
        for paths in file_paths:
            with paths.input.open() as f:
                code = f.read()
            with paths.output.open() as f:
                transformed = f.read()
            _, _ = _transform(paths.input.as_posix(), code, target)

# Generated at 2022-06-23 22:05:15.980582
# Unit test for function compile_files
def test_compile_files():
    import os
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def test_compile_files(self):
            import tempfile
            with tempfile.TemporaryDirectory() as tmpdir:
                os.mkdir(os.path.join(tmpdir, 'input'))
                os.mkdir(os.path.join(tmpdir, 'output'))
                with open(os.path.join(tmpdir, 'input', 'test.py'), 'w') as f:
                    f.write('x = 1\n')
                compile_files(os.path.join(tmpdir, 'input'),
                              os.path.join(tmpdir, 'output'),
                              CompilationTarget.ES5)


# Generated at 2022-06-23 22:05:22.819279
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os

# Generated at 2022-06-23 22:05:23.428404
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:05:31.772423
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import tempfile

    class FakeInputOutput:
        def __init__(self, _input: str, output: str):
            self.input_ = _input
            self.output = output
            self.read_data = None

        def open(self, mode='r'):
            self.mode = mode
            return self

        def __iter__(self):
            yield self.input_, self.output
            return

        def read(self):
            return self.read_data

        def write(self, *args, **kwargs):
            pass

    class FakePath():
        def __init__(self, path: str):
            self.path = path

        def open(self, *args, **kwargs):
            pass

        def parent(self):
            return self


# Generated at 2022-06-23 22:05:43.127665
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import re
    with tempfile.TemporaryDirectory() as path:
        subdir = os.path.join(path, 'subdir')
        os.mkdir(subdir)
        file_ = os.path.join(subdir, 'testfile')
        with open(file_, 'w') as f:
            f.write('\n'.join([
                'def test():',
                '    x = 1',
                '    y = x + 1',
                '    print(y)',
            ]))
        build_dir = os.path.join(path, 'build')
        compile_files(path, build_dir, CompilationTarget.STATIC)

# Generated at 2022-06-23 22:05:46.756592
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/input'
    output = 'tests/output'
    root = 'tests/root'
    compile_files(input_, output, CompilationTarget.EVIL, root)

# Generated at 2022-06-23 22:05:50.230542
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('../tests/data/simple-files', '../tests/data/simple-files-output', CompilationTarget.PYTHON_26)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:05:58.558530
# Unit test for function compile_files
def test_compile_files():
    import os
    import pytest
    from .test.test_helpers import assert_code

    def assert_compile_files(input_: str, output: str,
                             target: CompilationTarget,
                             expected: List[str]):
        assert expected == compile_files(input_, output, target).dependencies

    abs_path = lambda path: os.path.abspath(path)

    assert_compile_files('test/data/', 'test/data/output',
                         target=CompilationTarget.TARGET_3,
                         expected=[])
    assert_compile_files('test/data/nested/', 'test/data/output',
                         target=CompilationTarget.TARGET_3,
                         expected=[])

# Generated at 2022-06-23 22:06:08.716127
# Unit test for function compile_files
def test_compile_files():
    input_ = './tests/integration/files/input.py'
    output = './tests/integration/files/output.py'
    result = compile_files(input_, output, 'server')

    assert result.count == 1
    assert result.target == 'server'
    assert result.dependencies == []

    with open(input_, 'r') as f:
        assert f.read().strip() == unparse(
            { 'foo': 'bar' }
        )

    with open(output, 'r') as f:
        assert f.read().strip() == unparse(
            { 'foo': [1, 2, 3] }
        )


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:06:15.081040
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from pathlib import Path

    current_path = Path(__file__)
    current_dir = current_path.parent.resolve()
    input_dir = current_dir / 'tests' / 'compiler' / 'input'
    output_dir = current_dir / 'tests' / 'compiler' / 'output_isort'
    root = current_dir

    input_dir.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(output_dir, ignore_errors=True)


# Generated at 2022-06-23 22:06:15.466006
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:06:21.167675
# Unit test for function compile_files
def test_compile_files():
    from .files import get_test_files
    from test import get_test_path

    input_ = get_test_path('simple', 'input')
    output = get_test_path('simple', 'output')

    result = compile_files(input_, output, CompilationTarget.ES5, root='test')

    assert result.count == 1
    assert result.target == CompilationTarget.ES5
    assert result.dependencies == []

    assert get_test_files('simple', 'output') == ['product.js']

# Generated at 2022-06-23 22:06:32.227274
# Unit test for function compile_files
def test_compile_files():
    import typing
    from .files import get_input_output_paths
    from .transformers import add_read_function
    compile_files('test/data/input', 'test/data/output',
                  CompilationTarget.JAVASCRIPT,
                  root='test/data/')
    assert(next(get_input_output_paths('test/data/input', 'test/data/output',
                                       root='test/data/')).output ==
           typing.Path('test/data/output/a.js'))
    assert(next(get_input_output_paths('test/data/input', 'test/data/output',
                                       root='test/data/')).output ==
           typing.Path('test/data/output/subdir/b.js'))

# Generated at 2022-06-23 22:06:35.520098
# Unit test for function compile_files
def test_compile_files():
    # TODO: For now, unit test will be similar to integration test
    # in test_wrapper
    assert compile_files('test/fixtures/foo',
                         'test/output',
                         CompilationTarget.PYTHON).errors == 0

# Generated at 2022-06-23 22:06:37.398970
# Unit test for function compile_files
def test_compile_files():
    #input_ = 'input/code_input_1.py'
    #output = 'input/code_input_2.py'
    pass

# Generated at 2022-06-23 22:06:42.395215
# Unit test for function compile_files
def test_compile_files():
    input_ = 'temp_compile_files_input'
    output = 'temp_compile_files_output'
    assert compile_files(input_, output, CompilationTarget.DEPLOY).count == 1
    assert compile_files(input_, output, CompilationTarget.INTERPRETER).count == 1


__all__ = [
    'CompilationError', 'CompilationResult', 'CompilationTarget',
    'compile_files', 'test_compile_files',
]

# Generated at 2022-06-23 22:06:46.672988
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./input', './output', 'cpython33')
    assert result.target == CompilationTarget.CPython3_3
    assert result.input_file_count == 2

# Generated at 2022-06-23 22:06:50.250619
# Unit test for function compile_files
def test_compile_files():
    print(compile_files(
        'test/input', 'test/output', CompilationTarget.PYTHON_3_6
    ))


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:06:50.725010
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:07:01.175051
# Unit test for function compile_files
def test_compile_files():
    from os import path, remove
    from pathlib import Path
    from tempfile import mkdtemp

    temp_dir = Path(mkdtemp('-mist', 'compile-'))
    assert (temp_dir.exists())

    def make_file(filename: str, content: str) -> (str, str):
        filepath = temp_dir.joinpath(filename)
        with filepath.open('w') as f:
            f.write(content)
        input_ = path.join(str(temp_dir), filename)
        output = input_.replace('.py', '.js')
        return input_, output

    input_, output = make_file('a.py', 'print("hello")')
    compiler = compile_files(input_, output, CompilationTarget.js)
    assert (compiler.count == 1)

# Generated at 2022-06-23 22:07:09.170251
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files"""
    cwd = os.path.dirname(os.path.abspath(__file__))
    compile_files(os.path.join(cwd, "..", "tests", "input"),
                  os.path.join(cwd, "..", "tests", "output"),
                  CompilationTarget.C)
    compile_files(os.path.join(cwd, "..", "tests", "input"),
                  os.path.join(cwd, "..", "tests", "output"),
                  CompilationTarget.CPP)
    compile_files(os.path.join(cwd, "..", "tests", "input"),
                  os.path.join(cwd, "..", "tests", "output"),
                  CompilationTarget.PY)

# Generated at 2022-06-23 22:07:19.910726
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import unittest
    from urllib.parse import urlparse
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .exceptions import CompilationError
    from .tests.utils import eprint

    class TestCompileFiles(unittest.TestCase):
        """
        Tests the compile_files function.
        """

        def _test(self, input_: str, output: str, target: CompilationTarget,
                  root: Optional[str] = None):
            """
            Tests compilation of files.
            """
            with TemporaryDirectory() as input_dir:
                with TemporaryDirectory() as output_dir:
                    input_path = os.path.join(input_dir, input_)
                    output_path = os.path.join(input_dir, output)

# Generated at 2022-06-23 22:07:24.827157
# Unit test for function compile_files
def test_compile_files():
    from .examples.hello_world import hello_world
    from .examples.hello_world import hello_world_output
    result = compile_files(hello_world, hello_world_output,
                           CompilationTarget.PYTHON_LEGACY)
    assert result.file_count == 1
    assert result.duration > 0
    assert result.target == CompilationTarget.PYTHON_LEGACY

# Generated at 2022-06-23 22:07:32.317208
# Unit test for function compile_files
def test_compile_files():
    import os
    import os.path
    from .files import get_input_output_paths
    from .errors import get_error_message
    from .utils.helpers import debug

    input_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../tests/data/input'))
    output_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../tests/data/output'))

    for paths in get_input_output_paths(input_dir, output_dir, input_dir):
        debug(lambda: 'Compiling: {}'.format(paths.input.as_posix()))

# Generated at 2022-06-23 22:07:35.909704
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("./testing/sample_input",
                         "./testing/sample_output", CompilationTarget.PYTHON36)



# Generated at 2022-06-23 22:07:45.253777
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    import tempfile
    import subprocess
    import pytest
    import os
    import shutil
    from .utils.types import CompilationTarget
    from .utils.logs import logging
    import logging as _debug_logging

    _debug_logging.basicConfig(level=_debug_logging.DEBUG)

    test_dir = os.path.dirname(__file__)

    test_file = os.path.join(test_dir, 'compiler', 'test.py')
    expected_file = os.path.join(test_dir, 'compiler', 'test.expected.js')

    def generated_file_content(generated: str) -> str:
        with open(generated) as f:
            return f.read()


# Generated at 2022-06-23 22:07:52.432112
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    class TestCompileFile(CompilationTarget):
        def __init__(self, path: str):
            self.path = path

        def gen_code(self, path: str) -> str:
            relative_path = os.path.relpath(path, self.path)
            return 'def {}():\n    pass'.format(relative_path.replace('/', '_'))

    test = TestCompileFile(tempfile.mkdtemp())

# Generated at 2022-06-23 22:07:55.557550
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    test_input = 'test_inputs'
    test_output = os.path.join(tempfile.mkdtemp(), test_output)

    result = compile_files(test_input, test_output, CompilationTarget.C)

    assert result is not None

# Generated at 2022-06-23 22:08:05.216939
# Unit test for function compile_files
def test_compile_files():
    from os.path import dirname
    from .utils.helpers import is_python_file
    from .utils.files import get_input_output_paths
    from .utils.types import CompilationTarget

    input_path = dirname(__file__) + '/../../tests/basic'
    output_path = dirname(__file__) + '/../../tests/output'

    file_count = 0
    for paths in get_input_output_paths(input_path, output_path):
        if not is_python_file(paths.input):
            continue

        result = compile_files(input_path, output_path, CompilationTarget.PYTHON,
                               paths.input.parent.as_posix())
        assert result.count == 1
        assert result.time >= 0

# Generated at 2022-06-23 22:08:12.304244
# Unit test for function compile_files
def test_compile_files():
    input_ = '/tmp/snake.py'
    output = '/tmp/snake.pyc'
    root = '/tmp/snake.pyc'
    target = CompilationTarget.PYC
    assert compile_files(input_, output, target, root) == CompilationResult(count, time() - start, target, sorted(dependencies))

# Unit tests for function _transform
code = """#!/usr/bin/env python
# coding: utf-8

import os
import sys
"""


# Generated at 2022-06-23 22:08:16.219547
# Unit test for function compile_files
def test_compile_files():
    from .tests import testdir, testdir_target, testdir_dependencies
    assert compile_files(testdir, testdir_target, target=CompilationTarget.ES6) == testdir_dependencies

# Generated at 2022-06-23 22:08:18.987339
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    paths = get_input_output_paths(Path('./test_inputs'), Path('./test_outputs'))
    for paths in paths:
        print(paths)

# Generated at 2022-06-23 22:08:28.624324
# Unit test for function compile_files
def test_compile_files():
    import os
    import random
    import string

    def random_string(length: int) -> str:
        """Returns random string."""
        return ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits)
                       for _ in range(length))

    result = compile_files(os.path.dirname(os.path.realpath(__file__)) + '/test',
                           random_string(10), CompilationTarget.JS)
    assert(result.count == 3)
    assert(result.dependencies == [])
    assert(result.target == CompilationTarget.JS)
    assert(result.time >= 0)

# Generated at 2022-06-23 22:08:39.539534
# Unit test for function compile_files
def test_compile_files():
    source_dir = "test/test_source"
    expected_dir = "test/test_expected"
    test_dir = "test/test_actual"
    paths = get_input_output_paths(source_dir, test_dir)
    for paths in paths:
        _compile_file(paths, target=CompilationTarget.JAVASCRIPT)
    for paths in paths:
        file_name = paths.input.name
        with open(paths.input.as_posix()) as f:
            expected_file = paths.output.with_name(file_name)
            with open(expected_file.as_posix()) as expected:
                assert expected.read() == f.read()

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:08:44.511467
# Unit test for function compile_files
def test_compile_files():
    compile_files('../tests/data/input',
                  '../tests/data/output',
                  CompilationTarget.PYTHON2)
    compile_files('../tests/data/input',
                  '../tests/data/output3',
                  CompilationTarget.PYTHON3)

# Generated at 2022-06-23 22:08:55.867219
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import tempfile
    import os
    class TestCompileModule(unittest.TestCase):
        @staticmethod
        def _temp_dir():
            return tempfile.TemporaryDirectory(dir='tests/')
        def test_compile_files(self):
            with TestCompileModule._temp_dir() as temp_dir_path:
                temp_dir_path = os.path.abspath(temp_dir_path)
                test_path = os.path.join(temp_dir_path, 'test.py')
                with open(test_path, 'w') as test_file:
                    test_file.write("print('hello')")

# Generated at 2022-06-23 22:09:04.247331
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import os

    class TestCompileFiles(unittest.TestCase):
        def test_correct_compilation(self):
            import shutil
            from io import StringIO
            from .types import CompilationTarget

            test_dir = 'test_dir'
            test_input = os.path.join(test_dir, 'input')
            test_output = os.path.join(test_dir, 'output')
            os.mkdir(test_dir)
            os.mkdir(test_input)
            os.mkdir(test_output)


# Generated at 2022-06-23 22:09:06.196747
# Unit test for function compile_files
def test_compile_files():
    from .tests import compile_files as test_compile_files

    test_compile_files()

# Generated at 2022-06-23 22:09:10.709864
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.html
    input_ = './test/compiler/testdata'
    output = '/tmp'
    result = compile_files(input_, output, target)
    assert result.target == target
    assert result.count == 4
    assert result.dependencies == ['test', 'test.sub.components']

# Generated at 2022-06-23 22:09:18.400027
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    import tempfile
    import shutil
    import pytest

    @pytest.fixture()
    def work_dir():
        d = Path(tempfile.mkdtemp())
        d.joinpath('plugin').mkdir()
        d.joinpath('plugin').joinpath('subplugin').mkdir()
        d.joinpath('plugin').joinpath('subplugin').joinpath('empty.py').touch()
        d.joinpath('plugin').joinpath('subplugin').joinpath('subsubplugin').mkdir()
        d.joinpath('plugin').joinpath('subplugin').joinpath('subsubplugin').joinpath('empty.py').touch()
        d.joinpath('ignore').mkdir()
        d.joinpath('ignore').joinpath('subplugin').mkdir()


# Generated at 2022-06-23 22:09:19.102493
# Unit test for function compile_files
def test_compile_files():
    assert False

# Generated at 2022-06-23 22:09:27.269974
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    def _get_temp_paths() -> Tuple[pathlib.Path, pathlib.Path]:
        """Creates temporary folder and returns input and output paths."""
        tmp = pathlib.Path(tempfile.mkdtemp())
        return tmp / 'input', tmp / 'output'

    def _assert_file(path: pathlib.Path, content: str,):
        """Asserts the file content."""
        with path.open() as f:
            assert f.read() == content

    def _assert_result(result: CompilationResult, files: int, time_: float,
                       deps: str) -> None:
        """Asserts the result."""
        assert result.files == files
        assert result.time >= time_

# Generated at 2022-06-23 22:09:32.208845
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    input_ = './samples/'
    output = './samples/compiled/'
    target = CompilationTarget.ES5
    compile_files(input_, output, target)
    assert os.path.isdir('./samples/compiled/')
    

# Generated at 2022-06-23 22:09:38.122795
# Unit test for function compile_files
def test_compile_files():
    from .utils import tmp_dir

    with tmp_dir() as tmp:
        assert compile_files(tmp, tmp, CompilationTarget.PYTHON_35).count == 0

# Generated at 2022-06-23 22:09:38.871034
# Unit test for function compile_files
def test_compile_files():
    assert False, 'Not implemented'

# Generated at 2022-06-23 22:09:49.129561
# Unit test for function compile_files
def test_compile_files():
    import os
    from .utils.test_helpers import TemporaryFile
    from .utils.mocks import MockTransformer
    from .types import CompilationTarget

    # Simple test for check that we can compile at least one file
    with TemporaryFile('simple.py', b'print("Hello, world!") ') as file:
        result = compile_files(file.path, 'output', CompilationTarget.PyToPy)
        assert result.count == 1
        assert os.path.isfile(os.path.join('output', file.name))

    # Test that function don't compile files with python2 code
    with TemporaryFile('print.py', b'print "Hello, world!"') as file:
        result = compile_files(file.path, 'output', CompilationTarget.PyToPy)
        assert result.count == 0

    #

# Generated at 2022-06-23 22:09:58.749751
# Unit test for function compile_files
def test_compile_files():
    import io
    import sys
    import pathlib
    import tempfile
    from unittest.mock import patch
    from . import __file__ as current_file
    from .exceptions import CompilationError
    from .utils.helpers import format_exc
    from .types import CompilationResult
    from .transformers import transformers

    curdir = pathlib.Path(current_file).parent
    input_dir = curdir.joinpath('test_data')
    output_dir = tempfile.mkdtemp()

    def test_compile_files(input_dir: str,
                           output_dir: str,
                           target: CompilationTarget):
        result = compile_files(input_dir, output_dir, target)
        assert result.count == 8
        assert result.target == target
        assert result.dependencies

# Generated at 2022-06-23 22:10:09.661701
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import subprocess
    with tempfile.TemporaryDirectory() as tmpdirname:
        subprocess.call(["python3", "-m", "kurier", "compile", os.path.join(tmpdirname, "in"), \
                os.path.join(tmpdirname, "out"), "--root", "src", "--target", "py3"])
        assert os.path.exists(os.path.join(tmpdirname,"out/client/sample_module.py"))
        assert os.path.exists(os.path.join(tmpdirname,"out/server/sample_module.py"))
        f = open(os.path.join(tmpdirname,"out/client/sample_module.py"),"r+")

# Generated at 2022-06-23 22:10:17.159638
# Unit test for function compile_files
def test_compile_files():
    # There is currently no way to run doctests on Python 3.5 :(
    # (or Python < 3.6)
    # See https://github.com/python/mypy/issues/4162
    assert """\
import os
import typing

a = {"abc": "abc"}  # type: typing.Dict[str, str]
print(a["abc"])
c = "tests"
print(os.path.join(c, "tests/__init__.py"))
""" == compile_files(
        'tests/fixtures/fixture.py',
        '__output', CompilationTarget.PYTHON36).code

# Generated at 2022-06-23 22:10:23.263432
# Unit test for function compile_files
def test_compile_files():
    from .test.test_files import get_test_files
    from .test.test_target import targets
    from .test.test_result_verifier import assert_results_same

    input_, output, files = get_test_files()
    result = compile_files(input_.as_posix(), output.as_posix(), targets[-1])
    assert result.files == len(files)
    assert_results_same(result.dependencies, files[-1].dependencies)

# Generated at 2022-06-23 22:10:26.122410
# Unit test for function compile_files
def test_compile_files():
    input_ = Path('tests/compile')
    output = Path('tests/compiled')
    assert compile_files(input_, output, CompilationTarget.ANY)

# Generated at 2022-06-23 22:10:34.207297
# Unit test for function compile_files
def test_compile_files():
    from .tests import test_pypy_to_js
    from .utils.helpers import get_root
    from .utils.io import TemporaryDirectory

    with TemporaryDirectory(prefix='tmp-compiler') as tmpdir:
        root = get_root() / 'tests' / 'test_pypy_to_js'

        input_ = tmpdir / 'input'
        output = tmpdir / 'output'

        input_.symlink_to(root)

        result = compile_files(str(input_), str(output), CompilationTarget.JS)

        print('Files:', result.count)
        print('Time:', result.time)
        print('Depends on:')
        for dep in result.dependencies:
            print('  -', dep)


if __name__ == '__main__':
    test_

# Generated at 2022-06-23 22:10:45.140086
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from glob import glob
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import rmtree

    with TemporaryDirectory() as input_:
        with TemporaryDirectory() as output:
            tmp_ = Path('tests/examples/compilation/')
            for filename in glob(str(tmp_ / '**/*.py')):
                (Path(input_) / filename[len(str(tmp_)):]).parent.mkdir(parents=True)
                (Path(input_) / filename[len(str(tmp_)):]).write_text(Path(filename).read_text())

            result = compile_files(input_, output, CompilationTarget.COMPRESS)

            print(result)

            assert result.count == 15
            assert result.target == CompilationTarget.COMPRESS


# Generated at 2022-06-23 22:10:55.550167
# Unit test for function compile_files
def test_compile_files():
    import os
    from .examples.tests.compiler import TestCompiler
    from .examples.python.compiler import TestPyCompiler
    from .examples.python.features.compiler import TestPyFCompiler
    from .examples.python.features.imports import TestPyImportsCompiler
    from .examples.python.features.string.format import TestPyFStringFormatCompiler
    from .examples.python.features.string.strip import TestPyFStringStripCompiler
    from .examples.python.features.string.replace import TestPyFStringReplaceCompiler
    from .examples.python.features.lists.concatenation import TestPyFListsConcatCompiler
    from .examples.python.features.lists.getitem import TestPyFListsGetitemCompiler

# Generated at 2022-06-23 22:11:02.124872
# Unit test for function compile_files
def test_compile_files():
    def test(input_: str, expected_out: str, expected_dep: str):
        result = compile_files('tests/{}'.format(input_),
                               'tests/out/{}'.format(input_),
                               CompilationTarget.NodeJS)
        assert 'tests/{}'.format(expected_out) == result.output
        assert result.dependencies == expected_dep.split(' ')

    test('input', 'out/input.js', '')
    test('input_with_errors', 'out/input_with_errors.js', '')
    test('input_with_import', 'out/input_with_import.js', 'c')
    test('input_with_import_requests', 'out/input_with_import_requests.js',
         'a b c d e')


# Generated at 2022-06-23 22:11:10.839896
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    root = os.path.dirname(os.path.abspath(__file__))
    input_ = os.path.join(root, 'files', 'input')
    output = os.path.join(root, 'files', 'output_test')

    def cleanup():
        shutil.rmtree(output)

    class TestCompileFiles(unittest.TestCase):

        def test_compile_files(self):
            cleanup()
            compile_files(input_, output, CompilationTarget.PYTHON2)

        def test_compile_files_in_temp(self):
            for func in (compile_files, compile_files):
                if func is compile_files:
                    continue

# Generated at 2022-06-23 22:11:16.874450
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/sources/example'
    output = 'tests/sources/example_out'
    target = 'es5'
    result = compile_files(input_, output, target)
    errors = []
    try:
        import astunparse
        import autopep8
        import typed_ast
    except ImportError as e:
        errors.append(str(e))
    assert result.target == target
    assert result.count == 2
    assert result.dependencies == []
    assert errors == []


if __name__ == '__main__':
    pass

# Generated at 2022-06-23 22:11:22.567017
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/examples/example1/input',
                           'tests/examples/example1/output',
                           CompilationTarget.PYTHON27,
                           'tests/examples/example1')

    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON27
    assert result.dependencies == ['_EXAMPLE_PYI']


# Generated at 2022-06-23 22:11:30.713364
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from contextlib import contextmanager

    @contextmanager
    def temporary_directory() -> Path:
        temp_dir = Path(mkdtemp())
        try:
            yield temp_dir
        finally:
            try:
                rmtree(temp_dir)
            except:
                pass

    with temporary_directory() as tmp:
        compile_files(tmp / 'input', tmp / 'output', CompilationTarget.ES5_STRICT)

# Generated at 2022-06-23 22:11:38.175848
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    testdir = tempfile.mkdtemp()
    tempdir = tempfile.mkdtemp()
    s = 'def x(): return 1'
    testfile = testdir + "/test.py"
    tempfile = tempdir + "/test.py"
    open(testfile, "w").write(s)
    compile_files(testdir + "/test.py", tempdir + "/test.py",CompilationTarget.PY2TO3)
    assert s == open(tempdir + "/test.py").read()
    shutil.rmtree(testdir)
    shutil.rmtree(tempdir)

# Generated at 2022-06-23 22:11:39.223027
# Unit test for function compile_files
def test_compile_files():
    # todo
    assert 1 == 1

# Generated at 2022-06-23 22:11:49.870063
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    import textwrap
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    import io
    import os
    import tempfile

    input_ = "assert a == 2\n"
    expected = "assert 'a' == 2"

    input_file = io.BytesIO(input_.encode('utf-8'))
    output_file = io.StringIO()

    targets = [t.name for t in CompilationTarget]
    for i, target in enumerate(targets):
        print('testing', i,target)
        paths = get_input_output_paths(input_file, output_file)
        _compile_file(paths, CompilationTarget[target])

# Generated at 2022-06-23 22:12:01.012860
# Unit test for function compile_files
def test_compile_files():
    """Test compile_files function."""
    import os.path
    from .utils.helpers import get_temp_directory
    from .paths import OS_DIR
    from .utils.logger import RESET_STYLES

    test_dir = get_temp_directory('compile_files')
    input_ = os.path.join(OS_DIR, 'out')
    output = os.path.join(test_dir, 'out')
    target = CompilationTarget.BROWSER
    root = os.path.join(OS_DIR, 'tests', 'onefile')

    # Ensure that nothing is compiled
    result = compile_files(input_, output, target, root)
    assert result.compiled == 0

    # Ensure that all files from test directory is compiled
    result = compile_files(input_, output, target)

# Generated at 2022-06-23 22:12:05.227533
# Unit test for function compile_files
def test_compile_files():
    res = compile_files('compile_files_input/main/', 'compile_files_output/main/', 'python')
    assert res.files_changed == 4
    assert len(res.dependencies) == 0



# Generated at 2022-06-23 22:12:05.863996
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:12:09.268925
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/fixtures'
    output = 'tests/compilation'
    target = CompilationTarget.PROD

    result = compile_files(input_, output, target)

    assert result.count == 2
    assert result.target == target
    assert result.dependencies == ['dummy1.py', 'dummy2.py']


# Generated at 2022-06-23 22:12:11.652845
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('fixtures/compiler', 'build', CompilationTarget.ES5, 'fixtures').total_files == 8


# Generated at 2022-06-23 22:12:20.724022
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os
    import os.path
    import re
    # first use the sample code
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                        '..', '..', 'examples', 'cpp_examples', 'dynamic_string_buffer.cpp')
    # open input file
    with open(path) as f:
        dynamic_string_buffer = f.read()
    target = CompilationTarget.CPP

    # get input and output path
    input_ = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                          '..', '..', 'examples', 'input')

# Generated at 2022-06-23 22:12:25.809047
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/python-input/*.py',
                           'tests/python-output',
                           CompilationTarget.Python)
    assert result.target == CompilationTarget.Python
    assert result.files_count == 10
    assert result.dependencies == ['cpython', 'numpy', 'scipy']
    assert result.compilation_time >= 0.0



# Generated at 2022-06-23 22:12:36.235574
# Unit test for function compile_files
def test_compile_files():
    import subprocess32
    import pytest
    import shutil
    import re
    import os
    import sys

    # set up directories
    input_ = "input"
    output = "output"
    test_files_root = "tests/files"
    pytest.test_files_root = test_files_root
    # remove existing output directory
    shutil.rmtree(output, ignore_errors=True)
    # copy all files from tests/files/test_package to input directory
    shutil.copytree(test_files_root, input_)

    # reset input directory
    # delete all __pycache__ folders
    to_delete = []
    for folder, sub_folders, f_names in os.walk(input_):
        if ".git" in folder or ".idea" in folder:
            continue


# Generated at 2022-06-23 22:12:47.127259
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import types
    import unittest
    def temp_file(name: str, content: str):
        with open(os.path.join(temp_dir, name), 'w') as f:
            f.write(content)

    temp_dir = tempfile.mkdtemp()    # type: str
    FILENAME = 'test.py'
    NESTED_FILENAME = 'root/test.py'
    DIR_FILENAME = 'root/test.py'
    FILE_CONTENT = 'foo bar baz'
    DIR_CONTENT = 'foo bar baz'
    temp_file(FILENAME, FILE_CONTENT)
    os.mkdir(os.path.join(temp_dir, 'root'))
    temp_file

# Generated at 2022-06-23 22:12:49.981961
# Unit test for function compile_files
def test_compile_files():
    compile_files(Path(__file__).parent / 'test' / 'input',
      Path(__file__).parent / 'test' / 'output',
      CompilationTarget.FUNCTIONS)

# Generated at 2022-06-23 22:12:56.407213
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('./examples/input/', './build', CompilationTarget.ES5)
        compile_files('./examples/input/', './build', CompilationTarget.ES6)
        compile_files('./examples/input/', './build', CompilationTarget.ES7)
        compile_files('./examples/input/', './build', CompilationTarget.ES8)
        compile_files('./examples/input/', './build', CompilationTarget.ES9)
        compile_files('./examples/input/', './build', CompilationTarget.ES10)
    except CompilationError as e:
        print(e)
        return
    except TransformationError as e:
        print(e)
        return
    except:  # noqa
        trace

# Generated at 2022-06-23 22:13:03.846901
# Unit test for function compile_files
def test_compile_files():
    compile_files('./test_data/test_data_compile/input','./test_data/test_data_compile/output', CompilationTarget.strict)
    assert Path('./test_data/test_data_compile/output/file3.py').is_file()
    assert Path('./test_data/test_data_compile/output/file1.py').is_file()
    assert Path('./test_data/test_data_compile/output/file2.py').is_file()
    assert Path('./test_data/test_data_compile/output/file3.py').is_file()

# Generated at 2022-06-23 22:13:14.277023
# Unit test for function compile_files
def test_compile_files():
    """Checks if the compilation process is successful."""
    from .files import list_files
    from .utils.helpers import workdir

    with workdir('build') as dir_:
        input_ = dir_ / 'input'
        output = dir_ / 'output'

        input_.mkdir()
        output.mkdir()

        (input_ / '__init__.py').touch()
        (input_ / 'file1.py').write_text('foo = lambda x: x ** 2\n')
        (input_ / 'file2.py').write_text('bar = lambda x: x + 2\n')
        (input_ / 'file3.py').write_text('x = "1 + 2"\n')

        result = compile_files(input_, output, CompilationTarget.NO_FRAMEWORK)



# Generated at 2022-06-23 22:13:21.363255
# Unit test for function compile_files
def test_compile_files():
    data = [
        ('tests/fixtures/js-min.js',
         'tests/fixtures/py-min.py'),
        ('tests/fixtures/js-min',
         'tests/fixtures/py-min'),
    ]
    for input_, output in data:
        res = compile_files(input_, output, CompilationTarget.PY_MIN)
        assert res.count == 5
        assert len(res.dependencies) == 1
        assert os.path.basename(res.dependencies[0]) == 'min.js'

# Generated at 2022-06-23 22:13:24.564020
# Unit test for function compile_files
def test_compile_files():
    class CompilationResultMock(CompilationResult):
        def __init__(self, *args) -> None:
            pass
        def __eq__(self, other) -> bool:
            return isinstance(other, CompilationResultMock)
    assert compile_files('', '', CompilationTarget.NODEJS) == CompilationResultMock()

# Generated at 2022-06-23 22:13:32.095340
# Unit test for function compile_files
def test_compile_files():
    import os
    import re
    import tempfile

    commit = os.popen('git rev-parse --short HEAD').read()[:-1]
    commit = commit if commit else 'test'
    version = re.compile('version="[0-9]+\.[0-9]+\.[0-9]+"')
    version = 'version="{}"'.format(commit)

    input_ = os.path.realpath('.')
    output = tempfile.mkdtemp(prefix='output.')
    target = CompilationTarget.JS_WITH_TWINE_STANDARD_LIBRARY

    compile_files(input_, output, target,
                  root=os.path.realpath('./lib'))


# Generated at 2022-06-23 22:13:38.501011
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import sys
    import os
    import filecmp
    import shutil
    from .files import get_input_output_paths

    class TestCompileFiles(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            sys.path.append(os.path.dirname(os.path.dirname(__file__)))

        def test_compile_files(self):
            input_ = os.path.join('tests', 'files')
            output = os.path.join('tests', 'files_2')
            compile_files(input_, output, CompilationTarget.PYTHON27)

            paths = get_input_output_paths(input_, output, os.path.dirname(__file__))

# Generated at 2022-06-23 22:13:48.841472
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths, InputOutput
    from pprint import pformat

    from .exceptions import CompilationError
    files = get_input_output_paths('tests/files', 'tests/out/files')
    for paths in files:
        print('Compiling: ' + pformat(paths))
        try:
            compile_files(paths.input.as_posix()
                          , paths.output.as_posix(), target=CompilationTarget.STANDALONE)
        except CompilationError as e:
            print(e)
            print(e.src)
            print(e.lineno)
            print(e.offset)
            raise e

# Generated at 2022-06-23 22:13:55.928423
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from os import remove
    from shutil import rmtree
    from .files import to_pathlib

    in_path = to_pathlib('memtest.py')
    out_path = to_pathlib('out')
    assert compile_files(in_path, out_path, CompilationTarget.MEMORYCLIENT, None) == \
        CompilationResult(1, pytest.approx(0.08), CompilationTarget.MEMORYCLIENT, [])
    assert (out_path / 'memtest.py').exists()
    rmtree(out_path)

# Generated at 2022-06-23 22:14:03.429994
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    def get_path(path, target=CompilationTarget.generic_serial, root=None):
        if root is not None:
            return os.path.join(root, path)
        else:
            return os.path.join(tempfile.gettempdir(), path)

    def create_file(file, target=CompilationTarget.generic_serial, root=None):
        path = get_path(file, target, root)
        directory = os.path.dirname(path)
        if not os.path.exists(directory):
            os.makedirs(directory)

        with open(path, 'w') as f:
            f.write('import foo\n')
            f.write('\n')

# Generated at 2022-06-23 22:14:04.416031
# Unit test for function compile_files
def test_compile_files():
    # TODO: add tests
    pass

# Generated at 2022-06-23 22:14:06.520868
# Unit test for function compile_files

# Generated at 2022-06-23 22:14:08.945990
# Unit test for function compile_files
def test_compile_files():
    from .tests.compilation import compile_files as test_compile_files
    test_compile_files(compile_files)

# Generated at 2022-06-23 22:14:19.410521
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.dir = tempfile.TemporaryDirectory()
            self.input_dir = self.dir.name + '/in'
            self.output_dir = self.dir.name + '/out'

        def tearDown(self):
            self.dir.cleanup()

        def test_python_to_python(self):
            """Check Python -> Python compilation."""
            compiled = compile_files(self.input_dir, self.output_dir,
                                     CompilationTarget.python)
            self.assertEqual(0, compiled.count)

            self.input_dir.write('x = 1\n')

# Generated at 2022-06-23 22:14:22.603018
# Unit test for function compile_files
def test_compile_files():
    compile_files('./demo/input', './demo/output', CompilationTarget.target_1)
    compile_files('./demo/input', './demo/output', CompilationTarget.target_2)

# Generated at 2022-06-23 22:14:26.767768
# Unit test for function compile_files
def test_compile_files():
    compiled = compile_files('./test/compiler/fixtures/input',
                            './test/compiler/fixtures/output',
                            CompilationTarget.ES6)
    assert compiled.count == 3
    assert all(dep.startswith('test/') for dep in compiled.dependencies)

# Generated at 2022-06-23 22:14:30.664625
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/examples', 'tests/out', CompilationTarget.ES5)
    assert result.count == 4
    assert result.target == CompilationTarget.ES5
    assert sorted(result.dependencies) == ['js2py', 'jspyder']


# Generated at 2022-06-23 22:14:31.664104
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass

# Generated at 2022-06-23 22:14:35.218187
# Unit test for function compile_files
def test_compile_files():
    # TODO: Test something useful!
    files = compile_files('test', 'test_out', CompilationTarget.PY36)
    assert files.count == 4
    assert files.time > 0
    assert files.target == CompilationTarget.PY36
    assert files.dependencies == []

# Generated at 2022-06-23 22:14:39.831677
# Unit test for function compile_files
def test_compile_files():
    compiled = compile_files('./tests/data/input', './tests/data/output', CompilationTarget.BAD)
    assert compiled.target == CompilationTarget.BAD
    assert compiled.number == 1
    assert compiled.dependencies == ['os']
    assert compiled.duration > 0
    assert compiled.duration < 0.5