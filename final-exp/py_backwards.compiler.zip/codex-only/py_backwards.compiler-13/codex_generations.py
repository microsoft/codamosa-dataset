

# Generated at 2022-06-23 22:04:58.874614
# Unit test for function compile_files
def test_compile_files():
    """Test function compile_files."""
    # pylint: disable=import-error
    from pathlib import Path
    from shutil import rmtree
    from .tests.greeter import greeter
    from autopep8 import diff

    input_ = Path('tests/input_test')
    output = Path('tests/output_test/')
    rmtree(output, ignore_errors=True)
    compile_files(input_, output, CompilationTarget.python27)

    with Path('tests/output_test/greeter.py').open() as f:
        actual = f.read()

    expected = greeter.format(CompilationTarget.python27)
    if actual != expected:
        print(''.join(diff(expected, actual)))
        assert False



# Generated at 2022-06-23 22:05:10.512408
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from typing import Set
    from os import remove
    from os.path import join
    from unittest import TestCase
    from string import digits

    class _Base(TestCase):
        def setUp(self) -> None:
            self.input_ = tempfile.TemporaryDirectory()
            self.output = tempfile.TemporaryDirectory()
            self.dependencies = set()  # type: Set[str]

        def tearDown(self) -> None:
            self.input_.cleanup()
            self.output.cleanup()

    class TestCompileFiles(_Base):
        def test_compile_files(self) -> None:
            from .files import get_input_output_paths
            from .utils.helpers import write_file
            from .types import CompilationTarget


# Generated at 2022-06-23 22:05:16.414365
# Unit test for function compile_files
def test_compile_files():
    from .compile import compile_files
    from .types import CompilationResult, CompilationTarget
    from .utils.helpers import get_test_data_path

    result = compile_files(get_test_data_path('input'),
                           get_test_data_path('output'),
                           CompilationTarget.ADVANCED)
    assert result == CompilationResult(6, 0, CompilationTarget.ADVANCED, [])

# Generated at 2022-06-23 22:05:22.991323
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    def _write_tmp(content: str, folder: str = '') -> str:
        with tempfile.NamedTemporaryFile(mode='w', dir=folder) as f:
            f.write(content)
            name = f.name
        return name

    input_, output = tempfile.mkdtemp(), tempfile.mkdtemp()
    test_str = '''
foo = "aaaaa" + "aaaaa"
'''
    _write_tmp(test_str, folder=input_)
    assert compile_files(input_, output, CompilationTarget.TEST).success

# Generated at 2022-06-23 22:05:33.323807
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from . import config

    def _count_lines(path: str) -> int:
        return len(open(path, 'r').readlines())

    before = {
        paths.input.as_posix(): _count_lines(paths.input.as_posix())
        for paths in get_input_output_paths(config.input,
                                            config.output,
                                            config.root)
    }

    result = compile_files(config.input, config.output, config.target,
                           config.root)


# Generated at 2022-06-23 22:05:42.333729
# Unit test for function compile_files
def test_compile_files():
    from .files import FIXTURE_DIR
    input_ = FIXTURE_DIR / 'src'
    output = FIXTURE_DIR / 'target'
    target = CompilationTarget.BROWSER
    root = FIXTURE_DIR
    res = compile_files(input_, output, target, root)
    assert res.target == target
    assert res.duration > 0
    assert res.count > 0
    assert len(res.dependencies) == 1
    dep = res.dependencies[0]
    assert dep.startswith(root.as_posix())
    assert dep.endswith('src/imports/module.py')

# Generated at 2022-06-23 22:05:48.257052
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from shutil import rmtree, copytree, copy2
    from .units.joblib_unit import testmodule
    tempdir = tempfile.mkdtemp()
    src = tempdir + '/test_files/testmodule'
    copy2(testmodule.__file__, src)
    copytree(testmodule.__file__ + '.data', tempdir + '/test_files/testmodule.data')
    results = compile_files(tempdir + '/test_files', tempdir + '/output', CompilationTarget.FULLY_CONVERTABLE)
    assert results.depended_files == ['testmodule.data/estimators/kernel_approximation.py'], results.depended_files
    assert results.target == CompilationTarget.FULLY_CONVERTABLE, results.target
    assert results.processed

# Generated at 2022-06-23 22:05:54.026191
# Unit test for function compile_files
def test_compile_files():
    # pylint: disable=import-error
    import unitts
    # pylint: enable=import-error

    unitts.test('compile files',
                lambda: compile_files('tests/test_data/test_compile_files',
                                      'tests/test_data/test_compile_files',
                                      CompilationTarget.PYTHON),
                CompilationResult(5, 0, CompilationTarget.PYTHON, []))
test_compile_files()

# Generated at 2022-06-23 22:06:01.147582
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import io
    import sys

    # TODO: use pytest for tests
    def _fail(message: str):
        print(message, file=sys.stderr)
        sys.exit(1)

    # copy all translation files to temporary directory
    tmp = tempfile.mkdtemp()
    tmp = os.path.join(tmp, 'translation')
    shutil.copytree(os.path.join(os.path.dirname(__file__), 'translation'),
                    tmp,
                    ignore=shutil.ignore_patterns('__pycache__'))


# Generated at 2022-06-23 22:06:11.918304
# Unit test for function compile_files
def test_compile_files():
    from .examples import examples

    for target in CompilationTarget:
        for example in examples:
            with example.input.open() as f:
                code = f.read()

            result = compile_files(example.input.as_posix(),
                                   example.output.as_posix(),
                                   target)

            with example.output.open() as f:
                compiled = f.read()

            try:
                assert code != compiled
            except:
                raise AssertionError(
                    'Input/output files are equal:\n{0}\n{1}'.format(
                        example.input.as_posix(),
                        example.output.as_posix()))


# Generated at 2022-06-23 22:06:22.487785
# Unit test for function compile_files
def test_compile_files():
    def run_test(input_, output, expected_output, target):
        result = compile_files(input_, output, target)
        print(result.time_elapsed)
        print(result)
        print(len(result.dependencies))

        assert result.target == target
        assert result.files_compiled == 1
        assert (result.time_elapsed > 0 and
                result.time_elapsed < 10)
        assert result.dependencies == []

        with open(expected_output, 'r') as f:
            assert f.read().strip() == '\n'.join(str(result).split('\n')[3:])

    INPUT = 'tests/examples/test.py'
    OUTPUT = 'test.py'

# Generated at 2022-06-23 22:06:32.090523
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import import_exc_formatter, exc_formatter
    from .utils.helpers import debug
    import subprocess
    import os
    import sys
    import shutil

    def run_test(test_dir: str) -> bool:
        # Set up test
        test_path = os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            'test',
            test_dir)
        test_input = os.path.join(test_path, 'input')
        test_output = os.path.join(test_path, 'output')
        test_spec = os.path.join(test_path, 'spec.json')
        test_py = os.path.join(test_path, 'test.py')
        test_log = os.path

# Generated at 2022-06-23 22:06:40.875604
# Unit test for function compile_files
def test_compile_files():
    def _test(input_: str, output: str, target: CompilationTarget) -> None:
        debug(lambda: 'Compile to {}'.format(output))
        result = compile_files('/tmp/ast-transformer/test', output, target)
        assert result.count == 2, 'Count: {}'.format(result.count)
        assert result.target == target, 'Target: {}'.format(result.target)
        debug(lambda: 'transform')
        assert result.dependencies == ['transform'], \
            f'Dependencies: {result.dependencies}'

    _test('/tmp/ast-transformer/test', '/tmp/ast-transformer/test.py',
          CompilationTarget.PYTHON_3)

# Generated at 2022-06-23 22:06:45.370253
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('./tests/fixtures/input/',
                      './tests/fixtures/output/', CompilationTarget.PY)
        compile_files('./tests/fixtures/input/',
                      './tests/fixtures/output/', CompilationTarget.JAVA)
        compile_files('./tests/fixtures/input/',
                      './tests/fixtures/output/', CompilationTarget.C)

        assert False
    except CompilationError as e:
        assert e.path == './tests/fixtures/input/syntax_error.py'
        assert e.code.splitlines()[e.lineno - 1][e.offset - 1] == '/'
    except TransformationError as e:
        assert False
    except SyntaxError:
        assert False

# Generated at 2022-06-23 22:06:55.039485
# Unit test for function compile_files
def test_compile_files():
    from .files import fake_files
    from .utils.test import run_tests, Test
    from .utils.helpers import compare_files

    def test_case(input_: str, output: str, target: CompilationTarget,
                  root: Optional[str] = None) -> Test:
        """Creates a Test for a case."""
        def run() -> None:
            """Compiles test files."""
            with fake_files(input_, output) as (input_path, output_path):
                result = compile_files(input_path.as_posix(),
                                       output_path.as_posix(), target,
                                       root)
                assert result.target == target
                assert result.count > 0
                assert compare_files(input_path, output_path)


# Generated at 2022-06-23 22:06:55.374095
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:07:00.734026
# Unit test for function compile_files
def test_compile_files():
    try:
        target = CompilationTarget.AUTO
        input_ = "tests/input"
        output = "generated"
        root = "tests/input/root"
        compile_files(input_, output, target, root)
    except Exception as e:
        print(e)
        exit(1)


if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-23 22:07:07.059839
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    input_ = os.path.join(tempfile.gettempdir(), 'input')
    output = os.path.join(tempfile.gettempdir(), 'output')
    open(os.path.join(input_, 'file.py'), 'w').close()
    result = compile_files(input_, output, CompilationTarget.PYTHON)
    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON
    assert result.time > 0
    assert os.path.exists(os.path.join(output, 'file.py'))
    assert result.dependencies == []

# Generated at 2022-06-23 22:07:18.692454
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.tmp_dir = tempfile.mkdtemp()
            self.input_dir = os.path.join(self.tmp_dir, 'input')
            self.output_dir = os.path.join(self.tmp_dir, 'output')
            self.output_file = 'output_{}.py'
            self.input_file = 'input_{}.py'
            self.result_file = 'result_{}.json'
            os.makedirs(self.input_dir)

# Generated at 2022-06-23 22:07:27.739174
# Unit test for function compile_files
def test_compile_files():
    import mock
    import os
    import unittest

    _files_to_create = [
        ('/foo/input/b.py', '''
            class B:
                def bar(self):
                    pass
            '''),
        ('/foo/input/a.py', '''
            from foo.input.b import B
            '''),
    ]

    _expected = [
        ('/foo/output/b.ts', '''
            class B {
                bar(): void {}
            }
            '''),
        ('/foo/output/a.ts', '''
            import B from './b'
            '''),
    ]

    # Copy python files

# Generated at 2022-06-23 22:07:35.559587
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    import tempfile
    from io import StringIO


# Generated at 2022-06-23 22:07:36.113810
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:07:40.655626
# Unit test for function compile_files
def test_compile_files():
    from .files import get_files_in_dir
    from .compile import compile_files
    from .utils.helpers import project_dir

    for file in get_files_in_dir(project_dir / 'tests' / 'inputs'):
        compile_files(
            project_dir / 'tests' / 'inputs' / file,
            project_dir / 'tests' / 'outputs' / file,
            CompilationTarget.JS)

# Generated at 2022-06-23 22:07:50.012963
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .types import CompilationResult

    import pytest

    source_dir = tempfile.mkdtemp()
    target_dir = tempfile.mkdtemp()

    def write_file(name: str, content: str):
        path = os.path.join(source_dir, name)
        with open(path, 'w') as f:
            f.write(content)
        return path

    path1 = write_file('test1.py', 'print("test")')
    path2 = write_file('test2.py', 'print("test2")')
    path3 = write_file('test3.py', 'print("test3")')

    assert compile_files(source_dir, target_dir, CompilationTarget.python3) \
        == Compilation

# Generated at 2022-06-23 22:07:57.665068
# Unit test for function compile_files
def test_compile_files():
    # pylint: disable=exec-used
    import os
    import re
    import tempfile
    from pathlib import Path
    from shutil import rmtree

    input_path = Path(tempfile.mkdtemp())
    output_path = Path(tempfile.mkdtemp())

    def compile_check(code: str, output: str, dependencies: List[str]) -> None:
        file_path = Path(input_path, 'file.py')
        with file_path.open('w') as f:
            f.write(code)
        result = compile_files(input_path, output_path,
                               CompilationTarget.ES5,
                               root=os.path.dirname(__file__))
        assert result.count == 1
        assert result.dependencies == dependencies

# Generated at 2022-06-23 22:08:01.897222
# Unit test for function compile_files
def test_compile_files():
    input_ = './'
    output = 'dist'
    target = CompilationTarget.PYTHON
    root = './test/test_files'
    res = compile_files(input_, output, target, root)
    return res.dependencies
print(test_compile_files())

# Generated at 2022-06-23 22:08:10.424701
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    import os.path
    import shutil
    import unittest

    class CompilerTestCase(unittest.TestCase):
        """Contains test cases for compiling files."""

        def setUp(self):
            """Set up testing environment."""
            self.test_dir = os.path.join('test', 'tmp')
            os.makedirs(self.test_dir)

        def tearDown(self):
            """Clean up testing environment."""
            shutil.rmtree(self.test_dir)

        def test_01_compile(self):
            """Tests compilation."""
            import shutil
            input_ = os.path.join('test', 'data', 'compile', 'input')

# Generated at 2022-06-23 22:08:20.808324
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    result = compile_files("tests/test_files/in", "tests/test_files/out",
                           CompilationTarget.JS)

# Generated at 2022-06-23 22:08:30.012101
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    dirpath = tempfile.mkdtemp()
    input_ = dirpath + '/src'
    output = dirpath + '/build'

    def write_file(path: str, contents: str) -> None:
        with open(path, 'w') as f:
            f.write(contents)

    write_file(input_ + '/1.py', "print('hello')")
    write_file(input_ + '/2.py', "print('hello')")

    compile_files(input_, output, CompilationTarget.TO_PY2)

    assert sorted(os.listdir(output)) == ['1.py', '2.py']

    shutil.rmtree(dirpath)

# Generated at 2022-06-23 22:08:36.830037
# Unit test for function compile_files
def test_compile_files():
    compile_files('./tests/test_files', './tests/test_files_compiled', CompilationTarget.ES3)
    compile_files('./tests/test_files', './tests/test_files_compiled', CompilationTarget.ES5)
    compile_files('./tests/test_files', './tests/test_files_compiled', CompilationTarget.ES2015)

# Generated at 2022-06-23 22:08:43.317105
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    from .types import CompilationTarget

    # Create temp directory
    temp_dir = tempfile.mkdtemp()

    # Copy input_ files to temp
    input_ = os.path.join(os.path.dirname(__file__), 'data')
    shutil.copytree(input_, os.path.join(temp_dir, 'data'))

    # Compile files
    result = compile_files(os.path.join(temp_dir, 'data'),
                           os.path.join(temp_dir, 'output'),
                           CompilationTarget.PRODUCTION)

    print(result)

    # Clean up
    shutil.rmtree(temp_dir)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:08:54.690371
# Unit test for function compile_files
def test_compile_files():
    import json
    from . import project
    from .exceptions import CompilationError
    from .utils.helpers import mktemp
    from .utils.helpers import tempdir
    from .utils.project import create_project

    with tempdir() as tmp:
        # Create sample project
        create_project(tmp.as_posix(), 'python3')

        # Compile it
        out = mktemp()
        r = compile_files(tmp, out, CompilationTarget.PYTHON2)
        assert r.count == 1
        assert out.joinpath('z3.py').is_file()
        assert out.joinpath('z3').is_file()

        # Check compilation result
        d = dict(project.__dict__)
        exec(out.joinpath('z3.py').read_text(), d)
       

# Generated at 2022-06-23 22:09:02.780775
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .test_data.transpile_test_data import transpile_test_data
    for test_data in transpile_test_data:
        if 'placeholder' in test_data:
            continue
        if test_data.get('skip', False):
            continue
        folder = 'test_data/' + test_data['name']
        input_ = '/'.join([folder, 'input'])
        output = '/'.join([folder, 'output'])
        target = CompilationTarget.parse(test_data['target'])
        compile_files(input_, output, target)
        compile_files(input_, output, target)



# Generated at 2022-06-23 22:09:13.032467
# Unit test for function compile_files
def test_compile_files():
    test_files = [
        (__file__.replace('app.py', 'tests/fixtures/test_func.py'),
         __file__.replace('app.py', 'tests/fixtures/test_func_out.py')),
        (__file__.replace('app.py', 'tests/fixtures/test_class.py'),
         __file__.replace('app.py', 'tests/fixtures/test_class_out.py')),
        (__file__.replace('app.py', 'tests/fixtures/test_decorator.py'),
         __file__.replace('app.py', 'tests/fixtures/test_decorator_out.py'))
    ]


# Generated at 2022-06-23 22:09:18.919167
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    result = compile_files('tests/basic', 'build', CompilationTarget.PYTHON,
                           root=str(pathlib.Path(__file__).parent.absolute()))
    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == []

# Generated at 2022-06-23 22:09:27.171828
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    import json
    
    with TemporaryDirectory() as tmp:
        # Create a package
        script_path = Path(tmp) / 'script.py'
        with script_path.open('w') as f:
            f.write('#!/usr/bin/env python3\n' +
                    'print("Hello world")')
        # Create stubs
        (script_path.parent / '__init__.py').touch()
        # Create requirements
        requirements_path = Path(tmp) / 'requirements.txt'
        with requirements_path.open('w') as f:
            f.write('requests\n')

        # Compile the package

# Generated at 2022-06-23 22:09:36.984452
# Unit test for function compile_files
def test_compile_files():
    files = [
        ('./tests/tests-data/in/test0.py', './tests/tests-data/out/test0.py'),
        ('./tests/tests-data/in/test1.py', './tests/tests-data/out/test1.py'),
        ('./tests/tests-data/in/test2.py', './tests/tests-data/out/test2.py')
    ]
    for input_, output in files:
        with open(input_, 'r') as file:
            assert file.read() == compile_files(input_, output, CompilationTarget.PY2).code
    return True


if __name__ == "__main__":
    assert test_compile_files()

# Generated at 2022-06-23 22:09:45.588721
# Unit test for function compile_files
def test_compile_files():
    """Test compile_files()."""
    import os

    input_ = os.path.join(os.path.dirname(__file__), '..', 'tests', 'data', 'input')
    output = os.path.join(os.path.dirname(__file__), '..', 'tests', 'data', 'output')
    target = CompilationTarget.PYTHON37
    expected = CompilationResult(8, 0, target,
                                 sorted(['functools', 'typing']))

    assert compile_files(input_, output, target) == expected

# Generated at 2022-06-23 22:09:51.935688
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test/test_files/test_compile_files'
    output = 'test/test_files/test_compile_files_output'
    compile_files(input_, output, CompilationTarget.ES5)
    assert open('test/test_files/test_compile_files_output/foo.js').read() == \
     open('test/test_files/test_compile_files_result/foo.js').read()
    assert open('test/test_files/test_compile_files_output/foo/bar.js').read() == \
     open('test/test_files/test_compile_files_result/foo/bar.js').read()

# Generated at 2022-06-23 22:10:00.449180
# Unit test for function compile_files
def test_compile_files():
    from .files import get_files_in_directory, InputOutput, OUTPUT_FILE_EXTENSION
    from .exceptions import CompilationError
    from .types import CompilationTarget
    from .transformers import TypedAstVisitorEx, TargetPython

    INPUT_DIRECTORY = "test_input"
    OUTPUT_DIRECTORY = "test_output"
    PLACE_HOLDER = "Result should be ..."

    class TestVisitor(TypedAstVisitorEx):
        def __init__(self):
            self.dependencies = {"import os"}

        def visit_Call(self, node: ast.Call):
            assert isinstance(node.args[1], ast.Name), dump(node)
            self.dependencies.add("import {}".format(node.args[1].id))
            return super().generic_

# Generated at 2022-06-23 22:10:08.497121
# Unit test for function compile_files
def test_compile_files():
    compilation_result = compile_files("test/compiler", "test/python", "python")
    assert compilation_result.target == "python"
    assert compilation_result.compiled_files == 4
    assert "sys" in compilation_result.dependencies
    assert "functools" in compilation_result.dependencies
    assert "datetime" in compilation_result.dependencies
    assert "time" in compilation_result.dependencies 
    assert "test/python/test_compiler/bar.py" in compilation_result.dependencies



if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-23 22:10:09.020634
# Unit test for function compile_files
def test_compile_files():
  assert(True)

# Generated at 2022-06-23 22:10:10.450744
# Unit test for function compile_files
def test_compile_files():
    from .tests.utils import compiler_test
    compiler_test('test_compile_files')

# Generated at 2022-06-23 22:10:17.203779
# Unit test for function compile_files
def test_compile_files():
    from .main import main
    from .utils.testutils import _test_dir, _get_file_contents
    import os

    def get_test_dir():
        return os.path.join(os.path.dirname(__file__), 'test-samples', 'py')

    def get_test_output_dir():
        return os.path.join(os.path.dirname(__file__), 'test-samples', 'output')

    def get_test_output_dir_by_target(target: int):
        return os.path.join(get_test_output_dir(), target.name)

    def get_test_output_file(file: str, target: int):
        return os.path.join(get_test_output_dir_by_target(target), *file.split('/'))

# Generated at 2022-06-23 22:10:27.678959
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import tempfile
    import shutil
    import os
    import sys

    sys.path.append(os.path.dirname(__file__))

    try:
        import test_source  # noqa
    except ImportError:
        print('Run in the directory containing the files')
        sys.exit(1)

    tempdir = tempfile.TemporaryDirectory()
    source_dir = os.path.join(tempdir.name, 'source')
    os.makedirs(source_dir)
    shutil.copy(os.path.join('test_source', 'source.py'), source_dir)
    dest_dir = os.path.join(tempdir.name, 'dest')
    compiled = compile_files(source_dir, dest_dir, CompilationTarget.PY_27)

# Generated at 2022-06-23 22:10:30.492569
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(input_='test_files/input', output='test_files/output', target=CompilationTarget.JAVA)



# Generated at 2022-06-23 22:10:39.344226
# Unit test for function compile_files
def test_compile_files():
    import datetime
    from tempfile import mkdtemp
    from shutil import rmtree
    from pathlib import Path
    project_name = 'project-' + datetime.date.today().isoformat()
    py_file = project_name + '.py'
    project_path = Path(mkdtemp())
    input_path = project_path / 'input'
    output_path = project_path / 'output'
    input_path.mkdir()
    output_path.mkdir()
    input_path.joinpath(py_file).write_text('test')
    CompilationResult = compile_files(input_path,
                                      output_path,
                                      CompilationTarget.UNIT_TESTS)
    assert isinstance(CompilationResult.count, int)

# Generated at 2022-06-23 22:10:45.392014
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import sys
    import shutil
    import os

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self.test_source = 'test/unit/compiler/test_files/sources'
            self.test_target = 'test/unit/compiler/test_files/target'
            self.test_root = 'test/unit/compiler'
            self.test_target_2 = 'test/unit/compiler/test_files/target_2'
            shutil.rmtree(self.test_target, ignore_errors=True)
            shutil.rmtree(self.test_target_2, ignore_errors=True)


# Generated at 2022-06-23 22:10:55.755323
# Unit test for function compile_files
def test_compile_files():
    from os import remove
    from os.path import isfile
    from tempfile import mkdtemp
    from shutil import rmtree
    from .exceptions import CompilationError
    import pytest
    # Test error during parsing
    with pytest.raises(CompilationError) as exc_info:
        compile_files('tests/fail', mkdtemp(), CompilationTarget.ES5)
    assert 'unexpected EOF while parsing' in str(exc_info.value)

    # Test error during transformation
    with pytest.raises(CompilationError) as exc_info:
        compile_files('tests/fail_transform', mkdtemp(), CompilationTarget.ES5)
    assert 'parenthesized generator expression' in str(exc_info.value)

    # Test with empty files
    tmp_dir = mkdtemp()
   

# Generated at 2022-06-23 22:11:02.237714
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/testdata', 'test/testout', CompilationTarget.PY) == CompilationResult(2, 0.05892256736755371, CompilationTarget.PY, ['random', 'json', 'sys', 'json'])
    assert compile_files('test/testdata', 'test/testout', CompilationTarget.PY, 'test') == CompilationResult(2, 0.034056425285339355, CompilationTarget.PY, ['random', 'json', 'sys', 'json'])
    assert compile_files('test/testdata', 'test/testout', CompilationTarget.RUN) == CompilationResult(2, 0.13735294342041016, CompilationTarget.RUN, ['collections', 'json', 'random', 'sys'])

# Generated at 2022-06-23 22:11:02.706299
# Unit test for function compile_files

# Generated at 2022-06-23 22:11:09.369075
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    tempdir = tempfile.mkdtemp()
    input_path = tempdir + "/in"
    output_path = tempdir + "/out"

    from pathlib import Path
    import os.path
    Path(input_path).mkdir()
    Path(output_path).mkdir()
    Path(input_path + "/test.py").touch()

    compile_files(input_path, output_path, CompilationTarget.ES5)

    assert os.path.exists(output_path + "/test.js")

test_compile_files()

# Generated at 2022-06-23 22:11:17.287255
# Unit test for function compile_files
def test_compile_files():
    assert compile_files.__name__ == 'compile_files'
    assert compile_files.__doc__ is not None
    assert compile_files('tests/data/compilation/input',
                         'tests/data/compilation/output-standart',
                         CompilationTarget.ES5).errors == 0
    assert compile_files('tests/data/compilation/input',
                         'tests/data/compilation/output-standart',
                         CompilationTarget.ES6).errors == 0
    assert compile_files('tests/data/compilation/input',
                         'tests/data/compilation/output-standart',
                         CompilationTarget.BROWSER).errors == 0

# Generated at 2022-06-23 22:11:17.866621
# Unit test for function compile_files
def test_compile_files():
    assert True

# Generated at 2022-06-23 22:11:28.991797
# Unit test for function compile_files
def test_compile_files():
    '''
    Test for compile_files function.
    '''
    import os.path
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .utils.helpers import delete_directory

    #
    # Create a temporary directory with a test file
    #
    import tempfile
    tmp_path = tempfile.TemporaryDirectory().name
    test_file_name = os.path.join(tmp_path, "test_file.py")
    # Create test file
    with open(test_file_name, "w") as file_:
        file_.write("print(42)\n")

    #
    # Do the compilation
    #
    from .__main__ import compile_files, CompilationResult


# Generated at 2022-06-23 22:11:30.584665
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/files/input', 'test/files/compiled/', CompilationTarget.PYTHON2)

# Unit tests for function _transform

# Generated at 2022-06-23 22:11:39.861173
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os
    import pytest
    import tempfile
    import typing
    import string
    import random
    import glob

    # Initializes test data.
    def init_test_data(
        input_: str, output: str, target: CompilationTarget,
    ):
        shutil.rmtree(input_, ignore_errors=True)
        shutil.rmtree(output, ignore_errors=True)
        os.mkdir(input_)
        os.mkdir(output)

        for i in range(1, 4):
            for j in range(3):
                fname = "".join(
                    random.choice(string.ascii_uppercase) for _ in range(10)
                )

# Generated at 2022-06-23 22:11:46.857107
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(input_='/Users/guillaume/Documents/Code/Python/Python-to-Lua/py2lua/tests/raw', output='/Users/guillaume/Documents/Code/Python/Python-to-Lua/py2lua/tests/compiled', target='lua', root='/Users/guillaume/Documents/Code/Python/Python-to-Lua')
    assert result.count == 3
    assert result.target == 'lua'
    assert result.dependencies == ['py2lua.stdlib']

# Generated at 2022-06-23 22:11:57.812565
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    from pathlib import Path
    from shutil import rmtree

    input_dir_path = Path(tempfile.mkdtemp())
    output_dir_path = Path(tempfile.mkdtemp())
    CountingTransformer.n = 0
    for a in [1, 1.1, "string", False, None]:
        with (input_dir_path / 'test_compile_files.py').open('w') as f:
            f.write("dummy = {}".format(repr(a)))
        compile_files(input_dir_path.as_posix(), output_dir_path.as_posix(),
                      CompilationTarget.PYTHON3)

# Generated at 2022-06-23 22:12:08.339156
# Unit test for function compile_files
def test_compile_files():
    from .transformers import ForToWhileTransformer
    from .exceptions import CompilationError, TransformationError
    from .utils.test_suite import check_source
    from .utils.test_suite import test_path
    from .utils.test_suite import source_path

    try:
        compile_files(test_path, output=test_path, target=50)
    except CompilationError as e:
        assert e.path == test_path / 'simple_imports.py'
        assert e.lineno == 8
        assert e.offset == 0
    else:
        raise

    try:
        compile_files(test_path, output=test_path, target=50)
    except TransformationError as e:
        assert e.path == test_path / 'simple_imports.py'
        assert e.trans

# Generated at 2022-06-23 22:12:17.883727
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    dependency_path = 'temp/dependency.py'
    with open(dependency_path, 'w') as f:
        f.write('n = 42')

    with open('temp/main.py', 'w') as f:
        f.write('from dependency import n\n')

    compile_files('temp', 'dist', CompilationTarget.MCPYTHON)

    assert os.path.isfile('dist/main.py')
    assert os.path.isfile('dist/dependency.py')

    with open('dist/main.py', 'r') as f:
        assert f.read() == 'n = 42\n'

    os.remove(dependency_path)
    shutil.rmtree('temp')
    shutil.rmtree('dist')

# Generated at 2022-06-23 22:12:21.614694
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .tests.helpers import get_test_path, get_test_target
    from .tests.data import tree
    input_ = get_test_path('input', 'correct')
    output = get_test_path('output', 'correct')
    target = get_test_target()
    compile_files(input_, output, target)
    assert tree(input_) == tree(output)

# Generated at 2022-06-23 22:12:32.501025
# Unit test for function compile_files
def test_compile_files():
    input_ = '../tests/compiler/src/'
    output = '../tests/compiler/cache/'

    expected_result = CompilationResult(
        count=5,
        elapsed=0.0,
        target=CompilationTarget.CYTHON,
        dependencies=[
            '<iostream>',
            '<stdexcept>',
            '<string>',
            '<typeinfo>',
            '<vector>'
        ]
    )
    result = compile_files(input_, output, CompilationTarget.CYTHON, '.')
    assert result == expected_result

    expected_result = CompilationResult(
        count=5,
        elapsed=0.0,
        target=CompilationTarget.CXX,
        dependencies=[]
    )

# Generated at 2022-06-23 22:12:43.070047
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import assert_deep_equal_ignore_type

    def compile_files_to_ast(input_: str, output: str, target: CompilationTarget,
                             root: Optional[str] = None) -> ast.Module:
        """Compiles all files from input_ to output and returns a module."""
        dependencies = set()
        for paths in get_input_output_paths(input_, output, root):
            code, dependencies = _transform(paths.input.as_posix(),
                                            paths.input.read_text(), target)
            paths.output.parent.mkdir(parents=True)
            paths.output.write_text(code)
        assert not dependencies
        return ast.parse(paths.output.read_text())


# Generated at 2022-06-23 22:12:51.329307
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import tempfile
    import functools
    import shutil
    import os
    @pytest.fixture
    def compiler():
        path = tempfile.mkdtemp()
        print("path", path)
        os.chmod(path, 0o000)
        yield functools.partial(compile_files, output=path)
        shutil.rmtree(path)

    def test_simple_compilation(compiler):
        compiler('''
        % for i in range(1, 4):
            print(i)
        % end
        ''', target=CompilationTarget.PRODUCTION)

# Generated at 2022-06-23 22:12:51.912016
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:13:00.754186
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("./tests/input", "./tests/output", CompilationTarget('python'))
    with open("./tests/output/sum.py", "r") as f:
        assert f.read() == 'def sum(a, b):\n    return a + b\n\n', "Wrong code"
    assert result.count == 1, "Wrong count"
    assert result.target == CompilationTarget('python'), "Wrong target"
    assert result.dependencies == [], "Wrong dependencies"
    assert result.time > 0, "Wrong time"

# Generated at 2022-06-23 22:13:03.322174
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('.', '.', CompilationTarget.PY,
                         lambda: __file__).count > 0

# Generated at 2022-06-23 22:13:11.997950
# Unit test for function compile_files
def test_compile_files():
    import argparse
    parser = argparse.ArgumentParser(prog='test_compile_files')
    parser.add_argument('--project', default='SRC')
    args = parser.parse_args()
    project_name = args.project
    input_ = 'dataset/%s/probx/src' % project_name
    output = 'dataset/%s/probx/tgt' % project_name
    root = 'dataset/%s/probx' % project_name
    target = 'COMPLETE'
    result = compile_files(input_, output, target, root)
    print('Compiled %d files in %.3f seconds' % (result.file_count,
                                                 result.duration))
    print('Transformed to target %s' % result.target)

# Generated at 2022-06-23 22:13:18.811685
# Unit test for function compile_files
def test_compile_files():
    from pytest import raises
    from pathlib import Path
    from .exceptions import CompilationError
    from .utils.tests import get_fixture, mock_pathlib_makedirs

    with raises(CompilationError, match='^Unexpected indentation$'):
        compile_files(get_fixture('syntax_error'),
                      output='/tmp/output_syntax_error',
                      target=CompilationTarget.ES6)

    with raises(CompilationError, match='^Unexpected indentation$'):
        compile_files(get_fixture('syntax_error_2'),
                      output='/tmp/output_syntax_error',
                      target=CompilationTarget.ES6)


# Generated at 2022-06-23 22:13:25.918979
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from io import open
    from pathlib import Path
    from tempfile import mkdtemp
    from .exceptions import CompilationError, TransformationError
    from .transformers.node_transformer import NodeTransformer
    from .transformers.node_visitor import NodeVisitor

    # Fixture function
    def fixture(code, file_suffix=None):
        if file_suffix:
            input_file.write('{}\n'.format(code.replace('\n', '\n')))
            output_file.write('{}\n'.format(code.replace('\n', '\n')))
        else:
            input_file.write('{}\n'.format(code))
            output_file.write('{}\n'.format(code))

    # Setup
    input_ = Path

# Generated at 2022-06-23 22:13:33.776890
# Unit test for function compile_files
def test_compile_files():
    from .files import files
    from .types import CompilationTarget, CompilationResult
    from unittest import TestCase
    from os import mkdir, remove
    from os.path import exists
    from pathlib import Path

    class CompileFilesTestCase(TestCase):

        def setUp(self):
            self.path = Path(__file__).with_name('test_folder')
            self.path.mkdir(parents=True, exist_ok=True)

            for f in files:
                for path in f.paths():
                    if not path.parent.exists():
                        mkdir(path.parent.as_posix())
                    with path.open('w') as file:
                        file.write(f.content)


# Generated at 2022-06-23 22:13:35.101202
# Unit test for function compile_files
def test_compile_files():
    assert True

# Generated at 2022-06-23 22:13:43.957874
# Unit test for function compile_files
def test_compile_files():
    import shutil, os.path
    from glob import glob

    input_ = 'tests/input'
    output = 'tests/output'
    shutil.rmtree(output)
    assert compile_files(input_, output, CompilationTarget.ES6) == CompilationResult(8, 0, CompilationTarget.ES6, [])

# Generated at 2022-06-23 22:13:52.727352
# Unit test for function compile_files
def test_compile_files():
    path = 'test/sample/'
    rc = compile_files(path + 'input', path + 'output', CompilationTarget.ES5)
    assert rc.succeeded is True
    f = open(path + 'output' + '/test.js')
    assert f.read() == 'var x1,x2=test.test1(x1,test.test2),y=x2;'
    f.close()
    f = open(path + 'output' + '/hello.js')
    assert f.read() == ('var x3,x4=math.min(x3,x3),y=x4;'
                        'console.log(\'hello\')')
    f.close()
    f = open(path + 'output' + '/.hidden.js')

# Generated at 2022-06-23 22:14:04.093078
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    d = tempfile.mkdtemp(prefix='metapensiero-pj-test-')
    src = pathlib.Path(d) / 'src'
    dst = pathlib.Path(d) / 'dst'
    src.mkdir(parents=True)
    dst.mkdir(parents=True)
    (src / '__init__.py').touch()

# Generated at 2022-06-23 22:14:10.828166
# Unit test for function compile_files
def test_compile_files():
    input_ = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), '../resources/test_resources')
    output = input_
    target = CompilationTarget.PYTHON3
    root = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), '../resources/test_resources')
    compile_files(input_, output, target, root)



# Generated at 2022-06-23 22:14:16.474708
# Unit test for function compile_files
def test_compile_files():
    from .files import find_files, InputOutput
    from .utils.helpers import get_test_input_path, get_test_output_path

    input = get_test_input_path('compile')
    output = get_test_output_path('compile')
    for paths in get_input_output_paths(input, output):
        compile_files(input, output, CompilationTarget.Py2, '/')


# Generated at 2022-06-23 22:14:26.097143
# Unit test for function compile_files
def test_compile_files():
    import shutil, pathlib
    try:
        shutil.rmtree('tmp/')
    except FileNotFoundError:
        pass

    files = compile_files('./test/fixtures/', 'tmp', CompilationTarget.ES6)

    assert files.count == 11
    assert files.target == CompilationTarget.ES6
    assert len(files.dependencies) == 2
    assert files.dependencies == ['typing', 'typed_ast']
    assert pathlib.Path('tmp/test/fixtures/app/index.js').exists()
    assert pathlib.Path('tmp/test/fixtures/utils/__init__.js').exists()
    assert pathlib.Path('tmp/test/fixtures/utils/helpers.js').exists()

# Generated at 2022-06-23 22:14:29.928092
# Unit test for function compile_files
def test_compile_files():
    import jedi
    target = CompilationTarget.PYTHON3
    result = compile_files('sample', 'out', target)
    script = jedi.Script('from out.module import foo')
    assert script.completions() == [('foo', 'function')]


# Generated at 2022-06-23 22:14:35.327346
# Unit test for function compile_files
def test_compile_files():
    from .tests import get_test_data_path
    from pathlib import Path
    import json
    input_ = get_test_data_path('compiler/input')
    output = get_test_data_path('compiler/output')
    result = compile_files(input_, output, CompilationTarget.STANDALONE)
    expected = json.load(open(Path(input_) / 'expected.json'))
    assert result == expected



# Generated at 2022-06-23 22:14:36.326966
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/input', 'test/output', CompilationTarget.ES5)

# Generated at 2022-06-23 22:14:46.443169
# Unit test for function compile_files
def test_compile_files():
    from .utils.testing import (temp_directory, make_file, get_file_content,
                                assert_equal, delete_file_or_dir)

    def run_test(input_: str, output: str, expected: str,
                 target: CompilationTarget) -> None:
        """Runs the test for specified targets."""
        try:
            with temp_directory() as temp:
                make_file(temp, 'input.py', input_)
                compile_files(temp / 'input.py', temp / 'output.py',
                              target, temp)
                result = get_file_content(temp / 'output.py')
                assert_equal(result, expected)

        finally:
            delete_file_or_dir(temp)


# Generated at 2022-06-23 22:14:53.740385
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import shutil
    from .test_transformers import test
    test_dir = pathlib.Path(__file__).parent / 'test_compilation'
    input_dir = test_dir / 'input'
    output_dir = test_dir / 'output'
    shutil.rmtree(output_dir, ignore_errors=True)
    result = compile_files(input_dir, output_dir, CompilationTarget.ES6)
    test(result, input_dir, output_dir)