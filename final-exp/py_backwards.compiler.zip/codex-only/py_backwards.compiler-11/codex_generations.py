

# Generated at 2022-06-23 22:04:53.154422
# Unit test for function compile_files
def test_compile_files():
    import os
    import tarfile

    from .tests.test_transformers import test_nodejs_transformer_if
    from .tests.test_transformers import test_nodejs_transformer_undefined
    from .tests.test_transformers import test_nodejs_transformer_from_import
    from .tests.test_transformers import test_nodejs_transformer_identity

    def _test():
        inputs = ['test_nodejs_transformer_if.py',
                  'test_nodejs_transformer_undefined.py',
                  'test_nodejs_transformer_from_import.py',
                  'test_nodejs_transformer_identity.py']
        output = 'test_compile_files.tar.gz'

# Generated at 2022-06-23 22:04:57.385430
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("tests/data/input", "tests/data/output", CompilationTarget.ES5)
    assert result.target == CompilationTarget.ES5
    assert result.count == 4
    assert result.dependencies == ['urllib.request', 'sys', 'aiohttp']
    assert result.duration > 0

# Unit tests for function compile_file

# Generated at 2022-06-23 22:05:03.617897
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('test/data/input', 'test/data/output', CompilationTarget.ES5)

    assert result.target == CompilationTarget.ES5
    assert result.count == 4
    assert result.time > 0
    assert set(result.dependencies) == {'fs', '__builtin__', 'builtins', 'input', 'output'}

    assert Path('test/data/output').is_dir()
    assert Path('test/data/output/1.js').is_file()
    with Path('test/data/output/1.js').open() as f:
        output_1 = f.read()
    assert output_1 == """\
var x = "abc" + "def";
"""

    assert Path('test/data/output/2.js').is_file()

# Generated at 2022-06-23 22:05:14.357195
# Unit test for function compile_files
def test_compile_files():
    import os, shutil
    from .utils.helpers import create_temp_directory

    paths = {
        'input': os.path.join(os.path.dirname(__file__), '../tests/fixtures/'),
        'output': create_temp_directory()
    }

    compile_files(paths['input'], paths['output'], CompilationTarget.PYTHON2)

    # Check if result is correct
    with open(os.path.join(paths['output'], 'file1.py')) as f:
        assert f.read() == "print('Hello world!')\n"


# Generated at 2022-06-23 22:05:15.703453
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import sys


# Generated at 2022-06-23 22:05:26.838641
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .tests import test_target
    from .transformers import first_transformer, second_transformer, third_transformer

    code = """
    def test():
        print('test')

    class Test:
        def __init__(self):
            pass
    """

    expected_code_1 = """
    def test():
        print('test')




    class Test:
        def __init__(self):
            pass
    """
    expected_code_2 = """
    def test():
        print('test')



    class Test:
        def __init__(self):
            pass
    """

    expected_code_3 = """
    def test():
        print('test')



        class Test:
            def __init__(self):
                pass
    """

    expected_code

# Generated at 2022-06-23 22:05:32.736672
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/sources/test/test1',
                         'target',
                         CompilationTarget.ES5).count == 6
    assert compile_files('tests/sources/test/test1',
                         'target',
                         CompilationTarget.ES5).time > 0
    assert compile_files('tests/sources/test/test1',
                         'target',
                         CompilationTarget.ES5).target == CompilationTarget.ES5

# Generated at 2022-06-23 22:05:33.672626
# Unit test for function compile_files
def test_compile_files():
    assert False, 'TODO: Write unit test for function compile_files'

# Generated at 2022-06-23 22:05:44.308610
# Unit test for function compile_files
def test_compile_files():
    input_ = '/Users/ryanzotti/Documents/repos/Self-Driving-Car/3-behavioral-cloning/pipe-car-behavioral-cloning/src/test/test_data/test_dir/test_dir_root.txt'
    output = '/Users/ryanzotti/Documents/repos/Self-Driving-Car/3-behavioral-cloning/pipe-car-behavioral-cloning/src/test/test_data/test_dir/test_dir_root.py'
    target = 'Python2'
    result = compile_files(input_, output, target)
    assert(result == CompilationResult(1, 0.001154184341430664, target, []))


# Generated at 2022-06-23 22:05:47.292221
# Unit test for function compile_files
def test_compile_files():
    CompilationResult(2, 3.14, None, ['a', 'b'])
    CompilationTarget.DEVELOPMENT
    CompilationError('path', 'code', 42, 42)


# Generated at 2022-06-23 22:05:56.429880
# Unit test for function compile_files
def test_compile_files():
    import textwrap
    import glob
    
    def test_transform(input_, expected, target=CompilationTarget.ALL):
        assert compile_files(input_, 'tests/tmp', target).count == 1
        assert glob.glob('tests/tmp/**', recursive=True)
        with Path('tests/tmp/example.py').open() as f:
            actual = textwrap.indent(f.read(), '    ')
            assert actual == expected

    test_transform(
        'tests/examples/to_unicode/example.py',
        textwrap.dedent('''\
            def to_unicode(str):
                return str.decode('utf8')''')
    )


# Generated at 2022-06-23 22:06:03.505545
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    dir_name = 'tmp'
    # remove existing tmp
    subprocess.run(str('rm -rf ' + dir_name), shell=True)
    subprocess.run(str('mkdir ' + dir_name), shell=True)

    result = compile_files(input_='./js_to_py/tests/fixtures/input/',
                    output=dir_name,
                    target=CompilationTarget(major=3))
    num_files = len(list(get_input_output_paths('./js_to_py/tests/fixtures/input/',
                                                dir_name)))

    subprocess.run(str('rm -rf ' + dir_name), shell=True)
    # check that the number of files processed matches the expected number of files
    assert result.count == num_

# Generated at 2022-06-23 22:06:13.472295
# Unit test for function compile_files
def test_compile_files():
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    file = 'foo.py'
    file_with_dependencies = 'foo_with_dependencies.py'
    code = 'def foo(): pass'
    with TemporaryDirectory() as temp_dir:
        with open(file, 'w') as f:
            f.write(code)
        input_ = temp_dir
        output = temp_dir
        result = compile_files(input_, output, CompilationTarget.ES6)
        assert(result.count == 1)
        assert(result.dependencies == [])
        assert(len(result.summary) > 0)
        with open(f'{temp_dir}/{file}') as f:
            assert(f.read() == code)


# Generated at 2022-06-23 22:06:18.839689
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError, TransformationError
    from io import StringIO

    import os
    import shutil

    import pytest

    import logging
    logging.basicConfig(format='[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s',
                        level=logging.DEBUG)
    logging.getLogger('astunparse').setLevel(logging.ERROR)
    logging.getLogger('typed_ast.ast3').setLevel(logging.ERROR)

    TESTDIR = os.path.join(os.path.dirname(__file__), 'test')
    INPUT_DIR = os.path.join(TESTDIR, 'compiler')
    OUTPUT_DIR = os.path.join(TESTDIR, 'compiler_out')



# Generated at 2022-06-23 22:06:20.722170
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('data/test1', 'output/test/test1', CompilationTarget.ES5)



# Generated at 2022-06-23 22:06:31.804395
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 22:06:36.436384
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/files/input/', 'tests/files/output',
                         CompilationTarget.FUNCTION_CALL_ARGUMENTS,
                         'tests/files/input/function_call_arguments/') \
        == CompilationResult(4, 0.0, CompilationTarget.FUNCTION_CALL_ARGUMENTS,
                             ['function'])

# Generated at 2022-06-23 22:06:43.818830
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import tempfile

    input_path = pathlib.Path(__file__).parent / 'resources'
    with tempfile.TemporaryDirectory() as output_path:
        output_path = pathlib.Path(output_path)
        res = compile_files(input_path, output_path, CompilationTarget.PY37)
        assert (res.files == 2)
        assert (res.time >= 0)
        assert (res.target == CompilationTarget.PY37)
        assert (set(res.dependencies) ==
                set(['{}/1.py'.format(input_path),
                     '{}/2.py'.format(input_path)]))


# Generated at 2022-06-23 22:06:53.842046
# Unit test for function compile_files
def test_compile_files():
    from io import StringIO
    import sys
    from .__main__ import compile_files as main

    old_sys_argv = sys.argv
    sys.argv = [
        'compile_files.py',
        '--input', 'tests/data/input',
        '--output', 'tests/data/output',
        '--target', '3'
    ]
    output = StringIO()
    try:
        main(output)
    finally:
        sys.argv = old_sys_argv
    result = output.getvalue()
    assert 'CompilationResult(count=4, duration=0.' in result
    assert 'test.py -> test.js' in result
    assert 'test2.py -> test2.js' in result
    assert 'test3.py -> test3.js' in result

# Generated at 2022-06-23 22:07:04.122718
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    output = Path('test/compiled/__init__.py')

    import os
    if not os.path.exists(output):
        os.makedirs(output)

    assert compile_files('test/input', 'test/compiled',
                         CompilationTarget.PY2_ONLY).code == 0
    assert compile_files('test/input', 'test/compiled',
                         CompilationTarget.PY2_ONLY).target == CompilationResult(5, CompilationTarget.PY2_ONLY)
    assert compile_files('test/input', 'test/compiled',
                         CompilationTarget.PY2_ONLY).dependencies == ['typing', 'six']


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser

# Generated at 2022-06-23 22:07:08.054743
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('', '', CompilationTarget.JS) == \
        CompilationResult(0, 0, CompilationTarget.JS, [])

    assert compile_files(
        '../test/input', '../test/output', CompilationTarget.JS, '../test') == \
        CompilationResult(5, 0, CompilationTarget.JS, [])


# Generated at 2022-06-23 22:07:14.802356
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/compile_files', 'tests/compile_files_out', CompilationTarget.RUNTIME).count == 3
    assert compile_files('tests/compile_files', 'tests/compile_files_out', CompilationTarget.CANONICAL).count == 3
    assert compile_files('tests/compile_files', 'tests/compile_files_out', CompilationTarget.COMPUTATION).count == 3

# Generated at 2022-06-23 22:07:17.620262
# Unit test for function compile_files
def test_compile_files():
    #    assert compile_files('test/temp/original') == None, 'compile_files not working'
    return

# Remember to add these tests
# test_compile_files

# Generated at 2022-06-23 22:07:23.069401
# Unit test for function compile_files
def test_compile_files():
    import os
    input_ = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'test', 'input')
    output = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'test', 'output')
    from .types import PythonVersion
    compile_files(input_, output, PythonVersion.py3)



# Generated at 2022-06-23 22:07:31.022149
# Unit test for function compile_files
def test_compile_files():
    import sys
    import pathlib


# Generated at 2022-06-23 22:07:34.171420
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('/aaa/bbb/ccc', '/ddd/eee/fff', CompilationTarget.PYTHON_3_6)
    print(compile_files.py_func_code)


if __name__ == '__main__':
    print(compile_files.py_func_code)

# Generated at 2022-06-23 22:07:42.408561
# Unit test for function compile_files
def test_compile_files():
    from .files import get_dependency_files
    import io
    import sys
    import tempfile
    from .utils.tempdir import temporary_directory

    class CaptureStdout:
        def __enter__(self):
            self.old = sys.stdout
            self.capture = io.StringIO()
            sys.stdout = self.capture

        def __exit__(self, *args):
            sys.stdout = self.old
            return True

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    target = CompilationTarget.ES5
    with temporary_directory(input_) as input_dir:
        with temporary_directory(output) as output_dir:
            with CaptureStdout():
                compile_files(input_dir, output_dir, target)



# Generated at 2022-06-23 22:07:52.693496
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path

    from .compile import compile_files
    from .types import CompilationResult
    from .utils.constants import DEFAULT_INPUT, DEFAULT_OUTPUT, CompilationTarget

    import pytest

    @pytest.fixture(scope='session')
    def input_dir(tmpdir_factory):
        input_dir = tmpdir_factory.mktemp('input_dir')
        sample_script = Path(input_dir, 'sample_script.py').as_posix()
        Path(input_dir, 'sample_script.py').touch()
        sample_script_empty_dir = Path(input_dir, 'sample_script_empty_dir').as_posix()
        Path(input_dir, 'sample_script_empty_dir').touch()

# Generated at 2022-06-23 22:08:03.403994
# Unit test for function compile_files
def test_compile_files():
    import pprint
    import unittest
    test_dir = '/Users/junjiecao/Desktop/Python/finablr_backend/finablr_backend/unit_tests'
    test_results = [
        #(test_dir, "test1.py", "tests", "test_compiler.py", "test1_compiler_output.py", "tests", "test_compiler.py")
        (test_dir, "test1.py", "tests", "test_compiler.py", "test2_compiler_output.py", "tests", "test_compiler.py")
    ]

    class CompilerTest(unittest.TestCase):
        def test_compile(self):
            for test_case in test_results:
                input_, output = test_case[0], test

# Generated at 2022-06-23 22:08:06.194577
# Unit test for function compile_files
def test_compile_files():
    compile_files("../input/", "../output/", "ECMAScript 5")

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:08:14.973473
# Unit test for function compile_files
def test_compile_files():
    """Compilation of files to the output directory"""
    # pylint: disable=missing-function-docstring
    import tempfile
    import os
    import shutil
    import subprocess
    from .compile import compile_files

    # compile test.c to test.py (source file from pycparser)
    with tempfile.TemporaryDirectory() as tempdir:
        input_dir = os.path.join(tempdir, 'input')
        shutil.copytree('tests/samples/test.c',
                        os.path.join(input_dir, 'test.c'))
        output_dir = os.path.join(tempdir, 'output')
        compile_files(input_dir, output_dir, CompilationTarget.python34)

# Generated at 2022-06-23 22:08:19.898632
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/input/'
    output = 'tests/output/'
    result = compile_files(input_, output, CompilationTarget.PYTHON_27)
    assert 'print' in result.dependencies
    assert len(result.dependencies) > 1
    assert result.compiled == 5
    assert result.elapsed > 0
    assert result.target == CompilationTarget.PYTHON_27

# Generated at 2022-06-23 22:08:27.685273
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import os
    import shutil
    input_ = Path('./Sample/input')
    output = './Sample/output'
    shutil.rmtree(output)
    compile_files(input_, output, CompilationTarget.JS)

    assert (len(os.listdir(output)) == 2)
    assert (len(os.listdir('./Sample/output/Example')) == 3)
    assert (len(os.listdir('./Sample/output/OtherExample')) == 4)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:08:28.326759
# Unit test for function compile_files
def test_compile_files():
    assert False

# Generated at 2022-06-23 22:08:35.814914
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os

    output_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 22:08:38.728254
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .compilation import compile_files
    from .utils.helpers import temp_dir

    result = compile_files('./test/compilation/input', 'output', CompilationTarget.node, temp_dir)

    assert result.count == 2
    assert result.target == 'node'
    assert result.dependencies == ['test/compilation/input/a', 'test/compilation/input/b']
    return result



# Generated at 2022-06-23 22:08:50.558363
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os

    d = tempfile.TemporaryDirectory()
    os.makedirs(os.path.join(d.name, '1'))
    os.makedirs(os.path.join(d.name, '2'))
    os.makedirs(os.path.join(d.name, '3'))
    os.makedirs(os.path.join(d.name, '4'))


# Generated at 2022-06-23 22:08:56.456340
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/data/app_with_imports',
                           './tests/data/app_with_imports_output',
                           CompilationTarget.BROWSER)
    assert result.count == 3
    assert result.target == CompilationTarget.BROWSER
    assert result.dependencies == ['simple', 'test', 'web']
    assert result.duration > 0

# Generated at 2022-06-23 22:09:03.468041
# Unit test for function compile_files
def test_compile_files():
    # Setup testing environment
    log.setLevel(logging.DEBUG)
    stream_handler = logging.StreamHandler()
    log.addHandler(stream_handler)
    # Run our tests
    compile_files('test/test_input', 'test/test_output', CompilationTarget.NORMAL, 'test/test_input')
    # Check if the output is correct
    with open('test/test_output/test_file.py') as f:
        output_code = f.read()
    with open('test/output_file.py') as f:
        expected_code = f.read()
    assert(output_code == expected_code)

# Generated at 2022-06-23 22:09:04.367030
# Unit test for function compile_files
def test_compile_files():
    # TODO: Implement me!
    assert False

# Generated at 2022-06-23 22:09:08.772531
# Unit test for function compile_files
def test_compile_files():
    class Target(CompilationTarget):
        pass

    result = compile_files(
        'tests/compiler/input', 'tests/compiler/output', Target)
    assert result.target == Target
    assert result.count == 2
    assert result.dependencies == ['aiohttp', 'asyncio']

# Generated at 2022-06-23 22:09:15.666974
# Unit test for function compile_files
def test_compile_files():
    import py_js
    import unittest

    # TODO: write more tests

    class CompileFileTest(unittest.TestCase):
        def test_compile_file(self):
            result = compile_files('input/js', 'output/js', CompilationTarget.statement)
            self.assertEqual(result.count, 1)

            with (Path('output/js/test.js').open()) as f:
                self.assertEqual(f.read(), '2')


    unittest.main(module=py_js, verbosity=2)

# Generated at 2022-06-23 22:09:24.681649
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os

    def _assert_compilation_result(result, count, duration, target, dependencies):
        assert result.count == count
        assert result.duration == duration
        assert result.target == target
        assert result.dependencies == dependencies

    with tempfile.TemporaryDirectory() as input_, tempfile.TemporaryDirectory() as output:
        with open(os.path.join(input_, 'file.py'), 'w+') as f:
            f.write('1')
        _assert_compilation_result(compile_files(input_, output, CompilationTarget.RELEASE),
                                   1, 0, CompilationTarget.RELEASE, [])
        with open(os.path.join(output, 'file.py'), 'r') as f:
            assert f.read()

# Generated at 2022-06-23 22:09:35.764510
# Unit test for function compile_files
def test_compile_files():
    input_ = './tests/test_compiler'
    output = './tmp/output'

    compile_files(input_, output, CompilationTarget.ES5)
    assert('''module.exports = {
  foo: function foo(baz) {
    return Math.sin(baz);
  }
};
''' == open('./tmp/output/foo.js').read())
    assert('''var bar = require('./foo');

module.exports = {
  baz: function baz(foo) {
    return bar.foo(foo);
  }
};
''' == open('./tmp/output/bar.js').read())

# Generated at 2022-06-23 22:09:39.988554
# Unit test for function compile_files
def test_compile_files():
    input_ = './src/tests/examples/compile_files_input'
    output = './src/tests/examples/compile_files_output'
    target = CompilationTarget.UNIX
    result = compile_files(input_, output, target)
    assert result.count == 1
    for dependency in result.dependencies:
        assert dependency.endswith('.py')

# Generated at 2022-06-23 22:09:42.733467
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('input', 'output', CompilationTarget.PYTHON) == \
           CompilationResult(count=0, time=0, target=CompilationTarget.PYTHON, dependencies=[])

# Generated at 2022-06-23 22:09:51.658548
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    def create_temp_file(dir_path: str, contents: str, suffix: str='',
                         prefix: str=tempfile.template):
        with tempfile.NamedTemporaryFile(dir=dir_path, mode='w',
                                         suffix=suffix, prefix=prefix,
                                         delete=False) as f:
            f.write(contents)

    def create_temp_dir(dir_path: str, prefix: str=tempfile.template):
        path = os.path.join(dir_path, prefix + '.' + next(tempfile._get_candidate_names()))
        os.mkdir(path)
        return path


# Generated at 2022-06-23 22:10:00.248209
# Unit test for function compile_files
def test_compile_files():
    from os import remove, makedirs
    from os.path import join, exists
    from tempfile import mkdtemp
    from shutil import rmtree

    target = CompilationTarget.TS_NODE_8
    root = mkdtemp()
    makedirs(join(root, 'input'))
    input_ = join(root, 'input')
    makedirs(join(root, 'output'))
    output = join(root, 'output')


# Generated at 2022-06-23 22:10:06.823376
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from shutil import rmtree
    from . import __path__ as package_paths
    package_path = Path(package_paths[0])

    input_ = str((package_path / 'test' / 'test_files').resolve())
    output = 'out'
    assert output != input_
    try:
        compile_files(input_, output, CompilationTarget.PY3)
        pass
    finally:
        rmtree(output)

# Generated at 2022-06-23 22:10:15.867232
# Unit test for function compile_files
def test_compile_files():
    import os, shutil
    folder = 'tmp'
    os.mkdir(folder)

    def clear():
        shutil.rmtree(folder)

    try:
        print(compile_files(folder, folder, CompilationTarget.KEEP_ALL))
        assert False
    except FileNotFoundError:
        pass

    code = 'def foo(x):\n    return x\n'
    with open(os.path.join(folder, 'foo.py'), 'w') as f:
        f.write(code)
    print(compile_files(folder, folder, CompilationTarget.KEEP_ALL))
    with open(os.path.join(folder, 'foo.py'), 'r') as f:
        assert f.read() == code

    clear()
    os.mkdir(folder)
   

# Generated at 2022-06-23 22:10:24.014595
# Unit test for function compile_files
def test_compile_files():
    import os
    import pkgutil
    import pathlib
    from shutil import rmtree

    from .lib.paths import ROOT_DIR
    from .types import CompilationTarget

    def test_case_from_name(name: str) -> Tuple[InputOutput]:
        """Returns input and output paths for particular test case."""
        cases_dir = pathlib.Path(__file__).parent / 'cases'
        input_ = cases_dir / name / 'input'
        output = cases_dir / name / 'output'
        return InputOutput(input_=input_, output=output)

    def run(input_: pathlib.Path, output: pathlib.Path):
        """Returns a `Result` instance."""

# Generated at 2022-06-23 22:10:26.003028
# Unit test for function compile_files
def test_compile_files():
    # TODO: add tests
    pass

# Generated at 2022-06-23 22:10:29.177352
# Unit test for function compile_files
def test_compile_files():
  target = CompilationTarget.PY2AND3
  assert compile_files("/home/c/test.py", "/home/c/test.py", target) == CompilationResult(1, 0, target, [])

# Generated at 2022-06-23 22:10:35.793801
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.python_35
    input_ = "testdata/input"
    output = "testdata/output"
    result = compile_files(input_, output, target)
    assert len(result.dependencies) == len([
        "testdata/input/lib/pyshared/six.py",
        "testdata/input/lib/pyshared/six/__init__.py"
    ])
    assert result.target == target
    assert result.elapsed > 0
    assert result.file_count > 0

# Generated at 2022-06-23 22:10:37.515525
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('.', 'tmp', CompilationTarget.UNKNOWN)



# Generated at 2022-06-23 22:10:48.736389
# Unit test for function compile_files
def test_compile_files():
    from .files import create_dummy_files
    from .transformers import module_name_transformer, function_name_transformer, assignment_transformer
    from .types import Transformer, NO_TRANSFORM

    # We create some dummy test files
    input_directory = create_dummy_files()

    # We use some dummy transformers
    # 1. Convert all module names to the same name
    # 2. Convert all function names to the same name
    # 3. Convert all assignments to None
    transformers = [module_name_transformer, function_name_transformer, assignment_transformer]

    # We compile the files at the standard target
    result = compile_files(input_directory, '.', NO_TRANSFORM)

    # We check whether all files where compiled

# Generated at 2022-06-23 22:10:57.712318
# Unit test for function compile_files
def test_compile_files():
    from tempfile import NamedTemporaryFile
    from .exceptions import CompilationError, TransformationError
    from .config import get_config
    from .types import CompilationTarget
    from .utils.helpers import cd
    from .files import get_full_path, get_relative_path
    from .transformers import transformers
    from .transformers.imports import ImportTransformer
    import py_mini_racer
    config = get_config('test/compile_files.yml')
    with open('test/compile_files_output.txt') as f:
        expected = f.read().rstrip()
    output = NamedTemporaryFile(mode='w+')


# Generated at 2022-06-23 22:11:08.081878
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    import os
    import json

    input_ = TemporaryDirectory('input')
    output = TemporaryDirectory('output')

    copyfile(os.path.join(os.path.dirname(__file__), 'test_files', 'simple.py'),
             os.path.join(input_.name, 'simple.py'))

    copyfile(os.path.join(os.path.dirname(__file__), 'test_files', 'simple.py'),
             os.path.join(input_.name, 'nested', 'simple.py'))

    print(compile_files(input_.name, output.name, CompilationTarget.ES5))

    print(compile_files(input_.name, output.name, CompilationTarget.NODE))

    input_.clean

# Generated at 2022-06-23 22:11:16.103293
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .files import mktemp_directory
    from .utils.helpers import write_file

    with mktemp_directory() as tmp:
        input_ = tmp / 'input'
        output = tmp / 'output'

        input_.mkdir()
        write_file(input_ / 'test1.py', 'def foo():\n    bar()')
        write_file(input_ / 'test2.py', 'def foo():\n    bar()')

        result = compile_files(input_.as_posix(), output.as_posix(),
                               CompilationTarget.PYTHON)

        assert result.compiled_files == 2
        assert result.dependencies == []

        assert output.exists()
        assert (output / 'test1.py').exists()

# Generated at 2022-06-23 22:11:22.934405
# Unit test for function compile_files
def test_compile_files():
    import pytest

    import os

    import tempfile
    import shutil

    from .compile_files import compile_files

    def get_paths(root, *names):
        return os.path.join(root, *names).replace('\\', '/')

    def test_compile_one_file(input_, expected):
        with tempfile.TemporaryDirectory() as output:
            result = compile_files(input_, output, CompilationTarget.PYJS)
            assert result.count == 1
            assert os.path.exists(get_paths(output, 'src/tests/test_compile_one_file.py'))
            with open(get_paths(output, 'src/tests/test_compile_one_file.py'), 'r') as f:
                assert f.read() == expected

# Generated at 2022-06-23 22:11:28.272882
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('test/test_files/compile/input_1',
                           'test/test_files/compile/output_1',
                           CompilationTarget.STANDALONE)
    assert(result.count == 1)
    assert(result.time > 0)
    assert(result.dependencies == ['os'])

# Generated at 2022-06-23 22:11:37.643910
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    def _compile_and_check(input_: str, output: str, root: str, target: CompilationTarget,
                           expected_result: CompilationResult):
        """Compiles files and checks result."""
        actual_result = compile_files(input_, output, target, root)
        assert actual_result == expected_result


# Generated at 2022-06-23 22:11:48.149238
# Unit test for function compile_files
def test_compile_files():
    from .compilers import compile_files
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from pathlib import Path
    import shutil

    file1input = Path('input')
    file1input.mkdir()
    with open(file1input.joinpath('file1.py'), 'w') as f:
        f.write('print(1)\nprint(2)')

    file1output = Path('output')
    file1output.mkdir()

    results = compile_files(file1input.as_posix(), file1output.as_posix(),
                            CompilationTarget.standalone)

    print(results)

    assert results.count == 1
    assert results.target == CompilationTarget.standalone
    assert len(results.dependencies) == 0

    file

# Generated at 2022-06-23 22:11:59.180460
# Unit test for function compile_files
def test_compile_files():
    # imports
    import os
    import shutil

    input_ = os.path.abspath('./test/compiler/input')
    output = os.path.abspath('./test/compiler/output')

    # cleanup directory
    shutil.rmtree(output)

    # do compilation
    compile_files(input_, output, CompilationTarget.PYTHON)

    # assert correct output
    expected_output_path = os.path.abspath('./test/compiler/expected-output')
    for filename in os.listdir(expected_output_path):
        output_filename = os.path.join(output, filename)
        expected_filename = os.path.join(expected_output_path, filename)

# Generated at 2022-06-23 22:12:07.552604
# Unit test for function compile_files
def test_compile_files():
    # 1
    assert compile_files('tests/data/empty', 'data/empty', CompilationTarget.BITBUCKET).count == 0
    # 2
    assert compile_files('tests/data/empty', 'data/empty', CompilationTarget.BITBUCKET).time > 0
    # 3
    assert compile_files('tests/data/empty', 'data/empty', CompilationTarget.BITBUCKET).target == CompilationTarget.BITBUCKET
    # 4
    assert compile_files('tests/data/empty', 'data/empty', CompilationTarget.BITBUCKET).dependencies == []


# Generated at 2022-06-23 22:12:17.665228
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import copytree

    class TestsException(Exception):
        """Fake error for test purposes."""

    def compile_files_with_fake_dependencies(input_: str,
                                             output: str,
                                             target: CompilationTarget,
                                             root: Optional[str] = None) -> CompilationResult:
        """Wrapper of compile_files with fake dependencies."""
        if target == CompilationTarget.BROWSER:
            return compile_files(input_, output, target, root)
        else:
            return CompilationResult(0, 0, target,
                                     ['package1', 'package2'])

    def get_test_input() -> str:
        """Returns path to input_ test dir."""

# Generated at 2022-06-23 22:12:28.445246
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from pathlib import Path
    from .types import CompilationTarget
    from .tests.data_generation import generate_py_file
    from .utils.diff import diff

    def run_with_options(input_path: Path,
                         output_path: Path,
                         target: CompilationTarget,
                         files_count: int,
                         *,
                         root: Optional[Path] = None
                         ) -> CompilationResult:
        """Runs compile_files with passed options."""
        return compile_files(
            input_path.as_posix(),
            output_path.as_posix(),
            target,
            root.as_posix() if root else None,
        )

    with TemporaryDirectory() as dirname:
        input_

# Generated at 2022-06-23 22:12:29.541374
# Unit test for function compile_files

# Generated at 2022-06-23 22:12:31.937197
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./test/input', './test/output', CompilationTarget.PYTHON)


# Generated at 2022-06-23 22:12:42.583963
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from unittest.mock import Mock
    from .utils import set_debug
    from .transformers import transformers

    set_debug(True)
    for transformer in transformers:
        transformer.transform = Mock()

    with TemporaryDirectory() as tmp:
        paths = get_input_output_paths(Path(tmp) / 'input',
                                       Path(tmp) / 'output',
                                       'root')
        for path in paths:
            path.input.parent.mkdir(parents=True)


# Generated at 2022-06-23 22:12:52.361618
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    inputs = (
        "tests/data/tests/errors/",
        "tests/data/tests/typing/",
        "tests/data/tests/syntax/",
        "tests/data/tests/classes/",
        "tests/data/tests/operators/",
        "tests/data/tests/functions/",
        "tests/data/tests/modules/"
    )

# Generated at 2022-06-23 22:12:59.060836
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./tests/data/scripts/good',
                         './tests/data/scripts/output',
                         CompilationTarget.SERVERSIDE) == CompilationResult(2, _,
                                                                           CompilationTarget.SERVERSIDE,
                                                                           sorted(['/usr/local/bin/python3',
                                                                                   '/home/jk/projects/abc/abc.py']))

# Generated at 2022-06-23 22:13:05.778926
# Unit test for function compile_files
def test_compile_files():
    import tempfile, os

    class TempDir:
        def __init__(self):
            self.path = tempfile.mkdtemp()

        def __enter__(self):
            return self.path

        def __exit__(self, type, value, traceback):
            import shutil

            shutil.rmtree(self.path)
            assert not os.path.exists(self.path)

    with TempDir() as tmp:
        # create some input files
        os.system('touch {}/file1.ss'.format(tmp))
        os.system('touch {}/file2.ss'.format(tmp))
        os.system('mkdir -p {}/subdir'.format(tmp))
        os.system('mkdir -p {}/subdir/subsubdir'.format(tmp))

# Generated at 2022-06-23 22:13:12.893951
# Unit test for function compile_files
def test_compile_files():
    print('Compilation test:')
    dirname = '../../tests/compiler'
    result = compile_files(dirname, 'temp', CompilationTarget.JAVASCRIPT)
    assert result.time > 0
    assert result.count > 0
    assert len(result.dependencies) > 0
    print('{count} files compiled in {time} seconds.'.format(**result))


# Generated at 2022-06-23 22:13:19.441385
# Unit test for function compile_files
def test_compile_files():
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def get_deps(self, input_: str) -> List[str]:
            import tempfile
            import os
            with tempfile.TemporaryDirectory() as tmpdirname:
                tmpdirname = os.path.abspath(tmpdirname)
                dst = os.path.join(tmpdirname, 'generated')
                compile_files(input_, dst, CompilationTarget.PYTHON)
                return list(get_input_output_paths(dst, '', tmpdirname))

        def test_dependencies(self):
            deps = self.get_deps('../tests/compilation/dependencies')
            self.assertEqual(len(deps), 2)

# Generated at 2022-06-23 22:13:26.497514
# Unit test for function compile_files
def test_compile_files():
    import io
    import os
    file_max = 4

    actual_results = []
    expected_results = []

    class MockOpen:
        def __init__(self):
            self.file = io.StringIO()

        def __call__(self):
            return self

        def read(self):
            return '''
print('Processing file {}')
'''.format(self.file.name)

        def write(self, content):
            expected_results.append(content)

    class MockGetInputOutputPaths:
        def __init__(self, input_, output):
            self.input = os.path.abspath(input_)
            self.output = os.path.abspath(output)


# Generated at 2022-06-23 22:13:34.414458
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path

    from .exceptions import CompilationError

    from .utils import example_file

    with pytest.raises(CompilationError):
        compile_files(example_file('invalid.py'),
                      example_file(), CompilationTarget.DEFAULT)

    with pytest.raises(CompilationError):
        compile_files(example_file('invalid.py'),
                      example_file(), CompilationTarget.DEFAULT)

    result = compile_files(example_file(), example_file(),
                           CompilationTarget.DEFAULT)

    assert result.count == 2
    assert result.time > 0.0
    assert result.target == CompilationTarget.DEFAULT


# Generated at 2022-06-23 22:13:43.680361
# Unit test for function compile_files
def test_compile_files():
    from .compiler import compile_files
    from .files import build_input_output
    from .exceptions import CompilationError
    result = compile_files(
        *build_input_output(
            '''
            # Translates to python
            def x():
                pass
            '''
        ),
        target='py',
        root=''
    )
    assert result.compiled_files == 1
    assert result.time_spent >= 0
    assert result.target == 'py'
    assert len(result.dependencies) == 0
    assert result.output[0][-3:] == '.py'
    with open(result.output[0]) as f:
        assert f.read() == 'def x():\n    pass\n'


if __name__ == '__main__':
    test_compile

# Generated at 2022-06-23 22:13:48.678880
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./test', './test/__pycache__', CompilationTarget.STANDALONE)
    assert result.count == 4
    assert result.target == CompilationTarget.STANDALONE
    assert result.dependencies == []


if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-23 22:13:56.436649
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import shutil

    with tempfile.TemporaryDirectory() as tmpdirname:
        os.makedirs(os.path.join(tmpdirname,"y"))
        with open(os.path.join(tmpdirname,"x/input1.cb"), "w") as f:
            f.write("a;\n") # this will be removed
            f.write("t;\n")
            f.write("var i: int32 = 0;\n")
            f.write("i += 3;\n") # this will be removed
            f.write("i += 3;\n")
            f.write("i += 3;\n") # this will be removed
            f.write("i += 3;\n")
            f.write("i += 3;\n") # this will be

# Generated at 2022-06-23 22:14:07.253293
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('data', 'dist', CompilationTarget.PY)
    assert result.target == CompilationTarget.PY
    assert result.dependencies == []

    result = compile_files('data', 'dist', CompilationTarget.JS)
    assert result.dependencies == ['numpy', 'pandas']

    result = compile_files('data', 'dist', CompilationTarget.JSX)
    assert result.dependencies == ['numpy', 'pandas']

    result = compile_files('data', 'dist', CompilationTarget.TS)
    assert result.dependencies == ['numpy', 'pandas']
    assert result.count == 3

    result = compile_files('data', 'dist', CompilationTarget.TSX)
    assert result.dependencies == ['numpy', 'pandas']
    assert result

# Generated at 2022-06-23 22:14:10.881420
# Unit test for function compile_files
def test_compile_files():
    # TODO: implement unit test
    if __name__ == '__main__':
        print("Unit tests for compile_files are not implemented")

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:14:15.953550
# Unit test for function compile_files
def test_compile_files():
    from .utils.asserts import assert_equals
    from .files import get_project_path

    class FakeTarget:
        def __init__(self, name):
            self.name = name

    target = FakeTarget('fake_target')
    result = compile_files(get_project_path('tests/input'),
                           get_project_path('tests/output'), target)
    assert_equals(result.target, target)
    assert_equals(result.dependencies, [])
    assert_equals(result.count, 1)
    assert_equals(result.time, 0.0)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:14:22.505651
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/data/input', 'tests/data/output', CompilationTarget.WEB)
    assert result.count == 5, 'Wrong number of compiled files'
    assert result.dependencies == [
        'd3@5.7.0',
        'src/custom/customjs.js',
        'src/custom/fib.js',
        'src/custom/main.js',
        'src/custom/webpack.js',
        'src/custom/webpack-ext.js'
    ], 'Wrong dependencies'

# Generated at 2022-06-23 22:14:24.930867
# Unit test for function compile_files
def test_compile_files():
    from .testing import assert_compilation
    assert_compilation('sample_project/lib', 'test-compile-files',
                       'test_compile_files')

# Generated at 2022-06-23 22:14:34.408311
# Unit test for function compile_files
def test_compile_files():
    def compile(input_: str, target: CompilationTarget) -> str:
        result = compile_files(input_, '/dev/null', target)
        assert result.target == target

        with Path(input_).open() as f:
            return unparse(ast.parse(f.read(), input_))

    with Path('tests/compile_files.py').open() as f:
        test_code = f.read()

    assert compile('tests/compile_files.py', CompilationTarget.python) == test_code
    assert compile('tests/compile_files.py', CompilationTarget.webassembly) == test_code
    assert compile('tests/compile_files.py', CompilationTarget.v8) != test_code
    assert compile('tests/a_stub.py', CompilationTarget.v8)

# Generated at 2022-06-23 22:14:37.911364
# Unit test for function compile_files
def test_compile_files():
    import os
    assert compile_files(
        input_=os.path.abspath(os.path.join(__file__, '..', '..', 'test', 'compile_test')),
        output=os.path.abspath(os.path.join(__file__, '..', '..', 'test', 'compile_test_output')),
        target='pypy').count == 2

# Generated at 2022-06-23 22:14:43.222328
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    try:
        output = temp_dir.name
        input_ = 'tests/assets/global_scope/*'
        target = CompilationTarget.PYTHON_CODE
        result = compile_files(input_, output, target)
        assert result.count == 2
        for path in os.listdir(os.path.join(output, 'global_scope')):
            assert path.endswith('.py')
    finally:
        shutil.rmtree(temp_dir)


# Generated at 2022-06-23 22:14:54.959774
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    import shutil
    import unittest

    from .utils.files import get_input_output_paths, InputOutput
    from .transformers import DataClassTransformer
    from .types import CompilationTarget
    from .utils.helpers import debug, get_root_path

    class TestCompileFiles(unittest.TestCase):

        def test_valid(self):
            input_ = os.path.join(get_root_path(), 'test/input')
            output = os.path.join(get_root_path(), 'test/output')

            shutil.rmtree(output, ignore_errors=True)
            os.makedirs(output, exist_ok=True)

            for paths in get_input_output_paths(input_, output):
                code = paths.input