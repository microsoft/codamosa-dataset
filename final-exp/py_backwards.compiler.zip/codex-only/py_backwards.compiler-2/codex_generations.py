

# Generated at 2022-06-23 22:04:34.753174
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:04:42.008717
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import shutil
    import tempfile
    from .files import get_input_output_paths
    from .types import CompilationTarget, CompilationResult
    from .transformers.bracket import module

    input_path = tempfile.mkdtemp()
    output_path = tempfile.mkdtemp()


# Generated at 2022-06-23 22:04:43.511430
# Unit test for function compile_files
def test_compile_files():
    pass
    # assert compile_file('test.py', 'out.py', CompilationTarget..) == '5'

# Generated at 2022-06-23 22:04:47.469061
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    from .types import CompilationResult
    from .transformers import TargetPython

    folder = pathlib.Path(__file__).parent.resolve()
    folder /= 'test_resources'

    result = compile_files(folder, folder / 'compiled', TargetPython, folder)
    assert isinstance(result, CompilationResult)
    assert result.count == 0

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:04:56.996987
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    assert compile_files('python_toolbox/tests/fixtures/truthy.py',
                         '/home/user/projects/foo/bar.js',
                         CompilationTarget.JS) == \
        CompilationResult(1, 0, CompilationTarget.JS,
                          ['python_toolbox/lib/bool/__init__.py'])

    assert compile_files('python_toolbox/tests/fixtures/truthy.py',
                         '/home/user/projects/foo/bar.js',
                         CompilationTarget.PY2) == \
        CompilationResult(1, 0, CompilationTarget.PY2,
                          [])


# Generated at 2022-06-23 22:05:08.649860
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from .types import CompilationTarget

    with TemporaryDirectory() as tmpdir:
        input_ = Path(tmpdir)
        output = input_ / 'output'
        result = compile_files(str(input_), str(output), CompilationTarget.NODEJS)
        assert len(result.dependencies) == 0
        assert result.files_compiled == 0
        assert result.build_time > 0


# Generated at 2022-06-23 22:05:17.179564
# Unit test for function compile_files
def test_compile_files():
    from os import environ
    from os.path import join
    from . import __file__ as dir
    from .utils.helpers import init_debug_logger, update_env_var
    init_debug_logger()
    update_env_var()

    target = environ['TARGET']
    result = compile_files(join(dir, 'test', 'data', 'src'),
                           join(dir, 'test', 'data', 'dst'),
                           target, dir)

    assert result.target == target
    assert result.time > 0
    assert result.count == 2
    assert len(result.dependencies) == 3



# Generated at 2022-06-23 22:05:26.308079
# Unit test for function compile_files
def test_compile_files():
    import tempfile

    with tempfile.TemporaryDirectory() as tempdir:
        input_ = tempdir + '/in'
        output = tempdir + '/out'
        import shutil
        shutil.copytree('tests/templates/simple', input_)
        shutil.copytree('tests/templates/simple/node_modules', input_ + '/node_modules')
        compile_files(input_, output, CompilationTarget.ES5)
        print('Compiled', len(list(get_input_output_paths(input_, output))), 'files')


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:05:34.230320
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/resources', 'tests/examples/tmp/projects', CompilationTarget.WEB)
    assert result.count == 3
    assert result.target == CompilationTarget.WEB
    assert result.dependencies == ['D:\\Dev\\PyAutoIEP\\_RELEASE\\projects.py', 'D:\\Dev\\PyAutoIEP\\_RELEASE\\utils']

if __name__ == '__main__':
    result = compile_files('tests/resources', 'tests/examples/tmp/projects', CompilationTarget.WEB)
    print('Compiled {} files in {:.2f}s\n{}'.format(result.count,
                                                    result.duration,
                                                    result))

# Generated at 2022-06-23 22:05:45.264102
# Unit test for function compile_files
def test_compile_files():
    import tempfile, shutil
    from pytest import raises
    from .test_files import get_test_path

    def _compile_test(input_: str, output: str, target: str):
        directory = tempfile.mkdtemp()
        try:
            compile_files(get_test_path(input_), directory, target)
            assert target in directory
            assert input_ in directory
        finally:
            shutil.rmtree(directory)

    _compile_test('test.py', 'test-output', 'BOTH')
    _compile_test('test.py', 'test-output', 'PY3')
    _compile_test('test.py', 'test-output', 'PY2')


# Generated at 2022-06-23 22:05:45.772345
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:05:46.446707
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:05:48.524955
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/data/tests', 'tests/data/dist', CompilationTarget.PY2)

# Generated at 2022-06-23 22:05:57.201239
# Unit test for function compile_files
def test_compile_files():
    from .debug import source

    import os

    if not os.path.exists('build'):
        os.mkdir('build')

    compile_files('src', 'build', CompilationTarget.PYTHON)
    compile_files('build', 'build-2', CompilationTarget.JAVASCRIPT)

    assert source('build-2/test/test_test.js') == (
        '(function() {\n'
        '    var x = "test";\n'
        '    var y = "test";\n'
        '}).call(this);\n'
    )

# Generated at 2022-06-23 22:06:03.956484
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import pathlib

    file_content = \
        'from _pytest.pytester import Testdir\n' \
        'def pytest_generate_tests(metafunc):\n' \
        '    metafunc.addoption("--failed", type=bool, default=False)\n'

    input_ = 'tests-input/'
    output = 'tests-output/'
    source = pathlib.Path(input_ + 'test_1.py')
    source.mkdir(parents=True)
    source.write_text(file_content)
    target = CompilationTarget.TEST

    result = compile_files(input_, output, target)
    assert result.count == 1
    assert len(result.dependencies) == 3
    assert result.target == target
    assert isinstance

# Generated at 2022-06-23 22:06:13.783629
# Unit test for function compile_files
def test_compile_files():
    def do_compile(input_: str, output: str, target: CompilationTarget, root: str = None) -> CompilationResult:
        paths = get_input_output_paths(input_, output, root)
        deps = set()
        for path in paths:
            deps.update(_compile_file(path, target))
        return CompilationResult(len(paths), -1, target, sorted(deps))

    res = do_compile('test/data/basic_lib', 'test/tmp', CompilationTarget.ES2015)
    assert res.files_count == 1
    assert res.target == CompilationTarget.ES2015
    assert res.dependencies == ['test/data/basic_lib/__init__.py']


# Generated at 2022-06-23 22:06:22.643244
# Unit test for function compile_files
def test_compile_files():
    from .compiler import compile_files
    from .types import CompilationResult
    from pathlib import Path
    import os

    os.mkdir('_compiler_test_dir')
    os.mkdir('_compiler_test_dir/module')
    os.mkdir('_compiler_test_dir/html')
    os.mkdir('_compiler_test_dir/js')
    Path('_compiler_test_dir/module/__init__.py').touch()
    Path('_compiler_test_dir/html/__init__.py').touch()
    Path('_compiler_test_dir/js/__init__.py').touch()


# Generated at 2022-06-23 22:06:23.389709
# Unit test for function compile_files
def test_compile_files():
    assert False

# Generated at 2022-06-23 22:06:26.817795
# Unit test for function compile_files
def test_compile_files():
    compile_files('./tests/input/regression', './tests/output',
                  CompilationTarget.DEBUG)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:06:34.203139
# Unit test for function compile_files
def test_compile_files():
    from io import StringIO
    from .compilation_result import CompilationResult
    from .utils import CompilationTargetEnum

    output = StringIO()
    compile_files(input_='test/test_files/test_file_*.py', output='temp', target=CompilationTargetEnum.PSA, root='test')
    result = CompilationResult(count=2, time=output, target=CompilationTargetEnum.PSA, dependencies=["test/test_files/test_file_2.py"])
    assert result == result

# Generated at 2022-06-23 22:06:36.821606
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/assets/hello.py',
                           './tests/output/hello/py', CompilationTarget.PYTHON)
    assert result.count == 1



# Generated at 2022-06-23 22:06:43.956962
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError
    from .files import compile_files
    from .types import CompilationTarget
    from .transformers import transformers

    paths = compile_files(Path('./tests/data/'))
    [transformer.__class__.transform(path, paths)
     for path, transformers in paths.items()
     for transformer in transformers]
    compile_files(Path('./tests/data/'),
                  Path('./tests/build/'),
                  CompilationTarget.RELEASE,
                  root=Path('./tests/data/'))

# Generated at 2022-06-23 22:06:53.907216
# Unit test for function compile_files
def test_compile_files():
    input_ = os.path.join(os.path.dirname(__file__), "input")
    output = os.path.join(os.path.dirname(__file__), "output")
    compile_files(input_, output, CompilationTarget.PYTHON)
    assert os.path.isfile(os.path.join(output, "test.py"))
    assert os.path.isfile(os.path.join(output, "subdir", "test.py"))
    assert os.path.isfile(os.path.join(output, "subdir", "test.js"))
    assert os.path.isfile(os.path.join(output, "subdir", "test.json"))
    assert os.path.isfile(os.path.join(output, "subdir", "test.txt"))

# Generated at 2022-06-23 22:06:57.892143
# Unit test for function compile_files
def test_compile_files():
    from splitback.exceptions import CompilationError
    try:
        compile_files('tests/files/compile_files_input',
                      'tests/files/compile_files_output',
                      CompilationTarget.STRICT)
    except CompilationError:
        pass



# Generated at 2022-06-23 22:07:01.627238
# Unit test for function compile_files
def test_compile_files():
    from .testing import TestCase
    from .testing.utils import test

    if test:
        TestCase(compile_files, 'compile_files', 'test_compile_files').run()

# Generated at 2022-06-23 22:07:04.459335
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('test/root', 'test/root', CompilationTarget.ES5)
    assert result.count == 3
    assert result.target == CompilationTarget.ES5



# Generated at 2022-06-23 22:07:08.317409
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    total_deps = set()
    for paths in get_input_output_paths('./examples', './examples/.compiled', './examples'):
        total_deps.update(_compile_file(paths, CompilationTarget.NATIVE))
    return total_deps

# Generated at 2022-06-23 22:07:13.464529
# Unit test for function compile_files
def test_compile_files():
    compile_files("../test_data/test_input", "../test_data/test_output", CompilationTarget.PY3)
    compile_files("../test_data/test_input", "../test_data/test_output", CompilationTarget.PY2)
    compile_files("../test_data/test_input", "../test_data/test_output", CompilationTarget.JAVA)
    compile_files("../test_data/test_input", "../test_data/test_output", CompilationTarget.JS)
    compile_files("../test_data/test_input", "../test_data/test_output", CompilationTarget.INTERP)

test_compile_files()

# Generated at 2022-06-23 22:07:14.191035
# Unit test for function compile_files
def test_compile_files():
    pass



# Generated at 2022-06-23 22:07:23.339987
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import FileFactory

    try:
        input_tmp = FileFactory.mktempdir()
        output_tmp = FileFactory.mktempdir()
        input_ = input_tmp.joinpath('input')
        output = output_tmp.joinpath('output')
        input_.mkdir()

        file = input_.joinpath('foo.py')
        file.write_text('print("Hello, World!")')

        compile_files(input_.as_posix(), output.as_posix(), CompilationTarget.VANILLA_PYTHON)

        assert output.joinpath('foo.py').exists()
    finally:
        shutil.rmtree(input_tmp)
        shutil.rmtree(output_tmp)

# Generated at 2022-06-23 22:07:28.982469
# Unit test for function compile_files
def test_compile_files():
    """Test compile_files()."""
    input_path = Path(__file__).parent / 'tests' / 'simple' / 'input'
    output_path = Path(__file__).parent / 'tests' / 'simple' / 'output'
    result = compile_files(input_path.as_posix(), output_path.as_posix(),
                           CompilationTarget.WEBASSEMBLY)
    print(result)

# Generated at 2022-06-23 22:07:36.030076
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    import pytest
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as temp_dir:
        input_ = os.path.join(temp_dir, 'input')
        output = os.path.join(temp_dir, 'output')
        os.mkdir(input_)
        os.mkdir(output)

        with open(os.path.join(input_, 'test.py'), 'w') as f:
            f.write('lt = lambda x: x < 10\nprint(lt(4))')

        with pytest.raises(CompilationError):
            compile_files(input_, output, CompilationTarget.PY)


# Generated at 2022-06-23 22:07:38.159181
# Unit test for function compile_files
def test_compile_files():
    compile_files(input_='examples', output='examples_output', \
                  target=CompilationTarget.PYTHON)
    # Check that there are no errors
    assert True

# Generated at 2022-06-23 22:07:41.179294
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/sources/1', 'tests/sources/1', CompilationTarget.ES5)



# Generated at 2022-06-23 22:07:48.596513
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    def _compile_files(target):
        directory = tempfile.mkdtemp()

# Generated at 2022-06-23 22:07:50.148859
# Unit test for function compile_files
def test_compile_files():
    from .examples.testcase import test_compile_files as test_compile_files_ex
    test_compile_files_ex()

# Generated at 2022-06-23 22:07:57.736204
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import pytest
    from pathlib import Path
    sys.path.append(os.getcwd())
    from pympile.transformers import transformers
    from pympile.exceptions import CompilationError, SyntaxError
    from pympile.types import CompilationTarget
    from pympile.utils.helpers import debug
    from pympile.utils.temp_dir import TempDir
    from pympile.utils.default_ast import InferHelper
    from pympile.files import InputOutput

    class TestTransformer(transformers[0]):  # type: ignore
        target = CompilationTarget.DEBUG
        @classmethod
        def transform(cls, tree: ast.Module) -> ast.Module:
            pass

    __tracebackhide__ = True

# Generated at 2022-06-23 22:08:07.561172
# Unit test for function compile_files
def test_compile_files():
    # Test setting up
    test_input = pathlib.Path(os.path.dirname(__file__), "test_input")
    test_output = pathlib.Path(os.path.dirname(__file__), "test_output")
    test_target = CompilationTarget.ES5
    if os.path.exists(test_output.as_posix()):
        shutil.rmtree(test_output.as_posix())
    os.mkdir(test_output.as_posix())
    result = compile_files(test_input.as_posix(), test_output.as_posix(), test_target)
    assert result.count == 3

# Generated at 2022-06-23 22:08:13.476906
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from shlex import split
    from subprocess import run

    with TemporaryDirectory() as dir_:
        compile_files('tests/data', dir_, CompilationTarget.COMPONENT,
                      'tests/data')
        result = run(split('py.test --cov-report term-missing --cov=py_ecc '
                           '-s -v {}'.format(dir_)))
        assert result.returncode == 0, result.stderr

# Generated at 2022-06-23 22:08:16.657739
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(input_ = 'test/basic_input', output = 'test/basic_output', target = CompilationTarget.ES5)



# Generated at 2022-06-23 22:08:17.319076
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:08:23.761311
# Unit test for function compile_files
def test_compile_files():
    compile_files('./test/test_input',
      './test/test_output',
      CompilationTarget.JAVASCRIPT)
    print('Compile files to javascript pass')
    compile_files('./test/test_input',
      './test/test_output',
      CompilationTarget.RUBY)
    print('Compile files to javascript pass')
    compile_files('./test/test_input',
      './test/test_output',
      CompilationTarget.GO)
    print('Compile files to javascript pass')
    compile_files('./test/test_input',
      './test/test_output',
      CompilationTarget.C)
    print('Compile files to javascript pass')

# Generated at 2022-06-23 22:08:32.223901
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    # Arrange
    input_ = os.path.join(os.path.dirname(__file__), 'compile_files.test')
    output = tempfile.mkdtemp()
    target = CompilationTarget.MODULE
    # Act
    compile_files(input_, output, target)
    output_file = os.path.join(output, 'src', 'test', 'a.py')
    with open(output_file, 'r') as f:
        code = f.read()
    # Assert
    assert code == "def a():\n    pass"
    # Cleanup
    shutil.rmtree(output)


# Generated at 2022-06-23 22:08:39.151455
# Unit test for function compile_files
def test_compile_files():
    import sys
    from . import __version__
    from .parser import parse_args
    from .exceptions import CompilationError

    args = parse_args(sys.argv[1:], __version__)
    args.target = CompilationTarget.PYTHON
    args.input = "test-input"
    args.output = "test-output"
    try:
        compile_files(args.input, args.output, args.target, args.root)
    except CompilationError:
        pass

# Generated at 2022-06-23 22:08:47.642008
# Unit test for function compile_files
def test_compile_files():
    input_ = Path(__file__).parent / 'tests' / 'compile_files' / 'input'
    output = Path(__file__).parent / 'tests' / 'compile_files' / 'output'
    result = compile_files(input_, output, CompilationTarget.BROWSER)
    assert result.count == 2
    assert result.target == CompilationTarget.BROWSER
    assert result.dependencies == ['x-loader', 'x-transformer']


# Generated at 2022-06-23 22:08:55.370965
# Unit test for function compile_files
def test_compile_files():
    from .test import test_dir
    import pprint
    compile_files(test_dir / 'input', test_dir / 'output', CompilationTarget.JS)
    compile_files(test_dir / 'input', test_dir / 'output', CompilationTarget.JS)
    compile_files(test_dir / 'input', test_dir / 'output', CompilationTarget.JS)
    compile_files(test_dir / 'input', test_dir / 'output', CompilationTarget.JS)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:04.003837
# Unit test for function compile_files
def test_compile_files():
    from pytest import raises
    from random import choice
    from string import ascii_letters
    from .types import CompilationTarget

    for target in CompilationTarget:
        # Empty files
        empty_code = """
        """
        count, duration, target, dependencies = compile_files(
            input_='/tmp/foo', output='/tmp/bar', target=target)
        assert count == 0
        assert dependencies == []

        # Single file
        code = """
            import os
            import sys
            import json

            a = ['{}']
            b = {'a', 'b', 'c'}

            class Foo:
                def __init__(self, a):
                self.a = a

        """

# Generated at 2022-06-23 22:09:14.062146
# Unit test for function compile_files
def test_compile_files():
    """Test compilation of .sql files into .py with mock data."""
    from py.path import local
    from . import mock
    from .types import CompilationTarget

    path_input = local(__file__).dirpath('mock', 'input')
    path_output = path_input.dirpath('output')
    CompilationResult(expected_count=1,
                      expected_time=0.0,
                      expected_target=CompilationTarget.POSTGRESQL,
                      expected_dependencies=['psycopg2', 'psycopg2-binary'])
    compile_files(path_input, path_output, CompilationTarget.POSTGRESQL)
    expected = mock.PYTHON_OUTPUT.strip()

# Generated at 2022-06-23 22:09:15.660705
# Unit test for function compile_files
def test_compile_files():
    compile_files('./tests/in', './tests/tests_out', CompilationTarget.ES6)

# Generated at 2022-06-23 22:09:23.742282
# Unit test for function compile_files
def test_compile_files():
    def assert_compilation_result(result: CompilationResult, count: int,
                                  duration: float, target: CompilationTarget,
                                  dependencies: List[str]):
        assert result.count == count
        assert round(result.duration, 2) == round(duration, 2)
        assert result.target == target
        assert result.dependencies == dependencies
        assert str(result)
        assert repr(result)

    result = compile_files(Path(__file__).parent / 'input',
                           Path(__file__).parent / 'output',
                           CompilationTarget.PYTHON27)
    assert_compilation_result(result, 1, 0, CompilationTarget.PYTHON27, [])

# Generated at 2022-06-23 22:09:34.763719
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import shutil
    import pytest
    import subprocess
    import json

    input_ = os.path.realpath(
        os.path.join(os.path.dirname(__file__), '..', 'data', 'input'))
    output = os.path.realpath(os.path.join(input_, '..', 'output'))

    # Create a temporary directory for files under test
    temp_dir = tempfile.mkdtemp()
    temp_output_dir = os.path.join(temp_dir, 'output')
    temp_input_dir = os.path.join(temp_dir, 'input')
    os.mkdir(temp_input_dir)
    os.mkdir(temp_output_dir)

    # Copy all files from input directory

# Generated at 2022-06-23 22:09:37.814656
# Unit test for function compile_files
def test_compile_files():
    path = Path(__file__).parent.parent / 'tests'
    result = compile_files(str(path), '/tmp/compiled', CompilationTarget.CORE_1_2)
    assert result.elapsed > 0
    assert result.count > 0
    assert len(result.dependencies) == 0

# Generated at 2022-06-23 22:09:41.417374
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/test.py', 'test/', CompilationTarget.PYTHON) == CompilationResult(1, 0.0, CompilationTarget.PYTHON, [])

# Generated at 2022-06-23 22:09:42.984673
# Unit test for function compile_files
def test_compile_files():
    compile_files("src", "dst", CompilationTarget.PYTHON_TO_C)

# Generated at 2022-06-23 22:09:50.878813
# Unit test for function compile_files
def test_compile_files():
    from .test.test_compiler import test_ts2js_single_file
    import os.path
    import json

    config_path = os.path.join(os.path.dirname(__file__), '../ts2js.json')
    with open(config_path, 'r') as config_file:
        config = json.load(config_file)
        config['input'] = os.path.join(os.path.dirname(__file__), config['input'])
        config['output'] = os.path.join(os.path.dirname(__file__), config['output'])
        test_ts2js_single_file(config)

# Generated at 2022-06-23 22:09:59.691268
# Unit test for function compile_files
def test_compile_files():
    # This tests some components of the compiler, without putting
    # the entire compiler through a test harness.

    # Construct a list of paths to the test files
    from os import listdir, path
    from .files import get_test_files
    test_files = [path.join(get_test_files(), test_file)
                  for test_file in listdir(get_test_files())]

    # Get the input and output paths from the test files
    from .files import get_input_output_paths
    input_output = get_input_output_paths(test_files, None, None)

    # Create the input and output directories
    from pathlib import Path
    Path(input_output[0][0].input).parent.mkdir()
    Path(input_output[0][0].output).parent.mkdir()

   

# Generated at 2022-06-23 22:10:10.095959
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .testutils.folder import TemporaryFolder
    from .testutils.files import make_files
    from .testutils.files import get_dependencies, assert_files_equal

    temp_dir = os.path.join(os.path.dirname(__file__), '__compile_files__')
    with TemporaryFolder(temp_dir) as folder:
        input_ = folder.make_path('src')
        output_ = folder.make_path('bin')

        make_files(input_ / 'ok', {'a.c': 'int main() {return 0;}'})
        make_files(input_ / 'ko', {'a.c': 'int main(int argc) {return 0;}'})

# Generated at 2022-06-23 22:10:16.427745
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import glob
    import os
    # Use some temporary directory
    tempdir = "testdir"
    shutil.rmtree(tempdir)
    os.mkdir(tempdir)
    # Use some (empty) directory as a root
    rootdir = "rootdir"
    os.mkdir(rootdir)
    # Create some fake files
    with open(os.path.join(tempdir, "x.py"), "w") as f:
        f.write("def f(x): pass")
    with open(os.path.join(tempdir, "y/y.py"), "w") as f:
        f.write("def f(x): pass")

# Generated at 2022-06-23 22:10:24.261872
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from pathlib import Path
    from .testing import TempDir
    input_ = TempDir.create()
    output = TempDir.create()
    input_.subdir('sub').subfile('sub_file.py', 'print(1)')
    input_.subfile('c.py', """
    from .sub import sub_file
    sub_file""")
    compile_files(input_.path, output.path, CompilationTarget.SOURCE)
    assert Path(output.path, 'sub', 'sub_file.py').exists()
    assert Path(output.path, 'sub', 'sub_file.py').read_text('utf-8') == "print(1)\n"
    assert Path(output.path, 'c.py').exists()
    assert Path(output.path, 'c.py').read

# Generated at 2022-06-23 22:10:33.700452
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import shutil

    def compile_and_check(code: str, expected: str, target: CompilationTarget):
        with tempfile.TemporaryDirectory() as tmpdirname:
            input_file = os.path.join(tmpdirname, 'test.go')
            output_file = os.path.join(tmpdirname, 'test.py')
            with open(input_file, 'w') as f:
                f.write(code)
            compile_files(input_=input_file, output=output_file, target=target)
            with open(output_file) as f:
                assert f.read() == expected


# Generated at 2022-06-23 22:10:37.141204
# Unit test for function compile_files
def test_compile_files():
    input_ = '../tests/sources'
    output = '../tests/bin'
    root = '../tests/sources'
    result = compile_files(input_, output, CompilationTarget.UNIVERSAL, root)
    assert result.success
    assert result.files == 3

# Generated at 2022-06-23 22:10:47.805952
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import pathlib
    import unittest
    import tempfile
    from .transformers import transformers

    target = CompilationTarget.JS
    input_ = pathlib.Path(__file__).parent / 'files' / 'input'
    output = tempfile.mkdtemp()

    result = compile_files(input_, output, target)

    assert result.count == 6
    assert result.target == target

    shutil.rmtree(output)

    result = compile_files(input_, output, target, input_)

    assert result.count == 6
    assert result.target == target

    input_ = input_ / 'subdir'

    result = compile_files(input_, output, target, input_)

    assert result.count == 3
    assert result.target == target


# Generated at 2022-06-23 22:10:52.443666
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("/tmp/test_input/test.py", "/tmp/test_output", CompilationTarget.PYTHON, "")
    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['os.path']

# Generated at 2022-06-23 22:11:00.180086
# Unit test for function compile_files
def test_compile_files():
    """Unit test for compile_files"""
    assert compile_files("input", "output", CompilationTarget.PYTHON) == \
        CompilationResult(3, 0, CompilationTarget.PYTHON, ['pc', 'pc2', 'pp'])
    assert compile_files("input", "output",
                         CompilationTarget.PYTHON_LAMBDA) == \
        CompilationResult(3, 0, CompilationTarget.PYTHON_LAMBDA,
                          ['pp'])
    assert compile_files("input", "output", CompilationTarget.POWERLINE) == \
        CompilationResult(3, 0, CompilationTarget.POWERLINE, ['pc', 'pc2'])
    assert compile_files("input", "output", CompilationTarget.JAVASCRIPT) == \
        Compilation

# Generated at 2022-06-23 22:11:10.187549
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils import build_path
    import os.path
    import pytest

    here = Path(os.path.dirname(__file__))

    def test(target: CompilationTarget, expect_error: bool = False):
        result = compile_files(
            build_path([here, 'test_files', 'input']),
            build_path([here, 'test_files', 'output']),
            target,
            str(here)
        )
        assert result.count == 3
        assert result.dependencies == ['forms', 'threading', 'io']


# Generated at 2022-06-23 22:11:18.487245
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile
    from .files import InputOutput
    from .transformers import transformers

    tmpdir = Path(tempfile.mkdtemp())
    
    paths1 = InputOutput(tmpdir / 'input' / 'a.h',
                         tmpdir / 'output' / 'a.h')
    paths1.output.parent.mkdir(parents=True)
    with paths1.input.open('w') as f:
        f.write('struct A{};')
    with paths1.output.open('w') as f:
        f.write('struct A{};')
    
    paths2 = InputOutput(tmpdir / 'input' / 'b.h',
                         tmpdir / 'output' / 'b.h')
    paths2.output.parent.mkdir(parents=True)

# Generated at 2022-06-23 22:11:29.790310
# Unit test for function compile_files
def test_compile_files():
    def _compile(path, target):
        with open(path) as f:
            code = f.read()

        try:
            return unparse(_transform(path, code, target)[0])
        except SyntaxError as e:
            raise CompilationError(path, code, e.lineno, e.offset)

    input_ = 'test/files/input'
    output = 'test/files/output'
    target = CompilationTarget.CLIENT

    compile_files(input_=input_, output=output, target=target)

    for paths in get_input_output_paths(input_, output):
        with paths.output.open() as f:
            transformed_code = f.read()

        with paths.input.open() as f:
            code = f.read()


# Generated at 2022-06-23 22:11:33.171634
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/input', 'tests/output', CompilationTarget.WEBPACK) == \
        CompilationResult(4, 0.1, CompilationTarget.WEBPACK, [])

# Generated at 2022-06-23 22:11:40.391983
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.test_data import test_data_dir
    input_ = str(test_data_dir / 'simple')
    output = str(test_data_dir / 'output')
    result = compile_files(input_, output, CompilationTarget.CENTRAL)
    assert result.count == 3
    assert sorted(result.dependencies) == [
        'pysnmp>=4.4.9',
        'pysnmp.hlapi>=4.2.5',
        'pysnmp.smi>=0.3.4',
        'typing',
    ]
    assert (Path(output) / 'a.py').is_file()
    assert (Path(output) / 'b.py').is_file()

# Generated at 2022-06-23 22:11:44.749698
# Unit test for function compile_files
def test_compile_files():
    test_input = '/home/test/test_input'
    test_output = '/home/test/test_output'
    test_root = '/home/test'
    test_target = 'pyjs'
    
    assert compile_files(test_input, test_output, test_target, test_root)

# Generated at 2022-06-23 22:11:55.229014
# Unit test for function compile_files
def test_compile_files():
    input_ = Path('tests', 'examples')
    output = Path('tests', 'examples', 'output')
    root = Path('tests')

    def _get_result(target: CompilationTarget, count: int, time: int,
                    dependencies: List[str]) -> CompilationResult:
        return CompilationResult(count, time, target, dependencies)

    assert compile_files(input_, output, CompilationTarget.JAVASCRIPT) == _get_result(CompilationTarget.JAVASCRIPT, 1, 0, [
        'datetime', 'math', 'random'])
    assert compile_files(input_, output, CompilationTarget.JAVA) == _get_result(CompilationTarget.JAVA, 1, 0, [
        'datetime'])

# Generated at 2022-06-23 22:12:02.849940
# Unit test for function compile_files
def test_compile_files():

    import os
    import shutil
    import tempfile

    from .exceptions import CompilationError

    from .utils.helpers import assert_equal

    def assert_compiled_files(input_: str, output: str, target: CompilationTarget,
                              count: int, dependencies: int):
        result = compile_files(input_, output, target)
        assert_equal(result.count, count)
        assert_equal(result.target, target)
        assert_equal(len(result.dependencies), dependencies)


# Generated at 2022-06-23 22:12:14.044794
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    target = CompilationTarget.HUB

    test_dir = os.path.dirname(os.path.abspath(__file__))
    source_dir = test_dir + '/fixtures/compilation/source'
    dest_dir = tempfile.mkdtemp()

    result = compile_files(source_dir, dest_dir, target)
    assert(result.count == 2)
    assert(result.target == target)

    files = sorted(os.listdir(dest_dir))

# Generated at 2022-06-23 22:12:17.167262
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('../tests/source/valid',
                           '../tests/build/valid',
                           CompilationTarget.PYTHON_3)
    assert result.target == CompilationTarget.PYTHON_3

# Generated at 2022-06-23 22:12:25.224798
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/invalid', 'tmp', CompilationTarget.PROTECTED)
    assert compile_files('tests/data/invalid', 'tmp', CompilationTarget.UNPROTECTED)


if __name__ == '__main__':
    import sys
    if len(sys.argv) < 4:
        print('usage: python -m mcscript.compilation <input> <output> <target> [<root>]')
        sys.exit(1)
    compile_files(*sys.argv[1:])

# Generated at 2022-06-23 22:12:29.963843
# Unit test for function compile_files
def test_compile_files():
    print(compile_files('/Users/Henry/Documents/School/CS1/CS1_projects/redone-repo/redone/examples',
                        '/Users/Henry/Documents/School/CS1/CS1_projects/redone-repo/redone/examples_out',
                        CompilationTarget.CPYTHON))

# Generated at 2022-06-23 22:12:36.441390
# Unit test for function compile_files
def test_compile_files():
    paths = list(get_input_output_paths('test/data/project/src',
                                        'test/data/project/out'))
    assert len(paths) == 3
    paths[0].input.exists()
    files = compile_files('test/data/project/src',
                          'test/data/project/out',
                          CompilationTarget.PY2)
    assert files.count == 3
    assert files.dependencies == []

# Generated at 2022-06-23 22:12:47.293447
# Unit test for function compile_files
def test_compile_files():
    from .files import create_files
    from .exceptions import CompilationError

    with create_files() as paths:
        assert compile_files(paths.source.as_posix(),
                             paths.dest.as_posix(),
                             CompilationTarget.BINARY) == CompilationResult(2, 0.0, CompilationTarget.BINARY, [])
        with paths.source.joinpath('a.py').open() as f:
            assert f.read() == 'import b.py\nprint("Hello world!")'
        with paths.dest.joinpath('a.py').open() as f:
            assert f.read() == 'import b.py\nprint("Hello world!")'

# Generated at 2022-06-23 22:12:52.711452
# Unit test for function compile_files
def test_compile_files():
    # 1. Initialize input
    input_ = input_ = '../input/'
    # 2. Initialize output
    output = '../output/'
    # 3. Initialize root
    root = None
    # 4. Initialize target
    target = 'ES5'
    # 5. Test compile_files
    compile_files(input_, output, target, root)


if __name__ == '__main__':
    compile_files('../input/', '../output/', 'ES5')

# Generated at 2022-06-23 22:13:03.280971
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files"""
    import pytest
    import shutil
    from pathlib import Path
    import tempfile
    import subprocess
    import os
    import sys
    from subprocess import CalledProcessError
    try:
        from config import TARGET_PYTHON_VERSION
    except ImportError:
        TARGET_PYTHON_VERSION = sys.version_info.major

    def _test_file(test_file: str,
                   target: CompilationTarget,
                   expected_file: str,
                   expected_stdout: str,
                   expected_stderr: str,
                   return_code: int = 0,
                   use_transformed_file: bool = False) -> None:
        """Test file with given target."""
        with tempfile.TemporaryDirectory() as tmpdir:
            temp

# Generated at 2022-06-23 22:13:11.314167
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import shutil
    import tempfile
    import unittest

    d =  Path(tempfile.mkdtemp())
    for f in ('foo1.py', 'bar.py', 'src/foo.py', 'src/bar.py'):
        Path(d / f).write_text('def foo():\n    pass\n')
    output = compile_files(d / '*.py', d / 'out', CompilationTarget.PYTHON)
    assert output.files == 2

    output = compile_files(d / 'src', d / 'out', CompilationTarget.PYTHON, d)
    assert output.files == 2
    shutil.rmtree(d)

# Generated at 2022-06-23 22:13:21.295789
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget, CompilationResult
    from .exceptions import CompilationError, TransformationError
    import pytest
    import sys
    import datetime
    import json
    import os
    import tempfile
    try:
        import cStringIO as StringIO
    except ImportError:
        import StringIO

    # Initialize
    with tempfile.TemporaryDirectory() as tmpdir:
        src = os.path.join(tmpdir, 'src')
        os.mkdir(src)
        dst = os.path.join(tmpdir, 'dst')
        os.mkdir(dst)
        os.chdir(tmpdir)

        # Try to compile
        fake = os.path.join(tmpdir, '__fake__')

# Generated at 2022-06-23 22:13:23.330822
# Unit test for function compile_files
def test_compile_files():
    compile_files(
        'tests/valid', 'tests/valid/output', CompilationTarget.COMMON_JS)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:13:29.805849
# Unit test for function compile_files
def test_compile_files():
    input_ = '../tests/compiler/data/basic/input'
    output = '../tests/compiler/data/basic/output.py'
    root = '../tests/compiler/data'
    target = CompilationTarget.PYTHON
    dependencies = set()
    start = time()
    count = 0
    for paths in get_input_output_paths(input_, output, root):
        count += 1
        dependencies.update(_compile_file(paths, target))
    assert count == 7


# Generated at 2022-06-23 22:13:34.574219
# Unit test for function compile_files
def test_compile_files():
    import shutil, os
    input_ = 'tests/data/sample_input'
    output = 'tests/data/sample_output'
    target = CompilationTarget.PYTHON35
    try:
        shutil.rmtree(output)
    except FileNotFoundError:
        pass
    assert not os.path.exists(output)
    compile_files(input_, output, target)
    assert os.path.exists(output)


# Generated at 2022-06-23 22:13:41.271411
# Unit test for function compile_files
def test_compile_files():
    target = 'py2js'
    input_ = 'tests/input'
    output = 'build/output'
    result = compile_files(input_, output, target)
    assert result.target == target
    assert result.num_files == 2
    assert sorted(result.dependencies) == [
        "ast",
        "astor",
        "astunparse",
        "codetransformer",
        "typed_ast",
        "typing"
    ]

# Generated at 2022-06-23 22:13:45.180763
# Unit test for function compile_files
def test_compile_files():
    try:
        assert compile_files('./test_files', './test_files/output', CompilationTarget.HOST)
    except AssertionError:
        pass
    except Exception as e:
        assert False


# Generated at 2022-06-23 22:13:53.858027
# Unit test for function compile_files
def test_compile_files():
    import os.path as p
    from .files import InputOutput

    class Counter:
        def __init__(self):
            self.count = 0

        def __call__(self, *args, **kwargs):
            self.count += 1

    compile_file_mock = Counter()

    def compile_files_mock(paths: InputOutput, target: CompilationTarget
                           ) -> CompilationResult:
        compile_file_mock(paths)
        return CompilationResult(1, 1, target, [])

    globals()['_compile_file'] = compile_files_mock


    # Single file
    result = compile_files(p.join('input', '1.py'),
                           p.join('output', '1.py'),
                           CompilationTarget.UNIT_TESTS)

# Generated at 2022-06-23 22:14:05.160239
# Unit test for function compile_files
def test_compile_files():
    import os
    import glob
    from .compiler import compile_files
    from .types import CompilationTarget
    from .compilation_result import CompilationResult
    from .utils.helpers import delete_dir

    path = os.path.dirname(__file__)
    input_ = os.path.join(path, 'tests', 'test_data', 'compiler')
    output = os.path.join(input_, 'output')
    target = CompilationTarget.BROWSER
    delete_dir(output)

    res = compile_files(input_, output, target)

    assert res.target == target
    assert res.count == 3
    assert res.time >= 0.0
    assert len(res.dependencies) == 3

# Generated at 2022-06-23 22:14:15.602043
# Unit test for function compile_files
def test_compile_files():
    input_: str = 'tests/compiler/test_data/test.py'
    output: str = 'tests/compiler/test_data/output'
    target: CompilationTarget = CompilationTarget.PY3_PYPY
    result: CompilationResult = compile_files(input_, output, target)
    assert result.files == 1
    assert result.dependencies == ['typing', 'astunparse']
    with open('tests/compiler/test_data/output/tests/compiler/test_data/test.py', 'r') as f:
        assert f.readlines() == ['def test():\n', "    print('hello, world')\n"]


# Generated at 2022-06-23 22:14:25.472987
# Unit test for function compile_files
def test_compile_files():
    from .transformers import AllowedImportTransformer, SyntaxTransformer, ClassMethodTransformer
    from .utils.test_suite import smart_code_gen

    import tempfile
    import shutil

    def _test_compile_files(include_syntax: bool = False, include_classes: bool = False):
        temp_dir = tempfile.mkdtemp()
        code = smart_code_gen(temp_dir)

        code_file_path = temp_dir + "/test.py"
        code_file = open(code_file_path,"w")
        code_file.write(code)
        code_file.close()

        runnable_code = compile_files(code_file_path, temp_dir, CompilationTarget.RUNNABLE)

# Generated at 2022-06-23 22:14:34.643990
# Unit test for function compile_files
def test_compile_files():
    from .files import find_files

    import pytest # type: ignore
    from os import path
    from shutil import rmtree

    from .types import CompilationTarget, CompilationResult

    from .transformers import transformers

    from .utils.helpers import debug, debug_enabled
    debug_enabled(True)

    import sys

    here = path.abspath(path.dirname(__file__))
    example = path.join(here, '../examples')
    examples_paths = lambda examples: [path.join(example, ex) for ex in examples]

    def _compare_result(result: CompilationResult,
                        target: CompilationTarget,
                        count: int,
                        dependencies: List[str] = None) -> None:
        assert result.target == target
        assert result.count == count

       