

# Generated at 2022-06-23 22:04:39.897754
# Unit test for function compile_files
def test_compile_files():
    """
    Runs unit test for function compile_files.
    """
    assert compile_files('test/test_input', 'test/test_output', CompilationTarget.JS) == CompilationResult(5, 0.2, CompilationTarget.JS, ['react', 'react-dom'])
    assert compile_files('test/test_input_empty', 'test/test_output_empty', CompilationTarget.JS) == CompilationResult(1, 0, CompilationTarget.JS, [])


# Generated at 2022-06-23 22:04:47.764517
# Unit test for function compile_files
def test_compile_files():
    from .utils.test import make_tree

    with make_tree({'input': {'a.py': 'print(1+2)',
                              'b.py': '2 ** 3',
                              'c.py': 'a = dict(b=4)\na["b"]'}}) as root:
        inp = root.joinpath('input')
        out = root.joinpath('output')

        compile_files(inp.as_posix(), out.as_posix(), CompilationTarget.js)

        assert out.is_dir()
        assert out.joinpath('a.js').read_text() == 'console.log(3);'
        assert out.joinpath('b.js').read_text() == 'console.log(8);'
        assert out.joinpath('c.js').read_text()

# Generated at 2022-06-23 22:04:57.327609
# Unit test for function compile_files
def test_compile_files():

    from .compilation_targets import JS
    from .exceptions import CompilationError

    result = compile_files('./tests', './__tests__', JS)
    assert result == CompilationResult(4, 0.0, JS, [])

    with pytest.raises(CompilationError):
        compile_files('./tests', './__tests__', JS, './__tests__/broken.py')

    with pytest.raises(CompilationError):
        compile_files('./tests', './__tests__', JS, './__tests__/bad_target.js')

    with pytest.raises(CompilationError):
        compile_files('./tests', './__tests__', JS, './__tests__/bad_names.py')


# Generated at 2022-06-23 22:05:09.111743
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os

    test_dir = os.path.dirname(__file__)
    root = tempfile.mkdtemp()

# Generated at 2022-06-23 22:05:11.409252
# Unit test for function compile_files
def test_compile_files():
    raise NotImplementedError


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:05:22.178997
# Unit test for function compile_files
def test_compile_files():

    # Compiling a single file
    import tempfile
    import os
    import shutil

    dummy_input = tempfile.mkdtemp("/tmp")
    dummy_output = tempfile.mkdtemp("/tmp")

    # file name and content
    test_file = 'test.py'
    text = "def f(x): return x + 1"

    # place dummy file in input folder
    test_file = os.path.join(dummy_input, test_file)
    with open(test_file, 'w') as f:
        f.write(text)

    # compile file
    compile_files(dummy_input, dummy_output, CompilationTarget.PYTHON27)

    # check output
    # expect None since we do not know the output_path

# Generated at 2022-06-23 22:05:25.330462
# Unit test for function compile_files
def test_compile_files():
    d = {'input_': '.', 'output': 'build', 'target':  CompilationTarget.CPP, 'root': '.'}
    assert compile_files(**d).files == 0


# Generated at 2022-06-23 22:05:34.370711
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from tempfile import mkdtemp

    from .utils.dir import Tree

    from . import __path__ as PACKAGE_PATH

    TEST_DIR = Tree(mkdtemp())

    SAMPLE_DIR = TEST_DIR.add('sample')
    SAMPLE_DIR.add('__init__.py')
    SAMPLE_DIR.add('file.py', 'x = "test"').touch()

    OUTPUT_DIR = TEST_DIR.add('output')


# Generated at 2022-06-23 22:05:37.814449
# Unit test for function compile_files
def test_compile_files():
    test_script = os.path.join(os.path.dirname(__file__), "test.py")
    result = compile_files(test_script, "./output", CompilationTarget.JS)
    assert result.count == 1
    assert result.target == CompilationTarget.JS
    assert result.seconds > 0.0
    assert "brython" in result.dependencies
    assert "bootstrap-native" in result.dependencies

# Generated at 2022-06-23 22:05:40.532421
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./test/examples/compilable/',
                         './test/compiled',
                         CompilationTarget.PYTHON_2)

# Generated at 2022-06-23 22:05:50.244567
# Unit test for function compile_files
def test_compile_files():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    def compile_files_mock(input_: str, output: str, target: CompilationTarget,
                           root: Optional[str] = None):
        return CompilationResult(1, 1, target, ['dependency'])

    compile_files_original = compiler.compile_files
    compiler.compile_files = compile_files_mock

    from argparse import Namespace
    from .cli import cli

    fake_args = Namespace(input='./input_path', output='./output_path',
                          root='./root_path', targets=['strict'])
    res = cli(fake_args)

# Generated at 2022-06-23 22:05:55.717177
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from . import example_config
    import os
    import shutil
    import random

    SOURCE_ROOT = Path(os.getenv('SOURCE_ROOT', '.'))
    INPUT_PATH = os.path.join(SOURCE_ROOT.as_posix(), example_config.INPUT_PATH)
    OUTPUT_PATH = os.path.join(SOURCE_ROOT.as_posix(), example_config.OUTPUT_PATH)

    def clean_out():
        if os.path.exists(OUTPUT_PATH):
            shutil.rmtree(OUTPUT_PATH)

    print("Test compile_files...")
    clean_out()
    results = compile_files(INPUT_PATH, OUTPUT_PATH, CompilationTarget.py36)

# Generated at 2022-06-23 22:06:02.086017
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from shutil import rmtree

    with TemporaryDirectory() as temp:
        temp = Path(temp).resolve()
        input_ = temp / 'input'
        output = temp / 'output'
        input_.mkdir()
        (input_ / 'test.py').write_text('def foo():\n  print("Hello")')
        (input_ / 'test2.py').write_text('x= "test"')

        result = compile_files(input_, output, CompilationTarget.WASM)
        assert result.count == 2
        assert result.target == CompilationTarget.WASM
        assert result.time > 0

# Generated at 2022-06-23 22:06:12.421251
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import unittest

    sys.path.append(os.getcwd())
    from .utils.test_utils import TestCase
    from .utils.test_utils import AssertFileContains

    class Test_compile_files(TestCase):
        """Test class for compile_files"""
        test_compile_files_params = (
            ('input', 'output', 'target', 'root',),
            [
                ('input/', 'output/', 'default', None,),
            ]
        )
        @unittest.skip('Not implemented')
        def test_compile_files(self, input_, output, target, root):
            """Test method for compile_files"""
            pass
    return Test_compile_files


# Generated at 2022-06-23 22:06:17.912401
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import tempfile
    from .types import CompilationTarget
    from .__init__ import __version__

    with tempfile.TemporaryDirectory() as temp:
        input_ = Path(__file__).parent / 'examples/test.py'
        output = Path(temp) / 'test.py'

        result = compile_files(str(input_), str(output), CompilationTarget.ES5)

        assert result.count == 1
        assert result.target == CompilationTarget.ES5
        assert result.dependencies == [__version__]

        assert output.exists()
        with open(output.as_posix()) as f:
            assert f.read().strip() == 'var x = "foo";'

# Generated at 2022-06-23 22:06:22.688477
# Unit test for function compile_files
def test_compile_files():
    from .process import process
    import difflib
    import os
    import shutil
    import tempfile
    import pathlib
    import pytest

    base = os.sep.join([
        os.path.dirname(__file__),
        '__pycache__',
        'tests',
        'files',
        'compilation'
    ])

    @pytest.fixture(autouse=True)
    def cleanup(request):
        """Cleanup fixture to remove the tempdir."""
        tempdir = tempfile.mkdtemp('-typed_ast_compilation')
        origdir = os.getcwd()
        os.chdir(tempdir)

        def cleanup():
            os.chdir(origdir)

# Generated at 2022-06-23 22:06:27.281372
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    from .files import DEFAULT_INPUT, DEFAULT_OUTPUT, DEFAULT_ROOT, SAMPLES_PATH

    result = compile_files(DEFAULT_INPUT, DEFAULT_OUTPUT, CompilationTarget.JAVA)
    assert len(result.dependencies) == result.count
    assert result.target is CompilationTarget.JAVA

    result = compile_files(str(SAMPLES_PATH), DEFAULT_OUTPUT, CompilationTarget.JAVASCRIPT)
    assert len(result.dependencies) == result.count
    assert result.target is CompilationTarget.JAVASCRIPT

    result = compile_files(DEFAULT_INPUT, DEFAULT_OUTPUT, CompilationTarget.WEBASSEMBLY)

# Generated at 2022-06-23 22:06:36.943485
# Unit test for function compile_files
def test_compile_files():
    from .test_cases.test_cases import test_cases
    for tc in test_cases:
        # build sources
        result = compile_files(tc.src, tc.temp_build, CompilationTarget.PY)
        assert result.count > 0
        # check results
        result = compile_files(tc.src, tc.temp_build, CompilationTarget.PY)
        assert result.count == len(tc.py_src)
        # build tests
        result = compile_files(tc.tests, tc.temp_build, CompilationTarget.PY)
        assert result.count > 0
        # check results
        result = compile_files(tc.tests, tc.temp_build, CompilationTarget.PY)
        assert result.count == len(tc.py_tests)

# Generated at 2022-06-23 22:06:44.028115
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os

    # Create directory to hold test files
    directory = os.path.join(sys.prefix, 'test_compile_files')
    os.mkdir(directory)

    # Create test files
    file_1 = 'test_1.py'
    with open(os.path.join(directory, file_1), 'w') as f:
        f.write('print(1)')

    file_2 = 'test_2.py'
    with open(os.path.join(directory, file_2), 'w') as f:
        f.write('from math import sqrt\nprint(sqrt(9))')

    file_3 = 'test_3.py'

# Generated at 2022-06-23 22:06:49.560301
# Unit test for function compile_files
def test_compile_files():
    input_ = '../examples/example_numpy_project/tests/'
    output = '../examples/example_numpy_project/tests/'
    target = 1
    res = compile_files(input_, output, target, root=None)
    assert res.count_files == 2
    assert res.compilation_time > 0



# Generated at 2022-06-23 22:06:59.536267
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files"""
    from .utils.helpers import get_test_path, get_test_path_output
    from .utils.bootstrapping import bootstrap
    from .files import get_dependencies
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .config import Settings

    result = compile_files(get_test_path('helpers.py'),
                           get_test_path_output(),
                           CompilationTarget.PYTHON3)

    assert result.count == 1
    assert get_dependencies(get_test_path_output('helpers.py')) == []

    result = compile_files(get_test_path('circular.py'),
                           get_test_path_output(),
                           CompilationTarget.PYTHON3)



# Generated at 2022-06-23 22:07:08.663150
# Unit test for function compile_files
def test_compile_files():
    import unittest
    from tempfile import TemporaryDirectory
    class TestCompileFiles(unittest.TestCase):
        def test_compile_files(self):
            from .types import CompilationTarget
            from .utils.helpers import update_paths
            from .exceptions import CompilationError, TransformationError
            from .transformers import TargetGtE
            from .test_data import LIBRARY_JAR

# Generated at 2022-06-23 22:07:09.748267
# Unit test for function compile_files
def test_compile_files():
    # TODO: create unit tests
    assert True

# Generated at 2022-06-23 22:07:17.013939
# Unit test for function compile_files
def test_compile_files():
    import tempfile

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    with open(os.path.join(input_, 'test.py'), 'w') as f:
        f.write('a = 1')
    result = compile_files(input_, output, CompilationTarget.BROWSER)
    assert result.compiled_file_count == 1
    assert 'lib/browser' in result.dependencies
    assert os.path.isfile(os.path.join(output, 'test.js'))

# Generated at 2022-06-23 22:07:17.680945
# Unit test for function compile_files
def test_compile_files():
    # TODO: test
    pass

# Generated at 2022-06-23 22:07:26.944581
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from os import path
    from shutil import copytree
    from re import match

    HERE = path.abspath(path.dirname(__file__))
    INPUT = path.join(HERE, '..', '..', 'tests', 'input')

    assert compile_files(INPUT, '/tmp/does-not-exist/',
                         CompilationTarget.ES5).failed

    with TemporaryDirectory() as tmpdir:
        copytree(INPUT, path.join(tmpdir, 'input'))
        result = compile_files(path.join(tmpdir, 'input'),
                               path.join(tmpdir, 'output'),
                               CompilationTarget.ES5)

        assert result.count
        assert result.duration
        assert result.target == CompilationTarget.ES5
        assert result

# Generated at 2022-06-23 22:07:33.815341
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    import tempfile
    from unittest import TestCase
    from contextlib import contextmanager

    class CompileFilesTest(TestCase):
        command = 'python py2web.py'
        path = os.path.dirname(__file__)

        def setUp(self):
            self.cwd = os.getcwd()
            self.tempd = tempfile.mkdtemp()
            os.chdir(self.tempd)

        def tearDown(self):
            os.chdir(self.cwd)
            for path in (self.tempd,):
                try:
                    os.removedirs(path)
                except Exception:
                    pass


# Generated at 2022-06-23 22:07:41.542166
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationResult

    input_ = 'input'
    output = 'output'
    target = CompilationTarget.PYTHON
    root = 'root'
    result = compile_files(input_, output, target, root)

    assert type(result) is CompilationResult
    assert result.count == 0
    assert type(result.count) is int
    assert type(result.time) is float
    assert result.target == CompilationTarget.PYTHON
    assert type(result.target) is CompilationTarget
    assert type(result.dependencies) is list
    assert len(result.dependencies) == 0
    assert type(result.dependencies[0]) is str


# Entry point for CLI

# Generated at 2022-06-23 22:07:43.210221
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('a.txt', 'b.txt', CompilationTarget.X86_64) is not None


# Generated at 2022-06-23 22:07:53.565499
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    _ROOT = os.path.join(os.getcwd(), 'examples')

    class CompileFilesTest(unittest.TestCase):
        def test1(self):
            tmpdir = tempfile.mkdtemp()
            try:
                ret = compile_files(_ROOT, tmpdir, CompilationTarget.PY2)
                self.assertIsNotNone(ret)
                self.assertEqual(ret.count, 8)
                self.assertIsNotNone(ret.time)
                self.assertIsNotNone(ret.dependencies)
                self.assertEqual(ret.target, CompilationTarget.PY2)
            except Exception as e:
                self.fail(e)
            finally:
                shutil.r

# Generated at 2022-06-23 22:08:03.627120
# Unit test for function compile_files
def test_compile_files():
    files = ["main.py", "module1.py", "module2.py", "module3.py"]
    # Compile files with objc target
    compile_files("input", "output", CompilationTarget.objc)
    for f in files:
        f = Path("output") / f
        assert f.exists()
    compile_files("input", "output", CompilationTarget.objc)
    for f in files:
        f = Path("output") / f
        assert f.exists()
    # clean outupt folder
    for f in files:
        f = Path("output") / f
        f.unlink()
    # Compile files with swift target
    compile_files("input", "output", CompilationTarget.swift)
    for f in files:
        f = Path("output") / f
       

# Generated at 2022-06-23 22:08:13.864847
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from textwrap import dedent
    import json
    import sys

    import pytest

    root = Path(__file__).parent.parent
    assert compile_files(
        root / 'tests' / 'data' / 'simple' / 'simple',
        root / 'tests' / 'data' / 'simple' / 'compiled',
        CompilationTarget(sys.version_info.major, sys.version_info.minor)) == \
        CompilationResult(
            count=4,
            time=pytest.approx(0, abs=0.05),
            target=CompilationTarget(sys.version_info.major, sys.version_info.minor),
            dependencies=[]
        )


# Generated at 2022-06-23 22:08:22.585330
# Unit test for function compile_files
def test_compile_files():
    compile_files("../source-code/", "../python-compiled/", CompilationTarget.PYTHON)
    compile_files("../source-code/", "../python-compiled/", CompilationTarget.PYTHON)
    compile_files("../source-code/", "../javascript-compiled/", CompilationTarget.JAVASCRIPT)
    compile_files("../source-code/", "../javascript-compiled/", CompilationTarget.JAVASCRIPT)
    compile_files("../source-code/", "../java-compiled/", CompilationTarget.JAVA)
    compile_files("../source-code/", "../java-compiled/", CompilationTarget.JAVA)
    
    
if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-23 22:08:32.447319
# Unit test for function compile_files
def test_compile_files():
    import astunparse
    # Writing the test file
    f = open('a.py', 'w')
    f.write('from b import c\nimport d\nprint(d.e)\nd.f(c.g)\n\n')
    f.close
    # Writing the dependencies
    f = open('d.py', 'w')
    f.write('e=1\ndef f(f):\n    print(f+e)\n\n')
    f.close
    f = open('b.py', 'w')
    f.write('from c import g\n\n')
    f.close
    f = open('c.py', 'w')
    f.write('g=6\n\n')
    f.close
    # The expected output of the test

# Generated at 2022-06-23 22:08:38.369264
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/resources/src'
    output = 'tests/resources/target'
    compile_files(input_, output, CompilationTarget.ES5)
    try:
        compile_files(input_, output, CompilationTarget.ES6)
        raise AssertionError('Should not be possible to compile from '
                             'ES6 to ES5')
    except CompilationError:
        pass

# Generated at 2022-06-23 22:08:50.104902
# Unit test for function compile_files
def test_compile_files():
    import json
    from io import BytesIO

    from .config import get_config
    from . import files as _files

    source = BytesIO(b"""
        def f():
            print(1 + 2)
    """)

    def export(_):
        return True

    config = get_config(_files.get_project_root(), export, export)
    target = config.compile.default_target

    input_file = 'test_input.py'
    output_file = 'test_output.py'
    with open(input_file, 'wb') as f:
        f.write(source.read())

    result = compile_files(input_file, output_file, target)

    print(json.dumps(result._asdict(), indent=4))
    assert result.target == CompilationTarget.python_2

# Generated at 2022-06-23 22:09:00.440791
# Unit test for function compile_files
def test_compile_files():
    # pylint: disable=C0103,W0612
    import shutil
    import sys
    import tempfile
    import unittest

    from .types import CompilationTarget

    try:
        from . import transformers as ts
        from .utils import helpers

    except ModuleNotFoundError:
        sys.path.append('..')
        from . import transformers as ts
        from .utils import helpers

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.input_ = tempfile.mkdtemp()
            self.output = tempfile.mkdtemp()

        def create_test_file(self, name: str, content: str) -> str:
            path = helpers.get_path(self.input_, name)

# Generated at 2022-06-23 22:09:08.508158
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import os

    input_ = Path('test/test_files')
    output = Path('test/test_files_output')
    try:
        os.remove(output.as_posix())
    except: pass
    result = compile_files(input_, output, CompilationTarget.PYTHON_DECODER)
    assert result.source_files == 2
    assert result.target == CompilationTarget.PYTHON_DECODER
    assert len(result.dependencies) == 0
    assert result.duration > 0



# Generated at 2022-06-23 22:09:11.598005
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import tempfile

    with tempfile.TemporaryDirectory(prefix='test_') as input_:
        with tempfile.TemporaryDirectory(prefix='test_') as output:
            compile_files(input_, output, CompilationTarget.PYTHON_3_5)

# Generated at 2022-06-23 22:09:20.422610
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/input', 'test_output', CompilationTarget.ES5)
    assert compile_files('tests/input', 'test_output', CompilationTarget.ES2015)
    assert compile_files('tests/input', 'test_output', CompilationTarget.ES2016)
    assert compile_files('tests/input', 'test_output', CompilationTarget.ES2017)
    
    try:
        compile_files('tests/input', 'test_output', CompilationTarget.ES5)
    except CompilationError as e:
        assert e.path == 'tests/input/exception.py'
        assert e.code
        assert e.lineno == 3
        assert e.offset == 1
    except:
        assert False


# Generated at 2022-06-23 22:09:24.218679
# Unit test for function compile_files
def test_compile_files():
    # Test case
    result = compile_files("../tests/resources/features", "../tests/resources/features_generated",
                           CompilationTarget.RUNTIME, None)
    assert result.count == 3
    assert result.target == CompilationTarget.RUNTIME
    assert len(result.dependencies) == 10


# Generated at 2022-06-23 22:09:24.728101
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:09:31.357593
# Unit test for function compile_files
def test_compile_files():
    from .files import get_paths
    from .tests.test_files import test_get_paths
    test_get_paths()
    paths = get_paths()

    result = compile_files(paths.input.as_posix(), paths.output.as_posix(), 1)
    assert result.count == 2

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:39.988935
# Unit test for function compile_files
def test_compile_files():
    from . import __main__
    import sys

    def run_compile_files(input_: str, output: str, target: CompilationTarget):
        class Args:
            def __init__(self, input_: str, output: str, target: CompilationTarget):
                self.input_ = input_
                self.output = output
                self.target = target

        __main__.compile_files(Args(input_, output, target), [])

    try:
        __main__.compile_files(None, [])
    except TypeError as e:
        print(e)

    run_compile_files(sys.path[-1] + '/*.py', './output', CompilationTarget.PYTHON)

# Generated at 2022-06-23 22:09:46.951203
# Unit test for function compile_files
def test_compile_files():
    import os
    input_ = os.path.abspath(os.path.join('..', '..', 'tests', 'resources', 'test.py'))
    output = os.path.abspath(os.path.join('..', '..', 'tests', 'resources', 'test_output.py'))
    target = CompilationTarget.PYTHON3
    compile_files(input_, output, target)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:48.480723
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    # TODO: Implement me!
    return None



# Generated at 2022-06-23 22:09:54.630005
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('../examples/', '../out/',
                           CompilationTarget.EXECUTE)
    assert result.count == 1, result  # number of files
    assert result.time < 0.5, result  # compilation time in seconds
    assert result.target == CompilationTarget.EXECUTE, result  # target
    assert result.dependencies == [], result  # list of additional dependencies



# Generated at 2022-06-23 22:10:01.302586
# Unit test for function compile_files
def test_compile_files():
    # run compile_files function on a test file
    # and check that the compiled output matches the expected output
    import filecmp

    from .utils.paths import test_file

    test_input_file_path = test_file('test_1.py')
    test_output_file_path = test_file('test_out_1.py')
    compile_files(test_input_file_path, test_output_file_path, CompilationTarget.PYTHON2)

    expected_output_file_path = test_file('expected_test_out_1.py')
    assert filecmp.cmp(test_output_file_path, expected_output_file_path)

# Generated at 2022-06-23 22:10:06.622529
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    input_dir = tempfile.TemporaryDirectory()
    output_dir = tempfile.TemporaryDirectory()
    input_path = os.path.join(input_dir.name, 'test_file.py')
    expected_output_path = os.path.join(output_dir.name, 'test_file.py')
    with open(input_path, 'w') as f:
        f.write('''import sys
print(sys.argv)''')
    compile_files(input_path, output_dir.name, CompilationTarget.PYTHON)
    with open(expected_output_path, 'r') as f:
        result = f.read()
        assert result == '''import os
import sys
print(sys.argv)'''

# Generated at 2022-06-23 22:10:12.145228
# Unit test for function compile_files
def test_compile_files():
    input_ = pathlib.Path('tests/data/input')
    output = pathlib.Path('tests/data/output')
    target = CompilationTarget.SERVER
    compile_files(input_, output, target)
    assert set(output.glob('**/*.py')) == {output.joinpath('ga.py'), output.joinpath('server.py'), output.joinpath('lib/site-packages/ga.py'), output.joinpath('lib/site-packages/server.py')}

# Generated at 2022-06-23 22:10:15.582813
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    compile_files("test/", "test_output/", "STATIC", None)
    compile_files("test/", "test_output/", "DYNAMIC", None)

# Generated at 2022-06-23 22:10:16.671535
# Unit test for function compile_files
def test_compile_files():
    print('TODO')

# Generated at 2022-06-23 22:10:22.675208
# Unit test for function compile_files
def test_compile_files():
    c = compile_files('./tests/data1', './tests/compiled1', CompilationTarget.ES6)
    assert(c.dependencies == [])
    assert(c.duration < 1)
    assert(c.target == CompilationTarget.ES6)
    assert(c.count > 0)
    assert(c.count == len(list(get_input_output_paths('./tests/data1', './tests/compiled1'))))

# Generated at 2022-06-23 22:10:33.158120
# Unit test for function compile_files
def test_compile_files():
    from cStringIO import StringIO
    from contextlib import redirect_stdout

    args = {
        'output': 'tests/output',
        'target': CompilationTarget.PYTHON2,
        'root': 'tests/input'
    }

    f = StringIO()
    with redirect_stdout(f):
        compile_files('tests/input/sample.py', **args)

    assert f.getvalue() == ''

    f = StringIO()
    with redirect_stdout(f):
        compile_files('tests/input/sample_error.py', **args)

    assert f.getvalue().startswith('CompilationError: ')

    f = StringIO()
    with redirect_stdout(f):
        compile_files('tests/input/sample_syntax.py', **args)


# Generated at 2022-06-23 22:10:41.885240
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/data/input', 'tests/output', CompilationTarget.Python3)

    with open('tests/output/test.py', 'r') as f:
        assert f.read() == (
            'import os\n'
            '\n'
            '\n'
            'def hello(a: int, b: float, c: float = 1.0, d: float = None) -> int: ...\n'
            '\n'
            '\n'
            'def world(): ...\n'
            '\n'
            '\n'
            'def main(): ...')



# Generated at 2022-06-23 22:10:52.355968
# Unit test for function compile_files
def test_compile_files():
    input_ = './tests/data/'
    output = './tmp/test_compile_files/'
    import shutil
    shutil.rmtree('./tmp/test_compile_files')

    result = compile_files(input_, output, CompilationTarget.TEST)
    assert result.count == 17
    assert result.dependencies == []
    assert result.seconds > 0

    result = compile_files(input_, output, CompilationTarget.INTERSECTION)
    assert result.count == 17
    assert result.dependencies == []
    assert result.seconds > 0

    result = compile_files(input_, output, CompilationTarget.UNION)
    assert result.count == 17
    assert result.dependencies == []
    assert result.seconds > 0

# Generated at 2022-06-23 22:10:55.588455
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('', '', CompilationTarget.ES5)
    assert result.compiled_file_count == 0
    assert result.compile_time == 0
    assert result.target == CompilationTarget.ES5
    assert result.dependencies == []

# Generated at 2022-06-23 22:11:02.148563
# Unit test for function compile_files
def test_compile_files():
    from .tests.tests import get_fixtures_path
    from .exceptions import CompilationError, TransformationError
    import pytest
    from .utils.helpers import debug

    debug(True)
    temp_path = get_fixtures_path('compiler.tmp')
    input_ = get_fixtures_path('compiler.in')

    with pytest.raises(CompilationError) as e:
        compile_files(get_fixtures_path(
            'compiler.in.broken'), temp_path, CompilationTarget.PYTHON)

    assert e.value.path == get_fixtures_path('compiler.in.broken/broken_syntax.py')
    assert e.value.expected_lineno == 2
    assert e.value.expected_offset == 2


# Generated at 2022-06-23 22:11:03.311769
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/data/simple', 'build', CompilationTarget.PY2)



# Generated at 2022-06-23 22:11:08.273829
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test/data/compiler'
    output = 'test/data/output'
    target = CompilationTarget.PYTHON
    root = 'test/data'

    result = compile_files(input_, output, target, root)
    assert result.files_count == 1
    assert result.target == target
    assert result.dependencies == ['astunparse']

# Generated at 2022-06-23 22:11:10.109522
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('input/', 'output/', CompilationTarget.PYTHON_TO_PYTHON)


# Generated at 2022-06-23 22:11:18.396939
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    # Create files to be compiled
    input_ = tempfile.mkdtemp()
    output = input_ + '_output'
    os.mkdir(output)
    with open(os.path.join(input_, '__init__.py'), 'w'):
        pass
    for i in range(4):
        path = os.path.join(input_, 'abc{}.py'.format(i))
        with open(path, 'w') as f:
            f.write('def f({}):\n'.format(i))
            f.write('    return {}\n'.format(int(i == 1)))

    # Compile files
    compile_files(input_, output, CompilationTarget.DEBUG)

    # Check if files were compiled
    assert os

# Generated at 2022-06-23 22:11:29.673711
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    def get_file_contents(file):
        with open(file) as f:
            return f.read()
    tempdir = tempfile.mkdtemp()
    input_ = os.path.join(tempdir, 'input')
    output = os.path.join(tempdir, 'output')
    target = CompilationTarget.LINKY
    os.mkdir(input_)
    os.mkdir(output)

    # test basic compilation
    os.mkdir(os.path.join(input_, 'foo'))
    os.mkdir(os.path.join(input_, 'bar'))
    os.mkdir(os.path.join(input_, 'baz'))

# Generated at 2022-06-23 22:11:38.093544
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    target = CompilationTarget.DEBUG
    with tempfile.TemporaryDirectory() as rt:
        tmp_rt = Path(rt)
        tmp_input = tmp_rt.joinpath('input')
        tmp_input.mkdir(parents=True)
        tmp_output = tmp_rt.joinpath('output')
        tmp_output.mkdir(parents=True)
        tmp_input.joinpath('main.py').write_text('import numpy as np')
        tmp_input.joinpath('subfolder', 'sub.py').write_text('import numpy as np')
        result = compile_files(tmp_input.as_posix(),
                               tmp_output.as_posix(),
                               target,
                               root=tmp_rt.as_posix())

# Generated at 2022-06-23 22:11:41.211526
# Unit test for function compile_files
def test_compile_files():
    import os
    os.chdir("../test")
    compile_files('examples', 'out', 'debug')
    os.chdir("../")
    print("Done")


# Generated at 2022-06-23 22:11:41.935248
# Unit test for function compile_files
def test_compile_files():
    assert False

# Generated at 2022-06-23 22:11:52.355990
# Unit test for function compile_files
def test_compile_files():
    from .files import PathMock
    from .transformers import test_transform

    def mock_transform(*args):
        return test_transform(*args)

    transformers.transformers.append(mock_transform)

    class Counter:
        def __init__(self):
            self.count = 0

        def __call__(self, *args, **kwargs):
            self.count += 1
            return ''

    mock_read = Counter()
    mock_write = Counter()
    mock_mkdir = Counter()

# Generated at 2022-06-23 22:12:01.388362
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    def _summarize(results):
        out = []
        for result in results:
            out.append('{} -> {}'.format(result.input, result.output))
        return sorted(out)

    def _create_file(path, content):
        with open(path, 'w', encoding='utf8') as f:
            f.write(content)

    def _assert_have_code(content: str, expected: str, target: CompilationTarget):
        with tempfile.TemporaryDirectory() as tmpdir:
            input_ = os.path.join(tmpdir, 'input')
            output = os.path.join(tmpdir, 'output')
            os.mkdir(input_)

# Generated at 2022-06-23 22:12:08.818727
# Unit test for function compile_files
def test_compile_files():
    input_ = Path("input_").as_posix()
    output = "output"
    if not os.path.exists("output"):
        os.makedirs("output")
    if not os.path.exists("output/tmp"):
        os.makedirs("output/tmp")
    target = CompilationTarget.JAVASCRIPT
    root = "root_path"
    compile_result = compile_files(input_, output, target, root)
    assert compile_result.count == 1
    assert compile_result.dependencies == ["java.lang.String"]

# Generated at 2022-06-23 22:12:18.078804
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .exceptions import Dummy
    from .utils.helpers import get_root
    from .utils.mock_utils import copytree

    copytree(get_root() / 'tests' / 'data', get_root() / 'build' / 'compile_test')

    try:
        result = compile_files(get_root() / 'build' / 'compile_test' / 'input',
                               get_root() / 'build' / 'compile_test' / 'output',
                               CompilationTarget.EXEC)

        assert result.count == 3
    except Dummy:  # Needed due to raise inside lambda
        pass
    finally:
        (get_root() / 'build' / 'compile_test').rmtree()

# Generated at 2022-06-23 22:12:28.497279
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files("foo", "bar", CompilationTarget.PYTHON)
        raise RuntimeError("expected CompilationError")
    except CompilationError as e:
        print("Exception caught: {}".format(e))

    from .compiler import compile_files
    compile_files("test/test_files", "test/test_output",
                  CompilationTarget.PYTHON)


if __name__ == '__main__':
    import sys
    try:
        result = compile_files(sys.argv[1], sys.argv[2],
                               CompilationTarget.PYTHON)
        print("Successfully compiled {} files in {:.2f}s.".format(
            result.files, result.time))
    except CompilationError as e:
        print("Compilation failed:")


# Generated at 2022-06-23 22:12:35.560787
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from ..test import test_dir

    def run_target(target: CompilationTarget) -> CompilationResult:
        input_ = test_dir / 'data' / 'test_compile_files' / target.name
        output = test_dir / 'data' / 'test_compile_files' / target.name
        return compile_files(input_, output, target,
                             test_dir / 'data' / 'test_compile_files')

    assert run_target(CompilationTarget.NODE_COMMONJS) == CompilationResult(
        2, 0.0, CompilationTarget.NODE_COMMONJS, [
            'fs', 'pathlib', 'sys'])

# Generated at 2022-06-23 22:12:46.249632
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import json
    import tempfile
    import re
    import subprocess
    testfile = 'hello.py'
    testcode = '#!/usr/bin/env python3\nprint("Hello World")'
    with tempfile.TemporaryDirectory() as inputdir,\
            tempfile.TemporaryDirectory() as outputdir,\
            tempfile.NamedTemporaryFile('w') as expected_file:
        with open(testfile, 'w') as file:
            file.write(testcode)
        # Get expected output path
        expected_file_path = Path(expected_file.name)
        expected_output_path = expected_file_path.parents[0]\
            .joinpath(expected_file_path.name + '.py').as_posix()
        expected_json_path = expected_

# Generated at 2022-06-23 22:12:48.802512
# Unit test for function compile_files
def test_compile_files():
	assert compile_files == compile_files
	assert compile_files != compile_files
	print('it works!')


# Generated at 2022-06-23 22:12:55.664696
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError
    from .utils import log
    import os

    def compare(original: str, expected: str) -> None:
        temp_input = 'test_input'
        temp_output = 'test_output'

        with open(temp_input, 'w') as f:
            f.write(original)
        result = compile_files(Path(temp_input), Path(temp_output),
                               CompilationTarget.PYTHON_TESTS)
        os.remove(temp_input)
        os.remove(temp_output)

        assert result.count == 1
        log.debug('Compiled in {:.3f} s'.format(result.time))
        assert result.target == CompilationTarget.PYTHON_TESTS
        assert result.depend

# Generated at 2022-06-23 22:13:04.715102
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    import re
    import io
    import os
    import pytest
    import tempfile
    from itertools import chain

    target = CompilationTarget.from_string("python2.7")
    input_file = 'tests/testdata/input.py'
    output_file = 'tests/testdata/output.py'
    comment = re.compile(' +#.*\n')

    with open(input_file, 'r') as f:
        input_ = comment.sub('\n', f.read())

    with open(output_file, 'r') as f:
        output = comment.sub('\n', f.read())

    directory = tempfile.mkdtemp()


# Generated at 2022-06-23 22:13:12.696229
# Unit test for function compile_files
def test_compile_files():
    from . import debug
    from time import time
    from uuid import uuid4
    from tempfile import mkdtemp
    from os import makedirs
    from os.path import join as pjoin
    from shutil import rmtree

    debug(True)

    def get_temp_dir(path: str = '.') -> str:
        return pjoin(path, str(uuid4()))

    def get_temp_file(directory: str = '.', content: str = '') -> str:
        path = pjoin(directory, str(uuid4()))
        makedirs(directory, exist_ok=True)
        with open(path, 'w') as f:
            f.write(content)
        return path


# Generated at 2022-06-23 22:13:13.252989
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:13:13.676503
# Unit test for function compile_files
def test_compile_files():
    assert False

# Generated at 2022-06-23 22:13:22.502256
# Unit test for function compile_files
def test_compile_files():
    import pytest
    assert compile_files('tests/fixtures/input', 'tests/fixtures/output',
                         CompilationTarget.C) == \
           CompilationResult(3, 0.0, CompilationTarget.C,
                             [])
    assert compile_files('tests/fixtures/input', 'tests/fixtures/output',
                         CompilationTarget.CSharp) == \
           CompilationResult(3, 0.0, CompilationTarget.CSharp,
                             ['Set', 'List', 'Array', 'Vector', 'Matrix'])
    with pytest.raises(CompilationError):
        compile_files('tests/fixtures/input_err', 'tests/fixtures/output',
                      CompilationTarget.CSharp)

# Generated at 2022-06-23 22:13:28.336816
# Unit test for function compile_files
def test_compile_files():
    """Test for function compile_files."""
    from .context import project_root
    from .examples.simple_types.simple_types_1 import print_
    from .examples.simple_types.simple_types_2 import print_

    input_ = project_root / 'tests/files/input'
    output = project_root / 'tests/files/output'

    result = compile_files(input_, output, CompilationTarget.DYNAMIC)
    assert result.count == 4
    assert result.target == CompilationTarget.DYNAMIC

    result = compile_files(input_, output, CompilationTarget.STATIC)
    assert result.count == 4
    assert result.target == CompilationTarget.STATIC

    print_()

# Generated at 2022-06-23 22:13:35.940916
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import os
    import shutil
    import unittest.mock
    from .files import InputOutput

    def compile_files_mock(io: InputOutput, target: CompilationTarget) -> str:
        with io.input.open() as input:
            with io.output.open('w') as output:
                output.write("mock")
        return io.input.as_posix()

    input_folder = "input"
    output_folder = "output"
    os.mkdir(input_folder)
    os.mkdir(output_folder)

    with open(f"{input_folder}/one.py", 'w') as f:
        f.write("a")

# Generated at 2022-06-23 22:13:44.055956
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers

    # Create temporary paths
    temp_dir = Path(tempfile.mkdtemp())
    input_dir = temp_dir / 'input'
    input_dir.mkdir()
    output_dir = temp_dir / 'output'

    # Copy all templates to temporary directory
    for transformer in transformers:
        for src in transformer.templates:
            dst = input_dir / ('{}.py'.format(transformer.__name__))
            shutil.copy(src, dst.as_posix())

    # Compile templates
    result = compile_files(input_dir.as_posix(), output_dir.as_posix(),
                           CompilationTarget.NATIVE)

    # Check number of processed files
    assert result.count

# Generated at 2022-06-23 22:13:46.247973
# Unit test for function compile_files
def test_compile_files():
    from .test import test_compile_files
    return test_compile_files(compile_files)

# Generated at 2022-06-23 22:13:54.321644
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    temp_dir = tempfile.gettempdir()


# Generated at 2022-06-23 22:14:05.351099
# Unit test for function compile_files
def test_compile_files():
    import os
    import json
    import sys

    print("Testing compile_files (You might need to install autopep8)")

    # Clear the loaded modules
    sys.modules.pop("test_compile_files", None)

    root = os.path.dirname(os.path.abspath(__file__))
    input_ = os.path.join(root, 'files/input')
    output = os.path.join(root, 'files/output')

    result = compile_files(input_, output, CompilationTarget.ALL)

    assert result.count == 4, f"result.count == 4\n{result.count}"

    result_file = os.path.join(output, 'result.json')
    with open(result_file) as f:
        result = json.load(f)

    assert result

# Generated at 2022-06-23 22:14:15.032085
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import shutil
    import tempfile

    def _compile(input_: str, output: str, target: CompilationTarget,
                 root: Optional[str] = None) -> None:
        compile_files(input_, output, target, root)

    with tempfile.TemporaryDirectory() as tmpdir:
        _compile(os.path.join(tmpdir, 'input'),
                 os.path.join(tmpdir, 'output'),
                 CompilationTarget.PYTHON_TO_PYTHON)

        _compile(os.path.join(tmpdir, 'input'),
                 os.path.join(tmpdir, 'output'),
                 CompilationTarget.PYTHON_TO_PYTHON, root=tmpdir)


# Generated at 2022-06-23 22:14:18.501224
# Unit test for function compile_files
def test_compile_files():
    paths = get_input_output_paths('./testdata/src', './testdata/temp/output', './testdata/temp/root')
    print(paths[0])
    pass

# Generated at 2022-06-23 22:14:27.695521
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    mock_dir = 'mock_dir'
    target = CompilationTarget.PY3
    count, t, target, dependencies = compile_files(mock_dir, mock_dir, target,
                                                   'utils/__init__.py')
    assert count == 3
    assert t > 0
    assert target == CompilationTarget.PY3
    assert dependencies == [
        'typing',
    ]
    assert os.path.exists(os.path.join(mock_dir, 'a.py'))
    assert os.path.exists(os.path.join(mock_dir, 'b.py'))
    assert os.path.exists(os.path.join(mock_dir, 'c.py'))


# Generated at 2022-06-23 22:14:36.460920
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .test.utils import get_test_resources_path, test_resources_path

    input_ = get_test_resources_path('compile_files', 'input')
    output = get_test_resources_path('compile_files', 'output')
    assert os.path.exists(output)
    shutil.rmtree(output)

    result = compile_files(input_, output, CompilationTarget.PY2)
    assert result.count == 2
    assert result.target == CompilationTarget.PY2
    assert not result.dependencies

    assert os.path.exists(os.path.join(output,
                                       'compile_files', 'input', 'dummy.py'))