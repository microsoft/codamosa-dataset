

# Generated at 2022-06-23 22:04:56.382453
# Unit test for function compile_files
def test_compile_files():
    from .examples.foo import foo
    from .examples.bar import bar
    from .examples.baz import baz

    compile_files(foo.input_, foo.output, foo.target)
    compile_files(bar.input_, bar.output, bar.target)
    compile_files(baz.input_, baz.output, baz.target)

# Generated at 2022-06-23 22:05:07.781153
# Unit test for function compile_files
def test_compile_files():
    input_ = Path(__file__).parent / 'test_files' / 'old'
    output = Path(__file__).parent / 'test_files' / 'new'
    target = CompilationTarget.PYTHON_3_5
    result = compile_files(input_, output, target)
    assert result.count == 3
    assert result.runtime > 0
    assert result.target == target
    assert result.dependencies == ['typed-ast', 'typing']

if __name__ == '__main__':
    input_ = Path(__file__).parent / 'test_files' / 'old'
    output = Path(__file__).parent / 'test_files' / 'new'
    result = compile_files(input_, output, CompilationTarget.PYTHON_3_5)

# Generated at 2022-06-23 22:05:15.098982
# Unit test for function compile_files
def test_compile_files():
    from .tests.compile.fixtures import compile_files as fixture

    for f in fixture:
        result = compile_files(f.input_, f.output, f.target, f.root)
        try:
            assert f.result == result
        except AssertionError:
            raise AssertionError('Expected: {r.count} of {r.target}\n'
                                 'Got:      {result.count} of {result.target}'
                                 .format(r=f.result, result=result))

# Generated at 2022-06-23 22:05:22.399936
# Unit test for function compile_files
def test_compile_files():
    # Import only for testing purposes
    import textwrap
    from pprint import pformat
    from .utils.helpers import resolve_path
    from .utils.test_helpers import TempDir
    from .transformers import AutoImportTransformer

    output = resolve_path(TempDir(temp_dir='tests/temp/compile_files'), 'output')
    target = CompilationTarget.python
    code = textwrap.dedent('''
        import datetime
        if True:
            print(datetime.datetime.now())
        ''')

    def run(target_: CompilationTarget, expected_dependencies: Optional[List[str]] = None) -> CompilationResult:
        input_ = resolve_path(TempDir(temp_dir='tests/temp/compile_files'), 'input')

# Generated at 2022-06-23 22:05:23.475494
# Unit test for function compile_files
def test_compile_files():
    # TODO: Add more tests
    pass

# Generated at 2022-06-23 22:05:27.624463
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from os import listdir

    with TemporaryDirectory() as dir:
        compile_files('tests', str(Path(dir)), CompilationTarget.PYTHON)
        assert listdir(str(Path(dir))) == ['test_compile.py']



# Generated at 2022-06-23 22:05:39.677459
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as input_:
        with tempfile.TemporaryDirectory() as output:
            path1 = input_ + '/a.py'
            path2 = input_ + '/b.py'
            src1 = 'def f():\n  return 1'
            src2 = 'import a\ndef f():\n  return a.f()'

            with open(path1, 'w') as f:
                f.write(src1)

            with open(path2, 'w') as f:
                f.write(src2)

            res = compile_files(input_, output, CompilationTarget.PYTHON)

            with open(output + '/a.py') as f:
                dst1 = f.read()


# Generated at 2022-06-23 22:05:46.363454
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/test_files/', 'test/test_output/', CompilationTarget.BINARY).count == 3
    assert compile_files('test/test_files/', 'test/test_output/', CompilationTarget.BINARY).target == CompilationTarget.BINARY
    assert len(compile_files('test/test_files/', 'test/test_output/', CompilationTarget.BINARY).dependencies) == 2
    assert compile_files('test/test_files/', 'test/test_output/', CompilationTarget.BINARY).dependencies == ['test/test_files/test.c', 'test/test_files/test2.c']


# Generated at 2022-06-23 22:05:55.732398
# Unit test for function compile_files
def test_compile_files():
    import random
    import tempfile
    result = compile_files(tempfile.gettempdir(), 'output', CompilationTarget.ES5)
    assert result.count == 0

    cwd = os.getcwd()
    with tempfile.TemporaryDirectory() as tempdir:
        os.chdir(tempdir)
        for _ in range(random.randint(10, 20)):
            with open('test{}.py'.format(random.randint(0, 100)), 'w') as f:
                f.write('try:\n\tpass\nexcept:\n\tpass')
        result = compile_files('.', 'output', CompilationTarget.ES5)
        assert result.count == 10
        assert result.time > 0.0
        assert result.target == CompilationTarget.ES5

# Generated at 2022-06-23 22:06:03.080807
# Unit test for function compile_files
def test_compile_files():
    import unittest
    from io import StringIO
    from .files import get_output_file_path
    from .preprocessors import get_preprocessor_path, is_preprocessor_installed

    class CompileFilesTest(unittest.TestCase):
        def test_compile_files(self):
            start = 0
            with StringIO() as f:
                out = compile_files('inputs/compile_files.input.py',
                                    f, CompilationTarget.PYTHON_35)
                self.assertEqual(
                    'inputs/compile_files.input.py', out.dependencies[0])
                self.assertEqual(
                    'inputs/compile_files.input.py', out.dependencies[1])

# Generated at 2022-06-23 22:06:04.483329
# Unit test for function compile_files
def test_compile_files():
    from .test.test_compiler import run as test_run
    test_run()

# Generated at 2022-06-23 22:06:12.044315
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    assert compile_files(Path(__file__).parent / 'test', '../test_output', CompilationTarget.TEST) == CompilationResult(1, 0, CompilationTarget.TEST, [])
    assert compile_files(Path(__file__).parent / 'test', '../test_output', CompilationTarget.PROD) == CompilationResult(1, 0, CompilationTarget.PROD, ['numpy', 'scipy'])

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:06:22.528630
# Unit test for function compile_files
def test_compile_files():  # pylint: disable=unused-variable
    """Unit test for function compile_files"""

    import pytest
    import tempfile
    import psutil
    import shutil
    import os

    @pytest.fixture
    def src(request):
        'Create a copy of the current directory and cd to it'
        temp = tempfile.mkdtemp(prefix='tw_compiler_test_')
        copy = tempfile.mkdtemp(prefix='tw_compiler_test_')
        shutil.copytree(str(Path(__file__).parent.parent), copy)
        on_exit = request.node.rep_setup.callspec.params['on_exit'].args[0]
        on_exit.addfinalizer(lambda: shutil.rmtree(temp))

# Generated at 2022-06-23 22:06:33.867703
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    import io
    import os
    import pytest

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        tmpdir.joinpath('input/file1.py').write_text(
            'import os\n'
            'import not_std\n'
            'import stdlib.builtins\n'
            'print("Hello, world!")\n')

        tmpdir.joinpath('input/file2.py').write_text(
            'print("Hello, world!")\n')

        def read_file(path: Path):
            return path.read_text()


# Generated at 2022-06-23 22:06:41.253805
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import get_test_files
    from pytest import raises
    input_, output = get_test_files('input', 'output')
    result = compile_files(input_, output, CompilationTarget(0))
    # CompilationResult(count=1, time=0.002034902572631836,
    #   target=CompilationTarget(0), dependencies=[])
    assert result.count == 1
    assert result.time >= 0.002
    assert result.target == CompilationTarget(0)
    assert result.dependencies == []
    with raises(SyntaxError) as e:
        compile_files(input_, output, CompilationTarget(1))
        print(e)

# Generated at 2022-06-23 22:06:49.611277
# Unit test for function compile_files
def test_compile_files():
    from .test import test_input, test_output, test_root
    from .utils.helpers import make_test_code

    with open(test_input('test.py'), 'w') as f:
        f.write(make_test_code(1, 0, 0, 0, 0, 0, 0))

    compile_files(test_input(), test_output(), CompilationTarget.asyncio,
                  test_root())

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:06:59.536399
# Unit test for function compile_files
def test_compile_files():
    code = '''
x = 1
if x:
    print(f'x: {x}')
'''

    class InputFile:
        def __init__(self, name):
            self.name = name

        def open(self, *args, **kwargs):
            return io.BytesIO(code.encode())

    class OutputFile:
        def __init__(self, name):
            self.name = name

        def open(self, *args, **kwargs):
            pass

    class InputOutput:
        def __init__(self, input_, output):
            self.input = input_
            self.output = output


# Generated at 2022-06-23 22:07:02.132715
# Unit test for function compile_files
def test_compile_files():
    compile_files('tinypy-stubs/tinypy_stubs',
                  'tinypy-stubs/tinypy_stubs',
                  CompilationTarget.py2)

# Generated at 2022-06-23 22:07:03.700452
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/', 'tests/output/',
                         CompilationTarget.HASKELL).count > 0

# Generated at 2022-06-23 22:07:07.739610
# Unit test for function compile_files
def test_compile_files():
    test = compile_files('unit-tests/compiler/input', 'unit-tests/compiler/output', CompilationTarget.PYTHON_31)
    assert test.input_files == 2
    assert test.target == CompilationTarget.PYTHON_31
    assert test.dependencies == ['typed_ast']
    assert test.elapsed_time > 0


# Generated at 2022-06-23 22:07:19.264133
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile
    import os.path
    from sys import version_info
    from pathlib import Path
    from . import __file__ as package_root
    from .types import CompilationTarget

    input_ = os.path.join(os.path.dirname(package_root),
                          'tests', 'compile_files')
    with tempfile.TemporaryDirectory() as temp:
        output = os.path.join(temp, 'out')
        shutil.copytree(input_, output)

# Generated at 2022-06-23 22:07:28.192119
# Unit test for function compile_files
def test_compile_files():
    def _get_result(input_: str, output: str, target: CompilationTarget,
                    root: Optional[str] = None) -> CompilationResult:
        input_path = Path(input_)
        output_path = Path(output)
        input_path.mkdir(parents=True, exist_ok=True)
        output_path.mkdir(parents=True, exist_ok=True)
        with input_path.joinpath('a.js').open('w') as f:
            f.write('')
        return compile_files(input_path.as_posix(),
                             output_path.as_posix(),
                             target, root)

    result = _get_result('/tmp/input', '/tmp/output', 'typescript')
    assert result.file_count == 1
    assert result

# Generated at 2022-06-23 22:07:36.932814
# Unit test for function compile_files
def test_compile_files():
    # Test without root
    assert compile_files('./test/test_files/test1', './test/test_files/output', CompilationTarget.PYTHON3_6) == \
           CompilationResult(7, 18, CompilationTarget.PYTHON3_6, ['import numpy as np', 'import os',
                                                                   'import pandas as pd', 'import time'])
    # Test with root

# Generated at 2022-06-23 22:07:46.653467
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationTargetNotFound
    from .types import CompilationTarget, CompilationResult
    from .utils.mockio import mock_open

    with mock_open() as io:
        io.input.write('1 + 1\n')
        io.output.write('2\n')

        result = compile_files(io.input.name, io.output.name,
                               CompilationTarget.JAVA)

        assert result.count == 1
        assert result.target == CompilationTarget.JAVA
        assert result.source_files == []
        assert result.header_files == []
        assert result.compiled_files == [
            '{}.java'.format(result.input_file.stem)]


# Generated at 2022-06-23 22:07:49.070725
# Unit test for function compile_files
def test_compile_files():
    # Given
    input_ = '/test'
    output = '/test'
    target = CompilationTarget.PY27

    # When
    compile_files(input_, output, target)

    # Then
    assert True

# Generated at 2022-06-23 22:07:52.823922
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('src', 'gen/compiler', CompilationTarget.PYTHON_NONE) == CompilationResult(6, 0.003722667694091797, CompilationTarget.PYTHON_NONE, [])


# Generated at 2022-06-23 22:07:55.695937
# Unit test for function compile_files
def test_compile_files():
    """Compile files"""
    compile_files('py-transpiler/tests/data/input',
                  'py-transpiler/tests/data/output', CompilationTarget.PY)

# Generated at 2022-06-23 22:08:05.312225
# Unit test for function compile_files
def test_compile_files():
    # Local import to avoid cyclic dependency
    from .transformers import PythonicTransformer
    from .transformers.base import TransformerResult

    original = "def test(x):\n  print(x)\n  if x < 5: pass\n"
    target = "test = lambda x: (print(x), True) if x < 5 else None"

    def mock_transform_tree(tree: ast.Module) -> TransformerResult:
        assert not tree.body  # assert that tree is empty
        new_tree = ast.parse(target)
        return TransformerResult(True, [], new_tree)

    PythonicTransformer.transform = mock_transform_tree

    result = compile_files(input_='input', output='output',
                           target=CompilationTarget.Pythonic, root=None)

# Generated at 2022-06-23 22:08:14.564803
# Unit test for function compile_files
def test_compile_files():
    from .utils.srcpath import get_abs_path
    import unittest
    import subprocess
    import shutil
    import os
    import sys
    import tempfile
    import contextlib

    def get_pyprepro(name):
        return get_abs_path('tests/pyprepro/{}.pre'.format(name))

    def get_golden(name):
        return get_abs_path('tests/golden/{}.out'.format(name))

    def get_output(name):
        return get_abs_path('tests/output/{}'.format(name))

    @contextlib.contextmanager
    def temp_dir():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)

   

# Generated at 2022-06-23 22:08:22.731556
# Unit test for function compile_files
def test_compile_files():

    import shutil, types

    from pytype import analyze

    shutil.rmtree('build', ignore_errors=True)

    def test(input_, output):
        assert isinstance(input_, str)
        assert isinstance(output, str)

        shutil.rmtree('build', ignore_errors=True)
        analyze.compile_files(input_, output, CompilationTarget.VANILLA)
        analyze.compile_files(input_, output, CompilationTarget.PYTYPE)
        analyze.compile_files(input_, output, CompilationTarget.PYTYPE_OR_VANILLA)

    test('tests/files/simple', 'build')
    test('tests/files', 'build')
    test('tests/files', 'build/files')

# Generated at 2022-06-23 22:08:32.597185
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import tempfile
    import os
    import shutil

    class Test(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_compile(self):
            input_ = os.path.join(self.tempdir, 'input')
            os.mkdir(input_)
            output = os.path.join(self.tempdir, 'output')

            with open(os.path.join(input_, 'simple.py'), 'w') as f:
                f.write('import sys; print(sys.executable); sys.exit(1)')


# Generated at 2022-06-23 22:08:35.607211
# Unit test for function compile_files
def test_compile_files():
    compile_result = compile_files('tests/sample/', 'target', 'JS')
    assert compile_result.counter == 3
    assert compile_result.target == 'JS'
    assert compile_result.time > 0

# Generated at 2022-06-23 22:08:42.073234
# Unit test for function compile_files
def test_compile_files():
    from .compiler import PROPERTIES
    from .compiler import compile_files
    from .exceptions import CompilationError
    from pathlib import Path

    assert PROPERTIES

    input = Path('input')
    output = Path('output')
    target = CompilationTarget.ES5

    try:
        compile_files(str(input), str(output), target)
    except CompilationError as e:
        assert str(e.input) == 'input/compiler.py'
        assert e.code.startswith('def compile_files(')
        assert e.lineno == 0
        assert e.offset == 0


# Generated at 2022-06-23 22:08:53.053954
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    source = 'tests/data/example-package'
    target = 'tests/data/example-package.compiled'

    compile_files(source, target, CompilationTarget.py37, source)

    compiled_input_output = {str(i): str(o) for
                             (i, o) in get_input_output_paths(target, target, source)}

# Generated at 2022-06-23 22:08:57.184933
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("data/in", "data/out", CompilationTarget.WEB) == CompilationResult(4, 0.0029892921447753906, CompilationTarget.WEB, ['fetch', 'notification', 'navigator'])


# Generated at 2022-06-23 22:09:04.930261
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    import os
    import shutil
    from .transformers import transformers
    from .utils.helpers import read_file, write_file

    # Step 1: Compile file (with valid test.)
    with TemporaryDirectory() as tmpdirname:

        # Create temp file
        path = tmpdirname + os.sep + 'temp.py'
        write_file(path, '1')
        assert read_file(path) == '1'

        # Compile file
        compile_files(path, path, transformers[0].target)
        assert read_file(path) == '1'

    # Step 2: Compile file (with invalid test.)
    with TemporaryDirectory() as tmpdirname:

        # Create temp file
        path = tmpdirname + os.sep + 'temp.py'

# Generated at 2022-06-23 22:09:15.106178
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    from .utils.helpers import (
        list_dir_recursive,
        get_test_input_output_paths
    )

    def build(input_: str, output: str):
        compile_files(input_, output, CompilationTarget.MILKMAN)

    def test(input_: str, output: str):
        for paths in get_input_output_paths(input_, output):
            assert paths.input.read_text() == paths.output.read_text()

    with tempfile.TemporaryDirectory() as dirpath:
        build('test/test_files/test_compile_files', dirpath)
        test(dirpath, 'test/test_files/test_compile_files')

# Generated at 2022-06-23 22:09:20.028400
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from ..tests.cases import compile_files_cases
    for name, case in compile_files_cases.items():
        with pytest.raises(case['exc']):
            compile_files(case['input'], case['output'], case['target'],
                          case['root'])

# Generated at 2022-06-23 22:09:28.131195
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import json

    result = compile_files('input', 'output', CompilationTarget.ES3,
                           root=Path(__file__).parent.parent.parent)

    with result.get_report_file().open() as f:
        report = json.load(f)

    assert 'Compilation report' in report['report']
    assert report['count'] > 0
    assert result.get_report_file().exists()


if __name__ == '__main__':
    import sys
    from .cli.parser import parse_args
    from .constants import targets
    from .exceptions import handle_errors

    args = parse_args(sys.argv[1:])
    if args.target not in targets:
        raise ValueError('Unknown target: "{}"'.format(args.target))



# Generated at 2022-06-23 22:09:34.776564
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from .utils.helpers import get_temporary_directory

    with get_temporary_directory() as directory:
        input_ = directory / 'input'
        output = directory / 'output'
        input_.mkdir()

        with (input_ / 'file.py').open('w') as f:
            f.write('x = 0')
        compile_files(input_, output, CompilationTarget.RUNTIME)
        with (output / 'file.js').open() as f:
            code = f.read()
        assert code == "var x = 0;\n"

        with (input_ / 'file.py').open('w') as f:
            f.write('{{invalid syntax')
        with pytest.raises(CompilationError):
            compile_files

# Generated at 2022-06-23 22:09:40.612809
# Unit test for function compile_files
def test_compile_files():
    test_result = compile_files('./test/test_input', './test/test_output',
                                CompilationTarget.CONSOLE)
    assert test_result.target == CompilationTarget.CONSOLE, 'ERROR: Wrong target'
    assert test_result.dependencies == ['monkey_patching'], 'ERROR: Wrong dependencies'
    assert test_result.total_time >= 0, 'ERROR: Wrong total time'
    assert test_result.total_files == 4, 'ERROR: Wrong total files'


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:47.130597
# Unit test for function compile_files
def test_compile_files():
    # TODO: Make tests for each individual transformer
    result = compile_files('test_data/test_files',
                           'test_data/test_files_compiled',
                           CompilationTarget.PYTHON2)
    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON2
    assert len(result.dependencies) == 1
    assert result.dependencies[0] == 'typing'
    assert result.time > 0

# Generated at 2022-06-23 22:09:57.307216
# Unit test for function compile_files
def test_compile_files():
    import pytest
    result = compile_files('tests/data/dummy', 'tests/data/dummy.dst', CompilationTarget.SERVER)
    assert result.count == 2
    assert result.target == CompilationTarget.SERVER
    assert result.elapsed > 0
    assert result.elapsed < 2
    assert len(result.dependencies) == 2
    for dep in ['/fake/path/to/dep.py', '/fake/path/to/other.py']:
        assert dep in result.dependencies
    with pytest.raises(CompilationError):
        compile_files('tests/data/invalid', 'tests/data/invalid.dst', CompilationTarget.SERVER)

if __name__ == '__main__':
    import sys
    test_compile_files()
    compile_

# Generated at 2022-06-23 22:10:03.761643
# Unit test for function compile_files
def test_compile_files():
    import json
    import tempfile
    import os
    import shutil
    import unittest
    import sys


# Generated at 2022-06-23 22:10:06.056672
# Unit test for function compile_files
def test_compile_files():
    compile_files('test_files/test_compiler.py',
                  'test_files/test_compiler_generated.py',
                  CompilationTarget.DOM)



# Generated at 2022-06-23 22:10:09.791528
# Unit test for function compile_files
def test_compile_files():
    input_ = '../test'
    output = '../test_output'
    target = 'py27'
    root = '../test'
    assert compile_files(input_, output, target, root) == CompilationResult(1, 0.015584945678710938, target, [])

# Generated at 2022-06-23 22:10:14.339206
# Unit test for function compile_files
def test_compile_files():
    from .debug import set_debug
    from .types import CompilationTarget
    result = compile_files('../testfolder', '../testfolder', CompilationTarget.PYTHON_TO_JAVASCRIPT)
    assert(result.count == 4)
    assert(result.target == CompilationTarget.PYTHON_TO_JAVASCRIPT)
    assert(result.time > 0)


# Generated at 2022-06-23 22:10:22.626418
# Unit test for function compile_files
def test_compile_files():
    from .tests.compilation import assert_compilation_result
    from .tests.compilation import TestFile
    from .tests.compilation import compare_files
    from os.path import join

    class Test1(TestFile):
        inputs = ('a.py',)
        outputs = ('output/a.py',)

        def __init__(self):
            super().__init__()
            self.a_path = join(self.inputs_dir, 'a.py')
            self.output_a_path = join(self.outputs_dir, 'output', 'a.py')


# Generated at 2022-06-23 22:10:25.093405
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('', '', CompilationTarget()) == CompilationResult(0, 0, CompilationTarget(), [])



# Generated at 2022-06-23 22:10:27.210935
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('.', 'out',
                           CompilationTarget.STANDARD_LIBRARY)
    print(result)



# Generated at 2022-06-23 22:10:29.880484
# Unit test for function compile_files
def test_compile_files():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:10:38.873060
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from .files import get_input_output_paths, InputOutput
    from .transformers import transformers

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()

    files = {
        'a.py': '''
            class A:
                pass
        ''',
        'b.py': '''
            import a
            import b

            class B:
                pass
        ''',
        'c.py': '''
            import a
            import b
            import c

            class C:
                pass
        ''',
    }

    for path_, code in files.items():
        with open(os.path.join(input_, path_), 'w') as f:
            f.write(code)

    # 0 - run all transformers
    transform

# Generated at 2022-06-23 22:10:49.820782
# Unit test for function compile_files
def test_compile_files():
    from .compiler import compile_files
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tempdir:
        input_ = Path(tempdir, 'input')
        output = Path(tempdir, 'output')
        input_.mkdir()
        output.mkdir()

        input_.joinpath('a.py').write_text('p = 0')
        input_.joinpath('b.py').write_text('p = 0')
        input_.joinpath('c.py').joinpath('__init__.py').write_text('p = 0')
        input_.joinpath('c.py').joinpath('d.py').write_text('p = 0')



# Generated at 2022-06-23 22:10:56.554190
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .tests import data
    from .types import CompilationTarget

    expected_result = CompilationResult(
        num_files=1, time=0,
        target=CompilationTarget.PYTHON3_TO_PYTHON2,
        dependencies=['ast'],
    )

    result = compile_files(data.TEST_INPUT_DIR, data.TEST_OUTPUT_DIR,
                           CompilationTarget.PYTHON3_TO_PYTHON2)

    assert result == expected_result
    assert Path(data.TEST_OUTPUT_DIR / 'test_file').read_text() == '#!/usr/bin/env python\n# coding: utf-8\n\nfor x in range(10):\n    print(x)\n'

# Generated at 2022-06-23 22:11:07.809264
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    paths = get_input_output_paths('./tests', './tests/out', str(pathlib.Path.cwd()))
    from .transformers import transformers
    for i in range(len(transformers)-1):
        compile_files('./tests/__init__.py', './tests/out/__init__.py', i+1, str(pathlib.Path.cwd()))
        result = compile_files('./tests', './tests/out', i+2, str(pathlib.Path.cwd()))
        assert result.count == 8
        assert result.time >= 0
        assert result.target == i+2
        #TODO: No idea why this fails:
        #assert result.dependencies == ['argparse', 'pandas', 'numpy', '

# Generated at 2022-06-23 22:11:15.829553
# Unit test for function compile_files
def test_compile_files():
    import os
    from .types import CompilationTarget
    from .transformers import transformers
    from .utils.helpers import get_test_data_path

    def test_data_path():
        return os.path.join(os.path.dirname(os.path.realpath(__file__)),
                            'test_data')

    def compare_files_content(file_name, expected_file_name):
        with open(file_name) as f:
            content = f.read()
        with open(expected_file_name) as f:
            expected_content = f.read()
        assert content == expected_content

    # prepare test input/output directory structure
    test_data_input_path = test_data_path() + '/input'
    test_data_input_path_2 = test_data_path

# Generated at 2022-06-23 22:11:22.781297
# Unit test for function compile_files
def test_compile_files():
    from .examples.numpy import (
        example,
        expected,
    )
    import os
    import shutil
    import tempfile
    import unittest

    def run():
        _input, _output, _target = 'input', 'output', CompilationTarget.PYTHON_NUMPY
        with tempfile.TemporaryDirectory() as tempd:
            input_ = os.path.join(tempd, _input)
            output = os.path.join(tempd, _output)
            os.makedirs(input_)
            os.makedirs(output)
            for filename, text in example.items():
                with open(os.path.join(input_, filename), 'w') as f:
                    f.write(text)

# Generated at 2022-06-23 22:11:34.366169
# Unit test for function compile_files
def test_compile_files():
    import shutil, os
    from pathlib import Path
    from .utils import get_test_input, get_test_output
    from .exceptions import CompilationError
    print('Testing compile_files')
    shutil.copytree(get_test_input().as_posix(), get_test_output().as_posix())
    result = compile_files(get_test_output().as_posix(),
                           os.path.join(get_test_output().as_posix(), 'py2js'),
                           CompilationTarget.PYJS)
    assert result == CompilationResult(8, 0.212697, CompilationTarget.PYJS,
                                       ['os', 'sys', 'math', 'math'])

# Generated at 2022-06-23 22:11:45.278422
# Unit test for function compile_files
def test_compile_files():
    # You must first compile the test files yourself by running make.
    # This is important for the test to succeed.
    # This test is not the same as the unit test for each transformer.
    result = compile_files('test/input', 'test/output', CompilationTarget.python2)
    from json import load
    with open('test/output/unit_test.json') as f:
        actual = load(f)
        expected = {'count': 17, 'duration': actual['duration'], 'target': 'python2', 'dependencies': []}
        assert actual == expected
    assert result.count == actual['count']
    assert result.duration > actual['duration']
    assert result.target == CompilationTarget.python2
    assert result.dependencies == []


# Generated at 2022-06-23 22:11:55.794611
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    TEST_FOLDER = os.path.abspath('test_compile_files')
    OUTPUT = os.path.join(TEST_FOLDER, 'output')
    shutil.rmtree(TEST_FOLDER, ignore_errors=True)
    os.makedirs(TEST_FOLDER)

    # Required files
    os.makedirs(os.path.join(TEST_FOLDER, 'd0', 'd1'))
    with open(os.path.join(TEST_FOLDER, 'd0', '__init__.py'), 'w') as f:
        f.write('# __init__.py')

# Generated at 2022-06-23 22:12:03.172767
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import tempfile
    import shutil
    from .types import CompilationTarget
    from .utils.testing import assert_dependencies_equal

    tmpdir = tempfile.TemporaryDirectory()

    with open(Path(tmpdir.name, 'test.py'), 'w') as f:
        f.write('print(1)\n')

    result = compile_files(Path(tmpdir.name, 'test.py').as_posix(),
                           Path(tmpdir.name, 'out').as_posix(),
                           CompilationTarget.PYTHON)

    shutil.rmtree(tmpdir.name)

    assert(result.count == 1)
    assert(Path(tmpdir.name, 'out', 'test.py').exists())

# Generated at 2022-06-23 22:12:04.957300
# Unit test for function compile_files
def test_compile_files():
    compile_files('test/data/', 'test/data/out/', CompilationTarget.PYTHON)

# Generated at 2022-06-23 22:12:16.112465
# Unit test for function compile_files
def test_compile_files():
    from .utils.random import RandomFile
    from shutil import rmtree
    from .exceptions import ErrorOutput

    def test_compile(input_: str, output: str, target: CompilationTarget,
                     **kwargs):
        try:
            compile_files(input_, output, target, **kwargs)
        except CompilationError as e:
            raise AssertionError(str(e))

    with RandomFile() as source:
        source.write('')
        source.write('#include <stdio.h>')

        with RandomFile() as build_src:
            build_src.write('#include <stdlib.h>')

            with RandomFile() as build_dir:
                build_dir.write('#include <stdlib.h>')

                # test normal compilation

# Generated at 2022-06-23 22:12:22.984537
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from shutil import rmtree

    from .utils.helpers import get_test_dir
    from .types import CompilationTarget

    test_dir = get_test_dir()
    src = test_dir / 'src'
    dst = test_dir / 'dst'

    rmtree(src)
    rmtree(dst)

    src.mkdir()
    dst.mkdir()

    test_file = src / 'test.py'

    test_file.write_text(
        'def test():\n    print(1 + 2)\n')

    compile_files(src.as_posix(), dst.as_posix(), CompilationTarget.PYTHON)


# Generated at 2022-06-23 22:12:34.354419
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationResult
    from .exceptions import CompilationError, TransformationError
    from .utils.helpers import debug
    import os
    import shutil
    import tempfile

    class TestInputOutput(InputOutput):
        def __init__(self, path: str, content: str) -> None:
            self.path = path
            self.content = content

        @property
        def input(self) -> Path:
            return Path(self.path)

        @property
        def output(self) -> Path:
            return Path(self.path) + '.pony'

        def open(self, mode: str, **kwargs) -> File:
            if mode == 'r':
                return FakeFile(self.path, self.content)
            return FakeFile(self.path + '.pony')


# Generated at 2022-06-23 22:12:44.505779
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug

    target = CompilationTarget.HTML
    input_ = './t_data/parseable/ast/input.py'
    output = './t_data/parseable/ast/output.py'

    def assert_exc(exc: Exception, message: str) -> None:
        assert str(exc) == message
        assert exc.input_path == input_
        assert exc.line == 3
        assert exc.col == 9

    with debug():
        try:
            compile_files(input_, output, target)
        except CompilationError as exc:
            assert_exc(exc, 'Invalid syntax')


test_compile_files()

# Generated at 2022-06-23 22:12:48.883729
# Unit test for function compile_files
def test_compile_files():
    class Result:
        def __init__(self):
            self.count = 0
            self.time = 0
            self.target = None
            self.dependencies = []

    actual_result = Result()

    def compile_files_patch(input_, output, target, root=None):
        nonlocal actual_result
        actual_result.count = 1
        actual_result.time = 1
        actual_result.target = target
        actual_result.dependencies = ['a.py', 'b.py']
        return actual_result

    from .compiler import compile_files
    compile_files.compile_files = compile_files_patch

    compile_files('a.py', 'output', None)


# Generated at 2022-06-23 22:12:49.474722
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass

# Generated at 2022-06-23 22:12:51.728642
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('test/test_files/test.js',
                           'test/test_files/test.py',
                           CompilationTarget.LATEX)
    assert result.count == 1
    assert result.target == CompilationTarget.LATEX
    assert result.dependencies == ['test/test_files/ref.tex']

# Generated at 2022-06-23 22:12:56.867360
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile
    from .files import get_files_in_tree
    from .exceptions import CompilationError
    from .types import CompilationTarget
    from .utils.helpers import has_file_changed


# Generated at 2022-06-23 22:13:05.049285
# Unit test for function compile_files
def test_compile_files():
    from .compiler import compile_files
    from collections import namedtuple
    from .types import CompilationResult
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .compiler import _compile_file
    import tempfile
    import shutil
    import pytest

    # Create a fake file system
    paths = namedtuple('paths', ['input', 'output'])
    with tempfile.TemporaryDirectory() as tmpdir:
        input_ = tmpdir + '/input'
        output = tmpdir + '/output'
        input_.mkdir()
        output.mkdir()

        # Create a fake compile file function

# Generated at 2022-06-23 22:13:06.679108
# Unit test for function compile_files
def test_compile_files():
    # TODO(TobleMiner): Implement it
    pass

# Generated at 2022-06-23 22:13:07.792995
# Unit test for function compile_files
def test_compile_files():
    # TODO: Add unit test
    pass

# Generated at 2022-06-23 22:13:12.684775
# Unit test for function compile_files
def test_compile_files():
    with open('test.txt','r') as f:
        assert compile_files('test.txt','test2.txt','JS') == f.read()


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:13:22.296643
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import contextlib
    from . import __version__

    def prepare_compilation(input_, output):
        shutil.rmtree(output, ignore_errors=True)
        os.makedirs(output)
        for name in os.listdir(input_):
            shutil.copyfile(os.path.join(input_, name),
                            os.path.join(output, name))

    @contextlib.contextmanager
    def test_compilation(input_, output, target, root=None):
        prepare_compilation(input_, output)
        yield compile_files(input_, output, target, root)


# Generated at 2022-06-23 22:13:22.781852
# Unit test for function compile_files
def test_compile_files():
    pass



# Generated at 2022-06-23 22:13:31.212504
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths  # import this function to avoid circular dependency
    from .transformers.decorators import decorators_transformer
    from .transformers.recursion import recursive_transformer
    from .transformers.types import types_transformer
    from .transformers.unpacking import unpacking_transformer
    from .transformers.numpy import numpy_transformer

    def compile_files(input_, output, target, root=None) -> CompilationResult:
        return compile_files(input_, output, target, root)


# Generated at 2022-06-23 22:13:35.560482
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/compilation/data/input',
                           'tests/compilation/data/output',
                           CompilationTarget.PYTHON,
                           'tests/compilation/data/input')
    debug(lambda: 'CompilationResult: {}'.format(result))
    assert result.passed == 4
    assert result.failed == 0
    assert result.target is CompilationTarget.PYTHON
    assert result.time > 0.0


# Generated at 2022-06-23 22:13:43.781578
# Unit test for function compile_files
def test_compile_files():
    code = """
#include <stdio.h>

int main() {
    printf("Hello world!\n");
}
""".lstrip()

    result = compile_files('./test/test_files/test_C_to_Py_compile_files',
                           './test/test_files/test_C_to_Py_compile_files_output',
                           CompilationTarget.compile_python)
    assert(result.success == 1)

    code = open('./test/test_files/test_C_to_Py_compile_files_output/main.py', 'r').read()
    assert('ManagedPrintfStderr' in code)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:13:48.051347
# Unit test for function compile_files
def test_compile_files():
    from .tests.helper import check_compilation
    test_file = 'tests/data/statements/1-simple.py'
    assert check_compilation(test_file, None) == 'tests/data/statements/1-simple.js'


# Generated at 2022-06-23 22:13:52.390967
# Unit test for function compile_files
def test_compile_files():
    from .tests.integration.support import DIR
    result = compile_files(DIR / 'simple',
                           DIR / 'output' / 'simple',
                           CompilationTarget.ES5)
    assert result.count == 3
    assert result.time > 0
    assert result.target == CompilationTarget.ES5
    assert result.dependencies == ['assert.d.ts', 'console.d.ts', 'map.d.ts']

# Generated at 2022-06-23 22:14:03.736074
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import tempfile
    import shutil
    import re

    def get_test_dir(test_dir: str) -> Path:
        return Path(__file__).resolve().parent / 'test_resources' / test_dir

    def assert_file(source: Path, result: str, target: CompilationTarget):
        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir)
            result = compile_files(source.as_posix(),
                                   output_dir.absolute().as_posix(),
                                   target)
            assert 1 == result.count
            assert result.target == target
            output_path = output_dir / source.relative_to('suppliers') / 'fixtures' / 'main.py'

# Generated at 2022-06-23 22:14:14.725996
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import importlib
    import os
    # checking the files are compiled if there is no errors
    test_code = '''print("Hello")'''
    m = compile_files("test_input", "test_output", CompilationTarget.JAVA)
    try:
        importlib.import_module("test_output")
        os.remove("test_output" + os.sep + "__init__.py")
        with open("test_output" + os.sep + "test.py", "r") as file:
            tcode = file.read()
        assert (tcode == test_code)
    except:
        pytest.raises(ImportError)

    # checking the files are compiled if there is errors
    test_code = '''asdf'''

# Generated at 2022-06-23 22:14:25.021286
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    import sys
    file1_name = 'test_file1.py'
    file2_name = 'test_file2.py'
    input_file1 = '{}/{}'.format(input_, file1_name)
    input_file2 = '{}/{}'.format(input_, file2_name)
    output_file1 = '{}/{}'.format(output, file1_name)
    output_file2 = '{}/{}'.format(output, file2_name)

# Generated at 2022-06-23 22:14:25.879399
# Unit test for function compile_files
def test_compile_files():
    # TODO: write unit test
    pass

# Generated at 2022-06-23 22:14:27.879188
# Unit test for function compile_files
def test_compile_files():
    from .tests import compile_files as _compile_files
    _compile_files()


__all__ = ['compile_files']

# Generated at 2022-06-23 22:14:32.960751
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile

    project_root = os.path.dirname(os.path.abspath(__file__))
    input_ = os.path.join(project_root, '..', 'tests', 'models')
    output = os.path.join(tempfile.mkdtemp(), 'models')
    compile_files(input_, output, CompilationTarget.CARAVAN)

# Generated at 2022-06-23 22:14:40.573791
# Unit test for function compile_files
def test_compile_files():

    import tempfile
    import shutil
    import os

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()


# Generated at 2022-06-23 22:14:51.203530
# Unit test for function compile_files
def test_compile_files():
    class MockCompilationResult:
        def __init__(self, count: int, time_: float, target: CompilationTarget, dependencies: List[str]):
            self.count = count
            self.time = time_
            self.target = target
            self.dependencies = dependencies

    class MockFile:
        def __init__(self, name: str, data: str):
            self.name = name
            self.data = data

    # Prepare input and output data
    files = [MockFile('program.py', 'import foo'), MockFile('bar/program.py', 'import foo')]
    target = CompilationTarget.INTERPRETER
    dependencies = []

    input_ = Path('test/input')
    output = Path('test/output')
    input_.mkdir(parents=True)