

# Generated at 2022-06-23 22:04:56.491910
# Unit test for function compile_files
def test_compile_files():
    """Test compilation of a single file."""
    # pylint: disable=import-error
    import tempfile
    import shutil
    source = 'import os\n'
    source += 'os.path.isdir(os.path.dirname(os.path.abspath(__file__)))'

    with tempfile.TemporaryDirectory() as temp:
        with open(os.path.join(temp, 'test.py'), 'wt') as f:
            f.write(source)

        output = os.path.join(temp, 'output')
        compile_files(temp, output, CompilationTarget.RELEASE)
        shutil.rmtree(output)

# Generated at 2022-06-23 22:05:07.823810
# Unit test for function compile_files
def test_compile_files():

    from pathlib import Path
    from contextlib import contextmanager
    from io import StringIO
    from unittest import TestCase, mock

    from .utils.helpers import clear_cache


    @contextmanager
    def capture_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class MainTest(TestCase):
        @classmethod
        def setUpClass(cls):
            cls.input_ = Path(__file__).parent / 'testdata'


# Generated at 2022-06-23 22:05:12.492251
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile

    tmp_dir = Path(tempfile.mkdtemp())

    # Prepare test files
    tmp_dir.joinpath('a.scss').touch()
    tmp_dir.joinpath('b.scss').touch()
    tmp_dir.joinpath('c.ts').touch()
    tmp_dir.joinpath('d.ts').touch()

    # Run tests
    test_cases = (
        (CompilationTarget.PYTHON, 2, 4, 2),
        (CompilationTarget.TYPESCRIPT, 0, 0, 4),
    )

# Generated at 2022-06-23 22:05:23.322529
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files"""
    import os
    import shutil
    try:
        compiler = compile_files(os.path.join(os.path.dirname(__file__), '../samples'),
                                 os.path.join(os.path.dirname(__file__), '../output'))
    except:
        assert False
    assert compiler is not None
    assert compiler.compilation_count == 2
    assert os.path.exists(os.path.join(os.path.dirname(__file__), '../output/model/billing/person_model.py'))
    assert os.path.exists(os.path.join(os.path.dirname(__file__), '../output/model/delivery/person_model.py'))

# Generated at 2022-06-23 22:05:25.639349
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/test', 'test/test2', CompilationTarget.JAVASCRIPT)


# Generated at 2022-06-23 22:05:33.014658
# Unit test for function compile_files
def test_compile_files():
    from .examples.simple import Simple
    import os

    input_dir = os.path.dirname(os.path.realpath(__file__)) + "/tests/test_compile_files"
    output_dir = input_dir + "/output"
    input_dir = input_dir + "/input"

    #setup
    try:
        os.makedirs(output_dir+"/bar")
    except:
        pass

    def run_test(expected_message, expected_target, expected_dependencies):
        result = compile_files(input_dir, output_dir, expected_target)
        assert result.message == expected_message
        assert result.target == expected_target
        assert result.dependencies == expected_dependencies
        assert os.path.isfile(output_dir+"/bar/hello.py")

# Generated at 2022-06-23 22:05:37.300925
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files"""
    from os import remove, makedirs
    from os.path import exists, join
    from typing import List
    from shutil import rmtree
    from .exceptions import CompilationError
    from .types import CompilationResult

    assert not exists('test_data')

    # Test for unknown file type
    try:
        compile_files('test_data/do_not_exists', 'test_result/do_not_exists',
                      CompilationTarget.APP)
        assert False
    except CompilationError:
        pass
    assert not exists('test_result')

    # Test for unknown file type in nested directories
    makedirs('test_data/nested/dir')

# Generated at 2022-06-23 22:05:45.815482
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import subprocess
    import sys
    import tempfile
    import unittest

    import yaml
    from typing import Any

    class CompilationTests(unittest.TestCase):
        """Compilation tests for target 'js'."""
        def setUp(self) -> None:
            self.workspace = tempfile.TemporaryDirectory()

        def tearDown(self) -> None:
            self.workspace.cleanup()

        def test_import(self) -> None:
            """Tests import and import from."""
            self.compile_and_assert()
            self.assertEqual(self.run_js('js'), 8)
            self.assertEqual(self.run_js('js', run_from='from'), 8)


# Generated at 2022-06-23 22:05:55.285422
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError

    cwd = Path(__file__).parent
    result = compile_files(cwd / 'example', cwd / '__build__',
                           CompilationTarget.ES5)

    assert result.count == 5
    assert result.target == CompilationTarget.ES5
    assert result.dependencies == ['utils/helpers', 'utils/Mocha']

    assert (cwd / '__build__/example/es5.js').is_file()
    assert (cwd / '__build__/example/es5-2.js').is_file()
    assert (cwd / '__build__/example/es5-3.js').is_file()
    assert (cwd / '__build__/example/es5-4.js').is_file

# Generated at 2022-06-23 22:06:02.745938
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import contextlib
    import subprocess
    from io import StringIO
    from tempfile import TemporaryDirectory, NamedTemporaryFile
    from .files import get_input_output_paths

    subprocess.run(['python', 'setup.py', 'install'])

    @contextlib.contextmanager
    def compile_files_log_mock(self):
        old_stdout = sys.stdout
        try:
            sys.stdout = StringIO()
            self.assertEqual('', self.compile_files(self.input_path, self.output_path, CompilationTarget.PYTHON))
            yield sys.stdout
        finally:
            sys.stdout = old_stdout


# Generated at 2022-06-23 22:06:12.925227
# Unit test for function compile_files
def test_compile_files():
    from os import remove
    from tempfile import mkdtemp
    from .types import CompilationTarget

    input_ = mkdtemp()
    output = mkdtemp()
    print(input_)
    print(output)
    sample_code = """class Test():
    def __init__(self):
        pass

    def my_method(self):
        return True

    async def async_method(self):
        return False"""
    sample_code_python2 = """class Test(object):
    def __init__(self):
        pass

    def my_method(self):
        return True

    def async_method(self):
        pass"""

# Generated at 2022-06-23 22:06:22.568105
# Unit test for function compile_files
def test_compile_files():
    import os
    import pytest
    from .types import CompilationResult

    def get_result(input_: str, output: str, target: CompilationTarget,
                   expected: CompilationResult, root: Optional[str] = None) -> None:
        result = compile_files(input_, output, target, root)
        assert result.count == expected.count, f'{result.count} != {expected.count}'
        assert result.elapsed == expected.elapsed, f'{result.elapsed} != {expected.elapsed}'
        assert result.target == expected.target, f'{result.target} != {expected.target}'
        assert result.dependencies == expected.dependencies, f'{result.dependencies} != {expected.dependencies}'


# Generated at 2022-06-23 22:06:33.868373
# Unit test for function compile_files
def test_compile_files():
    from .examples.test_example import compile_test_example_to_py
    from os import path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        compile_test_example_to_py(tmpdir)

        res1 = compile_files(path.join(tmpdir, 'src'),
                             path.join(tmpdir, 'out1'),
                             CompilationTarget(0))
        res2 = compile_files(path.join(tmpdir, 'src'),
                             path.join(tmpdir, 'out2'),
                             CompilationTarget(1))
        res3 = compile_files(path.join(tmpdir, 'src'),
                             path.join(tmpdir, 'out3'),
                             CompilationTarget(2))


# Generated at 2022-06-23 22:06:42.052752
# Unit test for function compile_files
def test_compile_files():
    from . import main
    import os

    import astunparse
    import autopep8
    from . import transformers

    directory = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             'test_compile_files')

    code = """
    import sys
    import os

    def main(argv: List[str]) -> int:
        output = sys.stdout

        print("Hello, World!", file=output)
        return 0

    if __name__ == "__main__":
        exit(main(sys.argv))
    """

    input_path = os.path.join(directory, 'test.py')
    output_path = os.path.join(directory, 'test.pyc')


# Generated at 2022-06-23 22:06:48.748865
# Unit test for function compile_files
def test_compile_files():
    def _do_compile_files():
        import tempfile
        tempdir = tempfile.TemporaryDirectory()
        test_input = Path(tempdir.name) / 'test_input.py'
        test_input.parent.mkdir(parents=True)

# Generated at 2022-06-23 22:06:56.941741
# Unit test for function compile_files
def test_compile_files():
    import filecmp

    compile_files('tests/data/inputs/compilation', 'tests/data/output', CompilationTarget.MIR)
    assert filecmp.cmp('tests/data/output/hello_world.mir',
                       'tests/data/expecteds/hello_world.mir')
    assert filecmp.cmp('tests/data/output/quine.mir',
                       'tests/data/expecteds/quine.mir')

    compile_files('tests/data/inputs/compilation', 'tests/data/output', CompilationTarget.LLVM)
    assert filecmp.cmp('tests/data/output/hello_world.ll',
                       'tests/data/expecteds/hello_world.ll')

# Generated at 2022-06-23 22:07:06.420329
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import tempfile
    import os
    import shutil

    def read_file(path):
        with open(path) as f:
            return f.read()

    def assert_content(input_: str, expected: str):
        output_dir = tempfile.TemporaryDirectory()
        try:
            compile_files(input_, output_dir.name, CompilationTarget.PY3)
            assert read_file(os.path.join(output_dir.name, input_)) == expected
        finally:
            output_dir.cleanup()

    with tempfile.TemporaryDirectory() as tmpdir:
        os.chdir(tmpdir)  # Tests rely on relative import

        # Create test folder
        os.makedirs('test')
        os.makedirs('test/empty_folder')



# Generated at 2022-06-23 22:07:18.108644
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from pathlib import Path
    # Create test files
    file1 = Path(os.environ['TEST_DIR']) / 'file1.py'
    file2 = Path(os.environ['TEST_DIR']) / 'file2.py'
    file3 = Path(os.environ['TEST_DIR']) / 'file3.py'
    file4 = Path(os.environ['TEST_DIR']) / 'file4.py'
    file5 = Path(os.environ['TEST_DIR']) / 'file5.py'
    file6 = Path(os.environ['TEST_DIR']) / 'file6.py'
    file7 = Path(os.environ['TEST_DIR']) / 'file7.py'
    file

# Generated at 2022-06-23 22:07:28.198705
# Unit test for function compile_files
def test_compile_files():
    import os
    import subprocess
    import sys
    import tempfile

    current_path = os.path.dirname(__file__)
    input_path = os.path.join(current_path, '..', 'test_sources')

    with tempfile.TemporaryDirectory() as output_path:
        compile_files(input_path, output_path, CompilationTarget.PYTHON)
        subprocess.check_call([sys.executable,
                               os.path.join(output_path, 'main.py')])

    with tempfile.TemporaryDirectory() as output_path:
        compile_files(input_path, output_path, CompilationTarget.CPYTHON)

# Generated at 2022-06-23 22:07:36.933241
# Unit test for function compile_files
def test_compile_files():
    import pytest
    result = compile_files('./tests/compilation/data/input',
                           './tests/compilation/data/output',
                           CompilationTarget.PYTHON)
    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON
    assert len(result.dependencies) == 1
    assert result.dependencies[0] == 'numpy'

    result = compile_files('./tests/compilation/data/input',
                           './tests/compilation/data/output',
                           CompilationTarget.CUDA)
    assert result.count == 1
    assert result.target == CompilationTarget.CUDA
    assert len(result.dependencies) == 0


# Generated at 2022-06-23 22:07:44.405933
# Unit test for function compile_files
def test_compile_files():
    import tempfile, shutil, os, sys

    root = tempfile.mkdtemp()
    sys.path.insert(0, root)

    os.mkdir(os.path.join(root, 'a'))
    with open(os.path.join(root, 'a/__init__.py'), 'w') as f:
        f.write('# Empty __init__.py')


# Generated at 2022-06-23 22:07:49.314733
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_path
    for path in get_input_path(__file__).parent.glob('*.py'):
        # pylint: disable=bare-except
        try:
            compile_files(path, '/tmp/dummy', CompilationTarget.PYTHON)
        except:
            # Invalid code in documentation
            pass

# Generated at 2022-06-23 22:07:57.230938
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import shutil

    # Remove previous test folder
    try:
        shutil.rmtree('./tests/compiler/compile_files_test_input')
    except:
        pass

    # Create test folder
    shutil.copytree('./tests/compiler/compile_files_test_input_source', './tests/compiler/compile_files_test_input')

    # Test
    input_ = './tests/compiler/compile_files_test_input'
    output = './tests/compiler/compile_files_test_output'
    result = compile_files(input_, output, CompilationTarget.ALL)

    assert result.count == 6
    assert result.target == 'all'
    assert int(result.time) == 0

    #

# Generated at 2022-06-23 22:07:59.805996
# Unit test for function compile_files
def test_compile_files():
    compile_files("../test_data/compiler_test/",
                  "../test_data/compiler_test2/",
                  CompilationTarget.CLIENT)



# Generated at 2022-06-23 22:08:04.749426
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/compiler/input', './tests/compiler/output', CompilationTarget.WEBASSEMBLY,
                           root='./tests/compiler')
    assert result.count == 4
    assert result.target == CompilationTarget.WEBASSEMBLY
    assert result.dependencies == ['foo.py']
    assert result.time > 0



# Generated at 2022-06-23 22:08:14.307314
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    # Prepare test files
    input_path = os.path.join(tempfile.mkdtemp(), 'input')
    output_path = os.path.join(tempfile.mkdtemp(), 'output')
    os.makedirs(input_path)
    os.makedirs(output_path)
    input_file_path = os.path.join(input_path, 'input.py')
    output_file_path = os.path.join(output_path, 'output.py')
    with open(input_file_path, 'w') as f:
        f.write("print('Hello world!')\n")

    # Run test
    compile_files(input_path, output_path, CompilationTarget.ES6)

    # Check result

# Generated at 2022-06-23 22:08:22.637292
# Unit test for function compile_files
def test_compile_files():
    import time
    import json

    import pytest

    from .. import main, __version__

    def check(input_: str, output: str, target: CompilationTarget,
              root: Optional[str] = None,
              dependencies: Optional[List[str]] = None) -> CompilationResult:
        result = compile_files(input_, output, target, root)

        try:
            with open(output / 'output.py') as f:
                assert f.read() == '"Hello, world!"\n'
        except:
            pytest.fail('Invalid output: {}'.format(output))


# Generated at 2022-06-23 22:08:32.485581
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    def run_simple_compilation(target: CompilationTarget) -> CompilationResult:
        input_ = os.path.join(temp_dir, 'input')
        output = os.path.join(temp_dir, 'output')
        os.mkdir(input_)

        f = open(os.path.join(input_, 'test.py'), 'w')
        f.write('print("Hello World!")')
        f.close()

        return compile_files(input_, output, target)

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 22:08:41.583493
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    def assert_equals(file1, file2):
        with open(file1) as f1:
            with open(file2) as f2:
                assert f1.read() == f2.read()

    def clean_up(tmpdir):
        shutil.rmtree(tmpdir)

    def test_example(example, example_path, compiler, except_file,
                     tmpdir):
        print(example)
        input_dir = example_path
        output_dir = os.path.join(tmpdir, example)
        compiler(input_dir, output_dir, root=example_path)
        assert_equals(os.path.join(output_dir, except_file),
                      os.path.join(input_dir, except_file))


# Generated at 2022-06-23 22:08:52.566765
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from glob import glob
    root = Path(__file__).parent.parent.absolute()
    target = CompilationTarget.PLATYPUS
    count, _, _, dependencies = compile_files(
        str(root / 'test'), str(root / 'build'), target, str(root))
    def is_all_right():
        built_files = list(map(str, glob(str(root / 'build' / '**' / '*.py'), recursive=True)))
        for file in built_files:
            with open(file, 'r') as f:
                code = f.read()
                assert 'import' not in code or \
                    any(dependency in code for dependency in dependencies), \
                    'Error: {} not found in {}'.format(dependency, file)
    is_all_right

# Generated at 2022-06-23 22:09:02.338278
# Unit test for function compile_files
def test_compile_files():
    from .utils.tempdir import TempDir
    from .utils.shell import run

    with TempDir() as tmp:
        target = 'py27'
        input_ = tmp.joinpath('input')
        output = tmp.joinpath('output')
        input_.joinpath('__init__.py').touch()
        input_.joinpath('data.py').write_text('''
            def f():
                pass
        ''')

        result = compile_files(input_, output, target)

        assert result.files == 2
        assert result.target == target
        assert result.time > 0
        assert result.dependencies == []

        assert run(['python2'], cwd=str(output)) == 0

        # Check the first line of the file
        assert input_.joinpath('data.py').read_text().splitlines

# Generated at 2022-06-23 22:09:12.599002
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import PythonError, PythonSyntaxError
    from .files import get_input_output_paths
    from .transformers.dependencies import DependenciesTransformer

    from .transformers.path import PathTransformer
    from .transformers.decorators import DecoratorsTransformer
    from .transformers.class_module import ClassModuleTransformer
    from .transformers.init import InitTransformer
    from .transformers.imports import ImportsTransformer
    from .transformers.exceptions import ExceptionsTransformer
    from .transformers.urllib import UrllibTransformer
    from .transformers.requests import RequestsTransformer
    from .transformers.utils import UtilsTransformer
    from .transformers.abs import AbsTransformer
    from .transformers import print_function

# Generated at 2022-06-23 22:09:18.288486
# Unit test for function compile_files
def test_compile_files():
    input_ = 'examples/example.html'
    output = 'examples/example.py'
    result = compile_files(input_, output, CompilationTarget.JYTHON)
    assert result.count == 1
    assert result.dependencies == ['examples/js/script.js', 'examples/js/function.js']



# Generated at 2022-06-23 22:09:24.986025
# Unit test for function compile_files
def test_compile_files():
    import os, shutil
    input_ = os.path.join(os.getcwd(), "tests", "test_input")
    output = os.path.join(os.getcwd(), "tests", "test_output")
    root = os.getcwd()
    compile_files(input_, output, CompilationTarget.PYTHON_SKIP_DEPRECATION, root)
    assert os.path.exists(output)
    assert os.path.isfile(os.path.join(output, "test_file.py"))
    shutil.rmtree(output)


# Generated at 2022-06-23 22:09:27.461443
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/input', 'tests/output',
                           CompilationTarget.TARGET)
    assert result.count == 2
    assert result.target == CompilationTarget.TARGET
    assert len(result.dependencies) == 6

# Generated at 2022-06-23 22:09:35.048201
# Unit test for function compile_files
def test_compile_files():
    # Unit test for function compile_files
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    import pprint
    import os

    with TemporaryDirectory() as tmp:
        compile_files(os.path.join(tmp, 'a.py'), os.path.join(tmp, 'a.js'),
                      CompilationTarget.JS)
        print('output:')
        Path(os.path.join(tmp, 'a.js')).write_text(open(os.path.join(tmp, 'a.js')).read())

# Generated at 2022-06-23 22:09:42.106587
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers import transformers
    from .types import CompilationTarget
    transformers.clear()
    for t in [t for t in dir() if t.endswith('_transformer')]:
        transformers.append(getattr(__import__(__name__), t).Transformer())
    paths = get_input_output_paths(
        '/Users/jeffreywang/Desktop/ml_template/ml/base/__init__.py',
        './out/ml/base/__init__.py', '/Users/jeffreywang/Desktop/ml_template')
    compile_files(paths[0].input.as_posix(), paths[0].output.as_posix(), CompilationTarget.PYTHON2)



# Generated at 2022-06-23 22:09:51.228707
# Unit test for function compile_files
def test_compile_files():
    import os, shutil
    import tempfile
    import subprocess

    def exact_sort(x):
        if type(x) == list:
            x.sort()
            return x
        elif type(x) == set:
            return sorted(exact_sort(list(x)))
        return x

    def test_pass(part, target, correct_code, correct_deps):
        with tempfile.TemporaryDirectory() as input_:
            with tempfile.TemporaryDirectory() as output:
                for path, code in correct_code.items():
                    open(os.path.join(input_, path), 'w').write(code)
                for path in correct_code:
                    compile_files(input_, output, target, input_)
                    correct_deps = exact_sort(correct_deps)
                   

# Generated at 2022-06-23 22:09:57.806436
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from shutil import rmtree
    from tempfile import gettempdir
    from .types import CompilationTarget, CompilationResult
    compiled = compile_files(Path(__file__).parent.joinpath('examples'),
                             Path(gettempdir()).joinpath('typedflow_output'),
                             CompilationTarget.PURE_PYTHON)
    assert compiled.target == CompilationTarget.PURE_PYTHON
    assert compiled.count > 0
    rmtree(compiled.output.as_posix())

# Generated at 2022-06-23 22:10:08.548207
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import os
    import shutil
    input = os.path.dirname(__file__) + "/tests/test_input"
    output = os.path.dirname(__file__) + "/tests/test_output"


    if os.path.isdir(output):
        shutil.rmtree(output)

    result = compile_files(input, output, CompilationTarget.ES5_STRICT, root=os.path.dirname(__file__))

    assert result.count == 1
    assert os.path.isfile(output + "/file.js")
    with open(output + "/file.js") as f:
        assert f.read() == 'var x = 1;\nvar y = 2;\n\nvar z = 3;\n'

    shutil.rmtree

# Generated at 2022-06-23 22:10:17.637080
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import tempfile
    import os.path
    import os
    import shutil
    from .exceptions import CompilationError, TransformationError
    from typing import List, Optional
    from .utils.helpers import debug
    from .types import CompilationTarget

    class TestCompileFiles(unittest.TestCase):
        """Unit test for function _compile_file."""

        def setUp(self):
            self.tmp_dir = tempfile.mkdtemp(prefix='flask-rest-api-')
            self.filename = os.path.join(self.tmp_dir, 'file.py')
            self._debug = debug

        def tearDown(self):
            shutil.rmtree(self.tmp_dir)
            del self._debug


# Generated at 2022-06-23 22:10:28.129946
# Unit test for function compile_files
def test_compile_files():
    class _ExampleTransformer(ast.NodeTransformer):
        target = CompilationTarget.STANDARD
        def visit_Name(self, node: ast.Name) -> ast.Name:
            return ast.copy_location(ast.Name(id='the_result',
                                              ctx=deepcopy(node.ctx)),
                                     node)

    transformers.append(_ExampleTransformer())
    input_ = 'example/input'
    output = 'example/output'
    target = CompilationTarget.STANDARD
    root = Path('example').resolve()
    result = compile_files(input_, output, target, root)
    transformers.remove(_ExampleTransformer())
    assert result.count == 2
    assert result.dependencies == ['example/input/main.py']

# Generated at 2022-06-23 22:10:37.591801
# Unit test for function compile_files
def test_compile_files():
    import os

    # We need python 3.6
    if tuple(map(int, os.environ['TRAVIS_PYTHON_VERSION'].split('.'))) < (3, 6):
        return

    from io import StringIO

    from .files import get_all_files
    from .utils.helpers import config_build_paths
    from .utils.helpers import init_default_logger

    init_default_logger()
    output_dir = config_build_paths('tests/fixtures/output')
    input_dir = config_build_paths('tests/fixtures/input')

    for path in get_all_files(input_dir):
        assert path.suffix == '.py'
        assert path.parent == input_dir

# Generated at 2022-06-23 22:10:48.737346
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil


# Generated at 2022-06-23 22:10:51.088149
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/compiler', 'tests/dist', CompilationTarget.WEB_CLIENT,
                         'tests').count == 10

# Generated at 2022-06-23 22:10:54.715572
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    try:
        compile_files('tests/advanced_features/',
                      'tests/advanced_features_compiled/',
                      CompilationTarget.JS)
    except CompilationError as e:
        print(e)
        assert False


# Generated at 2022-06-23 22:10:57.182150
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/input', 'tests/output', 'py3', 'tests/input')
    assert compile_files('tests/input', 'tests/output', 'py3')



# Generated at 2022-06-23 22:11:00.951411
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/function', 'tmp', CompilationTarget.GEOPYTHON)
    print(result)
    assert result.count == 2

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:11:02.489234
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./test_data/test_compile_files/input',
                         './test_data/test_compile_files/output',
                         CompilationTarget.TEST)

# Generated at 2022-06-23 22:11:05.997918
# Unit test for function compile_files
def test_compile_files():
    print("Trying to compile a solution...")
    start = time()
    compile_files('solutions/task4', 'output', CompilationTarget.PYTHON)
    print("Successfully compiled the solution in %f seconds" % (time() - start))

# Generated at 2022-06-23 22:11:14.561141
# Unit test for function compile_files
def test_compile_files():
    from .transformers.imports import ImportsTransformer
    from .transformers.v2 import V2Transformer
    from .transformers.v3 import V3Transformer
    from .transformers.v4 import V4Transformer

    path = './tests/files/'
    input_ = path + 'input/'
    output = path + 'output/'

    arguments = [
        ('import_simple.py', path, CompilationTarget.IMPORT),
        ('v2_simple.py', path, CompilationTarget.V2),
        ('v3_simple.py', path, CompilationTarget.V3),
        ('v4_simple.py', path, CompilationTarget.V4),
    ]

    with open(path + 'v3_simple.py') as f:
        code = f.read()


# Generated at 2022-06-23 22:11:21.979038
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/compilation/input', 'test/compilation/output', CompilationTarget.DYNAMIC) == CompilationResult(4, 0.06, CompilationTarget.DYNAMIC, [])

if __name__ == '__main__':
    from sys import argv, exit
    from .types import CompilationTarget

    if len(argv) != 5:
        print('Usage: python3 -m python_to_python <input> <output> <target> <root>')
        exit(1)

    input_, output, target, root = argv[1:]
    target = CompilationTarget[target.upper()]

    try:
        result = compile_files(input_, output, target, root)
    except Exception as e:
        print(e)
        exit(1)

    print

# Generated at 2022-06-23 22:11:33.539561
# Unit test for function compile_files
def test_compile_files():
    import pytest  # type: ignore

    def pytest_addoption(parser):
        parser.addoption("--test-data-path", default="test_data")

    def pytest_generate_tests(metafunc):
        import os.path
        path = metafunc.config.getoption("test_data_path")
        files = sorted([i for i in os.listdir(path) if i.endswith(".cpp")])
        metafunc.parametrize("test_file", files)

    def join_path(path, test_file):
        return os.path.normpath(os.path.join(path, "test_data", test_file))

    def test_compile_file(test_file):
        print("Compile {}".format(test_file))
        input_ = join

# Generated at 2022-06-23 22:11:39.998262
# Unit test for function compile_files
def test_compile_files():
    from .transformers import DEFAULT_TARGET
    from .utils.mock import mock_compiler

    mock_compiler(
        (
            'foo.py',
            'import bar\n'
            'print(bar.__path__)\n'
            'print(bar.__file__)\n',
            'import bar\n'
            'print(bar.__path__)\n'
            'print(bar.__file__)\n'
        ),
        (
            'bar.py',
            'print(1234567890)\n',
            'print(1234567890)\n'
        ),
        target=DEFAULT_TARGET,
        root='/foo'
    )

# Generated at 2022-06-23 22:11:50.638007
# Unit test for function compile_files
def test_compile_files():
    import textwrap
    import tempfile
    from random import choice
    from string import ascii_letters

    def _random_string(length=10):
        return "".join(choice(ascii_letters) for _ in range(length))

    from .files import InputOutput
    from . import types

    compiler = set()
    for i, transformer in enumerate(transformers):
        compiler.add(types.CompilationTarget(i))
        src = textwrap.dedent('''
        def {name}({arg}): # line 1
            return {arg} # line 2
        ''').format(name=transformer.__name__, arg=_random_string(3))
        with tempfile.NamedTemporaryFile(suffix='.py') as f:
            f.write(src.encode())
           

# Generated at 2022-06-23 22:11:55.228593
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(
        './tests/files/input',
        './tests/files/.output',
        CompilationTarget.ES5) == \
        CompilationResult(12, 18.84896087646484, CompilationTarget.ES5, ['./tests/files/input/modules/es6/modules/es5/index.js'])

# Generated at 2022-06-23 22:12:07.016201
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .tmpdirs import inputdir, outputdir

    # Disable flake8 for all files in tests/ because we want to ensure
    # that all unindented code will be detected by compiler
    # flake8: noqa
    INPUT1 = '''
    # comment
    "use strict"
    '''
    INPUT2 = '''
    # comment
    x = 1
    '''
    INPUT3 = '''
    # comment
    x = 1
    '''
    INPUT4 = '''
    # comment
    "use strict"
    x = 1
    x = 2
    '''
    # flake8: enable


# Generated at 2022-06-23 22:12:11.911435
# Unit test for function compile_files
def test_compile_files():
    test_compile_files = compile_files('test/test-files/testfiles/', 'test/test-files/testfiles_compiled/', CompilationTarget.PYTHON)
    print(test_compile_files.count)
    print(test_compile_files.target)

# Generated at 2022-06-23 22:12:20.919545
# Unit test for function compile_files
def test_compile_files():
    compile_files('temp', 'temp', 'auto')


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Compiles Python 2 code to Python 3')
    parser.add_argument('input', type=str, help='path to input folder')
    parser.add_argument('output', type=str, help='path to output folder')
    parser.add_argument('--target', '-t', choices=['py3', 'js', 'auto'], default='auto',
                        help='target language')
    parser.add_argument('--root', '-r', type=str,
                        help='path to root folder')
    parser.add_argument('--only-dependencies', '-d', action='store_true',
                        help='only print dependencies')


# Generated at 2022-06-23 22:12:30.061736
# Unit test for function compile_files
def test_compile_files():
    from os import environ
    from tempfile import TemporaryDirectory
    from shutil import copytree, rmtree

    def with_paths(input_: str, output: str) -> CompilationResult:
        with TemporaryDirectory() as tmp:
            copytree(input_, tmp)
            return compile_files(tmp, output, CompilationTarget.web, tmp)

    assert with_paths('tests/samples/basic', '/tmp/testing') == \
        CompilationResult(2, None, CompilationTarget.web,
                          ['os', 'sys', 'itertools.chain', 'foo'])

# Generated at 2022-06-23 22:12:34.963233
# Unit test for function compile_files
def test_compile_files():
    from .importers import import_files
    from .files import get_input_output_paths
    from .types import CompilationTarget
    import os
    input_ = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'importer',
    )
    output = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        '..',
        'tests',
        'compiler',
    )
    target = CompilationTarget.PYTHON_3
    result = compile_files(input_, output, target)
    assert len(result.dependencies) == 0
    assert result.count == 3
    assert import_files(output) == import_

# Generated at 2022-06-23 22:12:45.311445
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .utils.helpers import debug, debug_off
    from . import CompilationTarget

    input_ = 'files/test/'
    output = 'files/test-output/'
    target = CompilationTarget.es5

    debug_off()
    compile_files(input_, output, target)
    debug()

    files = []
    for paths in get_input_output_paths(input_, output):
        assert paths.input.exists()
        assert paths.output.exists()
        files.append(paths.output)

    assert sorted(files) == [Path('files/test-output/class.js'),
                             Path('files/test-output/decorators.js')]

# Generated at 2022-06-23 22:12:53.794025
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    import unittest

    directory = tempfile.TemporaryDirectory()

    INPUT_TEMPLATE = '''
        import os
        import sys
        from __future__ import print_function
        def _helper(a, b):
            {system_call}
            return a + b

        def main():
            _helper(3, 4)
            print("Hello world")
    '''

    OUTPUT_TEMPLATE = '''\
        import os
        import sys


        def _helper(a, b):
            {system_call}
            return a + b


        def main():
            _helper(3, 4)
            print("Hello world")
    '''


# Generated at 2022-06-23 22:12:59.049483
# Unit test for function compile_files

# Generated at 2022-06-23 22:13:03.955118
# Unit test for function compile_files
def test_compile_files():  # pragma: no cover
    import json

    with open('tests/data/result.json') as f:
        data = json.load(f)

    result = compile_files(data['input'], data['output'],
                           CompilationTarget(data['target']))
    assert result == CompilationResult(data['input'], data['output'],
                                       CompilationTarget(data['target']),
                                       data['dependencies'], data['time'])

# Generated at 2022-06-23 22:13:14.400241
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os
    import os.path

    import pytest

    from .files import get_input_output_paths

    from .doctest_runner import doctest_runner
    from .test_data_provider import test_data_provider

    from .adapters import StdoutAdapter, FileAdapter
    from .transformation_cache import TransformationCache

    doctest_runner.register_adapter(StdoutAdapter())
    doctest_runner.register_adapter(FileAdapter('temp/'))
    cache = TransformationCache()
    doctest_runner.register_adapter(cache)

    def do_test(name, input_, target: CompilationTarget):
        output = cache.generate_name(name, target)


# Generated at 2022-06-23 22:13:23.410085
# Unit test for function compile_files
def test_compile_files():
    import os
    import subprocess as sp
    from .tests import test_dir
    from .files import temp_dir
    from .tests.test_sources import simple_source
    from .types import CompilationTarget

    # Prepare input
    input_path = test_dir.joinpath('input')
    input_path.mkdir()
    (input_path / 'test.py').touch()
    (input_path / 'test.txt').touch()

    # Compile
    with temp_dir() as output_path:
        compile_files(input_path, output_path, CompilationTarget.PY2)
        assert not os.path.exists(os.path.join(output_path, 'test.txt'))
        assert open(os.path.join(output_path, 'test.py')).read() == simple

# Generated at 2022-06-23 22:13:29.079500
# Unit test for function compile_files
def test_compile_files():
    """Checks compile_files function."""
    compiler = compile_files('tests/data/simple', '__output',
                             CompilationTarget.CPYTHON)
    assert compiler.target == CompilationTarget.CPYTHON
    assert compiler.dependencies == []
    assert compiler.count == 1
    assert compiler.time > 0
    assert compiler.check_input_output_equality('tests/data/simple',
                                                '__output')

# Generated at 2022-06-23 22:13:38.284313
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .exceptions import CompilationError
    from .types import CompilationTarget, CompilationResult
    from .files import InputOutput
    from .test_helpers import get_directory_hash, clean_directory

    example_dir = 'doc/examples/'
    compiled_dir = 'test/compiled/'


# Generated at 2022-06-23 22:13:45.964355
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import get_files_from_dir, get_files_from_requirements

    def fixture_path(path: str) -> Path:
        return Path(__file__).resolve().parent / 'fixtures' / path

    def compile_fixture(path: str, target: CompilationTarget, need_test: bool = False) -> CompilationResult:
        out_path = fixture_path(path) / 'compiled'
        if not out_path.exists():
            out_path.mkdir()

        return compile_files(fixture_path(path) / 'source',
                             out_path, target)

    result = compile_fixture('test_pysa_dsl', CompilationTarget.PYSA)
    assert result.compiled_files == 5

# Generated at 2022-06-23 22:13:48.473529
# Unit test for function compile_files
def test_compile_files():
    print(compile_files('sources', 'output', CompilationTarget.PROD))
    print(compile_files('sources', 'output', CompilationTarget.DEV))

# Generated at 2022-06-23 22:13:55.191961
# Unit test for function compile_files
def test_compile_files():
    input_ = './test_files/simple'
    output = './tmp/simple'
    root = './test_files'
    result = compile_files(input_, output, CompilationTarget.small_pypy, root)
    print("Compiled {} files.\nTakes {}s.\nTarget: {}".format(result.file_count,
                                                              result.time,
                                                              result.target))
    assert result.file_count == 2, 'Only 2 file should be compiled.'
    assert result.time <= 2, 'Only takes less than 2 seconds.'
    assert result.target == CompilationTarget.small_pypy, 'Target should be small_pypy'

# Generated at 2022-06-23 22:14:03.095110
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    # import shutil
    from .utils.helpers import get_full_path

    with tempfile.TemporaryDirectory() as temp_dir:
        # shutil.copyfile(get_full_path('compiler/tests/input.py'),
        #                get_full_path('./input.py'))
        # shutil.copytree(get_full_path('compiler/tests/dependencies'),
        #                get_full_path('./dependencies'))
        result = compile_files(get_full_path('compiler/tests/input.py'),
                               get_full_path(temp_dir),
                               CompilationTarget.FRONTEND,
                               get_full_path('compiler/tests/'))
        print(result)

# Generated at 2022-06-23 22:14:14.632901
# Unit test for function compile_files
def test_compile_files():
    from io import StringIO
    from .compile import compile_files
    from .types import CompilationTarget, CompilationResult
    from .exceptions import CompilationError

    buf = StringIO()

    buf.write('def foo(x):\n'
              '    return x * 2\n'
              '\n'
              'def bar(x):\n'
              '    return x + 2\n')

    buf.seek(0)

    try:
        r = compile_files(buf, '/tmp', CompilationTarget.PROTOTYPE)
    except CompilationError as e:
        assert(False)

    assert(r.count == 1)
    assert(r.time > 0.0)
    assert(r.target == CompilationTarget.PROTOTYPE)

# Generated at 2022-06-23 22:14:24.980636
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import shutil
    import tempfile
    import unittest

    class CompileFilesTestCase(unittest.TestCase):
        def setUp(self):
            self.tmp = tempfile.TemporaryDirectory()
            src = pathlib.Path(self.tmp.name, 'src')
            src.mkdir()
            src.joinpath('a.py').write_text('print(5)')
            src.joinpath('b.py').write_text('print(5, 6)')
            src.joinpath('b.txt').write_text('hello')
            src.joinpath('dir', 'c.py').write_text('print(5 + 6)')
            src.joinpath('dir', 'd.txt').write_text('world')

# Generated at 2022-06-23 22:14:34.406943
# Unit test for function compile_files
def test_compile_files():

    from .types import CompilationTarget

    from .files import get_input_output_paths

    from .utils.context import create_temp_dir
    from .utils.helpers import list_files

    with create_temp_dir() as d:
        compile_files(input_=d / 'in', output=d / 'out', target=CompilationTarget.JAVA)

        in_paths = get_input_output_paths(input_=d / 'in', output=d / 'out')
        assert len(in_paths) == 0

        (d / 'in' / 'a.py').write_text(u'import sys\nprint(sys.version)')
        compile_files(input_=d / 'in', output=d / 'out', target=CompilationTarget.JAVA)

        in_

# Generated at 2022-06-23 22:14:44.745767
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import os

    class CompileFilesTest(unittest.TestCase):
        def setUp(self):
            self._cur_dir = os.getcwd()
            os.chdir(os.path.abspath(os.path.join(__file__, '..', '..', 'tests')))

        def tearDown(self):
            os.chdir(self._cur_dir)

        def test_compile_files(self):
            result = compile_files('input', 'output', CompilationTarget.Node, '.')
            self.assertEqual(2, result.count)
            self.assertEqual(1, len(result.dependencies))


# Generated at 2022-06-23 22:14:45.413603
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:14:51.376323
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('python_transpile/tests/fixtures/manual/compile_files/input',
                           'python_transpile/tests/fixtures/manual/compile_files/output',
                           CompilationTarget.ES5)
    assert result.count == 1, result.count
    assert result.dependencies == [], result.dependencies