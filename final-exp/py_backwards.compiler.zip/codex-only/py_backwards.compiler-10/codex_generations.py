

# Generated at 2022-06-23 22:04:43.854970
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .utils.file_system import path_from_root
    from .utils.testing import skip_ci
    from .utils.helpers import clear_directory

    skip_ci()
    input_ = path_from_root('tests/resources/sample/src')
    output = path_from_root('tests/resources/sample/compiled')
    root = path_from_root('tests/resources/sample')
    clear_directory(path_from_root(output))

    try:
        compile_files(input_, output, CompilationTarget.PYTHON)
    except CompilationError as e:
        print(e.message)
        raise e


# Generated at 2022-06-23 22:04:52.123352
# Unit test for function compile_files
def test_compile_files():
    from pytest import raises
    from .types import ALL_KNOWN_TARGETS
    from .transformers.conditional import ConditionalTransformer
    from .transformers.dataclass import DataclassTransformer

    for target in ALL_KNOWN_TARGETS:
        for use_strict_mode in [True, False]:
            for use_typing in [True, False]:
                using = ('using' if use_strict_mode else '') +\
                        (' and typing' if use_typing else '')
                debug(lambda: '-' * 100)
                debug(lambda: 'Test {}{}'.format(target, using))

                # Create simple .py file

# Generated at 2022-06-23 22:05:00.380383
# Unit test for function compile_files
def test_compile_files():
    from . import __file__ as src
    from . import __version__ as version
    from .__main__ import main
    from tempfile import TemporaryDirectory
    from glob import glob
    import os

    with TemporaryDirectory() as out:
        os.chdir(out)
        main([src, '--out', '.', '--target', 'js'])
        assert len(glob('*.js')) == 2
        assert len(glob('*.py*')) == 0
        assert len(glob('*')) == 2
        with open('index.js') as f:
            assert 'f-strings' in f.read()
        with open('code.js') as f:
            assert version in f.read()
        with open('index.js') as f:
            assert __file__ in f.read()

        main

# Generated at 2022-06-23 22:05:06.414449
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    with tempfile.TemporaryDirectory() as input_dir:
        with tempfile.TemporaryDirectory() as input_dir:
            input_dir.write_text('import numpy as np')
            compile_files(input_dir, input_dir, CompilationTarget.PYTHON_LEGACY)
            # TODO: Check the result of compilation

# Generated at 2022-06-23 22:05:17.276503
# Unit test for function compile_files
def test_compile_files():
    # Basic function
    assert compile_files("./test/test_data/test1", "./test_output", CompilationTarget.PYTHON).count == 1
    # Test input_ path is not a directory
    assert compile_files("./test/test_data/test2/foo.py", "./test_output", CompilationTarget.PYTHON).count == 0
    # Test input_ directory is empty
    assert compile_files("./test/test_data/test3", "./test_output", CompilationTarget.PYTHON).count == 0
    # Test output directory not exist
    assert compile_files("./test/test_data/test1", "./test_output_not_exist/", CompilationTarget.PYTHON).count == 1
    # Test output directory is none
    assert compile_files

# Generated at 2022-06-23 22:05:28.499568
# Unit test for function compile_files
def test_compile_files():
    from os import remove
    from tempfile import mkdtemp
    from ertb import build
    import subprocess

    def compile_and_run(source_file, output_directory, target):
        build.compile_files(source_file, output_directory, target)
        subprocess.call(["python", output_directory+"/"+source_file.split('/')[-1]])

    def test_compile_source_file(source_file, target):
        output_directory = mkdtemp()
        try:
            compile_and_run(source_file, output_directory, target)
        except:
            print("compile_and_run(\"{}\", \"{}\", {}) threw an exception: ".format(source_file, output_directory, target))
            raise

    test_compile_source_

# Generated at 2022-06-23 22:05:31.021063
# Unit test for function compile_files
def test_compile_files():
    from .tests.test_compiler import test_compile_files
    test_compile_files()

# Generated at 2022-06-23 22:05:36.084898
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    from .utils.helpers import ProjectSettings

    with TemporaryDirectory() as tmp:
        ProjectSettings(tmp)
        compile_files('examples',
                      '{}/pytojs/examples'.format(tmp),
                      CompilationTarget.ES5)

        rmtree(tmp)

# Generated at 2022-06-23 22:05:46.431784
# Unit test for function compile_files
def test_compile_files():
    compile_files('functions/src/dynamic.py', 'functions/build/dynamic.py', CompilationTarget.DYNAMIC, 'functions')
    compile_files('functions/src/static.py', 'functions/build/static.py', CompilationTarget.STATIC, 'functions')
    compile_files('modules/src/dynamic.py', 'modules/build/dynamic.py', CompilationTarget.DYNAMIC, 'modules')
    compile_files('modules/src/static.py', 'modules/build/static.py', CompilationTarget.STATIC, 'modules')
    compile_files('modules/src/static.py', 'modules/build/static.py', CompilationTarget.STATIC, 'modules')

# Generated at 2022-06-23 22:05:55.818460
# Unit test for function compile_files
def test_compile_files():
    from .tests import get_test_resource
    from pathlib import Path

    test_root = get_test_resource('compilation')
    input_ = test_root / 'input'
    output = test_root / 'output'

    result = compile_files(input_, output, CompilationTarget.TARGET2)
    assert result.target == CompilationTarget.TARGET2
    assert result.count == 2
    assert result.time >= 0.0
    assert result.dependencies == ['__future__', 'abc']

    result = compile_files(input_, output, CompilationTarget.TARGET3)
    assert result.target == CompilationTarget.TARGET3
    assert result.count == 2
    assert result.time >= 0.0
    assert result.dependencies == ['__future__', 'abc', 'io']

    result

# Generated at 2022-06-23 22:06:00.957661
# Unit test for function compile_files
def test_compile_files():
    import pytest
    paths, dependencies = get_input_output_paths('./examples/examples/', './examples/tests/')
    for paths in paths:
        with paths.input.open() as f:
            code = f.read()
        transformed = _transform(paths.input.as_posix(), code, 1)
    with paths.output.open('w') as f:
        f.write("print('hello world')")
        assert f.read() == (transformed)

# Generated at 2022-06-23 22:06:03.088673
# Unit test for function compile_files
def test_compile_files():
    compile_files('../input/',
                  '../output/',
                  CompilationTarget.SEQ2SEQ)

# Generated at 2022-06-23 22:06:13.153283
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    root = pathlib.Path(__file__).parent.parent
    compile_files(root / 'data' / 'pypy',
                  root / 'data' / 'pypy_out',
                  CompilationTarget.PYPY, root)
    compile_files(root / 'data' / 'python2',
                  root / 'data' / 'python2_out',
                  CompilationTarget.PYTHON2, root)
    compile_files(root / 'data' / 'python3',
                  root / 'data' / 'python3_out',
                  CompilationTarget.PYTHON3, root)
    # compile_files(root / 'data' / 'pypy',
    #               root / 'data' / 'pypy_out2',
    #               CompilationTarget.PYPY

# Generated at 2022-06-23 22:06:17.698828
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    import pathlib
    import shutil
    import subprocess
    import tempfile


# Generated at 2022-06-23 22:06:19.743855
# Unit test for function compile_files
def test_compile_files():
    assert True

# Generated at 2022-06-23 22:06:29.544449
# Unit test for function compile_files
def test_compile_files():
    from .tests.env import in_temp_dir
    from .utils.helpers import is_file, path_exists

    root = in_temp_dir({
        'input': {
            'a.py': 'import b.y as c',
            'b.py': 'import c as y'
        }
    })

    compile_files(root / 'input', root / 'output', CompilationTarget.PYTHON)

    input = root / 'input'
    output = root / 'output'
    a = input / 'a.py'
    b = input / 'b.py'
    c = output / 'b.y.py'
    assert not path_exists(c)
    assert is_file(output / 'a.py')
    assert is_file(output / 'b.py')

    compile

# Generated at 2022-06-23 22:06:30.410294
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass

# Generated at 2022-06-23 22:06:32.232971
# Unit test for function compile_files
def test_compile_files():
    # Arrange
    input_ = Path('input')
    output = Path('output')


# Generated at 2022-06-23 22:06:32.808360
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:06:38.062776
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.helpers import get_full_path

    # Get paths
    root = get_full_path('tests', 'test_compile_files')
    input_ = Path.cwd() / root / 'input'
    output = Path.cwd() / root / 'output'

    # Test
    compile_files(input_, output, CompilationTarget.CPU)

    # Compare results
    for paths in get_input_output_paths(input_, output):
        with paths.input.open() as expected, \
                paths.output.open() as result:
            assert expected.read() == result.read(), \
                'Compilation failed at {}'.format(paths.input.as_posix())


# Generated at 2022-06-23 22:06:44.195370
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    import tempfile
    import shutil
    import os
    import io

    input_ = io.StringIO(
        """
        import util
        import pygame.time

        d = time.Clock()
        print(d)
        """)

    with tempfile.TemporaryDirectory() as tmpdirname:
        try:
            compile_files(input_, tmpdirname, 'pygame')
        except CompilationError as e:
            assert e.path == input_.name
            assert e.line == 4
            assert e.offset == 10
            return

    assert False, 'CompilationError should be raised'

test_compile_files()

# Generated at 2022-06-23 22:06:48.075966
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/input_dir', './tests/output_dir', CompilationTarget.PYTHON)
    assert result.duration > 0 and result.count > 0
    assert len(result.dependencies) == 4

# Generated at 2022-06-23 22:06:56.274366
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    import os
    import shutil
    import sys
    from .utils.helpers import chdir
    from .types import CompilationTarget
    import tempfile

    test_dir = os.path.abspath(os.path.dirname(__file__))

    input_dir = test_dir + '/test_case/'
    output_dir = tempfile.mkdtemp()

    try:
        with chdir(test_dir):
            compile_files(input_dir, output_dir, CompilationTarget.PYTHON)
            os.system('python ' + sys.executable + ' ' + \
                      output_dir + '/test_case.py')
    finally:
        shutil.rmtree(output_dir)

# Generated at 2022-06-23 22:06:56.853844
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:07:06.457004
# Unit test for function compile_files
def test_compile_files():
    import pytest
    if not pytest.config.getoption("--runslow"):
        pytest.skip("need --runslow option to run")

    import pathlib

    from .tests.mocks import Mocker

    from .config import compile

    input_ = pathlib.Path(__file__).parent.resolve() / 'tests' / 'mocks' / 'input'
    output = pathlib.Path(__file__).parent.resolve() / 'tests' / 'mocks' / 'output'

    mocker = Mocker(input_, output)
    mocker.mock(compile)
    result = compile_files(input_, output, CompilationTarget.ES5)
    mocker.assert_mocked()

    assert result.count == 3

# Generated at 2022-06-23 22:07:18.151807
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from .files import compile_files
    from .consts import Python3

    def test_project(target: str, project_path: str,
                     expected_files_count: int) -> None:
        input_ = Path(project_path) / 'input'
        output = Path(project_path) / 'output'
        result = compile_files(str(input_), str(output), target)
        assert result.count == expected_files_count
        assert result.target == target

    def test_transformations(target: str, project_path: str) -> None:
        input_ = Path(project_path) / 'input'
        output = Path(project_path) / 'output'
        compile_files(str(input_), str(output), target)

        # Check if

# Generated at 2022-06-23 22:07:21.982306
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/test_files/examples'
    output = 'tests/test_files/compiled'
    result = compile_files(input_, output, CompilationTarget.ES5)
    assert result.files == 9
    assert result.time < 0.2
    assert len(result.dependencies) == 2

# Generated at 2022-06-23 22:07:25.828496
# Unit test for function compile_files
def test_compile_files():
    r = compile_files('/home/chenyiran/Downloads/src/',
                      '/home/chenyiran/Downloads/result/',
                      CompilationTarget.PYTHON)
    print(r)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:07:32.994838
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError, TransformationError
    from .utils.test_utils import remove_path, assert_equal_path
    import os
    import tempfile

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()

# Generated at 2022-06-23 22:07:34.455842
# Unit test for function compile_files
def test_compile_files():
    compile_files('../code/src/', '../code/build/',
                  CompilationTarget.java)



# Generated at 2022-06-23 22:07:42.634813
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    try:
        with open(input_ + '/test.py', 'w') as f:
            f.write('import os')
            f.write('import os;import os')
            f.write('x = "\\n"')
        compile_files(input_, output, CompilationTarget.ES6)
        with open(output + '/test.js', 'r') as f:
            assert f.read() == 'import os\nimport os;import os\nlet x = "\\n"\n'
    finally:
        shutil.rmtree(input_)
        shutil.rmtree(output)

if __name__ == '__main__':
    test_comp

# Generated at 2022-06-23 22:07:44.999243
# Unit test for function compile_files
def test_compile_files():
    compile_files('test/test_input/test.py',
                  'test/test_output',
                  CompilationTarget.ES5)


# Generated at 2022-06-23 22:07:48.353689
# Unit test for function compile_files
def test_compile_files():
    from .test.test_compiler import test_failed_compilation
    from .test.test_compiler import test_compilation
    from .test.test_compiler import test_target_comparison

    test_failed_compilation()
    test_compilation()
    test_target_comparison()

# Generated at 2022-06-23 22:07:49.857293
# Unit test for function compile_files
def test_compile_files():
    print('compile_files')
    print('Not testable')


# Generated at 2022-06-23 22:07:54.431383
# Unit test for function compile_files
def test_compile_files():
    files = compile_files('tests/resources', 'tests/output', CompilationTarget.WASM)
    assert files.count == 2
    assert files.dependencies == ['python-wasm-lib', 'python-wasm-stdlib']
    assert files.target == CompilationTarget.WASM

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:08:04.330891
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from .exceptions import InputFolderNotFound

    with tempfile.TemporaryDirectory() as tmp:
        try:
            compile_files('/tmp/no_such_dir', tmp, CompilationTarget.TO_GOOGLE)
            assert False, 'Exception expected, but not raised'
        except InputFolderNotFound:
            pass

        # Compiling empty dir
        compile_files(tmp, tmp, CompilationTarget.TO_GOOGLE)

        # Compiling not empty dir
        with open(tmp + '/a.py', 'w') as f:
            f.write('1\n')
        with open(tmp + '/b.py', 'w') as f:
            f.write("""
if __name__ == '__main__':
    pass
""")

# Generated at 2022-06-23 22:08:11.534239
# Unit test for function compile_files
def test_compile_files():
    from .types import SELF
    from .transformers import ExtraAppendTransformer
    import os
    import tempfile
    import unittest

    with tempfile.TemporaryDirectory(suffix='_input') as input_:
        input_ = Path(input_)
        with tempfile.TemporaryDirectory(suffix='_output') as output:
            output = Path(output)
            input_file = input_ / 'file.py'
            output_file = output / 'file.py'


# Generated at 2022-06-23 22:08:15.009363
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("../data/input_test/input_test.py",
                         "../data/output_test",
                         CompilationTarget.TYPED)

# Generated at 2022-06-23 22:08:22.914306
# Unit test for function compile_files
def test_compile_files():
    from .files import compile_files
    from pathlib import Path
    from .types import CompilationResult
    from .exceptions import CompilationError
    import pytest

    assert compile_files('../tests/data/compile_files/input_1/', '../tests/data/compile_files/output/', 'STABLE') == CompilationResult(3, 0.009987115859985352, 'STABLE', ['../tests/data/compile_files/input_1/b.py'])
    assert compile_files('../tests/data/compile_files/input_2/', '../tests/data/compile_files/output/', 'UNSTABLE') == CompilationResult(1, 0.00697636604309082, 'UNSTABLE', [])

# Generated at 2022-06-23 22:08:32.744764
# Unit test for function compile_files
def test_compile_files():
    import os.path
    from pathlib import Path
    from tempfile import mkdtemp

    def run(input_: str, *, output: str, target: CompilationTarget, root: Optional[str] = None) -> None:
        result = compile_files(input_, output, target, root)
        if result.count != len(result.dependencies):
            raise AssertionError('result.count != len(result.dependencies)')

        if not Path(output).is_dir():
            raise AssertionError('!output.is_dir()')

        for dependency in result.dependencies:
            if not os.path.isfile(dependency):
                raise AssertionError('!is_file(dependency)')


# Generated at 2022-06-23 22:08:36.613967
# Unit test for function compile_files
def test_compile_files():
    compile_files("tests/input", "tests/output", CompilationTarget.STANDALONE_EXECUTABLE)


if __name__ == '__main__':
    # Unit test for function compile_file
    test_compile_files()

# Generated at 2022-06-23 22:08:41.146849
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    assert compile_files('./tests/src', './tests/out',
                         CompilationTarget.ES5) == CompilationResult(5, 0.0,
                         CompilationTarget.ES5, [Path('/home/nikita/Documents/prog/python/styla/styla/styla/utils/utils.js').as_posix()])
    assert compile_files(Path('./tests/src'), Path('./tests/out'),
                         CompilationTarget.ES5) == CompilationResult(5, 0.0,
                         CompilationTarget.ES5, [Path('/home/nikita/Documents/prog/python/styla/styla/styla/utils/utils.js').as_posix()])



# Generated at 2022-06-23 22:08:52.157203
# Unit test for function compile_files
def test_compile_files():
    from os import remove, makedirs
    from os.path import exists, join
    from shutil import rmtree
    from tempfile import mkdtemp
    from .files import PathToFile, PathPrefixes
    from .transformers.demo import DemoTransformer

    input_ = join(mkdtemp(), 'input')
    output = join(mkdtemp(), 'output')


# Generated at 2022-06-23 22:09:01.986995
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import shutil
    from tempfile import mkdtemp
    from pytest import raises
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .types import CompilationResult
    from .utils.helpers import debug, DEFAULT_TARGET, TARGETS

    for target in TARGETS:
        for code in [
            'import crypt',  # bad import
            'print(1/0)',    # division by zero
            'print(1//0)',   # floor division by zero
            'print(1%0)',    # modulo by zero
            '"This is bad string format" % "value"',  # bad string format
            'a = 1\na = 2',  # redefinition
        ]:
            t = target.name

# Generated at 2022-06-23 22:09:08.720233
# Unit test for function compile_files
def test_compile_files():
    root = Path(__file__).parent / '..'
    result = compile_files(root / 'tests', root / 'tests_out', CompilationTarget.ES2017)
    assert result.files == 2
    assert result.target == CompilationTarget.ES2017
    assert sorted(result.dependencies) == [
        'https://github.com/WebAssembly/wabt',
        'https://github.com/WICG/EventListenerOptions',
        'https://polyfill.io/v2/polyfill.min.js'
    ]

# Generated at 2022-06-23 22:09:12.147593
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('./tests/input', './tests/output', CompilationTarget.JS_JSON) == CompilationResult(4, 5, CompilationTarget.JS_JSON, ['a/b', 'a/b/c'])

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:22.956128
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import tempfile
    import shutil

    root = Path(tempfile.mkdtemp())

    paths = [
        ('a.py', 'b.py'),
        ('hello/a.py', 'hello/b.py'),
        ('bye/a.py', 'bye/b.py'),
    ]

    inputs = [
        'print(__name__)',
        'print(42)',
        'print("foo")',
    ]

    result = [
        'print("a")',
        'print(42)\n',
        'print("foo")\n',
    ]

    expected_root = '/' + root.as_posix()


# Generated at 2022-06-23 22:09:28.066312
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import shutil
    with tempfile.TemporaryDirectory() as td:
        shutil.copy(os.path.join(os.path.dirname(__file__),
                                 'test', 'data', 'test.py'),
                    os.path.join(td, 'test.py'))
        print('Compiling...')
        print(compile_files(td, td, CompilationTarget.Python))

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:34.215155
# Unit test for function compile_files
def test_compile_files():
    import os
    from tempfile import TemporaryDirectory
    from .files import get_output_path

    with TemporaryDirectory() as temp:
        count = 0
        for paths in get_input_output_paths('tests/compilation/source', 'tests/compilation/target',
                                            'tests/compilation/source'):
            count += 1
            assert (os.path.exists(get_output_path(paths.input, 'tests/compilation/source',
                                                   'tests/compilation/target',
                                                   'tests/compilation/source')))
        assert count == 73

        with open('tests/compilation/target/utils/__init__.py', 'r') as file:
            assert file.read() == '\n'

# Generated at 2022-06-23 22:09:34.817401
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:09:35.535381
# Unit test for function compile_files
def test_compile_files():
    pass
    # TODO



# Generated at 2022-06-23 22:09:36.023984
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:09:46.130560
# Unit test for function compile_files
def test_compile_files():
    from .transformers import VariableNameTransformer
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .config import get_config
    from .utils.tempdir import get_tempdir
    import os

    @VariableNameTransformer.register('test')
    def transform(tree):
        pass

    with TemporaryDirectory() as tempdir:
        get_config(tempdir)
        os.system('touch %s/{__init__.py,test.py}' % tempdir)
        result = compile_files(Path(tempdir).as_posix(),
                               Path(tempdir).as_posix(), 'test')
        assert result.transformation_target == 'test'
        assert len(result.dependencies) == 0


# Generated at 2022-06-23 22:09:53.039734
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("./tests/compiler/input", "./tests/compiler/output", CompilationTarget.STANDARD) == CompilationResult(count=4, time=0.0, target=CompilationTarget.STANDARD, dependencies=['typing', '_pytest', 'pytest', 'pytest_lazyfixture'])
    assert compile_files("./tests/compiler/input", "./tests/compiler/output", CompilationTarget.STANDARD) != CompilationResult(count=4, time=0.0, target=CompilationTarget.STANDARD, dependencies=['typing', '_pytest', 'pytest', 'pytest_lazyfixture', 'pytest_lazyfixture_t'])

# Generated at 2022-06-23 22:10:01.188826
# Unit test for function compile_files
def test_compile_files():
    import os
    test_script_path = os.path.realpath(__file__)
    test_dir_path = os.path.dirname(os.path.dirname(test_script_path))
    input_ = os.path.join(test_dir_path, 'test_files', 'input_files') + '/'
    output = os.path.join(test_dir_path, 'test_files', 'output_files') + '/'
    target = CompilationTarget.js

    compile_files(input_, output, target)

    # Make sure after compilation, all output files are the same
    import filecmp
    input_files_path = os.path.join(test_dir_path, 'test_files', 'input_files')

# Generated at 2022-06-23 22:10:10.274828
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/data/in', 'tests/data/out',
                           CompilationTarget.PYTHON27PLUS)
    assert result.compiled == 1
    assert result.elapsed < 1
    assert result.dependencies == ['classes.A', 'classes.B']
    assert result.target == CompilationTarget.PYTHON27PLUS
    # raise Exception(result)

    with open('tests/data/out/test.py') as f:
        code = f.read()

# Generated at 2022-06-23 22:10:16.918651
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import debug
    from .utils.mockfs import create_mock_tree, mock_fs, check_mock_tree
    from .utils.temporary import TemporaryDirectory

    class TargetA(CompilationTarget):
        pass

    class TargetB(TargetA):
        pass

    class TargetC(TargetB):
        pass

    def transform_dummy(tree: ast.AST) -> CompilationResult:
        debug(lambda: 'Transforming "{}"'.format(tree))
        if isinstance(tree, ast.Module) and tree.body:
            first_item = tree.body.pop(0)


# Generated at 2022-06-23 22:10:27.278430
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test/testdata/jsm'
    output = 'build/test_compile_files'
    result = compile_files(input_, output, CompilationTarget.web)
    dependencies = {
        'https://github.com/pazams/jsm/archive/master.tar.gz',
        'https://github.com/pazams/util/archive/master.tar.gz',
        'https://github.com/pazams/console/archive/master.tar.gz',
        'https://github.com/pazams/assert/archive/master.tar.gz',
        'https://github.com/pazams/clue/archive/master.tar.gz',
    }
    assert result.target == CompilationTarget.web
    assert result.files_count == 3
    assert result.depend

# Generated at 2022-06-23 22:10:36.984026
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from os import getcwd
    from shutil import copytree
    from collections import namedtuple

    def copy_tree(source: str, target: str):
        """Copies tree and changes python files"""
        return copytree(source, target, ignore=lambda src, names: ['__pycache__'])

    def list_files(path: str) -> List[str]:
        """List all files in tree"""
        return list(Path(path).glob('./**/*.py'))

    def get_paths(old_paths: List[str], new_dir: str) -> List[Tuple[str, str]]:
        """Changes all paths from old_dir to new_dir"""

# Generated at 2022-06-23 22:10:40.196540
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('/project/input', '/project/output',
                         CompilationTarget.JS) == CompilationResult(0, 0,
                                                                    CompilationTarget.JS,
                                                                    [])



# Generated at 2022-06-23 22:10:44.185672
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('../tests/compiler/input',
                           '../tests/compiler/output',
                           CompilationTarget.MARKDOWN)
    assert result.target == CompilationTarget.MARKDOWN
    assert result.compiled_files == 3


# Generated at 2022-06-23 22:10:53.913534
# Unit test for function compile_files
def test_compile_files():
    import os
    import filecmp
    import tempfile

    os.system("python3 compile.py --input tests/test_data/raw_data --target simple tests/test_data/test_data_res")
    assert filecmp.cmp("tests/test_data/test_data_res/test_case.py", "tests/test_data/expected_data/test_case.py")

    with tempfile.TemporaryDirectory() as tmpdir:
        os.system("python3 compile.py --input tests/test_data/raw_data --target simple {}".format(tmpdir))
        assert filecmp.cmp("{}/test_case.py".format(tmpdir), "tests/test_data/expected_data/test_case.py")

# Generated at 2022-06-23 22:11:01.121231
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import pytest
    import pycs

    @pytest.fixture
    def input_dir() -> str:
        return os.path.join('tests', 'resources')

    @pytest.fixture
    def output_dir() -> str:
        return os.path.join('tests', 'temp')

    @pytest.fixture
    def clean_output_dir(output_dir: str) -> None:
        if os.path.exists(output_dir):
            shutil.rmtree(output_dir)

    def test_files(files: List[str], expected: Tuple[int, int, int]):
        count = 0
        for file_ in files:
            if os.path.isfile(file_):
                count += 1

# Generated at 2022-06-23 22:11:11.151217
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from unittest.mock import patch
    from .utils.helpers import get_dependencies

    class Test:
        def __init__(self, input_: str, output: str) -> None:
            self.input_ = input_
            self.output = output

    @pytest.fixture
    def test() -> Test:
        return Test(input_='input_', output='output')

    @patch('src.compiler.files.get_input_output_paths')
    @patch('src.compiler._compile_file')
    def test_compile_files(mock_compile_file: object,
                           mock_get_input_output_paths: object,
                           test: Test) -> None:
        mock_compile_file.return_value = get_depend

# Generated at 2022-06-23 22:11:18.674459
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import pytest
    import os
    def _create_temp_file(content=''):
        fd, filepath = tempfile.mkstemp()
        with open(filepath, 'w') as f:
            f.write(content)
        return os.fdopen(fd, 'w')

    input_ = _create_temp_file(content='''
        from typing import List
        from .utils import UserData
        from .types import Source

        def f(a: List[str], b: UserData) -> List[Source]:
            return ['{}_{}'.format(s[0], s[1]) for s in b.rows]
    ''')

# Generated at 2022-06-23 22:11:22.146982
# Unit test for function compile_files
def test_compile_files():
    from json import dumps
    from shutil import rmtree
    from tempfile import mkdtemp

    from . import types
    from .types import CompilationTarget

    test_target = CompilationTarget.PROGRAM

# Generated at 2022-06-23 22:11:33.653071
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import sys
    import tempfile
    import unittest
    import os.path
    from os import path
    from pyfakefs.fake_filesystem_unittest import TestCase

    from .exceptions import CompilationError

# Generated at 2022-06-23 22:11:34.281908
# Unit test for function compile_files

# Generated at 2022-06-23 22:11:38.424215
# Unit test for function compile_files
def test_compile_files():
    from .tests.fixtures import path

    result = compile_files(path('simple', 'input'),
                           path('simple', 'output'),
                           CompilationTarget.PY2)

    print('Compiled {} files in {:.4f}s for target {}'.format(
        result.count, result.seconds, result.target.value))
    print('Dependencies:')
    import os
    os.system("find {} -name '*.py'".format(path('simple', 'output')))

# Generated at 2022-06-23 22:11:44.003274
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from .tests.compiling import test_compiler
    try:
        compile_files(test_compiler.INPUT, test_compiler.OUTPUT,
                      test_compiler.TARGET, test_compiler.ROOT)
    except CompilationError as e:
        assert e.original_message == test_compiler.EXPECTED_EXCEPTION

# Generated at 2022-06-23 22:11:52.505678
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    try:
        with tempfile.TemporaryDirectory() as input_:
            with tempfile.TemporaryDirectory() as output:
                open(input_ + '/file.sample', 'w').close()
                compile_files(input_, output, CompilationTarget(version='3.4'))
                assert bool(open(output + '/file.sample', 'r').read())

    except Exception:
        print('Error')
    finally:
        shutil.rmtree(input_)
        shutil.rmtree(output)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:12:04.586682
# Unit test for function compile_files
def test_compile_files():
    import os
    import subprocess
    print('\nRunning unit test for function compile_files')
    current_dir = os.path.dirname(os.path.abspath(__file__))
    subprocess.call(['mkdir', os.path.join(current_dir, 'test_compile_files_out')])
    compile_files(os.path.join(current_dir, 'test_compile_files_in'),
                  os.path.join(current_dir, 'test_compile_files_out'),
                  CompilationTarget.PYTHON27)
    print('\nCompiled files:')
    subprocess.call(['find', os.path.join(current_dir, 'test_compile_files_out')])

# Generated at 2022-06-23 22:12:15.002661
# Unit test for function compile_files
def test_compile_files():
    input_ = "test_files/test_compilers.py"
    output = "test_files/test_compilers_compiled.py"
    target = CompilationTarget.PYTHON_3_6

    compilation_result = compile_files(input_, output, target)

    result_file = Path(output, input_.replace(".py", ".compiled.py"))
    assert(result_file.exists())
    assert(result_file.is_file())

    compiled_code = ""
    with result_file.open() as f:
        compiled_code = f.read()

    assert(compiled_code == "def foo(a):\n    a.foo(a, a)\n")

    result_file.unlink()

# Generated at 2022-06-23 22:12:17.219733
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/unit/data/compile/input', 'tests/unit/data/compile/output', CompilationTarget.PYTHON)


# Generated at 2022-06-23 22:12:28.118364
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from .types import CompilationTarget, CompilationResult

    input_path = Path(__file__).parent.parent.joinpath('tests/examples/input')
    output_path = Path(__file__).parent.parent.joinpath('tests/examples/output')
    target = CompilationTarget.jep

    result = compile_files(input_path, output_path, target)
    assert result.count == 2
    assert result.duration > 0
    assert result.target == target
    assert result.dependencies == ['a.py']

    with pytest.raises(CompilationError):
        compile_files('', '', target)
    with pytest.raises(ValueError):
        compile_files(input_path, output_path, 'unknown')

# Generated at 2022-06-23 22:12:38.964302
# Unit test for function compile_files
def test_compile_files():
    def test(input_, output, root):
        import astunparse
        import os

        try:
            result = compile_files(input_, output, CompilationTarget.FROM_FUNCTION)
        except:
            return False

        for path in result.dependencies:
            if not os.path.exists(path):
                return False

        for file in os.listdir(output):
            if not file.endswith('.py'):
                continue

            tree_in = ast.parse(open(input + '/' + file).read())
            tree_out = ast.parse(open(output + '/' + file).read())
            if not astunparse.unparse(tree_in) == astunparse.unparse(tree_out):
                return False
                
        return True
    

# Generated at 2022-06-23 22:12:46.304745
# Unit test for function compile_files
def test_compile_files():
    import os
    from .tests.utils import get_path_of_data_file
    from .types import CompilationResult

    input_path = get_path_of_data_file('compilation', 'input', 'input.txt')
    output_path = get_path_of_data_file('compilation', 'output', 'output.txt')

    result = compile_files(input_path, output_path,
                           CompilationTarget.WEB_BROWSER)

    expected = CompilationResult(count=1, time=0,
                                 target=CompilationTarget.WEB_BROWSER,
                                 dependencies=[get_path_of_data_file(
                                     'compilation', 'input', 'special.txt')])

    assert result == expected


# Generated at 2022-06-23 22:12:48.097138
# Unit test for function compile_files
def test_compile_files():
    compile_files('../src', '../output', CompilationTarget.BROWSER)

# Generated at 2022-06-23 22:12:55.063514
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from .utils.helpers import compare_files_content, create_test_file

    # Create files for testing
    with TemporaryDirectory() as input_dir:
        dir_path = Path(input_dir)
        create_test_file(dir_path / '__init__.py')
        create_test_file(dir_path / 'test.py', 'from six import print_')
        create_test_file(dir_path / 'test2.py', 'from six import print_\nfrom six import print_')
        create_test_file(dir_path / 'test3.py', 'import six\nprint("Hello world!")')
        create_test_file(dir_path / 'test4.py', 'from six import print_')

        # Create correct files
        correct = []


# Generated at 2022-06-23 22:13:04.373642
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import pathlib
    import string
    import random
    import os
    import shutil
    import tempfile
    import subprocess

    input_path = pathlib.Path(__file__).parent / 'test'
    output_path = tempfile.TemporaryDirectory().name
    result = compile_files(input_path, output_path, CompilationTarget.PYTHON)
    assert result.count == 2

    def remove_comments(code: str) -> str:
        return '\n'.join(filter(lambda l: not l.startswith('#'), code.split('\n')))

    # Check if compiled code matches the expected result

# Generated at 2022-06-23 22:13:14.780878
# Unit test for function compile_files
def test_compile_files():
    # TODO: add unit test here
    #raise NotImplementedError()
    try:
        import pytest
    except ImportError:
        raise ImportError('pytest package is not installed')
    from .files import get_input_output_paths, InputOutput
    from .transformers import transformers
    from .utils.helpers import debug
    from .types import CompilationTarget, CompilationResult

    class TestTransform(object):
        target = CompilationTarget.PYTHON_COMPATIBLE


# Generated at 2022-06-23 22:13:23.529528
# Unit test for function compile_files
def test_compile_files():
    import os, pytest
    from .main import main
    from pathlib import Path
    from shutil import rmtree
    from tempfile import TemporaryDirectory
    from textwrap import dedent

    with TemporaryDirectory() as tmpdir:
        # create input directory
        input_dir = Path(tmpdir) / 'input'
        input_dir.mkdir()

        # create package directory
        package_dir = input_dir / 'package'
        package_dir.mkdir()

        # create package__init__.py
        (package_dir / '__init__.py').touch()

        # create test1.py
        (package_dir / 'test1.py').write_text(dedent("""\
            def test(arg):
                return arg"""))

        # create test2.py

# Generated at 2022-06-23 22:13:31.686998
# Unit test for function compile_files
def test_compile_files():
    # Compile source code to .mm file
    from .utils.test_utils import test_with_temp_directories
    from pathlib import Path
    import pytest
    from .utils.test_utils import compile_test

    src_dir = Path(__file__).parent / 'tests' / 'data' / 'compile' / 'good'
    dest_dir = Path('/tmp') / 'test_compile_files'
    dest_dir.mkdir(parents=True, exist_ok=True)
    def run():
        result = compile_files(src_dir, dest_dir, CompilationTarget.C)
        assert result.target == CompilationTarget.C
        assert result.count > 1
        assert result.elapsed > 0
        assert result.dependencies == []

# Generated at 2022-06-23 22:13:38.223005
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import pytest

    from . import compile
    from .exceptions import CompilationError

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 22:13:45.946852
# Unit test for function compile_files
def test_compile_files():
    from .files import InputOutput
    from .transformers import add_one
    from .transformers.common import AddTwo

    class AddTwo(AddTwo):
        """Add 2."""

        @staticmethod
        def transform(tree):
            return add_one(add_one(tree))

    transformers.append(AddTwo)

    class Dummy1(object):
        """Dummy class."""

    class Dummy2(object):
        """Dummy class."""


# Generated at 2022-06-23 22:13:46.552728
# Unit test for function compile_files
def test_compile_files():
    assert False

# Generated at 2022-06-23 22:13:50.844726
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    
    with open('test_compile_files.py') as f:
        code = f.read()
    
    input_ = Path('test_compile_files.py')
    output = Path('test_compile_files.compiled.py')
    compile_files(input_, output, CompilationTarget.C)


# Generated at 2022-06-23 22:14:00.104973
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from shutil import rmtree, copytree
    from .exceptions import CompilationError, TransformationError
    import tempfile
    import contextlib

    @contextlib.contextmanager
    def compile(input_, output, target, root=None):
        with tempfile.TemporaryDirectory() as tmp:
            input_ = Path(tmp, input_)
            output = Path(tmp, output)
            input_.mkdir(parents=True)
            output.mkdir(parents=True)

            try:
                yield
            except CompilationError:
                pass

            try:
                result = compile_files(input_.as_posix(),
                                       output.as_posix(),
                                       target, root)
            except TransformationError:
                pass

# Generated at 2022-06-23 22:14:09.857841
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import tempfile
    import shutil
    import os
    import pathlib
    import pytest

    tests_root = pathlib.Path(__file__).parent.resolve()
    tests_input = tests_root / 'test_data'
    tests_output = tests_root / 'test_output'

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir_path = pathlib.Path(temp_dir)
        temp_output = temp_dir_path / 'test_output'
        test_file_name = 'test.py'
        expected_file_name = 'expected.py'
        compilation_command_name = 'compile'
        compilation_command_path = temp_dir_path / compilation_command_name

# Generated at 2022-06-23 22:14:10.685551
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-23 22:14:17.498887
# Unit test for function compile_files
def test_compile_files():

    def get_paths(root: str, files: List[str]) -> InputOutput:
        return InputOutput(root / files[0], root / files[1])

    class TestCase:
        input_: str
        output: str
        target: CompilationTarget
        root: str
        expected: List[List[str]]

        def __init__(self, input_: str, output: str, target: CompilationTarget,
                     root: Optional[str] = None, expected: Optional[List[List[str]]] = None):
            self.input_ = input_
            self.output = output
            self.root = root or input_
            self.target = target

            if expected:
                self.expected = expected

# Generated at 2022-06-23 22:14:27.063844
# Unit test for function compile_files
def test_compile_files():
    import os.path
    import sys
    import os
    import pty
    import time
    import json
    import subprocess
    import importlib

    # Compile example module
    example_compiled_module_name = 'example_module_compiled'
    print(compile_files(
        os.path.join(os.path.dirname(__file__), '..', 'example'),
        os.path.join(os.path.dirname(__file__), '..', 'target'),
        "TEST", os.path.join(os.path.dirname(__file__), '..')))

    # Run compiled example module
    # Stdout and stderr are not written to the terminal (not to mess up ours)
    # Process output is written to the terminal
    pid, fd = pty.fork

# Generated at 2022-06-23 22:14:35.956546
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pytest import raises
    import os

    ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    INPUT = os.path.join(ROOT, 'tests', 'test_compiler')
    OUTPUT = os.path.join(ROOT, 'tests', 'output')

    def assert_compilation_error(pyfile: str, lineno: int, offset: int):
        assert raises(CompilationError,
                      compile_files, INPUT, OUTPUT, CompilationTarget.STD_LIB,
                      root=ROOT).match('{}:{}:{}'.format(pyfile, lineno, offset))


# Generated at 2022-06-23 22:14:42.623698
# Unit test for function compile_files
def test_compile_files():
    from .test.test_compile import test_app
    import tempfile

    _, input_dir = tempfile.mkstemp(dir='.')
    _, output_dir = tempfile.mkstemp(dir='.')

    test_app(input_dir=input_dir,
             output_dir=output_dir,
             graph_dir='./test/test_compile/graphs',
             target=CompilationTarget.PY_TO_JL)