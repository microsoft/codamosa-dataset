

# Generated at 2022-06-23 22:04:46.272714
# Unit test for function compile_files
def test_compile_files():
    import sys
    import functools
    sys.exit = functools.partial(print, "Error")

    print("Starting unit test")
    compile_files("tests/input", "tests/output", CompilationTarget.PASS)
    print("Unit test successful")

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-23 22:04:55.895857
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    import shutil
    import tempfile

    def test_compile(input_: str, output: str, target: CompilationTarget,
                     root: str) -> CompilationResult:
        try:
            return compile_files(input_, output, target, root)
        finally:
            for path in sys.path:
                if path.startswith(root):
                    sys.path = [x for x in sys.path if x != path]
                    try:
                        shutil.rmtree(path)
                    except:
                        pass

    def check_result(result: CompilationResult, expected_dependencies: List[str]):
        assert isinstance(result, CompilationResult)
        assert isinstance(result.count, int)
        assert isinstance(result.time, float)
        assert result

# Generated at 2022-06-23 22:05:00.594428
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/data', './tests/out',
                           CompilationTarget.python_36)
    assert result.count == 2
    assert result.target == CompilationTarget.python_36
    assert result.dependencies == ['dataclasses', 'typing']
    assert result.time_taken > 0


# Generated at 2022-06-23 22:05:05.317655
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/fixtures/test_compilations.txt'
    output = '/tmp/output'
    compile_files(input_, output, CompilationTarget.TEST)
    compile_files(input_, output, CompilationTarget.STUDENT)

# Generated at 2022-06-23 22:05:15.841251
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/hamlet', 'tests/data/output', CompilationTarget.PYTHON37)
    print(compile_files('tests/data/hamlet', 'tests/data/output', CompilationTarget.PYTHON37))
    assert compile_files('tests/data/hamlet', 'tests/data/output', CompilationTarget.PYTHON37, 'tests/data')
    print(compile_files('tests/data/hamlet', 'tests/data/output', CompilationTarget.PYTHON37, 'tests/data'))
    assert compile_files('tests/data/hamlet', 'tests/data/output', CompilationTarget.PYTHON35)

# Generated at 2022-06-23 22:05:22.737603
# Unit test for function compile_files
def test_compile_files():
    from .stubs import compile_tree
    from .transformers import StubInitTransformer, StubAssertionsTransformer
    from .types import CompilationTarget
    from .utils.testing import get_recursive_dependencies
    from .examples import SIMPLE_EXAMPLE_PATH, COMPLEX_EXAMPLE_PATH
    from tempfile import TemporaryDirectory

    for example in [SIMPLE_EXAMPLE_PATH, COMPLEX_EXAMPLE_PATH]:
        with TemporaryDirectory() as tmpdir:
            result = compile_files(example, tmpdir, CompilationTarget.TEST,
                                   example)

            assert result.files_count > 0
            assert result.time_passed > 0.0
            assert result.target == CompilationTarget.TEST
            assert len(result.dependencies) > 0

            _, compiled_tree = compile

# Generated at 2022-06-23 22:05:28.053082
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    input_ = "/home/lena/temp/input"
    output = "/home/lena/temp/output"
    target = "ast"
    root = "/"
    assert compile_files(input_, output, target, root) == CompilationResult(
        count, time() - start, target, sorted(dependencies))

# Generated at 2022-06-23 22:05:37.957927
# Unit test for function compile_files
def test_compile_files():
    from .files import InputOutput
    from .transpilers.lib_core.types import CoreType
    target = CoreType.ES6
    input_ = 'tests/data/compile'
    output = 'tests/data/output'
    root = 'tests/data'
    paths = [
        InputOutput('tests/data/compile/a.py', 'tests/data/output/a.py'),
    ]

    result = compile_files(input_, output, target, root)
    assert result.count == 1
    assert paths[0].output.exists()
    assert result.dependencies == ['functools', 'itertools', 'operator']

# Generated at 2022-06-23 22:05:45.839475
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    import shutil
    import tempfile
    import unittest
    from pathlib import Path

    class CompileFunctionTest(unittest.TestCase):
        def setUp(self):
            self.root_dir = tempfile.mkdtemp()
            self.test_input_dir = Path(self.root_dir).joinpath('input')
            self.test_output_dir = Path(self.root_dir).joinpath('output')
            self.test_input_dir.mkdir()
            self.test_output_dir.mkdir()

            self.error_path = self.test_input_dir.joinpath('error.py')
            self.error_path.write_text('print(\'error\')+')


# Generated at 2022-06-23 22:05:55.286453
# Unit test for function compile_files
def test_compile_files():
    import os
    import subprocess

    # TEST 1:
    root_dir = os.getcwd()
    subprocess.run('python3 -m  py_make_file.files.files_generator {0} {0}/tests/files'.format(root_dir), shell=True)
    result = compile_files('tests/files/input', 'tests/files/output', CompilationTarget.GLFW)
    assert result.count == 2
    assert result.dependencies == ['glfw', 'numpy']
    assert result.target == CompilationTarget.GLFW

    # TEST 2:
    try:
        compile_files('tests/files/input/semicolon.py', 'tests/files/output/semicolon.py', CompilationTarget.GLUT)
    except CompilationError:
        assert True

# Generated at 2022-06-23 22:06:02.775452
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .utils.test_utils import TempFile
    import os

    def check(source: str, target: CompilationTarget, expected: str):
        with TempFile('.py') as tmp:
            with tmp.open('w') as f:
                f.write(source)
            result = compile_files(tmp.name, tmp.name, target)
            with open(tmp.name) as f:
                actual = f.read()
            assert actual == expected, '\n\n{}\n\n------\n\n{}\n'.format(actual, expected)
        return result

    # simple function
    check('def foo(x):\n  return x + 1', CompilationTarget.PY27, 'def foo(x): return x + 1')

# Generated at 2022-06-23 22:06:12.925732
# Unit test for function compile_files
def test_compile_files():
    input_ = pathlib.Path(__file__).parent.joinpath('files', 'test_files').as_posix()
    output = input_ + '_output'
    result = compile_files(input_, output, CompilationTarget.duck)
    #file1.py
    with open(output + '/file1.py', 'r') as f:
        result_file1 = f.read()
    with open(input_ + '/file1.py', 'r') as f:
        expected_file1 = f.read()
    assert result_file1 == expected_file1
    #file2.py
    with open(output + '/file2.py', 'r') as f:
        result_file2 = f.read()

# Generated at 2022-06-23 22:06:17.241208
# Unit test for function compile_files
def test_compile_files():
    from .test.test_helpers import compare_files
    from .test.test_compile_files_input import input_, output, target, root
    compare_files(compile_files(input_, output, target, root),
                  input_, output)

# Generated at 2022-06-23 22:06:24.990511
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from pathlib import Path
    from shutil import rmtree
    import sys

    with tempfile.TemporaryDirectory() as tempdir:
        tempdir = Path(tempdir)
        outdir = tempdir.joinpath('out')
        sys.path.insert(0, str(outdir))

        testfile = tempdir.joinpath('test.py')
        testfile.write_text('1\n2\n3\n')

        compile_files(str(tempdir), str(outdir), CompilationTarget.PY2)

        resultfile = outdir.joinpath('test.py')
        assert resultfile.read_text() == '3\n'

        try:
            import test
            assert test.MAIN() == 6
        except:
            rmtree(str(outdir))


# Generated at 2022-06-23 22:06:34.092831
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile

    input_folder = os.path.join(os.path.dirname(__file__), '..', 'data')
    output_folder = tempfile.mkdtemp()

    result = compile_files(input_folder, output_folder, CompilationTarget.COMMON)

    assert result.count == 3
    assert result.target == CompilationTarget.COMMON

    assert os.path.exists(os.path.join(output_folder, 'test.py'))
    with open(os.path.join(output_folder, 'test.py'), 'r') as f:
        content = f.read()
        assert content == 'import json\nimport sys\na = [1, 2, 3]\njson.loads(sys.argv[0])\n'


# Generated at 2022-06-23 22:06:42.218569
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/input/a', 'tests/data/output/a',
                         CompilationTarget.python2) == CompilationResult(
                             3, 0.0, CompilationTarget.python2, [])
    assert compile_files('tests/data/input/b', 'tests/data/output/b',
                         CompilationTarget.python2) == CompilationResult(
                             1, 0.0, CompilationTarget.python2, [])
    assert compile_files('tests/data/input/c', 'tests/data/output/c',
                         CompilationTarget.python2) == CompilationResult(
                             1, 0.0, CompilationTarget.python2, [])

# Generated at 2022-06-23 22:06:47.547610
# Unit test for function compile_files
def test_compile_files():
    import os
    os.chdir('../')
    print(compile_files('e2e/source', 'e2e/compiled',
                        CompilationTarget.ES5))


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:06:52.955274
# Unit test for function compile_files
def test_compile_files():
    input_ = "samples/src"
    output = "tests/output/src"
    result = compile_files(input_, output, CompilationTarget.STANDALONE)
    assert result.files_compiled == 10
    assert result.execution_time > 0
    assert result.target == CompilationTarget.STANDALONE
    assert result.dependencies == ['copy', 'inspect', 'os', 'pickle', 'sys']



# Generated at 2022-06-23 22:07:03.581038
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import subprocess
    import tempfile

    cwd = Path('.', '_tests')
    input_ = cwd / 'input'
    output = cwd / 'output'
    assert input_.is_dir()
    assert not output.exists()

    result = compile_files(input_, output, CompilationTarget.PYX)
    assert result.count == 9
    assert output.is_dir()

    # pytest cannot handle compilation errors due function-scoped 'finally'
    temp = tempfile.TemporaryFile('r+')
    # subprocess.check_call(['tree', '-d', output], stdout=temp)
    subprocess.check_call(['tree', output], stdout=temp)
    temp.seek(0)
    print(temp.read())

   

# Generated at 2022-06-23 22:07:06.893354
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('../tests/fixtures/input', '../tests/fixtures/output', CompilationTarget.PYTHON36, root='../tests')
    assert result.count == 1
    assert result.time > 0
    assert result.dependencies == ['typing']


# Generated at 2022-06-23 22:07:18.598674
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import jsontree
    import os

    # Create test directory
    if os.path.isdir('testdir'):
        shutil.rmtree('testdir')
    os.mkdir('testdir')
    os.makedirs('testdir/input/a/b/c/d')
    os.makedirs('testdir/output/a/b/c/d')
    os.chdir('testdir')

    # Prepare file contents

# Generated at 2022-06-23 22:07:27.662342
# Unit test for function compile_files
def test_compile_files():
    """Compiles all files from input_ to output."""
    message = """Results are wrong!
CompilationResult(count, time() - start, target,
                             sorted(dependencies))"""
    input_ = "input_"
    output = "output"
    target = "target"
    root = "root"
    result = compile_files(input_, output, target, root)
    assert result.count == CompilationResult(input_, output, target, root).count, message
    assert result.time == CompilationResult(input_, output, target, root).time, message
    assert result.target == CompilationResult(input_, output, target, root).target, message
    assert result.dependencies == CompilationResult(input_, output, target, root).dependencies, message
    print("test_compile_files: passed")

# Generated at 2022-06-23 22:07:31.002201
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("./tests/data/input", "./tests/data/output",
                           CompilationTarget.DEFAULT)
    assert result.count == 1
    assert len(result.dependencies) == 1
    assert result.target == CompilationTarget.DEFAULT
    assert isinstance(result.time, float)
    assert result.time > 0

# Generated at 2022-06-23 22:07:35.070509
# Unit test for function compile_files
def test_compile_files():
    io = get_input_output_paths('tests/resources/tests/1.bytestring',
                                'tests/resources/tests/1.py',
                                'tests/resources')
    assert len(io) == 1
    assert _compile_file(io[0], CompilationTarget.TO_STRING) == ['bytestring']
    # TODO: Write more tests

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:07:40.723998
# Unit test for function compile_files
def test_compile_files():
    from .examples.sample_04_web import precompile
    import os
    import shutil

    root = os.path.abspath("tests/tmp/compiler")

    os.makedirs(root, exist_ok=True)
    shutil.copytree("tests/utils/compiler_test/source", os.path.join(root, "source"))
    shutil.copytree("tests/utils/compiler_test/inc", os.path.join(root, "inc"))

    result = compile_files(os.path.join(root, "source"),
                           os.path.join(root, "output"),
                           CompilationTarget.PYTHON_BYTECODE,
                           root)
    assert result.count == 3
    assert result.target == CompilationTarget.PYTHON_BY

# Generated at 2022-06-23 22:07:50.092690
# Unit test for function compile_files
def test_compile_files():
    import sys
    import pkg_resources
    import pytest
    import requests
    import platform
    sys.path.append('./tests/')
    import compile_test

    # Find how many tests to run
    if 'CI' in os.environ:
        # Travis CI doesn't support Python 3.6, so fake this test there.
        test_cases = 5
    else:
        test_cases = len(os.listdir('./tests/')) - 1

    # Format:
    #   [ (file_name, test) ]
    test_list = []

# Generated at 2022-06-23 22:07:57.713301
# Unit test for function compile_files
def test_compile_files():
    from .compile import compile_files
    from .exceptions import CompilationError
    from pytest import raises

    INPUT = 'tests/input/'
    OUTPUT = 'tests/output_compile_files/'
    TARGET = CompilationTarget.PYTHON

    # with raises(CompilationError) as e:
    #     compile_files(INPUT, OUTPUT, TARGET)

    # assert e.value.path == 'tests/input/invalid.py'
    # assert e.value.target == TARGET
    # assert e.value.line == 5
    # assert e.value.column == 37
    compile_files(INPUT, OUTPUT, TARGET)


if __name__ == '__main__':
    import sys
    import argparse

    root = None

    parser = argparse.Arg

# Generated at 2022-06-23 22:08:04.951699
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from ._utils.compiler import compile_files
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmpdirname:
        compile_files('mock_files/objdump', Path(tmpdirname), CompilationTarget.JAVASCRIPT)
        with open(os.path.join(tmpdirname, 'main.js')) as f:
            result = f.read()
            assert result == 'var main = function(a, b) {\n    return a + b;\n}\n'

# Generated at 2022-06-23 22:08:11.251429
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pytest import raises
    from shutil import rmtree
    from tempfile import mkdtemp

    tmpd = mkdtemp()
    code = tmpd + '/code/'
    input_ = code + 'input/'
    output = code + 'output/'
    input_file = input_ + 'file.py'


# Generated at 2022-06-23 22:08:15.226661
# Unit test for function compile_files
def test_compile_files():
    # TODO
    compile_files("src/tests/test-data/temp/t1.py", "src/tests/test-data/temp/tout.py", CompilationTarget.Python)
    assert True

# Generated at 2022-06-23 22:08:23.006643
# Unit test for function compile_files
def test_compile_files():
    import shutil, tempfile
    tempdir = tempfile.mkdtemp()
    try:
        shutil.copytree('./tests/test_data', tempdir+'/test_data')
        shutil.copytree('./cr/stdlib', tempdir+'/stdlib')
        print(compile_files(tempdir+'/test_data', tempdir, CompilationTarget.PYTHON2))
        for r, d, f in os.walk(tempdir+'/test_data'):
            for name in [os.path.join(r, n) for n in f]:
                if name.endswith(".py"):
                    assert os.path.isfile(name+"c")
        shutil.rmtree(tempdir)
    except:
        import sys
        sys.exit(1)

# Generated at 2022-06-23 22:08:32.819625
# Unit test for function compile_files
def test_compile_files():
    from .main import parse_args
    from .tests.extended import setup, teardown
    from .tests.io import create_temp_file
    from .target import get_compilation_target

    config_file, input_, output_ = setup('function', 'test_compile_files')

# Generated at 2022-06-23 22:08:34.913252
# Unit test for function compile_files
def test_compile_files():
    compile_files('./cst/__init__.py', './cst/__init__.py', CompilationTarget.RELEASE)

# Generated at 2022-06-23 22:08:42.710746
# Unit test for function compile_files
def test_compile_files():
    import pytest, os
    from pathlib import Path
    from .exceptions import CompilationError
    from .files import get_input_output_paths, InputOutput
    from .transformers import transformers

    def _transform(path: str, code: str, target: CompilationTarget) -> Tuple[str, List[str]]:
        tree = ast.parse(code, path)
        debug(lambda: 'Initial ast:\n{}'.format(dump(tree)))
        dependencies = []  # type: List[str]

        for transformer in transformers:
            if transformer.target < target:
                debug(lambda: 'Skip transformer "{}"'.format(transformer.__name__))
                continue

            debug(lambda: 'Use transformer "{}"'.format(transformer.__name__))

            working_tree = deepcopy(tree)


# Generated at 2022-06-23 22:08:54.125501
# Unit test for function compile_files
def test_compile_files():
    """Unit tests for compile_files"""
    from .files import input_output_paths_to_trees, io_tree_to_string
    from .transformers import bla
    from .exceptions import TypingError

    pth1 = "one/two/three/hello.bla"
    pth2 = "four/five/six/world.lol"

    def compile_files(input_: str, output: str, target: CompilationTarget,
                      dependencies: Optional[str] = None) -> str:
        """Helper to use trees of files"""
        roots = input_output_paths_to_trees(input_, output)
        compile_files(roots, target)
        return io_tree_to_string(roots, dependencies)

    # Test import

# Generated at 2022-06-23 22:09:03.220665
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as d:
        input_ = Path(d) / 'input'
        input_.mkdir(parents=True)

        with open(input_ / 'f1.py', 'w') as f:
            f.write('def f1():\n\treturn 1\n')

        result = compile_files(input_.as_posix(), input_.as_posix(),
                               CompilationTarget.js)
        assert result.count == 1
        assert result.dependencies == []

        subdir = input_ / 'subdir'

        with open(subdir / 'f2.py', 'w') as f:
            f.write('from f1 import *\n\n')

# Generated at 2022-06-23 22:09:08.594435
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/test_files/test_compile', './tests/test_files/test_compile_output', CompilationTarget.JS)
    
    assert result.count == 3
    assert result.target == CompilationTarget.JS
    assert result.dependencies == ['assert', 'buildins', 'math']


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:16.938762
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    def assert_compile(input_: str, output: str, target: CompilationTarget,
                       dependencies: List[str] = []):
        c = compile_files(input_, output, target)
        assert c.target == target
        assert c.dependencies == dependencies
        assert os.path.exists(os.path.join(output, 'foo.js'))


# Generated at 2022-06-23 22:09:23.456316
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    input_path = tempfile.TemporaryDirectory()
    output_path = tempfile.TemporaryDirectory()
    input_.mkdir(parents=True)
    output_.mkdir(parents=True)
    simple_file = input_path + "file.py"
    simple_file.write_text("print(1)\n")
    result = compile_files(input_path, output_path)
    assert result.count == 1
    assert result.target == 'jinja'
    assert result.dependencies == []
    assert result.time > 0

# Generated at 2022-06-23 22:09:29.626084
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/data/comprehensions'
    output = '/tmp/compilation-test'
    target = CompilationTarget.PY39
    result = compile_files(input_, output, target)
    print("Compilation result: " + str(result))
    assert result.count == 2

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-23 22:09:39.103856
# Unit test for function compile_files
def test_compile_files():
    from .transformers import Transformer
    from .test import DATA_PATH
    import astunparse
    import os

    with open(os.path.join(DATA_PATH, 'sample.py'), encoding="utf8") as sample:
        sample_code = sample.read()

    with open(os.path.join(DATA_PATH, 'sample_output.py'), encoding="utf8") as sample:
        sample_output = sample.read()

    original = open(os.path.join(DATA_PATH, 'sample.py'), encoding="utf8")
    tree = ast.parse(original.read())
    original.close()

    Transformer.target = Transformer.Target.DEFAULT

    def _transform(code):
        tree = ast.parse(code)
        for transformer in transformers:
            result = transformer.transform(tree)

# Generated at 2022-06-23 22:09:45.534057
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    try:
        with open(temp_dir.name + "/foo.py", "w") as f:
            f.write("""
z = [1,2,3]
print(z)
""")
        compile_files(temp_dir.name, temp_dir.name, CompilationTarget.X86_32)
    finally:
        temp_dir.cleanup()

# Generated at 2022-06-23 22:09:50.492854
# Unit test for function compile_files
def test_compile_files():
    input_ = './.test_compile_files/a'
    output = './.test_compile_files/b'
    target = CompilationTarget.BC
    root = './.test_compile_files'
    result = compile_files(input_, output, target, root)
    assert result.target == target
    assert result.dependencies == ['test_compile_files.py']

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-23 22:09:59.395497
# Unit test for function compile_files
def test_compile_files():
    r = compile_files('tests/inputs', 'tests/outputs', CompilationTarget.ES5)
    assert r.target is CompilationTarget.ES5
    assert r.compiled == 6
    assert 14.0 < r.time < 20.0

# Generated at 2022-06-23 22:10:09.839802
# Unit test for function compile_files
def test_compile_files():
    def _test(code: str, target: CompilationTarget, expected: str) -> None:
        """Compiles a file and asserts that it matches the expected code."""
        with NamedTemporaryFile() as input_file:
            with NamedTemporaryFile(delete=False) as output_file:
                input_file.write(code.encode('utf-8'))
                input_file.seek(0)
                compile_files(input_file.name, output_file.name, target)
                with open(output_file.name) as f:
                    assert f.read() == expected

    _test("""
input()
""", CompilationTarget.ES5, """
"use strict";

input();
"""
         )


# Generated at 2022-06-23 22:10:16.063044
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .files import get_files_from_directory
    from .config import get_dependencies_from_config, get_compile_target
    paths = Path(__file__).parent.joinpath('files')
    with TemporaryDirectory() as tmpdir:
        compile_files(paths.as_posix(), tmpdir, CompilationTarget.ES5)
        config_path = Path(tmpdir).joinpath('config.json')
        config = get_dependencies_from_config(config_path)
        assert get_compile_target(config) == CompilationTarget.ES5
        for file, file_path in get_files_from_directory(paths):
            file_path = file_path.with_suffix('.js')

# Generated at 2022-06-23 22:10:26.266285
# Unit test for function compile_files
def test_compile_files():
    """unit test for function compile_files"""
    input_ = Path.cwd() / 'tests' / 'typed_input'
    output = Path.cwd() / 'tests' / 'output'
    compile_files(input_, output, CompilationTarget.TYPED)
    check_output = Path.cwd() / 'tests' / 'output' / 'example.py'
    with check_output.open('r') as f:
        check_output_code = f.read()
    assert check_output_code == \
        'from typing import List, Tuple\n\ndef add(x: List[int], y: List[int]) -> List[int]:\n    return [a + b for a, b in zip(x, y)]\n\n\n'

# Generated at 2022-06-23 22:10:36.201062
# Unit test for function compile_files
def test_compile_files():
    input_ = './input/'
    output = './output/'
    compilation_target = CompilationTarget.PYTHON_TO_PYTHON
    input_file_paths = ['input\\test_py2py\\test_py2py_A.py',
                        'input\\test_py2py\\B\\test_py2py_B2.py']
    output_file_paths = ['output\\test_py2py\\test_py2py_A.py',
                         'output\\test_py2py\\B\\test_py2py_B2.py']
    dependencies = ['B']
    compilation_result = compile_files(input_, output, compilation_target)
    assert compilation_result.file_count == 2
    assert compilation_result.compilation_time >= 0
    assert compilation_

# Generated at 2022-06-23 22:10:46.789686
# Unit test for function compile_files
def test_compile_files():
    from .tests.fixtures import files
    from .tests.helpers import assert_compilation_result, cleanup
    from .tests.stubs import stub_class, stub_def, stub_for, stub_if

# Generated at 2022-06-23 22:10:56.643629
# Unit test for function compile_files
def test_compile_files():
    code = """
    import sys as s
    if s == 3:
        print(2)
    else:
        print(3)
    """
    input_ = 'input'
    output = 'output'
    with open(input, 'w') as f:
        f.write(code)
    target = CompilationTarget.PY2
    compile_files(input_, output, target, root=None)
    assert compile_files(input, output, target, root=None).count == 1
    assert compile_files(input, output, target, root=None).time > 0
    assert compile_files(input, output, target, root=None).dependencies == []
    assert compile_files(input, output, target, root=None).target == CompilationTarget.PY2

    # raise an error when input doesn't exist


# Generated at 2022-06-23 22:11:07.808211
# Unit test for function compile_files
def test_compile_files():
    from .transformers.strings_to_consts import StringsToConsts
    from .transformers.unused_statements_remover import UnusedStatementsRemover
    from .transformers.used_builtins_remover import UsedBuiltinsRemover
    from .transformers.constants_evaluation import ConstantsEvaluation
    from .transformers.constants_calculation import ConstantsCalculation
    from .transformers.unpack_assignment import UnpackAssignment
    from .transformers.additional_imports import AdditionalImports
    from .transformers.const_to_number import ConstToNumber
    from .transformers.inline_constants import InlineConstants
    from .transformers.inline_functions import InlineFunctions
    from .transformers.flatten_functions import FlattenFunctions

# Generated at 2022-06-23 22:11:15.834507
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./test/test_files', './test/test_out',
                           CompilationTarget.PYTHON27)
    assert result.count == 23
    assert result.target == CompilationTarget.PYTHON27

# Generated at 2022-06-23 22:11:26.130445
# Unit test for function compile_files
def test_compile_files():
    files = {
        'test1.py': 'a = float(input()) + 1.0',
        'test2.py': 'n = int(input())',
        'test3.py': 'a = 3.2 - 1.2',
    }

    inputs = {
        'test1.py': '1',
        'test2.py': '3',
        'test3.py': '',
    }

    outputs = {
        'test1.py': '2.0\n',
        'test2.py': '3\n',
        'test3.py': '2.0\n',
    }


# Generated at 2022-06-23 22:11:34.214497
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    input_dir = tempfile.mkdtemp()
    with open(input_dir + '/tests/helloworld.py', 'w') as f:
        f.write("print('Hello world!')")
    output_dir = tempfile.mkdtemp()
    res = compile_files(input_dir, output_dir, "WASM")
    assert len(res.dependencies) == 1
    assert res.dependencies[0] == 'stdlib.wasm'
    assert res.files_count == 1

# Generated at 2022-06-23 22:11:40.604002
# Unit test for function compile_files
def test_compile_files():
    from .context import src
    from .exceptions import CompilationError
    import os
    import shutil
    import glob
    import pytest
    testpath = src + os.sep + "test" + os.sep + "compiler" + os.sep + "test_compile_files"
    input_ = os.path.join(testpath, "in")
    output = os.path.join(testpath, "out")
    target = CompilationTarget.IOS

    # Act
    compilation_result = compile_files(input_, output, target)

    # Assert
    assert compilation_result.count == 1
    assert compilation_result.target == target
    assert compilation_result.dependencies == ['sub.subsub']

    # Cleanup

# Generated at 2022-06-23 22:11:51.256762
# Unit test for function compile_files
def test_compile_files():
    import pytest

    input_ = 'tests/data/compile_files'
    output = 'tests/data/compile_files_output'

    # Compilation target: All Transformers
    result = compile_files(input_, output, CompilationTarget.ALL)
    assert result.total_files == 5
    assert result.compilation_target == CompilationTarget.ALL
    assert result.runtime >= 0.0

    # Chech output files

# Generated at 2022-06-23 22:12:00.474056
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from shutil import rmtree

    input_ = Path(__file__).parent / 'tests/compilation' / 'inputs'
    output = Path(__file__).parent / 'tests/compilation' / 'outputs' / 'compile_files'
    rmtree(output, ignore_errors=True)

    compilation_result = compile_files(input_, output, CompilationTarget.BOTH)
    assert compilation_result.files_compiled == 3

# Generated at 2022-06-23 22:12:05.480581
# Unit test for function compile_files
def test_compile_files():
    rslt = compile_files("tests/compile/input", "tests/compile/output", CompilationTarget.COMBINED)
    assert rslt.files_compiled == 3
    assert rslt.target == CompilationTarget.COMBINED



# Generated at 2022-06-23 22:12:16.515160
# Unit test for function compile_files
def test_compile_files():
    from tempfile import mkdtemp
    import os
    import shutil

    def get_file(dir, file):
        with open(os.path.join(dir, file)) as f:
            return f.read()


# Generated at 2022-06-23 22:12:27.245388
# Unit test for function compile_files
def test_compile_files():
    class Path():
        def __init__(self, string):
            self.string = string
        def as_posix(self):
            return self.string
    paths1 = InputOutput(Path('/path/to/1.py'),
        Path('/path/to/1.py'))
    paths2 = InputOutput(Path('/path/to/2.py'),
        Path('/path/to/2.py'))
    try:
        compile_files('/path/to', '/path/to/output',
            CompilationTarget.ES5, '/path/to')
    except CompilationError as e:
        pass
    try:
        compile_files('/path/to', '/path/to/output',
            CompilationTarget.ES5, '/path/to')
    except TransformationError as e:
        pass

# Generated at 2022-06-23 22:12:38.113418
# Unit test for function compile_files
def test_compile_files():
    def create_file(path: str, content: str):
        with open(path, 'w') as f:
            f.write(content)

    # Arrange
    input_ = 'src'
    output = 'output'
    target = 'js'
    create_file('{}/file1.py'.format(input_), 'import sys')
    create_file('{}/subdir/file2.py'.format(input_), 'print(sys)')

    # Act
    compile_files(input_, output, target)

    # Assert
    for file in [ 'file1.js', 'subdir/file2.js' ]:
        path = '{}/{}'.format(output, file)
        assert os.path.isfile(path), 'File "{}" not found'.format(path)



# Generated at 2022-06-23 22:12:45.363078
# Unit test for function compile_files
def test_compile_files():
    input_ = Path(__file__).parent.joinpath('input')
    output = Path(__file__).parent.joinpath('output')
    target = CompilationTarget.JAVASCRIPT
    result = compile_files(input_, output, target)
    assert result.target.value == target.value
    assert result.input_files == 1
    assert result.compiled_files == 1
    assert result.output_files == 1
    assert result.compile_time > 0.0
    assert result.dependencies == ['pandas']

# Generated at 2022-06-23 22:12:50.436325
# Unit test for function compile_files
def test_compile_files():
    from shutil import rmtree
    rmtree('/tmp/mj2py/output')
    compile_files('/tmp/mj2py/input', '/tmp/mj2py/output', CompilationTarget.PYTHON)
    compile_files('/tmp/mj2py/input', '/tmp/mj2py/output', CompilationTarget.PYTHON)

# Generated at 2022-06-23 22:12:54.669030
# Unit test for function compile_files
def test_compile_files():
    compile_files('test_files/input/', 'test_files/output/', CompilationTarget.PYTHON)
    print("test_compile_files() passed")
test_compile_files()

# Generated at 2022-06-23 22:12:59.689764
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from .exceptions import CompilationError, TransformationError
    from .transformers import remove_print_transform

    with TemporaryDirectory() as d:
        # Simple import and print
        Path(d, 'input.py').write_text('import sys; print(1)')
        r = compile_files(d, d, CompilationTarget.PYTHON3)
        assert r.count == 1
        assert r.target == CompilationTarget.PYTHON3
        assert r.dependencies == []
        assert Path(d, 'input.py').read_text() == 'import sys; print(1)'

        # Function with print inside
        Path(d, 'input.py').write_text('def f():\n    print(1)')

# Generated at 2022-06-23 22:13:09.735741
# Unit test for function compile_files
def test_compile_files():
    source = Path('__test__/sc_module.py')
    target = Path('__test__/sc_module.js')
    compile_files(source, target, CompilationTarget.JS)
    assert target.read_text() == Path('__test__/sc_module_js.js').read_text()
    assert compile_files(source, target, CompilationTarget.JS).dependencies == []
    assert compile_files(source, target, CompilationTarget.PYPYJS).dependencies == []
    assert compile_files(source, target, CompilationTarget.JS).dependencies == []
    compile_files(source, target, CompilationTarget.JS)
    assert compile_files(source, target, CompilationTarget.PYPYJS).dependencies == []
    assert compile_files(source, target, CompilationTarget.JS).depend

# Generated at 2022-06-23 22:13:17.574771
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from .files import create_test_files

    paths = []

    input_path = Path(input)
    output = Path(input_path.stem + ".copied")
    with TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        create_test_files(temp_path, input_path, output)
        paths.append((temp_path / input_path.name, temp_path / output))

    for src, target in paths:
        compile_files(src, target, CompilationTarget.NODE)

# Generated at 2022-06-23 22:13:24.466461
# Unit test for function compile_files
def test_compile_files():
    from .test import test_dir
    from pyassert import assert_that
    from .simple import simple
    from .stdlib import stdlib
    from .stdlib import stdlib_types

    result = compile_files(
        input_=test_dir('data/test_compile_files/input_').as_posix(),
        output=test_dir('data/test_compile_files/output').as_posix(),
        target=CompilationTarget.PYTHON)
    assert_that(result.count).is_equal_to(1)
    assert_that(result.target).is_equal_to(CompilationTarget.PYTHON)

# Generated at 2022-06-23 22:13:29.730215
# Unit test for function compile_files
def test_compile_files():
    from .transformers import Python2Target
    from .tests import TARGET_TEST_INPUT, TARGET_TEST_OUTPUT
    import shutil
    try:
        shutil.rmtree(TARGET_TEST_OUTPUT)
    except FileNotFoundError:
        pass
    compile_files(TARGET_TEST_INPUT, TARGET_TEST_OUTPUT, Python2Target)



# Generated at 2022-06-23 22:13:36.516792
# Unit test for function compile_files
def test_compile_files():
    class CompilationTest(object):
        """Test case for compile_files."""

        def __init__(self, input_: str, output: str, target: CompilationTarget,
                     root: str, expected: CompilationResult):
            """Initialize test case."""
            self.input = input_
            self.output = output
            self.target = target
            self.root = root
            self.expected = expected

        def run(self):
            """Run the test case."""
            result = compile_files(self.input, self.output, self.target,
                                   self.root)
            assert result == self.expected

    # Example for test input
    input_ = '/home/chelyaev/projects/karel/examples/hw03/karel.py'

# Generated at 2022-06-23 22:13:45.059426
# Unit test for function compile_files
def test_compile_files():
    from .testing import tmp_path

    input_ = tmp_path('input')
    output = tmp_path('output')
    input_.joinpath('test.py').write_text('x=1')
    compile_files(input_, output, 1)
    assert output.joinpath('test.py').read_text() == 'x = 1\n'

    input_.joinpath('test.py').write_text('x = 1')
    compile_files(input_, output, 3)
    assert output.joinpath('test.py').read_text() == 'x = 1\n'
    output.rmtree()

    input_ = tmp_path('input')
    output = tmp_path('output')

# Generated at 2022-06-23 22:13:53.747716
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    import shutil
    from tempfile import mkdtemp
    from .files import _get_input_output_paths
    # Import module
    sys.path.insert(0, os.path.dirname(__file__))
    # Create temporary files for testing
    input_dir = mkdtemp(dir=os.getcwd())
    output_dir = mkdtemp(dir=os.getcwd())
    # Create input.py file
    input_file_path = input_dir + '/input.py'

# Generated at 2022-06-23 22:13:55.024700
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass

# Generated at 2022-06-23 22:14:05.961099
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from .files import get_python_files
    from .utils.helpers import is_blank
    from .config import Config
    from pathlib import Path
    import pytest
    import os
    import sys

    # Set up:
    # 1. Create a temporary directory
    # 2. Create a sample input directory
    # 3. Create a sample output directory
    with TemporaryDirectory() as root:
        root_path = Path(root)

        input_path = root_path / 'input'
        input_path.mkdir()

        output_path = root_path / 'output'
        output_path.mkdir()

        # Test:
        # * Check that the input and output directories are created correctly
        assert os.path.isdir(str(input_path))
        assert os.path.isdir

# Generated at 2022-06-23 22:14:15.156359
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from .tests.helpers import test_path
    from .utils import ROOT_DIR

    shutil.rmtree(test_path)
    shutil.copytree(str(ROOT_DIR / 'examples'), test_path)
    result = compile_files(
        input_=test_path, output=test_path, target=CompilationTarget.BROWSER)

    assert result.count == 6
    assert result.compilation == CompilationTarget.BROWSER
    assert result.duration > 0
    assert result.dependencies == ['examples/example.js', 'examples/lib1.js',
                                   'examples/lib2.js', 'examples/lib3.js']

# Generated at 2022-06-23 22:14:25.398136
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import tempfile
    import shutil
    import pytest

    # Create temp directory
    temp_dir = tempfile.mkdtemp()

    # Create temp code.py file
    with open(os.path.join(temp_dir, "code.py"), "w") as f:
        f.write("""\
a = 42
b = 'hello world'
    """)

    try:
        # Run py2ts under temp directory
        result = compile_files(input_=temp_dir,
                               output=temp_dir,
                               target=CompilationTarget.PYTHON3,
                               root=temp_dir)
    finally:
        # Remove temp directory
        shutil.rmtree(temp_dir)

    # Assert compilation result
    assert result.count == 1

# Generated at 2022-06-23 22:14:32.225111
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths, InputOutput
    import os

    input_ = os.path.join(os.getcwd(), 'test/')
    output = os.path.join(os.getcwd(), 'test/result/')

    result = compile_files(input_, output, CompilationTarget.PYTHON_M)

    input_ = os.path.join(os.getcwd(), '/')
    output = os.path.join(os.getcwd(), '/')


# Generated at 2022-06-23 22:14:38.773359
# Unit test for function compile_files
def test_compile_files():
    import ast
    import unittest
    import pathlib
    import typing
    import os
    import filecmp

    class Result(typing.NamedTuple):
        target: CompilationTarget
        count: int
        duration: float
        dependencies: list
        output: pathlib.Path

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.input = pathlib.Path(__file__).parent.parent / "tests" / "input"
            self.output = pathlib.Path("tmp")

# Generated at 2022-06-23 22:14:43.273913
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .utils import get_test_dir
    from .types import CompilationTarget

    for paths in get_input_output_paths(get_test_dir().as_posix(), '', '.'):
        yield _compile_file, paths, CompilationTarget.TESTS

    _compile_file(InputOutput('../tests/directives/setup.py', '../compiled_tests/directives/setup.py'),
                  CompilationTarget.TESTS)