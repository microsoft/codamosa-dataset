

# Generated at 2022-06-22 14:43:24.289340
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    tmp = tempfile.mkdtemp()

# Generated at 2022-06-22 14:43:33.007265
# Unit test for function compile_files
def test_compile_files():
    import astunparse
    import collections
    import inspect
    import json
    import os
    import textwrap
    import traceback
    from .exceptions import CompilationError
    from .transformers import ast_to_str
    from .utils.asserts import assert_code_equal

    _TEST_DATA = os.path.join(os.path.dirname(__file__), '..', '_testdata')

    class TestCase:
        def __init__(self, name, module, target, in_, out, params={}):
            self.name = name
            self.module = module
            self.target = target
            self.in_ = in_
            self.out = out
            self.params = params

        def run(self):
            print(self.name)

            params = self.params.copy()

# Generated at 2022-06-22 14:43:45.309992
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .tests import TEST_DIR
    from .utils.helpers import before_after_file_contents
    import os.path as path

    input_ = path.join(TEST_DIR, 'input')
    output = path.join(TEST_DIR, 'output')

    result = compile_files(input_, output, 
        CompilationTarget.HTML)

    assert not result.failed
    assert result.dependencies == ['tal', 'chameleon.genshi']
    assert result.count == 2
    assert result.formatted_time == '0.03'
    assert result.target == CompilationTarget.HTML

    with before_after_file_contents(input_, output) as files:
        assert files[0][0].read() == '<div tal:content="1"/>'
       

# Generated at 2022-06-22 14:43:46.329901
# Unit test for function compile_files
def test_compile_files():
    pass


# Generated at 2022-06-22 14:43:47.714404
# Unit test for function compile_files
def test_compile_files():
    # TODO: write test
    assert False


# Generated at 2022-06-22 14:43:59.476940
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.HTML
    from pathlib import Path
    from .transformers import transformers
    data_path = Path('data', 'compiler')

    for fname in data_path.glob('*.py'):
        if fname.stem.startswith('__'):
            continue

        print('=' * 80)
        print('Compile %s' % fname.stem)
        with fname.open() as f:
            code = f.read()

        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            raise CompilationError(fname.as_posix(),
                                   code, e.lineno, e.offset)

        dependencies = set()
        working_tree = ast.parse(code, fname.as_posix())

# Generated at 2022-06-22 14:44:06.582349
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import subprocess
    import sys

    def pipe(command):
        return subprocess.Popen(command, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)

    def check_output(command, stdin=None):
        p = pipe(command)
        output, error = p.communicate(stdin)
        if p.returncode != 0:
            raise subprocess.CalledProcessError(p.returncode, command,
                                                output + error)
        return output


# Generated at 2022-06-22 14:44:13.985781
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from .transformers import RemoveImportTransformer
    from .utils import log_exception
    from pylint.lint import PyLinter
    from autopep8 import fix_code
    from shutil import rmtree
    import os
    import tempfile

    def test_compile(code, target, name=None, assert_exception=None):
        tempdir = tempfile.mkdtemp()

# Generated at 2022-06-22 14:44:17.944626
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./data/input-1', './data/output-1', CompilationTarget.PYTHON30)
    assert result.files_count == 3, 'files count assertion'
    assert result.time > 0.0, 'compilation time assertion'
    assert result.target == CompilationTarget.PYTHON30, 'target assertion'
    assert result.dependencies == [], 'dependencies assertion'

# Generated at 2022-06-22 14:44:28.513263
# Unit test for function compile_files
def test_compile_files():
    class C(ast.AST):
        _fields = ('stmt',)
        _attributes = ('lineno', 'col_offset')

    def _build_ast(lineno: int, col_offset: int) -> ast.AST:
        class_ = ast.ClassDef()
        class_.name = 'A'
        class_.body = [C.stmt]
        class_.lineno = lineno
        class_.col_offset = col_offset
        return class_

    target = CompilationTarget.ES5
    cases = (
        ('line 1, column 8 (char 7)', _build_ast(1, 8)),
        ('line 2, column 8 (char 8)', _build_ast(2, 8)),
        ('line 3, column 8 (char 15)', _build_ast(3, 8)),
    )
   