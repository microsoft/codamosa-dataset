

# Generated at 2022-06-22 14:43:25.119850
# Unit test for function compile_files
def test_compile_files():
    import json
    import os
    import sys
    import tempfile
    import unittest

    class TestCase(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.input_ = tempfile.mkdtemp()
            cls.output = tempfile.mkdtemp()
            sys.path.append(cls.input_ + ':')

        @classmethod
        def tearDownClass(cls):
            sys.path.remove(cls.input_ + ':')

        def _write_source(self, name: str, code: str):
            with open(os.path.join(self.input_, name), 'w') as f:
                f.write(code)


# Generated at 2022-06-22 14:43:31.148955
# Unit test for function compile_files
def test_compile_files():
    from .config import config
    config.target = CompilationTarget.PY2

    import pytest
    with pytest.raises(AssertionError):
        compile_files('./tests/testdata/robot', './tests/testdata/robot',
                      CompilationTarget.PY2)
    compile_files('./tests/testdata/robot', './tests/testdata/normal',
                  CompilationTarget.PY2)


__all__ = ['compile_files']

# Generated at 2022-06-22 14:43:33.881892
# Unit test for function compile_files
def test_compile_files():
    compile_files(
        'test/input/python/', 'test/output/python/',
        CompilationTarget(CompilationTarget.PYTHON_3_6))
    pass


# Generated at 2022-06-22 14:43:36.678354
# Unit test for function compile_files
def test_compile_files():
    __test__ = False
    import os
    import tempfile


# Generated at 2022-06-22 14:43:45.714833
# Unit test for function compile_files
def test_compile_files():
    import pytest
    test_input_dir = pytest.helpers.TEST_ROOT / 'fixtures' / 'compiler' / 'input'
    test_output_dir = pytest.helpers.TEST_ROOT / 'fixtures' / 'compiler' / 'output'
    test_output_dir.mkdir(parents=True)
    assert compile_files(test_input_dir.as_posix(), test_output_dir.as_posix(),
                         CompilationTarget.ATOMS) == CompilationResult(
        3, 0, CompilationTarget.ATOMS, [])



# Generated at 2022-06-22 14:43:57.967697
# Unit test for function compile_files
def test_compile_files():
    from .transformers import transformers

    def test(src: str, dst: str, needed: bool, target: CompilationTarget
             ) -> None:
        result = compile_files('test_files/compile/{}'.format(src),
                               'test_files/result/{}'.format(dst),
                               target)
        if needed:
            assert result.target == target
            assert result.dependencies == ['js2py']
        else:
            assert result.target < target
            assert result.dependencies == []

    test('original.py', 'original.py', True, CompilationTarget.JS)
    test('original.py', 'original.py', True, CompilationTarget.PYTHON)
    test('original.py', 'original.py', False, CompilationTarget.PYTHON3)


# Generated at 2022-06-22 14:44:03.153804
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationResult
    from .test.test_files import fake_paths
    compile_files(fake_paths.input_, fake_paths.output,
                  CompilationTarget.DIRECT, root=fake_paths.root)

# Generated at 2022-06-22 14:44:12.164709
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 14:44:23.853861
# Unit test for function compile_files
def test_compile_files():
    from .files import input_output_paths
    from .transformers import Defaults, Names
    from .utils.helpers import get_file_content
    from tempfile import TemporaryDirectory
    from typing import Generator

    def get_files(target: CompilationTarget) -> Generator[Tuple[str, str], None, None]:
        return input_output_paths(target,
                                  'tests/samples/{}'.format(target.name),
                                  'tests/samples/{}'.format(target.name))

    with TemporaryDirectory() as tmp:
        for target in [Defaults, Names]:
            with TemporaryDirectory() as tmp_in, TemporaryDirectory() as tmp_out:
                for code, result in get_files(target):
                    with (tmp_in / code).open('w') as f:
                        f.write

# Generated at 2022-06-22 14:44:36.331630
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import json
    import typing
    import os

    def assert_compile(input_: str, output: str,
                       target: CompilationTarget) -> typing.List[str]:
        result = compile_files(input_, output, target)
        assert result.target == target
        assert result.dependencies == []
        assert result.compilation_time >= 0
        assert result.file_count == 0


# Generated at 2022-06-22 14:44:52.137787
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .transformers.logging import Logging
    from .transformers.enum import Enum
    from .transformers.time import Time
    from .transformers.sched import Sched
    from .transformers.beep import Beep
    from .transformers.random import Random
    from .transformers.input_ import Input
    from .transformers.webbrowser import WebBrowser
    from .transformers.multiprocessing import Multiprocessing
    from .transformers.socket import Socket
    from .transformers.sys import Sys
    from .transformers.shutil import Shutil
    from .transformers.platform import Platform
    from .transformers.os import OS
    from .transformers.subprocess import Subprocess
    from .transformers.math import Math
   

# Generated at 2022-06-22 14:45:03.796952
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import shutil
    from .transformers import (ModuleTypeTransformer, ModuleAttrTransformer,
                               ModuleConstTransformer)

    transformers_ = [
        ModuleTypeTransformer,
        ModuleAttrTransformer,
        ModuleConstTransformer
    ]

    # Create temporary directory
    folder = tempfile.mkdtemp()

    # Write some test files
    with open(os.path.join(folder, 'a.py'), 'w') as f:
        f.write('b = (1, 2)')
    with open(os.path.join(folder, 'b.py'), 'w') as f:
        f.write('a = None')

    # Compile files

# Generated at 2022-06-22 14:45:10.625047
# Unit test for function compile_files
def test_compile_files():
    input_ = pathlib.Path(__file__).parent / '../tests/input'
    output = pathlib.Path(__file__).parent / '../tests/output'
    target = CompilationTarget.TEST
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        compile_files(input_, output, target)

# Generated at 2022-06-22 14:45:20.831867
# Unit test for function compile_files
def test_compile_files():
    # GIVEN
    import os
    import shutil
    root = os.path.join(os.path.dirname(__file__),
                        '__tests__/functional/compilation')
    input_ = os.path.join(root, 'input')
    output = os.path.join(root, 'output')
    # WHEN
    result = compile_files(input_, output, CompilationTarget.BOTH)
    # THEN
    assert result.count == 5
    assert result.target == CompilationTarget.BOTH
    assert result.dependencies == ['app.py', 'app.py', 'app.py']
    assert os.path.exists(output)
    shutil.rmtree(output)

# Generated at 2022-06-22 14:45:29.876885
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .main import get_compiler_root
    import subprocess
    import sys
    import os

    class cd:
        def __init__(self, newPath):
            self.newPath = newPath

        def __enter__(self):
            self.savedPath = os.getcwd()
            os.chdir(self.newPath)

        def __exit__(self, etype, value, traceback):
            os.chdir(self.savedPath)

    def run_tests(compile_files, dirname, target):
        # get compiler root
        compiler_root = get_compiler_root()
        input_ = os.path.join(compiler_root, "unittest/tests/" + dirname, "input")

# Generated at 2022-06-22 14:45:41.529893
# Unit test for function compile_files
def test_compile_files():
    from .files import InputOutput
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from pathlib import Path

    # For test purposes only
    def file_path(path: str) -> Path:
        return (Path(__file__).parent / 'tests' / 'files' / path)

    def _test(input_: str, output: str, target: CompilationTarget):
        test_name = '{} -> {} ({})'.format(input_, output, target)
        debug(lambda: 'Test {}'.format(test_name))
        paths = InputOutput(file_path(input_), file_path(output))

# Generated at 2022-06-22 14:45:45.439618
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/test_input', 'test/test_output', CompilationTarget.PYTHON) == CompilationResult(0, 0, CompilationTarget.PYTHON, [])

# Generated at 2022-06-22 14:45:57.467852
# Unit test for function compile_files
def test_compile_files():
    def test_target(target: CompilationTarget):
        nonlocal root
        result = compile_files(str(input_), str(output), target,
                               str(root))
        assert result.compiled_count == 2
        assert result.target == target
        assert result.dependencies.sort()
        assert len(result.dependencies) == len(dependencies)

    root = input_ = output = Path(__file__).parent.parent.parent / 'tests'
    input_ = input_ / 'compile_files_to_test'
    output = output / 'compile_files_to_test_output'
    dependencies = set(['a', 'b'])
    test_target(CompilationTarget.PYTHON)
    test_target(CompilationTarget.JS)


# Generated at 2022-06-22 14:46:04.089538
# Unit test for function compile_files
def test_compile_files():
    import os, pytest, tempfile
    from shutil import rmtree

    @pytest.fixture
    def input_():
        return tempfile.mkdtemp()

    @pytest.fixture
    def output():
        return tempfile.mkdtemp()

    def create_files(files: List[str]):
        for file in files:
            with open(os.path.join(input_, file + '.py'), 'w') as f:
                f.write('import numpy\n'
                        'def foo():\n    pass\n'
                        'print(None)\n')
        return files

    def check(files: List[str], target: CompilationTarget):
        assert compile_files(input_, output,
                             target, root=input_).files_count == len(files)

# Generated at 2022-06-22 14:46:06.265072
# Unit test for function compile_files
def test_compile_files():
    input_ = '../examples'
    output = '../dist'
    assert compile_files(input_, output, CompilationTarget.ES5)
    assert compile_files(input_, output, CompilationTarget.ES6)



# Generated at 2022-06-22 14:46:24.145799
# Unit test for function compile_files
def test_compile_files():
    """Test compile_files function."""
    import pytest

    def _test_compile_files():
        """Test compile_files function."""
        input_dir = 'test/test_compiler/input'
        output_dir = 'test/test_compiler/output'
        target = CompilationTarget.DEFAULT
        result = compile_files(input_dir, output_dir, target)
        assert result.total == 2
        assert result.target == target
        assert result.dependencies == [
            'concurrenct.futures',
            'concurrent.futures.thread',
            'concurrent.futures.process',
            'concurrent.futures.process',
        ]


# Generated at 2022-06-22 14:46:33.298910
# Unit test for function compile_files
def test_compile_files():
    assert len(compile_files('tests/data/simple', 'tmp',
                             CompilationTarget.Python2)) == 1
    assert len(compile_files('tests/data/simple', 'tmp',
                             CompilationTarget.Python3)) == 1
    assert len(compile_files('tests/data/simple', 'tmp',
                             CompilationTarget.Python4)) == 1
    assert len(compile_files('tests/data/simple', 'tmp',
                             CompilationTarget.Python5)) == 1

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:46:41.205026
# Unit test for function compile_files
def test_compile_files():
    """A unit test for function compile_files"""
    from jsontester.testutil import current_dir, remove_dir_content, create_file
    from .compile_files import compile_files
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils.helpers import debug
    from pytest import raises

    debug(lambda: "Unit test for compile_files")

    def transformed_content(content: str) -> str:
        """Transformed content"""
        return content.replace("import", "window.import")

    input_ = current_dir("input")
    output = current_dir("output")
    remove_dir_content(input_)
    remove_dir_content(output)

    target = CompilationTarget.ES5

# Generated at 2022-06-22 14:46:51.473258
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import TransformationError
    from .utils.helpers import run_tests
    from .utils.mock_transformers import AlwaysFailTransformer

    def test_basic():
        output = run_tests('tests/in/basic', 'tests/out/basic',
                           lambda it: compile_files(it, '/tmp/out', CompilationTarget.FRONTEND))
        assert output.count == 2
        assert output.target == CompilationTarget.FRONTEND
        assert output.dependencies == []

    def test_broken_syntax():
        with pytest.raises(CompilationError):
            run_tests('tests/in/broken', 'tests/out/broken',
                      lambda it: compile_files(it, '/tmp/out', CompilationTarget.FRONTEND))


# Generated at 2022-06-22 14:46:52.410184
# Unit test for function compile_files
def test_compile_files():
    # TODO
    pass

# Generated at 2022-06-22 14:47:04.092169
# Unit test for function compile_files
def test_compile_files():
    from pytest import raises
    from .exceptions import CompilationError
    from .files import InputOutput
    from .types import CompilationTarget
    from .utils.helpers import tmp_file

    with tmp_file('a.b') as paths:
        paths.input.write_text('a')
        with raises(CompilationError):
            compile_files(paths.input.as_posix(), paths.output.as_posix(),
                          CompilationTarget.javac)

        paths.input.write_text('1 + 1')
        paths.output.unlink()
        assert compile_files(paths.input.as_posix(), paths.output.as_posix(),
                             CompilationTarget.javac) == \
            CompilationResult(1, 0, CompilationTarget.javac, [])



# Generated at 2022-06-22 14:47:14.053545
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import pathlib
    import subprocess
    import filecmp
    import os

    work_dir = tempfile.mkdtemp()

    with open('test/test_cases/test.py', 'r') as f:
        test_code = f.read()

    with open('test/test_cases/test_modified.py', 'r') as f:
        test_code_modified = f.read()

    with open('test/test_cases/test_dependency.py', 'r') as f:
        test_code_dependency = f.read()

    with open('test/test_cases/test_dependency_global.py', 'r') as f:
        test_code_dependency_global = f.read()


# Generated at 2022-06-22 14:47:18.000338
# Unit test for function compile_files
def test_compile_files():
    '''Unit test for compile_files.'''

    result = compile_files(
        input_='./test/test_input',
        output='./test/test_output',
        target=CompilationTarget.PYTHON,
    )
    assert './test/test_input/simple.py' not in result.dependencies
    assert result.count == 2

# Generated at 2022-06-22 14:47:21.147804
# Unit test for function compile_files
def test_compile_files():
    debug(lambda: 'Start compile_files test')
    try:
        result = compile_files('examples/input', 'examples/output',
                               CompilationTarget.PYTHON_26)
        assert result.success
        assert len(result.dependencies) > 0
        assert result.duration > 0.0
    except Exception as ex:
        debug(lambda: 'Compile error: {}'.format(str(ex)))
        raise

# Generated at 2022-06-22 14:47:22.460460
# Unit test for function compile_files
def test_compile_files():
    # TODO: add
    print('\nUnit test for function compile_files')

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:47:52.498997
# Unit test for function compile_files
def test_compile_files():
    # Test if single file is correctly compiled
    test1_fname = 'tests/unit_tests/test_files/test.py'
    output = 'tests/unit_tests/test_files/'
    target = CompilationTarget.PYTHON
    dependencies = compile_files(test1_fname, output, target)
    assert dependencies.count == 1
    assert dependencies.target == target

    # Test if dependencies are correctly detected
    test2_fname = 'tests/unit_tests/test_files/matrix.py'
    dependencies = compile_files(test2_fname, output, target)
    assert dependencies.count == 1
    assert dependencies.target == target
    assert len(dependencies.dependencies) == 1
    assert 'matrix' in dependencies.dependencies

    # Test if extensions are correctly detected and renamed
   

# Generated at 2022-06-22 14:48:03.242890
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory, mkdtemp
    from shutil import rmtree
    import os, sys, pytest
    from pathlib import Path
    input_ = mkdtemp()
    output = mkdtemp()
    root = mkdtemp()


# Generated at 2022-06-22 14:48:16.057320
# Unit test for function compile_files
def test_compile_files():
    from .transformers import transform_string_to_file_name
    from pathlib import Path
    from os.path import join

    result = compile_files('fixtures/main.py', 'output/main.py',
                           CompilationTarget.to_file)

    assert result.count == 1
    assert result.target == CompilationTarget.to_file
    assert result.time_elapsed > 0.0
    assert result.dependencies == ['fixtures/main.py']

    assert Path(join('output', 'main.py')).is_file()


# Generated at 2022-06-22 14:48:17.944152
# Unit test for function compile_files
def test_compile_files():
    import unittest

    class TestCompileFiles(unittest.TestCase):
        def test_compile_files(self):
            # TODO
            pass

    print('Testing function compile_files')
    unittest.main()

# Generated at 2022-06-22 14:48:24.045668
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import shutil
    result = compile_files(os.path.join(os.path.abspath(os.path.dirname(__file__)),"test_files","transformation1"), '/tmp', CompilationTarget.CLIENT)
    assert result.target == CompilationTarget.CLIENT
    assert result.compiled_files == 3
    assert set(result.dependencies) == {'a.js', 'b.js', 'c.js', 'd.js', 'e.js', 'f.js'}
    assert result.time > 0
    shutil.rmtree('/tmp')


if __name__ == '__main__':
    import sys
    if len(sys.argv) == 2 and sys.argv[1] == '--test':
        test_compile

# Generated at 2022-06-22 14:48:25.910647
# Unit test for function compile_files
def test_compile_files():
    compile_files('./tests/input/', './tests/output/', 'py2')


# Generated at 2022-06-22 14:48:38.285932
# Unit test for function compile_files
def test_compile_files():
    import pathlib, pprint, tests

    paths = pathlib.Path('tests/testdata/simple').glob('**/*.py')
    paths = [path.as_posix() for path in paths]
    paths.remove('tests/testdata/simple/__init__.py')
    result = compile_files(
        '/usr/src/app/compiler/tests/testdata/simple',
        '/usr/src/app/temp',
        CompilationTarget.PYTHON)

    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON
    assert result.compile_time > 0
    assert result.dependencies == []

    paths.remove('tests/testdata/simple/submodule/__init__.py')

# Generated at 2022-06-22 14:48:48.356042
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths, InputOutput
    from .types import CompilationTarget
    from .types import CompilationResult

    # CompilationTarget.EXECUTE = True
    # CompilationTarget.EXECUTE = False
    # assert compile_files("test_files/file_example.py", "test_files/file_example.py", CompilationTarget.EXECUTE) == CompilationResult(1, 2, CompilationTarget.EXECUTE, []), "Error in compile_files function"
    # assert compile_files("test_files/file_example.py", "test_files/file_example.py", CompilationTarget.EXECUTE) == CompilationResult(1, 2, CompilationTarget.EXECUTE, []), "Error in compile_files function"
    # assert compile_files("test_files/file

# Generated at 2022-06-22 14:48:58.917525
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import pathlib
    import shutil
    target = CompilationTarget.CFG
    input_ = pathlib.Path(__file__).parent.joinpath('test_files/')
    output_dir = tempfile.mkdtemp()
    output = pathlib.Path(output_dir)
    compile_files(input_, output, target)

    for file_ in input_.glob('*.py'):
        with open(file_) as f:
            file_content = f.read()
        with open(output.joinpath(file_.name)) as f:
            compiled_content = f.read()
        assert 'py_ast' not in compiled_content
        assert 'if_else' not in compiled_content
        assert 'compile_files' in compiled_content

# Generated at 2022-06-22 14:49:01.366362
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/simple/input', 'tests/simple/output', CompilationTarget.WITH_TYPE_COMMENTS)

# Generated at 2022-06-22 14:49:55.778939
# Unit test for function compile_files
def test_compile_files():
    import sys
    import json
    import os
    import pytest
    import tempfile
    dirpath = tempfile.mkdtemp()
    #
    try:
        filename = os.path.join(dirpath, 'test.tx')
        with open(filename, 'w') as f:
            f.write("def f():\n    x = [1,2,3]\n    return x")
        result = compile_files(dirpath, dirpath, CompilationTarget.PYTHON27, dirpath)
        assert result.target == CompilationTarget.PYTHON27
    finally:
        try:
            os.remove(filename)
            os.removedirs(dirpath)
        except:
            pass

# Generated at 2022-06-22 14:49:57.433815
# Unit test for function compile_files
def test_compile_files():
    from .test.test_compile import test_compile_files
    test_compile_files(compile_files)

# Generated at 2022-06-22 14:50:09.120179
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data', 'tmp', CompilationTarget.PYTHON) == \
        CompilationResult(1, 0.0, CompilationTarget.PYTHON, [])

    assert compile_files('tests/data', 'tmp', CompilationTarget.PYTHON, 'tests') == \
        CompilationResult(1, 0.0, CompilationTarget.PYTHON, [])

    assert compile_files('tests', 'tmp', CompilationTarget.PYTHON) == \
        CompilationResult(3, 0.0, CompilationTarget.PYTHON, [])

    assert compile_files('tests', 'tmp', CompilationTarget.PYTHON, 'tests') == \
        CompilationResult(2, 0.0, CompilationTarget.PYTHON, [])

    assert compile_files

# Generated at 2022-06-22 14:50:13.151110
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test_input', 'test_output', CompilationTarget.DEFAULT) == \
        CompilationResult(count=23, time=0.0, target=CompilationTarget.DEFAULT, dependencies=[])

# Generated at 2022-06-22 14:50:24.556032
# Unit test for function compile_files
def test_compile_files():
    from .pythran import CompilationError, TransformationError
    import os

    result = compile_files('test/test_files/test_compilation.py',
                           'temp',
                           CompilationTarget.PYTHRAN,
                           root=os.getcwd())

    assert not result.has_errors()
    assert result.ast_count == 1
    assert result.compilation_duration > 0
    assert result.target == CompilationTarget.PYTHRAN

    # test wrong input

# Generated at 2022-06-22 14:50:31.886176
# Unit test for function compile_files
def test_compile_files():
    import argparse
    argparser = argparse.ArgumentParser()
    argparser.add_argument('-t', '--target', default='C')
    argparser.add_argument('-i', '--input', default='tests/fixtures/')
    argparser.add_argument('-o', '--output', default='/tmp/o')
    args = argparser.parse_args()
    print(compile_files(args.input, args.output, args.target))

# Generated at 2022-06-22 14:50:38.871228
# Unit test for function compile_files
def test_compile_files():
    from .dist.test_utils.test_utils import TEST_DIRECTORY
    from .dist.test_utils.test_utils import DATA_DIRECTORY
    from .dist.test_utils.test_utils import TEMP_DIRECTORY
    sample = DATA_DIRECTORY / 'sample1.txt'
    assert compile_files(sample, TEMP_DIRECTORY, CompilationTarget.PY).count == 1
    assert compile_files(TEMP_DIRECTORY, TEMP_DIRECTORY, CompilationTarget.PY).count == 1


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:50:50.903049
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .utils.testutils import TestCase

    class CompileFilesTest(TestCase):
        def setUp(self):
            self.input_ = Path(self.mktemp('input'))
            self.output = Path(self.mktemp('output'))

        def test_compile_generic_file(self):
            self.input_.joinpath('foo.js').write_text('let x = [1,2,3]')
            result = compile_files(str(self.input_),
                                   str(self.output),
                                   CompilationTarget.ES5)
            self.assertEqual(self.output.joinpath('foo.js').read_text(),
                             'var x = [1, 2, 3];')
            self.assertEqual(result.count, 1)
           

# Generated at 2022-06-22 14:50:52.270494
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-22 14:51:03.669023
# Unit test for function compile_files
def test_compile_files():
    from .updaters import update_code
    import os
    import pytest
    from .exceptions import ParsingError, CompilationError

    def compile_to_py(code: str) -> str:
        return compile_files('src', 'dst', CompilationTarget.PY,
                             os.path.abspath('.')).output

    with pytest.raises(ParsingError):
        compile_to_py('1 *')

    with pytest.raises(CompilationError):
        compile_to_py('2 * 3')

    assert compile_to_py('1') == "1"


if __name__ == '__main__':
    from .version import version
    from .updaters import update_code
    import argparse
    import os
    import sys
    import time
