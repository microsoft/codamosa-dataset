

# Generated at 2022-06-22 14:43:24.545918
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths, InputOutput
    from .config import config
    from .targets import gen_target, TARGETS
    from .exceptions import CompilationError
    from .transformers import BaseTransformer
    from .utils.typing import NewType
    from .utils.paths import Path
    from pytest import raises
    from unittest import mock
    from os import remove, rename, makedirs
    from io import StringIO
    from typing import Tuple, List, Optional
    from pathlib import Path as StdPath
    from contextlib import contextmanager
    from tempfile import TemporaryDirectory

    # Mock BaseTransformer
    BaseTransformer.transform = mock.Mock(name='transform')

    # CompilationResult

# Generated at 2022-06-22 14:43:27.816777
# Unit test for function compile_files
def test_compile_files():
    result = compile_files("./compile.py", "./transformed",
                           CompilationTarget.FUNCTION, root="./")
    print(result)


if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-22 14:43:33.881582
# Unit test for function compile_files
def test_compile_files():
    import pytest

    @pytest.mark.parametrize('target', [CompilationTarget.PYTHON27,
                                        CompilationTarget.JAVASCRIPT])
    def test(tmp_path, target):
        input_ = tmp_path / 'input'
        output = tmp_path / 'output'
        input_.mkdir()
        (input_ / 'file.py').write_text('def foo(): return 1')

        compile_files(input_, output, target)

    test()

# Generated at 2022-06-22 14:43:46.331166
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile

    source = tempfile.mkdtemp()
    os.makedirs(os.path.join(source, 'a'))
    os.makedirs(os.path.join(source, 'b'))

    with open(os.path.join(source, 'a', 'foo.js'), 'w') as f:
        f.write('function foo() {\n'
                '  return bar();\n'
                '}\n')

    with open(os.path.join(source, 'a', 'bar.js'), 'w') as f:
        f.write('function bar() {\n'
                '  return "baz";\n'
                '}\n')


# Generated at 2022-06-22 14:43:58.446552
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .tests.helpers import create_file
    from .utils.helpers import get_temp_dir
    target = CompilationTarget.PYTHON
    temp = get_temp_dir('v', True)

# Generated at 2022-06-22 14:44:01.426349
# Unit test for function compile_files
def test_compile_files():
    from .transformers import remove_debug, insert_count

# Generated at 2022-06-22 14:44:02.863329
# Unit test for function compile_files
def test_compile_files():
    compile_files("/input/", "/output/", CompilationTarget.ES5)

# Generated at 2022-06-22 14:44:05.835920
# Unit test for function compile_files
def test_compile_files():
    from .test_compile import compile_dir
    compile_dir('test/test_dir', 'test/test_dir_output',
                'test/test_dir_expected')

# Generated at 2022-06-22 14:44:13.563123
# Unit test for function compile_files
def test_compile_files():
    from .files import mock_fs
    from .types import CompilationTarget, CompilationResult
    from .exceptions import CompilationError, TransformationError
    from tempfile import TemporaryDirectory
    import os

    def compile_files_test(code: str, target: CompilationTarget,
                           exc: Optional[Exception] = None) -> CompilationResult:
        td = TemporaryDirectory()

# Generated at 2022-06-22 14:44:17.872593
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('.', './build/css', CompilationTarget.css)
    assert result.count == 1
    assert result.target == CompilationTarget.css


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--target',
        choices=[target.name for target in CompilationTarget],
        required=True,
        dest='target')
    parser.add_argument('-r', '--root', default=None)
    parser.add_argument('input')
    parser.add_argument('output')
    args = parser.parse_args()
