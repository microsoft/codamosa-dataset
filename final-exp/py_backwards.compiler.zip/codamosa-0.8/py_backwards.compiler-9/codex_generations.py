

# Generated at 2022-06-22 14:43:25.733750
# Unit test for function compile_files
def test_compile_files():
    input_ = 'resources/test_files/test_files'
    output = 'resources/test_files/test_files_compiled'

    # TODO Different test for different target
    target = CompilationTarget.JAVACRIPT
    compilation_result = compile_files(input_, output, target, root='resources')

    print('Count of compiled files: {}'.format(compilation_result.count))
    print('Compilation time: {}'.format(compilation_result.time))
    print('Compilation target: {}'.format(compilation_result.target))
    print('Dependencies:')
    for dependency in compilation_result.dependencies:
        print('  - {}'.format(dependency))

    # TODO Compare files

# Generated at 2022-06-22 14:43:34.007692
# Unit test for function compile_files
def test_compile_files():
    print('test_compile_files')
    input_ = 'tests/samples/in'
    output = 'tests/samples/out'
    expected_files = ['compiled.py', '__init__.py']
    expected_dependencies = {'datetime', 'os', 'json', 'datetime', 'datetime'}

    def clean():
        """Clean output directory"""
        for path in Path(output).glob('*'):
            if path.is_dir():
                shutil.rmtree(path)
            else:
                os.unlink(path)

    clean()

    compile_files(input_, output, CompilationTarget.PYTHON)

    files = sorted([path.name for path in Path(output).glob('**/*')])

# Generated at 2022-06-22 14:43:46.543236
# Unit test for function compile_files
def test_compile_files():
    from .files import Paths
    from .transformers import FindDependencies
    from .utils.helpers import capture_stdout

    # Compile files and test that the module is found.
    compile_files('./tests/fixtures/text', './__temp__', FindDependencies.target)
    source = Paths('./__temp__/text/foo.js').input
    with capture_stdout() as (out, err):
        exec(open(str(source)).read())

    assert 'Found module "text.bar"' in out.getvalue()

    # Compile files and test that the package is found.
    compile_files('./tests/fixtures/text', './__temp__', FindDependencies.target)
    source = Paths('./__temp__/text/foo.js').input


# Generated at 2022-06-22 14:43:58.648896
# Unit test for function compile_files
def test_compile_files():
    from . import __file__
    from pathlib import Path
    from tempfile import mkdtemp
    from shutil import rmtree, move
    from .tests.tests import get_test_paths

    # build testing directory
    cwd = Path.cwd()
    temp_dir = Path(mkdtemp())
    sources_dir = temp_dir / 'sources'
    sources_dir.mkdir()
    test_dir = Path(__file__).parent
    move(test_dir / 'tests', sources_dir / 'tests')

    # compile tests
    output = temp_dir / 'output'
    output.mkdir()
    result = compile_files(sources_dir.as_posix(), output.as_posix(),
                           CompilationTarget.TESTS, cwd.as_posix())
   

# Generated at 2022-06-22 14:44:10.516314
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    import pytest

    root = os.path.abspath(os.path.dirname(__file__))
    src = os.path.join(root, 'data', 'src')
    dst = os.path.join(root, 'data', 'dst')

    try:
        shutil.rmtree(dst)
    except FileNotFoundError:
        pass

    compile_files(src, dst, CompilationTarget.STANDARD)

    for dirpath, dirnames, filenames in os.walk(dst):
        for filename in [f for f in filenames if f.endswith('.py')]:
            with open(os.path.join(dirpath, filename)) as f:
                code = f.read()
            ast.parse(code)

# Generated at 2022-06-22 14:44:22.749983
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    from .test_files import example_code, example_code_with_lambda
    with tempfile.TemporaryDirectory() as tmpdir:
        input_ = os.path.join(tmpdir, 'input')
        os.mkdir(input_)
        output = os.path.join(tmpdir, 'output')
        os.mkdir(output)
        file_name = 'example.py'
        file_path = os.path.join(input_, file_name)
        with open(file_path, 'w') as f:
            f.write(example_code)
        compile_files(input_, output, CompilationTarget.PYTHON_37)
        with open(os.path.join(output, file_name)) as f:
            assert f.read() == example

# Generated at 2022-06-22 14:44:27.279886
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    test_input = 'test/test_ast/test_files'
    
    path_out = 'test/test_ast/test_output'
    Path.mkdir(Path(path_out), exist_ok=True)
    compile_files(test_input, path_out, CompilationTarget.BOTH)

# Generated at 2022-06-22 14:44:28.108737
# Unit test for function compile_files
def test_compile_files():
    pass



# Generated at 2022-06-22 14:44:33.202777
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/test_compiler/input/',
                         'tests/test_compiler/output/',
                         CompilationTarget.PYTHON,
                         'tests/test_compiler').count == 2


# Generated at 2022-06-22 14:44:38.277959
# Unit test for function compile_files
def test_compile_files():
    c = compile_files('tests/input', 'tests/output', CompilationTarget.PY36)
    assert c.target == CompilationTarget.PY36
    assert c.duration > 0
    assert c.count == 2
    assert len(c.dependencies) == 2
    assert c.dependencies[0] == 'aiohttp'
    assert c.dependencies[1] == 'asyncio'

# Generated at 2022-06-22 14:44:50.365679
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from tempfile import mkdtemp
    from .test.example import EXAMPLE_DIR as E
    from .test.generated import GENERATED_DIR as G
    E, G = Path(E), Path(G)
    gen_dir = mkdtemp()
    try:
        compile_files(E.as_posix(), gen_dir, CompilationTarget.PYTHON3)
        assert (Path(gen_dir) / G).exists()
    finally:
        shutil.rmtree(gen_dir)



# Generated at 2022-06-22 14:44:59.776660
# Unit test for function compile_files
def test_compile_files():
    from .explanation import Explanation
    from .parser.parser import get_parser
    from .transformers.operator_transformer import Transformer as OperatorTransformer
    import os
    import pytest

    input_ = os.path.join(os.path.dirname(__file__), '../test/fixtures/input')
    output = os.path.join(os.path.dirname(__file__), '../test/fixtures/output')

    def _compile_files():
        return compile_files(input_, output, CompilationTarget.INTERPRETER,
                             input_)

    explanation = Explanation()
    parser = get_parser(explanation)
    transformer = OperatorTransformer(parser, explanation)

    # Transformer can not be set as __builtins__['__transformer__'] because
    # python

# Generated at 2022-06-22 14:45:12.487397
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile

    this_folder = os.path.dirname(os.path.abspath(__file__))

    with tempfile.TemporaryDirectory() as temp_dir:
        input_ = os.path.join(temp_dir, 'a')
        os.makedirs(input_, exist_ok=True)

        output = os.path.join(temp_dir, 'b')
        os.makedirs(output, exist_ok=True)

        shutil.copy(os.path.join(this_folder, 'files/simple.py'),
                    os.path.join(input_, 'simple.py'))

# Generated at 2022-06-22 14:45:13.317450
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-22 14:45:24.728222
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('/tmp/r', '/tmp/r', CompilationTarget.ES5).count == 0
    assert 'json_dump' in compile_files('tests/fixtures/', '/tmp/r',
                                        CompilationTarget.ES5).dependencies
    assert ('_json_dump' in compile_files('tests/fixtures/', '/tmp/r',
                                          CompilationTarget.ES5).dependencies
            and 'json' in compile_files('tests/fixtures/', '/tmp/r',
                                        CompilationTarget.ES5).dependencies)

# Generated at 2022-06-22 14:45:31.800754
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    import pytest

    tmp = tempfile.mkdtemp()

# Generated at 2022-06-22 14:45:42.065962
# Unit test for function compile_files
def test_compile_files():
    def check(input_: str, output: str, root: Optional[str] = None,
              target: CompilationTarget = CompilationTarget.PROD) -> None:
        assert compile_files(input_, output, target, root)

    check('tests/data/tests_for_compilation', 'tests/data/compiled/output')
    check('tests/data/tests_for_compilation', 'tests/data/compiled/output',
          target=CompilationTarget.DEBUG)
    check('tests/data/tests_for_compilation', 'tests/data/compiled/output',
          root='tests/data/tests_for_compilation')


# Generated at 2022-06-22 14:45:53.347028
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as tmp_dir:
        # Write source file
        source_path = os.path.join(tmp_dir, 'a.py')
        with open(source_path, 'w') as f:
            f.write('print(0)')

        # Write target file
        target_path = os.path.join(tmp_dir, 'b.py')
        assert not os.path.exists(target_path)

        result = compile_files(source_path, target_path, CompilationTarget.C)

        # Read newly compiled file
        with open(target_path) as f:
            compiled = f.read()
        assert compiled == 'print 0\n'
        assert len(result.dependencies) == 0

        # Write source file again
       

# Generated at 2022-06-22 14:45:59.462751
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget

    result = compile_files(
        input_ = 'test/test_files/input/',
        output = 'test/test_files/output/',
        target = CompilationTarget.PYTHON35,
        root = 'test/test_files/'
    )
    assert result.count == 4
    assert result.target == CompilationTarget.PYTHON35
    assert sorted(result.dependencies) == ['dep2', 'dep3', 'dep4']

# Generated at 2022-06-22 14:46:08.890403
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .utils.test_utils import read_file
    from .transformers.string import translate_b_strings
    from .transformers.types import add_type_hints
    from pathlib import Path

    result = compile_files('tests/input', 'tests/output/test_compile_files',
                           CompilationTarget.PYTHON_3_7)

    expected = read_file('tests/expected/test_compile_files.py')
    actual = read_file(Path('tests/output/test_compile_files.py'))

    assert result.count == 1
    assert expected == actual



# Generated at 2022-06-22 14:46:22.115361
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from pathlib import Path
    from shutil import rmtree
    from tempfile import mkdtemp
    from .examples import examples
    from .utils.helpers import red

    temp = Path(mkdtemp())
    debug(lambda: 'Using temporary directory "{}"'.format(temp))


# Generated at 2022-06-22 14:46:26.222625
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import filecmp
    test_path = Path("tests/test_compile/files")
    output_path = test_path / "output"
    compile_files(str(test_path), str(output_path), CompilationTarget.PYTHON)
    files = filecmp.dircmp(str(test_path / "expected"), str(output_path))
    assert not files.diff_files
    shutil.rmtree(output_path)

# Generated at 2022-06-22 14:46:30.608279
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/basic/input', 'output', CompilationTarget.ES5) == CompilationResult(
        count=3, time=0.0, target=CompilationTarget.ES5, dependencies=[])

# Generated at 2022-06-22 14:46:31.580188
# Unit test for function compile_files
def test_compile_files():
    assert True

# Generated at 2022-06-22 14:46:34.961437
# Unit test for function compile_files
def test_compile_files():
    from .test import test_file_path
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    shutil.copytree(test_file_path('test_files'),
                    os.path.join(temp_dir, 'test_files'))

    try:
        compile_files(os.path.join(temp_dir, 'test_files'),
                      os.path.join(temp_dir, 'output'),
                      CompilationTarget.JS)
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-22 14:46:46.513220
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from .types import CompilationResult

    dir_ = TemporaryDirectory('test-dir')

    with open(dir_.name + '/foo.js', 'w') as f:
        f.write('foo();')

    with open(dir_.name + '/bar/foo.js', 'w') as f:
        f.write('foo(); bar();')

    with open(dir_.name + '/bar/baz.js', 'w') as f:
        f.write('var a = 1;')

    dir_path = Path(dir_.name)
    compile_files(str(dir_path / 'foo.js'), str(dir_path / 'out'),
                  CompilationTarget.ES5)

# Generated at 2022-06-22 14:46:53.996770
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import difflib
    import tempfile

    class TempPaths(InputOutput):
        def __init__(self, input_: str, output: str) -> None:
            self.input = Path(input_)
            self.output = Path(output)

    def assert_equal(result: CompilationResult, expected: CompilationResult) -> None:
        assert result.count == expected.count
        assert result.duration >= expected.duration - 0.01
        assert result.target == expected.target
        assert set(result.dependencies) == set(expected.dependencies)

    def assert_equal_file(result: TempPaths, expected: TempPaths) -> None:
        result_content = result.output.read_text()
        expected_content = expected.output.read_text()


# Generated at 2022-06-22 14:47:04.714603
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .stubs import fs, os
    
    input_ = Path('/input')
    output = Path('/output')
    root = Path('/root')
    paths = [
        InputOutput(Path('/input/file1.py'), Path('/output/file1.py')),
        InputOutput(Path('/input/file2.py'), Path('/output/file2.py')),
        InputOutput(Path('/input/file3.py'), Path('/output/file3.py')),
    ]

    fs.create_file('/input/file1.py', contents='a = 1;')
    fs.create_file('/input/file2.py', contents='b = 2;')

# Generated at 2022-06-22 14:47:10.449587
# Unit test for function compile_files
def test_compile_files():
    output = 'test_output'
    input_ = 'test_input'

    files = [
        'test_input/app/app.json',
        'test_input/app/app.js',
        'test_input/app/app.xml',
        'test_input/app/sub/sub.tns',
        'test_input/app/sub/sub.js',
        'test_input/app/sub/sub.css',
        'test_input/app/sub/sub.d.ts',
    ]

# Generated at 2022-06-22 14:47:18.697600
# Unit test for function compile_files
def test_compile_files():
    """Test function compile files"""
    import pathlib
    import pytest
    import subprocess
    import shutil
    import sys
    import os
    here = os.path.dirname(__file__)
    root = pathlib.Path(here)
    pytest_dir = root / 'pytest'
    pytest_dir.mkdir()
    pytest_input = pytest_dir / 'input'
    pytest_input.mkdir()
    pytest_output = pytest_dir / 'output'
    pytest_output.mkdir()
    shutil.copytree(root / 'tests' / 'input', pytest_input / 'tests')
    # prints the result
    print(compile_files(pytest_input, pytest_output, CompilationTarget.PY35_SDIST))

    # compare