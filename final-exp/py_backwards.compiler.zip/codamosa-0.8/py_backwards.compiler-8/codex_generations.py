

# Generated at 2022-06-22 14:43:17.300614
# Unit test for function compile_files
def test_compile_files():
    assert False

# Generated at 2022-06-22 14:43:25.645708
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from argparse import Namespace
    from .types import CompilationResult
    from . import parameters
    from .files import get_input_output_paths
    from .transformers import remove_none as remove_none_transformer, remove_unused as remove_unused_transformer, remove_static as remove_static_transformer, remove_global as remove_global_transformer, remove_empty_classes as remove_empty_classes_transformer, remove_docstrings as remove_docstrings_transformer, remove_simple_annotations as remove_simple_annotations_transformer

# Generated at 2022-06-22 14:43:33.951999
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .types import CompilationTarget
    from .utils.helpers import is_str_like
    from .loggers import get_stdout_logger
    from .exceptions import CompilationError

    def assert_result(result: CompilationResult):
        assert(is_str_like(result.message))
        assert(isinstance(result.target, CompilationTarget))
        assert(isinstance(result.time, float))
        assert(isinstance(result.total, int))
        assert(isinstance(result.dependencies, list))
        assert(all(is_str_like(dep) for dep in result.dependencies))

    def assert_compiles(input_: str, output: str, target: CompilationTarget,
                        root: str = ''):
        logger

# Generated at 2022-06-22 14:43:46.449486
# Unit test for function compile_files
def test_compile_files():
    from os.path import join, exists
    from . import __file__ as DIR
    from shutil import rmtree

    def test_case(input_: str, output: str):
        """Runs a test case."""
        debug(lambda: 'Run test case: {} to {}'.format(input_, output))
        compile_files(input_, output, CompilationTarget.py_to_js)

        # Some files should be outputed
        assert exists(output)
        assert exists(output + '-1.js')
        assert exists(output + '-2.js')

        # Some files should not be outputed
        assert not exists(output + '.js')

        # Files should be equal
        assert open(input_ + '.py').read()\
            == open(output + '.py').read()

# Generated at 2022-06-22 14:43:52.525317
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    with tempfile.TemporaryDirectory() as input_dir, \
            tempfile.TemporaryDirectory() as output_dir:
        assert compile_files(input_dir, output_dir, CompilationTarget.PYTHON) == \
               CompilationResult(0, 0, CompilationTarget.PYTHON, [])

# Generated at 2022-06-22 14:44:01.535866
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import sys
    import tempfile
    import unittest
    path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append("..")
    import typycal_py
    sys.path.pop()

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.tempdir)

    class CompileFilesTestCase(TestCase):
        def test_skip(self):
            input_ = os.path.join(path, "integration", "compile")
            output = os.path.join(self.tempdir, "output")

# Generated at 2022-06-22 14:44:04.914307
# Unit test for function compile_files
def test_compile_files():
    '''
    test_compile_files is testing the function compile_files.
    '''
    assert compile_files('test/test_input', 'test/test_output', CompilationTarget.ES5) is not None

# Generated at 2022-06-22 14:44:06.251702
# Unit test for function compile_files
def test_compile_files():
    compile_files('test_input', 'test_output', 'python')

# Generated at 2022-06-22 14:44:11.211264
# Unit test for function compile_files
def test_compile_files():
    # Actual compilation is tested in tests/unit/transformer_tests
    result = compile_files('tests/unit/fixtures',
                           'tests/unit/build/compiler_tests',
                           CompilationTarget.PYTHON_JS)
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON_JS
    assert result.time > 0
    assert len(result.dependencies) > 0

# Generated at 2022-06-22 14:44:23.462402
# Unit test for function compile_files
def test_compile_files():
    import pytest

    def test_files(input_: str, output: str, dependencies: List[str], target: CompilationTarget):
        result = compile_files(input_, output, target)
        assert result.count_files == 4
        assert result.target == target
        assert result.dependencies == dependencies

    test_files('test/data/compiler',
               'test_build',
               [],
               CompilationTarget.DEVELOPMENT)

    test_files('test/data/compiler',
               'test_build',
               ['unittest', 'mock'],
               CompilationTarget.BUILD)


# Generated at 2022-06-22 14:44:39.046197
# Unit test for function compile_files
def test_compile_files():
    from tempfile import mkdtemp
    from shutil import rmtree
    from .types import CompilationTarget

    input_ = mkdtemp()
    output = mkdtemp()


# Generated at 2022-06-22 14:44:50.858551
# Unit test for function compile_files
def test_compile_files():
    from .tests.helpers import random_tempdir
    from .tests.helpers import random_string
    from .tests.helpers import generate_random_stmts
    from .tests.helpers import assert_compiles
    from .transpilers.python import PythonTarget
    from .transformers import ClassImportTransformer

    with random_tempdir() as tmpdir:
        generator = lambda: unparse(ast.parse(
            '\n'.join(generate_random_stmts())))

        for _ in range(10):
            input_ = tmpdir.joinpath(random_string())
            output = tmpdir.joinpath(random_string())

            input_.write_text(generator())
            assert_compiles(input_, output, PythonTarget, root=tmpdir)


# Generated at 2022-06-22 14:45:02.346975
# Unit test for function compile_files
def test_compile_files():
    import os
    import pytest
    import shutil
    import tempfile
    import subprocess

    test_dir = tempfile.mkdtemp(prefix="smyt_compiler_test_")

# Generated at 2022-06-22 14:45:10.368177
# Unit test for function compile_files
def test_compile_files():
    import shutil, os
    try:
        compile_files('.', './target', CompilationTarget.ES5, root='tests')
    except CompilationError as e:
        print(e)
        shutil.rmtree('./target')
        os.remove('./target.zip')
        raise
    else:
        shutil.rmtree('./target')
        os.remove('./target.zip')
        print("Successfully compiled all")


# Generated at 2022-06-22 14:45:21.791275
# Unit test for function compile_files
def test_compile_files():
    from .examples.hello_world import main
    from .examples.recursive_function import recursive_function
    from .examples.multi_class import main as multi_class
    from .examples.complex_class import main as complex_class
    from .examples.deep_class import main as deep_class
    from .examples.generator_function import main as generator_function
    from .examples.function_call import main as function_call
    from .examples.default_arguments import main as default_arguments
    from .examples.generator import main as generator
    from .examples.partial import main as partial
    from .examples.anonymous import main as anonymous
    from .examples.decorators import main as decorators
    from .examples.generator_decorator import main as generator_decorator

# Generated at 2022-06-22 14:45:24.636429
# Unit test for function compile_files
def test_compile_files():
    _compile_file(InputOutput(Path('/home/test1.py'), Path('/home/test1.js')), CompilationTarget.PYTHON)



# Generated at 2022-06-22 14:45:28.175674
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/fixtures', 'tests/tmp', CompilationTarget.ES5)
    assert result.file_count == 3
    assert result.target == CompilationTarget.ES5
    assert 'es5_class.js' in result.dependencies
    # TODO: check other values

# Generated at 2022-06-22 14:45:35.870872
# Unit test for function compile_files
def test_compile_files():
    from .test import compile
    import distutils.dir_util
    distutils.dir_util.mkpath("test/output")
    print("Testing start...")
    print(compile_files("test/input", "test/output", CompilationTarget.PYTHON3))
    compile("3")
    distutils.dir_util.remove_tree("test/output")


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:45:47.342555
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .__main__ import parse_args
    import unittest
    import sys
    import pathlib

    class TestCompileFiles(unittest.TestCase):

        def test_compile_files(self):
            from .__main__ import compile_files

            args = parse_args([
                '--input', 'tests/input',
                '--output', 'tests/output',
                '--target', 'python27'
            ])
            res = compile_files(args)

            self.assertEqual(res['count'], 1)
            self.assertGreater(res['time'], 0)
            self.assertEqual(res['target'], CompilationTarget.python27)
            self.assertListEqual(res['dependencies'], [
                'math'
            ])

# Generated at 2022-06-22 14:45:52.610269
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/test_files', 'tests/compiled/test_files', CompilationTarget.PYTHON)
    compile_files('tests/test_files', 'tests/compiled/test_files', CompilationTarget.JAVA)
    compile_files('tests/test_files', 'tests/compiled/test_files', CompilationTarget.CPP)

# Generated at 2022-06-22 14:46:10.221451
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from io import StringIO
    from .compiler import compile_files

    input_ = Path('.')

    # Simple case
    output = StringIO()
    compile_files(input_, output, CompilationTarget.RUNTIME)
    assert output.getvalue().strip() == '2 files compiled in 0:00:00.000'

    # Root path
    output = StringIO()
    compile_files(input_, output, CompilationTarget.RUNTIME,
                  root='.pyci')
    assert output.getvalue().strip() == '1 files compiled in 0:00:00.000'

    # Error case
    output = StringIO()

# Generated at 2022-06-22 14:46:20.010647
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

    tmp = tempfile.mkdtemp()
    try:
        test_source_file = tmp + '/src/test.py'
        test_destination_file = tmp + '/dest/test.py'
        with open(test_source_file, 'w') as f:
            f.write('def f(x):\n    x ** x')

        success, output = compile_files('src', 'dest', 'python')
        assert success
        with open(test_destination_file) as f:
            assert f.read() == 'def f(x):\n    x ** x'
        shutil.rmtree(tmp)
    except:
        shutil.rmtree(tmp)
        raise

# Generated at 2022-06-22 14:46:26.939326
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    folders_to_remove = [
        tempfile.mkdtemp(),
    ]

# Generated at 2022-06-22 14:46:36.785103
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .test.get_tests import get_tests

    for input_, output in get_tests():
        target = CompilationTarget.PY2

        with TemporaryDirectory() as tmp:
            tmp_input = Path(tmp) / 'input'
            tmp_output = Path(tmp) / 'output'

            input_.copytree(tmp_input)
            result = compile_files(tmp_input, tmp_output, target)

            assert result.count > 0
            assert result.compilation_time > 0
            assert result.target is target
            assert len(result.dependencies) > 0

            assert output == tmp_output

# Generated at 2022-06-22 14:46:48.798794
# Unit test for function compile_files
def test_compile_files():
    from os import path
    from shutil import rmtree
    from tempfile import mkdtemp
    from .utils.helpers import cd
    from .utils.test_helpers import rewrite_file

    input_ = path.abspath('tests/units/fixtures/compile_files')
    output = mkdtemp(prefix='mamba_')


# Generated at 2022-06-22 14:46:51.187722
# Unit test for function compile_files
def test_compile_files():
    from .test.test_test_compiler import test_compile_files
    return test_compile_files()
# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-22 14:47:02.853496
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    tmp_dir = tempfile.TemporaryDirectory()

    os.makedirs(os.path.join(tmp_dir.name, 'test', 'subfolder'))
    open(os.path.join(tmp_dir.name, 'test', 'hello.j'), 'w').close()
    open(os.path.join(tmp_dir.name, 'test', 'world.j'), 'w').close()
    open(os.path.join(tmp_dir.name, 'test', 'subfolder', 'subworld.j'), 'w').close()


# Generated at 2022-06-22 14:47:13.635016
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import os
    import shutil
    root = Path('./test_compile_files')

    try:
        shutil.rmtree(root.as_posix())
    except FileNotFoundError:
        pass

    root.mkdir()

    compile_files('tests/tree/', root.as_posix(), CompilationTarget.TOML)

    assert (root / 'test.js').is_file()
    assert (root / 'test').is_file()
    assert (root / 'test2.js').is_file()
    assert (root / 'test2').is_file()
    assert (root / 'test_dir').is_dir()
    assert (root / 'test_dir/foo.js').is_file()

# Generated at 2022-06-22 14:47:18.320998
# Unit test for function compile_files
def test_compile_files():
    code = '''
import numpy as np
arr = np.arange(15).reshape(3,5)
    '''
    target = 'translation'
    result = compile_files('tests/samples', 'tests/samples-out', target)

    with open('tests/samples-out/ast.py') as f:
        compiled_code = f.read()

    assert compiled_code == code
    assert result.target == target
    assert result.count == 1

# Generated at 2022-06-22 14:47:28.595581
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import pytest

    from pathlib import Path
    from datetime import datetime
    from time import sleep
    from os import listdir, mkdir
    from os.path import isfile, join, isdir
    from .exceptions import FormatError, CompilationError
    from .transformers import transformers

    def test_transformer(path_input, path_output, transformer,
                         target, filename, dependencies, expected_content=None, expected_error=None):
        new_files = [f for f in listdir(path_input) if isfile(join(path_input, f))]

        if isfile(path_output):
            os.remove(path_output)
        dir_path = os.path.dirname(os.path.realpath(__file__))