
'\n======================\nReverse Cuthill--McKee\n======================\n\nCuthill-McKee ordering of matrices\n\nThe reverse Cuthill--McKee algorithm gives a sparse matrix ordering that\nreduces the matrix bandwidth.\n'
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
G = nx.grid_2d_graph(3, 3)
rcm = list(nx.utils.reverse_cuthill_mckee_ordering(G))
print('ordering', rcm)
print('unordered Laplacian matrix')
A = nx.laplacian_matrix(G)
(x, y) = np.nonzero(A)
print(''.join(['bandwidth: ', '{}'.format(
    (((y - x).max() + (x - y).max()) + 1))]))
print(A)
B = nx.laplacian_matrix(G, nodelist=rcm)
print('low-bandwidth Laplacian matrix')
(x, y) = np.nonzero(B)
print(''.join(['bandwidth: ', '{}'.format(
    (((y - x).max() + (x - y).max()) + 1))]))
print(B)
sns.heatmap(B.todense(), cbar=False, square=True, linewidths=0.5, annot=True)
plt.show()
