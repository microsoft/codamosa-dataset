
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals


def test_compile_files():
    pass


def test_compile_files():

    class DummyTransformer(object):
        target = 0


def test_compile_files():
    import shutil
    import sys
    import tempfile
    root = tempfile.mkdtemp()
    sys.path.append(root)


def test_compile_files():
    import tempfile
    (input_, output) = (tempfile.TemporaryDirectory(), tempfile.TemporaryDirectory())
    (input_path, output_path) = (Path(input_.name), Path(output_.name))
    (input_path / 'a.py').write_text("print('Hello')")
    (input_path / 'b.py').write_text("print('World')")
    (input_path / 'c.py').write_text("print('!')")
    compile_files(input_path, output_path, CompilationTarget.PYTHON)
    assert ((output_path / 'a.py').read_text() == "print('Hello')")
    assert ((output_path / 'b.py').read_text() == "print('World')")


def test_compile_files():
    result = compile_files('test_data', 'test_data_compiled', 'ES5')
    result.check()
    assert (result.count == 3)
    assert (result.time > 0)
    assert (result.target == 'ES5')
    assert (result.dependencies == ['d.js'])


if (__name__ == '__main__'):
    print(compile_files('test_data', 'test_data_compiled', 'ES5'))


def test_compile_files():
    assert os.path.exists('test/test_samples/inputs')
    assert os.path.exists('test/test_samples/js')
    assert os.path.exists('test/test_samples/outputs')
    if (not os.path.exists('test/test_samples/compiled')):
        os.makedirs('test/test_samples/compiled')
    if (not os.path.exists('test/test_samples/compiled/commonjs')):
        os.makedirs('test/test_samples/compiled/commonjs')


def test_compile_files():
    print('Testing compile_files')
    source_path = os.path.realpath(os.path.join(os.path.dirname(
        os.path.realpath(__file__)), '../test/unit/test_compile_files/source'))
    target_path = os.path.realpath(os.path.join(os.path.dirname(
        os.path.realpath(__file__)), '../test/unit/test_compile_files/target'))
    python_path = os.path.realpath(os.path.join(os.path.dirname(
        os.path.realpath(__file__)), '../test/unit/test_compile_files/python_output'))


def test_compile_files():
    input_ = 'julia_codes/tests/dir_tests/'
    output = 'custom_out/dir_tests/'
    root = 'julia_codes/'
    target = CompilationTarget.PYTHON
    test = compile_files(input_, output, target, root)
    assert (test.count == 1)
    assert (test.target == CompilationTarget.PYTHON)


def test_compile_files():
    code = "if a == 3:\nprint('a is 3')\nprint('a is', a)\n"
    expected_code = "if a == 3:\n    print('a is 3')\n    print('a is', a)"
    result = compile_files('test/test_files/test.py',
                           'test/test_files/build/', CompilationTarget.PYTHON_3)
    assert (result.target == CompilationTarget.PYTHON_3)
    assert result.success
    assert (result.time > 0)
    assert (result.files == 1)
    assert (result.dependencies == [])
    with open('test/test_files/build/test.py') as f:
        assert (f.read() == expected_code)


def test_compile_files():
    from .tests.utils import test_directory
    results = compile_files(unicode(
        test_directory), output='../../output', target=CompilationTarget.PYTHON_PYTEST)
    print(('%d files compiled' % results.count))
    print(('compilation time: %.3f s' % results.compilation_time))
    print(('dependencies: ' + unicode(results.dependencies)))


if (__name__ == '__main__'):
    test_compile_files()
