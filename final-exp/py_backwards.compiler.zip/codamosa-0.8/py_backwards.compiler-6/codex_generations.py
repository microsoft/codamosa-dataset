

# Generated at 2022-06-22 14:43:18.909066
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test_files/test_files_1', 'test_files_output', CompilationTarget.ES5)


# Generated at 2022-06-22 14:43:30.870472
# Unit test for function compile_files
def test_compile_files():
    import sys
    import os
    import shutil
    import tempfile
    from pathlib import Path
    from ctypes import cdll
    from unittest import TestCase, main

    class CompileTest(TestCase):
        def test_compile(self):
            import hello
            self.assertEqual(hello.greet(), 'Hello, World!')

    def compile(input_: str, output: str, target: CompilationTarget):
        compile_files(input_, output, target)

    def test_compiled(input_: str, output: str, target: CompilationTarget):
        tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 14:43:33.921160
# Unit test for function compile_files
def test_compile_files():
    compile_files('test_input/test', 'test_output', CompilationTarget.PYTHON)
    compile_files('test_input/test', 'test_output', CompilationTarget.PYTHON, root='test_input')



# Generated at 2022-06-22 14:43:46.380129
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import runpy
    import pytest
    import tempfile
    import shutil
    import os
    import sys

    import jsonpickle
    #jsonpickle.set_encoder_options('simplejson', sort_keys=True, indent=4 * ' ')

    dir = pathlib.Path(tempfile.mkdtemp())

    script = """
    #include<stdio.h>

    int main(void) {
        int a = __builtin_bswap32(0x12345678);
        printf("Hello world, %d\\n", a);
        return 0;
    }
    """

    with open(dir/'main.c', 'w') as f:
        f.write(script)


# Generated at 2022-06-22 14:43:57.487159
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('test_files/simple.py', 'tmp', CompilationTarget.PYTHON, '.')
    assert result.total_count == 1
    assert result.time_spend > 0
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['test_transformers.py']

    result = compile_files('test_files', 'tmp', CompilationTarget.PYTHON, '.')
    assert result.total_count == 4
    assert result.time_spend > 0
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['test_transformers.py', 'test_transformers2.py']

# Generated at 2022-06-22 14:44:06.344388
# Unit test for function compile_files
def test_compile_files():
    with TemporaryDirectory() as tmp:
        in_dir = Path(tmp) / 'in'
        in_dir.mkdir()
        (in_dir / 'main.py').touch()
        (in_dir / 'sub' / 'main.py').mkdir(parents=True)
        out_dir = Path(tmp) / 'out'

        for target in CompilationTarget:
            result = compile_files(in_dir.as_posix(), out_dir.as_posix(), target)
            assert result.target == target

# Generated at 2022-06-22 14:44:13.856713
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from .utils.helpers import TemporaryDirectory
    
    with TemporaryDirectory() as d:
        from pathlib import Path
        from shutil import copy

        copy('tests/data/basic.py', d)
        copy('tests/data/package', d)

        target = CompilationTarget.Compile
        result = compile_files(d, d, target, root=Path('tests', 'data'))
        assert result.count == 1
        assert result.target == target
        assert result.dependencies == []

        with Path(d, 'basic.py').open() as f:
            assert f.read().strip() == 'def foo(x, y):\n    return x + y'

        target = CompilationTarget.Run

# Generated at 2022-06-22 14:44:15.659172
# Unit test for function compile_files
def test_compile_files():
    # TODO: Write unit test for function compile_files
    pass


# Generated at 2022-06-22 14:44:26.057724
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    
    # Setup a temporary workspace
    workspace = tempfile.mkdtemp()
    os.mkdir(os.path.join(workspace, "input"))
    os.mkdir(os.path.join(workspace, "output"))
    os.mkdir(os.path.join(workspace, "output", "dir1"))
    os.mkdir(os.path.join(workspace, "output", "dir2"))
    os.mkdir(os.path.join(workspace, "output", "dir2", "dir"))

    # Write two files to the input directory

# Generated at 2022-06-22 14:44:38.132574
# Unit test for function compile_files
def test_compile_files():
    from pytest import raises
    from .transformers import SyntheticErrorTransformer
    from .utils.paths import Paths

    target = CompilationTarget.PY2
    input_ = Paths.TESTS.as_posix()
    output = Paths.TESTS_COMPILED.as_posix()

    def replace_transformer(transformer: type) -> type:
        """Replaces certain transformer in list of all transformers."""
        i = transformers.index(transformer)
        transformers[i] = SyntheticErrorTransformer
        return transformer

    # Test exception in SyntheticErrorTransformer
    transformer = replace_transformer(transformers[0])
    with raises(CompilationError):
        compile_files(input_, output, target)
    transformers[0] = transformer

    # Test exception

# Generated at 2022-06-22 14:44:45.025523
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('') is None


# Generated at 2022-06-22 14:44:50.783996
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget, CompilationResult
    from .exceptions import CompilationError
    from .transformers import get_elm_dependencies
    from pathlib import Path
    from pytest import raises
    import tempfile

    # Create temporary directory for test
    with tempfile.TemporaryDirectory() as tempdir:
        tempdir = Path(tempdir)
        # Create input file

# Generated at 2022-06-22 14:44:59.836667
# Unit test for function compile_files
def test_compile_files():
    import pytest

    result = compile_files('test/input', 'test/output', CompilationTarget.PYTHON2)

    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON2
    assert not result.dependencies

    with open('test/output/index.py') as f:
        current_code = f.read()

    with open('test/data/index2.py') as f:
        expected_code = f.read()

    assert current_code == expected_code

    result = compile_files('test/input', 'test/output', CompilationTarget.PYTHON3)

    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON3
    assert not result.dependencies


# Generated at 2022-06-22 14:45:12.492810
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from .exceptions import CompilationError
    from .types import CompilationResult
    from .utils.helpers import debug

    debug(lambda: 'Test compilation')
    with tempfile.TemporaryDirectory() as temp_in, tempfile.TemporaryDirectory() as temp_out:
        temp_in = Path(temp_in)
        temp_out = Path(temp_out)
        (temp_in / 'test1.py').touch()
        (temp_in / 'test2.py').touch()

        result = compile_files(str(temp_in / 'test1.py'), str(temp_out), CompilationTarget.Py27)
        assert result == CompilationResult(1, target=CompilationTarget.Py27)

# Generated at 2022-06-22 14:45:24.192068
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import hashlib

    def sha256sum(path: str) -> str:
        with open(path, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()

    with tempfile.TemporaryDirectory() as tempdir:
        base = '{}/'.format(tempdir)
        open('{}/a.py'.format(base), 'w').write('x = 2\n')
        open('{}/b.py'.format(base), 'w').write('from a import x\n')
        open('{}/c.py'.format(base), 'w').write('from a import x\n')
        open('{}/d.py'.format(base), 'w').write('from b import x\n')

# Generated at 2022-06-22 14:45:30.222951
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil
    import contextlib

    @contextlib.contextmanager
    def in_temp_dir():
        temp_dir_path = tempfile.mkdtemp()
        old = os.getcwd()
        os.chdir(temp_dir_path)
        try:
            yield os.getcwd()
        finally:
            os.chdir(old)
            shutil.rmtree(temp_dir_path)


# Generated at 2022-06-22 14:45:41.936069
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    from pathlib import Path
    from .exceptions import CompilationError
    from .types import CompilationResult
    from .transformers.modifiers import FixIndentationTransformer
    FixIndentationTransformer.indent = ' ' * 4

    source_dir = Path(__file__).parent / 'files/complie_files'

    # Create temporary directory
    temp_dir = tempfile.mkdtemp()
    dest_dir = Path(temp_dir) / 'tmp'

    # Compilation with target Python
    result = compile_files(source_dir, dest_dir, CompilationTarget.PYTHON)
    assert result.count == 1, 'We expect one file to be compiled.'

# Generated at 2022-06-22 14:45:46.519724
# Unit test for function compile_files
def test_compile_files():
    expected = CompilationResult(
        5, target=CompilationTarget.strict,
        compiled_time=0.0, dependencies=[]
    )

    assert compile_files('test/folder/', 'temp/',
                         CompilationTarget.strict) == expected



# Generated at 2022-06-22 14:45:58.457231
# Unit test for function compile_files
def test_compile_files():
    import os
    import sys
    import re
    import difflib
    import argparse
    import logging

    # By default, verbose logging is disabled.
    logging.basicConfig(level=logging.ERROR)

    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Run the unit test.')
    parser.add_argument('-v', '--verbose',
                        help='enable verbose output',
                        action='store_const', const=logging.DEBUG,
                        default=logging.ERROR,
                        dest='verbosity')
    parser.add_argument('-t', '--test',
                        help='test to run',
                        action='append',
                        dest='tests')

# Generated at 2022-06-22 14:46:05.914738
# Unit test for function compile_files
def test_compile_files():
    assert get_input_output_paths('input', 'output') == [
        InputOutput('input', 'output')
    ]
    assert get_input_output_paths('input/a.py', 'output/a.py') == [
        InputOutput('input/a.py', 'output/a.py')
    ]
    assert get_input_output_paths('input/a.py', 'output/b.py') == [
        InputOutput('input/a.py', 'output/b.py')
    ]
    assert get_input_output_paths('input/a.py', 'output') == [
        InputOutput('input/a.py', 'output/a.py')
    ]
    import pprint
    pp = pprint.PrettyPrinter(indent=4)

# Generated at 2022-06-22 14:46:22.179069
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile
    import pathlib

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    root = tempfile.mkdtemp()
    pathlib.Path(input_, 'T', 'tests.py').touch()
    pathlib.Path(input_, 'T2', 'x.py').touch()

    compile_files(input_, output, CompilationTarget.HOST, root)
    shutil.rmtree(input_)
    shutil.rmtree(output)
    shutil.rmtree(root)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:46:22.620519
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-22 14:46:27.238211
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import os.path
    import os
    import shutil
    from tempfile import mktemp
    from pathlib import Path
    from .files import get_input_output_paths, InputOutput

    def _compile_files(input_: str,
                       output: str,
                       expected: List[str],
                       expected_target: CompilationTarget,
                       **kwargs):
        result = compile_files(input_, output, expected_target, **kwargs)
        assert result.target == expected_target
        assert result.dependencies == expected
        assert result.duration >= 0
        assert result.count >= 0
        
        for paths in get_input_output_paths(input_, output, **kwargs):
            with paths.output.open() as f:
                assert f.read() == paths.input

# Generated at 2022-06-22 14:46:33.687529
# Unit test for function compile_files
def test_compile_files():
    src = 'test-compiler/src'
    dst = 'test-compiler/helpers'
    expected = ['test-compiler/helpers/a.py']
    compile_files(src, dst, CompilationTarget.PYTHON)
    res = get_input_output_paths(src, dst, src)
    assert expected == [path.output.as_posix() for path in res]



# Generated at 2022-06-22 14:46:39.004378
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from pathlib import Path
    from .types import CompilationTarget
    result = compile_files(Path('examples'), Path('examples_output'), CompilationTarget.PYTHON_34)
    print (result)
    assert result.duration > 0

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:46:49.028927
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path

    def get_content(path: Path) -> str:
        with path.open() as f:
            return f.read()

    def test(src: str, expected: str) -> None:
        tmp = Path('/tmp')
        result = compile_files(src, str(tmp / 'output'), CompilationTarget.PY2)
        assert result.count == 1
        assert expected == get_content(tmp / 'output/test.py')

    test(str(Path('tests/resources/test.py')),
         """import my_lib # type: ignore

x = my_lib.test1()
assert isinstance(x, int)
print('ok')
""")

# Generated at 2022-06-22 14:46:54.543570
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    input_ = 'test/files/input'
    output = 'test/files/output'
    shutil.copytree(input_, output)
    result = compile_files(input_, output, CompilationTarget.PYTHON_TO_CPYTHON)
    assert result.count == 5
    assert result.target == CompilationTarget.PYTHON_TO_CPYTHON
    assert not result.dependencies
    assert list(os.walk(output)) == [('test/files/output', [], ['static.py', 'nested/static.py', 'module.py', 'nested/module.py', 'main.py'])]
    assert os.path.isfile('test/files/output/main.py')

# Generated at 2022-06-22 14:47:04.918156
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import subprocess
    import sys
    import xml.etree.ElementTree as ET
    import shutil

    with tempfile.TemporaryDirectory() as path:
        os.chdir(path)
        files_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'files')
        shutil.copy(os.path.join(files_path, 'main.py'), path)
        shutil.copy(os.path.join(files_path, 'main2.py'), path)
        shutil.copy(os.path.join(files_path, 'main3.py'), path)
        shutil.copy(os.path.join(files_path, 'main4.py'), path)

# Generated at 2022-06-22 14:47:14.550358
# Unit test for function compile_files
def test_compile_files():
    import os.path
    import shutil
    import tempfile
    import unittest

    here = os.path.dirname(__file__)
    input_ = os.path.join(here, os.path.pardir, 'tests', 'test_files')
    output = tempfile.mkdtemp()

    class CompilerTest(unittest.TestCase):
        def test_compile_files(self):
            status = compile_files(input_, output, CompilationTarget.PYTHON)
            self.assertEqual(status.count, 3)
            self.assertGreater(status.time, 0)
            self.assertEqual(status.target, CompilationTarget.PYTHON)

# Generated at 2022-06-22 14:47:21.113311
# Unit test for function compile_files
def test_compile_files():
    input_ = '../../src'
    output = '../../build'
    target = CompilationTarget.PYTHON31
    result = compile_files(input_, output, target)
    assert result.count == 28
    assert len(result.dependencies) == 1
    assert 'typed_ast' in result.dependencies
    print(result)


# Generated at 2022-06-22 14:47:42.546424
# Unit test for function compile_files
def test_compile_files():
    for target in CompilationTarget:
        print(compile_files('tests/data', 'build/data', target))

# Generated at 2022-06-22 14:47:48.486920
# Unit test for function compile_files
def test_compile_files():
    from .config import get_config
    from .__main__ import main as entrypoint
    from pathlib import Path

    config = get_config('test/source', 'test/target')
    assert compile_files(**config, target=CompilationTarget.PY2_PY3) == entrypoint(config, CompilationTarget.PY2_PY3)
    assert compile_files(**config, target=CompilationTarget.PY3) == entrypoint(config, CompilationTarget.PY3)


# Generated at 2022-06-22 14:48:01.779748
# Unit test for function compile_files
def test_compile_files():
    import os
    import glob
    import sys
    import subprocess
    from unittest import TestCase, main

    from .utils.file_operations import find_files, remove_file, remove_directory

    class CompileFilesTest(TestCase):
        def setUp(self):
            self.path_input = os.path.abspath('test_input')
            self.path_output = os.path.abspath('test_output')
            self.path_pexpect = os.path.abspath('test_pexpect')
            self.path_pytest = os.path.abspath('test_pytest')
            self.path_example = os.path.abspath('test_example')


# Generated at 2022-06-22 14:48:14.190847
# Unit test for function compile_files
def test_compile_files():
    import unittest
    from .files import get_input_output_paths, InputOutput
    test_input_ = 'test/test_input'
    test_output = 'test/test_output'


# Generated at 2022-06-22 14:48:25.231767
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import pytest
    import subprocess

    def assert_run_ok(cmd: str):
        assert subprocess.run(cmd, shell=True, check=True).returncode == 0

    cur_dir = Path('.').resolve()
    with tempfile.TemporaryDirectory() as test_dir:
        # Copy all .py files from example directory
        example_dir = cur_dir / 'example'
        for py_file in example_dir.glob('**/*.py'):
            shutil.copy(py_file.as_posix(),
                        (Path(test_dir) / py_file.relative_to(example_dir)).as_posix())

        # Compile to another directory

# Generated at 2022-06-22 14:48:35.414221
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from .testcases import testcases
    for testcase in testcases:
        with TemporaryDirectory() as tmpdir:
            input_ = Path(tmpdir) / 'input'
            input_.mkdir()
            output = Path(tmpdir) / 'output'
            output.mkdir()

            testcase.input_.parent.mkdir()
            testcase.input_.write_text(testcase.code)

            compile_files(input_, output, CompilationTarget.PYTHON,
                          testcase.input_.parent)

            assert output.joinpath(testcase.input_.name).read_text() == testcase.expected

# Generated at 2022-06-22 14:48:44.191892
# Unit test for function compile_files
def test_compile_files():
    from .types import CompiledFile
    from .utils.test_utils import temporary_directory, check_compilation_result
    
    with temporary_directory() as d:
        input_ = d.path / 'input'
        output = d.path / 'output'
        input_.mkdir()
        output.mkdir()
        (input_ / 'test.py').touch()
        (input_ / 'another.py').touch()
        result = compile_files(input_.as_posix(),
                               output.as_posix(),
                               CompilationTarget.PYTHON)

# Generated at 2022-06-22 14:48:55.165373
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths
    from .exceptions import CompilationError
    from .types import CompilationTarget
    from pathlib import Path
    from pytest import raises
    import shutil
    import tempfile
    import os
    # Compiles all files from input_ to output.

    class FakePath(object):
        """Class to mimic the pathlib.Path object."""

        def __init__(self, path):
            self.path = path
            self.folder = os.path.split(path)[0]
            self.name = os.path.split(path)[1]

        def open(self, mode='r'):
            return open(self.path, mode)

        def as_posix(self):
            return self.path


# Generated at 2022-06-22 14:49:00.507377
# Unit test for function compile_files
def test_compile_files():
    import tempfile

    input_ = 'test_input'
    root = tempfile.mkdtemp()
    try:
        output = tempfile.mkdtemp(dir=root)
        assert compile_files(
            input_, output, CompilationTarget.PYTHON).errors == 0
    finally:
        import shutil
        shutil.rmtree(root)

# Generated at 2022-06-22 14:49:01.733075
# Unit test for function compile_files
def test_compile_files():
    # TODO write unit tests for all functions in this file
    pass

# Generated at 2022-06-22 14:49:44.350872
# Unit test for function compile_files
def test_compile_files():
    # TODO: Write unit test
    return True



# Generated at 2022-06-22 14:49:51.701159
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/examples/python/file_list'
    output = 'tests/examples/python/file_list_compiled'
    target = CompilationTarget.PYTHON_2
    result = compile_files(input_, output, target)
    assert result.count == 4
    assert set(result.dependencies) == {
        'io', 'scrapy', 'scrapy.http.response.html', 'scrapy.http.response'}

# Generated at 2022-06-22 14:50:04.634810
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import traceback
    from .files import get_input_output_paths
    from .transformers import transformers
    from .utils.helpers import debug
    from .types import CompilationTarget

    def create_temp_files(files: dict) -> tempfile.TemporaryDirectory:
        d = tempfile.TemporaryDirectory()
        for k, v in files.items():
            with open(os.path.join(d.name, k), 'w') as f:
                f.write(v)
        return d


# Generated at 2022-06-22 14:50:09.019516
# Unit test for function compile_files
def test_compile_files():
    print(compile_files('../test_dummy', '../test_dummy_compiled', CompilationTarget.ES6))


# Generated at 2022-06-22 14:50:17.926278
# Unit test for function compile_files
def test_compile_files():
    temp_dir = tempfile.TemporaryDirectory()
    try:
        input_ = Path(temp_dir.name) / 'input'
        input_.mkdir()
        input_path = input_ / 'ex.py'
        (input_path).write_text(
            '''def f():
    x = input("")
    print(x)
f()''')
        output = Path(temp_dir.name) / 'output'
        compile_files(input_, output, CompilationTarget.PYPY)
    finally:
        temp_dir.cleanup()


__all__ = ['compile_files']

# Generated at 2022-06-22 14:50:35.906525
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile
    import os
    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'input'))
    open(os.path.join(tmpdir, 'input', 'main.py'), 'a').close()
    open(os.path.join(tmpdir, 'input', 'imported.py'), 'a').close()
    open(os.path.join(tmpdir, 'input', '__init__.py'), 'a').close()
    open(os.path.join(tmpdir, 'input', 'imported', '__init__.py'), 'a').close()
    open(os.path.join(tmpdir, 'input', 'imported', 'more.py'), 'a').close()

# Generated at 2022-06-22 14:50:37.636434
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/input', 'tests/output',
                  CompilationTarget.BROWSER)



# Generated at 2022-06-22 14:50:50.705008
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    # Setup
    input_ = os.path.join(os.path.dirname(__file__), '..', 'tests', 'data',
                          'compile_files_in')
    output = os.path.join(os.path.dirname(__file__), '..', 'tests', 'data',
                          'compile_files_out')
    shutil.rmtree(output, ignore_errors=True)

    # Test
    result = compile_files(input_, output, CompilationTarget.ES5)

    # Verify
    assert result.compiled == 1
    assert len(result.dependencies) == 1
    assert result.target == CompilationTarget.ES5

    # Cleanup
    shutil.rmtree(output, ignore_errors=True)


#

# Generated at 2022-06-22 14:50:55.504310
# Unit test for function compile_files
def test_compile_files():
    files = compile_files('/Users/robert/Desktop/test/basics',
                          '/Users/robert/Desktop/test/compiled',
                          CompilationTarget.PY2)
    assert files == {'abs', 'print'}

# Generated at 2022-06-22 14:50:59.222564
# Unit test for function compile_files
def test_compile_files():
    compile_files('./test/compile/input', './test/compile/output', CompilationTarget.ES5)
    # assert 0, 'test not implemented'