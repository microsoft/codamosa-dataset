

# Generated at 2022-06-22 14:43:26.642955
# Unit test for function compile_files
def test_compile_files():
    import os.path
    import shutil

    import pytest
    from .types import CompilationResult

    from .transformers import transformers

    INPUT_PATH = os.path.join(os.path.dirname(__file__), 'test_compiler_input')
    OUTPUT_PATH = os.path.join(os.path.dirname(__file__), 'test_compiler_output')
    OUTPUT_FILE = os.path.join(OUTPUT_PATH, 'test_file.py')
    TEST_FILE = os.path.join(INPUT_PATH, 'test_file.py')
    TARGET_FILE_INPUT = 'test_target_file'
    TARGET_FILE_OUTPUT = 'test_target_file'

    # Remove previously compiled directory

# Generated at 2022-06-22 14:43:38.027417
# Unit test for function compile_files
def test_compile_files():
    test_input = Path(__file__).parent / 'test_inputs'
    test_output = Path(__file__).parent / 'test_outputs'

    actual = compile_files(test_input, test_output, CompilationTarget.PYTHON_M)

    assert actual.count == 2
    assert actual.target == CompilationTarget.PYTHON_M
    assert len(actual.dependencies) == 0
    assert test_output.exists()
    assert (test_output / 'hello_world.py').exists()
    assert (test_output / 'hello_world.py').is_file()
    assert (test_output / 'foo' / 'bar.py').exists()
    assert (test_output / 'foo' / 'bar.py').is_file()

# Generated at 2022-06-22 14:43:51.310224
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .files import InputOutput
    from .types import CompilationResult

    def compile(input_: str, output: str, target: CompilationTarget,
                root: Optional[str] = None) -> CompilationResult:
        return compile_files(input_, output, target, root)

    compile('in', 'out', 0)
    compile('in', 'out', 0, 'root')
    with pytest.raises(FileNotFoundError):
        compile('root/in', 'out', 0)

    assert compile('in', 'out', 0) == \
        CompilationResult(0, 0.0, 0, [])
    assert compile('in/a.py', 'out', 0) == \
        CompilationResult(1, 0.0, 0, [])

# Generated at 2022-06-22 14:44:00.961844
# Unit test for function compile_files
def test_compile_files():
    from .transformers import FunctionTransformer
    from .helpers import Dumper

    class FunctionTransformerShallDoNothing(FunctionTransformer):
        pass

    class FunctionTransformerShallDoSomething(FunctionTransformer):
        def __init__(self):
            self.count = 0

        def visit_FunctionDef(self, node: ast.FunctionDef):
            super(FunctionTransformerShallDoSomething, self).visit_FunctionDef(node)
            self.count += 1

    transformers.append(FunctionTransformerShallDoNothing)
    target = CompilationTarget.PYTHON_3_6
    input_ = '/tmp/pyxel-compiler-test-input'
    output = '/tmp/pyxel-compiler-test-output'


# Generated at 2022-06-22 14:44:06.693021
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from pprint import pprint
    path = Path('test_data/test_files')
    input_ = path / 'input'
    output = path / 'output'
    result = compile_files(input_, output, CompilationTarget.PY)
    pprint(result)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:44:14.048769
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .temp import Temp
    from .files import check_files

    with Temp() as tmp:
        # TODO: test multiple files
        path = tmp.path('a.py')
        path.parent.mkdir(parents=True)
        with path.open('w') as f:
            f.write('def add(a, b):\n  return a + b')

        compile_files(path.as_posix(), '',
                      CompilationTarget.PY27)

        assert check_files(path.as_posix(), '')

        shutil.rmtree(path.parent)
        path.parent.mkdir(parents=True)

        compile_files(path.as_posix(), '',
                      CompilationTarget.PY35)


# Generated at 2022-06-22 14:44:19.784939
# Unit test for function compile_files
def test_compile_files():
    # type: (...) -> None
    cwd = os.path.dirname(os.path.realpath(__file__))
    input_ = os.path.join(cwd, 'tests', 'fixtures', 'compile_files')
    output = os.path.join(cwd, 'tests', 'fixtures', 'compiled')

    compile_files(input_, output, CompilationTarget.CLASS)

# Generated at 2022-06-22 14:44:30.853245
# Unit test for function compile_files
def test_compile_files():
    with TemporaryDirectory() as tmp:
        input_ = pathlib.Path(tmp) / 'input.py'
        output = pathlib.Path(tmp) / 'output.py'
        input_.write_text('a=1\n')
        result = compile_files(input_.as_posix(), output.as_posix(), CompilationTarget.PYPY)
        assert result.count == 1
        assert output.read_text() == 'a=1\n'
        assert result.dependencies == []
        assert result.target == CompilationTarget.PYPY


if __name__ == '__main__':
    import sys

# Generated at 2022-06-22 14:44:35.857981
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./input', './output', CompilationTarget.ES5)
    assert result is not None
    assert result.count >= 0
    assert result.target == CompilationTarget.ES5
    assert len(result.dependencies) >= 0

# Generated at 2022-06-22 14:44:48.926321
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .scripts import pyco
    from .utils import capture_stdout
    from .exceptions import CompilationError
    from .types import CompilationTarget
    from .transformers import transformers as ts

    # Print information about all transformers
    for i in ts:
        print(i.__name__, i.target)

    # Unit test for function compile_files
    print('--- Unit test for function compile_files ---')
    root = Path(pyco.__file__).parent.parent
    inp = root / 'tests' / 'fixtures' / 'a.py'
    out = root / 'tests' / 'fixtures' / 'a_out.py'
    with inp.open() as f:
        before = f.read()
    with out.open() as f:
        after

# Generated at 2022-06-22 14:44:58.174885
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/input', 'tests/output', CompilationTarget.ES5)
    assert result.compiled_files == 3
    assert len(result.dependencies) == 1
    assert result.dependencies[0] == 'ecmascript'
    assert result.compilation_time > 0

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-22 14:45:06.576619
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.BROWSER
    files_count = compile_files('./tests', './out', target).files_count
    assert files_count == 7

    target = CompilationTarget.SERVER
    files_count = compile_files('./tests', './out', target).files_count
    assert files_count == 7

    target = CompilationTarget.ALL
    files_count = compile_files('./tests', './out', target).files_count
    assert files_count == 7

# Generated at 2022-06-22 14:45:18.933558
# Unit test for function compile_files
def test_compile_files():
    from .test.test_import import test_disambiguate_import
    from .test.test_transformers import test_transformers
    from .test.test_iter import test_iter_over_bytes
    from .test.test_dict import test_dict_comprehensions
    from .test.test_exceptions import test_exceptions

    input_, output = compile_files('test', 'output', CompilationTarget.v3)(
    ).result
    test_disambiguate_import(f'{output}/test_import.py')
    test_transformers(f'{output}/test_transformers.py')
    test_iter_over_bytes(f'{output}/test_iter.py')

# Generated at 2022-06-22 14:45:28.672126
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import sys
    import tempfile
    from .types import CompilationTarget

    def _test(path: str) -> str:
        """
        Builds the tempdir with test files, compiles it, and then
        checks if compiled files are as expected.
        """
        # Create the test folder in tempdir
        tempdir = tempfile.mkdtemp()
        assert 'test' not in os.listdir(tempdir)
        test_path = os.path.join(tempdir, 'test')
        shutil.copytree(os.path.join(path, 'test'), test_path)

        # Compile the test folder
        compiled = os.path.join(tempdir, 'compiled')
        assert 'compiled' not in os.listdir(tempdir)

# Generated at 2022-06-22 14:45:35.816675
# Unit test for function compile_files
def test_compile_files():
    in_ = os.path.abspath('tests/data/compile/input')
    out = os.path.abspath('tests/data/compile/output')
    result = compile_files(in_, out, CompilationTarget.PYTHON)
    assert result.count == 6
    assert result.target == CompilationTarget.PYTHON
    assert result.dependencies == ['math', 'random', 'time']

# Generated at 2022-06-22 14:45:44.887386
# Unit test for function compile_files
def test_compile_files():
    from .files import transform_paths
    from .utils.tests import assert_generated_files_equal, TEST_FILE_PATH

    input_ = Path(TEST_FILE_PATH) / 'test_files'
    output = Path(TEST_FILE_PATH) / 'test_output'
    target: CompilationTarget = CompilationTarget['C++']

    compile_files(input_, output, target)

    expected = Path(TEST_FILE_PATH) / 'test_expected'
    result, expected = transform_paths(result=output, expected=expected)
    assert_generated_files_equal(result, expected)

# Generated at 2022-06-22 14:45:49.356238
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(
        './tests/data/compile_files/input',
        './tests/data/compile_files/output',
        CompilationTarget.ES5,
        './tests/data/compile_files'
    )
    print(result)

# Generated at 2022-06-22 14:46:00.066050
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from os import remove
    from .exceptions import CompilationError
    from .main import parse_args
    from .__model import get_source, get_dependencies
    from .__common import script_dir
    from .transformers import transformers

    def _get_compilation_result(target: CompilationTarget, file: str) -> CompilationResult:
        input_ = str(Path(script_dir, 'compile_test', file))
        output = '/tmp/compiled.py'
        return compile_files(input_, output, target)

    expected_count = len([tr for tr in transformers if tr.target == CompilationTarget.PYTHON])
    assert len(get_dependencies(get_source('str'))) == expected_count


# Generated at 2022-06-22 14:46:10.159782
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import shutil
    import os.path
    import tempfile

    class CompileFilesTest(unittest.TestCase):
        def test1(self):
            """Tests simple compilation"""
            input_ = os.path.join(os.path.dirname(__file__), 'input', 'compile_files')
            output = tempfile.mkdtemp()

            compile_files(input_, output, CompilationTarget.V7)
            self.assertTrue(os.path.isfile(os.path.join(output, 'test.py')))
            self.assertTrue(os.path.isfile(os.path.join(output, 'test.js')))

            shutil.rmtree(output)

    unittest.main()


# Generated at 2022-06-22 14:46:16.643598
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test/fixtures/input'
    output = 'test/fixtures/output'
    target = CompilationTarget.PYTHON35
    compile_files(input_, output, target)
    compile_files(output, output, target)
    compile_files(output, output, target, output)
    compile_files(output, output, target, input_)
    compile_files(input_, input_, target, input_)

# Generated at 2022-06-22 14:46:27.678680
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget
    from .utils import cleanup
    from .exceptions import CompilationError
    from .files import get_input_output_paths
    from .transformers import transformers
    from .utils.helpers import debug

    with cleanup():
        input_ = Path('test_files')
        input_.mkdir()

        output = Path('output_files')
        output.mkdir()

        empty_file = input_ / 'empty.py'
        empty_file.touch()

        single_import = input_ / 'single.py'
        single_import.write_text('import os')

        double_imports = input_ / 'double.py'
        double_imports.write_text('import os\nimport sys')


# Generated at 2022-06-22 14:46:31.577265
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('test_files/package',
                           'test_files',
                           CompilationTarget.SOURCE_MODULE)
    assert result.compiled_files == 1

# Generated at 2022-06-22 14:46:40.241035
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from os import path
    from .types import CompilationTarget


# Generated at 2022-06-22 14:46:43.862001
# Unit test for function compile_files
def test_compile_files():
    assert compile_files(
        'tests/data/input/compile',
        'tests/data/output/compile',
        CompilationTarget.CPYTHON).count == 4

# Generated at 2022-06-22 14:46:52.667997
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths, InputOutput
    from .types import CompilationTarget
    from . import compile_files
    from .transformers import transformers
    from .transformers.base import TransformationResult
    from .transformers.base import get_name

    class Dummy(object):
        def __init__(self, tree_changed: bool, dependencies: List[str]):
            self.tree_changed = tree_changed
            self.dependencies = dependencies

        def __call__(self, tree: ast) -> TransformationResult:
            return self

        def transform(self, tree: ast) -> TransformationResult:
            return self

    class DummyTransformer(object):
        pass
    dummy = Dummy(True, [])
    transformers = [DummyTransformer() for i in range(9)]
    transform

# Generated at 2022-06-22 14:47:04.293773
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    dirpath = tempfile.mkdtemp()
    try:
        with open(os.path.join(dirpath, 'test.py'), 'w') as f:
            f.write('x = 0.5 ** 2')
        compile_files(os.path.join(dirpath, 'test.py'), os.path.join(dirpath, 'compiled'),
            CompilationTarget.IE10)
        assert os.path.exists(os.path.join(dirpath, 'compiled', 'test.py'))
        with open(os.path.join(dirpath, 'compiled', 'test.py')) as f:
            assert '0.5 ** 2' in f.read()
    finally:
        shutil.rmtree(dirpath)

# Generated at 2022-06-22 14:47:10.888285
# Unit test for function compile_files
def test_compile_files():
    r = compile_files(r'./test_files/backend/tmp_input', r'./test_files/backend/tmp_output', CompilationTarget.PYI)
    print(r)
    r = compile_files(r'./test_files/backend/tmp_input', r'./test_files/backend/tmp_output', CompilationTarget.PY)
    print(r)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:47:18.991476
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import os
    import shutil
    import tempfile
    import pytest
    res = compile_files(os.path.join(os.path.dirname(__file__), 'test_data/'), os.path.join(os.path.dirname(__file__), 'test_data_compiled/'), CompilationTarget.JS)
    assert res == CompilationResult(2, 0.0006662845611572266, CompilationTarget.JS, ['expressions.py'])
    assert subprocess.check_output([os.path.join(os.path.dirname(__file__), 'test_data_compiled/expressions.js'), '4']) == b'4.0\n6.9\n'

# Generated at 2022-06-22 14:47:28.867808
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    input_ = tempfile.mkdtemp(prefix='flask_jsonschema_app_input_')
    output = tempfile.mkdtemp(prefix='flask_jsonschema_app_output_')
    import os

# Generated at 2022-06-22 14:47:37.081601
# Unit test for function compile_files
def test_compile_files():
    input_ = 'data/compilation/files'
    output = 'output/compilation/files'
    target = CompilationTarget.WASM

    try:
        result = compile_files(input_, output, target)
    except BaseException as e:
        assert False, '{} : {}'.format(type(e).__name__, e)
    else:
        debug(lambda: 'Result is {}'.format(result))
        assert result.count == 2
        assert 'wasm' in result.dependencies


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:47:52.019627
# Unit test for function compile_files
def test_compile_files():
    try:
        assert compile_files('tests/samples/input',
                             'tests/samples/output',
                             CompilationTarget.PYTHON) == \
               CompilationResult(2, 0.15, CompilationTarget.PYTHON,
                                 ['compile.py', 'utils.py'])
    except:
        assert False, 'Compile files failed'


# Generated at 2022-06-22 14:48:02.945295
# Unit test for function compile_files
def test_compile_files():
    import autopep8
    import astunparse
    import pathlib
    from .test.test_data import test_data_path
    from .transformers import transformers
    from .utils.helpers import get_version

    source = test_data_path('test.py')
    target = test_data_path('test-output')
    compilation_target = CompilationTarget.ALL

    # clear target directory
    for file in target.rglob('*.py'):
        file.unlink()


# Generated at 2022-06-22 14:48:15.487922
# Unit test for function compile_files
def test_compile_files():
    from .files import create_temporary_directory
    import os
    import shutil
    from .types import CompilationTarget
    from .exceptions import CompilationError

    # Initializing temporary directories for testing
    test_output_path = os.path.join(create_temporary_directory(),'result_code')
    test_input_path = os.path.join(create_temporary_directory(),'code')

    # Creating the input file
    os.mkdir(test_input_path)
    os.mkdir(test_output_path)

    file_name = os.path.join(test_input_path,'test.py')

    test_file = open(file_name,'w')
    test_file.write('def foo(x):\n    print x')
    test_file.close()

    # Compiling

# Generated at 2022-06-22 14:48:19.492414
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/data/compilation', './tests/output/compilation',
                           CompilationTarget.PRODUCTION)
    assert(result.count == 1)
    assert('doctest' in result.dependencies)

# Generated at 2022-06-22 14:48:26.576222
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import pathlib
    import os
    import shutil
    import traceback

    os.makedirs(os.path.join(os.getcwd(), "tests/unittests_input"))
    os.makedirs(os.path.join(os.getcwd(), "tests/unittests_output"))


# Generated at 2022-06-22 14:48:39.120803
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import os

    class TestCompileFiles(unittest.TestCase):

        def setUp(self):
            pass

        def test_compile_files(self):
            from .utils.test_helpers import get_test_path
            test_path = get_test_path('base')

            input_path = os.path.join(test_path, 'in')
            output_path = os.path.join(test_path, 'out')

            result = compile_files(input_path, output_path,
                                   CompilationTarget.STANDARD)
            self.assertEqual(result.count, 2)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestCompileFiles)
    unittest.TextTestRunner().run(suite)

# Generated at 2022-06-22 14:48:42.950875
# Unit test for function compile_files
def test_compile_files():
    compile_files('../examples/compiler', 'compiled', 'bytecode')

if __name__ == "__main__":
    test_compile_files()

# Generated at 2022-06-22 14:48:50.378368
# Unit test for function compile_files
def test_compile_files():
    from .compiler import compile_files
    from .types import CompilationResult
    from .utils.test_data import COMPILE_JS_INPUT, COMPILE_JS_OUTPUT, COMPILE_JS_ROOT

    # test function
    assert compile_files(COMPILE_JS_INPUT, COMPILE_JS_OUTPUT,
                         CompilationTarget.JAVASCRIPT) == CompilationResult(count=2,
                                                                            duration=0.0,
                                                                            target=CompilationTarget.JAVASCRIPT,
                                                                            dependencies=[])

    # test function

# Generated at 2022-06-22 14:49:01.234958
# Unit test for function compile_files
def test_compile_files():
    code = '''
if a:
    b
else:
    c
    d
'''

    with tempfile.TemporaryDirectory() as input_, \
            tempfile.TemporaryDirectory() as output:
        input_ = pathlib.Path(input_)
        input_.joinpath('test.py').write_text(code)
        output = pathlib.Path(output)
        result = compile_files(input_, output, CompilationTarget.web)
        assert len(result.dependencies) == 0
        assert result.count == 1

        output = pathlib.Path(output)
        assert output.is_dir()
        assert len(list(output.glob('**/*'))) == 1
        assert output.joinpath('test.py').exists()

        code = output.joinpath('test.py').read_

# Generated at 2022-06-22 14:49:10.381088
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .utils.temp_dir import TempDir
    from os import path
    from shutil import copyfile

    with TempDir() as tmp_dir:
        code = '''\
            def f():
                pass
        '''
        copyfile((path.join(path.dirname(__file__), 'utils', 'test.py')),
                 path.join(tmp_dir, 'test.py'))

        res = compile_files(
            path.join(tmp_dir, 'test.py'),
            path.join(tmp_dir, 'test.min.py'),
            CompilationTarget.py2
        )

        with open(path.join(tmp_dir, 'test.min.py')) as f:
            min_code = f.read()

        assert res.count == 1

# Generated at 2022-06-22 14:49:40.096630
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    from .transformers import transformer_names

    input_ = tempfile.TemporaryDirectory()
    output = tempfile.TemporaryDirectory()

    with open(os.path.join(input_.name, 'a.py'), 'w') as f:
        f.write('def f(x):\n    y = 1\n    if x:\n        return y\n')

    with open(os.path.join(input_.name, 'b.py'), 'w') as f:
        f.write('from a import f\n\ndef g(x):\n    return f(x) + 1\n')

    compile_files(input_.name, output.name, CompilationTarget.CPYTHON)


# Generated at 2022-06-22 14:49:46.616790
# Unit test for function compile_files
def test_compile_files():
    code = '''
print(a)
'''
    class TestCompilationTarget(CompilationTarget):
        def __init__(self):
            self.name = 'test'

    import tempfile
    input_ = tempfile.TemporaryDirectory()
    output = tempfile.TemporaryDirectory()
    input_path = Path(input_.name) / 'test.py'
    output_path = Path(output.name) / 'test.py'
    input_path.write_text(code)

    result = compile_files(input_path, output_path, TestCompilationTarget())
    assert input_path.read_text() == code
    assert result.code == output_path.read_text()
    assert result.count == 1
    assert result.target == TestCompilationTarget()

    input_.cleanup()

# Generated at 2022-06-22 14:49:57.875073
# Unit test for function compile_files
def test_compile_files():
    import io
    import sys
    import os
    import unittest
    import tempfile
    from .transformers import transformers

    class TestMethods(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.input_dir = tempfile.TemporaryDirectory()
            self.output_dir = tempfile.TemporaryDirectory()
            self.old_stdout = sys.stdout
            self.output = io.StringIO()
            sys.stdout = self.output
            self.input_dir_path = Path(self.input_dir.name)
            self.output_dir_path = Path(self.output_dir.name)

        def tearDown(self):
            self.input_dir.cleanup()
            self.output_dir.cleanup()
            sys.std

# Generated at 2022-06-22 14:50:09.558488
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from .transformers import transformers
    from .types import CompilationTarget
    from .utils.helpers import debug
    debug(True)

    input_ = 'tests/resources/input'
    output = 'tests/resources/__output'

    # build & compile
    compile_files(input_, output, CompilationTarget.FULL)

    # check which transformers are used
    transformers_used = [t.__name__
                         for t in transformers
                         if t.target == CompilationTarget.FULL]
    assert transformers_used == ['CastTransformer',
                                 'AnnAssignTransformer',
                                 'TypeCommentsTransformer']

    # parse output
    with open('tests/resources/__output/some.py') as f:
        output = f.read()


# Generated at 2022-06-22 14:50:18.431727
# Unit test for function compile_files
def test_compile_files():
    for input_, output in [
            ('../tests/sample1', '../tests/output1'),
            ('../tests/sample2', '../tests/output2'),
    ]:
        with open(output + '.py', 'r') as f:
            expected = f.read()

        compile_files(input_, output, CompilationTarget.Python27)
        with open(output + '.py', 'r') as f:
            actual = f.read()

        assert expected == actual, '{} expected: \n{}\nactual: \n{}'\
            .format(output, expected, actual)

# Generated at 2022-06-22 14:50:25.115501
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.QtPy5

    files = compile_files('test/test_files/', 'test/test_compiled_files/', target)
    assert files.count == 3
    assert files.target == target

    files = compile_files('test/test_files/', 'test/test_compiled_files/', target)
    assert files.count == 0
    assert files.target == target

# Generated at 2022-06-22 14:50:33.886140
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    with open(Path(input_) / 'test.py', 'w') as f:
        f.write('def add(a, b):\n\treturn a + b')
    compile_files(input_, output, CompilationTarget.PYTHON)
    with open(Path(output) / 'test.py') as f:
        assert f.read() == 'def add(a, b): return a + b'

# Generated at 2022-06-22 14:50:40.620137
# Unit test for function compile_files
def test_compile_files():
    import io
    import sys
    import pytest
    from typing import IO
    from pyfuck.exceptions import CompilationError, TransformationError
    from pyfuck.transformers import SimpleTransformer

    # Simple test file
    test_file = u"""    def test(x):
        return x * x"""

    # Compile it and check correctness
    test_input_output = u'tests/input', u'tests/output'
    compile_files(*test_input_output, CompilationTarget.Python27)
    with io.open(test_input_output[1] + '/test.py') as f:
        code = f.read()
    assert code == u"def test(x):\n    return x * x"

    # Compile it with errors

# Generated at 2022-06-22 14:50:51.792879
# Unit test for function compile_files
def test_compile_files():
    # Arrange
    import io
    from lesscpy.lexer import lex
    from lesscpy.parser import parse

    import sys,os
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

    from less.compiler.files import get_input_output_paths
    from less.compiler.transformers import transformers
    from less.compiler.compiler import compile_files, CompilationTarget
    from less.compiler.exceptions import CompilationError
    from less.compiler.tests.utils import compare_ast

    # Act
    # Assert
    assert compile_files('.','.',CompilationTarget.PLAIN) == None

    # Arrange
    import lesscpy.lessc

# Generated at 2022-06-22 14:51:03.465434
# Unit test for function compile_files
def test_compile_files():
    from .utils.test import TempDir, assert_compilation_result
    with TempDir() as temp:
        temp.add([
            ('input', 'foo.py',
             'import aiohttp # type: ignore'),
            ('input/subdirectory', 'bar.py',
             'import aiohttp # type: ignore'),
        ])
        assert_compilation_result(
            compile_files(temp.path('input'), temp.path('output'),
                          CompilationTarget.PYTHON27),
            target=CompilationTarget.PYTHON27,
            dependencies={'aiohttp'},
            count=2,
        )
        assert_exists(temp.path('output/foo.py'))
        assert_exists(temp.path('output/subdirectory/bar.py'))
        assert temp.path