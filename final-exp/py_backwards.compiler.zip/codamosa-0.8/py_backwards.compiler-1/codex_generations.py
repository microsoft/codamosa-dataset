

# Generated at 2022-06-22 14:43:20.757789
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("test/examples/python", "test/output",
                         CompilationTarget.PYTHON).target == CompilationTarget.PYTHON

# Generated at 2022-06-22 14:43:31.072973
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import tempfile
    from shutil import rmtree
    from .utils.json_encoder import JSONEncoder

    expected_code = """if __name__ == "__main__":
    print("Hello1")
    print("Hello2")"""
    with tempfile.TemporaryDirectory() as dir_:
        dir_ = Path(dir_)
        dir_.joinpath('hello.py').write_text('print(\'Hello1\')\nprint(\'Hello2\')')
        output = compile_files(dir_, dir_, CompilationTarget.MULTI_RUNNER)
        assert output.duration > 0
        assert output.count == 1
        assert output.target == CompilationTarget.MULTI_RUNNER
        assert list(output.dependencies) == []

        assert expected_

# Generated at 2022-06-22 14:43:42.750083
# Unit test for function compile_files
def test_compile_files():
    from .files import get_input_output_paths, InputOutput
    from .transformers import transformers, ConstStr

    assert len([t for t in transformers if t.target == ConstStr]) == 1

    for paths in get_input_output_paths('input/test_input.py',
                                        'output',
                                        root='.'):
        assert paths == InputOutput(Path('input', 'test_input.py'),
                                    Path('output', 'test_input.py'))

    for paths in get_input_output_paths('input',
                                        'output',
                                        root='.'):
        assert paths == InputOutput(Path('input', 'test_input.py'),
                                    Path('output', 'test_input.py'))


# Generated at 2022-06-22 14:43:55.499116
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from pathlib import Path
    from .exceptions import CompilationError
    from .transformers.controllers import controllers
    from .transformers.form_for import form_for
    from .transformers.link_to import link_to

    def _compiler(
            input_: str,
            output: str,
            target: CompilationTarget,
            root: Optional[str] = None) -> CompilationResult:
        curdir = os.getcwd()
        tmpdir = tempfile.TemporaryDirectory()
        os.chdir(tmpdir.name)
        Path('assets/layout.pht').write_text('')
        Path('app/views/home/index.pht').write_text('')


# Generated at 2022-06-22 14:44:06.432835
# Unit test for function compile_files

# Generated at 2022-06-22 14:44:11.072974
# Unit test for function compile_files
def test_compile_files():
    start = time()
    result = compile_files('source_code', 'destination_code', CompilationTarget.COMPLETE)
    time_elapsed = time() - start

    assert result.dependencies == ['numpy', 'pandas', 'regex']
    assert result.count == 3
    assert result.target == CompilationTarget.COMPLETE
    assert 0.9 < time_elapsed < 5  # seconds

# Generated at 2022-06-22 14:44:17.054207
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/data/compile_files',
                  'tests/data/compile_files/compiled',
                  CompilationTarget.JS)
    compile_files('tests/data/compile_files',
                  'tests/data/compile_files/compiled',
                  CompilationTarget.CSS)

# Generated at 2022-06-22 14:44:27.452859
# Unit test for function compile_files
def test_compile_files():
    import os
    import pathlib

    from distutils.util import strtobool
    from argparse import ArgumentParser
    from .utils.helpers import debug
    from .types import CompilationTarget

    parser = ArgumentParser()
    parser.add_argument('--in', dest='input', default='example/src',
                        help='Input directory')
    parser.add_argument('--out', dest='output', default='example/bin',
                        help='Output directory')
    parser.add_argument('--root', dest='root', default='',
                        help='Root directory')
    parser.add_argument('--target', dest='target', type=strtobool,
                        default=CompilationTarget.LIBRARY.value,
                        help='Compilation target')

# Generated at 2022-06-22 14:44:31.717333
# Unit test for function compile_files
def test_compile_files():
    import json
    import os.path
    import tempfile
    script_dir = os.path.dirname(os.path.realpath(__file__))

    with open(os.path.join(script_dir, 'data', 'compile_files.json')) as f:
        tests = json.load(f)

    for test in tests:
        with tempfile.TemporaryDirectory() as temp_dir:
            input_dir = os.path.join(temp_dir, test['input'])
            output_dir = os.path.join(temp_dir, test['output'])
            os.makedirs(output_dir)
            result = compile_files(input_dir, output_dir, test['target'])
            assert len(result.dependencies) == len(test['dependencies'])

# Generated at 2022-06-22 14:44:40.848368
# Unit test for function compile_files
def test_compile_files():
    import pprint
    import tempfile

    # python3 -m jinjalint.compiler tests/fixtures/hello_jinja2.html output --test
    with tempfile.TemporaryDirectory() as temp:
        print(compile_files('tests/fixtures/hello_jinja2.html',
                            temp,
                            CompilationTarget.py38))

    # python3 -m jinjalint.compiler tests/fixtures output --test
    with tempfile.TemporaryDirectory() as temp:
        print(compile_files('tests/fixtures',
                            temp,
                            CompilationTarget.py38))

    # python3 -m jinjalint.compiler tests/fixtures --test

# Generated at 2022-06-22 14:44:51.797765
# Unit test for function compile_files
def test_compile_files():
    input_ = "./test/converted_test_codes/test/test_1.json"
    output = "./test/output_test/test/test_1.json"
    expected_output = [{"list": [1, 2, 3]}, [1, 2, 3, 4, 5]]
    result = compile_files(input_, output, CompilationTarget.JSON)
    with open(output) as f:
        read_output = json.loads(f.read())
    assert read_output == expected_output
    assert result.success

# Generated at 2022-06-22 14:44:58.804166
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/example1', 'tests/data/example1',
                         CompilationTarget.SPYDER)
    assert compile_files('tests/data/example2', 'tests/data/example2',
                         CompilationTarget.SPYDER)
    assert compile_files('tests/data/example3', 'tests/data/example3',
                         CompilationTarget.SPYDER)
    assert compile_files('tests/data/example4', 'tests/data/example4',
                         CompilationTarget.SPYDER)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:45:11.994279
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import shutil
    import unittest

    class CompileFilesTest(unittest.TestCase):
        """
        Unit test for function compile_files
        """
        def test_target_dev(self, target = CompilationTarget.DEV):
            """
            Unit test for function compile_files
            :param target: target python version
            :type target: CompilationTarget
            """
            path = Path(__file__)
            input_ = path.parent / "test" / "test_files"
            output = path.parent / "test" / "test_files_output"
            shutil.rmtree(output.as_posix())
            compile_files(input_, output, target)
            # TODO: write test


# Generated at 2022-06-22 14:45:18.126192
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    input_ = 'test/test_files/input/'
    output = tempfile.mkdtemp()
    target = CompilationTarget.BROWSER
    result = compile_files(input_, output, target)
    assert result.target == target
    assert result.count == 4
    assert result.dependencies == ['core']


# Generated at 2022-06-22 14:45:21.639743
# Unit test for function compile_files
def test_compile_files():
    compile_files("/home/mikhail/Desktop/school42/42python/src/frameworks",
                  "/home/mikhail/Desktop/school42/42python/bin",
                  CompilationTarget.PYCORE)


# Generated at 2022-06-22 14:45:23.219942
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests', 'output', 'C').count == 9


# Generated at 2022-06-22 14:45:27.405505
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from . import files
    import shutil

    compile_files('./tests/data/', './test_out/', CompilationTarget.ES5)
    assert Path('./test_out/dummy.js').exists()
    files.remove('./test_out/')


# Generated at 2022-06-22 14:45:39.972151
# Unit test for function compile_files
def test_compile_files():
    compile_files('test/test_programs/simple_get_v1', 'test/test_programs/test_test_programs/simple_get_v1', CompilationTarget.TESTER)
    compile_files('test/test_programs/simple_get_v1', 'test/test_programs/solution_test_programs/simple_get_v1', CompilationTarget.SOLUTION)
    compile_files('test/test_programs/simple_get_v2', 'test/test_programs/test_test_programs/simple_get_v2', CompilationTarget.TESTER)

# Generated at 2022-06-22 14:45:48.180481
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/data/input'
    output = 'tests/data/output'
    target = CompilationTarget.PYTHON
    root = 'tests/data'
    res = compile_files(input_, output, target, root)
    assert res.counter == 5
    assert res.time > 0
    assert res.target == target
    assert len(res.dependencies) == 1
    assert 'tests/data/extra/bar.py' in res.dependencies


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:45:59.673339
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from .tests import TEST_DIR
    from .bundles import catkin_bundles

    # clean directory
    shutil.rmtree(TEST_DIR / 'catkin', ignore_errors=True)

    # test compile
    result = compile_files(TEST_DIR/'ros2' / 'src', TEST_DIR/'catkin' / 'src', CompilationTarget.catkin)

    # check result
    assert result.n_files == 6
    assert result.target == CompilationTarget.catkin
    assert result.duration > 0
    assert result.dependencies == catkin_bundles

    # test that files exist