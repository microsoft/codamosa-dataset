

# Generated at 2022-06-22 14:43:22.275953
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/test_files/compile_files',
                           'tests/test_files/compile_files_output',
                           CompilationTarget.PYTHON_CODE)
    assert result.compiled_files == 2
    assert result.target == CompilationTarget.PYTHON_CODE



# Generated at 2022-06-22 14:43:31.973802
# Unit test for function compile_files
def test_compile_files():
    class FakePath(object):
        def __init__(self, as_posix):
            self.as_posix = as_posix
        def parent(self):
            return self
        def mkdir(self, parents=True):
            pass
        def open(self, mode='r'):
            return open(self.as_posix, 'w')
    class FakeInputOutput(object):
        def __init__(self, input, output):
            self.input = FakePath(input)
            self.output = FakePath(output)

    class FakeGetInputOutputPaths(object):
        def __init__(self, items):
            self.items = items
        def __iter__(self):
            for i in self.items:
                yield FakeInputOutput(i[0], i[1])

# Generated at 2022-06-22 14:43:38.812415
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('{}/test_input/test_func_1'.format(os.getcwd()), '{}/test_output'.format(os.getcwd()), CompilationTarget.TEST_FUNCTION) == CompilationResult(1, 0.00027, CompilationTarget.TEST_FUNCTION, ['{}/test_input/test_func_1/test_function_1.py'.format(os.getcwd())])

# Generated at 2022-06-22 14:43:40.534077
# Unit test for function compile_files
def test_compile_files():
    compile_files("../tests/data/input",
                  "../tests/data/output",
                  CompilationTarget.PY35)

# Generated at 2022-06-22 14:43:52.951985
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import subprocess
    import os
    import sys
    import re


# Generated at 2022-06-22 14:44:01.709812
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import tempfile
    import shutil
    import os
    from .test import sample
    from .types import CompilationTarget

    class _Tests(unittest.TestCase):
        def setUp(self):
            self.root = tempfile.mkdtemp()
 
        def tearDown(self):
            shutil.rmtree(self.root)

        def test(self):
            input_ = os.path.join(self.root, 'input')
            output = os.path.join(self.root, 'output')
            os.mkdir(input_)

            for filename, sample_code in sample.items():
                with open(os.path.join(input_, filename), 'w') as f:
                    f.write(sample_code)


# Generated at 2022-06-22 14:44:06.563601
# Unit test for function compile_files
def test_compile_files():
    result = compile_files(input_="../tests/examples",
                           output="../tests/output",
                           target=CompilationTarget.PYTHON_35)
    assert result.target == CompilationTarget.PYTHON_35
    assert result.number_of_compiled_files == 2
    assert result.total_time > 0.0

# Generated at 2022-06-22 14:44:13.984799
# Unit test for function compile_files
def test_compile_files():
    class TempDir:
        def __enter__(self):
            self.dir = tempfile.TemporaryDirectory()
            return self.dir.__enter__()

        def __exit__(self, *args):
            self.dir.__exit__(*args)

    def test_file(file_name: str, expected_output: str, target: CompilationTarget) -> None:
        with TempDir() as input_:
            with TempDir() as output:
                with open(Path(input_) / file_name, 'w') as f:
                    f.write(dedent(expected_output))
                compile_files(Path(input_), Path(output), target)
                with open(Path(output) / file_name, 'r') as f:
                    assert f.read() == expected_output


# Generated at 2022-06-22 14:44:20.922375
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .exceptions import CompilationError
    from .transformers import transformers
    from .types import CompilationTarget

    root = Path(__file__).parent.parent
    input_ = root / 'tests'
    output = root / 'compiled_tests'

    target = CompilationTarget.PYTHON37

    CompilationResult = compile_files(str(input_), str(output), target, str(root))
    assert CompilationResult.count == 12, CompilationResult.count

    target = CompilationTarget.PYPY
    CompilationResult = compile_files(str(input_), str(output), target, str(root))
    assert CompilationResult.count == 12, CompilationResult.count

# Generated at 2022-06-22 14:44:21.489623
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-22 14:44:33.063026
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    target = CompilationTarget.BROWSER
    input_ = pathlib.Path('../demo/src')
    output = pathlib.Path('/tmp')
    result = compile_files(input_, output, target)
    assert result.dependencies == []
    assert result.count == 1
    assert result.elapsed > 0
    assert result.target == target

# Generated at 2022-06-22 14:44:41.146501
# Unit test for function compile_files
def test_compile_files():
    from .test.test_debug import assert_regex
    from .test.test_files import assert_files_equal

    test_files_path = Path(__file__).parent / "test/files"
    input_path = test_files_path / "a.py"
    output_path = test_files_path / "b.py"

    assert_regex(r"CompilationResult\(count=1, time=.+, target=<Target\.compile_strict: 1>, dependencies=\[\'compiled\'/compiled/__init__\.py\'\]\)", repr(compile_files(input_path, output_path, CompilationTarget.compile_strict)))
    assert_files_equal(output_path, test_files_path / "a.compile_strict.py")

    output_path

# Generated at 2022-06-22 14:44:52.137059
# Unit test for function compile_files
def test_compile_files():
    import pytest, tempfile, pathlib, os
    def test_file(path: pathlib.Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path,'w') as file:
            file.write('def __init__(self, x):\n    pass')
            file.close()
        return path

    with tempfile.TemporaryDirectory() as tempdir:
        path1 = test_file(pathlib.Path(tempdir)/'test_file1.py')
        path2 = test_file(pathlib.Path(tempdir)/'test_file2.py')
        result = compile_files(tempdir, tempdir, CompilationTarget.PYTHON_LEGACY)
        assert result.count == 2

# Generated at 2022-06-22 14:44:53.610384
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/compiler/input', 'tests/compiler/output', CompilationTarget.STANDALONE)

# Generated at 2022-06-22 14:44:58.750778
# Unit test for function compile_files
def test_compile_files():
    f = compile_files
    tests = [
        (InputOutput(1, 2, 3), 4, 5, 6),
        (InputOutput(7, 8, 9), 10, 11, 12),
    ]
    for t in tests:
        assert f(t[0], t[1], t[2], t[3]) == 123456789101112

# Generated at 2022-06-22 14:45:11.943851
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import pytest

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    shutil.rmtree(input_, output)

    # test dir
    (Path(input_) / 'dir').mkdir()
    (Path(input_) / 'dir/dir2').mkdir(parents=True)

    # test files
    (Path(input_) / 'file.py').touch()
    (Path(input_) / 'dir/file.py').touch()
    (Path(input_) / 'dir/file2.py').touch()
    (Path(input_) / 'dir/dir2/file.py').touch()

    # test files, compilation error

# Generated at 2022-06-22 14:45:14.818709
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/test_data/test1/src', 'test/test_data/test1/out', 'yotta')

# Generated at 2022-06-22 14:45:19.445037
# Unit test for function compile_files
def test_compile_files():
    """Test function compile_files."""
    # TODO: write a real test
    result = compile_files('./src/tests/data', './Temp', CompilationTarget.ES5)
    assert result.count == 3


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:45:24.864127
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test'
    output = 'build'
    input_paths = get_input_output_paths(input_, output)
    for paths in input_paths:
        _compile_file(paths, target=CompilationTarget.JS)
        _compile_file(paths, target=CompilationTarget.JSX)

# test_compile_files()

# Generated at 2022-06-22 14:45:34.595071
# Unit test for function compile_files
def test_compile_files():
    from .tests.python import py_to_adhoc
    from .tests.pyj import pyj_to_py_and_js

    files = list(get_input_output_paths(py_to_adhoc.input_,
                                    py_to_adhoc.output, py_to_adhoc.root))
    compile_files(py_to_adhoc.input_,
                  py_to_adhoc.output,
                  CompilationTarget.adhoc, py_to_adhoc.root)
    assert [f.output.stat().st_size for f in files] == [1078, 39, 17]
