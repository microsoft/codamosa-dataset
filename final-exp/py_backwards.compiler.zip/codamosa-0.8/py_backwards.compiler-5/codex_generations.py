

# Generated at 2022-06-22 14:43:24.198941
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    input_ = Path(__file__).parent.parent.parent / 'src'
    output = Path(__file__).parent.parent.parent / 'build'
    target = CompilationTarget.STANDARD_MODULE
    result = compile_files(input_, output, target)
    print(result)
    assert result.count == 5
    assert result.target == target
    assert 'numpy' in result.dependencies
    assert 'typing' in result.dependencies
    assert 'typed_ast' in result.dependencies


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:43:27.132762
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('examples/input', 'examples/output', CompilationTarget.DISTUTILS)
    assert compile_files('examples/static', 'examples/static_output', CompilationTarget.STATIC)

# Generated at 2022-06-22 14:43:36.071001
# Unit test for function compile_files
def test_compile_files():
    compile_files('./tests/0001-input', './tests/0001-output',
                  CompilationTarget.PYTHON)
    compile_files('./tests/0002-input', './tests/0002-output',
                  CompilationTarget.BROWSER)
    compile_files('./tests/0003-input', './tests/0003-output',
                  CompilationTarget.BROWSER)
    compile_files('./tests/0004-input', './tests/0004-output',
                  CompilationTarget.BROWSER)


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:43:37.965157
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test_input', 'test_output', CompilationTarget.nodejs), \
        'Compilation failed.'

# Generated at 2022-06-22 14:43:51.310963
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import shutil

    def _clean_dir(path: str):
        try:
            shutil.rmtree(path)
        except:
            pass

    directory = tempfile.mkdtemp()

# Generated at 2022-06-22 14:43:54.736388
# Unit test for function compile_files
def test_compile_files():
    compile_files(
        input_='test/test_files/test.py',
        output='test/test_files/test_out',
        target='js',
    )

# Generated at 2022-06-22 14:44:01.709704
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    input_ = tempfile.mkdtemp(prefix='input')
    output = tempfile.mkdtemp(prefix='output')
    filename = os.path.join(input_, 'test.py')
    with open(filename, 'w') as f:
        f.write('a = b\nc = d')
    result = compile_files(input_, output, CompilationTarget.TS)
    assert not result.errors
    assert len(result.dependencies) == 2
    assert os.path.exists(os.path.join(output, 'test.ts'))
    shutil.rmtree(input_)
    shutil.rmtree(output)

# Generated at 2022-06-22 14:44:08.853244
# Unit test for function compile_files
def test_compile_files():
    import os, shutil
    import pytest

    input_dir = os.path.normpath('test/resources/compile')
    output_dir = os.path.normpath('test/resources/compile_out')
    shutil.rmtree(output_dir, True)

    result = compile_files(input_dir, output_dir, CompilationTarget.PYTHON)
    assert result.count == 5

    for name in ('__init__.py', 'a.py', 'b.py'):
        with open('{}/{}'.format(output_dir, name), 'r') as f:
            assert f.read().strip() == 'print("{}")'.format(name)

# Generated at 2022-06-22 14:44:10.621381
# Unit test for function compile_files
def test_compile_files():
    pass


# Generated at 2022-06-22 14:44:23.001852
# Unit test for function compile_files
def test_compile_files():
    import pathlib

    def compile_files(input_, output, target, root=None):
        import os
        import ast

        dependencies = set()
        start = time()
        count = 0
        for paths in get_input_output_paths(input_, output, root):
            count += 1
            with paths.input.open() as f:
                code = f.read()
            try:
                transformed, deps = _transform(paths.input.as_posix(),
                                               code, target)
            except SyntaxError as e:
                raise CompilationError(paths.input.as_posix(),
                                       code, e.lineno, e.offset)
            try:
                paths.output.parent.mkdir(parents=True)
            except FileExistsError:
                pass

# Generated at 2022-06-22 14:44:38.818078
# Unit test for function compile_files
def test_compile_files():
    from .dump import dump_to_file
    from .compilation_targets import TARGETS
    from .types import COMPILATION_RESULT_SCHEMA
    import json
    import os
    import pytest

    # Make sure that all targets are present
    targets = os.path.join(os.path.dirname(__file__),
                           '..', '..', 'data', 'targets.json')
    assert os.path.exists(targets)
    with open(targets) as f:
        data = json.load(f)
    assert set(data.keys()) == set(TARGETS.__members__.keys())

    # Make sure that all targets are compiled and dumped to file
    for target in TARGETS:
        dump_to_file(target)
        path = os

# Generated at 2022-06-22 14:44:46.150076
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .utils.helpers import temporary_directory
    from io import StringIO
    from tempfile import mkdtemp
    from pathlib import Path
    import sys
    import subprocess

    # Create temporary directory

# Generated at 2022-06-22 14:44:57.111150
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    import os.path
    import sys
    import shutil

    test_dir = os.path.join(os.path.dirname(__file__), 'test')
    compiled_dir = os.path.join(test_dir, 'compiled')

    try:
        shutil.rmtree(compiled_dir)
    except FileNotFoundError:
        pass

    compile_files(os.path.join(test_dir, 'src'), compiled_dir, CompilationTarget.ES5)

    with open(os.path.join(compiled_dir, 'numbers.js')) as f:
        print(f.read(100000))

    with open(os.path.join(compiled_dir, 'numbers.d.ts')) as f:
        print

# Generated at 2022-06-22 14:44:57.767040
# Unit test for function compile_files
def test_compile_files():
    pass  # TODO

# Generated at 2022-06-22 14:45:05.404608
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/debugging/test1',
                         'tmp/test_compile_files_1', CompilationTarget.PYTHON25).count == 2
    assert compile_files('tests/data/debugging/test1',
                         'tmp/test_compile_files_2', CompilationTarget.PYTHON25,
                         'tests/data/debugging/test1/test.py').count == 1

# Generated at 2022-06-22 14:45:07.537585
# Unit test for function compile_files
def test_compile_files():
    compile_files('input/', 'output/', CompilationTarget.Python2,
                  root='py2_test')

# Generated at 2022-06-22 14:45:18.644033
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/test_data/input/simple_file.py',
                         'result',
                         target=CompilationTarget(0)).count == 1
    assert compile_files('test/test_data/input/',
                         'result',
                         target=CompilationTarget(0)).count == 10
    assert compile_files('test/test_data/input/',
                         'result',
                         target=CompilationTarget(0),
                         root='test/test_data/input/').count == 10
    assert compile_files('test/test_data/input/',
                         'result',
                         target=CompilationTarget(0),
                         root='test/test_data/input/library').count == 9



# Generated at 2022-06-22 14:45:25.558449
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    in_dir = os.path.join('Test', 'In')
    out_dir = os.path.join('Test', 'Out')
    root = os.path.join('Test', 'Code')
    shutil.rmtree(out_dir, ignore_errors=True)
    compile_files(in_dir, out_dir, CompilationTarget.JS, root=root)
    shutil.rmtree(out_dir, ignore_errors=True)


# Generated at 2022-06-22 14:45:36.484317
# Unit test for function compile_files
def test_compile_files():
    # pylint: disable=import-outside-toplevel
    import os
    import tempfile
    import json
    from shutil import rmtree
    from .transformers import transformers as ts
    from .transformers.docs import StringLiteralsDocsTransformer
    from .transformers.dependencies import DependenciesTransformer
    # pylint: enable=import-outside-toplevel


# Generated at 2022-06-22 14:45:46.192388
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import shutil
    import glob
    import os
    
    input_ = "./test/stubs"
    output = "./test/tmp"
    target = CompilationTarget.PYTHON36
    root = "./test/stubs"
    
    shutil.rmtree(output, ignore_errors=True)
    
    compile_files(input_, output, target, root)
    
    total = 0
    for filename in glob.glob(output + "/**/**", recursive=True):
        if os.path.isfile(filename):
            total += os.path.getsize(filename)
    
    assert total > 0