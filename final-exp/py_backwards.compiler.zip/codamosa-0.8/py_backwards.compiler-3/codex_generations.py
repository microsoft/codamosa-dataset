

# Generated at 2022-06-22 14:43:17.695921
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test/input'
    output = 'test/output'
    res = compile_files(input_, output, CompilationTarget.BROWSER)
    assert 8 == res.count
    assert CompilationTarget.BROWSER == res.target

# Generated at 2022-06-22 14:43:25.906927
# Unit test for function compile_files
def test_compile_files():
    compile_files("tests/examples/hello_world", "tests/unit/compile_files/hello_world", CompilationTarget.Python)
    with open("tests/unit/compile_files/hello_world/hello.py", "r") as f:
        assert(f.read() == "#!/usr/bin/env python3\nprint(\"hello\")\n")
    with open("tests/unit/compile_files/hello_world/main.py", "r") as f:
        assert(f.read() == "import hello\nprint(\"world\")\n")
    compile_files("tests/examples/hello_world", "tests/unit/compile_files/hello_world", CompilationTarget.Bash)

# Generated at 2022-06-22 14:43:30.866252
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os

    input_ = os.path.join(os.path.dirname(__file__), '..', 'examples', '23')
    output = tempfile.mkdtemp()

    try:
        compile_files(input_, output, CompilationTarget.PYTHON_2)
    finally:
        shutil.rmtree(output)

# Generated at 2022-06-22 14:43:42.486802
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import tempfile
    from .types import CompilationResult
    from .utils.helpers import debug

    debug(lambda: 'Compile test started.')

    # Prepare test directory
    tmp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmp_dir, 'src'))
    open(os.path.join(tmp_dir, 'src', 'test.py'), 'a').close()
    open(os.path.join(tmp_dir, 'src', 'test2.py'), 'a').close()
    os.makedirs(os.path.join(tmp_dir, 'bin'))

    # Run tests

# Generated at 2022-06-22 14:43:50.173787
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/transform', 'tests/data/output', CompilationTarget.python)


if __name__ == '__main__':
    import sys
    argv = sys.argv
    if len(argv) == 3:
        compile_files(argv[1], argv[2], CompilationTarget.python)
    else:
        print('Usage: python -m gnes.cli.compile <input> <output>')
        sys.exit(1)

# Generated at 2022-06-22 14:44:00.422546
# Unit test for function compile_files
def test_compile_files():
    filename = 'test.py'
    code = (
        "from sys import stdin, stdout, stderr\n"
        "import os, shutil\n"
        "def main():\n"
        "    cmd = stdin.read()\n"
        "    try:\n"
        "        os.system(cmd)\n"
        "    except: stderr.write('Error\\n')\n"
    )
    target = CompilationTarget.SERVER

# Generated at 2022-06-22 14:44:10.710941
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .tests.test_resources import get_test_path
    from .utils.helpers import run_cmd
    from .exceptions import CompilationError

    def _cleanup():
        if os.path.exists('tests/tmp'):
            shutil.rmtree('tests/tmp')

    _cleanup()

    test_path = get_test_path('build/tmp')
    test_path.mkdir(parents=True)

    compile_files('tests/data/simple/input',
                  'tests/data/simple/output',
                  CompilationTarget.c)

    run_cmd('cp tests/data/simple/output/main.c tests/tmp')
    run_cmd('gcc -o tests/tmp/main tests/tmp/main.c')
    assert run_cmd

# Generated at 2022-06-22 14:44:22.967243
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/fixtures/example_input/'
    output = 'tests/fixtures/example_output/'
    target = CompilationTarget.PROTO3
    result = compile_files(input_, output, target)
    assert result.target == target
    assert result.dependencies == list('i')
    assert result.count == 2

# Generated at 2022-06-22 14:44:32.750722
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tempdir:
        result = compile_files('fixtures', os.path.join(tempdir, 'out'),
                               CompilationTarget.JAVA)

        assert result.target == CompilationTarget.JAVA
        assert result.count == 1
        assert 'fixtures/helloworld/helloworld.py' in result.dependencies

        with open(os.path.join(tempdir, 'out/helloworld/hello.java')) as f:
            assert f.read() == open('fixtures/helloworld/hello.java').read()

# Generated at 2022-06-22 14:44:41.099625
# Unit test for function compile_files
def test_compile_files():

    import os
    import shutil

    import pytest

    from .exceptions import CompilationError

    def test_it(input_: str, output: str, target: CompilationTarget,
                root: Optional[str] = None, errors: int = 0) -> None:
        try:
            result = compile_files(input_, output, target, root)
        except CompilationError as e:
            assert errors > 0
            return

        assert result.count == errors
        assert result.target == target
        assert result.time > 0.0
        assert sorted(result.dependencies) == []
        assert len(result.dependencies) == len(set(result.dependencies))

        os.remove(output)
        shutil.rmtree(output)
