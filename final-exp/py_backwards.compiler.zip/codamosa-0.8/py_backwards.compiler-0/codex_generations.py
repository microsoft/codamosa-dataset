

# Generated at 2022-06-22 14:43:19.068639
# Unit test for function compile_files
def test_compile_files():
  assert False

# Generated at 2022-06-22 14:43:30.950664
# Unit test for function compile_files
def test_compile_files():
    import unittest
    import shutil
    import tempfile

    def count_files(path: str) -> int:
        count = 0
        for _ in path.rglob('*'):
            count += 1
        for _ in path.glob('*'):
            count -= 1
        return count

    class TestCompileFiles(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.input = self.tempdir / 'input'
            self.output = self.tempdir / 'output'
            self.input.mkdir(parents=True)
            self.output.mkdir(parents=True)
            for suffix in 'py', 'pyx':
                (self.input / 'main.{}'.format(suffix)).touch()


# Generated at 2022-06-22 14:43:35.479751
# Unit test for function compile_files
def test_compile_files():
    compile_files('/home/daniel/Git/SLang/SLang/SLang/tests/data/source',
                  '/home/daniel/Git/SLang/SLang/SLang/tests/data/build/python',
                  CompilationTarget.PYTHON,
                  root='../data')
    pass

# Generated at 2022-06-22 14:43:39.597718
# Unit test for function compile_files
def test_compile_files():
    # Apply some inputs
    # Function compile_files should return CompilationResult
    # with the number of files compiled, the time it took, the target of
    # the compilation, and all the dependencies required to compile the files
    assert True


# Generated at 2022-06-22 14:43:52.018043
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .exceptions import CompilationError
    from .utils.helpers import redirect_stderr, redirect_stdout

    with pytest.raises(CompilationError):
        compile_files("./tests/testdata/invalid/test1.py", "./", CompilationTarget.PY2)

    with redirect_stdout() as stdout_:
        with redirect_stderr() as stderr_:
            compile_files(
                "./tests/testdata/correct/", "./tests/testdata/output/", CompilationTarget.PY2)
    assert stdout_.getvalue() == ""
    assert stderr_.getvalue() == ""


# Generated at 2022-06-22 14:44:01.730867
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import tempfile
    import pathlib

    tmpdir = tempfile.TemporaryDirectory()
    tmpdir_path = pathlib.Path(tmpdir.name)

    try:
        subprocess.check_call([
            'python3', '-m', 'pip', 'install',
            '--user', 'https://github.com/mhilpisch/pybpp/archive/master.zip'
        ], cwd=tmpdir.name)
    except Exception:
        raise ValueError('Could not install PyBPP')

    input_ = tmpdir_path / 'input'
    output = tmpdir_path / 'output'
    target = CompilationTarget.GENERATED_CODE
    input_.mkdir()
    output.mkdir()


# Generated at 2022-06-22 14:44:11.314010
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os
    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()
    shutil.copytree(os.path.join(os.path.dirname(__file__), '..', '..', 'dev_data', 'examples', 'dir_compile'),
                    os.path.join(input_, 'dir_compile'))
    result = compile_files(input_, output, CompilationTarget.PYTHON2)
    assert result.compiled == 13
    #assert result.dependencies == [
    #    'd2to1', 'distribute', 'setuptools', 'six'
    #]
    assert os.path.exists(os.path.join(output, 'dir_compile', 'hello.py'))

# Generated at 2022-06-22 14:44:15.659442
# Unit test for function compile_files
def test_compile_files():
    # TODO: Add unit test
    raise NotImplementedError()

__all__ = [
    "test_compile_files",
    "compile_files",
]

# Generated at 2022-06-22 14:44:22.379067
# Unit test for function compile_files
def test_compile_files():
    def compile_files(base_path):
        import os.path
        from .exceptions import CompilationError, TransformationError
        from .files import get_input_output_paths
        from .compiler import compile_files as _compile_files
        input_path = os.path.join(base_path, 'input')
        output_path = os.path.join(base_path, 'output')
        try:
            import os
            os.mkdir(output_path)
        except FileExistsError:
            pass
        try:
            compile_result = _compile_files(input_path, output_path,
                                            CompilationTarget.ES5)
        except TransformationError as e:
            print(e)
            return
        except CompilationError as e:
            print(e)
            return
       

# Generated at 2022-06-22 14:44:34.813936
# Unit test for function compile_files
def test_compile_files():
    import subprocess
    import math
    import numpy

    paths, deps = get_input_output_paths('tests/backend/compiler/', 'tests/backend/compiler-out/', 'tests/backend/')
    assert len(paths) == 1, 'Wrong number of files'
    assert len(paths[0]) == 2, 'Wrong number of output files'
    assert 'tests/backend/compiler/test.py' == paths[0].input.as_posix(), 'Wrong input file'
    assert 'tests/backend/compiler-out/test.py' == paths[0].output.as_posix(), 'Wrong output file'
    assert len(deps) == 2, 'Wrong number of dependencies'

# Generated at 2022-06-22 14:44:45.625734
# Unit test for function compile_files
def test_compile_files():
    assert(compile_files(
        input_='tests/data/tests',
        output='tests/data/compiled',
        target='python37',
        root='tests/data/')
        ==
        CompilationResult(1, 0, 'python37', ['pytest', 'typing']))

# Generated at 2022-06-22 14:44:50.863437
# Unit test for function compile_files
def test_compile_files():
    input_ = './tests/data/input'
    output = './tests/data/output'
    result = compile_files(input_, output, CompilationTarget.PYTHON36)
    assert result.count == 1
    assert result.target == CompilationTarget.PYTHON36
    assert result.dependencies == ['template']


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:45:02.346766
# Unit test for function compile_files
def test_compile_files():
    from .models import CompilationResult, CompilationTarget
    from .utils.paths import Path
    from pathlib import Path as Path1
    from .files import get_input_output_paths, InputOutput

    # FIXME: What is this??
    class TempPath(Path):
        def __init__(self, path: str) -> None:
            super().__init__(path)
        def __enter__(self, *args: object, **kwargs: object) -> Path1:
            if self.exists():
                raise FileExistsError
            return self
        def __exit__(self, *args: object, **kwargs: object) -> None:
            self.unlink()


# Generated at 2022-06-22 14:45:15.011178
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    from os import path
    from .types import CompilationTarget

    out_dir = path.join(path.dirname(__file__), 'tests', 'compile_files_output')
    base_dir = path.join(path.dirname(__file__), 'tests')
    for f in ['tests/test1.py', 'tests/test2.py']:
        pathlib.Path(out_dir).mkdir(parents=True, exist_ok=True)

        test_file = f[len('tests/'):]
        result = compile_files(path.join(base_dir, test_file),
                               path.join(out_dir, test_file),
                               CompilationTarget.PYTHON_3_7)

# Generated at 2022-06-22 14:45:25.897861
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import tempdir, change_environment, get_environment
    from .utils.helpers import execute, assert_equal, assert_exists

    class Transformer:
        target = CompilationTarget.JS

        @staticmethod
        def transform(tree: ast.AST) -> ast.AST:
            return tree

    def _test(input_: str, output: str) -> None:
        with change_environment(input=input_, output=output):
            assert_equal(execute('pjsc.py "test.py"', capture_output=True),
                         'test.js:\n')
            assert_exists('test.js')


# Generated at 2022-06-22 14:45:37.520238
# Unit test for function compile_files
def test_compile_files():
    import tempfile, os
    from .files import PROJECT_ROOT

    tempdir = tempfile.TemporaryDirectory()
    project_root = PROJECT_ROOT.resolve().as_posix() + '/'
    result = compile_files(
        input_='{}scripts/pycubexr/tests/files/compile'.format(project_root),
        output=tempdir.name,
        target=CompilationTarget.py2)
    assert result.count == 5

# Generated at 2022-06-22 14:45:41.549588
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import tempfile
    import shutil
    import pytest

    _input = pathlib.Path(__file__).parent.absolute() / 'examples'
    _output = pathlib.Path(tempfile.mkdtemp(prefix='pp3_test_compile_files_'))

    compile_files(_input, _output, CompilationTarget.JS)

    _input_js = _input.resolve() / 'js'
    _output_js = _output.resolve() / 'js'
    for file in _input_js.iterdir():
        assert _output_js.joinpath(file.name).exists()

    shutil.rmtree(_output.resolve(), ignore_errors=True)


# Generated at 2022-06-22 14:45:47.888832
# Unit test for function compile_files
def test_compile_files():
    compile_files("tests/test_data/input/simple_task",
    			  "tests/test_data/output/simple_task",
    			  CompilationTarget(CompilationTarget.Function.SERVER,
    			  					CompilationTarget.Language.PYTHON3,
    			  					CompilationTarget.Platform.DEFAULT))

# Generated at 2022-06-22 14:45:53.462999
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/fixtures/input/'
    output = 'tests/fixtures/output'
    target = CompilationTarget.TO_FUNCTION
    root = 'tests/fixtures/'
    assert compile_files(input_, output, target, root) == CompilationResult(5, 0.0, CompilationTarget.TO_FUNCTION, ['pybind11', '_cstack'])

# Generated at 2022-06-22 14:45:53.992733
# Unit test for function compile_files
def test_compile_files():
    pass