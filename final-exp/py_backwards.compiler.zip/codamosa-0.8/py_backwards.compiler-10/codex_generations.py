

# Generated at 2022-06-22 14:43:22.277605
# Unit test for function compile_files
def test_compile_files():
    from .examples import compile_examples
    compile_examples()

# Generated at 2022-06-22 14:43:31.973968
# Unit test for function compile_files
def test_compile_files():
    import os
    import subprocess
    import sys
    import tempfile
    import shutil
    import pytest
    with tempfile.TemporaryDirectory() as td:
        with open(os.path.join(td, 'a.js'), 'w') as f:
            f.write('let a = 7;\n'
                    'let b = 10;\n'
                    'let c = a + b;\n'
                    'console.log(c);\n')
        out = subprocess.check_output([sys.executable, '-m', 'js2py', td, os.path.join(td, 'out'),
                                       '--target', 'node.js']).decode('utf-8')
    assert 'let a = 7;' in out
    assert 'let b = 10;' in out

# Generated at 2022-06-22 14:43:41.735707
# Unit test for function compile_files
def test_compile_files():
    output_path = Path('./test/output')
    output_path.mkdir(parents=True, exist_ok=True)
    r = compile_files('./test/input', './test/output', CompilationTarget.ES5_STRICT)
    assert r.source_files == 5
    assert r.time > 0
    assert r.target == CompilationTarget.ES5_STRICT
    assert r.dependencies == ['test/output/test.js']
    # for file in Path('./test/output').iterdir():
    #     print(file.name)
    #     print(file.read_text())

# Generated at 2022-06-22 14:43:46.492033
# Unit test for function compile_files
def test_compile_files():
    compile_files(input_='tests/code/func',
                  output='tests/output/func',
                  target=CompilationTarget.C_LANGUAGE)
    compile_files(input_='tests/code/func',
                  output='tests/output/func',
                  target=CompilationTarget.INTEL_ASM)

# Generated at 2022-06-22 14:43:55.703356
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os.path
    input_ = './tests/input/'
    output = './tests/output/'
    if os.path.exists(output):
        shutil.rmtree(output)
    result = compile_files(input_, output, CompilationTarget.PYTHON)
    assert result.files == 2
    assert result.target == CompilationTarget.PYTHON
    assert len(result.dependencies) == 8
    print('Tests finished successfully')

test_compile_files()

# Generated at 2022-06-22 14:43:59.616879
# Unit test for function compile_files
def test_compile_files():
    input_ = Path('test_inputs/test_compile_files')
    output = Path('test_outputs/test_compile_files')
    output.mkdir(exist_ok=True)
    compile_files(input_, output, CompilationTarget.PY35)
    assert output.as_posix() == input_.as_posix()

# Generated at 2022-06-22 14:44:06.824748
# Unit test for function compile_files
def test_compile_files():
    from os.path import dirname
    from .tests import TEST_FILES

    root = dirname(__file__) + '/tests/input/'
    output = dirname(__file__) + '/tests/output/'
    result = compile_files(root, output, CompilationTarget.PYTHON27)
    assert sum(1 for (path, _) in result.dependencies) == len(TEST_FILES)

# Generated at 2022-06-22 14:44:07.807956
# Unit test for function compile_files
def test_compile_files():
    # TODO
    assert True

# Generated at 2022-06-22 14:44:14.598051
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('tests/data/types/input', 
                        'tests/data/types/output', 
                        CompilationTarget.JS)
    assert compile_files('tests/data/types/input', 
                        'tests/data/types/output', 
                        CompilationTarget.VYPER)
    assert compile_files('tests/data/types/input', 
                        'tests/data/types/output', 
                        CompilationTarget.LANGUAGE_FLASK)
    assert compile_files('tests/data/types/input', 
                        'tests/data/types/output', 
                        CompilationTarget.LLVM)
    assert compile_files('tests/data/types/input', 
                        'tests/data/types/output', 
                        CompilationTarget.RUST)   

test_compile_files

# Generated at 2022-06-22 14:44:21.985146
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import autopep8
    import sys
    from .runner import run_file
    from .utils.helpers import assert_error

    def compile_and_run(
            code: str) -> Tuple[str, Tuple[int, str, str, str]]:
        with tempfile.TemporaryDirectory() as input_, \
                tempfile.TemporaryDirectory() as output:
            with open(input_ + '/test.py', 'w') as f:
                f.write(autopep8.fix_code(code))
            compile_files(input_, output, CompilationTarget.PYTHON_3_6, input_)
            return run_file(output + '/test.py')

    assert compile_and_run(
        'import a; print(a.a)')

# Generated at 2022-06-22 14:44:37.487397
# Unit test for function compile_files
def test_compile_files():
    # Test setup
    path = pathlib.Path(__file__)
    input_ = str(path.parent / 'tests' / 'in')
    output = str(path.parent / 'tests' / 'out')
    # Compile files
    result = compile_files(input_, output, CompilationTarget.PYTHON36)
    # Expected number of files
    assert result.count == 2
    # Expected number of dependencies
    assert len(result.dependencies) == 2
    # Expected list of dependencies
    assert result.dependencies == [
        'typing',
        'astunparse'
    ]

# Generated at 2022-06-22 14:44:49.902439
# Unit test for function compile_files
def test_compile_files():
    import sys, tempfile
    from .transformers import Transformer, ShiftTransformer

    class TestTransformer(Transformer):
        @staticmethod
        def transform(tree):
            tree.body[0].value.n += 5
            return Transformer.Dependencies()

    class FailTransformer(Transformer):
        @staticmethod
        def transform(tree):
            raise Exception('Test exception')

    class FailTransformer2(Transformer):
        @staticmethod
        def transform(tree):
            raise ValueError('Test exception 2')

    class FailTransformer3(Transformer):
        @staticmethod
        def transform(tree):
            raise SyntaxError('Test exception 3', '', 0, 0, None)

    def check_result(result):
        assert result.count == 2
        assert result.execution_time > 0.0

# Generated at 2022-06-22 14:44:52.346139
# Unit test for function compile_files
def test_compile_files():
    compile_files(".", "./tests/out", 0)
    print("Test Finished!")

# Generated at 2022-06-22 14:44:56.190545
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('./tests/compiler/cases', './tests/compiler/outputs/' + str(int(time() * 1000)), CompilationTarget.HTML)
    assert result.count > 1
    assert result.duration > 0.1


# Generated at 2022-06-22 14:44:59.322786
# Unit test for function compile_files
def test_compile_files():
    compile_files('python-ex/', 'build/', CompilationTarget.WEB)
    assert Path('build/hello_web.py').exists()



# Generated at 2022-06-22 14:45:01.669855
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    raise NotImplementedError()

# Generated at 2022-06-22 14:45:08.443967
# Unit test for function compile_files
def test_compile_files():
    input_ = 'test_compiler/'
    output = 'test_compiler_py/'
    root = 'test_compiler_py/'
    target = CompilationTarget.PYTHON
    compile_files(input_, output, target, root)
    assert compile_files(input_, output, target, root) == (1, 0.0001838207244873047, CompilationTarget.PYTHON, ['numpy'])

# Generated at 2022-06-22 14:45:09.363965
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-22 14:45:21.389371
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import pathlib
    import re
    import subprocess
    tmpdir = tempfile.mkdtemp()
    assert compile_files(pathlib.Path('.'), tmpdir, CompilationTarget.SELF).count == 0
    assert compile_files(pathlib.Path('.'), tmpdir, CompilationTarget.TRIVIAL).count == 0
    assert compile_files(pathlib.Path('.'), tmpdir, CompilationTarget.TEST).count == 0
    assert compile_files(pathlib.Path('.'), tmpdir, CompilationTarget.TEST_CLIENT).count == 0
    assert compile_files(pathlib.Path('.'), tmpdir, CompilationTarget.TEST_SERVER).count == 0

# Generated at 2022-06-22 14:45:23.358570
# Unit test for function compile_files
def test_compile_files():
    from .test.test_compiler import test_compile_files as test
    return test()

# Generated at 2022-06-22 14:45:38.466018
# Unit test for function compile_files
def test_compile_files():
    input_dir = 'tests/data/compile_files/source'
    output_dir = 'tests/data/compile_files/target'
    target = CompilationTarget.AS3
    compile_files(input_dir, output_dir, target)

# Generated at 2022-06-22 14:45:49.731793
# Unit test for function compile_files
def test_compile_files():
    # Test imports
    assert compile_files('tests/basic', 'output', CompilationTarget.PY2) \
        .dependencies == ['__future__']

    # Test imports
    assert compile_files('tests/compile', 'output', CompilationTarget.PY3) \
        .dependencies == []

    # Test recursion
    assert compile_files('tests/recursion', 'output', CompilationTarget.PY3) \
        .dependencies == ['__future__']

    # Test modification of user files
    assert compile_files('tests/modification', 'output', CompilationTarget.PY3) \
        .dependencies == []
    assert compile_files('tests/modification', 'output', CompilationTarget.PY2) \
        .dependencies == ['__future__']

# Generated at 2022-06-22 14:46:00.433830
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import glob
    import pytest
    # prepare
    print("Preparing...")
    if not os.path.exists("temp"):
        os.makedirs("temp")
    if os.path.exists("temp/test"):
        shutil.rmtree("temp/test")
    shutil.copytree("test", "temp/test")
    # test
    from .compiler import compile_files, CompilationTarget
    res = compile_files("temp/test", "temp/test/test_output", CompilationTarget.PYTHON)
    # res1 = compile_files("temp/test", "temp/test/test_output", CompilationTarget.RUNTIME)
    os.chdir("temp/test")

    # compare

# Generated at 2022-06-22 14:46:10.158714
# Unit test for function compile_files
def test_compile_files():
    import os
    import subprocess
    import tempfile
    import pytest

    test_path = os.path.dirname(__file__)
    test_files = os.path.join(test_path, 'test_files')
    compiler_path = os.path.join(test_path, '..', 'compiler.py')

    def compare_trees(file1: str, file2: str) -> bool:
        from astunparse import parse as parse_tree
        tree1 = parse_tree(file1)
        tree2 = parse_tree(file2)
        return str(tree1) == str(tree2)

    def compare_paths(path1: str, path2: str) -> bool:
        with open(path1, 'r') as f:
            file1 = f.read()

# Generated at 2022-06-22 14:46:17.855796
# Unit test for function compile_files
def test_compile_files():
    import os
    import tempfile
    import shutil

    current_path = os.path.dirname(__file__)


# Generated at 2022-06-22 14:46:23.284346
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from os import path

    with TemporaryDirectory() as d:
        input_ = path.join(d, 'a')
        output = path.join(d, 'b')
        with open(input_, 'w') as f:
            f.write('print(3 + 4)')
        compile_files('a', 'b', 'transpile')
        with open(output, 'r') as f:
            assert f.read() == 'console.log(3 + 4);\n'

# Generated at 2022-06-22 14:46:29.372372
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from . import __version__
    from .files import get_paths_to_compile
    from .utils.helpers import joined_paths

    with TemporaryDirectory() as output:
        result = compile_files(
            input_=joined_paths('src', 'test', 'fixtures'),
            output=output,
            target=CompilationTarget.ES5,
            root=joined_paths('src', 'test', 'fixtures'),
        )

        assert result.version == __version__
        assert len(result.paths) == len(set(result.paths))

        compiled_files = [str(path.relative_to(output))
                          for path in get_paths_to_compile(output)]
        compiled_files.sort()

        assert result.paths == compiled

# Generated at 2022-06-22 14:46:39.414814
# Unit test for function compile_files
def test_compile_files():
    import tempfile

    def create_file(name: str, content: str):
        with open(name, mode='w') as f:
            f.write(content)

    with tempfile.TemporaryDirectory() as temp:
        # Create test.py
        test_py_name = tempfile.gettempdir() + '/test.py'
        test_py = '''
        def foo(x):
            return x + 42
        '''
        create_file(test_py_name, test_py)

        # Create main.py
        main_py_name = tempfile.gettempdir() + '/main.py'
        main_py = '''
        import test

        sum = test.foo(1) + test.foo(2)
        '''

# Generated at 2022-06-22 14:46:50.538702
# Unit test for function compile_files
def test_compile_files():
    from functools import partial
    from pprint import pprint
    import pathlib
    testcase_path = pathlib.Path(__file__).parent / 'testcases'
    test_compile_files = partial(compile_files,
                                 input_=str(testcase_path / 'input'),
                                 output=str(testcase_path / 'output'),
                                 target=CompilationTarget.python3)

    def test_compile_files_valid():
        result = test_compile_files()
        assert result.count == 4
        assert result.elapsed > 0
        assert result.target == CompilationTarget.python3
        assert sorted(result.dependencies) == [
            'java.lang.Iterable',
        ]


# Generated at 2022-06-22 14:46:51.900441
# Unit test for function compile_files
def test_compile_files():
    # TODO, needs environments getting setup
    pass