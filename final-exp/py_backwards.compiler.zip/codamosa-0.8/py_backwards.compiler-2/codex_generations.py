

# Generated at 2022-06-22 14:43:28.399110
# Unit test for function compile_files
def test_compile_files():
    from .utils.test import run_test_compilation
    run_test_compilation(compile_files,
                         '{"a": 1, "b": "2", "c": [1, 2, 3, 4], "d": {"d": 1}}',
                         '{"a": 1, "b": "2", "c": [1, 2, 3, 4], "d": {"d": 1}}',
                         '{"a": 1, "b": "2", "c": [1, 2, 3, 4], "d": {"d": 1}}')

# Generated at 2022-06-22 14:43:39.547768
# Unit test for function compile_files
def test_compile_files():
    from .types import CompilationTarget
    from .exceptions import CompilationError, TransformationError
    from pathlib import Path

    input_ = Path('/tmp/input')
    output = Path('/tmp/output')
    target = CompilationTarget.CLEVER

    # Normal
    def normal():
        input_.mkdir(parents=True)
        (input_ / '0').write_text('0')
        (input_ / 'a' / '0').write_text('0')
        (input_ / 'a' / 'b' / '0').write_text('0')
        compile_files(input_, output, target)
        assert output.read_text() == '0'

    normal()
    output.rmtree()

    # Fail in compilation

# Generated at 2022-06-22 14:43:51.961213
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files."""
    from shutil import rmtree
    from pathlib import Path
    from tempfile import mkdtemp
    from os.path import exists
    from .exceptions import CompilationError

    input_ = 'source'
    output = 'build'
    root = 'project'

    def paths_as_posix(paths: List[InputOutput]) -> List[Tuple[str, str]]:
        return [(p.input.as_posix(), p.output.as_posix()) for p in paths]

    # Function returns paths to input and output files.
    assert paths_as_posix(get_input_output_paths(input_, output, root)) == \
        [('/project/source/file.py', '/project/build/file.py')]

    # Files

# Generated at 2022-06-22 14:44:01.248930
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationResult
    from .transforms import default_transformers

    # dirty hack for mocking _transform
    global _transform
    _transform.__wrapped__ = _transform
    _transform.__defaults__ = (_transform.__defaults__[0],
                               list(default_transformers))

    # compile files
    result = compile_files(Path(__file__).parent / 'files',
                           Path(__file__).parent / 'files' / 'output',
                           CompilationTarget.PYTHON27)

    # test result
    assert isinstance(result, CompilationResult)
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON27
    assert result.elapsed >= 0
    assert result.dependencies == ['json']



# Generated at 2022-06-22 14:44:11.001557
# Unit test for function compile_files
def test_compile_files():

    from pathlib import Path
    from .__main__ import parser, main
    from .utils.helpers import temp_chdir

    input_ = Path('input')
    output = Path('output')
    root = Path.cwd()

    with temp_chdir():
        input_.mkdir()
        output.mkdir()
        with open(input_ / 'main.py', 'w') as f:
            f.write('print("Hello, world!")')
        with open(input_ / 'subfolder' / 'subscript.py', 'w') as f:
            f.write('import main')

        result = main(parser.parse_args([input_, output]))

    assert(result.count == 2)
    assert(output / 'subfolder' / 'subscript.py' in result.dependencies)


# Generated at 2022-06-22 14:44:23.237707
# Unit test for function compile_files
def test_compile_files():
    from .files import InputOutput
    from .types import CompilationTarget, CompilationResult
    import shutil
    import tempfile
    import os

    input_ = os.path.abspath(
        os.path.join(os.path.dirname(__file__), '../', 'tests', 'source'))
    output = os.path.join(tempfile.gettempdir(), 'bambipy-test-output')
    result = compile_files(input_, output, CompilationTarget.FUNCTION)
    assert result.compiled == 282
    assert result.target == CompilationTarget.FUNCTION
    assert result.dependencies == []

    result = compile_files(input_, output, CompilationTarget.MODULE)
    assert result.compiled == 282
    assert result.target == CompilationTarget.MODULE


# Generated at 2022-06-22 14:44:30.453181
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .files import InputOutput

    with Path('/tmp/stak/test/test.py').open('w') as f:
        f.write('''# coding: utf-8

import os
import sys
import fileinput

a = 1 + 2
''')

    target = CompilationTarget.PYTHON_TARGET
    res = compile_files('/tmp/stak/test', '/tmp/stak/build', target)
    print(res)

# Generated at 2022-06-22 14:44:37.565101
# Unit test for function compile_files
def test_compile_files():
    output = Path('./tmp/compile_files_test')
    with output.open('w') as f:
        f.write('Writing to existing file shouldn\'t raise errors')
    compile_files('./tests/fixtures', './tmp/compile_files_test',
                  CompilationTarget.PYTHON)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:44:46.351727
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('/home/yihui/Documents/Python/PythonRunner/python-runner/src','/home/yihui/Documents/Python/PythonRunner/python-runner/src',CompilationTarget.ES6)
    print(result.count,result.target,result.time,result.dependencies)
    assert result.count == 2 and result.time >= 0 and result.target == CompilationTarget.ES6 and isinstance(result.dependencies, list)


# Generated at 2022-06-22 14:44:57.180275
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os

    def write_file(path: str, content: str) -> None:
        with open(path, 'w') as f:
            f.write(content)

    def compile_test(input_: str, output: str, target: CompilationTarget) -> None:
        input_dir = tempfile.mkdtemp()
        output_dir = tempfile.mkdtemp()
        try:
            write_file(os.path.join(input_dir, 'file.py'), input_)
            write_file(os.path.join(output_dir, 'file.py'), output)
            result = compile_files(input_dir, output_dir, target)
            result.verify()
        finally:
            shutil.rmtree(input_dir)
            shut

# Generated at 2022-06-22 14:45:08.871251
# Unit test for function compile_files
def test_compile_files():
    try:
        compile_files('tests/compiler/director', 'tmp/compilation', 'julia')
    except CompilationError as e:
        e.print_message()
        print(e.code)
        print(' ' * (e.offset + 9) + '^')
    except:
        raise
    else:
        print('Tests passed.')


# Generated at 2022-06-22 14:45:13.830605
# Unit test for function compile_files
def test_compile_files():
    with tempfile.TemporaryDirectory() as output:
        result = compile_files(path.Dir('src/tests/files').path,
                               output, CompilationTarget.GENERATED)
        print(result)
        assert result.count == 1


# Generated at 2022-06-22 14:45:24.818010
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    curr_dir = os.path.dirname(__file__)
    test_dir = os.path.join(curr_dir, 'test')

    # init
    shutil.rmtree(os.path.join(test_dir, 'output'), ignore_errors=True)

    import common.compiler as compiler

    compiler.compile_files(os.path.join(test_dir, 'input'),
                           os.path.join(test_dir, 'output'),
                           compiler.CompilationTarget.target_2)

    # clean-up
    shutil.rmtree(os.path.join(test_dir, 'output'), ignore_errors=True)

    assert(True)
test_compile_files()

# Generated at 2022-06-22 14:45:25.360375
# Unit test for function compile_files
def test_compile_files():
    # TODO: add tests
    pass

# Generated at 2022-06-22 14:45:36.084244
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test/data/empty', 'target/data/empty',
                         CompilationTarget.CPY3, 'test') \
        == CompilationResult(0, 0, CompilationTarget.CPY3, [])
    assert compile_files('test/data/empty_dir', 'target/data/empty_dir',
                         CompilationTarget.CPY3, 'test') \
        == CompilationResult(0, 0, CompilationTarget.CPY3, [])
    assert compile_files('test/data/ap8', 'target/data/ap8',
                         CompilationTarget.CPY3, 'test') \
        == CompilationResult(3, 0, CompilationTarget.CPY3, [])

# Generated at 2022-06-22 14:45:45.111734
# Unit test for function compile_files
def test_compile_files():
    from .files import get_test_input_output
    from .transformers import Py27Transformer
    import pytest
    from pathlib import Path

    test_target = Py27Transformer.target

    for input_, output in get_test_input_output():
        print('Test {0}'.format(input_))

        result = compile_files(input_, output, test_target)

        assert result.target == test_target

        assert Path(output).exists(), 'Output file should exists'
        assert len(result.dependencies) > 0, 'Dependencies should exists'


# Generated at 2022-06-22 14:45:57.214053
# Unit test for function compile_files
def test_compile_files():
    input_ = './ypypypypypypypypypypypypypypypy'
    output = './ypypypypypypypypypypypypypypypy'
    target = 'js'
    root = 'ypypypypypypypypypypypypypypypypypypypypypypypypypy'

# Generated at 2022-06-22 14:46:05.272701
# Unit test for function compile_files
def test_compile_files(): 
    from pathlib import Path
    import os
    import subprocess
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .compiler import compile_files
    from .utils.helpers import debug
    from .names.base import FQN
    from .transformers.base import FunctionType, Variable

    test_path = Path(os.path.dirname(os.path.abspath(__file__)))
    test_cwd = test_path / 'test_cwd'
    input_path = test_cwd / 'input'
    output_path = test_cwd / 'output'

    os.chdir(test_cwd)
    subprocess.call(['git', 'init'])
    subprocess.call(['git', 'add', 'input'])

# Generated at 2022-06-22 14:46:11.731357
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .files import get_input_output_paths, InputOutput
    from .utils.temp import TempDir, TempFile
    
    root = TempDir()

    for path in ['test.js', os.path.join('test', 'test.js')]:
        TempFile(root, path, 'console.log(0);')

    input_ = str(root)
    output = os.path.join(str(root), 'build')

    compile_files(input_, output, 'ES6')

    paths = list(get_input_output_paths(input_, output, root))
    assert len(paths) == 2
    assert paths[0].input.as_posix() == os.path.join(input_, 'test.js')

# Generated at 2022-06-22 14:46:12.865912
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-22 14:46:26.287689
# Unit test for function compile_files
def test_compile_files():
    from os import remove
    from os.path import join
    from shutil import rmtree
    from tempfile import mkdtemp
    from django_code_generator import compile_files
    from django_code_generator.files import compile_files as compile_files_
    from django_code_generator.transformers import TemplateTransformer
    from django_code_generator.types import CompilationTarget
    import unittest
    import codecs

    class CompileTest(unittest.TestCase):
        def setUp(self):
            self.tempdir = mkdtemp()
            self.input = join(self.tempdir, 'input')
            self.output = join(self.tempdir, 'output')

        def tearDown(self):
            rmtree(self.tempdir)


# Generated at 2022-06-22 14:46:37.714481
# Unit test for function compile_files
def test_compile_files():
    from os import system
    from os.path import join

    TMP_OUTPUT_PATH = './tmp_output'
    def cleanup():
        system('rm -rf ' + TMP_OUTPUT_PATH)

    INPUT_FILE_CONTENT = """
if True:
    a = 1
    b = 2

    for i in range(10):
        print(i)

    print(b)
"""
    EXPECTED_OUTPUT_FILE_CONTENT = """
if True:
    a = 1
    b = 2

    for i in range(10):
        console.log(i);
    
    console.log(b);
"""
    TEST_FILE = 'test.py'

    cleanup()


# Generated at 2022-06-22 14:46:45.409810
# Unit test for function compile_files
def test_compile_files():
    output = 'tests/output'
    input_ = 'tests/input'
    result = compile_files(input_, output, CompilationTarget.ES5JS)
    with open('tests/expected/jquery.results.json') as f:
        expected = json.loads(f.read())
    assert result.files == expected['files']
    assert result.target == expected['target']
    assert result.dependencies == expected['dependencies']


# Generated at 2022-06-22 14:46:50.746919
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from tempfile import mkdtemp
    from .types import CompilationTarget
    from .targets import CompilationTarget as Target
    from .utils.entry_points import get_entry_points

    targets = get_entry_points('frost.targets')
    targets = sorted(targets.keys())
    targets = [targets[i] for i in range(len(targets)) if i % 3 == 0]
    input_ = 'tests/sources/src'
    output = 'tests/sources/bin'
    shutil.rmtree(input_)
    shutil.rmtree(output)
    shutil.copytree('tests/sources/test_sources', input_)
    for target in targets:
        print('Testing', target)
        compile

# Generated at 2022-06-22 14:46:51.944217
# Unit test for function compile_files
def test_compile_files():
    # TODO: implement
    pass

# Generated at 2022-06-22 14:47:00.545229
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    input_ = Path.cwd() / 'tests' / 'data' / 'compile' / 'input'
    output = Path.cwd() / 'tests' / 'data' / 'compile' / 'output'
    result = compile_files(input_, output, CompilationTarget.NODE)
    assert result.target == CompilationTarget.NODE
    assert result.time > 0
    assert result.count == 1
    assert len(result.dependencies) == 1

# Generated at 2022-06-22 14:47:11.553155
# Unit test for function compile_files
def test_compile_files():
    """
    :return: None
    """
    result = compile_files("test/test_dirs/compilation/test_dir",
                           "test_result", CompilationTarget.RUNTIME)
    assert result.count == 3
    assert result.target == CompilationTarget.RUNTIME
    assert set(result.dependencies) == set(['test/test_dirs/compilation/test_dir/__init__.py',
                                            'test/test_dirs/compilation/test_dir/a.py'])
    assert os.path.exists("test_result/test_dirs/compilation/test_dir/a/__init__.py")
    assert os.path.exists("test_result/test_dirs/compilation/test_dir/a/c/__init__.py")

# Generated at 2022-06-22 14:47:19.342813
# Unit test for function compile_files
def test_compile_files():
    from .files import create_temp
    from .config import default_ini_file, default_target
    import os
    import re
    import shutil
    import sys
    import tempfile

    input_dir = os.path.join(os.path.dirname(__file__), 'test', 'files')
    temp_dir = tempfile.mkdtemp()
    input_dir = os.path.relpath(input_dir, start=os.path.dirname(__file__))
    output_dir = os.path.join(temp_dir, 'out')
    root_dir = tempfile.mkdtemp()

    with open(default_ini_file, 'w') as f:
        f.write('[distutils]\n')
        f.write('include-dirs =\n')

# Generated at 2022-06-22 14:47:28.904824
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import sys
    from .exceptions import CompilationError
    from .transformers.base import BaseTransformer
    from .transformers.typing import TypeAnnotationsTransformer
    from pathlib import Path
    PYTHON = sys.executable
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 14:47:31.580975
# Unit test for function compile_files
def test_compile_files():
    """Test to check if compile_files works properly"""
    assert compile_files("./tests/data/test.py", "./tests/data/test.js",
                         CompilationTarget.ES5)


# Generated at 2022-06-22 14:47:45.946870
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('test_input', 'test_output',
                         CompilationTarget.ES5).count == 7



# Generated at 2022-06-22 14:47:47.583783
# Unit test for function compile_files
def test_compile_files():
    compile_files('tests/data/', 'tests/data/output', CompilationTarget.ES5)



# Generated at 2022-06-22 14:47:52.692216
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    from .types import CompilationTarget

    dir_ = 'tests/compiler/test_compile_files'
    input_ = os.path.join(dir_, 'input')
    output = os.path.join(dir_, 'output')
    shutil.rmtree(output)
    result = compile_files(input_, output, CompilationTarget.RUNTIME)
    assert result.count == 4
    assert result.target == CompilationTarget.RUNTIME
    assert output == os.path.join(dir_, 'output')

# Generated at 2022-06-22 14:48:03.373653
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import NoInputFiles
    import tempfile

    input_ = tempfile.mkdtemp()
    output = tempfile.mkdtemp()

    assert compile_files(input_, output, CompilationTarget.PYTHON2).count == 0
    assert compile_files(input_, output, CompilationTarget.PYTHON2_NONE_NEGATIVE).count == 0
    assert compile_files(input_, output, CompilationTarget.JAVA_BYTECODE).count == 0
    assert compile_files(input_, output, CompilationTarget.JAVA).count == 0

    with tempfile.NamedTemporaryFile(mode='w', dir=input_) as f:
        f.write('a = 1')

# Generated at 2022-06-22 14:48:09.031279
# Unit test for function compile_files
def test_compile_files():
    
    comp = compile_files('./dat/test/a', './dat/test/b', CompilationTarget.RELEASE, './dat/test')

    print(comp.count, comp.duration, comp.target, comp.dependencies)

if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:48:16.508156
# Unit test for function compile_files
def test_compile_files():
    """Unit test for function compile_files"""
    result = compile_files(
        './tests/fixtures/input',
        './tests/fixtures/expected',
        CompilationTarget.PYTHON_3_6,
    )
    assert result.duration < 0.1
    assert result.target == CompilationTarget.PYTHON_3_6

    assert result.dependencies == ['foo']
    assert result.count == 2

# Generated at 2022-06-22 14:48:20.817222
# Unit test for function compile_files
def test_compile_files():
    def test(before, after):
        assert compile_files(before, after, CompilationTarget.JVM)
        with open(after + '/java.version') as f:
            assert f.read() == '1.8'

    test('test', '/tmp/test')



# Generated at 2022-06-22 14:48:29.433684
# Unit test for function compile_files
def test_compile_files():

    from .test_utils.test_filesystem_helpers import create_dir, create_file
    from .exceptions import CompilationError

    # Check that function fails if given invalid inputs
    try:
        compile_files('', '', CompilationTarget.Auto, '')
    except AssertionError:
        pass
    else:
        assert False, 'Should not allow empty input/output'

    create_dir('/test/')
    create_dir('/test/input')
    create_file('/test/input/bar.py', 'x = "foo"')
    create_dir('/test/output')
    create_file('/test/output/bar.py', 'x = "foo"')

    # Check that function fails if given invalid file

# Generated at 2022-06-22 14:48:41.473875
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    from .utils.helpers import assert_eq
    result = compile_files(
        'tests', 
        'outputs', 
        CompilationTarget.COPY, 
        pathlib.Path(__file__).parent.as_posix())
    assert_eq(result.count, 6)

# Generated at 2022-06-22 14:48:49.550324
# Unit test for function compile_files
def test_compile_files():
    from py._path.local import LocalPath
    from subprocess import run
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir_path = LocalPath(tmpdir)

        input_ = tmpdir_path.join('input')
        output = tmpdir_path.join('output')
        input_.ensure_dir()
        output.ensure_dir()

        input_file = input_.join('test.py')
        input_file.ensure()
        input_file.write('print("test_compile_files")')

        compile_files(input_=input_.strpath,
                      output=output.strpath,
                      target=CompilationTarget.COMPILE)

        output_file = output.join('test.pyc')
        assert output_file.check()

# Generated at 2022-06-22 14:49:18.461762
# Unit test for function compile_files
def test_compile_files():
    with pytest.raises(TypeError):
        compile_files(1, 2, 3)
    with pytest.raises(TypeError):
        compile_files("", 2, 3)
    with pytest.raises(TypeError):
        compile_files("", "", 3)
    with pytest.raises(TypeError):
        compile_files("", "", CompilationTarget.PYTHON2)


# Generated at 2022-06-22 14:49:28.711122
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import distutils.dir_util
    distutils.dir_util.remove_tree('tests/test_compile/dist')
    compile_files('tests/test_compile/src', 'tests/test_compile/dist', 'js', 'tests')
    with open('tests/test_compile/dist/_test_class.js') as f:
        assert 'class TestClass' in f.read()
    with open('tests/test_compile/dist/_test_sub_class.js') as f:
        assert 'class TestSubClass' in f.read()
    with open('tests/test_compile/dist/_test_sub_sub_class.js') as f:
        assert 'class TestSubSubClass' in f.read()

# Generated at 2022-06-22 14:49:34.520745
# Unit test for function compile_files
def test_compile_files():
    import io
    import unittest

    input_ = io.StringIO('say(')
    output = 'test.js'

    class TestClass(unittest.TestCase):
        def test(self):
            self.assertRaises(CompilationError,
                              compile_files, input_, output, CompilationTarget.ES5)
    unittest.main()

# Generated at 2022-06-22 14:49:43.908169
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .test import TestCase

    class TestCompileFiles(TestCase):
        """Unit test for compile_files"""

        def test_compile_files(self):
            """Unit test for compile_files"""
            def _assert_compilation(input_: Path,
                                    output: Path,
                                    target: CompilationTarget,
                                    count: int,
                                    dependencies: set):
                result = compile_files(input_, output, target)
                self.assertEqual(result.count, count)
                self.assertEqual(result.target, target)
                self.assertEqual(result.dependencies, sorted(dependencies))


# Generated at 2022-06-22 14:49:58.021069
# Unit test for function compile_files
def test_compile_files():
    code = """#!/usr/bin/env python3

from math import pi

name = 'Spam and Eggs'
print(name)

radius = 1.23
print(round(2 * radius * pi, 2))"""

    # Copy over and save the input file
    with open('test.py', 'w') as f:
        f.write(code)

    result = compile_files('test.py', 'build', CompilationTarget.PY2)
    assert result.count == 1
    assert result.target == CompilationTarget.PY2

    # Make sure the file was generated
    assert os.path.isfile('build/test.py')
    # Make sure the file has the right content

# Generated at 2022-06-22 14:50:08.000164
# Unit test for function compile_files
def test_compile_files():
    from .utils.test_helpers import assert_program

    assert_program('''
        from __future__ import annotations
        from typing import NewType
        X = NewType("X", float)
        x = X(1.0)
        print(x)
        print(type(x))
    ''', 'print(1.0)')

    assert_program('''
        from __future__ import annotations
        from typing import NewType
        X = NewType("X", float)
        x = X(1.0)
        print(x)
        print(type(x))
    ''', 'print(type(None))')

# Generated at 2022-06-22 14:50:19.149542
# Unit test for function compile_files
def test_compile_files():
    from .files import generate_files
    from .utils.helpers import read_file
    from .utils.hashes import hash_file
    from .utils.testing import assert_equal

    # Generate files
    generated = generate_files(':memory:')
    debug(lambda: 'Generated: {}'.format(generated))

    # Compile files
    compiled = generate_files(':memory:', '.py')
    debug(lambda: 'Compiled: {}'.format(compiled))

    # Assert files are compiled
    for file in generated:
        with file.open() as f:
            assert_equal(hash_file(f), hash_file(compiled[file]))

        assert_equal(read_file(file), read_file(compiled[file]))

    # Cleanup

# Generated at 2022-06-22 14:50:20.156299
# Unit test for function compile_files
def test_compile_files():
    compile_files('../tests/programs/', '../tests/programs_output/', CompilationTarget.JS)

# Generated at 2022-06-22 14:50:33.265352
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from .files import _InputOutput
    from .exceptions import CompilationResult
    from .types import CompilationTarget
    
    src: str = 'test/test_files/test_compile_files/src'
    dst: str = 'test/test_files/test_compile_files/dst'
    debug(lambda: 'src: {}'.format(src))
    debug(lambda: 'dst: {}'.format(dst))
    
    with TemporaryDirectory() as tmpdir:
        tmpdst: Path = Path(tmpdir).absolute() / 'dst'
        debug(lambda: 'Absolute path to temporary output directory: {}'.format(tmpdst))

# Generated at 2022-06-22 14:50:40.359670
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil
    import subprocess
    def file_exists(path):
        return os.path.exists(path) and os.path.isfile(path)
    
    # move data folder to temporary location
    tmp_file_path = os.path.join(os.getcwd(), "tmp_data")
    os.mkdir(tmp_file_path)
    os.chdir(tmp_file_path)
    shutil.move(os.path.join(os.getcwd(), "../data"), os.getcwd())

    # update file path for all tests
    for i in range(1, 22):
        with open(str(i) + '.py') as f:
            content = f.readlines()

# Generated at 2022-06-22 14:51:32.865630
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    test_dir = "test_compiler"
    os.mkdir(test_dir)
    shutil.copy2("tests/test_data/simple/simple.py", test_dir)
    compile_files(test_dir, test_dir, CompilationTarget.C)
    shutil.rmtree(test_dir)

# Generated at 2022-06-22 14:51:37.876434
# Unit test for function compile_files
def test_compile_files():
    res = compile_files('samples', 'samples_out', CompilationTarget.CPython27)
    assert res.files == 4
    assert len(res.dependencies) == 3
    assert 'dataclasses' in res.dependencies
    assert 'typing' in res.dependencies
    assert 'typed-ast' in res.dependencies

# Generated at 2022-06-22 14:51:44.174487
# Unit test for function compile_files
def test_compile_files():
    try:
        import pytest
    except ImportError:
        raise ImportError('pytest is required to run unit tests') from None
    from .test import compile_test, DATA_DIR

    pytest.main([str(DATA_DIR), '--cov=.,--cov-report=term-missing'])
    compile_test()

# Generated at 2022-06-22 14:51:53.693552
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from .types import CompilationTarget
    from .exceptions import CompilationError
    from .utils import helpers

    class CompileFilesPaths:
        def __init__(self):
            from tempfile import TemporaryDirectory
            from .utils import helpers

            self.input_ = Path(TemporaryDirectory().name, 'input')
            self.output = Path(TemporaryDirectory().name, 'output')
            self.output.mkdir(parents=True)

        def get_paths(self, name: str) -> InputOutput:
            return InputOutput(Path(self.input_, name), Path(self.output, name))

        def get_files(self, names: List[str]) -> List[InputOutput]:
            return [self.get_paths(n) for n in names]


# Generated at 2022-06-22 14:52:06.213285
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil

# Generated at 2022-06-22 14:52:17.919584
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import os
    import shutil
    from pathlib import Path
    from .use_cases import use_case_with_side_effects
    from .types import CompilationTarget

    def check(input_: str, output: str, target: CompilationTarget = CompilationTarget.RUNTIME):
        result = compile_files(input_, output, target)
        assert not result.dependencies
        assert result.target == target
        assert result.count
        assert type(result.elapsed) == float
        assert result.elapsed > 0
        assert os.path.isdir(output)
        for file in Path(input_).glob('**/*.py'):
            shutil.rmtree(output)  # fixme: why are files being copied, not compiled

# Generated at 2022-06-22 14:52:26.667104
# Unit test for function compile_files
def test_compile_files():
    """Unit test for compile_files function."""
    import shutil
    from .utils.helpers import debug_level

    with debug_level(0):
        compile_files('tests/data/input', 'tests/data/output', CompilationTarget.PYTHON)
    assert shutil.filecmp.cmp('tests/data/output/test.py',
                              'tests/data/output_expected/test.py',
                              shallow=False)

    # remove output directory
    shutil.rmtree('tests/data/output')

# Generated at 2022-06-22 14:52:27.309029
# Unit test for function compile_files
def test_compile_files():
    ...

# Generated at 2022-06-22 14:52:34.203462
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    from . import utils
    from .utils.mock import TempDir, touch

    temp_dir = TempDir()
    with temp_dir as temp:
        temp.write('test.py', 'print("Hello, world!")')

        result = compile_files(temp.path.joinpath('test.py').as_posix(),
                               temp.path.joinpath('out').as_posix(),
                               CompilationTarget.nodejs)
        assert temp.read('out/test.js') == 'console.log("Hello, world!");'
        assert result.count == 1



# Generated at 2022-06-22 14:52:46.221714
# Unit test for function compile_files
def test_compile_files():
    from .utils.helpers import path_to_test_files, path_to_test_files_output
    from .files import get_input_output_paths

    result = compile_files(path_to_test_files(), path_to_test_files_output(),
                           CompilationTarget.PYTHON27)

    assert result.count == 3
    assert len(result.dependencies) == 0
    assert result.target == CompilationTarget.PYTHON27

    for paths in get_input_output_paths(path_to_test_files(),
                                        path_to_test_files_output()):
        input_code = paths.input.read_text()
        output_code = paths.output.read_text()
        assert input_code != output_code