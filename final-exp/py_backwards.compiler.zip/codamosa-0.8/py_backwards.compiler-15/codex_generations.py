

# Generated at 2022-06-22 14:43:24.139856
# Unit test for function compile_files
def test_compile_files():
    import os
    import glob
    import json
    assert compile_files('./tests/input/sum.js', './tests/output/', CompilationTarget.BROWSER_ES3) == \
           CompilationResult(1, 0.024239444732666016, CompilationTarget.BROWSER_ES3, [])
    assert os.path.getsize("./tests/output/sum.js") == 92
    assert json.load(open("./tests/output/sum-report.json")) == \
           {'target': 'browser_es3', 'dependencies': [], 'compiled_files': 1, 'time_total': 0.024239444732666016}


# Generated at 2022-06-22 14:43:31.539240
# Unit test for function compile_files
def test_compile_files():
    import pytest
    with pytest.raises(CompilationError) as e:
        compile_files('./tests/invalid_program', './tests/output', CompilationTarget.WEB)
    assert e.value.path == './tests/invalid_program/program.py'
    assert e.value.code == 'def foo(a, b):\n    return a + b\n\n\nprint(foo)\n'
    assert e.value.line == 4
    assert e.value.column == 7

if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-22 14:43:39.798371
# Unit test for function compile_files
def test_compile_files():
    test = compile_files('tests/input', 'tests/output', CompilationTarget.TEST)
    assert test == CompilationResult(count=3,
                                     duration=0.0,
                                     target=CompilationTarget.TEST,
                                     dependencies=['bar'])

    release = compile_files('tests/input', 'tests/output', CompilationTarget.RELEASE)
    assert release == CompilationResult(count=3,
                                        duration=0.0,
                                        target=CompilationTarget.RELEASE,
                                        dependencies=['foo'])

# Generated at 2022-06-22 14:43:44.661615
# Unit test for function compile_files
def test_compile_files():
    from .test.test_data import TEST_CASES
    input_ = '/tmp/qpython-test'
    output = '/tmp/qpython-test'
    count = compile_files(input_, output, CompilationTarget.Q).count
    assert count == len(TEST_CASES)

# Generated at 2022-06-22 14:43:57.103002
# Unit test for function compile_files
def test_compile_files():
    import pytest
    from .exceptions import CompilationError, TransformationError
    from .files import InputOutput
    from .types import CompilationResult, CompilationTarget

    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as td:
        td_path = Path(td)

        with open(td_path.joinpath('minimal.py'), 'w') as f:
            f.write('1 + 1')

        with open(td_path.joinpath('compilation-error.py'), 'w') as f:
            f.write('1 +')

        with open(td_path.joinpath('transformation-error.py'), 'w') as f:
            f.write('1 ** 2')

        # No files

# Generated at 2022-06-22 14:44:08.730501
# Unit test for function compile_files
def test_compile_files():
    import os
    import getpass
    import shutil
    import tempfile

    # create a temporary directory
    current_dir = os.path.dirname(os.path.abspath(__file__))
    test_dir = tempfile.mkdtemp()

    # create a temporary input directory
    input_dir = os.path.join(test_dir, 'input')
    os.mkdir(input_dir)

    # create a temporary output directory
    output_dir = os.path.join(test_dir, 'output')
    os.mkdir(output_dir)

    # copy test files to temporary input directory
    print('Copying files...')
    files = ['simple.py', 'func.py', 'transpose.py']

# Generated at 2022-06-22 14:44:16.781802
# Unit test for function compile_files
def test_compile_files():
    input_ = 'tests/src'
    output = 'tests/temp/compile_files'
    target = CompilationTarget.PYTHON_35
    root = 'test'
    compiler_results = compile_files(input_, output, target, root = root)
    assert compiler_results.count == 15
    assert compiler_results.target == target
    assert compiler_results.time == compiler_results.time

# Generated at 2022-06-22 14:44:23.043452
# Unit test for function compile_files
def test_compile_files():
    from tempfile import TemporaryDirectory
    from shutil import rmtree
    import os
    import sys
    import re

    def get_test_compile_file_paths(test_temporary_dir: TemporaryDirectory):
        test_input = os.path.join(test_temporary_dir.name, 'input')
        test_output = os.path.join(test_temporary_dir.name, 'output')
        test_dependencies = os.path.join(test_temporary_dir.name, 'dependencies')

        if not os.path.exists(test_input):
            os.makedirs(test_input)
        if not os.path.exists(test_output):
            os.makedirs(test_output)

# Generated at 2022-06-22 14:44:27.722911
# Unit test for function compile_files
def test_compile_files():  # noqa
    result = compile_files(__dir__ + '/data/compile_files.input/',
                           __dir__ + '/data/compile_files.input/../compile_files.output/',
                           CompilationTarget.PYTHON_RUNTIME,
                           __dir__)
    assert result


# Generated at 2022-06-22 14:44:39.105884
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import shutil
    import os

    module_path = Path(__file__).absolute().parent
    start = time()

# Generated at 2022-06-22 14:44:53.430716
# Unit test for function compile_files
def test_compile_files():
    import json
    import os.path
    import unittest

    class TestCompileFiles(unittest.TestCase):
        DATA_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                                 'test_data')

        def test_compile_files(self):
            with open(os.path.join(self.DATA_PATH, 'compile_files.json')) as f:
                tests = json.load(f)
            for t in tests:
                result = compile_files(t['input'], t['output'], t['target'])
                self.assertEqual(t['input'], result.input)
                self.assertEqual(t['output'], result.output)

# Generated at 2022-06-22 14:45:05.405385
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import subprocess

    paths = get_input_output_paths('./tests/test_project/src',
                                   './tests/test_project/src/../build',
                                   './tests/test_project/src/../tests')

    for path in paths:
        subprocess.run(['rm', '-rf', path.output.as_posix()])

    res = compile_files('./tests/test_project/src',
                        './tests/test_project/build',
                        CompilationTarget.es5)

    assert res.count == 9
    assert res.target == CompilationTarget.es5
    assert len(res.dependencies) == 3

    for path in paths:
        assert path.output.exists() and path.output.is_file()

    # Path to compiled

# Generated at 2022-06-22 14:45:17.982374
# Unit test for function compile_files
def test_compile_files():
    from . import __version__
    from .utils import here
    import os

    target = CompilationTarget.java
    input_ = os.path.join(here, 'data/input')
    output = os.path.join(here, 'data/output')
    result = compile_files(input_, output, target)

    assert result.target == target
    assert result.count == 5
    assert result.dependencies == []
    assert result.time > 0

    assert os.path.exists(os.path.join(output, 'Example.java'))
    with open(os.path.join(output, 'Example.java')) as f:
        code = f.read()
        assert code.find('package data.output;') == 0
        assert code.find('Version: {}'.format(__version__)) != -1

# Generated at 2022-06-22 14:45:26.595718
# Unit test for function compile_files
def test_compile_files():
    """Tests compilation of files."""
    # Given
    input_ = '/tmp/file-compiler/input'
    output = '/tmp/file-compiler/output'
    target = CompilationTarget.PYTHON_3
    result = compile_files(input_, output, target)

    # Then
    assert result.duration > 0
    assert result.target == target
    assert sorted(result.dependencies) == sorted(['/tmp/file-compiler/input/a.py',
                                                  '/tmp/file-compiler/input/b.py'])


if __name__ == '__main__':
    test_compile_files()

# Generated at 2022-06-22 14:45:32.689910
# Unit test for function compile_files
def test_compile_files():
    import pathlib
    import tempfile
    import shutil
    import os

    input_dir = pathlib.Path('tests/data/compile_files/input')
    expected_dir = pathlib.Path('tests/data/compile_files/expected')
    expected = []
    for path in expected_dir.iterdir():
        with path.open() as f:
            expected.append(f.read())
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 14:45:40.502130
# Unit test for function compile_files
def test_compile_files():
    compile_files(
        './tests/test_inputs',
        './tests/test_outputs',
        CompilationTarget.FUNCTIONS,
    )
    compile_files(
        './tests/test_inputs',
        './tests/test_outputs',
        CompilationTarget.CLASSES,
    )
    compile_files(
        './tests/test_inputs',
        './tests/test_outputs',
        CompilationTarget.PACKAGES,
    )

# Generated at 2022-06-22 14:45:51.962887
# Unit test for function compile_files
def test_compile_files():
    import os
    import os.path
    import json
    import tempfile
    import shutil

    # prepare a fake project

# Generated at 2022-06-22 14:45:59.801262
# Unit test for function compile_files
def test_compile_files():
    import os
    import glob
    import shutil
    this_dir = os.path.dirname(os.path.realpath(__file__))
    temp_dir = os.path.join(this_dir, 'temp')
    for temp in glob.glob(os.path.join(this_dir, 'temp', '*')):
        shutil.rmtree(temp)
    print(compile_files(os.path.join(this_dir, 'tests', 'test_input'),
                        os.path.join(this_dir, 'temp', 'test_input'),
                        CompilationTarget.JAVASCRIPT))

# Generated at 2022-06-22 14:46:04.354933
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import os

    inputdir = 'testdir'
    outputdir = 'builtdir'

# Generated at 2022-06-22 14:46:11.356029
# Unit test for function compile_files
def test_compile_files():
    from .exceptions import CompilationError
    from pathlib import Path
    import pytest

    with pytest.raises(CompilationError):
        compile_files('./tests/inputs', './tests/outputs', CompilationTarget.PYPY3)
    with pytest.raises(CompilationError):
        compile_files('./tests/inputs/test_invalid_syntax.py',
                      './tests/outputs', CompilationTarget.PYPY3)

    actual = compile_files('./tests/inputs/test_compile_files.py',
                           './tests/outputs', CompilationTarget.PYPY3)

    assert actual.count == 1

# Generated at 2022-06-22 14:46:26.852405
# Unit test for function compile_files
def test_compile_files():
    from .config import config
    from .test import fixtures
    from shutil import rmtree
    from pathlib import PurePath

    # temp directory must be inside of 'test' directory to be deleted
    tmp = PurePath(fixtures, 'tmp')

    # Compile Python -> Python
    rmtree(tmp, ignore_errors=True)
    try:
        py_python = compile_files(fixtures, tmp, config.py2py)
    except:
        raise
    else:
        assert py_python.count == 1

    # Compile Python -> TypeScript
    rmtree(tmp, ignore_errors=True)
    try:
        py_ts = compile_files(fixtures, tmp, config.py2ts)
    except:
        raise
    else:
        assert py_ts.count == 1

# Generated at 2022-06-22 14:46:31.063098
# Unit test for function compile_files
def test_compile_files():
    target = CompilationTarget.DEFAULT
    result = compile_files('examples', 'output', target, 'examples')
    print('\n{} files compiled in {:.2f} seconds'.format(
        result.count, result.time))

# Generated at 2022-06-22 14:46:40.234083
# Unit test for function compile_files
def test_compile_files():
    import shutil
    from .exceptions import CompilationError, TransformationError
    from pathlib import Path
    from .__main__ import get_output_directory
    from .transformers import import_transformer as imp

    test_input = Path(__file__).parent / 'tests' / 'compile_files'
    test_output = get_output_directory(test_input)
    shutil.rmtree(test_output, ignore_errors=True)  # delete output directory

    try:
        result = compile_files(test_input.as_posix(), test_output.as_posix(), imp.target)
    except CompilationError as e:
        print('{}:{}: error: {}'.format(e.filename, e.line, e.error))
        raise

# Generated at 2022-06-22 14:46:51.223787
# Unit test for function compile_files
def test_compile_files():
    from pathlib import Path
    import shutil
    from .utils import get_data_dir

    data_dir = get_data_dir()

    def cleanup():
        try:
            shutil.rmtree(str(data_dir))
        except FileNotFoundError:
            pass

    def _compile(input_: str, output: str, target: CompilationTarget):
        result = compile_files(str(data_dir / input_), str(data_dir / output), target)
        assert result.target == target
        assert result.dependencies == ['math']


# Generated at 2022-06-22 14:46:51.773719
# Unit test for function compile_files
def test_compile_files():
    pass

# Generated at 2022-06-22 14:47:03.299584
# Unit test for function compile_files
def test_compile_files():

    import os
    from .test.test_files import TEST_SOURCE_PATH, TEST_COMPILED_PATH

    compile_files(TEST_SOURCE_PATH, TEST_COMPILED_PATH, CompilationTarget.PY2)
    assert os.access(os.path.join(TEST_COMPILED_PATH, 'test_compile_files.py'), os.R_OK)
    with open(os.path.join(TEST_COMPILED_PATH, 'test_compile_files.py')) as f:
        assert f.read() == "from future import print_function\n\n\nprint('Hello')\n"

    compile_files(TEST_SOURCE_PATH, TEST_COMPILED_PATH, CompilationTarget.PY3)

# Generated at 2022-06-22 14:47:10.656109
# Unit test for function compile_files
def test_compile_files():
    from .utils.tester import assert_compilation_result_equals
    from .utils.helpers import get_bootstrap_html_path
    path = get_bootstrap_html_path()
    result = compile_files(path, 'output', 'JS')
    expected_result = CompilationResult(1, 0, 'JS', [])
    assert_compilation_result_equals(expected_result, result)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_compile_files()

# Generated at 2022-06-22 14:47:18.846155
# Unit test for function compile_files
def test_compile_files():
    assert compile_files('', '', CompilationTarget.UNIT_TEST) == CompilationResult(0, 0, CompilationTarget.UNIT_TEST, [])
    assert compile_files('tests/data/input/A', 'tests/data/output/A', CompilationTarget.UNIT_TEST) == CompilationResult(1, 7.89, CompilationTarget.UNIT_TEST, ['tests/data/input/A/a.py', 'tests/data/input/A/b.py'])

# Generated at 2022-06-22 14:47:25.198414
# Unit test for function compile_files
def test_compile_files():
    from .test.test_compile import test_compile
    result = test_compile(lambda a, b, c, d: compile_files(a, b, c, d))
    assert all(isinstance(dep, str) for dep in result.dependencies)
    assert isinstance(result.duration, float)
    assert isinstance(result.files_count, int)
    assert isinstance(result.target, CompilationTarget)

# Generated at 2022-06-22 14:47:31.903213
# Unit test for function compile_files
def test_compile_files():
    import pytest
    import subprocess
    import time
    from pathlib import Path
    import shutil
    import os

    # Configuration
    target = CompilationTarget.FAST
    root = 'tests/simple'
    input_ = f'{root}/input'
    output = f'{root}/output'

    # Test
    result = pytest.raises(subprocess.CalledProcessError,
                           lambda: compile_files(input_, output, target, root))

# Generated at 2022-06-22 14:48:03.469613
# Unit test for function compile_files
def test_compile_files():
    import shutil
    import tempfile
    import re
    import pytest
    import os.path as path

    import csscompressor

    TMP_FOLDER = path.join(tempfile.gettempdir(), 'csscompressor_test')
    CSS_FILE_MAXIMIZED = path.join(TMP_FOLDER, 'css', 'maximized.css')
    CSS_FILE_MINIMIZED = path.join(TMP_FOLDER, 'css', 'minimized.css')
    DEST_FOLDER = path.join(TMP_FOLDER, 'dest')
    SOURCE_FOLDER = path.join(TMP_FOLDER, 'source')
    TMP_TAGS = path.join(TMP_FOLDER, 'tags')

# Generated at 2022-06-22 14:48:09.121316
# Unit test for function compile_files
def test_compile_files():
    if compile_files('../src/tests/input', '../src/tests/output',
                    CompilationTarget.PYTHON2) != \
    CompilationResult(3, 0.8281998634338379, CompilationTarget.PYTHON2,
                      ['argparse', 'collections', 'sys']):
        raise Exception

# Generated at 2022-06-22 14:48:15.445352
# Unit test for function compile_files
def test_compile_files():
    result = compile_files('tests/input', 'tests/output', CompilationTarget.BROWSER)
    assert result.count == 1
    assert result.time >= 0
    assert result.target == CompilationTarget.BROWSER
    assert result.dependencies == ['benchmark', 'colorama', 'numpy', 'pandas']



# Generated at 2022-06-22 14:48:26.386011
# Unit test for function compile_files
def test_compile_files():
    import os
    import shutil

    input_ = os.path.join(os.path.dirname(__file__), 'tests', 'two_files')
    output = os.path.join(os.path.dirname(__file__), 'tests', 'two_files_out')
    shutil.rmtree(output, ignore_errors=True)

    result = compile_files(input_, output, CompilationTarget.PYTHON_2)
    assert result.count == 2
    assert result.target == CompilationTarget.PYTHON_2
    assert result.dependencies == ['__future__', 'sys', 'six']
    assert result.duration > 0

    with open(os.path.join(output, 'file1.py'), 'r') as f:
        code = f.read()
    assert code

# Generated at 2022-06-22 14:48:38.909976
# Unit test for function compile_files
def test_compile_files():
    import glob
    import subprocess
    import os

    compiler_path = os.path.join(os.path.dirname(__file__), '..', '..', 'scripts', 'compile_to_swift.py')
    input_path = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'src')
    output_path = os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'compiled')

    # Compile with latest version
    subprocess.run(['python', compiler_path, '--input', input_path, '--output', output_path, '--target', 'latest'],
                   stderr=subprocess.PIPE, check=True)

    # Re-compile with source code

# Generated at 2022-06-22 14:48:45.292303
# Unit test for function compile_files
def test_compile_files():
    """Test function compile_files."""
    compile_files('/home/ali.aalizade/templates/fastship/fastship/ship/templates',
                '/home/ali.aalizade/templates/fastship/fastship/ship/templates',
                'html',
                '/home/ali.aalizade/templates/fastship/fastship/ship/templates')

# Generated at 2022-06-22 14:48:56.562351
# Unit test for function compile_files
def test_compile_files():
    from ..tests import compile_file_to
    from ..repl import repl
    from ..decorator import function
    from ..generator import generator
    import os
    import tempfile
    input_ = os.path.join(tempfile.gettempdir(), 'decorator_in')
    output = os.path.join(tempfile.gettempdir(), 'decorator_out')
    result = compile_files(input_, output, CompilationTarget.EVERYTHING, 'tests')
    with function('test'):
        def hello(f, name):
            return f"hello {name}"
    with generator('testgen'):
        def hello(f, name):
            return f"hello {name}"
    compile_file_to(os.path.realpath(__file__), input_)
    from ..tests import hello

# Generated at 2022-06-22 14:49:06.743257
# Unit test for function compile_files
def test_compile_files():
    import os
    import pytest
    import tempfile
    import shutil
    import subprocess
    import six
    PY = """def f():
        x = 1
    """

    F = """x = 1
    """

    def transform(code: str, target: str) -> str:
        cwd = os.getcwd()
        temp = tempfile.mkdtemp()

# Generated at 2022-06-22 14:49:21.581446
# Unit test for function compile_files
def test_compile_files():
    assert compile_files("./tests/integration", "./tests/integration/out", CompilationTarget.PYTHON).total_compiled_files == 3
    # An assertion error should be raised as the input directory does not exist
    try:
        compile_files("./tests/integration1", "./tests/integration/out", CompilationTarget.PYTHON)
    except AssertionError:
        assert True
    # An assertion error should be raised as the output directory has a filename not a directory
    try:
        compile_files("./tests/integration", "./tests/integration/out.py", CompilationTarget.PYTHON)
    except AssertionError:
        assert True
    # An assertion error should be raised as the input directory is not a string

# Generated at 2022-06-22 14:49:30.480227
# Unit test for function compile_files
def test_compile_files():
    import tempfile
    import os
    import pytest
    from .utils.helpers import set_debug_dir, write_ast

    input_dir = 'test_input'
    output_dir = 'test_output'
    set_debug_dir(input_dir)
    with tempfile.TemporaryDirectory() as tmpdir:
        input_ = os.path.join(tmpdir, input_dir)
        output = os.path.join(tmpdir, output_dir)
        write_ast('x = "string"',
                  os.path.join(input_, 'test.py'))
        result = compile_files(input_, output, CompilationTarget.PYTHON_27)
        assert result.count == 1
        assert result.dependencies == ['string']