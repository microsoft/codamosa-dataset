

# Generated at 2022-06-26 06:28:44.865594
# Unit test for function match
def test_match():
    str_0 = " -q"
    str_1 = " -r"
    result_0 = match(str_0, str_1)
    assert result_0 == " -r"


# Generated at 2022-06-26 06:28:53.979328
# Unit test for function match
def test_match():
    assert match("Some error about an option")
    assert match("Some error about an option with space")
    assert match("Some error about an option with an option")
    assert match("Some error about an option with space with an option")
    assert match("Some error about an option with space with an option with space")
    assert match("Some error about an option with space with an option with space with an option")
    assert match("Some error about an option with space with an option with space with an option with space")
    assert match("Some error about an option with space with an option with space with an option with space with an option")
    assert match("Some error about an option with space with an option with space with an option with space with an option with space")
    assert not match("Some error without an option")
    assert not match("Some error about an option with space without an option")


# Generated at 2022-06-26 06:28:58.199053
# Unit test for function match
def test_match():
    assert match(Command('echo "error: invalid option \'-v\'"', ''))
    assert match(Command('echo "error: invalid option \'-s\'"', ''))
    assert match(Command('echo "error: invalid option \'-x\'"', ''))



# Generated at 2022-06-26 06:28:59.161874
# Unit test for function match
def test_match():
	pass


# Generated at 2022-06-26 06:29:02.006535
# Unit test for function match
def test_match():
    assert match(Command('pacman -S linux', 'error: invalid option "-S"\n'))


# Generated at 2022-06-26 06:29:11.670614
# Unit test for function match
def test_match():
    assert match(
        Command(script='pacman -Syu', stderr='error: invalid option -- \'u\'')
        ) == True
    assert match(
        Command(script='pacman -Syu', stderr='error: invalid option -- \'u\'')
        ) == True
    assert match(
        Command(script="pacman -S --noconfirm ls", stderr="error: invalid option -- 'n'")
        ) == True
    assert match(
        Command(script="pacman -S --noconfirm ls", stderr="error: invalid option -- 'n'")
        ) == True
    assert match(
        Command(script="pacman -Syu", stderr="error: invalid option -- 'u'")
        ) == True

# Generated at 2022-06-26 06:29:12.522811
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = True
    var_1 = get_new_command(var_0)

# Generated at 2022-06-26 06:29:22.964395
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = True
    var_0 = get_new_command(bool_0)
    bool_1 = False
    var_1 = get_new_command(bool_1)
    bool_2 = True
    var_2 = get_new_command(bool_2)
    bool_3 = True
    var_3 = get_new_command(bool_3)
    bool_4 = True
    var_4 = get_new_command(bool_4)
    bool_5 = True
    var_5 = get_new_command(bool_5)
    bool_6 = True
    var_6 = get_new_command(bool_6)
    assert var_0 == None
    assert var_1 == None
    assert var_2 == None
    assert var_3 == None

# Generated at 2022-06-26 06:29:25.240490
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = "pacman -Suy"
    var_1 = get_new_command(var_0)

 # Unit test for function match

# Generated at 2022-06-26 06:29:34.704968
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = Command("pacman -r foo")
    assert var_0.output == "error: invalid option '-r'\n"
    assert var_0.script == "pacman -r foo"
    assert repr(var_0) == "Command('pacman -r foo', 'error: invalid option '-'r'\\n')"
    var_1 = Command("pacman -S foo")
    assert var_1.output == "error: invalid option '-S'\n"
    assert var_1.script == "pacman -S foo"
    assert repr(var_1) == "Command('pacman -S foo', 'error: invalid option '-'S'\\n')"
    var_2 = Command("pacman -R foo")

# Generated at 2022-06-26 06:29:45.762428
# Unit test for function match
def test_match():
    bool_0 = True
    var_0 = command
    var_1 = var_0.output
    bool_1 = var_1.startswith
    var_2 = "error: invalid option '-"
    bool_2 = bool_1(var_2)
    bool_3 = True
    for_4 = var_0.script
    for_4 = -1
    for_4 = -1
    var_6 = " -{}".format
    str_1 = var_6(-1)
    for_4 = str_1
    bool_4 = any
    bool_5 = bool_4(for_4)
    bool_6 = bool_2 and bool_5 and bool_3
    return bool_6


# Generated at 2022-06-26 06:29:46.890560
# Unit test for function get_new_command
def test_get_new_command():
    assert False


# Generated at 2022-06-26 06:29:55.881415
# Unit test for function match

# Generated at 2022-06-26 06:29:58.989225
# Unit test for function match
def test_match():
    assert match.match(Command('sudo pacman -S python-pip'))
    assert not match.match(Command('pacman -S python-pip'))
    assert not match.match(Command('pacman -s python-pip'))



# Generated at 2022-06-26 06:30:05.396759
# Unit test for function get_new_command
def test_get_new_command():
    try:
        assert re.match(r"(?x)\$\s?pacman\s+(\\?(\S+\s+)+)", var_0)
    except AssertionError:
        raise AssertionError(('Expected: {}\n'
                              'Received: {}').format(re.match(r"(?x)\$\s?pacman\s+(\\?(\S+\s+)+)", var_0), var_0))

# Generated at 2022-06-26 06:30:13.496472
# Unit test for function match
def test_match():
    print('Testing function match')
    # TODO: Currently only tests the output of the function
    # If user adds in more "actual" tests, this can be removed
    # If a user wants to test the functionality, they can test the
    # match function individually
    actual_output = match(get_new_command)
    desired_output = None
    test_success = (actual_output == desired_output)
    print("Test Success: {}".format(test_success))
    print("Actual output: {}".format(actual_output))
    print("Desired output: {}".format(desired_output))


# Generated at 2022-06-26 06:30:15.013784
# Unit test for function match
def test_match():
    if match("pacman -Qdt"):
        print("Test match: ")

# Generated at 2022-06-26 06:30:17.247552
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('pacman -u -q') == 'pacman -U -q'
    assert get_new_command('pacman -s -v') == 'pacman -S -v'


# Generated at 2022-06-26 06:30:27.272257
# Unit test for function match
def test_match():
    assert match(Command(script='pacman -A /var/cache/pacman/pkg/dbus-core-1.12.2-2-x86_64.pkg.tar.xz',
      output='error: invalid option -- A'))
    assert match(Command(script='pacman -A /var/cache/pacman/pkg/dbus-core-1.12.2-2-x86_64.pkg.tar.xz',
      output='error: invalid option -- A\n'))
    assert match(Command(script='pacman -A bus-core-1.12.2-2-x86_64.pkg.tar.xz',
      output='error: invalid option -- A\n'))

# Generated at 2022-06-26 06:30:28.767901
# Unit test for function get_new_command
def test_get_new_command():
    # assertion
    assert True # TODO: implement your test here


# Generated at 2022-06-26 06:30:39.432705
# Unit test for function match
def test_match():
    var_1 = "error: invalid option '-p'"
    var_2 = " -p"
    var_3 = var_1 + var_2
    var_4 = Command(var_3)
    var_5 = sudo_support
    var_6 = for_app
    var_7 = "pacman"
    var_8 = var_6(var_7)
    var_9 = var_8(match)
    var_10 = var_9(var_4)
    assert var_10 == True


# Generated at 2022-06-26 06:30:40.560705
# Unit test for function get_new_command
def test_get_new_command():
    assert True is not False


# Generated at 2022-06-26 06:30:42.002821
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command() == "Fuck"

# Generated at 2022-06-26 06:30:49.713155
# Unit test for function match
def test_match():
    var_0 = Command(
        'pacman -Syu',
        'error: invalid option -\x16\nusage:\n  pacman [options\x16\n...\n',
    )
    bool_0 = match(var_0)
    assert_not_equals(bool_0, False)
    assert_equals(bool_0, True)


# Generated at 2022-06-26 06:30:51.282049
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command == "pacman -Syu"

# Generated at 2022-06-26 06:30:52.271740
# Unit test for function match
def test_match():
    assert match('pacman --help')


# Generated at 2022-06-26 06:31:02.656135
# Unit test for function match
def test_match():
	# Test the command of echo when valid option is -t
    assert match(Command("pacman -t", "Expected output"))
    assert match(Command("pacman -t test", "Expected output"))
    assert match(Command("pacman -c test", "Expected output"))
    assert match(Command("pacman -d test", "Expected output"))
    # Test the command of echo when wrong option is entered
    assert not match(Command("pacman test", "Expected output"))
    assert not match(Command("pacman -t -f test", "Expected output"))
    assert not match(Command("pacman -t -t test", "Expected output"))
    assert not match(Command("pacman -t test -t", "Expected output"))

# Generated at 2022-06-26 06:31:04.456742
# Unit test for function match
def test_match():
    assert match(OptionNotRecognized('', val='')) == False


# Generated at 2022-06-26 06:31:06.396471
# Unit test for function match
def test_match():
    assert match(command).output == "error: invalid option '-s'\n"


# Generated at 2022-06-26 06:31:13.511296
# Unit test for function match
def test_match():
    # If we have an error with a valid option, don't match
    assert not match(Command('pacman -U http://example.com/foo.pkg.tar.xz', 'error: invalid option -- \'U\''))
    assert not match(Command('pacman -r foo', 'error: invalid option -- \'r\''))
    # If we have an error with a valid option, don't match
    assert not match(Command('pacman -S foo', 'error: invalid option -- \'S\''))
    # If we have an error with an invalid option, match
    assert match(Command('pacman -Z foo', 'error: invalid option -- \'Z\''))
    assert match(Command('pacman -z foo', 'error: invalid option -- \'z\''))
    # If we have an error with a valid option, don't match
   

# Generated at 2022-06-26 06:31:19.728741
# Unit test for function match
def test_match():
    assert match(bool_0)


# Generated at 2022-06-26 06:31:25.624368
# Unit test for function match
def test_match():
    bool_0 = match(get_new_command(get_new_command(get_new_command(get_new_command(get_new_command(get_new_command(get_new_command(True))))))))
    bool_1 = match(get_new_command(get_new_command(get_new_command(get_new_command(get_new_command(get_new_command(get_new_command(get_new_command(get_new_command(True))))))))))
    assert bool_0 == bool_1

# Generated at 2022-06-26 06:31:33.454577
# Unit test for function match
def test_match():
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)
	# Basic case
	assert match(command=True)

test_case_0()
test_match()

# Generated at 2022-06-26 06:31:36.196410
# Unit test for function match
def test_match():
    var_1 = "pacman -Suythd 2>&1"
    var_0 = for_app("pacman")(match)(var_1)
    assert var_0


# Generated at 2022-06-26 06:31:42.396538
# Unit test for function match
def test_match():
    var_0 = Command(
        "pacman -aQq --foreign --quiet",
        "error: invalid option '-q'\nusage: pacman -[FfikqRV]\nSee 'pacman --help' for more information.",
        "",
    )
    var_0.script = "pacman -aQq --foreign --quiet"
    assert match(var_0) == True


# Generated at 2022-06-26 06:31:43.714759
# Unit test for function match
def test_match():
    command = get_new_command()
    assert match(command)



# Generated at 2022-06-26 06:31:46.338957
# Unit test for function match
def test_match():
    bool_0 = True
    var_0 = match(bool_0)
    bool_1 = (var_0 == None)
    assert bool_1


# Generated at 2022-06-26 06:31:47.470767
# Unit test for function match
def test_match():
    assert match(get_new_command(True))


# Generated at 2022-06-26 06:31:48.864714
# Unit test for function match
def test_match():
	command = "pacman -R vlc"

	assert match(command), "match is true"

# Generated at 2022-06-26 06:31:51.919538
# Unit test for function match
def test_match():
    bool_0 = "error: invalid option '-s' (use '-S' instead)"
    var_0 = for_app("pacman")(match)
    assert var_0(bool_0, bool_0)


# Generated at 2022-06-26 06:32:13.332191
# Unit test for function match
def test_match():
    assert evaluate_match(match, 'pacman --query --search -v') ==  True
    assert evaluate_match(match, 'pacman -S -u -q') ==  True
    assert evaluate_match(match, 'pacman -Syuq') ==  False
    assert evaluate_match(match, 'pacman -Q -d') ==  True
    assert evaluate_match(match, 'pacman -Q --search') ==  True
    assert evaluate_match(match, 'pacman --query --search -r') ==  True
    assert evaluate_match(match, 'pacman -Su') ==  True
    assert evaluate_match(match, 'pacman -Q -e') ==  True
    assert evaluate_match(match, 'pacman -R -c -u -q') ==  True

# Generated at 2022-06-26 06:32:23.759809
# Unit test for function match
def test_match():
    assert (match(Command(script='pacman -S xorg-server')) == True)
    assert (match(Command(script='pacman -S xorg-server', output='error: invalid option -S')) == False)
    assert (match(Command(script='pacman -S xorg-server', output='error: invalid option -S\n')) == False)
    assert (match(Command(script='pacman -S xorg-server', output='error: invalid option -S\n'
        'Usage: pacman -[V')) == False)
    assert (match(Command(script='pacman -s xorg-server', output='error: invalid option -s')) == True)
    assert (match(Command(script='pacman -s xorg-server', output='error: invalid option -s\n')) == True)

# Generated at 2022-06-26 06:32:25.449461
# Unit test for function match
def test_match():
    # prepare
    result = match(command)

    # check
    assert result == expected


# Generated at 2022-06-26 06:32:27.295406
# Unit test for function match
def test_match():
    assert match(Command(script="pacman -c", stderr="error: invalid option '-c'",
                         error=True))


# Generated at 2022-06-26 06:32:28.328130
# Unit test for function match
def test_match():
    
#	assert match(command) ==
	return

# Generated at 2022-06-26 06:32:29.835518
# Unit test for function match
def test_match():
    assert match("pacman -Syu")
    assert not match("pacman -Syu test")

# Generated at 2022-06-26 06:32:34.524005
# Unit test for function match
def test_match():
    assert match(bool_0) == False
    assert match(bool_1) == False
    assert match(var_0) == False
    assert match(var_1) == False
    assert match(var_2) == False
    assert match(var_3) == False
    assert match(var_4) == Fals

# Generated at 2022-06-26 06:32:45.020668
# Unit test for function match
def test_match():
    func = match
    command_1 = Command(script="pacman -R foo", output="error: invalid option '-R'")
    assert func(command_1) is True
    command_2 = Command(script="pacman -q foo", output="error: invalid option '-q'")
    assert func(command_2) is True
    command_3 = Command(script="pacman -s foo", output="error: invalid option '-s'")
    assert func(command_3) is True
    command_4 = Command(script="pacman -u foo", output="error: invalid option '-u'")
    assert func(command_4) is True
    command_5 = Command(script="pacman -v foo", output="error: invalid option '-v'")
    assert func(command_5) is True
    command_6

# Generated at 2022-06-26 06:32:46.694543
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(bool_0) == "pacman -S python3-pip"


# Generated at 2022-06-26 06:32:52.821560
# Unit test for function match
def test_match():
    bool_0 = True
    bool_1 = False
    bool_2 = True
    bool_3 = False
    bool_4 = False
    bool_5 = bool_0
    bool_6 = bool_2
    str_1 = "error: invalid option '--foo'"
    str_2 = "error: invalid option '-foo'"
    TestCase_0 = match(bool_1)
    TestCase_1 = match(bool_2)
    TestCase_2 = match(bool_3)
    TestCase_3 = match(bool_4)
    TestCase_4 = match(bool_5)
    TestCase_5 = match(bool_6)

    assert TestCase_0 == bool_0
    assert TestCase_1 == bool_0
    assert TestCase_2 == bool_0
    assert TestCase_

# Generated at 2022-06-26 06:33:23.915781
# Unit test for function match
def test_match():
    # Error_1
    var_1 = "pacman -Rdd package"
    var_2 = True
    var_1 = re.findall(r" -[dfqrstuv]", var_1)[0]
    var_3 = re.sub(var_1, var_1.upper(), var_2)
    var_0 = sudo_support
    var_0 = for_app()
    var_0 = match(var_3)
    assert var_0
    # Error_2
    var_4 = "pacman -Rdd package"
    var_5 = False
    var_4 = re.findall(r" -[dfqrstuv]", var_4)[0]
    var_6 = re.sub(var_4, var_4.upper(), var_5)
    var_0

# Generated at 2022-06-26 06:33:24.866395
# Unit test for function match
def test_match():
    assert None == match(None)


# Generated at 2022-06-26 06:33:26.155874
# Unit test for function match
def test_match():
    assert match(bool) == bool


# Generated at 2022-06-26 06:33:36.999799
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = "pacman -R proj"
    cmd = Command(script=var_0, output='error: invalid option -- \'r\'')
    assert get_new_command(cmd) == "pacman -R proj"
    var_0 = "pacman -d proj"
    cmd = Command(script=var_0, output='error: invalid option -- \'d\'')
    assert get_new_command(cmd) == "pacman -d proj"
    var_0 = "pacman -f proj"
    cmd = Command(script=var_0, output='error: invalid option -- \'f\'')
    assert get_new_command(cmd) == "pacman -f proj"
    var_0 = "pacman -q proj"

# Generated at 2022-06-26 06:33:38.305221
# Unit test for function match
def test_match():
    var_1 = 'pacman -Suyyu'
    var_2 = Command(var_1)
    var_3 = match(var_2)
    assert var_3 == False

# Generated at 2022-06-26 06:33:40.322916
# Unit test for function match
def test_match():
    bool_0 = True
    arg0 = Command("pacman -Ssd ruby", "error: invalid option -d")
    ret_0 = match(arg0)
    arg1 = Command("pacman -Ssd", "error: invalid option -d")
    ret_1 = match(arg1)

# Generated at 2022-06-26 06:33:50.371362
# Unit test for function match
def test_match():
    bool_0 = True
    var_0 = get_new_command(bool_0)
    var_1 = match(bool_0)
    assert var_1 == bool_0

    var_2 = False
    bool_1 = True
    var_3 = get_new_command(var_2)
    var_4 = match(bool_1)
    assert var_4 == bool_1

    var_5 = False
    var_6 = get_new_command(var_5)
    var_7 = match(var_5)
    assert var_7 == var_5

    var_8 = True
    var_9 = get_new_command(var_8)
    var_10 = match(var_8)
    assert var_10 == var_8

# Generated at 2022-06-26 06:33:54.637539
# Unit test for function match
def test_match():

    # Argument void:
    # Implicit declaration of variable command
	command = 0

    # Verify that match returns the expected boolean value.

# Generated at 2022-06-26 06:33:57.014348
# Unit test for function match
def test_match():
    command = bool_0
    assert match(bool_0) == re.findall(' -[dfqrstuv]', command.script)[0].upper()

# Generated at 2022-06-26 06:34:03.161675
# Unit test for function match
def test_match():

    # Test original script
    var_0 = True
    var_1 = "error: invalid option '-r'"
    var_2 = "pacman -r"
    var_2_copy = var_2.copy()
    var_2_copy.output = var_1
    var_2_copy.stderr = var_1.encode()
    var_2_copy.script = var_2
    var_2_copy.stderr = var_1.encode()
    var_2_copy.stdout = None
    boo

# Generated at 2022-06-26 06:34:55.136511
# Unit test for function match
def test_match():
    arg0 = re.findall(r" -[dfqrstuv]", "sudo pacman -Suq")[0]
    var_1 = " -{}".format(arg0)
    var_2 = "sudo pacman -Suq"
    var_3 = re.sub(var_1, var_1.upper(), var_2)
    # var_2: "sudo pacman -Suq"
    # var_3: "sudo pacman -SuQ"

    res = match(
        Command(
            script = var_2,
            output = "error: invalid option '-q'\nTry 'pacman --help' for more information.",
        )
    )

    assert res


# Generated at 2022-06-26 06:34:56.624333
# Unit test for function match
def test_match():
    assert match(bool_0) == True


# Generated at 2022-06-26 06:34:59.784606
# Unit test for function match
def test_match():
    bool_0 = True
    # TODO: Change to a valid command
    command = "pacman -gf"
    var_0 = match(command)
    # EXPECT: bool_0
    assert var_0 == bool_0

# Generated at 2022-06-26 06:35:00.755723
# Unit test for function match
def test_match():
    assert match(command) == bool_0


# Generated at 2022-06-26 06:35:05.572451
# Unit test for function get_new_command
def test_get_new_command():
    # Test a false positive
    assert get_new_command(Command("ls -qr", "", 0, "")) != "pacman -S pacman"
    # Test a false negative
    assert get_new_command(Command("pacman -qr", "", 0, "")) == "pacman -Qr"
    # Test a false negative
    assert get_new_command(Command("pacman -sr", "", 0, "")) == "pacman -Sr"
    assert get_new_command(Command("pacman -qr", "", 0, "")) != "pacman -Sr"
    # Test a false negative
    assert get_new_command(Command("pacman -sq", "", 0, "")) == "pacman -Sq"

# Generated at 2022-06-26 06:35:15.142395
# Unit test for function match
def test_match():
    assert re.match(r'error: invalid option \'\-(\S)\'', 'error: invalid option \'-f\'')
    assert re.match(r'error: invalid option \'\-(\S)\'', 'error: invalid option \'-u\'')
    assert re.match(r'error: invalid option \'\-(\S)\'', 'error: invalid option \'-d\'')
    assert re.match(r'error: invalid option \'\-(\S)\'', 'error: invalid option \'-q\'')
    assert re.match(r'error: invalid option \'\-(\S)\'', 'error: invalid option \'-r\'')
    assert re.match(r'error: invalid option \'\-(\S)\'', 'error: invalid option \'-s\'')

# Generated at 2022-06-26 06:35:20.793268
# Unit test for function match
def test_match():
    command = Command("pacman -s something", "error: invalid option '-'")
    assert match(command)
    command = Command("pacman -q something", "error: invalid option '-'")
    assert match(command)
    command = Command("pacman foobar", "error: invalid option '-'")
    assert not match(command)


# Generated at 2022-06-26 06:35:22.786869
# Unit test for function match
def test_match():
    var_1 = True
    output = match(var_1)
    assert output == True


# Generated at 2022-06-26 06:35:33.262873
# Unit test for function match
def test_match():
    boo_0 = "pacman -Qa"
    boo_1 = "pacman -Syu"
    boo_2 = "pacman -Sfq"
    boo_3 = "pacman -Sq"
    boo_4 = "pacman -SqQ"
    boo_5 = "pacman -Qsq"
    boo_6 = "pacman -Qq"
    boo_7 = "pacman -uqd"
    boo_8 = "pacman -vdu"
    boo_9 = "pacman -Sy"
    boo_10 = "pacman -rq"
    boo_11 = "pacman -qr"
    boo_12 = "pacman -su"
    boo_13 = "pacman -Vu"
    boo_14 = "pacman -Qu"
    boo_15

# Generated at 2022-06-26 06:35:36.654922
# Unit test for function match
def test_match():
    assert not match(Command('pacman -Auf', '', ''))
    assert match(Command('pacman -u', '', ''))
    assert match(Command('pacman -A', '', ''))
    assert not match(Command('pacman -A', '', ''))


# Generated at 2022-06-26 06:37:16.291842
# Unit test for function match
def test_match():
    var_2 = " -"
    var_1 = "error: invalid option '-R'; use '--unneeded' to remove unneeded packages, '--asexplicit' to list them or '--asexplicit --unneeded' to remove them"
    var_0 = Command(var_1, var_2)
    var_3 = match(var_0)
    print(var_3)


# Generated at 2022-06-26 06:37:22.366336
# Unit test for function match
def test_match():
    var_1 = Command("pacman -Syu")
    var_1.error = True
    var_1.side_effect = ["error: invalid option '-'"]
    var_1.output = "error: invalid option '-'"
    var_1.script = "pacman -Syu"
    var_1.env = {}
    var_1.args = []
    var_1.kwargs = {}
    bool_1 = match(var_1)
    assert bool_1 == False


# Generated at 2022-06-26 06:37:28.914101
# Unit test for function match
def test_match():
    bool_0 = False
    bool_1 = False
    bool_2 = True
    bool_3 = False
    bool_4 = True
    bool_5 = False
    bool_6 = False
    bool_7 = True
    bool_8 = True
    bool_9 = False
    bool_10 = True
    bool_11 = True
    bool_12 = False
    bool_13 = True
    bool_14 = False
    bool_15 = False
    bool_16 = True
    bool_17 = False
    bool_18 = True
    result_1 = match(bool_1)
    result_2 = match(bool_2)
    result_3 = match(bool_3)
    result_4 = match(bool_4)
    result_5 = match(bool_5)
    result_6 = match

# Generated at 2022-06-26 06:37:29.648675
# Unit test for function match
def test_match():
    assert match(bool_0) == False


# Generated at 2022-06-26 06:37:33.413486
# Unit test for function get_new_command
def test_get_new_command():
    var_1 = Mock(script = 'pacman -R -s extra/foo --dbonly', output = '', stdout = '', stderr = '', args = '', sucess = True)
    assert get_new_command(var_1) == 'pacman -R -S extra/foo --db-only'

# Generated at 2022-06-26 06:37:36.017729
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command is not None


# Generated at 2022-06-26 06:37:36.893103
# Unit test for function match
def test_match():
    test_case_0()

# Generated at 2022-06-26 06:37:38.781547
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(True) == 'True'


# Generated at 2022-06-26 06:37:43.259945
# Unit test for function get_new_command
def test_get_new_command():
    func_0 = build_command_list()
    assert func_0 and func_0[0][0] == '-u', 'Wrong command list!'
    bool_0 = (func_0[0][0], var_0[1], func_0[0][2])
    assert var_0 == bool_0, 'Wrong new command!'

# Generated at 2022-06-26 06:37:51.447810
# Unit test for function match
def test_match():
    arg = True
    var_0 = re.findall(r" -[dfqrstuv]", arg)
    var_1 = True
    var_2 = re.sub(var_0, option.upper(), arg)