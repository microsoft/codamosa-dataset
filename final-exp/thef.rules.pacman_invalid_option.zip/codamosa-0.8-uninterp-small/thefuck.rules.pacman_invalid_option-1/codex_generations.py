

# Generated at 2022-06-26 06:28:43.213057
# Unit test for function get_new_command
def test_get_new_command():
    assert callable(get_new_command)


# Generated at 2022-06-26 06:28:47.693933
# Unit test for function match
def test_match():
    var_0 = False
    command = var_0
    command.output = "error: invalid option '-f'"
    command.script = "pacman -f"
    var_2 = match(command)
    var_3 = False

    assert var_2 == var_3


# Generated at 2022-06-26 06:28:55.457781
# Unit test for function match

# Generated at 2022-06-26 06:29:01.310889
# Unit test for function match
def test_match():
    var_0 = True
    var_1 = True
    bool_0 = True
    var_2 = Command(script='', stderr='error: invalid option -s')

    expected = True
    received = match(var_2)
    assert received == expected, "Match failed: Expected {0}, received {1}".format(expected, received)

# Generated at 2022-06-26 06:29:02.655906
# Unit test for function match
def test_match():
    assert match("error: invalid option '-s'")


# Generated at 2022-06-26 06:29:12.208447
# Unit test for function get_new_command

# Generated at 2022-06-26 06:29:12.702295
# Unit test for function match
def test_match():
    assert match() == False

# Generated at 2022-06-26 06:29:16.434863
# Unit test for function match
def test_match():
    var_1 = False
    with Mock() as mock:
        mock.script = "no match"
        mock.output = "no match"
        var_2 = match(mock)
        assert (var_2 == var_1)
        

# Generated at 2022-06-26 06:29:18.925606
# Unit test for function match
def test_match():
    command = "sudo apt-get install kde-plasma-desktop"
    p = match(command)
    assert p == "sudo apt-get install kde-plasma-desktop"

# Generated at 2022-06-26 06:29:28.728348
# Unit test for function match
def test_match():
    assert match(False) == False
    assert match(True) == False
    assert match(True) == False
    assert match(False) == False
    assert match(True) == False
    assert match(False) == False
    assert match(False) == False
    assert match(True) == False
    assert match(True) == False
    assert match(False) == False
    assert match(False) == False
    assert match(True) == False
    assert match(False) == False
    assert match(True) == False
    assert match(True) == False
    assert match(False) == False
    assert match(True) == False
    assert match(True) == False
    assert match(False) == False
    assert match(True) == False
    assert match(False) == False
    assert match(True) == False
   

# Generated at 2022-06-26 06:29:31.904325
# Unit test for function match
def test_match():
    assert match('pacman -suq') == (True, ('-u', ), ('-q', ))



# Generated at 2022-06-26 06:29:33.453870
# Unit test for function get_new_command
def test_get_new_command():
    assert re.match('parser.add_argument.+', get_new_command('command'))

# Generated at 2022-06-26 06:29:35.981111
# Unit test for function match
def test_match():
    # call function
    var_match = match()
    # assert return value
    assert (var_match == False)


# Generated at 2022-06-26 06:29:40.618763
# Unit test for function match
def test_match():
    var_0 = Command('pacman -qss xsel', 'error: invalid option -q', match)
    var_1 = Command('pacman -Qs xsel', 'error: invalid option -Q', match)
    assert_equal(var_0, False)
    assert_equal(var_1, True)


# Generated at 2022-06-26 06:29:42.225422
# Unit test for function match
def test_match():
    assert False


# Generated at 2022-06-26 06:29:44.733204
# Unit test for function match
def test_match():
    script = "$ pacman -Qv"
    output = "error: invalid option '-'"
    command = Command(script, output)
    assert match(command)


# Generated at 2022-06-26 06:29:47.991880
# Unit test for function match
def test_match():
    assert not match(Command("pacman bla", stderr="error: invalid option '-'"))
    assert match(Command("pacman -q bla", stderr="error: invalid option '-q'"))



# Generated at 2022-06-26 06:29:48.842695
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command({}) == {}

# Generated at 2022-06-26 06:29:57.372037
# Unit test for function match
def test_match():
    var_1 = Command('pacman -Qi nvidia', '', 'error: invalid option -- \'i\'')
    assert match(var_1) == False
    var_2 = Command('pacman -Qnvidia', '', 'error: invalid option -- \'n\'')
    assert match(var_2) == False
    var_3 = Command('pacman -Q', '', 'error: invalid option -- \'Q\'')
    assert match(var_3) == False
    var_4 = Command('pacman -Qa', '', 'error: invalid option -- \'a\'')
    assert match(var_4) == True
    var_5 = Command('pacman -Qi', '', 'error: invalid option -- \'i\'')
    assert match(var_5) == True

# Generated at 2022-06-26 06:29:59.570577
# Unit test for function match
def test_match():
    command = Command('pacman -u', 'error: invalid option -- \'u\'')
    assert match(command)



# Generated at 2022-06-26 06:30:05.939212
# Unit test for function match
def test_match():
    bool_0 = False
    bool_1 = True
    command = Command('pacman -sh')
    bool_2 = bool_0 if bool_1 else bool_0
    bool_3 = match(command)
    assert bool_2 == bool_3


# Generated at 2022-06-26 06:30:15.867972
# Unit test for function match
def test_match():
    assert match("pacman -Syu", "error: invalid option '-y'\nTry `pacman -Sy --help' or `pacman --help' for more information.") == True
    assert match("pacman -Syu", "man: invalid option -- 'S'\nTry `man -h' or `man --help' for more information.") == False
    assert match("pacman -Syu", "error: invalid option '-x'\nTry `pacman --help' for more information.") == False
    assert match("pacman -Syu", "error: invalid option '-x'\nTry `pacman --help' for more information.") == False
    assert match("pacman -Syu", "error: invalid option '-x'\nTry `pacman --help' for more information.") == False

# Generated at 2022-06-26 06:30:22.083386
# Unit test for function match
def test_match():
    command = MagicMock(
        output="error: invalid option '-s'",
        script="pacman -s vim",
        arguments=["pacman", "-s", "vim"],
    )
    assert match(command)
    assert not match(MagicMock(script="pacman -f vim",
                                      output="",
                                      arguments=["pacman", "-f", "vim"]))

# Generated at 2022-06-26 06:30:25.560136
# Unit test for function match
def test_match():
    bool_0 = True
    input_bool = 'bWWx'
    str_0 = get_new_command(input_bool)
    var_0 = match(bool_0)
    var_1 = match(input_bool)
    var_2 = match(str_0)

# Generated at 2022-06-26 06:30:27.530675
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = False
    var_0 = get_new_command(bool_0)
    assert True


# Generated at 2022-06-26 06:30:31.925647
# Unit test for function match
def test_match():
    print("Testing match")
    cmd = Command("pacman -Qs python2-tox", "")
    assert match(cmd)
    cmd = Command("pacman -Qs python3-tox", "")
    assert match(cmd)


# Generated at 2022-06-26 06:30:35.455758
# Unit test for function get_new_command
def test_get_new_command():
    param_0 = (re.findall(r" -[dfqrstuv]", command.script)[0])
    assert re.sub(param_0, param_0.upper(), command.script) == True

# Generated at 2022-06-26 06:30:39.390471
# Unit test for function match
def test_match():
    var_0 = 'pacman -f -qqg'
    var_0 = Command(script=var_0, output='error: invalid option -- f\n\n')
    var_0 = match(var_0)
    assert var_0 == True


# Generated at 2022-06-26 06:30:44.554032
# Unit test for function match
def test_match():
	string_0 = "sudo someprogram"
	var_0= match(string_0)
	assert(var_0 == True)

	string_0 = "sudo someprogrm"
	var_0= match(string_0)
	assert(var_0 == True)

	string_0 = "somprog"
	var_0= match(string_0)
	assert(var_0 == False)

# Generated at 2022-06-26 06:30:51.616249
# Unit test for function match
def test_match():
    var_0 = True
    var_1 = "error: invalid option '-d'"
    var_2 = "pacman -d foo"
    var_2 = Command(var_2, var_1)
    var_3 = match(var_2)
    result = var_3

    assert result


# Generated at 2022-06-26 06:30:57.233082
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = "pacman -Qqet"
    var_0 = get_new_command(bool_0)
    assert var_0 == "pacman -Qqet"


# Generated at 2022-06-26 06:31:03.138478
# Unit test for function match
def test_match():
    command = Command("pacman -Sd X Y Z")
    assert match(command)
    command = Command('pacman -q "extra/gcc"')
    assert not match(command)
    command = Command('pacman -u "extra/gcc"')
    assert not match(command)
    command = Command("pacman -s core/coreutils")
    assert not match(command)



# Generated at 2022-06-26 06:31:08.866426
# Unit test for function get_new_command
def test_get_new_command():
    bool_2 = False
    str_0 = "pacman -v -r"
    var_1 = command.Script(str_0, bool_2, bool_2)
    var_2 = var_1.script
    var_3 = get_new_command(var_1)
    var_4 = var_3 == var_2.replace("-v", "-V")
    assert var_4 == True

# Generated at 2022-06-26 06:31:13.285599
# Unit test for function match
def test_match():
    assert match(command="pacman -D --asdeps community/firefox-nightly")



# Generated at 2022-06-26 06:31:21.200788
# Unit test for function match
def test_match():

    # No Argument
    assert not match(None)

    # Argument = pacman -b
    assert match("pacman -b")

    # Argument = pacman -t
    assert match("pacman -t")

    # Argument = pacman -q
    assert match("pacman -q")

    # Argument = pacman -s
    assert match("pacman -s")

    # Argument = pacman -T
    assert match("pacman -T")

    # Argument = pacman -u
    assert match("pacman -u")

    # Argument = pacman -v
    assert match("pacman -v")

# Generated at 2022-06-26 06:31:31.959204
# Unit test for function match
def test_match():
    bool_0 = False
    bool_1 = True
    str_0 = " error: invalid option '-f' "
    str_1 = " "
    str_2 = " error: invalid option '-f' "
    str_3 = " "
    str_4 = " error: invalid option '-f' "
    str_5 = " "
    str_6 = " error: invalid option '-f' "
    str_7 = " "
    str_8 = " error: invalid option '-f' "
    str_9 = " "
    str_10 = " error: invalid option '-f' "
    str_11 = " "
    str_12 = " error: invalid option '-f' "
    str_13 = " "
    str_14 = " error: invalid option '-f' "
   

# Generated at 2022-06-26 06:31:42.049981
# Unit test for function match
def test_match():
    var_0 = True
    var_1 = True
    var_2 = True
    var_3 = True
    var_4 = True
    var_5 = True
    var_6 = True
    var_7 = True
    var_8 = True
    var_9 = True
    var_10 = True
    var_11 = True
    var_12 = True
    var_13 = True
    var_14 = True
    var_15 = True
    var_16 = True
    var_17 = True
    var_18 = True
    var_19 = True
    var_20 = True
    var_21 = True
    var_22 = True
    var_23 = True
    var_24 = True
    var_25 = True
    var_26 = True
    var_27 = True
    var_

# Generated at 2022-06-26 06:31:43.021382
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(bool_0) == ""

# Generated at 2022-06-26 06:31:44.729572
# Unit test for function match
def test_match():
    assert match(False, 'error: invalid option \'-v\'') == False


# Generated at 2022-06-26 06:31:45.361892
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command() == "Pacman -S $@"

# Generated at 2022-06-26 06:31:53.051492
# Unit test for function match
def test_match():
    assert match(Command("ls -1", "ls: invalid option -- '1'\ntry 'ls --help' for more information"))


# Generated at 2022-06-26 06:31:55.886669
# Unit test for function get_new_command
def test_get_new_command():
    with mock.patch('thefuck.rules.arch.match', return_value='Do_you_mean'):
        assert mock.match == 'Do_you_mean'

# Generated at 2022-06-26 06:31:58.038987
# Unit test for function match
def test_match():
    bool_0 = True

    # SUT
    var_0 = match(bool_0)

    # Assertion
    assert var_0 == True

# Generated at 2022-06-26 06:32:05.551880
# Unit test for function match
def test_match():
    var_1 = 'Error: invalid option \'q\''
    var_2 = True
    var_2 = run(var_2, echo=True, stderr=var_1)
    var_5 = var_2.script
    var_1 = 'error: invalid option \'q\''
    var_2 = var_2.output
    var_3 = 'q'
    var_4 = '  -q'
    var_6 = var_5.startswith(var_1)
    var_7 = bool(var_2)
    var_8 = bool(var_3 in var_4)
    var_9 = bool(var_6 == var_7 and var_7 == var_8)
    return var_9

# Generated at 2022-06-26 06:32:11.716142
# Unit test for function get_new_command
def test_get_new_command():
    import thefuck.main
    import thefuck.types

# Generated at 2022-06-26 06:32:12.793689
# Unit test for function match
def test_match():
    assert match(command) == true

# Generated at 2022-06-26 06:32:15.005035
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = True
    var_0 = get_new_command(bool_0)


# Generated at 2022-06-26 06:32:17.987416
# Unit test for function match
def test_match():
	function_match = True
	bool_0 = True
	var_0 = match(bool_0)
	function_match = var_0
	assert function_match


# Generated at 2022-06-26 06:32:27.168228
# Unit test for function match
def test_match():
    assert match('foo') is False
    assert match('pacman -Qi bla') is False
    assert match('pacman -Qi') is False
    assert match('pacman -Qi') is False
    assert match('pacman -Qi') is False
    assert match('pacman') is False
    assert match('pacman -Sy foo and bar') is False
    assert match('pacman -Qlk foo') is False
    assert match('pacman -S foo') is False
    assert match('pacman -S') is False
    assert match('pacman -S foo') is False
    assert match('pacman -Sfoo') is False
    assert match('pacman -Syy foo') is False
    assert match('pacman -Sy foo') is False
    assert match('pacman -Syu foo') is False

# Generated at 2022-06-26 06:32:29.913997
# Unit test for function match
def test_match():
    # This is a test for testability
    # If I understand this correctly, it just checks if the functions that
    # match() calls actually exist.
    assert callable(match)



# Generated at 2022-06-26 06:32:42.251603
# Unit test for function match
def test_match():
    assert match(get_new_command(True)) == False

# Generated at 2022-06-26 06:32:45.668973
# Unit test for function match
def test_match():
    assert match(Command('pacman -S pack', 'error: invalid option -S')) is False
    assert match(Command('pacman -u pack', 'error: invalid option -u')) is True


# Generated at 2022-06-26 06:32:48.529028
# Unit test for function match
def test_match():
    var_0 = "pacm -su"
    var_0 = Command(script=var_0)
    bool_0 = True
    bool_0 = match(var_0)
    assert bool_0 == bool(True)


# Generated at 2022-06-26 06:32:51.515214
# Unit test for function match
def test_match():
    bool_0 = True
    var_0 = re.findall(r" -[dfqrstuv]", bool_0)
    assert var_0 == ['-t']


# Generated at 2022-06-26 06:32:54.895227
# Unit test for function match
def test_match():
    command = "pacman --sync -f meld"
    output = "error: invalid option '-f'"
    
    assert match(command, output)

# Generated at 2022-06-26 06:32:57.885502
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('pacman -Ss pacman',
                      'error: invalid option -- \'S\'')
    
    one_in_false = get_new_command(command)
    assert one_in_false


# Generated at 2022-06-26 06:33:03.806375
# Unit test for function get_new_command
def test_get_new_command():
    var_1 = "Error: invalid option '-f'"
    var_2 = TestCommand(stdout=var_1, stderr=var_1)
    var_2.script = "pacman -Suy -Sf"
    bool_1 = False
    assert get_new_command(var_2) == "sudo pacman -Suy -SF"


# Generated at 2022-06-26 06:33:05.889711
# Unit test for function get_new_command
def test_get_new_command():
    assert re.search(r" -[dfqrstuv]", " -f", re.M|re.I)


# Generated at 2022-06-26 06:33:08.720719
# Unit test for function get_new_command
def test_get_new_command():
    command = "pacman -Qd"
    option = re.findall(r" -[dfqrstuv]", command)[0]
    actual = re.sub(option, option.upper(), command)
    expected = "pacman -QD"
    assert actual == expected


# Generated at 2022-06-26 06:33:11.357716
# Unit test for function match
def test_match():
    assert match(Command('pacman -rsu sudo', '', ''), None) == True
    assert match(Command('pip install requests', '', '/usr/bin/pip'), None) == False


# Generated at 2022-06-26 06:33:34.994507
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 06:33:36.988205
# Unit test for function match
def test_match():
    re.findall = MagicMock()

    command = "command"
    assert match(command) == False

# Generated at 2022-06-26 06:33:39.077020
# Unit test for function match
def test_match():
	assert match(5) == False, "Bad options are showing up as valid"
	assert match(1) == True, "It thinks a valid option is bad"



# Generated at 2022-06-26 06:33:48.190874
# Unit test for function match

# Generated at 2022-06-26 06:33:58.030372
# Unit test for function match
def test_match():
    bool_0 = False
    bool_1 = False
    bool_2 = False
    bool_3 = False

    var_0 = (False, True)
    var_0 = force_bool(var_0)
    var_1 = (False, True)
    var_1 = force_bool(var_1)
    var_2 = (False, True)
    var_2 = force_bool(var_2)
    var_3 = (False, True)
    var_3 = force_bool(var_3)


# Generated at 2022-06-26 06:34:05.319288
# Unit test for function match
def test_match():
    assert match(Command('pacman -Sy'), None) == False
    assert match(Command('pacman --sync', None), None) == False
    assert match(Command('pacman -s', None), None) == False
    assert match(Command('pacman -h', None), None) == False
    assert match(Command('pacman-g2 -?', None), None) == False
    assert match(Command('pacman --help', None), None) == False
    assert match(Command('pacman --version', None), None) == False
    assert match(Command('pacman -V', None), None) == False
    assert match(Command('pacman --version', None), None) == False
    assert match(Command('pacman -v', None), None) == False
    assert match(Command('pacman --version', None), None) == False


# Generated at 2022-06-26 06:34:14.820599
# Unit test for function match
def test_match():
    # If match is called with parameter:
    # command = Command(<script>, <output>)
    # then return value of this function should be this:
    assert match(
        Command(script="pacman -q", output="error: invalid option '-q'")
    ) is True
    assert match(
        Command(
            script="pacman -e", output="error: invalid option '-e'", stderr=""
        )
    ) is False
    assert match(
        Command(script="pacman -u", output="error: invalid option '-u'")
    ) is True
    assert match(
        Command(
            script="pacman -r -r", output="error: invalid option '-r'", stderr=""
        )
    ) is False

# Generated at 2022-06-26 06:34:19.572275
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = True
    var_0 = get_new_command(bool_0)
    var_1 = re.findall(r" -[dfqrstuv]", command.script)[0]
    if var_1 is not None:
        var_2 = re.sub(option, option.upper(), command.script)
    assert var_2 == re.sub(option, option.upper(), command.script)

# Generated at 2022-06-26 06:34:24.873024
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = Match(script=Script(script="pacman -Q", stderr="error: invalid option '-Q'\n"), output="error: invalid option '-Q'\n", command="pacman -Q")
    var_1 = get_new_command(var_0)
    assert var_1 == "pacman -q"


# Generated at 2022-06-26 06:34:32.641541
# Unit test for function match
def test_match():
    var_0 = Command(script = "sudo pacman -Ss linux",
                    output = "error: invalid option '-S'")
    var_1 = Command(script = "sudo pacman -Syu",
                    output = "error: invalid option '-U'")
    var_2 = Command(script = "sudo pacman -Qe",
                    output = "error: invalid option '-E'")
    var_3 = Command(script = "sudo pacman -Qo /usr/bin/gnome-terminal",
                    output = "error: invalid option '-O'")
    var_4 = Command(script = "sudo pacman -Ir linux",
                    output = "error: invalid option '-I'")

# Generated at 2022-06-26 06:35:21.663278
# Unit test for function match
def test_match():
    assert match(bool_0) == True

# Generated at 2022-06-26 06:35:26.506348
# Unit test for function match
def test_match():
    command = 'pacman --ascii -Qow "7-zip" | grep "^/usr/bin/"'
    assert match(command) == 1

    command = 'pacman --ascii -Qow "7-zip" | grep -o "^/usr/bin/.*$"'
    assert match(command) == False

# Generated at 2022-06-26 06:35:29.090143
# Unit test for function match
def test_match():
    from thefuck.rules.Error_invalid_option import get_new_command
    command = "root@boo:~# pacman -v -u blah blah blah"
    assert match(command)


# Generated at 2022-06-26 06:35:31.404184
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = False
    var_0 = get_new_command(bool_0)



# Generated at 2022-06-26 06:35:39.569322
# Unit test for function match
def test_match():
    assert match('pacman -v') == True
    assert match('pacman -q') == True
    assert match('pacman -qe') == False
    assert match('pacman -qe -sync') == False
    assert match('pacman -qe -sync --asroot') == False
    assert match('pacman -Fy') == False
    assert match('pacman -Fy --asroot') == False
    assert match('pacman -Fy --sync') == False
    assert match('pacman -u') == True
    assert match('pacman -u -sync') == True
    assert match('pacman -u -sync') == True
    assert match('pacman -u -sync --asroot') == True
    assert match('pacman -u -sync --asroot') == True

# Generated at 2022-06-26 06:35:40.813770
# Unit test for function match
def test_match():
    assert match(var_0) == False


# Generated at 2022-06-26 06:35:42.505696
# Unit test for function match
def test_match():
    assert match(bool_0)==False
    assert match(var_0)==True

# Generated at 2022-06-26 06:35:52.801453
# Unit test for function match

# Generated at 2022-06-26 06:35:54.400609
# Unit test for function match
def test_match():
    assert match("pacman -v")
    assert not match("pacman -V")


# Generated at 2022-06-26 06:35:55.898463
# Unit test for function match
def test_match():
    assert bool(match(["pacman -h"]))


# Generated at 2022-06-26 06:37:40.472258
# Unit test for function match
def test_match():
    bool_0 = True
    assert bool_0 == (match(bool_0))


# Generated at 2022-06-26 06:37:47.898757
# Unit test for function match
def test_match():
    # Setup mock for for for_app to return true for app_name = "pacman"
    mock_for_app = mock.MagicMock()
    mock_for_app.return_value = True

    # Setup mock for sudo_support to return the function unchanged
    mock_sudo_support = mock.MagicMock()
    mock_sudo_support.return_value = match

    # Test that the match is found
    import thefuck.specific.archlinux
    with mock.patch.object(thefuck.specific.archlinux, 'for_app', mock_for_app), \
            mock.patch.object(thefuck.specific.archlinux, 'sudo_support', mock_sudo_support):
        command = mock.MagicMock()
        command.script = "pacman -Syu"

# Generated at 2022-06-26 06:37:51.158073
# Unit test for function match
def test_match():
    command = Command("pacman -u <pkg>")
    setattr(command, 'output', "error: invalid option '-u'")
    assert match(command) == True
    command = Command("pacman --help")
    setattr(command, 'output', "error: invalid option '-u'")
    assert match(command) == False


# Generated at 2022-06-26 06:37:56.449957
# Unit test for function match
def test_match():
    assert match("pacman -S python")
    assert not match("pacman -S python2")
    assert not match("something")
    assert match("pacman -F")
    assert not match("pacman -f")
    assert match("pacman -q")
    assert match("sudo pacman -q")
    assert not match("pacman -q")
    assert match("pacman -r")
    assert not match("pacman -r")
    assert match("pacman -t")
    assert not match("pacman -t")

# Generated at 2022-06-26 06:38:03.228388
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = Command("pacman -sws python")
    assert var_0.script == "pacman -sws python"
    assert var_0.stdout == ""
    assert var_0.stderr == "error: invalid option '-s'\nSee 'pacman --help'.\n"
    var_0 = get_new_command(var_0)
    assert var_0 == "pacman -Sws python"

    var_0 = Command("pacman -updf lolcat")
    assert var_0.script == "pacman -updf lolcat"
    assert var_0.stdout == ""
    assert var_0.stderr == "error: invalid option '-d'\nSee 'pacman --help'.\n"
    var_0 = get_new_command(var_0)


# Generated at 2022-06-26 06:38:06.756477
# Unit test for function match
def test_match():
    app_var = "pacman"
    out_var = "error: invalid option '-f'"
    cmd_var = "pacman -f"
    ret_var = True

    ret = match(app_var, out_var, cmd_var)

    assert(ret == ret_var)


# Generated at 2022-06-26 06:38:10.787442
# Unit test for function match
def test_match():
    # AssertionError(return_value) is returned when error
    assert match(Command('pacman --version', '', '/tmp'))


# Generated at 2022-06-26 06:38:15.431818
# Unit test for function match
def test_match():
    command = "pacman -Syu"
    #return command.output.startswith("error: invalid option '-") and any(
    #    " -{}".format(option) in command.script for option in "surqfdvt"
    return "error: invalid option '-s'" in command

test_match()

# Generated at 2022-06-26 06:38:16.809023
# Unit test for function match
def test_match():
    assert match(command=False) == False


# Generated at 2022-06-26 06:38:18.447251
# Unit test for function match
def test_match():
    bool_0 = False
    var_0 = match(bool_0)
    assert var_0 == bool_0