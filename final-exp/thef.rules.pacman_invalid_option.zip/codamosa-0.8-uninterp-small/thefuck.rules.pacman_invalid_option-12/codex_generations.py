

# Generated at 2022-06-26 06:28:46.060985
# Unit test for function match
def test_match():
    assert match(dict_0) #, None)

# Generated at 2022-06-26 06:28:54.710494
# Unit test for function match
def test_match():

    # Ensure that the function returns True if the error message is 
    # "error: invalid option '-'"
    dict = {}
    dict["output"] = "error: invalid option '-'"
    dict["script"] = "pacman -Syu"
    var = match(dict)
    assert var == True

    # Ensure that the function returns True if the error message is 
    # "error: invalid option '-'"
    dict = {}
    dict["output"] = "error: invalid option '-'"
    dict["script"] = "pacman -Syuw"
    var = match(dict)
    assert var == True

    # Ensure that the function returns False if the error message is 
    # "error: invalid option '--'"
    dict = {}
    dict["output"] = "error: invalid option '--'"

# Generated at 2022-06-26 06:28:56.427445
# Unit test for function match
def test_match():
    dict_0 = {}
    var_0 = match(dict_0)

# Generated at 2022-06-26 06:29:05.492857
# Unit test for function match
def test_match():
    var_1 = re.sub
    var_2 = re.findall
    dict_0 = {
        "output": "error: invalid option '-a'\nSee pacman(8) for more information.\n",
        "script": "pacman -asdf"
    }
    var_3 = dict_0["output"]
    var_4 = dict_0["output"]
    var_5 = dict_0["script"]
    if var_2(r" -[dfqrstuv]", var_5):
        pass
    else:
        raise AssertionError("The function 'match' returned a wrong value")


# Generated at 2022-06-26 06:29:09.949423
# Unit test for function match
def test_match():
    # Tests that if the output of the command starts with 'error: invalid option '-' and if the command has
    # an option of pacmans options that are -[surqfdvt] and if the inputted option is any of those then it
    # will return True.
    assert match("sudo pacman -rg") == True


# Generated at 2022-06-26 06:29:11.225627
# Unit test for function match
def test_match():
    assert match(Command("pacman -k"))
    assert not match(Command("pacman"))

# Generated at 2022-06-26 06:29:12.669483
# Unit test for function match
def test_match():
    assert match(var_0)
    assert not match(var_1)


# Generated at 2022-06-26 06:29:15.955743
# Unit test for function match
def test_match():
    var_1 = "error: invalid option '-f'"
    var_2 = match(var_1)

    assert 'Revert to "sudo pacman -F"' in var_2



# Generated at 2022-06-26 06:29:19.719951
# Unit test for function match
def test_match():
    var_0 = {'script': 'pacman -q', 'stderr': 'error: invalid option "-q"', 'stdout': ''}
    var_1 = match(var_0)
    assert var_1 is False

# Generated at 2022-06-26 06:29:20.630185
# Unit test for function match
def test_match():
    assert True == match(dict_0)

# Generated at 2022-06-26 06:29:32.351480
# Unit test for function match
def test_match():
    from thefuck.rules.pacman_upper_lower_case_option import match

    script = "pacman pacman -q"
    output = "error: invalid option '-q'"

    assert match(Command(script, output))

    script = "pacman pacman -u"
    output = "error: invalid option '-u'"

    assert match(Command(script, output))

    script = "pacman pacman -f"
    output = "error: invalid option '-f'"

    assert match(Command(script, output))

    script = "pacman pacman -r"
    output = "error: invalid option '-r'"

    assert match(Command(script, output))

    script = "pacman pacman -s"
    output = "error: invalid option '-s'"

    assert match(Command(script, output))

# Generated at 2022-06-26 06:29:42.463817
# Unit test for function get_new_command
def test_get_new_command():
    dict_0 = {'_command': 'pacman -qk pkg'}
    var_0 = get_new_command(dict_0)
    if var_0 == "pacman -Qk pkg":
        pass
    else:
        raise Exception("Test case 0 failed. Expected: %s, get %s" % ("pacman -Qk pkg", var_0))

    dict_1 = {'_command': 'pacman -yupg pkg'}
    var_1 = get_new_command(dict_1)
    if var_1 == "pacman -Syu pkg":
        pass
    else:
        raise Exception("Test case 1 failed. Expected: %s, get %s" % ("pacman -Syu pkg", var_1))


# Generated at 2022-06-26 06:29:45.917548
# Unit test for function get_new_command
def test_get_new_command():
    dict_0 = {'output': 'error: invalid option -- \'q\'', 'script': 'sudo pacman -q'}
    if (get_new_command(dict_0) == 'sudo pacman -Q'):
        return True
    return False


# Generated at 2022-06-26 06:29:51.330101
# Unit test for function match
def test_match():
    var_0 = "error: invalid option '-d'"
    var_1 = re.findall(r" -[dfqrstuv]", " -d")  # line 8
    var_2 = any(" -{}".format(option) in "" for option in "surqfdvt")  # line 9
    assert (var_0 and var_1) and var_2


# Generated at 2022-06-26 06:29:52.556619
# Unit test for function get_new_command
def test_get_new_command():
    # Tested by hand
    assert True


# Generated at 2022-06-26 06:29:53.096360
# Unit test for function match
def test_match():
    assert match(test_case_0) == 'S'

# Generated at 2022-06-26 06:29:55.705059
# Unit test for function match
def test_match():
    assert match("""error: invalid option '-f'""") == True
    assert match("""error: invalid option '-q'""") == True
    assert match("""error: invalid option '-R'""") == False


# Generated at 2022-06-26 06:30:05.649769
# Unit test for function match

# Generated at 2022-06-26 06:30:15.637278
# Unit test for function match
def test_match():
    assert match.match(Command(script='pacman -Sd -y', output='error: invalid option -- d')) == False
    assert match.match(Command(script='pacman -Sdd -y', output='error: invalid option -- dd')) == False
    assert match.match(Command(script='pacman -Qdd -y', output='error: invalid option -- dd')) == False
    assert match.match(Command(script='pacman -Qdd -y', output='error: invalid option -- dd')) == False
    assert match.match(Command(script='pacman -Qdd -y', output='error: invalid option -- dd')) == False
    assert match.match(Command(script='pacman -Qdd -y', output='error: invalid option -- dd')) == False

# Generated at 2022-06-26 06:30:18.068694
# Unit test for function match
def test_match():
    print("Test case 0")
    dict_0 = {}
    assert match(dict_0) == False


# Generated at 2022-06-26 06:30:31.061040
# Unit test for function match
def test_match():
    assert match("ls") == False
    assert match("ls -al") == True
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l") == False
    assert match("ls -a -l")

# Generated at 2022-06-26 06:30:32.270196
# Unit test for function match
def test_match():
    assert match(dict_0) == True



# Generated at 2022-06-26 06:30:37.922639
# Unit test for function match
def test_match():
    command_input_0 = {}
    command_input_1 = {"output": "error: invalid option '-rd'"}

    # Call function
    output_0 = match(command_input_0)
    output_1 = match(command_input_1)

    # Check if outputs are equal
    assert output_0 == False
    assert output_1 == True



# Generated at 2022-06-26 06:30:39.634676
# Unit test for function match
def test_match():
    dict_0 = {}
    var_0 = match(dict_0)


# Generated at 2022-06-26 06:30:40.749888
# Unit test for function match
def test_match():
    assert match(dict, script) == True

# Generated at 2022-06-26 06:30:44.318540
# Unit test for function match
def test_match():
    assert not match(Command("pacman -Syu", "error: invalid option '-S'"))
    assert match(Command("pacman -Su", "error: invalid option '-S'"))
    assert match(Command("pacman -S", "error: invalid option '-S'"))


# Generated at 2022-06-26 06:30:47.971844
# Unit test for function get_new_command
def test_get_new_command():
    command = "pacman -S"
    assert get_new_command(command) == "pacman -S"



# Generated at 2022-06-26 06:30:50.015841
# Unit test for function match
def test_match():
    var_0 = {}
    var_0 = match(var_0)


# Generated at 2022-06-26 06:30:51.945193
# Unit test for function match
def test_match():
    command = "error: invalid option '-s'"
    assert match(command) == True


# Generated at 2022-06-26 06:30:52.871912
# Unit test for function match
def test_match():

    assert match(var_0)

# Generated at 2022-06-26 06:31:03.730668
# Unit test for function get_new_command
def test_get_new_command():
    dict_1 = {
        "command": "sudo pacman -S -u",
        "stderr": "",
        "script": "sudo pacman -S -u",
        "stdout": "error: invalid option '-u'\n",
        "stderr_raw": "",
        "stdout_raw": "error: invalid option '-u'\n",
    }
    var_1 = get_new_command(dict_1)
    assert var_1 == "sudo pacman -S -U"



# Generated at 2022-06-26 06:31:05.562723
# Unit test for function get_new_command
def test_get_new_command():
    dict_0 = {}
    var_0 = get_new_command(dict_0)

# Generated at 2022-06-26 06:31:12.918302
# Unit test for function match
def test_match():
    assert re.match(re.compile(r"error: invalid option '-") ,match()) # Expects a match
    assert re.match(re.compile(r"error: invalid option '-") ,match()) # Expects a match
    assert re.match(re.compile(r"error: invalid option '-") ,match()) # Expects a match
    assert re.match(re.compile(r"error: invalid option '-") ,match()) # Expects a match
    assert re.match(re.compile(r"error: invalid option '-") ,match()) # Expects a match
    assert re.match(re.compile(r"error: invalid option '-") ,match()) # Expects a match
    assert re.match(re.compile(r"error: invalid option '-") ,match()) # Expect

# Generated at 2022-06-26 06:31:18.114979
# Unit test for function match
def test_match():
    var_1 = Command("pacman -F", "error: invalid option '-F'\nTry 'pacman --help' for more information")
    var_1 = for_app("pacman", sudo_support(match))(var_1)
    assert var_1 == True


# Generated at 2022-06-26 06:31:18.970439
# Unit test for function match
def test_match():
    assert match(command) == True


# Generated at 2022-06-26 06:31:22.200406
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(" -d option ") == " -D option "
    assert get_new_command(" -s dsfsdf") == " -S dsfsdf"
    assert get_new_command(" -v dsfsdf") == " -V dsfsdf"



# Generated at 2022-06-26 06:31:30.355267
# Unit test for function match
def test_match():
    dict_0 = {'script': 'u -Syu', 'output': 'error: invalid option \'--Syu\''}
    var_0 = match(dict_0)

    dict_1 = {'script': 'u -Syu', 'output': 'error: invalid option \'--Syu\''}
    var_1 = match(dict_1)

    dict_2 = {'script': 'u -Syu', 'output': 'error: invalid option \'--Syu\''}
    var_2 = match(dict_2)


# Generated at 2022-06-26 06:31:34.345999
# Unit test for function get_new_command
def test_get_new_command():
    dict_0 = {'output': 'error: invalid option -f', 'script': 'pacman -Syu --noconfirm -f', 'stderr': ''}
    var_0 = get_new_command(dict_0)

    assert var_0 == 'pacman -Syu --noconfirm -F'

# Generated at 2022-06-26 06:31:42.396619
# Unit test for function match
def test_match():
    var_0 = match({'script':"pacman -quuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu", 'output':"error: invalid option '-'\n"})
    assert var_0 == False


# Generated at 2022-06-26 06:31:45.817545
# Unit test for function match
def test_match():
    test_output = "error: invalid option '-q'"
    command_ = {
        "script": "pacman -q",
        "output": "error: invalid option '-q'"
    }
    assert match(command_)



# Generated at 2022-06-26 06:31:53.744193
# Unit test for function match
def test_match():
    assert match(" ") != True


# Generated at 2022-06-26 06:31:56.338245
# Unit test for function match
def test_match():
    assert not match(dict_0)

# Generated at 2022-06-26 06:31:57.284893
# Unit test for function match
def test_match():
    assert match('')


# Generated at 2022-06-26 06:32:01.727497
# Unit test for function match
def test_match():
    assert match({"output": "error: invalid option '-r'"}) == True

    assert match({"output": "error: invalid option '-e'"}) == False

    assert match({"output": "error: invalid option '-u'"}) == True


# Generated at 2022-06-26 06:32:04.630101
# Unit test for function match
def test_match():
	assert match("pacman -e")
	assert match("pacman -l")
	assert match("pacman -r")


# Generated at 2022-06-26 06:32:07.593643
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="pacman -s install", output="/usr/bin/pacman: invalid option -- 's'")
    assert get_new_command(command) == "pacman -S install"

# Generated at 2022-06-26 06:32:12.203857
# Unit test for function get_new_command
def test_get_new_command():
    dict_0 = {"script":"pacman -Q",
              "output":"error: invalid option '-q'"}
    var_0 = get_new_command(dict_0)
    # expected "pacman -Q"
    var_1 = "pacman -Q"
    assert var_0 == var_1


# Generated at 2022-06-26 06:32:13.580105
# Unit test for function get_new_command
def test_get_new_command():
    dict_0 = {}
    test_case_0(dict_0)

# Generated at 2022-06-26 06:32:23.987215
# Unit test for function match

# Generated at 2022-06-26 06:32:27.873212
# Unit test for function match
def test_match():
    assert not match(Command("pacman -S", "error: invalid option '-S'\n\nTry 'pacman --help' for more information."))

    assert match(Command("pacman -y", "error: invalid option '-y'\n\nTry 'pacman --help' for more information."))


# Generated at 2022-06-26 06:32:42.798197
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command({}) == ''

# Generated at 2022-06-26 06:32:45.581195
# Unit test for function match
def test_match():
    # assert match(dict_0) == var_0
    with pytest.raises(AttributeError):
        dict_0 = match()


# Generated at 2022-06-26 06:32:52.291529
# Unit test for function match
def test_match():
    assert match("""ls -""") == False
    assert match("""ls""") == False
    assert match("""ls -ls""") == False
    assert match("""ls -d """) == False
    assert match("""ls -af""") == False
    assert match("""ls -f""") == False
    assert match("""ls -e""") == False
    assert match("""ls -f -e""") == False
    assert match("""ls -e -f""") == False
    assert match("""pacman -qqq""") == False
    assert match("""pacman -r""") == False
    assert match("""pacman -f""") == False
    assert match("""pacman -d""") == False
    assert match("""pacman -s""") == False

# Generated at 2022-06-26 06:32:54.573121
# Unit test for function match
def test_match():
    assert(match.__name__ == "match")



# Generated at 2022-06-26 06:33:01.403111
# Unit test for function match
def test_match():
    case_0 = "pacman -Syu"
    expected_0 = False
    actual_0 = match(case_0)
    assert actual_0 == expected_0

    case_1 = "error: invalid option '-S'"
    expected_1 = True
    actual_1 = match(case_1)
    assert actual_1 == expected_1

    case_2 = " "
    expected_2 = False
    actual_2 = match(case_2)
    assert actual_2 == expected_2



# Generated at 2022-06-26 06:33:06.437670
# Unit test for function match
def test_match():
    assert match(Command(script=" pacman -Ss foo", output="error: invalid option '-S'\nTry `pacman --help' for more information."))
    assert not match(Command(script=" pacman -Ss foo", output="error: invalid option '-F'\nTry `pacman --help' for more information."))


# Generated at 2022-06-26 06:33:08.697401
# Unit test for function match
def test_match():
    error_msg = "Invalid option '-'"
    dict_1 = {'output': error_msg}
    func_return = match(dict_1)

    assert func_return == True


# Generated at 2022-06-26 06:33:19.349886
# Unit test for function match
def test_match():
    var_0 = {
        "output": "error: invalid option '-v'\n"
    }
    assert not match(var_0)
    var_1 = {
        "output": "error: invalid option '-v'\n",
        "script": "pacman -Syuf"
    }
    assert match(var_1)
    var_2 = {
        "output": "error: invalid option '-v'\n",
        "script": "pacman -Suufr"
    }
    assert match(var_2)
    var_3 = {
        "output": "error: invalid option '-f'\n",
        "script": "pacman -Suufr -f"
    }
    assert match(var_3)


# Generated at 2022-06-26 06:33:20.265991
# Unit test for function match
def test_match():
    assert match('') == False


# Generated at 2022-06-26 06:33:23.482094
# Unit test for function match
def test_match():
    str_0 = "error: invalid option '-s'"
    dict_0 = {'output': str_0, 'script': "pacman -s", 'stdout': '', 'stderr': ''}
    var_0 = match(dict_0)
    assert var_0

# Generated at 2022-06-26 06:33:53.886048
# Unit test for function match
def test_match():
    dict_0 = {}
    assert(match(dict_0) == None)



# Generated at 2022-06-26 06:33:55.765394
# Unit test for function match
def test_match():
    command = Command('pacman -Rsc xyz', '')
    assert match(command)



# Generated at 2022-06-26 06:33:58.001903
# Unit test for function match
def test_match():
    assert match("pacman -i -u -v --noconfirm whatever")


# Generated at 2022-06-26 06:33:58.856806
# Unit test for function match
def test_match():
    test_case_0()



# Generated at 2022-06-26 06:34:01.257978
# Unit test for function match
def test_match():
    # mock command
    command = Mock(script='pacman -Suy', output="error: invalid option '-S'")
    var_0 = match(command)
    assert var_0 == True


# Generated at 2022-06-26 06:34:07.106123
# Unit test for function match

# Generated at 2022-06-26 06:34:09.066495
# Unit test for function get_new_command
def test_get_new_command():
    dict_0 = {}
    var_0 = get_new_command(dict_0)
    pass



# Generated at 2022-06-26 06:34:16.691701
# Unit test for function match
def test_match():
    dict_0 = {}
    dict_1 = {}
    dict_0['script'] = 'paCMa -f aa'
    dict_0['output'] = 'error: invalid option -- f'
    dict_1['script'] = 'paCMa -f aa'
    dict_1['output'] = 'error: invalid option -- f'
    dict_0['output'] = dict_0['output'].lower()
    dict_1['output'] = dict_1['output'].lower()
    var_0 = match(dict_0)
    var_1 = match(dict_1)
    var_2 = get_new_command(dict_0)
    assert var_0 == var_1
    assert var_0 == True
    assert var_1 == True

# Generated at 2022-06-26 06:34:18.807990
# Unit test for function match
def test_match():
    var_1 = "error: invalid option '-f'"
    var_2 = match(var_1)
    assert var_2 == True


# Generated at 2022-06-26 06:34:21.381693
# Unit test for function match
def test_match():
    assert match(Command("pacman -qsf"))
    assert not match(Command("pacman -Syy"))

# Generated at 2022-06-26 06:35:31.169836
# Unit test for function match
def test_match():
    # class Script:
    #     def __init__(self, output, script):
    #         self.output = output
    #         self.script = script
    script = Script(output='error: invalid option -s', script='pacman -s')
    assert match(script)

    script = Script(output='error: invalid option -u', script='pacman -u')
    assert match(script)

    script = Script(output='error: invalid option -r', script='pacman -r')
    assert match(script)

    script = Script(output='error: invalid option -s', script='pacman -s')
    assert match(script)

    script = Script(output='error: invalid option -q', script='pacman -q')
    assert match(script)


# Generated at 2022-06-26 06:35:33.551036
# Unit test for function match
def test_match():
    assert match(Command("pacman -Q sudo", "", None))
    assert match(Command("pacman -h -Syu", "", None))


# Generated at 2022-06-26 06:35:34.386440
# Unit test for function get_new_command
def test_get_new_command():
    assert var_0 == "pacman -Su"

# Generated at 2022-06-26 06:35:41.430092
# Unit test for function get_new_command
def test_get_new_command():
	var_1 = match("pacman -Rdd")
	assert ( var_1.output == "error: invalid option '-d'")
	var_2 = get_new_command(var_1)
	assert ( var_2 == "pacman -RDD")
	var_3 = match("pacman -Sf")
	assert ( var_3.output == "error: invalid option '-f'")
	var_4 = get_new_command(var_3)
	assert ( var_4 == "pacman -SF")
	var_5 = match("pacman -Sq")
	assert ( var_5.output == "error: invalid option '-q'")
	var_6 = get_new_command(var_5)
	assert ( var_6 == "pacman -SQ")

# Generated at 2022-06-26 06:35:43.335913
# Unit test for function match
def test_match():
    assert match(dict_0) == True


# Generated at 2022-06-26 06:35:53.575011
# Unit test for function get_new_command
def test_get_new_command():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_

# Generated at 2022-06-26 06:35:55.441651
# Unit test for function match
def test_match():
    res = match(var_0)
    assert isinstance(res, bool)



# Generated at 2022-06-26 06:36:06.599486
# Unit test for function match
def test_match():
    var_0 = Command("pacman -Se jre8-openjdk-headless", "error: invalid option '-S'")
    var_1 = match(var_0)
    var_2 = Command("pacman -e jre8-openjdk-headless", "error: invalid option '-e'")
    var_3 = match(var_2)
    var_4 = Command("pacman -u jre8-openjdk-headless", "error: invalid option '-u'")
    var_5 = match(var_4)
    var_6 = Command("pacman -r jre8-openjdk-headless", "error: invalid option '-r'")
    var_7 = match(var_6)

# Generated at 2022-06-26 06:36:08.903880
# Unit test for function match
def test_match():
    param_0 = "gksu ls  -l"
    unit_test_0 = match(param_0)
    assert unit_test_0 == False


# Generated at 2022-06-26 06:36:10.548568
# Unit test for function match
def test_match():
    # Test of match function
    dict_0 = {}
    var_0 = match(dict_0)


# Generated at 2022-06-26 06:38:18.814720
# Unit test for function get_new_command
def test_get_new_command():

    # fail: get_new_command("pacman -S packagename")
    test_case_0()
    
    return


# Generated at 2022-06-26 06:38:24.667882
# Unit test for function match
def test_match():
    assert re.findall(r" -[dfqrstuv]", " -s")
    assert match(command=Test(script='pacman -s', output='error: invalid option -- \'s\'').script)
    assert match(command=Test(script='pacman -r', output='error: invalid option -- \'r\'').script)
    assert match(command=Test(script='pacman -t', output='error: invalid option -- \'t\'').script)

# Generated at 2022-06-26 06:38:25.625536
# Unit test for function match
def test_match():
    test_case_0()


# Generated at 2022-06-26 06:38:35.134083
# Unit test for function match
def test_match():
    # Test case 0

    # Test case 1
    dict_1 = {}
    var_0 = match(dict_1)
    assert var_0 == False

    # Test case 2
    dict_2 = {}
    var_0 = match(dict_2)
    assert var_0 == False

    # Test case 3
    dict_3 = {}
    var_0 = match(dict_3)
    assert var_0 == False

    # Test case 4
    dict_4 = {}
    var_0 = match(dict_4)
    assert var_0 == False

    # Test case 5
    dict_5 = {}
    var_0 = match(dict_5)
    assert var_0 == False

    # Test case 6
    dict_6 = {}
    var_0 = match(dict_6)
    assert var

# Generated at 2022-06-26 06:38:41.282195
# Unit test for function match
def test_match():
    assert match(Command("yay -qj", "error: invalid option '-q'")) == True
    assert match(Command("yay -aj", "error: invalid option '-a'")) == True
    assert match(Command("yay -tj", "error: invalid option '-t'")) == True
    assert match(Command("yay -uj", "error: invalid option '-u'")) == True
    assert match(Command("yay -fj", "error: invalid option '-f'")) == True
    assert match(Command("yay -rj", "error: invalid option '-r'")) == True
    assert match(Command("yay -vj", "error: invalid option '-v'")) == True
    assert match(Command("yay -sj", "error: invalid option '-s'")) == True
   

# Generated at 2022-06-26 06:38:47.512549
# Unit test for function match