

# Generated at 2022-06-12 12:01:16.938206
# Unit test for function match
def test_match():
    command = Command("pacman -Syu")

    assert(match(command) == True)

    command = Command("pacman -y")

    assert(match(command) == False)


# Generated at 2022-06-12 12:01:19.166110
# Unit test for function get_new_command
def test_get_new_command():
    script = "pacman -q"
    assert get_new_command(Command(script)) == "pacman -Q"

# Generated at 2022-06-12 12:01:20.744214
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("yaourt -S vlc", "")) == "yaourt -S VLC"

# Generated at 2022-06-12 12:01:22.839520
# Unit test for function match
def test_match():
    assert match(Command("pacman -S firefox -s", "error: invalid option 's'\n"))
    assert not match(Command("firefox"))


# Generated at 2022-06-12 12:01:26.878146
# Unit test for function get_new_command
def test_get_new_command():
    assert (
        get_new_command(Command("sudo pacman -Su --noconfirm", "", ""))
        == "sudo pacman -SU --noconfirm"
    )
    assert (
        get_new_command(Command("sudo pacman -Syuq grep --noconfirm", "", ""))
        == "sudo pacman -SUq grep --noconfirm"
    )

# Generated at 2022-06-12 12:01:32.475409
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('pacman -S', '')) == 'pacman -S'
    assert get_new_command(Command('pacman -s', '')) == 'pacman -S'
    assert get_new_command(Command('pacman -d', '')) == 'pacman -D'
    assert get_new_command(Command('pacman -f', '')) == 'pacman -F'
    assert get_new_command(Command('pacman -q', '')) == 'pacman -Q'
    assert get_new_command(Command('pacman -r', '')) == 'pacman -R'
    assert get_new_command(Command('pacman -t', '')) == 'pacman -T'

# Generated at 2022-06-12 12:01:33.805575
# Unit test for function match
def test_match():
    assert match(Command("pacman -S foobar"))



# Generated at 2022-06-12 12:01:37.911293
# Unit test for function match
def test_match():
    assert match(Command("pacman -Si", "error: invalid option '-S'\n"))
    assert match(Command("pacman -Y", "error: invalid option '-Y'\n"))
    assert not match(Command("pacman -Y", "error: invalid option 'Y'\n"))


# Generated at 2022-06-12 12:01:39.654844
# Unit test for function match
def test_match():
    assert match(Command('pacman -qd', ''))
    assert not match(Command('pacman -Qd', ''))

# Generated at 2022-06-12 12:01:42.340958
# Unit test for function match
def test_match():
    assert match(Command("pacman -Sj firefox", "error: invalid option '-j'\n"))
    assert not match(Command("pacman -S firefox", "nodejs is up to date\n"))

# Generated at 2022-06-12 12:01:52.970237
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="sudo pacman -Qdt", output="error: invalid option '-d'")) == "sudo pacman -QDT"
    assert get_new_command(Command(script="sudo pacman -Qs hello", output="error: invalid option '-s'")) == "sudo pacman -QS hello"
    assert get_new_command(Command(script="sudo pacman -Qsu", output="error: invalid option '-s'")) == "sudo pacman -QSu"
    assert get_new_command(Command(script="sudo pacman -Qqt", output="error: invalid option '-q'")) == "sudo pacman -QQt"

# Generated at 2022-06-12 12:01:55.956804
# Unit test for function match
def test_match():
    assert match(Command('pacman -Su', 'error: invalid option -- \'u\'\nSee pacman(8) for help and examples.'))
    assert not match(Command('pacman -Du', 'error: invalid option -- \'u\'\nSee pacman(8) for help and examples.'))



# Generated at 2022-06-12 12:01:59.151616
# Unit test for function match
def test_match():
    assert match(Command('pacman -sru', '', error='error: '
                                                  'invalid option '
                                                  '\'-s\'\nSee \'pacman --help\' for more information.'))


# Generated at 2022-06-12 12:02:08.954130
# Unit test for function match
def test_match():
	def run_match(command, script, output):
		assert match(Command(script=script, output=output))

	run_match(command=None, script="pacman -S -q --noconfirm dotnet2-runtime", output="error: invalid option '-q'")
	run_match(command=None, script="pacman -S -d -u --noconfirm dotnet2-runtime", output="error: invalid option '-d'")
	run_match(command=None, script="pacman -S -u -f --noconfirm dotnet2-runtime", output="error: invalid option '-f'")
	run_match(command=None, script="pacman -S -u --asdeps -u --noconfirm dotnet2-runtime", output="error: invalid option '-u'")


# Generated at 2022-06-12 12:02:13.675442
# Unit test for function match
def test_match():
    # test default case
    assert match(Command('pacman -Rdd python'))
    assert match(Command('pacmam -Rdd python3'))
    assert match(Command('pacmam -R python2'))
    assert match(Command('pacma -Rdd python2'))
    assert not match(Command('pacman -Rddd python2'))


# Generated at 2022-06-12 12:02:16.642999
# Unit test for function match
def test_match():
    assert match(Command("pacman -q", "error: invalid option '-q'"))
    assert match(Command("pacman -u", "error: invalid option '-u'"))

# Generated at 2022-06-12 12:02:25.102528
# Unit test for function match

# Generated at 2022-06-12 12:02:29.314162
# Unit test for function match
def test_match():
    assert match(Command("sudo pacman -Syyu", "error: invalid option -y"))
    assert not match(Command("pacman -Syyu", "error: invalid option -y"))
    assert not match(Command("pacman -Syyu", "error: invalid option --y"))



# Generated at 2022-06-12 12:02:36.243203
# Unit test for function match
def test_match():
	assert match(Command('pacman -u', 
		'error: invalid option -- \'u\''))
	assert match(Command('pacman -s', 
		'error: invalid option -- \'s\''))
	assert match(Command('pacman -r', 
		'error: invalid option -- \'r\''))
	assert match(Command('pacman -q', 
		'error: invalid option -- \'q\''))
	assert match(Command('pacman -d', 
		'error: invalid option -- \'d\''))
	assert match(Command('pacman -f', 
		'error: invalid option -- \'f\''))
	assert match(Command('pacman -v', 
		'error: invalid option -- \'v\''))

# Generated at 2022-06-12 12:02:43.188425
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="sudo pacman -S", output="error: invalid option '-S'")) == "sudo pacman -S"
    assert get_new_command(Command(script="sudo pacman -s", output="error: invalid option '-s'")) == "sudo pacman -S"
    assert get_new_command(Command(script="sudo pacman -u", output="error: invalid option '-u'")) == "sudo pacman -U"

# Generated at 2022-06-12 12:02:53.245946
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('pacman -S git', 'pacman -S: error: invalid option -- S')) == 'pacman -S git'
    assert get_new_command(Command('pacman -q git', 'pacman -q: error: invalid option -- q')) == 'pacman -Q git'
    assert get_new_command(Command('pacman -r git', 'pacman -r: error: invalid option -- r')) == 'pacman -R git'
    assert get_new_command(Command('pacman -s git', 'pacman -s: error: invalid option -- s')) == 'pacman -S git'
    assert get_new_command(Command('pacman -t git', 'pacman -t: error: invalid option -- t')) == 'pacman -T git'
    assert get_

# Generated at 2022-06-12 12:03:02.205981
# Unit test for function match
def test_match():
    assert match(Command('pacman -Syu', 'error: invalid option -- \'y\''))
    assert match(Command('pacman -Syu', 'error: invalid option -- \'u\''))
    assert match(Command('pacman -Syu', 'error: invalid option -- \'f\''))
    assert match(Command('pacman -Syu', 'error: invalid option -- \'r\''))
    assert match(Command('pacman -Syu', 'error: invalid option -- \'d\''))
    assert match(Command('pacman -Syu', 'error: invalid option -- \'q\''))
    assert match(Command('pacman -Syu', 'error: invalid option -- \'v\''))
    assert match(Command('pacman -Syu', 'error: invalid option -- \'t\''))

# Generated at 2022-06-12 12:03:04.226443
# Unit test for function get_new_command
def test_get_new_command():
    assert (
        get_new_command(Command("pacman -qddl", None))
        == "pacman -Qddl"
    )

# Generated at 2022-06-12 12:03:07.750307
# Unit test for function match
def test_match():
    assert match(Command('pacman -s firefox-esr'))
    assert match(Command('pacman -s -u firefox-esr'))
    assert match(Command('pacman -s -u -f -f -f firefox-esr'))



# Generated at 2022-06-12 12:03:17.492482
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("pacman -u", "error: invalid option 'u'")) == "pacman -U"
    assert get_new_command(Command("pacman -s", "error: invalid option 's'")) == "pacman -S"
    assert get_new_command(Command("pacman -q", "error: invalid option 'q'")) == "pacman -Q"
    assert get_new_command(Command("pacman -f", "error: invalid option 'f'")) == "pacman -F"
    assert get_new_command(Command("pacman -d", "error: invalid option 'd'")) == "pacman -D"
    assert get_new_command(Command("pacman -v", "error: invalid option 'v'")) == "pacman -V"
    assert get_new_command

# Generated at 2022-06-12 12:03:21.057384
# Unit test for function get_new_command
def test_get_new_command():
    output = "error: invalid option '-f'"
    script = "pacman -Syuu -sf"
    command = Command(script, output)
    assert re.findall(r" -[dfqrstuv]", get_new_command(command)) == [" -F"]

# Generated at 2022-06-12 12:03:23.117319
# Unit test for function match
def test_match():
    assert match(Command("pacman -q", "error: invalid option '-q'"))
    assert not match(Command("pacman -Q", "error: invalid option '-q'"))

# Generated at 2022-06-12 12:03:25.041513
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("pacman -s netctl",
                                   "error: invalid option '-s'\n")) == "pacman -S netctl"

# Generated at 2022-06-12 12:03:29.772057
# Unit test for function match
def test_match():
    assert match(Command("pacman -Syu", output="error: invalid option '-Syu'"))
    assert match(Command("pacman -Sy", output="error: invalid option '-Syu'"))
    assert match(Command("pacman -Syyu", output="error: invalid option '-Syu'"))
    assert match(Command("pacman -Syyu", output="error: invalid option '-Su'"))
    assert match(Command("pacman -Syyu", output="error: invalid option '-yu'"))


# Generated at 2022-06-12 12:03:36.659120
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("pacman -sw git", "error: invalid option '-sw'\n")
    assert get_new_command(command) == "pacman -Sw git"

    command = Command("pacman -rsw git", "error: invalid option '-rsw'\n")
    assert get_new_command(command) == "pacman -Rsw git"

    command = Command("pacman -v", "error: invalid option '-v'\n")
    assert get_new_command(command) == "pacman -V"

# Generated at 2022-06-12 12:03:45.250010
# Unit test for function match
def test_match():
    command = Command(script='pacman -Rsnu spotify',
                      output='error: invalid option "-s".')
    assert(match(command))



# Generated at 2022-06-12 12:03:48.411397
# Unit test for function get_new_command
def test_get_new_command():
    script = "sudo pacman -S lol"
    command = Command(script, "error: invalid option '-S'\n" +
        "error: target not found: lol\n")
    assert get_new_command(command) == "sudo pacman -RS lol"
    assert get_new_command(command) == "sudo pacman -RS lol"

# Generated at 2022-06-12 12:03:50.715813
# Unit test for function match
def test_match():
    """
       Unit test for function match
    """
    assert match("$ sudo pacman -Suy")
    assert match("$ sudo pacman -Suy")
    assert match("$ sudo pacman -Suy")


# Generated at 2022-06-12 12:03:51.725344
# Unit test for function match
def test_match():
    command = Command("sudo pacman -d", "")
    assert match(command)



# Generated at 2022-06-12 12:03:54.294628
# Unit test for function get_new_command
def test_get_new_command():
    script = "pacman -y"
    command = Command(script, "error: invalid option '-y'")
    assert get_new_command(command) == "pacman -Y"

# Generated at 2022-06-12 12:04:02.237335
# Unit test for function match
def test_match():
    assert match(Command('pacman -fq',
                         'error: invalid option -- f\n'
                         'error: invalid option -- q\n'
                         'Try \'pacman --help\' for more information.'))
    assert match(Command('pacman -uq',
                         'error: invalid option -- u\n'
                         'error: invalid option -- q\n'
                         'Try \'pacman --help\' for more information.'))

# Generated at 2022-06-12 12:04:03.690380
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("pacman -S", "error: invalid option '-S'")) == "pacman -S"



# Generated at 2022-06-12 12:04:11.592089
# Unit test for function match
def test_match():
    assert match(Command('pacman -q', 'error: invalid option -q'))
    assert match(Command('pacman -S', 'error: invalid option -S'))
    assert match(Command('pacman -u', 'error: invalid option -u'))
    assert match(Command('pacman -r', 'error: invalid option -r'))
    assert match(Command('pacman -t', 'error: invalid option -t'))
    assert match(Command('pacman -f', 'error: invalid option -f'))
    assert match(Command('pacman -v', 'error: invalid option -v'))
    assert match(Command('pacman -d', 'error: invalid option -d'))
    assert not match(Command('pacman -s', 'error: invalid option -s'))

# Generated at 2022-06-12 12:04:19.983026
# Unit test for function match
def test_match():
    # Matching a command with an invalid option
    assert(match(Command("pacman -Qqdt", "error: invalid option '-q'")) != None)
    # Matching a command with an invalid option (different case)
    assert(match(Command("pacman -qd", "error: invalid option '-q'")) != None)
    # Matching a command with an invalid option (in the middle)
    assert(match(Command("pacman -Qdqdt", "error: invalid option '-q'")) != None)
    # Matching a command with an invalid option (in the middle, different case)
    assert(match(Command("pacman -qdt", "error: invalid option '-q'")) != None)
    # Not matching a command without an invalid option
    assert(match(Command("pacman -foo")) == None)
   

# Generated at 2022-06-12 12:04:29.888820
# Unit test for function match
def test_match():
    assert match(Command('pacman -Suy foo', 'error: invalid option \'--sync\'\nTry `pacman --help\' for more information.\n', '', 1))
    assert match(Command('pacman -Suy foo', 'error: invalid option \'--refresh\'\nTry `pacman --help\' for more information.\n', '', 1))
    assert not match(Command('pacman -Suy foo', 'error: invalid option \'--refresh\'\nTry `pacman --help\' for more information.\n', '', 1))
    assert not match(Command('pacman -Suy foo', 'error: invalid option \'--confirm\'\nTry `pacman --help\' for more information.\n', '', 1))

# Generated at 2022-06-12 12:04:48.250578
# Unit test for function match
def test_match():
    command = "pacman -Sas --config /etc/pacman.conf"
    assert match(command) is not None
    assert match(Command(script=command, output="error: invalid option '--config'"))
    assert match(Command(script=command, output="error: invalid option '-s'"))
    assert match(Command(script=command, output="error: invalid option '-a'"))
    assert match(Command(script=command, output="error: invalid option '-q'"))
    assert match(Command(script=command, output="error: invalid option '-f'"))
    assert match(Command(script=command, output="error: invalid option '-u'"))
    assert match(Command(script=command, output="error: invalid option '-v'"))

# Generated at 2022-06-12 12:04:50.210422
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("sudo pacman -q")) == "sudo pacman -Q"

# Generated at 2022-06-12 12:04:59.219106
# Unit test for function match
def test_match():
    assert match(Command('pacman -s foo'))
    assert match(Command('pacman -s foo', ''))
    assert match(Command('pacman -s foo', '', ''))
    assert match(Command('pacman -surq foo'))
    assert match(Command('pacman -surq foo', ''))
    assert match(Command('pacman -surq foo', '', ''))
    assert match(Command('pacman -surqd foo'))
    assert match(Command('pacman -surqd foo', ''))
    assert match(Command('pacman -surqd foo', '', ''))
    assert not match(Command('pacman -Qu bar'))
    assert not match(Command('pacman -Qu bar', ''))
    assert not match(Command('pacman -Qu bar', '', ''))

# Generated at 2022-06-12 12:05:01.203113
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("pacman -s", output="error: invalid option '-s'")
    assert get_new_command(command).script == "pacman -S"

# Generated at 2022-06-12 12:05:05.572073
# Unit test for function match
def test_match():
    assert match(Command('pacman -Ss thefuck', 'error: invalid option \'-S\'\n',
                         '', 'pacman', 'pacman', 1, None))
    assert not match(Command('pacman -v', '', '', 'pacman', 'pacman', 1, None))



# Generated at 2022-06-12 12:05:10.696894
# Unit test for function match
def test_match():
    assert match(Command("pacman -S", ""))
    assert match(Command("pacman -Syu", ""))
    assert not match(Command("pacman -S extra/wget", ""))
    assert not match(Command("pacman -Syu", ""))
    assert not match(Command("pacman -Su", ""))
    assert not match(Command("pacman", ""))

# Generated at 2022-06-12 12:05:12.370104
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command ("sudo pacman -Ss firefox") == "sudo pacman -SS firefox"

# Generated at 2022-06-12 12:05:17.031885
# Unit test for function match
def test_match():
    assert match(Command('pacman -Syyuu', '', 'error: invalid option -y'))
    assert match(Command('pacman -Syyuu', '', 'error: invalid option -u'))
    assert match(Command('pacman -Syyuu', '', 'error: invalid option -s'))
    assert not match(Command('pacman -Syyuu', ''))


# Generated at 2022-06-12 12:05:26.596822
# Unit test for function match
def test_match():
    assert (
        match(Command("sudo pacman -Ss linux", "error: invalid option '-s'"))
        is True
    )
    assert (
        match(Command("sudo pacman -Q linux", "error: invalid option '-Q'"))
        is True
    )
    assert match(Command("sudo pacman -u linux", "error: invalid option '-u'")) is True
    assert match(Command("sudo pacman -r linux", "error: invalid option '-r'")) is True
    assert match(Command("sudo pacman -f linux", "error: invalid option '-f'")) is True
    assert match(Command("sudo pacman -d linux", "error: invalid option '-d'")) is True
    assert match(Command("sudo pacman -v linux", "error: invalid option '-v'")) is True


# Generated at 2022-06-12 12:05:28.314349
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("pacman -a -s") == "pacman -a -S"

# Generated at 2022-06-12 12:05:50.223079
# Unit test for function match
def test_match():
    assert match(Command("pacman -u", "error: invalid option '-u'\n"))
    assert match(Command("pacman  -u", "error: invalid option '-u'\n"))
    assert match(Command("pacman -u -f", "error: invalid option '-u'\n"))
    assert match(Command("pacman -i -u -f", "error: invalid option '-i'\n"))
    assert not match(Command("pacman -q", "error: invalid option '-q'\n"))
    assert not match(Command("pacman -h", "error: invalid option '-h'\n"))
    assert not match(
        Command("pacman -u", "error: invalid option '-u'\n", "error: foo bar")
    )

# Generated at 2022-06-12 12:05:53.637862
# Unit test for function match
def test_match():
    assert match(Command("pacman -s git", "error: invalid option '-s'"))
    assert match(Command("pacman -u -s git", "error: invalid option '-u'"))
    assert not match(Command("pacman -f git", "error: invalid option '-f'"))



# Generated at 2022-06-12 12:06:00.780396
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('pacman -s foo', 'error: invalid option \'-s\'\n')) == 'pacman -S foo'
    assert get_new_command(Command('pacman -d foo', 'error: invalid option \'-d\'\n')) == 'pacman -D foo'
    assert get_new_command(Command('pacman -f foo', 'error: invalid option \'-f\'\n')) == 'pacman -F foo'
    assert get_new_command(Command('pacman -q foo', 'error: invalid option \'-q\'\n')) == 'pacman -Q foo'
    assert get_new_command(Command('pacman -r foo', 'error: invalid option \'-r\'\n')) == 'pacman -R foo'

# Generated at 2022-06-12 12:06:10.526783
# Unit test for function match
def test_match():
    assert match(Command("sudo pacman -Syu --quiet",
                         "error: invalid option '-q'\n"))
    assert match(Command("sudo pacman -Syu --verbose",
                         "error: invalid option '-v'\n"))
    assert match(Command("sudo pacman -Syu --no-confirm",
                         "error: invalid option '-y'\n"))
    assert match(Command("sudo pacman -Syu --noconfirm",
                         "error: invalid option '-y'\n"))
    assert not match(Command("sudo pacman -Syu",
                             "error: invalid option '-y'\n"))
    assert not match(Command("apt-get install -qy",
                             "error: invalid option '-q'\n"))


# Generated at 2022-06-12 12:06:18.438921
# Unit test for function match
def test_match():
    assert match(Command(script="pacman -ssw"))
    assert match(Command(script="pacman -u"))
    assert match(Command(script="pacman -r x"))
    assert match(Command(script="pacman -d"))
    assert match(Command(script="pacman -f"))
    assert match(Command(script="pacman -q"))
    assert match(Command(script="pacman -t"))
    assert match(Command(script="pacman -v"))

    assert match(Command(script="pacman -Ss"))
    assert match(Command(script="sudo pacman -Ss"))
    assert match(Command(script="sudo pacman -Ss", use_sudo=True))

    assert not match(Command(script="pacman -Ss"))
    assert not match(Command(script="pacman -Ss"))


# Generated at 2022-06-12 12:06:22.028473
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="sudo pacman -Syu", output="error: invalid option '-y'")) == "sudo pacman -Syu"
    assert get_new_command(Command(script="pacman -Syu", output="error: invalid option '-y'")) == "pacman -Syu"

# Generated at 2022-06-12 12:06:28.824781
# Unit test for function match
def test_match():
    assert match(Command("pacman -d -t"))
    assert match(Command("pacman -q -r"))
    assert not match(Command("pacman -u"))
    assert not match(Command("pacman -S"))
    assert not match(Command("pacman -Q"))
    assert not match(Command("pacman -V"))
    assert not match(Command("pacman -F"))
    assert not match(Command("pacman -t"))
    assert not match(Command("pacman -v"))
    assert not match(Command("pacman -f"))

# Each of these strings is the output of a line entered in the terminal
# The output of these strings should be the two-letter combinations
# of the following strings:
# D
# F
# Q
# R
# S
# T
# U
# V
#
# r,

# Generated at 2022-06-12 12:06:35.836936
# Unit test for function match
def test_match():
    assert match(Command('pacman -q', ''))
    assert match(Command('pacman -d', ''))
    assert match(Command('pacman -f', ''))
    assert match(Command('pacman -s', ''))
    assert match(Command('pacman -u', ''))
    assert match(Command('pacman -v', ''))
    assert match(Command('pacman -r', ''))
    assert match(Command('pacman -t', ''))
    assert match(Command('pacman --query', ''))
    assert match(Command('pacman --download', ''))
    assert match(Command('pacman --files', ''))
    assert match(Command('pacman --search', ''))
    assert match(Command('pacman --sync', ''))
    assert match(Command('pacman --upgrade', ''))

# Generated at 2022-06-12 12:06:41.789477
# Unit test for function match
def test_match():
    script = "sudo pacman -Sy"
    assert not match(Command(script))

    script = "sudo pacman -Syu"
    assert not match(Command(script))

    script = "sudo pacman -qy"
    assert match(Command(script))

    script = "pacman -qy"
    assert match(Command(script))



# Generated at 2022-06-12 12:06:50.124274
# Unit test for function match
def test_match():
    assert match(Command("pacman -Qqemtt > pkglist",
                         "error: invalid option '-t'")).script == "pacman -Qqemtt > pkglist"
    assert match(Command("pacman -Qqemtt > pkglist",
                         "error: invalid option '-r'")).script == "pacman -Qqemtt > pkglist"
    assert match(Command("pacman -Qqemtt > pkglist",
                         "error: invalid option '-f'")).script == "pacman -Qqemtt > pkglist"
    assert not match(Command("pacman -Qqemtt > pkglist",
                              "error: another option '-r'")).script == "pacman -Qqemtt > pkglist"

# Generated at 2022-06-12 12:07:26.406044
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("sudo pacman -R pkg1")) == "sudo pacman -R pkg1"
    assert get_new_command(Command("sudo pacman -r pkg1")) == "sudo pacman -R pkg1"
    assert get_new_command(Command("sudo pacman -u pkg1")) == "sudo pacman -U pkg1"
    assert get_new_command(Command("sudo pacman -q pkg1")) == "sudo pacman -Q pkg1"
    assert get_new_command(Command("sudo pacman -s pkg1")) == "sudo pacman -S pkg1"
    assert get_new_command(Command("sudo pacman -v pkg1")) == "sudo pacman -V pkg1"

# Generated at 2022-06-12 12:07:30.134462
# Unit test for function match
def test_match():
    assert match(Command("pacman -Suy", "")) is True
    assert match(Command("pacman -Suy", "error: invalid option '-y'\n")
                  ) is True
    assert match(Command("pacman -Suy", "error: invalid option '-y'\n", "")) is True
    assert match(Command("yaourt -Suy", "error: invalid option '-y'\n", "")) is False



# Generated at 2022-06-12 12:07:36.835220
# Unit test for function match
def test_match():
    assert (
        match(
            Command(
                script="pacman -syyu",
                output="error: invalid option '-y'\n\nUsage: pacman "
                "[options]",
            )
        )
        is True
    )
    assert (
        match(
            Command(
                script="pacman -suyu",
                output="error: invalid option '-u'\n\nUsage: pacman "
                "[options]",
            )
        )
        is True
    )
    assert (
        match(
            Command(
                script="pacman -sfdt",
                output="error: invalid option '-f'\n\nUsage: pacman "
                "[options]",
            )
        )
        is True
    )

# Generated at 2022-06-12 12:07:44.360475
# Unit test for function match
def test_match():
    assert match(Command(script="pacman -f -d"))
    assert match(Command(script="pacman -q -r"))
    assert match(Command(script="pacman -r -q"))
    assert match(Command(script="pacman -f -d -z"))
    assert match(Command(script="pacman -q -d -z"))
    assert match(Command(script="pacman -q -d -z -f"))
    assert match(Command(script="pacman -u -d -z -f"))
    assert match(Command(script="pacman -t -d -z -f"))
    assert match(Command(script="pacman -q -d -z -f"))
    assert match(Command(script="pacman -r -q -r -r"))

# Generated at 2022-06-12 12:07:49.356088
# Unit test for function match
def test_match():
    assert match(Command('pacman -qf firefox', 'error: invalid option \'-f\''))
    assert match(Command('pacman -x -u firefox', 'error: invalid option \'-x\''))
    assert not match(Command('pacman -y -u firefox', 'error: invalid option \'-y\''))


# Generated at 2022-06-12 12:07:51.253805
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('pacman -Su') == 'pacman -SU'
    assert get_new_command('pacman -u') == 'pacman -U'

# Generated at 2022-06-12 12:07:53.222542
# Unit test for function match
def test_match():
    assert match(Command(
        script='pacman -s',
        output='error: invalid option -- \'s\''
    ))


# Generated at 2022-06-12 12:07:58.151821
# Unit test for function match
def test_match():
    assert match(Command("pacman -q"))
    assert match(Command("pacman -s"))
    assert match(Command("pacman -r"))
    assert match(Command("pacman -f"))
    assert match(Command("pacman -d"))
    assert match(Command("pacman -v"))
    assert match(Command("pacman -t"))
    assert match(Command("pacman --sync"))
    assert not match(Command("pacman -S"))
    assert not match(Command("pacman -u"))
    assert not match(Command("pacman -U"))
    assert not match(Command("pacman -R"))
    assert not match(Command("pacman -F"))
    assert not match(Command("pacman -D"))
    assert not match(Command("pacman -V"))
    assert not match(Command("pacman -T"))

# Generated at 2022-06-12 12:08:00.560195
# Unit test for function match
def test_match():
    assert match(Command("pacman -Qi"))
    assert not match(Command("pacman -Q"))
    assert not match(Command("apt-get install"))



# Generated at 2022-06-12 12:08:03.789976
# Unit test for function match
def test_match():
    assert match(Command('pacman -Surq', 'error: invalid option \'-q\'.'))
    assert not match(Command('pacman', ''))

# Generated at 2022-06-12 12:09:07.326881
# Unit test for function match
def test_match():
    assert match(Command("pacman -s"))
    assert match(Command("pacman -sus"))
    assert match(Command("pacman -s q"))
    assert match(Command("pacman -s -q"))
    assert not match(Command("pacman -S"))
    assert not match(Command("pacman -Sync"))
    assert not match(Command("pacman -S qwerty"))
    assert not match(Command("pacman -Sqwerty"))


# Generated at 2022-06-12 12:09:12.327957
# Unit test for function match
def test_match():
    assert match(Command("pacman -Rkk mariadb", "error: invalid option -k"))
    assert not match(Command("pacman -R", "error: invalid option -k"))
    assert not match(Command("pacman -Rkk mariadb", "pacman -Rkk mariadb"))


# Generated at 2022-06-12 12:09:16.530797
# Unit test for function match
def test_match():
    assert match(Command("sudo pacman -Suq", "", "", "", 0, ""))
    assert match(Command("pacman -Suq", "", "", "", 0, ""))
    assert not match(Command("pacman -Suq", "", "", "", 0, ""))



# Generated at 2022-06-12 12:09:24.637507
# Unit test for function match
def test_match():
    output1 = "error: invalid option '-q'; use --help to show usage"
    output2 = "error: invalid option '-f'"
    output3 = "error: invalid option '-r'"
    output4 = "error: invalid option '-s'"
    output5 = "error: invalid option '-u'"
    output6 = "error: invalid option '-v'"
    output7 = "error: invalid option '-d'"
    output8 = "error: invalid option '-t'"

    assert match(Command("$ pacman -q", output1))
    assert match(Command("$ pacman -f", output2))
    assert match(Command("$ pacman -r", output3))
    assert match(Command("$ pacman -s", output4))
    assert match(Command("$ pacman -u", output5))


# Generated at 2022-06-12 12:09:26.054802
# Unit test for function match
def test_match():
    command = "pacman -Ss linux"
    assert match(Command(command, "", ""))



# Generated at 2022-06-12 12:09:32.368200
# Unit test for function match
def test_match():
    assert match(Command("pacman -sf foo bar", None))
    assert match(Command("pacman -S foo bar", None))
    assert match(Command("pacman -qf foo bar", None))
    assert not match(Command("pacman -h", None))
    assert not match(Command("pacman -Q", None))
    # Don't match when output is empty
    assert not match(Command("pacman -sf foo bar", ""))
    # Don't match when output is not pacman related
    assert not match(Command("ls -sf foo bar", "ls: invalid option -- 's'"))

# Generated at 2022-06-12 12:09:37.586092
# Unit test for function match
def test_match():
    assert match(Command('sudo pacman -Suy', '', 'error: invalid option -y\n'))
    assert match(Command('sudo pacman -Sqy', '', 'error: invalid option -q\n'))
    assert not match(Command('sudo pacman -Suy', '', 'error: invalid option -Y\n'))

# Generated at 2022-06-12 12:09:45.208731
# Unit test for function match
def test_match():
    assert match(Command('pacman -Sy', 'error: invalid option "Sy"\n\nSyntax: pacman [options]\nTry "pacman -h" for more information.'))
    assert match(Command('pacman -u', 'error: invalid option -u\n\nSyntax: pacman [options]\nTry "pacman -h" for more information.'))
    assert match(Command('pacman -r', 'error: invalid option -r\n\nSyntax: pacman [options]\nTry "pacman -h" for more information.'))
    assert match(Command('pacman -f', 'error: invalid option -f\n\nSyntax: pacman [options]\nTry "pacman -h" for more information.'))

# Generated at 2022-06-12 12:09:46.626872
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.pacman import get_new_command
    assert get_new_command(Command("pacman -Syy", "")) == "pacman -SYY"

# Generated at 2022-06-12 12:09:51.346435
# Unit test for function match
def test_match():
    assert match(Command("pacman -sd", "error: invalid option '-s'", "", "", 3))
    assert match(Command("pacman -qd", "error: invalid option '-q'", "", "", 3))
    assert match(Command("pacman -fd", "error: invalid option '-f'", "", "", 3))
    assert match(Command("pacman -sd", "error: invalid option '-s'", "", "", 3))
    assert match(Command("pacman -rd", "error: invalid option '-r'", "", "", 3))
    assert match(Command("pacman -ud", "error: invalid option '-u'", "", "", 3))
    assert match(Command("pacman -vd", "error: invalid option '-v'", "", "", 3))