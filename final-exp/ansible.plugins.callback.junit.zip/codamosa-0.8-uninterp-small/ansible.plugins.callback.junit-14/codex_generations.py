

# Generated at 2022-06-25 08:36:27.087703
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_data = TaskData(1, "test", "test", "test", "action")
    test_host_data = HostData(1, "test_host", "test_status", "test_result")
    test_data.add_host(test_host_data)
    assert test_data.host_data[test_host_data.uuid] == test_host_data
    assert test_data.host_data[test_host_data.uuid].name == "test_host"
    assert test_data.host_data[test_host_data.uuid].status == "test_status"
    assert test_data.host_data[test_host_data.uuid].result == "test_result"


# Generated at 2022-06-25 08:36:30.053477
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._start_task(task_0)
    callback_module_0._finish_task('status_0', result_0)

    TaskData_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)
    TaskData_0.add_host(host_0)


# Generated at 2022-06-25 08:36:32.806885
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1._TaskData_add_host()
    print("Test finished")


# Generated at 2022-06-25 08:36:36.222326
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = None
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:36:48.649532
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='9bd9d81195aab0b4f130145d97d6477a', name='fail_this', path='/Users/juniper/ansible_work/testjenkins_playbook.yml', play='testjenkins', action='ping')
    host_data_0 = HostData(uuid='c6eb5d6f5c6e5f636f0e2bdb9d35a6ca', name='test_testjenkins_0', status='failed', result={'changed': True, 'msg': 'All items completed'})
    try:
        task_data_0.add_host(host_data=host_data_0)
    except Exception as e:
        print(e)



# Generated at 2022-06-25 08:36:52.090941
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData("uuid_0", "name_0", "path_0", "play_0", "action_0")
    task_data_0.add_host(HostData("uuid_1", "name_1", "status_1", "result_1"))


# Generated at 2022-06-25 08:36:58.036015
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module = CallbackModule()
    callback_module._task_class = 'true'
    callback_module._task_relative_path = os.path.expanduser('~')
    callback_module._fail_on_change = 'false'
    callback_module._fail_on_ignore = 'false'
    callback_module._include_setup_tasks_in_report = 'true'
    callback_module._hide_task_arguments = 'false'
    callback_module._test_case_prefix = ''

    task_data = TaskData('test_task_data_uuid', 'test_task_data_name', 'test_task_data_path', 'test_task_data_play', 'test_task_data_action')


# Generated at 2022-06-25 08:37:03.863914
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    
    host_0 =  HostData("","","","")
    task_0 =  TaskData("","","","","")
    
    task_0.add_host("")
    assert 'duplicate host callback' in str(sys.exc_info()[1])


# Generated at 2022-06-25 08:37:16.601174
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='cb27fde1-2a41-495d-823e-f39efc002a87', name='print variable', path='/home/ansible/project/playbooks/vars.yml', play='play_0', action='action_0')
    task_data_1 = TaskData(uuid='cb27fde1-2a41-495d-823e-f39efc002a87', name='print variable', path='/home/ansible/project/playbooks/vars.yml', play='play_0', action='action_0')

# Generated at 2022-06-25 08:37:21.650440
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = callback_module_0._playbook_path
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert isinstance(callback_module_0._playbook_name, unicode)
    assert isinstance(callback_module_0._playbook_path, unicode)


# Generated at 2022-06-25 08:37:33.349269
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    test_TaskData_0 = TaskData(None, None, None, None, None)
    test_HostData_0 = HostData(None, None, None, None)
    assert test_TaskData_0.add_host(test_HostData_0) != None


# Generated at 2022-06-25 08:37:42.914786
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_TaskData_0 = CallbackModule()
    task_data_add_host_0 = TaskData(callback_module_TaskData_0.v2_playbook_on_task_start(), callback_module_TaskData_0.v2_runner_on_no_hosts(), callback_module_TaskData_0.v2_playbook_on_play_start(), callback_module_TaskData_0.v2_playbook_on_start(), callback_module_TaskData_0.v2_playbook_on_cleanup_task_start())

# Generated at 2022-06-25 08:37:43.989294
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:37:51.167752
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert TaskData(task_uuid, task_data.name, task_data.path, task_data.play, task_data.start, task_data.host_data) == TaskData(task_uuid, task_data.name, task_data.path, task_data.play, task_data.start, task_data.host_data)
    assert TaskData(task_uuid, task_data.name, task_data.path, task_data.play, task_data.start, task_data.host_data) != TaskData(task_uuid, task_data.name, task_data.path, task_data.play, task_data.start, host_data)

# Generated at 2022-06-25 08:37:54.023241
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = None
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:37:57.186162
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed()


# Generated at 2022-06-25 08:38:00.727913
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    task_data_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)
    host_0 = HostData(uuid_0, name_0, status_0, result_0)

    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:38:05.633407
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_0 = HostData(host_uuid=None, host_name=None, status=None, result=None)
    task_data_0 = TaskData(uuid=None, name=None, path=None, play=None, action=None)
    task_data_0.add_host(host=host_0)


# Generated at 2022-06-25 08:38:12.643261
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData("uuid_0", "name_0", "path_0", "play_0", "action_0")
    host_data_0 = HostData("uuid_0", "name_0", "status_0", "result_0")
    host_data_1 = HostData("uuid_1", "name_1", "status_1", "result_1")
    host_data_2 = HostData("uuid_2", "name_2", "status_2", "result_2")

    # Test method when host data is not in host_data
    task_data_0.add_host(host_data_0)
    assert task_data_0.host_data["uuid_0"] == host_data_0

    # Test method when host data is in host_data, but

# Generated at 2022-06-25 08:38:14.741172
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:38:31.053930
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """
    TestCase for TaskData.add_host
    """

    # The only thing we can test is the exception path, so we'll just try
    # to add a host to TaskData with a UUID that already exists.
    host_data = HostData(
        uuid='UUID_1',
        name='NAME_1',
        status='STATUS_1',
        result='RESULT_1'
    )

    # Create a TaskData object which is the "real" data saved by the plugin
    task_data = TaskData(
        uuid='UUID_1',
        name='NAME_1',
        path='PATH_1',
        play='PLAY_1',
        action='ACTION_1'
    )

    # Add a HostData object to test_data with the same UUID as above

# Generated at 2022-06-25 08:38:36.800362
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("Testing add_host")

    # Setup test
    callback_module_1 = CallbackModule()
    uuid = 'abcdef'
    name = 'test'
    path = 'path'
    play = 'play'
    action = 'action'
    task_data_0 = TaskData(uuid, name, path, play, action)

    uuid = 'abcdef'
    name = 'host_name'
    host_data_0 = HostData(uuid, name, None, None)
    host_data_0.uuid = 'abcdef'
    host_data_0.name = 'host_name 1'
    host_data_0.status = 'included'
    host_data_0.result = 'result'
    task_data_0.add_host(host_data_0)



# Generated at 2022-06-25 08:38:41.513549
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    t = TaskData("", "", "", "", "")
    t.add_host(HostData("", "", "", ""))
    assert t.host_data != "", "Try to add host to HostData"


# Generated at 2022-06-25 08:38:45.193934
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(None, None, None, None, None)
    host_data_0 = HostData(None, None, None, None)
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:38:56.929996
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._task_data['play_name_0'] = callback_module_0.TaskData('task_name_0', 'task_name_0', 'play_name_0', 'play_name_0');
    host_data_0 = callback_module_0.HostData('host_name_0', 'host_name_0', 'status_0', 'result_0');
    try:
        callback_module_0._task_data['play_name_0'].add_host(host_data_0);
    except Exception:
        pass;
    assert(callback_module_0._task_data['play_name_0'].host_data['host_name_0'].uuid == 'host_name_0');

# Generated at 2022-06-25 08:39:01.247783
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1._playbook_path='playbook_path'
    callback_module_1._play_name='play_name'
    data = TaskData('uuid', 'name', 'path', 'play', 'action')
    data.add_host(HostData('host_uuid', 'host_name', 'included', {'result': 'result'}))



# Generated at 2022-06-25 08:39:08.443498
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert set_equal(mock_TaskData_add_host()['msg'], {'exception'}) == True
    assert set_equal(mock_TaskData_add_host()['name'], {'ok'}) == True
    assert set_equal(mock_TaskData_add_host()['uuid'], {'failed'}) == True
    assert set_equal(mock_TaskData_add_host()['play'], {'included'}) == True
    assert set_equal(mock_TaskData_add_host()['path'], {'skipped'}) == True


# Generated at 2022-06-25 08:39:16.552654
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_0 = TaskData('fg', 'fl', 'ox', 'nx', 'yt')
    host_data_0 = HostData('rw', 'sm', 'yg', 'tt')
#     task_data_0.add_host(host_data_0)
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 08:39:27.921441
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    t1 = TaskData('uuid1', 'name1', 'path1', 'play1', 'action1')
    t2 = TaskData('uuid2', 'name2', 'path2', 'play2', 'action2')
    t3 = TaskData('uuid3', 'name3', 'path3', 'play3', 'action3')
    t4 = TaskData('uuid4', 'name4', 'path4', 'play4', 'action4')
    t5 = TaskData('uuid5', 'name5', 'path5', 'play5', 'action5')
    t6 = TaskData('uuid6', 'name6', 'path6', 'play6', 'action6')

    h1 = HostData('host_uuid1', 'host_name1', 'status1', 'result1')
    h2

# Generated at 2022-06-25 08:39:36.062778
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = {'_ansible_version': '2.4.2.0'}
    playbook_0['_file_name'] = u'untitled.yml'
    playbook_0['_ansible_no_log'] = False
    playbook_0['_ansible_debug'] = True
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:39:45.654605
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    playbook = {'_file_name': 'sample.yaml'}
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:39:51.976893
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData("uuid","name","path","play","action")
    host_data_0 = HostData("uuid","name","status", "result")
    callback_module_0._task_data = {"uuid": task_data_0}
    result = task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:39:52.856865
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # No output
    return

# Generated at 2022-06-25 08:40:00.765967
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with an empty result
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()

    # Test with result
    callback_module_1 = CallbackModule()
    ansible_result = AnsibleResult()
    ansible_result._task = AnsibleTask()
    ansible_result._task._uuid = 'a9efb38f-2d6b-4eb1-9f29-ad6f8c6e846f'
    ansible_result._result = {'no_log': 'on_fail', 'stderr': 'unsupported locale setting'}
    ansible_result._host = AnsibleHost()

# Generated at 2022-06-25 08:40:06.847320
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    callback_module_1 = CallbackModule()

    # Assign values to test arguments
    uuid_0 = 'abcd'
    name_0 = 'tacos'
    path_0 = 'tacos.yml'
    play_0 = 'playbook'
    action_0 = 'include'

    host_uuid_0 = 'host'
    host_name_0 = 'host.example.com'
    host_status_0 = 'ok'
    host_result_0 = 'host.example.com'

    # Test the TaskData class 
    task_data_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)


# Generated at 2022-06-25 08:40:10.021570
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'ok', 'result')
    try:
        task_data.add_host(host_data)
    except Exception as ex:
        print('test_TaskData_add_host failed: str(ex)')
        print(str(ex))
    assert True


# Generated at 2022-06-25 08:40:19.537470
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    callback_module_0.task_data = {}
    callback_module_0.task_data['test_add_host'] = callback_module_0.TaskData("test_add_host", "test_add_host", "test_add_host", "test_add_host", "test_add_host") 

    host = callback_module_0.HostData("test_add_host", "test_add_host", "test_add_host", "test_add_host")
    callback_module_0.task_data['test_add_host'].add_host(host)


# Generated at 2022-06-25 08:40:26.883602
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Pass case 1
    test_TaskData_add_host_1 = TaskData("uuid", "name", "path", "play", "action")
    test_TaskData_add_host_2 = HostData("host uuid", "host_name", "status", "result")
    test_TaskData_add_host_1.add_host(test_TaskData_add_host_2)

    # Pass case 2
    test_TaskData_add_host_3 = TaskData("uuid", "name", "path", "play", "action")
    test_TaskData_add_host_4 = HostData("host uuid", "host_name", "status", "result")
    test_TaskData_add_host_3.add_host(test_TaskData_add_host_4)


# Generated at 2022-06-25 08:40:32.645540
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Dummy()
    playbook_0._file_name = 'playbook_0._file_name'
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_path == 'playbook_0._file_name'
    assert callback_module_0._playbook_name == 'playbook_0'


# Generated at 2022-06-25 08:40:36.758825
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = None

    # No exception should be thrown
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:02.508670
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    test_int_0 = 123
    test_str_0 = 'ansible.registered_variables[hostvar].var_.self'
    test_str_1 = 'ansible.registered_variables[hostvar].var_.self'
    test_str_2 = 'ansible_host'
    test_str_3 = 'ansible_host'
    test_str_4 = 'ansible_host'
    test_str_5 = 'ansible.registered_variables.hostvar'
    test_str_6 = 'ansible.registered_variables.hostvar'
    test_str_7 = 'ansible_port'
    test_str_8 = 'ansible_port'
    test_str_9 = 'ansible_port'
    test_str_10

# Generated at 2022-06-25 08:41:14.143441
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    assert_equal(callback_module_0._playbook_path, None)
    assert_equal(callback_module_0._playbook_name, None)
    callback_module_0_v2_playbook_on_start = MagicMock()
    callback_module_0.v2_playbook_on_start(callback_module_0_v2_playbook_on_start)
    assert_equal(callback_module_0._playbook_path, callback_module_0_v2_playbook_on_start._file_name)
    assert_equal(callback_module_0._playbook_name, os.path.splitext(os.path.basename(callback_module_0_v2_playbook_on_start._file_name))[0])



# Generated at 2022-06-25 08:41:16.661101
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host = HostData()
    task_data = TaskData()
    assert not task_data.add_host(host)


# Generated at 2022-06-25 08:41:22.800516
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = callback_module_0.TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data_0 = callback_module_0.HostData('uuid', 'name', 'status', None)

    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:41:24.819254
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_0 = {}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:30.304433
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(uuid='foo', name='foo', path='foo', play='foo', action='foo')
    host_uuid = 'foo'
    host_name = 'foo'
    status = 'bar'
    result = 'bar'
    host_data_0 = HostData(host_uuid, host_name, status, result)
    try:
        task_data_0.add_host(host=host_data_0)
    except Exception as e:
        assert e.args[0] == 'foo: foo: foo: duplicate host callback: foo'


# Generated at 2022-06-25 08:41:37.631598
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    # Arrange
    host_0 = HostData('uuid_0', 'name_1', 'status_2', 'result_3')

    task_data_0 = TaskData('uuid_0', 'name_1', 'path_2', 'play_3', 'action_4')

    # Act
    task_data_0.add_host(host_0)

    # Assert
    assert task_data_0.host_data['uuid_0'] == host_0

    assert task_data_0.host_data['uuid_0'].uuid == 'uuid_0'

    assert task_data_0.host_data['uuid_0'].name == 'name_1'

    assert task_data_0.host_data['uuid_0'].status == 'status_2'


# Generated at 2022-06-25 08:41:48.201559
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    common_task_data_0 = TaskData(uuid = None, name = 'name', path = 'path', play = 'play', action = 'action')
    host_0 = HostData(uuid = 'uuid', name = 'name', status = 'status', result = 'result')
    try:
        common_task_data_0.add_host(host_0)
    except Exception as exception_0:
        assert str(exception_0) == 'path: play: name: duplicate host callback: name', \
               'Expected exception\'s message: path: play: name: duplicate host callback: name, but got: %s' % str(exception_0)
    else:
        raise AssertionError('No exception thrown')


# Generated at 2022-06-25 08:41:51.508018
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host=callback_module_0.add_host()
    assert(callback_module_0.uuid == host)
    assert(callback_module_0.name == host)
    assert(callback_module_0.path == host)
    assert(callback_module_0.play == host)
    assert(callback_module_0.start == host)
    assert(callback_module_0.host_data == host)



# Generated at 2022-06-25 08:41:52.539290
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert True


# Generated at 2022-06-25 08:42:52.153661
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    result = vars(Result())
    result['_task'] = vars(Task())
    result['_task']['_uuid'] = str(uuid4())
    result['_task']['_dump_results'] = '.'
    result['_task']['_action'] = '';
    result['_task']['_task_fields'] = ['_dump_results']
    result['_host'] = vars(Host())
    result['_host']['_uuid'] = str(uuid4())
    result['_host']['_name'] = 'host_a'
    result['_result'] = {}

    callback_module.v2_runner_on_failed(result, False)


# Generated at 2022-06-25 08:42:53.709158
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('task_data', 'name', 'path', 'play')
    host = HostData('host')
    task_data.add_host(host)


# Generated at 2022-06-25 08:42:55.940709
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = {}
    callback_module_0.v2_playbook_on_start(playbook_0)



# Generated at 2022-06-25 08:43:03.622426
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Creating a RunnerResult
    runner_result_0 = RunnerResult('changed', None, None, None, 'changed', 'changed', 'changed')
    # Creating another RunnerResult
    runner_result_1 = RunnerResult('changed', None, None, None, 'changed', 'changed', 'changed')
    test_case(runner_result_0, runner_result_1)


# Generated at 2022-06-25 08:43:09.320220
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_task_data = TaskData(uuid = "UUID",
                              name = "name",
                              path = "path",
                              play = "play",
                              action = "action")

    test_host = HostData(uuid = "UUID",
                         name = "name",
                         status = "status",
                         result = "result")

    test_task_data.add_host(test_host)


# Generated at 2022-06-25 08:43:11.242126
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:43:16.933124
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    # Try to call method with unsupported value for argument result
    result = 'result'
    try:
        CallbackModule_v2_runner_on_failed(callback_module_0, result)
    except TypeError:
        pass

    # Try to call method with unsupported value for argument ignore_errors
    result = type('A')
    result.task_uuid = 'task_uuid'
    result.host_uuid = 'host_uuid'
    result.result = 'result'
    ignore_errors = 'ignore_errors'
    try:
        CallbackModule_v2_runner_on_failed(callback_module_0, result, ignore_errors)
    except TypeError:
        pass

    # Set argument to known value and call method
    result.task_uuid

# Generated at 2022-06-25 08:43:22.561310
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_0 = HostData('uuid', 'name', 'status', 'result')
    task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:43:26.236274
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1.test_case_0.add_host()


# Generated at 2022-06-25 08:43:33.831229
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    #Test case 1: Duplicate host
    callback_module_1 = CallbackModule()
    host_data_1_1 = HostData('host_uuid', 'host_name', 'status', 'result')
    host_data_1_2 = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data_1 = TaskData('uuid', 'name', 'path', 'play', 'action')
    task_data_1.add_host(host_data_1_1)
    try:
        task_data_1.add_host(host_data_1_2)
    except Exception as e:
        assert str(e) == 'path: play: name: duplicate host callback: host_name'


# Generated at 2022-06-25 08:44:20.344762
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    taskdata_0 = TaskData('uui7d', 'name1', 'path1', 'play1', 'action1')
    hostdata_0 = HostData('uui7d', 'name1', 's7a7tus1', 'result1')
    taskdata_0.add_host(hostdata_0)


# Generated at 2022-06-25 08:44:27.080612
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Prepare test data
    callback_module_0 = CallbackModule()
    result = None
    ignore_errors = False
    # Invoke method
    callback_module_0.v2_runner_on_failed(result, ignore_errors)
    # Check return value
    assert isinstance(callback_module_0, CallbackModule)
    # Check side effects



# Generated at 2022-06-25 08:44:32.821851
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = MockPlaybook(file_name = "test_0")
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:44:39.087578
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_1 = TaskData(None, None, None, None, None)
    host_data_0 = HostData(None, None, None, None)
    # Verifying precondition:
    assert len(task_data_1.host_data) == 0
    # Executing method:
    task_data_1.add_host(host_data_0)
    # Verifying postcondition:
    assert len(task_data_1.host_data) == 1


# Generated at 2022-06-25 08:44:40.747018
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:44:43.297626
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = None
    callback_module_0.v2_playbook_on_start(playbook_0)

# Generated at 2022-06-25 08:44:47.218362
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    output = to_bytes('{}')
    result = to_bytes('{}')
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed(result)
    assert output == to_bytes('{}')


# Generated at 2022-06-25 08:44:55.314576
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    class Host:
        def __init__(self):
            self._uuid = 'host_uuid'
            self.name = 'host_name'

    class Result:
        def __init__(self):
            self._task = 'task'
            self._host = Host()

    class Task:
        def __init__(self):
            self._uuid = 'task_uuid'
            self.action = 'action'
            self.name = 'name'
            self.no_log = 'no_log'
            self.args = 'args'

    my_result = Result()
    my_result._result = {"exception": "test exception"}
    my_result._task = Task()

# Generated at 2022-06-25 08:44:58.793447
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Initialize
    callback_module_0 = CallbackModule()
    playbook_0 = mock.MagicMock()
    assert isinstance(playbook_0, object)
    callback_module_0.v2_playbook_on_start(playbook_0)




# Generated at 2022-06-25 08:45:00.771902
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    callback_module_0.v2_playbook_on_start(
        playbook
    )
