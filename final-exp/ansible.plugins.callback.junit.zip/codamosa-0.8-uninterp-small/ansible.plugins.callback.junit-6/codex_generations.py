

# Generated at 2022-06-25 08:36:20.634726
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    bool_0 = False
    callback_module_0 = CallbackModule()
    var_0 = TaskData(bool_0)
    result = var_0.add_host(callback_module_0)
    assert result


# Generated at 2022-06-25 08:36:22.586939
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    arg_1 = HostData()
    obj = TaskData()
    obj.add_host(arg_1)


# Generated at 2022-06-25 08:36:26.464994
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    bool_0 = False
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_play_start(bool_0)
    host_data_0 = HostData(var_0, 'failed', 'rc=0')
    var_0.add_host(host_data_0)



# Generated at 2022-06-25 08:36:28.709245
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    bool_0 = False
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(bool_0)


# Generated at 2022-06-25 08:36:32.640936
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    bool_0 = True
    bool_1 = False
    task_data_0 = TaskData()
    host_data_0 = HostData()
    task_data_0.add_host(host_data_0)



# Generated at 2022-06-25 08:36:35.795742
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Instantiate a CallbackModule object
    callback_module_0 = CallbackModule()
    
    # Call method v2_playbook_on_start
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:36:46.149357
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    bool_0 = False
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_play_start(bool_0)
    task_data_0 = TaskData(var_0, var_0, var_0, var_0, var_0)
    var_1 = callback_v2_playbook_on_play_start(bool_0)
    host_data_0 = HostData(var_1, var_1, var_1, var_1)
    task_data_0.add_host(host_data_0)
    return var_1


# Generated at 2022-06-25 08:36:49.061968
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    bool_0 = False
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_play_start(bool_0)


# Generated at 2022-06-25 08:36:50.213363
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:36:50.784636
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    pass


# Generated at 2022-06-25 08:36:58.762879
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    pass


# Generated at 2022-06-25 08:37:03.226562
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('/home/vagrant/devops-sandbox/ansible/devops.yml')


# Generated at 2022-06-25 08:37:09.071960
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = playbook(int_0)
    var_0 = callback_module_0.v2_playbook_on_start(playbook_0)
    # Asserts that the method :method_name terminates with return type :return_type
    assert isinstance(var_0, bool)


# Generated at 2022-06-25 08:37:20.540318
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook(playbook_path_0)
    # Variable is a string
    assert isinstance(playbook_0._file_name, str)
    # Try to call method v2_playbook_on_start of class CallbackModule
    try:
        callback_v2_playbook_on_start(playbook_0)
    except TypeError:
        # Try to call method v2_playbook_on_start of class CallbackModule
        test_CallbackModule_v2_playbook_on_start()
    except Exception:
        # Try to call method v2_playbook_on_start of class CallbackModule
        test_CallbackModule_v2_playbook_on_start()


# Generated at 2022-06-25 08:37:24.546729
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("Begin Unit test for TaskData add_host")
    test_data = TaskData("a1","name","path","play","action")
    host = HostData("b2","name","status",["result"])
    test_data.add_host(host)
    assert (test_data.name == "name")
    assert (test_data.host_data == {"b2":host})
    print("Pass the Unit test for TaskData add_host")


# Generated at 2022-06-25 08:37:25.857449
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert True


# Generated at 2022-06-25 08:37:34.063411
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # TaskData for testing TaskData.add_host method
    task_data = TaskData('task_data_0', 'task_data_name_0', 'task_data_path_0', 'test_TaskData_add_host', 'test_TaskData_add_host')
    # HostData for testing TaskData.add_host method
    host_data = HostData('host_data_0', 'host_data_name_0', 'ok', 'host_data_result_0')
    task_data.add_host(host_data)
    assert host_data == task_data.host_data['host_data_0']


# Generated at 2022-06-25 08:37:37.053611
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    bool_0 = False
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(bool_0)
    assert True

# Generated at 2022-06-25 08:37:41.004437
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert(True)


# Generated at 2022-06-25 08:37:43.830728
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    bool_0 = False
    callback_module_0 = CallbackModule()
    var_0 = TaskData(bool_0)
    var_1 = TaskData()
    var_0.add_host(var_1)


# Generated at 2022-06-25 08:37:59.477454
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # test your method
    callback_module_0 = CallbackModule()
    callback_v2_playbook_on_start(callback_module_0)
    #assert callback_module_0._playbook_name == 'callback.yml'


# Generated at 2022-06-25 08:38:08.803795
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    callback_module_0 = CallbackModule()
    callback_module_0.validate_configuration()
    var_1 = Playbook()
    var_2 = None
    # Partially stub Playbook object
    var_1.validate_filenames = var_2
    # End of partially stub Playbook object
    # Partially stub _playbook_on_start
    callback_module_0.disabled = True
    callback_module_0.v2_playbook_on_play_start = var_2
    callback_module_0.v2_playbook_on_start = var_2
    callback_module_0.v2_playbook_on_stats = var_2
    callback_module_0.v2_playbook_on_notify = var_2

# Generated at 2022-06-25 08:38:10.875591
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:38:12.589047
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    t = TaskData()
    h = HostData()

    t.add_host(h)



# Generated at 2022-06-25 08:38:13.881025
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    param_0 = callback_module_0.v2_runner_on_failed()
    assert type(param_0) == Result 


# Generated at 2022-06-25 08:38:17.245794
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(None)


# Generated at 2022-06-25 08:38:22.109165
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    """
    Unit test for method v2_playbook_on_start of class CallbackModule.
    """
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_playbook_on_start(callback_module_1)


# Generated at 2022-06-25 08:38:28.723904
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    assert callback_module_1._playbook_path == None
    assert callback_module_1._playbook_name == None
    var_1 = FakePlaybook()
    var_1._file_name = 'foo.yml'
    callback_module_1.v2_playbook_on_start(var_1)
    assert callback_module_1._playbook_path == 'foo.yml'
    assert callback_module_1._playbook_name == 'foo'


# Generated at 2022-06-25 08:38:33.978769
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:38:40.980733
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_2 = CallbackModule()
    result_3 = None
    ignore_errors_4 = None
    callback_module_2.v2_runner_on_failed(result_3, ignore_errors_4)


# Generated at 2022-06-25 08:38:56.470612
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    pass


# Generated at 2022-06-25 08:38:59.066227
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    var_0 = Playbook()
    var_1 = callback_v2_playbook_on_start(callback_module_0, var_0)


# Generated at 2022-06-25 08:39:03.034029
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook()
    callback_module_v2_playbook_on_start(callback_module_0, playbook_0)


# Generated at 2022-06-25 08:39:06.814760
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    var_1 = TaskData('uuid', 'name', 'path', 'play', 'action')
    var_2 = HostData('uuid', 'name', 'status', 'result')
    var_1.add_host(var_2)


# Generated at 2022-06-25 08:39:16.344258
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Init callback_module force setting
    callback_module = CallbackModule()

    # Init playbook force setting
    playbook = MagicMock()
    playbook._file_name = 'test/test.yml'

    # Try setting playbook
    callback_module.v2_playbook_on_start(playbook)
    assert callback_module._playbook_path == playbook._file_name
    assert callback_module._playbook_name == 'test.yml'

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 08:39:21.517148
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    var_0 = v2_playbook_on_start(callback_module_0)


# Generated at 2022-06-25 08:39:24.208082
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    var = callback_v2_playbook_on_start(callback_module)


# Generated at 2022-06-25 08:39:26.923614
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    # var_0 = TaskData(callback_module_0.v2_playbook_on_play_start())
    callback_module_0.v2_runner_on_skipped(callback_module_0)
    callback_module_0.v2_runner_on_ok(callback_module_0)



# Generated at 2022-06-25 08:39:30.361331
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = RunnerResult()
    result._result = {}
    result._result['changed'] = False
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)
    assert True


# Generated at 2022-06-25 08:39:36.639692
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    taskData_0 = TaskData("yBp", "0RG", "DpF", "aZ5", "Zm8")
    hostData_0 = HostData("x6U", "6Y1", "eU5", "k3q")
    taskData_0.add_host(hostData_0)



# Generated at 2022-06-25 08:40:06.953408
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:40:10.562163
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(callback_module_0)


# Generated at 2022-06-25 08:40:20.114110
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    Path_0 = callback_module_0._playbook_path
    assert type(Path_0) == type(''), 'Variable Path_0 is not of type str as expected'
    path_0 = callback_module_0._playbook_name
    assert type(path_0) == type(''), 'Variable path_0 is not of type str as expected'
    object_0 = callback_v2_playbook_on_start(callback_module_0, None) # do we need a param of type 'playbook'?
    assert type(object_0) == type(None), 'Variable object_0 is not of type NoneType as expected'


# Generated at 2022-06-25 08:40:22.015901
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    self = CallbackModule()
    playbook = Playbook()
    # Act
    v2_playbook_on_start(self, playbook)
    # Assert
    pass


# Generated at 2022-06-25 08:40:23.279407
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case_0()


# Generated at 2022-06-25 08:40:34.994062
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    uuid_0 = callback_v2_playbook_on_task_start(callback_module_1)
    name_0 = 'TASK NAME'
    path_0 = '\\path\\file.yml:line'
    play_1 = 'PLAY NAME'
    action_0 = 'ACTION'
    callback_module_1 = TaskData(uuid_0, name_0, path_0, play_1, action_0)
    host_0 = 'HOST NAME'
    finish_0 = time.time()
    uuid_1 = callback_v2_playbook_on_task_start(callback_module_1)
    status_0 = 'STATUS'
    result_0 = 'RESULT'

# Generated at 2022-06-25 08:40:37.890349
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_playbook_on_start(callback_module_1)


# Generated at 2022-06-25 08:40:46.154315
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(var_1)
    callback_module_0.v2_playbook_on_play_start(var_2)
    callback_module_0.v2_runner_on_ok(var_3)
    var_4 = var_3.result
    test_data_0 = TaskData(var_0, var_1, var_2, var_3, var_4)
    callback_module_0.v2_playbook_on_stats(var_5)
    callback_module_0.v2_runner_on_failed(var_6, var_7)
    callback_module_0.v2_runner_on_ok(var_8)
    callback_module_0.v2_

# Generated at 2022-06-25 08:40:48.319459
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(None)


# Generated at 2022-06-25 08:40:51.355826
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = ANSIBLE_RECORD(host='ansible.example.com', task=dict(name='TEST_TASK'), failed=True)
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:41:55.185755
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup
    callback_module_0 = CallbackModule()
    result_0 = ''
    ignore_errors_0 = False

    # Invoke
    method_result_0 = callback_v2_runner_on_failed(callback_module_0, result_0, ignore_errors_0)

    # Verify
    assert method_result_0 == None


# Generated at 2022-06-25 08:41:58.159056
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    var_0 = TaskData()
    var_1 = HostData()
    var_0.add_host(var_1)


# Generated at 2022-06-25 08:42:03.635185
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(callback_module_0)


# Generated at 2022-06-25 08:42:09.623503
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(callback_module_0, callback_module_0, callback_module_0, callback_module_0, callback_module_0)
    host_0 = HostData(callback_module_0, callback_module_0, callback_module_0, callback_module_0)
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:42:15.973880
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    f = open("../tests/test_data/D1.yml")
    playbook = yaml.load(f.read())
    f.close()
    var_2 = callback_v2_playbook_on_start(callback_module_1, playbook)


# Generated at 2022-06-25 08:42:21.171351
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    
    # Note: v2_playbook_on_start(playbook) has no return value
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:42:24.503919
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = None
    ignore_errors_0 = False
    var_0 = callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:42:28.317315
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_0 = HostData('uuid_1', 'name_1', 'status_1', 'result_1')
    task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:42:32.558473
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_be6aadb6ac1c4ed9adbaa27a6ab2f6a4 = CallbackModule()
    param_result = mock.MagicMock()
    param_ignore_errors = False
    callback_module_be6aadb6ac1c4ed9adbaa27a6ab2f6a4.v2_runner_on_failed(param_result, param_ignore_errors)
    return True


# Generated at 2022-06-25 08:42:34.169235
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(callback_module_0)



# Generated at 2022-06-25 08:45:23.589292
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(callback_module_0)


# Generated at 2022-06-25 08:45:25.601283
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = host_0()
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:45:29.742856
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook()
    playbook_0._file_name = 'test_files/test_playbook.yml'
    callback_module_0.v2_playbook_on_start(playbook_0)
    
    assert callback_module_0._playbook_path == 'test_files/test_playbook.yml'
    assert callback_module_0._playbook_name == 'test_playbook'
    


# Generated at 2022-06-25 08:45:34.216331
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result=None, ignore_errors=False)


# Generated at 2022-06-25 08:45:40.206872
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_0 = HostData()
    task_data_0 = TaskData()
    task_data_0.add_host(host_0)
    host_0_0 = task_data_0.host_data[0]
    assert host_0 == host_0_0


# Generated at 2022-06-25 08:45:50.788733
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:45:58.616996
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    var_1 = TaskData(uuid, name, path, play, action)
    callback_module_1 = callback_module_1._TaskData_add_host(var_1, host)


# Generated at 2022-06-25 08:46:04.466628
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = playbook(filename=None)
    var_0 = callback_module_0.v2_playbook_on_start(playbook_0)
