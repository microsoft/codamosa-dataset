

# Generated at 2022-06-25 08:36:21.094482
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    bytes_0 = b'a[\xdd/n\xaf\xbc\xbe\xa8\x1b\x96XO\xc7F\xa5'
    tuple_0 = (bytes_0,)
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_cleanup_task_start(tuple_0)
    tuple_1 = (None,)
    callback_module_1 = callback_module_0
    var_1 = callback_v2_playbook_on_cleanup_task_start(tuple_1)


# Generated at 2022-06-25 08:36:27.632866
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    bytes_0 = b'a[\xdd/n\xaf\xbc\xbe\xa8\x1b\x96XO\xc7F\xa5'
    tuple_0 = (bytes_0,)
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(tuple_0)


# Generated at 2022-06-25 08:36:38.283436
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    bytes_0 = b'+\xa3\x1c\x9f\x9a\xdd\xa7\x97\x88\xbc*\xe8\xbd\xbc\x9b\xd1\xa8\xf6\xd7\xc3\xeb\xd3\x8c\x1d\xf9k\xaa\xa5\x97\xef\xb4\x16\x8e\xd4\x83\x9f\x98C\xd3\x1e\xe2\x1b\x8fRL\x05\x16\x0e'
    dict_0 = dict()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_playbook_on_start(dict_0)
   

# Generated at 2022-06-25 08:36:43.850343
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of a class
    class_0 = CallbackModule()
    # Create a variable of type tuple
    tuple_0 = (class_0)
    # Call method v2_playbook_on_start with arguments (tuple_0)
    var_0 = callback_v2_playbook_on_start(tuple_0)


# Generated at 2022-06-25 08:36:50.850177
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    bytes_0 = b'5P\tB\xca\xf1'
    tuple_0 = (bytes_0,)
    task_data_0 = TaskData(tuple_0)
    bytes_1 = b'\xcf\xc4\xd4\x1c\xed\xab6\xcb\xa35'
    callback_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_cleanup_task_start(tuple_0)

test_TaskData_add_host()

# Generated at 2022-06-25 08:36:51.659199
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert true


# Generated at 2022-06-25 08:37:05.936089
# Unit test for method v2_playbook_on_start of class CallbackModule

# Generated at 2022-06-25 08:37:15.958700
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(callback_module_0.uuid, callback_module_0.name, callback_module_0.path, callback_module_0.play, callback_module_0.action)
    task_data_0.task_data = callback_module_0.host_data
    task_data_0.callback_module_0 = TaskData(callback_module_0.uuid, callback_module_0.name, callback_module_0.path, callback_module_0.play, callback_module_0.action)


# Generated at 2022-06-25 08:37:22.272942
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    name_0 = 'TaskData'
    type_0 = type(name_0, (TaskData,), {})
    object_0 = type_0.__new__(type_0)
    bytes_0 = b'a[\xdd/n\xaf\xbc\xbe\xa8\x1b\x96XO\xc7F\xa5'
    tuple_0 = (bytes_0,)
    dict_0 = dict()
    var_0 = object_0.add_host(tuple_0)


# Generated at 2022-06-25 08:37:29.868265
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    bytes_0 = b'a[\xdd/n\xaf\xbc\xbe\xa8\x1b\x96XO\xc7F\xa5'
    tuple_0 = (bytes_0,)
    var_0 = callback_v2_playbook_on_cleanup_task_start(tuple_0)

    assert(var_0 == b'')


# Generated at 2022-06-25 08:37:40.690146
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print('Testing add_host')
    uuid = 'f4c4a31a-a6d7-430f-b6c9-9aeb99c47dd7'
    name = 'ping'
    path = 'ping.yml'
    play = 'ping'
    action = 'ping'
    taskData = TaskData(uuid, name, path, play, action)
    host = HostData('6d68c6a7-6a78-4e30-89ec-fa92cd5fa918', 'localhost', 'failed', 'failed')
    taskData.add_host(host)


# Generated at 2022-06-25 08:37:43.864918
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_stats(float_0)
    var_1 = TaskData.add_host(var_0, float_0)


# Generated at 2022-06-25 08:37:45.979499
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(callback_module_0)


# Generated at 2022-06-25 08:37:47.442292
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    try:
        pass
    except Exception as exception_0:
        print(exception_0.message)


# Generated at 2022-06-25 08:37:53.609129
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = 0.0
    string_0 = '58R<9>'
    string_1 = ''
    string_2 = '~6j'
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(float_0, string_0, string_1, string_2)


# Generated at 2022-06-25 08:37:58.262335
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:38:02.036855
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData()
    float_0 = -3193.32
    host_0 = HostData()
    task_data_0 = add_host(float_0)
    assert_equal(task_data_0, host_0)


# Generated at 2022-06-25 08:38:05.505980
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_stats(float_0)
    assert isinstance(var_0, int)


# Generated at 2022-06-25 08:38:09.380636
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -8985.35
    callback_module_0 = CallbackModule()
    callback_v2_runner_on_failed(callback_module_0, float_0)


# Generated at 2022-06-25 08:38:12.206457
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:38:25.756878
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Create test instances of Input type
    HostData_0 = HostData(None, None, None, None)

    # Create test instances of type TaskData
    TaskData_0 = TaskData(None, None, None, None, None)
    TaskData_1 = TaskData(None, None, None, None, None)

    # Call method
    TaskData_0.add_host(HostData_0)



# Generated at 2022-06-25 08:38:33.530386
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_data_0 = callback_module_0.v2_playbook_on_include('included_file_0')
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0.uuid = 'uuid_1'
    task_data_0.add_host(host_data_0)
    task_data_1 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    with pytest.raises(Exception) as excinfo:
        task_data_1.add_host(host_data_0)


# Generated at 2022-06-25 08:38:35.811997
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_stats(float_0)


# Generated at 2022-06-25 08:38:42.424969
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -1023.01
    task_data_0 = TaskData(float_0, float_0, float_0, float_0, float_0)
    host_data_0 = HostData(float_0, float_0, float_0, float_0)
    task_data_0.add_host(host_data_0)



# Generated at 2022-06-25 08:38:45.424909
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    from ansible.utils._junit_xml import TestSuites, TestSuite
    callback_module_0 = CallbackModule()
    callback_module_0._task_data['hello'] = TaskData(1,2,3,4,5)
    host_data_0 = HostData(1,2,3,4)
    callback_module_0._task_data['hello'].add_host(host_data_0)




# Generated at 2022-06-25 08:38:50.986375
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 37.72
    TaskData_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    HostData_0 = HostData('uuid', 'name', 'status', 'result')
    var_0 = TaskData_0.add_host(HostData_0)


# Generated at 2022-06-25 08:38:57.559449
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -4925.22
    TaskData_instance_0 = TaskData('TaskData_instance_0','TaskData_instance_1','TaskData_instance_2','TaskData_instance_3','TaskData_instance_4')
    HostData_instance_0 = HostData('HostData_instance_0','HostData_instance_1', float_0)
    TaskData_instance_0.add_host(HostData_instance_0)


# Generated at 2022-06-25 08:38:59.852464
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule()
    status, result = cb.v2_runner_on_failed(1)
    assert status == 'failed'
    assert result == 1


# Generated at 2022-06-25 08:39:01.621385
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -3298.6
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:39:08.435531
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:39:24.456499
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    class_0 = TaskData(float_0, float_0, float_0, float_0, float_0)
    var_0 = HostData(float_0, float_0, float_0, float_0)
    callback_module_0.TaskData_add_host(class_0, var_0)


# Generated at 2022-06-25 08:39:31.425131
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Initialization of an object
    callback_module_0 = CallbackModule()
    # Testing of the method v2_playbook_on_start of an object
    assert_equal(callback_module_0.v2_playbook_on_start(), True)


# Generated at 2022-06-25 08:39:37.011198
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -0.8003347908065588
    callback_module_0 = CallbackModule()
    var_0 = TaskData(float_0, '', '', '', '')
    var_1 = HostData(float_0, '', '', float_0)
    var_0.add_host(var_1)


# Generated at 2022-06-25 08:39:41.747538
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 5759.38
    TaskData_0 = TaskData(float_0)
    float_1 = 5135.87
    TaskData_1 = TaskData(float_1)
    float_2 = -89.61
    HostData_0 = HostData(float_2)
    float_3 = -3727.16
    HostData_1 = HostData(float_3)
    TaskData_1.add_host(HostData_0)
    HostData_1.add_host(TaskData_0)
    TaskData_0.add_host(TaskData_1)


# Generated at 2022-06-25 08:39:46.945986
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Setup test data
    task_name = 'test_task'
    task_path = 'test_task_path'
    host_name = 'test_host'
    host_result = 'test_host_result'
    folder_name = 'test_folder'
    host_data = HostData(host_name, host_result)

    task_data = TaskData(task_name, task_path, host_data)

    # Instantiate callback module
    callback_module = CallbackModule()

    # Invoke method under test
    result = callback_module._finish_task('failed', task_data, host_data)

    assert result == 'failed'


# Generated at 2022-06-25 08:39:52.540588
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host_0 = HostData()
    task_data_0 = TaskData(str_0, str_1, str_2, str_3, str_4)
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:39:57.468005
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = 20.0
    double_0 = 100.0
    float_1 = -3842.55
    double_1 = -100.0
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(float_0, double_0)
    callback_module_0.v2_runner_on_failed(float_1, double_1)


# Generated at 2022-06-25 08:39:59.729094
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_stats(float_0)



# Generated at 2022-06-25 08:40:03.771379
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Creates a test TaskData object
    task_data_obj = TaskData()
    # Creates a test HostData object
    test_host_data_obj = HostData()
    # Call method under test
    task_data_obj.add_host(test_host_data_obj)



# Generated at 2022-06-25 08:40:05.648152
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -1824.40
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:40:24.701124
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host_0 = HostData()
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.task_data
    var_1 = None
    if (var_0 == var_1):
        raise Exception('AssertionError')
    var_2 = callback_module_0.task_data
    var_3 = host_0.uuid
    var_4 = None
    if (var_3 in var_2):
        raise Exception('AssertionError')
    else:
        callback_module_0.task_data.add_host(host_0)
    var_5 = callback_module_0.task_data
    var_6 = None
    if (var_5 != var_6):
        raise Exception('AssertionError')


# Generated at 2022-06-25 08:40:30.311380
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:40:32.452084
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_stats(float_0)


# Generated at 2022-06-25 08:40:40.786437
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    # Cases
    # Case 1:
    #  host.status == 'included'
    #  self.host_data[host.uuid] is True
    #  if host.status == 'included':
    #    host.result = '%s\n%s' % (self.host_data[host.uuid].result, host.result)
    #  else:
    #    raise Exception('%s: %s: %s: duplicate host callback: %s' % (self.path, self.play, self.name, host.name))

    # Case 2:
    #  host.status == 'failed'
    #  self.host_data[host.uuid] is False
    #  if host.status == 'included':
    #    host.result

# Generated at 2022-06-25 08:40:43.164660
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_1 = -5255.57
    callback_module_1 = CallbackModule()
    var_1 = callback_v2_playbook_on_start(float_1)


# Generated at 2022-06-25 08:40:44.905705
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    included_0 = IncludedFile(uuid)
    task_data_0 = TaskData(uuid, name, path, play, action)
    task_data_0.add_host(included_0)


# Generated at 2022-06-25 08:40:46.802605
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = TaskData(float_0)
    # assert that var_0 is an instance of the class
    assert isinstance(var_0, TaskData)



# Generated at 2022-06-25 08:40:53.585385
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData('t_wNkH', 'A7N8c9Y', 'pzBL', 'HdVb', 'nKw')
    assert task_data_0.add_host(HostData('4bD_', '2QW', 'include', 'iHw')) == None


# Generated at 2022-06-25 08:40:58.004464
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -16.9
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(float_0)
    print(var_0)


# Generated at 2022-06-25 08:41:01.317246
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    # Class instance
    task_data_0 = TaskData('', '', '', '', '')
    # Class instance
    host_0 = HostData('', '', '', '')
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:41:10.880555
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    str_0 = '(]!K@'
    result_1 = test_TaskData_add_host_0(str_0, callback_module_0)
    assert result_1 == '(]!K@'


# Generated at 2022-06-25 08:41:18.530944
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 08:41:23.027939
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Set callback for TaskData
    TaskData.add_host(callback_TaskData_add_host)
    float_0 = -1118.10
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_stats(float_0)



# Generated at 2022-06-25 08:41:25.518308
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    float_1 = float_0
    var_0 = callback_v2_playbook_on_start(float_0, callback_module_0)
    assert_equals(var_0, float_1)


# Generated at 2022-06-25 08:41:27.955565
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:41:30.794224
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    test_case_0()


# Generated at 2022-06-25 08:41:34.162266
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = TaskData(float_0, callback_module_0, callback_module_0)



# Generated at 2022-06-25 08:41:39.042138
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(float_0, True)


# Generated at 2022-06-25 08:41:46.751274
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    TaskData_0 = TaskData(float_0, float_0, float_0, float_0, float_0)
    dict_0 = dict()
    str_0 = str()
    str_1 = str()
    dict_0['uuid'] = str_0
    dict_0['name'] = str_1
    dict_0['status'] = str()
    dict_0['result'] = dict_0
    HostData_0 = HostData(dict_0)
    TaskData_0.add_host(HostData_0)


# Generated at 2022-06-25 08:41:50.032675
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData()
    host_0 = HostData()
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:41:59.362486
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print('Testing add_host')
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_stats(float_0)



# Generated at 2022-06-25 08:42:08.799954
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(float_0, callback_module_0.path, callback_module_0.name, callback_module_0.play, callback_module_0.action)
    host_data_0 = HostData(float_0, task_data_0.name, task_data_0.status, task_data_0.host_data)
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:42:14.875634
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)

test_case_0()

# Generated at 2022-06-25 08:42:17.498262
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:42:20.685757
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()


# Generated at 2022-06-25 08:42:28.411880
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -1.8042049331804774E+308
    str_0 = "7"
    str_1 = "z&XD;K6_lU6C,:*.7~2L-BD+=!fI,^>"
    str_2 = "~S;,R.VL0v:yV7L-=F4uW%[8*v"
    str_3 = "rNg-]iNvq:z$H=A@l]|bj*"
    str_4 = "QX=~s,W*m8:mK- >.Y"
    str_5 = "R[#Zv%0<|{M;9Ht!-3dG_wYg$h(z"
    float_1 = -1.60689952329908

# Generated at 2022-06-25 08:42:30.567428
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:42:32.618561
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -7084.61
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:42:34.442094
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(float_0)


# Generated at 2022-06-25 08:42:41.352389
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -2.8
    TaskData_0 = TaskData(float_0, float_0, float_0, float_0, float_0)
    callback_module_0 = CallbackModule()
    var_0 = TaskData_0.add_host(callback_module_0)


# Generated at 2022-06-25 08:43:12.212049
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    host_0 = HostData()
    task_data_0 = TaskData(float_0, host_0)
    callback_module_0 = CallbackModule()
    var_0 = task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:43:17.893549
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 6970.22
    callback_module_0 = CallbackModule()
    var_1 = callback_module_0.TaskData(float_0)
    float_1 = 3201.30
    float_2 = 9713.79
    float_3 = 6897.54
    float_4 = 7071.34
    test_case_0 = callback_module_0.HostData(float_1, float_2, float_3, float_4)
    if var_1 == None:
        assert False, 'the host data should be not None'


# Generated at 2022-06-25 08:43:25.816200
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -5.5601
    task_data_0 = TaskData('', '', float_0, float_0, float_0)
    task_data_1 = task_data_0
    host_data_0 = HostData('', '', '', '')
    task_data_1.add_host(host_data_0)

#Unit test for method start of class TaskData

# Generated at 2022-06-25 08:43:30.632488
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test setup

    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    # The following call will fail an assertion
    # if the start method of the callback module class throws an exception
    try:
        callback_module_0.v2_playbook_on_start(float_0)
    except:
        assert False


# Generated at 2022-06-25 08:43:32.379616
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    TaskData_0 = TaskData()
    HostData_0 = HostData()
    TaskData_0.add_host(HostData_0)


# Generated at 2022-06-25 08:43:35.570662
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_0 = playbook()
    callback_module_0 = CallbackModule()

    # Call method v2_playbook_on_start of callback_module_0
    callback_v2_playbook_on_start(playbook_0)

    # Assertions
    assert(callback_module_0._playbook_name == 'random_name')


# Generated at 2022-06-25 08:43:40.501069
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_0 = HostData(float_0, str_0, str_1, result_0)
    var_0 = task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:43:47.532706
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -5061.26
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(float_0)
    assert var_0 is None and callback_module_0._task_data == {}, 'test_CallbackModule_v2_runner_on_failed %s %s' % (var_0,callback_module_0._task_data)


# Generated at 2022-06-25 08:43:50.802367
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -3193.32
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData()
    host_0 = HostData()
    task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:43:55.537731
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert CallbackModule().v2_playbook_on_start('Playbook')._playbook_path == 'Playbook'


# Generated at 2022-06-25 08:44:33.007891
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    
    # Call method v2_playbook_on_start
    callback_v2_playbook_on_start(callback_module_0)


# Generated at 2022-06-25 08:44:38.456523
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    v2_runner_on_failed_0_result =  V2RunnerResult()
    v2_runner_on_failed_0_ignore_errors = False
    callback_module_v2_runner_on_failed(callback_module_0, v2_runner_on_failed_0_result, v2_runner_on_failed_0_ignore_errors)


# Generated at 2022-06-25 08:44:44.898653
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = callback_create_task_data(callback_module_0)
    host_data_0 = callback_create_host_data(callback_module_0)
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:44:51.501106
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # From: ansible/plugins/callback/juni.py::TaskData::add_host
    # Hint: The internal implementation of this method is subject to change in a future release. You should only use it directly in order to preserve backwards compatibility when the method's implementation is changed.
    pass


# Generated at 2022-06-25 08:44:58.717856
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    print('Test v2_playbook_on_start of CallbackModule start')
    test_playbook = Playbook()
    callback_module_0 = CallbackModule()
    callback_v2_playbook_on_start(callback_module_0, test_playbook)
    print('Test v2_playbook_on_start of CallbackModule done')



# Generated at 2022-06-25 08:45:04.844771
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Setup
    callback_module_0 = CallbackModule()

    # Preconditions:
    # Setup
    callback_v2_playbook_on_start(callback_module_0)
    callback_v2_playbook_on_play_start(callback_module_0)
    callback_v2_playbook_on_task_start(callback_module_0)
    callback_v2_runner_on_no_hosts(callback_module_0)
    callback_v2_playbook_on_stats(callback_module_0)

    # Preconditions:
    # Setup
    callback_v2_playbook_on_start(callback_module_0)
    callback_v2_playbook_on_play_start(callback_module_0)
    callback_v2_playbook_on_task_

# Generated at 2022-06-25 08:45:10.540725
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    var_2 = AnsiblePlaybook('')
    var_3 = callback_v2_playbook_on_start(callback_module_1, var_2)


# Generated at 2022-06-25 08:45:12.261230
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0.test_case_0()
    print('test_TaskData_add_host finished')


# Generated at 2022-06-25 08:45:24.886576
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    var_0 = CallbackModule()
    var_1 = Playbook(file_name = "/home/ansible/ansible/lib/ansible/playbook/__init__.py", loader = None, variable_manager = None, options = MagicMock(), passwords = None, inventory = None, subset = None)
    var_2 = var_0.v2_playbook_on_start(var_1)
    assert var_2 == None, "Value for variable '_playbook_name' does not match expected value"
    assert var_0._playbook_name == "__init__", "Value for variable '_playbook_name' does not match expected value"

# Generated at 2022-06-25 08:45:33.805041
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()