

# Generated at 2022-06-25 08:36:12.584647
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    return


# Generated at 2022-06-25 08:36:23.147744
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    #Initialization of TaskData object
    test_case_data_0.add_host()
    #Initialization of HostData object
    test_case_data_1.add_host()
    #Initialization of HostData object
    test_case_data_2.add_host()
    #Initialization of str object
    test_case_data_3 = 'failed'
    #Actual Test
    #Checking if it raises 'Exception' with test_case_data_3 as input to method 'add_host'
    with pytest.raises(Exception):
        test_case_data_0.add_host(test_case_data_3)


# Generated at 2022-06-25 08:36:30.404809
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._play_name = 'play_name'
    callback_module_0._playbook_name = 'playbook_name'
    callback_module_0._playbook_path = 'playbook_path'
    callback_module_0._task_relative_path = ''
    callback_module_0._task_data = {}
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_0 = HostData('uuid', 'name', '', None)
    callback_module_0._task_data['uuid'] = task_data_0
    callback_module_0._task_data['uuid'].start = time.time()


# Generated at 2022-06-25 08:36:34.823736
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = "result"
    ignore_errors = True
    callback_module_0.v2_runner_on_failed(result,ignore_errors) # On failed should record the output as 'failed'


# Generated at 2022-06-25 08:36:39.143952
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = None
    callback_module_0 = CallbackModule()
    ret_val_0 = callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:36:41.127812
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()
    test_case_0()


# Generated at 2022-06-25 08:36:47.778235
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._start_task('task_name')
    callback_module_0.v2_runner_on_ok('result')
    callback_module_0.v2_runner_on_ok('result')



# Generated at 2022-06-25 08:36:49.940460
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook=None)
    assert callback_module_0._playbook_name == "test_callback_module"


# Generated at 2022-06-25 08:36:51.568481
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_0 = mock.Mock()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:36:54.797610
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(None, None, None, None, None)
    host_data_0 = HostData(None, None, None, None)
    try:
        task_data_0.add_host(host_data_0)
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-25 08:37:13.856157
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:37:23.145652
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create a test object of class Playbook
    test_object_0 = Playbook()
    # Create a test object of class CallbackModule
    test_object_1 = CallbackModule()
    # Call method v2_playbook_on_start of class CallbackModule with argument test_object_0
    test_object_1.v2_playbook_on_start(test_object_0)
    assert isinstance(test_object_1._playbook_path, str)
    assert test_object_1._playbook_path == test_object_0._file_name
    assert isinstance(test_object_1._playbook_name, str)
    assert test_object_1._playbook_name == os.path.splitext(os.path.basename(test_object_1._playbook_path))[0]

# Generated at 2022-06-25 08:37:29.233049
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)

    # check for expected attribute values
    assert callback_module_0._playbook_path == 'test_playbook.yml'
    assert callback_module_0._playbook_name == 'test_playbook'


# Generated at 2022-06-25 08:37:33.767383
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    class_0 = getattr(playbook,"Playbook")
    class_0_clone = class_0()
    callback_module_0.v2_playbook_on_start(class_0_clone)
    assert callback_module_0._playbook_path == class_0_clone._file_name


# Generated at 2022-06-25 08:37:40.839151
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0._generate_report.return_value = 'return'
    ret_0 = callback_module_0.v2_playbook_on_start(playbook_0)
    assert ret_0 == None


# Generated at 2022-06-25 08:37:44.506265
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = 0
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)

    # Test with good parameter
    # Test with bad parameter


# Generated at 2022-06-25 08:37:47.938923
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    class Mock_playbook:
        _file_name = "test/filename/testfile.yml"

    callback_module_0.v2_playbook_on_start(Mock_playbook())
    test_case_0()


# Generated at 2022-06-25 08:37:48.469157
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass

# Generated at 2022-06-25 08:37:53.135036
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    """ test v2_playbook_on_start of class CallbackModule """

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)



# Generated at 2022-06-25 08:37:55.009704
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    assert type(callback_module) is CallbackModule



# Generated at 2022-06-25 08:38:11.286356
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    
    playbook_0 = Playbook()
    callback_module_0.v2_playbook_on_start(playbook_0)



# Generated at 2022-06-25 08:38:14.559457
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    result_0 = 'result_0'
    ignore_errors_0 = 'ignore_errors_0'
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:38:26.001057
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    playbook = '/home/shubham/Documents/ansible/roles/monitor_up_time/tasks/main.yml'

    play = Play.load(playbook, variable_manager=VariableManager(), loader=loader)
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])

    callback_module_0.v2_playbook_on_start(play)


# Generated at 2022-06-25 08:38:29.559390
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:38:33.159979
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(1, "", "", "", "")
    host_data_0 = HostData("")


# Generated at 2022-06-25 08:38:37.548912
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0.setUp()
    uuid_1 = ''
    name_2 = ''
    path_3 = ''
    play_4 = ''
    action_5 = ''
    task_data_0 = TaskData(uuid_1, name_2, path_3, play_4, action_5)
    host_6 = ''
    task_data_0.add_host(host_6)


# Generated at 2022-06-25 08:38:41.558270
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Mock()
    callback_module_0.v2_playbook_on_start(playbook_0)



# Generated at 2022-06-25 08:38:48.992287
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 = HostData('uuid_1', 'name_1', 'status_1', 'result_1')
    task_data_0.add_host(host_data_0)
    assert task_data_0.host_data['uuid_1'] == host_data_0, "Assertion failed"


# Generated at 2022-06-25 08:38:56.164814
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host_0 = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:38:59.028990
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    ignore_errors_0 = True
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:39:21.366477
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_input = ["test_case_0"]
    for test_val in test_input:
        assert test_val


# Generated at 2022-06-25 08:39:24.784420
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Mock()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:39:26.722058
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = None  # placeholder
    callback_module_0.v2_playbook_on_start(playbook=playbook_0)
    # No output


# Generated at 2022-06-25 08:39:35.769553
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    ignore_errors_0 = True
    # TODO: Replace call to deprecated function w/ actual implementation
    try:
        callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)
    except TypeError as e:
        if str(e) == 'v2_runner_on_failed() missing 1 required positional argument: \'result\'':
            raise AssertionError('Incorrect number of parameters passed to v2_runner_on_failed().')
        else:
            raise e



# Generated at 2022-06-25 08:39:42.180863
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert callback_module_0.v2_playbook_on_include == task_data_0.v2_playbook_on_include, 'Method v2_playbook_on_include of class TaskData mismatch'
    assert callback_module_0.v2_playbook_on_play_start == task_data_0.v2_playbook_on_play_start, 'Method v2_playbook_on_play_start of class TaskData mismatch'
    assert callback_module_0.v2_playbook_on_handler_task_start == task_data_0.v2_playbook_on_handler_task_start, 'Method v2_playbook_on_handler_task_start of class TaskData mismatch'
    assert callback_module_0.v2_playbook_on_task_start == task_data_0

# Generated at 2022-06-25 08:39:45.788815
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.plugins.callback.junit import CallbackModule
    callback_module_1 = CallbackModule()
    result_2 = None 
    callback_module_1.v2_runner_on_failed(result_2)
    
    print('Tests Finished')



# Generated at 2022-06-25 08:39:56.158406
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 = HostData('uuid_0', 'name_0', 'ok', 'result_1_0')
    # test raise exception
    try:
        task_data_0.add_host(host_data_0)
        task_data_0.add_host(host_data_0)
    except Exception:
        pass
    
    host_data_1 = HostData('uuid_1', 'name_1', 'included', 'result_1_1')
    task_data_0.add_host(host_data_1)

# Generated at 2022-06-25 08:40:03.082014
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    test_TaskData = TaskData("c20b9f4b-49bd-4dc4-88c1-2d3b8c397f3a", "test_name", "test_path", "test_play", "test_action")
    test_HostData = HostData("f97a097d-9f3a-4990-80e3-f5c5e5e5b5c5", "test_host", "ok", "test_result")
    test_TaskData.add_host(test_HostData)
    assert test_TaskData.host_data["f97a097d-9f3a-4990-80e3-f5c5e5e5b5c5"] == test_HostData


# Generated at 2022-06-25 08:40:03.761473
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()


# Generated at 2022-06-25 08:40:04.926964
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start()


# Generated at 2022-06-25 08:40:30.383875
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    result_0 = TaskData({}, )
    result_1 = TaskData({}, )
    result_2 = TaskData({}, )
    result_3 = TaskData({}, )
    result_4 = TaskData({}, )
    result_5 = TaskData({}, )
    result_6 = TaskData({}, )
    result_7 = TaskData({}, )
    result_8 = TaskData({}, )
    result_9 = TaskData({}, )
    result_10 = TaskData({}, )
    result_11 = TaskData({}, )
    result_12 = TaskData({}, )
    result_13 = TaskData({}, )
    result_14 = TaskData({}, )
    result_15 = TaskData({}, )
    result_16 = TaskData({}, )
    result_17 = TaskData({}, )
   

# Generated at 2022-06-25 08:40:37.777087
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_task_start(task, host)
    callback_module_1.v2_runner_on_ok(result)
    callback_module_1.v2_runner_on_failed(result, ignore_errors)
    callback_module_1.v2_runner_on_skipped(result)
    callback_module_1.v2_playbook_on_include(included_file)
    callback_module_1.v2_playbook_on_stats(stats)
    callback_module_1._start_task(task)
    task_data_0 = TaskData(uuid, name, path, play, action)
    host_0 = HostData(uuid, name, status, result)
    task_data

# Generated at 2022-06-25 08:40:40.994121
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('', '', '', '', '')
    host_data = HostData('', '', '', '')
    task_data.add_host(host_data)


# Generated at 2022-06-25 08:40:48.067596
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_path == './test/test_callback_module.py'
    assert callback_module_0._playbook_name == 'test_callback_module'


# Generated at 2022-06-25 08:40:50.121881
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = {}
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:00.393710
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    HostData = callback_module_0.HostData('host_uuid', 'host_name', 'status', 'result_')
    TaskData_0 = callback_module_0.TaskData('host_uuid', 'host_name', 'path', 'play', 'action')
    try:
        TaskData_0.add_host(HostData)
    except:
        pass


if __name__ == "__main__":
    test_TaskData_add_host()
    test_case_0()

# Generated at 2022-06-25 08:41:04.352908
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    with pytest.raises(Exception) as e_info:
        TaskData(uuid, name, path, play, action).add_host(host)


# Generated at 2022-06-25 08:41:09.669833
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    callback_module_0 = CallbackModule()

    # Testing the argument - playbook
    class test_playbookClass():
      def __init__(self):
        self._file_name = 'test.yml'
    test_playbook_0 = test_playbookClass()

    # Testing
    callback_module_0.v2_playbook_on_start(test_playbook_0)

    # Verification
    assert callback_module_0._playbook_name == 'test'

    # Cleanup - N/A


# Generated at 2022-06-25 08:41:12.564472
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook0 = Playbook()
    playbook0._file_name = 'junit.log'
    instance = CallbackModule()
    instance.v2_playbook_on_start(playbook0)


# Generated at 2022-06-25 08:41:23.657539
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    '''
    Unit test for method v2_playbook_on_start of class CallbackModule
    '''
    callback_module_0 = CallbackModule()
    assert hasattr(callback_module_0, 'v2_playbook_on_start')
    assert callable(getattr(callback_module_0, 'v2_playbook_on_start'))
    playbook_1 = object()
    try:
        callback_module_0.v2_playbook_on_start(playbook_1)
    except:
        pass


# Generated at 2022-06-25 08:41:58.453569
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1.TaskData._TaskData__name = "name"
    callback_module_1.TaskData._TaskData__play = "play"
    callback_module_1.TaskData._TaskData__uuid = "uuid"
    callback_module_1.TaskData._TaskData__path = "path"
    callback_module_1.TaskData._TaskData__host_data = "host_data"
    callback_module_1.TaskData._TaskData__action = "action"

    try:
        callback_module_1.TaskData.add_host("host")
    except Exception as e:
        print(e)


# Generated at 2022-06-25 08:42:04.087483
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Mock('ansible.playbook.Playbook.Playbook')
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:42:08.361199
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    assert callable(getattr(callback_module_0, 'v2_runner_on_failed', None))


# Generated at 2022-06-25 08:42:10.251637
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:42:14.379489
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:42:18.076040
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_TaskData_add_host_0()
    test_TaskData_add_host_1()
    test_TaskData_add_host_2()
    test_TaskData_add_host_3()



# Generated at 2022-06-25 08:42:24.256659
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(None, '', '', '', None)
    host_data_0 = HostData(None, None, None, None)
    try:
        task_data_0.add_host(host_data_0)
    except Exception as exception:
        print('Exception: ' + str(exception))



# Generated at 2022-06-25 08:42:28.096703
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Test for method v2_runner_on_failed(self, result, ignore_errors=False)
    # Test error reporting
    try:
        raise Exception('foo')
    except Exception:
        result = Exception
        result = result(result)
        callback_module_0.v2_runner_on_failed(result, True)


# Generated at 2022-06-25 08:42:30.003110
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    playbook = 'playbook'
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:42:31.542988
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:43:49.095833
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook = mock()
    playbook._file_name = "file_name"
    callback_module_0.v2_playbook_on_start(playbook)
    assert "file_name" == callback_module_0._playbook_path
    assert "file_name" == callback_module_0._playbook_name


# Generated at 2022-06-25 08:43:51.630756
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = object()

    # Call method
    callback_module_0.v2_playbook_on_start(playbook = playbook_0)



# Generated at 2022-06-25 08:43:56.479506
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module._start_task(task)
    callback_module.v2_runner_on_failed(result, ignore_errors)
    assert True



# Generated at 2022-06-25 08:44:04.127088
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_1 = TaskData('uuid','name','path','play','action')
    host_data_0 = HostData('uuid','name','status','result')
    try:
        task_data_1.add_host('host')
        print('FAIL')
    except Exception as e:
        print('PASS: Test Exception')
    task_data_1.add_host(host_data_0)



# Generated at 2022-06-25 08:44:15.157078
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:44:20.955567
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    from ansible import playbook
    playbook_0 = playbook.PlayBook()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:44:25.073905
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    test_passed = True
    test_msg = ""

    callback_module_0 = CallbackModule()
    #test_case_1.callback_module_0.v2_playbook_on_start(playbook_0)
    if test_passed:
        print("Test passed")
        print(test_msg)
    else:
        print("Test Failed")
        print(test_msg)


# Generated at 2022-06-25 08:44:30.406815
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print('')
    print('Testing TaskData.add_host...')
    callback_module_1 = CallbackModule()
    task_data_1 = TaskData('e2ca-8e9c-2ea0','Toggle failure','main.yml:25','MyPlay','debug')
    host_data_1 = HostData('host_uuid','host_name','status','result')
    task_data_1.add_host(host_data_1)


# Generated at 2022-06-25 08:44:34.117309
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = GetFilepath()
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(playbook)
    assert callback_module._playbook_path == playbook._file_name
    assert callback_module._playbook_name == os.path.splitext(os.path.basename(playbook._file_name))[0]


# Generated at 2022-06-25 08:44:38.574058
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    ignore_errors_0 = bool()

    # Call method v2_runner_on_failed of CallbackModule
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0=False)
