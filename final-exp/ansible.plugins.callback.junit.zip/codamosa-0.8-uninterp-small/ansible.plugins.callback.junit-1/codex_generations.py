

# Generated at 2022-06-25 08:36:26.818823
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0._playbook_name = None
    callback_module_0._playbook_path = None
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:36:28.367462
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """Test v2_runner_on_failed"""

    callback_module = CallbackModule()

    pass



# Generated at 2022-06-25 08:36:32.640771
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    host_0 = HostData(None, None, None, None)
    task_data_0 = TaskData(None, None, None, None, None)
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:36:41.837847
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 = HostData('uuid_1', 'name_1', 'status_1', 'result_1')
    try:
        task_data_0.add_host(host_data_0)
        task_data_0.add_host(host_data_0)
        assert False
    except Exception:
        assert True


# Generated at 2022-06-25 08:36:51.531861
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    callback_module_0._playbook_name = "playbook_name"
    callback_module_0._play_name = "play_name"
    callback_module_0._task_class = "true"
    callback_module_0._task_relative_path = "task_relative_path"
    callback_module_0._include_setup_tasks_in_report = "true"
    callback_module_0._hide_task_arguments = "false"
    callback_module_0._test_case_prefix = "test_case_prefix"
    callback_module_0._fail_on_change = "false"
    callback_module_0._fail_on_ignore = "false"


# Generated at 2022-06-25 08:36:54.551076
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_1 = TaskData("uuid_1","name_1","path_1","play_1","action_1")
    host_data_1 = HostData("uuid_1","name_1","status_1","result_1")
    task_data_1.add_host(host_data_1)


# Generated at 2022-06-25 08:37:07.894123
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(0, 'sample_name', 'sample_path', 'sample_play', 'sample_action')

    # Case 1: Non-duplicate host
    host = HostData(0, 'sample_name', 'sample_status', 'sample_result')
    task_data.add_host(host)
    assert task_data.host_data == {0: host}

    # Case 2: Duplicate host
    host_0 = HostData(0, 'sample_name', 'sample_status', 'sample_result')
    try:
        task_data.add_host(host_0)
        assert False
    except:
        assert True


# Generated at 2022-06-25 08:37:14.500589
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(uuid, name, path, play, action)
    assert len(task_data_0.host_data) == 0
    host = HostData(uuid, name, status, result)
    task_data_0.add_host(host)
    assert len(task_data_0.host_data) == 1


# Generated at 2022-06-25 08:37:23.485474
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Input data
    # TaskData.add_host(HostData(host_uuid, host_name, status, result))
    # host_name : name of the host
    callback_module_0 = CallbackModule()
    # Input : host_name = 'localhost.localdomain'
    host_name_0 = 'localhost.localdomain'
    # Input : host_uuid = 'host_uuid'
    host_uuid_0 = 'host_uuid'
    # Input : status = 'ok'
    status_0 = 'ok'
    # Input : result = 'example'
    result_0 = 'example'

    callback_module_0._start_task(str())
    callback_module_0._finish_task(str(), str())
    callback_module_0._build_test_case

# Generated at 2022-06-25 08:37:26.456377
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook = None
    callback_module_0.v2_playbook_on_start(playbook)



# Generated at 2022-06-25 08:37:36.208918
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    playbook = "test_play_name"
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:37:42.951504
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    try:
        task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
        if task_data_0.host_data is None:
            task_data_0.host_data = {}
        host_0 = HostData(uuid='uuid_0', name='name_0', status='included', result='result_0')
        task_data_0.add_host(host=host_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 08:37:48.870471
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    t1 = TaskData('uuid0', 'name0', 'path0', 'play0', 'action0')
    t1.add_host(HostData('host_uuid0', 'host_name0', 'host_status0', 'host_result0'))
    if t1.host_data['host_uuid0'].uuid!= 'host_uuid0':
        raise Exception('test_TaskData_add_host 1 failed')
    t1.add_host(HostData('host_uuid0', 'host_name0', 'host_status0', 'host_result0'))



# Generated at 2022-06-25 08:37:50.427572
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
  callbackModule_0 = CallbackModule()


# Generated at 2022-06-25 08:37:52.271022
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData("task_data_0", "", "", "", "ok")
    task_data_0.add_host("host_data_0")


# Generated at 2022-06-25 08:37:53.958998
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:38:02.905846
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    try:
        callback_module_0 = CallbackModule()
        host = HostData('host_uuid', 'host_name', 'ok', 'result')
        task_data = TaskData('task_uuid', 'task_name', 'path', 'play', 'action')
        task_data.add_host(host)
        print('test_TaskData_add_host')
        assert(len(task_data.host_data) == 1)
    except AssertionError as e:
        print('test_TaskData_add_host failed')


# Generated at 2022-06-25 08:38:05.632854
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    test_case = 0
    result = ""
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed(result)



# Generated at 2022-06-25 08:38:09.007441
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    playbook = Playbook
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:38:17.131521
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    callback_module_0 = CallbackModule()

    # from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    # from ansible.parsing.mod_args import ModuleArgsParser
    # from ansible.vars.manager import VariableManager
    # from ansible.inventory.manager import InventoryManager
    # from ansible.inventory.host import Host
    # from ansible.executor.playbook_executor import PlaybookExecutor
    # from ansible.plugins.loader import callback_loader

    # playbook_0 = PlaybookExecutor('tests/test_playbooks/test_playbook.yml', variable_manager, inventory_manager, loader, options, passwords)
    # callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:38:32.196891
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert test_case_0() == None


# Generated at 2022-06-25 08:38:33.586656
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:38:41.690962
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    taskdata_0 = TaskData('1', '2', '3', '4', '5')
    hostdata_0 = HostData('6', '7', '8', '9')
    taskdata_0.add_host(hostdata_0)


# Generated at 2022-06-25 08:38:43.439215
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('playbook')


# Generated at 2022-06-25 08:38:46.331390
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = MockPlaybook()

    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:38:48.737822
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    for case in test_case_0:
        callback_module_0 = test_case_0[case]
        callback_module_0.v2_playbook_on_start(playbook)
        pass


# Generated at 2022-06-25 08:38:55.972414
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # TODO: create fake result, task and ignore_errors parameters
    result = None
    task = None
    ignore_errors=False
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:39:00.897729
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = MockPlaybook(callback_module_0)
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_path in playbook_0._file_name
    assert callback_module_0._playbook_name in os.path.splitext(os.path.basename(callback_module_0._playbook_path))[0]


# Generated at 2022-06-25 08:39:09.294589
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    # Setup
    task_data_0 = TaskData(callback_module_0.v2_runner_on_no_hosts(callback_module_0.v2_playbook_on_task_start(callback_module_0.v2_playbook_on_play_start(callback_module_0.v2_playbook_on_start(callback_module_0._playbook_path)), callback_module_0._playbook_path)), '', '', '', '')

# Generated at 2022-06-25 08:39:12.399727
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_value = mock()
    ignore_errors_value = false
    callback_module_0.v2_runner_on_failed(result_value, ignore_errors_value)


# Generated at 2022-06-25 08:39:28.255340
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start("")


# Generated at 2022-06-25 08:39:38.981105
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_uuid_0 = 'e6b8e6b7-25bb-4dc4-ace4-b4a9e9c2d2a0'
    name_0 = 'Create file /tmp/example with some content.'
    path_0 = 'example_playbook.yml'
    play_0 = 'Main play'
    action_0 = 'command'
    task_data_0 = TaskData(task_uuid_0, name_0, path_0, play_0, action_0)
    host_uuid_0 = '192.168.0.13'
    host_name_0 = '192.168.0.13'
    status_0 = 'ok'
    result_0 = 'result_0'
    host_data_

# Generated at 2022-06-25 08:39:40.284125
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print('Test: v2_runner_on_failed')
    assert False == False


# Generated at 2022-06-25 08:39:42.152151
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Mock()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:39:45.287587
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    taskData_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
    hostData_0 = HostData(uuid='uuid_1', name='name_1', status='ok', result=None)
    taskData_0.add_host(hostData_0)


# Generated at 2022-06-25 08:39:51.122090
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    from ansible import playbook
    from ansible import inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible import context
    from ansible.utils.display import Display
    from copy import deepcopy

    display = Display()
    loader = DataLoader()
    passwords = dict(vault_pass='secret')
    inventory = inventory.Inventory(loader=loader, variable_manager=inventory.VariableManager(), host_list='localhost')
    variable_manager = inventory.get_variable_manager()

    display.verbosity = 3
    all_vars = variable_manager.get_vars(loader=loader, play=playbook.Play().load(loader=loader, variable_manager=variable_manager, file_name='test.yml'))


# Generated at 2022-06-25 08:39:53.514503
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook()
    callback_module_0.v2_playbook_on_start(playbook_0)
# END UNIT TEST


# Generated at 2022-06-25 08:40:01.330318
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')

    host_data_0 = HostData('uuid', 'name', 'ok')
    host_data_1 = HostData('uuid', 'name', 'ok')

    task_data_0.add_host(host_data_0)
    task_data_0.add_host(host_data_1)

    if task_data_0.host_data[host_data_0.uuid].result != 'uuid: name: ok: duplicate host callback: name':
        raise Exception('task_data_0.host_data[host_data_0.uuid].result != \'uuid: name: ok: duplicate host callback: name\'')



# Generated at 2022-06-25 08:40:09.807110
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0.host_data = []
    callback_module_0.host_data.append(obj = HostData(host_uuid = '', host_name = '', status = '', result = None))
    callback_module_0.add_host(host = callback_module_0.host_data)


# Generated at 2022-06-25 08:40:20.373969
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    callback_module_0 = CallbackModule()
    callback_module_0._playbook_path = None
    callback_module_0._playbook_name = None
    playbook_0 = 'scenario_yaml_1'
    try:
        # Act
        callback_module_0.v2_playbook_on_start(playbook=playbook_0)
        # Assert
        assert callback_module_0._playbook_path == 'scenario_yaml_1'
        assert callback_module_0._playbook_name == 'scenario_yaml_1'
    except Exception as error:
        # Assert
        assert False
    finally:
        # Arrange
        callback_module_0 = None


# Generated at 2022-06-25 08:40:55.520909
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.disabled = False
    callback_module_0._output_dir = None
    callback_module_0._task_class = "False"
    callback_module_0._task_relative_path = ""
    callback_module_0._fail_on_change = "False"
    callback_module_0._fail_on_ignore = "False"
    callback_module_0._include_setup_tasks_in_report = "True"
    callback_module_0._hide_task_arguments = "False"
    callback_module_0._test_case_prefix = ""
    callback_module_0._playbook_path = "hosts.yml"
    callback_module_0._playbook_name = "hosts"
    callback_module_0._

# Generated at 2022-06-25 08:41:01.198150
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData('TaskData', 'TaskData', 'TaskData', 'TaskData', 'TaskData')
    host_data_0 = HostData('HostData', 'HostData', 'HostData', 'HostData')
    try:
        task_data_0.add_host(host_data_0)
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-25 08:41:03.967390
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0._finish_task();




# Generated at 2022-06-25 08:41:06.453431
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = 'string'
    result = callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:15.235993
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()

    # Set parameter `result` to a valid ansible.parsing.dataloader.DataLoader object
    # Set parameter `task` to a valid ansible.playbook.task.Task object
    # Set parameter `play` to a valid ansible.playbook.play.Play object
    # Set parameter `playbook` to a valid ansible.playbook.play.Playbook object
    # Execute method v2_playbook_on_start of class CallbackModule with parameter `playbook`
    callback_module_1.v2_playbook_on_start(playbook=None)


# Generated at 2022-06-25 08:41:25.566464
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("Testing TaskData.add_host")
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_1', 'path_2', 'play_3', 'action_4')
    host_data_0 = HostData('uuid_5', 'name_6', 'ok', 'result_8')
    host_data_0.result = 'result_8'
    host_data_0.status = 'ok'
    host_data_0.name = 'name_6'
    host_data_0.uuid = 'uuid_5'
    task_data_0.add_host(host_data_0)
    assert task_data_0.host_data["uuid_5"].result == "result_8"
    assert task_data_

# Generated at 2022-06-25 08:41:27.473825
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:41:31.357860
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    test_playbook_0 = Play(playbook=playbook._playbook)
    callback_module_0.v2_playbook_on_start(test_playbook_0)

# Generated at 2022-06-25 08:41:33.424305
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_0 = False
    callback_module_1.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:39.214905
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = v2_runner_result()
    ignore_errors = bool()
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors)


# Generated at 2022-06-25 08:42:52.123159
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    Ensure that the v2_runner_on_failed method produces the expected results when the callback module is invoked from the ansible-playbook command
    """
    
    # Create a callback module with the JUnit environment variables set for the unit test
    callback_module_0 = CallbackModule()
    os.environ['JUNIT_OUTPUT_DIR'] = "."
    os.environ['JUNIT_FAIL_ON_IGNORE'] = "False"
    os.environ['JUNIT_FAIL_ON_CHANGE'] = "False"
    os.environ['JUNIT_TASK_CLASS'] = "True"
    os.environ['JUNIT_INCLUDE_SETUP_TASKS_IN_REPORT'] = "True"

# Generated at 2022-06-25 08:42:56.640591
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    file_name = File("/home/ec2-user/ansible/playbooks/ansible_playbook.yml")
    callback_module_0.v2_playbook_on_start(file_name)
    assert callback_module_0._playbook_path == file_name._file_name


# Generated at 2022-06-25 08:42:59.559843
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_0 = {}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)

    assert callback_module_0.v2_playbook_on_start == callback_module_0.v2_playbook_on_start


# Generated at 2022-06-25 08:43:03.299525
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = object()

    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:43:11.403671
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:43:17.082910
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    from unittest import mock
    from unittest import TestCase
    # Mock of class TaskData
    task_data_0 = mock.MagicMock(name='TaskData')
    # Mock of HostData
    host_data_0 = mock.MagicMock(name='HostData')
    # Mock of method __init__ of class TaskData
    mock_init_0 = mock.MagicMock(name='__init__')
    mock_init_0.return_value = None
    # Mock of method __init__ of class HostData
    mock_init_1 = mock.MagicMock(name='__init__')
    mock_init_1.return_value = None
    # Create mock object of class TaskData

# Generated at 2022-06-25 08:43:22.154418
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    c = CallbackModule()
    c._fail_on_ignore = 'False'

    class task:
        _uuid = "123"

    class result:
        _task = task
        _host = 'host'
        _result = {'msg': "I do not exist"}
        def __init__(self):
            self.task = task

    c._start_task(task)
    c._finish_task('failed', result)
    assert len(c._task_data) == 1
    assert c._task_data[task._uuid].host_data["host"].status == 'failed'
    assert c._task_data[task._uuid].host_data["host"].result._result['msg'] == "I do not exist"

# Generated at 2022-06-25 08:43:30.439347
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = os.path.splitext(os.path.basename(os.path.realpath(__file__)))[0]
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_name == 'test_callback_junit'


# Generated at 2022-06-25 08:43:34.434915
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start("playbook")


# Generated at 2022-06-25 08:43:44.759315
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_0 = TaskData(uuid = None, name = '', path = '', play = '', action = 'setup')
    host_data_0 = HostData(uuid = '', name = '', status = 'included', result = '')
    task_data_0.add_host(host = host_data_0)
    exception_0 = Exception('%s: %s: %s: duplicate host callback: %s' % (task_data_0.path, task_data_0.play, task_data_0.name, host_data_0.name))
    with raises(Exception) as raised_0:
        task_data_0.add_host(host = host_data_0)
    assert raised_0.type == exception_0.__class

# Generated at 2022-06-25 08:45:11.415865
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = Playbook
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    pass


# Generated at 2022-06-25 08:45:16.044399
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:45:20.327940
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    print('Testing method v2_playbook_on_start...')
    callback_module_0 = CallbackModule()
    playbook = None
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:45:23.557006
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:45:29.643366
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    assert True # TODO: may fail


# Generated at 2022-06-25 08:45:35.919210
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    test_case_1 = {'_file_name': 'foo.yml'}
    callback_module_1.v2_playbook_on_start(test_case_1)
    assert callback_module_1._playbook_path is 'foo.yml'


# Generated at 2022-06-25 08:45:37.938694
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = Playbook('file_name')
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    assert callback_module_0._playbook_name == 'file_name'


# Generated at 2022-06-25 08:45:43.961213
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_1 = Playbook()
    callback_module_1.v2_playbook_on_start(playbook_1)


# Generated at 2022-06-25 08:45:55.341425
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    callback_module_0 = CallbackModule()
    playbook_0 = None

    # Act
    with patch('ansible.plugins.callback.CallbackModule._dump_results', return_value=None) as mock_CallbackModule__dump_results, patch('ansible.plugins.callback.CallbackModule._cleanse_string', return_value=None) as mock_CallbackModule__cleanse_string:
        callback_module_0.v2_playbook_on_start(playbook=playbook_0)
        assert mock_CallbackModule__dump_results.called
        assert mock_CallbackModule__cleanse_string.called


# Generated at 2022-06-25 08:46:00.767426
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    assert callback_module_0._playbook_path == None
    assert callback_module_0._playbook_name == None
    assert callback_module_0._play_name == None
    assert callback_module_0._task_data == None
    assert callback_module_0.disabled == False
    assert callback_module_0._task_data == {}

