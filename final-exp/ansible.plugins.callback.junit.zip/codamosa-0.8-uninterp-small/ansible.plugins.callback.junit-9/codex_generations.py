

# Generated at 2022-06-25 08:36:14.397548
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -1820.53
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(float_0)



# Generated at 2022-06-25 08:36:23.562679
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -1.0
    callback_module_0 = CallbackModule()
    var_0 = TaskData(float_0, "", "", "", "")
    var_1 = HostData("", "", "", "")
    var_0.add_host(var_1)
    if (var_1 is not None):
        if (var_0.host_data[""] is var_1):
            assert True
        else:
            assert False
    else:
        assert False


# Generated at 2022-06-25 08:36:27.087015
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Case 0: no failure for the task and fail_on_ignore is false
    result_0 = ''
    callback_module_0 = CallbackModule()
    var_0 = callback_module_0.v2_runner_on_failed(result_0, ignore_errors=False)


# Generated at 2022-06-25 08:36:31.252439
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -32.928
    CallbackModule_0 = CallbackModule()
    var_0 = TaskData(float_0, '', '', '', '', )
    var_1 = HostData(float_0, '', '', '')
    var_2 = var_0.add_host(var_1)


# Generated at 2022-06-25 08:36:34.190864
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -14.58
    task_data_0 = TaskData()
    host_data_0 = HostData()


# Generated at 2022-06-25 08:36:35.141779
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()


# Generated at 2022-06-25 08:36:39.506158
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    float_0 = -1820.53
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:36:43.094188
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = -1820.53
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_skipped(float_0)
    raise Exception("Unit test not implemented")


# Generated at 2022-06-25 08:36:49.315177
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -75.16
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(float_0)

    # AssertionError: CallbackModule.failed.__get__(<__main__.CallbackModule object at 0x7f15b64e6668>, CallbackModule) is expected to return TaskData, got None
    assert TaskData == var_0


# Generated at 2022-06-25 08:36:51.849104
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    float_0 = -1820.53
    bool_0 = False
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_runner_on_failed(float_0, bool_0)


# Generated at 2022-06-25 08:37:12.425011
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(None, None, None, None, None)
    host_0 = HostData(None, None, None, None)
    callback_module_0._task_relative_path = './'
    callback_module_0._task_class = 'True'
    callback_module_0._hide_task_arguments = 'False'
    callback_module_0._fail_on_ignore = 'False'
    callback_module_0._fail_on_change = 'True'
    callback_module_0._include_setup_tasks_in_report = 'False'
    callback_module_0._test_case_prefix = ''
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:37:19.200985
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = __import__('ansible.parsing.yaml.objects').parsing.yaml.objects.AnsibleMapping()
    playbook_0._file_name = tempfile.mkstemp()[1]
    callback_module_0.v2_playbook_on_start()
    assert callback_module_0._playbook_name=='tempfile'


# Generated at 2022-06-25 08:37:21.723520
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    # Test target function
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    assert callback_module_0 is not None


# Generated at 2022-06-25 08:37:33.695947
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_v2_runner_on_failed = CallbackModule()
    result = namedtuple("result", "task")
    result.result = {"_ansible_no_log": False, "changed": False, "msg": "", "invocation": {"module_args": {"a": None, "b": None, "file": "/tmp/foo", "listen": True, "debug": False, "state": "present"}, "module_name": "copy"}, "rc": 1, "stdout": ""}
    result.task = namedtuple("task", "name")
    result.task.name = "foo"
    result.task._uuid = 1
    result.task.action = "copy"
    result.task.no_log = False
    result.task.get_name = lambda: "copy"
    result.task

# Generated at 2022-06-25 08:37:38.401825
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_0 = HostData('uuid_0', 'name_0', 'status_0', 'result_0')
    task_data_0.add_host(host_0)
    host_0 = HostData('uuid_0', 'name_0', 'status_0', 'result_0')
    task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:37:44.462275
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    # Default parameter value
    args = {}

    v2_playbook_on_start_retval = callback_module.v2_playbook_on_start(**args)

    assert v2_playbook_on_start_retval is None


# Generated at 2022-06-25 08:37:46.372701
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    assert callback_module_0.__init__() != None


# Generated at 2022-06-25 08:37:50.129382
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0.test_case_1 = TaskData(1, "test_junit", "test/test_junit.py", "test_junit",
    "test_junit")
    callback_module_0.test_case_1.add_host(HostData(1, "test_junit", "", ""))


# Generated at 2022-06-25 08:37:59.422486
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    play = {'_uuid': '1'}
    task = {'_uuid': '1'}
    host_data_0 = {'name': '1'}
    host_data_1 = {'name': '2'}
    host_data_2 = {'name': '3'}
    host_data_3 = {'name': '4'}
    host_data_4 = {'name': '5'}
    host_data_5 = {'name': '6'}
    host_data_6 = {'name': '7'}
    host_data_7 = {'name': '8'}


# Generated at 2022-06-25 08:38:00.538987
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert True


# Generated at 2022-06-25 08:38:12.871139
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = {'_file_name': 'test.txt'}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    assert callback_module_0._playbook_path == 'test.txt'
    assert callback_module_0._playbook_name == 'test'


# Generated at 2022-06-25 08:38:26.001175
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._test_case_prefix = 'test'
    callback_module_0._fail_on_ignore = 'false'
    callback_module_0._task_class = 'false'
    callback_module_0._task_relative_path = 'false'
    callback_module_0._task_class = 'false'
    callback_module_0._fail_on_change = 'true'
    callback_module_0._task_class = 'false'
    callback_module_0._fail_on_ignore = 'true'
    callback_module_0._task_relative_path = 'true'
    callback_module_0._task_relative_path = 'false'
    callback_module_0._task_class = 'false'
    callback_module_0._task

# Generated at 2022-06-25 08:38:29.267985
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result = result()
    ignore_errors = False
    callback_module_1.v2_runner_on_failed(result, ignore_errors)
    assert res._result['failed'] == 0


# Generated at 2022-06-25 08:38:33.225635
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    
    # Create test object
    callback_module_1 = CallbackModule()
    
    # Create test object
    playbook_2 = data_model.Playbook()
    
    # Call method
    result = callback_module_1.v2_playbook_on_start(playbook_2)

    # Assert expected result
    assert result == None


# Generated at 2022-06-25 08:38:41.203767
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    class Playbook:
        def _file_name():
            return 'playbook'
    callback_module.v2_playbook_on_start(Playbook())
    assert callback_module._playbook_path == 'playbook'


# Generated at 2022-06-25 08:38:44.423562
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    callback_module = CallbackModule()
    result = RunnerResult(host=HostResult(host=Host(), runner=Runner(), task=Task(), task_result=TaskResult()), result=dict())
    callback_module.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:38:48.282883
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    callback_module_0 = CallbackModule()
    playbook_0 = 1

    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:38:51.312030
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    task = None
    result = None
    ignore_errors = False
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:38:55.970951
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    # Place your implementation of test here
    # I just assert the class has the method
    assert hasattr(callback_module_0, 'v2_playbook_on_start')



# Generated at 2022-06-25 08:38:57.902724
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callbackModule = CallbackModule()
    playBook = object()
    callbackModule.v2_playbook_on_start(playBook)


# Generated at 2022-06-25 08:39:09.861908
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert CallbackModule().v2_runner_on_failed(None, None) # throw exception if any error happens


# Generated at 2022-06-25 08:39:13.067637
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    # TODO: create a mock object for class 'Result'
    result_2 = Result(None)
    ignore_errors_3 = None
    callback_module_1._finish_task('failed', result_2)


# Generated at 2022-06-25 08:39:16.224745
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = MockObject()
    playbook._file_name = "string"
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:39:27.861250
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # test 1
    # case that we have no host
    callback_module_1 = CallbackModule()
    callback_module_1.start = time.time()
    callback_module_1.add_host(HostData('hostname'))
    assert callback_module_1.host_data['hostname'].status == 'ok'
    
    # test 2
    # case that we have repeated host
    callback_module_2 = CallbackModule()
    callback_module_2.start = time.time()
    callback_module_2.add_host(HostData('hostname'))
    callback_module_2.add_host(HostData('hostname'))
    assert callback_module_2.host_data['hostname'].status == 'ok'


# Generated at 2022-06-25 08:39:38.616461
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._task_relative_path = 'yaml'
    callback_module_0._task_class = 'True'
    callback_module_0._fail_on_change = 'True'
    callback_module_0._fail_on_ignore = 'True'
    callback_module_0._include_setup_tasks_in_report = 'False'
    callback_module_0._hide_task_arguments = 'False'
    callback_module_0._test_case_prefix = ''
    callback_module_0._playbook_path = 'test/test_playbook.yml'
    callback_module_0._playbook_name = 'test_playbook'
    callback_module_0._play_name = 'play name'
    callback_module_0

# Generated at 2022-06-25 08:39:40.284420
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # FIXME: no test case to run
    # FIXME: unit tests are missing on a lot of callbacks
    pass


# Generated at 2022-06-25 08:39:41.095287
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_playbook = An

# Generated at 2022-06-25 08:39:49.715942
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    uuid_0 = 'abc'
    name_0 = 'abc'
    path_0 = 'abc'
    play_0 = 'abc'
    action_0 = 'abc'
    task_data_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)
    host_uuid_0 = 'abc'
    host_name_0 = 'abc'
    status_0 = 'abc'
    result_0 = 'abc'
    host_0 = HostData(host_uuid_0, host_name_0, status_0, result_0)
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:39:51.356567
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed(result={'foo':'bar', 'baz':'qux'}, ignore_errors=False)


# Generated at 2022-06-25 08:39:54.085474
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    result = mockresult
    ignore_errors = True

    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:40:17.475024
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """Check that an Exception is raised if there are duplicate hosts."""
    callback_module_1 = CallbackModule()
    task_data_0 = TaskData('7c895b1c69c346f18b625ac2395f491c', 'test_name', 'test_path', 'test_play', 'test_action')
    host_data_0 = HostData('test_uuid', 'test_name', 'test_status', 'test_result')
    with pytest.raises(Exception):
        task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:40:27.626885
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    # Setup
    callback_module_1 = CallbackModule()
    playbook_0 = b'\x8F\xB0u\x0E'


    # Invocation
    result = callback_module_1.v2_playbook_on_start(playbook_0)

    # Verification
    assert result == None



# Generated at 2022-06-25 08:40:33.008347
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_v2_playbook_on_start_playbook = '/home/marko/.ansible/roles/ansible-role-junit/tests/fixtures/test_playbook.yml'
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(callback_module_v2_playbook_on_start_playbook)
    actual = callback_module._playbook_name
    #assert actual == 'test_playbook'


# Generated at 2022-06-25 08:40:36.548790
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_v2_playbook_on_start_0 = CallbackModule() # class: CallbackModule
    arg0 = None # type: Playbook
    callback_module_v2_playbook_on_start_0.v2_playbook_on_start(arg0)


# Generated at 2022-06-25 08:40:38.870101
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_0 = Playbook()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:40:46.538537
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = result_1 = result_2 = None

# Generated at 2022-06-25 08:41:00.062985
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    class TaskData_0(object):
        def __init__(self, uuid, name, path, play, action):
            self.uuid = uuid
            self.name = name
            self.path = path
            self.play = play
            self.start = None
            self.host_data = {}
            self.start = time.time()
            self.action = action
    class HostData_0(object):
        def __init__(self, uuid, name, status, result):
            self.uuid = uuid
            self.name = name
            self.status = status
            self.result = result
            self.start = time.time()
            self.finish = None

# Generated at 2022-06-25 08:41:07.561640
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1._task_data = {
        '580c1d8e-c6b2-45f3-9953-d6a47c914a9a': TaskData(
            uuid = '580c1d8e-c6b2-45f3-9953-d6a47c914a9a',
            name = 'Test if ElasticSearch is reachable',
            path = 'roles/elasticsearch/tasks/test_es.yml',
            play = 'test_elasticsearch',
            action = 'STATIC',
        ),
    }

# Generated at 2022-06-25 08:41:10.695133
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
  assert True # TODO: implement your test here


# Generated at 2022-06-25 08:41:12.837740
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = {
        '_file_name': 'str'
        }
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:46.429302
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook = None
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:41:48.863486
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """
    Testcase for TaskData.add_host
    """

    callback_module_1 = CallbackModule()
    taskdata = callback_module_1._task_uuid
    host = callback_module_1.uuid
    taskdata.add_host(host)



# Generated at 2022-06-25 08:42:01.411190
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    # Test with a argument of type struct
    struct_1 = struct()

    # Test with an argument of type struct
    struct_2 = struct()
    struct_2.callback_dir = 'any string'
    struct_2.callback_name = 'any string'
    struct_2.callbacks = 'any string'
    struct_2.columns = 'any string'
    struct_2.config = 'any string'
    struct_2.display_args_to_stdout = 'any string'
    struct_2.ansible_playbook_python = 'any string'
    struct_2.action_plugins = 'any string'
    struct_2.cache_plugins = 'any string'
    struct_2.callback_plugins = 'any string'
    struct_2.connection

# Generated at 2022-06-25 08:42:04.241394
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result_0 = RunnerResult()
    obj_0 = CallbackModule()
    ignore_errors_0 = True
    obj_0.v2_runner_on_failed(result_0, ignore_errors=ignore_errors_0)


# Generated at 2022-06-25 08:42:09.524077
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    ignore_errors_0 = True
    print(callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0))

# Generated at 2022-06-25 08:42:15.163278
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.setUp()
    playbook = Playbook()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:42:21.959964
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_data_0 = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    task_data_0.add_host(host_data_0)
    assert task_data_0.host_data.get('host_uuid') == host_data_0

# Generated at 2022-06-25 08:42:24.502736
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    expected = 'failed'
    actual = callback_module.v2_runner_on_failed('failed')
    assert expected == actual


# Generated at 2022-06-25 08:42:26.295071
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    task = MockTask()
    callback_module.v2_playbook_on_task_start(task, True)
    result = MockResult()
    callback_module.v2_runner_on_failed(result, True)


# Generated at 2022-06-25 08:42:27.941646
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert (TaskData(1, 2, 3, 4, 5).add_host(HostData(1, 2, 3, 4)) == None)


# Generated at 2022-06-25 08:43:56.784347
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    playbook = Playbook()

    callback_module.v2_playbook_on_start(playbook)

    assert callback_module._playbook_path is not None
    assert callback_module._playbook_name is not None


# Generated at 2022-06-25 08:43:57.880968
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(None)


# Generated at 2022-06-25 08:44:03.721515
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid', name='name', path='path', play='play', action='action')
    host_0 = HostData(uuid='uuid', name='name', status='status', result='result')
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:44:09.319668
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print('Begin test for TaskData.add_host')
    callback_module_0 = CallbackModule()
    callback_module_0.add_host('included', '', '', 'systemout')
    print('End test for TaskData.add_host')


# Generated at 2022-06-25 08:44:11.437865
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data = TaskData('1.252.255.126', '', '', '', 'setup')
    assert task_data.action == 'setup'


# Generated at 2022-06-25 08:44:15.839254
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Add your test inputs here
    result_1 = 'some result'
    ignore_errors_1 = False

    callback_module_0.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:44:22.967963
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print ('Unit test for method v2_runner_on_failed of class CallbackModule')
    callback_module_0 = CallbackModule()
    result_0 = {}
    ignore_errors_0 = bool
    try:
        callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)
    except:
        pass


# Generated at 2022-06-25 08:44:30.458076
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """

    """

    callback_module_1 = CallbackModule()
    task_data_1 = callback_module_1.TaskData()
    callback_module_1.task_data = {'first': task_data_1}
    host_1 = callback_module_1.HostData('first','host_1','ok','host_1')
    host_1.uuid = 'first'
    task_data_1.uuid = 'first'
    task_data_1.path = 'path'
    task_data_1.play = 'play'
    task_data_1.name = 'name'
    task_data_1.action = 'action'
    task_data_1.add_host(host_1)
    assert task_data_1.uuid == 'first'
    assert task_data_

# Generated at 2022-06-25 08:44:39.173105
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    # default value of status:[ok]
    task_data = TaskData(0, '', '', '', '')
    host_data = HostData(0, "localhost", "ok", "")
    exception = False
    try:
        task_data.add_host(host_data)
    except Exception as e:
        exception = True
    assert (exception == False)

    # default value of status:[failed]
    task_data = TaskData(0, '', '', '', '')
    host_data = HostData(0, "localhost", "failed", "")
    exception = False
    try:
        task_data.add_host(host_data)
    except Exception as e:
        exception = True
    assert (exception == True)

    # default value of status:[included]
    task_data

# Generated at 2022-06-25 08:44:46.278145
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()

    # Create a class instance of class TaskData
    task_data_1 = callback_module_1.TaskData(uuid=17, name='EAST', path='Dwayne', play='SWITCH', action='10.100.100.100')

    # Create a class instance of class HostData
    host_data_1 = callback_module_1.HostData(uuid=18, name='Bobby', status='SECURITY', result=18)

    # Call method add_host of class TaskData
    task_data_1.add_host(host_data_1)

    # Create a class instance of class HostData
    host_data_2 = callback_module_1.HostData(uuid=17, name='EAST', status='included', result='INCLUDE')

   