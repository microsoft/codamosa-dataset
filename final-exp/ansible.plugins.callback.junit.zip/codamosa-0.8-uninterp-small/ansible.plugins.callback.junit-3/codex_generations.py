

# Generated at 2022-06-25 08:36:21.630286
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module = CallbackModule()
    host = HostData('include', 'include', 'included', 'included')
    task_data = TaskData('uuid', 'task_name1', 'path1', 'play1', 'action1')
    task_data.add_host(host)


# Generated at 2022-06-25 08:36:27.841894
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 = HostData('uuid_0', 'name_0', 'status_0', 'result_0')
    TaskData.add_host(task_data_0, host_data_0)


# Generated at 2022-06-25 08:36:34.799556
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    # Test raise Exception
    host_0 = HostData(None, None, None, None)
    host_1 = HostData(None, None, None, None)
    callback_module_0._task_data[0] = TaskData(None, None, None, None, None)
    callback_module_0._task_data[0].host_data[0] = host_0
    callback_module_0._task_data[0].host_data[1] = host_1
    callback_module_0._task_data[0].path = None
    callback_module_0._task_data[0].play = None
    callback_module_0._task_data[0].name = None
    host_2 = HostData(None, None, None, None)

# Generated at 2022-06-25 08:36:47.155357
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    callback_module_0 = CallbackModule()
    callback_module_0._playbook_path = None
    callback_module_0._playbook_name = None
    callback_module_0._finish_task = MagicMock()
    callback_module_0._start_task = MagicMock()
    callback_module_0._generate_report = MagicMock()
    playbook_0 = PlayContext()
    block_0 = Block()
    task_0 = Task()
    task_

# Generated at 2022-06-25 08:36:51.595173
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_1 = TaskData(uuid='42', name='foo', path='/tmp/foo.yml', play='play', action='action')
    host_data_0 = HostData(uuid='42', name='host', status='status', result='result')
    task_data_1.add_host(host_data_0)


# Generated at 2022-06-25 08:36:53.213124
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data = TaskData
    task_data.add_host(HostData('1', '1', '1', '1'))


# Generated at 2022-06-25 08:37:07.424833
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Setup
    callback_module_0 = CallbackModule()
    host = callback_module_0.HostData("ansible_host", "test_host", "ok", "test_result")

    # Exercise
    callback_module_0.TaskData("test_uuid", "test_name", "test_path", "test_play", "test_action").add_host(host)

    # Result
    assert callback_module_0.TaskData("test_uuid", "test_name", "test_path", "test_play", "test_action").host_data == {
        'ansible_host': host
    }


# Generated at 2022-06-25 08:37:11.401273
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = os._file_name
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:37:22.053014
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    playbook_path_0 = '/home/pravin/schema_migration/schema_migration_v2/schema_migration/playbooks/migration_playbook.yml'
    playbook_name_0 = os.path.splitext(os.path.basename(playbook_path_0))[0]
    play_name_0 = "Migration"
    task_name_0 = 'Migration steps'
    task_path_0 = os.path.splitext('tasks/main.yml')[0]
    task_uuid_0 = '4456dfc4-4b8e-4464-8e19-55ac6d9f2c7f'

# Generated at 2022-06-25 08:37:27.960316
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()

    # Create object instance of class TaskData
    task_data_2 = TaskData(uuid=None, name=None, path=None, play=None, action=None)

    # Create a second object instance of class TaskData
    task_data_3 = TaskData(uuid=None, name=None, path=None, play=None, action=None)

    # Create object instance of class HostData
    host_data_4 = HostData(uuid=None, name=None, status=None, result=None)

    # Add object instance of HostData to object instance of TaskData
    task_data_2.add_host(host=host_data_4)
    # Verify that add_host results are as expected

# Generated at 2022-06-25 08:37:38.695196
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Call method on class
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook=object)


# Generated at 2022-06-25 08:37:43.400031
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """
    Test that multiple 'include' tags are returned as one.
    """
    task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
    host_data_0 = HostData(uuid='uuid_0', name='name_0', status='status_0', result='result_0')
    task_data_0.add_host(host_data_0)
    assert(len(task_data_0.host_data) == 1)
    assert(host_data_0 == task_data_0.host_data['uuid_0'])

    # Test command included twice
    task_data_0.add_host(host_data_0)

# Generated at 2022-06-25 08:37:45.045768
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0.test_case_0()
    assert True



# Generated at 2022-06-25 08:37:46.017950
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:37:46.802881
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
#    TaskData.add_host(host)
    pass


# Generated at 2022-06-25 08:37:57.601786
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:38:07.458897
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    uuid_1 = "uuid_1"
    callback_module_1.uuid_1 = uuid_1
    name_1 = "name_1"
    callback_module_1.name_1 = name_1
    path_1 = "path_1"
    callback_module_1.path_1 = path_1
    play_1 = "play_1"
    callback_module_1.play_1 = play_1
    action_1 = "action_1"
    callback_module_1.action_1 = action_1

# Generated at 2022-06-25 08:38:12.162610
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(str, str, str, str, str)
    # Test with valid argument
    host_data_0 = HostData(str, str, str, dict)
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:38:13.294790
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()


# Generated at 2022-06-25 08:38:15.966839
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook()
    res = callback_module_0.v2_playbook_on_start(playbook_0)
    assert type(res) == None


# Generated at 2022-06-25 08:38:27.618469
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook('/tmp/ansible_junit_payload_U6EoSl/test.yml')
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:38:36.958592
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Before the execution of the method add_host
    string_const_0 = """
Dump of the variable callback_module_0.host_data
""".strip().splitlines()
    string_const_1 = """
Dump of the variable host_data
""".strip().splitlines()
    # Assigning a string to 'test_case_0'
    string_const_2 = """
""".strip()
    test_case_0 = string_const_2
    # Assigning a str to 'result_0' (line 381)
    result_0 = str()
    # Calling the method add_host of class TaskData
    result_0 = callback_module_0.TaskData.add_host(string_const_0)
    # Calling the method add_host of class TaskData
    result_1 = callback_module_0

# Generated at 2022-06-25 08:38:48.866200
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:39:00.546561
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    result_0 = {'stderr': '',
 'stderr_lines': [],
 'stdout': '',
 'stdout_lines': []}

    result_1 = result_0

    result_2 = result_0

    result_3 = result_0

    result_4 = result_0

    result_5 = result_0

    result_6 = result_0

    result_7 = result_0

    result_8 = result_0

    result_9 = result_0

    result_10 = result_0

    result_11 = result_0

    result_12 = result_0

    result_13 = result_0

    result_14 = result_0

    result_15 = result_0

    result_16 = result_0

    result_

# Generated at 2022-06-25 08:39:03.575044
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook=None)


# Generated at 2022-06-25 08:39:08.208396
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = object()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:39:12.257023
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = ''
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:39:15.912242
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    ignore_errors_0 = False

    # Call method v2_runner_on_failed
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)



# Generated at 2022-06-25 08:39:25.788159
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    callback_module_0 = CallbackModule()

    # put in your test code here

    # Unit tests
    class Playbook(object):

        def __init__(self, _file_name):
            self._file_name = _file_name

    callback_module_0.v2_playbook_on_start(Playbook('dummy.yml'))
    assert callback_module_0._playbook_path == 'dummy.yml'
    assert callback_module_0._playbook_name == 'dummy'


# Generated at 2022-06-25 08:39:26.818497
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._TaskData_add_host()


# Generated at 2022-06-25 08:39:44.958121
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # mock object
    class MockPlaybook:
        def _file_name(self):
            return os.path.join('/home/user', 'site.yml')
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(MockPlaybook())
    assert callback_module_0._playbook_path == os.path.join('/home/user', 'site.yml')
    assert callback_module_0._playbook_name == 'site.yml'


# Generated at 2022-06-25 08:39:50.532559
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Initialise assert statements
    assert True == True

    # Construct the first test object
    callback_module_0 = CallbackModule()

    # Construct the first dummy object of class Result
    result_0 = Result()
    result_0.result = "result"
    result_0.host = ""
    result_0.invocation = {"module_args": {"_uses_shell": False, "_raw_params": "", "name": "implementation", "_raw_params_list": [""], "_files_params": None, "creates": "", "removes": "", "executable": "/usr/bin/python"}, "module_name": "implementation", "_task": "playbook on task start"}
    result_0.task = "playbook on task start"
    result_0.item = ""
    result_0.changed = False


# Generated at 2022-06-25 08:39:54.651421
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    try:
        callback_module_0.v2_playbook_on_start(
            playbook = "Hi!"
        )
    except:
        pass
    else:
        raise Exception


# Generated at 2022-06-25 08:40:02.215210
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    stats_0 = dict()
    stats_1 = dict()
    stats_2 = dict()

    stats_0['processed'] = 1
    stats_1['changed'] = 1
    stats_2['failures'] = 1

    stats_0['rescued'] = 1
    stats_1['ignored'] = 1
    stats_2['success'] = 1

    stats_0['ok'] = 1
    stats_1['dark'] = 1
    stats_2['skipped'] = 1

    stats_0['unreachable'] = 1
    stats_1['file'] = 1
    stats_2['completed'] = 1

    stats_0['failures'] = 1
    stats_1['changed'] = 1
   

# Generated at 2022-06-25 08:40:06.369542
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert_equals(callback_module_0._output_dir,u'/tmp/junittests/.ansible.log')
    assert_equals(callback_module_0._playbook_path,u'/tmp/junittests/playbooks/test-0.yml')
    assert_equals(callback_module_0._playbook_name,u'test-0')


# Generated at 2022-06-25 08:40:09.398843
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = _result()
    ignore_errors = False  # Default value
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:40:17.515941
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    print("\nTesting method v2_runner_on_failed of class CallbackModule\n")
    try:
        callback_module_0.v2_runner_on_failed(result, ignore_errors=False)

    except:
        print("Exception raised in method v2_runner_on_failed of class CallbackModule")
        print(sys.exc_info())
        return False


# Generated at 2022-06-25 08:40:18.264874
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass # TODO: implement your test here


# Generated at 2022-06-25 08:40:26.229541
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid="cb9f9b13-fc0e-4b8d-ac69-ba7e0b0c2550", name="Debug variable", path="/Users/corey/osuosl/working/cloud-vm-manager/ansible/azure-vm.yaml:18", play="launch", action="debug")
    host_data_0 = HostData(uuid='cb9f9b13-fc0e-4b8d-ac69-ba7e0b0c2550', name='hostname', status='ok', result='cb9f9b13-fc0e-4b8d-ac69-ba7e0b0c2550')

# Generated at 2022-06-25 08:40:33.833223
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass_0 = '~/workspace/ansible/junit.py'
    pass_1 = 'junit'
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    callback_module_0.v2_playbook_on_start(pass_0)
    callback_module_1.v2_playbook_on_start(pass_1)
    assert callback_module_0._playbook_path == callback_module_1._playbook_path
    assert callback_module_0._playbook_name == callback_module_1._playbook_name


# Generated at 2022-06-25 08:41:04.641336
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:41:07.026594
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pc = PlayContext()
    callback_module_0 = CallbackModule()
    playbook = Playbook()
    callback_module_0.v2_playbook_on_start(playbook)



# Generated at 2022-06-25 08:41:17.031231
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # arrange
    callback_module_1 = CallbackModule()
    callback_module_1._task_data = {'task_uuid_0':TaskData('task_uuid_0','echo foo','test/testfile.txt','playbook_0','debug')}
    host_data_0 = HostData('host_uuid_0','host_name_0','ok','result_0')
    host_data_1 = HostData('host_uuid_1','host_name_1','ok','result_1')
    # act
    callback_module_1._task_data['task_uuid_0'].add_host(host_data_0)
    # assert

# Generated at 2022-06-25 08:41:26.199317
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    callback_module_0._finish_task('ok', HostVars(VariableManager()))
    callback_module_0._finish_task('ok', HostVars(VariableManager()))
    callback_module_0._finish_task('failed', HostVars(VariableManager()))
    callback_module_0._finish_task('failed', HostVars(VariableManager()))
    callback_module_0._finish_task('skipped', HostVars(VariableManager()))
    callback_module_0._finish_task('skipped', HostVars(VariableManager()))

# Generated at 2022-06-25 08:41:30.223610
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._start_task("task")
    host_data_0 = HostData("host_uuid", "host_name", "status", "result")
    callback_module_0._task_data["task_uuid"].add_host(host_data_0)
    assert callback_module_0._task_data["task_uuid"].host_data == {"host_uuid": host_data_0}


# Generated at 2022-06-25 08:41:33.698503
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule()
    res = {}
    cb.v2_runner_on_failed(res)


# Generated at 2022-06-25 08:41:37.615341
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:41:42.940598
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    CallbackModule.v2_playbook_on_start(CallbackModule(), call())
    assert True # TODO: implement your test here


# Generated at 2022-06-25 08:41:49.478224
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    callback_module_2 = CallbackModule()
    callback_module_2 = CallbackModule()
    callback_module_3 = CallbackModule()
    callback_module_4 = CallbackModule()
    callback_module_5 = CallbackModule()
    callback_module_6 = CallbackModule()
    callback_module_7 = CallbackModule()
    callback_module_8 = CallbackModule()
    callback_module_9 = CallbackModule()
    callback_module_10 = CallbackModule()
    callback_module_11 = CallbackModule()
    callback_module_12 = CallbackModule()
    callback_module_13 = CallbackModule()
    callback_module_14 = CallbackModule()

# Generated at 2022-06-25 08:41:53.709064
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='abcd1234', name='', path='/home/user/ansible/test.yml', play='name', action='setup')
    host_data_0 = HostData(uuid='abcd1234', name='include', status='included', result='abcdef')
    task_data_0.add_host(host_data_0)
    host_data_1 = HostData(uuid='abcd1234', name='include', status='included', result='abcdef')
    task_data_0.add_host(host_data_1)


# Generated at 2022-06-25 08:42:33.340216
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:42:38.779991
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    from ansible import playbook
    playbook_0 = playbook.Playbook()
    callback_module.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:42:47.361827
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Checks that _playbook_path is assigned correctly
    # Checks that _playbook_name is assigned correctly
    callback_module_1 = CallbackModule()
    fake_playbook = MagicMock()
    fake_playbook._file_name = "/fake/path/to/playbook.yml"
    callback_module_1.v2_playbook_on_start(fake_playbook)
    assert callback_module_1._playbook_path == "/fake/path/to/playbook.yml"
    assert callback_module_1._playbook_name == "playbook"


# Generated at 2022-06-25 08:42:47.824606
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert True == True

# Generated at 2022-06-25 08:42:50.690796
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = 'result'
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)
    assert callback_module_0._finish_task._status == 'failed'


# Generated at 2022-06-25 08:42:52.378168
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = {}
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:42:53.880479
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_ = CallbackModule()
    callback_module_.v2_runner_on_failed(result, ignore_errors=False)
    return callback_module_


# Generated at 2022-06-25 08:42:56.530258
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    result_1 = callback_module_0.v2_playbook_on_start([])
    assert result_1 == None, "Expected None, got " + repr(result_1)

# Generated at 2022-06-25 08:42:59.972473
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert callback_module_0.v2_runner_on_failed('', '') == null


# Generated at 2022-06-25 08:43:03.562434
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = object
    callback_module_0.v2_playbook_on_start(playbook=playbook_0)


# Generated at 2022-06-25 08:44:19.997699
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    assert callable(getattr(callback_module_1, "v2_runner_on_failed", None))



# Generated at 2022-06-25 08:44:22.108476
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = object()
    callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:44:23.936085
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start('playbook')


# Generated at 2022-06-25 08:44:26.545098
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = ansible.utils.unsafe_proxy.AnsibleUnsafeText(u'../../tests/molecule/default/playbook.yml')
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:44:29.530152
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook = play_0 = TaskResult(host=host_0, task=task_0, result=result_0)
    # No exception is expected from this method
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:44:33.663532
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    class playbook_0(object):
        class _file_name_0(object):
            pass
        _file_name = _file_name_0()
    callback_module_0.v2_playbook_on_start(playbook=playbook_0)


# Generated at 2022-06-25 08:44:39.115538
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    expected_value_0 = 'playbook.yml'

    playbook_0 = MockPlaybook()
    playbook_0._file_name = expected_value_0

    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_path == expected_value_0
    assert callback_module_0._playbook_name == 'playbook'



# Generated at 2022-06-25 08:44:42.549528
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:44:47.727383
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test case with no arguments
    callback_module_0 = CallbackModule()
    test_case_0 = {
        'playbook': {
            '_file_name': 'playbook.yml'
        }
    }
    callback_module_0.v2_playbook_on_start(test_case_0['playbook'])


# Generated at 2022-06-25 08:44:51.050370
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    obj_0 = DummyObject()
    obj_0._file_name = "playbook.txt"
    obj_0._playbook_basedir = "/home/user/ansible"

    callback_module_0.v2_playbook_on_start(obj_0)

    assert (callback_module_0._playbook_path == obj_0._file_name)
    assert (callback_module_0._playbook_name == "playbook")
