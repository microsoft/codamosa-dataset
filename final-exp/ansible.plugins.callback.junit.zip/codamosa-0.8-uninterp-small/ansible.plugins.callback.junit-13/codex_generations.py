

# Generated at 2022-06-25 08:36:26.660973
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()

    taskData_1 = TaskData(uuid='uuid_0', name='[192.168.0.21] include: (note) Include file', path='/home/hc/workspace/ansible-playbook/template-playbook/site.yml:5', play='site', action='include')
    hostData_1 = HostData(uuid='uuid_0', name='192.168.0.21', status='included', result='---\n')
    hostData_2 = HostData(uuid='uuid_1', name='192.168.0.21', status='included', result='- name: (note) Include file\n')
    taskData_1.add_host(host=hostData_1)

# Generated at 2022-06-25 08:36:36.163983
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("\n*** test_TaskData_add_host ***")
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData("task_data_0.uuid", "task_data_0.name", "task_data_0.path", "task_data_0.play", "task_data_0.action")
    host_0 = HostData("host_0.uuid", "host_0.name", "host_0.status", "host_0.result")
    task_data_0.add_host(host_0)
    assert task_data_0.host_data[host_0.uuid] == host_0
    print("\n************** test_TaskData_add_host PASSED **************\n")


# Generated at 2022-06-25 08:36:48.566592
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    task_0 = Mock()
    result_0 = Mock()
    task_0._uuid = get_random_string(6)
    if random.randint(0, 1) == 0:
        callback_module_0._task_data.__setitem__(task_0._uuid, get_random_string(6))
    result_0._task = task_0
    result_0._host = object()
    result_0._result = object()
    result_0._result.__setitem__('rc', get_random_integer(-99, 99))
    task_0.get_name = Mock()
    task_0.get_name.return_value = get_random_string(6)
    task_0.get_path = Mock()

# Generated at 2022-06-25 08:36:52.739849
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_play_start('play')
    callback_module_1.v2_playbook_on_task_start('task', 'is_conditional')
    callback_module_1.v2_runner_on_failed('result', 'ignore_errors')
    callback_module_1.v2_runner_on_ok('result')



# Generated at 2022-06-25 08:36:56.539541
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid', name='name', path='path', play='play', action='action')
    host_data_0 = HostData(uuid='uuid', name='name', status='status', result='result')
    try:
        task_data_0.add_host(host_data_0)
    except Exception:
        pass
    else:
        raise Exception


# Generated at 2022-06-25 08:37:00.583475
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook = ''
    callback_module_0.v2_playbook_on_start(playbook)
    assert callback_module_0._playbook_path == playbook


# Generated at 2022-06-25 08:37:08.132373
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(
        '0000-00-00 00:00:00', 'some name', 'some path', 'some play', 'some action')
    host_data_0 = HostData(
        '0000-00-00 00:00:00', 'some other name', 'some status', 'some result')
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:37:12.090483
# Unit test for method v2_playbook_on_start of class CallbackModule

# Generated at 2022-06-25 08:37:22.431755
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    import sys

    import ansible.playbook.task_include
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    import ansible.plugins.loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.utils.display
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.callback import CallbackModule
    import ansible.parsing.yaml.objects


# Generated at 2022-06-25 08:37:25.778036
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    obj0 = TaskData(0, '0', '1', '2', '3')
    obj0.start = 3.14
    obj1 = HostData('0', '1', '2', 3)
    obj1.finish = 2.72
    obj1.result = 'result'
    obj0.add_host(obj1)
    assert obj0.host_data[obj1.uuid] == obj1


# Generated at 2022-06-25 08:37:40.449188
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    task_1 = None
    result_2 = None
    ignore_errors_3 = False
    callback_module_0.v2_runner_on_failed(task_1, result_2, ignore_errors_3)


# Generated at 2022-06-25 08:37:42.535309
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case = TaskData(0,0,0,0,0)
    test_case.add_host(0)


# Generated at 2022-06-25 08:37:50.007097
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    uuid = '0b2d6dae-6c81-4022-ae65-0ea633a9fa80'
    name = 'task 1'
    path = '//'
    play = 'play 1'
    action = 'copy'
    task_data_0 = TaskData(uuid, name, path, play, action)
    host_uuid = 'b0f32d14-1091-4b4d-b4e1-a9ac9f600cce'
    host_name = 'host 1'
    status = 'ok'
    result = ''
    host_0 = HostData(host_uuid, host_name, status, result)
    task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:37:54.349037
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    #from unittest.mock import patch

    #callback_module_0 = CallbackModule()

    #playbook = Mock()

    #callback_module_0.v2_playbook_on_start(playbook)
    assert False # TODO: implement your test here


# Generated at 2022-06-25 08:38:05.918850
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    callback_module_0 = CallbackModule()

    uuid_0 = 'UUID'
    name_0 = 'Name'
    path_0 = 'Path'
    play_0 = 'Play'
    action_0 = 'Action'
    task_data_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)

    uuid_1 = 'Host UUID'
    name_1 = 'Host Name'
    status_1 = 'Host Status'
    result_1 = 'Host Result'
    host_1 = HostData(uuid_1, name_1, status_1, result_1)

    task_data_0.add_host(host_1)

    callback_module_0 = CallbackModule()

    uuid_2 = 'UUID'
   

# Generated at 2022-06-25 08:38:12.859931
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert TaskData('f1', 'f2', 'f3', 'f4', 'f5') != None
    assert TaskData('f1', 'f2', 'f3', 'f4', 'f5').uuid == 'f1'
    assert TaskData('f1', 'f2', 'f3', 'f4', 'f5').name == 'f2'
    assert TaskData('f1', 'f2', 'f3', 'f4', 'f5').path == 'f3'
    assert TaskData('f1', 'f2', 'f3', 'f4', 'f5').play == 'f4'
    assert TaskData('f1', 'f2', 'f3', 'f4', 'f5').start == None

# Generated at 2022-06-25 08:38:20.633367
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Create object of class TaskData
    TaskData_0 = TaskData(0, 'name_0', 'path_0', 'play_0', 'action_0')
    # Call the method of class TaskData
    #TaskData_0.add_host(None)
    TaskData_0.add_host(HostData(None, None, 'included', None))


# Generated at 2022-06-25 08:38:29.231126
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('async_wrapper')
    callback_module_0.v2_playbook_on_play_start('test_function')
    host_data_0 = HostData('foo', 'bar', 'ok', 'result')
    task_data_0 = TaskData('baz', 'qux', 'xyzzy', 'play', 'action')
    callback_module_0._task_data['baz'] = task_data_0
    task_data_0.add_host(host_data_0)
    assert task_data_0.host_data['foo'] == host_data_0


# Generated at 2022-06-25 08:38:34.457344
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData("uuid", "name", "path", "play", "action")
    host_0 = HostData("uuid", "name", "status", "result")

    with pytest.raises(Exception):
        callback_module_0._finish_task("exception", "result")


# Generated at 2022-06-25 08:38:42.031165
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_path == '~/.ansible.log'
    assert callback_module_0._playbook_name == '-0.01'


# Generated at 2022-06-25 08:38:56.376894
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_0 = HostData('host_uuid_0', 'host_name_0', 'host_status_0', 'host_result_0')
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:38:57.207970
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()


# Generated at 2022-06-25 08:39:00.785289
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data_0 = HostData('uuid', 'name', 'status', 'result')
    task_data_0.add_host(host_data_0)



# Generated at 2022-06-25 08:39:09.228659
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    callback_module_1 = CallbackModule()


    host_data_2 = HostData('host_uuid', 'host_name', 'status', 'result')
    host_data_2.uuid = 'host_uuid'
    host_data_2.name = 'host_name'
    host_data_2.status = 'status'
    host_data_2.result = 'result'

    task_data_3 = TaskData('uuid', 'name', 'path', 'play', 'action')
    task_data_3.uuid = 'uuid'
    task_data_3.name = 'name'
    task_data_3.path = 'path'
    task_data_3.play = 'play'
    task_data_3.start = 'start'
    task_data_3.host

# Generated at 2022-06-25 08:39:12.046564
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    return_value_0 = callback_module_0.v2_playbook_on_start()
    assert return_value_0 is None


# Generated at 2022-06-25 08:39:13.100532
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:39:18.458572
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0','name_0','path_0','play_0','action_0')
    host_data_0 = HostData('uuid_0','name_0','status_0','result_0')

    callback_module_0._task_data['uuid_0'] = task_data_0
    callback_module_0._task_data['uuid_0'].add_host(host_data_0)


if __name__ == '__main__':
    test_TaskData_add_host()

# Generated at 2022-06-25 08:39:26.662489
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    dmp = {}
    dmp['_result'] = '1'
    dmp['_host'] = {'_uuid': 'host_uuid_0',
                    'name': 'host_name_0'}
    dmp['_task'] = {'_uuid': 'task_uuid_0',
                    '_name': 'task_name_0'}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(dmp, ignore_errors=False)


# Generated at 2022-06-25 08:39:37.080405
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    class_names = ["ansible.parsing.yaml.objects.AnsibleUnicode", "ansible.parsing.yaml.objects.AnsibleUnicode", "ansible.parsing.yaml.objects.AnsibleUnicode", "ansible.parsing.yaml.objects.AnsibleUnicode"]
    values = ["test_value_0", "test_value_1", "test_value_2", "test_value_3"]
    kwargs = dict(zip(class_names, values))
    playbook_0 = FakePlaybook(**kwargs)
    callback_module_1.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:39:40.928769
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_1 = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    host.status = 'included'
    host.result = 'result2'
    task_data_1.add_host(host)
    assert task_data_1.host_data['uuid'].result == 'result2'



# Generated at 2022-06-25 08:39:55.134029
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Setup
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(None)
    callback_module_0.v2_playbook_on_play_start(None)
    callback_module_0.v2_playbook_on_task_start(None, False)
    
    host_data_obj = HostData("host_uuid", "host_name",  "status", None)
    # Testing add_host(host)
    
    callback_module_0._task_data['key'].add_host(host_data_obj)
    # No assert statement, it will fail without adding host correctly.



# Generated at 2022-06-25 08:39:56.673136
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test case comments should be written here.
    pass


# Generated at 2022-06-25 08:40:09.859783
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    assert not hasattr(callback_module_0, '_task_data')
    task_0 = Context()
    callback_module_0._start_task(task_0)
    assert callback_module_0._task_data != {}
    result_0 = Context()
    result_0._result = {}
    result_0._result['rc'] = 2
    assert result_0._result['rc'] == 2
    result_0._result['exception'] = 'An exception'
    assert result_0._result['exception'] == 'An exception'
    assert result_0._result['rc'] == 2
    assert result_0._result['exception'] == 'An exception'
    result_0._task = task_0
    assert result_0._task == task_0
    result

# Generated at 2022-06-25 08:40:20.656679
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    td = TaskData('123','name','path','play','action')
    hd = HostData('456','hostname','status','result')
    td.add_host(hd)
    assert td.host_data['456'].name == 'hostname', 'hostname'
    assert td.host_data['456'].result == 'result', 'result'
    assert td.host_data['456'].status == 'status', 'status'
    assert td.host_data['456'].uuid == '456', 'uuid'
    assert td.action == 'action', 'action'
    assert td.host_data['456'].finish == '', 'finish'
    assert td.name == 'name', 'name'
    assert td.play == 'play', 'play'

# Generated at 2022-06-25 08:40:26.959241
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("test_TaskData_add_host")
    print("\tTestCase 1: Test with host: object HostData and host.status: ok")
    print("\t\tExpected Result: throw exception")
    print("\t\tActual Result: ", end='')
    callback_module_1 = CallbackModule()
    host_1 = HostData(host_uuid="host_1", host_name="host_name_1", status="ok", result="result_1")
    task_data_1 = TaskData(uuid="task_data_1", name="task_name_1", path="path_1", play="play_1", action="action_1")
    try:
        task_data_1.add_host(host_1)
    except Exception as error:
        print(error)
   

# Generated at 2022-06-25 08:40:28.936324
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = { '_file_name': 'test' }
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:40:36.139290
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module = CallbackModule()
    task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
    host_data_0 = HostData(uuid='uuid_0', name='name_0', status='ok', result='result_0')
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:40:38.806018
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(None)
    assert callback_module._playbook_path == None
    assert callback_module._playbook_name == None


# Generated at 2022-06-25 08:40:43.312282
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    try:
        callback_module_0._playbook_path = None
        callback_module_0._playbook_name = None
        playbook_0 = Playbook.objects.get(pk=1)
        callback_module_0.v2_playbook_on_start(playbook_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 08:40:48.205335
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    task_data_0 = TaskData(junit_test_case_prefix='[default]', name='junit_test_case_prefix=, junit_output_dir=/tmp, junit_task_class=false', path='/home/ansible/playbooks/testsuite/', play='playbook.yml', action='add_host')
    host_data_0 = HostData(host_name='host_name=localhost', rc=0, start=None, uuid='uuid=b17c39ebe1c28b51a8c08a6e5e6c5d6b', name='localhost', status='ok', result='localhost              : ok=1    changed=0    unreachable=0    failed=0    skipped=1    rescued=0    ignored=0   ')

# Generated at 2022-06-25 08:41:05.537734
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    import unittest
    import mock
    from mock import patch
    from mock import call

    @patch('ansible.plugins.callback.junit.TaskData.host_data')
    @patch('ansible.plugins.callback.junit.TaskData.path')
    @patch('ansible.plugins.callback.junit.TaskData.play')
    @patch('ansible.plugins.callback.junit.TaskData.name')
    def mocked_add_host(self, mock_name, mock_play, mock_path, mock_host_data):
        mock_name.return_value = 'kube-etcd-lgwdb'
        mock_play.return_value = 'Register and configure K8s minions'

# Generated at 2022-06-25 08:41:08.201356
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_0 = playbook._file_name
    exposed_playbook_0 = os.path.splitext(os.path.basename(playbook_0))[0]
    assert exposed_playbook_0 == "test_case_0"
    

# Generated at 2022-06-25 08:41:17.042020
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    try:
        raise Exception('Cannot create instance of abstract class TaskData')
    except Exception as inst:
        if 'Cannot create instance' in inst.args[0]:
            pass 
        else:
            print('Exception raised was not expected')
            raise 
    
    # Test exception if multiple instances of host names found
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_ok(result)
    
    callback_module_2 = CallbackModule()
    callback_module_2.v2_runner_on_ok(result)
    
    callback_module_1._task_data['task_uuid'] = TaskData('task_uuid', 'name', 'path', 'play', 'action')
    callback_module_

# Generated at 2022-06-25 08:41:26.009610
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    name = 't1'
    path = 't1.yml'
    play = 'play_name'
    action = 't1.yml'
    uuid = '123'
    start = time.time()
    host_data = {}

    task_data_0 = TaskData(uuid=uuid, name=name, path=path, play=play, action=action)
    assert task_data_0.uuid == uuid
    assert task_data_0.name == name
    assert task_data_0.path == path
    assert task_data_0.play == play
    assert task_data_0.start == start
    assert task_data_0.host_data == host_data
    assert task_data_0.action == action


# Generated at 2022-06-25 08:41:32.527836
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._task_data = dict()
    callback_module_0._task_data['dfd08d7c-869f-48a7-b70d-bc7f6b004ac6'] = TaskData('dfd08d7c-869f-48a7-b70d-bc7f6b004ac6', 'show inventory', 'get_inventory.yml:1', 'Get inventory from three places', 'win_ping')
    attr_0 = callback_module_0._task_data['dfd08d7c-869f-48a7-b70d-bc7f6b004ac6']

# Generated at 2022-06-25 08:41:38.827714
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Create input data
    host = HostData('include', 'include', 'included', 'unused')

    # Input data from existing object
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')

    # Call method
    task_data.add_host(host)


# Generated at 2022-06-25 08:41:48.806883
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 = HostData('uuid_0', 'name_0', 'status_0', 'result_0')
    host_data_1 = HostData('uuid_1', 'name_1', 'status_1', 'result_1')
    host_data_2 = HostData('uuid_2', 'name_2', 'status_2', 'result_2')
    host_data_3 = HostData('uuid_0', 'duplicate', 'status_0', 'result_0')

# Generated at 2022-06-25 08:41:58.798575
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData('A', 'B', 'C', 'D', 'E')
    host_data_0 = HostData('G', 'H', 'I', 'J')
    host_data_0.result = 'K'
    task_data_0.host_data = {'M': 'N'}
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:42:10.823059
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Create a HostData object with uuid "test_uuid_0"
    host_0 = HostData("test_uuid_0", "test_name_0", "test_status_0", "test_result_0")
    # Create a TaskData object with uuid "test_uuid_1" name "test_name_1" path "test_path_1" play "test_play_1" action "test_action_1"
    task_data_0 = TaskData("test_uuid_1", "test_name_1", "test_path_1", "test_play_1", "test_action_1")
    # Call method add_host of TaskData object with input host_0
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:42:17.285716
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid_0, 'name_0', 'path_0', 'play_0', 'action_0')
    host_0 = HostData(uuid_0, name_0, status_0, result_0)
    TaskData.add_host(task_data_0, host_0)



# Generated at 2022-06-25 08:42:28.221573
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = None
    host_0 = None
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:42:31.128489
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('2', '2', '2', '2', '2')
    host_0 = HostData('3', '3', '3', '3')
    task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:42:37.297181
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    try:
        callback_module_0._task_data['ansible_collections.notstdlib.moveitallout.tasks_0'] = TaskData('ansible_collections.notstdlib.moveitallout.tasks_0', 'test_task', 'test_path', 'test_play', 'test_action')
        callback_module_0._task_data['ansible_collections.notstdlib.moveitallout.tasks_0'].add_host(HostData('ansible_collections.notstdlib.moveitallout.tasks_0', 'test_host', 'test_status', None))
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-25 08:42:46.814195
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Initialise test environment
    import os
    os.environ['JUNIT_TASK_CLASS'] = 'False'
    os.environ['JUNIT_TASK_RELATIVE_PATH'] = ''
    os.environ['JUNIT_FAIL_ON_CHANGE'] = 'False'
    os.environ['JUNIT_FAIL_ON_IGNORE'] = 'False'
    os.environ['JUNIT_INCLUDE_SETUP_TASKS_IN_REPORT'] = 'True'
    os.environ['JUNIT_HIDE_TASK_ARGUMENTS'] = 'False'
    os.environ['JUNIT_TEST_CASE_PREFIX'] = ''

    # Instantiate class to be tested
    callback_module_0 = Call

# Generated at 2022-06-25 08:42:51.413302
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    # Test for the v2_playbook_on_start method with no args
    try:
        callback_module_0.v2_playbook_on_start(playbook_on_start_0)
    except TypeError as e:
        if "v2_playbook_on_start() takes exactly 2 arguments (1 given)" == str(e):
            pass
        else:
            raise Exception(e)

    # Test for the v2_playbook_on_start method with no args
    try:
        callback_module_0.v2_playbook_on_start()
    except TypeError as e:
        if "v2_playbook_on_start() takes exactly 2 arguments (0 given)" == str(e):
            pass

# Generated at 2022-06-25 08:42:58.179320
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(
        '06563b7f-eae8-4cab-b093-3b01a466b289',
        'Ping the control host',
        'provision.yml',
        'control',
        'action'
    )

    host_data_0 = HostData(
        'meta',
        'meta',
        'okay',
        '_result'
    )

    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:43:06.414138
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    mock_result = mock.Mock()
    mock_result.host.name = 'hostname'
    mock_result.task.get_name.return_value = 'taskname'
    mock_result.task.action = 'action'
    mock_result.task._uuid = 'uuid'
    mock_result.task.host = 'host'
    mock_result.task._role = 'role'
    mock_result.task._role_name = 'rolename'
    mock_result._task_fields = dict()
    mock_result._task_fields['action'] = 'action'
    mock_result._task_fields['name'] = 'name'
    mock_result._task_fields['tags'] = ['tag']

# Generated at 2022-06-25 08:43:17.030464
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    uuid_1 = '2d9cef0a-ad28-4c4d-b52c-849a5a5a5c5b'
    name_1 = 'mytask'
    path_1 = 'myplaybook.yml:15'
    play_1 = 'myplay'
    action_1 = 'myaction'
    task_data_1 = TaskData(uuid_1, name_1, path_1, play_1, action_1)
    host_uuid_1 = 'host1'
    host_name_1 = 'host1'
    status_1 = 'ok'
    result_1 = 'success'

# Generated at 2022-06-25 08:43:22.043927
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_uuid = "ab3e4b4d-5f1b-4a9d-9d5e-70b6e236b2dd"
    task_name = "Get Facts"
    task_type = "action"
    task_path = "/root/test/test.yml:90"
    task_play = "Test"
    task_start = None
    host_data = dict()
    action = "module"
    task_data_0 = TaskData(task_uuid, task_name, task_path, task_play, action)
    
    host_uuid = "a7a6d10e-aec8-4766-a1be-885e9d9a1e3a"

# Generated at 2022-06-25 08:43:23.349242
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 08:43:49.025041
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    print("\nStart test test_CallbackModule_v2_runner_on_failed")
    callback_module_0 = CallbackModule()
    result = Result()
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)
    print("Finish test test_CallbackModule_v2_runner_on_failed")


# Generated at 2022-06-25 08:43:50.201569
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()




# Generated at 2022-06-25 08:43:54.132018
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_path == '/usr/local/Cellar/ansible/2.6.1/install_dir/playbooks/deploy.yml'
    assert callback_module_0._playbook_name == 'deploy'


# Generated at 2022-06-25 08:44:02.806168
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    task_data_0 = TaskData("uuid", "name", "path", "play", "action")
    callback_module_0.test_case_0(task_data_0)

test_TaskData_add_host()




# Generated at 2022-06-25 08:44:13.003214
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:44:15.114330
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass
test_case_0()
 

# Generated at 2022-06-25 08:44:19.949535
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Arrange
    callback_module = CallbackModule()
    task = {'uuid': '123'}


# Generated at 2022-06-25 08:44:22.543050
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    no_of_args = 2

    args = []
    args.append(None)
    args.append(None)

    callback_module.v2_playbook_on_start(*args)


# Generated at 2022-06-25 08:44:28.047608
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    print('\n Unit tests for method v2_playbook_on_start of class CallbackModule ')
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)

    test_case_0()


# Generated at 2022-06-25 08:44:37.409224
# Unit test for method v2_playbook_on_start of class CallbackModule

# Generated at 2022-06-25 08:45:07.831111
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    from ansible.playbook.play import Play
    callback_module_0 = CallbackModule()
    playbook_0 = Play()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:45:11.731704
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start('/tmp/ansible_junit_callback.junit_test-11')
 

# Generated at 2022-06-25 08:45:18.011361
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result_0 = CallbackModule()
    result_0.v2_runner_on_failed()

    assert result_0.result == 'failed'


# Generated at 2022-06-25 08:45:21.123916
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = None
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:45:25.312242
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 =  HostData('host_uuid_0', 'host_name_0', 'status_0', 'result_0')
    # Test with True expected value and True actual value
    assert task_data_0.add_host(host_data_0) == None


# Generated at 2022-06-25 08:45:30.243784
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = object()
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:45:36.847579
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    Task_Data = TaskData('uuid', 'name', 'path', 'play', 'action')
    Task_Data.host_data = {'host_uuid': HostData('host_uuid', 'host_name', 'status', 'result')}

    host = HostData('host_uuid', 'host_name', 'included', 'included_file')

    try:
        Task_Data.add_host(host)
    except Exception as e:
        print('Duplicate host callback: expected result')


# Generated at 2022-06-25 08:45:41.020751
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    assert callback_module_0._playbook_path == '/home/christian/ansible-test/test_playbook.yml' and callback_module_0._playbook_name == 'test_playbook'


# Generated at 2022-06-25 08:45:44.675659
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
  # TaskData.add_host(self, host)

  # call method to be tested
  test_case_0()

  # check that results are correct
  # TODO: implement test


# Generated at 2022-06-25 08:45:52.288811
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    """
    JUnit report module has one test case for method v2_playbook_on_start.
    """
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)
    callback_module_0.v2_playbook_on_start()
