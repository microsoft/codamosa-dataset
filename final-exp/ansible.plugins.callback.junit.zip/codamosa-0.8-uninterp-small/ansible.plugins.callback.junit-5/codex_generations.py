

# Generated at 2022-06-25 08:36:20.474890
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    TaskData_obj = TaskData('uuid', 'name', 'path', 'play', 'action')
    HostData_obj = HostData('uuid', 'name', 'status', 'result')
    TaskData_obj.add_host(HostData_obj)
    return TaskData_obj.host_data


# Generated at 2022-06-25 08:36:23.439048
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
    assert True


# Generated at 2022-06-25 08:36:25.993248
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(None, None, None, None, None)
    try:
        task_data_0.add_host(None)
    except Exception:
        pass



# Generated at 2022-06-25 08:36:30.399753
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print('Test add_host method of the TaskData class')
    callback_module_1 = CallbackModule()
    assert callback_module_1._task_data == {}, "Variable _task_data should be an empty dictionary"
    assert callback_module_1._task_data.add_host() == None

# Unit  test for method fail_on_ignore of the CallbackModule class

# Generated at 2022-06-25 08:36:39.061615
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 = HostData('uuid_0', 'name_0', 'status_0',  'result_0')
    host_data_1 = HostData('uuid_1', 'name_1', 'status_1',  'result_1')
    task_data_0.add_host(host_data_0)
    task_data_0.add_host(host_data_1)
    #assert(value_0 == expected_0)


# Generated at 2022-06-25 08:36:49.482237
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_2 = CallbackModule()
    task_data_obj_2 = TaskData(uuid='0f9b022f-e1d8-4df0-96c3-24d91f0c8d0e', name='test_task', path='/home/user/playbook.yml', play='play_name', action='action_namen')
    host_2 = HostData(uuid='8295f7f0-6612-41d6-8ed2-e7cb9cb35e99', name='localhost', status='ok', result='result')
    try:
        task_data_obj_2.add_host(host_2)
    except Exception as e:
        print(e)
    else:
        pass


# Generated at 2022-06-25 08:36:51.086030
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module._fail_on_ignore = 'False'
    callback_module.v2_runner_on_failed('result', True)


# Generated at 2022-06-25 08:36:54.179887
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data_0 = HostData('uuid', 'name', 'status', 'result')
    try:
        task_data_0.add_host(host_data_0)
    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 08:37:09.595170
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    args_0 = {}
    args_0['uuid'] = callback_module_1
    args_0['name'] = callback_module_1
    args_0['path'] = callback_module_1
    args_0['play'] = callback_module_1
    args_0['action'] = callback_module_1
    task_data_0 = TaskData(**args_0)
    args_1 = {}
    args_1['uuid'] = callback_module_1
    args_1['name'] = callback_module_1
    args_1['status'] = callback_module_1
    args_1['result'] = callback_module_1
    args_1['finish'] = callback_module_1

# Generated at 2022-06-25 08:37:19.607915
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    res_0 = 'arguments'
    test_case_0 = TaskData('uuid', 'name', 'path', 'play', 'action')

    # should throw exception so this will fail.
    try:
        # Add duplicate host callback
        test_case_0.add_host(HostData('uuid', 'name', 'status', res_0))
        # Add duplicate host callback
        test_case_0.add_host(HostData('uuid', 'name', 'status', res_0))
    except:
        # test passes
        return

    # test fails
    assert False


# Generated at 2022-06-25 08:37:33.428173
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
    host_0 = HostData(uuid='uuid_0', name='name_0', status='included', result='result_0')
    task_data_0.add_host(host=host_0)


# Generated at 2022-06-25 08:37:42.988750
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # test case 3
    callback_module_3 = CallbackModule()

    # initialization
    callback_module_3._playbook_path = None
    callback_module_3._playbook_name = None

    # parameter extraction
    playbook_4 = object()

    # parameter values
    expected_playbook_path_5 = 'C:\\var\\lib\\awx\\projects\\VaultCore\\playbooks\\base_playbook.yml'
    expected_playbook_name_6 = 'base_playbook'

    # function invocation
    callback_module_3.v2_playbook_on_start(playbook_4)

    # assertions
    assert expected_playbook_path_5 == callback_module_3._playbook_path
    assert expected_playbook_name_6 == callback_module_3._playbook_name

# Generated at 2022-06-25 08:37:46.046585
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = None # TODO: create an instance of Playbook()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:37:46.862821
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    expected = None
    actual = None
    assert expected == actual


# Generated at 2022-06-25 08:37:49.661885
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_1 = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data_1 = HostData('uuid', 'name', 'status', 'result')
    task_data_1.add_host(host_data_1)


# Generated at 2022-06-25 08:37:59.346438
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._task_class = 'true'
    callback_module_0.CALLBACK_VERSION = 2.0
    callback_module_0._playbook_name = '.'
    callback_module_0._playbook_path = 'task_data.yml'
    callback_module_0._play_name = 'play'
    uuid_0 = 'roles/test/tasks/main.yml:7'
    name_0 = '[root <local machine>] task'
    path_0 = 'roles/test/tasks/main.yml'
    play_0 = 'play'
    action_0 = 'task'

# Generated at 2022-06-25 08:38:07.486540
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_1', 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 = HostData('uuid_0', 'name_0', 'status_0', 'result_0')
    callback_module_0._task_data['uuid_1'] = task_data_0
    try:
        task_data_0.add_host(host_data_0)
    except Exception as e:
        print('Error: Exception: %s' % e)
    except:
        print('Error: Unknown')



# Generated at 2022-06-25 08:38:09.905387
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('playbook')
    print("Passed: v2_playbook_on_start()")


# Generated at 2022-06-25 08:38:12.349002
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('playbook_on_start')


# Generated at 2022-06-25 08:38:16.956072
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_0 = callback_module_1.TaskData.__init__('uuid', 'name', 'path', 'play', 'action')
    assert_equals(task_data_0.host_data, {})
    callback_module_1.TaskData.add_host(task_data_0, 'host')
    assert_equals(task_data_0.host_data, {})


# Generated at 2022-06-25 08:38:40.613802
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    result = Result()
    ignore_errors = False
    callback_module.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:38:43.156714
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    result = callback_module_1.v2_playbook_on_start(playbook_0)
    assert result == None


# Generated at 2022-06-25 08:38:46.331056
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    value = callback_module_1.v2_playbook_on_start()
    # AssertionError: <lambda>() takes 1 positional argument but 2 were given


# Generated at 2022-06-25 08:38:48.952930
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    pass


# Generated at 2022-06-25 08:38:59.557314
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Dummy()
    playbook_0._file_name = '/etc/ansible/roles/spring-boot-microservices/tests/test/test_spring-boot-microservices.yml'
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_name == 'test_spring-boot-microservices'
    assert callback_module_0._playbook_path == '/etc/ansible/roles/spring-boot-microservices/tests/test/test_spring-boot-microservices.yml'


# Generated at 2022-06-25 08:39:07.675725
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    try:
        callback_module_0 = CallbackModule()
        host_0 = HostData(test_case_0.uuid, test_case_0.name, test_case_0.status, test_case_0.result)
        callback_module_0.add_host(host_0)
        # assert callback_module_0.add_host(host_0) == True
    except Exception as e:
        print("Exception: %s" % e)
        # assert False


# Generated at 2022-06-25 08:39:10.713541
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:39:12.810022
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed("result", "ignore_errors")
    assert 0


# Generated at 2022-06-25 08:39:16.660327
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')

    try:
        task.add_host(host)
    except Exception as e:
        print(e)
        assert True
    else:
        assert False


# Generated at 2022-06-25 08:39:21.866854
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    assert callback_module_0.v2_runner_on_failed() == True


# Generated at 2022-06-25 08:39:44.503045
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    src_cb_module = CallbackModule()
    src_playbook = Playbook()
    src_playbook._file_name = "test_playbook.txt"
    src_cb_module.v2_playbook_on_start(src_playbook)
    assert_equal(src_cb_module._playbook_name, "test_playbook.txt")
    assert_equal(src_cb_module._playbook_path, "test_playbook.txt")


# Generated at 2022-06-25 08:39:47.239679
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    the_playbook_0 = the_playbook_1 = the_playbook_2 = None
    callback_module_0.v2_playbook_on_start(the_playbook_0)

    assert callback_module_0._playbook_name == 'default'


# Generated at 2022-06-25 08:39:51.722244
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    print('Testing method v2_playbook_on_start in class CallbackModule')

    callback_module_0 = CallbackModule()

    test_case_0()


# Generated at 2022-06-25 08:39:56.984020
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(uuid=0, name='default', path='/var/lib/jenkins/workspace/ansible/test/cb_junit.py', play='default', action='default')
    callback_module_0 = CallbackModule()
    result_0 = HostData(uuid=None, name=None, status='default', result=None)
    task_data_0.add_host(host=result_0)


# Generated at 2022-06-25 08:40:02.424610
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = callback_module_0._start_task(task)
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:40:12.522435
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    file_path = "/opt/ansible/ansible/test/integration/targets/complex_target/complex.yml"
    fake_playbook = False # Can't test with single file playbook. Have to consider entire directory "complex_target"
    callback_module_0.v2_playbook_on_start(fake_playbook)
    assert callback_module_0._playbook_path == file_path


# Generated at 2022-06-25 08:40:18.274291
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_0 = CallbackModule()
    callback_module_0._playbook_path = 'pathname_0'
    callback_1 = CallbackModule()
    callback_module_0._playbook_name = 'name_0'
    callback_1.v2_playbook_on_start(callback_0)


# Generated at 2022-06-25 08:40:27.859990
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """ Test add_host """

    callback_module_0 = TaskData(0,'test_name', 'test_path', 'test_play', 'test_action')
    host_data_0 = HostData(0,'host_name', 'host_status', 'host_result')

    callback_module_0.add_host(host_data_0)


# Generated at 2022-06-25 08:40:36.102418
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()

    task_data_0 = callback_module_0.TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data_0 = callback_module_0.HostData('uuid', 'name', 'status', 'result')
    task_data_0.host_data = {'host_data_0.uuid': host_data_0}

    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:40:37.315182
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:41:00.206249
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)



# Generated at 2022-06-25 08:41:09.430934
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:41:11.693995
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    params_0 = {'self': 'self_0', 'playbook': 'playbook_0'}
    retval_0 = callback_module_0.v2_playbook_on_start(**params_0)


# Generated at 2022-06-25 08:41:16.385754
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()



# Generated at 2022-06-25 08:41:23.843763
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    callback_module_1 = CallbackModule()
    task_data_1 = TaskData('uuid_1', 'name_1', 'path_1', 'play_1', 'action_1')
    host_1 = HostData('uuid_1', 'name_1', 'status_1', 'result_1')
    task_data_1.add_host(host_1)
    assert task_data_1.host_data == {'uuid_1': host_1}


# Generated at 2022-06-25 08:41:26.001681
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = MagicMock()
    callback_module_0.v2_runner_on_failed(result)



# Generated at 2022-06-25 08:41:32.517472
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # playbook._file_name fake
    playbook_file_name_0 = 'playbook.yml'
    # playbook.name fake
    playbook_name_0 = 'playbook.yml'

    callback_module_1 = CallbackModule()
    # <ansible.plugins.callback.CallbackModule object at 0x7f7bfc0512b0>
    assert isinstance(callback_module_1, CallbackModule)

    # setting attribute _playbook_path to value returned by property playbook._file_name
    callback_module_1._playbook_path = playbook_file_name_0
    # setting attribute _playbook_name to value returned by property playbook.name
    callback_module_1._playbook_name = playbook_name_0

    callback_module_1.v2_playbook_on_start()

    #

# Generated at 2022-06-25 08:41:40.018736
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
    host_data_0 = HostData(uuid='uuid_1', name='name_1', status='included', result='result_0')
    with raises(Exception):
        task_data_0.add_host(host_data_0)



# Generated at 2022-06-25 08:41:50.165911
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # These two lines invoke the test_case_0 function written above.
    # The first line is for debugging purposes only, so you can see
    # which test failed.
    #test_case_0()
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import json


# Generated at 2022-06-25 08:41:54.045382
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()
    assert True

test_case_0()

# Generated at 2022-06-25 08:42:22.156665
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()
    test_case_1 = TaskData("null", "null", "null", "null", "null")
    test_case_1.add_host("null")
    assert True == True


# Generated at 2022-06-25 08:42:25.273487
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = 'string'
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:42:26.321439
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    pass


# Generated at 2022-06-25 08:42:28.722388
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = 'test_playbook' # str | The name of the playbook.
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    

# Generated at 2022-06-25 08:42:35.016036
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    result_0 = {}
    status_0 = 'included'
    value_0 = {}
    value_1 = 'result'
    result_0[value_1] = value_0
    arg_0 = result_0
    value_0 = 'uuid'
    arg_1 = value_0
    value_0 = 'name'
    arg_2 = value_0
    value_0 = 'status'
    arg_3 = value_0
    value_0 = 'host_uuid'
    value_1 = 'host_name'
    value_2 = 'included'
    value_3 = {}
    value_4 = 'result'
    value_3[value_4] = value_0

# Generated at 2022-06-25 08:42:38.974889
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(None)


# Generated at 2022-06-25 08:42:41.697733
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    assert callback_module.v2_runner_on_failed() == None


# Generated at 2022-06-25 08:42:48.610388
# Unit test for method v2_playbook_on_start of class CallbackModule

# Generated at 2022-06-25 08:42:55.753400
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid', name='name', path='path', play='play', action='action')
    host_0 = HostData(uuid='uuid', name='name', status='status', result='result')
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:43:06.287936
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    uuid_0 = 'This is an ID.'
    name_0 = 'This is a task name.'
    path_0 = 'This is a path.'
    play_0 = 'This is a play name.'
    action_0 = 'This is an action.'
    task_data_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)
    uuid_1 = 'This is an ID.'
    name_1 = 'This is a host name.'
    status_0 = 'failed'
    result_0 = 'This is a result.'
    host_data_0 = HostData(uuid_1, name_1, status_0, result_0)

# Generated at 2022-06-25 08:43:33.433714
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert TaskData.add_host(TaskData, HostData) is None


# Generated at 2022-06-25 08:43:41.619924
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(uuid='6acd1d87-43b0-4a15-b4e4-4665b1ab2e9e', name='task_name_0', path='file_path_0', play='play_0', action='action_0')
    host_data_0 = HostData(uuid='id_0', name='id_0', status='ok', result=True)
    task_data_0.add_host(host=host_data_0)


# Generated at 2022-06-25 08:43:53.099882
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    test_task_data_0 = TaskData('Sx0I_gDBYW', 'GENERATE REPORT', 'playbooks/dynamic_inventory.yml:1', 'playbooks/dynamic_inventory.yml', 'collect')
    test_host_data_0 = HostData('eM_wA1fZM', 'localhost', 'ok', 'result')
    test_task_data_0.add_host(test_host_data_0)



# Generated at 2022-06-25 08:43:56.532755
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    assert callback_module_0.v2_playbook_on_start(playbook) == None


# Generated at 2022-06-25 08:44:01.003595
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    callback_module_0 = CallbackModule()

    assert callback_module_0.v2_runner_on_failed(result=None, ignore_errors=False) == None


# Generated at 2022-06-25 08:44:06.190656
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_name = "test_TaskData_add_host"
    callback_module = CallbackModule()

    task = TaskData(1, 2, 3, 4, 5)
    host = HostData('include', 'include', 'included', 'included_file')
    task.add_host(host)
    try:
        assert task.host_data['include'] == host
    except AssertionError as e:
        print(test_case_name + " failed", e)
    else:
        print(test_case_name + " passed")


# Generated at 2022-06-25 08:44:18.550890
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    """test add_host of TaskData"""
    callback_module_0 = CallbackModule()

    task_data_0 = TaskData(
        uuid='string_0',
        name='string_1',
        path='string_2',
        play='string_3',
        action='string_4'
   )

    host_data_0 = HostData(
        uuid='string_0',
        name='string_1',
        status='string_2',
        result='string_3'
   )

    task_data_0.add_host(host=host_data_0)
    print(task_data_0)

    # AssertionError: string_0: string_3: string_1: duplicate host callback: string_1


# Generated at 2022-06-25 08:44:20.344712
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # TODO:
    pass


# Generated at 2022-06-25 08:44:22.335784
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook = 'argument_0')

# Generated at 2022-06-25 08:44:25.889814
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    cb = CallbackModule()
    td = TaskData('a', 'b', 'c', 'd', 'e')
    host_data_0 = HostData('f', 'g', 'h', 'i')
    td.add_host(host_data_0)
    if td.host_data['f'].name != 'g':
        raise Exception('Failed')


# Generated at 2022-06-25 08:45:30.514571
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    arg_0 = Playbook()
    callback_module_0.v2_playbook_on_start(arg_0)


# Generated at 2022-06-25 08:45:32.588641
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    ansible_runner_result_0 = FakeResult()
    assert callback_module_0._finish_task('failed', ansible_runner_result_0) is None


# Generated at 2022-06-25 08:45:37.351541
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {
        '_ansible_parsed': True,
        '_ansible_no_log': False,
        '_ansible_item_result': True,
        '_ansible_ignore_errors': False,
        '_ansible_item_label': {},
        'changed': False,
        'failed': True,
        'skip_reason': 'Conditional check failed',
        'invocation': {
            'module_name': 'test',
            'module_args': {}
        }
    }
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:45:43.684819
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = FakeResult()
    ignore_errors_0 = True
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:45:49.395211
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:45:52.474492
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:45:58.062121
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    uuid = 'a'
    name = 'b'
    path = 'c'
    play = 'd'
    action = 'e'
    taskData_0 = TaskData(uuid, name, path, play, action)
    uuid_1 = 'f'
    name_1 = 'g'
    host_data_0 = HostData(uuid_1, name_1, None, None)
    taskData_0.add_host(host_data_0)


# Generated at 2022-06-25 08:46:01.019195
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module = CallbackModule()
    test_TaskData_add_host_1 = TaskData("f0a6bd17-bb52-43f7-b1da-29a7cae56e9d","[Start] the entity")
    test_HostData_1 = HostData("host","host","ok")
    test_TaskData_add_host_1.add_host(test_HostData_1)


# Generated at 2022-06-25 08:46:06.224261
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # instantiate the callback module
    callback_module_0 = CallbackModule()

    # instantiate the playbook
    playbook_0 = {
        'hosts': 'hosts',
        'name': 'playbook_0',
    }
    # host/group
    hosts_0 = []
    # task
    tasks_0 = []
    # play
    plays_0 = [
        {
            'hosts': 'hosts_0',
            'name': 'play_0',
            'tasks': 'tasks_0',
        },
    ]
    playbook_0['hosts'] = hosts_0
    playbook_0['plays'] = plays_0

    # parameters for v2_playbook_on_start
    # playbook
    playbook_0 = playbook_0

    # call the method
    callback_module_