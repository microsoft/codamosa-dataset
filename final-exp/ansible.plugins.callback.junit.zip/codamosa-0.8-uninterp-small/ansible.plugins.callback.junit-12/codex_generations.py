

# Generated at 2022-06-25 08:36:19.572832
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = 'playbook'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:36:26.759190
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback = CallbackModule()
    task_data = TaskData("123", "taskName", "path", "play", "action")
    host_data = HostData("123", "hostName", "ok", "result")
    task_data.add_host(host_data)



# Generated at 2022-06-25 08:36:30.194349
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(task_uuid, task_name, task_path, task_play, task_action)
    host = HostData(host_uuid, host_name, host_status, host_result)
    task_data.add_host(host)


# Generated at 2022-06-25 08:36:39.167987
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid_1', name='name_1', path='path_1', play='play_1', action='a_1')
    task_data_0.host_data['host_data_2'] = 'HostData_1'
    host_data_1 = HostData('uuid_2', 'name_2', 'status_2', 'result_2')
    callback_module_0._task_data['task_data_0'] = task_data_0
    callback_module_0._task_data['task_data_0'].add_host(host_data_1)


# Generated at 2022-06-25 08:36:47.099004
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module = CallbackModule()
    uuid_0 = 'abcdefgh'
    name_0 = 'string'
    path_0 = 'string'
    play_0 = 'string'
    action_0 = 'string'
    tasks_data_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)
    host_0 = HostData('abcdefgh', 'string', 'ok', 'ok')
    tasks_data_0.add_host(host_0)
    assert True == True

# Generated at 2022-06-25 08:36:51.305053
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData('@34f1', "task-0", 'playbook-0.yml', 'play-0', 'action-0')
    host_data_0 = HostData('Nzk}', 'host-0', 'ok', 'result-0')

    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:36:52.713639
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:36:57.527063
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    # HostData.__init__(self, uuid, name, status, result):
    host_data_0 = HostData('host_uuid', 'host_name', 'status', 'result')
    # Exception is raised by add_host
    try:
        task_data_0.add_host(host_data_0)
        task_data_0.add_host(host_data_0)
        assert False
    except Exception as e:
        assert True


# Generated at 2022-06-25 08:37:05.515709
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    TestFileName0 = 'playbook_0.yml'
    TestFileName1 = 'playbook_1.yml'
    TestFileName2 = 'playbook.yml'
    TestFileName3 = 'playbook'
    TestFileName4 = 'playbook_0.txt'
    TestFileName5 = 'playbook.yml.txt'
    TestFileName6 = 'playbook.txt.yml'
    TestFileName7 = 'playbook_with_path.yml'
    TestFileName8 = '/a/b/c/playbook_2.txt'

    callback_module_0 = CallbackModule()

    class Playbook():
        def __init__(self, file_name):
            self.file_name = file_name

        def get_file_name(self):
            return self

# Generated at 2022-06-25 08:37:10.441759
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    TaskDataTest = TaskData(0, 'test', 'test', 'test', 'test')
    HostDataTest = HostData(0, 'test', 'test', 'test')

    TaskDataTest.add_host(HostDataTest)

    assert TaskDataTest.host_data[0].status == 'test'


# Generated at 2022-06-25 08:37:25.460713
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
    host_0 = HostData(uuid='uuid_1', name='name_1', status='status_1', result='result_1')
    task_data_0.add_host(host=host_0)
    assert task_data_0.host_data['uuid_1'].status == 'status_1'


# Generated at 2022-06-25 08:37:28.856197
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:37:34.121901
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = {}
    result._task = {}
    result._task._uuid = "5cf5dab1-c5e5-4f58-a86e-4b9ce16d6652"
    callback_module_0 = CallbackModule()
    callback_module_0._start_task(result._task)
    callback_module_0.v2_runner_on_failed(result, True)
    pass


# Generated at 2022-06-25 08:37:40.347053
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host = HostData("host_uuid","host_name","host_status","host_result")
    callback_module_0 = CallbackModule()
    callback_module_0._task_data = {'uuid_0':TaskData("uuid_0","name_0","path_0","play_0","action_0")}
    assert callback_module_0._task_data['uuid_0'].add_host(host) == None
    assert callback_module_0._task_data['uuid_0'].host_data["host_uuid"].name == "host_name"
    assert callback_module_0._task_data['uuid_0'].host_data["host_uuid"].result == "host_result"



# Generated at 2022-06-25 08:37:47.948371
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(0,0,0,0,0)
    def get_host_name(self):
        return 'localhost'
    def add_host(self, host):
        if host.uuid in self.host_data:
            if host.status == 'included':
                # concatenate task include output from multiple items
                host.result = '%s\n%s' % (self.host_data[host.uuid].result, host.result)
            else:
                raise Exception('%s: %s: %s: duplicate host callback: %s' % (self.path, self.play, self.name, host.name))

        self.host_data[host.uuid] = host



# Generated at 2022-06-25 08:37:52.740833
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0,ignore_errors_0)


# Generated at 2022-06-25 08:38:04.710506
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	
	# Create an instance of class HostData
	host_data = HostData(host_uuid='test', host_name='test', status='test', result='test')

	# Create an instance of class TaskData
	task_data = TaskData(uuid='test', name='test', path='test', play='test', action='test')

	task_data.add_host(host_data)

	if len(task_data.host_data.items()) == 1:
		print('PASSED')
	else:
		print('FAILED')

	res = {'exception':'hello'}
	dump = 'dumped_string'

	status = 'failed'
	ignore_errors = False
	fail_on_ignore = True

	# Create an instance of class CallbackModule

# Generated at 2022-06-25 08:38:07.038776
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()

    # act
    callback_module.v2_runner_on_failed()



# Generated at 2022-06-25 08:38:12.740452
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._task_data = dict()
    with pytest.raises(Exception) as e_0:
        _task_data_0 = TaskData(uuid='', name='', path='', play='', action='')
        callback_module_0._task_data[''] = _task_data_0
        host_0 = HostData(uuid='', name='', status='', result='')
        callback_module_0._task_data[''].add_host(host_0)
    assert str(e_0.value) == ': : : duplicate host callback: '


# Generated at 2022-06-25 08:38:15.767037
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(1, 2, 3, 4, 5)
    host = HostData(1, 2, 3, 4)
    try:
        task_data.add_host(host)
        assert True
    except :
        assert False

# Generated at 2022-06-25 08:38:31.209873
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host_0 = HostData('', '', '', '')
    host_1 = HostData('', '', '', '')
    host_2 = HostData('', '', '', '')
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('', '', '', '', '')
    task_data_0.host_data['host_2.uuid'] = host_2
    task_data_0.add_host(host_0)
    task_data_0.add_host(host_1)
    task_data_0.add_host(host_2)


# Generated at 2022-06-25 08:38:35.320081
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('UUID', 'NAME', 'PATH', 'PLAY', 'ACTION')
    host_data_0 = HostData('METHOD', 'STATUS', 'RESULT')
    task_data_0.add_host(host_data_0)



# Generated at 2022-06-25 08:38:38.098653
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_TaskData_add_host_0 = TaskData(0, 0, 0, 0, 0)
    test_TaskData_add_host_1 = HostData(0, 0, 0, 0)
    test_TaskData_add_host_0.add_host(test_TaskData_add_host_1)


# Generated at 2022-06-25 08:38:39.380115
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    TaskData_instance_0 = TestCase()
    TaskData_instance_0.add_host()


# Generated at 2022-06-25 08:38:42.031121
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('playbook')


# Generated at 2022-06-25 08:38:47.205117
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    result_task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    result_host_data_0 = HostData('uuid_0', 'name_0', 'status_0', 'result_0')
    result_task_data_0.host_data = {'uuid_0': result_host_data_0}
    exception_occurred = False
    try:
        result_task_data_0.add_host(result_host_data_0)
    except Exception as e:
        exception_occurred = True
        assert str(e) == 'name_0: play_0: name_0: duplicate host callback: name_0'
    assert exception_occurred


test

# Generated at 2022-06-25 08:38:54.168014
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    assert callback_module_1._task_data == {}
    test_data_0 = callback_module_1._task_data
    test_data_1 = TaskData('uuid', 'name', 'path', 'play', 'action')
    test_data_1.add_host('host')
    assert test_data_0 == {'uuid':test_data_1}


# Generated at 2022-06-25 08:38:56.687791
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    result = 'result'
    callback_module.v2_runner_on_failed(result)
    assert isinstance(callback_module._task_data, dict)


# Generated at 2022-06-25 08:38:59.820714
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = os.path.splitext('/usr/local/repo/ansible/test.yml')[0]

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)



# Generated at 2022-06-25 08:39:03.800338
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = None

    callback_module_0.v2_playbook_on_start(playbook_0)
    assert(callback_module_0._playbook_name == 'Untitled')


# Generated at 2022-06-25 08:39:18.506165
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    _file_name = "/home/travis/build/ansible/ansible/test/test.yml"
    _loader = True
    _variable_manager = True
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(Playbook(_file_name, _loader, _variable_manager))
    assert callback_module._playbook_path == "/home/travis/build/ansible/ansible/test/test.yml"
    assert callback_module._playbook_name == "test"


# Generated at 2022-06-25 08:39:25.395380
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    v2_playbook_on_start_args = dict(playbook=None)
    v2_playbook_on_start_args['playbook'] = Mock()

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(**v2_playbook_on_start_args)


# Generated at 2022-06-25 08:39:27.521759
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()

    # Test with args
    args = dict(playbook = dict(
        _file_name = 'string', 
    ))

    callback_module_1.v2_playbook_on_start(**args)



# Generated at 2022-06-25 08:39:29.517470
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callbackModule = CallbackModule()
    result = "ok"
    ignore_errors = False
    callbackModule.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:39:38.083895
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    
    global callback_module_0
    callback_module_0 = CallbackModule()
    callback_module_0.disabled = True
    callback_module_0.v2_playbook_on_start(playbook)
    assert callback_module_0._playbook_path == playbook._file_name
    assert callback_module_0._playbook_name == os.path.splitext(os.path.basename(callback_module_0._playbook_path))[0]
    assert callback_module_0._play_name == None
    assert callback_module_0._task_data == {}


# Generated at 2022-06-25 08:39:43.701453
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(0, "task_data_name", "task_data_path", "task_data_play", "task_data_action")
    host = HostData(0, "host_name", "included", "result_result")
    task_data.add_host(host)
    task_data.add_host(host)
#
#    task_data.add_host(HostData(1, "host_name", "ok", "result_result"))
#
#    task_data.add_host(HostData(2, "host_name", "failed", "result_result"))
#
#    task_data.add_host(HostData(3, "host_name", "included", "result_result"))
#
#    task_data.add_host(HostData(4, "host

# Generated at 2022-06-25 08:39:45.508933
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = None
    ignore_errors_1 = None
    callback_module_1.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:39:47.134188
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:39:53.408116
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('playbook_0')
    assert callback_module_0._playbook_path == 'playbook_0'
    assert callback_module_0._playbook_name == 'playbook_0'


# Generated at 2022-06-25 08:39:57.687521
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_1 = "playbooks/someplay.yml"
    callback_module_1.v2_playbook_on_start(playbook_1)
    assert callback_module_1._playbook_path == playbook_1
    assert callback_module_1._playbook_name == "someplay"


# Generated at 2022-06-25 08:40:10.809886
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    task = None
    is_conditional = False
    result = None
    ignore_errors = True
    callback_module_0.v2_playbook_on_task_start(task, is_conditional)
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:40:17.516214
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    test_playbook_0 = Playbook()
    callback_module_1.v2_playbook_on_start(test_playbook_0)
    assert callback_module_1._playbook_path == ''
    assert callback_module_1._playbook_name == ''


# Generated at 2022-06-25 08:40:22.474994
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0._playbook_path = ("/usr/lib/python2.7/site-packages/ansible/playbooks/examples/test.yml")
    callback_module_0._playbook_name = None
    callback_module_0.v2_playbook_on_start(playbook)
    callback_module_0._playbook_path = ("/usr/lib/python2.7/site-packages/ansible/playbooks/examples/test.yml")
    callback_module_0._playbook_name = "test"


# Generated at 2022-06-25 08:40:28.186979
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed("result", False)


# Generated at 2022-06-25 08:40:31.421034
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Init
    callback_module_1 = CallbackModule()
    result = Result()
    ignore_errors = False

    # Execute method
    callback_module_1.v2_runner_on_failed(result, ignore_errors)



# Generated at 2022-06-25 08:40:37.678933
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = {"foo": "bar"} # change this
    ignore_errors = False # change this

    # Try to invoke the method
    try:
        callback_module_0.v2_runner_on_failed(result, ignore_errors)
    except Exception as e:
        print("Exception when calling v2_runner_on_failed: %s\n" % e)


# Generated at 2022-06-25 08:40:40.702114
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start(0)
    assert True


# Generated at 2022-06-25 08:40:43.553823
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    ansible_playbook_0 = ansible_playbook.AnsiblePlaybook()
    #callback_module_0.v2_playbook_on_start(ansible_playbook_0)
    assert True


# Generated at 2022-06-25 08:40:51.845558
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    task_0 = Task()
    result_0 = Result()
    task_0._uuid = '0'
    task_0.get_name = lambda: '0'
    task_0.get_path = lambda: '0'
    task_0.action = '0'
    callback_module_0._task_data['0'] = TaskData('0', '0', '0', '0', '0')
    callback_module_0._task_data['0'].add_host(HostData('0', '0', '0', '0'))
    callback_module_0._task_data['0'].start = '0'
    result_0._task = task_0
    result_0._host = Host()

# Generated at 2022-06-25 08:40:55.978858
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('playbook')


# Generated at 2022-06-25 08:41:19.570785
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    global callback_module_0
    callback_module_0.v2_runner_on_failed(result, ignore_errors=False)


# Generated at 2022-06-25 08:41:23.102509
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = None
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:41:26.204595
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    dummy_playbook = object() # Dummy for __init__(self, **kwargs)
    callback_module_1.v2_playbook_on_start(dummy_playbook)


# Generated at 2022-06-25 08:41:29.126671
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('test_value_1')
    assert callback_module_0.v2_playbook_on_start('test_value_1') == 'test_value_1'


# Generated at 2022-06-25 08:41:34.257058
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = mock()
    ignore_errors = false

    # Call method
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:41:46.329636
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    args = [
        """/home/kkopachev/git/ansible/local/osops-utils-ansible-tests/roles/test-role-test-role-test-role/tests/test_role_test_role_test_role.yml"""
    ]

    verify_results = """ansible-playbook-2.8.2-1547.506_test_role_test_role_test_role"""

    results = playbuf = playbook = None

    # Establish that the method to test exists
    try:
        playbook = args[0]
        playbuf = os.path.basename(playbook)
        Results = os.path.splitext(playbuf)[0]
    except NameError:
        pass # Ignore the failure and continue testing

    # Establish that the method to test exists

# Generated at 2022-06-25 08:41:49.201827
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:41:52.317467
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:41:54.645680
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Instantiate the CallbackModule class
    callback_module_0 = CallbackModule()
    # Call method v2_runner_on_failed of CallbackModule instance callback_module_0
    callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:41:58.708726
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = object()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:42:21.790461
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start('not used')


# Generated at 2022-06-25 08:42:25.409864
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    test_case_0()
    callback_module_0 = CallbackModule()
    playbook_0 = Mock(name='playbook_0')
    test_case_0 = callback_module_0.v2_playbook_on_start(playbook=playbook_0)


# Generated at 2022-06-25 08:42:28.658080
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # set up inputs
    callback_module_var_0_0 = CallbackModule()
    callback_module_var_0_1 = playbook_0 = None

    # invoke method
    callback_module_var_0_0.v2_playbook_on_start(callback_module_var_0_1)


# Generated at 2022-06-25 08:42:34.415108
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0._playbook_name = None
    callback_module_0._playbook_path = None
    callback_module_0._play_name = None
    callback_module_0._task_data = {}
    callback_module_0.disabled = False
    playbook_0 = Mock()
    playbook_0._file_name = ""
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_name == os.path.splitext(os.path.basename(callback_module_0._playbook_path))[0] == ""


# Generated at 2022-06-25 08:42:39.568466
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create class instance
    callback_module_0 = CallbackModule()

    # Call method v2_runner_on_failed with parameters
    result = callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:42:43.907149
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of class CallbackModule
    callback_module_0 = CallbackModule()

    # Assign parameter 'playbook' value 'None'
    playbook = None

    # Call method v2_playbook_on_start of class CallbackModule with parameter playbook
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:42:46.652331
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    # Arrange
    v2_playbook_on_start_0 = CallbackModule()
    v2_playbook_on_start_0.disabled = False

    # Act
    v2_playbook_on_start_0.v2_playbook_on_start(playbook=None)

    # Assert


# Generated at 2022-06-25 08:42:48.516542
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start(playbook_0) # Call method with Arguments



# Generated at 2022-06-25 08:42:51.583196
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_v2_runner_on_failed_0 = CallbackModule()
    job_result_0 = JobResult()
    ignore_errors = False
    callback_module_v2_runner_on_failed_0.v2_runner_on_failed(job_result_0, ignore_errors)


# Generated at 2022-06-25 08:42:57.201741
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb_mock = MagicMock()
    cb_mock.CALLBACK_VERSION = 2.0
    cb_mock.CALLBACK_TYPE = 'aggregate'
    cb_mock.CALLBACK_NAME = 'junit'
    cb_mock.CALLBACK_NEEDS_ENABLED = True
    cb_mock.__init__ = MagicMock()
    cb_mock._output_dir = os.getenv('JUNIT_OUTPUT_DIR', os.path.expanduser('~/.ansible.log'))
    cb_mock._task_class = os.getenv('JUNIT_TASK_CLASS', 'False').lower()

# Generated at 2022-06-25 08:43:32.355033
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    task_uuid = result._task._uuid

    if task_uuid in self._task_data:
        return

    play = self._play_name
    name = task.get_name().strip()
    path = task.get_path()
    action = task.action

    if not task.no_log and self._hide_task_arguments == 'false':
        args = ', '.join(('%s=%s' % a for a in task.args.items()))
        if args:
            name += ' ' + args

    self._task_data[uuid] = TaskData(uuid, name, path, play, action)
    


# Generated at 2022-06-25 08:43:35.255550
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    print("test_CallbackModule_v2_playbook_on_start:")
    # TODO
    pass



# Generated at 2022-06-25 08:43:42.237901
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    ansible_playbook_file_name = 'main.yml'
    playbook = {'_file_name': ansible_playbook_file_name}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    assert callback_module_0._playbook_path == ansible_playbook_file_name
    assert callback_module_0._playbook_name == 'main'


# Generated at 2022-06-25 08:43:47.828711
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    import os
    import pdb
    from ansible.playbook import Playbook
    from ansible.utils.vars import merge_hash

    playbook = Playbook.load('playbook.yml', variable_manager=merge_hash({'hosts': 'localhost'}, os.environ), loader=None)
    callback_module_0.v2_playbook_on_start(playbook)
    pass


# Generated at 2022-06-25 08:43:56.761072
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    v2_runner_on_failed_0 = CallbackModule()
    result_0 = MockTaskResult(task=MockTask(), host=MockHost(), results=True, changed=True)
    ignore_errors_1 = False
    try:
        v2_runner_on_failed_0.v2_runner_on_failed(result_0, ignore_errors_1)

    except AssertionError:
        fail("test_CallbackModule_v2_runner_on_failed(): assertion 0 failed")


# Generated at 2022-06-25 08:44:00.999626
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    task_data_0 = TaskData(
        'uuid_0',
        'name_0',
        'path_0',
        'play_0',
        'action_0'
    )
    callback_module_0 = CallbackModule()
    test_case = TestCase(
        name='[host_name_0] play_0: name_0',
        classname='path_0',
        time=0.0,
        system_out='',
        failures=[TestFailure(
            message='rc=0',
            output=''
        )]
    )
    result_0 = Result(
        'host_name_0',
        'host_0',
        'task_0',
        {
            'rc': 0
        }
    )

# Generated at 2022-06-25 08:44:03.845943
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_0 = {'_file_name': 'test_file_name'}
    callback_module_1.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:44:04.717196
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:44:12.188408
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    assert callback_module_0._playbook_path == None
    assert callback_module_0._playbook_name == None
    callback_module_0.v2_playbook_on_start("playbook")
    assert callback_module_0._playbook_path == "playbook._file_name"
    assert callback_module_0._playbook_name == "os.path.splitext(os.path.basename(callback_module_0._playbook_path))[0]"


# Generated at 2022-06-25 08:44:15.989527
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    # Test playbook file
    playbook_file_0 = 'playbook.yml'
    callback_module_0.v2_playbook_on_start(playbook_file_0)


# Generated at 2022-06-25 08:45:11.448167
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:45:16.044750
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    test_playbook = TestPlaybook()
    callback_module.v2_playbook_on_start(test_playbook)


# Generated at 2022-06-25 08:45:20.770410
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = MockPlaybook()
    callback_module_0.v2_playbook_on_start(playbook_0)
    

# Generated at 2022-06-25 08:45:25.572655
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()

    runner_on_failed_1_result = None
    # RunnerOnFailedResult. Result of a failed runner execution
    runner_on_failed_1_ignore_errors = True
    # boolean. Whether execution should be ignored or not

    callback_module_1.v2_runner_on_failed(runner_on_failed_1_result, runner_on_failed_1_ignore_errors)
    assert isinstance(callback_module_1, CallbackModule)


# Generated at 2022-06-25 08:45:27.731910
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1._fail_on_ignore = 'false'
    callback_module_1._finish_task('failed', None)


# Generated at 2022-06-25 08:45:33.458380
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = None
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)



# Generated at 2022-06-25 08:45:34.962186
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed(result='result_0')


# Generated at 2022-06-25 08:45:39.775286
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = 'playbook/path'
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:45:43.839547
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    playbook = "playbook_example.yml"
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:45:52.207496
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Test steps and verification assertions
    task = object()
    result = object()
    ignore_errors = False
    # Call the method under test
    callback_module_0.v2_runner_on_failed(result, ignore_errors)
