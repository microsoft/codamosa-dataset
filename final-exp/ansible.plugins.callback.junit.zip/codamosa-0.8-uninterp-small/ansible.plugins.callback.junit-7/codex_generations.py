

# Generated at 2022-06-25 08:36:20.419601
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 2443.0
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)
    var_1 = TaskData(var_0, 'name', 'path', 'play', 'action')
    var_2 = HostData('host_uuid', 'host_name', 'host_status', 'host_result')
    var_1.add_host(var_2)
    assert var_1.start == time.time()


# Generated at 2022-06-25 08:36:28.233943
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 2443.0
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)
    stdout_0 = ''.join(var_0)
    task_data_0 = TaskData(stdout_0, stdout_0, stdout_0, stdout_0, stdout_0)
    assert raise_exception_on_failure(task_data_0)


# Generated at 2022-06-25 08:36:29.740139
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 2443.0
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:36:39.829113
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 2443.0
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)
    callback_module_1 = CallbackModule()
    callback_v2_runner_on_ok(callback_module_1)
    callback_module_2 = CallbackModule()
    if not var_0:
        callback_v2_playbook_on_task_start(callback_module_2)
    else:
        callback_v2_runner_on_skipped(callback_module_2)
    callback_module_3 = CallbackModule()
    callback_v2_runner_on_no_hosts(callback_module_3)
    callback_module_4 = CallbackModule()

# Generated at 2022-06-25 08:36:51.946651
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    uuid_0 = '0dpd'
    name_0 = 'The task name'
    path_0 = '.data/task/test.yml'
    play_0 = 'test play'
    action_0 = 'test action'
    assert isinstance(task_data_0, TaskData)
    assert task_data_0.name == name_0
    assert task_data_0.path == path_0
    assert task_data_0.play == play_0
    assert task_data_0.start is None
    assert task_data_0.host_data == {}
    assert task_data_0.action == action_0
    assert task_data_0.uuid == uuid_0


# Generated at 2022-06-25 08:36:53.840333
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    taskdata_0 = TaskData()
    task_data_taskdata_0 = HostData()
    # Put your implementation here!
    taskdata_0.add_host(task_data_taskdata_0)


# Generated at 2022-06-25 08:37:01.707946
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    float_0 = 2443.0
    float_1 = float_0
    var_0 = callback_v2_runner_on_failed(float_0, float_1)


# Generated at 2022-06-25 08:37:14.447221
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playlist = PlayList()
    float_0 = float()
    float_0 = float_0 + float(float_0)
    float_0 = float_0 * float(float_0)
    float_0 = float_0 % float(float_0)
    float_0 = float_0 * float(float_0)
    float_1 = float()
    float_1 = float_0 * float(float_0)
    float_1 = float_1 + float(float_0)
    float_1 = float_1 * float(float_1)
    float_1 = float_1 * float(float_1)
    float_1 = float_1 * float(float_1)
    float_1 = float_1 * float(float_1)
    float_1

# Generated at 2022-06-25 08:37:17.855074
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 2443.0
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_start(float_0)


# Generated at 2022-06-25 08:37:21.953395
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    float_0 = 2443.0
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(float_0, callback_module_0)
    host_data_0 = HostData(float_0)

    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:37:44.666851
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    print('Test #1')
    print('Description: Tests the method v2_playbook_on_start from class CallbackModule')

    # Test 1.1 - Tests a valid case

    # Setup test 1.1
    callback_module_0 = CallbackModule()
    _file_name = 'test_case.py'
    playbook_0 = type('', (), {'_file_name': _file_name})
    print('\tTest 1.1 - Tests a valid case')

    # Execute test 1.1
    callback_module_0.v2_playbook_on_start(playbook_0)

    # Validate test 1.1

# Generated at 2022-06-25 08:37:51.740653
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._task_data = {'NG': TaskData(uuid='NG', name='TaskName', path='TaskPath', play='TaskPlay', action='TaskAction')}
    callback_module_0._task_data['NG'].host_data = {'HostUuid': HostData(uuid='HostUuid', name='HostName', status='HostStatus', result='HostResult')}
    callback_module_0._task_data['NG'].host_data['HostUuid'].status = 'HostStatus'
    callback_module_0._task_data['NG'].host_data['HostUuid'].result = 'HostResult'

# Generated at 2022-06-25 08:37:52.549097
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 08:38:00.133768
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of class CallbackModule
    callback_module = CallbackModule()
    assert isinstance(callback_module, CallbackModule) == True

    # Setup test case
    class DummyAnsiblePlaybook:
        """ Dummy class for testing method v2_playbook_on_start """

        def __init__(self):
            self._file_name = None

        def _get_file_name(self):
            return self._file_name
    playbook = DummyAnsiblePlaybook()
    playbook._file_name = "playbook"

    # Call the method
    callback_module.v2_playbook_on_start(playbook)

    # Verify the results
    assert callback_module._playbook_path == "playbook"
    assert callback_module._playbook_name == "playbook"



# Generated at 2022-06-25 08:38:04.791301
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(uuid, name, path, play, action)
    print('Start test for method add_host of class TaskData.')
    result = None
    assert (task_data.add_host(result) == None)
    print('End test for method add_host of class TaskData.')


# Generated at 2022-06-25 08:38:07.163143
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start('playbook')


# Generated at 2022-06-25 08:38:16.382261
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    from ansible.task_vars import TaskVars
    task_vars_0 = TaskVars(0)
    task_0 = None
    task_vars_0.task = task_0
    from ansible.vars.manager import VariableManager
    variable_manager_0 = VariableManager(loader=None, variables=None, inventory=None, version_data=None)
    from ansible.inventory.manager import InventoryManager
    inventory_manager_0 = InventoryManager(loader=None, sources=None, sources_dicts=None)
    callback_module_0._playbook_name = 'playbook_name'
    callback_module_0._start_task(task_0)

if __name__ == "__main__":
    test_case_0()
    test

# Generated at 2022-06-25 08:38:18.705584
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    TaskData_instance_0 = TaskData()
    TaskData_instance_0.add_host()


# Generated at 2022-06-25 08:38:25.164736
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(None, None, None, None, None)
    host_0 = HostData(None, None, None, None)
    try:
        task_data_0.add_host(host_0)
    except Exception as e:
        assert str(e) == 'None: None: None: duplicate host callback: None'


# Generated at 2022-06-25 08:38:33.125988
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_uuid_0 = ''
    name_0 = 'foo'
    path_0 = 'bar'
    play_0 = 'baz'
    action_0 = 'qux'
    task_data_1 = TaskData(task_uuid_0, name_0, path_0, play_0, action_0)
    host_uuid_0 = ''
    host_name_0 = 'foo'
    status_0 = 'bar'
    result_0 = 'baz'
    host_data_0 = HostData(host_uuid_0, host_name_0, status_0, result_0)
    task_data_1.add_host(host_data_0)


# Generated at 2022-06-25 08:38:43.509261
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('123', '', '', '', 'debug')
    #TODO: test for the case, if the host data is not in the object host_data, but with the same uuid


# Generated at 2022-06-25 08:38:48.825432
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_data_0 = HostData(host_uuid_0, host_name_0, host_status_0, host_result_0)
    callback_module_0._TaskData__add_host(host_data_0)


# Generated at 2022-06-25 08:38:58.399509
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    callback_module_2 = CallbackModule()
    callback_module_3 = CallbackModule()
    
    t_0 = TaskData("cafebabe","","","","")
    t_1 = TaskData("cafebabe","","","","")
    t_2 = TaskData("cafebabe","","","","")
    t_3 = TaskData("cafebabe","","","","")

    h_0 = HostData("cafebabe","","","","")
    h_1 = HostData("cafebabe","host","","","")
    h_2 = HostData("cafebabe","host2","","","")
    h_3 = HostData("cafebabe","host","","","")

   

# Generated at 2022-06-25 08:38:59.788413
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    assert callback_module_0


# Generated at 2022-06-25 08:39:07.949963
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """
    This method tests the add_host method of the TaskData class.
    """

    name = 'host-1'
    uuid = 'abc-123'
    status = 'ok'
    result = 'result'
    host = HostData(uuid, name, status, result)
    task_data = TaskData('test_UUID', 'test_name', 'test_path', 'test_play', 'test_action')

    task_data.add_host(host)

    assert task_data.host_data[uuid].name == name
    assert task_data.host_data[uuid].status == status
    assert task_data.host_data[uuid].result == result


# Generated at 2022-06-25 08:39:12.439738
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

    result_0 = Result()
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors=True)
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors=False)


# Generated at 2022-06-25 08:39:19.718685
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    '''
        function to test add_host method of class TaskData
    '''
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start('playbook')
    callback_module_1.v2_playbook_on_play_start('play')
    callback_module_1.v2_playbook_on_task_start('task1', 'is_conditional')
    callback_module_1.v2_playbook_on_task_start('task2', 'is_conditional')
    callback_module_1.v2_runner_on_ok('result')
    callback_module_1.v2_runner_on_ok('result')

# Generated at 2022-06-25 08:39:28.397391
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    task_data_0_uuid = 'task_data_0_uuid'
    task_data_0_name = 'task_data_0_name'
    task_data_0_path = 'task_data_0_path'
    task_data_0_play = 'task_data_0_play'
    task_data_0_action = 'task_data_0_action'
    task_data_0 = TaskData(task_data_0_uuid, task_data_0_name, task_data_0_path, task_data_0_play, task_data_0_action)

    host_0_uuid = 'host_0_uuid'
    host_0_name = 'host_0_name'
    host_0_status = 'host_0_status'
    host_

# Generated at 2022-06-25 08:39:36.023492
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(uuid='', name='', path='', play='', action='')
    callback_module_1 = CallbackModule()
    with pytest.raises(Exception) as excinfo:
        task_data.add_host(callback_module_1._finish_task())
    assert excinfo.value == 'must be set to a object of type HostData'


# Generated at 2022-06-25 08:39:40.496321
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action='action_0')
    host_data_0 = HostData(uuid='uuid_0', name='name_0', status='status_0', result='result_0')
    try:
        task_data_0.add_host(host=host_data_0)
        assert False
    except:
        assert True


# Generated at 2022-06-25 08:40:05.740775
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid_0='uuid_0', name_0='name_0', path_0='path_0', play_0='play_0', action_0='action_0')
    host_data_0 = HostData(uuid_0='uuid_0', name_0='name_0', status_0='status_0', result_0='result_0')
    task_data_0.add_host(host_data_0)
    host_data_0 = HostData(uuid_0='uuid_0', name_0='name_0', status_0='status_0', result_0='result_0')
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:40:08.733442
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """test_TaskData_add_host"""

    #test_TaskData_add_host.__doc__ = TaskData.add_host.__doc__
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:40:10.862268
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    TaskData_0 = TaskData(uuid=uuid, action=action, play=play, path=path, name=name)
    callback_module_0.TaskData.add_host(host=host)


# Generated at 2022-06-25 08:40:14.025194
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task = TaskData('', '', '', '', '')
    callback_module_1.task = task
    host_data = HostData('', '', '', '')
    callback_module_1.host_data = host_data
    host = HostData('', '', '', '')
    callback_module_1.host = host
    callback_module_1.task.add_host(callback_module_1.host)


# Generated at 2022-06-25 08:40:18.263929
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_3 = FakeResult()
    result_3.rc = 1
    callback_module_1.v2_runner_on_failed(result_3)


# Generated at 2022-06-25 08:40:25.886002
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    assert callback_module_0._build_test_case(test_case_0()) == True


# Generated at 2022-06-25 08:40:28.836371
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(5, 'fS', 'UGwEV', 'fWdU', '3U4c')
    host_data_0 = HostData('A', '1O', '1Q', 'W')
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:40:35.830505
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('task_uuid_0', 'name_0', 'path_0', 'play_0', 'action_0')
    exception = None
    try:
        task_data_0.add_host(host='host_0')
    except Exception as exc:
        exception = exc
    assert exception is not None


# Generated at 2022-06-25 08:40:39.281210
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(str(), str(), str(), str(), str())
    host_data_0 = HostData(str(), str(), str(), str())
    try:
        task_data_0.add_host(host_data_0)
    except:
        print("Exception when invoking add_host on TaskData")


# Generated at 2022-06-25 08:40:44.140718
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Case1:
    callback_module_1 = CallbackModule()
    task_data_1 = TaskData(0, 'task_name', 'path', 'play_name', 'action')
    host_data_1 = HostData(0, 'host_name', 'status', 'result')
    task_data_1.add_host(host_data_1)
    assert task_data_1.host_data[0].status == 'status'


# Generated at 2022-06-25 08:41:17.937444
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1._task_data = {'a9e21e7c-26d0-4de7-b235-1a7f8a691f3c': TaskData('a9e21e7c-26d0-4de7-b235-1a7f8a691f3c', '[root] play 1: task 2', 'playbook1.yml', 'play 1', 'command')}

# Generated at 2022-06-25 08:41:26.331549
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    class HostData:
        """
        Data about an individual task on a single host.
        """

        def __init__(self, uuid, name, status, result):
            self.uuid = uuid
            self.name = name
            self.status = status
            self.result = result
            self.finish = time.time()

    class TaskData:
        """
        Data about an individual task.
        """

        def __init__(self, uuid, name, path, play, action):
            self.uuid = uuid
            self.name = name
            self.path = path
            self.play = play
            self.start = None
            self.host_data = {}
            self.start = time.time()
            self.action = action


# Generated at 2022-06-25 08:41:28.745916
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_1 = Result()
    ignore_errors_2 = True
    callback_module_0.v2_runner_on_failed(result_1, ignore_errors_2)


# Generated at 2022-06-25 08:41:36.755847
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # TaskData class instance
    callback_module_1 = TaskData('uuid', 'name', 'path', 'play', 'action')
    # HostData class instance
    callback_module_2 = HostData('host_uuid', 'host_name', 'host_status', 'host_result')
    # Set attribute host_data for object callback_module_1
    callback_module_1.host_data = {'host_uuid': callback_module_2}
    # HostData class instance
    callback_module_3 = HostData('host_uuid', 'host_name', 'host_status', 'host_result')
    # Execute method add_host of class TaskData with parameters callback_module_1, callback_module_3
    callback_module_1.add_host(callback_module_3)



# Generated at 2022-06-25 08:41:41.593155
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1._task_data = {}
    task_uuid_0 = 'task_uuid_0'
    callback_module_1._task_data.update({task_uuid_0: TaskData(task_uuid_0, 'name_0', 'path_0', 'play_0', 'action_0')})
    assert len(callback_module_1._task_data) == 1
    callback_module_1._task_data[task_uuid_0].add_host(HostData('host_uuid_0', 'name_1', 'status_0', 'result_0'))
    assert len(callback_module_1._task_data) == 1



# Generated at 2022-06-25 08:41:43.918796
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    fn = test_case_0
    obj = TaskData()
    host = HostData()
    obj.add_host(host)


# Generated at 2022-06-25 08:41:49.189947
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_0 = HostData()
    host_0.status = "included"
    host_0.uuid = 0
    host_0.name = "test"
    host_0.result = "result"
    task_data_0 = callback_module_0._task_data[0]
    task_data_0.add_host(host_0)
    assert task_data_0.host_data[host_0.uuid].result == host_0.result
    assert task_data_0.host_data[host_0.uuid].status == host_0.status


# Generated at 2022-06-25 08:41:58.911513
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    if True:
        callback_module_0 = CallbackModule()
        callback_module_0._task_data = { '111': TaskData('111', 'aaa', 'bbb', 'ccc', 'setup') }
        result = callback_module_0._task_data['111'].add_host(HostData('222', 'host1', 'ok', 'result1'))


# Generated at 2022-06-25 08:42:02.109675
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_data_0 = HostData(host_uuid_0, host_name_0, host_status_0, host_result_0)
    callback_module_0._task_data[task_uuid_0] = TaskData(uuid, name, path, play, action)
    callback_module_0._task_data[task_uuid_0].add_host(host_data_0)


# Generated at 2022-06-25 08:42:10.334144
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_uuid = 'task_uuid'
    name = 'name'
    path = 'path'
    play = 'play'
    action = 'action'
    callback_module_0._task_data[task_uuid] = TaskData(task_uuid, name, path, play, action)
    callback_module_0.host_data = 'host_data'
    host = HostData('host_uuid', 'host_name', 'host_status', 'host_result')
    callback_module_0._task_data[task_uuid].add_host(host)
    


# Generated at 2022-06-25 08:43:06.374317
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Test input
    uuid_0  = "abcdii1234"
    name_0  = "test_case_0"
    path_0  = "test_case_0.yml"
    play_0  = "playbook_test.yml"
    action_0  = ""
    host_uuid_0 = "1234"
    host_name_0 = "test_task"
    status_0 = "ok"
    result_0 = "success"
    # Run function
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)
    host_data_0 = HostData(host_uuid_0, host_name_0, status_0, result_0)

# Generated at 2022-06-25 08:43:09.522119
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('aaaaa', 'bbbbb', 'ccccc', 'ddddd', 'eeeee')
    result_0 = task_data_0.add_host(HostData('fffff', 'ggggg', 'ok', 'hhhhh'))

    assert result_0 is None



# Generated at 2022-06-25 08:43:16.821784
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    # TaskData.add_host(host)
    # TaskData.add_host(self, host)
    # TaskData.add_host(self, host)
    # TaskData.add_host(self, host)
    # TaskData.add_host(self, host)
    # TaskData.add_host(self, host)
    # TaskData.add_host(self, host)
    # TaskData.add_host(self, host)
    # TaskData.add_host(self, host)

    assert True


# Generated at 2022-06-25 08:43:26.129790
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_1', 'path_2', 'play_3', 'action_4')
    host_data_0 = HostData('uuid_0', 'name_1', 'included', 'result_3')
    host_data_0.finish = 5.679084435590539
    task_data_0.add_host(host_data_0)



# Generated at 2022-06-25 08:43:33.855955
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
	# Create a task data
	task_data = TaskData('', '', '', '', '')
	# Create a hostdata
	host_data = HostData('', '', '', '')
	# Add host to taskdata
	task_data.add_host(host_data)
	
	# We cannot test the code INSIDE the IF statement since the IF statement is based on some conditions that change throughout the run
	# So we have to test 2 conditions: when the IF statement is TRUE or FALSE
	
	# Test when IF statement is FALSE, that the value of result is not added to host data
	assert task_data.host_data[host_data.uuid].result == host_data.result
	
	# Test when IF statement is TRUE, that the value of host data is added
	# host_data.result = '42'
	

# Generated at 2022-06-25 08:43:37.931282
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(0, '', '', '', '')
    host_data_0 = HostData(0, '', '', '', '', '', '')
    task_data_0.add_host(host_data_0)
    task_data_1 = TaskData(0, '', '', '', '')
    host_data_1 = HostData(0, '', '', '', '', '', '')
    task_data_1.add_host(host_data_1)


# Generated at 2022-06-25 08:43:41.054793
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    # Call method add_host of class TaskData
    callback_module_1.TaskData.add_host(callback_module_1)


# Generated at 2022-06-25 08:43:45.511692
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert True


# Generated at 2022-06-25 08:43:47.610719
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("Test 1: ")
    test_case_0()
    assert True, "Pass"


# Generated at 2022-06-25 08:43:57.007965
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_cleanup_task_start('task')
    callback_module_1.v2_runner_on_ok('result')
    callback_module_1.v2_playbook_on_include('included_file')
    if (callback_module_1._task_data[callback_module_1._task_data.keys()[0]].host_data.keys()[0] == 'include'):
        return True
    else:
        return False


# Generated at 2022-06-25 08:45:23.748754
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    path_0 = '/Users/jimitdatta/ansible-junit.py'
    play_0 = 'PLAY [all]'
    name_0 = 'TASK [debug]'
    uuid_0 = 'e32adc31-5e06-4c5f-b5a9-ce08d60e8b01'
    host_name_0 = 'localhost'
    host_uuid_0 = '0a952d26-f21d-41dc-a4f1-4cbd69336075'
    status_0 = 'ok'
    result_0 = 'msg'
    host_data_0 = HostData(host_uuid_0, host_name_0, status_0, result_0)
    task_data_0

# Generated at 2022-06-25 08:45:28.613888
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(None, None, None, None, None)
    host_data_0 = HostData(None, None, None, None)
    task_data_0.host_data = dict()
    task_data_0.host_data[host_data_0.uuid] = host_data_0
    try:
        task_data_0.add_host(host_data_0)
    except:
        print("Caught expected exception when trying to add duplicate host")


# Generated at 2022-06-25 08:45:41.109264
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("test_TaskData_add_host:")
    task_data_0 = TaskData(uuid="task_data_0", name="task_data_0", path="task_data_0", play="task_data_0", action="task_data_0")
    try:
        task_data_0.add_host(HostData(uuid="host_data_0", name="host_data_0", status="failed", result="host_data_0"))
    except:
        print("Unit test for line number: " + str(traceback.tb_lineno()), sys.exc_info())

# Generated at 2022-06-25 08:45:46.298392
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()

    task_data_1 = TaskData(1, 2, 3, 4, 5)
    host_data_1 = HostData(1, 2, 3, 4)

    # Test case 1
    task_data_1.add_host(host_data_1)

    print("")
    print("test_TaskData_add_host() completed")


# Generated at 2022-06-25 08:45:56.070175
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    #
    # Setup
    #
    callback_module_1 = CallbackModule()
    task_data_0 = TaskData(
        'task_uuid',
        'task_name',
        'task_path',
        'test_play',
        'action'
    )
    host_data_0 = HostData(
        'host_uuid',
        'host_name',
        'failed',
        'result'
    )
    task_data_0.host_data = {'host_name': host_data_0}

    #
    # Function call
    #
    task_data_0.add_host(host_data_0)

    #
    # Assertion
    #
    assert True == True


# Generated at 2022-06-25 08:46:00.895560
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host_0 = HostData()
    callback_module_0._task_data["test_0"] = TaskData("test_0", "test_0", "test_0", "test_0", "test_0")
    callback_module_0._task_data["test_0"].host_data["host_0"] = HostData()
    test_case_0 = callback_module_0._task_data["test_0"]
    host_0 = callback_module_0._task_data["test_0"].host_data["host_0"]
    test_case_0.add_host(host_0)

