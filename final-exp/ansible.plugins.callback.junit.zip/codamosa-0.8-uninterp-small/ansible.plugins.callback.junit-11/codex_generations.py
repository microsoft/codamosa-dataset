

# Generated at 2022-06-25 08:36:26.583288
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("Test case 0")
    callback_module_0 = CallbackModule()
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('host_uuid', 'host_name', 'status', 'result')
    host_1 = HostData('host_uuid', 'host_name', 'status', 'result')
    host_2 = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host)
    task_data.add_host(host_1)
    task_data.add_host(host_2)
    # assert host_1.uuid in task_data.host_data

# Generated at 2022-06-25 08:36:30.025608
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = object()
    ignore_errors = False
    callback_module_0.v2_runner_on_failed(result, ignore_errors)
    # The above test is not yet implemented. :-(


# Generated at 2022-06-25 08:36:32.808121
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:36:41.118855
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    task_data_1 = TaskData('uuid1', 'name1', 'path1', 'play1', 'action1')


    task_data_1.add_host(HostData('uuid2', 'name2', 'status2', 'res2'))
    if task_data_1.host_data[0].uuid != 'uuid2':
        raise Exception('Value not as expected')
    if task_data_1.host_data[0].name != 'name2':
        raise Exception('Value not as expected')
    if task_data_1.host_data[0].status != 'status2':
        raise Exception('Value not as expected')
    if task_data_1.host_data[0].result != 'res2':
        raise Exception('Value not as expected')


# Generated at 2022-06-25 08:36:49.792735
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    args = ["test.yml"]
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    playbook = Play.load(args, variable_manager=variable_manager, loader=loader)
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    assert(True)



# Generated at 2022-06-25 08:36:50.377523
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-25 08:36:57.134370
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1._playbook_name = 'test_playbook_1'
    callback_module_1._play_name = 'test_play_1'
    task_data_1 = TaskData('test_task_1', 'test_name_1', 'test_path_1', 'test_play_1', 'test_action_1')
    host_data_1 = HostData('test_host_1', 'test_name_1', 'test_status_1', 'test_result_1')
    task_data_1.add_host(host_data_1)
    task_data_1.uuid = 'test_task_1'
    task_data_1.name = 'test_name_1'

# Generated at 2022-06-25 08:37:00.706914
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(result=None, ignore_errors=False)


# Generated at 2022-06-25 08:37:13.404380
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Define a class named Task, which has two members: name and action
    class Task:
        deprecated = None
        action = 'None'
        args = {}
        no_log = False

        # Define the constructor function
        def __init__(self, uuid, name):
            self._uuid = uuid
            self.name = name

        def get_name(self):
            return self.name

        def get_path(self):
            return 'None'

    # Define a class named Result, which has two members: _host and _result
    class Result:
        _host = 'None'
        _result = {
            'changed': False,
            'msg': 'None'
        }

    # Define the _finish_task function
    def _finish_task(status, result):
        print

# Generated at 2022-06-25 08:37:19.472164
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    _playbook = Mock()
    _playbook._file_name = 'playbook.yml'
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(_playbook)
    assert callback_module_0._playbook_path == 'playbook.yml'
    assert callback_module_0._playbook_name == 'playbook'


# Generated at 2022-06-25 08:37:31.147581
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook=["playbook"], loader=["loader"], variable_manager=["variable_manager"], options=["options"])


# Generated at 2022-06-25 08:37:34.868610
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_1 = callback_module_1.TaskData
    host_1 = callback_module_1.HostData
    task_data_1.add_host(host_1)
    assert callback_module_1.task_data[task_data_1.uuid] == host_1



# Generated at 2022-06-25 08:37:40.111733
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_case_0()
    test_TaskData_add_host_0()
    test_TaskData_add_host_1()
    test_TaskData_add_host_2()
    test_TaskData_add_host_3()
    test_TaskData_add_host_4()
    test_TaskData_add_host_5()
    test_TaskData_add_host_6()



# Generated at 2022-06-25 08:37:47.752289
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.vars.manager

    playbook = ansible.playbook.play.Play()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_play_start(playbook)

test_CallbackModule_v2_playbook_on_start.stypy_type_store = module_type_store

# Declaration of the 'HostData' class
# Getting the type of 'object' (line 97)
object_964 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 97, 15), 'object')


# Generated at 2022-06-25 08:37:52.973862
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Initialize class
    callback_module_1 = CallbackModule()
    task_data_0 = TaskData(uuid=0, name='name_0', path='path_0', play='play_0', action='a')
    host_uuid = 'host_uuid_0'
    host_name = 'host_name_0'
    host_status = 'host_status_0'
    host_result = 'host_result_0'
    host_0 = HostData(host_uuid=host_uuid, host_name=host_name, host_status=host_status, host_result=host_result)

    # Test method
    task_data_0.add_host(host_0)

    # Verify results

# Generated at 2022-06-25 08:37:54.096850
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:38:04.035099
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()

    task_uuid_0 = '75bba3a3-1f34-40e3-b78c-7c95a9315b0f'
    callback_module_0._task_data[task_uuid_0] = TaskData(task_uuid_0, 'cli script', 'release.yml', 'release', 'script')
    host_data_0 = HostData('myhost', 'myhost', 'included', 'i am included')
    callback_module_0._task_data[task_uuid_0].add_host(host_data_0)


# Generated at 2022-06-25 08:38:05.065508
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert True


# Generated at 2022-06-25 08:38:09.572983
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    test_host_data_0 = HostData('host_uuid', 'host_name', 'status', 'result')
    test_task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    test_task_data_0.start = 'start'
    test_task_data_0.add_host(test_host_data_0)



# Generated at 2022-06-25 08:38:11.647056
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start()


# Generated at 2022-06-25 08:38:33.694398
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    
    task_data_0 = TaskData("uuid_0", "name_0", "path_0", "play_0", "action_0")
    host_data_0 = HostData("uuid_0", "name_0", "status_0", "result_0")
    
    
    try:
        task_data_0.add_host(host_data_0)
    except Exception as err:
        pass
    try:
        task_data_0.add_host(host_data_0)
    except Exception as err:
        print("Exception raised: ", err)
    else:
        print("No exception raised")

test_TaskData_add_host()



# Generated at 2022-06-25 08:38:48.194839
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    import collections

    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars import combine_vars

    callback_module_0 = CallbackModule()

    # Test playbook._file_name
    # self._playbook_path = playbook._file_name
    callback_module_0._playbook_path = 'playbook_0.yaml'
    callback_module_0.v2_playbook_on_start('playbook_0.yaml')
    assert callback_module_0._playbook_path == 'playbook_0.yaml'

    # Test os.path.splitext(os.path.basename

# Generated at 2022-06-25 08:38:51.588249
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_mock_0 = Mock(name='playbook_mock_0')

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_mock_0)



# Generated at 2022-06-25 08:39:02.713441
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    import unittest
    class TaskDataTestCase(unittest.TestCase):

        def test_TaskData_add_host_1(self):
            task_data_0 = TaskData()

            task_data_0.start = 0
            task_data_0.path = ''
            task_data_0.boo = ''
            task_data_0.action = ''
            task_data_0.host_data = {}
            task_data_0.play = ''
            task_data_0.name = ''
            task_data_0.uuid = ''
            class host():
                def __init__(self):
                    self.uuid = ''
                    self.name = ''
                    self.status = ''
                    self.result = ''
            task_data_0.add_host(host())
    un

# Generated at 2022-06-25 08:39:08.434970
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_0 = None
    callback_module_1.v2_playbook_on_start(playbook=playbook_0)


# Generated at 2022-06-25 08:39:13.984533
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    # Parameters
    playbook = magicmock('playbook')

    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:39:17.463613
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Setup test environment
    callback_module_0 = CallbackModule()
    result_1 = None
    ignore_errors_1 = False

    # Invoke method
    callback_module_0.v2_runner_on_failed(result_1, ignore_errors_1)


# Generated at 2022-06-25 08:39:24.074347
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:39:26.381233
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_4 = CallbackModule()
    playbook_5 = Mock()
    callback_module_4.v2_playbook_on_start(playbook_5)
    assert callback_module_4.v2_playbook_on_start(playbook_5) == None


# Generated at 2022-06-25 08:39:33.076429
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    from ansible.playbook import Playbook
    playbook = Playbook()
    callback_module.v2_playbook_on_start(playbook)
    assert callback_module._playbook_path == playbook._file_name
    assert callback_module._playbook_name == os.path.splitext(os.path.basename(callback_module._playbook_path))[0]


# Generated at 2022-06-25 08:39:52.723770
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_0 = None  # TODO: Create a playbook object for testing
    callback_module_1.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:39:54.203525
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:39:59.567255
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_2 = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data_3 = HostData('uuid', 'name', 'status', 'result')
    host_data_4 = HostData('uuid', 'name', 'status', 'result')
    task_data_2.add_host(host_data_3)
    task_data_2.add_host(host_data_4)


# Generated at 2022-06-25 08:40:02.825972
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_0 = playbook.Playbook()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:40:13.228342
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_a = CallbackModule()
    callback_module_a.v2_runner_on_failed({
        "_host": "localhost",
        "_result": {
            "changed": False,
            "msg": "a"
        }
    })
    callback_module_b = CallbackModule()
    callback_module_b.v2_runner_on_failed({
        "_host": "localhost",
        "_result": {
            "changed": False,
            "msg": "a"
        }
    }, True)


# Generated at 2022-06-25 08:40:17.054120
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    # playbook = Mock()
    # callback_module_0.v2_playbook_on_start(playbook)



# Generated at 2022-06-25 08:40:21.285881
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('')
    host_data_0 = HostData('')
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:40:32.880400
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Set up mock
    playbook = mock.MagicMock()
    playbook.get_variable.return_value = True

    # Call the command to test
    callback_module_0.v2_playbook_on_start(playbook)

    # Establish that the mock was called
    assert mock.call(playbook, '_task_relative_path') in playbook.get_variable.mock_calls

    # Establish that the mock was called
    assert mock.call(playbook, '_task_class') in playbook.get_variable.mock_calls

    # Establish that the mock was called
    assert mock.call(playbook, '_fail_on_change') in playbook.get_variable.mock_calls

    # Establish that the mock was called

# Generated at 2022-06-25 08:40:36.254432
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = Playbook()
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(playbook)
    assert callback_module._playbook_path == ''
    assert callback_module._playbook_name == ''


# Generated at 2022-06-25 08:40:38.660552
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    mock_result = Mock()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(mock_result, True)


# Generated at 2022-06-25 08:40:59.026079
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module = CallbackModule()
    task_data_obj = TaskData('uuid0', 'name0', 'path0', 'play0', 'action0')
    host_obj = HostData('uuid0', 'name0', 'status0', 'result0')
    return_value = task_data_obj.add_host(host_obj)


# Generated at 2022-06-25 08:41:04.501555
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = MockEmpty()
    assert not hasattr(callback_module_0, '_playbook_path')
    assert not hasattr(callback_module_0, '_playbook_name')
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_path is None
    assert callback_module_0._playbook_name is None



# Generated at 2022-06-25 08:41:10.335353
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_1 = {'_file_name': 'test_playbook.yml'}
    test_case_1 = test_case_0()
    try:
        test_case_1._playbook_path = 'test_playbook.yml'
        callback_module_1.v2_playbook_on_start(playbook_1)
        if test_case_1._playbook_path != 'test_playbook.yml':
            print("FAILED")
        else:
            print("PASSED")
    except:
        print("FAILED")


# Generated at 2022-06-25 08:41:12.831160
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_0 = Mock()
    callback_module_1.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:21.519589
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = AnsibleResult()
    ignore_errors=False
    # Case 0
    callback_module_0.v2_runner_on_failed(result, ignore_errors)
    # Case 1
    callback_module_0.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:41:31.915231
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_1 = TaskData(uuid='uuid_1', name='name_1', path='path_1', play='play_1', action='action_1')
    host_1 = HostData(uuid='uuid_2', name='name_2', status='status_2', result='result_2')
    task_data_1.host_data['host_1'] = host_1
    host_2 = HostData(uuid='uuid_2', name='name_2', status='included', result='result_3')
    try:
        task_data_1.add_host(host_2)
    except Exception as e:
        print("Exception: {}".format(e))
    # assertion

# Generated at 2022-06-25 08:41:38.725271
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = 'tests/fixtures/ansible-syntax-check.log'

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)

    assert callback_module_0._playbook_path == playbook
    assert callback_module_0._playbook_name == 'ansible-syntax-check'


# Generated at 2022-06-25 08:41:47.342599
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert_raises(TypeError, callback_module_0.v2_playbook_on_start, 1)
    assert_raises(TypeError, callback_module_0.v2_playbook_on_start, None)
    assert_raises(TypeError, callback_module_0.v2_playbook_on_start, 1.0)
    assert_raises(TypeError, callback_module_0.v2_playbook_on_start, "1")
    assert_raises(TypeError, callback_module_0.v2_playbook_on_start, True)


# Generated at 2022-06-25 08:41:51.847146
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    # Setup mocking dependencies
    playbook = Mock()
    playbook._file_name = 'playbook.yml'

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:41:57.829737
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('7df3a3c3-7b8d-4d2f-a3d3-8d8b3f74bff5', 'task name', 'path/to/task', 'play name', 'action name')
    host_data_0 = HostData('host id', 'host name', 'status', 'result')
    try:
        task_data_0.add_host(host_data_0)
    except:
        pass


# Generated at 2022-06-25 08:42:30.408698
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    result = 'test'
    callback_module_1 = CallbackModule()
    assert callback_module_1.v2_runner_on_failed(result) == None


# Generated at 2022-06-25 08:42:34.517609
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_path == '/home/dave/ansible/playbook.yaml', \
        'Attribute value of callback_module_0 was not set correctly.'
    assert callback_module_0._playbook_name == 'playbook', \
        'Attribute value of callback_module_0 was not set correctly.'


# Generated at 2022-06-25 08:42:39.594026
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup
    callback_module = CallbackModule()
    result = None
    ignore_errors = False

    # Invoke method
    callback_module.v2_runner_on_failed(result, ignore_errors)


# Generated at 2022-06-25 08:42:40.690450
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:42:43.839068
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # result = task.add_host(host)
    raise NotImplementedError()


# Generated at 2022-06-25 08:42:44.718900
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    test_case_0()


# Generated at 2022-06-25 08:42:51.705456
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    assert callback_module_0._task_data['0'].add_host().status == 'included'
    assert callback_module_0._task_data['0'].add_host().status == 'ok'
    assert callback_module_0._task_data['0'].add_host().status == 'failed'
    assert callback_module_0._task_data['0'].add_host().status == 'skipped'
    assert callback_module_0._task_data['0'].add_host().status == 'ok'
    assert callback_module_0._task_data['0'].add_host().status == 'failed'
    assert callback_module_0._task_data['0'].add_host().status == 'ok'

# Generated at 2022-06-25 08:42:56.391317
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    global callback_module_0
    print("test_CallbackModule_v2_playbook_on_start")

    # initialization
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start("/home/user/ansible/playbooks/site.yml")


# Generated at 2022-06-25 08:42:59.196835
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    task_0 = object()
    result_0 = object()
    ignore_errors_0 = object()
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)
    assert True


# Generated at 2022-06-25 08:43:05.037472
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Create an instance of TaskData
    task_data_0 = TaskData(1, 'task 0', 'task.yml', 'play 0', 'action 0')
    # Create an instance of HostData
    host_data_0 = HostData(0, 'host 0', 'ok', None)
    # Call method add_host
    task_data_0.add_host(host_data_0)
    # Call method add_host
    task_data_0.add_host(host_data_0)



# Generated at 2022-06-25 08:44:14.967699
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result = _fake_result()
    callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:44:15.895086
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:44:26.051058
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_0 = TaskData(0, '', '', '', '')
    host_0 = HostData(0, '', '', 0)
    
    # Test case 1 - exception when host already exists
    callback_module_1.host_data[host_0.uuid] = host_0
    task_data_0.host_data = callback_module_1.host_data
    exception_caught = False

    try:
        task_data_0.add_host(host_0)
    except Exception:
        exception_caught = True

    assert exception_caught

    # Test case 2 - add host
    task_data_0.host_data = {}
    task_data_0.add_host(host_0)
    assert task_data

# Generated at 2022-06-25 08:44:33.725739
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid-0', 'name-1', 'path-2', 'play-3', 'action-4')
    host_0 = HostData('uuid-5', 'name-6', 'status-7', 'result-8')
    task_data_0.add_host(host_0)



# Generated at 2022-06-25 08:44:42.747176
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    task_data_0 = TaskData(uuid='uuid_0', name='name_0', path='path_0', play='play_0', action=None)
    host_data_0 = HostData(uuid='uuid_0', name='name_0', status=None, result=None)
    try:
        task_data_0.add_host(host_data_0)
        raise Exception("expect to throw")
    except Exception as e:
        assert type(e) == Exception
    try:
        task_data_0.add_host(host_data_0)
        raise Exception("expect to throw")
    except Exception as e:
        assert type(e) == Exception

# Generated at 2022-06-25 08:44:48.868918
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Create mock object
    h_uuid = 'host_uuid'
    h_name = 'host_name'
    h_status = 'host_status'
    h_result = 'host_result'
    h_host = HostData(h_uuid, h_name, h_status, h_result)

    # Create object
    task_data_0 = TaskData('task_uuid', 'task_name', 'path', 'play', 'action')

    # Call method to test
    task_data_0.add_host(h_host)


# Generated at 2022-06-25 08:44:50.151263
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start('playbook_0')


# Generated at 2022-06-25 08:44:50.937530
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:44:56.859981
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = playbook.PlayBook()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:45:05.596331
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_v2_playbook_on_start = CallbackModule()
    callback_module_v2_playbook_on_start._playbook_path = '/home/foobar/ansible-junit'
    callback_module_v2_playbook_on_start._playbook_name = 'ansible-junit'
# v2_playbook_on_start(self, playbook)
    playbook = ['ninth_birthday']
    callback_module_v2_playbook_on_start.v2_playbook_on_start(playbook)
    assert(callback_module_v2_playbook_on_start._playbook_path == '/home/foobar/ansible-junit' and callback_module_v2_playbook_on_start._playbook_name == 'ansible-junit')
