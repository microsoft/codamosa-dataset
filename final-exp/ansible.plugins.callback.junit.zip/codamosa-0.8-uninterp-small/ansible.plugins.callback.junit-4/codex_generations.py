

# Generated at 2022-06-25 08:36:26.969792
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    str_0 = 'ok'
    str_1 = 'ok'
    str_2 = 'true'
    result_0 = dict()
    result_0['rc'] = 0
    result_0['changed'] = False
    result_0['failed'] = False
    result_0['skip_reason'] = 'Conditional result was False'
    result_0['msg'] = 'hello world'
    result_0['exception'] = 'boo'
    result_0['start'] = '2016-11-14 07:55:55.554955'
    result_0['end'] = '2016-11-14 07:55:56.554955'
    result_0['delta'] = '0:00:01.000000'
    result_0['cmd'] = 'echo hello world'

# Generated at 2022-06-25 08:36:29.243555
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    str_0 = 'true'
    callback_module_0 = CallbackModule()
    # Test case 0:
    test_case_0(str_0)


# Generated at 2022-06-25 08:36:39.555614
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    from ansible.callbacks import PlaybookCallbacks
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    callback_module_0 = CallbackModule()
    variable_manager_0 = VariableManager()
    inventory_0 = Inventory(loader=DataLoader(), variable_manager=variable_manager_0, host_list=None)
    playbook_0 = PlaybookCallbacks(playbook=None, loader=DataLoader(), inventory=inventory_0, variable_manager=variable_manager_0)
    # Test that v2_playbook_on_start sets the correct values for _playbook_path and _playbook_name
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0

# Generated at 2022-06-25 08:36:48.987047
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    str_0 = 'true'
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData(uuid = None, name = '', path = '', play = '', action = None)
    host_data_0 = HostData(uuid = None, name = '', status = '', result = None)
    task_data_0.add_host(host = host_data_0)


# Generated at 2022-06-25 08:36:55.953802
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    with pytest.raises(Exception):
        assert str_0 == 'true'
        assert callback_module_0._task_class == 'true'
        assert callback_module_0._include_setup_tasks_in_report == 'true'
        assert str_0 == 'true'
        assert str_0 == 'true'
        assert str_0 == 'true'
        assert str_0 == 'true'
        assert str_0 == 'true'
        assert str_0 == 'true'
        str_1 = 'true'
        task_data_0 = TaskData(str_0, str_0, str_0, str_0, str_0)
        host_data_0 = HostData(str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 08:37:09.702627
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    str_0 = 'true'
    callback_module_0 = CallbackModule()
    uuid_3 = 'd45be998-a008-456d-b6fa-f4029fd9fd16'
    uuid_2 = 'd45be998-a008-456d-b6fa-f4029fd9fd16'
    path_0 = '~/.ansible.log'
    uuid_0 = 'd45be998-a008-456d-b6fa-f4029fd9fd16'
    uuid_1 = 'd45be998-a008-456d-b6fa-f4029fd9fd16'
    host_data_0 = HostData(uuid_3, host_name_0, status_0, result_0)

# Generated at 2022-06-25 08:37:21.319775
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    #Initialize the object
    task_uuid_0 = 'uuid1'
    name_0 = 'name1'
    path_0 = 'path1'
    play_0 = 'play1'
    action_0 = 'include'
    task_data_0 = TaskData(task_uuid_0, name_0, path_0, play_0, action_0)
    #Add a host
    host_uuid_0 = 'uuid2'
    host_name_0 = 'host_name1'
    status_0 = 'ok'
    result_0 = 'result1'
    host_data_0 = HostData(host_uuid_0, host_name_0, status_0, result_0)
    task_data_0.add_host(host_data_0)
    #

# Generated at 2022-06-25 08:37:25.753932
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    str_0 = 'true'
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('','','','','')
    host_data_0 = HostData('','','','')
    task_data_0.start = str_0
    host_data_0.uuid = str_0
    task_data_0.action = str_0
    task_data_0.path = str_0
    task_data_0.add_host(host_data_0)
    host_data_0.status = str_0


# Generated at 2022-06-25 08:37:35.268860
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    str_0 = 'true'
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:37:40.147852
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    c = CallbackModule()
    c._task_relative_path = '/home/test/test.yml'
    task_data = TaskData('1', 'name', '/home/test/test.yml', 'play', 'action')
    host_data = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host_data)


# Generated at 2022-06-25 08:37:54.272571
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    obj_0 = TaskData()
    obj_0.uuid = 'uuid'
    obj_0.name = 'name'
    obj_0.path = 'path'
    obj_0.play = 'play'
    obj_0.start = time.time()
    obj_0.action = 'action'
    obj_0.host_data = {}
    # Another case
    obj_0.host_data['key'] = HostData(uuid='uuid', name='name', status='ok', result=Result())
    obj_0.add_host(HostData(uuid='uuid', name='name', status='ok', result=Result()))
    # Another case
    obj_0.host_data['key'] = HostData(uuid='uuid', name='name', status='included', result='result')

# Generated at 2022-06-25 08:37:55.555201
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-25 08:38:06.809158
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Instantiate object, we get a new object every time
    obj_0 = CallbackModule()
    obj_1 = CallbackModule()
    obj_2 = CallbackModule()
    # All objects should have the same v2_playbook_on_start
    obj_0._playbook_on_start
    obj_1._playbook_on_start
    obj_2._playbook_on_start
    # Assign values to each element of the dictionary self._task_data
    obj_0._task_data = {}
    obj_1._task_data = {}
    obj_2._task_data = {}
    # Assign values to each element of the dictionary self._task_data

# Generated at 2022-06-25 08:38:08.871479
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    data_0 = TaskData(str_0, str_0, str_0, str_0, str_0)
    str_4 = str()


# Generated at 2022-06-25 08:38:17.075972
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup


    # Perform action
    mock_playbook = mock.Mock()
    mock_playbook._file_name = None
    junit_output_dir = mock.Mock()
    junit_task_class = mock.Mock()
    junit_task_relative_path = mock.Mock()
    junit_fail_on_change = mock.Mock()
    junit_fail_on_ignore = mock.Mock()
    junit_include_setup_tasks_in_report = mock.Mock()
    junit_hide_task_arguments = mock.Mock()
    junit_test_case_prefix = mock.Mock()

# Generated at 2022-06-25 08:38:20.533737
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData()
    host_0 = HostData()
    task_data_0.add_host(host_0)


# Generated at 2022-06-25 08:38:23.843628
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = None
    self = CallbackModule()

    # Call method v2_playbook_on_start of CallbackModule
    self.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:38:26.689311
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule()
    result = object()
    ignore_errors = bool()
    cb.v2_runner_on_failed(result, ignore_errors)
    assert test_case_0()

# Generated at 2022-06-25 08:38:34.358407
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb = CallbackModule()
    cb.v2_playbook_on_start(test_case_0())
    # State check: call method v2_put_host_var
    cb.v2_put_host_var(test_case_0(), test_case_0())
    # State check: call method v2_playbook_on_play_start
    cb.v2_playbook_on_play_start(test_case_0())
    # State check: call method v2_playbook_on_task_start
    cb.v2_playbook_on_task_start(test_case_0(), test_case_0())
    # State check: call method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:38:37.719991
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    
    task_data_0 = TaskData('0', '0', '0', '0', '0')
    host_data_0 = HostData('0', '0', '0', '0')

    task_data_0.add_host(host_data_0)

    assert task_data_0.host_data.get('0') == host_data_0


# Generated at 2022-06-25 08:38:56.537862
# Unit test for method add_host of class TaskData

# Generated at 2022-06-25 08:39:08.277736
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    if not isinstance(callback_module_0, CallbackModule):
        raise RuntimeError("was not created with CallbackModule class")
    if not isinstance(callback_module_0, CallbackBase):
        raise RuntimeError("was not created with CallbackBase class")
    if not issubclass(callback_module_0, CallbackBase):
        raise RuntimeError("was not created with CallbackBase class")
    if not issubclass(CallbackModule, CallbackBase):
        raise RuntimeError("CallbackModule is not a subclass of CallbackBase")
    if not isinstance(callback_module_0._output_dir, str):
        raise RuntimeError("output_dir is not a string")

# Generated at 2022-06-25 08:39:10.235591
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    global callback_module_0
    assert callback_module_0.v2_playbook_on_start() == None



# Generated at 2022-06-25 08:39:17.851187
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    import ansible.playbook.play
    callback_module_v2_playbook_on_start = CallbackModule()
    class mock_playbook():
        def __init__(self):
            self._file_name = './xsjf.yml'
    mock_playbook = mock_playbook()
    result = callback_module_v2_playbook_on_start.v2_playbook_on_start(mock_playbook)

# Generated at 2022-06-25 08:39:24.774277
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    # add_host
    callback_module_1 = CallbackModule()
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

if __name__ == '__main__':

    # Run tests
    test_TaskData_add_host()

# Generated at 2022-06-25 08:39:32.009379
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data_0 = HostData('uuid', 'name', 'status', 'result')
    task_data_0.add_host(host_data_0)

test_case_0()
test_TaskData_add_host()

# Generated at 2022-06-25 08:39:37.298066
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    test_case_0 = TaskData(uuid='test_string', name='test_string', path='test_string', play='test_string', action='test_string')
    host = 'test_string'
    expected = 'test_string'
    actual = test_case_0.add_host(host)
    assert(expected == actual)


# Generated at 2022-06-25 08:39:38.424992
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-25 08:39:40.808817
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = None
    ignore_errors_0 = False
    callback_module_0.v2_runner_on_failed(result_0, ignore_errors_0)


# Generated at 2022-06-25 08:39:44.004842
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData()
    host_0 = HostData()
    callback_module_0.assertRaises(task_data_0.add_host(host_0))


# Generated at 2022-06-25 08:40:05.321977
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._task_data.clear()
    callback_module_0._task_data[0] = TaskData(0, "name", "path", "play", "action")
    callback_module_0._task_data[0].add_host(HostData(2, "name1", "status1", "result1"))
    callback_module_0._task_data[0].add_host(HostData(2, "name2", "status2", "result2"))



# Generated at 2022-06-25 08:40:06.259076
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:40:08.096790
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    # assert not false
    assert not True


# Generated at 2022-06-25 08:40:13.284711
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():

    #Test for TaskData object with uuid 'b1f8463a'
    TaskData_with_uuid_b1f8463a = TaskData(uuid='b1f8463a', name='name_string', path='.', play='play_string', action='include')

    #Testcase for exception
    host_collection = [HostData(uuid='b1f8463a', name='name_string', status='ok', result=None),
HostData(uuid='b1f8463a', name='name_string', status='ok', result=None)]
    for host in host_collection:
        try:
            TaskData_with_uuid_b1f8463a.add_host(host)
            assert(True)
        except Exception:
            assert(False)


# Generated at 2022-06-25 08:40:17.391113
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.test_case_0()
    result = []
    callback_module_0.v2_runner_on_failed(result)


# Generated at 2022-06-25 08:40:25.779566
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0_name_0 = "callback_module_0"
    callback_module_0_task_data_0 = TaskData(callback_module_0_name_0, callback_module_0_name_0, callback_module_0_name_0, callback_module_0_name_0, callback_module_0_name_0)
    callback_module_0_host_data_0 = HostData(callback_module_0_name_0, callback_module_0_name_0, callback_module_0_name_0, callback_module_0_name_0)
    try:
        callback_module_0_task_data_0.add_host(callback_module_0_host_data_0)
    except Exception:
        assert False



# Generated at 2022-06-25 08:40:35.615110
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    obj_TaskData_0 = TaskData('', '', '', '', '')
    host_0 = HostData('', '', '', '')
    obj_TaskData_0.add_host(host_0)
    # Test to see if host_0 was added to obj_TaskData_0.host_data
    assert obj_TaskData_0.host_data[host_0.uuid] == host_0
    # Test to see if 'duplicate host callback' is raised
    with pytest.raises(Exception) as exception_info:
        obj_TaskData_0.add_host(host_0)
    assert 'duplicate host callback' in str(exception_info.value)



# Generated at 2022-06-25 08:40:38.600740
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)
    assert os.path.isfile(callback_module_0._output_dir)


# Generated at 2022-06-25 08:40:44.075588
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    uuid_0 = '9834jkk5'
    name_0 = 'all'
    path_0 = 'playbook.yml'
    play_0 = 'play'
    action_0 = 'command'
    task_data_0 = TaskData(uuid_0, name_0, path_0, play_0, action_0)
    uuid_1 = '9834jkk5'
    name_1 = 'all'
    path_1 = 'playbook.yml'
    play_1 = 'play'
    action_1 = 'command'
    host_uuid_0 = '123456789'
    host_name_0 = 'example.com'
    status_0 = 'failed'
    result_0 = '123456789'

# Generated at 2022-06-25 08:40:45.963625
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    result = {}
    result['_result'] = {}
    result['_result']['exception']='fake_exception'


# Generated at 2022-06-25 08:41:08.341278
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host = HostData('host_uuid_0', 'host_name_0', 'host_status_0', 'host_result_0')
    callback_module_0 = CallbackModule()
    task = TaskData('task_uuid_0', 'task_name_0', 'task_path_0', 'task_play_0', 'task_action_0')
    task_uuid = task.uuid
    task_name = task.name
    task_path = task.path
    task_play = task.play
    task_start = task.start
    task_host_data = task.host_data
    task_action = task.action
    task.add_host(host)
    print(task.uuid)
    print(task.name)
    print(task.path)

# Generated at 2022-06-25 08:41:12.174453
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_0 = AnsiblePlaybook()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:18.332285
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed()


# Generated at 2022-06-25 08:41:23.843600
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(0, 'name_0', 'path_0', 'play_0', 'action_0')
    host_data_0 = HostData(0, 'name_0', 'status_0', 'result_0')
    task_data_0.add_host(host_data_0)
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:41:26.451587
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start


# Generated at 2022-06-25 08:41:30.866538
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = object()
    assert None is callback_module_0.v2_playbook_on_start(playbook_0)
    assert callback_module_0._playbook_name == 'test_case'


# Generated at 2022-06-25 08:41:32.358841
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    global host_data
    print("Testing method add_host of class TaskData")
    assert(True)

# Generated at 2022-06-25 08:41:35.752892
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host = HostData('host_uuid', 'host_name', 'status', 'result')
    host_data = {'host_uuid': host}
    task_data = TaskData('task_uuid', 'name', 'path', 'play', host_data)
    callback_module_0 = CallbackModule()
    task_data.add_host(host)


# Generated at 2022-06-25 08:41:39.653282
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Mock()
    playbook._file_name = 'playbook_0._file_name'
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:41:47.184372
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    TaskData_add_host_0 = TaskData(uuid = 'uuid', name = 'name', path = 'path', play = 'play', action = 'action')
    host = HostData(uuid = 'uuid', name = 'name', status = 'status', result = 'result')
    try:
        TaskData_add_host_0.add_host(host)
    except Exception as e:
        print('An exception was raised : ' + str(e))
        assert False
    assert True



# Generated at 2022-06-25 08:42:07.836767
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of class CallbackModule
    callback_module_0 = CallbackModule()
    # Create an instance of class PlayBook
    playbook_0 = PlayBook()
    # Invoke method v2_playbook_on_start of callback_module_0
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:42:11.652044
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Initializing objects
    playbook_0 = ansible.Playbook()
    playbook_0._file_name = "\\\lib\\orchestration\\.ansible\\.log\\-482685.xml"
    callback_module_0 = CallbackModule()

    # Invoking method
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:42:22.631584
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module = CallbackModule()
    callback_module._task_data = {}
    callback_module._task_relative_path = '~/.ansible.log'
    callback_module._task_class = 'False'
    callback_module._fail_on_change = 'True'
    callback_module._fail_on_ignore = 'True'
    callback_module_0 = CallbackModule()
    uuid = 'ansible_playbook_gather_facts_task'
    name = 'gather_facts'
    path = '~/.ansible.log'
    play = 'Initializing'
    action = 'gather_facts'
    callback_module_1 = TaskData(uuid, name, path, play, action)
    callback_module._task_data['ansible_playbook_gather_facts_task']

# Generated at 2022-06-25 08:42:25.708097
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData(None, None, None, None, None)
    assert task_data_0
    task_data_0.add_host(None)
    assert task_data_0


# Generated at 2022-06-25 08:42:27.899967
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # test callback_module_0 with valid values
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook=None)


# Generated at 2022-06-25 08:42:34.434442
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(callback_module_0)
    assert hasattr(callback_module_0, "_playbook_path")
    assert hasattr(callback_module_0, "_playbook_name")



# Generated at 2022-06-25 08:42:35.727294
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = {}
    callback_module_0.v2_playbook_on_start(playbook_0)


# Generated at 2022-06-25 08:42:41.556513
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    host = HostData(host_uuid = 'host_uuid', host_name = 'host_name', status = 'status', result = 'result')
    task_data = TaskData(uuid = 'uuid', name = 'name', path = 'path', play = 'play', action = 'action')
    task_data.add_host(host)
    assert task_data.host_data[host.uuid].host_uuid == host.host_uuid
    assert task_data.host_data[host.uuid].status == host.status



# Generated at 2022-06-25 08:42:44.607906
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = PlayBook()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:42:46.353290
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    assert callback_module_0.v2_playbook_on_start() is None


# Generated at 2022-06-25 08:43:27.153815
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    from ansible import playbook
    playbook_0 = playbook.Playbook()
    playbook_0 = playbook.Playbook()
    assert callback_module_0.v2_playbook_on_start(playbook_0) == None


# Generated at 2022-06-25 08:43:32.485110
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host_data_0 = HostData("", "", "", "")
    host_data_1 = HostData("", "", "", "")
    task_data_0 = TaskData("", "", "", "", "")
    task_data_0.add_host(host_data_0)
    task_data_0.add_host(host_data_1)


# Generated at 2022-06-25 08:43:35.312483
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(None)


# Generated at 2022-06-25 08:43:38.830714
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    """Test if a second host is added correctly."""
    task = TaskData("42", "test_data", "path", "play", "action")
    host = HostData("4242", "host_name", "status", "result")
    task.add_host(host)
    assert task.host_data["4242"] == host


# Generated at 2022-06-25 08:43:39.846972
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass


# Generated at 2022-06-25 08:43:45.384649
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed()


# Generated at 2022-06-25 08:43:55.260003
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    callback_module_0._task_data['test_module_0_play_0_task_0'] = TaskData(5, 'test_task_name_0', 'test_task_path_0', 'test_play_name_0', 'test_action_0')
    callback_module_0._task_data['test_module_0_play_0_task_0'].start = 1534887796.656216

# Generated at 2022-06-25 08:44:06.166490
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_1 = CallbackModule()
    callback_module_1._task_data = {'task_uuid1': TaskData('task_uuid1', 'task_name1', 'task_path1', 'task_play1', 'task_action1')}
    callback_module_1._task_data['task_uuid1'].add_host(HostData('host_uuid1', 'host_name1', 'host_status1', 'host_result1'))
    assert callback_module_1._task_data['task_uuid1'].host_data['host_uuid1'].uuid == 'host_uuid1'
    assert callback_module_1._task_data['task_uuid1'].host_data['host_uuid1'].name == 'host_name1'

# Generated at 2022-06-25 08:44:16.071376
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data_0 = TaskData("UU-ID-0", "Task-1", "Path-1", "Play-1", "Action-1")
    host_data_0 = HostData("UU-ID-1", "Host-1", "Status-1", "Result-1")
    # try:
    task_data_0.add_host(host_data_0)
    # except:
        # assert False


# Generated at 2022-06-25 08:44:23.966201
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
        
    # Create task
    task_data_0 = TaskData('a12c', 'my_play_name', 'my_play_path', 'my_play', 'my_action')
 
    # Create host
    host_data_0 = HostData('12', 'my_host_name', 'failed', 'something')
    task_data_0.add_host(host_data_0)


# Generated at 2022-06-25 08:45:59.074659
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # create an instance of the class
    callback_module_1 = CallbackModule()

    # create an instance of the Ansible class and assign it to a variable
    ansible_1 = Ansible()

    # create an instance of the PlayBook class and assign it to a variable
    playbook_1 = PlayBook()

    # assign to a variable the value returned by the v2_playbook_on_start method of the callback_module_1 object
    result_1 = callback_module_1.v2_playbook_on_start(playbook_1)

    # compare the value of the result_1 variable with its expected value
    assert result_1 == None


# Generated at 2022-06-25 08:46:08.089046
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    callback_module_0 = CallbackModule()
    task_data_0 = TaskData('uuid_0', 'name_0', 'path_0', 'play_0', 'no_log')
    host_0 = HostData('uuid_1', 'name_1', 'included', 'result_0')
    task_data_0.add_host(host_0)
    print('\n##### Running test: TaskData.add_host')
    print(task_data_0.host_data[host_0.uuid].status)
    assert task_data_0.host_data[host_0.uuid].status == 'included'
