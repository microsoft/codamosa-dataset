

# Generated at 2022-06-11 13:26:11.599252
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    playbook_on_start = False
    playbook_on_play_start = False
    runner_on_no_hosts = False
    playbook_on_task_start = False
    playbook_on_cleanup_task_start = False
    playbook_on_handler_task_start = False
    runner_on_failed = False
    runner_on_ok = False
    runner_on_skipped = False
    playbook_on_include = False
    playbook_on_stats = False


# Generated at 2022-06-11 13:26:15.492608
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
  x = TaskData("1", "1", "1", "1", "1")
  y = HostData("2", "2", "2", "{\"_host\": \"2\", \"_result\": \"2\"}")
  x.add_host(y)



# Generated at 2022-06-11 13:26:29.030800
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host = HostData('2', 'stack', 'ok', 'stack')
    host2 = HostData('3', 'stack', 'ok', 'stack')

    host_data = {'2': host}
    task_data = TaskData('1', 'stack', 'stack', 'stack', 'stack')
    task_data.host_data = host_data
    task_data.add_host(host)

    assert task_data.host_data == {'2': host}

    host_data = {'2': host}
    task_data = TaskData('1', 'stack', 'stack', 'stack', 'stack')
    task_data.host_data = host_data
    task_data.add_host(host2)

    assert task_data.host_data == {'2': host, '3': host2}



# Generated at 2022-06-11 13:26:34.070357
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    class HostData:
        def __init__(self, uuid, name, status, result):
            self.uuid = uuid
            self.name = name
            self.status = status
            self.result = result
            self.finish = time.time()

    class TaskData:
        def __init__(self, uuid, name, path, play, action):
            self.uuid = uuid
            self.name = name
            self.path = path
            self.play = play
            self.start = None
            self.host_data = {}
            self.start = time.time()
            self.action = action


# Generated at 2022-06-11 13:26:40.574050
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    print("Testing add_host of class TaskData")

    class Host:
        def __init__(self, uuid):
            self.uuid = uuid

    class Result:
        def __init__(self, result):
            self.result = result

    class HostData:
        def __init__(self, uuid, name, status, result):
            self.uuid = uuid
            self.name = name
            self.status = status
            self.result = result
            self.finish = 0

    # successful creation of a TaskData object
    task_data = TaskData('1', 'task', 'playbook.yml', 'play', 'something')

    # add one result
    result1 = Result('result1\n')

# Generated at 2022-06-11 13:26:46.571685
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    """
    Unit test for method CallbackModule.v2_playbook_on_start
    """

    # Construct the parameter list for the test
    playbook =  None

    # Perform the test
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(playbook)

    # Create assert statements


# Generated at 2022-06-11 13:26:57.357015
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    host = 'test-host'
    arg1 = 'test-arg1'
    arg2 = 'test-arg2'
    host_data = HostData(host, host, 'ok', arg1)
    task = 'test-task'
    path = 'test-path'
    play = 'test-play'
    action = 'test-action'
    task_data = TaskData(task, task, path, play, action)
    task_data.add_host(host_data)
    result1 = task_data.host_data[host]
    assert result1.result == arg1
    host_data2 = HostData(host, host, 'ok', arg2)
    try:
        task_data.add_host(host_data2)
    except:
        assert ValueError


# Generated at 2022-06-11 13:27:08.046842
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_uuid = "1234"
    task_name = "install task"
    task_path = "/home/aalok/ansible/playbooks/install.yml"
    task_play = "play1"
    task_action = "install"

    task = TaskData( task_uuid, task_name, task_path, task_play, task_action )

    host_uuid = "123"
    host_name = "abc.com"
    host_status = "failed"
    host_result = "error occured"
    host = HostData( host_uuid, host_name, host_status, host_result )

    task.add_host( host )

    assert( task.uuid == "1234" )
    assert( task.name == "install task" )

# Generated at 2022-06-11 13:27:16.869647
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'included', 'result')
    task.add_host(host)
    assert task.host_data['uuid'].status == 'included'
    assert task.host_data['uuid'].result == 'result'
    host = HostData('uuid', 'name', 'included', 'result')
    with pytest.raises(Exception):
        task.add_host(host)


# Generated at 2022-06-11 13:27:21.644976
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task = TaskData(1, 'test', 'Dummy path', 'Dummy play', 'dummy action')
    host = HostData(1, 'Dummy name', 'dummy status', 'result')
    task.add_host(host)

    assert task.host_data[1] == host



# Generated at 2022-06-11 13:27:37.327440
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # arrange
    output_dir = '~/.ansible.log'
    task_class = 'False'
    fail_on_ignore = 'False'
    include_setup_tasks_in_report = 'True'
    hide_task_arguments = 'False'
    test_case_prefix = ''

    os.environ['JUNIT_OUTPUT_DIR'] = output_dir
    os.environ['JUNIT_TASK_CLASS'] = task_class
    os.environ['JUNIT_FAIL_ON_IGNORE'] = fail_on_ignore
    os.environ['JUNIT_INCLUDE_SETUP_TASKS_IN_REPORT'] = include_setup_tasks_in_report

# Generated at 2022-06-11 13:27:44.018535
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    module = CallbackModule()
    result = dict(rc=0, stdout="", stderr="")
    result['rc'] = 255;
    result['stdout'] = 'stdout.txt';
    result['stderr'] = 'stderr.txt';
    module.v2_runner_on_failed(result, ignore_errors=False)
    cmd = 'cd $JUNIT_TEST_HOME && grep ' + '"' + 'stdout' + '"' + 'stdout.txt';
    os.system(cmd);
    cmd = 'cd $JUNIT_TEST_HOME && grep ' + '"' + 'stderr' + '"' + 'stderr.txt';
    os.system(cmd);


# Generated at 2022-06-11 13:27:45.053483
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    CallbackModule().v2_playbook_on_start("playbook")

# Generated at 2022-06-11 13:27:45.609337
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-11 13:27:48.452327
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    obj = CallbackModule()
    bookmark = None
    playbook = None
    obj.v2_playbook_on_start(bookmark, playbook)
    return True

# Generated at 2022-06-11 13:27:58.726652
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    target = CallbackModule()
    type(target).CALLBACK_NAME = 'junit'
    type(target)._playbook_path = 'unit_tests/ansible.cfg'
    type(target)._playbook_name = 'ansible.cfg'
    playbook = 'unit_tests/ansible.cfg'
    expected = 'ansible.cfg'

    # Act
    target.v2_playbook_on_start(playbook)

    # Assert
    assert(target._playbook_path == expected)
    assert(target._playbook_name == expected)

if __name__ == '__main__':
    test_CallbackModule_v2_playbook_on_start()

# Generated at 2022-06-11 13:28:05.450082
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Configure the arguments that would be sent to the Ansible task.
    # These are dummy values, but represent the parameters to the
    # v2_playbook_on_start method, which would normally be set by Ansible.
    playbook = None

    # Instantiate the callback module
    cb = CallbackModule()

    # Call the callback module method
    cb.v2_playbook_on_start(playbook)

# Generated at 2022-06-11 13:28:11.581609
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback = CallbackModule()
    assert callback._playbook_path == None
    assert callback._playbook_name == None
    
    file_name = '.py'
    playbook = Playbook()
    playbook._file_name = file_name
    callback.v2_playbook_on_start(playbook)
    
    assert callback._playbook_path == file_name
    assert callback._playbook_name == '.py'

# Generated at 2022-06-11 13:28:19.551020
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    '''
    Unit test for method v2_playbook_on_start of class CallbackModule
    '''

    # Create an instance of CallbackModule
    cb = CallbackModule()

    # Create a instance of FakePlaybook to pass to v2_playbook_on_start
    playbook = FakePlaybook()

    # Set up necessary class attributes
    cb._playbook_name = 'foo'
    cb._output_dir = '/tmp/foo'

    # Create a dummy directory to write the XML file to
    os.makedirs(cb._output_dir)

    # Call the method under test
    cb.v2_playbook_on_start(playbook)

    # Verify the appropriate attributes have been set
    assert cb._playbook_path == '/tmp/foo/foo.yml'
    assert c

# Generated at 2022-06-11 13:28:22.361976
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    '''
    Test method CallbackModule.v2_runner_on_failed
    '''
    assert False, 'This test needs to be implemented'

# Generated at 2022-06-11 13:28:34.741927
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Parameters
    result = None
    ignore_errors = None

    # Instantiation
    callback = CallbackModule()

    # Invoke method
    callback.v2_runner_on_failed(result=result, ignore_errors=ignore_errors)


# Generated at 2022-06-11 13:28:37.369329
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    _playbook_path = "test_playbook.yaml"
    _playbook_name = "test_playbook"
    test_instance = CallbackModule()
    test_instance.v2_playbook_on_start(playbook=MagicMock(file_name=_playbook_path))
    assert test_instance._playbook_path == _playbook_path
    assert test_instance._playbook_name == _playbook_name

# Generated at 2022-06-11 13:28:40.661636
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    _playbook_path = os.path.join('test/data/vars', 'test.yaml')
    _playbook_name = os.path.splitext(os.path.basename(_playbook_path))[0]
    instance = CallbackModule()
    instance.v2_playbook_on_start(_playbook_path)
    assert instance._playbook_path == _playbook_path
    assert instance._playbook_name == _playbook_name

# Generated at 2022-06-11 13:28:44.094145
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    task = TaskData
    result = ResultData
    ignore_errors = False
    callbackmodule = CallbackModule()
    # TODO: What is the result of the function?
    # callbackmodule.v2_runner_on_failed(task, result, ignore_errors)


# Generated at 2022-06-11 13:28:46.905232
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # setup

    # execute
    CallbackModule.v2_playbook_on_start(CallbackModule, "CallbackModule.v2_playbook_on_start")

    # verify


# Generated at 2022-06-11 13:28:49.622189
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    c = CallbackModule()
    c.v2_playbook_on_start(None)
    assert c._playbook_name == 'None'



# Generated at 2022-06-11 13:28:53.680748
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    print("Testing v2_playbook_on_start")
    junit = CallbackModule() 
    playbook = {}
    playbook['_file_name'] = "Playbookname"
    junit.v2_playbook_on_start(playbook)

# Generated at 2022-06-11 13:28:55.633776
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    assert CallbackModule.v2_runner_on_failed() == 'failed'


# Generated at 2022-06-11 13:29:06.967469
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start(): 
    import os
    import tempfile
    from ...testing import make_test_env

    make_test_env()

    current_dir = tempfile.mkdtemp()

    output_dir = tempfile.mkdtemp()
    playbook_name = 'test_v2_playbook_on_start'
    playbook_path = os.path.join(current_dir, playbook_name + '.yml')

    with open(playbook_path, 'wb') as fd:
        fd.write('---\n')

    callback = CallbackModule()
    assert callback._playbook_path is None
    assert callback._playbook_name is None

    callback.v2_playbook_on_start(playbook=DummyPlaybook(playbook_path))
    assert callback._playbook_path == playbook_path
    assert callback

# Generated at 2022-06-11 13:29:09.036799
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callbackModule = CallbackModule()
    callbackModule.v2_playbook_on_start(None)


# Generated at 2022-06-11 13:29:26.134305
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    CallbackModule().v2_runner_on_failed(None)

# Generated at 2022-06-11 13:29:27.517516
# Unit test for method v2_playbook_on_start of class CallbackModule

# Generated at 2022-06-11 13:29:29.895744
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    test = CallbackModule()
    test.v2_playbook_on_start(None)
    # assert test._playbook_path == None
    # assert test._playbook_name == None


# Generated at 2022-06-11 13:29:35.455050
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    playbook = Mock(
        _file_name = 'my_playbook.yml'
    )
    CallbackModule.CALLBACK_NEEDS_ENABLED = True
    actual = CallbackModule()
    actual.v2_playbook_on_start(playbook)
    assert 'my_playbook' == actual._playbook_name


# Generated at 2022-06-11 13:29:41.149453
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    CallbackModule.set_unit_test()
    CallbackModule.v2_playbook_on_start('playbook')
    assert CallbackModule._playbook_path == 'playbook._file_name'



# Generated at 2022-06-11 13:29:45.896181
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb = CallbackModule()
    playbook = type('playbook_obj', (object,), {'_file_name': 'test.yml'})()

    cb.v2_playbook_on_start(playbook)

    assert cb._playbook_name == 'test'

# Generated at 2022-06-11 13:29:53.153083
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    playbook = Playbook.load(playbook_path="path/to/playbook.yml", variable_manager=None, loader=None)

    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(playbook)
    assert callback_module._playbook_name == "playbook"
    assert callback_module._playbook_path == "path/to/playbook.yml"


# Generated at 2022-06-11 13:29:57.470620
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    """
    Test case to test the method v2_playbook_on_start
    """
    playbook = "Test"
    junit_obj = CallbackModule()
    junit_obj.v2_playbook_on_start(playbook)
    assert junit_obj._playbook_name == "Test"



# Generated at 2022-06-11 13:29:59.527195
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test method with required arguments only
    CallbackModule().v2_playbook_on_start(playbook=None)

# Generated at 2022-06-11 13:30:02.332380
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb = CallbackModule()
    cb.v2_playbook_on_start(playbook=None)


# Generated at 2022-06-11 13:30:44.559221
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # create an instance of the CallbackModule class
    callback = CallbackModule()
    # create an instance of the PlaybookFile class
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 13:30:46.877691
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # TODO:  Need to add unit test for v2_playbook_on_start
    # This is currently not available as part of the CallbackBase
    assert False


# Generated at 2022-06-11 13:30:50.258571
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback = CallbackModule()
    callback.v2_playbook_on_start('playbook')
    assert callback._playbook_path == 'playbook'
    assert callback._playbook_name == 'playbook'


# Generated at 2022-06-11 13:30:54.622169
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    x = CallbackModule()
    x.v2_playbook_on_start(playbook="playbook")
    assert x._playbook_path == "playbook"
    assert x._playbook_name == ""

test_CallbackModule_v2_playbook_on_start()


# Generated at 2022-06-11 13:31:00.524270
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup test data
    playbook = MagicMock()
    
    # Setup mock objects
    
    
    
    
    
    
    
    
    
    
    
    
    # Execute the code to be tested
    callbackmodule = CallbackModule()
    callbackmodule.v2_playbook_on_start(playbook)
    
    # Verify the results
    
    pass


# Generated at 2022-06-11 13:31:01.228478
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass

# Generated at 2022-06-11 13:31:03.692775
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    test_object = CallbackModule()
    playbook = lambda: None
    setattr(playbook, '_file_name', 'tests/data/test.yml')
    test_object.v2_playbook_on_start(playbook)
    assert test_object._playbook_path == 'tests/data/test.yml'
    assert test_object._playbook_name == 'test'


# Generated at 2022-06-11 13:31:11.079559
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    testInput = dict()

    testInput['playbook'] = dict()
    testInput['playbook']['_file_name'] = "/home/user1/playbook.yaml"

    cbm = CallbackModule()
    cbm.v2_playbook_on_start(testInput['playbook'])

    assert cbm._playbook_path     == testInput['playbook']['_file_name']
    assert cbm._playbook_name     == "playbook"


# Generated at 2022-06-11 13:31:19.434371
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    task = unittest.mock.Mock()
    task._uuid = 'task_uuid'
    result = unittest.mock.Mock()
    result._task = task
    result._host = 'host'
    result._result = {
        'changed': True,
    }
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed(result, ignore_errors=True)
    callback_module.v2_runner_on_failed(result)
    result._result['rc'] = 1
    callback_module.v2_runner_on_failed(result)
    result._result['rc'] = 1
    result._result['msg'] = 'msg'
    callback_module.v2_runner_on_failed(result)

# Generated at 2022-06-11 13:31:31.567832
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
	testObj = CallbackModule()
	
	# Test 1
	testObj._fail_on_ignore = "False"
	ignore_errors = True
	status = "ok"
	result = 1
	
	testObj.v2_runner_on_failed(result, ignore_errors)
	assert testObj._task_data[1].host_data[1].status == status
	
	# Test 2
	testObj._fail_on_ignore = "True"
	status = "failed"
	
	testObj.v2_runner_on_failed(result, ignore_errors)
	assert testObj._task_data[1].host_data[1].status == status
	
	# Test 3
	testObj._fail_on_ignore = "True"
	ignore_errors = False
	
	testObj.v2

# Generated at 2022-06-11 13:32:39.395717
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    ref_obj = CallbackModule()
    setattr(ref_obj, "_playbook_path", None)
    setattr(ref_obj, "_playbook_name", None)
    
    test_obj = CallbackModule()
    test_obj.v2_playbook_on_start(playbook=playbook_obj)
    
    assert ref_obj._playbook_path==test_obj._playbook_path
    assert ref_obj._playbook_name==test_obj._playbook_name

# Generated at 2022-06-11 13:32:42.503043
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb = CallbackModule()
    cb.v2_playbook_on_start(None)
    assert(cb._playbook_path == None)
    assert(cb._playbook_name == None)


# Generated at 2022-06-11 13:32:47.863063
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module = CallbackModule()
    class Playbook:
        def __init__(self):
            self._file_name = "test"
    playbook = Playbook()
    callback_module.v2_playbook_on_start(playbook)
    assert callback_module._playbook_name == "test"

# Generated at 2022-06-11 13:33:00.077043
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.hosts.host import Host
    task = Task()
    task._uuid = '12345'
    task._role = None
    task._parent = None
    task._play = None
    task._play_context = None
    task._task_fields = {}
    task._tmp = None
    task._tags = set()
    task._args = None
    task._action = 'setup'
    task.action = 'setup'
    task.block = None
    task.async_val = 0
    task.any_errors_fatal = False
    task.attributes = {}
    task.become = False
    task.become_explicit = False

# Generated at 2022-06-11 13:33:06.299039
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test a valid object
    callback = CallbackModule()
    valid_playbook_mock = type('PlaybookMock', (object,), {
        "hosts": "hosts",
        "name": "name",
        "dependent_roles": "dependent_roles",
        "__dict__": "__dict__",
        "_entries": "_entries",
        "_file_name": "_file_name",
        "roles": "roles"
    })
    callback.v2_playbook_on_start(playbook=valid_playbook_mock())


# Generated at 2022-06-11 13:33:11.198549
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
  # create instance of class to be tested
  instance = CallbackModule()
  # define test input data
  playbook = [{}]
  # call method to be tested
  instance.v2_playbook_on_start(playbook)
  # perform assertions
  assert True # TODO: implement your test here


# Generated at 2022-06-11 13:33:11.804911
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
  pass

# Generated at 2022-06-11 13:33:17.091432
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_path = "test/test-playbook.yml"
    playbook = {'_file_name': playbook_path}
    c = CallbackModule()
    c.v2_playbook_on_start(playbook)
    assert c._playbook_path == playbook_path
    assert c._playbook_name == 'test-playbook'

# Generated at 2022-06-11 13:33:22.882470
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Init parameter
    playbook = Playbook()

    # Call method
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook)
    
    # Test attributes
    result = getattr(callback, '_playbook_path')
    assert result == ''
    
    result = getattr(callback, '_playbook_name')
    assert result == ''
    

# Generated at 2022-06-11 13:33:32.840045
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    with patch("os.path.basename") as mock_os_path_basename:
        with patch("os.path.splitext") as mock_os_path_splitext:
            cb_m = CallbackModule()
            mock_os_path_basename.return_value = "pbook.yml"
            mock_os_path_splitext.return_value = ["pbook",".yml"]
            play_book_file_name = "pbook.yml"
            playbook = MagicMock()
            playbook._file_name = play_book_file_name
            cb_m.v2_playbook_on_start(playbook)
            assert cb_m._playbook_path == play_book_file_name
            assert cb_m._playbook_name == "pbook"