

# Generated at 2022-06-21 03:55:19.330799
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
  pass
from ansible.module_utils.six import PY2
if not PY2:
  raise Exception('Cannot test for non-ascii characters under Python2')
from ansible.module_utils.basic import AnsibleModule
if not PY2:
  class AnsibleModule(object):
    def __init__(self, *args, **kwargs):
      pass

result = dict(
  ansible_facts=dict(
    junit_output_dir=None,
  )
)
assert AnsibleModule(
  argument_spec=dict(
  ),
).execute_module() == result

result = dict(
  ansible_facts=dict(
    junit_output_dir=None,
  )
)

# Generated at 2022-06-21 03:55:20.524842
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
	pass


# Generated at 2022-06-21 03:55:24.195311
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    obj = CallbackModule()
    task = unittest.mock.MagicMock()
    obj.v2_playbook_on_handler_task_start(task)

# Generated at 2022-06-21 03:55:26.503456
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    a = 'a'
    b = 'b'
    c = CallbackModule(a, b)
    assert c != None


# Generated at 2022-06-21 03:55:35.562046
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = Namespace()
    result._result = {'changed': False, 'ansible_facts': {'some_key': 'some_value'}, 'skip_reason': 'some_skip_reason'}
    callback = CallbackModule()
    callback._start_task(Namespace(action='some_action', _uuid='some_uuid', no_log=False, args={'x': 'y', 'a': 'b'}))
    callback.v2_runner_on_ok(result)
    test_case = callback._build_test_case(callback._task_data['some_uuid'], callback._task_data['some_uuid'].host_data['some_host'])

# Generated at 2022-06-21 03:55:47.024367
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    with patch('builtins.open') as m_open:
        with patch('junit_xml.TestCase') as m_TestCase:
            with patch('junit_xml.TestSuite') as m_TestSuite:
                with patch('junit_xml.TestSuites') as m_TestSuites:
                    # Setup test
                    module = CallbackModule()
                    module._playbook_name = 'playbook_name'
                    module._play_name = 'play_name'
                    module.v2_playbook_on_task_start(task, is_conditional)
                    host_data = HostData()
                    task_data = TaskData()
                    task_data.add_host(host_data)
                    module._task_data = {'ok':task_data}

# Generated at 2022-06-21 03:55:48.837312
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
	pass
	# TestCase 1
	CallbackModule().v2_playbook_on_cleanup_task_start()

# Generated at 2022-06-21 03:55:52.141316
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    instance = CallbackModule()
    # TODO: Test for v2_playbook_on_task_start of class CallbackModule



# Generated at 2022-06-21 03:55:54.537271
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
  """
  TestCase for method v2_playbook_on_stats
  """
  pass

# Generated at 2022-06-21 03:56:06.050331
# Unit test for method v2_runner_on_skipped of class CallbackModule

# Generated at 2022-06-21 03:56:23.989050
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # CallbackModule tests setUp
    c = CallbackModule()
    c.disabled = False
    c._output_dir = '/home/eacc/.ansible.log'
    c._task_class = 'false'
    c._task_relative_path = ''
    c._fail_on_change = 'false'
    c._fail_on_ignore = 'false'
    c._include_setup_tasks_in_report = 'true'
    c._hide_task_arguments = 'false'
    c._test_case_prefix = ''
    c._playbook_path = None
    c._playbook_name = None
    c._play_name = None
    c._task_data = None
    # Mock inputs
    playbook = Mock()

# Generated at 2022-06-21 03:56:28.385950
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    '''
    Unit tests for method v2_playbook_on_handler_task_start of class CallbackModule
    '''

    import ansible.plugins.callback as callback
    import ansible.plugins.callback.junit as junit

    cbm = callback.CallbackModule()
    cbm.v2_playbook_on_handler_task_start(None)
    assert True



# Generated at 2022-06-21 03:56:33.941339
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    cb = CallbackModule()
    included_file = IncludedFile()

    cb.v2_playbook_on_include(included_file)

    assert cb._finish_task.__name__ == "v2_playbook_on_include"


# Generated at 2022-06-21 03:56:42.359269
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook_path = "hello.yml"
    playbook = [{}, "", playbook_path]
    # nbateam=["hello.yml", "", playbook_path]
    # print type(playbook)
    # print type(playbook)
    # print type(playbook[2])
    # print type(playbook[1])
    # print type(playbook[0])
    #
    # print type(playbook[0].get("hosts"))
    # print type(playbook[0].get("name"))
    #
    # print playbook[0].get("hosts")
    # print playbook[0].get("name")
    # print type(playbook[0].get("hosts"))
    #
    # print playbook[1]
    # print type(playbook[1])
    #


# Generated at 2022-06-21 03:56:43.114362
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass # TODO

# Generated at 2022-06-21 03:56:46.693565
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('123', 'Copy secret file', 'copy/secret_file.yml', 'Play Name', 'Copy')
    task_data.add_host('123', 'Host Name', 'ok', 'Transfer')


# Generated at 2022-06-21 03:56:49.663906
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():

    module = CallbackModule()
    task = 'task1'
    module.v2_runner_on_no_hosts(task)
    assert module._start_task(task) != None


# Generated at 2022-06-21 03:56:50.694629
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    pass


# Generated at 2022-06-21 03:56:53.497164
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    c = CallbackModule()
    c._start_task = Mock()
    c.v2_playbook_on_handler_task_start(Mock())
    c._start_task.assert_called_once_with(Mock())


# Generated at 2022-06-21 03:57:06.607607
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # init object
    callback = CallbackModule()
    # test all the variables to ensure that they are set to the expected defaults.

    assert callback._output_dir is not None
    assert callback._output_dir == os.path.expanduser('~/.ansible.log')

    assert callback._task_class is not None
    assert callback._task_class == 'false'

    assert callback._task_relative_path is not None
    assert callback._task_relative_path == ''

    assert callback._fail_on_change is not None
    assert callback._fail_on_change == 'false'

    assert callback._fail_on_ignore is not None
    assert callback._fail_on_ignore == 'false'

    assert callback._include_setup_tasks_in_report is not None
    assert callback._include_setup_tasks_in_

# Generated at 2022-06-21 03:57:20.392074
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    __tracebackhide__ = True
    assert True

# Generated at 2022-06-21 03:57:25.240847
# Unit test for constructor of class TaskData
def test_TaskData():
    """
    Unit test for constructor of class TaskData
    """

    # Create object of class TaskData
    taskDataInstance = TaskData(1, 'name', 'path', 'play', 'action')
    # test object of class TaskData
    assert taskDataInstance.uuid == 1
    assert taskDataInstance.name == 'name'
    assert taskDataInstance.path == 'path'
    assert taskDataInstance.play == 'play'
    assert taskDataInstance.start == None
    assert taskDataInstance.action == 'action'
    assert type(taskDataInstance.host_data) is dict



# Generated at 2022-06-21 03:57:29.020766
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():

    result = TaskResult()
    result.task = Task()
    result.task._uuid = '1234'
    callback = CallbackModule()
    callback.v2_runner_on_no_hosts(result.task)
    assert callback._task_data['1234'] == TaskData('1234', '', None, None, 'command')
    callback.playbook_on_task_start(result.task, False)


# Generated at 2022-06-21 03:57:31.486175
# Unit test for constructor of class HostData
def test_HostData():
    result = HostData(1, 'name', 'status', 'result')
    assert result.uuid == 1
    assert result.name == 'name'
    assert result.status == 'status'
    assert result.result == 'result'

# Generated at 2022-06-21 03:57:38.295546
# Unit test for constructor of class HostData
def test_HostData():
    host_data = HostData('uuid', 'host01', 'status', 'result')
    assert host_data.uuid == 'uuid'
    assert host_data.name == 'host01'
    assert host_data.status == 'status'
    assert host_data.result == 'result'

# Generated at 2022-06-21 03:57:42.066958
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    import mock

    task, is_conditional = mock.MagicMock(), mock.MagicMock()
    CallbackModule().v2_playbook_on_cleanup_task_start(task, is_conditional)


# Generated at 2022-06-21 03:57:45.887836
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb._playbook_path = None
    cb.v2_playbook_on_start(playbook)
    assert cb._playbook_name == os.path.splitext(os.path.basename(playbook._file_name))[0]

# Generated at 2022-06-21 03:57:58.567265
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    from ansible import errors
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # CallbackModule.v2_playbook_on_task_start() with default parameters
    # setup
    _playbook = mock.Mock()

    _playbook._file_name = 'x'
    _is_conditional = False
    _task = mock.Mock()
    _task.get_name.return_value = 'x'
    _task.action = 'x'
    _task._uuid = 'x'
    _task.args = {'x': 'x'}
    _task.get_path.return_value = 'x'
    _task.no_log = False

    _self = CallbackModule()
    _self._task_data = {}

    # exercise

# Generated at 2022-06-21 03:58:05.282439
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    """
    Test Case:
        Test if v2_playbook_on_include is called

    Assertions:
        assert a_callback_module.v2_playbook_on_include(included_file = True)
    """
    a_callback_module = CallbackModule()
    assert a_callback_module.v2_playbook_on_include(included_file = True)


# Generated at 2022-06-21 03:58:07.113607
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Setup
    stats = MagicMock()

    # Execute
    object = CallbackModule()
    object._generate_report()

##
# Class to collect and manage the task data.
##

# Generated at 2022-06-21 03:58:33.496035
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert(module)

# Generated at 2022-06-21 03:58:45.574943
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    c = CallbackModule()
    assert c._output_dir == os.path.expanduser('~/.ansible.log')
    assert c._task_class == 'false'
    assert c._task_relative_path == ''
    assert c._fail_on_change == 'false'
    assert c._fail_on_ignore == 'false'
    assert c._include_setup_tasks_in_report == 'true'
    assert c._hide_task_arguments == 'false'
    assert c._test_case_prefix == ''
    assert c._playbook_path == None
    assert c._playbook_name == None
    assert c._play_name == None
    assert c._task_data == None
    assert c.disabled == False
    assert c._task_data == {}


# Generated at 2022-06-21 03:58:51.966888
# Unit test for constructor of class TaskData
def test_TaskData():
    uuid1 = 'e749a153-6d73-46a0-9873-f82f2dbc9f51'
    name1 = 'Task1'
    path1 = './../test/Task1.yml'
    play1 = 'Play1'
    start1 = time.time()
    action1 = 'action1'

    task_data = TaskData(uuid1, name1, path1, play1, action1)
    if task_data.uuid != uuid1 or task_data.name != name1 or task_data.path != path1 or task_data.play != play1 or task_data.action != action1:
        raise Exception('TaskData could not be created')



# Generated at 2022-06-21 03:58:54.148316
# Unit test for constructor of class HostData
def test_HostData():
    hostdata = HostData()
    assert(hostdata.get_uptime_string() == "")

# Generated at 2022-06-21 03:58:57.142353
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    class Mock_playbook:
        mock_get_name = 'name'

    result = CallbackModule()
    result.v2_playbook_on_play_start(Mock_playbook())
    assert result._play_name == Mock_playbook().mock_get_name



# Generated at 2022-06-21 03:59:00.394790
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_task_start('')


# Generated at 2022-06-21 03:59:12.147388
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    cb = CallbackModule()

    assert cb.CALLBACK_VERSION == 2.0
    assert cb.CALLBACK_TYPE == 'aggregate'
    assert cb.CALLBACK_NAME == 'junit'
    assert cb.CALLBACK_NEEDS_ENABLED

    cb.v2_runner_on_skipped(result="hello")

    assert isinstance(cb._task_relative_path, str)
    assert cb._task_relative_path == ''
    assert isinstance(cb._fail_on_change, str)
    assert cb._fail_on_change == 'false'
    assert isinstance(cb._fail_on_ignore, str)
    assert cb._fail_on_ignore == 'false'

# Generated at 2022-06-21 03:59:16.815563
# Unit test for constructor of class HostData
def test_HostData():
    result = ''
    uuid = '1'
    name = 'Host'
    status = 'ok'
    host = HostData(uuid, name, status, result)
    assert host.uuid is not None
    assert host.name is not None
    assert host.status is not None
    assert host.result is not None
    assert host.finish is not None


# Generated at 2022-06-21 03:59:24.785203
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    """
    This test checks that method v2_playbook_on_include() of class CallbackModule
    works as expected.
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.plugins.loader import module_loader
    from ansible.plugins.callback import CallbackModule

# Generated at 2022-06-21 03:59:29.337312
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback = CallbackModule()
    result = [{'msg': 'skip_reason'},{'msg': 'skip_reason'}]
    stats = {'changed': 2, 'ok': 2, 'dark': 0, 'failures': 2, 'processed': 2, 'skipped': 2, 'unreachable': 0}
    callback.v2_runner_on_failed(result)
    callback.v2_playbook_on_stats(stats)
    if (not callback._task_data):
        return False
    else:
        return True


# Generated at 2022-06-21 04:00:34.145716
# Unit test for constructor of class TaskData
def test_TaskData():
    uuid = 'task_1_12345'
    name = 'task_1'
    path = 'main.yml'
    play = 'main'
    action = 'command'
    task_data = TaskData(uuid, name, path, play, action)
    assert(task_data.uuid == uuid)
    assert(task_data.name == name)
    assert(task_data.path == path)
    assert(task_data.play == play)
    assert(task_data.start is not None)
    assert(task_data.host_data == {})
    assert(task_data.action == action)



# Generated at 2022-06-21 04:00:35.270832
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    pass
    #TODO

# Generated at 2022-06-21 04:00:42.603669
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
  c = CallbackModule()
  c.v2_playbook_on_handler_task_start("a", "b")
  c.v2_playbook_on_handler_task_start("b", "c")
  assert c._task_data.__len__() == 2

# Generated at 2022-06-21 04:00:54.903449
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # DEF VARS
    result = None
    ignore_errors = False

# Generated at 2022-06-21 04:01:03.203802
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    task=object()
    task.action='set_fact'
    task.name='Toggle result'
    task.no_log='False'
    task.tags=[]
    task.args= {'a': 1, 'ansible_check_mode': 'True', 'b': 2,'ansible_version': {'full': '2.7.10', 'major': 2, 'minor': 7, 'revision': 10, 'string': '2.7.10'}, 'var': 'var1'}
    task.action='set_fact'

    result=object()
    result._task=task

# Generated at 2022-06-21 04:01:15.913677
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    mock_task, mock_is_conditional = MagicMock(spec=Task, name='_MockTask'), True
    mock_self = MagicMock(spec=CallbackModule, name='_MockCallbackModule')

    # Call play without task_class set
    callback_module.v2_playbook_on_task_start(mock_self, mock_task, True)
    assert mock_self._play_name == mock_task.get_name()
    assert mock_task.action not in C._ACTION_SETUP
    assert mock_self._playbook_name == os.path.splitext(os.path.basename(mock_self._playbook_path))[0]

    # Call play with task_class set to False
    mock_self.task_class = 'False'
    callback_module.v2_

# Generated at 2022-06-21 04:01:21.321005
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    stat = dict()
    stat["msg"] = "Hello"
    result = dict()
    result["_result"] = stat
    
    obj = CallbackModule()
    
    
    
    
    assert_equals(obj._finish_task('failed', result), None)
    
    


# Generated at 2022-06-21 04:01:26.168523
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    callbackModule = CallbackModule()
    task = mock.Mock()
    task._uuid = 'task_uuid'
    task.action = 'task_action'
    is_conditional = False
    # v2_playbook_on_task_start
    callbackModule.v2_playbook_on_task_start(task, is_conditional)

# Generated at 2022-06-21 04:01:27.351224
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    x = CallbackModule()
    file_cls = 'file_cls'
    x.v2_playbook_on_include(file_cls)

# Generated at 2022-06-21 04:01:29.673080
# Unit test for constructor of class TaskData
def test_TaskData():
    taskdata = TaskData('test_uuid', 'test_name', 'test_path', 'test_play', 'test_action')
    assert 'test_uuid' == taskdata.uuid
    assert 'test_name' == taskdata.name
    assert 'test_path' == taskdata.path
    assert 'test_action' == taskdata.action
    assert taskdata.host_data == {}


# Generated at 2022-06-21 04:03:45.670566
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    next_uuid = 1
    task_data = TaskData(next_uuid, 'my name', 'my path', 'my play', 'my action')
    next_uuid += 1
    host = HostData(next_uuid, 'my name', 'ok' , 'result')

    task_data.add_host(host)

    # Verify 3 private attributes of the task_data had been initialized
    assert task_data.name == 'my name'
    assert task_data.path == 'my path'
    assert task_data.play == 'my play'
    assert task_data.start == None
    assert task_data.action == 'my action'

    # Verify the class HostData was created correctly
    assert host.uuid == 1
    assert host.name == 'my name'
    assert host.status == 'ok'


# Generated at 2022-06-21 04:03:47.799991
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().__class__.__name__ == 'CallbackModule'


# Generated at 2022-06-21 04:03:58.450111
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    import unittest

    # Create objects for testing
    task_uuid = 'task_uuid'
    name = 'name'
    path = 'path'
    play = 'play'
    action = 'action'
    task_data = TaskData(task_uuid, name, path, play, action)
    host_uuid = 'host_uuid'
    host_name = 'host_name'
    status = 'status'
    result = 'result'
    host = HostData(host_uuid, host_name, status, result)

    # Add the host
    task_data.add_host(host)

    # Test the result
    assert task_data.uuid == task_uuid 
    assert task_data.name == name
    assert task_data.path == path

# Generated at 2022-06-21 04:04:08.936360
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():
    # Set up mock objects and context
    task = mock.MagicMock()
    callback_module = CallbackModule()
    callback_module._start_task = mock.MagicMock()
    callback_module.disabled = False
    callback_module._play_name = None
    
    
    
    
    # Invoke method
    callback_module.v2_runner_on_no_hosts(task=task)
    
    # Check results
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # Reset mocks
    task.reset_mock()
    callback_module._start_task.reset_mock()
    callback_module.disabled = None
    callback_module._play_name = None
    callback_module.v2_runner_on

# Generated at 2022-06-21 04:04:11.079558
# Unit test for constructor of class HostData
def test_HostData():
    h = HostData(uuid='test_uuid', name='test_name', status='ok', result='result')
    assert type(h.uuid) is str
    assert type(h.name) is str
    assert type(h.status) is str
    assert type(h.result) is str
    assert type(h.finish) is float


# Generated at 2022-06-21 04:04:15.908530
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    '''
    Unit test for method v2_runner_on_failed of class CallbackModule
    '''
    obj = CallbackModule()
    try:
        obj.v2_runner_on_failed(result, ignore_errors=False)
        assert False, "unit test - should have thrown exception"
    except:
        pass

# Generated at 2022-06-21 04:04:18.199035
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback = CallbackModule()
    callback._generate_report()
# End of unit test

# Generated at 2022-06-21 04:04:20.781986
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    tmp_test_class = CallbackModule()
    tmp_test_class.v2_playbook_on_stats(stats=None)


# Generated at 2022-06-21 04:04:23.019689
# Unit test for constructor of class HostData
def test_HostData():
    hostd = HostData(1, "host1", "skipped", "skip_reason")
    assert hostd.name == "host1"
    assert hostd.status == "skipped"
    assert hostd.result == "skip_reason"
    assert hostd.uuid == 1


# Generated at 2022-06-21 04:04:27.608453
# Unit test for constructor of class HostData
def test_HostData():
    result = 6
    testData = HostData(uuid = 1, name = "Host1", status = 1, result = result)
    assert result == testData.result
    assert "Host1" == testData.name
