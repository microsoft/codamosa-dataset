

# Generated at 2022-06-21 03:55:06.063885
# Unit test for constructor of class HostData
def test_HostData():
    tHostData = HostData('a', 'b', 'c', 'd')
    assert tHostData.uuid == 'a'
    assert tHostData.name == 'b'
    assert tHostData.status == 'c'
    assert tHostData.result == 'd'
    assert tHostData.finish != None



# Generated at 2022-06-21 03:55:08.956612
# Unit test for constructor of class TaskData
def test_TaskData():
    td = TaskData('some_uuid', 'some_name', 'some_path', 'some_play', 'some_action')
    assert td is not None
    assert td.uuid == 'some_uuid'
    assert td.name == 'some_name'
    assert td.path == 'some_path'
    assert td.play == 'some_play'


# Generated at 2022-06-21 03:55:09.889347
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass


# Generated at 2022-06-21 03:55:21.293477
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start(): 
    with pytest.raises(NotImplementedError) as excinfo:
        callback_module = CallbackModule()
        callback_module.v2_playbook_on_play_start()
        path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
        data_path = os.path.abspath(os.path.join(path, 'test', 'unit', 'callback_plugins', 'files', 'ansible.log'))
        assert isinstance(excinfo.value, NotImplementedError)
        assert data_path == callback_module._output_dir
        assert '' == callback_module._task_relative_path
        assert 'false' == callback_module._fail_on_change
        assert 'false' == callback_

# Generated at 2022-06-21 03:55:30.012036
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import ansible
    runner = ansible.module_utils.basic.AnsibleModule()
    cb = CallbackModule()
    cb.disabled = False
    cb.v2_playbook_on_start(runner)
    cb._start_task(runner)
    cb.v2_runner_on_ok(runner)
    #assert runner._result['changed'] is False
    #assert runner._result['file_exists'] is True
    #assert runner._result['is_directory'] is False
    #assert runner._result['size'] == 0

# Generated at 2022-06-21 03:55:36.666678
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    obj = TaskData("uuid","name","path","play","action")
    obj.add_host("host")
    assert obj.start == obj.start,'%s != %s' % (obj.start, obj.start)
    assert obj.host_data["host"].name == "host.name",'%s != %s' % (obj.host_data["host"].name, "host.name")


# Generated at 2022-06-21 03:55:42.000471
# Unit test for constructor of class HostData
def test_HostData():
    uuid = 1
    name = 'test'
    status = 'ok'
    result = 'success'
    host = HostData(uuid, name, status, result)
    assert host.uuid == 1
    assert host.name == name
    assert host.status == status
    assert host.result == result

# Generated at 2022-06-21 03:55:46.203920
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    c = CallbackModule()
    pb = mock.Mock()
    pb._file_name = 'test file'
    c.v2_playbook_on_start(pb)
    assert c._playbook_path == 'test file'
    assert c._playbook_name == 'test file'

# Generated at 2022-06-21 03:55:48.900499
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    c = CallbackModule()
    c.v2_playbook_on_cleanup_task_start("task")


# Generated at 2022-06-21 03:55:50.293159
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():
    assert True


# Generated at 2022-06-21 03:56:04.152630
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # arrange
    args = get_callback_module_args()
    args['task_relative_path'] = '.'
    ansible_host = MagicMock()
    ansible_host.configuration = get_ansible_host_configuration()
    callback = CallbackModule()
    callback.disabled = False
    mocked_playbook = MagicMock()

    # act
    callback.v2_playbook_on_start(mocked_playbook)

    # assert
    assert callback.CALLBACK_VERSION == 2.0
    assert callback.CALLBACK_TYPE == 'aggregate'
    assert callback.CALLBACK_NAME == 'junit'
    assert callback.CALLBACK_NEEDS_ENABLED == True
    assert callback.disabled == False
    assert mocked_playbook._file_name != None

# Generated at 2022-06-21 03:56:15.850639
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():
    '''
    Test
    '''

    # setup test data
    no_hosts_message = {}
    no_hosts_message['message'] = "No hosts matched"


    # setup test class
    callback = CallbackModule()
    callback._start_task = mock.MagicMock()
    callback._finish_task = mock.MagicMock()
    callback._build_test_case = mock.MagicMock(return_value=no_hosts_message['message'])
    callback._cleanse_string = mock.MagicMock(return_value=no_hosts_message['message'])
    callback._generate_report = mock.MagicMock()

    task = mock.MagicMock()

    # run test
    callback.v2_runner_on_no_hosts(task)

    # verify


# Generated at 2022-06-21 03:56:17.826579
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    pass # TODO: create unit test for v2_runner_on_skipped method of class CallbackModule


# Generated at 2022-06-21 03:56:21.928248
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    # Test missing argument
    with pytest.raises(TypeError) as excinfo:
        CallbackModule().v2_playbook_on_handler_task_start()
    assert 'required argument' in str(excinfo.value)

# Generated at 2022-06-21 03:56:30.438063
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    __test__ = True
    _output_dir = os.getenv("JUNIT_OUTPUT_DIR", os.path.expanduser("~/.ansible.log"))
    _task_class = os.getenv("JUNIT_TASK_CLASS", "False").lower()
    _task_relative_path = os.getenv("JUNIT_TASK_RELATIVE_PATH", "")
    _fail_on_change = os.getenv("JUNIT_FAIL_ON_CHANGE", "False").lower()
    _fail_on_ignore = os.getenv("JUNIT_FAIL_ON_IGNORE", "False").lower()

# Generated at 2022-06-21 03:56:40.940229
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():

    # Test specific imports
    import mock
    import os.path
    import ansible.playbook.play as Play

    # Mocked function call
    mocked_task = mock.MagicMock(spec=Play.Task)
    mocked_task.get_name.return_value = 'Cleanup'
    mocked_task.action = 'cleanup'
    mocked_task.no_log = False
    mocked_task.args = {}

    # test callback module
    cm = CallbackModule()

    # test on_playbook_on_cleanup_task_start
    cm.v2_playbook_on_cleanup_task_start(mocked_task)
    assert cm._task_data
    assert len(cm._task_data) == 1
    assert 'cleanup' in cm._task_data

# Generated at 2022-06-21 03:56:48.359629
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    cb = CallbackModule()
    task = 'dummy-task'
    result = 'dummy-result'
    cb.v2_runner_on_skipped(result)
    [task_uuid, task_data] = cb._task_data.items()[0]
    [host_uuid, host_data] = task_data.host_data.items()[0]
    assert host_data.status == 'skipped'
    assert host_data.finish - task_data.start >= 0


# Generated at 2022-06-21 03:56:55.821485
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():
    from ansible import context
    from ansible.module_utils._text import to_bytes
    from ansible.runner.return_data import ReturnData
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    cb = CallbackModule()
    cb.disabled = False

    v = VariableManager()
    h = HostVars(host_name='host')
    hvars = v.get_vars(loader=None, play=None, host=h)

    task = mock.Mock()
    task._uuid = '123'
    task.action = 'task'
    task.no_log = True
    task.get_name.return_value = 'task name'
    task.get_path.return_value = '/path/to/task'

# Generated at 2022-06-21 03:57:07.643234
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    import mock

    ansible_playbook_on_include_mock = mock.MagicMock()
    ansible_playbook_on_include_mock.__str__ = mock.MagicMock(return_value='ansible_playbook_on_include_mock')
    ansible_playbook_on_include_mock.__repr__ = mock.MagicMock(return_value='ansible_playbook_on_include_mock')
    ansible_playbook_on_include_mock.name = 'ansible_playbook_on_include_mock_name'

# Generated at 2022-06-21 03:57:12.004496
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    file_path = input("Enter the full path of the playbook file: ")
    included_file = input("Enter the included file: ")
    cb = CallbackModule()
    cb.v2_playbook_on_include(included_file)


# Generated at 2022-06-21 03:57:29.562050
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = dict(changed=False)
    # TODO: Add real test cases
    for case in [dict(result=result)]:
        module = CallbackModule()
        module.v2_runner_on_ok(result)


# Generated at 2022-06-21 03:57:42.021674
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    import ansible.plugins.callback
    from ansible.vars.manager import VariableManager

    from ansible.plugins.loader import module_loader

    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    ansible.utils.vars.load_extra_vars = load_extra_vars
    ansible.utils.vars.load_options_vars = load_options_vars
    ansible.utils.vars.merge_hash = merge_hash


# Generated at 2022-06-21 03:57:43.655724
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    test_object = CallbackModule()
    assert test_object


# Generated at 2022-06-21 03:57:57.058257
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    a = CallbackModule()
    a._playbook_path = '/tmp/test_playbook_path'
    a._playbook_name = 'test_playboook_name'
    a._fail_on_change = 'False'
    a._include_setup_tasks_in_report = 'True'
    a._task_data = {}

    test_case = TestCase(name='test_case', classname='test_case_classname',
                          time=0, system_out='test_case_system_output')

# Generated at 2022-06-21 03:58:05.283579
# Unit test for constructor of class TaskData
def test_TaskData():
    taskdata = TaskData('1234', 'name', 'path', 'play', 'action')
    assert taskdata.uuid == '1234'
    assert taskdata.name == 'name'
    assert taskdata.path == 'path'
    assert taskdata.play == 'play'
    assert taskdata.start is not None
    assert taskdata.host_data == {}
    assert taskdata.action == 'action'



# Generated at 2022-06-21 03:58:10.354569
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    import unittest

    from ansible.playbook import Playbook

    playbook = Playbook()
    callbackModule = CallbackModule()
    callbackModule.v2_playbook_on_start(playbook)

    assert callbackModule._playbook_path is None
    assert callbackModule._playbook_name is None



# Generated at 2022-06-21 03:58:12.684501
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback = CallbackModule()
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-21 03:58:24.579632
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print("Testing CallbackModule.v2_runner_on_ok() ...")
    class Task:
        def __init__(self):
            self._uuid = None
            self._name = None
            self._path = None

        def get_name(self):
            return self._name

        def get_path(self):
            return self._path

        def get_action(self):
            return self._action

    class Result:
        def __init__(self):
            self._task = None
            self._result = None
            self._host = None

        def get_task(self):
            return self._task

        def get_result(self):
            return self._result

        def get_host(self):
            return self._host

    class Host:
        def __init__(self, name):
            self

# Generated at 2022-06-21 03:58:29.946324
# Unit test for constructor of class HostData
def test_HostData():
    uuid = 'dummy_uuid'
    name = 'dummy_name'
    status = 'dummy_status'
    result = 'dummy_result'
    host_data = HostData(uuid, name, status, result)
    assert(host_data.uuid == uuid)
    assert(host_data.name == name)
    assert(host_data.status == status)
    assert(host_data.result == result)

# Generated at 2022-06-21 03:58:30.897061
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass

# Generated at 2022-06-21 03:59:00.125736
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb = CallbackModule()
    cb.v2_playbook_on_start("playbook")
    assert cb._playbook_path == "playbook"


# Generated at 2022-06-21 03:59:02.293999
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():
    _callback = CallbackModule()
    _task = ""
    _callback.v2_runner_on_no_hosts(_task)



# Generated at 2022-06-21 03:59:14.059165
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class A(object):
        def __init__(self, path, name=None, action=None):
            self._file_name = path
            if name:
                self.get_name = lambda: name
            if action:
                self.action = action
    class B(object):
        def __init__(self, path, name=None, action=None):
            self.get_path = lambda: path
            if name:
                self.get_name = lambda: name
            if action:
                self.action = action
    class C(object):
        def __init__(self, path, name=None, action=None):
            self.path = path
            if name:
                self.name = name
            if action:
                self.action = action

# Generated at 2022-06-21 03:59:22.672719
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    result = PlaybookResults(
        tasks=[
            PlaybookResult(
                task_name='foo',
                task_action='bar',
                task_path='foo.yml',
                task_uuid='uuid-foo',
                task_results=[
                    HostResult(
                        host_name='test-host',
                        host_uuid='uuid-test-host',
                        result={
                            'msg': 'error message'
                        }
                    )
                ],
            )
        ]
    )
    ignore_errors=False
    callback_module = CallbackModule()
    # Act
    callback_module.v2_runner_on_failed(result, ignore_errors=ignore_errors)
    # Assert

# Generated at 2022-06-21 03:59:27.432034
# Unit test for constructor of class TaskData
def test_TaskData():
    t = TaskData('uuid', 'name', 'path', 'play', 'action')
    assert t.uuid == 'uuid'
    assert t.name == 'name'
    assert t.path == 'path'
    assert t.play == 'play'
    assert t.start is not None
    assert t.host_data == {}
    assert t.action == 'action'



# Generated at 2022-06-21 03:59:31.407345
# Unit test for constructor of class TaskData
def test_TaskData():
    test_task_data = TaskData("abc123", "test_name", "test_path", "test_play", "test_action")
    assert test_task_data.uuid == "abc123"
    assert test_task_data.name == "test_name"
    assert test_task_data.path == "test_path"
    assert test_task_data.play == "test_play"
    assert test_task_data.action == "test_action"
    assert test_task_data.start == None
    assert test_task_data.host_data == {}


# Generated at 2022-06-21 03:59:37.828180
# Unit test for constructor of class HostData
def test_HostData():

    uuid = '68d2d81e-8e11-4b67-b3d3-0a955b252073'
    name = 'test_HostData'
    status = 'failed'
    result = '{"deprecated_msg": "Test for HostData class"}'
    host_data = HostData(uuid, name, status, result)

    assert host_data.uuid == uuid
    assert host_data.name == name
    assert host_data.status == status
    assert host_data.result == result


# Generated at 2022-06-21 03:59:42.665483
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    # Setup
    ansible_path = 'ansible/plugins/callback'
    sys_path = sys.path
    sys.path.append(ansible_path)
    callback = CallbackModule()
    callback._task_relative_path = 'ansible/test/test_playbooks'
    # Exercise
    callback.v2_playbook_on_task_start(task, is_conditional)
    # Verify
    # Cleanup
    sys.path = sys_path


# Generated at 2022-06-21 03:59:44.593583
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass



# Generated at 2022-06-21 03:59:46.512091
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    obj = CallbackModule()
    obj.v2_playbook_on_stats(stats)

# Generated at 2022-06-21 04:00:46.424101
# Unit test for constructor of class TaskData
def test_TaskData():
    t = TaskData('uuid', 'name', 'path', 'play', 'action')

    assert t.uuid == 'uuid'
    assert t.name == 'name'
    assert t.path == 'path'
    assert t.play == 'play'
    assert t.start is not None
    assert t.host_data == {}
    assert t.action == 'action'



# Generated at 2022-06-21 04:00:50.871092
# Unit test for constructor of class CallbackModule
def test_CallbackModule():

    # create a global instance of the callback module
    global junit_callback_plugin
    junit_callback_plugin = CallbackModule()
    assert len(junit_callback_plugin._task_data) == 0
    assert junit_callback_plugin.disabled == False

# Generated at 2022-06-21 04:01:00.949331
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # create mock to replace ansible.plugins.callback.CallbackBase()
    mock_CallbackBase = MagicMock()
    mock_CallbackBase_instance = mock_CallbackBase.return_value

    # create mock to replace ansible.utils._junit_xml()
    mock_junit_xml = MagicMock()
    mock_junit_xml_instance = mock_junit_xml.return_value

    # create mock to replace ansible.module_utils._text()
    mock_module_utils_text = MagicMock()
    mock_module_utils_text_instance = mock_module_utils_text.return_value

    # create mock to replace os.makedirs()
    mock_os_makedirs = MagicMock()


# Generated at 2022-06-21 04:01:03.278163
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    cbm = CallbackModule()
    print(cbm.CALLBACK_TYPE)
    print(cbm.CALLBACK_NAME)
    print(cbm.CALLBACK_NEEDS_ENABLED)



# Generated at 2022-06-21 04:01:09.438390
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Make sure we have a CallbackModule object
    cb = CallbackModule()

    # Create a simple result object
    result = {'_result': {'foo': 10}}

    # Try to call method v2_runner_on_failed
    cb.v2_runner_on_failed(result)


# Generated at 2022-06-21 04:01:21.843677
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    class mock_stats(): pass
    class mock_included_file(): 
        def __init__(self):
            self._result = { 'stderr': 'error', 'stderr_lines': ['error'], 'stdout': 'output', 'stdout_lines': ['output'], 'changed': True }

    instance = CallbackModule()
    instance._finish_task = unittest.mock.MagicMock()
    instance._generate_report = unittest.mock.MagicMock()
    included_file = mock_included_file()
    stats = mock_stats()
    instance.v2_playbook_on_include(included_file)
    instance._finish_task.assert_called_once()

# Generated at 2022-06-21 04:01:30.402555
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callbackModule = CallbackModule()


# Generated at 2022-06-21 04:01:35.414934
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    #arrange
    result_mock = Mock()
    obj = CallbackModule()
    #act
    obj._finish_task('ok', result_mock)
    #assert
    assert obj._task_data[result_mock._task._uuid].host_data[result_mock._host._uuid].status == 'ok'


# Generated at 2022-06-21 04:01:43.882565
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    # Arrange
    test_name = 'test'
    test_path = 'path'
    test_play = 'play'
    test_uuid = 'uuid'
    test_action = 'action'
    test_host = HostData('uuid', 'name', 'ok', 'result')
    test_object = TaskData(test_uuid, test_name, test_path, test_play, test_action)

    # Act
    test_object.add_host(test_host)

    # Assert
    assert (test_object.host_data['uuid'].status == 'ok')



# Generated at 2022-06-21 04:01:45.416488
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    assert True == True
 # Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule

# Generated at 2022-06-21 04:04:34.566395
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    module = CallbackModule()
    assert module.disabled == False

# Generated at 2022-06-21 04:04:35.165812
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    assert True

# Generated at 2022-06-21 04:04:38.823341
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert not CallbackModule().disabled
    assert CallbackModule()._task_class == 'false'
    assert CallbackModule()._fail_on_change == 'false'
    assert CallbackModule()._fail_on_ignore == 'false'
    assert CallbackModule()._include_setup_tasks_in_report == 'true'
    assert CallbackModule()._test_case_prefix == ''



# Generated at 2022-06-21 04:04:49.701471
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import os
    import sys
    import unittest
    class_name = "CallbackModule"
    log_path = "/tmp/junit-test.log"
    try:
        os.remove(log_path)
    except OSError:
        pass