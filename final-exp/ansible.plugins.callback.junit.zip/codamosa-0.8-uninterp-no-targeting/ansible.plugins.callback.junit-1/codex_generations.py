

# Generated at 2022-06-21 03:55:13.897828
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # arrange
    result = MagicMock()
    result._result = {'rc': 1}
    result._task = MagicMock()
    result._task._uuid = '12345'
    result._host = MagicMock()
    result._host._uuid = '67890'
    result._host.name = 'host.name'
    result._host.host_name = 'host.name'
    cb = CallbackModule()
    cb.v2_playbook_on_start(MagicMock())
    cb._playbook_path = '/a/path/playbook.yml'
    cb._playbook_name = 'playbook'
    cb._play_name = 'play'
    cb.v2_playbook_on_task_start(result._task, True)
    # act

# Generated at 2022-06-21 03:55:17.199719
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():
    m = CallbackModule()
    # simple smoke test
    t = dict(task=True, uuid='uuid')
    m.v2_runner_on_no_hosts(t)




# Generated at 2022-06-21 03:55:29.294393
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cb = CallbackModule()
    assert(isinstance(cb, CallbackModule))
    assert(cb._output_dir == os.path.expanduser('~/.ansible.log'))
    assert(cb._task_class == 'false')
    assert(cb._task_relative_path == '')
    assert(cb._include_setup_tasks_in_report == 'true')
    assert(cb._fail_on_change == 'false')
    assert(cb._fail_on_ignore == 'false')
    assert(cb._hide_task_arguments == 'false')
    assert(cb._test_case_prefix == '')
    assert(cb._playbook_path is None)
    assert(cb._playbook_name is None)
    assert(cb._play_name is None)

# Generated at 2022-06-21 03:55:40.513823
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    callbackModule = CallbackModule()
    assert callbackModule._task_class == 'false'
    assert callbackModule._task_relative_path == ''
    assert callbackModule._fail_on_change == 'false'
    assert callbackModule._fail_on_ignore == 'false'
    assert callbackModule._include_setup_tasks_in_report == 'true'
    assert callbackModule._hide_task_arguments == 'false'
    assert callbackModule._test_case_prefix == ''
    assert callbackModule._playbook_path is None
    assert callbackModule._playbook_name is None
    assert callbackModule._play_name is None
    assert callbackModule._task_data is None

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-21 03:55:42.132593
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = {}
    callback = CallbackModule()
    callback._generate_report()

# Generated at 2022-06-21 03:55:50.455798
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.callback import CallbackBase
    from ansible.utils._junit_xml import (
        TestCase,
        TestError,
        TestFailure,
        TestSuite,
        TestSuites,
    )
    from ansible.utils.display import Display
    import os
    import time
    import re

    obj = CallbackModule()

    playbook = Playbook()
    playbook._file_name = os.path.dirname(__file__) + '/file.yml'
    obj.v2_playbook_on_play_start(playbook)

    # Test if the attribute self._playbook_name is set properly
    assert obj._playbook_name == 'file'
    assert obj._play_name == None


# Generated at 2022-06-21 03:55:59.428611
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins import callback_loader
    from ansible.utils.plugin_docs import docstring_parser

    print(docstring_parser.get_docstring(CallbackModule, verbose=False, style='sphinx', group_by_type=False))

    callback = callback_loader.get('junit')
    callback.disabled = False

    stats = {'tasks': {'{some-task}': {'skipped': True, 'skipped_reason': 'skipped'}}}
    callback.v2_playbook_on_stats(stats)

    assert False # TODO: implement your test here


# Generated at 2022-06-21 03:56:11.350649
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-21 03:56:24.009996
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_no_hosts({})
    callback_module.v2_playbook_on_task_start({}, True)
    callback_module.v2_playbook_on_cleanup_task_start({})
    callback_module.v2_playbook_on_handler_task_start({})
    callback_module.v2_runner_on_failed({}, False)
    callback_module.v2_runner_on_ok({})
    callback_module.v2_runner_on_skipped({})
    callback_module.v2_playbook_on_include({})
    callback_module.v2_playbook_on_stats({})



# Generated at 2022-06-21 03:56:26.355424
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    cb = CallbackModule()
    play = create_play()
    cb.v2_playbook_on_play_start(play)
    assert cb._play_name == play.get_name()
    

# Generated at 2022-06-21 03:56:42.888598
# Unit test for constructor of class CallbackModule

# Generated at 2022-06-21 03:56:48.887151
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    import ansible.plugins.callback as callback
    testobj = None
    if callback.callback_loader.is_available('junit', C.DEFAULT_CALLBACK_WHITELIST):
        testobj = callback.callback_loader._load_one_plugin('junit')
    assert(testobj is not None)

    testobj.v2_playbook_on_cleanup_task_start('foo')


# Generated at 2022-06-21 03:56:55.936624
# Unit test for constructor of class TaskData
def test_TaskData():
    data = TaskData(
        uuid = "1234",
        name = "Test",
        path = "path/to/my/file",
        play = "play",
        action = "action"
    )

    assert data.uuid == "1234", "uuid was not correctly initialized"
    assert data.name == "Test", "name was not correctly initialized"
    assert data.path == "path/to/my/file", "path was not correctly initialized"
    assert data.play == "play", "play was not correctly initialized"
    assert data.action == "action", "action was not correctly initialized"
    assert len(data.host_data) == 0, "host_data was not correctly initialized"
    assert data.start != None, "start was not correctly initialized"


# Generated at 2022-06-21 03:57:01.840168
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # create an instance of the Ansible callback module
    callback = CallbackModule()
    # create a result object
    result = "some result"
    # create a ignore_errors variable
    ignore_errors = False
    # call the callback method
    callback.v2_runner_on_failed(result, ignore_errors)
    # verify results



# Generated at 2022-06-21 03:57:10.628876
# Unit test for constructor of class TaskData
def test_TaskData():
    expected_uuid = '0123456789'
    expected_name = 'This is the task name'
    expected_path = 'path/to/playbook.yml'
    expected_play = 'play_name'
    expected_action = 'action_name'
    expected_start = 1234.56

    dut = TaskData(expected_uuid, expected_name, expected_path, expected_play, expected_action)

    assert(dut.uuid == expected_uuid)
    assert(dut.name == expected_name)
    assert(dut.path == expected_path)
    assert(dut.play == expected_play)
    assert(dut.start == None)
    assert(dut.host_data == {})


# Generated at 2022-06-21 03:57:13.547300
# Unit test for constructor of class HostData
def test_HostData():
    host1 = HostData(1, 2, 3, 4)
    assert(host1.uuid == 1)
    assert(host1.name == 2)
    assert(host1.status == 3)
    assert(host1.result == 4)

# Generated at 2022-06-21 03:57:18.488118
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Setup


    # Exercise
    output_dir = os.getenv('JUNIT_OUTPUT_DIR', os.path.expanduser('~/.ansible.log'))
    task_class = os.getenv('JUNIT_TASK_CLASS', 'False').lower()
    task_relative_path = os.getenv('JUNIT_TASK_RELATIVE_PATH', '')
    fail_on_change = os.getenv('JUNIT_FAIL_ON_CHANGE', 'False').lower()
    fail_on_ignore = os.getenv('JUNIT_FAIL_ON_IGNORE', 'False').lower()

# Generated at 2022-06-21 03:57:24.923338
# Unit test for constructor of class HostData
def test_HostData():
    from ansible.playbook.task import Task
    from ansible.hosts.host import Host
    from ansible.vars.manager import VariableManager

    host = Host(name="hostname")
    host._variable_manager = VariableManager()
    host._variable_manager.set_host_variable(host, "foo", "bar")

    task = Task()
    task._role = None
    task._parent = None

    result = dict(foo="bar", rc=0)

    host_data = HostData(uuid=123, name='my_host', status='ok', result=result)
    assert host_data.uuid == 123
    assert host_data.name == 'my_host'
    assert host_data.status == 'ok'

# Generated at 2022-06-21 03:57:26.584515
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback = CallbackModule()
    mock_result = None
    callback.v2_runner_on_skipped(mock_result)

# Generated at 2022-06-21 03:57:29.351474
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    playbook = mock.Mock()
    play = mock.Mock()
    task = mock.Mock()
    is_conditional = mock.Mock()
    is_conditional.return_value = True

    C = CallbackModule()
    C._start_task(task)
    assert type(C._task_data) == {}


# Generated at 2022-06-21 03:57:59.468558
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    from ansible import constants as C
    C.HOST_KEY_CHECKING = False
    
    b = CallbackModule()
    b.v2_playbook_on_play_start(play = {})
    assert b._play_name == None
    
    # Test play with name
    b.v2_playbook_on_play_start(play = {'name': 'play'})
    assert b._play_name == 'play'

# Generated at 2022-06-21 03:58:02.161850
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    X=CallbackModule()
    stats = None
    X.v2_playbook_on_stats(stats)

# Generated at 2022-06-21 03:58:03.637886
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    CallbackModule().v2_playbook_on_task_start()



# Generated at 2022-06-21 03:58:10.057099
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    name = 'test_task'
    task = mock_task(name)
    task._uuid = 'test'
    task.action = 'test_action'
    plugin = CallbackModule()
    plugin.v2_playbook_on_task_start(task, False)
    assert plugin._task_data[task._uuid].name == name
    assert plugin._task_data[task._uuid].action == 'test_action'


# Generated at 2022-06-21 03:58:15.835053
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    # Setup test data
    task = object()
    callback = CallbackModule()

    # Invoke method
    callback.v2_playbook_on_handler_task_start(task)

    # Check instance variables
    assert callback._task_data == {}, 'Expected:"{}", but was:"{}"'.format({}, callback._task_data)


# Generated at 2022-06-21 03:58:22.514918
# Unit test for constructor of class HostData
def test_HostData():
    host_data = HostData('uuid1', 'name1', 'status1', 'result1')
    assert(host_data.uuid == 'uuid1')
    assert(host_data.name == 'name1')
    assert(host_data.status == 'status1')
    assert(host_data.result == 'result1')



# Generated at 2022-06-21 03:58:25.940251
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():

    cb = CallbackModule()

    # Test default behaviour
    cb.v2_playbook_on_task_start(task=None, is_conditional=False)

    # Test default behaviour
    cb.v2_playbook_on_task_start(task=None, is_conditional=False)

# Generated at 2022-06-21 03:58:28.753682
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    playbook = {}
    task = {}
    obj = CallbackModule()
    ret = obj.v2_playbook_on_cleanup_task_start(task)
    assert ret is None


# Generated at 2022-06-21 03:58:39.987008
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    import os.path

    data_dir = os.path.dirname(__file__)
    playbook_path = os.path.join(data_dir, 'test_playbook.yml')

    play = {
        'name': 'Test Play',
        'file_name': playbook_path,
        'tasks': [{
            'name': 'Test Task',
            'action': 'shell',
            'args': {
                'command': 'exit 0'
            }
        }]
    }

    callback = CallbackModule()
    callback._playbook_name = 'test-playbook'
    callback.v2_playbook_on_play_start(play)

    task = play['tasks'][0]

# Generated at 2022-06-21 03:58:49.995490
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import tempfile
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.task_result import TaskResult

    class TestCallbackModule(CallbackBase):
        def __init__(self, display=None):
            if display is None:
                self._display = Display()
            else:
                self._display = display

    task_result = TaskResult()
    display = Display()

    test_callbackmodule = TestCallbackModule(display)
    test_callbackmodule.v2_runner_on_skipped(task_result)
    assert display.display.call_count == 1


# Generated at 2022-06-21 03:59:14.609397
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule().__class__ is CallbackModule


# Generated at 2022-06-21 03:59:16.682429
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    print("v2_playbook_on_handler_task_start:")
    # Instantiation of a class object
    ansible = CallbackModule()

# Generated at 2022-06-21 03:59:24.785180
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    junit = CallbackModule()

    junit._playbook_name = 'Test Playbook'
    junit._play_name = 'Test Play'

    # Invalid input
    junit._task_class = 'True'
    junit._include_setup_tasks_in_report = 'True'
    junit._fail_on_change = 'True'
    junit._fail_on_ignore = 'True'
    junit._hide_task_arguments = 'True'
    junit._test_case_prefix = 'Test Case: '

    # Valid input
    junit._task_class = 'true'
    junit._include_setup_tasks_in_report = 'false'
    junit._fail_on_change = 'true'
    junit._fail_on_ignore = 'true'
    junit

# Generated at 2022-06-21 03:59:25.498353
# Unit test for constructor of class HostData
def test_HostData():
    pass



# Generated at 2022-06-21 03:59:32.790409
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Set up test objects
    class dummy_play():
        def __init__(self):
            self.__name = 'dummy'

        def get_name(self):
            return self.__name

    class dummy_playbook():
        def __init__(self):
            self._file_name = 'dummy'

    class dummy_stats():
        def __init__(self):
            self.__dummy = None

    class dummy_result():
        def __init__(self, task, host):
            self._task = task
            self._host = host
            self._result = {'changed': False}

    class dummy_task():
        def __init__(self, action, path, name, _uuid, no_log):
            self.action = action
            self.get_path = lambda: path
           

# Generated at 2022-06-21 03:59:38.984053
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    taskdata = TaskData("uuid", "name", "path", "play", "action")

    # Test case with status as included
    host = HostData("uuid", "name", "included", "result")
    taskdata.add_host(host)

    assert taskdata.host_data[host.uuid] == host

    # Test case with status as failed
    host_new = HostData("uuid", "name_new", "failed", "result_new")
    try:
        taskdata.add_host(host_new)
    except Exception as e:
        assert(str(e) == 'path: play: name: duplicate host callback: name_new')


# Generated at 2022-06-21 03:59:48.389969
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
  # set up task data
  task_data = TaskData('xxx', 'a task', 'a/path', 'a play', 'action')
  # set up host data
  host_data = HostData('xxx', 'a host', 'ok', result='a result')
  # set up test object
  cb = CallbackModule()
  setattr(cb, '_task_data', {'xxx': task_data})
  # run test
  cb.v2_runner_on_ok('a result')
  # check
  assert task_data.host_data == {'xxx': host_data}

# Generated at 2022-06-21 03:59:50.351017
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)


# Generated at 2022-06-21 03:59:51.804205
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert CallbackModule()



# Generated at 2022-06-21 03:59:55.371933
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    test = CallbackModule()
    test.v2_playbook_on_play_start(play={"name":"test"})
    assert(test._play_name == "test")



# Generated at 2022-06-21 04:00:25.800432
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    # initialize
    obj = CallbackModule()
    task = MagicMock()
    is_conditional = False

    # invoke
    obj.v2_playbook_on_task_start(task, is_conditional)

    # assert



# Generated at 2022-06-21 04:00:37.799918
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    class Result:
        def __init__(self):
            self.exception = None
            self.msg = 'Test Msg'
            self.skip_reason = None
            self.rc = 0
    result = Result()
    self = CallbackModule()
    self._init_data()
    self.v2_playbook_on_task_start = Mock(return_value = None)
    self.v2_runner_on_failed = Mock(return_value = None)
    self.v2_runner_on_ok = Mock(return_value = None)
    self.v2_runner_on_skipped = Mock(return_value = None)
    self.v2_playbook_on_include = Mock(return_value = None)

# Generated at 2022-06-21 04:00:46.874928
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callbackModule = CallbackModule()
    class task:
        def get_name():
            return "test"
        def get_path():
            return "test"
        def no_log():
            return False
    class task_result:
        def _task():
            return task()
        def _host():
            return "test"
        def _result():
            return {'changed': False}
    callbackModule.v2_runner_on_ok(task_result())



# Generated at 2022-06-21 04:00:53.599685
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_plugin = CallbackModule()
    callback_plugin.disabled = True
    callback_plugin._playbook_path = 'test_playbook_path'
    callback_plugin._playbook_name = 'test_playbook_name'
    callback_plugin._play_name = 'test_play_name'
    class DummyTask(object):
        _uuid = 'dummy_task_uuid'
        def get_name(self):
            return 'dummy_task_name'
        def get_path(self):
            return 'dummy_task_path'
    dummy_task = DummyTask()
    class DummyResult(object):
        _task = dummy_task
        _host = 'dummy_host'
        _result = 'dummy_result'
    dummy_result = DummyResult()
    callback

# Generated at 2022-06-21 04:00:54.626098
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass

# Generated at 2022-06-21 04:00:56.065246
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test for failure and pass status
    assert True == True


# Generated at 2022-06-21 04:00:58.882834
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_cleanup_task_start("task")
    assert callback_module._task_data.__len__() == 1


# Generated at 2022-06-21 04:01:01.056697
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    callback_module = CallbackModule()
    type(mock.MagicMock())
    callback_module.v2_runner_on_skipped(result)


# Generated at 2022-06-21 04:01:09.335406
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    class task_class:
        def get_name():
            return 'test'
        def get_path():
            return 'test'
        def action():
            return 'test'
        def no_log():
            return False
        def args():
            return False
    task_obj = task_class
    is_conditional = False
    result = CallbackModule()
    result.v2_playbook_on_task_start(task_obj, is_conditional)
    

# Generated at 2022-06-21 04:01:15.335722
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    tdata = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    assert tdata.add_host(host) == None
    assert tdata.path == 'path'
    assert tdata.name == 'name'
    assert tdata.add_host(host) == None


# Generated at 2022-06-21 04:02:11.232992
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    CallbackModule_v2_playbook_on_include()


# Generated at 2022-06-21 04:02:13.053745
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    """ Test v2_runner_on_skipped of CallbackModule """

    callback_module = CallbackModule()

    callback_module._finish_task('skipped', 'result')

# Generated at 2022-06-21 04:02:15.959922
# Unit test for constructor of class HostData
def test_HostData():
    h = HostData('host_uuid', 'host_name', 'status', 'result')
    assert h.uuid == 'host_uuid'
    assert h.name == 'host_name'
    assert h.status == 'status'
    assert h.result == 'result'


# Generated at 2022-06-21 04:02:20.423794
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    error_message = "Test of method v2_playbook_on_include failed."

    callback = CallbackModule()
    callback.v2_playbook_on_include('some_included_file')

    ok_(True, error_message)

# Generated at 2022-06-21 04:02:23.161674
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    # call method v2_playbook_on_handler_task_start of class CallbackModule
    CallbackModule().v2_playbook_on_handler_task_start(self, task)

# Generated at 2022-06-21 04:02:23.691953
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass

# Generated at 2022-06-21 04:02:30.189356
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Setup test data
    included_file = ['included']

    # Setup test environment
    cb = CallbackModule()
    cb._finish_task = MagicMock()

    # Run test scenario
    cb.v2_playbook_on_include(included_file)

    # Check test results
    cb._finish_task.assert_called_once_with('included', included_file)


# Unit test class for CallbackModule

# Generated at 2022-06-21 04:02:32.611364
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    mod = CallbackModule()
    mod.v2_runner_on_failed()

# Generated at 2022-06-21 04:02:38.671042
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    global CallbackModule
    result = CallbackModule()
    task_arg1 = {"_file_name": "/Users/abc/Downloads/ansible/ansible-2.9.6/test/integration/targets/async_wrapper.yml"}
    result.v2_playbook_on_start(task_arg1)
    assert result._playbook_name == "async_wrapper"

# Generated at 2022-06-21 04:02:39.280165
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    pass

# Generated at 2022-06-21 04:04:40.517658
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():

  # Setup
  callback = CallbackModule()

  # exec
  result = callback.v2_runner_on_no_hosts(task)

  # assert
  assert result == None

# Generated at 2022-06-21 04:04:47.590682
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
	# Arrange
	expected_return = 'something'
	cb = CallbackModule()
	cb._generate_report = MagicMock(return_value=expected_return)
	result = 'something'

	# Act
	cb.v2_runner_on_ok(result)

	# Assert
	cb._generate_report.assert_called_with()
	assert cb.v2_runner_on_ok(result) == expected_return

