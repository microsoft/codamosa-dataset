

# Generated at 2022-06-21 03:55:19.225140
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    # CallbackModule.v2_playbook_on_start
    # This test case will cover following logics.
    # 1. playbook._file_name and os.path.splitext(os.path.basename(playbook._file_name))[0]

    # Arrange
    import os
    import time
    import re

    from ansible import constants as C
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.callback import CallbackBase
    from ansible.utils._junit_xml import (
        TestCase,
        TestError,
        TestFailure,
        TestSuite,
        TestSuites,
    )
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types


# Generated at 2022-06-21 03:55:20.310672
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    pass

# Generated at 2022-06-21 03:55:27.233584
# Unit test for constructor of class TaskData
def test_TaskData():
    uuid = 'TaskData.uuid.1'
    name = 'TaskData.name.1'
    path = 'TaskData.path.1'
    play = 'TaskData.play.1'
    action = 'TaskData.action.1'
    td = TaskData(uuid, name, path, play, action)
    assert td.uuid == 'TaskData.uuid.1'
    assert td.name == 'TaskData.name.1'
    assert td.path == 'TaskData.path.1'
    assert td.play == 'TaskData.play.1'
    assert td.start == None
    assert td.host_data == {}
    assert td.start != None
    assert td.action == 'TaskData.action.1'


# Generated at 2022-06-21 03:55:36.717644
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    data = TaskData("a", "b", "c", "d", "e")
    data2 = HostData("a", "c", "d", "f")
    data2.result = "included"
    data.add_host(data2)
    assert data.host_data["a"] == data2
    data3 = HostData("a", "c", "d", "f")
    data3.result = "included"
    try:
        data.add_host(data3)
    except Exception as e:
        assert str(e) == "c: d: b: duplicate host callback: c"
    else:
        raise Exception("Duplicate key did not raise exception")



# Generated at 2022-06-21 03:55:47.556692
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():
    v2_runner_on_no_hosts_input = {}
    c = CallbackModule()
    c.v2_runner_on_no_hosts(v2_runner_on_no_hosts_input)
    assert c._task_data == {'f6aebb6e-d53d-425c-9e6a-b6f07d26d8b3': TaskData('f6aebb6e-d53d-425c-9e6a-b6f07d26d8b3', 'missing host', None, None, None)}
    assert c._playbook_path is None
    assert c._playbook_name is None
    assert c._play_name is None
    assert c.disabled is False
    assert c._task_class == 'false'
    assert c._task_

# Generated at 2022-06-21 03:55:48.640773
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    # Arrange
    pass



# Generated at 2022-06-21 03:56:00.743953
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    c = CallbackModule()
    c.v2_playbook_on_start(playbook='./playbook.yml')
    c.v2_playbook_on_play_start(play='myplay')
    task = Task()
    task.action = 'shell'
    c.v2_playbook_on_cleanup_task_start(task=task)
    assert c._task_data == {'e1b7d21c-c91d-4d8a-a097-2cd9f3a4d1e4': TaskData('e1b7d21c-c91d-4d8a-a097-2cd9f3a4d1e4', 'shell', 'cleanup.yaml', 'myplay', 'shell')}


# Generated at 2022-06-21 03:56:02.637527
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    cfg = {
        'outdir': None,
    }
    obj = CallbackModule()


# Generated at 2022-06-21 03:56:06.330174
# Unit test for constructor of class TaskData
def test_TaskData():
    task_data = TaskData('UUID', 'NAME', 'PATH', 'PLAY', 'ACTION')
    assert isinstance(task_data, TaskData)


# Generated at 2022-06-21 03:56:10.889776
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Initialize
    stats = object()
    self = object()

    # Call the method
    CallbackModule.v2_playbook_on_stats(self, stats)

    # Setup mocks
    assert self._generate_report.call_count == 1
 

# Generated at 2022-06-21 03:56:25.442532
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Variables initialization
    test_object = CallbackModule()
    result = None
    # This method is not implemented yet


# Generated at 2022-06-21 03:56:27.075167
# Unit test for method v2_playbook_on_task_start of class CallbackModule

# Generated at 2022-06-21 03:56:28.385975
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    assert True == True

# Generated at 2022-06-21 03:56:33.476969
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    playbook_on_handler_task_start_result = "ok"
    obj = CallbackModule()
    assert obj.v2_playbook_on_handler_task_start(task) == playbook_on_handler_task_start_result


# Generated at 2022-06-21 03:56:36.939280
# Unit test for constructor of class HostData
def test_HostData():
    name = 'test_host'
    status = 'ok'
    result = 'test'
    obj_test = HostData('001', name, status, result)
    assert obj_test.name == name
    assert obj_test.status == status
    assert obj_test.result == result
    assert obj_test.finish > 0


# Generated at 2022-06-21 03:56:48.660590
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.playbook import Playbook
    from ansible.plugins.loader import callback_loader
    plugin = callback_loader.get('JUnit', 'callback')
    created_plugin = plugin()

    playbook = Playbook()
    created_plugin.v2_playbook_on_start(playbook)
    created_plugin.v2_playbook_on_play_start("something")

    from ansible.playbook.task import Task
    task = Task("something")
    created_plugin._start_task(task)

    from ansible.executor.task_result import TaskResult

    class Result(object):
        def __init__(self):
            self._task = task
            self._result = "something"

    task_result = TaskResult()
    task_result.__dict__ = Result().__dict__
    created

# Generated at 2022-06-21 03:57:00.688151
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    from ansible.plugins.callback import CallbackBase
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    host_list = []

    dataloader = DataLoader()
    inventory = InventoryManager(loader=dataloader)
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)


# Generated at 2022-06-21 03:57:05.642280
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    td = TaskData('abc', 'xyz', 'foo', 'bar', 'ansible')
    hd = HostData('def', 'ghk', 'ok', 1)
    td.add_host(hd)
    ret = td.host_data['def']
    assert ret == hd


# Generated at 2022-06-21 03:57:10.366582
# Unit test for constructor of class HostData
def test_HostData():
    host_data = HostData('uuid', 'name', 'status', 'result')
    assert host_data.uuid == 'uuid'
    assert host_data.name == 'name'
    assert host_data.status == 'status'
    assert host_data.result == 'result'


# Generated at 2022-06-21 03:57:14.298619
# Unit test for method v2_runner_on_no_hosts of class CallbackModule
def test_CallbackModule_v2_runner_on_no_hosts():
    # setup test
    task = mock.MagicMock()
    self = CallbackModule()
    # perform the test
    self.v2_runner_on_no_hosts(task)

# Generated at 2022-06-21 03:57:44.019672
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # init
    playbook = {"_file_name": "/Users/i054444/Documents/workspace/playbook.yml"}
    callbackModule = CallbackModule()
    callbackModule._playbook_path = None
    callbackModule._playbook_name = None
    # run the code
    callbackModule.v2_playbook_on_start(playbook)
    # assert the result
    assert callbackModule._playbook_path == "/Users/i054444/Documents/workspace/playbook.yml"
    assert callbackModule._playbook_name == "playbook"

# Generated at 2022-06-21 03:57:56.861200
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
        task = TaskData('uuid','name','path','play','action')
        host_ok = HostData('uuid','name','ok','/result')
        host_included = HostData('uuid','name','included','/result')
        try:
            task.add_host(host_included)
            task.add_host(host_ok)
            assert 1 == 2, "Exception non levée"
        except Exception as e:
            assert "duplicate host callback" in str(e), "Pas le bon message d'erreur"
        try:
            task.add_host(host_ok)
            assert 1 == 2, "Exception non levée"
        except Exception as e:
            assert "duplicate host callback" in str(e), "Pas le bon message d'erreur"
        task

# Generated at 2022-06-21 03:58:09.783413
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    # Parameters
    task = mock.MagicMock()
    is_conditional = mock.MagicMock()
    # Configuration
    config = {
		"JUNIT_OUTPUT_DIR": "/tmp",
		"JUNIT_TASK_CLASS": "False",
		"JUNIT_TASK_RELATIVE_PATH": "",
		"JUNIT_FAIL_ON_CHANGE": "False",
		"JUNIT_FAIL_ON_IGNORE": "False",
		"JUNIT_INCLUDE_SETUP_TASKS_IN_REPORT": "True",
		"JUNIT_HIDE_TASK_ARGUMENTS": "False",
		"JUNIT_TEST_CASE_PREFIX": ""
	}

# Generated at 2022-06-21 03:58:22.423572
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create a test class
    class TestClass:
        def setUp(self):
            self.callback_module = CallbackModule()
            
        def test_v2_playbook_on_start(self):
            # Create a Mock object to mimic the PlayBook object
            class PlayBookInstance:
                def __init__(self):
                    self._file_name = '/home/devuser/Desktop/Ansible/testing_ansible_with_unittesting/test_playbook.yml'          

            # Create a instance of playbook and pass it to the v2_playbook_on_start
            mock_pb_instance = PlayBookInstance()
            self.callback_module.v2_playbook_on_start(mock_pb_instance)

    # Create an instance of the testclass
    test_instance = TestClass()



# Generated at 2022-06-21 03:58:29.916392
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
     td = TaskData('123', '456', '789', '012', '345')
     td.add_host(HostData('123', '456', '789', '012'))
     assert td.host_data == {'123':HostData('123', '456', '789', '012')}
     td.add_host(HostData('4567', '45678', '456789', '4567890'))
     assert td.host_data == {'123':HostData('123', '456', '789', '012'), '4567':HostData('4567', '45678', '456789', '4567890')}


# Generated at 2022-06-21 03:58:37.040527
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = mock.Mock()
    playbook._file_name = '/tmp/ansible.log'
    callback_module = CallbackModule()

    # Act
    callback_module.v2_playbook_on_start(playbook)

    # Assert
    assert callback_module._playbook_path == '/tmp/ansible.log'
    assert callback_module._playbook_name == 'ansible'



# Generated at 2022-06-21 03:58:48.563162
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # fixture:
    class Test(object):
        @classmethod
        def v2_runner_on_failed(self, result, ignore_errors=False):
            assert result._task._uuid == "4e4ce06d-7457-4c3f-84e1-cba181c3bcd3"
            assert ignore_errors == False
            assert callback.disabled == False
            assert callback._output_dir == "/home/vagrant/.ansible.log"
            assert callback._task_class == "false"
            assert callback._task_relative_path == ""
            assert callback._playbook_path == "/tmp/cb_playbook-1511497109.28/cb_playbook.yml"
            assert callback._play_name == "cb_play"

# Generated at 2022-06-21 03:58:52.946036
# Unit test for constructor of class HostData
def test_HostData():
    hd = HostData(uuid='host_0', name='host', status='host_status', result='host_result')
    assert hd.uuid == 'host_0'
    assert hd.name == 'host'
    assert hd.status == 'host_status'
    assert hd.result == 'host_result'

# Generated at 2022-06-21 03:58:55.675932
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = 1
    callback = CallbackModule()
    callback.v2_runner_on_ok(result)
    assert callback.v2_runner_on_ok.__doc__ == "record the results of a task for a single host "

# Generated at 2022-06-21 03:59:07.192668
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():

    # Create a mock object of class AnsibleTask
    class AnsibleTask(object):
        def __init__(self):
            self._uuid = 'sdjadadwd2134'

    # Create a mock object of class AnsibleHost
    class AnsibleHost(object):
        def __init__(self):
            self._uuid = 'sdjadadwd2134'
            self.name = 'my_host'

    # Create a mock object of class AnsibleResult
    class AnsibleResult(object):
        def __init__(self):
            self._task = AnsibleTask()
            self._host = AnsibleHost()
            self._result = {"changed": False, "msg": ''}

    # Create a mock object of class AnsiblePlaybook

# Generated at 2022-06-21 04:00:04.208102
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    class Playbook:
        def __init__(self, _file_name):
            self._file_name = _file_name
        def get_filename(self):
            return self._file_name
    objCallbackModule = CallbackModule()
    objCallbackModule._playbook_name = None
    test_playbook = Playbook('test_playbook.yml')
    objCallbackModule.v2_playbook_on_start(test_playbook)
    assert objCallbackModule._playbook_name == 'test_playbook'


# Generated at 2022-06-21 04:00:11.806677
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    uuid = 'c4d91b4e-dc8c-4ba1-9c58-d9b9b8e42e6f'
    name = 'Test task name'
    path = '/path/to/file.yml'
    play = 'Test play'
    action = 'Test action'
    task_data = TaskData(uuid, name, path, play, action)
    uuid1 = 'f099f7d8-c8b2-4fe0-9d34-d8c4494b02a1'
    name1 = 'first host'
    host1 = HostData(uuid1, name1, 'failed', 1)

# Generated at 2022-06-21 04:00:22.144037
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    instance = CallbackModule()
    assert isinstance(instance, CallbackModule)
    assert instance._output_dir == os.path.expanduser('~/.ansible.log')
    assert instance._task_class == 'false'
    assert instance._task_relative_path == ''
    assert instance._fail_on_change == 'false'
    assert instance._fail_on_ignore == 'false'
    assert instance._include_setup_tasks_in_report == 'true'
    assert instance._hide_task_arguments == 'false'
    assert instance._test_case_prefix == ''
    assert instance._playbook_path is None
    assert instance._playbook_name is None
    assert instance._play_name is None

    assert isinstance(instance._task_data, dict)


# Generated at 2022-06-21 04:00:27.253201
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # create an object for class 'CallbackModule'
    stats = {}
    obj = CallbackModule()
    # test method 'v2_playbook_on_stats' of class 'CallbackModule'
    obj.v2_playbook_on_stats(stats)
    assert True



# Generated at 2022-06-21 04:00:38.677395
# Unit test for constructor of class HostData
def test_HostData():
    uuid1 = 'UUID1'
    name1 = 'name1'
    status1 = 'status1'
    result1 = 'result1'
    test1 = HostData(uuid1, name1, status1, result1)

    assert (uuid1 == test1.uuid)
    assert (name1 == test1.name)
    assert (status1 == test1.status)
    assert (result1 == test1.result)

    uuid2 = 'UUID2'
    name2 = 'name2'
    status2 = 'status2'
    result2 = 'result2'
    test2 = HostData(uuid2, name2, status2, result2)

    assert (uuid2 == test2.uuid)
    assert (name2 == test2.name)

# Generated at 2022-06-21 04:00:46.873358
# Unit test for constructor of class TaskData
def test_TaskData():
    t = TaskData('uuid1', 'name1', 'path1', 'play1', 'action1')
    assert(t.uuid == 'uuid1')
    assert(t.name == 'name1')
    assert(t.path == 'path1')
    assert(t.play == 'play1')
    assert(t.start == t.start)
    assert(t.host_data == {})
    assert(t.action == 'action1')



# Generated at 2022-06-21 04:00:58.089072
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    open('playbookfile.yml', 'a').close()
    stats = {
        'skipped': ['skipped'],
        'skipped_tasks': [],
        'changed': 4,
        'failed': 0,
        'ok': 4,
        'processed': 8,
        'dark': [],
        'failures': [],
        'ignored': 0,
        'time': {
            'local': '2019-05-08T22:37:56.099121',
            'start': '2019-05-08T22:37:55.727050',
            'delta': '0:00:00.372071',
            'end': '2019-05-08T22:37:56.099121'
        }
    }
    

# Generated at 2022-06-21 04:00:59.694831
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Instantiate the CallbackModule class.
    obj = CallbackModule()
    # TODO: Add the code, to set the parameter values
    # Call method
    obj.v2_playbook_on_include()


# Generated at 2022-06-21 04:01:01.454177
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test for constructor
    test_instance = CallbackModule()
    assert isinstance(test_instance, CallbackModule) == True
    assert isinstance(test_instance, CallbackBase) == True


# Generated at 2022-06-21 04:01:06.269187
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # arrange
    test_object = CallbackModule()
    stats = Stats()

    # act
    test_object._generate_report()
    test_object.v2_playbook_on_stats(stats)

    # assert
    assert isinstance(test_object, CallbackModule)



# Generated at 2022-06-21 04:03:15.359212
# Unit test for constructor of class HostData
def test_HostData():
    # Unit test to check the constructor of HostData class
    host_data = HostData("uuid", "name", "status", "result")
    assert host_data.uuid == "uuid"
    assert host_data.name == "name"
    assert host_data.status == "status"
    assert host_data.result == "result"


# Generated at 2022-06-21 04:03:17.312225
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    c = CallbackModule()
    c.v2_playbook_on_play_start("")
    assert c._play_name == ""


# Generated at 2022-06-21 04:03:20.431268
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    callback = CallbackModule()
    task = "task1"
    is_conditional = False
    callback.v2_playbook_on_cleanup_task_start(task=task)
    assert(callback._task_data["task1"].name == "task1")


# Generated at 2022-06-21 04:03:26.877710
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    tmp = TaskData('', '', '', '', '')
    assert not tmp.host_data
    # First host is added
    host = HostData('', '', '', '')
    tmp.add_host(host)
    assert tmp.host_data['include']
    # Second host is added - exception is raised
    host = HostData('', '', '', '')
    try:
        tmp.add_host(host)
    except Exception as exc:
        if not str(exc) == ': : : duplicate host callback: include':
            raise Exception('Exception with different message was raised')



# Generated at 2022-06-21 04:03:28.918280
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    # CallbackModule.v2_playbook_on_handler_task_start(task)
    return True

# Generated at 2022-06-21 04:03:29.789168
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    assert False



# Generated at 2022-06-21 04:03:31.574810
# Unit test for constructor of class HostData
def test_HostData():
    test_hostdata = HostData("uuid","name","status","result")
    assert (test_hostdata.status == "status")

# Generated at 2022-06-21 04:03:36.675781
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    task = AnsibleFakeTask()
    callback = CallbackModule()
    callback._task_data = {}
    callback.v2_playbook_on_cleanup_task_start(task)
    assert callback._task_data[task._uuid].action == AnsibleFakeTask.ACTION_CLEANUP

# Generated at 2022-06-21 04:03:42.744065
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    
    task_data.add_host(host_data)

    assert task_data.host_data == {'uuid': host_data}



# Generated at 2022-06-21 04:03:45.999638
# Unit test for constructor of class TaskData
def test_TaskData():
    uuid = '1'
    name = 'test'
    path = '1/1/1'
    play = 'test play'
    action = 'test action'

    task_data = TaskData(uuid, name, path, play, action)

    assert task_data is not None

