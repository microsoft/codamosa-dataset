

# Generated at 2022-06-17 10:38:58.575880
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data == {'uuid': host_data}


# Generated at 2022-06-17 10:39:04.060623
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:39:08.192598
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with no playbook
    callback = CallbackModule()
    callback.v2_playbook_on_start(None)
    assert callback._playbook_path == None
    assert callback._playbook_name == None
    # Test with a playbook
    callback = CallbackModule()
    callback.v2_playbook_on_start(Playbook())
    assert callback._playbook_path == 'playbook.yml'
    assert callback._playbook_name == 'playbook'


# Generated at 2022-06-17 10:39:12.672580
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].uuid == 'uuid'
    assert task_data.host_data['uuid'].finish == None


# Generated at 2022-06-17 10:39:18.550290
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MockPlaybook()
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == playbook._file_name
    assert callback._playbook_name == os.path.splitext(os.path.basename(playbook._file_name))[0]


# Generated at 2022-06-17 10:39:28.866571
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a new instance of CallbackModule
    cb = CallbackModule()

    # Create a new instance of Result
    result = Result()

    # Create a new instance of Host
    host = Host()

    # Create a new instance of Task
    task = Task()

    # Set the task uuid
    task._uuid = "12345"

    # Set the task name
    task.name = "Test task"

    # Set the task action
    task.action = "test"

    # Set the task path
    task.path = "test.yml"

    # Set the task no_log
    task.no_log = False

    # Set the task args
    task.args = {"arg1": "value1", "arg2": "value2"}

    # Set the result task
    result._task = task

    #

# Generated at 2022-06-17 10:39:34.407921
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:39:44.895599
# Unit test for method v2_playbook_on_start of class CallbackModule

# Generated at 2022-06-17 10:39:48.507822
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:39:55.740618
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:40:10.429287
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'


# Generated at 2022-06-17 10:40:17.849810
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['host_uuid'] == host


# Generated at 2022-06-17 10:40:20.722107
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with no argument
    cb = CallbackModule()
    cb.v2_runner_on_failed()
    assert True


# Generated at 2022-06-17 10:40:27.225138
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:40:34.998148
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'


# Generated at 2022-06-17 10:40:37.691813
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:40:40.298538
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:40:50.125438
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    mock_CallbackModule = CallbackModule()
    # Create a mock object of class Result
    mock_result = Result()
    # Create a mock object of class Task
    mock_task = Task()
    # Create a mock object of class Host
    mock_host = Host()
    # Create a mock object of class TaskData
    mock_task_data = TaskData()
    # Create a mock object of class HostData
    mock_host_data = HostData()
    # Create a mock object of class TestCase
    mock_test_case = TestCase()
    # Create a mock object of class TestSuite
    mock_test_suite = TestSuite()
    # Create a mock object of class TestSuites
    mock_test_suites = TestSuites()
    # Create a mock object

# Generated at 2022-06-17 10:40:53.882388
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:41:01.312400
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    callback_module = CallbackModule()
    # Create a mock object of class Result
    result = Result()
    # Create a mock object of class Task
    task = Task()
    # Create a mock object of class Host
    host = Host()
    # Create a mock object of class Play
    play = Play()
    # Create a mock object of class PlayContext
    play_context = PlayContext()
    # Create a mock object of class Playbook
    playbook = Playbook()
    # Create a mock object of class PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create a mock object of class PlaybookCLI
    playbook_cli = PlaybookCLI()
    # Create a mock object of class PlaybookCLI
    playbook_cli = PlaybookCLI()
    #

# Generated at 2022-06-17 10:41:15.464364
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of CallbackModule
    callback_module = CallbackModule()
    # Create an instance of Result
    result = Result()
    # Call method v2_runner_on_failed of CallbackModule
    callback_module.v2_runner_on_failed(result)


# Generated at 2022-06-17 10:41:21.811541
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:41:30.206981
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:41:35.384973
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # create an instance of the CallbackModule class
    cb = CallbackModule()
    # create an instance of the Result class
    result = Result()
    # call the v2_runner_on_failed method
    cb.v2_runner_on_failed(result)
    # assert that the task_data dictionary is not empty
    assert cb._task_data != {}


# Generated at 2022-06-17 10:41:41.558548
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    self = CallbackModule()
    playbook = Playbook()

    # Act
    self.v2_playbook_on_start(playbook)

    # Assert
    assert self._playbook_path == playbook._file_name
    assert self._playbook_name == os.path.splitext(os.path.basename(self._playbook_path))[0]


# Generated at 2022-06-17 10:41:48.024370
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:41:50.522796
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:41:54.881429
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:42:02.275404
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Exercise
    callback.v2_playbook_on_start(playbook)

    # Verify
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:42:12.794286
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:42:35.470787
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    class MockPlaybook:
        def __init__(self):
            self._file_name = 'test_file_name'

    mock_playbook = MockPlaybook()
    callback_module = CallbackModule()

    # Act
    callback_module.v2_playbook_on_start(mock_playbook)

    # Assert
    assert callback_module._playbook_path == 'test_file_name'
    assert callback_module._playbook_name == 'test_file_name'



# Generated at 2022-06-17 10:42:46.827904
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with no arguments
    result = {
        '_ansible_verbose_always': True,
        '_ansible_no_log': False,
        'changed': False,
        'invocation': {
            'module_args': {
                '_raw_params': '',
                '_uses_shell': False,
                'argv': None,
                'chdir': None,
                'creates': None,
                'executable': None,
                'removes': None,
                'stdin': None,
                'warn': True
            }
        },
        'module_name': 'command'
    }
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)

# Generated at 2022-06-17 10:42:50.400069
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Exercise
    callback.v2_playbook_on_start(playbook)

    # Verify
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:42:57.174720
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:43:03.686596
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:43:08.170765
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:43:15.469929
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:43:21.058409
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:43:27.593867
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    test_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    test_data.add_host(host)
    assert test_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:43:33.278712
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data == {'uuid': host_data}



# Generated at 2022-06-17 10:43:58.463224
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:44:06.110836
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result
    result = Mock()
    result.result = {'msg': 'test_message'}
    result.task_name = 'test_task'
    result.task_path = 'test_path'
    result.play_name = 'test_play'
    result.action = 'test_action'
    result.host_name = 'test_host'
    result.host_uuid = 'test_host_uuid'
    result.task_uuid = 'test_task_uuid'

    # Create a mock object for the task
    task = Mock()
    task.action = 'test_action'
    task.get_name.return_value = 'test_task'
    task.get_path.return_value = 'test_path'
    task.no_log = False


# Generated at 2022-06-17 10:44:15.405775
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with a failed task
    task = MockTask()
    task._uuid = '123'
    task.action = 'setup'
    task.get_name.return_value = 'test task'
    task.get_path.return_value = 'test/test.yml:1'
    task.no_log = False
    task.args = {'test': 'test'}

    result = MockResult()
    result._task = task
    result._host = MockHost()
    result._host.name = 'test'
    result._result = {'changed': False}

    callback = CallbackModule()
    callback._playbook_name = 'test'
    callback._play_name = 'test'
    callback._task_data = {}
    callback._task_class = 'false'
    callback._task_relative_

# Generated at 2022-06-17 10:44:25.100604
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object of class CallbackModule
    callback_module = CallbackModule()

    # Create a mock object of class Result
    result = Result()

    # Create a mock object of class Task
    task = Task()

    # Create a mock object of class Host
    host = Host()

    # Create a mock object of class TaskData
    task_data = TaskData()

    # Create a mock object of class HostData
    host_data = HostData()

    # Create a mock object of class TestCase
    test_case = TestCase()

    # Create a mock object of class TestSuite
    test_suite = TestSuite()

    # Create a mock object of class TestSuites
    test_suites = TestSuites()

    # Create a mock object of class TestError
    test_error = TestError()

    # Create

# Generated at 2022-06-17 10:44:27.866332
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:44:30.286904
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:44:34.981093
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = Mock()
    playbook._file_name = 'test.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test.yml'
    assert callback._playbook_name == 'test'


# Generated at 2022-06-17 10:44:42.007522
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with a valid playbook
    test_playbook = 'test_playbook.yml'
    test_playbook_name = 'test_playbook'
    test_callback = CallbackModule()
    test_callback.v2_playbook_on_start(test_playbook)
    assert test_callback._playbook_path == test_playbook
    assert test_callback._playbook_name == test_playbook_name


# Generated at 2022-06-17 10:44:46.346246
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].uuid == 'uuid'


# Generated at 2022-06-17 10:44:57.215796
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with a failed task
    result = {'failed': True, 'msg': 'test'}
    callback = CallbackModule()
    callback.v2_runner_on_failed(result)
    assert callback._task_data['test'].host_data['test'].status == 'failed'
    assert callback._task_data['test'].host_data['test'].result == result
    # Test with a failed task and ignore_errors=True
    result = {'failed': True, 'msg': 'test'}
    callback = CallbackModule()
    callback.v2_runner_on_failed(result, ignore_errors=True)
    assert callback._task_data['test'].host_data['test'].status == 'ok'
    assert callback._task_data['test'].host_data['test'].result == result

# Generated at 2022-06-17 10:45:33.510587
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:45:40.533624
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = mock.Mock()
    playbook._file_name = 'playbook.yml'
    callback_module = CallbackModule()
    # Exercise
    callback_module.v2_playbook_on_start(playbook)
    # Verify
    assert callback_module._playbook_path == 'playbook.yml'
    assert callback_module._playbook_name == 'playbook'


# Generated at 2022-06-17 10:45:43.281774
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:45:48.854147
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'


# Generated at 2022-06-17 10:45:53.346391
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['host_uuid'] == host


# Generated at 2022-06-17 10:45:57.358424
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()
    callback._playbook_name = None
    callback._playbook_path = None

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_name == 'test_playbook'
    assert callback._playbook_path == 'test_playbook.yml'


# Generated at 2022-06-17 10:46:02.816346
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = Mock()
    playbook._file_name = 'playbook.yml'
    callback = CallbackModule()

    # Exercise
    callback.v2_playbook_on_start(playbook)

    # Verify
    assert callback._playbook_path == 'playbook.yml'
    assert callback._playbook_name == 'playbook'


# Generated at 2022-06-17 10:46:09.741724
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    callbackModule = CallbackModule()
    playbook = Playbook()
    playbook._file_name = 'test.yml'

    # Act
    callbackModule.v2_playbook_on_start(playbook)

    # Assert
    assert callbackModule._playbook_path == 'test.yml'
    assert callbackModule._playbook_name == 'test'


# Generated at 2022-06-17 10:46:15.138042
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:46:20.204368
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['host_uuid'] == host_data



# Generated at 2022-06-17 10:47:33.353809
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()
    callback._playbook_path = None
    callback._playbook_name = None

    # Test
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'



# Generated at 2022-06-17 10:47:37.539059
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of class CallbackModule
    obj = CallbackModule()
    # Create an instance of class Result
    result = Result()
    # Call method v2_runner_on_failed of class CallbackModule
    obj.v2_runner_on_failed(result)


# Generated at 2022-06-17 10:47:46.929218
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with ignore_errors=False
    result = MockResult()
    result._task = MockTask()
    result._task._uuid = '123'
    result._host = MockHost()
    result._host._uuid = '456'
    result._host.name = 'host1'
    result._result = {'rc': 1, 'msg': 'failed'}
    callback = CallbackModule()
    callback._start_task(result._task)
    callback.v2_runner_on_failed(result, ignore_errors=False)
    assert callback._task_data['123'].host_data['456'].status == 'failed'
    assert callback._task_data['123'].host_data['456'].result == result
    # Test with ignore_errors=True and fail_on_ignore=False
    result = Mock

# Generated at 2022-06-17 10:47:50.075425
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['host_uuid'] == host


# Generated at 2022-06-17 10:47:56.841477
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'


# Generated at 2022-06-17 10:47:59.535932
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['host_uuid'] == host_data


# Generated at 2022-06-17 10:48:04.261679
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].uuid == 'uuid'


# Generated at 2022-06-17 10:48:11.841958
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = mock.Mock()
    playbook._file_name = 'test_playbook.yml'
    callback_module = CallbackModule()

    # Exercise
    callback_module.v2_playbook_on_start(playbook)

    # Verify
    assert callback_module._playbook_path == 'test_playbook.yml'
    assert callback_module._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:48:20.823333
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'

# Generated at 2022-06-17 10:48:30.997686
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    result = MockResult()
    result._result = {'msg': 'test'}
    callback = CallbackModule()
    callback._task_data = {}
    callback._task_data['test_task'] = TaskData('test_task', 'test_task', 'test_task', 'test_task', 'test_task')
    callback._task_data['test_task'].start = 0.0
    callback._task_data['test_task'].add_host(HostData('test_host', 'test_host', 'test_host', 'test_host'))
    callback._task_data['test_task'].host_data['test_host'].start = 0.0
    callback._task_data['test_task'].host_data['test_host'].finish = 0.0
    callback._