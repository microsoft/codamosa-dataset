

# Generated at 2022-06-17 10:39:11.796802
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:39:18.036562
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:39:26.091976
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MockPlaybook()
    callback_module = CallbackModule()

    # Act
    callback_module.v2_playbook_on_start(playbook)

    # Assert
    assert callback_module._playbook_path == playbook._file_name
    assert callback_module._playbook_name == os.path.splitext(os.path.basename(playbook._file_name))[0]


# Generated at 2022-06-17 10:39:39.374620
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:39:49.209542
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup
    result = MockResult()
    result._result = {'changed': True}
    result._task = MockTask()
    result._task._uuid = '123'
    result._host = MockHost()
    result._host._uuid = '456'
    result._host.name = 'host'
    callback = CallbackModule()
    callback._fail_on_change = 'true'
    callback._task_data = {}
    callback._task_data['123'] = TaskData('123', 'name', 'path', 'play', 'action')

    # Test
    callback.v2_runner_on_failed(result)

    # Assert
    assert callback._task_data['123'].host_data['456'].status == 'failed'


# Generated at 2022-06-17 10:40:00.732043
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result parameter
    result = mock.Mock()
    # Create a mock object for the ignore_errors parameter
    ignore_errors = mock.Mock()
    # Create a mock object for the CallbackModule class
    callback_module = mock.Mock()
    # Create a mock object for the _finish_task method
    callback_module._finish_task = mock.Mock()
    # Create a mock object for the _fail_on_ignore attribute
    callback_module._fail_on_ignore = mock.Mock()

    # Call the v2_runner_on_failed method of the CallbackModule class
    callback_module.v2_runner_on_failed(result, ignore_errors)

    # Assert that the _finish_task method was called with the correct parameters
    callback_module._finish

# Generated at 2022-06-17 10:40:12.282798
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()

    # Create an instance of Result
    result = Result()

    # Call method v2_runner_on_failed of CallbackModule
    cb.v2_runner_on_failed(result)

    # Assert
    assert cb._task_data == {'dummy_uuid': TaskData('dummy_uuid', 'dummy_name', 'dummy_path', 'dummy_play', 'dummy_action')}
    assert cb._task_data['dummy_uuid'].host_data == {'dummy_host_uuid': HostData('dummy_host_uuid', 'dummy_host_name', 'failed', result)}


# Generated at 2022-06-17 10:40:18.101366
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'


# Generated at 2022-06-17 10:40:23.153638
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['host_uuid'] == host


# Generated at 2022-06-17 10:40:30.562784
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Exercise
    callback.v2_playbook_on_start(playbook)

    # Verify
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:40:49.704908
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = mock.Mock()
    playbook._file_name = 'test_playbook'
    callback = CallbackModule()

    # Test
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:41:00.074410
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:41:10.797253
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create a new instance of CallbackModule
    callback_module = CallbackModule()
    # Create a new instance of Playbook
    playbook = Playbook()
    # Call method v2_playbook_on_start of class CallbackModule
    callback_module.v2_playbook_on_start(playbook)
    # Assert that the attribute _playbook_path of callback_module is equal to the attribute _file_name of playbook
    assert callback_module._playbook_path == playbook._file_name
    # Assert that the attribute _playbook_name of callback_module is equal to the attribute _file_name of playbook
    assert callback_module._playbook_name == playbook._file_name


# Generated at 2022-06-17 10:41:19.728937
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['host_uuid'] == host


# Generated at 2022-06-17 10:41:25.212826
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:41:27.725802
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:41:34.021191
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with a valid playbook
    playbook = {'_file_name': 'test.yml'}
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook)
    assert callback._playbook_path == 'test.yml'
    assert callback._playbook_name == 'test'


# Generated at 2022-06-17 10:41:38.829674
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with a playbook file
    playbook = {'_file_name': 'test.yml'}
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook)
    assert callback._playbook_path == 'test.yml'
    assert callback._playbook_name == 'test'


# Generated at 2022-06-17 10:41:46.728297
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:41:55.991215
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].uuid == 'uuid'



# Generated at 2022-06-17 10:42:13.402098
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-17 10:42:23.696100
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:42:27.731840
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:42:34.682310
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:42:39.795574
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with a valid playbook
    playbook = Playbook()
    playbook._file_name = "test.yml"
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook)
    assert callback._playbook_path == "test.yml"
    assert callback._playbook_name == "test"


# Generated at 2022-06-17 10:42:43.797986
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook=None)
    assert callback._playbook_path == None
    assert callback._playbook_name == None


# Generated at 2022-06-17 10:42:47.874274
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:42:54.394975
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:42:54.997419
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert True


# Generated at 2022-06-17 10:42:57.217909
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(uuid='uuid', name='name', path='path', play='play', action='action')
    host = HostData(uuid='uuid', name='name', status='status', result='result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:43:18.153603
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(1, 'name', 'path', 'play', 'action')
    host_data = HostData(1, 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data[1].name == 'name'
    assert task_data.host_data[1].status == 'status'
    assert task_data.host_data[1].result == 'result'
    assert task_data.host_data[1].uuid == 1
    assert task_data.host_data[1].finish == 0


# Generated at 2022-06-17 10:43:24.171299
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(uuid='uuid', name='name', path='path', play='play', action='action')
    host_data = HostData(uuid='uuid', name='name', status='status', result='result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'


# Generated at 2022-06-17 10:43:29.231576
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb = CallbackModule()
    cb.v2_playbook_on_start(playbook=None)
    assert cb._playbook_path == None
    assert cb._playbook_name == None


# Generated at 2022-06-17 10:43:37.997559
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = mock.MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:43:43.697648
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:43:44.701540
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass

# Generated at 2022-06-17 10:43:49.307267
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:43:53.685500
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:43:59.283139
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = Mock()
    playbook._file_name = 'playbook.yml'
    callback = CallbackModule()

    # Exercise
    callback.v2_playbook_on_start(playbook)

    # Verify
    assert callback._playbook_path == 'playbook.yml'
    assert callback._playbook_name == 'playbook'


# Generated at 2022-06-17 10:44:03.569382
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:44:34.522588
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:44:44.654879
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Arrange
    result = {'_task': {'_uuid': 'test_uuid'}, '_host': {'_uuid': 'test_host_uuid', 'name': 'test_host_name'}}
    ignore_errors = False
    callback = CallbackModule()

# Generated at 2022-06-17 10:44:51.362123
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].uuid == 'uuid'
    host2 = HostData('uuid', 'name2', 'status2', 'result2')
    task_data.add_host(host2)
    assert task_data.host_data['uuid'].name == 'name2'
    assert task_data

# Generated at 2022-06-17 10:45:02.302660
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(uuid='uuid', name='name', path='path', play='play', action='action')
    host = HostData(uuid='uuid', name='name', status='status', result='result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].uuid == 'uuid'
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].finish == None


# Generated at 2022-06-17 10:45:14.711732
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:45:24.065667
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = mock.MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Test
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:45:29.132710
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = "test_playbook.yml"
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == "test_playbook.yml"
    assert callback._playbook_name == "test_playbook"


# Generated at 2022-06-17 10:45:37.080267
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup
    result = None
    ignore_errors = False
    callback = CallbackModule()
    callback._start_task(result)
    callback._finish_task('failed', result)
    # Exercise
    callback.v2_runner_on_failed(result, ignore_errors)
    # Verify
    assert callback._task_data[result._task._uuid].host_data[result._host._uuid].status == 'failed'
    assert callback._task_data[result._task._uuid].host_data[result._host._uuid].result == result
    # Cleanup - none necessary



# Generated at 2022-06-17 10:45:46.471089
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Playbook
    pb = Playbook()
    # Call method v2_playbook_on_start of CallbackModule
    cb.v2_playbook_on_start(pb)
    # Check if the attribute _playbook_path of CallbackModule is set
    assert cb._playbook_path is not None
    # Check if the attribute _playbook_name of CallbackModule is set
    assert cb._playbook_name is not None


# Generated at 2022-06-17 10:45:50.535171
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of CallbackModule
    callback_module = CallbackModule()
    # Create an instance of Playbook
    playbook = Playbook()
    # Call method v2_playbook_on_start of class CallbackModule
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-17 10:46:29.016027
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with a valid playbook
    playbook = 'test_playbook.yml'
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook)
    assert callback._playbook_path == playbook
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:46:38.784027
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create a CallbackModule object
    obj = CallbackModule()
    # Create a playbook object
    playbook = Playbook()
    # Call method v2_playbook_on_start of class CallbackModule
    obj.v2_playbook_on_start(playbook)
    # Check if the attribute _playbook_path is set correctly
    assert obj._playbook_path == playbook._file_name
    # Check if the attribute _playbook_name is set correctly
    assert obj._playbook_name == os.path.splitext(os.path.basename(playbook._file_name))[0]


# Generated at 2022-06-17 10:46:41.320086
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(uuid='uuid', name='name', path='path', play='play', action='action')
    host = HostData(uuid='uuid', name='name', status='status', result='result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:46:53.551426
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with ignore_errors=False
    callback = CallbackModule()
    callback.v2_runner_on_failed(result=None, ignore_errors=False)
    assert callback._task_data['None'].host_data['None'].status == 'failed'
    # Test with ignore_errors=True and JUNIT_FAIL_ON_IGNORE=False
    callback = CallbackModule()
    callback.v2_runner_on_failed(result=None, ignore_errors=True)
    assert callback._task_data['None'].host_data['None'].status == 'ok'
    # Test with ignore_errors=True and JUNIT_FAIL_ON_IGNORE=True
    callback = CallbackModule()
    callback._fail_on_ignore = 'true'
    callback.v2_runner_on_

# Generated at 2022-06-17 10:46:58.818380
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create a mock object for result
    result = Mock()
    # Create a mock object for ignore_errors
    ignore_errors = Mock()
    # Call method v2_runner_on_failed of CallbackModule
    cb.v2_runner_on_failed(result, ignore_errors)
    # Assert that method _finish_task of CallbackModule was called with parameters 'failed' and result
    cb._finish_task.assert_called_with('failed', result)


# Generated at 2022-06-17 10:47:05.398544
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:47:12.246583
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create a CallbackModule object
    obj = CallbackModule()
    # Create a playbook object
    playbook = Playbook()
    # Call the method
    obj.v2_playbook_on_start(playbook)
    # Check the results
    assert obj._playbook_path == playbook._file_name
    assert obj._playbook_name == os.path.splitext(os.path.basename(obj._playbook_path))[0]


# Generated at 2022-06-17 10:47:20.947486
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:47:32.283444
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # arrange
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()
    callback._playbook_name = None
    callback._playbook_path = None

    # act
    callback.v2_playbook_on_start(playbook)

    # assert
    assert callback._playbook_name == 'test_playbook'
    assert callback._playbook_path == 'test_playbook.yml'


# Generated at 2022-06-17 10:47:34.423837
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host
