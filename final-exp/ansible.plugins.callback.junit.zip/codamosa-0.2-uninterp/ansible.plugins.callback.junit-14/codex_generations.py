

# Generated at 2022-06-17 10:38:58.328277
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:39:04.022286
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:39:09.544033
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].uuid == 'uuid'


# Generated at 2022-06-17 10:39:12.052900
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:39:17.080594
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = mock.MagicMock()
    playbook._file_name = 'playbook.yml'
    callback = CallbackModule()

    # Test
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'playbook.yml'
    assert callback._playbook_name == 'playbook'


# Generated at 2022-06-17 10:39:21.356506
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:39:35.312618
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:39:39.763379
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:39:45.612883
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:39:48.947774
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:40:06.904530
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].uuid == 'uuid'
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].finish == None
    assert task_data.host_data['uuid'].start == None


# Generated at 2022-06-17 10:40:11.026978
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with no arguments
    callback = CallbackModule()
    callback.v2_runner_on_failed()
    # Test with arguments
    callback = CallbackModule()
    callback.v2_runner_on_failed(result=None, ignore_errors=False)


# Generated at 2022-06-17 10:40:22.877779
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result parameter
    result = Mock()
    result.task_name = 'task_name'
    result.host = 'host'
    result.task_action = 'task_action'
    result.task_args = 'task_args'
    result.changed = 'changed'
    result.failed = 'failed'
    result.skipped = 'skipped'
    result.status = 'status'
    result.uuid = 'uuid'
    result.ignore_errors = 'ignore_errors'
    result.result = 'result'
    result.task = 'task'
    result.host = 'host'
    result.task_name = 'task_name'
    result.task_action = 'task_action'
    result.task_args = 'task_args'

# Generated at 2022-06-17 10:40:30.004439
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of CallbackModule
    callback_module = CallbackModule()
    # Create an instance of Playbook
    playbook = Playbook()
    # Call method v2_playbook_on_start of class CallbackModule
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-17 10:40:39.095861
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].uuid == 'uuid'
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].finish == None


# Generated at 2022-06-17 10:40:41.856610
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data



# Generated at 2022-06-17 10:40:46.827590
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('host_uuid', 'host_name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['host_uuid'] == host_data


# Generated at 2022-06-17 10:40:50.271533
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:41:00.547281
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object for the result parameter
    result = mock.Mock()
    # Create a mock object for the ignore_errors parameter
    ignore_errors = mock.Mock()
    # Create a mock object for the task parameter
    task = mock.Mock()
    # Create a mock object for the is_conditional parameter
    is_conditional = mock.Mock()
    # Create a mock object for the included_file parameter
    included_file = mock.Mock()
    # Create a mock object for the stats parameter
    stats = mock.Mock()
    # Create a mock object for the host parameter
    host = mock.Mock()
    # Create a mock object for the res parameter
    res = mock.Mock()
    # Create a mock object for the rc parameter
    rc = mock.Mock()
    # Create a mock

# Generated at 2022-06-17 10:41:01.897806
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-17 10:41:12.875004
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    # Act
    # Assert
    pass


# Generated at 2022-06-17 10:41:20.603084
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:41:26.377451
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].uuid == 'uuid'


# Generated at 2022-06-17 10:41:32.878758
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:41:38.127271
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:41:44.896205
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:41:50.113049
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = Mock()
    playbook._file_name = 'test.yml'
    callback = CallbackModule()

    # Test
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test.yml'
    assert callback._playbook_name == 'test'


# Generated at 2022-06-17 10:41:55.459821
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Given
    playbook = MockPlaybook()
    callback = CallbackModule()

    # When
    callback.v2_playbook_on_start(playbook)

    # Then
    assert callback._playbook_path == playbook._file_name
    assert callback._playbook_name == os.path.splitext(os.path.basename(playbook._file_name))[0]


# Generated at 2022-06-17 10:42:00.514051
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'].name == 'name'


# Generated at 2022-06-17 10:42:05.069138
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:42:31.336705
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:42:34.564706
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    cb = CallbackModule()
    cb.v2_playbook_on_start(playbook=None)
    assert cb._playbook_path == None
    assert cb._playbook_name == None


# Generated at 2022-06-17 10:42:40.059750
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'

# Generated at 2022-06-17 10:42:45.464725
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:42:48.886435
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:42:57.704461
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:43:04.186580
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with a valid playbook
    playbook = MagicMock()
    playbook._file_name = "test_playbook.yml"
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook)
    assert callback._playbook_path == "test_playbook.yml"
    assert callback._playbook_name == "test_playbook"


# Generated at 2022-06-17 10:43:11.457405
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:43:16.195175
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    self = CallbackModule()
    playbook = Playbook()
    playbook._file_name = 'test_playbook.yml'

    # Act
    self.v2_playbook_on_start(playbook)

    # Assert
    assert self._playbook_path == 'test_playbook.yml'
    assert self._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:43:21.140855
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].name == 'name'


# Generated at 2022-06-17 10:43:59.374357
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback_module = CallbackModule()

    # Exercise
    callback_module.v2_playbook_on_start(playbook)

    # Verify
    assert callback_module._playbook_path == 'test_playbook.yml'
    assert callback_module._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:44:02.385114
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:44:08.206889
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MockPlaybook()
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == playbook._file_name
    assert callback._playbook_name == os.path.splitext(os.path.basename(playbook._file_name))[0]


# Generated at 2022-06-17 10:44:12.326581
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:44:19.249123
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = mock.MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Execute
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:44:27.150838
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    playbook._file_name = 'test_playbook.yml'
    callback_module = CallbackModule()

    # Act
    callback_module.v2_playbook_on_start(playbook)

    # Assert
    assert callback_module._playbook_path == 'test_playbook.yml'
    assert callback_module._playbook_name == 'test_playbook'



# Generated at 2022-06-17 10:44:37.831658
# Unit test for method add_host of class TaskData

# Generated at 2022-06-17 10:44:44.754069
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'].name == 'name'
    assert task_data.host_data['uuid'].status == 'status'
    assert task_data.host_data['uuid'].result == 'result'
    assert task_data.host_data['uuid'].uuid == 'uuid'


# Generated at 2022-06-17 10:44:53.322965
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:45:00.680511
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup
    cb = CallbackModule()
    cb._start_task(None)
    cb._finish_task('failed', None)
    # Exercise
    cb.v2_runner_on_failed(None, False)
    # Verify
    assert cb._task_data[None].host_data[None].status == 'failed'
    # Cleanup - none necessary



# Generated at 2022-06-17 10:45:35.869492
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create a mock playbook object
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'

    # Create a mock callback object
    callback = CallbackModule()

    # Call the method
    callback.v2_playbook_on_start(playbook)

    # Check the results
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:45:44.572132
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MagicMock()
    callback = CallbackModule()
    callback._playbook_name = None
    callback._playbook_path = None
    # Act
    callback.v2_playbook_on_start(playbook)
    # Assert
    assert callback._playbook_name == 'test_playbook'
    assert callback._playbook_path == 'test_playbook.yml'


# Generated at 2022-06-17 10:45:47.640746
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host_data = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host_data)
    assert task_data.host_data['uuid'] == host_data


# Generated at 2022-06-17 10:45:50.986347
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:45:55.378773
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:46:02.926119
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(uuid = 'uuid', name = 'name', path = 'path', play = 'play', action = 'action')
    host = HostData(uuid = 'uuid', name = 'name', status = 'status', result = 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:46:14.323469
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Test with a failed task
    task = TaskData('uuid', 'name', 'path', 'play', 'action')
    result = HostData('uuid', 'name', 'status', 'result')
    result._result = {'changed': False}
    callback = CallbackModule()
    callback._task_data = {'uuid': task}
    callback._fail_on_ignore = 'false'
    callback._fail_on_change = 'false'
    callback.v2_runner_on_failed(result, ignore_errors=False)
    assert callback._task_data['uuid'].host_data['uuid'].status == 'failed'
    assert callback._task_data['uuid'].host_data['uuid'].result == 'result'
    # Test with a failed task and ignore_errors=True
    task

# Generated at 2022-06-17 10:46:19.518312
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with a valid playbook
    cb = CallbackModule()
    cb.v2_playbook_on_start(playbook=None)
    assert cb._playbook_path is None
    assert cb._playbook_name is None

    # Test with a valid playbook
    cb = CallbackModule()
    cb.v2_playbook_on_start(playbook=MockPlaybook())
    assert cb._playbook_path == 'playbook.yml'
    assert cb._playbook_name == 'playbook'



# Generated at 2022-06-17 10:46:21.873996
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData(1, 'test', 'test', 'test', 'test')
    host_data = HostData(1, 'test', 'test', 'test')
    task_data.add_host(host_data)
    assert task_data.host_data[1] == host_data


# Generated at 2022-06-17 10:46:25.288211
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host
    host2 = HostData('uuid', 'name', 'status', 'result')
    with pytest.raises(Exception):
        task_data.add_host(host2)



# Generated at 2022-06-17 10:47:07.721728
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = Mock()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:47:18.253886
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:47:30.208437
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data == {'uuid': host}
    host = HostData('uuid', 'name', 'included', 'result')
    task_data.add_host(host)
    assert task_data.host_data == {'uuid': host}
    host = HostData('uuid', 'name', 'status', 'result')
    try:
        task_data.add_host(host)
    except Exception as e:
        assert str(e) == 'path: play: name: duplicate host callback: name'


# Generated at 2022-06-17 10:47:35.245671
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with default values
    cb = CallbackModule()
    cb.v2_playbook_on_start(playbook=None)
    assert cb._playbook_path == None
    assert cb._playbook_name == None


# Generated at 2022-06-17 10:47:39.768732
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Arrange
    playbook = MockPlaybook()
    callback = CallbackModule()

    # Act
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == playbook._file_name
    assert callback._playbook_name == os.path.splitext(os.path.basename(playbook._file_name))[0]


# Generated at 2022-06-17 10:47:43.412994
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:47:46.490202
# Unit test for method add_host of class TaskData
def test_TaskData_add_host():
    task_data = TaskData('uuid', 'name', 'path', 'play', 'action')
    host = HostData('uuid', 'name', 'status', 'result')
    task_data.add_host(host)
    assert task_data.host_data['uuid'] == host


# Generated at 2022-06-17 10:47:52.368353
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Setup
    playbook = Mock()
    playbook._file_name = 'playbook.yml'
    callback = CallbackModule()

    # Test
    callback.v2_playbook_on_start(playbook)

    # Assert
    assert callback._playbook_path == 'playbook.yml'
    assert callback._playbook_name == 'playbook'


# Generated at 2022-06-17 10:47:57.256698
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with a valid playbook
    playbook = Playbook()
    playbook._file_name = 'test_playbook.yml'
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook)
    assert callback._playbook_path == 'test_playbook.yml'
    assert callback._playbook_name == 'test_playbook'


# Generated at 2022-06-17 10:48:09.273750
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # create an instance of the CallbackModule class
    cb = CallbackModule()
    # create an instance of the Playbook class
    pb = Playbook()
    # set the _file_name attribute of the Playbook instance
    pb._file_name = 'test.yml'
    # call the v2_playbook_on_start method of the CallbackModule instance
    cb.v2_playbook_on_start(pb)
    # assert the _playbook_path attribute of the CallbackModule instance is equal to the _file_name attribute of the Playbook instance
    assert cb._playbook_path == pb._file_name
    # assert the _playbook_name attribute of the CallbackModule instance is equal to the basename of the _file_name attribute of the Playbook instance
    assert cb._playbook_