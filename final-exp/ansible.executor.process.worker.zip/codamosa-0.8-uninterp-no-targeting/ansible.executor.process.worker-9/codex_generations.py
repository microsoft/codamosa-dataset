

# Generated at 2022-06-20 14:26:16.834746
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    q = multiprocessing.Queue()

    # create a host with some vars
    h = Host("testhost")
    h.vars = dict(
        ansible_user="root",
        ansible_host="127.0.0.1",
        foo="123",
        bar="xyz",
    )

    # create a task
    t = Task()
    t.module_name = 'shell'
    t.module_args = 'echo hi'
    t.name = 'hi'
    t._uuid = '1234'
    t.action = 'shell'

    # create a play context
    p = PlayContext()

    # create a task queue manager
    tqm = TaskQueueManager(q)

    # create a worker process and run it
    wp = Worker

# Generated at 2022-06-20 14:26:26.356516
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():

    import multiprocessing
    import ansible.plugins.loader
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.callback as callback_plugins
    import ansible.plugins.connection.local as connection_plugins
    import ansible.compat.six as six
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    try:
        from __main__ import cli
    except ImportError:
        cli = None

    multiprocessing.current_process()._config['tempdir'] = None


# Generated at 2022-06-20 14:26:34.466400
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from multiprocessing import Queue
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    results_q = Queue()
    host = FakeHost()
    task = FakeTask('fake1')
    play_context = PlayContext()
    loader = FakeLoader()
    variable_manager = VariableManager()

    worker = WorkerProcess(results_q, host, task, play_context, loader, variable_manager, [])

    worker.run()

    # TODO: Test the actual results somehow?

# Helper classes for test

# Generated at 2022-06-20 14:26:42.008175
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    UnitTest for method start
    '''    
    from multiprocessing import Queue
    q = Queue()
    host = "localhost"
    task_vars = {}
    task = {}
    play_context = {}
    loader = {}
    variable_manager = {}
    shared_loader_obj = {}
    worker = WorkerProcess(q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker.start()
    worker.join()

# Generated at 2022-06-20 14:26:46.486317
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    final_q = multiprocessing.Queue()
    task_vars = dict()
    host = dict()
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()

    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker.start()

    worker.join()

# Generated at 2022-06-20 14:26:58.405220
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import ansible.parsing.dataloader

    def mock_TaskExecutor_run(self):
        return True

    final_q = MockQueue()
    task_vars = {}
    host = MockHost()
    task = MockTask()
    play_context = MockPlayContext()
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = MockVariableManager()
    shared_loader_obj = MockSharedLoaderObj()

    worker_process = WorkerProcess(
        final_q,
        task_vars,
        host,
        task,
        play_context,
        loader,
        variable_manager,
        shared_loader_obj
    )

    worker_process.run = mock_TaskExecutor_run
    worker_process.start()

    import time
   

# Generated at 2022-06-20 14:27:09.207015
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    from multiprocessing import queues, syncthreads
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play

    class FakeTask(object):
        def __init__(self):
            self.action = 'ping'

        def dump_attrs(self):
            return dict(action=self.action)

    class FakeTaskExecutor(object):
        def __init__(self, host, task, task_vars, play_context, new_stdin, loader, final_q):
            self.host = host
            self.task = task
            self.task_vars = task_vars
            self.play_context = play_context
            self.new_stdin = new_stdin
            self.loader = loader

# Generated at 2022-06-20 14:27:11.349180
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # TODO:
    # - check if the error handling is the same as expected
    return True

# Generated at 2022-06-20 14:27:23.413120
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # test the method run of class WorkerProcess
    # usually, we have a TaskQueueManager in final_q, the input of the method run
    # In this test case, to mock the manager, we add a list in it, and used it to store the result

    # create a test inventory
    inv_source = '''
    localhost ansible_connection=local ansible_python_interpreter=/usr/bin/python3
    '''
    inv_loader = DataLoader()
    inventory = InventoryManager(loader=inv_loader, sources=[inv_source])

    # create a test play

# Generated at 2022-06-20 14:27:33.981864
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    class MockFinalQueue:
        def send_task_result(self, host, task_uuid, result, task_fields):
            self.result = result


# Generated at 2022-06-20 14:27:54.627935
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import pytest
    import ansible.executor.task_result
    import ansible.module_utils
    #import ansible.playbook.task_include
    #import ansible.plugins.action
    import ansible.plugins.action.copy
    import ansible.template
    import ansible.vars.manager

    from ansible.module_utils.basic import AnsibleModule

    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.module_utils import connections
    from ansible.plugins.action.copy import ActionModule as CopyModule
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    #from ansible.playbook.task_include import TaskInclude

    #from ansible.plugins.

# Generated at 2022-06-20 14:27:55.166782
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Generated at 2022-06-20 14:28:07.015056
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    class Queue():
        def __init__(self):
            self.queue = {}
        def send_task_result(self,host,uuid,executor_result,task_fields):
            self.queue[host] = (uuid,executor_result,task_fields)

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import ansible.utils.vars as vars_util
    import ansible.utils.vars as vars_util
    from ansible.inventory.host import Host

    class Options(object):
        verbosity = 0
        connection = 'ssh'
        module_

# Generated at 2022-06-20 14:28:16.240854
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    multiprocessing_context.initialize()
    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    host = dict()
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()

    worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert worker_process

# Generated at 2022-06-20 14:28:27.217147
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # pylint: disable=unused-variable
    try:
        from multiprocessing import Queue
    except ImportError:
        from multiprocessing.queues import Queue
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.vars.manager import VariableManager
    final_q = Queue()
    task_vars = {}
    host = {}
    task = {}
    play_context = {}
    loader = get_all_plugin_loaders()
    variable_manager = VariableManager()
    shared_loader_obj = {}
    worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert worker_process is not None

# Generated at 2022-06-20 14:28:41.774954
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    class MyQueueManager(object):

        class Queue(object):
            def get(*args, **kwargs):
                return

            def task_done(*args, **kwargs):
                return

            def join(*args, **kwargs):
                return

            def empty(*args, **kwargs):
                return

        class Pipe(object):
            def recv(*args, **kwargs):
                return

        def connect(*args, **kwargs):
            return

        def close(*args, **kwargs):
            return

        def get_task_queue(*args, **kwargs):
            return MyQueueManager.Queue()

        def get_result_queue(*args, **kwargs):
            return MyQueueManager.Queue()

        def get_fail_queue(*args, **kwargs):
            return MyQueueManager.Queue()


# Generated at 2022-06-20 14:28:50.832373
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    import ansible.plugins

    fake_host1 = ansible.inventory.host.Host('fake1')

    fake_host2 = ansible.inventory.host.Host('fake2')

    fake_loader = ansible.parsing.dataloader.DataLoader()

    fake_variable_manager = ansible.vars.manager.VariableManager()

    fake_host1.vars['ansible_connection'] = 'fake'
    fake_host2.vars['ansible_connection'] = 'fake'

    # Test with a fake connection plugin
    original_connection_plugins = [ansible.plugins.connection.ConnectionBase]

    class FakeConnBase(ansible.plugins.connection.ConnectionBase):
        def __init__(self, play_context, new_stdin, *args, **kwargs):
            self._play_context

# Generated at 2022-06-20 14:29:02.682109
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.play_context import PlayContext
    from multiprocessing import Queue, Event
    from multiprocessing.managers import BaseManager
    from ansible.plugins.loader import shared_loader_obj

    event_obj = Event()
    send_queue = Queue(5)
    event_obj.set()
    BaseManager.register('get_event_obj', callable=lambda: event_obj)
    manager = BaseManager(address=('127.0.0.1', 0), authkey=b'testpass')
    manager.start()

# Generated at 2022-06-20 14:29:14.523401
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue
    from ansible.plugins import module_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash

    module_loader.add_directory(os.getcwd())
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../'))
    module_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../'))

    loader = module_loader.get_loader()
    final_q = Queue()
    host = 'testhost'
    task = dict(action='ping')
    play_context = dict(remote_addr='127.0.0.1', password='pass')
    task_vars

# Generated at 2022-06-20 14:29:24.669151
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from collections import namedtuple

    FakeQueue = namedtuple('FakeQueue', ['task_fields'])

    class FakeTaskExecutor(object):
        def __init__(self, host, task, task_vars, play_context, new_stdin, loader, shared_loader_obj, final_q):
            assert host == 'my_host'
            assert task.action == 'my_action'
            assert play_context.shell == '/bin/bash'


# Generated at 2022-06-20 14:29:43.479882
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass # TODO

# Generated at 2022-06-20 14:29:50.606586
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    host = "127.0.0.1"
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()

    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    worker._run()

# Generated at 2022-06-20 14:30:00.700108
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    class Mock_Process(object):
        def __init__(self):
            self.counter = 0

        def start(self):
            self.counter += 1

    class Mock_WorkerProcess(WorkerProcess):
        def __init__(self, final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj):
            super(Mock_WorkerProcess, self).__init__(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
            self._new_stdin = None
            self.mock_process = Mock_Process()

        def _save_stdin(self):
            self._new_stdin = None

# Generated at 2022-06-20 14:30:07.461593
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    final_q = multiprocessing.Queue()
    task_vars = None
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None
    worker = WorkerProcess(
        final_q,
        task_vars,
        host,
        task,
        play_context,
        loader,
        variable_manager,
        shared_loader_obj
    )
    worker.start()
    worker.join()

# Generated at 2022-06-20 14:30:18.059233
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import get_all_plugin_loaders, get_plugin_loader
    import multiprocessing
    from ansible.parsing.dataloader import DataLoader
    # initialize needed objects
    loader = DataLoader()

    variable_manager = VariableManager()

    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-20 14:30:25.512643
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue
    from ansible.vars import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader, connection_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    from ansible.playbook.task import Task

    task_vars = dict()
    final_q = Queue()
    task = Task()
    play_context = PlayContext()
    loader = DataLoader()
    plugin_loaders = get_all_plugin_

# Generated at 2022-06-20 14:30:25.988261
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-20 14:30:31.616922
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    import tempfile
    import os
    q = multiprocessing.Queue()
    def foo():
        return os.fdopen(os.dup(sys.stdin.fileno()))
    try:
        tmpfd, tmpname = tempfile.mkstemp(prefix='ansible-tmp')
        sys.stdin = os.fdopen(tmpfd, 'rb')
        try:
            foo()
        except:
            assert False
    finally:
        sys.stdin = os.fdopen(os.open(os.devnull, os.O_RDONLY))
        os.unlink(tmpname)

# Generated at 2022-06-20 14:30:42.618431
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue
    queue = Queue()
    task_vars = [{'testdata': 'testdata'}]
    class Host:
        def __init__(self):
            self.vars = ['vars']
            self.groups = ['groups']
            self.name = 'testhost'
    host = Host()
    class Task:
        def __init__(self):
            self._uuid = 'testtask'
            self.dump_attrs = ['dump_attrs']
    task = Task()
    class PlayContext:
        pass
    play_context = PlayContext()
    class Loader:
        pass
    loader = Loader()
    class VariableManager:
        pass
    variable_manager = VariableManager()
    class SharedLoaderObj:
        pass
    shared_loader_

# Generated at 2022-06-20 14:30:48.305175
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # create mockup variables
    final_q = None
    task_vars = {
        "inventory_hostname": "testhost",
        "gather_facts": "no",
        "ignore_errors": "True"
    }
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = True

    # give mockup variables to worker
    worker = WorkerProcess(
        final_q, task_vars, host, task, play_context, loader,
        variable_manager, shared_loader_obj)

    assert worker.start() == None

# Generated at 2022-06-20 14:31:31.534085
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    final_q = multiprocessing.Queue()
    task_vars = dict()
    host = '127.0.0.1'
    task = u'Test Task'
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None
    WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

# work around for http://bugs.python.org/issue15881#msg170215
if __name__ == '__main__':
    multiprocessing_context.freeze_support()

# Generated at 2022-06-20 14:31:39.487538
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.strategy import StrategyBase

    # create mock objects and stacks
    class MockDataLoader(DataLoader):
        mock_data = {}

        def __init__(self):
            mock_dataloader = self

        def get(self, path, style='auto', unsafe=False):
            return self.mock_data[path]

    class MockStrategyBase(StrategyBase):
        mock_tqm = None

        def __init__(self, tqm):
            self.mock_tqm = tqm

    loader = MockDataLoader()
    shared_loader_obj = MockData

# Generated at 2022-06-20 14:31:52.977921
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing.connection

    result_q = multiprocessing_context.Queue()
    task_result = dict()
    task_result['host_name'] = 'some_host'
    task_result['task_uuid'] = 'some_task'
    task_result['task_result'] = dict()
    task_result['task_result']['failed'] = True
    task_result['task_result']['exception'] = ''
    task_result['task_result']['stdout'] = ''

    worker_process = WorkerProcess(result_q, 'task_vars', 'host', 'task', 'play_context', 'loader', 'variable_manager', 'shared_loader_obj')
    worker_process.start()
    worker_process.join()

    assert result_q.get() == task

# Generated at 2022-06-20 14:31:59.537779
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    def _test_method():
        pass

    final_q = multiprocessing_context.Queue()
    task_vars = {}
    host = "localhost"
    task = "debug"
    play_context = "play_context"
    loader = "loader"
    variable_manager = "variable_manager"
    shared_loader_obj = "shared_loader_obj"
    worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager,
                                   shared_loader_obj)

    worker_process.start()
    worker_process.join(timeout=10)
    assert not worker_process.is_alive()


# Generated at 2022-06-20 14:32:02.804125
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    return WorkerProcess(None, None, None, None, None, None, None, None)

# pylint: disable=unused-argument

# Generated at 2022-06-20 14:32:08.270989
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Create a FinalQueue object
    final_q = multiprocessing_context.FinalQueue()
    # Create a WorkerProcess object
    worker_process = WorkerProcess(final_q, task_vars=None, host=None, task=None, play_context=None, loader=None, variable_manager=None, shared_loader_obj=None)
    # Test the start method of WorkerProcess
    worker_process.start()

# Generated at 2022-06-20 14:32:11.110623
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass


# Generated at 2022-06-20 14:32:19.545086
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import time
    import multiprocessing
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins import module_loader

# Generated at 2022-06-20 14:32:28.937679
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.vars.manager import VariableManager

    def fake_final_q():
        return

    def fake_task_vars():
        return

    def fake_host():
        return

    def fake_task():
        return

    def fake_play_context():
        return

    def fake_loader():
        return

    def fake_variable_manager():
        return VariableManager()

    def fake_shared_loader_obj():
        return

    worker_process = WorkerProcess(
        fake_final_q(),
        fake_task_vars(),
        fake_host(),
        fake_task(),
        fake_play_context(),
        fake_loader(),
        fake_variable_manager(),
        fake_shared_loader_obj()
    )

    assert worker_process

# Generated at 2022-06-20 14:32:36.915503
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from . import queue_manager
    # Mock all objects that are passed to the constructor.
    final_q = queue_manager.QueueManager(10)
    task_vars = 'task_vars'
    host = 'host'
    task = 'task'
    play_context = 'play_context'
    loader = 'loader'
    variable_manager = 'variable_manager'
    shared_loader_obj = 'shared_loader'

    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert worker._final_q == final_q
    assert worker._task_vars == task_vars
    assert worker._host == host
    assert worker._task == task
    assert worker._play_context == play_context
    assert worker._

# Generated at 2022-06-20 14:33:56.491730
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import queue
    task_vars = {}
    q = queue.Queue()
    host = "foo"
    task = 'test'
    play_context = 1
    loader = 'loader'
    variable_manager = 'variable_manager'
    shared_loader_obj = 'shared_loader_obj'

    w = WorkerProcess(q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

# Generated at 2022-06-20 14:34:06.474523
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

    # Initialize arguments.
    final_q = Queue()
    task_vars = HostVars(HostVarsVars({}))
    host = '*'
    task = '*'
    play_context = PlayContext()
    loader = '*'
    variable_manager = VariableManager()
    shared_loader_obj = '*'

    # Construct object.

# Generated at 2022-06-20 14:34:09.289837
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-20 14:34:17.893713
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    multiprocessing_context.SUPPORTS_REDIRECT_STDIO = False

    fq = multiprocessing_context.Queue()
    wp = WorkerProcess(
        final_q=fq,
        task_vars={},
        host={},
        task={},
        play_context={},
        loader=None,
        variable_manager=None,
        shared_loader_obj=None,
    )

    wp.start()

    # Clean up
    wp.join()



# Generated at 2022-06-20 14:34:22.121666
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass



# Generated at 2022-06-20 14:34:28.582027
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    import os
    import sys
    import traceback

    import multiprocessing

    # import cProfile, pstats, StringIO
    # pr = cProfile.Profile()
    # pr.enable()


# Generated at 2022-06-20 14:34:30.010196
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass



# Generated at 2022-06-20 14:34:31.085380
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # TODO: write unit tests
    pass

# Generated at 2022-06-20 14:34:39.759628
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    from ansible_test._internal.utils.test.test_executor import test_result_queue
    from ansible_test._internal.utils.test.units.callback_plugins import TestCallbackModule
    from ansible_test._internal.utils.test.units.module_utils import TestModuleUtils
    result_queue = multiprocessing.Queue()

    # initialize the callback
    callback_plugin = TestCallbackModule()
    callback_plugin.set_queue(result_queue)
    # initialize the task executor with a play
    test_task = dict(action=dict(module='debug', args=dict(msg='Hello World!')))
    # initialize the play with the task
    play = dict(hosts=['localhost'], role_name=None, tasks=[test_task])
    # initialize the play context


# Generated at 2022-06-20 14:34:45.277465
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    def _new_worker(*args, **kwargs):
        w = WorkerProcess(*args, **kwargs)
        w._new_stdin = open('/dev/null', 'w')
        return w

    from ansible.utils.queue import Queue
    from ansible.vars.manager import VariableManager

    vars_manager = VariableManager()
    final_queue = Queue()
    task_queue = Queue()
    host = '127.0.0.1'
    task = {'action': {'module': 'shell', 'args': 'ls'}}
    loader = 'fake loader'
    task_vars = {'ansible_job_id': 'fake job'}
    play_context = 'fake play context'
    shared_loader_obj = 'fake shared loader obj'
