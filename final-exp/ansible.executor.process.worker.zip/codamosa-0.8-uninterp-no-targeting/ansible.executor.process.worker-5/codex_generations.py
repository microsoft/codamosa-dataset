

# Generated at 2022-06-20 14:26:09.167528
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_host = type('', (), dict(name='testhost'))
    test_task = type('', (), dict(uuid='testuuid'))
    test_task_vars = dict(test_var=True)
    test_play_context = type('', (), dict(module_name='testmodule', module_args='testmoduleargs'))

    test_loader = type('', (), dict(cleanup_all_tmp_files=lambda: print('test cleanup')))
    test_variable_manager = type('', (), dict(get_vars=lambda host, task, play_context, loader, templar=None,
        shared_loader_obj=None: test_task_vars, _hostvars_dir=None))

# Generated at 2022-06-20 14:26:22.156483
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Create an empty multiprocessing queue
    queue = multiprocessing_context.Queue()

    task_vars = {}
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None

    # Create the object
    worker_object = WorkerProcess(queue, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    # Check to see if fields are set
    assert worker_object._final_q == queue
    assert worker_object._task_vars == task_vars
    assert worker_object._host == host
    assert worker_object._task == task
    assert worker_object._play_context == play_context
    assert worker_object._loader == loader
    assert worker_object

# Generated at 2022-06-20 14:26:34.377968
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        def v2_runner_on_unreachable(self, result):
            self._unreachable_hosts.append(result)

        def v2_runner_on_ok(self, result):
            self._ok_hosts.append(result)

    options = {'verbosity': 0}  # quiet

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

# Generated at 2022-06-20 14:26:44.530849
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import callback_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host

    import ansible.constants as C
    import json

    # Initialize needed objects
    loader = DataLoader()
    callback_plugin = callback_loader.get('json')
    variable_

# Generated at 2022-06-20 14:26:49.937156
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from ansible.utils.multiprocessing import FakeMultiprocessingModule

    def fake_start(self):
        try:
            self._save_stdin()
        finally:
            self._new_stdin.close()

    multiprocessing_context.Process.start = fake_start

    multiprocessing_context.Process = FakeMultiprocessingModule
    # initialize the connection plugin
    multiprocessing_context.forking.get_context('spawn')

    task_vars = dict(foo='bar')
    host = 'test_host'
    task = dict(action=dict(module='test_module'))
    play_context = {}
    loader = None
    vars_manager = None
    shared_loader_obj = None

# Generated at 2022-06-20 14:27:02.396821
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Prepare some test data
    class FakeFinalQ:
        def __init__(self):
            self.results = {}

        def send_task_result(self, host, task_uuid, result, task_fields = {}):
            self.results[host] = result

        def clear_task_results(self):
            self.results = {}


    final_q = FakeFinalQ()
    task_vars = {'test_key':'test_value'}
    host = 'test_host'
    task = 'test_task'
    play_context = {}
    loader = {}
    variable_manager = {}
    shared_loader_obj = {}


    # Start the test

# Generated at 2022-06-20 14:27:04.345807
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-20 14:27:15.707073
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # test constructor
    final_q = multiprocessing_context.SimpleQueue()
    task_vars = {}
    host = "127.0.0.1"
    task = {}
    play_context = {}
    loader = {}
    variable_manager = {}
    shared_loader_obj = {}

    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    # test if instance is initialized properly
    assert worker._final_q == final_q
    assert worker._task_vars == task_vars
    assert worker._host == host
    assert worker._task == task
    assert worker._play_context == play_context
    assert worker._loader == loader
    assert worker._variable_manager == variable_manager
    assert worker._shared

# Generated at 2022-06-20 14:27:16.469910
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass


# Generated at 2022-06-20 14:27:23.992887
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.executor import task_queue_manager
    from ansible.inventory.host import Host
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    host = Host('test_host')
    host_vars = HostVars(host, {})

    host.vars = host_vars

    shared_loader_obj = module_loader._loaders[0]
    loader = module_loader.get('command', class_only=True)

    class MockTask:
        def __init__(self, module='command', when=None, action=None, loop=None, delegate_to='test_host', no_log=False):
            self.module = module

# Generated at 2022-06-20 14:27:44.018486
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # This is not a test and is only used to demonstrate how this
    # class method works.
    from multiprocessing import Process, Queue
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    handler_queue = Queue()
    host = Host(name='localhost', port=22)
    task = Task()
    task_vars = {}
    play_context = {}

    shared_loader_obj = {}

    wp = WorkerProcess(
        handler_queue, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    wp.start()


# Generated at 2022-06-20 14:27:51.670798
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.plugins.callback.default import CallbackModule
    import multiprocessing
    import sys

    loader = DataLoader()
    callback = CallbackModule()
    host = Host("host")
    task = Task()
    task.connection = 'local'
    task.action = "setup"
    task.args = {'gather_subset': '!all'}
    play_context = None
    task_vars = {}
    variable_manager = None
    shared_loader_obj = None
    final_q = multiprocessing.Queue()


# Generated at 2022-06-20 14:27:52.300600
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Generated at 2022-06-20 14:28:06.873205
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    """
    assert that WorkerProcess get initialized properly
    """
    def run():
        from ansible.inventory.host import Host
        from ansible.playbook.task import Task
        from ansible.vars.manager import VariableManager
        class Queue:
            def __init__(self):
                self.queue = []
                self.manager_get_value = []
                self.send_task_result_value = []

            def get(self):
                if len(self.queue) < 1:
                    return None
                else:
                    return self.queue.pop(0)

            def put(self, value):
                self.queue.append(value)

            def qsize(self):
                return len(self.queue)

        def manager_get(name):
            return "task_vars"


# Generated at 2022-06-20 14:28:10.489988
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Test if the stdin of process can be preserved
    pass

# Generated at 2022-06-20 14:28:24.733159
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    try:
        from multiprocessing import Queue
    except:
        from multiprocessing import Queue
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.basic import load_module_specs

    shared_loader_obj = DataLoader()
    shared_loader_obj.set_

# Generated at 2022-06-20 14:28:33.424557
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import tempfile
    import shutil
    import multiprocessing
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-20 14:28:34.100159
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Generated at 2022-06-20 14:28:39.806932
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing

    q = multiprocessing.Queue()
    p = WorkerProcess(q,
                      task_vars={},
                      host=None,
                      task=None,
                      play_context={},
                      loader=None,
                      variable_manager=None,
                      shared_loader_obj=None)
    # print(p)

# Generated at 2022-06-20 14:28:48.951097
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext

    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    host = "testhost"
    variable_manager = VariableManager()
    play_context = PlayContext()
    loader = None
    shared_loader_obj = None

    class MockTask(object):

        def __init__(self):
            self.name = None

        def __repr__(self):
            return self.name

        def __getattr__(self, name):
            return None

        def __getstate__(self):
            return {'name': self.name}

        def __setstate__(self, d):
            self.name = d['name']

    task = MockTask()
   

# Generated at 2022-06-20 14:29:18.400909
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.module_utils.six.moves import cStringIO as StringIO
    import sys

    class AnsibleFakeDisplay(Display):
        def __init__(self):
            self.display_messages = []

        def display(self, msg, *args, **kwargs):
            self.display_messages.append(msg)

    fake_display = AnsibleFakeDisplay()
    old_display = display
    display = fake_display
    test_stdout = StringIO()
    test_stderr = StringIO()
    test_sys = sys
    old_sys = sys
    sys = test_sys
    test_sys.stdout = test_stdout
    test_sys.stderr = test_stderr

    from ansible.module_utils.six.moves import queue as Queue

# Generated at 2022-06-20 14:29:21.120746
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    q = multiprocessing_context.Queue(5)
    worker = WorkerProcess(q, {}, None, None, None, None, None, None)
    worker.start()


# Generated at 2022-06-20 14:29:26.335438
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    multiprocessing_context.set_executor()
    MultiQ = multiprocessing_context.get_context('multiprocessing.queues.SimpleQueue')
    final_q = MultiQ()
    task_vars = dict()
    # fake host
    host = dict()
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert worker

# Generated at 2022-06-20 14:29:33.048285
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    host = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None

    task = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    task._run()

# Generated at 2022-06-20 14:29:40.249671
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    class FakeHost:
        def __init__(self, name):
            self.name = name

    class FakeLoader:
        def __init__(self):
            self._all_vars = dict(
                host_name = 'localhost',
                play_hosts = ['localhost'],
            )

        def get_basedir(self):
            return '.'

    class FakeFinalQ:
        def __init__(self):
            pass
        def send_task_result(self, host, uuid, result, task_fields):
            pass

    # test verify_file

# Generated at 2022-06-20 14:29:51.196037
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    try:

        print("*****This is a test for class WorkerProcess*****")
        final_q = multiprocessing_context.Queue()
        task_vars = {}
        host = 'host'
        task = 'task'
        play_context = 'play_context'
        loader = 'loader'
        variable_manager = 'variable_manager'
        shared_loader_obj = 'shared_loader_obj'
        worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
        assert isinstance(worker_process, WorkerProcess)

    except:
        print("WorkerProcess object creation failed!")


# Generated at 2022-06-20 14:30:02.872873
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import tempfile
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import module_loader, callback_loader
    from ansible.plugins.callback import CallbackBase

    # Create a temp directory to use as a fake dataroot
    temp_dir = tempfile.mkdtemp()

    # Create a queue and a manager to manage it
    task_queue = multiprocessing_context.Queue()
    result_queue = multiprocessing_context.Queue()

# Generated at 2022-06-20 14:30:10.236771
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Test case 1: _answer is an empty list

    _answer = []

    _final_q = "data"
    _task_vars = []
    _host = "server"
    _task = "task"
    _play_context = "context"
    _loader = "loader"
    _variable_manager = "variable_manager"
    _shared_loader_obj = "shared_loader_obj"

    # Run the test case
    workerProcess = WorkerProcess(_final_q, _task_vars, _host, _task, _play_context, _loader, _variable_manager, _shared_loader_obj)

    # Assert that objects equal to expected output
    assert workerProcess._final_q == _answer
    assert workerProcess._task_vars == _answer
    assert workerProcess._host == _answer

# Generated at 2022-06-20 14:30:19.924947
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
  import multiprocessing
  import tempfile
  q_res = multiprocessing.Queue()
  q_in = multiprocessing.Queue()
  q_in.put(('localhost', {'a': 1}, 'noop'))
  worker = WorkerProcess(q_res, q_in)
  worker.start()
  worker.join()

  class dummy_loader:
    def __init__(self):
      self._tempfiles = set()

    def get_basedir(self, *args, **kwargs):
      return tempfile.mkdtemp()

    def cleanup_tmp_file(self, *args, **kwargs):
      return True

  class dummy_variable_manager:
    def __init__(self):
      pass


# Generated at 2022-06-20 14:30:28.462849
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import load_extra_vars, load_options_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    inventory.add_group(Group('test'))
    inventory.add_host(Host(name='localhost', port=22, group_names=['test']))
    extra_vars = load_extra_vars(loader=DataLoader(), options=load_options_vars(dict()))

# Generated at 2022-06-20 14:31:12.937506
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    try:
        os.remove('/tmp/worker_result.txt')
    except:
        pass

    def test_task_callback(task, host, task_result, ignore_errors=False, task_fields=None):
        fd = open('/tmp/worker_result.txt', 'a')
        fd.write('%s\n' % task_result)
        fd.close()

    # Create a test task
    class TestTask():
        def __init__(self, uuid):
            self._uuid = uuid

    host = 'localhost'
    queue = multiprocessing_context.Queue()
    final_q = multiprocessing_context.FinalQueue(queue, test_task_callback)

    task_vars = dict(localhost='localhost')

# Generated at 2022-06-20 14:31:24.200459
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-20 14:31:32.834320
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    from multiprocessing import Queue
    from ansible.vars import VariableManager
    from ansible.inventory import Host
    from ansible.parsing.dataloader import DataLoader
    import ansible.playbook.play as Play
    import ansible.playbook.task as Task
    import ansible.executor.task_queue_manager as TaskQueueManager
    import ansible.utils.vars as vars

    class FakeVariableManager(VariableManager):
        def __init__(self):
            self.vars = dict()
            self.hostvars = dict()

    class FakeTaskQueueManager():
        def __init__(self):
            pass


# Generated at 2022-06-20 14:31:40.443608
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue

    msg = [None]
    q = Queue()

    def ping(q):
        msg[0] = q.get()
        q.put('pong')

    def foo():
        pass

    worker = WorkerProcess(q, None, None, None, None, None, None, None)
    worker.run = ping
    worker.start()
    q.put('ping')
    q.get()
    worker.join()
    assert msg[0] == 'ping', 'start() did not call run(), msg = %r' % msg[0]

    # test that if the run() method excepts, the thread exits
    worker = WorkerProcess(q, None, None, None, None, None, None, None)
    worker.run = foo
    worker.start()

# Generated at 2022-06-20 14:31:48.679998
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    """Test WorkerProcess._run() method"""

    # Create fake mocks
    final_q = MockFinalQueue()
    task_vars = dict()
    host = MockHost()
    task = MockTask()
    play_context = MockPlayContext()
    loader = MockLoader()
    variable_manager = MockVariableManager()
    shared_loader_obj = MockSharedLoaderObject()

    # Create instance of WorkerProcess
    worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    # Call run method
    worker_process._run()

    # Assert that methods are called
    assert final_q.method_calls[0][0] == 'send_task_result'

# Generated at 2022-06-20 14:31:57.800063
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    Does the method _start work as expected?
    '''

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = dict()

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)

    # Create play with random tasks

# Generated at 2022-06-20 14:32:08.231483
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import Queue
    final_q = Queue.Queue()
    task_vars = dict()
    host = 'example host'
    task = 'example task'
    play_context = 'example play_context'
    loader = 'example loader'
    variable_manager = 'example variable_manager'
    shared_loader_obj = None

    w = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    out = w.run()

    #TODO
    print("out = %s" % out)

# Generated at 2022-06-20 14:32:19.139212
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing, time, sys
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import get_all_plugin_loaders

    def _write_to_q(q):
        '''Write some data to the queue'''
        data = [1, 'a', {'foo': 'bar'}]
        q.put(data)

    def _read_from_q(q):
        '''Read some data from the queue'''
        data = q.get()
        print(data)

    if __name__ == '__main__':
        q = multiprocessing.Queue()
        tqm = TaskQueueManager()

# Generated at 2022-06-20 14:32:28.937607
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Create a worker process and test the start() method
    import multiprocessing
    from ansible.executor.task_queue_manager import TaskQueueManager

    class MockFinalQ(object):

        def send_task_result(self, host, uuid, result, task_fields=None):
            print('Send result from worker to main process')

    class MockVariableManager(object):

        def get_vars(self, loader, host, task, wrap_async=False):
            return {'var':'varval'}

    class MockLoader(object):

        def get_basedir(self, play=None):
            return 'non-existant'

        def get_real_file(self, path):
            return path


# Generated at 2022-06-20 14:32:36.914689
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    import multiprocessing.queues
    import threading
    import time

    #
    # Worker testing using a very simple 'hello world' task
    #
    class TestTask(object):
        def __init__(self):
            self._length = 1
            self._uuid = 'dummy UUID'
            self._role = None
            self._block = None
            self._always_run = False
            self._any_errors_fatal = False
            self._any_unreachable_fatal = False
            self._loop = None
            self._failed_when = False
            self._tags = []
            self._dep_chain = []
            self._when = None
            self._changed_when = None
            self._notify = []
            self._handlers = []
            self._

# Generated at 2022-06-20 14:33:51.920230
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # TBD
    return True


# Generated at 2022-06-20 14:33:52.548508
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-20 14:33:59.777345
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    display.verbosity = 3
    display.debug(u"Running test_WorkerProcess")

    results_queue = multiprocessing_context.Queue()
    results_queue._reader = multiprocessing_context.Queue()
    results_queue._writer = multiprocessing_context.Queue()
    results_queue._rlock = multiprocessing_context.RLock()

    t = WorkerProcess(results_queue, dict(), dict(), dict(), dict(), dict(), dict(), dict())

# Generated at 2022-06-20 14:34:09.339992
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Dummy tasks
    class DummyTask:
        def __init__(self):
            self.name = "DummyTask"
            self.action = "dummyAction"
            self.uuid = "DummyUUID"
            self.tags = "DummyTags"
            self.when = "DummyWhen"
            self.attributes = "DummyAttributes"

    # Dummy hosts
    class DummyHost:
        def __init__(self):
            self.name = "DummyHost"
            self.groups = ["DummyGroups"]
            self.vars = "DummyVars"

    # Dummy queue
    class DummyFinalQ:
        def __init__(self):
            self.name = "DummyFinalQ"

    # Dummy task vars

# Generated at 2022-06-20 14:34:20.508921
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.inventory.host import Host

    add_all_plugin_dirs()
    loader = DataLoader()
    hostvars = HostVars(loader=loader, host_name='foo')
    play_context = Runner.get_default_play_context(None)


# Generated at 2022-06-20 14:34:28.249127
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager

    class TestTask(TaskInclude):
        pass

    pctx = PlayContext()
    pctx._initialize()
    lm = module_loader.all(class_only=True)
    vm = VariableManager()

    task = TestTask()
    task_vars = vm.get_vars(loader=None, play=None, host=None)
    host = 'localhost'

    wp = WorkerProcess(None, task_vars, host, task, pctx, None, vm, None)
    wp.start()
    wp.join()
    assert wp.exitcode == 0

# Generated at 2022-06-20 14:34:35.578289
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Set up a few parameters
    final_q = 1
    task_vars = {}
    host = 1
    task = 1
    play_context = 1
    loader = 1
    variable_manager = 1
    shared_loader_obj = 1

    # Instantiate a WorkerProcess object
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    # Run worker.run()
    worker.run()

# Generated at 2022-06-20 14:34:38.969658
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Initialize empty class on which the method is tested
    worker_process = WorkerProcess(None,{'a':'b'},'host','task','play_context',None,None,None)

    # Check worker_process._run return value
    assert(worker_process._run() is None)


if __name__ == "__main__":
    test_WorkerProcess_run()

# Generated at 2022-06-20 14:34:53.397354
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Test if all attrs are initialized of class WorkerProcess
    final_q = {}
    task_vars = {}
    host = {}
    task = {}
    play_context = {}
    loader = {}
    variable_manager = {}
    shared_loader_obj = {}
    wp = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert final_q == wp._final_q
    assert task_vars == wp._task_vars
    assert host == wp._host
    assert task == wp._task
    assert play_context == wp._play_context
    assert loader == wp._loader
    assert variable_manager == wp._variable_manager
    assert shared_loader_obj == wp._shared_loader

# Generated at 2022-06-20 14:34:55.690885
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    obj = WorkerProcess(None, None, None, None, None, None, None, None)
    assert not obj is None