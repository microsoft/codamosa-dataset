

# Generated at 2022-06-20 14:26:00.917285
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # tested by integration tests
    # TODO: bring back tests for this
    pass

# Generated at 2022-06-20 14:26:10.008975
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import queue
    import sys
    import os, os.path
    import multiprocessing
    import tempfile
    import shutil
    import stat
    import pdb
    import traceback
    import jinja2
    import ansible.constants as C
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

# Generated at 2022-06-20 14:26:21.224675
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Unittest for constructor of class WorkerProcess
    # We need to mockup some data for the constructor of WorkerProcess

    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()

    wp = WorkerProcess(
        final_q, task_vars,
        'hostname', task,
        play_context, loader,
        variable_manager,
        shared_loader_obj
    )

    assert wp._final_q == final_q
    assert wp._task_vars == task_vars
    assert wp._host == 'hostname'
    assert wp._task == task

# Generated at 2022-06-20 14:26:24.618472
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    multiprocessing_context.worker_process = WorkerProcess

# Generated at 2022-06-20 14:26:34.949888
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Test case 1
    # Check if it works properly when completed the task
    # (when the execution results of the task reach the client)

    # the execution results of the task reach the client
    def send_task_result(host_name, task_uuid, task_result, task_fields):
        assert host_name == 'host1'
        assert task_uuid == 'uuid1'
        assert task_result['stdout'] == 'output1'
        assert task_fields['task_name'] == 'task1'

    # the queue object for task execution results
    class TestFinalQueue:

        def __init__(self):
            pass


# Generated at 2022-06-20 14:26:35.563295
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-20 14:26:42.918803
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Build up a task result queue for testing
    class FinalQueueDummy():
        def send_task_result(self, host, uuid, result, task_fields):
            pass
    final_q = FinalQueueDummy()
    task_vars = dict()
    host = '127.0.0.1'
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()

    test_worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert isinstance(test_worker, multiprocessing_context.Process)

# Generated at 2022-06-20 14:26:49.024921
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import callback_loader

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    final_q = multiprocessing_context.SimpleQueue()
    results_q = multiprocessing_context.SimpleQueue()
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

# Generated at 2022-06-20 14:26:56.233995
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    """
    Test WorkerProcess.start
    """

    def add_mock_queue():
        setattr(multiprocessing_context, 'Queue', MockQueue)

    def del_mock_queue():
        delattr(multiprocessing_context, 'Queue')

    def add_mock_process():
        setattr(multiprocessing_context, 'Process', MockProcess)

    def del_mock_process():
        delattr(multiprocessing_context, 'Process')

    task = dict()

    task_vars = dict()
    task_vars["vars"] = dict()
    task_vars["vars"]["ansible_ssh_user"] = 'root'
    task_vars["vars"]["ansible_ssh_pass"] = 'password'


# Generated at 2022-06-20 14:27:04.616251
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import JoinableQueue
    q = JoinableQueue()
    task_vars = {}
    host = {}
    task = {}
    play_context = {}
    loader = {}
    variable_manager = {}
    shared_loader_obj = {}
    t = WorkerProcess(q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    try:
        t.start()
    finally:
        t.join()
    assert t.exitcode == 0


# Generated at 2022-06-20 14:27:22.898860
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue

    display.verbosity = 3
    final_q = Queue()
    task_vars = dict()
    host = dict(name="localhost")
    task = dict(_uuid="foo")
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()

    wp = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    wp.start()
    wp.join(0.1)
    assert not wp.is_alive()



# Generated at 2022-06-20 14:27:24.053649
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass


# Generated at 2022-06-20 14:27:34.258088
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():

    import multiprocessing

    # multiprocessing.Queue
    final_q = multiprocessing.Queue()
    # dict
    task_vars = dict()
    # AnsibleHost
    host = None
    # Task
    task = None
    # PlayContext
    play_context = None
    # DataLoader
    loader = None
    # VariableManager
    variable_manager = None
    # AnsibleLoader
    shared_loader_obj = None

    test = WorkerProcess(
        final_q,
        task_vars,
        host,
        task,
        play_context,
        loader,
        variable_manager,
        shared_loader_obj
    )

    assert final_q == test._final_q
    assert task_vars == test._task_vars
    assert host == test._host


# Generated at 2022-06-20 14:27:44.017897
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.vars import VariableManager

    try:
        import multiprocessing
        mp_context = multiprocessing.get_context('fork')
    except ImportError:
        mp_context = None

    hosts = ['localhost']
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_vars': {'foo': 'bar'}}
    loader = module_loader._find_plugin(None, 'ping')

# Generated at 2022-06-20 14:27:54.884026
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    """
    Test the constructor of class WorkerProcess
    """

    # Create worker process with no parameters
    workerprocess = WorkerProcess()
    # Test that the final_q variable is None
    assert workerprocess._final_q is None, "final_q variable is not None"
    # Test that the task_vars variable is None
    assert workerprocess._task_vars is None, "task_vars variable is not None"
    # Test that the host variable is None
    assert workerprocess._host is None, "host variable is not None"
    # Test that the task variable is None
    assert workerprocess._task is None, "task variable is None"
    # Test that the play_context variable is None
    assert workerprocess._play_context is None, "play_context variable is not None"
    # Test that the loader variable is None

# Generated at 2022-06-20 14:28:06.966992
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    import unittest
    import mock

    class TestWorkerProcess(WorkerProcess):
        def __init__(self, final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj):
            super(TestWorkerProcess, self).__init__(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

        def _run(self):
            assert False, "_run() should not be called, we're just testing _save_stdin()"

    class TestDisplay(Display):

        def __init__(self):
            self.debug_called = False

        def debug(self, msg):
            self.debug_called = True

    class TestIO(object):
        def __init__(self):
            self

# Generated at 2022-06-20 14:28:10.695548
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    q = multiprocessing.Queue()
    p = WorkerProcess(q, {}, 'localhost', 'test', 'context', 'loader', 'variable_manager')
    p.start()
    p.join()

# Generated at 2022-06-20 14:28:19.024008
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue, cpu_count
    _final_q = Queue(cpu_count)
    _task_vars = dict(a_variable='a_value')
    _host = 'host'
    _task = dict(action=dict(module='ping'))
    _play_context = dict(remote_addr=None)
    _loader = 'loader'
    _variable_manager = 'variable_manager'
    _shared_loader_obj = 'shared_loader_obj'
    worker_process = WorkerProcess(_final_q, _task_vars, _host, _task, _play_context, _loader, _variable_manager, _shared_loader_obj)

    assert worker_process._final_q == _final_q
    assert worker_process._task_vars == _task_vars
   

# Generated at 2022-06-20 14:28:28.584810
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    '''
    Basic tests when workers are not started
    '''
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # We need a queue prepared for the worker, so we create a TaskQueueManager
    # here and instead of queuing the task to it, we create a result queue
    # by calling get_result_queue()
    worker_queue_manager = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=False,
        forks=5,
    )
    host = 'fake_host'

# Generated at 2022-06-20 14:28:34.125920
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    from multiprocessing import Queue
    from queue import Empty
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    class MyHandler(Handler):
        def __init__(self, my_var=None):
            self.my_var = my_var

# Generated at 2022-06-20 14:28:56.438952
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        from multiprocessing import Queue
        from multiprocessing import JoinableQueue
    except ImportError:
        from multiprocessing import Queue

    class QueueToQueue(object):
        def __init__(self, queue):
            self.queue = queue

        def send_task_result(self, host, task_uuid, result, task_fields):
            self.queue.put((host, task_uuid, result, task_fields))

    def run_in_worker(final_q):
        WorkerProcess(
            final_q,
            {},
            'localhost',
            {'action': {'module': 'setup'}},
            {},
            None,
            None,
            None
        ).start()

    # case 1:  queue.qsize() > 0

# Generated at 2022-06-20 14:29:10.137443
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible import constants as C
    from ansible.vars.manager import VariableManager

    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    host = "localhost"
    task = dict(action="shell echo hello world")
    play_context = dict(remote_user="root", become_user="become_user", become=True, become_method='sudo')
    loader = None
    variable_manager = VariableManager()
    shared_loader_obj = None
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    assert worker._final_q == final_q
    assert worker._task_vars == task_vars
    assert worker._host == host
    assert worker._task == task

# Generated at 2022-06-20 14:29:21.194455
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue
    task_vars_for_host = {'host_vars': 'host_vars'}
    test_host = {}
    test_task = {}
    test_play_context = {}
    test_loader = {}
    test_variable_manager = {}
    test_shared_loader_obj = {}
    wp = WorkerProcess(Queue(), task_vars_for_host, test_host, test_task, test_play_context, test_loader, test_variable_manager, test_shared_loader_obj)
    assert wp
    assert wp._final_q
    assert wp._task_vars == task_vars_for_host
    assert wp._host == test_host
    assert wp._task == test_task
    assert wp._play_context

# Generated at 2022-06-20 14:29:27.511470
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # command line arguments
    args = {}

    # test variables
    task = args['task'] = dict(name='test')
    inventory = args['inventory'] = dict(hosts='localhost')
    args['connection'] = 'local'
    args['forks'] = 1
    args['become'] = False
    args['become_method'] = None
    args['become_user'] = None
    args['verbosity'] = 5
    args['check'] = False
    args['start_at_task'] = None
    args['diff'] = False
    args['extra_vars'] = []
    args['passwords'] = dict()
    args['datacenter'] = None
    args['ssh_common_args'] = ""
    args['sftp_extra_args'] = ""

# Generated at 2022-06-20 14:29:28.125321
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    pass

# Generated at 2022-06-20 14:29:38.386841
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Build inventory
    test_inventory = InventoryManager(loader=DataLoader())
    test_inventory.add_host('testgroup', 'testhost')

    # Build play

# Generated at 2022-06-20 14:29:50.349989
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    final_q = None
    task_vars = None
    host = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None
    print("test_WorkerProcess:\n")
    task_name = 'setup'
    action = dict(module=task_name)
    test_task = dict(action=action, register='test_result')
    test_worker = WorkerProcess(final_q, task_vars, host, test_task, play_context, loader, variable_manager, shared_loader_obj)
    test_worker.start()
    test_worker.join()

# Generated at 2022-06-20 14:30:02.827835
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    multiprocessing_context.initialize_manager_connection()

    # add TaskQueueManager class to namespace for pickling
    def test_TaskQueueManager():
        class TestTaskQueueManager:
            def __init__(self):
                self.task_status_q = multiprocessing_context.Queue()
                self.task_result_q = multiprocessing_context.Queue()

            def send_task_status(self, host, task):
                self.task_status_q.put(dict(host=host, task=task))

            def send_task_result(self, host, task, result):
                self.task_result_q.put(dict(host=host, task=task, result=result))

        return TestTaskQueueManager()


    # add task class to namespace for pickling

# Generated at 2022-06-20 14:30:10.217408
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from multiprocessing import JoinableQueue, Event
    from queue import Queue
    from ansible.module_utils.facts import get_facts

    display.verbosity = 3

# Generated at 2022-06-20 14:30:14.221079
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    Unit test code for the start() method of class WorkerProcess.
    '''
    worker_process = WorkerProcess(None, None, None, None, None, None, None, None)
    assert worker_process is not None

# Generated at 2022-06-20 14:31:02.481856
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # This test is used to ensure that the run() method
    # is executed remotely and does not throw an exception.

    class TestQueue(object):
        def __init__(self):
            self.sent_task_results = []

        def send_task_result(self, hostname, task_uuid, result, task_fields=None):
            self.sent_task_results.append(result)

    class TestHost(object):
        pass

    class TestTask(object):
        def __init__(self):
            self.args = {}
            self.vars = {}

    class TestVariableManager(object):
        def __init__(self):
            self.extra_vars = {}

    queue = TestQueue()
    host = TestHost()
    task = TestTask()
    play_context = PlayContext()
    loader

# Generated at 2022-06-20 14:31:09.218837
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    task_vars = {}
    host = 'test_host'
    task = lambda: None
    play_context = {}
    loader = lambda: None
    variable_manager = {}
    shared_loader_obj = {}

    final_q = multiprocessing.Queue()

    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker.start()
    worker.join()

# Generated at 2022-06-20 14:31:21.725870
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    from collections import namedtuple
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    host = inventory.get_host("localhost")

    class myTaskExecutor(object):
        def run(self):
            return namedtuple("result", ["task_result"])(task_result=dict(changed=False, stdout=b"Hello World"))

    class myFinalQueue(object):

        class sentinel(object):
            pass

        def __init__(self):
            self.s = None
            self.q = multiprocessing.Queue()


# Generated at 2022-06-20 14:31:23.312950
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Cannot test without network access; see #18674
    pass

# Generated at 2022-06-20 14:31:24.047444
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    pass

# Generated at 2022-06-20 14:31:32.698254
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Test with fake connection, task, loader and variable_manager
    final_q = multiprocessing_context.SimpleQueue()
    task_vars = {}
    host = 'localhost'
    task = 'TestTask'
    play_context = 'TestPlayContext'
    loader = 'TestLoaderClass'
    variable_manager = 'TestVariableManager'
    shared_loader_obj = 'TestSharedLoaderObj'
    worker = WorkerProcess(
        final_q, task_vars, host, task, play_context, loader,
        variable_manager, shared_loader_obj)
    assert final_q == worker._final_q
    assert task_vars == worker._task_vars
    assert host == worker._host
    assert task == worker._task
    assert play_context == worker._play_context
    assert loader == worker

# Generated at 2022-06-20 14:31:38.237800
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    display = Display()
    final_q = multiprocessing_context.Queue()
    task_vars = {}
    host = {}
    task = {}
    play_context = {}
    variable_manager = {}
    shared_loader_obj = {}

    w = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    w.run()

# Generated at 2022-06-20 14:31:47.604055
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # TODO: this unit test only tests that WorkerProcess.run() returns zero
    #       when the task was successfully executed.
    #       This test should be extended to test a failed execution.
    #       For example using the 'debug' module with the following task:
    #       - debug: msg="{{ 1 + '2' }}"
    #       This will raise an exception.

    # import units as units # imported here to avoid recursive import of
    #                        # test_WorkerProcess_run in units
    # import multiprocessing
    # import PlayContext
    # import PlayBookResults
    from units.mock.loader import DictDataLoader

    # prepare the variables that are passed to the WorkerProcess
    mock_q = multiprocessing.Queue()

# Generated at 2022-06-20 14:31:49.538042
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    raise NotImplementedError

# Generated at 2022-06-20 14:31:58.260008
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import callback_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_