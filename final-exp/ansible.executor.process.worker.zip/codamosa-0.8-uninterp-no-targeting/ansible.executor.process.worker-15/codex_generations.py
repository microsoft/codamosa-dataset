

# Generated at 2022-06-20 14:26:01.685550
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    """Unit test for ansible.executor.worker_process.WorkerProcess.run()
    """
    # FIXME: add test
    pass

# Generated at 2022-06-20 14:26:16.835068
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    class FinalQueue(object):
        def send_task_result(self, host, task_uuid, result, task_fields={}):
            pass

    try:
        host = "dummy_host"
        task = "dummy_task"
        play_context = "dummy_play_context"
        loader = "dummy_loader"
        final_q = FinalQueue()
        task_vars = dict()
        variable_manager = "dummy_variable_manager"
        shared_loader_obj = "dummy_shared_loader_obj"

        wp = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
        wp.run()
        assert(True)
    except:
        assert(False)

# Generated at 2022-06-20 14:26:26.329050
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    from ansible.executor.stats import AggregateStats
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars

    queue = multiprocessing.Queue()
    stats = AggregateStats()
    play_context = PlayContext()
    inventory = 'inventory/hosts'
    loader = None
    variable_manager = None

    task_vars = combine_vars(loader, variable_manager, 'examples', play_context)

    display.debug("test_WorkerProcess: task_vars = %s" % task_vars)

    #host = None
    #task = None

    #WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj

# Generated at 2022-06-20 14:26:27.085794
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    pass

# Generated at 2022-06-20 14:26:37.563798
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    final_q = multiprocessing.Queue()
    task_vars = dict()
    host = dict()
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()
    
    worker_process = WorkerProcess(
        final_q,
        task_vars,
        host,
        task,
        play_context,
        loader,
        variable_manager,
        shared_loader_obj
    )

if __name__ == '__main__':
    test_WorkerProcess()

# Generated at 2022-06-20 14:26:44.889549
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars

    my_vars = dict()
    my_vars['hostvars'] = dict()
    my_vars['hostvars']['127.0.0.1'] = dict()
    my_vars['hostvars']['127.0.0.1']['ansible_connection'] = 'local'

# Generated at 2022-06-20 14:26:45.878392
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    pass

# Generated at 2022-06-20 14:26:57.553433
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    import multiprocessing

    class FakeQueue():

        def __init__(self):
            self.queue = multiprocessing.Queue()

        def send_task_result(self, host, uuid, result, task_fields=None, host_fields=None):
            self.queue.put(result)

        def get(self):
            return self.queue.get()

        def put(self, value):
            self.queue.put_nowait(value)

    class FakeTask():

        def __init__(self):
            self.tags = []
            self.when = []
            self.name = ""
            self.notify = []

        def _load_attr_from_yaml(self, data):
            pass

        def copy(self):
            pass

        def serialize(self):
            return ""



# Generated at 2022-06-20 14:27:08.848972
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing

    class FakeLoader(object):
        def __init__(self):
            self._tempfiles = []

        def set_basedir(self, basedir):
            self._basedir = basedir

        def path_exists(self, path):
            return True

        def add_temporary_file(self, path):
            self._tempfiles.append(path)

        def cleanup_all_tmp_files(self):
            self._tempfiles = []

    fake_loader = FakeLoader()
    fake_loader.set_basedir('/foo')

    task = dict(name='task name', args={}, async_val=45, poll=0)
    final_q = multiprocessing.Queue()
    shared_loader_obj = multiprocessing.Manager().Namespace()

# Generated at 2022-06-20 14:27:21.984719
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    import tempfile
    import shutil
    import multiprocessing
    import time

    class TestFinalQ(object):

        def __init__(self, *args, **kwargs):
            self.host = None
            self.uuid = None
            self.result = None
            self.task_fields = None

        def send_task_result(self, host, uuid, result, task_fileds):
            self.host = host
            self.uuid = uuid
            self.result = result

    class TestHost(object):

        def __init__(self, *args, **kwargs):
            self.name = 'localhost'

    class TestTask(object):

        def __init__(self, *args, **kwargs):
            if args:
                self.action = args[0]

# Generated at 2022-06-20 14:27:41.963320
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue
    from ansible.utils.loader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    empty_q = Queue()

    test_play = dict(
        name='test_play',
        hosts='all',
        gather_facts='no',
        tasks=[ dict(action=dict(module='setup')) ]
    )

    loader = DataLoader()
    inventory = InventoryManager(loader, 'localhost')
    variable_manager = VariableManager(loader, inventory)

    host = inventory.hosts['localhost']

    w = WorkerProcess(empty_q, dict(), host, test_play['tasks'][0], dict(), loader, variable_manager, None)
    s = w.start()
    # should not be needed but just

# Generated at 2022-06-20 14:27:52.922978
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    import time

    # Create two queues
    final_queue = multiprocessing.Queue()
    task_queue = multiprocessing.Queue()

    # Create a worker
    worker = WorkerProcess(
        task_queue=task_queue,
        final_queue=final_queue
    )

    # Start the worker
    worker.start()

    # Wait for a second for it to process the queue
    time.sleep(1)

    # Put something on the task queue
    task_queue.put('test')

    # Wait for a second for the queue to get processed
    time.sleep(1)

    # We should have something on the queue now
    assert not task_queue.empty()

    # Terminate the worker
    worker.terminate()

# Generated at 2022-06-20 14:28:06.919546
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from queue import Queue
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import add_all_plugin_dirs

    # prepare the docker connection
    import docker
    docker_client = docker.from_env()
    docker_client.containers.run('alpine', 'sh', detach=True, remove=True)

    # prepare the objects for WorkerProcess

# Generated at 2022-06-20 14:28:18.290614
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import JoinableQueue
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    final_q = JoinableQueue()

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = None

    play_context = Play()
    host = inventory.get_host('localhost')
    host.vars = {'ansible_connection': 'local'}

    task_vars = variable_manager.get_vars(host=host, task=None)
    play_context.network_os = 'default'

# Generated at 2022-06-20 14:28:28.289269
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from queue import Queue
    from ansible.utils.vars import combine_vars

    fake_loader = None
    fake_variable_manager = None
    fake_shared_loader_obj = None

    fake_task = dict(
        action='fake_task',
    )

    fake_host1 = dict(
        name='fake_host1',
        vars=dict(
            ansible_connection='local',
            ansible_host=None
        )
    )

    fake_host2 = dict(
        name='fake_host2',
        vars=dict(
            ansible_connection='local',
            ansible_host=None
        )
    )


# Generated at 2022-06-20 14:28:34.617421
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    q = multiprocessing.Queue()
    task_vars = {}
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None
    w = WorkerProcess(q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    # Test default run
    print("***Test default run***")
    try:
        w.start()
    except Exception as e:
        print("error: {}".format(e))
    w.join()
    # Test run with bad task name
    print("***Test run with bad task name***")
    task = "fail_task"
    q = multiprocessing.Queue()

# Generated at 2022-06-20 14:28:41.342758
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue
    final_q = Queue()
    task_vars = dict(hostvars=dict())
    host = 'localhost'
    task = dict(action=dict(module='setup'))
    play_context = dict()
    loader = None
    variable_manager = None
    shared_loader_obj = None

    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker.start()
    worker.join()
    assert worker._new_stdin.closed

if __name__ == '__main__':
    test_WorkerProcess()

# Generated at 2022-06-20 14:28:50.551042
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.executor.queue_manager import FinalQueue
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Setup for the unit test
    test_final_q = FinalQueue()
    test_task_vars = {}
    test_host = "localhost"
    test_task = "Test"
    test_play_context = "Test"
    test_loader = DataLoader()
    test_variable_manager = VariableManager()
    test_shared_loader_obj = "Test"

    # Unit test
    worker = WorkerProcess(test_final_q, test_task_vars, test_host, test_task, test_play_context, test_loader, test_variable_manager, test_shared_loader_obj)

    assert worker._final_

# Generated at 2022-06-20 14:29:02.516847
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # Setup a queue
    final_q = multiprocessing_context.Queue()

    task_vars = dict()
    host = 'dummy_host'
    task = dict()
    play_context = 'dummy_play_context'
    loader = 'dummy_loader'
    variable_manager = 'dummy_variable_manager'
    shared_loader_obj = 'dummy_shared_loader_obj'

    # Start a WorkerProcess object
    worker_process = WorkerProcess(
        final_q,
        task_vars,
        host,
        task,
        play_context,
        loader,
        variable_manager,
        shared_loader_obj)
    worker_process.start()

    # Test if the process exists
    assert worker_process.is_alive() == True

    # Stop the process

# Generated at 2022-06-20 14:29:05.888524
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    return

# Generated at 2022-06-20 14:29:27.512915
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    class QueueMock:
        def __init__(self):
            self.val = None
        def send_task_result(self, *args, **kwargs):
            self.val = (args, kwargs)
    
    final_q = QueueMock()
    task_vars = {}
    host = '127.0.0.1'
    task = {}
    play_context = {}
    loader = {}
    variable_manager = {}
    shared_loader_obj = {}
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker.start()
    worker.join()

# Generated at 2022-06-20 14:29:28.125458
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    pass

# Generated at 2022-06-20 14:29:34.274512
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue

    final_q = Queue()
    task_vars = {}
    host = "host1"
    task = "task1"
    play_context = {}
    loader = None
    variable_manager = None
    wp = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, None)
    wp.start()

# Generated at 2022-06-20 14:29:42.203163
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue
    import ansible.playbook.play
    from ansible.vars.manager import VariableManager

    class DummyTask():
        def __init__(self, uuid):
            self._uuid = uuid

        def __repr__(self):
            return "TASK(%s)" % self._uuid

        def dump_attrs(self):
            return dict(
                uuid=self._uuid
            )

    class DummyQueue():
        def __init__(self):
            self.q = []

        def send_task_result(self, host, uuid, result, task_fields=None):
            self.q.append({
                'host': host,
                'uuid': uuid,
                'result': result
            })


# Generated at 2022-06-20 14:29:43.031878
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Generated at 2022-06-20 14:29:45.507032
# Unit test for method start of class WorkerProcess

# Generated at 2022-06-20 14:29:58.128909
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = variable_manager.get_inventory(loader.load_from_file('/Users/ansible/ansible/inventory'))
    play_context = PlayContext()

# Generated at 2022-06-20 14:30:09.346716
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    results_q = multiprocessing_context.Queue()
    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    task_vars['hostvars'] = dict()
    task_vars['hostvars']['localhost'] = dict()
    task_vars['hostvars']['localhost']['ansible_connection'] = 'local'
    host = multiprocessing_context.SimpleNamespace()
    host.name = 'localhost'
    play_context = multiprocessing_context.SimpleNamespace()
    play_context.connection = 'local'
    task = multiprocessing_context.SimpleNamespace()
    task._uuid = 'abcd'
    task.tasks = dict()


# Generated at 2022-06-20 14:30:09.864954
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-20 14:30:19.859326
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    def run(*args):
        pass
    WorkerProcess.run = run
    multiprocessing_context.Process.start = run
    multiprocessing_context.Process.is_alive = lambda *args: None
    multiprocessing_context.Process.join = lambda *args: None

    final_q = "final_q"
    task_vars = {"foo": "bar"}
    host = "host"
    task = "task"
    play_context = "play_context"
    loader = "loader"
    variable_manager = "variable_manager"
    shared_loader_obj = "loader_obj"

    # Check required parameters are given
    with pytest.raises(TypeError):
        WorkerProcess()

    # Create a WorkerProcess object

# Generated at 2022-06-20 14:30:53.006712
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    pass

if __name__ == '__main__':
    test_WorkerProcess()

# Generated at 2022-06-20 14:31:05.921600
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    ######
    # This test is slow to run, so we only run it by explicit request
    if os.getenv('TEST_WORKER_RUN', '0') == '1':
        pass
    else:
        sys.exit(0)
    ######
    from multiprocessing import Queue
    from ansible.playbook.play_context import PlayContext

    # Add the library to the loader path to ensure it can be imported.
    import sys
    import os
    import tempfile
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    from ansible.plugins.loader import module_loader

    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Create a task that uses a Linux command.


# Generated at 2022-06-20 14:31:12.991929
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    class MockHost():
        def __init__(self, name):
            self.name = name
            self.groups = []
            self.vars = {}

    class MockTask():
        def __init__(self, uuid, action):
            self._uuid = uuid
            self._attributes = dict(action=action)

        def dump_attrs(self):
            return self._attributes

    class MockFinalQueue():
        def __init__(self):
            self.results = []
        def close(self):
            pass
        def put(self, item):
            self.results.append(item)
        def send_task_result(self, host, uuid, result, task_fields=None):
            msg = u'Sending result for %s' % (uuid,)


# Generated at 2022-06-20 14:31:24.444506
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.reserved import RESERVED_TASK_NAMES
    from multiprocessing import Queue


# Generated at 2022-06-20 14:31:36.476583
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import json
    import ansible.callbacks
    import ansible.plugins.callback

    class PluginCallback(ansible.plugins.callback.CallbackBase):
        def __init__(self, task_uuid, final_q):
            self.task_uuid = task_uuid
            self.final_q = final_q
            super(PluginCallback, self).__init__()

        def v2_runner_on_ok(self, result):
            self.final_q.put((self.task_uuid, json.dumps(result._result)))

    final_q = multiprocessing_context.Queue()
    callback = PluginCallback('2314', final_q)
    callbacks_manager = ansible.callbacks.PlaybookCallbacksManager(
        callback, [], [], None, None)


# Generated at 2022-06-20 14:31:47.526695
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():

    # Work around expected AnsibleParserError if using problematic path:
    sys.argv = ['ansible', '--version']
    sys.path = ['', '..']

    # Create mock data:
    final_q = None
    task_vars = {'foo': 'bar'}
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None

    # Call unit under test:
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    # Perform assertions:
    assert isinstance(worker, WorkerProcess)
    assert worker._final_q == final_q
    assert worker._task_vars == task_vars
    assert worker._

# Generated at 2022-06-20 14:31:57.639790
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import JoinableQueue
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader

    final_q = JoinableQueue()
    final_q.put('testing')
    loader = DataLoader()
    vault_secrets = VaultLib()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    new_stdin = object()
    host

# Generated at 2022-06-20 14:32:04.196191
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    '''
    Unit test for the constructor of class WorkerProcess
    '''
    wp = WorkerProcess('final_q', 'task_vars', 'host', 'task', 'play_context', 'loader', 'variable_manager', 'shared_loader_obj')
    assert wp

# Generated at 2022-06-20 14:32:04.856147
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    pass

# Generated at 2022-06-20 14:32:05.489057
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print("")

# Generated at 2022-06-20 14:33:14.201142
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader, action_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    # Create task queue manager object
    tqm = TaskQueueManager(
        inventory=dict(),
        variable_manager=dict(),
        loader=dict(),
        options=dict(),
        passwords=dict(),
    )
    # Add something to the shared loader plugin object so it is not empty
    shared_loader_obj = dict()
    shared_loader_obj['foo'] = 'bar'
    task_vars = dict()
    play_context = PlayContext()
    loader = module_loader
    variable_manager = dict()
    host = "fake_host"
    task = dict()
    task['action'] = action_

# Generated at 2022-06-20 14:33:26.649144
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.play
    import ansible.inventory.host
    import ansible.vars.hostvars
    import ansible.vars.manager
    import ansible.utils.queues

    host = ansible.inventory.host.Host(name='testhost')
    host.set_variable('ansible_ssh_pass', 'pass')
    host.set_variable('ansible_ssh_port', '22')
    host.set_variable('ansible_ssh_host', 'host')
    host.set_variable('ansible_ssh_user', 'user')

# Generated at 2022-06-20 14:33:41.851734
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    class Manager():
        def __init__(self):
            self._result_queue = None
            self._task_queue = None
            self._manager = None
            self._task_vars = {}
            self._host = None
            self._task = None
            self._play_context = None
            self._loader = None
            self._final_q = None
            self._shared_loader_obj = None

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    manager = Manager()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {}
    variable_manager._options = None
    variable_manager._vars = {}
    variable_manager._hostvars = {}
    # manager._shared_loader_obj.cleanup

# Generated at 2022-06-20 14:33:50.355304
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    class FakeQueue:
        def __init__(self):
            self.sent = []

        def send_task_result(self, host, uuid, result, task_fields):
            self.sent.append((host, uuid, result, task_fields))

    class FakePlayContext:
        def __init__(self):
            self.name = 'fake_play'
            self.remote_addr = 'fake_remote'
            self.port = 'fake_port'
            self.remote_user = 'fake_user'
            self.become = False
            self.become_method = 'fake_become_method'
            self.become_user = 'fake_become_user'
            self.verbosity = 5
            self.connection = 'fake_connection'

# Generated at 2022-06-20 14:33:55.234900
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    class FinalQueue(object):
        def __init__(self):
            self.task_result = None
            return

        def send_task_result(self, host_name, task_uuid, task_result, task_fields):
            self.task_result = task_result
            return

    class TestHost(object):
        def __init__(self):
            self.vars = {}
            self.groups = []
            return

    class TestTask(object):
        def __init__(self):
            self.dump_attrs = lambda: {}
            return

    # Test case 1: success
    worker1 = WorkerProcess(FinalQueue(), {}, TestHost(), TestTask(), TestHost(), TestHost(), TestHost(), TestHost())
    worker1.run()
    assert worker1._final_q.task_result == {}



# Generated at 2022-06-20 14:34:05.656970
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    import threading
    import Queue
    import errno
    import sys
    import time
    import shutil
    import tempfile
    import multiprocessing

    from ansible.plugins.strategy import StrategyBase
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts import default_collectors

    from ansible.module_utils.facts.collector import FactsCollector

    from ansible.playbook.task import Task

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-20 14:34:09.231300
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    pass

# Generated at 2022-06-20 14:34:16.525350
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    final_q = multiprocessing.Queue()
    task_vars = 'x'
    host = 'x'
    task = 'x'
    play_context = 'x'
    loader = 'x'
    variable_manager = 'x'
    shared_loader_obj = 'x'
    WorkerProcess(final_q, task_vars, host, task, play_context,
        loader, variable_manager, shared_loader_obj)

# Generated at 2022-06-20 14:34:25.658732
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    def handle_task_result(host, task, task_result):
        print(task_result)
        final_q.put(task_result)

    final_q = multiprocessing.Queue()

    task_vars = dict(
        one=1,
        two=2,
        three=3,
        failed=False,
        stdout='',
    )
    host = 'test'
    task = dict(action=dict(module='debug', args=dict(msg='test')))
    play_context = dict(
        become=False,
        become_method='sudo',
        become_user='root',
        check_mode=False,
    )
    loader = None
    variable_manager = None
    shared_loader_obj = None


# Generated at 2022-06-20 14:34:36.977626
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    import multiprocessing_context
    import Queue

    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.utils.display import Display