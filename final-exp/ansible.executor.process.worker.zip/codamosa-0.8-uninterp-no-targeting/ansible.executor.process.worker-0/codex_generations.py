

# Generated at 2022-06-20 14:26:08.481497
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    final_q = multiprocessing_context.Queue()
    task_vars = multiprocessing_context.Manager().dict()
    host = multiprocessing_context.Manager().list()
    task = multiprocessing_context.Manager().list()
    play_context = multiprocessing_context.Manager().list()
    loader = multiprocessing_context.Manager().list()
    variable_manager = multiprocessing_context.Manager().list()
    shared_loader_obj = multiprocessing_context.Manager().list()
    wp = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    print(wp.start())

# Generated at 2022-06-20 14:26:21.730739
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from six.moves import queue
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host

    final_q = queue.Queue()
    task_vars = []
    host = Host(name='testhost')
    task = TaskInclude()
    play_context = PlayContext()
    loader = DataLoader()
    variable_manager = VariableManager

# Generated at 2022-06-20 14:26:26.018332
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 14:26:39.136533
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import ansible.executor.task_executor as task_executor
    import multiprocessing
    import queue
    import time
    import uuid
    import ansible.playbook.play_context as play_context
    import ansible.playbook.play as play
    import ansible.playbook.block as block
    import ansible.playbook.task as task
    import ansible.inventory.host as host
    import ansible.vars.manager as manager
    import ansible.template as template
    import ansible.parsing.dataloader as dataloader
    import ansible.plugins as plugins

    # mock
    def mocked_run_executor():
        # do nothing
        return

    def mocked_send_task_result():
        # do nothing
        return

    task_executor.TaskExec

# Generated at 2022-06-20 14:26:46.906968
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing.queues import Queue
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task

    q = Queue()
    host = Host(name='worker_host')
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = {}
    task = Task()
    task._role = None

    w = WorkerProcess(q, {}, host, task, play_context, loader, variable_manager, loader)
    w.start()
    w.join()

# Generated at 2022-06-20 14:26:58.751427
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    class Mock_final_q:
        def __init__(self):
            self.args = []

        def send_task_result(self, *args):
            self.args.append(args)

    class Mock_host:
        def __init__(self):
            self.name = 'localhost'
            self.vars = {}
            self.groups = []
            self.options = {}
            self.groups = []

    class Mock_task:
        def __init__(self):
            self.name = 'fake_task'
            self.action = 'noop'
            self.action_args = {}
            self.action_args.update(environment=dict(), basedir='/var/lib/awx/projects/_1/library')
            self.args = dict()

# Generated at 2022-06-20 14:27:09.414518
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_context = PlayContext()
    play_context.network_os = 'junos'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'root'
    play_context.remote_addr = '1.1.1.1'
    play_context.remote_user = 'root'

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback='default',
        run_tree=False,
        forks=10,
        play_context=play_context)

    # add new task
    tq

# Generated at 2022-06-20 14:27:22.490424
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    sys.path.append('.')
    from lib.shuffle_list import shuffle_list
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    from ansible.plugins.callback.default import CallbackModule
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block

    queue_name = 'Q_master'
    inventory_name = 'tests/inventory'
    stats = AggregateStats()
    variable_manager = VariableManager()
    loader = DataLoader()

    # Create inventory and pass to var manager
   

# Generated at 2022-06-20 14:27:24.303708
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    display.verbosity = 2
    worker_process = WorkerProcess()
    assert worker_process is not None

# Generated at 2022-06-20 14:27:25.330315
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass


# Generated at 2022-06-20 14:27:36.911144
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # TODO
    pass


# Generated at 2022-06-20 14:27:47.094846
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    This requires an active Eventlet event loop, which implies we need a task queue
    to process.
    '''

    (final_q, _) = multiprocessing_context.get_context().Queue(), multiprocessing_context.get_context().Queue()
    worker_prc = WorkerProcess(final_q,
                               task_vars={},
                               host={}, task={},
                               play_context={}, loader={}, variable_manager={}, shared_loader_obj={})
    worker_prc.start()
    worker_prc.join()

# Generated at 2022-06-20 14:27:56.636509
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    import os
    import shutil
    import tempfile

    # Generate a temporary directory to simulate a playbook directory
    temp_directory = tempfile.mkdtemp()

    # Create a temporary file to simulate the playbook file
    playbook_file_name = tempfile.mkstemp()[1]
    playbook_file = open(playbook_file_name, "w")
    playbook_file.write("---\n- hosts: all\n  tasks: []\n")
    playbook_file.close()

    # Create a temporary file to simulate the inventory file
    inventory_file_name = tempfile.mkstemp()[1]
    inventory_file = open(inventory_file_name, "w")
    inventory_file.write("all:\n")
    inventory_file.write("  children:\n")

# Generated at 2022-06-20 14:27:58.964740
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    workerProcess = WorkerProcess('', '', '', '', '', '', '', '')
    assert workerProcess

# Generated at 2022-06-20 14:28:00.840325
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # FIXME: Need to set up mock objects to do this
    pass


# Generated at 2022-06-20 14:28:01.904961
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass


# Generated at 2022-06-20 14:28:10.535037
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    import ansible.playbook.task
    from ansible.executor.task_queue_manager import TaskQueueManager

    task_vars = dict()

    localhost = '127.0.0.1'
    task = ansible.playbook.task.Task()
    task._role = None
    task.args['print'] = 'hello world'
    task_fields = task.dump_attrs()

    task_queue_manager = TaskQueueManager()
    worker_process = WorkerProcess(
        task_queue_manager.result_q,
        task_vars,
        localhost,
        task,
        task_queue_manager.play_context,
        task_queue_manager.loader,
        task_queue_manager.variable_manager,
        task_queue_manager._shared_loader_obj,
    )
   

# Generated at 2022-06-20 14:28:14.312546
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    '''
    WorkerProcess constructor
    '''

    workerprocess = WorkerProcess

# Generated at 2022-06-20 14:28:25.744354
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    test_final_q = multiprocessing_context.Queue()
    test_task_vars = dict()
    test_host = "test_host"
    test_task = "test_task"
    test_play_context = dict()
    test_loader = dict()
    test_variable_manager = dict()
    test_shared_loader_obj = dict()

    worker_process = WorkerProcess(test_final_q, test_task_vars, test_host, test_task, test_play_context, test_loader, test_variable_manager, test_shared_loader_obj)

    assert worker_process._final_q == test_final_q
    assert worker_process._task_vars == test_task_vars
    assert worker_process._host == test_host
    assert worker_process._task == test

# Generated at 2022-06-20 14:28:31.988531
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import time
    import threading
    import multiprocessing
    import multiprocessing.queues

    class TestWorkerProcess(WorkerProcess):
        def __init__(self, *args, **kwargs):
            super(TestWorkerProcess, self).__init__(*args, **kwargs)

        def _run(self):
            super(TestWorkerProcess, self)._run()
            return True

    class TestFinalQ(multiprocessing.queues.Queue):
        def __init__(self, *args, **kwargs):
            super(TestFinalQ, self).__init__(*args, **kwargs)
            self.results = []

        def _get(self, *args, **kwargs):
            output = super(TestFinalQ, self)._get(*args, **kwargs)
           

# Generated at 2022-06-20 14:29:00.316868
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # These are needed to complete initialization of WorkerProcess, so they are defined here
    class mock_shared_loader_obj:
        def __init__(self):
            self.basedir = None
    class mock_loader:
        def __init__(self):
            self._tempfiles = set()
        def cleanup_all_tmp_files(self):
            pass
    class mock_play_context:
        def __init__(self):
            self.connection = 'ssh'
            self.remote_addr = '127.0.0.1'
            self.timeout = 10
            self.shell = '/bin/sh -c'
            self.remote_user = 'test'
            self.password = 'password'
            self.port = 22
            self.private_key_file = None
            self.become = False
            self

# Generated at 2022-06-20 14:29:11.310454
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import multiprocessing
    final_q = multiprocessing.Queue()
    task_vars = dict()
    host = "localhost"
    task = "test-task"
    play_context = "test-context"
    loader = "test-loader"
    variable_manager = "test-variable-manager"
    shared_loader_obj = "test-shared-loader"

    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert final_q == worker._final_q
    assert task_vars == worker._task_vars
    assert host == worker._host
    assert task == worker._task
    assert play_context == worker._play_context
    assert loader == worker._loader
    assert variable_manager == worker._

# Generated at 2022-06-20 14:29:14.481234
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    worker = WorkerProcess('final_queu', 'task_vars', 'host', 'task', 'play_context', 'loader', 'variable_manager', 'shared_loader_obj')
    assert worker is not None

# Generated at 2022-06-20 14:29:21.379988
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars
    from multiprocessing import Queue
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import fragment_loader
    from ansible.executor.process.result import TaskResult

    test_hosts = ["localhost"]
    test_loader = DataLoader

# Generated at 2022-06-20 14:29:26.302321
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from collections import namedtuple
    from multiprocessing import Queue
    from ansible.playbook.play_context import PlayContext


# Generated at 2022-06-20 14:29:37.418191
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # multiprocessing uses start method that replaces stdin with a file,
    # we wish to preserve it if it is connected to a terminal
    # so prior to calling the real start, we dup a copy to ensure the descriptor
    # is preserved somewhere in the new child, and make sure it is closed in
    # the parent after start completes.
    import os
    import sys
    import fcntl
    import subprocess

    def child_code():
        import sys
        import os
        import time
        import fcntl

        time.sleep(1)
        devnull = open(os.devnull, 'w')
        os.dup2(devnull.fileno(), 1)
        os.dup2(devnull.fileno(), 2)
        print('stdout')

# Generated at 2022-06-20 14:29:42.721984
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # init the class
    class TaskExecutorDummy():
        def __init__(self):
            self.something = True

    class QueueDummy():
        def __init__(self):
            self.something = True

    class TaskDummy():
        def __init__(self):
            self.something = True

    class PlayContextDummy():
        def __init__(self):
            self.something = True

    class HostDummy():
        def __init__(self):
            self.something = True

    class VariableManagerDummy():
        def __init__(self):
            self.something = True

    class LoaderDummy():
        def __init__(self):
            self.something = True

    task_executor = TaskExecutorDummy()
    queue = QueueDummy()
    task = Task

# Generated at 2022-06-20 14:29:55.384821
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import queue
    import json
    global_vars = {"host_vars" : {"host_variable": "host_value"}}
    task_vars = {"task_variable" : "task_value"}
    task_vars.update(global_vars)
    inventory = {"_meta" : {"hostvars" : { "127.0.0.1" : { "inventory_variable" : "inventory_value"}}}}
    final_q = queue.Queue()
    task_vars.update(inventory["_meta"]["hostvars"]["127.0.0.1"])
    task_vars.update(inventory)
    task_vars.pop("_meta")
    host = "127.0.0.1"
    task = {}
    play_context = {}
    loader = None


# Generated at 2022-06-20 14:29:59.228474
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    with multiprocessing_context.Manager() as m:
        final_q = m.Queue(1)
        workerProcess = WorkerProcess(final_q, dict(), "", "", "", "", "", "")
        workerProcess.start()
        workerProcess.join()

if __name__ == "__main__":
    test_WorkerProcess()

# Generated at 2022-06-20 14:30:05.698669
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # Create a WorkerProcess object
    final_q = multiprocessing_context.Queue()
    task_vars = {}
    host = "localhost"
    task = "test"
    play_context = "test_play_context"
    loader = "test_loader"
    variable_manager = "test_variable_manager"
    shared_loader_obj = "test_shared_loader_obj"
    wp = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    import multiprocessing

    # Create a start method to raise an exception, and assert that the exception
    # is not caught in the method run of the WorkerProcess class
    def start():
        raise Exception("Start Exception")

    wp.start = start

# Generated at 2022-06-20 14:30:47.041833
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.executor.process.worker import WorkerProcess

    import multiprocessing

    final_q = multiprocessing.Queue()
    task_vars = dict()
    fake_loader = DataLoader()
    play_context = dict()
    inventory = InventoryManager(loader=fake_loader, sources='localhost,')
    variable_manager = VariableManager(loader=fake_loader, inventory=inventory)

# Generated at 2022-06-20 14:30:47.620378
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Generated at 2022-06-20 14:31:02.482272
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    # Create the Queue used by the TaskExecutor class to send results back
    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    host = 'host1'
    task = 'task1'
    play_context = dict()
    loader = 'loader1'
    variable_manager = 'variable_manager1'
    shared_loader_obj = dict()

    w = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert w.final_q == final_q
    assert w.task_vars == task_vars
    assert w.host == host
    assert w.task == task
    assert w.play_context == play_context
    assert w.loader == loader
    assert w.variable

# Generated at 2022-06-20 14:31:11.216702
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Mock call to final_q.send_task_result
    def mock_qsend_task_result(host, task_uuid, vdict, task_fields={}):
        return True
    # Mock call to executor_result = TaskExecutor.run()
    def mock_executor_run(self):
        return dict(failed=True, msg="")

    # Mock class for final_q
    class MockFinalQ():
        def __init__(self):
            self.send_task_result = mock_qsend_task_result

    # Mock class for TaskExecutor
    class MockTaskExecutor():
        def __init__(self):
            self.run = mock_executor_run

    # Create mock objects
    fq = MockFinalQ
    tsk = MockTaskExecutor

# Generated at 2022-06-20 14:31:22.456060
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from ansible.playback.play_context import PlayContext
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    loader = DataLoader()
    variable_manager = VariableManager()
    task1 = {}
    shared_loader_obj = None
    final_q = TaskQueueManager(variable_manager)
    task_vars = {}
    host = 'test_host'
    task = 'test_task'
    play_context = PlayContext()


# Generated at 2022-06-20 14:31:31.937615
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    Test to make sure workerprocess start method correclty forks
    and dupes stdin
    '''

    # Create fake stdin and fd, and mock out the os functions needed to
    # test WorkerProcess
    class stdin():
        isatty = True

    fd = 1
    stdin.fileno = lambda s: fd
    duped_fd = 2
    open_fd = 3
    opens = []  # Remember what file handles were opened
    def dup(fd):
        assert fd == fd
        return duped_fd
    def fdopen(new_fd):
        assert new_fd == duped_fd
        return open_fd
    def close_fd(fd):
        opens.remove(fd)
    os.dup = dup
    os.fdopen = fdopen

# Generated at 2022-06-20 14:31:37.168659
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
   data = {'var1': 'val1'}
   final_q = multiprocessing_context.Queue()
   task_vars = multiprocessing_context.Manager().dict()
   host = u'localhost'
   task = None
   play_context = None
   loader = None
   variable_manager = None
   shared_loader_obj = None

   worker = WorkerProcess(final_q, data, host, task, play_context, loader, variable_manager, shared_loader_obj)
   assert worker

# Generated at 2022-06-20 14:31:39.729380
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Test WorkerProcess.start()
    pass


# Generated at 2022-06-20 14:31:48.310452
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Process
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.modules.test import ping
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    inv_obj = InventoryManager(loader=DataLoader())
    pb = Play()
    pb.connection = 'local'
    pb.hosts = [u'localhost']

# Generated at 2022-06-20 14:31:57.769578
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import queue
    import unittest

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar

    class TestStrategyModule(object):
        def __init__(self, tqm, final_q):
            self._final_q = final_q

        def get_host_list(self, host, task):
            return [host]

        def send_task_result(self, host, task_uuid, result, task_fields=None):
            self._final_q.put({host: result})

    class TestHost(object):
        def __init__(self, name):
            self._

# Generated at 2022-06-20 14:33:11.427532
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing.managers import SyncManager
    from ansible.vars import VariableManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.cli.adhoc import AdHocCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    import tempfile

    # Create our inventory
    i = InventoryManager(loader=DataLoader())

    # Create our inventory, and make sure it is empty
    assert i.list_hosts() == []

    # Add group-0 with two hosts
    i.add_group('group-0')

# Generated at 2022-06-20 14:33:26.397547
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    class TestQueue:
        def send_task_result(self, host, uuid, result, task_fields):
            return (host, uuid, result, task_fields)
    final_q = TestQueue()
    task_vars = {}
    host = 'localhost'
    task = 'Task'
    play_context = 'Play'
    loader = 'Loader'
    variable_manager = 'Variable'
    shared_loader_obj = 'SharedLoader'
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert isinstance(worker, WorkerProcess)
    assert worker._final_q == final_q
    assert worker._task_vars == task_vars
    assert worker._host == host

# Generated at 2022-06-20 14:33:41.500775
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    import time
    import multiprocessing_executors
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.action.normal import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager

    class MockBlocking(object):
        def block(self, hosts, msg):
            pass

        def get_blocked_hosts(self):
            return list()


# Generated at 2022-06-20 14:33:49.213222
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    import queue

    final_q = queue.Queue()
    task_vars = dict()
    host = '127.0.0.1'
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()
    worker = WorkerProcess(final_q=final_q, task_vars=task_vars, host=host, task=task, play_context=play_context, loader=loader, variable_manager=variable_manager, shared_loader_obj=shared_loader_obj)

    # verify if instance variables are set correctly
    assert final_q is worker._final_q
    assert task_vars is worker._task_vars
    assert host is worker._host
    assert task is worker._task
    assert play_context is worker._

# Generated at 2022-06-20 14:33:49.907903
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    Tests start method of WorkerProcess class
    '''
    pass

# Generated at 2022-06-20 14:34:02.452971
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    class FakeQueue(object):
        def __init__(self):
            self._queue = []

        def send_task_result(self, host, uuid, result, task_fields=None):
            self._queue.append(result)

    q = FakeQueue()
    task_vars = dict()
    host = 'localhost'
    task = dict(action='ping')
    play_context = dict()
    loader = None
    variable_manager = None
    shared_loader_obj = None

    worker_process = WorkerProcess(q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker_process.start()
    worker_process.join()

    assert len(q._queue) == 1
    result = q._queue.pop()

# Generated at 2022-06-20 14:34:11.895377
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():

    import queue
    import multiprocessing

    mp = multiprocessing.Manager()
    play_context = connection_loader.get('local', class_only=True).load()
    host = u'localhost'
    task = Task()
    task_vars = dict()
    loader = DataLoader()
    variable_manager = VariableManager()
    shared_loader_obj = mp.Namespace()
    final_q = mp.Queue()
    worker_process = WorkerProcess(
        final_q,
        task_vars,
        host,
        task,
        play_context,
        loader,
        variable_manager,
        shared_loader_obj
    )

    assert worker_process._final_q == final_q
    assert worker_process._task_vars == task_vars
    assert worker_process._host

# Generated at 2022-06-20 14:34:24.522052
# Unit test for constructor of class WorkerProcess
def test_WorkerProcess():
    from multiprocessing import Queue
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host

    fake_loader = DataLoader()
    fake_play_context = PlayContext()

    fake_variable_manager = VariableManager()

    fake_task_vars = HostVars(
        hostname='fake_hostname',
        variables=dict()
    )

    fake_host = Host(
        name='fake_hostname',
        port=22,
        vars=fake_task_vars
    )


# Generated at 2022-06-20 14:34:36.047373
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import hashlib
    from multiprocessing import  Queue
    from jinja2 import Environment, FileSystemLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars import hosts
    from ansible.inventory import Inventory
    from ansible.errors import AnsibleParserError

    from ansible.constants import DEFAULT_HASH_BEHAVIOUR
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    play_context = None
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list='/dev/null')

# Generated at 2022-06-20 14:34:40.642993
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        import __builtin__
    except ImportError:
        import builtins as __builtin__

    # Define inputs/mocks

    # Define expected outputs/results
    expected_stdin = os.path.realpath(os.devnull)

    # Define worker process and execute
    worker_process = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process.start()
    worker_process._new_stdin.close()

    # Assert results
    assert worker_process._new_stdin.closed
    assert worker_process._new_stdin == __builtin__.open(expected_stdin)