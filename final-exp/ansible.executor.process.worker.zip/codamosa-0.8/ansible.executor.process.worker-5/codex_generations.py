

# Generated at 2022-06-22 13:40:52.632093
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader

    # Setup mock objects
    loader = DataLoader()
    play_context = PlayContext()
    host = MockHost()
    task = MockTask()
    task._role = MockRole()
    shared_loader_obj = Mock()

    # Create worker, execute run method and assert it's status
    worker = WorkerProcess(None, None, host, task, play_context, loader, None, shared_loader_obj)
    status = worker.run()
    assert status is None


# Generated at 2022-06-22 13:40:58.243494
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase
    import ansible.constants as C
    import multiprocessing
    import pytest

    fake_inventory = InventoryManager(host_list=[])
    fake_play = Play().load({
        'name': 'fakeplay',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'fail', 'args': 'msg="this should fail"'}}
        ]
    }, variable_manager=VariableManager(), loader=C.DEFAULT_LOADER)


# Generated at 2022-06-22 13:41:08.385570
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import shutil
    import tempfile
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.common.json_utils import jsonify
    from ansible.plugins.loader import module_loader
    from ansible.vars.hashivault import hashivault_argspec
    from ansible.module_utils.hashivault import hashivault_read_token

# Generated at 2022-06-22 13:41:09.189927
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass


# Generated at 2022-06-22 13:41:18.068066
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Init WorkerProcess
    final_q = None
    task_vars = None
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None

    worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker_process.start()
    assert(worker_process.name)
    assert(worker_process.is_alive())
    worker_process.terminate()


# Generated at 2022-06-22 13:41:27.623397
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    '''
        Unit test for method run of class WorkerProcess
    '''

    try:
        from ansible.playbook.play_context import PlayContext
        from ansible.inventory.manager import InventoryManager
        from ansible.vars.manager import VariableManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.executor.playbook_executor import PlaybookExecutor
    except:
        print("import failed")
        return

    class DummyFinalQ(object):
        '''
        Dummy FinalQ class
        '''

        def send_task_result(self, host, uuid, executor_result, task_fields):
            pass

    class DummyHost():
        '''
        DummyHost class
        '''


# Generated at 2022-06-22 13:41:28.779965
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass


# Generated at 2022-06-22 13:41:35.551257
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    class DummyQueue:
        def send_task_result(self, *args, **kwargs):
            pass

    class DummyHost:
        pass

    class DummyTask:
        dump_attrs = lambda s: dict()

    worker = WorkerProcess(DummyQueue(), {}, DummyHost(), DummyTask(), {}, {}, {}, {})
    worker._run()

# Generated at 2022-06-22 13:41:48.541450
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    '''
    This is the unit test for method run of class WorkerProcess
    '''
    final_q = None
    task_vars = dict()
    host = dict()
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = False
    worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    assert worker_process.run() is None
    worker_process._final_q.send_task_result = lambda a, b, c, d: print("")
    worker_process.run()
    assert worker_process.run() is None

# Generated at 2022-06-22 13:42:00.874530
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    import os

    # Mock stdin
    stdin = os.fdopen(os.dup(sys.stdin.fileno()))

    # Mock os module
    os._exit = lambda x: None
    os.fdopen = lambda x: stdin

    # Mock sys module
    sys.stdin = stdin

    # Mock builtin module
    builtins.open = lambda x, y: stdin

    display = Display()
    display.debug = lambda x: x

    # Execute method
    try:
        WorkerProcess(None, None, None, None, None, None, None, None).start()
    except Exception as e:
        assert False, "catched unexpected exception: %s" % e

    # Test if