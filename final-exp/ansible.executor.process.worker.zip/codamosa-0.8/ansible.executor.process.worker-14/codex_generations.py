

# Generated at 2022-06-22 13:40:53.007810
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from multiprocessing.queues import Queue
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

# Generated at 2022-06-22 13:40:53.475802
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Generated at 2022-06-22 13:40:58.812808
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import queue
    import multiprocessing

    final_queue = multiprocessing.Queue()
    task_queue = multiprocessing.Queue()

    task = dict(action=dict(module='shell', args='/usr/bin/env'))

    host = 'localhost'

    q_in = queue.Queue()
    q_in.put((host, task))

    wp = WorkerProcess(
        task_q=q_in,
        final_q=final_queue,
        task_vars=dict(),
        host=host,
        task=task,
        play_context=play_context,
        loader=None,
        variable_manager=None,
        shared_loader_obj=None
    )

    wp.run()

    result = final_queue.get()

# Generated at 2022-06-22 13:41:04.743938
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # import cProfile, pstats, StringIO
    # pr = cProfile.Profile()
    # pr.enable()

    # import profile
    # prof = profile.runctx('WorkerProcess.run(self)', globals(), locals(), "profile_stats.txt")

    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-22 13:41:05.716643
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-22 13:41:18.554308
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    import ansible.constants as C
    import os
    import json

    global display

    testfile = os.path.join(os.path.dirname(__file__), '../unit/lib/ansible/modules/commands/command.py')
    (fd, cp_file) = tempfile.mkstemp()
    os.close(fd)
    shutil.copyfile(testfile, cp_file)

# Generated at 2022-06-22 13:41:20.398791
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    print ("WorkerProcess test")

# Generated at 2022-06-22 13:41:30.756296
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import find_plugin, load_plugin
    from collections import namedtuple
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.removed import removed_module

    # Arrange

# Generated at 2022-06-22 13:41:35.416597
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import sys
    import time

    import mock
    import multiprocessing
    import pytest

    from ansible import context
    from ansible.executor import task_queue_manager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.callbacks import default

    from ansible.utils.multiprocessing import Manager
    from ansible.utils.vars import combine_vars

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.verbosity = 0


# Generated at 2022-06-22 13:41:41.810581
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import Queue
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.playbook.play
    from ansible.playbook.task import Task

    class Runner():
        def __call__(self, *args, **kwargs):
            pass

        def flush_task_queue(*args, **kwargs):
            return dict(changed=False)

    final_q = Queue.Queue()
    task_vars = dict()
    host = dict(name='testhost')
    task = dict(action='ping')
    play_context = dict(timeout=10)
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()