

# Generated at 2022-06-22 13:40:48.076869
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue
    wp = WorkerProcess(Queue(), {}, None, None, None, None)
    assert len(wp._new_stdin.read()) == 0

# Generated at 2022-06-22 13:40:54.898796
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import unittest
    import shutil
    import multiprocessing
    import os
    import sys

    def mock_cleanup_all_tmp_files():
        assert os.path.isdir(tempdir)
        assert not os.path.isfile(tempdir + "/testfile")
        open(tempdir + "/testfile", "a").close()

    def mock_get_host_list(host):
        return [host]

    def mock_get_host_vars(host):
        return dict()

    def mock_get_vars(host):
        return dict()

    tempdir = "test_workerprocess"
    if os.path.isdir(tempdir):
        shutil.rmtree(tempdir)
    os.mkdir(tempdir)


# Generated at 2022-06-22 13:40:59.860196
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    class stub_host:
        name = "stub_host"
        vars = dict()
        groups = list()

    class stub_task:
        def __init__(self, task_uuid):
            self._uuid = task_uuid
        def dump_attrs(self):
            return None

    class stub_final_q:
        def send_task_result(self, host_name, task_uuid, result, task_fields):
            return "ok %s %s" % (host_name, task_uuid)

    class stub_executor_result:
        def __init__(self):
            self.result = dict()

    final_q = stub_final_q()

# Generated at 2022-06-22 13:41:01.085377
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass


# Generated at 2022-06-22 13:41:06.297290
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from multiprocessing import Queue
    from .mock_callback import AnsibleMockCallbackModule
    from .mock_callback import AnsibleMockCallbackModuleResult

    queue = Queue()

    worker = WorkerProcess(
        queue,
        dict(),
        dict(name='hostname'),
        dict(action=dict(module='callback_test')),
        dict(become_method=None),
        dict(),
        dict(),
        dict()
    )

    # run test
    worker.run()

    # check result
    res = queue.get()
    assert('hostname' == res['host'])
    assert('callback_test' == res['task']['action']['module'])
    assert(isinstance(res, dict))

# Generated at 2022-06-22 13:41:18.854304
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    class FakeFinalQ(object):
       def send_task_result(self, hostname, task_uuid, result, task_fields=None):
           self._hostname = hostname
           self._task_uuid = task_uuid
           self._result = result
           self._task_fields = task_fields

    class FakeHost(object):
        def __init__(self):
            self.vars = dict()
            self.groups = []
        def _set_name(self, name):
            self.name = name

    class FakeTask(object):
        def __init__(self, result):
            self._result = result
        def run(self, tmp, task_vars):
            return self._result

    import multiprocessing

    class FakeExecutorResult(object):
        pass


# Generated at 2022-06-22 13:41:30.244504
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    host = '127.0.0.1'
    task_name = 'shell'
    task_args = 'ls'
    variables = { 'a': 'aaa' }
    task_queue_manager = TaskQueueManager('', None, None, None, None, Play(), PlayContext())
    task = task_queue_manager.create_task(task_name, task_args, variables, host)
    play_context = PlayContext()
    loader = None
    variable_manager = None
    shared_loader_obj = None
    final_q = None

# Generated at 2022-06-22 13:41:32.079320
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass


# Generated at 2022-06-22 13:41:45.205249
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    """ test WorkerProcess._run() method to test TaskExecutor functionality """

    import json
    import tempfile
    from multiprocessing import Queue

    # Create a temporary file to use for task serialization
    (tf_fd, tf_path) = tempfile.mkstemp()
    with os.fdopen(tf_fd, "wb") as f:
        json.dump(dict(action=dict(module='shell', args='echo "hello world"')), f)
    os.close(tf_fd)

    # Create a task result queue to use for task result communication
    task_result_queue = Queue()

    # Create a TaskExecutor object

# Generated at 2022-06-22 13:41:57.399378
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    sys.modules['__main__'].HOSTS = set()

    class FakeQueue(object):
        def __init__(self):
            self.result = []

        def qsize(self):
            return 0

        def empty(self):
            return True

        def put(self, item):
            self.result.append(item)

        def get(self, block=True, timeout=None):
            return self.result.pop()

    class FakeLoader(object):
        def __init__(self):
            self.paths = []
            self.result = True
            self.files = []

        def _add_path(self, path):
            self.paths.append(path)

        def _get_path_depth(self):
            return len(self.paths)


# Generated at 2022-06-22 13:42:18.677202
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    final_q = multiprocessing.Queue()
    task_vars = dict()
    # Create a host object, with a name
    host = multiprocessing.Manager().dict()
    host['name'] = 'localhost'
    task = dict()
    play_context = dict()
    loader = dict()
    variable_manager = dict()
    shared_loader_obj = dict()
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    # execute the task and build a TaskResult from the result
    executor_result = dict()
    result = final_q.get()

# Generated at 2022-06-22 13:42:22.969059
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    q = multiprocessing_context.Queue()
    p = multiprocessing_context.Process(target=q.get)
    p.start()
    p.join()
    assert p.exitcode == 0


# Generated at 2022-06-22 13:42:35.674690
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Skip the test on Windows
    import platform
    if platform.system() == 'Windows':
        return
     

    import multiprocessing
    import shutil
    import tempfile
    import time

    # Define a test host
    class TestHost(object):
        def __init__(self, name):
            self.name = name
            self.vars = dict()
            self.groups = []
    test_host = TestHost('localhost')

    # Create the test queue
    final_q = multiprocessing.Queue()

    # Create the test data
    task_vars = dict()
    play_context = dict()
    task_data = dict(action=dict(module='debug', args=dict(msg='Hello World')))

# Generated at 2022-06-22 13:42:47.536436
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    class HostMock:
        def __init__(self):
            self.name = 'localhost'

    class TaskMock:
        def __init__(self, shall_fail):
            self._uuid = 'task_mock.uuid'
            self.shall_fail = shall_fail
            self.args = dict()

        def __repr__(self):
            return self._uuid

        def dump_attrs(self):
            return dict()

    import multiprocessing
    q_final_result = multiprocessing.Queue()
    # test task success

# Generated at 2022-06-22 13:43:00.651770
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.mock import patch
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.plugins.loader import action_loader, lookup_loader

    # setup
    setattr(TaskQueueManager, '_final_q', None)
    setattr(TaskQueueManager, '_inventory', None)
    setattr(TaskQueueManager, '_variable_manager', None)


# Generated at 2022-06-22 13:43:09.574301
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible import constants as C
    from ansible.plugins.loader import action_loader, module_loader
    from ansible.utils.plugin_docs import get_action_documentation, get_docstring
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.utils.vars import merge_hash
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display


# Generated at 2022-06-22 13:43:22.144860
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    class TestWorkerProcess(WorkerProcess):
        def _clean_up(self):
            pass
        def run(self):
            try:
                return self._run()
            except BaseException as e:
                self._hard_exit(e)

    class Test_Task:
        def dump_attrs(self):
            return dict()

    class Test_Queue:
        def send_task_result(self, host_name, uuid, result, task_fields):
            assert host_name == 'host0'
            assert uuid == 'uuid0'
            assert result['failed'] == True
            assert result['exception'] == 'test exception'
            assert result['stdout'] == ''
            result.pop('exception')
            result.pop('stdout')
            assert result == {'failed': True}

# Generated at 2022-06-22 13:43:25.284055
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # do not run unit test when not invoked directly
    if not __name__ == "__main__":
        sys.exit(0)
    print("FIXME")
    sys.exit(1)

if __name__ == "__main__":
    test_WorkerProcess_run()

# Generated at 2022-06-22 13:43:35.986649
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    '''
    This function tests the method run of class WorkerProcess,
    ensuring that the function is running successfully
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.manager import PluginLoader
    from ansible.executor.process.worker import WorkerProcess

    test_host = InventoryManager(loader=DataLoader(), sources=['localhost,'])

# Generated at 2022-06-22 13:43:40.245645
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process._save_stdin = lambda x: True
    worker_process.start()

# Generated at 2022-06-22 13:44:09.707632
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    new_final_q = multiprocessing.Queue()
    new_task_vars = dict(var1='value1', var2='value2')
    new_host = 'some-hostname'
    new_task = dict(task_name='some-task-name', task_args='some-task-args')
    new_play_context = dict(play_context_var1='value1', play_context_var2='value2')
    new_loader = 'some-loader'
    new_variable_manager = 'some-variable-manager'
    new_shared_loader_obj = 'some-shared-loader'

    fake_success_executor_result = dict(changed=True, failed=False)
    fake_failed_executor_result = dict(changed=False, failed=True)

# Generated at 2022-06-22 13:44:20.467243
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from multiprocessing import Queue
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs(['test/units/modules'])

    task_vars = {}
    host = '127.0.0.1'
    task = {"action": 'test_normal', "async": 0}
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = {'_load_name': 'test_normal'}

    results_queue = Queue()

    worker = WorkerProcess(results_queue, task_vars, host, task,
                           play_context, loader, variable_manager, shared_loader_obj)

    worker.run()

    result = results_queue.get()

# Generated at 2022-06-22 13:44:21.587635
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass



# Generated at 2022-06-22 13:44:22.210882
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-22 13:44:32.487605
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    import multiprocessing
    import shutil

    # create test inventory
    temp_dir = tempfile.mkdtemp()
    test_inventory = """
    localhost ansible_connection=local
    """
    inventory_file = os.path.join(temp_dir, 'test_inventory')
    with open(inventory_file, 'w') as fh:
        fh.write(test_inventory)

    # create test playbook

# Generated at 2022-06-22 13:44:40.860351
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Create executor object
    stragegy_base_class = StrategyBase()
    executor_obj = StrategyModuleMake(stragegy_base_class)
    final_queue = FinalQueueManager()
    # Run method
    obj = WorkerProcess(final_queue, 'task_vars', 'host', 'task', 'play_context', 'loader', 'variable_manager', 'shared_loader_obj')
    assert(obj.start() == None)


# Generated at 2022-06-22 13:44:48.000331
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    """WorkerProcess - run method test"""
    import multiprocessing
    import sys

    # Ensure we are using the right ssl.py.
    # On Python3+, pip installs the it's own copy of ssl.py that is later
    # than the one loaded at execution time.
    # load_module will wipe the other versions of ssl.py so that the
    # correct one is in sys.modules.
    if sys.version_info[0] > 2:
        import importlib
        importlib.import_module('ansible.module_utils.ssl')


# Generated at 2022-06-22 13:44:49.098771
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Generated at 2022-06-22 13:44:57.050269
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    final_q = TaskQueueManager()
    task_vars = dict()
    host = Host()
    task = Task()
    play_context = PlayContext()
    loader = DataLoader()
    variable_manager = VariableManager()
    shared_loader_obj = None
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    try:
        worker.start()
    except Exception as err:
        print(err)


# Generated at 2022-06-22 13:45:09.440712
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import AnsibleTemplate
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    import multiprocessing

    host = 'host'
    task_vars = HostVars(host, {})
    task_vars._hostvars[host] = {}
    task_vars._hostvars['localhost'] = {}
    task_vars.update_vars = lambda x: x

    play_context = PlayContext()
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory='localhost')

    task = AnsibleTemplate()
    task._uuid = 'test'

# Generated at 2022-06-22 13:45:54.881780
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import module_loader

    import os
    import sys
    import tempfile
    import time
    import shutil
    import textwrap
    import subprocess

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    fake_loader = DataLoader()
    fake_invent = InventoryManager(loader=fake_loader, sources='')
    fake_variable_manager = VariableManager()
    fake_

# Generated at 2022-06-22 13:46:07.015302
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.plugins.loader import task_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import multiprocessing
    import time
    import shutil

    my_task = task_loader.get('debug', task_loader.find_plugin(task_loader.get_all(), 'debug'))
    print (my_task)

    # Create a dummy queue and make it appear to have one item in it
    class FakeQueue(object):
        def __init__(self):
            self.num_results = 0
            self.results = []

        def qsize(self):
            return 1


# Generated at 2022-06-22 13:46:17.611930
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    dl = DataLoader()
    inv = Inventory(loader=dl, variable_manager=VariableManager(), host_list='localhost,')
    play_context = PlayContext()
    task = dict(action=dict(module='command', args='ls'))

    host = inv.get_host('localhost')
    play = Play()

    p = WorkerProcess(None, None, host, task, play_context, dl, VariableManager(), play)
    p._run()

# Generated at 2022-06-22 13:46:29.049435
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import sys
    import os
    import tempfile
    import time
    import shutil
    import multiprocessing
    import multiprocessing.managers
    import ansible.inventory
    import ansible.playbook
    import ansible.vars
    import ansible.constants as C

    from ansible.plugins import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import module_loader

    # create the QueueManager and final_q
    _shared_loader_obj = multiprocessing.managers.SharedLoader()._obj
    _final_q = multiprocessing.Queue()

# Generated at 2022-06-22 13:46:41.454649
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    '''
    Test scenario: Test run method of class WorkerProcess.

    '''
    host = {'name': 'localhost'}
    task_vars = {'ansible_connection': 'local'}
    play_context = {'name': 'localhost'}
    task = {"action": {"__ansible_module__": "raw", "__ansible_arguments__": "ls -l", "__ansible_module_name__": "raw"}}

    class MockLoader():
        pass
    loader = MockLoader()

    class MockVariableManager():
        pass
    variable_manager = MockVariableManager()

    class MockFinalQueue():
        pass
    final_q = MockFinalQueue()

    class MockSharedLoaderObj():
        pass
    shared_loader_obj = MockSharedLoaderObj()


# Generated at 2022-06-22 13:46:52.627058
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.plugins.loader import find_plugin

    task = dict()

    task_executor = find_plugin('executor', 'task_executor')
    task_executor_instance = task_executor(
        host=dict(),
        task=task,
        task_vars=dict(),
        play_context=dict(),
        stdin=None,
        loader=dict(),
        shared_loader_obj=dict(),
        final_q=TaskQueueManager(
            inventory=None,
            variable_manager=None,
            loader=None,
            passwords=dict(),
            display=None),
        )

# Generated at 2022-06-22 13:47:03.420657
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from ansible.utils.multiprocessing import process_common

    shared_loader_obj = multiprocessing_context.Process(target=process_common.dummy).start()
    worker_process = WorkerProcess(
        process_common.DummyFinalQueue(),
        process_common.DummyTaskVars(),
        process_common.DummyHost(),
        process_common.DummyTask(),
        process_common.DummyPlayContext(),
        process_common.DummyLoader(),
        process_common.DummyVariableManager(),
        shared_loader_obj
    )
    worker_process.start()
    assert worker_process.pid



# Generated at 2022-06-22 13:47:14.478044
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # The method start of class WorkerProcess is a subclass method of multiprocessing.Process,
    # and its behavior can be tested by testing the behavior of multiprocessing.Process.start
    import multiprocessing
    p = multiprocessing.Process()
    with pytest.raises(RuntimeError) as exception:
        p.start()
    assert "child process" in str(exception.value)

    def f(name):
        print('hello', name)

    p = multiprocessing.Process(target=f, args=('bob',))
    p.start()
    p.join()
    assert p.is_alive() == False
    assert p.exitcode == 0


# Generated at 2022-06-22 13:47:24.300723
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    Unit test for method start of class WorkerProcess
    '''
    (task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj) = (
        dict(), '127.0.0.1', dict(), dict(), dict(), dict(), dict()
    )

    # Create a final_q object
    final_q = multiprocessing_context.Queue()

    # Create a WorkerProcess object
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    # Call method start
    worker.start()

# Generated at 2022-06-22 13:47:26.267455
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass