

# Generated at 2022-06-22 13:40:53.124640
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import sys
    import copy
    import time
    import time as time_module
    import os
    import multiprocessing
    import uuid
    from multiprocessing import Event, Value, Process, Queue
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import module_loader
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.task_executor import TaskExecutor

# Generated at 2022-06-22 13:40:58.129130
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    import unittest
    import mock
    import multiprocessing
    import collections

    # Struct to hold the arguments passed to multiprocessing.Process
    class ProcessArgs(object):

        def __init__(self):
            self.target = None
            self.args = None

    # Mock used to mock methods of TaskExecutor
    class TaskExecutorMock(object):
        def __init__(self):
            self.run_ran = False

        def run(self):
            self.run_ran = True
            return collections.OrderedDict([('a', 1), ('b', 2)])

    # Test the run method

# Generated at 2022-06-22 13:41:08.311554
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager

    class FakeQueue():
        pass

    fake_queue = FakeQueue()
    fake_queue.send_task_result = lambda x, y, z, w: x

    # test setup
    fake_variable_manager = VariableManager()
    fake_loader = "fake_loader"
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    fake_play_context = Play()
    fake_display = Display()
    fake_new_stdin = "fake_new_stdin"

# Generated at 2022-06-22 13:41:13.666207
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing
    import Queue
    final_q = multiprocessing.Queue()
    task_vars = {}
    host = ""
    task = ""
    play_context = ""
    loader = ""
    variable_manager = ""
    shared_loader_obj = ""

    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader,
                           variable_manager, shared_loader_obj)
    worker.start()



# Generated at 2022-06-22 13:41:18.248629
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    import mock
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host


    '''
    The test case for the method start of class WorkerProcess.
    '''

    def exec_command(cmd):
        '''
        The mock function for exec_command.
        '''
        return (0, 'success', '')

    mock_exec_command = mock.Mock(side_effect=exec_command)
    mock_final_q = mock.Mock()

# Generated at 2022-06-22 13:41:30.102719
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import unittest
    import test
    import copy


    class WorkerProcessTestResult(unittest.TestResult):
        def __init__(self, *args, **kwargs):
            unittest.TestResult.__init__(self, *args, **kwargs)
            self.successes = []
            self.failures = []
            self.errors = []

        def startTestRun(self):
            pass

        def stopTestRun(self):
            pass

        def addSuccess(self, test):
            self.successes.append(test)

        def addFailure(self, test, err):
            self.failures.append((test, err))

        def addError(self, test, err):
            self.errors.append((test, err))

    class MockUnreachable(Exception):
        pass

   

# Generated at 2022-06-22 13:41:43.511607
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible import constants as C
    import multiprocessing
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    def mock_host_result_q(host, uuid, result, task_fields):
        print('host, uuid, result, task_fields : ')
        print(host, uuid, result, task_fields)


# Generated at 2022-06-22 13:41:56.066889
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create data loader
    loader = DataLoader()
    display.verbosity = 3

    # Create inventory, and pass to var manager
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Setup PlayContext
    play_context = PlayContext()
    play_context.network_os = 'ios'

    # Create play

# Generated at 2022-06-22 13:41:57.266329
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    raise Exception("Not implemented")

# Generated at 2022-06-22 13:42:06.806091
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import ansible.playbook
    import ansible.inventory
    import ansible.constants as C
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from .mock_executor import MockTaskExecutor

    # Mock the task
    task_name = 'fake_task'
    task_args1 = {}
    task_args2 = {}
    fake_task = MockTaskExecutor(task_name, task_args1)
    fake_task2 = MockTaskExecutor(task_name, task_args2)

    # Mock the host
    host_name = 'fake_host'
    host_vars = {}
    host_groups = []
    fake_host = Host(host_name)
    fake_host.v