

# Generated at 2022-06-22 13:40:47.741626
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-22 13:40:54.871950
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class Host:
        def __init__(self, name):
            self.name = name

    class Queue:
        def __init__(self):
            self.results = []

        def send_task_result(self, host, uuid, result, task_fields):
            self.results.append(result)

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext

# Generated at 2022-06-22 13:41:04.880682
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    Test that start does not break with fileno() exception
    '''
    import mock
    final_q = mock.MagicMock()
    task_vars = mock.MagicMock()
    host = mock.MagicMock()
    task = mock.MagicMock()
    play_context = mock.MagicMock()
    loader = mock.MagicMock()
    variable_manager = mock.MagicMock()

    wp = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, None)
    wp.start()

# Generated at 2022-06-22 13:41:18.113244
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import ansible.utils.plugin_docs as plugin_docs
    import os
    import stat
    import difflib
    import tempfile
    import time
    import sys
    import shutil
    import multiprocessing
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins.action as action_plugin
    import ansible.parsing.dataloader as loaders
    import ansible.executor as executor
    import ansible.inventory as inventory
    import ansible.playbook.play_context as play_context
    import ansible.playbook.play as play

    from ansible.module_utils.six.moves import StringIO
    from ansible.vars.manager import VariableManager
    from ansible.vars import HostVars

# Generated at 2022-06-22 13:41:27.670619
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import json
    sys.modules['ansible'] = None
    import ansible.plugins.loader
    sys.modules.pop('ansible')
    import ansible.plugins.action
    from ansible.playbook import play
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from multiprocessing import Queue

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
        display.verb

# Generated at 2022-06-22 13:41:36.202362
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    host = '127.0.0.1'
    task = 'uptime'
    play_context = dict()
    loader = 'ansible'
    variable_manager = 'ansible'
    shared_loader_obj = 'ansible'
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker.start()

# Generated at 2022-06-22 13:41:36.807362
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert True

# Generated at 2022-06-22 13:41:49.781745
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader, module_loader
    from ansible.inventory.manager import InventoryManager

    my_vars = dict(
        foo='bar'
    )
    my_play_context = PlayContext()
    my_play_context.prompt = dict()
    my_play_context.network_os = 'ios'
    my_inventory = InventoryManager(loader=DataLoader())
    host = my_inventory.get_host(name="testhost")
    host.set_variable('ansible_connection', 'local')

# Generated at 2022-06-22 13:41:55.671003
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    def mock_TaskExecutor(*args, **kwargs):
        fake_result = {"result":123}
        return fake_result

    fake_final_q = "fake_final_q"
    fake_task_vars = "fake_task_vars"
    fake_host = "fake_host"
    fake_task = "fake_task"
    fake_play_context = "fake_play_context"
    fake_loader = "fake_loader"
    fake_variable_manager = "fake_variable_manager"
    fake_shared_loader_obj = "fake_shared_loader_obj"

    wp = WorkerProcess(fake_final_q, fake_task_vars, fake_host, fake_task, fake_play_context, fake_loader, fake_variable_manager, fake_shared_loader_obj)



# Generated at 2022-06-22 13:42:00.070830
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import shared_loader_obj
    from ansible.plugins.strategy import StrategyBase
    from multiprocessing import JoinableQueue
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.process.worker import WorkerProcess

    results_queue = JoinableQueue()
    block       = Block()
    play_context    = PlayContext()