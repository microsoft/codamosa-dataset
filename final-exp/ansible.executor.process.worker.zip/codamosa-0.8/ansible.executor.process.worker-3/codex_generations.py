

# Generated at 2022-06-22 13:40:53.579896
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 1

    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager(loader=loader, sources=[]))
    variable_manager.extra_vars = {"key": "value"}

    task = dict(
        action={
            'module': 'ping',
            'args': {},
            'kwargs': {},
        },
        async_val=0,
        register='shell_out',
    )
    host = "localhost"
   

# Generated at 2022-06-22 13:40:54.016399
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-22 13:41:02.480211
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing
    q = multiprocessing.Queue()
    w = WorkerProcess(q, None, None, None, None, None, None)
    w.start()
    w.join()
    # should be no errors
    assert True

# This class is not a testcase class so make pylint shut up
# pylint: disable=too-few-public-methods

# Generated at 2022-06-22 13:41:07.290992
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import multiprocessing

    q = multiprocessing.Queue()
    p = WorkerProcess(q, [], [], [], [], [], [], [])

    # this should not raise exception and return normally
    p.start()

# Generated at 2022-06-22 13:41:19.153250
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # generate a simple task and job queue
    dummy_task = dict(action=dict(module='ping'))
    final_q = multiprocessing_context.Queue()
    task_vars = dict()
    host = '127.0.0.1'
    play_context = dict()
    loader = 'loader'
    variable_manager = 'var_manager'
    shared_loader_obj = 'loader_obj'

    # create a worker and start it
    worker = WorkerProcess(
        final_q,
        task_vars,
        host,
        dummy_task,
        play_context,
        loader,
        variable_manager,
        shared_loader_obj,
    )
    worker.start()

    # cleanup
    worker.join()


# Generated at 2022-06-22 13:41:22.880811
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    wp = WorkerProcess(object, object, object, object, object, object, object, object)
    wp.start()
    assert True

# Generated at 2022-06-22 13:41:23.997756
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    raise Exception('not tested yet')

# Generated at 2022-06-22 13:41:32.395232
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager, TaskQueue
    from ansible.executor.play_context import PlayContext
    from ansible.utils.display import Display

    class TestTask(Task):
        '''
        A test task.
        '''
        def __init__(self, module='noop', args=None):
            self._module_name = module
            self._name = ''
            self._args = args or {}
            self._role = None
            self._loop = None
            self._when = None
            self

# Generated at 2022-06-22 13:41:33.314516
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-22 13:41:33.998321
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass