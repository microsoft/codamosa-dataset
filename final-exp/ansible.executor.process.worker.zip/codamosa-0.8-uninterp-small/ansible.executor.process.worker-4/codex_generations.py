

# Generated at 2022-06-24 19:07:30.749604
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Init parameter values
    # float 0.0
    float_0 = 0.0
    # float 0.0
    float_1 = 0.0

    # Run method WorkerProcess.run against parameters
    # Exception number: 0
    exception_number = 0

    # Call method "run" of class WorkerProcess with a first parameter:
    # float 0.0
    # and a second parameter:
    # float 0.0
    try:
        WorkerProcess.run(float_0, float_1)
    except Exception as e:
        assert e.__class__.__name__ == 'AnsibleConnectionFailure'
        assert e.args[0] == 'Yo'
        exception_number += 1

    # Exception number: 1
    exception_number = 1

    # Call method "run" of class WorkerProcess with a first parameter:


# Generated at 2022-06-24 19:07:38.528498
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    list_0 = ['Ymj', None, 'Ej4L', 'nxn', None, list(), list(), list(), list()]
    set_0 = {list_0, list_0}
    tuple_0 = (list_0, set_0)
    str_0 = 'Pm72'
    int_0 = 526
    worker_process_0 = WorkerProcess(tuple_0, tuple_0, str_0, tuple_0, int_0, set_0, str_0, set_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:07:47.607726
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    list_0 = None
    set_0 = {list_0, list_0}
    tuple_0 = (list_0, set_0)
    str_0 = 'S6B\rKOBp'
    int_0 = 371
    worker_process_0 = WorkerProcess(tuple_0, tuple_0, str_0, tuple_0, int_0, set_0, str_0, set_0)
    result_0 = worker_process_0.start()
    print(result_0)
    print(worker_process_0)
    print(str_0)
    print(set_0)
    print(int_0)
    print(worker_process_0)
    print(tuple_0)
    print(tuple_0)
    print(worker_process_0)
   

# Generated at 2022-06-24 19:07:56.016841
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    list_0 = None
    list_1 = list()
    set_0 = {list_0, list_0}
    tuple_0 = (list_0, set_0)
    str_0 = 'S6B\rKOBp'
    int_0 = 371
    worker_process_0 = WorkerProcess(tuple_0, tuple_0, str_0, tuple_0, int_0, set_0, str_0, set_0)
    worker_process_0.start()
    int_1 = worker_process_0.exitcode
    print(int_1)


# Generated at 2022-06-24 19:08:02.015180
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    arg_0 = None
    arg_1 = None
    arg_2 = ''
    arg_3 = None
    arg_4 = 371
    arg_5 = set()
    arg_6 = ''
    arg_7 = set()
    worker_process_0 = WorkerProcess(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:09.105148
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()
    list_0 = None
    set_0 = {list_0, list_0}
    tuple_0 = (list_0, set_0)
    str_0 = 'S6B\rKOBp'
    int_0 = 371
    worker_process_0 = WorkerProcess(tuple_0, tuple_0, str_0, tuple_0, int_0, set_0, str_0, set_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:08:10.943591
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_run()
    print('All unit tests complete')

# Generated at 2022-06-24 19:08:18.111210
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    list_0 = None
    set_0 = {list_0, list_0}
    tuple_0 = (list_0, set_0)
    str_0 = 'S6B\rKOBp'
    int_0 = 371
    worker_process_0 = WorkerProcess(tuple_0, tuple_0, str_0, tuple_0, int_0, set_0, str_0, set_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:21.815742
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.run()



# Generated at 2022-06-24 19:08:28.901761
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    list_0 = [635, 'GJZz.]\rUof&']
    set_0 = {list_0, list_0}
    tuple_0 = (list_0, set_0)
    str_0 = 'S6B\rKOBp'
    int_0 = 371
    worker_process_0 = WorkerProcess(tuple_0, tuple_0, str_0, tuple_0, int_0, set_0, str_0, set_0)
    try:
        worker_process_0.run()
    except Exception as e:
        print(e)

# Test the main function
if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:46.676325
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.run()

if __name__ == "__main__":
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:53.116758
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.run()

# Generated at 2022-06-24 19:09:00.379125
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    mock_task = MockTask()
    var_0 = None
    mock_host = MockHost()
    task_vars = {}
    var_1 = {}
    play_context = {}
    loader = None
    variable_manager = None
    shared_loader_obj = None
    worker_process_0 = WorkerProcess(var_0, task_vars, mock_host, mock_task, play_context, loader, variable_manager, shared_loader_obj)
    try:
        var_1 = worker_process_0.run()
    except BaseException as e:
        var_1 = e
    assert type(var_1) == AnsibleConnectionFailure



# Generated at 2022-06-24 19:09:05.648487
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    worker_process_0 = WorkerProcess(var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8)
    worker_process_0.run()
    print("foo")


# Generated at 2022-06-24 19:09:11.139028
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass
    # var_0 = None
    # worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    # worker_process_0.run()


# Generated at 2022-06-24 19:09:17.356608
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    worker_process_0 = WorkerProcess(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    var_8 = False
    if (not var_8):
        return
    var_9 = worker_process_0.run()


# Generated at 2022-06-24 19:09:21.419692
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # Create a new instance of WorkerProcess
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    # Call method start of worker_process_0
    var_1 = worker_process_0.start()


# Generated at 2022-06-24 19:09:29.708690
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # NOTE: unit testing this is tricky since this uses the multiprocessing library
    # and multiprocessing can't be mocked
    mock_final_q = None
    mock_task_vars = None
    mock_host = None
    mock_task = None
    mock_play_context = None
    mock_loader = None
    mock_variable_manager = None
    mock_shared_loader_obj = None
    worker_process_2 = WorkerProcess(mock_final_q, mock_task_vars, mock_host, mock_task, mock_play_context, mock_loader, mock_variable_manager, mock_shared_loader_obj)
    result = worker_process_2.run()
    assert result == None

# Generated at 2022-06-24 19:09:30.309964
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:09:37.328859
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    worker_process_1 = WorkerProcess(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_2)
    var_9 = worker_process_1.start()

    worker_process_2 = WorkerProcess(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_2)
    var_10 = worker_process_2.start()
    print(var_10)
    print(var_9)


# Generated at 2022-06-24 19:09:56.736379
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    worker_process_0 = WorkerProcess(var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8)
    var_9 = worker_process_0.start()


# Generated at 2022-06-24 19:10:00.787811
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Setup test code
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    # Execute run method
    var_1 = worker_process_0.run()

    # Assert test result
    assert var_1 == None

# Generated at 2022-06-24 19:10:05.434288
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    var_2 = 0
    var_1 = worker_process_0.start()
    var_3 = None
    var_4 = isinstance(var_1, var_3)
    if var_4:
        var_2 = 1
    else:
        var_2 = 0
    assert var_2 == 1


# Generated at 2022-06-24 19:10:09.746350
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_2 = 'A'*1
    worker_process_1 = WorkerProcess(var_2, var_2, var_2, var_2, var_2, var_2, var_2, var_2)
    worker_process_1.start()
    worker_process_1.join()


# Generated at 2022-06-24 19:10:16.411931
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    try:
        del(sys.modules["ansible.modules.packaging.os.yum"])
    except KeyError:
        pass
    try:
        del(sys.modules["ansible.modules.packaging.os.zypper"])
    except KeyError:
        pass
    try:
        del(sys.modules["ansible.modules.packaging.os.dnf"])
    except KeyError:
        pass
    var_0 = "yum"
    var_1 = "zypper"
    var_2 = "dnf"
    var_3 = ["yum", "zypper", "dnf"]
    var_4 = None

# Generated at 2022-06-24 19:10:18.687171
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # Input parameters tests
    var_0 = None

    # No input
    var_1 = sys.stdin

# Generated at 2022-06-24 19:10:21.949682
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:30.085876
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    worker_process_1 = WorkerProcess(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9)
    var_10 = worker_process_1.run()

# Generated at 2022-06-24 19:10:32.954037
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.start()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 19:10:34.959571
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.start()


# Generated at 2022-06-24 19:10:59.047069
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    worker_process_1 = WorkerProcess(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9)
    worker_process_1.start()

# Generated at 2022-06-24 19:11:01.642208
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
   test_case_0()


# Generated at 2022-06-24 19:11:04.865517
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()
    worker_process_0.join()

# Generated at 2022-06-24 19:11:08.411528
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = None
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.run()
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.run()


# Generated at 2022-06-24 19:11:10.648619
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.run()


# Generated at 2022-06-24 19:11:14.236235
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        var_0 = None
        worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
        var_1 = worker_process_0.run()
    except Exception as err:
        print(err)
        assert False
    else:
        assert True


# Generated at 2022-06-24 19:11:16.041512
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process.run()

# Generated at 2022-06-24 19:11:22.109686
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Start a process and run
    var_0 = None
    var_0 = None
    var_0 = None
    var_0 = None
    var_0 = None
    var_0 = None
    var_0 = None
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    try:
        worker_process_0.start()
        worker_process_0.join()
    except (AnsibleConnectionFailure, KeyboardInterrupt):
        worker_process_0.terminate()
        worker_process_0.join()
    var_2 = worker_process_0.is_alive()
    var_3 = worker_process_0.name
    worker_

# Generated at 2022-06-24 19:11:25.359242
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.run()


if __name__ == '__main__':
    print('Testing')
    test_WorkerProcess_run()
    print('Ending')

# Generated at 2022-06-24 19:11:26.744587
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Run the function
    test_case_0()

# Generated at 2022-06-24 19:12:05.453394
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.start()


# Generated at 2022-06-24 19:12:11.293016
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.start()


# Generated at 2022-06-24 19:12:16.295324
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    worker_process_0 = WorkerProcess(var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8)
    worker_process_0.start()



# Generated at 2022-06-24 19:12:25.236200
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-24 19:12:29.827580
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    worker_process_1 = WorkerProcess(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9)
    var_10 = worker_process_1.run()

# Generated at 2022-06-24 19:12:35.198881
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.run()


# Generated at 2022-06-24 19:12:37.907048
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.start()


# Generated at 2022-06-24 19:12:45.705326
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_8 = None
    var_9 = None
    var_10 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
    var_29 = None
    var_30 = None
    var_31 = None
    var_33 = None
    var_34 = None
    var_35 = None
    var_36 = None
    var_37 = None
    var_38 = None
    var_

# Generated at 2022-06-24 19:12:50.359801
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()



# Generated at 2022-06-24 19:12:55.444439
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.run()


# Generated at 2022-06-24 19:14:10.081219
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    var_1 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_2 = var_1.start()


# Generated at 2022-06-24 19:14:14.319874
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():  # lgtm [py/similar-function]
    test_case_0()

# Generated at 2022-06-24 19:14:23.083298
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing.queues import SimpleQueue
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.module_utils.facts import Facts
    from ansible.vars import HostVarsVars
    test_host_vars_vars = HostVarsVars()
    test_hostvars = HostVars(host=None, vault_password=None, task=None)

# Generated at 2022-06-24 19:14:32.242627
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    """Unit test for method WorkerProcess.start"""

    # Construct object with non-empty arguments
    worker_process_1 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    # Call method
    worker_process_1.start()

    # Construct object with non-empty arguments
    worker_process_2 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    # Call method
    worker_process_2.start()

    # Construct object with non-empty arguments

# Generated at 2022-06-24 19:14:32.793313
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:14:35.789414
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = worker_process_0.run()
    assert isinstance(var_1, int)


# Generated at 2022-06-24 19:14:37.682497
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_2 = None
    worker_process_1 = WorkerProcess(var_2, var_2, var_2, var_2, var_2, var_2, var_2, var_2)
    worker_process_1.start()

# Generated at 2022-06-24 19:14:39.689694
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print("Test for WorkerProcess class. Method run")

if __name__ == "__main__":
    test_WorkerProcess_run()
    print("Test for WorkerProcess class. Done")

# Generated at 2022-06-24 19:14:42.151219
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:14:45.251105
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Run method of WorkerProcess without any exception
    test_case_0()
    # Test if a NotImplementedError is raised when run method is called without implementation
    try:
        obj = WorkerProcess(None, None, None, None, None, None, None, None)
        obj.run()
    except NotImplementedError as e:
        print("Exception raised successfully as run method of WorkerProcess class is not implemented")

# Generated at 2022-06-24 19:17:13.523146
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    worker_process_1 = WorkerProcess(var_2, var_3, var_4, var_5, var_6, var_7, var_8, var_9)
    # hard coded return value for _save_stdin
    worker_process_1._new_stdin = None
    # hard coded return value for super()
    var_10 = None
    var_11 = worker_process_1.start()

    assert var_10 == var_11