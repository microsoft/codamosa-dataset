

# Generated at 2022-06-24 19:07:29.769459
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:07:33.043866
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    assert worker_process_0.start() == None


# Generated at 2022-06-24 19:07:40.165798
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0._host = str_0
    worker_process_0._task = bytes_0
    worker_process_0._task_vars = tuple_0
    worker_process_0._new_stdin = tuple_0
    worker_process_0._loader = float_0
    worker_process_0._shared_loader_obj = bytes_0
    worker_process

# Generated at 2022-06-24 19:07:46.234317
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    # Call method start of class WorkerProcess
    worker_process_0.start()


# Generated at 2022-06-24 19:07:57.184458
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Method run could not run in python2.7 and python3.6, because of the pickle dump failure.
    # IOError: [Errno 32] Broken pipe
    # But it is run successfully in python3.7. 
    # It is different from the former run method of WorkerProcess, which is not exist in python3.7.
    # So we could not use the former run method to test in python2.7, and we still could not use the new run method to test in python3.6.
    tuple_0 = ()
    bytes_0 = b'>:F/\x1fQ\x0f\xd2\xc9\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
   

# Generated at 2022-06-24 19:08:01.914823
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:02.523231
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:08:05.624683
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()
    worker_process_0.start()


# Generated at 2022-06-24 19:08:10.072582
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = (0,)
    bytes_0 = b'\xcfa\xe3\x02\x0f\x1a\x81\xac\x9d\xb9\x93r'
    int_0 = 8000000
    str_0 = "m.:!o\n{2$^'Yz8W:<fZv\x0c\x1f\x02"
    float_0 = 256.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:08:19.116126
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:08:31.787798
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test using default values for WorkerProcess.run
    test_case_0()


# Generated at 2022-06-24 19:08:42.973216
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import ctypes
    import multiprocessing

    # Mock Class
    class TaskExecutor():
        def __init__(self):
            self.instance = None
            self.worker_process = None
            self.status = None
            self.task = None
            self.task_vars = None
            self.play_context = None
            self.new_stdin = None
            self.loader = None
            self.shared_loader_obj = None
            self.final_q = None

        def run(self):
            self.instance = WorkerProcess
            self.worker_process = WorkerProcess()
            self.worker_process.run()
            self.worker_process.start()
            self.worker_process.finalize()
            self.worker_process.terminate()
            self.status = True

    # Mock Class


# Generated at 2022-06-24 19:08:51.848734
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    hostname = 'localhost'
    port = 22
    username = 'my_username'
    password = 'my_password'
    private_key = 'my_private_key'
    host = AnsibleHost(hostname, port, username, password, private_key)
    command = 'ls'
    task = TaskExecutor(command=command)
    play_context = PlayContext(check_mode=False, network_os='default', remote_addr=None, become_method=None, become_user=None, become_pass=None, become_exe=None, become_flags=None, become_info=None)
    queue_manager = QueueManager(playbook_path="playbook.yml")
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-24 19:09:00.217122
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = ()

# Generated at 2022-06-24 19:09:02.162745
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = WorkerProcess()
    assert True == var_0.start()



# Generated at 2022-06-24 19:09:07.247681
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process = WorkerProcess(final_q=var_0, task_vars=var_0, host=str_0, task=str_0, play_context=str_0, loader=int_0, variable_manager=bytes_0, shared_loader_obj=float_0)
    worker_process.start()


# Generated at 2022-06-24 19:09:12.868649
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = ()
    bytes_0 = b'>:F/\x1fQ\x0f\xd2\xc9\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0

    # Setup the object
    obj = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    obj.run()


# Generated at 2022-06-24 19:09:17.882523
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Make the dependencies
    # Make the expected values
    expected_return = None
    # Perform the test
    test_case_0()
    # Compare expected vs actual
    print('Expected :')
    print(expected_return)
    print('Actual :')
    print()


# Generated at 2022-06-24 19:09:20.037344
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    int_0 = 200000


# Generated at 2022-06-24 19:09:22.716113
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    multiprocessing_context.set_forks_compat_mode()
    my_worker = WorkerProcess((), {}, (), (), (), (), (), ())
    my_worker.start() # TODO: test the return value?


# Generated at 2022-06-24 19:09:37.223994
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:09:46.176871
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    try:
        worker_process_0.run()
    except Exception as exception_0:
        assert type(exception_0) == Exception

# Generated at 2022-06-24 19:09:50.922013
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:09:55.927864
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.daemon = True
    worker_process_0.start()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:10:01.902373
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.run()
    assert True # TODO: implement your test here


# Generated at 2022-06-24 19:10:10.118755
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0

    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:18.780408
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Arrange
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)

    # Act
    worker_process_0.run()


if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:23.583867
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    # Call method
    # TODO: add assert statements
    worker_process_0.start()


# Generated at 2022-06-24 19:10:27.948371
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    ret = worker_process_0.start()


# Generated at 2022-06-24 19:10:32.685474
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    # Run the function
    result = worker_process_0.run()
    # Check the results
    assert result is None


# Generated at 2022-06-24 19:10:58.450179
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    str_0 = "6i>42\u0018"
    str_1 = "6i>42\u0018"
    int_0 = 200000
    list_0 = [str_0, str_1, int_0]
    worker_process_0 = WorkerProcess(*list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:01.851742
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess()
    worker_process_0.run()

# Generated at 2022-06-24 19:11:07.057823
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:11:14.881843
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:23.237027
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:11:29.062566
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # test_case_0
    try:
        test_case_0()
    except BaseException as e:
        pass
    return True


# Generated at 2022-06-24 19:11:33.844489
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    try:
        assert_true(worker_process_0.start(), "assert_true(worker_process_0.start(),)")
    except AssertionError as e:
        print("AssertionError: ", e)


# Generated at 2022-06-24 19:11:40.507446
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:11:47.687103
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()



# Generated at 2022-06-24 19:11:51.165996
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # constructor test
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)

    # method test
    worker_process_0.run()


# Generated at 2022-06-24 19:12:32.070719
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:12:38.878205
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Creating test data
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)

    # Calling method to execute test case.
    worker_process_0.start()


# Generated at 2022-06-24 19:12:44.290925
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:12:48.374708
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:12:55.082241
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b'3'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    try:
        worker_process_0.run()
    except BaseException as error_1:
        print("Test case 0: Failed: ")
        print(error_1)

if __name__ == '__main__':
    test_WorkerProcess_run()
    #test_case_0()

# Generated at 2022-06-24 19:13:02.913792
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
  print("\n--- test_WorkerProcess_run ---\n\n")
  tuple_0 = ()
  bytes_0 = b':\xc2\xa0'
  int_0 = 200000
  str_0 = "E9vf.6w}]\ri.'YGi,a`"
  float_0 = 512.0
  worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
  worker_process_0.run()

# Testing the function run of the class WorkerProcess

# Generated at 2022-06-24 19:13:06.807135
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:09.916131
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:16.935420
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:23.277926
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'*\x16PG\x07\x18\xb0\x96:'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, bytes_0)
    str_1 = '\x0b"\x05\xb9\x9c\x1a\x8f\xcf\xdf'
    int_1 = -1
    worker_process_0.start(int_1, str_1)


# Generated at 2022-06-24 19:14:43.788128
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    try:
        worker_process_0._run()
    except SystemExit as e:
        print("Exception: SystemExit")
    except BaseException as e:
        print("Exception: ",e, str(e), type(e))


# Generated at 2022-06-24 19:14:48.836067
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    # _save_stdin() method call
    # testing for method start( self )
    # Parameters: self /
    # Return type: None
    #method start( self )
    #executor.py:252
    #method _run( self )
    #executor.py:256
    #method _clean_up( self )
    #executor.py:474
    #

# Generated at 2022-06-24 19:14:52.039845
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:14:53.370819
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # No need to test, since it calls multiprocessing.Process.start
    pass


# Generated at 2022-06-24 19:14:58.774264
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:15:05.259532
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    # Call method run of class WorkerProcess
    worker_process_0.run()

# Tests for method start of class WorkerProcess

# Generated at 2022-06-24 19:15:11.360684
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    float_0 = 0.0
    bytes_0 = b''
    int_0 = 0
    worker_process_0 = WorkerProcess(float_0, float_0, bytes_0, int_0, float_0, float_0, bytes_0, tuple_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:15:16.677898
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:15:23.085858
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)

    # Testing code begin
    # Testing code end


# Generated at 2022-06-24 19:15:28.447550
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    bytes_0 = b':\xc2\xa0'
    int_0 = 200000
    str_0 = "E9vf.6w}]\ri.'YGi,a`"
    float_0 = 512.0
    worker_process_0 = WorkerProcess(bytes_0, int_0, float_0, int_0, bytes_0, str_0, float_0, tuple_0)
    worker_process_0._run()
    # Unit test for method _save_stdin of class WorkerProcess
    def test_WorkerProcess__save_stdin():
        tuple_0 = ()
        bytes_0 = b':\xc2\xa0'
        int_0 = 200000