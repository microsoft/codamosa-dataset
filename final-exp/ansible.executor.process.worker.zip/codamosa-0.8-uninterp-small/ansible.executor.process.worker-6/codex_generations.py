

# Generated at 2022-06-24 19:07:26.566296
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print('Test start:')
    test_case_0()


# Generated at 2022-06-24 19:07:30.650971
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.run()

if __name__ == "__main__":
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:07:37.095552
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = '<c+'
    bytes_0 = b'@O:N'
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:07:41.284878
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.run()

    # TODO: Add more test cases for the class WorkerProcess

if __name__ == '__main__':
    test_WorkerProcess_run()
    test_case_0()

# Generated at 2022-06-24 19:07:46.858348
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = '%\x8b'
    bytes_0 = b'm#_[\xa3\x98\xe1\xef@'
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:07:53.132137
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:07:54.197570
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

# Generated at 2022-06-24 19:08:00.086303
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()
    assert True


# Generated at 2022-06-24 19:08:07.966943
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'v$D;'
    bytes_0 = b'}5qq'
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    # Call WorkerProcess.run
    worker_process_0.run()

test_case_0()
test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:14.835577
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()
    worker_process_0.start()


# Generated at 2022-06-24 19:08:31.702658
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

# Test case configuration
test_cases = [
    (0, 0)
]

# Test suite
test_suite = [test_WorkerProcess_start]

test_runner = unittest.TextTestRunner()
test_runner.run(test_suite)

# Generated at 2022-06-24 19:08:34.884673
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'Test start:'
    var_0 = print(str_0)

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:40.522437
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
    except AssertionError as e:
        print('Test fail: ' + str(e))
    except Exception as e:
        print('Test error: ' + str(e))
    else:
        print('Test pass')
    

# Generated at 2022-06-24 19:08:50.328118
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.plugins import connection_loader, module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/ansible_hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source =  dict(
            name = "Ansible Play 1",
            hosts = 'hostA',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='shell', args='ifconfig'))
             ]
        )

# Generated at 2022-06-24 19:08:51.292274
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()
    pass


# Generated at 2022-06-24 19:08:52.736615
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print("Method start start")
    test_case_0()
    print("Method start end")


# Generated at 2022-06-24 19:09:02.910893
# Unit test for method start of class WorkerProcess

# Generated at 2022-06-24 19:09:04.484154
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:09:06.511910
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker = WorkerProcess(None, None, None, None, None, None, None, None)
    worker.start()
    worker._clean_up()
    worker.run()

test_WorkerProcess_start()

# Generated at 2022-06-24 19:09:08.451976
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = WorkerProcess()
    var_0.start()
    var_1 = var_0.start()


# Generated at 2022-06-24 19:09:19.211059
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        WorkerProcess_0 = WorkerProcess()
        WorkerProcess_0.start()
        print('Worked')
    except Exception as e:
        print('Failed:', e)


# Generated at 2022-06-24 19:09:24.888022
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'Test start:'
    var_0 = print(str_0)


# Generated at 2022-06-24 19:09:25.664159
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print("Testing WorkerProcess.run")
    test_case_0()


# Generated at 2022-06-24 19:09:26.216128
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:09:29.234035
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print('*** Unit test start: WorkerProcess.run()')
    str_0 = 'Test start:'
    var_0 = print(str_0)
    print('*** Unit test end: WorkerProcess.run()')


# Generated at 2022-06-24 19:09:31.282623
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    WorkerProcess_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    WorkerProcess_0.start()


# Generated at 2022-06-24 19:09:34.702060
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Unit test execution
if __name__ == '__main__':
    print('Start unit test for WorkerProcess')
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:09:35.918216
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'Test start:'
    var_0 = print(str_0)

# Generated at 2022-06-24 19:09:38.137672
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

# Unit test generator for class WorkerProcess

# Generated at 2022-06-24 19:09:47.223557
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    WorkerProcess_0 = WorkerProcess(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8)
    WorkerProcess_0.start()

# Test case for class WorkerProcess

# Generated at 2022-06-24 19:10:01.133704
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:05.004022
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # test cases
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:11.002040
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:10:16.916364
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:23.474290
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    try:
        worker_process_0.run()
    except:
        pass
    else:
        assert False
    return



# Generated at 2022-06-24 19:10:25.640496
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    def test_case_0(self):
        self.run()
        assert self._final_q == False
        assert self._play_context == False
        assert self._host == True


# Generated at 2022-06-24 19:10:30.964988
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:41.289262
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.run()

if __name__ == "__main__":
    for test_function in [test_case_0, test_WorkerProcess_run, ]:
        print("[{}]: For {}:".format(test_function.__name__, test_function.__doc__))
        test_function()
        print("[{}]: Success.".format(test_function.__name__))

# Generated at 2022-06-24 19:10:43.742916
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '1+G7VBU'
    set_0 = set()
    worker_process_0 = WorkerProcess(set_0, set_0, str_0, set_0, set_0, set_0, set_0, set_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:10:48.079345
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'Ygl0U'
    bytes_0 = b'\x1c'
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    assert isinstance(worker_process_0.start(), None)


# Generated at 2022-06-24 19:11:14.832752
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    list_0 = []
    tuple_0 = ()
    int_0 = None
    str_0 = 'U\x19'

# Generated at 2022-06-24 19:11:22.993369
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = '!L'
    bytes_0 = b'|\x00'
    int_0 = -3844
    list_0 = []
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    # test case start
    worker_process_0.start()


# Generated at 2022-06-24 19:11:24.594276
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # No exception should be thrown
    test_case_0()


if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:11:25.028272
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:11:31.261752
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'c(T#o~'
    bytes_0 = b''
    int_0 = False
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:38.719707
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    # with pytest.raises(Exception):
    try:
        worker_process_0.run()
    except Exception:
        pass

# Generated at 2022-06-24 19:11:44.749713
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.run()
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.run()
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker

# Generated at 2022-06-24 19:11:52.280687
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = '|'
    bytes_0 = b'{Z4'
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()
    assert worker_process_0.exitcode is None
    worker_process_0.close()


# Generated at 2022-06-24 19:11:58.043507
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:12:00.701004
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print('Executing test_WorkerProcess_start...')
    test_case_0()


# Generated at 2022-06-24 19:12:38.909531
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()
    assert worker_process_0._new_stdin


# Generated at 2022-06-24 19:12:44.323676
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    with pytest.raises(TypeError) as error_info:
        bool_0 = None
        tuple_0 = ()
        str_0 = 'qs[8k'
        bytes_0 = b''
        int_0 = None
        list_0 = None
        worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
        worker_process_0.start()


# Generated at 2022-06-24 19:12:49.232043
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:12:50.460170
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-24 19:12:52.213137
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Setup mock args and kwargs
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)

    # Run method
    worker_process_0.run()

# Generated at 2022-06-24 19:12:57.704484
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    print("Testing start() method of class WorkerProcess")
    worker_process_0.start()
    pass


# Generated at 2022-06-24 19:13:04.607237
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    tuple_0 = ()
    str_0 = 'iu'
    bytes_0 = b'K\xe1\x9a\x14\xea\xec\x86\xb1\xac0\xfb\xc2\x8b}'
    tuple_1 = (str_0, )
    int_0 = None
    list_0 = None
    tuple_2 = (bytes_0, )
    bool_0 = True
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_1, list_0)
    worker_process_0.start()
    try:
        worker_process_0.run()
    finally:
        worker_process_0.join()


# test procedures --------------------------------------------------------------

#

# Generated at 2022-06-24 19:13:05.728321
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(False, ())
    worker_process_0.run()


# Generated at 2022-06-24 19:13:09.831479
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    _final_q_0 = None
    _task_vars_0 = None
    _host_0 = None
    _task_0 = None
    _play_context_0 = None
    _loader_0 = None
    _variable_manager_0 = None
    _shared_loader_obj_0 = None
    worker_process_0 = WorkerProcess(_final_q_0, _task_vars_0, _host_0, _task_0, _play_context_0, _loader_0, _variable_manager_0, _shared_loader_obj_0)
    try:
        worker_process_0._save_stdin()
    except:
        pass


# Generated at 2022-06-24 19:13:16.209013
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'l}>Z^t'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:14:29.705468
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.run()

if __name__ == "__main__":
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:14:35.020645
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Init local variables
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.run()


# unit tests
if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:14:35.789829
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()



# Generated at 2022-06-24 19:14:40.315365
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'z'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    worker_process_0.daemon = bool_0
    worker_process_0.start()


# Generated at 2022-06-24 19:14:47.611555
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    # test case for method run of class WorkerProcess
    try:
        worker_process_0.run()
    except Exception as e:
        print(sys.exc_info())


# Generated at 2022-06-24 19:14:52.650555
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = '2'
    bytes_0 = b'{'
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    # NOTE: another case of un-testable code because Python uses fork()
    # NOTE: instead of threading and there's no way to override it
    # NOTE: in a unit test. This calls fork() and a thread class
    # NOTE: written this way to handle a unique situation with
    # NOTE: multiprocessing, can't test without a completely different
    # NOTE: class written to be tested, and that's a lot of work
    # NOTE: for very little

# Generated at 2022-06-24 19:14:53.370293
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass



# Generated at 2022-06-24 19:14:58.775195
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Initialization
    bool_0 = True
    tuple_0 = ()
    str_0 = 'qs[8k'
    bytes_0 = b''
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)

    # Function call
    worker_process_0.run()

    # Verifying if test could be executed
    assert True == True

# Generated at 2022-06-24 19:15:05.449423
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    tuple_0 = ()
    str_0 = 'Cv'
    bytes_0 = b'\x88l7\rp'
    int_0 = None
    worker_process_0 = WorkerProcess(tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, tuple_0, tuple_0)
    worker_process_0._new_stdin = None
    worker_process_0._save_stdin()
    assert worker_process_0._new_stdin is not None
    # Implement test logic here.
    # Assertions


# Generated at 2022-06-24 19:15:15.039441
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    tuple_0 = ()
    str_0 = '8=vE'
    bytes_0 = b'\x8a\x0e'
    int_0 = None
    list_0 = None
    worker_process_0 = WorkerProcess(bool_0, tuple_0, str_0, bytes_0, tuple_0, int_0, tuple_0, list_0)
    bool_1 = bool_0
    if bool_1:
        bool_1 = bool_1
    else:
        bool_1 = not bool_1
    try:
        worker_process_0.start()
    except:
        bool_1 = not bool_1

    assert bool_1

# Test case for method start of class WorkerProcess