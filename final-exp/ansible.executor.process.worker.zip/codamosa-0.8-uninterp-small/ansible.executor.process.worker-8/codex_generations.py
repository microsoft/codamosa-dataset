

# Generated at 2022-06-24 19:07:29.653815
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'I\x0cJ\\<c35'
    int_0 = 5
    str_1 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    set_0 = {'\x0b'}
    set_1 = {str_0}
    set_2 = {str_1}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_1, set_2, set_0)
    int_1 = worker_process_0.run()
    assert int_1 == None


# Generated at 2022-06-24 19:07:32.821805
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
        print("\n")
        print("Test case 0 PASSED!\n")
    except Exception as e:
        print("\n")
        print("Test case 0 FAILED!\n")
        raise(e)

if __name__ == "__main__":
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:07:34.532423
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:07:36.019854
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    worker_process_0.start()


# Generated at 2022-06-24 19:07:41.498941
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:07:47.500974
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    set_0 = {1}
    worker_process_0 = WorkerProcess("gTkPX", "T@D0T", "N1,G", 8, 3, set_0, set_0, set_0)
    class_0 = worker_process_0.__class__
    assert not hasattr(class_0, '_WorkerProcess__new_stdin')
    assert hasattr(class_0, '_WorkerProcess__new_stdin')
    var_0 = worker_process_0.start()
    assert hasattr(class_0, '_WorkerProcess__new_stdin')


# Generated at 2022-06-24 19:07:49.688347
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:07:52.544999
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'Y\n0}mF\x0b\\<v'
    int_0 = 74
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:07:54.154227
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:08:00.049937
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.run()


# Generated at 2022-06-24 19:08:11.054888
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.start()
    assert var_0 == None

# Generated at 2022-06-24 19:08:15.359000
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        # Test object creation
        worker_process_0 = WorkerProcess()
        # Test execution of method start
        var_0 = worker_process_0.start()
    except Exception:
        print("Caught exception: " + traceback.format_exc())


# Generated at 2022-06-24 19:08:17.538002
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.run()


# Generated at 2022-06-24 19:08:19.253122
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:08:22.305651
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_WorkerProcess_start_0()

# Unit test function test_WorkerProcess_start_0

# Generated at 2022-06-24 19:08:24.423891
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.start()
    assert var_0 is None


# Generated at 2022-06-24 19:08:31.012566
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    try:
        var_0 = worker_process_0.start()
    except (AttributeError, ValueError, IOError) as e:
        var_0 = str(e)
        # var_0 = "'WorkerProcess' object has no attribute 'run'"
    finally:
        # print(var_0)
        # TODO : check if the value of var_0 is correct
        assert var_0 == "'WorkerProcess' object has no attribute 'run'"


# Generated at 2022-06-24 19:08:33.814486
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Test with dummy WorkerProcess
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.start()
    assert var_0 is None


# Generated at 2022-06-24 19:08:45.494463
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
  # Verifies there is created a new WorkerProcess instance
  worker_process_0 = WorkerProcess()
  assert isinstance(worker_process_0, WorkerProcess)
  # Verifies the expected exception is raised when calling start with an invalid 'stdin' parameter
  worker_process_1 = WorkerProcess()
  with pytest.raises(Exception):
    worker_process_1.start(stdin=1)
  # Verifies that the method 'start' is returning a boolean value of False
  worker_process_2 = WorkerProcess()
  var_0 = worker_process_2.start()
  assert isinstance(var_0 == bool)
  assert var_0 == False
  # Verifies that the method 'start' is returning a boolean value of True
  worker_process_3 = WorkerProcess()
  var_0 = worker_process_3

# Generated at 2022-06-24 19:08:47.049284
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    worker_process_0.start()


# Generated at 2022-06-24 19:08:59.293637
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Generated at 2022-06-24 19:09:00.234056
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert True


# Generated at 2022-06-24 19:09:05.274441
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing

    task_q_mgr = multiprocessing.Manager()
    task_q = task_q_mgr.Queue()
    result_q = task_q_mgr.Queue()
    worker_process_0 = WorkerProcess(task_q, result_q)
    worker_process_0.start()

    worker_process_0.join()

if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:09:11.366342
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.runner.host_result import HostResult
    from ansible.vars import VariableManager
    from ansible.module_utils import basic
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from collections import namedtuple
    from ansible.executor.play_iterator import PlayIterator
    import multiprocessing
    import copy
    import json

    # Create a fake inventory file
    test_inventory = Inventory("test_inventory")
    test_inventory.add_host("test_host")

    # Create a fake variable manager
    test_variable_manager = VariableManager(loader=None, inventory=test_inventory)

    # Create a fake loader

# Generated at 2022-06-24 19:09:12.648416
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    worker_process_0.start()


# Generated at 2022-06-24 19:09:16.126099
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess('final_q', 'task_vars', 'host', 'task', 'play_context', 'loader', 'variable_manager', 'shared_loader_obj')
    worker_process_0._run()
    return worker_process_0

# Generated at 2022-06-24 19:09:24.820430
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Unit test case: test_case_0
    #
    # Create a new single instance of the class 'WorkerProcess' using the default
    # constructor.
    #
    # Call the method 'run' to test it

    # unit_test_case_0_worker_process_run: WorkerProcess.run()
    #
    # Create one instance of the class 'WorkerProcess'
    try:
        worker_process_0 = WorkerProcess()
    except Exception as e:
        display.error("Failed to create instance of WorkerProcess for unit test case.")
        display.error(to_text(e))
        sys.exit(1)

    # Call to method 'run' to test it

# Generated at 2022-06-24 19:09:37.240693
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # see test_case_N for various worker_process N

    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'ansible_user': 'root',
        'ansible_host': None
    }
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play_context = PlayContext()
    host = inventory.get_host(get_defaults('localhost'))
    host.vars = {'ansible_user': 'root', 'ansible_host': None}
    shared_loader_obj = SharedLoaderObj()
    task = Task()
    task._uuid = 'UUID'
    task.action = 'setup'
    task._variable_manager = variable_manager
    host_manager = HostManager(inventory=inventory)
   

# Generated at 2022-06-24 19:09:39.947873
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_1 = WorkerProcess()
    assert worker_process_1.run()  # TODO: test method run of class WorkerProcess


# Generated at 2022-06-24 19:09:48.274356
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from multiprocessing import Queue
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.loader import connection_loader

    class TestCallback(CallbackBase):
        def __init__(self):
            self.messages = {}

        def v2_playbook_on_handler_task_start(self, task):
            self.messages['task_start'] = task._uuid

# Generated at 2022-06-24 19:10:03.129590
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    start_0 = worker_process_0.start()
    assert start_0 is None, 'Failed at lines below: \n94, 97, 98'

# Test Trace #1

# Generated at 2022-06-24 19:10:09.390348
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        print('Testing start()')
        test_case_0()
        print('unit test for start completed')
    except Exception as e:
        print('EXCEPTION: %s' % e)
        traceback.print_exc()

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:10:13.986240
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '\x1c`'
    set_0 = set()
    str_1 = '\\'
    set_1 = {str_0, str_1}
    worker_process_0 = WorkerProcess(str_1, str_0, str_0, str_0, str_0, set_0, set_0, set_1)
    worker_process_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:10:19.900717
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.run()

# Generated at 2022-06-24 19:10:24.563286
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Create some test objects
    str_0 = 'P_|\x7f'
    int_0 = 89
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    # Test method start of class WorkerProcess
    test_case_0()


# Generated at 2022-06-24 19:10:30.665001
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'WX+l{x"<'
    str_1 = 'Aoc\x1a'
    int_0 = 0
    str_2 = '`H\\`'
    set_0 = {str_1, str_2}
    worker_process_0 = WorkerProcess(str_0, str_1, str_1, str_0, str_0, int_0, set_0, set_0)
    worker_process_0.run()



# Generated at 2022-06-24 19:10:36.731836
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    int_0 = 74
    float_0 = 0.47167622932715405
    float_1 = 0.004444314291436705
    set_0 = {float_1, int_0, float_0}
    worker_process_0 = WorkerProcess(int_0, float_0, float_1, int_0, int_0, set_0, set_0, set_0)
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.run()
    worker_process_0.start()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:10:41.932155
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Initialize worker_process_0
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    try:
        # Call method start of worker_process_0
        var_0 = worker_process_0.start()
    except Exception as e:
        var_1 = str(e)


# Generated at 2022-06-24 19:10:46.319403
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '9eO?R|{0)<a'
    int_0 = 49
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:10:52.597395
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        # Set up test values
        temp_file_0_path = 'p/G`6,$N0?\\\'Da\\f{G#31'
        temp_file_0_fd = 43
        temp_file_0 = open(temp_file_0_path, 'r')

        # Perform the method call
        WorkerProcess.run(temp_file_0, temp_file_0_fd)

        # Check the results
        assert True # logged message indicates test passed
    except Exception:
        # Clean up
        try:
            if temp_file_0 is not None:
                temp_file_0.close()
        except Exception:
            pass
        raise


if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:11:15.435779
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.run()



# Generated at 2022-06-24 19:11:23.299054
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        str_0 = 'gUkTo7a%cO?O'
        int_0 = 46
        set_0 = {int_0}
        worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
        worker_process_0.run()
        worker_process_0.start()
    except:
        print(sys.exc_info()[1])


# Generated at 2022-06-24 19:11:26.404498
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:11:30.868160
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '8W5<?R'
    int_0 = 20
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:11:41.263787
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    int_0 = 55
    str_0 = 'UQ$\x1dRU)OS^9\x13\x02\x07\x1f\x04\x01\x1b\x02\r\x04'
    int_1 = 70
    str_1 = 'W8G:!t"_"t\\/\\QS'
    # str_0 is a hostname
    # str_1 is a task
    # int_0 is a task id
    # int_1 is a expected results
    worker_process_0 = WorkerProcess(str_0, str_0, str_1, int_0, int_1, str_1, str_0, int_0)
    assert worker_process_0.start() == int_1

# Generated at 2022-06-24 19:11:45.184429
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.start()
    worker_process_0.run()

# Generated at 2022-06-24 19:11:50.811380
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    """
    Method start of class WorkerProcess
    """
    str_0 = 'R*\x1f?\x19x\x00\x0f\x07\x14\t_\x12\x1d\x02\x15\x1f<\r\x1d\x1f\x13!\x02\x05\x17A\x1fK'
    int_0 = 156
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:11:52.982162
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert test_case_0() == None, "The function should return None"

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:11:58.092719
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'e'
    int_0 = 71
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.start()
    test_case_0()

test_WorkerProcess_start()

# Generated at 2022-06-24 19:12:06.743002
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    int_0 = 70
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    float_0 = float(0)
    set_0 = {float_0, str_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:12:45.899320
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 19:12:49.727240
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '0'
    str_1 = '1'
    str_2 = '2'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_1, str_2, int_0, int_0, set_0, set_0, set_0)
    # var_0 = worker_process_0.start()
    var_0 = worker_process_0._run()


# Generated at 2022-06-24 19:12:53.858850
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print ("Test start")
    # Create test case
    test_case_0()
    print ("Test done")

# Generated at 2022-06-24 19:12:57.811590
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    set_0 = {75}
    str_0 = 'Y5H+1e2J'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, 75, 75, set_0, set_0, set_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:13:01.302905
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_2 = os.getpid()
    var_1 = str(var_2)
    int_0 = 70
    set_0 = {int_0}
    var_0 = WorkerProcess(var_2, var_1, var_1, int_0, int_0, set_0, set_0, set_0)
    var_0.start()


# Generated at 2022-06-24 19:13:02.659372
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess()
    worker_process_0.run()


# Generated at 2022-06-24 19:13:06.400972
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # test_case_0
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.start()



# Generated at 2022-06-24 19:13:07.008787
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Your code here ...
    pass


# Generated at 2022-06-24 19:13:13.122245
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Create an instance of class WorkerProcess with dummy arguments
    worker_process_1 = WorkerProcess('dummy_q', 'dummy_task_vars', 'dummy_host', 'dummy_task', 'dummy_play_context', 'dummy_loader', 'dummy_variable_manager', 'dummy_shared_loader_obj')
    # Run the target method
    worker_process_1.run()

# Generated at 2022-06-24 19:13:18.808295
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '$2T8zR#r!Z#MzG^q3<\\'
    int_0 = 62
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.start()
    var_1 = worker_process_0.run()
    output_0 = var_1

    assert output_0 == None


# Generated at 2022-06-24 19:14:36.649725
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'o7J\x0e"5\tS}h\x1bF\x1bv\x1f'
    int_0 = 81
    set_0 = {str_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    set_0 = worker_process_0.start()


# Generated at 2022-06-24 19:14:39.433947
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except:
        print('test_WorkerProcess_start FAILED!')
        assert 0
    else:
        print('test_WorkerProcess_start PASSED!')
        assert 1


# Generated at 2022-06-24 19:14:46.304946
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.start()

# generated source for method _run of class WorkerProcess

# Generated at 2022-06-24 19:14:56.056835
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = 'G>_\x14|\x1eN<\x1e!\rW'
    var_0 = 'T\x7f\x0eZ\x05\x06\x1e$\x0cPf'
    var_1 = '\x13\x07\nX\x0b\x01\x1e\nQ\x18\x0cQ'
    var_2 = '\x03\x0b\x0c\x06[a'
    set_0 = {var_1}
    set_0 = {var_1}
    set_0 = {var_2}
    set_0 = {var_2}
    set_0 = {var_2}
    set_0 = {var_1}

# Generated at 2022-06-24 19:14:58.745584
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess('\r#', '', '', 0, 0, set(), set(), set())
    worker_process_0.run()
    # Test branch coverage in run()
    worker_process_0.run()


# Generated at 2022-06-24 19:15:05.961693
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    #from ansible.plugins.strategy import StrategyBase
    #strategy_base_0 = StrategyBase(strategy_base_0, strategy_base_0)
    #strategy_base_0.get_next_task_lock()
    #worker_process_0 = WorkerProcess(strategy_base_0, strategy_base_0, strategy_base_0, strategy_base_0, strategy_base_0, strategy_base_0, strategy_base_0, strategy_base_0, strategy_base_0, strategy_base_0)
    #worker_process_0.run()
    return

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:15:08.970485
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except BaseException as e:
        assert False, str(e)


# Generated at 2022-06-24 19:15:10.531177
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test:
    #   Default constructor
    # Expectation:
    #   run() should not return None
    test_case_0()

test_WorkerProcess_run()

# Generated at 2022-06-24 19:15:12.559130
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess('', '', '', 0, '', {}, {}, {})
    assert worker_process_0.run() is None

# Generated at 2022-06-24 19:15:17.116633
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'E\r !ZNF$]zE\x0cJ\\<c35'
    int_0 = 70
    set_0 = {int_0}
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, int_0, int_0, set_0, set_0, set_0)
    var_0 = worker_process_0.start()
