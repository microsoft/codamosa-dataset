

# Generated at 2022-06-24 19:07:28.702835
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'b\x99s\x1a\x7f\xcb'
    bool_0 = True
    complex_0 = None
    float_0 = 692.6774349735346
    str_0 = 'c%\xde'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:07:36.371497
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)

    # exception raised
    try:
        float_0 = float_0 / float_0
        raise Exception('wrong exception')
    except ZeroDivisionError:
        pass


# Generated at 2022-06-24 19:07:41.364264
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    args = {"final_q": None, "task_vars": None, "host": None, "task": None, "play_context": None, "loader": None, "variable_manager": None, "shared_loader_obj": None}

    # Case 0: no args
    worker_process_0 = WorkerProcess()

    # Case 1: with args
    worker_process_1 = WorkerProcess(**args)

# Generated at 2022-06-24 19:07:47.820348
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:07:53.662273
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\x08$\x88\x02\x8b\x9b\x9fI\xa4\x05\x01\x06\xa4\x04\xb4'
    float_0 = 1089.95948361
    bool_0 = False
    complex_0 = None
    str_0 = 'WorkerProcess.run'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    try:
        worker_process_0.run()
    except Exception as exception_0:
        print('Traceback (most recent call last):')
        print_tb(exception_0.__traceback__, limit=None, file=None)
       

# Generated at 2022-06-24 19:08:02.531886
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    #  Create a WorkerProcess object
    WorkerProcess_0 = WorkerProcess(b'\x04\xc6\xef6\xf7\xaeA\x80\xc4~\x8e@\xab\x06\x1d', 813.6, True, complex(real=0.8091674054264, imag=0.2829515243818), 0.0, b'\xe0\xaa\xc2\x00\xc1\xae\x14\x9d\x8b\xae|\x03\xce\xc1D\xc8', 818.7821239603729, 4.8)
    #  Start the process

# Generated at 2022-06-24 19:08:06.706587
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()
    worker_process_0.start()


# Generated at 2022-06-24 19:08:13.355485
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\x14\xfe\xc8\xd7'
    bool_0 = True
    complex_0 = -1.795635289927514j
    float_0 = 9723.575987188061
    str_0 = '\rF\x1a\x0b'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 19:08:24.704161
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    with multiprocessing_context.Manager() as manager_0:
        with multiprocessing_context.Process(target=worker_process_0._run(), args=()) as process_0:
            print(process_0.is_alive())
            process_0.start()
            print(process_0.name)

# Generated at 2022-06-24 19:08:36.655758
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\x0e\x87\xed\x0b\x0cJ'
    bool_0 = True
    complex_0 = None
    float_0 = 3174.4622445948084
    str_0 = '+6X\x1d\x19'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    try:
        worker_process_0.run()
    except AssertionError:
        pass
    except:
        raise Exception


if __name__ == '__main__':

    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:52.304132
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    task = TaskExecutor()
    WorkerProcess.run(task)


# Generated at 2022-06-24 19:08:54.656826
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert True


# Generated at 2022-06-24 19:09:02.231979
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # An instance of the class
    WorkerProcess_0 = WorkerProcess(multiprocessing_context.Queue, dict(), ansible.inventory.host.Host, ansible.playbook.task.Task, ansible.playbook.play_context.PlayContext, ansible.plugins.loader.PluginLoader, ansible.vars.manager.VariableManager, ansible.parsing.dataloader.DataLoader)
    # Call the start method
    test_case_0()


# Generated at 2022-06-24 19:09:05.003490
# Unit test for method run of class WorkerProcess

# Generated at 2022-06-24 19:09:13.504547
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from multiprocessing import Queue
    final_q = Queue()
    task_vars = dict()
    host = str()
    task = str()
    play_context = str()
    loader = str()
    variable_manager = str()
    shared_loader_obj = str()
    worker = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)

    # call method run
    test_return = worker.run()
    assert test_return == None, 'Return value of method run must be None.'
    assert test_return == None, 'Return value of method start must be None.'

# Generated at 2022-06-24 19:09:21.374742
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 7466.936466203614
    bool_0 = False
    float_2 = 3272.066288953663
    str_0 = '\x1b\x1b\x1b\x1b'
    dict_0 = dict()
    dict_0['str_0'] = '\x1b\x1b\x1b\x1b'
    dict_0['float_0'] = 7466.936466203614
    dict_0['bool_0'] = False
    dict_0['float_2'] = 3272.066288953663
    dict_0['float_1'] = 7466.936466203614
    dict_0['float_3'] = 7466.936466203614
    dict_0['float_4']

# Generated at 2022-06-24 19:09:23.133944
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    workerprocess_0 = WorkerProcess()
    workerprocess_0._hard_exit(Exception())
    workerprocess_0._run()


# Generated at 2022-06-24 19:09:32.011763
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Pending fix for https://bugs.python.org/issue10977
    return

    import multiprocessing

    final_q = multiprocessing.Manager().Queue()
    task_vars = {'vars': {'test_var': 'test_value'}}
    host = 'host'
    task = 'task'
    play_context = 'play_context'
    loader = 'loader'
    variable_manager = 'variable_manager'
    shared_loader_obj = 'shared_loader_obj'
    worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj,)
    worker_process.start()
    worker_process._new_stdin.close()


# Generated at 2022-06-24 19:09:36.763266
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    WorkerProcess_instance = WorkerProcess(None, None, None, None, None, None, None, None)
    if sys.version_info[0] >= 3:
        assert_exception = OSError
    else:
        assert_exception = AssertionError
    assert_exception = None
    try:
        WorkerProcess_instance.start()
    except assert_exception as error:
        print('AssertionError: ', error)


# Generated at 2022-06-24 19:09:41.251045
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\x14\xfe\xc8\xd7'
    bool_0 = True
    float_0 = 9723.575987188062
    str_0 = '\rF\x1a\x0b'



# Generated at 2022-06-24 19:09:53.060676
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.run()


# Generated at 2022-06-24 19:09:58.110992
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\x12\xec\xb6c\x0e\xa9\x90\xe1\xae\x91\x84\xad'
    bool_0 = False
    complex_0 = None
    float_0 = 0.140086
    str_0 = '0Y-^\xa6\xe3\x9e\xd3\xf7\x98\xab\xe2'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    try:
        worker_process_0.run()
    except Exception as exception_0:
        assert False


# Generated at 2022-06-24 19:09:59.339992
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:10:02.596952
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:10:10.570427
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = None
    bool_0 = False
    complex_0 = None
    float_0 = -1896.03
    str_0 = 'm|\x1d\x1a|WjSSv\x9f0\xb4\x03\x8f'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:21.097219
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Setup
    bytes_0 = b'\xfa\xda'
    bool_0 = True
    complex_0 = complex(9.9, 0)
    float_0 = 1795.9727367733409
    str_0 = 'O\x08\x00\x00\x00\x00\x00\x00'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    # Test
    worker_process_0.run()

if __name__ == '__main__':
    import subprocess
    import tempfile
    import unittest
    from multiprocessing import Process, JoinableQueue

    from ansible.playbook.play import Play

# Generated at 2022-06-24 19:10:22.379912
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # TODO: test the method
    pass


# Generated at 2022-06-24 19:10:30.742479
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'(i\\\xec\xd6\\\xa6\x11'
    bool_0 = False
    complex_0 = None
    float_0 = 7370.874939187526
    str_0 = 'zP9_6eC7'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:37.978021
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\x9e\x0f\x17'
    bool_0 = True
    complex_0 = None
    float_0 = 578.94
    str_0 = '`YI#'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:10:42.406142
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:06.951211
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:11:15.252582
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:11:24.430108
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.run()

if __name__ == '__main__':
    # Unit test main
    import cProfile

    cProfile.run('test_WorkerProcess_run()')

# Generated at 2022-06-24 19:11:31.961671
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Prepare test objects
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    # Execute start
    worker_process_0.start()


# Generated at 2022-06-24 19:11:38.163114
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Create an instance of WorkerProcess with simple args
    worker_process_0 = WorkerProcess(
        None, {}, type('', (), {})(), {}, {}, None, None, None)

    # Call method run of worker_process_0
    worker_process_0.run()
    # remove the test directory
    shutil.rmtree("test")

test_case_0()
#test_run()

# Generated at 2022-06-24 19:11:43.589295
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    # Method run of WorkerProcess
    assert_equal(worker_process_0.run(), None)


# Generated at 2022-06-24 19:11:50.967506
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:56.111802
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)

    # Exercise the method
    worker_process_0.run()

# Generated at 2022-06-24 19:11:57.726967
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass


# Generated at 2022-06-24 19:12:08.966956
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    global bytes_0
    bytes_0 = b'd\xce\xd9\x91O\xd5\x94\x15\xfc\xdb\x96\x9c\x0f\xf7'
    global bool_0
    bool_0 = True
    global complex_0
    complex_0 = None
    global float_0
    float_0 = 496.4
    global str_0
    str_0 = '=\xed\xd9\x9cS\xe1V\xae\x05\x7f\x8c\xc6\xf4\x91\xd2'
    global worker_process_0

# Generated at 2022-06-24 19:12:55.199610
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xfe\x8a\xb5\xdc;\x83\xf9\x0f\xdb\xe5\x0e\xe1\x07\xa6\xdc\xe0\xcf\xd6\x8b\xda\xa1\x02\x01\x1b\xa0\x9e'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)

# Generated at 2022-06-24 19:13:00.021631
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'<\xf6\x0e\x82\x9d\xb7'
    bool_0 = False
    complex_0 = None
    float_0 = 1047.8716728857549
    str_0 = '@q&F>l:r^P\t'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:05.368404
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    """
    Tests the run method of the WorkerProcess class
    """
    
    # Create test values
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)

    # Call run method
    worker_process_0.run()


# Generated at 2022-06-24 19:13:13.546677
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Create instance of class WorkerProcess with dummy args
    bytes_0 = b'\x10\x9d\x0c\x9f\x8d'
    bool_0 = True
    complex_0 = None
    float_0 = 672.935220895117
    str_0 = '%U_B&'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    # Call method
    worker_process_0.start()
    # Check if method has been called
    # assert worker_process_0.start() == None


# Generated at 2022-06-24 19:13:18.596497
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:23.278667
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\x89'
    bool_0 = True
    complex_0 = 998.0
    float_0 = -881.1708254444792
    str_0 = 'g\\tF5r\\~I'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()
# Failure test for method start of class WorkerProcess

# Generated at 2022-06-24 19:13:24.006573
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()



# Generated at 2022-06-24 19:13:29.103551
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:35.457261
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b"`\xea\xef\x12B\xfc\x99\xbe\xcd"
    bool_3 = True
    float_3 = 1871.5979662306377
    str_3 = 'm\x01\x88\x8f'
    float_4 = 2446.9442244227248
    complex_4 = complex(float_4, float_4)
    str_4 = 't\x9b\xd8\xb7\x15\xd5\x05\x17'
    float_5 = 582.5566404064863
    complex_5 = complex(float_5, float_5)

# Generated at 2022-06-24 19:13:39.302551
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_1 = b'^\x8a\x80o"\xb8'
    bool_1 = False
    complex_1 = None
    float_1 = 1019.2854298521409
    str_1 = '+m_Mo@;I3K'
    worker_process_1 = WorkerProcess(bytes_1, float_1, bool_1, complex_1, float_1, str_1, float_1, complex_1)
    worker_process_1.start()
    worker_process_1.terminate()


# Generated at 2022-06-24 19:15:03.345361
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.run()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:15:12.765229
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        from multiprocessing import Queue
    except ImportError:
        from multiprocessing.queues import Queue
    bytes_0 = b'\xa1\x80\x86\r\xc5'
    str_0 = '0z-kN!Y$2,dl'
    complex_0 = (0+0j)
    bool_0 = False
    float_0 = 8186.57538671864
    queue_0 = Queue()
    worker_process_0 = WorkerProcess(queue_0, bytes_0, str_0, complex_0, bool_0, float_0, float_0, float_0, float_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:15:17.502193
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    cmd = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    worker_process_0 = WorkerProcess(cmd, 1.0, False, None, 10.09 / 2.0, 'XsWd-6`B', 1.0, None)
    worker_process_0.start()


# Generated at 2022-06-24 19:15:19.644048
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    '''
    Unit test for method run of class WorkerProcess
    '''
    test_case_0()

# Generated at 2022-06-24 19:15:23.145805
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess()
    worker_process_0.run()


# Generated at 2022-06-24 19:15:26.770612
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:15:29.533747
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert True == True

# Generated at 2022-06-24 19:15:34.901205
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    try:
        worker_process_0.run()
    except Exception:
        assert False


# Generated at 2022-06-24 19:15:41.788736
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'^\x8a\x80o"\xb8'
    bool_0 = False
    complex_0 = None
    float_0 = 1019.2854298521409
    str_0 = '+m_Mo@;I3K'
    worker_process_0 = WorkerProcess(bytes_0, float_0, bool_0, complex_0, float_0, str_0, float_0, complex_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:15:43.791739
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # TODO: Implement method
    pass
