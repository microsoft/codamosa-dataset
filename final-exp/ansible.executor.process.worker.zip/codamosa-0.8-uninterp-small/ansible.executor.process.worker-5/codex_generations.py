

# Generated at 2022-06-24 19:07:24.115446
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:07:29.457979
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = None
    bytes_0 = b''
    set_0 = {float_0, float_0}
    list_0 = [float_0, float_0, set_0, float_0]
    int_0 = 753
    worker_process_0 = WorkerProcess(float_0, bytes_0, set_0, list_0, int_0, int_0, bytes_0, bytes_0)
    worker_process_0._save_stdin()
    worker_process_0.start()


# Generated at 2022-06-24 19:07:31.002438
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)


# Generated at 2022-06-24 19:07:39.247729
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        import cStringIO as StringIO
    except ImportError:
        import StringIO
    import sys
    import traceback
    import unittest

    class TestStart(unittest.TestCase):

        @unittest.skipIf(sys.version_info < (3, 0), "This tests a python3 specific behavior")
        def test_start(self):
            # Test that we don't hang on a deadlock during stdout/stderr flushing
            # upon process exit.
            old_stdout, old_stderr = sys.stdout, sys.stderr
            sys.stdout, sys.stderr = new_stdout, new_stderr = StringIO.StringIO(), StringIO.StringIO()

# Generated at 2022-06-24 19:07:44.744102
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = None
    bytes_0 = b''
    set_0 = {float_0, float_0}
    list_0 = [float_0, float_0, set_0, float_0]
    int_0 = 753
    worker_process_0 = WorkerProcess(float_0, bytes_0, set_0, list_0, int_0, int_0, bytes_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:07:49.918119
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = None
    bytes_0 = b''
    set_0 = {float_0, float_0}
    list_0 = [float_0, float_0, set_0, float_0]
    int_0 = 753
    worker_process_0 = WorkerProcess(float_0, bytes_0, set_0, list_0, int_0, int_0, bytes_0, bytes_0)
    try:
        worker_process_0.run()
    except Exception:
        pass


# Generated at 2022-06-24 19:07:56.350180
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = None
    bytes_0 = b''
    set_0 = {float_0, float_0}
    list_0 = [float_0, float_0, set_0, float_0]
    int_0 = 753
    worker_process_0 = WorkerProcess(float_0, bytes_0, set_0, list_0, int_0, int_0, bytes_0, bytes_0)
    worker_process_0.run = worker_process_0._run
    worker_process_0.start()


# Generated at 2022-06-24 19:08:01.053916
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = None
    bytes_0 = b''
    set_0 = {float_0, float_0}
    list_0 = [float_0, float_0, set_0, float_0]
    int_0 = 753
    worker_process_0 = WorkerProcess(float_0, bytes_0, set_0, list_0, int_0, int_0, bytes_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:08:07.999352
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = None
    bytes_0 = b''
    set_0 = {float_0, float_0}
    list_0 = [float_0, float_0, set_0, float_0]
    int_0 = 532

    worker_process_0 = WorkerProcess(float_0, bytes_0, set_0, list_0, int_0, int_0, bytes_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:08:14.454228
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    list_0 = []
    float_0 = None
    bytes_0 = b''
    set_0 = {float_0, float_0}
    tuple_0 = ()
    int_0 = 753
    worker_process_0 = WorkerProcess(float_0, bytes_0, set_0, tuple_0, int_0, int_0, bytes_0, bytes_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:08:26.422625
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    assert not hasattr(worker_process_0, "var_1")


# Generated at 2022-06-24 19:08:31.827024
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    worker_process_1 = WorkerProcess()
    worker_process_2 = WorkerProcess()
    worker_process_2._new_stdin = "/"
    worker_process_2.start()
    worker_process_1._save_stdin()


# Generated at 2022-06-24 19:08:35.992576
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_1 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_1.run()

test_case_0()
test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:36.845721
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass


# Generated at 2022-06-24 19:08:39.247757
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process.start()


# Generated at 2022-06-24 19:08:42.837512
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    print("test")


# Generated at 2022-06-24 19:08:45.775304
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print("\nMethod start of class WorkerProcess")
    # debug
    print("\nCase 0")
    test_case_0()



# Generated at 2022-06-24 19:08:49.039114
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:51.895395
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start = test_case_0
    worker_process_0.run()


# Generated at 2022-06-24 19:09:00.247129
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    var_0 = None
    worker_process_0._final_q = var_0
    var_0 = None
    worker_process_0._task_vars = var_0
    var_0 = None
    worker_process_0._host = var_0
    var_0 = None
    worker_process_0._task = var_0
    var_0 = None
    worker_process_0._play_context = var_0
    var_0 = None
    worker_process_0._loader = var_0
    var_0 = None
    worker_process_0._variable_manager = var_0


# Generated at 2022-06-24 19:09:11.764554
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)


# Generated at 2022-06-24 19:09:14.163098
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:09:17.663416
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:09:20.739247
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:09:25.508631
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    args = (None,)
    kwargs = {'task_vars': None, 'host': None, 'task': None, 'play_context': None, 'loader': None, 'variable_manager': None, 'final_q': None}
    worker_process_0 = WorkerProcess(*args, **kwargs)
    worker_process_0.run()


# Generated at 2022-06-24 19:09:28.681403
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    assert worker_process_0.run() == None


# Generated at 2022-06-24 19:09:35.119440
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    # test that function returns something
    var_1 = worker_process_0.run()


# Generated at 2022-06-24 19:09:36.520073
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process = test_case_0()
    worker_process.start()



# Generated at 2022-06-24 19:09:38.939148
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process = WorkerProcess()
    worker_process.run()

test_case_0()

# Generated at 2022-06-24 19:09:46.694652
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    worker_process_0 = WorkerProcess(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    # Call method start of class WorkerProcess
    worker_process_0.start()


# Generated at 2022-06-24 19:10:07.023597
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:12.139705
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None

    # Test setup: create mock object of TaskExecutor
    var_1 = TaskExecutor(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    def side_effect_func():
        return var_1.run()

    side_effect_0 = side_effect_func

    # Mock object of TaskExecutor class
    var_1.run = side_effect_0

    # Create mock object of class WorkerProcess
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    # Assign mock object of TaskExecutor class to attribute of class WorkerProcess
    worker_process_0._final_q = var

# Generated at 2022-06-24 19:10:18.687786
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print(WorkerProcess.run)
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    try:
        worker_process_0.run()
    except:
        pass


# Run the unit test of method run of class WorkerProcess
#test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:26.776177
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import multiprocessing as mp
    import queue
    # Test with a queue of one, just to get coverage data
    final_q = mp.Queue(1)
    worker_process_object = WorkerProcess(final_q, 'task_vars', 'host', 'task', 'play_context', 'loader', 'variable_manager', 'shared_loader_obj')
    worker_process_run_process = mp.Process(target=worker_process_object.run)
    worker_process_run_process.start()
    worker_process_run_process.join()
    # Check if there is any Queue value even after the worker process has terminated, for that matter its Queue value should be empty
    worker_process_run_process_queue_size = final_q.qsize()

# Generated at 2022-06-24 19:10:33.523040
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()



# Generated at 2022-06-24 19:10:39.358310
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:49.350206
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)

    # Test assumptions
    assert isinstance(worker_process_0, multiprocessing_context.Process)

    # Test preconditions
    assert hasattr(worker_process_0, '_clean_up')
    assert hasattr(worker_process_0, '_run')
    assert hasattr(worker_process_0, '_save_stdin')
    assert hasattr(worker_process_0, 'run')

    assert callable(worker_process_0._clean_up)
    assert callable(worker_process_0._run)
    assert callable(worker_process_0._save_stdin)
    assert callable(worker_process_0.run)

    # Test preconditions

# Generated at 2022-06-24 19:10:54.025944
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:10:59.268408
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = None
    try:
        worker_process_0.run()
        var_1 = None
    except Exception as var_1:
        pass
    assert var_1 is None

# Generated at 2022-06-24 19:11:03.792703
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.run = MagicMock(return_value=None)
    worker_process_0.start()
    worker_process_0.run.assert_called_with()


# Generated at 2022-06-24 19:11:42.641389
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var__final_q = None
    var__task_vars = None
    var__host = None
    var__task = None
    var__play_context = None
    var__loader = None
    var__variable_manager = None
    var__shared_loader_obj = None
    worker_process_0 = WorkerProcess(var__final_q, var__task_vars, var__host, var__task, var__play_context, var__loader, var__variable_manager, var__shared_loader_obj)
    # Start a process and return its associated Process object.
    # This method actually starts the process.
    # start() has no return value.
    worker_process_0.start()


# Generated at 2022-06-24 19:11:48.600908
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.run()

if '__main__' == __name__:
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:11:56.370434
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    try:
        from queue import Queue
    except ImportError:
        from Queue import Queue
    var_1 = Queue()
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    try:
        var_11 = WorkerProcess(var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8)
        var_11.start()
    except Exception as var_10:
        var_9 = var_10
    assert var_9 is None


# Generated at 2022-06-24 19:12:04.411047
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

if __name__ == '__main__':
    import sys
    import traceback
    import pytest
    from mock import patch
    from test.support.unit import skipTest
    from ansible.errors import AnsibleConnectionFailure
    from ansible.utils.multiprocessing import context as multiprocessing_context

    # Patch pytest
    m_pytest = patch.multiple(pytest, __file__=__file__, PytestDeprecationWarning=pytest.PytestWarning, PytestExperimentalApiWarning=pytest.PytestWarning)
    m_pytest.start()

    # We patch multiprocessing here due to the fact that it is gone in Python 3.7 on Windows.
    # We do not add a requirement for a backport of the module on Windows and test under Python 3

# Generated at 2022-06-24 19:12:05.760887
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass


# Generated at 2022-06-24 19:12:16.409693
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    from ansible.executor.task_result import TaskResult
    task_result_0 = TaskResult(worker_process_0)
    var_0 = None
    try:
        var_1 = task_result_0._to_json()
    except Exception:
        var_1 = None
    try:
        var_2 = task_result_0._to_data()
    except Exception:
        var_2 = None
    try:
        var_3 = task_result_0.as_dict()
    except Exception:
        var_3 = None
    try:
        var_4 = task_result_0.change
    except Exception:
        var_4 = None

# Generated at 2022-06-24 19:12:22.048666
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Test ast.literal_eval()
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    # Test return value.
    returned = worker_process_0.start()
    # Test type of return value.
    assert isinstance(returned, types.NoneType)


# Generated at 2022-06-24 19:12:28.957580
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    try:
        worker_process_0.run()
    except Exception as e:
        assert False


# Generated at 2022-06-24 19:12:35.136119
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_1 = None
    worker_process_0 = WorkerProcess(var_1, var_1, var_1, var_1, var_1, var_1, var_1, var_1)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:12:37.872674
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:46.664353
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except:
        print('Exception')

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:13:49.611430
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    # Test with valid arguments
    try:
        worker_process_0.run()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 19:13:53.501612
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    try:
        worker_process_0.start()
    except Exception:
        display.debug("Caught exception in worker process")


# Generated at 2022-06-24 19:14:01.355540
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_1 = None
    worker_process_0 = WorkerProcess(var_1, var_1, var_1, var_1, var_1, var_1, var_1, var_1)

    # START OF FILE test_ansible_module_template.py.example_1
    #
    # end of file test_ansible_module_template.py.example_1
    #
    # START OF FILE test_ansible_module_template.py.example_2
    #
    # end of file test_ansible_module_template.py.example_2


# Generated at 2022-06-24 19:14:02.766752
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

# Generated at 2022-06-24 19:14:05.019491
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)

    # Call method start to execute the unit under test
    # No assertions to perform



# Generated at 2022-06-24 19:14:06.924526
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    # call function
    worker_process_0.start()


# Generated at 2022-06-24 19:14:10.433522
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.start()



# Generated at 2022-06-24 19:14:18.752673
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    try:
        var_2 = WorkerProcess(var_3, var_4, var_5, var_6, var_7, var_8, var_9, var_10)
        var_2.start()
        var_11 = True
    except Exception:
        var_11 = False
    assert var_11 == False


# Generated at 2022-06-24 19:14:23.670080
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:16:40.848532
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # Variation 1: assert that _save_stdin gets called
    var_1 = None
    worker_process_1 = WorkerProcess(var_1, var_1, var_1, var_1, var_1, var_1, var_1, var_1)
    worker_process_1._save_stdin = MagicMock(return_value=None)
    worker_process_1._save_stdin.return_value = None
    worker_process_1.start()
    assert worker_process_1._save_stdin.called
    assert worker_process_1._save_stdin.call_count == 1

# Unit tests for method _run of class WorkerProcess

# Generated at 2022-06-24 19:16:45.744834
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_1 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_1._save_stdin()
    worker_process_1._run()
    worker_process_1._hard_exit(None)


# Generated at 2022-06-24 19:16:47.860671
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    multiprocessing_context_1 = multiprocessing_context
    from multiprocessing import Process
    assert isinstance(multiprocessing_context_1.Process.start(var_0), Process)


# Generated at 2022-06-24 19:16:51.217216
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    try:
        worker_process_0.run()
    except Exception as exception_0:
        print(exception_0)

if __name__ == '__main__':
    print(test_case_0())
    print(test_WorkerProcess_run())

# Generated at 2022-06-24 19:16:58.024980
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        var_0 = None
        worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
        worker_process_0.start()
    except Exception as err:
        print(err)

if __name__ == '__main__':

    test_WorkerProcess_start()
    test_case_0()

# Generated at 2022-06-24 19:17:09.347090
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    var_0 = None
    worker_process_0 = WorkerProcess(var_0, var_0, var_0, var_0, var_0, var_0, var_0, var_0)
    worker_process_0.run()

if __name__ == "__main__":
    import sys
    import inspect
    import traceback

    try:
        test_name = sys.argv[1]
    except:
        print('Missing Test Arg. Exiting')
        raise

    print('Starting unit test')

    task_names = [x[0] for x in inspect.getmembers(sys.modules[__name__], inspect.isfunction) if x[0].startswith('test_')]
    if test_name in task_names:
        globals()[test_name]()

# Generated at 2022-06-24 19:17:16.007436
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    worker_process_0 = WorkerProcess(var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7)
    worker_process_0.start()
