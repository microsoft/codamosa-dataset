

# Generated at 2022-06-24 19:07:26.577805
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

test_WorkerProcess_run()

# Generated at 2022-06-24 19:07:33.174393
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Setup input arguments to the method.
    def test_case_0():
        float_0 = 2985.92640
        bool_0 = False
        complex_0 = None
        set_0 = None
        int_0 = 380
        bytes_0 = b'\r\x8a\x10\xd0\x81\xfb\x9b\xaf\xea\xfe\x8c\xcd\xe7\x1f\xcf'
        worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
        return worker_process_0
    worker_process_0 = test_case_0()

    # Invoke method.
    worker_process_0.run()



# Generated at 2022-06-24 19:07:42.308544
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_1 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()
    worker_

# Generated at 2022-06-24 19:07:48.257791
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 694.265725
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = -1
    bytes_0 = b'\x9c\xed\x87\x03\x8a\xdb\xae\x10\xcf\x16'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.run()



# Generated at 2022-06-24 19:07:53.215447
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)

    # Example 1
    assert worker_process_0.start() == None



# Generated at 2022-06-24 19:08:02.811964
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # We should probably make the constructor take all of these for this test case
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    set_1 = None
    int_0 = 438
    int_1 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'

    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)

    # We should probably move this to the constructor
    worker_process_0.start()

    # Call

# Generated at 2022-06-24 19:08:03.370760
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:08:05.545949
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    string_0 = ''
    item_0 = 3.3
    complex_0 = WorkerProcess(string_0, item_0, string_0)
    complex_0.run()
    complex_0.run()
    complex_0.run()
    complex_0.run()
    complex_0.run()
    complex_0.run()
    complex_0.run()

# Generated at 2022-06-24 19:08:06.426343
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process = WorkerProcess()
    worker_process.start()


# Generated at 2022-06-24 19:08:10.205984
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 12345.6789
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 1234567890
    bytes_0 = b'\x15'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()
    worker_process_0.run()

test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:22.879345
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:08:28.556681
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Run test case 0
    test_case_0()

if __name__ == "__main__":
    # Run test cases
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:08:31.867697
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Calling run method of WorkerProcess class with args

    print("Testing WorkerProcess Class")
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.run()


# Generated at 2022-06-24 19:08:33.978232
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:08:35.541789
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.start()



# Generated at 2022-06-24 19:08:39.804196
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = WorkerProcess()
    var_1 = var_0.start()
    assert var_1 is None, 'AssertionError: {0} != {1}'.format('None', var_1)


# Generated at 2022-06-24 19:08:40.761024
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_0 = WorkerProcess()
    var_0.start()


# Generated at 2022-06-24 19:08:43.648870
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    self_t = WorkerProcess(None, None, None, None, None, None, None, None)
    self_t._run()


# Generated at 2022-06-24 19:08:46.216786
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess()
    var_0 = worker_process_0.run()


# Generated at 2022-06-24 19:08:47.073749
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:09:01.658759
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Testing parameters
    worker_process_0 = WorkerProcess()
    worker_process_0.run()


test = 0
if test:
    test_case_0()

# Generated at 2022-06-24 19:09:04.368090
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert True



# Generated at 2022-06-24 19:09:11.760011
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test with a dummy class instead of multiprocessing.Queue
    class dummy_queue():
        def __init__(self, data):
            self.data = data
        def put(self, entry):
            self.data.append(entry)
        def get(self):
            return self.data.pop()
        def empty(self):
            return len(self.data) == 0

    data = [{'msg': 'dummy data'}]
    q = dummy_queue(data)
    worker_process_0 = WorkerProcess(q)
    worker_process_0.run()
    assert len(q.data) == 1
    assert q.data[0] == {'msg': 'dummy data'}

# Generated at 2022-06-24 19:09:13.018603
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # no test case at the moment
    pass


# Generated at 2022-06-24 19:09:15.147676
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    return None

# Generated at 2022-06-24 19:09:23.395187
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash

    variable_manager = VariableManager()
    loader = DataLoader()

    variable_manager.extra_vars = { "hostvars": {} } # 'hostvars': {'hostname1': {'new_var': 'foo', 'var1': 'bar'}, 'hostname2': {'var1': 'other'}} }

    inv_host = Host(name="hostname")

# Generated at 2022-06-24 19:09:26.331589
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print("")
    print("test_WorkerProcess_run()")
    print("")
    w = WorkerProcess()
    w.run()

# unit test for class WorkerProcess

# Generated at 2022-06-24 19:09:31.209072
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Find out the number of tasks that we have to carry out
    # Iterate over the number of tasks and run the functionality of the above method
    # If the number of tasks exceeds 1, then only then multiprocessing is used
    # If the number of tasks is 1, then the above code is run only in a single process
    pass

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:09:33.852236
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    try:
        worker_process_0.start()
    except:
        assert False, "WorkerProcess.start() raised exception"
    return True


# Generated at 2022-06-24 19:09:35.520210
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_start = WorkerProcess()
    worker_process_start.start()


# Generated at 2022-06-24 19:09:53.660762
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 23.4348
    dict_0 = dict()
    dict_0['set_0'] = set()
    dict_0['set_1'] = set()
    dict_0['set_2'] = set()
    dict_0['dict_0'] = dict()
    dict_0['dict_1'] = dict()
    dict_0['dict_2'] = dict()
    dict_0['dict_2']['str_1'] = None
    dict_0['dict_2']['str_0'] = 'dict_1'
    dict_0['dict_2']['str_2'] = 'dict_2'
    dict_0['dict_2']['float_0'] = float_0
    dict_0['dict_2']['float_1'] = float_0
   

# Generated at 2022-06-24 19:10:01.291685
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 3016.4005
    bool_0 = True
    complex_0 = None
    set_0 = None
    set_1 = None
    int_0 = 435
    int_1 = 674
    bytes_0 = b'\x8f\x1cs\xfb\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()

# Generated at 2022-06-24 19:10:03.432698
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    ex_0 = None
    try:
        test_case_0()
    except Exception as ex:
        ex_0 = ex
    assert True if ex_0 else False


# Generated at 2022-06-24 19:10:06.662752
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:10:13.153249
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:10:15.658956
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = None
    worker_process_0 = WorkerProcess(worker_process_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:10:24.147434
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    set_1 = None
    int_0 = 438
    int_1 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_1, int_0, int_1, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:32.365862
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Make mock
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)

    # Bad input
    with pytest.raises(TypeError):
        worker_process_0.start()


# Generated at 2022-06-24 19:10:41.317672
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:41.985968
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:11:07.496028
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = None
    bool_0 = False
    complex_0 = None
    set_0 = None
    list_0 = None
    int_0 = None
    float_1 = None
    bytes_0 = None
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, list_0, int_0, float_1, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:12.971209
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        worker_process_0 = WorkerProcess(None, None, None, None, None, None, None)
        worker_process_0.start()

    except Exception:
        assert False


# Generated at 2022-06-24 19:11:18.718641
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:21.690397
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # TODO: implement this test case
    assert(False)


# Generated at 2022-06-24 19:11:28.893998
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'.\x13\x1d\x6e\x9b\x80\x1e(\x1d\xce\xf8\x14\xe6\x9a\x9d\x07\x9b\xdb\xb3\xde\xe3\x86s'
    int_2 = 3
    float_1 = 52.0
    int_3 = 6
    float_3 = 88.0
    int_0 = 0
    float_0 = 5.387630
    complex_0 = None
    float_2 = 78.0

# Generated at 2022-06-24 19:11:35.485363
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = -20.726792
    bool_0 = True
    complex_0 = None
    set_0 = None
    str_0 = "\x1e\x18\x8e\x9e\x0d\xaa\x10\xab\x01\xaf\x1f\xb8\x1f\xe9\x15\xc2\x04\xb0\x00\x20\x00\x80\x00"
    int_0 = 0
    bytes_0 = b'\xab]\x07'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    # Test body
    worker_process_0._run() #pass
   

# Generated at 2022-06-24 19:11:42.910387
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    # Test for method start of class WorkerProcess
    # Test for method start of class WorkerProcess

# Generated at 2022-06-24 19:11:51.440729
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)

    worker_process_0.start()


# Generated at 2022-06-24 19:11:59.718614
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print("Testing start in WorkerProcess")
    set_0 = None
    int_0 = 756
    float_0 = 4197.73541
    bool_0 = False
    complex_0 = None
    bytes_0 = b'\x08\x83\xd9\x8d\x82QZ\xa1\x93H\x95\xc6\xa8\x9a\x00\xf0\x00\xd8\x16\x08'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()
    assert True # TODO: implement your test here



# Generated at 2022-06-24 19:12:09.339417
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    # Test with a condition on which the function should return NULL
    worker_process_0.run()
    worker_process_0.run()
    # Test with a condition on which the function should return NULL
    worker_process_0.run

# Generated at 2022-06-24 19:12:55.019134
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:13:03.857852
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = -2.1358483
    bool_0 = True
    complex_0 = None
    set_0 = None
    set_1 = None
    int_0 = -272
    int_1 = -137
    bytes_0 = b'\xd9\x0f\xa5\x14\x00\x00\x00\x00\x00\x00\xf0?\xf0?\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_1, int_0, int_1, bytes_0)
    with pytest.raises(TypeError):
        worker_process

# Generated at 2022-06-24 19:13:10.729900
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 201.633
    int_0 = -693
    complex_0 = complex(int_0, float_0)
    set_0 = set(('a', 'f', 't'))
    dict_0 = dict()
    dict_0['a'] = complex_0
    dict_0['b'] = set_0
    dict_0['c'] = set_0
    dict_0['d'] = int_0
    dict_0['e'] = int_0
    dict_0['f'] = bytes()
    dict_0['g'] = dict_0
    dict_0['h'] = dict_0
    dict_0['i'] = dict_0
    dict_0['j'] = dict_0
    dict_0['k'] = dict_0

# Generated at 2022-06-24 19:13:20.090262
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
  new_WorkerProcess = None
  try:
      new_WorkerProcess = WorkerProcess(1.0, True, None, None, None, 428, 803, b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd')
  except ValueError:
      # We expect this to fail
      pass

# Generated at 2022-06-24 19:13:27.897077
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_2 = 2774.11847
    bool_2 = True
    complex_2 = None
    set_2 = None
    int_2 = 438
    bytes_2 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_2 = WorkerProcess(float_2, bool_2, complex_2, set_2, set_2, int_2, int_2, bytes_2)
    worker_process_2.start()


# Generated at 2022-06-24 19:13:33.142939
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:38.414448
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Setup
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    set_1 = None
    int_0 = 438
    int_1 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_1, int_0, int_1, bytes_0)
    worker_process_0.run()
    # Teardown



# Generated at 2022-06-24 19:13:46.329950
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:13:54.722138
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Construct object
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)

    # Invoke method
    worker_process_0.run()



# Generated at 2022-06-24 19:13:56.924209
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
  pass


# Generated at 2022-06-24 19:15:20.938143
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.run()
    worker_process_0._run()


# Generated at 2022-06-24 19:15:27.812267
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print('# Unit test for method start of class WorkerProcess')
    float_0 = 893.85819
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 4
    bytes_0 = b'\x81\xb5\xd6\x0e\\\x9a\x7f\x93\xf4\x92\xf5\xe7'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()



# Generated at 2022-06-24 19:15:32.579311
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.start()



# Generated at 2022-06-24 19:15:37.429704
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print("test_start")

    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    if sys.version_info < (3, 3):
        with pytest.raises(NotImplementedError):
            assert worker_process_0.start() == NotImplemented

# Generated at 2022-06-24 19:15:43.758753
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Process
    from multiprocessing import Queue
    from multiprocessing import Queue
    from multiprocessing import Queue
    from multiprocessing import Queue

    # Create mock methods
    def mock_Process_start(self):
        pass
    def mock_Process_is_alive(self):
        return True
    def mock_Process_save_stdin(self):
        pass
    Process.start = mock_Process_start
    mock_Process_is_alive.return_value = True
    mock_Process_save_stdin.return_value = None

    # Construct arguments
    final_q = Queue()
    task_vars = Queue()
    host = Queue()
    task = Queue()
    play_context = Queue()
    loader = Queue

# Generated at 2022-06-24 19:15:52.294727
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print('start')
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.start()
    return int_0


# Generated at 2022-06-24 19:15:53.094029
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:15:54.469227
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:15:55.238303
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:16:00.862551
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    float_0 = 2774.11847
    bool_0 = True
    complex_0 = None
    set_0 = None
    int_0 = 438
    bytes_0 = b'\xa3\x10\xa8\xc1\xa0\x00)\x08\xa3V\x81.\xa0\x8c\xf7\x82\xd5\x85\xcd'
    worker_process_0 = WorkerProcess(float_0, bool_0, complex_0, set_0, set_0, int_0, int_0, bytes_0)
    worker_process_0.run()

