

# Generated at 2022-06-24 19:07:21.995287
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(b'', -268.522875, "H?'N!", b'', "", "", ["H?'N!"], b'')
    worker_process_0.run()


# Generated at 2022-06-24 19:07:28.543087
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Generate correct arguments
    final_q = None
    task_vars = None
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None
    worker_process_0 = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker_process_0.run()


# Generated at 2022-06-24 19:07:36.999584
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()

if __name__ == '__main__':
    test_WorkerProcess_run()



# Generated at 2022-06-24 19:07:43.191885
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:07:43.792445
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:07:49.387086
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:07:50.798215
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess('', '', '', '', '', '', '', '')
    worker_process_0.run()

# Generated at 2022-06-24 19:08:00.575072
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)

    worker_process_0.run()


# Generated at 2022-06-24 19:08:04.587031
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.start()
    worker_process_0.join()

# Generated at 2022-06-24 19:08:08.830863
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    worker_process_0.start()


# Generated at 2022-06-24 19:08:19.284429
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    """Test if we can successfully start a WorkerProcess process"""
    test_worker_process = WorkerProcess()


# Generated at 2022-06-24 19:08:22.879859
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process = WorkerProcess()
    assert worker_process.start() is None, 'What is the expected output?'


# Generated at 2022-06-24 19:08:25.053593
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    try:
        worker_process_0.start()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 19:08:26.169144
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process = WorkerProcess() # NOQA


# Generated at 2022-06-24 19:08:31.655048
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        sys.stdout.write('Test: start of class WorkerProcess: ')
        sys.stdout.flush()
        try:
            t_WorkerProcess = WorkerProcess()
            # for further tests, we will use the run() method...
        except:
            sys.stdout.write('FAILED\n')
            sys.stdout.flush()
            return
        sys.stdout.write('PASS\n')
        sys.stdout.flush()
    except:
        sys.stdout.write('FAILED\n')
        sys.stdout.flush()


# Generated at 2022-06-24 19:08:34.013429
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from .test_worker_process import WorkerProcess_run_TestCase
    WorkerProcess_run_TestCase.test_run()

# Generated at 2022-06-24 19:08:42.535511
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    os.environ['ANSIBLE_ROLES_PATH'] = './test/data/test_roles'
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars

    play_context = PlayContext()
    play_context._PromptModule__collect_input = False
    play_context._PromptModule__is_playbook = False
    play_context._PromptModule__is_task = True
    play_context._PromptModule__is_role = False
    play_context._PromptModule__is_module = False
    play_context._PromptModule__is_include = False
    play_context._PromptModule__variables = {}

    # TODO: this should really be marked as private
   

# Generated at 2022-06-24 19:08:43.765982
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass # No tests have been implemented for this function


# Generated at 2022-06-24 19:08:46.337084
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    worker_process_0.start()


# Generated at 2022-06-24 19:08:47.516177
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # TODO: validate the actual behavior
    assert 0 == 0



# Generated at 2022-06-24 19:09:06.511804
# Unit test for method run of class WorkerProcess

# Generated at 2022-06-24 19:09:14.219525
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    result_contains = [
        b"worker_process_0._run()",
        b"WorkerProcess.run()",
        b"WorkerProcess._run()",
        b"worker_process_0._host",
        b"worker_process_0._task",
        b"worker_process_0._task_vars",
        b"worker_process_0._play_context",
        b"worker_process_0._new_stdin",
        b"worker_process_0._loader",
        b"worker_process_0._shared_loader_obj",
        b"worker_process_0._final_q",
        b"TaskExecutor.run()",
        b"worker_process_0._clean_up()",
    ]
    test_case_0()

# Generated at 2022-06-24 19:09:22.826102
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\x15<\xe3\xff\x84\x7f\xea\xf5\xfe'
    float_0 = -218.3855
    str_0 = '\xc7\x0bY\x9a\xe3\x86\xf2\x8b\xa8\xdb\x83\xb4\x9c\x8a\xee\xda\xbc\xc8\x93\xb6'
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    try:
        worker_process_0.run()
    except Exception as e:
        print(e)

#

# Generated at 2022-06-24 19:09:27.239940
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Create a new WorkerProcess object
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)

    # Run method run of the WorkerProcess object
    worker_process_0.run()

# Generated at 2022-06-24 19:09:33.752058
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:09:39.299552
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    try:
        worker_process_0.run()
    except:
        print('Exception:')
        e = sys.exc_info()[1]
        print(str(e))


# Generated at 2022-06-24 19:09:40.356037
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:09:49.194096
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Setup:
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)

    # Unit test:
    worker_process_0.start()


# Generated at 2022-06-24 19:09:50.053424
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:09:57.166868
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:21.817981
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:10:32.642167
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    bytes_1 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    bytes_2 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list

# Generated at 2022-06-24 19:10:41.317487
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:10:47.813596
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Imports
    import os

    # Setup
    bytes_50 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_50 = -268.522875
    str_50 = "H?'N!"
    list_50 = [str_50]
    worker_process_50 = WorkerProcess(bytes_50, float_50, str_50, bytes_50, str_50, str_50, list_50, bytes_50)
    worker_process_50.start()

    # Testing
    assert os.getppid() == 1

    # Teardown
    os._exit(1)


# Generated at 2022-06-24 19:10:49.667247
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.run()


# Generated at 2022-06-24 19:10:51.461121
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:11:00.101108
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:07.596353
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # initialize object
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)

    # start test
    worker_process_0.run()

if __name__ == '__main__':
    # unit tests
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:11:15.944206
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print("Test WorkerProcess run...")
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()
    print("Test WorkerProcess run finished.")



# Generated at 2022-06-24 19:11:17.227232
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    WorkerProcess.start()

    # assert_equal(expected, start())
    assert True # TODO: implement your test here


# Generated at 2022-06-24 19:11:55.141733
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.start()
    worker_process_0.start()


# Generated at 2022-06-24 19:12:01.428462
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'E\xe9\x8e\xbf\xaf\xf6\xec[_\xe8\xef\xb7'
    float_0 = -8.62447
    str_0 = "f4,y\x1f\x7f"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()

test_WorkerProcess_run()

# Generated at 2022-06-24 19:12:08.476002
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # This insures that the test runs with the correct number of parameters
    num_args = 8
    if len(sys.argv) < num_args:
        print("Error: This test needs to be run with", num_args, "arguments")
        exit()

    # Create a worker process
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)

    print('Testing worker process run method')
    worker_process_0.run()


# Generated at 2022-06-24 19:12:12.113034
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # FIXME : test is failing
    # worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    # worker_process_0.run()
    assert True


# Generated at 2022-06-24 19:12:13.786562
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

# Generated at 2022-06-24 19:12:21.549860
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_1 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_1.start()


# Generated at 2022-06-24 19:12:30.518100
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:12:38.922324
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'm'
    float_0 = -0.77395
    str_0 = "XnP\x9d"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    list_1 = [str_0]
    worker_process_0._new_stdin = list_1
    str_1 = "Yk\x9a"
    bytes_1 = b'\x84\x97\xbd\x05\xff\x9d\x96'
    list_2 = [str_1]
    worker_process_0.__dict__[str_1] = list_2
    # Invoke method
    result

# Generated at 2022-06-24 19:12:40.732842
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    total = 0
    for _ in range(1):
        o = WorkerProcess()
        o.start()
    return total


# Generated at 2022-06-24 19:12:47.039995
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    with pytest.raises(TypeError) as exception:
        worker_process_0.start()


# Generated at 2022-06-24 19:13:57.932785
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xefq)k\x0f\xba\x17,\x9d\x8d\x94\xf1\x1b\xab\xac\xbb\xfa\xb1\x83\xe9\xf9'
    float_0 = -7.7025
    str_0 = "E \x00\n\xea\x9d\x9e\x93\xe4\x1c\x92\x80"
    list_0 = [float_0]

# Generated at 2022-06-24 19:13:58.747491
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:14:02.638044
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:14:10.052589
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:14:19.640461
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    try:
        worker_process_0.run()
    except Exception as exception_0:
        exception_type = type(exception_0)
        print(exception_type)
        print(exception_0.args)
        print(exception_0)

# Generated at 2022-06-24 19:14:26.713167
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.start()
    worker_process_0.start()


# Generated at 2022-06-24 19:14:33.058207
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:14:38.588427
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:14:44.867633
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0._new_stdin = list_0
    worker_process_0._run()

# Generated at 2022-06-24 19:14:49.247177
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:17:03.278908
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:17:10.964851
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bytes_0 = b'\xe6\xbb\xfc\x8d\xa4cp\x01\xfbM\x8fV0\xe9\x80\xb5E\xcc\xf3\xcf'
    float_0 = -268.522875
    str_0 = "H?'N!"
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(bytes_0, float_0, str_0, bytes_0, str_0, str_0, list_0, bytes_0)
    try:
        worker_process_0.run()
    except Exception as exception_0:
        print(exception_0)

test_case_0()
test_WorkerProcess_run()