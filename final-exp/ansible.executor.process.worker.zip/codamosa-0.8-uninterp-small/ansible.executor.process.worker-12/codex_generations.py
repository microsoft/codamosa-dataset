

# Generated at 2022-06-24 19:07:24.979089
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test case #0
    test_case_0()


# Generated at 2022-06-24 19:07:26.485614
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print('Testing start()')
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:07:38.635858
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.run()
    assert var_0 is None

if __name__ == "__main__":
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:07:45.124321
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:07:47.813661
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print("Test start: %s" % __file__)
    test_case_0()
    print("Test successful: %s" % __file__)


if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:07:56.016824
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.run()
    worker_process_0.start()
    worker_process_0.run()


# Generated at 2022-06-24 19:07:57.017204
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()



# Generated at 2022-06-24 19:08:02.004694
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.start()
    worker_process_0.run()


# Generated at 2022-06-24 19:08:06.016928
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.run()
    assert var_0 == None

# Generated at 2022-06-24 19:08:13.631231
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.run()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:30.963577
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Sample argument
    mock_self = WorkerProcess()
    # Default return value
    default_return = None
    # Invoke method
    return_value = mock_self.run()
    # Assert
    assert return_value == default_return
    # Sample argument
    mock_self = WorkerProcess()
    # Default return value
    default_return = None
    # Invoke method
    return_value = mock_self.run()
    # Assert
    assert return_value == default_return



# Generated at 2022-06-24 19:08:36.861647
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Note that the test_case_0() function is used for testing,
    # and cannot be used here.
    # If a function is used for testing, then the function name
    # will replace the 'run' method name in the worker process.
    from ansible.executor.task_queue_manager import TaskQueueManager
    import time

    qmanager = TaskQueueManager()
    task_number = 10
    worker_number = 5

    # 1. Put tasks into queue
    for i in range(task_number):
        qmanager.add_task_to_queue(i)

    # 2. Create worker process, note that the method is test_case_0()
    for j in range(worker_number):
        worker = WorkerProcess(qmanager, None, None, None, None, None, None, None, None)
        worker.start

# Generated at 2022-06-24 19:08:38.917914
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'Test start: %s'
    str_1 = 'Test successful: %s'


# Generated at 2022-06-24 19:08:41.154677
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print(str_0)
    assert False
    print(str_1)


# Generated at 2022-06-24 19:08:43.017587
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_2 = 'Test start: %s'
    str_3 = 'Test successful: %s'


# Generated at 2022-06-24 19:08:51.874849
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    ansible_template = 'Test successful: %s'
    str_3 = 'Test start: %s'
    str_0 = 'Test start: %s'
    str_1 = 'Test successful: %s'
    str_2 = 'Test start: %s'
    str_4 = 'Test successful: %s'
    str_5 = 'Test successful: %s'
    str_6 = 'Test start: %s'
    str_7 = 'Test successful: %s'
    str_8 = 'Test start: %s'
    str_9 = 'Test successful: %s'
    str_10 = 'Test start: %s'
    str_11 = 'Test successful: %s'
    str_12 = 'Test start: %s'
    str_13 = 'Test successful: %s'
    str_

# Generated at 2022-06-24 19:08:57.152888
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    """ WorkerProcess.run - 001

    **Test Scenario:**
    #. Instantiate WorkerProcess object with test data, should succeed.
    #. Start WorkerProcess to start testing, should succeed.
    """
    pass

# Generated at 2022-06-24 19:09:02.197316
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    """
    Test start
    """
    print(test_case_0.__doc__)
    w = WorkerProcess(None, None, None, None, None, None, None, None)
    w.start()


# Generated at 2022-06-24 19:09:03.522585
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'Test successful: %s'
    str_1 = 'Test start: %s'

# Generated at 2022-06-24 19:09:04.938009
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    """
    Test WorkerProcess.run() method
    """
    test_case_0()

# Generated at 2022-06-24 19:09:18.338700
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        for str_1 in range(1, 4, 2):
            str_1.join(str(str_1))

    except AssertionError as e:
        print(str(e))
    except BaseException as e:
        print(str(e))


# Generated at 2022-06-24 19:09:19.811429
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '\n    Test WorkerProcess.run() method\n    '
    pass

# Generated at 2022-06-24 19:09:22.198419
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        str_1 = '\x00'
    except Exception as exception_1:
        print('Exception: ', exception_1)
    assert str_1 == '\x00'



# Generated at 2022-06-24 19:09:30.794409
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    final_q = SimpleQueue()
    task_vars = dict()
    host = Host(name = 'localhost')
    task = Task(name = 'test_module', async_val = 0, action = 'shell', args = 'whoami', delegate_to = 'localhost')
    play_context = PlayContext()
    loader = DataLoader()
    variable_manager = VariableManager()
    shared_loader_obj = True
    worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
    worker_process.run()
    worker_process.join()
    assert str(worker_process) == '<WorkerProcess(WorkerProcess-1, initial)>'

# Generated at 2022-06-24 19:09:31.776641
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_1 = '\n    Test WorkerProcess.start() method\n    '


# Generated at 2022-06-24 19:09:35.865882
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    str_1 = '\n    Test WorkerProcess.run() method\n    '

    result = WorkerProcess.run()
    assert result == str_0, 'Test WorkerProcess.run() method failed'
    assert str_0 == str_1, 'Test WorkerProcess.run() method failed'


# Generated at 2022-06-24 19:09:38.766067
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '\n    Test WorkerProcess.start() method\n    '


# Generated at 2022-06-24 19:09:40.310815
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    w = WorkerProcess()
    test_case_0()



# Generated at 2022-06-24 19:09:46.445637
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        raise Exception('An exception has occurred')
    except Exception as exc:
        exc_info = (type(exc), exc, exc.__traceback__)
        result = None
        result = traceback.format_exception(*exc_info)
        assert 'An exception has occurred' in result[-1]

test_case_0()

# Generated at 2022-06-24 19:09:53.076216
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # test_case_0(self)

    str_0 = '\n    Test WorkerProcess.run() method\n    '

    str_1 = "running TaskExecutor() for %s/%s" % (self._host, self._task)

    str_2 = "done running TaskExecutor() for %s/%s [%s]" % (self._host, self._task, self._task._uuid)

    str_3 = "sending task result for task %s" % self._task._uuid

    str_4 = "done sending task result for task %s" % self._task._uuid

    str_5 = "WORKER EXCEPTION: %s" % to_text(e)
    str_6 = "WORKER TRACEBACK: %s" % to_text(traceback.format_exc())
   

# Generated at 2022-06-24 19:10:12.918908
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test WorkerProcess.run() method
    # Test with good parameters
    from ansible.vars.manager import VariableManager

    def mock_method(*args, **kwargs):
        pass

    var_manager = VariableManager(loader=None, inventory=None)

    mock_host = type('MockHost', (object,), {'name': 'host', 'vars': dict(), 'groups': [], 'get_vars': mock_method, 'set_variable': mock_method})

# Generated at 2022-06-24 19:10:20.418083
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Test case 0
    test_WorkerProcess_run_test_case_0()


if __name__ == '__main__':
    if len(sys.argv) > 1:
        test_WorkerProcess_run()
    else:
        print('no testable module')
else:
    if __name__ == 'ansible.executor.workerprocess':

        if len(sys.argv) > 1:
            test_WorkerProcess_run()
        else:
            print('no testable module')

# Generated at 2022-06-24 19:10:21.383854
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert True == True


# Generated at 2022-06-24 19:10:26.796163
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Testing the run method

    # Setup test case
    test_case_0()

    # Unit test for method run of class WorkerProcess

    pass

# Generated at 2022-06-24 19:10:31.878892
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    #Declarations
    worker = WorkerProcess(None, None, None, None, None, None, None, None)

    #Test
    worker._run()


# Generated at 2022-06-24 19:10:40.536874
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    final_q = None
    task_vars = None
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None
    wp = WorkerProcess(
        final_q,
        task_vars,
        host,
        task,
        play_context,
        loader,
        variable_manager,
        shared_loader_obj
    )
    wp.start()

    start_result = wp.start()
    assert start_result == None


# Generated at 2022-06-24 19:10:42.130395
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import StringIO
    import sys
    test_case_0()
    return StringIO.StringIO()

# Setup test case for WorkerProcess.run() method

# Generated at 2022-06-24 19:10:45.611553
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # default call to method run
    args = (1, 'test.sample', 1, 'play_context', 1, 'loader', 'variable_manager', 'shared_loader_obj')
    result = WorkerProcess.run(*args)
    assert isinstance(result, NoneType)

test_case_0()

# Generated at 2022-06-24 19:10:54.793805
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    Unit test for method start of class WorkerProcess
    '''
    localhost_1 = {'hostname': 'localhost', 'port': 22, 'hostvars': ['hostvars_1'], 'play_hosts': ['play_hosts_1'], 'groups': ['groups_1'], 'vars': ['vars_1'], 'name': 'localhost'}

# Generated at 2022-06-24 19:10:57.329370
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '    Test WorkerProcess.run() method\n    '
    #TODO: Add test cases for method run of class WorkerProcess
    #pass


# Generated at 2022-06-24 19:11:14.907506
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:23.714005
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()
    assert var_0 is None


# Generated at 2022-06-24 19:11:31.564992
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.run()

# Generated at 2022-06-24 19:11:36.960156
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except:
        print(u'exception handled in method test_WorkerProcess_start')
        # TODO: add a more appropriate error message
        #assert False
    else:
        pass
    finally:
        pass

# Generated at 2022-06-24 19:11:43.313372
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.run()
    return var_0


# Generated at 2022-06-24 19:11:44.866943
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
  t = WorkerProcess()
  t.run()

test_case_0()

# Generated at 2022-06-24 19:11:49.289627
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:11:54.497348
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:11:58.867839
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()
    print(var_0)


# Generated at 2022-06-24 19:12:07.057824
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:12:31.282712
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.run()

# Generated at 2022-06-24 19:12:37.583823
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.run()



# Generated at 2022-06-24 19:12:46.098817
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:12:53.975013
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()
    assert var_0 is None

# Generated at 2022-06-24 19:13:00.951110
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()
    assert var_0 is not None
    assert var_0 == 0

if __name__ == '__main__':

    test_WorkerProcess_start()
    # test_case_0()

# Generated at 2022-06-24 19:13:06.281478
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -222
    bytes_0 = b'\x95O\x1b\x8e\x13\xbf\xb9\xf7\x8b\xaa\x1c\x1d\x8c\xa3\x01'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    # Call method start of class WorkerProcess
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:13:07.668680
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except Exception as e:
        # Display error message
        print(e)

test_WorkerProcess_start()

# Generated at 2022-06-24 19:13:15.526477
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_1 = worker_process_0.run()

    assert worker_process_1 is None


# Generated at 2022-06-24 19:13:23.371185
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.run()



# Generated at 2022-06-24 19:13:28.990442
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()
# Intrumentation
test_WorkerProcess_start()


# Generated at 2022-06-24 19:14:18.503804
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_1 = {}
    set_1 = set()
    int_1 = -266

# Generated at 2022-06-24 19:14:27.384979
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Local variables
    var_0 = {}
    var_1 = {}
    var_2 = set()
    var_3 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    var_4 = -231
    var_5 = set()
    var_6 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(var_0, var_1, var_2, var_3, var_1, var_4, var_5, var_6)

    # Invoke method run of class WorkerProcess
    worker_process_0.run()


# Unit test

# Generated at 2022-06-24 19:14:33.187887
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()
    # No need to check any value


# Generated at 2022-06-24 19:14:36.747224
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

if __name__ == '__main__':
    fmt= '%(asctime)s - %(levelname)s - %(message)s'
    #logging.basicConfig(filename='log/worker.log', filemode='w', format=fmt, level=logging.DEBUG)
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:14:41.508836
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:14:48.183155
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        # setup
        dict_0 = {}
        set_0 = set()
        int_0 = -231
        bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
        worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
        worker_process_0.start()
    except Exception as e:
        # Verify
        assert False

# Generated at 2022-06-24 19:14:49.018349
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert worker_process_0.start() == None


# Generated at 2022-06-24 19:14:52.771098
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_1 = {}
    set_1 = set()
    int_1 = -205
    bytes_1 = b'w\xed\x17\xba\x90\x9e\x9b\x80\xa7\x84\xa39\x92\x86\x86\x9a\xa0\x9c'
    worker_process_1 = WorkerProcess(dict_1, dict_1, set_1, bytes_1, dict_1, int_1, set_1, bytes_1)
    var_1 = worker_process_1.start()


# Generated at 2022-06-24 19:15:02.693909
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = 1653
    tuple_0 = (1, 2)
    bytes_0 = b'\xa4\x0e\x97\xb2\x98\x89\xe2'
    bytes_1 = b'\x8c\x80\x88\xfe\x9b\x08\x97'
    bytes_2 = b'y17\x8a\x9e\x9e\x04\x16M\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, tuple_0, int_0, set_0, bytes_0)
    worker_process_0._hard_exit(bytes_1)
    worker_process_0._save_

# Generated at 2022-06-24 19:15:11.955269
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    worker_process_0.run = lambda self: None
    worker_process_0.start = lambda self: None
    var_0 = worker_process_0.start()
    assert var_0 is None


# Generated at 2022-06-24 19:16:40.631461
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(dict, dict, set, b'\xad\x8f\xf1\xad\xb4\xfb\x9d\x18\xf0\xd4\xfc\x8e\xa4\x1b\xb7\x80\x9e\x1e\x1c\x98', dict, -230, set, b'\xa5\x80\x9a\x1b\xba\xc7\xfd\xb0\xdd\xb2\xfb\xad\xad\xbd\x87\x9b\xdd\xcd\x0b\x86')
    var_0 = worker_process_0.start()
    assert var_0 == None


# Generated at 2022-06-24 19:16:43.677884
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-24 19:16:44.691956
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

# Generated at 2022-06-24 19:16:48.937246
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:16:49.774023
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Class of worker process definition

# Generated at 2022-06-24 19:16:57.998362
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.start()


if __name__ == '__main__':
    # test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:17:08.466438
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        test_case_0()
    except:
        print("Error while processing test case: " + str(sys.exc_info()))
    def test_case_1():
        dict_2 = {}
        set_2 = set()
        int_2 = -231
        bytes_2 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
        worker_process_2 = WorkerProcess(dict_2, dict_2, set_2, bytes_2, dict_2, int_2, set_2, bytes_2)
        var_1 = worker_process_2.run()


# Generated at 2022-06-24 19:17:11.595947
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:17:15.807099
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    set_0 = set()
    int_0 = -231
    bytes_0 = b'\xb28\xac\xbe7\x89rZ\\\x9a\x97\x06i\x7f\x0c'
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, bytes_0, dict_0, int_0, set_0, bytes_0)
    var_0 = worker_process_0.run()
