

# Generated at 2022-06-24 19:07:30.652124
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'k6'
    list_0 = ['$TT1hJ', str_0]
    list_1 = ['', list_0, '']
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, list_1, list_1, str_0)
    worker_process_0.start()
    worker_process_0 = WorkerProcess(list_0, str_0, str_0, str_0, '', '&q3q[U', list_0, list_0)
    worker_process_0.start()
    worker_process_0 = WorkerProcess('Z', str_0, str_0, str_0, list_1, list_1, list_1, 'Z')
    worker_process_0.start()


# Generated at 2022-06-24 19:07:37.561001
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {'file': 'file'}
    dict_1 = dict()
    dict_2 = dict()
    dict_2['file'] = 'file'
    dict_3 = dict()
    dict_3['path'] = 'path'
    worker_process_0 = WorkerProcess(dict_0, dict_1, dict_2, dict_3, dict_2, dict_3, dict_3, dict_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:07:38.493637
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()



# Generated at 2022-06-24 19:07:45.995102
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Initialization, test prepare
    str_0 = 'virtualization_role'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    str_1 = 'L$na~-T2ZC6fk'
    list_0 = [bool_0, dict_0, bool_0, str_0]
    worker_process_0 = WorkerProcess(dict_0, bool_0, bool_0, str_0, dict_0, str_1, list_0, list_0)
    return None


# Generated at 2022-06-24 19:07:53.981279
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = dict()
    dict_0 = dict()
    bool_0 = bool()
    str_1 = dict()
    dict_1 = dict()
    str_2 = dict()
    list_0 = dict()
    list_1 = dict()
    worker_process_0 = WorkerProcess(str_0, bool_0, str_1, str_2, dict_0, dict_1, list_0, list_1)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:02.242154
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'virtualization_role'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    str_1 = 'L$na~-T2ZC6fk'
    list_0 = [bool_0, dict_0, bool_0, str_0]
    worker_process_0 = WorkerProcess(dict_0, bool_0, bool_0, str_0, dict_0, str_1, list_0, list_0)
    worker_process_0.run()

if __name__ == "__main__":
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:07.193920
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'virtualization_role'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    str_1 = 'L$na~-T2ZC6fk'
    list_0 = [bool_0, dict_0, bool_0, str_0]
    worker_process_0 = WorkerProcess(dict_0, bool_0, bool_0, str_0, dict_0, str_1, list_0, list_0)
    worker_process_0.start()
    worker_process_0.run()

test_case_0()
test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:13.615063
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'virtualization_role'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    str_1 = 'L$na~-T2ZC6fk'
    list_0 = [bool_0, dict_0, bool_0, str_0]
    worker_process_0 = WorkerProcess(dict_0, bool_0, bool_0, str_0, dict_0, str_1, list_0, list_0)
    assert_true(worker_process_0.start())


# Generated at 2022-06-24 19:08:16.848284
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(dict(), bool(), bool(), str(), dict(), str(), list(), list())
    # TODO: add some test code for start()


# Generated at 2022-06-24 19:08:27.061553
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    list_0 = [0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0]
    list_1 = [0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1]
    list_2 = [0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1]
    list_3 = [0, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1]
    list_

# Generated at 2022-06-24 19:08:38.622326
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
        worker_process_0.start()
    except:
        pass

test_WorkerProcess_start()

# Generated at 2022-06-24 19:08:48.936611
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    playbook_path = 'test/unit/ansible_collections/ansible/builtin/playbooks/playbook_empty.yml'

# Generated at 2022-06-24 19:08:59.451133
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = "yum|install"
    int_0 = 0
    int_1 = -1
    str_1 = "xen"
    str_2 = "]"
    str_3 = ":"
    str_4 = "ssh_args"
    str_5 = "verbosity"
    str_6 = "environment"
    str_7 = "ANSIBLE_ROLES_PATH"
    str_8 = "ssh"
    str_9 = "0.0.0.0"
    str_10 = "become"
    str_11 = "gather_facts"
    str_12 = "check"
    str_13 = "serial"
    str_14 = "close_fds"
    str_15 = "sudo_user"
    str_16 = "sudo_exe"
    str

# Generated at 2022-06-24 19:09:10.536583
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = "w!nrm"
    bool_0 = True
    list_0 = [bool_0, str_0, bool_0, str_0]
    worker_process_0 = WorkerProcess(str_0, bool_0, bool_0, str_0, str_0, str_0, list_0, list_0)
    try:
        worker_process_0.run()
    except:
        if sys.exc_info()[0] != None:
            raise

str_0 = "et"
str_1 = "c%o"
str_2 = "nc"
str_3 = "cu"
str_4 = "m"
str_5 = "!ti!n"
str_6 = "!ti!n"
str_7 = "et"

# Generated at 2022-06-24 19:09:14.204618
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    bool_0 = True
    str_0 = "v!rtua'izaIion!role"
    list_0 = [bool_0, dict_0, bool_0, str_0]
    worker_process_0 = WorkerProcess(dict_0, bool_0, bool_0, str_0, dict_0, str_0, list_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:09:15.307716
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:09:18.338472
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(dict(), dict(), dict(), dict(), dict(), dict(), list(), list())
    # worker_process_0._save_stdin()
    assert worker_process_0.start() == None


# Generated at 2022-06-24 19:09:19.056827
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:09:29.513618
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = "v!rtua'izaIion!role"
    dict_0 = {str_0: str_0, str_0: str_0}
    bool_0 = True
    list_0 = [bool_0, dict_0, bool_0, str_0]
    worker_process_0 = WorkerProcess(dict_0, bool_0, bool_0, str_0, dict_0, str_0, list_0, list_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:09:31.027558
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(str(), bool(), bool(), str(), str(), bool(), list(), bool())


# Generated at 2022-06-24 19:09:40.628480
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

test_WorkerProcess_run()

# Generated at 2022-06-24 19:09:50.407125
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'test/unit/ansible_collections/ansible/builtin/playbooks/playbook_empty.yml'

    final_q = None
    task_vars = {}
    host = None
    task = None
    play_context = None
    loader = None
    variable_manager = None
    shared_loader_obj = None

    with open('test/unit/worker_process/test_file_0.txt','w') as f:
        def _save_stdin():
            f.write(u"WORKER PROCESS STARTING\n")

        worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
        worker_process._save_stdin = _save_stdin
        worker_process.start

# Generated at 2022-06-24 19:09:56.923155
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    final_q = None
    task_vars = 'task_vars'
    host = 'host'
    task = 'task'
    play_context = 'play_context'
    loader = 'loader'
    variable_manager = 'variable_manager'
    shared_loader_obj = 'shared_loader_obj'
    workerprocess_obj = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager,
                                      shared_loader_obj)
    workerprocess_obj.start()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:09:58.071068
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# End of WorkerProcess run unittest

# Generated at 2022-06-24 19:09:59.571156
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # init
    # test case
    test_case_0()


# Generated at 2022-06-24 19:10:01.326924
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
	str_0 = 'test/unit/ansible_collections/ansible/builtin/playbooks/playbook_empty.yml'



# Generated at 2022-06-24 19:10:03.070008
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    Unit test for the method start from the class WorkerProcess
    '''
    # just call the method
    #test_case()
    WorkerProcess.start()


# Generated at 2022-06-24 19:10:05.049903
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:10:10.510937
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    import os
    import sys
    import traceback
    from jinja2.exceptions import TemplateNotFound
    from ansible.errors import AnsibleConnectionFailure
    from ansible.executor.task_executor import TaskExecutor
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display
    from ansible.utils.multiprocessing import context as multiprocessing_context
    __all__ = ['WorkerProcess']
    display = Display()
    class WorkerProcess(multiprocessing_context.Process):
        '''
        The worker thread class, which uses TaskExecutor to run tasks
        read from a job queue and pushes results into a results queue
        for reading later.
        '''

# Generated at 2022-06-24 19:10:11.601214
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()
