

# Generated at 2022-06-24 19:07:29.842641
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = False
    str_0 = 'Recursively convert dict keys and values to text str\n\n    Specialized for json return because this only handles, lists, tuples,\n    and dict container types (the containers that the json module returns)\n    '
    dict_0 = {}
    int_0 = -1274
    list_0 = [str_0, bool_0, int_0, int_0]
    worker_process_0 = WorkerProcess(bool_0, str_0, dict_0, int_0, str_0, list_0, list_0, bool_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:07:38.798091
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = False
    str_0 = 'Recursively convert dict keys and values to text str\n\n    Specialized for json return because this only handles, lists, tuples,\n    and dict container types (the containers that the json module returns)\n    '
    dict_0 = {}
    int_0 = -1274
    list_0 = [str_0, bool_0, int_0, int_0]
    worker_process_0 = WorkerProcess(bool_0, str_0, dict_0, int_0, str_0, list_0, list_0, bool_0)
    var_0 = worker_process_0.run()


# Generated at 2022-06-24 19:07:41.453829
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    var_1 = os.devnull
    worker_process_1 = WorkerProcess(var_1)
    worker_process_1.start()


# Generated at 2022-06-24 19:07:48.701603
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # Test case 0
    bool_0 = False
    str_0 = 'Recursively convert dict keys and values to text str\n\n    Specialized for json return because this only handles, lists, tuples,\n    and dict container types (the containers that the json module returns)\n    '
    dict_0 = {}
    int_0 = -1274
    list_0 = [str_0, bool_0, int_0, int_0]
    worker_process_0 = WorkerProcess(bool_0, str_0, dict_0, int_0, str_0, list_0, list_0, bool_0)
    assert worker_process_0.start() is None


# Generated at 2022-06-24 19:07:51.612817
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # No parameter test case
    worker_process_0 = WorkerProcess(None, 'str_0', None, 0, 'str_0', None, None, None)
    worker_process_0.start()

# Generated at 2022-06-24 19:08:00.646834
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    int_1 = -10
    dict_1 = {}
    list_1 = [int_1, dict_1, dict_1]
    str_1 = 'process pool worker'
    bool_1 = False
    worker_process_1 = WorkerProcess(True, list_1, dict_1, list_1, dict_1, dict_1, list_1, dict_1)
    int_0 = worker_process_1.start()
    assert int_0 == None

if __name__ == "__main__":
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:08:07.404729
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test no params
    test_case_0()

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        globals()['test_' + sys.argv[1]]()
    else:
        for name in globals().keys():
            if name.startswith('test_'):
                globals()[name]()

# Generated at 2022-06-24 19:08:09.034164
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Setup
    worker_process = WorkerProcess(None, None, None, None, None, None, None, None)

    # Exercise
    worker_process.start()

# Generated at 2022-06-24 19:08:14.663454
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = False
    str_0 = 'Recursively convert dict keys and values to text str\n\n    Specialized for json return because this only handles, lists, tuples,\n    and dict container types (the containers that the json module returns)\n    '
    dict_0 = {}
    int_0 = -1274
    list_0 = [str_0, bool_0, int_0, int_0]
    worker_process_0 = WorkerProcess(bool_0, str_0, dict_0, int_0, str_0, list_0, list_0, bool_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:08:24.441711
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = False
    str_0 = 'Recursively convert dict keys and values to text str\n\n    Specialized for json return because this only handles, lists, tuples,\n    and dict container types (the containers that the json module returns)\n    '
    dict_0 = {}
    int_0 = -1274
    list_0 = [str_0, bool_0, int_0, int_0]
    worker_process_0 = WorkerProcess(bool_0, str_0, dict_0, int_0, str_0, list_0, list_0, bool_0)

    # Call method run of worker_process_0
    test_case_0()

# Generated at 2022-06-24 19:08:35.864788
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:41.204933
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:48.487925
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()


# test_WorkerProcess_run()
# put the result on the result queue
# example: done sending task result for task 8a287a59-2d7c-4fdf-928c-f9b1e7e0071c

# Generated at 2022-06-24 19:08:54.278210
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:55.016808
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:09:01.738228
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # test case 0
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    try:
        worker_process_0.run()
    except BaseException:
        pass



# Generated at 2022-06-24 19:09:08.575116
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    try:
        worker_process_0.start()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:09:13.394710
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:09:14.781497
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    #test case 0
    test_case_0()


# Generated at 2022-06-24 19:09:18.546220
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:09:31.727365
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # int.
    assert isinstance(WorkerProcess(0, '', 0, 0, '', 0, 0, 0).run(), type(None))


# Generated at 2022-06-24 19:09:36.250651
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)

    # Testing preconditions
    assert True

    # Testing method
    worker_process_0.start()
    # Testing postconditions
    assert True


# Generated at 2022-06-24 19:09:42.406514
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()
    assert True # TODO: may fail later



# Generated at 2022-06-24 19:09:47.536700
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # This test checks if we are able to connect to the localhost with a wrong password
    # When we run the playbook with a wrong password, the worker_process should not be able to
    # connect to the localhost. So the worker_process should be able to print the error.
    test_case_0()


if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:09:55.291823
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # instantiate a WorkerProcess object
    worker_process_object_0 = WorkerProcess('str_0', int(), 'str_1', int(), 'str_2', int(), int(), int())
    # call the method
    worker_process_object_0.run()
    # check the result
    assert worker_process_object_0 is not None


# Generated at 2022-06-24 19:09:59.920987
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()


if __name__ == '__main__':
    #for test case 1
    test_case_0()
    
    #for test case 2
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:01.693958
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-24 19:10:07.929202
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:11.925892
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0._run()
    # try:
    #     worker_process_0._run()
    # finally:
    #     worker_process_0._clean_up()


if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:17.752384
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    try:
        worker_process_0.start()
    except Exception as exception_0:
        assert True
        return
    assert True


# Generated at 2022-06-24 19:10:39.179244
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()

if __name__ == '__main__':
    # test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:48.322173
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    # Test for method start of class WorkerProcess
    try:
        # Call method start of class WorkerProcess
        worker_process_0.start()
    except (AttributeError, Exception) as e:
        assert False

    # Test for method start of class WorkerProcess
    try:
        # Call method start of class WorkerProcess
        worker_process_0.start()
    except (AttributeError, Exception) as e:
        assert False


# Generated at 2022-06-24 19:10:50.767484
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()

# Generated at 2022-06-24 19:10:51.569883
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:11:01.800764
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Init a WorkerProcess
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)

    # Call method start of class WorkerProcess
    worker_process_0.start()
    # Assert start of class WorkerProcess
    str_1 = 'str_1'
    str_2 = 'str_2'
    str_3 = 'str_3'
    str_4 = 'str_4'
    str_5 = 'str_5'
    str_6 = 'str_6'
    str_7 = 'str_7'
    str_8 = 'str_8'
    str_9 = 'str_9'
    str

# Generated at 2022-06-24 19:11:07.672105
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:15.118758
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print('Testing run method of WorkerProcess class.')
    # test_case_0
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(str_0, int_0, str_0, str_0, int_0, int_0, int_0)
    result = worker_process_0.run()
    exp_result = None
    if result != exp_result:
        print('Test 0 failed.')
        return
    else:
        print('Test 0 passed.')
        return

# Generated at 2022-06-24 19:11:19.521049
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:22.835921
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = create_WorkerProcess()
    worker_process_0.start()
    assert worker_process_0.is_alive() == True


# Generated at 2022-06-24 19:11:30.202086
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:12:08.610196
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    if isinstance(int_0, int):
        assert isinstance(worker_process_0.run(), int)
    else:
        assert False

if __name__ == "__main__":
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:12:12.495292
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()

test_WorkerProcess_run()

# Generated at 2022-06-24 19:12:15.514167
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass


# Generated at 2022-06-24 19:12:19.079366
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:12:23.429264
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(1, 2, 3, 4, 5, 6, 7, 8)
    worker_process_0._loader._tempfiles = None
    worker_process_0._save_stdin()
    worker_process_0._new_stdin = 1
    worker_process_0._run()

# Generated at 2022-06-24 19:12:26.946221
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:12:29.679565
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:12:36.156769
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    # Case 0
    try:
        worker_process_0.start()
    except OSError:
        pass


# Generated at 2022-06-24 19:12:43.879302
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:12:48.705660
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    try:
        worker_process_0.start()
    except AttributeError:
        # Exception thrown because 'Process' is not callable
        assert False
    except IOError:
        # This exception is thrown because stdin is not available
        assert False

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:13:26.888995
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    with pytest.raises(TypeError):
        worker_process_0.start()


# Generated at 2022-06-24 19:13:29.913145
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:13:32.693290
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:35.068835
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        test_case_0()
    except NameError as e:
        print(e)
    except Exception as e:
        print(e)

if __name__ == "__main__":
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:13:35.927776
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

test_WorkerProcess_run()

# Generated at 2022-06-24 19:13:40.934231
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Initialization
    final_q_0 = multiprocessing_context.JoinableQueue()
    task_vars_0 = {'key_0': 'value_0'}
    host_0 = 'host_0'
    task_0 = 'task_0'
    play_context_0 = 'play_context_0'
    loader_0 = 'loader_0'
    variable_manager_0 = 'variable_manager_0'
    shared_loader_obj_0 = 'shared_loader_obj_0'
    worker_process_0 = WorkerProcess(final_q_0, task_vars_0, host_0, task_0, play_context_0, loader_0, variable_manager_0, shared_loader_obj_0)

    # Invoke method
    worker_process_0.run()



# Generated at 2022-06-24 19:13:46.838360
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0

    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()
    # test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:13:49.093751
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()



# Generated at 2022-06-24 19:13:53.265073
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:13:59.437781
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()
    assert(True)



# Generated at 2022-06-24 19:15:16.304368
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

if __name__ == '__main__':
    test_WorkerProcess_run()

#!/usr/bin/env python
'''
(c) 2011, 2012 Georgia Tech Research Corporation
This source code is released under the New BSD license.  Please see
http://wiki.quantsoftware.org/index.php?title=QSTK_License
for license details.

Created on January, 23, 2013

@author: Sourabh Bajaj
@contact: sourabhbajaj@gatech.edu
@summary: Example tutorial code.
'''

# QSTK Imports
import QSTK.qstkutil.qsdateutil as du
import QSTK.qstkutil.tsutil as tsu
import QSTK.qstkutil.DataAccess as da

# Third Party Imports


# Generated at 2022-06-24 19:15:20.900291
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # test to cover some of the more difficult cases in WorkerProcess.run()
    # result = WorkerProcess.run(*args, **kwargs)
    assert True == True # TODO: implement your test here


# Generated at 2022-06-24 19:15:24.390566
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:15:26.695443
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()



# Generated at 2022-06-24 19:15:28.600935
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.run()

# Generated at 2022-06-24 19:15:33.594670
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    worker_process_0.start()



# Generated at 2022-06-24 19:15:40.161594
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    int_1 = worker_process_0.start()
    assert type(int_1) == int


# Generated at 2022-06-24 19:15:46.036906
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'str_0'
    int_0 = 0
    worker_process_0 = WorkerProcess(int_0, str_0, int_0, int_0, str_0, int_0, int_0, int_0)
    try:
        worker_process_0.run()
    except Exception as err:
        assert(str(err) == 'worker_process_0 is not yet implemented')
    else:
        assert True
test_WorkerProcess_run()


# Generated at 2022-06-24 19:15:55.173908
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    args_0 = dict()
    args_0['play_context'] = dict()
    args_0['play_context']['remote_addr'] = 'str_1'
    args_0['play_context']['net_pref_remote_addr'] = 'str_2'
    args_0['play_context']['local_addr'] = 'str_3'
    args_0['play_context']['remote_user'] = 'str_4'
    args_0['play_context']['become'] = 'bool_0'
    args_0['play_context']['become_method'] = 'str_5'
    args_0['play_context']['become_user'] = 'str_6'
    args_0['play_context']['become_ask_pass']

# Generated at 2022-06-24 19:16:02.086849
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Set up test environment
    import ansible.plugins
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.task
    import ansible.utils.vars
    import ansible.utils.shlex
    ansible.utils.shlex.split = lambda val: val.split()
    import os
    PLAYBOOK_FILE = 'test_playbook.yml'
    PLAYBOOK_DIR = 'test_dir'
    if not os.path.exists(PLAYBOOK_DIR):
        os.makedirs(PLAYBOOK_DIR)