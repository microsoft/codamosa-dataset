

# Generated at 2022-06-24 19:07:24.534983
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    worker_process_0 = None
    bool_0 = worker_process_0.start()
    float_0 = 1208.8
    list_0 = []


# Generated at 2022-06-24 19:07:26.309593
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    worker_process_0 = None
    var_0 = worker_process_0.run()
    float_0 = 1208.8
    list_0 = []


# Generated at 2022-06-24 19:07:31.819441
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    worker_process_0 = WorkerProcess(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    worker_process_0.run()
    worker_process_0.run()
    worker_process_0.run()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()
    worker_process_0.start()

# Generated at 2022-06-24 19:07:34.337879
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Arrange
    new_WorkerProcess = WorkerProcess('', {}, {}, {}, {}, {}, {}, {})

    # Act
    new_WorkerProcess.run()

    # Assert

# Generated at 2022-06-24 19:07:35.191072
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:07:37.697187
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    worker_process_0 = None
    var_0 = worker_process_0.start()
    float_0 = 1208.8
    list_0 = []


# Generated at 2022-06-24 19:07:41.538227
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    worker_process_0 = WorkerProcess(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    var_0 = worker_process_0.start()
    float_0 = 1208.8
    list_0 = []


# Generated at 2022-06-24 19:07:49.547328
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    worker_process_0 = WorkerProcess(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    var_0 = worker_process_0.run()
    float_0 = 1208.8
    list_0 = []
    var_1 = worker_process_0.run()
    worker_process_0 = WorkerProcess(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    float_0 = 1208.8
    var_2 = worker_process_0.run()
    float_1 = 3.2
    list_1 = []
    float_2 = 1208.8
    list_2 = []
    float_3

# Generated at 2022-06-24 19:07:50.946906
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print("Testing WorkerProcess.run...", end="")
    test_case_0()
    print("Passed!")


# Generated at 2022-06-24 19:07:57.017386
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    worker_process_0 = None
    var_0 = worker_process_0.start()
    float_0 = 1208.8
    list_0 = []


# Generated at 2022-06-24 19:08:16.063088
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        # Variables used in the test
        final_q = Queue()
        task_vars = dict()
        host = Host()
        task = Task()
        play_context = PlayContext()
        loader = DataLoader()
        variable_manager = VariableManager()
        shared_loader_obj = set()
        # Set up the test
        worker_process = WorkerProcess(final_q, task_vars, host, task, play_context, loader, variable_manager, shared_loader_obj)
        # Perform the test
        worker_process.run()
        # Check the test result
        assert True
    except BaseException as e:
        # print the error information
        print(e)
        # Check the test result
        assert False


# Generated at 2022-06-24 19:08:21.299497
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    mp_ctx = multiprocessing_context.copy()
    p =  WorkerProcess(mp_ctx, test_case_0(), test_case_0(), test_case_0(), test_case_0(), test_case_0(), test_case_0(), test_case_0())
    p.start()


# Generated at 2022-06-24 19:08:29.250432
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    set_0 = set()
    str_0 = '9I+L7MUu_z#FgCC(BJB.H%[>|*'
    dict_0 = {set_0: set_0, str_0: set_0, set_0: str_0, str_0: set_0}
    int_0 = 1

# Generated at 2022-06-24 19:08:30.426620
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass


# Generated at 2022-06-24 19:08:32.164673
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:37.138400
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    set_0 = set()
    str_0 = '_sAL?LI,W/!E?&EJ[BM'
    dict_0 = {str_0: set_0, set_0: set_0, set_0: str_0, str_0: set_0}
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:48.933556
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    # Run test for method run for testcase 1
    import os, tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

    loader = DataLoader()
    results_callback = CallbackBase()
    inventory = InventoryManager(loader=loader, sources=['/Users/shivanshmakkar/ansible_NEW/test/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-24 19:08:50.023145
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Put your test code here
    pass


# Generated at 2022-06-24 19:08:52.987880
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process.start()


# Generated at 2022-06-24 19:09:03.039302
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    set_0 = set()
    str_0 = 'J$?%KOZ\x00]Y\x00N.\x00P_\x00KW/\x00I}U/\x00K\x00=\x00C\x00Q@\x00\x00'
    int_0 = -1
    str_1 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    str_2 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    int_1 = -1

    # call start() with arguments

# Generated at 2022-06-24 19:09:21.318144
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_2 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_1, float_0, float_0, list_0)
    # Unit test for method run of class WorkerProcess
    #

# Generated at 2022-06-24 19:09:22.198474
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:09:22.998655
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:09:31.965184
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.run()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:09:36.548668
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        # Create a WorkerProcess object to test
        WorkerProcess_obj = WorkerProcess(None, None, None, None, None, None, None, None)
        # Place code that will call the run() method of the selected object
        # here
        raise Exception("Method run() not implemented yet")
    except Exception as e:
        print("Exception when calling run() method: %s" % str(e))
        raise


# Generated at 2022-06-24 19:09:37.862660
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:09:48.536568
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.start()
    worker_process_1.start()
    worker_process_1.start()
    worker_process_1.start()


# Generated at 2022-06-24 19:09:54.906348
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.start()


# Generated at 2022-06-24 19:10:02.116142
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.run()

if __name__ == '__main__':
    # Unit test for method run of class WorkerProcess
    test_case_0()

# Generated at 2022-06-24 19:10:11.197755
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.start()

# Generated at 2022-06-24 19:10:38.014352
# Unit test for method run of class WorkerProcess

# Generated at 2022-06-24 19:10:43.286358
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x8e\xde\x81t\x93V\xb5\xf8\x0e\xfc\xb9'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.run()


# Generated at 2022-06-24 19:10:49.148096
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.start()


# Generated at 2022-06-24 19:10:54.331864
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    # Test that a exception is raised
    try:
        worker_process_1.run()
    except Exception as e:
        assert str(e) == 'The process tries to join a child process'

# Generated at 2022-06-24 19:11:01.378349
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    # Assign parameter 'self'
    worker_process_1.run()

# Generated at 2022-06-24 19:11:08.471124
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    queue_0 = None
    task_vars_0 = None
    host_0 = None
    task_0 = None
    play_context_0 = None
    loader_0 = None
    variable_manager_0 = None
    shared_loader_obj_0 = None
    worker_process_0 = WorkerProcess(queue_0, task_vars_0, host_0, task_0, play_context_0, loader_0, variable_manager_0, shared_loader_obj_0)
    worker_process_0.run()

if __name__ == "__main__":
    from logging import basicConfig
    from sys import stdin, stdout, stderr

    basicConfig(level=0, stream=stderr)

# Generated at 2022-06-24 19:11:09.154423
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:11:09.592757
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:11:12.627974
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = {}
    float_0 = float(0)
    set_0 = {float_0}
    worker_process_0 = WorkerProcess(dict_0, dict_0, set_0, dict_0, dict_0, float_0, float_0, dict_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:13.551403
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print('Testing start...')
    print('Done testing start')


# Generated at 2022-06-24 19:11:50.426416
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print('Testing run...', end='')
    worker_process_0 = WorkerProcess(None,None,None,None,None,None,None,None)
    worker_process_0.run()
    print('done')


if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:11:53.198849
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Create a workerProcess object
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None,
                                     None)
    # Invoke method run
    worker_process_0.run()


# Generated at 2022-06-24 19:11:59.788441
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_1 = None
    bytes_1 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_1 = (bytes_1,)
    set_1 = {dict_1}
    worker_process_2 = None
    float_1 = 1208.8
    list_1 = []
    worker_process_3 = WorkerProcess(dict_1, tuple_1, set_1, dict_1, worker_process_2, float_1, float_1, list_1)



# Generated at 2022-06-24 19:12:00.701284
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:12:03.914586
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Test execution of method start
    test_case_0()


# Generated at 2022-06-24 19:12:05.665174
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.start()


test_case_0()
test_WorkerProcess_start()

# Generated at 2022-06-24 19:12:15.192258
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.run()



# Generated at 2022-06-24 19:12:23.113364
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    assert_raises(BaseException, worker_process_1.run)

# Generated at 2022-06-24 19:12:29.006115
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.run()

# Generated at 2022-06-24 19:12:38.824512
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\xd9\x96h\xd1\x8a\x1a\xfe\xbe\xeb\xbd\x9d\x84\xad\xf0\xcd\x17e\x1b\xb5\xc8\x8a\xda\x00\xcb\xe0\x8a\x92\x02\xc4\x88\x10\x9dD\xcd'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []

# Generated at 2022-06-24 19:13:45.419110
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print("Running tests for method start in class WorkerProcess")
    # Initial Setup
    worker_process_0 = WorkerProcess()
    # Assertions


# Generated at 2022-06-24 19:13:45.999803
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:13:50.816600
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\xdc\xae\x08Oq\x9d\x9a\x08be\x0c\x0e\xf2'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 541.07
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.run()
    

# Generated at 2022-06-24 19:13:51.663118
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:13:56.142170
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_1 = None
    bytes_1 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_1 = (bytes_1,)
    set_1 = {dict_1}
    worker_process_2 = None
    float_1 = 1208.8
    list_1 = []
    worker_process_3 = WorkerProcess(dict_1, tuple_1, set_1, dict_1, worker_process_2, float_1, float_1, list_1)
    assert(isinstance(worker_process_3.start(), None))


# Generated at 2022-06-24 19:14:02.196758
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Arrange
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    
    # Act
    worker_process_1.run()
    
    # Assert
    

# Generated at 2022-06-24 19:14:04.350979
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert callable(getattr(WorkerProcess, "start", None)), "Method 'start' is not callable"


# Generated at 2022-06-24 19:14:11.250893
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    bytes_0 = b'\xd0\xea\xa0\xeb\xd4\xbd\xd4\x10\xbak'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 618.57
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    # test start of WorkerProcess
    worker_process_1.start()

# Generated at 2022-06-24 19:14:14.194283
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:14:21.802494
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.run()


# Generated at 2022-06-24 19:16:43.769059
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Arrange
    from unittest.mock import Mock

    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)

    worker_process_1.start = Mock(side_effect=worker_process_1.start)

    # Act
    worker_process_1.start()

    # Assert


# Generated at 2022-06-24 19:16:46.116038
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    global worker_process_0, worker_process_1
    test_case_0()
    try:
        worker_process_1.start()
    except Exception:
        pass


# Generated at 2022-06-24 19:16:50.760417
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    # TODO: fix
    #worker_process_1.start()


# Generated at 2022-06-24 19:16:53.296091
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Test case data
    worker_process_0 = None
    # Test case execution
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    worker_process_0.start()



# Generated at 2022-06-24 19:16:59.839733
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = {dict_0}
    worker_process_0 = None
    # float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, 1208.8, 1208.8, list_0)
    worker_process_1._hard_exit(dict_0)

# Generated at 2022-06-24 19:17:02.342303
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:17:03.148333
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:17:10.509105
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = dict()
    bytes_0 = b'\x90\xc2\x08Oq\xa1\xa1\x14U\x00\x0f\x14'
    tuple_0 = (bytes_0,)
    set_0 = set()
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = list()
    worker_process_0 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    try:
        worker_process_0.run()
    except:
        print('Test Failed')


# Generated at 2022-06-24 19:17:12.800575
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 19:17:18.352266
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    dict_0 = None
    bytes_0 = b'5\xd8\x98\xb8\x9e\x964\x1d\x89\xcc\xd2\xaa\x13'
    tuple_0 = (dict_0,)
    set_0 = {dict_0, bytes_0}
    worker_process_0 = None
    float_0 = 1208.8
    list_0 = []
    worker_process_1 = WorkerProcess(dict_0, tuple_0, set_0, dict_0, worker_process_0, float_0, float_0, list_0)
    worker_process_1.start()
