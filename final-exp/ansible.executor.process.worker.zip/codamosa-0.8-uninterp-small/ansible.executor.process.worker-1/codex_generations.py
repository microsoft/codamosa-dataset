

# Generated at 2022-06-24 19:07:25.577375
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from multiprocessing import Process, Queue
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    tqm = TaskQueueManager(
        inventory=Inventory(loader=DataLoader()),
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader(),
        options=dict(),
        passwords=dict(),
    )
    queue_1 = Queue()
    queue_2 = Queue()
    worker_process = WorkerProcess(queue_1, dict(), dict(), dict(), dict(), dict(), dict(), dict())
    worker_process.start()
    worker_process.run()


# Generated at 2022-06-24 19:07:31.308576
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # pylint: disable=W0612
    # Initialize class WorkerProcess
    final_q = ''
    task_vars = {}
    host = ''
    task = ''
    play_context = ''
    loader = ''
    variable_manager = ''
    shared_loader_obj = ''
    # Call method run of class WorkerProcess
    start_time = time.time()
    test_case_0()
    end_time = time.time()
    test_case_0()
    end_time_1 = time.time()

    print("Total time taken in (function name) is: ", end_time-start_time)
    print("Total time taken in (function name) is: ", end_time_1-end_time)

# Generated at 2022-06-24 19:07:36.724592
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    list_0 = []
    list_1 = [list_0]
    str_0 = '`9Z'
    float_0 = 512.0
    int_0 = 2263
    str_1 = '?'
    set_0 = {list_0, str_1}
    worker_process_0 = WorkerProcess(str_0, str_1, float_0, int_0, list_0, set_0, list_1, str_1)
    worker_process_0.start()


# Generated at 2022-06-24 19:07:37.648523
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:07:40.041334
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    pass

# Testing method start on class WorkerProcess
# Tests should cover all cases in the code, however,
# following is a small sample

# Generated at 2022-06-24 19:07:41.326089
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Test case 0
    test_case_0()


# Generated at 2022-06-24 19:07:44.621130
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    workerProc_0 = WorkerProcess(5.5, g_58, 25.5, [], test_case_0, 0.8)
    workerProc_0.start()
    assert workerProc_0._play_context.timeout == 15


# Generated at 2022-06-24 19:07:46.470635
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    wp = WorkerProcess(None, None, None, None, None, None, None, None)
    wp.start()


# Generated at 2022-06-24 19:07:57.210336
# Unit test for method run of class WorkerProcess

# Generated at 2022-06-24 19:08:04.021297
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    class DummyTask:
        def __init__(self, uid):
            self._uuid = uid
        def dump_attrs(self):
            return {}

    class TestFinalQueue:
        def send_task_result(self, host, uid, result, task_fields):
            expected_host = '172.16.218.10'
            expected_uid = '5df5a5d5-35a9-4bf1-ac0e-13a79f48e562'
            expected_result = {'task_id': expected_uid, 'success': {'msg': 'all done'}}
            expected_task_fields = {'task_id': expected_uid}


# Generated at 2022-06-24 19:08:24.347809
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '1l^(8tV'
    bool_0 = True
    int_0 = 0
    bytes_0 = b'$E\xa5'
    set_0 = None
    str_1 = '5'
    float_0 = -79.1621270
    bool_1 = False
    list_0 = [str_0, bool_1, bool_0, bool_0, bool_1, bool_0, bool_1, bool_1, bool_1, bool_1]
    bytes_1 = b'\x08\x97\x00'
    list_1 = [int_0, int_0, str_0, str_1, float_0, float_0, str_1, str_1, str_1, float_0]
    float_1 = 0.3201

# Generated at 2022-06-24 19:08:37.251347
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'\xf0\x84\x9e\xda\x1c\x8d\xca\x07\xa3\x16o3\x9a\xf2,b\x03\xca\xaa\x81\x05\x9e\xa2\xf3\x88\x8c\x96\x83\xab\xd2\x8cY\x9e\xa0\x8a\x8d'
    set_0 = None
    str_1 = '\x9b'
    dict_0 = {str_1: bytes_0, str_0: set_0}
    float_0 = -3912.90508094

# Generated at 2022-06-24 19:08:48.409009
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Initialization of the test case
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)

    # Invoke method run
    worker_process_0.run()

# Generated at 2022-06-24 19:08:53.728736
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'?\x9f\xf2\x04o\xb1\xc6\xbe\xeb'
    set_0 = set()
    str_1 = '\xd3\xf8\xc1'
    dict_0 = {}
    float_0 = -4.49110878924778E+300
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    try:
        worker_process_0.run()
    except ZeroDivisionError:
        pass


# Generated at 2022-06-24 19:09:02.884400
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = ')'
    bool_0 = True
    bytes_0 = b'\n\xd2g9\xe7\x0c\xcf\xcc\xda\xb7\x98\xa2\xef\x03\x00\xd8f\x0f'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:09:11.963329
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    '''
    multiprocessing.Process replaces the worker's stdin with a new file
    but we wish to preserve it if it is connected to a terminal.
    Therefore dup a copy prior to calling the real start(),
    ensuring the descriptor is preserved somewhere in the new child, and
    make sure it is closed in the parent when start() completes.
    '''
    str_0 = ''
    bool_0 = True
    bytes_0 = b'\x0cE\x1c\x06\x01\x8e\x0eyY\xe2\xd5w\x8d\xa7\x90\xd7\x86\x0e\xf0Y'
    set_0 = None
    str_1 = '\x0b'

# Generated at 2022-06-24 19:09:14.987178
# Unit test for method run of class WorkerProcess

# Generated at 2022-06-24 19:09:22.160661
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '\x13\xfcF\x1f'
    bool_0 = 1
    bytes_0 = b'o'
    set_0 = {}
    str_1 = '\x0f\x1d\x17\x00\x1a\x1b\x0b'
    dict_0 = {str_1: str_0, str_0: bytes_0}
    float_0 = 2343.0
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_1, str_0, dict_0, float_0)
    worker_process_0._run()

# Generated at 2022-06-24 19:09:30.755560
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '-R'
    bool_0 = True
    bytes_0 = b'\x10`6\xfd\x12\xbf\x15|J\x1eN\xdb\x9b\xf9'
    set_0 = None
    str_1 = '\x16'
    dict_0 = {str_0: str_1, str_1: dict_0}
    float_0 = 0.530947
    worker_process_0 = WorkerProcess(str_1, str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.start()
    assert True == True


# Generated at 2022-06-24 19:09:37.196207
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # TODO: Fix
    pass
    #str_0 = '\x01<\x01p\x15\x00\x00'
    #set_0 = None
    #str_1 = '\t\x16'
    #int_0 = -1167
    #dict_0 = {'\x1c': '\x14\x0c', str_0: int_0}
    #float_0 = -4199.89733
    #worker_process_0 = WorkerProcess(str_0, bool_0, bool_0, set_0, str_1, dict_0, float_0)
    #worker_process_0.run()


# Generated at 2022-06-24 19:10:02.235390
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import random
    import string

    # check if it runs with these random values

    str_0 = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(32)])
    bool_0 = random.choice([0, 1])
    bytes_0 = b'\xefII\x1d\xbc\xd5\x05\x82\x8a\xee\xbf\x08\xd5\x83\x9f\x08'
    set_0 = None
    str_1 = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(32)])
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = random.random()
   

# Generated at 2022-06-24 19:10:12.980983
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    del str_0, bool_0, bytes_0, set_0, str_1, dict_0, float_0


# Generated at 2022-06-24 19:10:23.405134
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    str_0 = 'W\xd8\xbe\x99:6\x0f\xdc\xef'

# Generated at 2022-06-24 19:10:32.736803
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print ('Test WorkerProcess run')
    str_0 = '=;L'
    bool_0 = False
    bytes_0 = b'\x98_\xca\xd3\xa5\xea\xce\xcc\xb5\xad\xc4\x83\x8c\xa0\xec\xed\x9b\xdc\x1f\xac'
    set_0 = None
    str_1 = '\xcc\x9b\xdc\x92\x86\xc6\x12\xce'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -1030.033

# Generated at 2022-06-24 19:10:41.168885
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'\xdc\x1c\xe3\x01'
    set_0 = set()
    str_1 = ','
    dict_0 = {str_0: str_1}
    float_0 = -5196.7755
    worker_process_0 = WorkerProcess(str_1, dict_0, bytes_0, set_0, str_0, str_0, dict_0, float_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:10:49.607307
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    dict_0 = {}
    str_0 = '\n}'
    str_1 = '\x0b'
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(dict_0, str_0, bytes_0, str_1, str_0, str_1, dict_0, float_0)
    worker_process_0.run()

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        test_case_0()
    else:
        test_WorkerProcess_run()

# Generated at 2022-06-24 19:11:00.171778
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    # Test for method start of class WorkerProcess
    worker_process_0.start()

    # Test for method _hard_exit of class WorkerProcess
    # TODO: set up

# Generated at 2022-06-24 19:11:03.183459
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    worker_process_0 = WorkerProcess(TaskQueueManager)
    worker_process_0.run()




# Generated at 2022-06-24 19:11:10.265923
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '2\x03\xd5\x95\x19'
    bool_0 = True
    bytes_0 = b'`\xc4\xce\xaaB\xba\xf4\x15\xc4\xf6\x9d\xe9\xa1\x03\x01'
    set_0 = None
    str_1 = '\xe8\x81'
    dict_0 = {str_0: str_0, str_1: bool_0}
    float_0 = -5522.0
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:16.859982
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)

# Generated at 2022-06-24 19:11:54.841652
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = 'n:1;*'
    bool_0 = False
    bytes_0 = b'\x18'
    set_0 = {''}
    str_1 = '\n'
    dict_0 = {}
    float_0 = 0.729904662961
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.start()


test_WorkerProcess_run()
test_case_0()

# Generated at 2022-06-24 19:11:55.670233
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass


# Generated at 2022-06-24 19:12:03.881357
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '\x00\x00\x02\x84'
    bool_0 = True
    bytes_0 = b'\xaaN\x82\xfc\x9a+\xa0F\x1d\x12\x0bw\x89\x93\x9f\t\xad\xaa'
    set_0 = None
    str_1 = "^|\x1c\x8d"
    dict_0 = {str_0: bytes_0, str_1: str_1}
    float_0 = 0.0
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    str_2 = '\x0b'
    bool

# Generated at 2022-06-24 19:12:11.815141
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.run()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:12:21.984348
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    dict_0 = dict()
    dict_0[0] = 0
    str_1 = '}t>|;(E\x0c'
    list_0 = list()
    list_0.append(str_1)
    list_0.append(str_0)
    dict_0[1] = list_0
    dict_0[2] = dict_0
    list_0 = list()
    list_0.append(dict_0)
    dict_0[3] = list_0
    dict_0[4] = str_1
    str_1 = ''
    set_0 = set()
    str_2 = '6K\xfd'
    dict_0[5] = set_0
    dict_0[6] = str_1
    dict_

# Generated at 2022-06-24 19:12:28.852236
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:12:38.823716
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test with fixed parameters
    dict_0 = dict()
    str_0 = 'bKcH'
    worker_process_0 = WorkerProcess(str_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    worker_process_0.run()
    assert worker_process_0._host == dict_0
    assert worker_process_0._loader == dict_0
    assert worker_process_0._task == dict_0
    assert worker_process_0._task_vars == dict_0
    assert worker_process_0._play_context == dict_0
    assert worker_process_0._shared_loader_obj == dict_0
    assert worker_process_0._variable_manager == dict_0
    assert worker_process_0._final_

# Generated at 2022-06-24 19:12:46.082892
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0._run()
    worker_process_0._hard_exit(str_0)

# Generated at 2022-06-24 19:12:50.745001
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.run()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 19:12:58.590027
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'\xbe\x13\xa2K\xf0\x97\xb52\xdd\x12\xf5\x87\x8b\x1e\x16\xa2\x8d\xd6\xdf\x86b'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:14:10.910550
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    assert isinstance(worker_process_0.start(),int)


# Generated at 2022-06-24 19:14:19.729332
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '\x12F\x0b\x03\x1e'
    set_0 = None
    list_0 = ['\x1d', '\x1d', '\x1d', '\x1d', '\x1d']
    str_1 = ''
    bool_0 = True
    list_1 = [b'Gi', b'gi\xf9\x83\x05\xbf', b'gi\xf9\x83\x05\xbf', b'Gi', b'gi\xf9\x83\x05\xbf']
    bytes_0 = b'\x1b{\x07\xe2\r!\x02\x13e\n'
    str_2 = '\x0b'
    float_0 = -2601.76
    worker

# Generated at 2022-06-24 19:14:28.007678
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '\x06\x1d\x08\x1b'
    bool_0 = False
    bytes_0 = b'\x07\x1c\x0e\x0c|\xba\xbd\x0f\x18\t\x1e\x0b\x1d\x08\x0b'
    set_0 = None
    str_1 = '\x0c'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -8693.03124
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.run()

# Unit test

# Generated at 2022-06-24 19:14:34.806763
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:14:41.835471
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    '''
    This function tests WorkerProcess.run. The test case used is (str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0).
    '''
    str_0 = ''
    bool_0 = True
    bytes_0 = b'pr\x8d:\xd8\x0e\x0fd\xcc0,K\x06p\xbeQ\x0e{\xbc'
    set_0 = None
    str_1 = '\x0b'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = -3734.57429

# Generated at 2022-06-24 19:14:44.593506
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()



# Generated at 2022-06-24 19:14:49.019188
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = False
    bytes_0 = b'\x0b'
    set_0 = None
    str_1 = '\n'
    dict_0 = {str_1: str_1, str_0: set_0}
    float_0 = 7239.942134
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    try:
        worker_process_0.run()
    except:
        pass


# Generated at 2022-06-24 19:14:53.763139
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'Q"\x0b\x1e\xe0'
    float_0 = 4.9723
    float_1 = -5.907814197
    list_0 = [str_0, float_0]
    list_1 = [float_1, float_1]
    int_0 = -1
    str_1 = 'D\xc4\xe4'
    str_2 = '\x01\x1e\xe3\x08\x0e\x0b'
    # something with mutable vs immutable
    list_0.append(list_0)
    list_1.append(list_1)
    list_0 = []
    list_1 = []
    list_0 = [2, 3, 4, 5]

# Generated at 2022-06-24 19:15:03.259530
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = ''
    bool_0 = True
    bytes_0 = b'\xcd\xb5M\x1a\xda\xcd\x1f\xe9\x9c\xc7\xab\x8d\xec\x1a\x1f\x90\xb7'
    set_0 = None
    str_1 = '\x99'
    dict_0 = {str_1: bool_0, str_0: bool_0, bytes_0: bool_0}
    float_0 = 2776.67395
    worker_process_0 = WorkerProcess(str_0, bool_0, bytes_0, set_0, str_0, str_1, dict_0, float_0)
    # TODO : verify correct behavior
    worker_process_0.run()

# Generated at 2022-06-24 19:15:13.707604
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'Y'
    str_1 = ';'
    bool_0 = True
    tuple_0 = (str_1, str_0)
    list_0 = []
    list_1 = [str_1]
    list_2 = [str_0]