

# Generated at 2022-06-24 19:07:26.694635
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    worker_process_0 = WorkerProcess(1, 'VZ', 60.89, 1, 'VZ', 60.89, [60.89], 60.89)
    worker_process_0.run()

# testing for coverage, not a real unit test

# Generated at 2022-06-24 19:07:30.694314
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    int_0 = 2284
    float_0 = -29.786086310860686
    str_0 = 'vJ'
    list_0 = [float_0]
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, list_0, float_0)
    worker_process_0.run()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:07:36.929283
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    int_0 = 2284
    float_0 = -29.786086310860686
    str_0 = 'vJ'
    list_0 = [float_0]
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, list_0, float_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:07:44.580989
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    int_0 = 2284
    float_0 = -29.786086310860686
    str_0 = 'vJ'
    list_0 = [float_0]
    print("[RUN     ] WorkerProcessTest.test_WorkerProcess_run")
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, list_0, float_0)
    # The test artifact is a result of recording.
    # There may be additional test attributes added in the recording phase that are not needed in the replay phase
    # Method run of WorkerProcess invoked.


# Generated at 2022-06-24 19:07:45.462802
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:07:50.947343
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # State 0
    int_0 = 2284
    float_0 = -29.786086310860686
    str_0 = 'vJ'
    list_0 = [float_0]
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, list_0, float_0)
    try:
        worker_process_0.run()
    except Exception:
        raise

if __name__ == '__main__':
    # test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:07:59.464350
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    int_0 = 2284
    float_0 = -29.786086310860686
    str_0 = 'vJ'
    list_0 = [float_0]
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, list_0, float_0)
    try:
        worker_process_0.start()
    except:
        pass


# Generated at 2022-06-24 19:08:06.326255
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    int_0 = 103
    float_0 = -41.927883339554055
    str_0 = 'wC'
    list_0 = [float_0]
    worker_process_0 = WorkerProcess(float_0, float_0, str_0, float_0, float_0, float_0, float_0, float_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:11.390199
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    int_0 = 0
    str_0 = '-_2'
    list_0 = [str_0]
    worker_process_0 = WorkerProcess(int_0, int_0, int_0, str_0, str_0, int_0, list_0, str_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:12.506468
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()


# Generated at 2022-06-24 19:08:24.937388
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    int_0 = 1
    str_0 = 'VZ'
    float_0 = 60.89
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, float_0, float_0)

    worker_process_0._run()

# Generated at 2022-06-24 19:08:33.983918
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Construct object to test
    int_0 = 1
    str_0 = 'VZ'
    float_0 = 60.89
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, float_0, float_0)
    worker_process_0.start()

    # Run method
    worker_process_0.run()



# Generated at 2022-06-24 19:08:37.339083
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Test the connection between start and _save_stdin
    worker_process_0 = WorkerProcess(None, None, '10.0.0.1', None, None, None, None, None)
    worker_process_0.start()


# Generated at 2022-06-24 19:08:41.865516
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(1, 'VZ', 60.89, 1, 'VZ', 60.89, 60.89, 60.89)
    worker_process_0.run()

# Generated at 2022-06-24 19:08:49.285277
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    #try:
    #    assert 'assert' in globals()
    #except AssertionError:
    #    raise ImportError('Your python interpreter does not have the "assert" keyword. ' +
    #        'Please remove this line from your test_WorkerProcess_start() function.')
    # Create an instance of a WorkerProcess object
    worker_process_0 = WorkerProcess(int, str, float, int, str, float, float, float)
    # Invoke the start method of class WorkerProcess to perform unit test
    worker_process_0.start()


# Generated at 2022-06-24 19:08:59.872865
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # Load the module
    from ansible.executor.worker_process import WorkerProcess

    # Call the method
    # Parameters:
    #   str_0: 'N')
    #   str_1: 'D/gf'
    #   float_0: 0.95
    #   int_0: -2
    #   str_2: '_U'
    #   float_1: 0.79
    #   float_2: 0.88
    #   float_3: 6.0
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, float_0, float_0)

    # check the value of worker_process_0.play_context in the WorkerProcess._save_stdin.worker_process_0.start()

# Generated at 2022-06-24 19:09:03.837063
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    int_0 = 1
    str_0 = 'VZ'
    float_0 = 60.89
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, float_0, float_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:09:04.798163
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Tests if test_case_0 passes

# Generated at 2022-06-24 19:09:06.007686
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:09:11.601234
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    int_0 = 1
    str_0 = 'VZ'
    float_0 = 60.89
    worker_process_0 = WorkerProcess(int_0, str_0, float_0, int_0, str_0, float_0, float_0, float_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:09:29.824961
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()
    worker_process_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 19:09:33.717828
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()
    assert var_0 == None


# Generated at 2022-06-24 19:09:36.474099
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:09:48.060560
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    from multiprocessing import Queue

    str_0 = '10.0.0.1'
    str_1 = '10.0.0.2'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()
    worker_process_1 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_1 = worker_process_1.start()
    worker_process_2 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var

# Generated at 2022-06-24 19:09:51.323851
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:09:53.121774
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess('', '', '', '', '', '', '', '')
    worker_process_0.start()


# Generated at 2022-06-24 19:09:55.930545
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print("Start test_WorkerProcess_start")
    # Test case 0
    test_case_0()
    print("End test_WorkerProcess_start")


# test_case_0()

# Generated at 2022-06-24 19:09:59.151982
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:02.578333
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.run()
    var_0 = worker_process_0.start()

# Generated at 2022-06-24 19:10:08.866553
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():

    # Test case with print statements
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()

# Generated at 2022-06-24 19:10:31.095939
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task as RoleTask
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Testing of the run method of the WorkerProcess class

# Generated at 2022-06-24 19:10:39.023380
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()
    worker_process_0.run()
    del worker_process_0

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:46.475863
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print('Test WorkerProcess.run(): start')
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.run()
    print('Test WorkerProcess.run(): end')


if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:54.109776
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = "10.0.0.1"
    str_1 = "10.0.0.2"
    str_2 = "10.0.0.3"
    str_3 = "10.0.0.4"
    str_4 = "10.0.0.5"
    str_5 = "10.0.0.6"
    str_6 = "10.0.0.7"
    test_case_0(str_0, str_1, str_2, str_3, str_4, str_5, str_6)

if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:57.746294
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()



# Generated at 2022-06-24 19:11:06.033181
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    last_stdin = sys.stdin
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()
    assert last_stdin == sys.stdin.fileno()

    import tempfile
    test_fd = tempfile.TemporaryFile()
    test_fd.write(b'\n')
    test_fd.seek(0)
    sys.stdin = test_fd

    str_1 = '10.0.0.1'

# Generated at 2022-06-24 19:11:09.980585
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    try:
        worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
        try:
            var_0 = worker_process_0.start()
        except BaseException as e_0:
            raise
    except Exception:
        raise
    except BaseException as e_1:
        raise


# Generated at 2022-06-24 19:11:10.852780
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Test cases for method run of class WorkerProcess

# Generated at 2022-06-24 19:11:13.461495
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.run()


# Generated at 2022-06-24 19:11:15.982101
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:11:40.546676
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.2'
    worker_process_1 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_1.run()
    print(var_0)

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:11:43.769628
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:11:44.939365
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    assert callable(getattr(WorkerProcess, "run", None))


# Generated at 2022-06-24 19:11:47.606266
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    import tempfile
    path = tempfile.mktemp()
    fd = open(path, 'w')
    fd.write('Test file for class WorkerProcess\n')
    fd.close()
    with open(path, 'r') as f:
        for line in f:
            print(line)


# Generated at 2022-06-24 19:11:49.861440
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # verify attribute 'name' is mapped to Multiprocessing.Process.name
    var_0 = WorkerProcess.start
    assert var_0 == 'start'
    assert var_0 is not None


# Generated at 2022-06-24 19:11:58.420299
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # Load host inventory
    inventory = InventoryManager(loader=DataLoader(), sources=['hosts'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello Ansible from worker_process.py')))
        ]
    )


# Generated at 2022-06-24 19:12:04.522117
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print("::: ansible-test sanity: starting sanity test 'WorkerProcess'")
    print("TEST0: Test 'run' method of class WorkerProcess")
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:12:12.088187
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # initialize the object
    str_0 = '10.0.0.1'
    str_1 = '10.0.0.2'
    str_2 = '10.0.0.3'
    str_3 = '10.0.0.4'
    str_4 = '10.0.0.5'
    str_5 = '10.0.0.6'
    str_6 = '10.0.0.7'
    str_7 = '10.0.0.8'
    worker_process_0 = WorkerProcess(str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7)
    # invoke run
    worker_process_0.run()


# Generated at 2022-06-24 19:12:20.002330
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.1'
    worker_process_1 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_1 = worker_process_1.run()

test_case_0()
#test_WorkerProcess_run()
#python -m pytest -v test_worker_process_0.py
#python3 -m pytest -v test_worker_process_0.py

# Generated at 2022-06-24 19:12:24.265678
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.run() # Should throw exception


# Generated at 2022-06-24 19:13:01.176756
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()



# Generated at 2022-06-24 19:13:04.006529
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:13:04.495953
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:13:06.877768
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    assert_expect(test_case_0, worker_process_0)

# Generated at 2022-06-24 19:13:09.716716
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_1 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_1.run()

# Generated at 2022-06-24 19:13:19.324859
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test with some number of arguments
    str_0 = '10.0.0.1'
    str_1 = '10.0.0.1'
    str_2 = '10.0.0.1'
    str_3 = '10.0.0.1'
    str_4 = '10.0.0.1'
    str_5 = '10.0.0.1'
    str_6 = '10.0.0.1'
    str_7 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()
    var_1 = worker_process_0._run()

# Generated at 2022-06-24 19:13:22.429292
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # TODO: test
    pass



# Generated at 2022-06-24 19:13:25.234689
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()



# Generated at 2022-06-24 19:13:28.597611
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()



# Generated at 2022-06-24 19:13:29.260092
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:14:48.471975
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_1 = '10.0.0.1'
    str_2 = '10.0.0.2'
    str_3 = '10.0.0.3'
    str_4 = '10.0.0.4'
    str_5 = '10.0.0.5'
    str_6 = '10.0.0.6'
    str_7 = '10.0.0.7'
    str_8 = '10.0.0.8'
    str_9 = '10.0.0.9'
    str_10 = '10.0.0.10'
    str_11 = '10.0.0.11'
    str_12 = '10.0.0.12'
    str_13 = '10.0.0.13'
    str_14

# Generated at 2022-06-24 19:14:49.095333
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:14:51.889406
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_1 = '10.0.0.1'
    var_1 = WorkerProcess(str_1, str_1, str_1, str_1, str_1, str_1, str_1, str_1)
    var_1.run()


# Generated at 2022-06-24 19:14:55.540182
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:14:58.776483
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()
    var_0 = worker_process_0.run()



# Generated at 2022-06-24 19:15:03.845324
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()

test_case_0()
test_case_0()

# Generated at 2022-06-24 19:15:09.009955
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.1'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    worker_process_0.run()
    worker_process_0._run()

# Generated at 2022-06-24 19:15:11.551369
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print('Start testing')
    test_case_0()
    print('End of testing')

if __name__ == '__main__':
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:15:15.465442
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_1 = '10.0.0.1'
    worker_process_1 = WorkerProcess(str_1, str_1, str_1, str_1, str_1, str_1, str_1, str_1)
    var_1 = worker_process_1.start()


# Generated at 2022-06-24 19:15:23.254785
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '10.0.0.2'
    worker_process_0 = WorkerProcess(str_0, str_0, str_0, str_0, str_0, str_0, str_0, str_0)
    var_0 = worker_process_0.start()
    worker_process_0.run()


if __name__ == '__main__':
    display = Display()
    test_case_0()
    # test_WorkerProcess_run()
    # test_case_2()
    pass