

# Generated at 2022-06-24 19:07:28.310978
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = 'qE$u^X'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.start()
    assert var_0 == None


# Generated at 2022-06-24 19:07:38.074793
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '\u0007@\x00x\x7f\x00\u0013\x19'
    str_1 = '\u0007@\x00x\x7f\x00\u0013\x19'
    bool_0 = True
    str_2 = '@'
    str_3 = '\u0007@\x00x\x7f\x00\u0013\x19'
    str_4 = '\u0007@\x00x\x7f\x00\u0013\x19'
    str_5 = '@'
    str_6 = '@'
    str_7 = '\u0007@\x00x\x7f\x00\u0013\x19'

# Generated at 2022-06-24 19:07:43.581352
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = '$#.6o!pho-\\\n<+8C\t%'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.start()

# Generated at 2022-06-24 19:07:45.454730
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process = WorkerProcess()
    worker_process.run()
    assert worker_process.run() == None


# Generated at 2022-06-24 19:07:49.775495
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = False
    str_0 = 'fe+TpTJG'
    int_0 = 949
    tuple_0 = (str_0,)
    worker_process_0 = WorkerProcess(int_0, str_0, str_0, int_0, str_0, str_0, int_0, tuple_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:07:52.017458
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except:
        print('Exception:', sys.exc_info()[0])
        print('Traceback:', traceback.print_tb(sys.exc_info()[2]))

test_WorkerProcess_start()

# Generated at 2022-06-24 19:07:57.105152
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ' + str(e))
    else:
        print('No exception')

test_WorkerProcess_start()

# Generated at 2022-06-24 19:08:03.939862
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    str_0 = 'R1#wZr|V+1'
    bool_0 = True
    bool_1 = False
    int_0 = 63
    str_1 = 'e'
    str_2 = 'x?vN}'
    tuple_0 = (int_0,)
    str_3 = 'p0;0,{'
    str_4 = '\x11<>.q-`eI#'
    str_5 = '\x0c#_\x1e}1'
    str_6 = 'nF|\'(o'
    worker_process_0 = WorkerProcess(str_0, str_4, bool_1, bool_0, str_5, str_6, str_1, tuple_0)
    var_0 = worker_process_0.start()
    str_

# Generated at 2022-06-24 19:08:06.601064
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print('Test failed')
    else:
        print('Test Successful')

test_WorkerProcess_start()

# Generated at 2022-06-24 19:08:10.773834
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = 'E\t]<p  .'
    int_0 = -1
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    worker_process_0._run()

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.test_case_0']
    #unittest.main()
    test_case_0()

# Generated at 2022-06-24 19:08:24.740837
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    obj_0 = WorkerProcess()
    test_case_0()

if __name__ == '__main__':
    '''
    Note: The doctest module automatically tests the functions and classes
    defined by doctest examples, so we will only run the test cases
    explicitly.
    '''
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:08:28.605472
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print("Call method start of class WorkerProcess")
    test_case_0()



# Generated at 2022-06-24 19:08:39.957311
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    print('This is a unit test for method run of class WorkerProcess')

# Generated at 2022-06-24 19:08:45.856063
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:08:50.513340
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    workerprocess_instance = WorkerProcess(final_q=None,
                                          task_vars=None,
                                          host=None,
                                          task=None,
                                          play_context=None,
                                          loader=None,
                                          variable_manager=None,
                                          shared_loader_obj=None)
    workerprocess_instance.start()
    test_case_0()


# Generated at 2022-06-24 19:08:54.726443
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    try:
        WorkerProcess(final_q=None, task_vars=None, host=None, task=None, play_context=None, loader=None, variable_manager=None, shared_loader_obj=None).run()
        print('Test case 0 succeeded!')
    except:
        print('Test case 0 failed.')


# Generated at 2022-06-24 19:09:05.140610
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print('\033[1m' + 'Method name: start \t\t\t' + '\033[0m')
    wp_1 = WorkerProcess(final_q='str_0', task_vars='str_0', host='str_0', task='str_0', play_context='str_0', loader='str_0', variable_manager='str_0', shared_loader_obj='str_0')
    for i in range(4):
        print('\033[1m' + 'Test case: ' + str(i) + '\t\t\t' + '\033[0m')
        if i == 0:
            print('\033[1m' + 'Normal case: ' + '\033[0m')
            wp_1.start()
        elif i == 1:
            print

# Generated at 2022-06-24 19:09:07.617864
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    x_WorkerProcess=WorkerProcess(final_q=None,task_vars=None,host=None,task=None,play_context=None,loader=None,variable_manager=None,shared_loader_obj=None)
    test_case_0()

test_WorkerProcess_start()

# Generated at 2022-06-24 19:09:11.260660
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process = WorkerProcess('', '', '', '', '', '', '', '')
    worker_process.run()
    assert worker_process.run() == None

if __name__ == '__main__':
    test_WorkerProcess_run()
    test_case_0()

# Generated at 2022-06-24 19:09:13.272542
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    output = ''
    try:
        test_case_0()    # Test Successful
    except Exception as e:
        output = to_text(e)
    assert not output, 'Test Failed'


# Generated at 2022-06-24 19:09:22.499494
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:09:23.845533
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = worker_process('unittest')


# Generated at 2022-06-24 19:09:25.608111
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()


# Generated at 2022-06-24 19:09:28.996289
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    success = True
    try:
        # assertion
        assert success, "start()"
    except AssertionError:
        print("An error occurred in the test case: test_WorkerProcess_start.")


# Generated at 2022-06-24 19:09:30.124398
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# vim: set expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-24 19:09:35.766444
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_1 = WorkerProcess()
    worker_process_1._run()

if __name__ == "__main__":

    # Copy stdin and stdout so that the test code can be used standalone or run
    # inside a worker process and still have the tests work.
    import copy

    sys.stdin = copy.copy(sys.stdin)
    sys.stdout = copy.copy(sys.stdout)
    sys.stderr = copy.copy(sys.stderr)

    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:09:39.142208
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    global worker_process_0
    worker_process_0 = WorkerProcess()
    WorkerProcess.start(worker_process_0)


# Generated at 2022-06-24 19:09:39.844455
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass

# Generated at 2022-06-24 19:09:41.597730
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()
    worker_process_0.start()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:09:44.556189
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_1 = WorkerProcess()
    worker_process_1.run()

if __name__ == "__main__":
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:09:59.138349
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = 'sd\t@|y'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    worker_process_0.start()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 19:10:04.807325
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess('azfd)c%n*Xb_R', 'D8Wj:?a~o', True, True, '', '.Qb^k[v@Hm', 'R5m5eDg!C=', ())
    worker_process_0.start()


# Generated at 2022-06-24 19:10:05.478905
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Do something
    pass


# Generated at 2022-06-24 19:10:09.656308
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = 'J\x1d\x1e\x03\x0bR`\x01\x12_\n$'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    worker_process_0.start()
    var_0 = worker_process_0.run()
    assert var_0 == None


# Generated at 2022-06-24 19:10:13.452625
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = 'j'
    int_0 = 41
    tuple_0 = (str_0,)
    worker_process_0 = WorkerProcess(bool_0, str_0, str_0, int_0, str_0, tuple_0, bool_0, str_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:10:20.502267
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = '6'
    int_0 = 7
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_1 = worker_process_0.run()


if __name__=='__main__':
    test_WorkerProcess_run()
    test_case_0()

# Generated at 2022-06-24 19:10:26.983554
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = 'J`-"a\x1bvZ8W[\x0b=\x7f#OiB-!h${Y|$8>\x1a<'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    worker_process_0.start()
    worker_process_0.run()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_run()

# Generated at 2022-06-24 19:10:27.862267
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:10:29.189575
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Test case: Class WorkerProcess has method run
    assert(True)

# Test case: Class WorkerProcess has method start

# Generated at 2022-06-24 19:10:30.917333
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Input parameters
    # Output type: int
    # Test case
    return_var = test_case_0()
    # Output verification
    assert return_var == 0


# Generated at 2022-06-24 19:10:51.755099
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = '^yhC\t(a?65\r'
    int_0 = 94
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:10:59.885189
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = 'n\x1b|n\x10w(C\x16['
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    try:
        var_0 = worker_process_0.run()
    except Exception as e:
        print(e)
        print(traceback.format_exc())
        assert False


# Generated at 2022-06-24 19:11:02.201358
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    # Setup
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)

    # Invoke method
    worker_process_0.start()



# Generated at 2022-06-24 19:11:08.437494
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = 'r'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.start()



# Generated at 2022-06-24 19:11:09.094339
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    test_case_0()

# Generated at 2022-06-24 19:11:10.691676
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Input parameters
    # Output parameters
    # Return value(s)
    # No exceptions to catch

    # Call the function
    test_case_0()


# Generated at 2022-06-24 19:11:16.995355
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Declare test variables
    WorkerProcess_run_arg_0 = str()
    WorkerProcess_run_arg_1 = str()
    WorkerProcess_run_arg_2 = str()
    WorkerProcess_run_arg_3 = str()
    WorkerProcess_run_arg_4 = str()
    WorkerProcess_run_arg_5 = str()
    WorkerProcess_run_arg_6 = str()
    WorkerProcess_run_arg_7 = str()
    WorkerProcess_run_arg_8 = str()

    # Setup test values
    WorkerProcess_run_arg_0 = '3qq1J5r5xu'
    WorkerProcess_run_arg_1 = 'J*15b^'
    WorkerProcess_run_arg_2 = 'y_*CJ'

# Generated at 2022-06-24 19:11:17.672505
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:11:23.668403
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    str_0 = '  -!\nJ;$\x0c\x00\x0b\\'
    str_1 = '*'
    int_0 = 3
    tuple_0 = (str_0, int_0, int_0)
    bool_0 = True
    str_2 = '-udp'
    list_0 = [str_0]
    tuple_1 = (str_1, str_2, str_0)
    int_1 = 96
    set_0 = {list_0}
    set_1 = {tuple_1}
    tuple_2 = (int_0, tuple_1, bool_0, tuple_0, bool_0)
    list_1 = [set_1, int_1, str_1]

# Generated at 2022-06-24 19:11:31.188297
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = 'zp!Sli:E:mO\\\no=_O'
    int_0 = 100
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:12:14.431340
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = '|,wY2\t`/x^tX9/h\x7fE\t#]PL\tZu.P\x7f5o'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    worker_process_0.start()


# Generated at 2022-06-24 19:12:20.658811
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = '$#.6o!pho-\\\n<+8C\t%'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.run()



# Generated at 2022-06-24 19:12:22.214762
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()


# Generated at 2022-06-24 19:12:24.516955
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():

    obj = WorkerProcess()
    obj.run()
    # TODO: set the var_0 value to something that is not None
    var_0 = obj._run()
    assert var_0 is None


# Generated at 2022-06-24 19:12:28.178302
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess('str_0', 'str_0', True, True, 'str_0', 'str_0', 'str_0', (40,))
    worker_process_0.start()


if __name__ == '__main__':
    pass
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:12:29.158087
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()

test_WorkerProcess_start()

# Generated at 2022-06-24 19:12:37.963435
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = '1'
    str_1 = '"{$1erp\tRK@!\x0cK^&W'
    str_2 = 'Bn!@7#hW4#ZqG'
    str_3 = 'GQW6N.UBl\x0c'
    int_0 = 0
    worker_process_0 = WorkerProcess(str_0, str_1, str_2, str_3, int_0, int_0, int_0, int_0)
    var_0 = worker_process_0.start()
    assert var_0 is None


# Generated at 2022-06-24 19:12:38.661997
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert True == True

# Generated at 2022-06-24 19:12:39.359520
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    test_case_0()



# Generated at 2022-06-24 19:12:44.827993
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = '`(*5'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    if __name__ == '__main__':
        try:
            test_WorkerProcess_run()
        except:
            pass
        else:
            raise Exception('Test failed!')

# Generated at 2022-06-24 19:13:53.449656
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except Exception as inst:
        print(inst)
    return True

if __name__ == '__main__':
    print(test_WorkerProcess_start())

# Generated at 2022-06-24 19:14:02.612248
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    worker_process_0._new_stdin = None
    try:
        worker_process_0._save_stdin()
    except BaseException as error_0:
        pass
    worker_process_0.name = '1'
    worker_process_0._pid = 0
    worker_process_0._parent_pid = 0
    var_0 = worker_process_0.start()

str_0 = 'S=%c\\w*f\\[2-7mK\\4\\9O,*\\$\\^iC'
bool_0 = True
int_0 = 40
tuple_0 = (int_0,)

# Generated at 2022-06-24 19:14:03.941813
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Call worker_process_0.run()
    test_case_0()

# Generated at 2022-06-24 19:14:05.516691
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    try:
        test_case_0()
    except:
        pass
    finally:
        pass




# Generated at 2022-06-24 19:14:09.632491
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    print("Testing start")
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
        assert False
    assert True

if __name__ == '__main__':
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:14:17.352080
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = 'h|-c>8"p#V+Bn\t'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    worker_process_0.start()
    worker_process_0.run()


# Generated at 2022-06-24 19:14:21.174257
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = 'void'
    int_0 = 640
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    worker_process_0.start()
    worker_process_0.run()


# Generated at 2022-06-24 19:14:27.702683
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = '$#.6o!pho-\\\n<+8C\t%'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.run()

if __name__ == '__main__':
    test_case_0()
    # test_WorkerProcess_run()

# Generated at 2022-06-24 19:14:28.464006
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    pass


# Generated at 2022-06-24 19:14:29.666939
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    worker_process_0 = WorkerProcess()
    worker_process_0.run()

# use the test_*() functions to evaluate WorkerProcess()

# Generated at 2022-06-24 19:16:46.689417
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    bool_0 = True
    str_0 = 'H^\x7fGXl$g(7\x1dZ\n'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.run()


# Generated at 2022-06-24 19:16:48.684942
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess()

    try:
        worker_process_0.start()
    except SystemExit:
        # expected
        return

    assert False


# Generated at 2022-06-24 19:16:53.689787
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    # Arrange
    bool_0 = True
    str_0 = '$#.6o!pho-\\\n<+8C\t%'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)

    # Act
    var_0 = worker_process_0.run()

    # Assert
    assert var_0 is None

    # Cleanup - none necessary



# Generated at 2022-06-24 19:17:01.742112
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    bool_0 = True
    str_0 = 's\x00ZU6[o\x17C\x04\x1f[&(Y\x08\x1b4'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.start()

if __name__ == '__main__':
    test_case_0()
    test_WorkerProcess_start()

# Generated at 2022-06-24 19:17:04.872231
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    worker_process_0 = WorkerProcess(None, None, None, None, None, None, None, None)
    var_0 = worker_process_0.start()


# Generated at 2022-06-24 19:17:05.666631
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    assert test_case_0()

# Generated at 2022-06-24 19:17:11.870562
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
    from multiprocessing import Queue
    bool_0 = True
    str_0 = '$#.6o!pho-\\\n<+8C\t%'
    int_0 = 40
    tuple_0 = (int_0,)
    worker_process_0 = WorkerProcess(str_0, str_0, bool_0, bool_0, str_0, str_0, str_0, tuple_0)
    var_0 = worker_process_0.run()
    # Renaming method parameter...
    expected_0 = None
    # Renaming method parameter...
    actual_0 = None
    assert expected_0 == actual_0


# Generated at 2022-06-24 19:17:13.017919
# Unit test for method run of class WorkerProcess
def test_WorkerProcess_run():
  # run method throws no exception
  assert True


# Generated at 2022-06-24 19:17:16.385787
# Unit test for method start of class WorkerProcess
def test_WorkerProcess_start():
    int_0 = WorkerProcess('`+Z~IeH\n', '%', True, -20, 'M}-2E{7', '6:', 'V7P,?N', [True, True])._save_stdin()
    assert (int_0 == None)
