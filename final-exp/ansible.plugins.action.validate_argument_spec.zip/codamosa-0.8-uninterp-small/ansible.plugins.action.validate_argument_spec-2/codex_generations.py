

# Generated at 2022-06-25 07:52:03.858985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 24
    float_0 = 242.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    # Create instance
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:52:14.964922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 24
    float_0 = 242.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    # assert action_module_0._handle_aliases is False
    # assert action_module_0._task.action == 'plugin'
    # assert action_module_0._tmp is None
    action_module_0 = None


# Generated at 2022-06-25 07:52:24.448051
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bool_0 = False
    int_0 = 24
    float_0 = 242.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    tmp_0 = None
    task_vars_0 = dict()
    argument_spec_0 = dict()
    result_0 = action_module_0.get_args_from_task_vars(argument_spec_0, task_vars_0)
    print(result_0)


# Generated at 2022-06-25 07:52:29.097664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 466
    float_0 = 4.33
    list_0 = [float_0, float_0, float_0, float_0]
    bool_1 = False
    bytes_0 = b'\xbe\x85\x8a\xd1\x89}k\xbf\x12\xcbv\xd2\x9b'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_1, bytes_0)


# Generated at 2022-06-25 07:52:38.241410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {u'bool_0_0': True, u'list_0_0': [256, 256, 256], u'int_0_0': -22, u'str_0_0': u'1\u00a41\u00f3\u00b2\u00ed\u00a8\u0082\u00db\u00fc\u0099e\u00b3\u00b9\u009c', u'bytes_0_0': b'\x0f\x01\xe1\xfc\x94\x9aG\xa2\xde\x95\xab\xd1\t\xd7\xafE\x0f\xc9'}
    task_vars_0 = dict()

# Generated at 2022-06-25 07:52:39.633660
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Run the constructor test
    test_case_0()


# Generated at 2022-06-25 07:52:44.281961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 24
    float_0 = 242.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)


# Generated at 2022-06-25 07:52:50.878688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    int_0 = 71
    float_0 = 938.086
    list_0 = [float_0, int_0, int_0, int_0]
    bool_1 = True
    bytes_0 = b'\xc2\x8f\xbf\x95\t\xada\xb8\x16\x13\xc2\xac\xe2\x1b\xb5\x9f9'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_1, bytes_0)


# Generated at 2022-06-25 07:52:51.736439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {}
    ActionModule(data)

# Generated at 2022-06-25 07:52:58.339399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    int_0 = 5
    float_0 = 3.0
    list_0 = [bool_0, bool_0, int_0]
    dict_0 = {'blah': 'blah'}
    str_0 = 'asdf'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, str_0)
    tmp, task_vars = dict_0, dict_0
    result = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:53:03.605967
# Unit test for constructor of class ActionModule
def test_ActionModule():

  # test constructor with action_plugins_path
  print('constructor of class ActionModule:')
  var_0 = {}
  action_module_0 = ActionModule(var_0)
  assert isinstance(action_module_0,ActionModule)


# Generated at 2022-06-25 07:53:13.939243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}
    action_module_0 = ActionModule(var_0)
    # <ansible.utils.vars.CombineVars object at 0x7f5b6323cda0>
    var_2 = combine_vars(var_0, var_1)
    action_result_0 = action_module_0.run(var_2=var_2)
    assert action_result_0 == {
        'changed': False,
        'failed': True,
        'msg': '"argument_spec" arg is required in args: {}'
    }

# Generated at 2022-06-25 07:53:24.551193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_0['argument_spec'] = "argument_spec"
    # var_0 = {}
    var_0['provided_arguments'] = "provided_arguments"
    # var_0 = {}
    var_0['msg'] = "msg"
    # var_0 = {}
    var_0['validate_args_context'] = "validate_args_context"
    # var_0 = {}
    var_0['argument_spec_data'] = "argument_spec_data"
    # var_0 = {}
    var_0['failed'] = "failed"
    # var_0 = {}
    var_0['changed'] = "changed"
    # var_0 = {}
    var_0['argument_errors'] = "argument_errors"
    action_module_0 = Action

# Generated at 2022-06-25 07:53:25.757841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    action_module_0 = ActionModule(var_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:53:36.164536
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:53:42.876192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = {}
    action_module_1 = ActionModule(var_1)
    var_2 = None
    var_3 = {}
    var_4 = action_module_1.run(var_2, var_3)



# Generated at 2022-06-25 07:53:47.878916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-25 07:53:55.371848
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    var_0 = {}
    action_module_0 = ActionModule(var_0)
    action_module_0._task = {'args': {'argument_spec': {'arg_0': {'type': 'bool'}}, 'provided_arguments': {'arg_0': True}}}
    argument_spec_1 = {}
    task_vars_1 = {}
    ret_1 = action_module_0.get_args_from_task_vars(argument_spec_1, task_vars_1)
    assert ret_1 == {}


# Generated at 2022-06-25 07:54:03.755381
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    var_0 = {}
    action_module_0 = ActionModule(var_0)
    action_module_0._templar = var_0

    var_1 = {}
    arg_spec_1 = var_1
    var_2 = {}
    task_vars_2 = var_2

    action_module_0.get_args_from_task_vars(arg_spec_1, task_vars_2)


# Generated at 2022-06-25 07:54:05.929819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    tmp_1 = None
    task_vars_2 = None
    var_3 = ActionModule.run(var_0, tmp_1, task_vars_2)

# Generated at 2022-06-25 07:54:10.453993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    var_0 = {}

# Generated at 2022-06-25 07:54:12.897745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    unit = ActionModule()
    assert(unit._task.action == 'validate_argument_spec')


# Generated at 2022-06-25 07:54:16.694927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_module_validate_args = ActionModule()
    assert ansible_module_validate_args.run({}, {"argument_spec": {}, "provided_arguments": {}}, {})


# Generated at 2022-06-25 07:54:19.969207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}


# Generated at 2022-06-25 07:54:22.829518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None
    )
    assert action_module is not None


# Generated at 2022-06-25 07:54:25.018817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}

    # instance for ActionModule class
    obj = ActionModule()
    ret_value = obj.run(var_0, var_0)
    assert ret_value is not None


# Generated at 2022-06-25 07:54:26.762273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # instantiate an instance of class ActionModule
    obj = ActionModule()
    assert obj is not None


# Generated at 2022-06-25 07:54:29.034905
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the object that will be used to run the tests
    a = ActionModule('test')

    # Import the test data
    data_in = test_case_0()

    # Run the tests
    a.run()


# Unit tests for the methods of the ActionModule class

# Generated at 2022-06-25 07:54:37.900566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars_0 = {}
    tmp_0 = None

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            ret= {'failed': None, 'changed': True}
            return ret

    action_module_0 = TestActionModule()

    result_1 = action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)
    assert result_1.get('failed') is None
    assert result_1.get('changed')





# Generated at 2022-06-25 07:54:45.738555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}
    obj_0 = {}
    obj_0 = ActionModule({"__ansible_vars": var_1}, obj_0)

# Generated at 2022-06-25 07:54:50.327113
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    instance = ActionModule(var_0, var_0)


# Generated at 2022-06-25 07:54:51.389772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({})
    assert not module.run()

# Generated at 2022-06-25 07:54:54.720460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {
        'provided_arguments': {
            'argument_spec': {}
        },
        'validate_args_context': {},
        'argument_spec': {}
    }
    result = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None).run(task_vars=None, tmp=None, **args)

    assert result is not None

# Generated at 2022-06-25 07:54:59.239086
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins
    var_0 = vars(builtins)
    test_case_0()

# Generated at 2022-06-25 07:55:05.144383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    argspec = {}
    argspec['foo'] = {'type': 'str', 'required': False}

    task_vars = {}
    task_vars['foo'] = 'hello'

    # Act
    validator = ArgumentSpecValidator(argspec)
    validation_result = validator.validate(task_vars)
    assert validation_result.error_messages == []

# Generated at 2022-06-25 07:55:06.280283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(Exception):
        var_0 = ActionModule(var_0)


# Generated at 2022-06-25 07:55:09.935451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(
        task=var_0,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert mod is not None


# Generated at 2022-06-25 07:55:12.899214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a class to test
    action_module = ActionModule(play_context=play_context, new_stdin='True')



# Generated at 2022-06-25 07:55:19.840756
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import iteritems, string_types
    from ansible.utils.vars import combine_vars

    class test_obj(ActionBase):
        ''' Validate an arg spec'''
        TRANSFERS_FILES = False

        def get_args_from_task_vars(self, argument_spec, task_vars):
            '''
            Get any arguments that may come from `task_vars`.

            Expand templated variables so we can validate the actual values.

            :param argument_spec: A dict of the argument spec.
            :param task_vars: A dict of task variables.

            :returns: A dict of values that can be validated against the arg spec.
            '''


# Generated at 2022-06-25 07:55:21.093742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    instance_0 = ActionModule()
    assert instance_0 is not None


# Generated at 2022-06-25 07:55:26.257521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    parameter_0 = {}
    parameter_1 = {}
    parameter_2 = {}



# Generated at 2022-06-25 07:55:27.304644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 07:55:35.230655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_n = {}
    var_n['validate_args_context'] = 'validate_args_context'
    var_n['failed'] = False
    var_n['msg'] = 'The arg spec validation passed'
    var_n['changed'] = False
    var_n['argument_spec_data'] = var_0
    var_n['argument_errors'] = var_0
    var_n['task_vars'] = var_0
    var_n['ansible_facts'] = var_0
    var_n['ansible_loop_var'] = var_0
    var_n['ansible_forks'] = var_0
    var_n['ansible_version'] = var_0
    var_n['ansible_hostname'] = var_0
    var_

# Generated at 2022-06-25 07:55:38.295930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mm = test_case_0()
    ActionModule.run(mm, tmp, task_vars)

# Generated at 2022-06-25 07:55:46.777457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The simple evaluation of the argument_spec parameter is enough to run the
    # test. The code below is kept for documentation purposes.

    tmp = None

    class ActionModule_Mock():
        def __init__(self, tmp):
            self._task = ActionModule_run__task_Mock(tmp)

        def run(self, tmp, task_vars):
            self._task.run(tmp, task_vars)

    class ActionModule_run__task_Mock():
        def __init__(self, tmp):
            self.args = test_case_0
            self._task = ActionModule_run__task_Mock._task_Mock(tmp)

        def run(self, tmp, task_vars):
            raise AnsibleError


# Generated at 2022-06-25 07:55:49.233842
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    assert isinstance(ActionModule().get_args_from_task_vars(var_0, var_0), dict)


# Generated at 2022-06-25 07:55:51.349728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    action_module = ActionModule(var_0, None)
    assert type(action_module) == ActionModule


# Generated at 2022-06-25 07:55:53.449116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()


# Generated at 2022-06-25 07:55:59.903099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run the unit test
    result = test_case_0()

    # Print the result
    print(result)

    # Verify the result
    assert result == "All test cases passed"

# Generated at 2022-06-25 07:56:02.407523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {}
    assert TypeError is ActionModule.run(tmp, task_vars)


# Generated at 2022-06-25 07:56:13.928321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the construction of ActionModule instance
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:56:17.844651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    test the method run() of class ActionModule with the following parameters

    :param  :
    :param  :
    :param  :
    :param  :
    :param  :
    :param  :
    :param  :
    :param  :
    :param  :

    """
    # TODO: Test goes here.
    pass


# Generated at 2022-06-25 07:56:18.675489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:56:20.561790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test that it returns a result
    assert True


# Generated at 2022-06-25 07:56:29.576945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    int_0 = -1288
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bool_1 = True
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_1, bytes_0)
    assert action_module_0.task_vars == {}
    assert action_module_0.noop_task_vars == {}
    assert action_module_0.tmp == '/tmp/ansible-tmp-1582279757.14-146712033076254'

# Generated at 2022-06-25 07:56:34.070621
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    argument_spec_0 = {}
    task_vars_0 = {}
    action_module_1 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    action_module_1.get_args_from_task_vars(argument_spec_0, task_vars_0)


# Generated at 2022-06-25 07:56:36.212661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == expected_return_value

# Do not edit the following line
# TEST_CASES["test_ActionModule_run"] = test_ActionModule_run


# Generated at 2022-06-25 07:56:42.489778
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    try:
        action_module_0.run()
    except AnsibleError:
        pass
    try:
        action_module_0.run(bool_0)
    except AnsibleError:
        pass
    try:
        action_module_0.run(int_0)
    except AnsibleError:
        pass

# Generated at 2022-06-25 07:56:46.584481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    action_module = ActionModule(tmp, task_vars)
    var = action_module.run()

# Generated at 2022-06-25 07:56:53.665720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)
    assert var_0 == int_0

# Generated at 2022-06-25 07:57:09.031949
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -8954
    bool_0 = True
    float_0 = 100.0
    list_0 = [int_0, int_0, int_0]
    bytes_0 = b'\x98F\x1a\x95\x90\xc2\xab\x08\xda#\xc6\xbf\x8a\xf5\x7f\xae'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    var_0 = action_run(int_0)


# Generated at 2022-06-25 07:57:10.543907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run()')

    # TODO: Perform tests

# Generated at 2022-06-25 07:57:17.724677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [ float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'

    # Testing if an exception is raised
    try:
        ActionModule(bool_0,int_0,float_0,list_0,bool_0,bytes_0)
    except Exception as exception:
        print(str(exception))

    # Testing if the type of the return value is dict
    test_dict = action_module_0.get_args_from_task_vars(int_0,bool_0)
    assert(type(test_dict) == dict)

# Generated at 2022-06-25 07:57:22.239229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    tmp = None
    task_vars = dict()
    var_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:57:30.313370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    var_1 = action_module_0.run(int_0)


# Generated at 2022-06-25 07:57:31.425182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = action_run(ActionModule())


# Generated at 2022-06-25 07:57:42.776337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args passed
    result = ActionModule().run()
    assert result['failed']
    assert '"argument_spec" arg is required in args' in result['msg']

    # Test with argument_spec not a dict
    result = ActionModule().run(argument_spec=['not a dict'])
    assert result['failed']
    assert 'Incorrect type for argument_spec' in result['msg']

    # Test with provided_arguments not a dict
    result = ActionModule().run(argument_spec={}, provided_arguments='not a dict')
    assert result['failed']
    assert 'Incorrect type for provided_arguments' in result['msg']

    # Test with a test arg spec, no args provided, and no task vars

# Generated at 2022-06-25 07:57:47.907144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    var_0 = action_module_0.run(int_0)
    assert isinstance(var_0, dict)
    assert var_0['failed'] == True
    assert isinstance(var_0['validate_args_context'], dict)
    assert var_0['validate_args_context'] == {}


# Generated at 2022-06-25 07:57:50.776102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    argument_spec = dict()
    provided_arguments = dict()
    tmp = None
    task_vars = None
    action_module = ActionModule(tmp, task_vars)
    action_module.run(tmp, task_vars)


# Generated at 2022-06-25 07:57:55.865013
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    var_0 = dict()
    var_1 = action_module_0.get_args_from_task_vars(var_0, var_0)
    assert isinstance(var_1, dict)
    assert var_1 == var_0


# Generated at 2022-06-25 07:58:23.382005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  str_0 = 'x\x15\x8c\x1d\x98\xc5\x9d\x112\xd6\xab\x99'
  str_1 = ' '
  bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
  bool_0 = True
  float_0 = 1000.0
  int_0 = -1288
  list_0 = [float_0, float_0, int_0]
  tmp_0 = None
  task_vars_0 = {str_0: bool_0, str_1: bool_0}
  action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)

# Generated at 2022-06-25 07:58:27.982779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    try:
        # Testing the actual run method
        action_module_0 = ActionModule(tmp, task_vars)
        var_0 = action_module_0.run()
        assert var_0 == None, "actual value: %s" % var_0
    except Exception as e:
        assert 'Test Failed!' == e.message


# Generated at 2022-06-25 07:58:34.833068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'

    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    assert action_module_0.result['msg'] == 'The arg spec validation passed'
    var_0 = action_run(int_0)
    assert action_module_0.result['msg'] == 'The arg spec validation passed'
    assert action_module_0.result['validate_args_context'] == {}


# Generated at 2022-06-25 07:58:44.434786
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:58:49.298714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)


# Generated at 2022-06-25 07:58:59.441887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        int_0 = 2403
        bool_0 = True
        float_0 = 697.3
        list_0 = [int_0, int_0, float_0]
        bytes_0 = b'P\xbd\xb5\x98\x8e\x92X\x08\xb8\xcc\xed\t\xc0\x85\xf1'
        action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
        if (not action_module_0):
            raise Exception('Cannot instantiate ActionModule')
    except Exception:
        print('FAIL')
    else:
        print('PASS')



# Generated at 2022-06-25 07:59:10.513857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    int_1 = -1288
    float_1 = 1000.0
    list_1 = [float_1, float_1, int_1]
    bytes_1 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'

# Generated at 2022-06-25 07:59:20.079323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)

# Unit test of method get_args_from_task_vars() of class ActionModule

# Generated at 2022-06-25 07:59:30.564226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # correct values
    correct_values = {'key_0': {'type': 'int', 'default': 1, 'required': False},
                      'key_1': {'type': 'str', 'default': 'hello world', 'required': True}}
    correct_provided_values = {'key_1': 'goodbye world'}

    action_module_0 = ActionModule(0, 1.0, correct_values, correct_provided_values)
    var_0 = action_run(0)

    # keys_0 is the keys of the argument specification so we can set the context
    keys_0 = [key for key in correct_values]
    action_module_0.run(correct_values, correct_provided_values, keys_0)
    assert(var_0['failed'] == False)

    # incorrect values
    incorrect_values

# Generated at 2022-06-25 07:59:37.274437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    tmp = None
    task_vars = dict()

    # Execute method (including asserts)
    run_result = ActionModule.run(bool_0, int_0, float_0, list_0, bool_0, bytes_0)

    # Make assertions
    assert run_result['changed'] == False
    assert run_result['msg'] == 'The arg spec validation passed'


# Generated at 2022-06-25 08:00:26.258693
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    argument_spec_0 = {}
    task_vars_0 = {}
    
    # Function loads the argument spec from the appropriate entry point for the given role.
    # The values are then passed in to the method to validate against.

# Generated at 2022-06-25 08:00:33.340182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    byte_0 = b'\xd2\x91(;\x86\x9d\xfd\xcc\x8e\xd5\x05\xe5\xbf\x8a\xfb\xf9\x1c\x90'
    var_0 = action_run(int_0)


# Generated at 2022-06-25 08:00:39.197361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1169
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'\n\x89\xe8\x01\xc7\x93\xb0\x8d\x18\xba\x9f\xe7U\xec\xa1\xa6'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)


# Generated at 2022-06-25 08:00:46.579364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: This test was generated from a template. Please add any missing tests or make changes to the template as needed.

    # This is a test for when the argument_spec arg is not present in args. It should throw a AnsibleError
    int_0 = 4
    bool_0 = bool()
    float_0 = 8.0
    list_0 = ['a']
    str_0 = str()
    str_1 = str()
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, str_0, str_1)
    try:
        action_module_0.run(str_0)
        assert False
    except AnsibleError:
        pass

    # This is a test for when the argument_spec arg is not a dict. It should throw a AnsibleError
    int

# Generated at 2022-06-25 08:00:51.689437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test for run of class ActionModule')
    if  not action_run(int_0) == str_0:
        print('Error for run of class ActionModule')
    else:
        print('ActionModule run test passed')


# Generated at 2022-06-25 08:00:58.735887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    var_0 = action_run(int_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:01:08.529558
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:01:16.530210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1095589132
    bool_0 = False
    float_0 = 965.9879
    str_0 = 'p\x8b:\xce\x04\xbd\x97\xca\x98\xb3\x9f\x8b\xde\xd7\x1a'
    list_0 = [int_0]
    bytes_0 = b'\x8c\xe4\xed\xeb\xecS\x0e\xe7\xfa\xc9\xd8\x83\x00\xdf'
    action_module_0 = ActionModule(int_0, list_0, int_0, float_0, bytes_0, list_0)
    var_0 = action_module_0.get_args_from_task_vars

# Generated at 2022-06-25 08:01:22.606817
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
    assert action_module_0 is not None, 'Failed to construct ActionModule.'


# Generated at 2022-06-25 08:01:27.880609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1288
    bool_0 = True
    float_0 = 1000.0
    list_0 = [float_0, float_0, int_0]
    bytes_0 = b'6\x94\x8b\xe7;U\xb6\xc2\xc11?D\x9cB'
    action_module_0 = ActionModule(bool_0, int_0, float_0, list_0, bool_0, bytes_0)
