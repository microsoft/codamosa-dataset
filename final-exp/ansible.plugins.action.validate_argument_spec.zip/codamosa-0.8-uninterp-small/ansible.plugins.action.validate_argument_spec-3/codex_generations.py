

# Generated at 2022-06-25 07:52:00.964757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    list_0 = [int_0, int_0]
    bool_0 = False
    str_0 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    bytes_0 = b'0t\x16`\xa4\x93\x1br'
    action_module_0 = ActionModule(int_0, list_0, bool_0, str_0, str_0, bytes_0)
    str_1 = '2\n        '
    tmp_0 = str_1
    dict_0 = {}
    result_0 = action_module_0.run(tmp_0, dict_0)
    # AssertionError: '\'validate_args_context\' arg is required

# Generated at 2022-06-25 07:52:04.331591
# Unit test for constructor of class ActionModule
def test_ActionModule():

    int_0 = None
    list_0 = [int_0, int_0]
    bool_0 = False
    str_0 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    bytes_0 = b'0t\x16`\xa4\x93\x1br'
    action_module_0 = ActionModule(int_0, list_0, bool_0, str_0, str_0, bytes_0)



# Generated at 2022-06-25 07:52:15.190961
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    str_0 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    bytes_0 = b'\x94\x14\xf6\x16\xc9\x9a\xcf\xbf\r\x00'

# Generated at 2022-06-25 07:52:21.059470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    list_0 = None
    bool_0 = False
    str_0 = None
    bytes_0 = None
    action_module_0 = ActionModule(int_0, list_0, bool_0, str_0, str_0, bytes_0)

    with pytest.raises(AnsibleError):
        action_module_0.run(int_0, list_0)


# Generated at 2022-06-25 07:52:28.087381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = None
    list_0 = [int_0, int_0]
    bool_0 = False
    str_0 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    bytes_0 = b'0t\x16`\xa4\x93\x1br'
    action_module_0 = ActionModule(int_0, list_0, bool_0, str_0, str_0, bytes_0)

    # test for get_args_from_task_vars
    int_1 = None
    list_1 = [int_0, int_0]
    bool_1 = False

# Generated at 2022-06-25 07:52:34.273270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = None
    list_1 = [int_1, int_1]
    bool_1 = True
    str_1 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    str_2 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    bytes_1 = b'1t\x16`\xa4\x93\x1br'
    action_module_1 = ActionModule(int_1, list_1, bool_1, str_1, str_2, bytes_1)
    int_2 = None
    list_2 = [int_2, int_2]
    bool_2 = False

# Generated at 2022-06-25 07:52:41.031928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    list_0 = []
    list_1 = []
    str_0 = 'Provided arguments do not match the argument specification'
    str_1 = 'argument_spec'
    str_2 = 'provided_arguments'

# Generated at 2022-06-25 07:52:50.118772
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    int_0 = None
    list_0 = [int_0, int_0]
    bool_0 = False
    str_0 = 'l3q<\xccHZ\xc9)'
    bytes_0 = b'\xea\xfd\xde\x0b\xb4\x1co\x9a'
    action_module_0 = ActionModule(int_0, list_0, bool_0, str_0, str_0, bytes_0)

    # Test if the method get_args_from_task_vars raises an exception
    # when an incorrect argument (int_0) is passed
    with pytest.raises(AnsibleError):
        action_module_0.get_args_from_task_vars(int_0, dict())

    # Test if the method get_args

# Generated at 2022-06-25 07:52:59.148357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = None
    list_0 = [int_0, int_0]
    bool_0 = False
    str_0 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    bytes_0 = b'0t\x16`\xa4\x93\x1br'
    action_module_0 = ActionModule(int_0, list_0, bool_0, str_0, str_0, bytes_0)

    # parameters: tmp, task_vars
    tmp = None
    dict_0 = {}
    task_vars = dict_0
    # method return type: action_result
    action_result_0 = action_module_0.run(tmp, task_vars)
    return action

# Generated at 2022-06-25 07:53:10.144750
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    int_0 = None
    list_0 = [int_0, int_0]
    bool_0 = False
    str_0 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    bytes_0 = b'0t\x16`\xa4\x93\x1br'
    action_module_2 = ActionModule(int_0, list_0, bool_0, str_0, str_0, bytes_0)

    dict_0 = dict()
    dict_0['__validate_experimental_args'] = str_0
    dict_0['system'] = str_0
    dict_0['name'] = str_0

    dict_1 = dict()
    dict_1['name'] = dict_

# Generated at 2022-06-25 07:53:21.667610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()

    def run(tmp, task_vars):
        ansible_facts = dict()

        if 'ansible_facts' in task_vars:
            ansible_facts.update(task_vars['ansible_facts'])

        ansible_facts['ansible_facts'] = ansible_facts

        return {'ansible_facts': ansible_facts}

    task_vars = dict()
    return run(tmp, task_vars)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:53:27.633451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if 0 == 1:
        print('Test for method run of class ActionModule')
        # Set up mock
        tmp = None
        task_vars = None
        action = ActionModule(tmp, task_vars)

        # Invoke method
        args = {
            'validate_args_context': {
                'entry_point': 'main',
                'role_name': 'test_role',
            },
        }
        result = action.run(tmp, task_vars, args)
        assert result['failed'] is True
        assert 'msg' in result
        assert 'provided_arguments' in result['msg']
        assert 'validate_args_context' in result


# Generated at 2022-06-25 07:53:38.366116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module = ActionModule()
  action_module._task = unittest.mock.MagicMock()
  action_module._task.args = unittest.mock.MagicMock()
  action_module._task.args.get = unittest.mock.MagicMock()
  action_module._task.args.get.return_value = 'scheme'
  action_module._task.args.get.return_value = '/etc/sysctl.conf'
  action_module._task.args.get.return_value = 'name'
  action_module._task.args.get.return_value = 'value'
  action_module._templar = unittest.mock.MagicMock()
  action_module._templar.template = unittest.mock.MagicMock()
 

# Generated at 2022-06-25 07:53:41.517752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-25 07:53:42.494458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    unit = ActionModule()


# Generated at 2022-06-25 07:53:54.109465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\n        Return the next available uid. If system=True, then\n        uid should be below of 500, if possible.\n        '
    bytes_0 = b'\x94\x14\xf6\x16\xc9\x9a\xcf\xbf\r\x00'

# Generated at 2022-06-25 07:53:55.331449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-25 07:53:57.649222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert isinstance(result, ActionModule)
    # Test that the correct type was assigned to the result.
    assert isinstance(result, ActionBase)


# Generated at 2022-06-25 07:53:58.425208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:54:08.983781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating an instance of class ActionBase
    obj = ActionBase()

    # Calling method run of ActionBase with parameters tmp='tmp2', task_vars='task_vars' and validating the result
    action_module = ActionModule()
    args = {'argument_spec': {'arg1': {'aliases': ['arg_1'], 'required': True, 'type': 'int'}}, 'provided_arguments': {'arg1': 'value_of_arg'}}
    result = action_module.run(None, args)


# Generated at 2022-06-25 07:54:15.576352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a_m_0 = ActionModule()
# No error should be raised
    a_m_0.run(task_vars={})



# Generated at 2022-06-25 07:54:26.762748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:54:29.927299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Simple test for the case where we just want to verify the method will run.
    # This test does not verify the results.
    action_module_0 = ActionModule()
    # Run the run method
    try:
        action_module_0.run()
    except Exception as e:
        # The run method should throw an error because we're passing in nothing
        assert "args" in str(e)


# Generated at 2022-06-25 07:54:39.252496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)
    assert action_module_0 != action_module_1
    assert action_module_0 is not action_module_1
    action_module_2 = ActionModule()
    assert isinstance(action_module_2, ActionModule)
    assert action_module_0 != action_module_2
    assert action_module_0 is not action_module_2
    action_module_3 = ActionModule()
    assert isinstance(action_module_3, ActionModule)
    assert action_module_0 != action_module_3
    assert action_module_0 is not action_module_3


# Generated at 2022-06-25 07:54:41.890541
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 != None, "Failed to constructor ActionModule."


# Generated at 2022-06-25 07:54:46.986633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0_run(tmp=None, task_vars=None)

    # tmp : Deprecated. Do not use
    tmp = None
    # task_vars : A dict of task variables
    task_vars = None
    test_case_0_run = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:54:57.736695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {
        "validate_args_context": {
            "error_on_missing_args": False,
            "for_role_entry_point_name": "Generic_Linux"
        },
        "argument_spec": {
            "key": {
                "type": "str"
            }
        },
        "provided_arguments": {
            "key": "value"
        }
    }
    action = ActionModule()
    res = action.run(task_vars=data)
    assert res.get('failed') == False
    assert res.get('msg') == 'The arg spec validation passed'
    assert res.get('changed') == False

# Generated at 2022-06-25 07:55:03.916799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except Exception as e:
        assert False, "constructor failed to initialize"
    assert isinstance(action_module_0, ActionModule), "object is not an instance of class ActionModule"

# Generated at 2022-06-25 07:55:11.846324
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    try:
        assert type(action_module_0) == ActionModule
    except AssertionError:
        raise AssertionError('Expected {}, got {}'.format(
            type(ActionModule), type(action_module_0)))

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:55:12.500471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()



# Generated at 2022-06-25 07:55:24.684805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module._task.args = {"argument_spec": {'f1': {'type': 'str'}, 'f2': {'type': 'list'}, 'f3': {'type': 'list'}}}
    action_module._task.args['provided_arguments'] = {'f1': 'f1'}
    action_module.run()
    assert action_module.run()['changed'] == False
    assert action_module.run()['msg'] == 'The arg spec validation passed'


# Generated at 2022-06-25 07:55:35.836657
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    # test for variable tmp to be of type <class 'NoneType'>
    assert type(action_module_1.tmp) == type(None)
    # test for variable task_vars of type <class 'NoneType'>
    assert type(action_module_1.task_vars) == type(None)
    # test for variable _connection of type NoneType
    assert type(action_module_1._connection) == type(None)
    # test for variable _play_context of type NoneType
    assert type(action_module_1._play_context) == type(None)
    # test for variable _loader of type NoneType
    assert type(action_module_1._loader) == type(None)
    # test for variable _templar of type NoneType

# Generated at 2022-06-25 07:55:39.129576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:55:46.818737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Monkeypatch in a simple ArgumentSpecValidator that returns a AnsibleValidationErrorMultiple
    # TODO: Move to the unit test module
    class MockArgumentSpecValidator(ArgumentSpecValidator):
        def __init__(self):
            pass

        def validate(self, args):
            class MockError(AnsibleValidationErrorMultiple):
                def __init__(self, error_messages):
                    self.error_messages = error_messages

            return MockError(['error 1', 'error 2'])

    test_case_0()
    ActionModule.ArgumentSpecValidator = MockArgumentSpecValidator

    # Create an action module object
    action_module = ActionModule()

    # Create a dummy argument spec
    argument_spec = {'foo': {'type': 'str'}}

    # Use the dummy

# Generated at 2022-06-25 07:55:50.751827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert (isinstance(action_module_1, ActionModule))

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:55:58.532731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_spec = {'argument_spec': {'a': {'type': 'int'}, 'b': {'type': 'int', 'required': True}}}
    task_vars = {'b': 1}
    # execute run()
    action_module_0 = ActionModule()
    action_module_0._task = MagicMock(ansible.plugins.action.ActionBase.Task)
    action_module_0._task.args = arg_spec
    action_module_0.run(task_vars=task_vars)
    assert 'The arg spec validation passed' in action_module_0.msg

# Generated at 2022-06-25 07:56:01.321855
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor')
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:56:11.616547
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock parameters:
    tmp = None

# Generated at 2022-06-25 07:56:18.415801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except AnsibleError as e:
        assert(str(e) != "")
    except Exception as e:
        print("Error occured while testing the constructor of class ActionModule")
        raise e



# Generated at 2022-06-25 07:56:20.657286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test 0: Constructor")
    action_module = ActionModule()


# Generated at 2022-06-25 07:56:36.785799
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    
    Testing for checking the action result and argument validation.
    '''


# Generated at 2022-06-25 07:56:38.287078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

    assert(action_module_1.TRANSFERS_FILES == False)


# Generated at 2022-06-25 07:56:39.788037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()  # constructor call of class ActionModule
    assert action_module_0 is not None


# Generated at 2022-06-25 07:56:46.914220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_vars = {'ansible_ssh_common_args': '-o ProxyCommand'}
    task_vars_0 = {'ansible_ssh_common_args': '-o ProxyCommand'}

# Generated at 2022-06-25 07:56:48.870892
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule) is True


# Generated at 2022-06-25 07:56:53.288067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Test with valid params.
    action_module_0.run(tmp=None, task_vars=None)
    # Test with missing params.
    with pytest.raises(AnsibleError) as err:
        action_module_0.run(tmp=None, task_vars=None)
    assert err.type == AnsibleError


# Generated at 2022-06-25 07:57:02.512327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_vars, test_args, test_kwargs
    test_vars = dict()
    test_args = dict(argument_spec=dict())
    test_kwargs = dict()

    template_keys = [
        'validate_args_context',
        'validate_argument_spec_context_1',
        'validate_argument_spec_context_2',
    ]
    template_keys_w_defaults = {
        'validate_args_context': {},
        'validate_argument_spec_context_1': {'foo': 'bar'},
        'validate_argument_spec_context_2': {'fizz': 'buzz'},
    }


# Generated at 2022-06-25 07:57:06.942952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = {"msg": "argument_spec arg is required in args: {\"validate_args_context\": {}, \"argument_spec\" : {}}", "failed": True}
    result_0 = action_module_0.run(tmp_0, task_vars_0)



# Generated at 2022-06-25 07:57:08.138955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:57:12.586134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    assert action_module_1 == action_module_2
    action_module_1.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:57:30.188650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -47
    list_0 = [int_0, int_0, int_0]
    str_0 = 'c%l<g[1(b4&~H9'
    str_1 = 'g#tM*r8V:W.2$'
    int_1 = 636
    bool_0 = False
    action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:57:30.794875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:57:41.473602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1465
    dict_0 = {int_0: int_0, int_0: int_0}
    int_1 = -3072
    list_0 = [int_1, int_1]
    list_1 = [int_1, list_0, list_0]
    str_0 = 'ZFt0pyxMBoaiw'
    int_2 = -2526
    bool_0 = False
    action_module_0 = ActionModule(int_1, list_1, str_0, str_0, int_2, bool_0)
    action_run(action_module_0, dict_0, list_0)


# --------------------------------------------------------------------------------------------------
# Helper code for test case methods

# Generated at 2022-06-25 07:57:48.460259
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3
    dict_0 = {int_0: int_0, int_0: int_0}
    int_1 = -4
    list_0 = [int_1, int_1]
    list_1 = [int_1, list_0, list_0]
    str_0 = 'NdiS5n.GU5sr5'
    int_2 = -2
    bool_0 = False
    action_module_0 = ActionModule(int_1, list_1, str_0, str_0, int_2, bool_0)
    var_0 = action_module_0.run(dict_0, list_0)

# Generated at 2022-06-25 07:57:57.139833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    vars = []
    str_0 = 'uYZg'
    int_0 = -1263
    float_0 = -2091.906682923
    str_1 = 'F:lC9E,.F.1'
    int_1 = 8405
    int_2 = -5752
    tuple_0 = (str_1, int_1, int_1, str_0, str_0, str_0)
    tuple_1 = (int_1, tuple_0, int_0, int_1)
    tuple_2 = (int_1, tuple_0, int_2, tuple_0, tuple_0, tuple_1)
    bool_0 = True

# Generated at 2022-06-25 07:58:04.812173
# Unit test for constructor of class ActionModule
def test_ActionModule():
  int_0 = -1811
  list_0 = [-1811, -1811]
  str_0 = 'y76m^Rk4)9B4Q#'
  str_1 = 'y76m^Rk4)9B4Q#'
  int_1 = -1238
  bool_0 = True
  action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)


# Generated at 2022-06-25 07:58:15.085300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -740
    int_1 = -237
    list_0 = [-624, 3506, 8217, -2661, -844, -2810]
    int_2 = -614616406
    str_0 = 's2dI'
    int_3 = -3264
    str_1 = '_-p'
    bool_0 = False
    action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)
    list_1 = [int_2, int_3]
    action_run(action_module_0, list_1, list_0)
    bool_1 = bool_0
    if (not bool_1):
        int_4 = -3

# Generated at 2022-06-25 07:58:22.570736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1908
    float_0 = 10.79
    str_0 = ']T'
    list_0 = [int_0, float_0]
    dict_0 = {str_0: list_0, str_0: list_0}
    str_1 = '_J9'
    int_1 = -3127
    float_1 = 7.38
    list_1 = [str_1, int_1]
    list_2 = [float_1, list_1, list_1]
    int_2 = -1408
    float_2 = 1.72
    action_module_0 = ActionModule(int_0, list_0, str_0, str_0, int_1, float_1)
    action_module_0.run(dict_0, list_2)



# Generated at 2022-06-25 07:58:29.365979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -107
    list_0 = [int_0, int_0]
    str_0 = '2dZWx5vG'
    str_1 = 'R'
    int_1 = -84
    bool_0 = True
    action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)

# Generated at 2022-06-25 07:58:35.770162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule(int_0, list_0, str_0, str_0, int_1, bool_0)
    int_3 = 0
    dict_1 = {'s': int_1, 'g': dict_0}
    dict_2 = {'h': list_1, 'c': dict_1}
    action_module_1.run(dict_0, dict_2)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:58:54.821217
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:59:00.776798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 3479
    dict_0 = {int_0: int_0, int_0: int_0}
    int_1 = -1224
    list_0 = [int_1, int_1]
    str_0 = 'RLxQvZSkJiWc'
    str_1 = 'rTwl'
    int_2 = -286
    bool_0 = True
    action_module_0 = ActionModule(int_1, dict_0, str_0, str_1, int_2, bool_0)
    action_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 07:59:10.643958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -144
    list_0 = [int_0, int_0, int_0, int_0]
    int_1 = -880
    str_0 = 'cxFCP.b4d_O0_K5y'
    str_1 = 'YXu.LY_A42_z5Vt'
    int_2 = -3787
    bool_0 = False
    action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_2, bool_0)
    assert action_module_0.action_exec_time is not None
    assert action_module_0.action_name == 'validate_argument_spec'
    assert action_module_0.action_results_meta is not None
    assert action_module_0.action_

# Generated at 2022-06-25 07:59:15.866360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 2
    list_0 = [int_0, int_0]
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dict_1 = {int_0: int_0, int_0: int_0, int_0: int_0}
    str_0 = 'IQuq3C5RC'
    str_1 = 'XS.Z.JpZ'
    int_1 = 9
    str_2 = 'adQFhJT-T'
    bool_0 = False
    action_module_0 = ActionModule(dict_1, dict_0, str_1, str_0, int_0, bool_0)
    dict_2 = dict_0

# Generated at 2022-06-25 07:59:22.846943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 484
    dict_0 = {int_0: int_0, int_0: int_0}
    int_1 = -2390
    list_0 = [int_1, int_1]
    list_1 = [int_1, list_0, list_0]
    str_0 = 'QrkcTjKHwixFgdn'
    int_2 = -288
    bool_0 = False
    action_module_0 = ActionModule(int_1, list_1, str_0, str_0, int_2, bool_0)


# Generated at 2022-06-25 07:59:30.325520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '66d8'
    str_1 = 'Lxks'
    str_2 = 'RBmO'
    bool_0 = False
    int_0 = -18243
    dict_0 = {str_0: str_0, str_1: str_0}
    dict_1 = {str_2: str_2, str_2: str_2}
    dict_2 = {str_2: str_2, str_2: str_2}

# Generated at 2022-06-25 07:59:39.842198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3464
    dict_0 = {int_0: int_0, int_0: int_0}
    int_1 = -1258
    list_0 = [int_1, int_1]
    list_1 = [int_1, list_0, list_0]
    str_0 = 'BuSad.3g_A6_q0W'
    int_2 = -290
    bool_0 = False
    action_module_0 = ActionModule(int_1, list_1, str_0, str_0, int_2, bool_0)
    assert isinstance(action_module_0, object)


# Generated at 2022-06-25 07:59:44.929862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -5822
    list_0 = [-7647, -7647, 16758]
    str_0 = 'K_&r.z)0kB'
    str_1 = 'K_&r.z)0kB'
    int_1 = 100
    bool_0 = True
    action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)
    assert True


# Generated at 2022-06-25 07:59:51.370253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3464
    dict_0 = {int_0: int_0, int_0: int_0}
    int_1 = -1258
    list_0 = [int_1, int_1]
    list_1 = [int_1, list_0, list_0]
    str_0 = 'BuSad.3g_A6_q0W'
    int_2 = -290
    bool_0 = False
    action_module_0 = ActionModule(int_1, list_1, str_0, str_0, int_2, bool_0)
    assert type(action_module_0) == type(ActionModule(int_1, list_1, str_0, str_0, int_2, bool_0))


# Generated at 2022-06-25 07:59:59.468979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['validate_args_context'] = dict()

    dict_1 = dict()
    dict_1['key'] = 'value'

    dict_2 = dict()
    dict_2['validate_args_context'] = dict_1

    dict_3 = dict()
    dict_3['argument_spec'] = dict()
    dict_3['provided_arguments'] = dict()

    dict_4 = dict()
    dict_4['validate_args_context'] = dict_1
    dict_4['msg'] = 'The arg spec validation passed'
    dict_4['changed'] = False

    dict_5 = dict()
    dict_5['validate_args_context'] = dict_1

# Generated at 2022-06-25 08:00:53.050887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_1 = -1258
    list_0 = [int_1, int_1]
    str_0 = 'BuSad.3g_A6_q0W'
    int_2 = -290
    bool_0 = False
    action_module_0 = ActionModule(int_1, list_0, str_0, str_0, int_2, bool_0)


# Generated at 2022-06-25 08:00:56.741679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The output of the following line is a false positive that the constructor is used.
    # TODO: Write an assertion to assert that the constructor is called when it should be.
    action_module_0 = ActionModule()
    
    # When this test is run, above line will throw an exception if the constructor is called.
    assert(False)

# Generated at 2022-06-25 08:01:01.533937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 4073
    list_0 = [int_0]
    str_0 = 's0s_'
    str_1 = 'KVsl_O2oX9'
    int_1 = -2919
    bool_0 = True
    action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)
    assert action_module_0._task.args.get('provided_arguments') is not None
    assert action_module_0._filename is not None
    assert type(action_module_0._task) is Task
    assert action_module_0._task_vars is not None
    assert action_module_0._loader is not None
    assert action_module_0._play_context is not None
    assert action_module

# Generated at 2022-06-25 08:01:05.643072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1493
    list_0 = [int_0, int_0, int_0, int_0]
    str_0 = 'Od[N#}N1-UYA%sU9'
    int_1 = -206
    str_1 = '1RQh1m!WbVG'
    int_2 = -2
    bool_0 = False
    action_module_0 = ActionModule(list_0, str_0, int_1, str_1, int_2, bool_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 08:01:09.771681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 959
    dict_0 = {int_0: int_0, int_0: int_0}
    int_1 = 183
    list_0 = [int_1, int_1]
    str_0 = 'M9q3TwTz1_Qa1jKZ'
    int_2 = -2921
    bool_0 = True
    action_module_0 = ActionModule(int_1, list_0, str_0, str_0, int_2, bool_0)
    result_0 = action_module_0.run(dict_0, list_0)


# Generated at 2022-06-25 08:01:19.996169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 841
    list_0 = [-1268891341, -1268891341]
    str_0 = 'qy_URi_8W_RUj'
    str_1 = 'vH8WJz'
    int_1 = 8467
    bool_0 = True
    action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)
    tmp = None
    task_vars = {'nc'}
    action_result_dict_0 = action_module_0.run(tmp, task_vars)
    var_0 = list_0.append({'c'})
    var_1 = list_0.append({'t'})
    list_1 = [task_vars]
   

# Generated at 2022-06-25 08:01:29.220199
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    generated_validate_args_context = {'role name': 'foo_role', 'entry_point': 'main'}

    # The argument spec for the role, which is used in the test cases for
    # the various test cases
    argument_spec = {
        'foo': {
            'required': True,
            'type': 'str',
        },
        'bar': {
            'required': False,
            'type': 'int'
        },
        'baz': {
            'required': True,
            'type': 'str',
        }
    }

    provided_arguments_tasks_vars = {
        'bar': 5,
        'foo': 'hello'
    }

    # Test case where the argument spec is not a dict

# Generated at 2022-06-25 08:01:36.039148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1112
    int_1 = -3049
    int_2 = 4109
    dict_0 = {int_1: int_2, int_2: int_2}
    dict_1 = {int_1: int_1, int_2: int_0}
    str_0 = 'zXV.a.&{O7V)%`y'
    str_1 = 'i=xg(<5/3qXA|(['
    int_3 = -6644
    bool_0 = False
    action_module_0 = ActionModule(int_1, dict_0, str_0, str_1, int_3, bool_0)

# Generated at 2022-06-25 08:01:41.375454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -3989
    list_0 = [-8, -8, -8]
    str_0 = '1lJoBweK@p^619F'
    str_1 = '1lJoBweK@p^619F'
    int_1 = 228
    bool_0 = False
    var_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)
    assert True


# Generated at 2022-06-25 08:01:44.865139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1298
    list_0 = [int_0, int_0]
    str_0 = '4Kmb'
    str_1 = '5Y5S_+B'
    int_1 = -1091
    bool_0 = False
    action_module_0 = ActionModule(int_0, list_0, str_0, str_1, int_1, bool_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
