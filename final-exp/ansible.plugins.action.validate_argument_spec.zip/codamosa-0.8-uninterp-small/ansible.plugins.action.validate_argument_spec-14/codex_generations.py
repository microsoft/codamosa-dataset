

# Generated at 2022-06-25 07:52:03.604886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:52:15.603466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True

# Generated at 2022-06-25 07:52:17.111261
# Unit test for constructor of class ActionModule
def test_ActionModule():
	action_module = ActionModule(None, False, False, "", b'\xb1\xa5[\x95E', b'M\xc9\x01@\xbcL*\xf2')


# Generated at 2022-06-25 07:52:19.701259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.get_args_from_task_vars(dict(), dict()) is not None
    assert action_module_0.run() is not None

# Generated at 2022-06-25 07:52:27.106145
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = '\xfa\x81pr\x95\x9e,\x84\xe2\xc2\xf7\xaf\x12o\x89\xa8h\x85\x9a'
    bytes_0 = b'\xca\x1c\xdd\x0c\xa6\x9aAK\x01'
    bytes_1 = b'\xa6\x95\x1c\x8a\xa7\x93\x17'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_0, bytes_1)
    tmp_0 = None
    task_vars_0 = dict()
    task_vars_0['argument_spec'] = dict()
   

# Generated at 2022-06-25 07:52:33.945898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'R>j$am.}NnC_t7el'
    bytes_0 = b'\xb1\xa5[\x95E'
    bytes_1 = b'M\xc9\x01@\xbcL*\xf2'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_0, bytes_1)


# Generated at 2022-06-25 07:52:40.741781
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test with arg[0] of type dict.
    action_module_1 = ActionModule()
    tmp_0 = {}
    task_vars_0 = {}
    result_0 = action_module_1.run(tmp_0, task_vars_0)
    assert result_0['validate_args_context'] == {}, 'Argument of ActionModule.run failed validation'
    assert result_0['failed'] == True, 'Argument of ActionModule.run failed validation'
    assert result_0['msg'] == '"argument_spec" arg is required in args: {}', 'Argument of ActionModule.run failed validation'
    assert result_0['argument_spec_data'] == None, 'Argument of ActionModule.run failed validation'

# Generated at 2022-06-25 07:52:47.941024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = '`t0G0fj'
    bytes_0 = b'\xb9u\xa0\x98\x90T\xce\xdd\x92\x8e]|\x9b\x97\x9e\xcc\xbe\xb2\xdf\x84\xec\x9b\xd9\x94\x99\x8d\xde\x82\xc3\xfa\x8e\xd9\xbd\xa9\xc2\xd8\x82\xce\xc5\x97\x98\xce\xe5\x9d\x93'

# Generated at 2022-06-25 07:52:57.257996
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '\x85\x1d'
    bytes_0 = b'\x8b\x84\xf6\x96\xcd\x8a\x9b\x0b\xba\x88'
    bytes_1 = b'\x7f\x91o\xdc\x9b\x1d"\xb6'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_0, bytes_1)
    assert(action_module_0._shared_loader_obj._module_manager is not None)
    assert(action_module_0._task._task is not None)
    assert(action_module_0._connection.buf is not None)

# Generated at 2022-06-25 07:53:05.460535
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class "ActionModule" on variable "action_module_0"
    bool_0 = True
    str_0 = 'jwL2'
    bytes_0 = b'\xa3\xf2\x0e\x91\x05\xaa\x88\xee\xfa\x96\xe9\x05\x8b\xbf\x82\x1c\x82g\x90\xad\x8a\x17\xaf\x16\x0e\x8c\xc2\xcd(r\xe1'

# Generated at 2022-06-25 07:53:22.461204
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:53:23.616825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:53:32.872857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=task_0)
    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module, object)
    assert action_module.task == task_0
    assert action_module.task.action == 'arg_spec_validator'
    assert action_module.task.args['validate_args_context'] == module_0.__name__
    assert action_module.task.async_val == None
    assert action_module.task.delegate_to == None
    assert action_module.task.become == None
    assert action_module.task.become_user == None
    assert action_module.task.become_method == None
    assert action_module.task.become_flags == ''
    assert action_module.task.become_pass == None

# Generated at 2022-06-25 07:53:39.497578
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.validate_arguments

    t = ansible.plugins.action.validate_arguments.ActionModule()
    task_vars = dict()

    try:
        t.run()
    except Exception as e:
        print(e)
        assert type(e) == AnsibleError

    assert t.run(task_vars=task_vars)


# Generated at 2022-06-25 07:53:40.425408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True


# Generated at 2022-06-25 07:53:44.087929
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Parameters
    tmp = None
    task_vars = dict() 

    with pytest.raises(AnsibleError) as exception_info:
        (ActionModule.run(None, tmp, task_vars))
    with pytest.raises(AnsibleError) as exception_info:
        (ActionModule.run(None, tmp, task_vars))
    with pytest.raises(AnsibleError) as exception_info:
        (ActionModule.run(None, tmp, task_vars))

# Generated at 2022-06-25 07:53:46.011079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bool_1 = True
    bool_2 = True
    bool_3 = True

# Generated at 2022-06-25 07:53:52.397869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = True
    action_base_0 = ActionBase()
    str_0 = 'foo'
    str_1 = 'foo'
    dict_0 = {}
    action_module_0 = ActionModule(bool_0, action_base_0, str_0, str_1, dict_0, dict_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:53:54.319495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_result = 'test_result'
    test_result = ActionModule()
    assert(test_result)


# Generated at 2022-06-25 07:53:58.582109
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Testcase 1
    print('Test case 1')

    # Setup
    task_vars_1 = {}
    task_vars_1['validate_args_context'] = {
        'path': './ansible/roles/test_role/meta/main.yml',
        'name': 'test_role',
        'entry_point_role_name': 'test_role'
    }
    task_vars_1['argument_spec'] = {
        'test_argument': {
            'type': 'bool',
            'default': False,
            'required': False,
            'options': [True, False]
        }
    }
    task_vars_1['provided_arguments'] = {
        'test_argument': True
    }

    # Function call
    #Method __init__ of

# Generated at 2022-06-25 07:54:10.776091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n\nTEST 1: BEGIN\n")
    print("ActionModule.run\n")
    obj = ActionModule(dict(), dict())
    argument_spec = dict()
    argument_spec['argument_spec'] = dict()
    argument_spec['provided_arguments'] = dict()
    argument_spec['validate_args_context'] = dict()
    # dict1 = dict()
    # dict1['key'] = 'value'
    # dict1['key1'] = 'value1'
    print("Expected error")
    print("AnsibleError: 'argument_spec' arg is required in args: {}")
    try:
        obj.run(None, argument_spec)
    except AnsibleError as e:
        print("Got exception")
        print(str(e))


# Generated at 2022-06-25 07:54:22.399172
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:54:32.099544
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    """Test method get_args_from_task_vars of  class ActionModule"""
    arg0 = ActionModule(argument_spec=None, bypass_checks=None, check_invalid_arguments=None, _task=None, _connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    arg1 = dict()
    arg2 = dict()
    try:
        arg0.get_args_from_task_vars(arg1, arg2)
        test_case_0()
    except Exception as e:
        print('Exception from test: %s' % e)
    finally:
        arg0 = None
        arg1 = None
        arg2 = None


# Generated at 2022-06-25 07:54:36.240796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    a = ActionModule()

    if test_case_0():
        tmp = None
        task_vars = None
        result = a.run(tmp, task_vars)
        assert(result is not None)


if __name__ == '__main__':
    #for test_case in [test_ActionModule_run]:
    #    test_case()
    test_case_0()

# Generated at 2022-06-25 07:54:43.510946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict()
    connection = 'local'
    tmp = None
    task_vars = dict()

    test_obj = ActionModule()
    result = test_obj.run(tmp, task_vars)
    assert result['failed'] == 'True'
    assert result['msg'] == '"argument_spec" arg is required in args: {}'


# Generated at 2022-06-25 07:54:48.542594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.validation import check_argument_types
    MockActionModule = type('MockActionModule', (object,), {'run': ActionModule.run, '_templar': None})
    Mock = type('Mock', (object,), {})
    module = ActionModule()
    action = MockActionModule()
    module._connection = Mock()
    action.connection = Mock()
    module._task = Mock()
    action._task = Mock()
    module._loader = Mock()
    action._loader = Mock()
    module._templar = Mock()
    action._templar = Mock()
    module._shared_loader_obj = None
    action._shared_loader_obj = None
    module._task_vars = {}
    action._task_vars = {}
    module._play_

# Generated at 2022-06-25 07:54:55.285701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    # Create an instance of the ActionModule class
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Provision the params to return a value for the test case
    obj.return_values['run'] = {
        'failed': False,
        'changed': True,
        'msg': 'The arg spec validation passed',
        'validate_args_context': dict(),
        'argument_spec_data': dict(),
        'argument_errors': ['a', 'b']
        }

    return_value_run = obj.run(tmp=tmp, task_vars=task_vars)

    # Perform test case validations

# Generated at 2022-06-25 07:55:01.312938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    action_module = ActionModule()
    result = action_module.run(tmp, task_vars)
    assert result['failed'] == None
    assert result['changed'] == None
    assert result['msg'] == None
    assert result['validate_args_context'] == dict()
    assert result['argument_spec_data'] == dict()
    assert result['argument_errors'] == list()

# Generated at 2022-06-25 07:55:08.264385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_jsonarg
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_str


# Generated at 2022-06-25 07:55:17.234836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile
    tempfile.TemporaryDirectory()

    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.six import string_types
    import pytest
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.utils.vars import combine_vars

    # No need to use this fake vars when we are using test fixtures
    #task_vars = dict(
    #    first_key='first_value',
    #    second_key='second_value',
    #)

    action_module = ActionModule()
    action_module.action_loader = pytest.helpers.ActionLoader()

# Generated at 2022-06-25 07:55:33.321743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    bool_0 = True
    str_0 = 'pJM0D\xed'
    bytes_1 = b'\xd9\x01'
    bytes_2 = b'\x06\x0b'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)
    assert action_module_0.static is False


# Generated at 2022-06-25 07:55:35.583074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:55:40.644890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_1 = dict()
    var_0 = ActionModule(dict_0, dict_1)
    dict_2 = dict()
    bool_0 = True
    dict_3 = dict()
    var_0.run(dict_2, dict_3)

# Generated at 2022-06-25 07:55:47.525068
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bytes_0 = b''
  bool_0 = True
  str_0 = 'd\x8d\xda\xefL\x04\xc6\x9a9\x93\xe1\xcd\xbe\xbf"\x1e\x01\x7f\x8f2'
  bytes_1 = b'\xad\x89\x1f\x01\xdbc\x13\xce\xd6\xef\xf4\xd7'
  bytes_2 = b'\xcb\x88\x08D\x9a'

# Generated at 2022-06-25 07:55:49.376765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass  # TODO


# Generated at 2022-06-25 07:55:59.117153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'a\x97\xf8$\xfd\x8f\x05\xd7\xc5O\x1ao\x0e'
    bool_0 = True
    bool_1 = True
    str_1 = '\x16\xa7\x8b\xac\xa6\x9b4\x1e\xbe\x0c\xc0\x7f\xca\xad\xfa\xb9L'
    bytes_0 = b'E\xae'
    bytes_1 = b'\x02\xd1\xcf+\x8a\x84\xde\xbb\xed\xd2\x06\xa7M'

# Generated at 2022-06-25 07:56:04.854804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: None of these tests actually test the run method or any other method.
    # They should be removed or rewritten.
    task_vars = dict(argument_spec=dict(), provided_arguments=dict())
    tmp = 'tmp'
    result = {}
    assert isinstance(result, dict)
    assert len(result) == 1


# Generated at 2022-06-25 07:56:13.922806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # A dict of task variables.
    task_vars = dict()

    dict_0 = dict()
    dict_0['k1'] = 'v1'

    dict_1 = dict()
    dict_1['k3'] = 'v3'

    dict_2 = dict()
    dict_2['k2'] = 'v2'

    dict_3 = dict()
    dict_3['k2'] = 'v2'

    dict_4 = dict()
    dict_4['k1'] = 'v1'

    dict_5 = dict()
    dict_5['k3'] = 'v3'

    ActionModule(dict_0, dict_1, dict_2, dict_3, dict_4, dict_5)
    # Return a dict
    dict_4 = dict()

# Generated at 2022-06-25 07:56:20.779717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x07n\xbe\xae'
    bool_0 = True
    bool_1 = True
    str_0 = '\xeb\xae\tS\x18\x99\x1e\x1c'
    bytes_1 = b'\x9a\xad\x9f\x1c\x8f\xb3\x80\x85\x8d\x90\x9f\x9f\x96\x86\xaaM\x86\xb3\x86\xc3\x83\x92\x9d\xb4\xe1\xe4\x80\xb4\x8b\x96\x9d\x9f\xab\x8f\xb3\x80\x85'

# Generated at 2022-06-25 07:56:26.112896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with a valid arg spec and valid module arguments.
    test_case_0()

    # Test with an invalid arg spec.
    # test_case_1()

    # Test with a valid arg spec and invalid module arguments.
    # test_case_2()

    # Test with an invalid arg spec and invalid module arguments.
    # test_case_3()

# Generated at 2022-06-25 07:56:53.116479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xab\x1d\xfd\x12\xfa\x14\x1d\xc2\xe2\xf8\xdf\x81\xed\xff`\x86\x9e'
    bool_0 = True
    bool_1 = True
    str_0 = 'pi&"\xaf\xd5\xc7\xad\xa8\xdd\xce\xbc\xb21'
    bytes_1 = b'.\xdd\xc9Xf\x0f\x1a\xf3\xae\x87\xaa\xef\xf3'
    bytes_2 = b'\x99\xd2\xde\x08\xca\x8e\xe1\xd7\x10'

# Generated at 2022-06-25 07:57:01.724430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x16\xae'
    bool_0 = True
    bool_1 = True
    str_0 = '^1D\xfc\xa1\x1f\x82\x95\xd5\xec\xae\x8e\xcc\x1e'
    bytes_1 = b'\xf0\x1d\x9f\x8e'
    bytes_2 = b'\xdc\x8a#\x82\xbb0\xb9'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_1, str_0, bytes_1, bytes_2)

# Generated at 2022-06-25 07:57:08.684677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    bool_0 = True
    str_0 = '|/L-xI\x1d\xa9N'
    bytes_1 = b'\xb3\x11\xe8\x0e\x1dT\xe9'
    bytes_2 = b'\xa2\x05\xdbw\x8d'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)
    var_0 = action_run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:57:11.872718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    action_module = ActionModule(task_vars, tmp)
    action_module.run()


# Generated at 2022-06-25 07:57:20.245960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'e\'I'
    bytes_0 = b'\x80\xca\x0e\xb8\x92\xf7\x02\xbb\x1f'
    dict_0 = {}
    dict_1 = {}
    dict_1['foo'] = 'bar'
    dict_1['baz'] = 'qux'
    dict_1['this'] = 'that'
    dict_0['dict_1'] = dict_1
    dict_1 = {}
    dict_1['abc'] = 'def'
    dict_1['ghi'] = 'jkl'
    dict_0['dict_2'] = dict_1
    action_module_0 = ActionModule(str_0, bool_0, bool_0, bool_0, bool_0, bool_0)
    var

# Generated at 2022-06-25 07:57:31.695894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xf0\x88\x08\x80'
    bool_0 = True
    bool_1 = False
    str_0 = '\x8e#\x96`\xca\xca'
    bytes_1 = b'\xd0\xab&\x8b\x97'
    bytes_2 = b'~\x98\xe9\xb9b\x95e'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_1, str_0, bytes_1, bytes_2)
    bytes_3 = b'\x14\x96\xee\xe1\xef'
    bool_2 = True
    str_1 = '\x80\x0f\xcf\xa9+\x9c|'
   

# Generated at 2022-06-25 07:57:43.165249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1e\xb8\xec\xac\xfe\xf5\xb6\xe0\x9a'
    bool_0 = False
    bool_1 = True
    str_0 = '\x03\xda\xd9\x17\xda\xd0\xca\x1c\xd1\x12\x03\xd2\xd9\x16\xda\xd0\xca\x1c\xd1\x12'
    bytes_1 = b"\x14\xde\x97\x91\x9b\x95\x90"
    bytes_2 = b',\xde\x97\x91\x9b\x95\x90'

# Generated at 2022-06-25 07:57:48.826121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_3 = b"5@\xef"
    bool_1 = False
    bool_2 = True
    str_1 = 'D\x87\xff'
    bytes_4 = b'\x11\xd6'
    bytes_5 = b'\xbc\x07\xbc\xda'
    action_module_1 = ActionModule(bytes_3, bool_1, bool_2, str_1, bytes_4, bytes_5)
    var_0 = action_module_1.run()


# Generated at 2022-06-25 07:57:57.196340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    bool_0 = True
    str_0 = '\x8b\x8b\x9d\x9e\xaf\xa8\x8b\x81\x96\x8b'
    bytes_1 = b'\x9d\x96\x8b\x9d\x90\x8b\x8b\x9c\x9d\x81'
    bytes_2 = b'\xad\x96\x8b\x96\x9d\x9c\x8b\x90\x81\x9d'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)
    var_0 = action_run()

# Generated at 2022-06-25 07:58:07.023626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'a{6\x9d|\x9e\xa6\x87\x85'
    str_1 = '6'
    str_2 = '`j\xe0>\x02\xc2\xbf\x8e\x00\x03\x01\r\n\x12\x1c\x1d\x1e\x1f\x04\x14\t\x05\x95/\x07\t\x06\xa3\x8b+\xfcN\xf0\xfa\xd1\x9d\xb5\xc7\xfa\xa4\x89\xb0v\x87\xa6/\xf6\x9d\x9cN$\xc7,'

# Generated at 2022-06-25 07:58:56.468142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    bool_0 = True
    str_0 = '"ITi|W8'
    bytes_1 = b'i\x82'
    bytes_2 = b'\x98\xc5\xca\x1f\x07m'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)

    dict_0 = dict()
    dict_0['validate_args_context'] = {
        'module_name': 'foo',
        'role_similarity': 0.1
    }
    dict_0['failed'] = True
    dict_0['msg'] = 'Validation of arguments failed:\n{0}\n'.format(dict_0['argument_errors'])

    dict_1 = dict

# Generated at 2022-06-25 07:59:02.945724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'test'
    bool_0 = False
    bool_1 = True
    str_0 = 'test'
    bytes_1 = b'\x9f\x8b*\xe6_'
    bytes_2 = b'8\xbc\x16\xc5\x9a\xe8'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_1, str_0, bytes_1, bytes_2)
    var_0 = action_module_0.run(None, None)
    if (var_0.get('failed')):
        raise 'AnsibleError: test'

# Generated at 2022-06-25 07:59:09.451629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    bool_0 = True
    str_0 = '7l\x9bF&p\xb0k\xed'
    bytes_1 = b'\x0c\x0e\x92\xda'
    bytes_2 = b'\x90\xb8\x15\xff\x03\x07\x0e\x1c'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)
    var_0 = action_run()


# Generated at 2022-06-25 07:59:19.044372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    bool_0 = True
    str_0 = 'A'
    bytes_1 = b'\x11e'
    bytes_2 = b'r|\xc1\xdc\x81k'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)
    action_module_0.run()

# End of generated test cases.

# Generated at 2022-06-25 07:59:20.918763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:59:30.611298
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:59:40.974427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of the class
    bytes_0 = b''
    bool_0 = True
    str_0 = '!\x9d\x1a\x89\xe0'
    bytes_1 = b'\t\xb2\x82\x9c\xe1\xd1\x97\xdb\xab\x86'
    bytes_2 = b'\x1b\x9d\x87\xc3\x81\x1fE\xad\x0e'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)

    # Return type assertion
    assert isinstance(action_module_0, ActionModule)

    # Return value assertion
    assert action_module_0 is not None

#

# Generated at 2022-06-25 07:59:49.026303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x1dI\x14\x89\xc2'
    bool_0 = True
    bool_1 = True
    str_0 = '/u\x1b\x885\xc7\x8c\xda\x99\x1d\x12\xe6'
    bytes_1 = b''
    bytes_2 = b'C\x17\x1a\xed\x8f\xd1\xb0\x89\xb6\xcd\x80'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_1, str_0, bytes_1, bytes_2)
    dict_0 = dict()
    var_0 = action_module_0.run(dict_0)

# Generated at 2022-06-25 07:59:55.234289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    bytes_0 = b''
    bool_0 = True
    str_0 = 'N}W8V0Hw^@1%QY\\'
    bytes_1 = b'Om\xbd\x99\x1f\x14\x0c'
    bytes_2 = b'\x1b\xd4\x01\x88\x8a\x90'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)
    var_0 = {'an argument_spec': 'dict'}
    action_module_0._task = Mock(**{'args': {'argument_spec': var_0}})
    # Setting up mock

# Generated at 2022-06-25 08:00:04.490548
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bytes_0 = b''
    bool_0 = True
    str_0 = 'JdBo\\wt+Pp'
    bytes_1 = b'\x89\x1e\x9c\xaf\xc4\xd0\xe8\x90\xad\xad\xb9\xfe'

# Generated at 2022-06-25 08:01:42.990509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up context variable
    bytes_0 = b''
    bool_0 = True
    str_0 = 'R>j$am.}NnC_t7el'
    bytes_1 = b'\xb1\xa5[\x95E'
    bytes_2 = b'M\xc9\x01@\xbcL*\xf2'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)
    tmp = None
    task_vars = None

# Generated at 2022-06-25 08:01:47.063743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, type)



# Generated at 2022-06-25 08:01:54.556731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    bool_0 = True
    str_0 = 'R>j$am.}NnC_t7el'
    bytes_1 = b'\xb1\xa5[\x95E'
    bytes_2 = b'M\xc9\x01@\xbcL*\xf2'
    action_module_0 = ActionModule(bytes_0, bool_0, bool_0, str_0, bytes_1, bytes_2)
    var_1 = None
    var_2 = {}
    var_3 = action_module_0.run(var_1, var_2)
    assert var_3
