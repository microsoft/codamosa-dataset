

# Generated at 2022-06-25 07:52:00.607520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict

    action_module_1 = ActionModule(b'', b'', b'', set(), ImmutableDict(), None)
    result = action_module_1.run()
    assert result == {'argument_spec_data': {}, 'argument_errors': ['A required argument was not supplied'], 'changed': False, 'failed': True, 'msg': 'Validation of arguments failed:\nA required argument was not supplied', 'validate_args_context': {}}


# Generated at 2022-06-25 07:52:05.342047
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bytes_0 = b'}X'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    complex_0 = None
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, set_0, dict_0, complex_0)
    argument_spec_0 = dict_0
    task_vars_0 = dict_0
    get_args_from_task_vars_1 = action_module_0.get_args_from_task_vars(argument_spec_0, task_vars_0)
    print("get_args_from_task_vars_1 =", get_args_from_task_vars_1)

# Generated at 2022-06-25 07:52:10.949453
# Unit test for constructor of class ActionModule
def test_ActionModule():

    def do_test(tmp, task_vars):
        result_0 = action_module_0.run(tmp, task_vars)
        if result_0.failed:
            raise AnsibleError(result_0.msg)




# Generated at 2022-06-25 07:52:12.837903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = action_module_0
    assert type(action_module) is ActionModule
    # TODO: Make better tests
    assert True


# Generated at 2022-06-25 07:52:17.946094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    # Testing with undefined parameter tmp
    # Testing with undefined parameter task_vars
    action_module_0 = ActionModule(tmp, task_vars)
    test_case_0()

# Generated at 2022-06-25 07:52:19.591292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate a ActionModule object
    # Run method and test return values and side effects
    pass

# Generated at 2022-06-25 07:52:26.990247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    input_0 = {'argument_spec': {
        'choice_0': {
            'type': 'str',
            'choices': ['choice_0', 'choice_1', 'choice_2', 'choice_3']
        },
        'choice_1': {
            'type': 'str',
            'choices': ['choice_0', 'choice_1']
        },
        'choice_3': {
            'type': 'str',
            'choices': ['choice_1', 'choice_2', 'choice_3', 'choice_0']
        }
    }, 'provided_arguments': {
        'choice_0': 'choice_1',
        'choice_1': 'choice_2',
        'choice_3': 'choice_3'
    }}

# Generated at 2022-06-25 07:52:37.139559
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:52:46.985737
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bytes_0 = b'\x07E\x90\xeb\x14\xe7\xf6U\xce\x12\xb3\x87\xb8\xed\x94\xf2\xac'
    set_0 = {bytes_0, bytes_0, bytes_0}
    dict_0 = {bytes_0: set_0}
    complex_0 = None
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, set_0, dict_0, complex_0)

    bytes_1 = b'\x07E\x90\xeb\x14\xe7\xf6U\xce\x12\xb3\x87\xb8\xed\x94\xf2\xac'

# Generated at 2022-06-25 07:52:58.037998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Initialize needed object attributes
    boolean_0 = True
    boolean_1 = False
    string_0 = 'yRFUzY'
    string_1 = 'OEOTd0'
    string_2 = 'w1O3Hg'
    string_3 = 'V7OuRx'
    string_4 = 'q3qGR1'
    string_5 = 'YGzxQ2'

# Generated at 2022-06-25 07:53:10.007429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'se'
    bytes_1 = b'dX'
    bytes_2 = b'_t'
    bytes_3 = b'\x89\x8a\x0c'
    int_0 = 1
    bytes_4 = b'_a\x84\x89\x8a\x0c'
    int_1 = 0
    bytes_5 = b'lid\x0c'
    bytes_6 = b'in\x02\x89\x8a\x0c'
    bytes_7 = b'ar\x8a'
    bytes_8 = b'te\x89'
    bytes_9 = b'me'
    bytes_10 = b'8a'
    bytes_11 = b'cu'

# Generated at 2022-06-25 07:53:22.461247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_0 = ActionModule(b'', b'', b'', {}, {}, {})
  var_0 = b'}X'
  var_1 = b'=`/'
  var_2 = {}
  var_3 = {}
  var_4 = {}
  var_5 = {}
  var_6 = {}
  var_7 = {}
  var_8 = {}
  var_9 = {}
  var_10 = {}
  var_11 = {}
  var_12 = {}
  var_13 = {}
  var_14 = {}
  var_15 = {}
  var_16 = {}
  var_17 = {}
  var_18 = {}
  var_19 = {}
  var_20 = {}
  var_21 = {}
  var_22 = {}
  var_

# Generated at 2022-06-25 07:53:32.284841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_2 = b'-\x1eW8Y'
    bytes_3 = b'\x17\x7f\x80\xed\xef\xf9\x8b\x1d\xab\xd2'
    bytes_4 = b'\xba\xa0Z\xb9\x8c\x12\xea\xef\xfd\x8e\x0fL\xb9\xa1W\xe8\xcc\xeb'

# Generated at 2022-06-25 07:53:36.115991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run()

if (__name__ == '__main__'):
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:53:43.651877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_0 = AnsibleError()
    ansible_1 = AnsibleError()
    action_module_0 = ActionModule(ansible_0, ansible_1, ansible_0, ansible_0, ansible_0, ansible_1)
    ansible_0.run(ansible_0, ansible_0)


# Generated at 2022-06-25 07:53:51.018453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {}
    setattr(module_args, 'argument_spec', {})
    setattr(module_args, 'provided_arguments', {})
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:53:56.844064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'q'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    action_module_0.run(bytes_0, bytes_0)
    var_0 = bytes_1
    var_1 = action_get_args_from_task_vars(var_0, bytes_0)
    str_0 = 'q'

# Generated at 2022-06-25 07:54:04.334386
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'abc$12'
    bytes_1 = b'%}W'
    bytes_2 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_1, bytes_0, bytes_0, bytes_2, bytes_2, bytes_2)
    var_0 = 'S'
    var_1 = {}
    action_module_0.run(var_0, var_1)

# Generated at 2022-06-25 07:54:11.686064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params_0 = {}
    params_0['verbosity'] = None
    var_0 = params_0
    var_1 = {}
    var_1['verbosity'] = None
    var_2 = var_1
    params_0['extra_vars'] = None
    var_3 = params_0
    var_4 = var_3
    params_0['connection_params'] = None
    var_5 = params_0
    clone_0 = var_5
    params_0['extra_vars'] = None
    var_6 = params_0
    var_7 = var_6
    params_0['connection_params'] = None
    var_8 = params_0
    clone_1 = var_8
    params_0['verbosity'] = None
    var_9 = params_0
    var_

# Generated at 2022-06-25 07:54:22.084887
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'o'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    var_1 = action_module_0.run(None, var_0)
    var_2 = {}
    for key_0 in var_0:
        var_4 = key_0
        var_5 = var_0
        var_6 = var_4
        var_2[var_4] = var_5[var_6]
    str_0 = 'validate_args_context ='


# Generated at 2022-06-25 07:54:35.565810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  tmp0 = 'uVyjK'
  task_vars0 = {'uVyjK': 'uVyjK'}
  action_module0 = ActionModule(tmp0, tmp0, tmp0, tmp0, task_vars0, tmp0)
  var_0 = action_module0.run(tmp0, task_vars0)
  str_0 = 'action_module_1 ='
  if var_0 != None:
    str_0 = 'action_module_1 = %s' % var_0


# Generated at 2022-06-25 07:54:42.094019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b':k'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    var_1 = action_module_0.run(var_0)
    str_0 = 'run_1 ='

# Generated at 2022-06-25 07:54:43.456399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0()


# Generated at 2022-06-25 07:54:51.046192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    try:
        action_module_0.run(bytes_0, bytes_0)
    except (AnsibleError, AnsibleValidationErrorMultiple) as var_0:
        str_0 = repr(var_0)



# Generated at 2022-06-25 07:54:52.410255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(test_case_0())

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:54:58.295536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9c\xcb\t\xcc\xcd\xaa\x86\xc5'
    bytes_1 = b'\x9c\xcb\t\xcc\xcd\xaa\x86\xc5'
    bytes_2 = b'\x9c\xcb\t\xcc\xcd\xaa\x86\xc5'
    bytes_3 = {bytes_0: bytes_1}
    bytes_4 = {bytes_2: bytes_1}
    action_module_0 = ActionModule(bytes_0, bytes_1, bytes_2, bytes_3, bytes_4, bytes_4)
    var_0 = bytes_4
    var_1 = action_module_0.run(var_0, bytes_3)
    str_0

# Generated at 2022-06-25 07:55:07.707963
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1. Create the action module
    result_1 = dict()
    result_1, result_2 = combine_vars(result_1, bytes_0)

# Generated at 2022-06-25 07:55:16.949032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'_'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    str_0 = 'run_0.msg'
    var_1 = '.gcs.a '
    var_2 = 'The arg spec validation passed'
    bytes_2 = b'Y'
    bytes_3 = {bytes_0: bytes_1}
    action_module_1 = ActionModule(bytes_2, bytes_0, bytes_0, bytes_3, bytes_1, bytes_1)
    str_1 = 'run_1.msg'
    var_3 = '`argument_spec` arg is required in args: '

# Generated at 2022-06-25 07:55:21.877152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    str_0 = 'ActionModule_0 ='


# Generated at 2022-06-25 07:55:33.575458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    tmp = b"\x1c\x89'\x19\x14\xa1"
    task_vars = bytes_1
    result = action_module_0.run(tmp, task_vars)
    str_0 = 'run result: %s'
    print(str_0 % result)
    str_1 = 'expected result: %s'
    print(str_1 % '<no parameters>')


# Generated at 2022-06-25 07:55:53.737182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  bytes_0 = b'}X'
  bytes_1 = {bytes_0: bytes_0}
  action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
  bytes_2 = b'\xcf'
  var_0 = bytes_2
  var_1 = bytes_1
  var_2 = action_module_0.run(var_0, var_1)
  str_0 = 'run_1 ='

# Generated at 2022-06-25 07:55:57.494202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'E'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    var_1 = action_module_0.run(bytes_0, var_0)

# Generated at 2022-06-25 07:56:08.383585
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:56:19.831279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    bytes_0 = b'4%'
    bytes_1 = {bytes_0: bytes_0}
    result_0 = action_module_0.run(bytes_0, bytes_1)
    str_0 = 'validate_args_context'
    var_0 = result_0[str_0]
    str_2 = 'failed'
    bool_1 = str_2 in var_0
    if bool_1:
        str_3 = 'msg'
        str_4 = 'Validation of arguments failed:\n%s'

# Generated at 2022-06-25 07:56:26.759376
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:56:36.185677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = 'this_is_a_test_day_for_run_2'
    bytes_0 = b'c_L'
    dict_0 = {bytes_0: string_0}
    action_module_0 = ActionModule(string_0, string_0, string_0, string_0, string_0, dict_0)
    action_module_0.run(string_0, dict_0)
    str_0 = '`\x7f\x12\x1e\x15\x04\x1b\n\x14\t\x17'
    str_1 = str_0
    assert action_module_0._task.args['validate_args_context'] == {str_1: {str_0: bytes_0}}


# Generated at 2022-06-25 07:56:42.499293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'q\x1a\xb1'
    int_0 = 1
    bytes_1 = b'#\x8d\x1a\x10\xf1\x9d\x8fkF\xc6\xea\x18\x1d\xeb\xee\xdb\xe9\x80\xb7\xf0\x18I\x92\xb8\x89m\xdc\xcd\x9b'
    var_0 = {int_0: bytes_1}
    bytes_2 = b'\xbc'
    var_1 = {bytes_0: var_0, bytes_2: bytes_1}
    bytes_3 = b'\x9f\x8c\x14'
    bytes_4 = b'}X'
    bytes

# Generated at 2022-06-25 07:56:53.115591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {'B8': [bytes_0, bytes_0]}
    bytes_2 = b'JP'
    bytes_3 = b'`'
    bytes_4 = {bytes_3: [bytes_0]}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_4, bytes_4, bytes_4)
    bytes_5 = b'\xabB'
    bytes_6 = {bytes_5: bytes_5}
    var_0 = bytes_6
    var_1 = var_0

# Generated at 2022-06-25 07:57:00.518021
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'<'
    bytes_1 = b'*\x04'
    bytes_2 = {bytes_1: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_2, bytes_2, bytes_2)
    str_0 = 'ActionModule(play, new_play, loader, templar, shared_loader_obj, variable_manager)'
    # This assert fills in the values for the object ActionModule
    assert isinstance(action_module_0, ActionModule)
    assert 'ActionModule' == str_0


# Generated at 2022-06-25 07:57:03.060295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.run() == {}


# Generated at 2022-06-25 07:57:36.571314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # this test will fail because we don't have a working connection mock,
    # so the __init__ method of the parent class ActionBase fails
    try:
        bytes_0 = b'}X'
        bytes_1 = {bytes_0: bytes_0}
        action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    except Exception as inst:
        # verify instance type
        assert isinstance(inst, AnsibleError)



# Generated at 2022-06-25 07:57:43.276443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b'}X'
    bytes_0 = {bytes_1: bytes_1}
    action_module_1 = ActionModule(bytes_0, bytes_1, bytes_1, bytes_0, bytes_1, bytes_1)
    var_0 = bytes_1
    var_1 = action_module_run(bytes_1, var_0)
    str_1 = 'run_1 ='


# Generated at 2022-06-25 07:57:51.287305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task_0 = {'argument_spec': {'key': {'type': 'string'}}}
    _task_1 = {'provided_arguments': {'key': 'VALUE'}}
    _arguments_0 = {'argument_spec': {'key': {'type': 'string'}}}
    _arguments_1 = {'provided_arguments': {'key': 'VALUE'}}
    _arguments_0["validate_args_context"] = {}
    _arguments_1["validate_args_context"] = {}
    _task_0.update(_arguments_0)
    _task_1.update(_arguments_1)
    _task_0["validate_args_context"] = {}
    _task_1["validate_args_context"] = {}

# Generated at 2022-06-25 07:57:54.936224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'#'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    var_1 = action_get_args_from_task_vars(var_0, bytes_0)
    str_0 = 'get_args_from_task_vars_1 ='


# Generated at 2022-06-25 07:58:02.679310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    var_1 = action_run(var_0, bytes_0)
    str_0 = 'run_1 ='


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:58:07.688382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    tmp_0 = None
    task_vars_0 = var_0
    result = action_module_0.run(tmp_0, task_vars_0)
    str_0 = 'run_1 ='


# Generated at 2022-06-25 07:58:09.876289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# -------------------------------------------------------------------------
# Test Functions
# -------------------------------------------------------------------------


# Generated at 2022-06-25 07:58:19.853972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b';(X'
    bytes_1 = b'%'
    bytes_2 = b'Di:Wi\t'
    bytes_3 = {bytes_2: bytes_1}
    bytes_4 = {bytes_0: bytes_0, bytes_2: bytes_0}
    bytes_5 = {bytes_2: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_3, bytes_4, bytes_5)
    var_0 = action_module_0
    var_1 = 'get_args_from_task_vars_1.py'
    var_2 = var_0.run(var_1, bytes_0)
    return var_2


# Generated at 2022-06-25 07:58:22.076882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)


# Generated at 2022-06-25 07:58:29.536252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    action_module_0.run(var_0)
    str_0 = 'run_1 ='
    print(str_0)



# Generated at 2022-06-25 07:59:37.124992
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    var_1 = action_module_0.run(var_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:59:45.615511
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create an instance of ArgumentSpecValidationErrorMultiple
    ArgumentSpecValidationErrorMultiple_instance_0 = ArgumentSpecValidationErrorMultiple('a', 'b', 'c')
    # Create an instance of ArgumentSpecValidationResult
    ArgumentSpecValidationResult_instance_0 = ArgumentSpecValidationResult()

    # Retrieve the value of 'ArgumentSpecValidationResult.error_messages'
    error_messages_val_0 = ArgumentSpecValidationResult.error_messages
    # Store the value of 'ArgumentSpecValidationResult.error_messages_1' in a dict
    error_messages_0 = {'error_messages_1': error_messages_val_0}

    # Retrieve the value of 'error_messages_0'

# Generated at 2022-06-25 07:59:54.852261
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    expect_val_0 = 'get_args_from_task_vars_1'
    var_0 = test_case_0()
    str_0 = 'get_args_from_task_vars_1 ='
    var_0 = var_0
    assert expect_val_0 == var_0, 'Test failed: {} != {}'.format(expect_val_0, var_0)

# Generated at 2022-06-25 08:00:01.805422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'get_args_from_task_vars_0'
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)


# Generated at 2022-06-25 08:00:08.187734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    assert type(getattr(action_module_0, '_task', None)) == bytes



# Generated at 2022-06-25 08:00:13.949225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'}X'
    bytes_1 = {bytes_0: bytes_0}
    action_module_0 = ActionModule(bytes_0, bytes_0, bytes_0, bytes_1, bytes_1, bytes_1)
    var_0 = bytes_1
    var_1 = action_run(var_0, var_0)
    str_0 = 'run_1 ='



# Generated at 2022-06-25 08:00:23.171507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_1 = b'~m}v'
    bytes_2 = {bytes_1: bytes_1}
    action_module_0 = ActionModule(bytes_1, bytes_1, bytes_1, bytes_2, bytes_2, bytes_2)
    bytes_0 = b'\x00\x00\x00'
    # noinspection PyUnusedLocal
    action_module_1 = None
    var_0 = bytes_2
    # noinspection PyUnusedLocal
    action_module_2 = None
    # noinspection PyUnusedLocal
    action_module_3 = None
    action_module_0._task.args['validate_args_context'] = bytes_0
    # noinspection PyUnusedLocal
    action_module_4 = None
    # noinspection PyUnusedLocal


# Generated at 2022-06-25 08:00:28.704365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'w\xc5'
    bytes_1 = b'\xca\xca\xc4\x8f\xb6\xd2\xed\xa4\x8a\x9aX\xa9(\x81\x8e'
    bytes_2 = b'3\xed'
    bytes_3 = b'\x9f'
    bytes_4 = b'w}'
    bytes_5 = {bytes_2: bytes_2, bytes_3: bytes_3, bytes_4: bytes_4}
    bytes_6 = b'\xef\xaf'

# Generated at 2022-06-25 08:00:35.812509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a string
    str_0 = 'argument_spec'
    # Create an instance of AnsibleError
    ansible_error_0 = AnsibleError(str_0)
    str_1 = 'validate_argument_spec'
    # Create an instance of ActionModule
    action_module_0 = ActionModule(str_1, dict(), dict())
    # Create a string
    str_2 = 'provided_arguments'
    # Create an instance of dict
    dict_0 = dict()
    # Create a string
    str_3 = 'argument_spec_data'
    # Create an instance of dict
    dict_1 = dict()
    dict_2 = {str_3: dict_1}
    # Create an instance of dict
    dict_3 = dict()

# Generated at 2022-06-25 08:00:46.114440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'm\x16\x17\x81\xc2\x04\xa2\xbd\x12\xc1\x96\xb5\xb1\x06\xea\xc5(A\xb0\x9a\x95\x8eW\x1c\x0f\xb2\xfa\xb1\x95\x9a\xc4\x11\xf6\x17\xee-\xaf\xa1\xc6\xaf\xfd\xc7\x8b\x84\x83'
    bytes_1 = b'\x839<\xd4\x1a\x06\xd6\xce\xee\xf3\x94\x92\x1c\x9d\xea\x1b'
    bytes_