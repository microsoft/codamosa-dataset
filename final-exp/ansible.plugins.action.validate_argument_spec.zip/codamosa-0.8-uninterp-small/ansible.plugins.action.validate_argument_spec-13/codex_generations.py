

# Generated at 2022-06-25 07:52:05.301769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        tmp = None
        task_vars = dict()
        action_module = ActionModule()
        action_module._task = dict()
        action_module._task['args'] = dict()
        action_module._task['args']['validate_args_context'] = dict()
        action_module._task['args']['argument_spec'] = dict()
        action_module._task['args']['provided_arguments'] = dict()
        return_value = action_module.run(tmp, task_vars)
        assert return_value == None
    except AnsibleError as err:
        print(err)
        assert False


# Generated at 2022-06-25 07:52:15.192527
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    str_0 = str(dict_0)
    dict_1 = {str_0: str_0, str_0: dict_0}
    dict_2 = {str_0: str_0, str_0: str_0}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {str_0: dict_4, str_0: dict_5}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {str_0: dict_7, str_0: dict_8, str_0: dict_9}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}

# Generated at 2022-06-25 07:52:23.508904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_6 = -1503.691226
    set_1 = {float_6, float_6, float_6}
    dict_1 = {set_1: float_6, set_1: float_6}
    # try:
    # TODO: uncomment after generic instantiation is implemented
    #     ActionModule(dict_1, dict_1)
    # except Exception as exception_0:
    #     # TODO: handle exception
    #     raise exception_0
    float_7 = -1503.691226
    set_2 = {float_7, float_7, float_7}
    dict_2 = {set_2: float_7, set_2: float_7}
    # try:
    # TODO: uncomment after generic instantiation is implemented
    #     ActionModule(dict_

# Generated at 2022-06-25 07:52:31.090224
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule()
    argument_spec = {}
    task_vars = {}
    assert action_module.get_args_from_task_vars(argument_spec, task_vars) == {}


# Generated at 2022-06-25 07:52:38.917683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1503.691226
    int_0 = -180
    bool_0 = True
    dict_0 = {float_0: bool_0}
    str_0 = 'pE7mpZ-O$u(7N=-jJ^PxUL|y'
    list_0 = [float_0]
    list_1 = [dict_0]
    list_2 = [int_0]
    dict_1 = {str_0: dict_0}
    dict_2 = {str_0: float_0, str_0: float_0}
    dict_3 = {list_0: dict_0}
    dict_4 = {list_1: dict_0}
    dict_5 = {list_2: dict_0}

# Generated at 2022-06-25 07:52:42.971967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    loop_1 = set_0
    loop_0 = set_0
    for var_3 in loop_0:
        for var_4 in loop_1:
            print(var_3, var_4)

# Generated at 2022-06-25 07:52:46.303026
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:52:52.903954
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arg spec
    argument_spec = {}

    # Arguments
    arguments = {}

    # Task variables
    task_vars = {}

    # Action
    action = ActionModule()

    # Execution
    result = action.run(tmp, task_vars)

    # Tests
    assert result == {} 


# Generated at 2022-06-25 07:53:02.051218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    tmp_0 = None
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    argument_spec_data_0 = ArgumentSpecValidator.validate_argument_spec(tmp_0)
    provided_arguments_0 = {}
    am = ActionModule(tmp_0, task_vars_0)
    result = am.run(tmp_0, task_vars_0)
    if result['argument_errors'] != validation_result.error_messages:
        raise Exception('''The returned value (result['argument_errors']) did not meet the expected expectations.''')

# Generated at 2022-06-25 07:53:05.196286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    argument_spec = {
        'argument_spec' : dict_0,
        'provided_arguments' : dict_0,
        'validate_args_context': dict_0
    }

    tmp = None

    task_vars = dict_0
    action_module = ActionModule(argument_spec, tmp, task_vars)



# Generated at 2022-06-25 07:53:12.673061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # exception
    with pytest.raises(AnsibleError):
        action_module_0.run()

    # exception
    with pytest.raises(AnsibleError):
        action_module_0.run()

    # exception
    with pytest.raises(AnsibleError):
        action_module_0.run()


# Generated at 2022-06-25 07:53:15.094988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_1.run()  # verify function is callable



# Generated at 2022-06-25 07:53:16.657797
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:53:19.510505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_1 = ActionModule()
        ActionModule.run(action_module_1)
    except Exception as exception:
        print('exception')
        assert False
    else:
        assert True

# Generated at 2022-06-25 07:53:20.599732
# Unit test for constructor of class ActionModule
def test_ActionModule():
   action_module_0 = ActionModule()



# Generated at 2022-06-25 07:53:28.643871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:53:32.423433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0._display.verbosity > 0


# Generated at 2022-06-25 07:53:35.884794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule(
        connection = None,
        task = None,
        play_context = None,
        loader = None,
        templar = None,
        shared_loader_obj = None
    )


# Generated at 2022-06-25 07:53:46.646872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  argument_spec = {'argument_spec': {'provider': {'required': False, 'type': 'dict'}, 'state': {'choices': ['absent', 'present'], 'required': True, 'type': 'str'}, 'type': {'required': True, 'type': 'str'}}, 'provided_arguments': {'state': 'present', 'type': 'aaaaaaaa'}}
  task_vars = {'validate_args_context': {}}

  # Construct the object
  am = ActionModule()

  # Capture the results of the method under test
  result = am.run(tmp=None, task_vars=task_vars)

  assert result['failed']

# Generated at 2022-06-25 07:53:56.979607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    # Setup test environment
    #
    # mock_ansible_module(module_args, check_mode=False, context=None,
    #                     load_in_safe_mode=True, run_additional_modules=True,
    #                     use_unix_socket=False):
    #
    #     setup mock result, which is a class, can use to setup attrs
    mock_result = action_module_0.mock_ansible_module(
        argument_spec=dict(),
        )
    # mock_ansible_module return a obj, can setup any return attrs for the obj
    mock_result.params = dict()

    # mock_ansible_module return result or exception tuple
    # result[0]: actual result
    # result[1]: exception if actual result is None
    result = action_

# Generated at 2022-06-25 07:54:10.680039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = '/tmp/ansible_val_arg_spec_payload.1Q2tjM'
    task_vars = {'a': {'a': 'string', 'b': 'dict'}, 'b': 'dict'}
    task = {'args': {'argument_spec': 'dict', 'provided_arguments': 'dict'}}
    action_module_0._task = task
    result = action_module_0.run(tmp, task_vars)
    assert result['failed'] == True
    assert result['msg'] == '"argument_spec" arg is required in args: dict'


# Generated at 2022-06-25 07:54:12.305630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 07:54:15.286144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    argument_spec_0 = {}
    result_0 = action_module_0.run()

test_ActionModule_run()

# Generated at 2022-06-25 07:54:19.980531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() is None

# Generated at 2022-06-25 07:54:20.782100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:54:22.186266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionBase)



# Generated at 2022-06-25 07:54:32.422684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First with some correct data.
    task_args = {'argument_spec': {'name': {'type': 'string', 'required': True},
                                   'state': {'type': 'str', 'required': False, 'choices': ['absent', 'present']}}}
    task_vars = {}
    provided_arguments = {'name': 'fake_name'}
    task_args['provided_arguments'] = provided_arguments
    task_args['validate_args_context'] = {'validate_args_context_representation': 'some_representation_of_something'}

    action_module = ActionModule()

    result = action_module.run(tmp=None, task_vars=task_vars, **task_args)

    # Check the result
    assert result['changed'] == False
   

# Generated at 2022-06-25 07:54:34.254391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    # Load test data
    # Set up
    action_module_1 = ActionModule()
    # Test
    



# Generated at 2022-06-25 07:54:44.433149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Create a mock task object
    task = dict()
    task['action'] = 'validate_argument_spec'
    action = 'validate_argument_spec'
    task['args'] = dict()
    task['args']['argument_spec'] = dict()
    task['args']['argument_spec']['y'] = dict()
    task['args']['argument_spec']['y']['type'] = 'str'
    task['args']['argument_spec']['x'] = dict()
    task['args']['argument_spec']['y']['type'] = 'int'
    task['args']['argument_spec']['x']['type'] = 'list'

# Generated at 2022-06-25 07:54:45.638081
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_1 = ActionModule()

# Generated at 2022-06-25 07:55:04.874173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    error_msg = 'not set'
    try:
        action_module_0.run(A='A')
    except Exception as e:
        error_msg = str(e)

    assert error_msg == '"task_vars" arg is required in args: {\'A\': \'A\'}'


# Generated at 2022-06-25 07:55:09.873681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test for key 'msg' in action result
    action_module_1 = ActionModule()
    action_module_1._task.args = {'argument_spec': {'key1': {'type': 'str'}, 'key2': {'type': 'str'}}, 'provided_arguments': {'key1': 'value1', 'key2': 'value2'}, 'validate_args_context': {'entity_name': 'test_entity', 'validate_args_type': 'task'}}
    action_module_1._task.action = 'src.modules.utils.validate_argument_spec'
    action_module_1._task._role = None
    action_module_1._templar = None
    action_module_1.docker_validate = None
    action_module_1.connection = None


# Generated at 2022-06-25 07:55:18.135804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 1
    d = dict(a=1, b=2)
    task_vars = dict(argument_spec=d, provided_arguments=dict(a=1, b=2))

    res1 = ActionModule().run(task_vars=task_vars)

    assert 'Validate argument spec success' in res1['msg']
    assert 'The arg spec validation passed' in res1['msg']
    assert 'changed' in res1
    assert not res1['changed']

    # Test case 2
    task_vars = dict(argument_spec=d, provided_arguments=dict(a=1, b='2', c=3))

    res2 = ActionModule().run(task_vars=task_vars)

    assert len(res2['argument_errors']) == 1
    assert res2

# Generated at 2022-06-25 07:55:20.208608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result is not None, "Constructor of class ActionModule should not return None"


# Generated at 2022-06-25 07:55:21.416483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.set_task(dict())
    action.set_loader(dict())



# Generated at 2022-06-25 07:55:22.524084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = action_module_0.ActionModule()


# Generated at 2022-06-25 07:55:27.324831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None



# Generated at 2022-06-25 07:55:29.952353
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    assert action_module_0.get_args_from_task_vars() == 0


# Generated at 2022-06-25 07:55:36.690764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    target_module = __import__('ansible.plugins.action.validate_argument_spec')
    action_module = getattr(target_module, 'ActionModule')
    obj = action_module()

    tmp = obj.tmp
    task_vars = obj.task_vars
    assert isinstance(tmp, str)
    assert isinstance(task_vars, dict)
    result = obj.run(tmp, task_vars)
    assert isinstance(result, dict)
    assert "argument_spec_data" in result


# Generated at 2022-06-25 07:55:37.537039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:56:08.211163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:56:11.239757
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a meta class action class object
    action_module = ActionModule()
    # test ActionBase class init functionality
    action_base = ActionBase()



# Generated at 2022-06-25 07:56:24.068480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Test with a string. Should raise AssertionError
    with pytest.raises(AssertionError) as excinfo:
        action_module_0._connection = None
        action_module_0._play_context = None
        action_module_0._loader = None
        action_module_0._templar = None
        action_module_0._shared_loader_obj = None
        action_module_0._task_vars = None
        action_module_0._start_at = None
        action_module_0._step = None
        action_module_0._job_cache = None
        action_module_0._last_task_banner = None
        action_module_0._nonpersistent_fact_cache = None

# Generated at 2022-06-25 07:56:24.827777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:56:25.717267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:56:31.034621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Try to define a variable "argument_spec" for the action module to test on
    try:
        action_module_0.run()
    except AnsibleError as e:
        # Note that this will only work if AnsibleError is the only exception thrown
        assert '"argument_spec" arg is required' in e.message
    else:
        raise Exception('Expected exception not thrown')


# Generated at 2022-06-25 07:56:38.951622
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule()

    assert action_module.get_args_from_task_vars({'a': {'type': 'int'}}, {'a': 1}) == {'a': 1}
    assert action_module.get_args_from_task_vars({'a': {'type': 'int'}}, {'a': '{{ 1 }}'}) == {'a': 1}
    assert action_module.get_args_from_task_vars({'a': {'type': 'int'}}, {'a': '{{ 1 }}{{ 2 }}'}) == {'a': '1{{ 2 }}'}

# Generated at 2022-06-25 07:56:40.809561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

    assert isinstance(action_module_0, ActionModule) is True, "Constructor did not create a ActionModule object"


# Generated at 2022-06-25 07:56:47.576753
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_1 = ActionModule()
    action_module_1._connection = object()
    action_module_1._task = object()
    action_module_1._loader = object()
    action_module_1._templar = object()
    action_module_1._shared_loader_obj = object()
    action_module_1._play_context = object()
    action_module_1._play_context.prompt = str()
    action_module_1._play_context.answer_wrapper = str()
    action_module_1._play_context.prompt_until_success = bool()
    action_module_1._play_context.new_stdin = object()
    action_module_1._play_context.remote_addr = str()
    action_module_1._play_context.password = str()

# Generated at 2022-06-25 07:56:53.036280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:57:48.253248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    p = action_module_1.run()
    assert not p

# Generated at 2022-06-25 07:57:53.422442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:57:59.162642
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    my_result = action_module_0.run(tmp, task_vars)
    my_expected_result = action_module_0.run(tmp, task_vars)
    assert my_result == my_expected_result


# Generated at 2022-06-25 07:58:08.095380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    argument_spec = {
        'argument_spec': {
            'argument_spec': {
                'choices': [
                    'arg_spec',
                    'args'
                ],
                'default': 'args',
                'type': 'str'
            },
            'args': {
                'required': True,
                'type': 'list',
                'elements': 'dict',
                'options': {
                    'argument_spec': {
                        'type': 'dict',
                        'required': True
                    },
                    'provided_arguments': {
                        'required': False,
                        'type': 'dict'
                    }
                }
            },
            'validate_args_context': {
                'required': False,
                'type': 'dict'
            }
        }
    }
    action_module_0

# Generated at 2022-06-25 07:58:15.546470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    #assert result_0['msg'] == 'The arg spec validation passed'
    #assert result_0['changed'] == False
    assert type(result_0) == dict

# Generated at 2022-06-25 07:58:19.262120
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_1 = ActionModule()
    assert action_module_1.get_args_from_task_vars(argument_spec={'argument_spec_0': {'type': 'int'}}, task_vars={'argument_spec_0': 1}) == {'argument_spec_0': 1}


# Generated at 2022-06-25 07:58:21.495277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Unit Test for ActionModule.get_args_from_task_vars()

# Generated at 2022-06-25 07:58:25.715693
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, object) is True


# Generated at 2022-06-25 07:58:26.411879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:58:27.361561
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:59:37.514733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 978.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = "H(XN\n)'Y9ZbA->*u1"
    list_0 = [tuple_0]
    str_1 = 'sD\t\x0cfA'
    int_0 = 10
    dict_0 = {}
    action_module_0 = ActionModule(tuple_0, tuple_0, tuple_0, str_0, tuple_0, bool_0)
    action_module_0.run(list_0, dict_0)
    var_0 = action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 07:59:44.976938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 678.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = "7e(,!]P:W0\t]74&`"
    list_0 = [tuple_0]
    str_1 = 'G0^T\x00\b\x0bK'
    dict_0 = {}
    set_0 = {str_1}
    action_module_0 = ActionModule(tuple_0, set_0, tuple_0, str_0, tuple_0, bool_0)
    var_0 = action_module_0.run(dict_0, list_0)
    assert var_0 is not None


# Generated at 2022-06-25 07:59:51.613040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 990.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = "A\x0cx6j5U>1"
    list_0 = [tuple_0]
    str_1 = 'z\x17xn'
    dict_0 = {}
    set_0 = {str_1}
    action_module_0 = ActionModule(tuple_0, set_0, tuple_0, str_0, tuple_0, bool_0)
    var_0 = action_module_0.get_args_from_task_vars(dict_0, tuple_0)
    # Verify that the instance has the correct attributes
    assert isinstance(action_module_0, ActionModule)
    assert isinstance(var_0, dict)
    #

# Generated at 2022-06-25 07:59:55.883314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    set_0 = set()
    str_0 = '\x0c'
    tuple_0 = ()
    tuple_1 = (tuple_0,)
    action_module_0 = ActionModule(tuple_0, set_0, tuple_0, str_0, tuple_0, False)


# Generated at 2022-06-25 08:00:03.803697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 978.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = "H(XN\n)'Y9ZbA->*u1"
    list_0 = [tuple_0]
    str_1 = 'sD\t\x0cfA'
    dict_0 = {}
    set_0 = {str_1}
    action_module_0 = ActionModule(tuple_0, set_0, tuple_0, str_0, tuple_0, bool_0)
    dict_1 = action_module_0.run()

# Generated at 2022-06-25 08:00:10.525114
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 978.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = "H(XN\n)'Y9ZbA->*u1"
    list_0 = [tuple_0]
    str_1 = 'sD\t\x0cfA'
    dict_0 = {}
    set_0 = {str_1}
    # parameter 0 is the 'task' parameter
    action_module_0 = ActionModule(tuple_0, set_0, tuple_0, str_0, tuple_0, bool_0)
    str_2 = 'qY\r@P\\$Nd"`k\x7f1\x0b'
    # parameter 0 is the 'tmp' parameter
    # parameter 1 is the 'task_vars' parameter

# Generated at 2022-06-25 08:00:18.185510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 978.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = "H(XN\n)'Y9ZbA->*u1"
    list_0 = [tuple_0]
    str_1 = 'sD\t\x0cfA'
    dict_0 = {}
    set_0 = {str_1}
    action_module_0 = ActionModule(tuple_0, set_0, tuple_0, str_0, tuple_0, bool_0)
    action_module_0.run(dict_0, tuple_0)

# Generated at 2022-06-25 08:00:27.101756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Case 0
    float_0 = 978.0
    tuple_0 = (float_0,)
    bool_0 = True
    str_0 = "H(XN\n)'Y9ZbA->*u1"
    list_0 = [tuple_0]
    str_1 = 'sD\t\x0cfA'
    dict_0 = {}
    set_0 = {str_1}
    action_module_0 = ActionModule(tuple_0, set_0, tuple_0, str_0, tuple_0, bool_0)
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 08:00:33.034151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 953.0
    tuple_0 = (float_0,)
    bool_0 = False
    str_0 = "r5;)@9:<\x0e"
    list_0 = [float_0]
    str_1 = 'uC@g\x7f'
    dict_0 = {}
    dict_1 = {}
    dict_0[str_1] = list_0
    action_module_0 = ActionModule(tuple_0, dict_0, tuple_0, str_0, tuple_0, bool_0)
    ret_val_0 = action_module_0.run()

# Generated at 2022-06-25 08:00:38.356879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (978.0,)
    bool_0 = True
    str_0 = "H(XN\n)'Y9ZbA->*u1"
    action_module_0 = ActionModule(tuple_0, set(), tuple_0, str_0, tuple_0, bool_0)
    str_1 = 'sD\t\x0cfA'
    tuple_1 = (tuple_0,)
    set_0 = {str_1}
    dict_0 = {}
    str_2 = '9]\r\n\x0bLsj\t'
    str_3 = 'H(XN\n)'
    str_4 = 'f}'
    str_5 = '<a\t'