

# Generated at 2022-06-25 07:52:08.019883
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of arguments
    args = dict()
    args['validate_args_context'] = dict()
    args['argument_spec'] = dict()
    args['provided_arguments'] = dict()

    # Create an instance of the AnsibleModule class
    AM = AnsibleModule(argument_spec=dict())

    # Create a mock task object by passing a phony task name and phony task args
    task = Task()
    task.args = args
    task._task = task
    
    # Create a mock of the tempfile module
    tempfile_mock = mock.Mock()
    tempfile_mock.mkdtemp.return_value = '/tmp/ansible_arg_spec_validation_plugin_tests.dhnjqs.1'
    tempfile_mock.gettempdir.return_value = '/tmp'

# Generated at 2022-06-25 07:52:16.224265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    sys_argv = ['ansible-test', 'validate_argument_spec']
    list_0 = [False, '', 0.0, 0, ['', {}], '']
    int_0 = -52
    bytes_0 = b'\xa3\xff$\xa7\xd4\xa8\x83\xd3\xe5\xbft\xfd(\x04\x8c\xe2'
    str_0 = '--depth'
    set_0 = {bytes_0, list_0, str_0}
    action_module_0 = ActionModule(list_0, int_0, bytes_0, set_0, int_0, list_0)
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:52:22.053509
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = 71
    bytes_0 = b'\xc2\x8c\x06\x05\x9a\xb9\x8d\xab\xe3\xe3\xe3\x8d'
    str_0 = 'BN'
    set_0 = {int_0, bytes_0, str_0}
    action_module_0 = ActionModule(list_0, int_0, bytes_0, set_0, int_0, list_0)

# Unit for get_args_from_task_vars

# Generated at 2022-06-25 07:52:31.234301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = -86
    bytes_0 = b'\x0b\xef\xf5\xca{"\x9f\xb1,\xfc.\xc8\xac\x84\xcd\xbc\x0e\x9e\xcd\xe1\xf5\x8b\xea\x88\xfc\xfa\x8a\xef\xe5\xe4\xb4\xf4\xe6\x19\x1a\xdf\x8c[\x03\x04\xb6R\xc0\x17\xdb\xbb'
    str_0 = 'rsa'
    set_0 = {int_0, list_0, str_0}

# Generated at 2022-06-25 07:52:36.186366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = -52
    bytes_0 = b'\xa3\xff$\xa7\xd4\xa8\x83\xd3\xe5\xbft\xfd(\x04\x8c\xe2'
    str_0 = '--depth'
    set_0 = {bytes_0, list_0, str_0}
    action_module_0 = ActionModule(list_0, int_0, bytes_0, set_0, int_0, list_0)


# Generated at 2022-06-25 07:52:43.941025
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:52:51.812223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = -52
    bytes_0 = b'\xa3\xff$\xa7\xd4\xa8\x83\xd3\xe5\xbft\xfd(\x04\x8c\xe2'
    str_0 = '--depth'
    set_0 = {bytes_0, list_0, str_0}
    action_module_0 = ActionModule(list_0, int_0, bytes_0, set_0, int_0, list_0)
    task_vars = {bytes_0: str_0, str_0: bytes_0}
    result = action_module_0.run(int_0, task_vars)
    if isinstance(result, dict):
        print("Result is as expected")
    else:
        raise Exception

# Generated at 2022-06-25 07:52:58.411106
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    int_0 = (1 << 30) + 1
    str_0 = 'default'
    set_0 = {str_0, int_0}
    action_module_0 = ActionModule(list_0, int_0, str_0, set_0, int_0, list_0)

    # call test function
    try:
        action_module_0.run(None, None)
    except SystemExit:
        raise Exception('Unexpected exit')
    except Exception as e:
        print(e)



# Generated at 2022-06-25 07:53:05.788355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_1 = []
    int_1 = -52
    bytes_1 = b'\xa3\xff$\xa7\xd4\xa8\x83\xd3\xe5\xbft\xfd(\x04\x8c\xe2'
    str_1 = '--depth'
    set_1 = {bytes_1, list_1, str_1}
    action_module_1 = ActionModule(list_1, int_1, bytes_1, set_1, int_1, list_1)
    action_module_2 = ActionModule(list_1, int_1, bytes_1, set_1, int_1, list_1)

    # Test with valid inputs
    list_1 = [dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict(), dict()]
   

# Generated at 2022-06-25 07:53:09.850119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    int_0 = -37
    str_0 = '#Y\x1f\x1e\x86\x90m'
    set_0 = {str_0}
    action_module_0 = ActionModule(set_0, list_0, str_0, list_0, list_0, int_0)


# Generated at 2022-06-25 07:53:24.551581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    obj = ActionModule(var_0, var_1)
    var_8 = obj.TRANSFERS_FILES
    var_9 = obj.BYPASS_HOST_LOOP
    var_10 = obj.NO_TARGET_SYSLOG
    var_11 = obj.DEFAULT_AS_FAILED
    var_12 = obj.SHARED_LOAD_FILENAME
    var_13 = obj.BYPASS_SINGLE_LOOP
    var_14 = obj.NO_LOCAL_ACTION
    var_15 = obj.BYPASS_WORKER_PROC

# Generated at 2022-06-25 07:53:32.879348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    # Create an instance of ArgumentSpecValidator
    # Create an instance of AnsibleError
    # Create an instance of AnsibleError
    # Create a run of ActionModule
    # Create an instance of ArgumentSpecValidator
    # Create an instance of AnsibleError
    # Create an instance of AnsibleError
    # Create a run of ActionModule
    # Create an instance of ArgumentSpecValidator
    # Create an instance of AnsibleError
    # Create an instance of AnsibleError
    # Create a run of ActionModule
    # Create an instance of ArgumentSpecValidator
    # Create an instance of AnsibleError
    # Create an instance of AnsibleError
    # Create a run of ActionModule
    pass


# Generated at 2022-06-25 07:53:42.695048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict()
    var_2['argument_spec'] = var_1
    var_2['argument_spec']['address'] = {'type': 'str'}
    var_2['argument_spec']['address6'] = {'type': 'str'}
    var_2['argument_spec']['advertise_network'] = {'type': 'bool'}
    var_2['argument_spec']['advertise_subnet'] = {'type': 'bool'}
    var_2['argument_spec']['advertisements'] = {'type': 'int'}
    var_2['argument_spec']['aggregate_address'] = {'type': 'list'}
    var_2['argument_spec']['aggregate_address6'] = {'type': 'list'}


# Generated at 2022-06-25 07:53:54.150784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = ActionModule()
    var_2 = ActionModule()
    var_3 = ActionModule()
    var_4 = ActionModule()
    var_5 = ActionModule()
    var_6 = ActionModule()
    var_7 = ActionModule()
    var_8 = ActionModule()
    var_9 = ActionModule()
    var_10 = ActionModule()
    var_11 = ActionModule()
    var_12 = ActionModule()
    var_13 = ActionModule()
    var_14 = ActionModule()
    var_15 = ActionModule()
    var_16 = ActionModule()
    var_17 = ActionModule()
    var_18 = ActionModule()
    var_19 = ActionModule()
    var_20 = ActionModule()
    var_21 = ActionModule()
   

# Generated at 2022-06-25 07:53:55.998072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    # var_1.run(tmp=tmp, task_vars=task_vars)


# Generated at 2022-06-25 07:53:59.254634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import PY3
    result = StringIO() if PY3 else StringIO.StringIO()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 07:54:09.339017
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Ansible mock_plugins.module_utils.ansible_module_utils.ActionBase instantiate object
    obj = AnsibleModule(argument_spec=dict())
    obj.argument_spec = {"argument_spec": "str", "provided_arguments": "str"}
    obj._task.args = {"argument_spec": var_0, "provided_arguments": var_1}

    # Ansible mock_plugins.module_utils.ansible_module_utils.ActionBase object run method
    # object run method with return value and with default values for args
    result_obj = obj.run()

    # Ansible mock_plugins.module_utils.ansible_module_utils.ActionBase object run method
    # object run method with return value and with params values for args

# Generated at 2022-06-25 07:54:11.659622
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()
    object1 = ActionModule(var_0, var_1)
    object2 = ActionModule(var_0, var_1)

    assert object1.TRANSFERS_FILES()==False


# Generated at 2022-06-25 07:54:22.776392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = dict()
    var_2 = dict()
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_28 = None
   

# Generated at 2022-06-25 07:54:25.913458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()


# Generated at 2022-06-25 07:54:31.345863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Make this a real unit test.
    return True

test_case_0()

# Generated at 2022-06-25 07:54:36.352673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    result = action_module_0.run()

    # Asserts
    assert result is None


# Generated at 2022-06-25 07:54:39.510415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0



# Generated at 2022-06-25 07:54:46.327009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    return action_module_0


# Generated at 2022-06-25 07:54:51.235898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:54:52.013214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_run()


# Generated at 2022-06-25 07:54:55.065378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(302, False, (), False, True, '\x0bK*Z\tat^Gf\t2$pl#--t8')
    assert '' == ''

# Generated at 2022-06-25 07:54:58.924523
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule')

    print('Testing constructor of ActionModule')
    action_module_0 = ActionModule()
    assert not action_module_0.TRANSFERS_FILES



# Generated at 2022-06-25 07:55:05.399530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)


# Generated at 2022-06-25 07:55:14.691673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    tmp_0 = None
    task_vars_0 = {}
    var_0 = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:55:33.012277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    tmp = None
    task_vars = dict()
    result = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:55:41.947117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:55:42.472615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:55:50.755750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)



# Generated at 2022-06-25 07:55:56.827234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    ActionModule.action_run(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)


# Generated at 2022-06-25 07:56:06.125017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ("\nUnit test for constructor of class ActionModule")
    int_0 = 700
    bool_0 = True
    tuple_0 = ()
    bool_1 = True
    bool_2 = False
    str_0 = '#c~=nB5@N\x1a\x15E<"D\x18i'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    #assert action_module_0._task.args == {}
    print ("\nUnit test for constructor of class ActionModule: PASS")



# Generated at 2022-06-25 07:56:13.249070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    def action_run():
        int_0 = 302
        bool_0 = False
        tuple_0 = ()
        bool_1 = False
        bool_2 = True
        str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'

# Generated at 2022-06-25 07:56:20.327804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    tmp_0 = None
    task_vars_0 = dict()
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    assert var_0['changed'] == False
    assert isinstance(var_0['msg'], str)
    assert var_0['failed'] == False
    assert var_0['validate_args_context'] == dict()

# Generated at 2022-06-25 07:56:29.537122
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    int_0 = 1
    bool_0 = True
    tuple_0 = ()
    bool_1 = False
    bool_2 = False
    str_0 = ''
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    argument_spec_0 = dict()
    task_vars_0 = dict()
    var_0 = action_module_0.get_args_from_task_vars(argument_spec_0, task_vars_0)
    var_0 = action_module_0.get_args_from_task_vars(argument_spec_0, task_vars_0)

# Generated at 2022-06-25 07:56:34.932757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:56:53.989232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 717791636
    bool_0 = True
    tuple_0 = ()
    bool_1 = True
    bool_2 = False
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)


# Generated at 2022-06-25 07:57:01.586073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for valid input
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    # Test for invalid input
    # (invalid inputs)
    # action_module_1 = ActionModule()


# Generated at 2022-06-25 07:57:09.880062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    str_1 = 'foo'
    str_2 = 'bar'
    str_3 = 'foobar'
    str_4 = 'foobar'
    str_5 = 'foobar'
    str_6 = 'foobar'
    str_7 = 'foobar'
    str_8 = 'foobar'
    str_9 = 'foobar'
    str_10 = 'foobar'
   

# Generated at 2022-06-25 07:57:15.294106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)


# Generated at 2022-06-25 07:57:21.004563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    print('get_args_from_task_vars')
    var_0 = {
        'type': 'str',
        'choices': ['present', 'absent'],
        'default': 'present',
        'required': True,
        'aliases': ['state']
    }

# Generated at 2022-06-25 07:57:31.718848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    var_0 = 'y4Y2I00kr'
    var_1 = {'Z]pV&o[': var_0}
    var_2 = 'DPnG\x0c@<\x07I'
    var_3 = 'a`\x0f\x0f\x0bO\x0c\x0e'

# Generated at 2022-06-25 07:57:39.919945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 594
    bool_0 = False
    tuple_0 = ()
    bool_1 = True
    bool_2 = False
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)


# Generated at 2022-06-25 07:57:49.393510
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'X\x88\x8c\x1e\x1c\xc3\x84\x10\x0c\x1c\x89'
    bool_0 = True
    list_0 = [str_0, bool_0]
    tuple_0 = (1, list_0)

    action_module_0 = ActionModule(list_0, str_0, tuple_0)
    print((action_module_0.action_loader))

    str_1 = '\x1f\x00\xe1\x9e\x84\x181\x0c\x0f\x12\x98\xe5\x1d'
    action_module_0 = ActionModule(tuple_0, str_1, str_0)

# Generated at 2022-06-25 07:57:50.032134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test Case 0
    assert test_case_0()

# Generated at 2022-06-25 07:57:55.216492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # stubs
    stubs = {}
    var_0 = {}
    # mock value
    var_1 = {
        'validate_args_context': {
            'type': 'playbook',
            'name': 'baz.yml',
            'file_line': '10'
        }
    }
    var_2 = {}
    # mock value
    var_3 = {
        'foo': 'bar'
    }
    # mock value
    var_4 = {
        'foo': {
            'type': 'str'
        }
    }
    # mock value
    var_5 = 'Incorrect type for argument_spec, expected dict and got NoneType'
    # mock value
    var_6 = None
    # mock value

# Generated at 2022-06-25 07:58:38.545516
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0 = action_module_0.get_args_from_task_vars(dict_0, dict_1)
    return dict_0


# Generated at 2022-06-25 07:58:48.760732
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)

# Generated at 2022-06-25 07:58:57.253578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = 'd\x04\t\x1bT\t'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    assert isinstance(action_module_0, object) == False
    assert isinstance(action_module_0, ActionModule) == True
    assert isinstance(action_module_0, ActionBase) == True


# Generated at 2022-06-25 07:59:03.348054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Executing test_ActionModule_run')
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    action_module_0.run()
    # AssertionError: False is not true : Validation of arguments failed
    var_0 = action_run()
    # AssertionError: False is not true : Validation of arguments failed
    # AssertionError: False is not true : The arg spec validation passed
    tmp = None
    task_vars = None

# Generated at 2022-06-25 07:59:12.079809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -1568001354
    bool_0 = True
    tuple_0 = ()
    bool_1 = True
    bool_2 = False
    str_0 = '0)7W}C*pS\t<rh|mA\x0b>\x0c4*\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    assert (action_module_0.argument_spec == {})
    assert (action_module_0.no_log == False)
    assert (action_module_0.supports_check_mode == False)

# Generated at 2022-06-25 07:59:22.874805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    tmp = None
    task_vars = None
    action_module = ActionModule(tmp, task_vars)
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    arg0 = action_module_0.argument_spec
    arg1 = action_module_0.boolean_options
    arg2 = action_module_0.bypass_checks
    arg3 = action_module_0.display
    arg4 = action_module_

# Generated at 2022-06-25 07:59:27.393748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 1
    var_1 = False
    var_2 = ()
    var_3 = False
    var_4 = True
    var_5 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    test_case_0(var_0, var_1, var_2, var_3, var_4, var_5)

# Generated at 2022-06-25 07:59:33.021115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = 302
  bool_0 = False
  tuple_0 = ()
  bool_1 = False
  bool_2 = True
  str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
  action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
  str_1 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
  dict_1 = {}
  dict_2 = {}
  dict_3 = {}
  dict_4 = {}
  dict_5 = {}
  dict_6 = {}
  dict_7 = {}
  dict_8 = {}
  dict_9 = {}
  dict_10 = {}

# Generated at 2022-06-25 07:59:42.751094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6285
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    assert action_module_0._task.action == 'validate_argument_spec'
    var_0 = action_module_0._display.vvv
    str_1 = 'TASK: [validate_argument_spec] ************************************'
    var_0(str_1)
    var_1 = action_module_0._loader.get_basedir()
    var_2 = action_module_0

# Generated at 2022-06-25 07:59:47.209567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    assert action_module_0 is not None

# Generated at 2022-06-25 08:01:12.431501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    task_vars_2 = {}
    tmp_1 = None
    var_1 = action_module_1.run(tmp_1, task_vars_2)
    assert isinstance(var_1, dict)
    assert len(var_1) == 3
    assert var_1['failed'] is False


# Generated at 2022-06-25 08:01:16.810100
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    str_1 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    int_1 = 302
    dict_0 = dict()
    dict_1 = dict()
    object_0 = type(dict_0)
    object_0 = object_0(dict_1)
    object_1 = type(dict_0)
    object_1 = object_1

# Generated at 2022-06-25 08:01:23.890808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 249
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = False
    str_0 = '#q?X9xr[r+@\x0cbY>*AU:0w4/c'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    var_1 = action_module_0.run('TMP', {'task_vars': {}})
    print(var_1)
    var_2 = action_module_0.run('TMP', {'task_vars': {}, 'provided_arguments': {}})
    print(var_2)

# Generated at 2022-06-25 08:01:26.810787
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_0 = ActionModule()
    argument_spec_0 = dict()
    task_vars_0 = dict()
    var_0 = action_module_0.get_args_from_task_vars(argument_spec_0, task_vars_0)


# Generated at 2022-06-25 08:01:34.278010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)


# Generated at 2022-06-25 08:01:40.990430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    int_0 = 302
    bool_0 = False
    tuple_0 = ()
    bool_1 = False
    bool_2 = True
    str_0 = '\x0bK*Z\tat^Gf\t2$pl#--t8'
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)

    # Stub
    # Stub

# Generated at 2022-06-25 08:01:43.756146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 402
    bool_0 = True
    tuple_0 = ()
    bool_1 = True
    bool_2 = False
    str_0 = ''
    action_module_0 = ActionModule(int_0, bool_0, tuple_0, bool_1, bool_2, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 08:01:54.621667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    runner = RunnerMock()
    action_module = ActionModule(runner)

    task_vars = {
        'argument_spec': {
            'name': {'type': 'String'},
            'number': {'type': 'Integer'}
        },
        'provided_arguments': {
            'name': 'test',
            'number': 'test'
        }
    }

    # Run the test case
    result = action_module.run(None, task_vars)

    # Validate the result
    assert result['failed']
    assert result['msg'] == 'Validation of arguments failed:\nValue test for argument number is not of expected type Integer'
    assert result['argument_spec_data'] == task_vars['argument_spec']