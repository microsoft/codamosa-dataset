

# Generated at 2022-06-25 07:52:04.796809
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tuple_0 = ()

# Generated at 2022-06-25 07:52:15.190763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'1'
    set_0 = set()
    action_module_0 = ActionModule(tuple_0, bytes_0, set_0, set_0, False, bytes_0)
    task_vars_0 = {}

    try:
        action_module_0.run(dict(), task_vars_0)
    except AnsibleError as ansible_error_0:
        if ansible_error_0.message != '"argument_spec" arg is required in args: {}':
            raise AssertionError("Failed: '" + ansible_error_0.message + "' != '" + '"argument_spec" arg is required in args: {}' + "'")


# Generated at 2022-06-25 07:52:23.508634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b"n\xb1\xa6F\xc6\xb7\x8c\xbc\xc6\x9b\x1b\x01\x1b\xc5\x00\xcf\xb6\x97\xc3\x9f\x14\x0e\xc7\xfa\xa6"
    set_0 = set()
    bool_0 = True
    action_module_0 = ActionModule(tuple_0, bytes_0, set_0, set_0, bool_0, bytes_0)
    tmp_0 = None
    task_vars_0 = dict()
    task_vars_0['ansible_check_mode'] = None
    task_vars_0['ansible_current_hosts'] = None


# Generated at 2022-06-25 07:52:34.580787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\xb9\xd8\x96\x80\xeb'
    set_0 = set()
    set_1 = set()
    bool_0 = True
    bytes_1 = b'#H\x04\x95\xc9\xb9\x94'
    action_module_0 = ActionModule(tuple_0, bytes_0, set_0, set_1, bool_0, bytes_1)

    action_module_0.run('tmp', 'task_vars')


# Generated at 2022-06-25 07:52:41.805174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    bytes_0 = b'\x95\xcaI\x92\xdc'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(tuple_0, bytes_0, set_0, set_0, bool_0, bytes_0)
    task_vars = dict()
    try:
        action_module_0.run(None, task_vars)
    except Exception:
        raise Exception


# Generated at 2022-06-25 07:52:49.062703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_1 = ()
    bytes_1 = b'\x9bg\xf6\xc9\xc8\xba'
    set_1 = set()
    set_2 = set()
    bool_1 = False
    bytes_2 = b'v\x11\x82\x92\xe3\xcb'
    test_case_0()


# Generated at 2022-06-25 07:52:53.372243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\xa5\x90\xa9'
    set_0 = set()
    bool_0 = True
    action_module_0 = ActionModule(tuple_0, bytes_0, set_0, set_0, bool_0, bytes_0)



# Generated at 2022-06-25 07:52:56.472450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'dict': {}, 'string': 'string'}
    args = {}
    action_module_1 = ActionModule(args)
    output = action_module_1.run(task_vars=task_vars)
    assert output['failed'] is True
    assert output['msg'] == '"argument_spec" arg is required in args: {}'


# Generated at 2022-06-25 07:53:04.212687
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    tuple_0 = ()
    bytes_0 = b'\x8d\xb1\x0c\xf5\x82\xc0\x95\x9c'
    set_0 = set()
    bool_0 = True
    action_module_0 = ActionModule(tuple_0, bytes_0, set_0, set_0, bool_0, bytes_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0['test'] = dict_1
    value = action_module_0._templar.template(dict_0)
    assert value == dict()


# Generated at 2022-06-25 07:53:06.159408
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    bytes_0 = b'\x1f\xa0\xc7\x8a\xd7\x9f\x1f\x80'
    set_0 = set()
    bool_0 = False
    action_module_0 = ActionModule(tuple_0, bytes_0, set_0, set_0, bool_0, bytes_0)


# Generated at 2022-06-25 07:53:15.134226
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    obj_0 = ActionModule(var_0, var_1, var_2)
    test_case_0()
    test_ActionBase()

# Generated at 2022-06-25 07:53:26.085790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = MockModule(
        load_list=['test_module'],
        run_command_results=[{'stdout': u"{'result': True}", 'rc': 0}]
    )

    task = dict(
        action=dict(
            module='test_module',
            args=dict()
        )
    )

    play_context = dict()

    am = ActionModule(task=task,
            connection=host,
            play_context=play_context,
            loader=host,
            templar=MockTemplar(),
            shared_loader_obj=None)

    result = am.run(task_vars=dict())

    assert result.get('msg') == "The arg spec validation passed"
    assert result.get('failed') is False
    assert result.get('changed') is False


# Generated at 2022-06-25 07:53:36.715858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.network.aos.aos_argument_spec_validator as aos_argument_spec_validator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy.linear import StrategyModule as LinearStrategyModule
    from ansible.plugins.callback.json import CallbackModule as JsonCallbackModule

    # Setup
    results = []
    # Run

# Generated at 2022-06-25 07:53:42.944573
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Assign parameter values
    tmp = None
    task_vars = None

    # Call the method
    result = run(tmp, task_vars)

    # Assert return None
    assert result == None


# Generated at 2022-06-25 07:53:46.332240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_instance = ActionModule()
    assert test_instance.run() == ({'failed': True, 'msg': '"argument_spec" arg is required in args: {}'}, None)


# Generated at 2022-06-25 07:53:49.875868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    tmp = False
    task_vars = {}

    # Setup mock module
    module = ActionModule()
    module.run(tmp, task_vars)


# Generated at 2022-06-25 07:53:52.224057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run()

# class AnsibleValidationErrorMultiple

# Generated at 2022-06-25 07:53:59.883493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule(data=None)
    var_2 = ActionModule(data=b'\x00')
    var_3 = ActionModule(data=b'\x00', temporary_directory=None)
    var_4 = ActionModule(data=b'\x00', temporary_directory=b'\x00')
    var_5 = ActionModule(data=b'\x00', temporary_directory=b'\x00', connection=None)
    var_6 = ActionModule(data=b'\x00', temporary_directory=b'\x00', connection=b'\x00')
    var_7 = ActionModule(data=b'\x00', temporary_directory=b'\x00', connection=b'\x00', shell=None)

# Generated at 2022-06-25 07:54:06.490111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = AnsibleActionModule()
    # Build argument spec
    var_0 = copy.deepcopy(test_data.ENCRYPTED_DATA)
    m_0 = "Incorrect type for argument_spec, expected dict and got {}".format(type(var_0))
    expected = m_0
    result = action_module.run(tmp=None, task_vars=None)
    assert result['msg'] == expected


# Generated at 2022-06-25 07:54:14.754499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # arg1
    arg1 = 'tmp'

    try:
        # Calling the constructor of ActionModule with arg1 = tmp throws a (400) exception
        test_case_0()
    except Exception as e:
        print(e)
        if (e.args[0] == 400):
            raise


# Generated at 2022-06-25 07:54:19.479295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-25 07:54:22.681884
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ()
    try:
        var_1 = test_case_0()
        # assert that the value is what we expect
    except AssertionError as ae:
        print(f"AssertionError: {ae}")


# Generated at 2022-06-25 07:54:26.389817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock
    class Mock(object):
        def __init__(self, *args, **kwargs):
            self.args = kwargs
            self.params = kwargs

    test_object = ActionModule(Mock(task_vars={'var_0': 'test_value_0'}))
    test_object.run()

# Generated at 2022-06-25 07:54:33.082572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ()
    var_1 = {'validate_args_context': {}, 'failed': False, 'argument_spec_data': {'argument_spec': {}, 'module_name': 'validate_arg_spec', 'task_name': 'Validate arg spec'}, 'changed': False, 'argument_errors': []}

    # Execution of the constructor of the class ActionModule
    var_2 = ActionModule(var_0, var_1)
    assert_equals(var_2.action_results, var_1)
    assert_equals(var_2.action_results['argument_errors'], [])
    assert_equals(var_2.action_results['failed'], False)
    assert_equals(var_2.action_results['changed'], False)

# Generated at 2022-06-25 07:54:39.551658
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:54:42.532296
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Test to check if argument is successfully constructed
  print("Test: Test ActionModule constructor")
  try:
    assert_msg = "Test Failed, Value not initialized"
    var_0 = ActionModule()
    assert var_0.name == "Arg Spec Validator", assert_msg
  except AssertionError:
    print(assert_msg)

# Pending test for ActionModule

# Generated at 2022-06-25 07:54:51.652010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Try to run method run with args:
    #  ('tmp', 'task_vars'),
    # This should fail, because 'tmp' is a required arg.
    try:
        ActionModule.run(('tmp', 'task_vars'))
    except AnsibleError as e:
        pass
        # assert isinstance(e, AnsibleError)
        # assert e == "The argument 'tmp' is required"

    # Try to run method run with args:
    #  ('tmp'),
    # This should fail, because 'tmp' is a required arg.
    try:
        ActionModule.run(('tmp'))
    except AnsibleError as e:
        pass
        # assert isinstance(e, AnsibleError)
        # assert e == "The argument 'tmp' is required"

    # Try to run method run with args

# Generated at 2022-06-25 07:54:58.021212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_1 = dict()
    var_2 = dict()
    var_1['module_name'] = 'validate_argument_spec'
    var_1['module_utils'] = dict()
    var_1['module_utils']['basic'] = dict()
    var_1['module_utils']['basic']['Basic'] = ActionModule
    var_2['argument_spec'] = dict()
    var_2['argument_spec']['argument_spec'] = dict()
    var_2['argument_spec']['provided_arguments'] = dict()
    var_2['skip_conditions'] = dict()
    var_2['skip_conditions']['test_result'] = dict()

# Generated at 2022-06-25 07:55:07.708150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = {
        '_ansible_no_log': False,
        'validate_args_context': {
            'entry_point': 'task',
            'task_path': '/home/zamri/python/ansible-runner/tests/functional/v2/gather_facts.yml:3',
        },
    }

    module = AnsibleModule(
        argument_spec=dict(
            argument_spec=dict(type='dict'),
            provided_arguments=dict(type='dict'),
            validate_args_context=dict(type='dict')
        ),
        supports_check_mode=False)

    res_0 = ActionModule(module, params)
    x = {}
    params['validate_args_context'].update(x=x)
    y = {}

# Generated at 2022-06-25 07:55:16.973138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    # Run a unit test for method run of class ActionModule
    # test_case_0
    mock_task = mock.MagicMock(spec_set=dict)

    mock_task_args = mock.MagicMock(spec_set=dict)
    mock_task_args.get.return_value = ()
    mock_task.args = mock_task_args

    mock_task_args_validate_args_context = mock.MagicMock(spec_set=dict)
    mock_task_args_validate_args_context.get.return_value = ()
    mock_task_args['validate_args_context'] = mock_task_args_validate_args_context

    mock_task_args_argument_spec

# Generated at 2022-06-25 07:55:26.307745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    # assert that the object is an instance of the right class
    assert isinstance(action_module_0, ActionModule)
    action_run(set_0, set_0)

# Generated at 2022-06-25 07:55:37.539132
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:55:45.915934
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:55:55.814942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    str_0 = 'argument_spec'
    dict_0 = {str_0: set()}
    str_1 = 'foo'
    str_2 = 'bar'
    dict_1 = {str_1: str_2}
    str_3 = 'action'
    dict_2 = {str_3: dict_1}
    str_4 = 'module'
    dict_3 = {str_4: dict_2}
    str_5 = 'FOO'
    str_6 = 'BAR'
    dict_4 = {str_5: str_6}
    str_7 = 'hostname'
    dict_5 = {str_7: dict_4}
    str_8 = 'fooo'
    str_9 = 'barr'

# Generated at 2022-06-25 07:56:01.893719
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    var_0 = action_get_args_from_task_vars(str_0, set_0)
    assert var_0 == set_0

# Generated at 2022-06-25 07:56:07.209343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'c\x1fA>\x1a\x1b'}
    dict_0 = {'HOSTNAME': '\x1e', 'action': '\x13s\x1f<', 'validate_args_context': {'action': '\x97\x0f\x1d \x0c'}}
    dict_1 = {'f\x1c': dict_0, 'ansible_facts': {'HOSTNAME': '\x1e', 'action': '\x13s\x1f<', 'validate_args_context': {'action': '\x97\x0f\x1d \x0c'}}}

# Generated at 2022-06-25 07:56:12.085104
# Unit test for constructor of class ActionModule
def test_ActionModule():
    p0 = set()
    p1 = dict()
    p2 = dict()
    p3 = b'}\x98\x8a\x8a'
    p4 = dict()
    p5 = p3
    action_module_0 = ActionModule(p0, p1, p2, p3, p4, p5)

if __name__ == '__main__':
    print("unit test")
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:56:16.000479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = {}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    result = action_run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:56:22.591659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r`p'
    set_0 = set()
    bool_0 = False
    list_0 = [bool_0]
    bytes_0 = b'\xd7\x81\xaa'
    dict_0 = {bool_0: bool_0}
    str_1 = 'y'
    bytes_1 = b'\xd7\x81\xaa'
    set_1 = set()
    str_2 = 'validate_args_context'
    str_3 = 'argument_spec'
    str_4 = 'provided_arguments'
    str_5 = 'msg'
    str_6 = 'failed'
    str_7 = 'Incorrect type for argument_spec, expected dict and got %s'
    set_2 = {str_1}
    bytes_2 = b

# Generated at 2022-06-25 07:56:28.395846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    print(str(action_module_0.action_name))
    print(str(action_module_0.display.deprecated))
    print(str(action_module_0.compat_core))
    print(str(action_module_0.connection))
    print(str(action_module_0.display.deprecated_reason))


# Generated at 2022-06-25 07:56:42.278965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'my_test'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    var_0 = action_module_0.run(dict_0, set_0)
# test_case_0()

# Generated at 2022-06-25 07:56:49.845544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)


# Generated at 2022-06-25 07:57:00.938297
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'x', 'PX\xf4\xe2\xbd\xe0', '{s\xb8\x02\xfb\xeb', 'q\x04\xc3\xb4\xee', 'HOSTNAME'}

# Generated at 2022-06-25 07:57:06.480187
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '@'
    int_0 = 101
    float_0 = float(int_0)
    list_0 = []
    list_1 = [str_0]
    list_2 = [int_0]
    list_3 = [float_0]
    list_4 = [str_0] + list_1 + list_2 + list_3
    dict_0 = {}
    dict_1 = {str_0: list_0}
    dict_2 = {str_0: list_1}
    dict_3 = {str_0: list_2}
    dict_4 = {str_0: list_3}
    dict_5 = {str_0: list_4}
    dict_6 = {str_0: dict_1}

# Generated at 2022-06-25 07:57:14.315777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'd\x88\x8a\x9b\x9a'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 07:57:20.730902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'COUNT'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'U\xea\xdb\x82'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    test_case_0()
    str_1 = 'COUNT'
    set_1 = {str_1}
    bool_1 = True
    list_1 = [bool_1]
    bytes_1 = b'U\xea\xdb\x82'
    dict_1 = {bool_1: bytes_1}

# Generated at 2022-06-25 07:57:29.918018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    assert not action_module_0.transfers_files

# Generated at 2022-06-25 07:57:41.017301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x82\xbf\xd7'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    # str_1 = '\x82\xbf\xd7'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    action_module_0.run(set_0, set_0)
    action_module_0.run(set_0, set_0)
    action_module_0.run(set_0, set_0)

# Generated at 2022-06-25 07:57:41.836569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:57:50.152276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    assert action_module_0._connection == bool_0
    assert action_module_0._display == list_0
    assert action_module_0._load_name == list_0
    assert action_module_0._task == bytes_0
    assert action_module_0._templar == dict_0
    assert action_module_0._loader == bytes_0



# Generated at 2022-06-25 07:58:18.931708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0) # init of class ActionModule
    bool_1 = True
    action_module_0.run(set_0, set_0) #calling method run of class ActionModule
    action_module_0.run(set_0, set_0)


# Generated at 2022-06-25 07:58:22.772600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for the constructor of class ActionModule
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_1 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)


# Generated at 2022-06-25 07:58:24.982234
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:58:29.437010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'vpn_connection_name'
    set_1 = {str_1}
    bool_1 = True
    list_1 = [bool_1]
    bytes_1 = b'U\xbb\xb8\x9f\xad\xa0\xcb\x8c\x98\xe6\x98\xb7\x8b\x9fY'
    dict_1 = {str_1: set_1}
    action_module_1 = ActionModule(bool_1, list_1, list_1, bytes_1, dict_1, bytes_1)
    var_1 = action_run(set_1, dict_1)


# Generated at 2022-06-25 07:58:37.888631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Y\x94\xe8\xa5\x91D\x91\xa5{N'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'\xaf\xb3\xbd\xca\xbb\xa1\xcd\xe6'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    dict_1 = dict()
    dict_2 = dict()
    dict_2['argument_spec'] = dict_1
    dict_2['provided_arguments'] = dict_1

# Generated at 2022-06-25 07:58:41.954041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'HOSTNAME'
    bool_0 = bool()
    list_0 = list()
    dict_0 = dict()
    action_module_0 = ActionModule(str_0, bool_0, list_0, list_0, dict_0, dict_0)


# Generated at 2022-06-25 07:58:49.645220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '{\xfb\x0b\x89\xb8\xfc'
    str_1 = '=\x1d'
    str_2 = 'o\xfb\x04\x96\xf7\xf9'
    int_0 = 0
    bytes_0 = b';\xb2\xca\x8f\xb7'
    str_3 = '\x8dv\x91\xda\x96\xba'
    int_1 = -1588337017

# Generated at 2022-06-25 07:59:00.101675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(dict_0, set_0, dict_0, dict_0, dict_0, dict_0)
    action_module_1 = ActionModule(dict_0, set_0, dict_0, dict_0, dict_0, dict_0)
    action_module_2 = ActionModule(dict_0, set_0, dict_0, dict_0, dict_0, dict_0)
    action_module_3 = ActionModule(dict_0, set_0, dict_0, dict_0, dict_0, dict_0)
    action_module_4 = ActionModule(dict_0, set_0, dict_0, dict_0, dict_0, dict_0)

# Generated at 2022-06-25 07:59:10.583268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '8=\x97\xd0\xce\xb1\x8e'
    str_1 = '<>q\x85\x99\t\xdf\xbf\x9f\x9d^\x82\xba\xee\xc6\x98'
    bytes_0 = b'q\x82\xbbO\x91\xca\x92\xdb\xa7'
    bytes_1 = b'\xd2\x9b\xd4n\xca\x92'
    dict_0 = {str_0: bytes_1}
    dict_1 = {str_1: dict_0}
    list_0 = [dict_1]
    list_1 = [list_0]

# Generated at 2022-06-25 07:59:15.823656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\r\r\r'
    list_0 = [str_0]
    set_0 = {str_0}
    bool_0 = False
    bytes_0 = b'W\x8e\x96\xb0\xab\x8f\x97\x9d\x9e\x8b\xb8\x83\xbd\x81\x83\x8c\xa9\x9e\x94\x98\x8d\xb4\x8a\x96\xac\x9e'
    dict_0 = {bytes_0: bool_0}

# Generated at 2022-06-25 07:59:56.116378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    var_0 = action_module_0.run()
    assert var_0 is not None
    assert var_0['failed'] == False
    assert var_0['changed'] == False
    assert var_0['msg'] == 'The arg spec validation passed'

# Generated at 2022-06-25 08:00:04.548083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x1f\x97\x08'
    str_1 = '\x87\xe2(\xb0t\x9d\x11\x81\x8a\x0f'
    str_2 = '\x8b\x1e\xae'
    str_3 = '\x11\x83\x04\r\r\r'
    bool_0 = bool(len(str_2))
    list_0 = [str_3]
    tuple_0 = (len(str_1), bool_0)
    dict_0 = {str_2: str_0}
    str_4 = '\x98\x9d\xfd\x0f'

# Generated at 2022-06-25 08:00:05.418064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True
  # TODO: Implement test


# Generated at 2022-06-25 08:00:10.664785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    action_module_0.run(bytes_0, set_0)

# Generated at 2022-06-25 08:00:11.171044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 08:00:21.385675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    assert (not action_module_0.TRANSFERS_FILES)
    assert (action_module_0._play_context.become_pass == list_0)
    assert (action_module_0._play_context.become_user == bytes_0)
    assert (action_module_0._play_context.remote_user == list_0)
    action

# Generated at 2022-06-25 08:00:27.577294
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    str_0 = 'HOSTNAME'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'}\x98\x8a\x8a'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    var_0 = action_get_args_from_task_vars(str_0, set_0)


# Generated at 2022-06-25 08:00:32.589695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '4W'
    set_0 = {str_0}
    bool_0 = True
    list_0 = [bool_0]
    bytes_0 = b'\xda\x91\xac\xc6'
    dict_0 = {bool_0: bytes_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    assert action_module_0 is not None


# Generated at 2022-06-25 08:00:35.339300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = '/tmp/find-on-path'
    task_vars_0 = {tmp_0}
    action_module_0 = ActionModule(bool_0, list_0, list_0, bytes_0, dict_0, bytes_0)
    var_0 = action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 08:00:41.830967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ','
    str_1 = 's='
    str_2 = 'D4P4'
    str_3 = '#x$@\x7f#\x12\x7f2'
    list_0 = ['', 'D.Ft-Qh)', 'M7\x17\x1d7\x14\x9f', '3', '|* j\x02\xdd\x93\xde\xef\xdb', 'K\x9d@\xcc\x18\xdf\x13\xbe', '2~']
    list_1 = ['\x9c\xec\xeb\xcd\xad\xa5Y', '', '5']