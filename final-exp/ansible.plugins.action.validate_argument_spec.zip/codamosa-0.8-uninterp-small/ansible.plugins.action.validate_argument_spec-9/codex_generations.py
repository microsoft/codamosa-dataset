

# Generated at 2022-06-25 07:52:15.551213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = './I+2G]~6f:U6w$='
    str_1 = 'G5+5R5]'
    str_2 = 'J="h=S\\l+~'
    set_0 = {str_0, str_1, str_2}
    dict_0 = {str_0: str_1}
    dict_1 = {str_2: dict_0}
    dict_2 = {str_0: dict_1}
    bool_0 = False
    action_module_0 = ActionModule(str_0, bool_0, bool_0, set_0, dict_2, str_1)
    assert action_module_0.task._parent._parent._parent.__class__.__name__ == 'Play'
    assert action_module_0.task._parent._

# Generated at 2022-06-25 07:52:22.249362
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'hN>&;b/%9*7B_fh'
    bool_0 = True
    set_0 = {str_0, bool_0}
    bytes_0 = b'\t'
    str_1 = 'T2w[*U\\~?=BW~s5'
    # Test with invalid_argument_spec
    action_module_2 = ActionModule(str_0, bool_0, str_0, set_0, bytes_0, str_1)
    action_module_2.run(str_0, set_0)


# Generated at 2022-06-25 07:52:27.419534
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '*qk?-1Qa;{'
    bool_0 = False
    set_0 = {str_0, bool_0}
    bytes_0 = b'a'
    str_1 = '<I{+'
    action_module_0 = ActionModule(str_0, bool_0, str_0, set_0, bytes_0, str_1)
    if action_module_0 != None:
        print('action_module_0 != None')
    else:
        print('action_module_0 == None')


# Generated at 2022-06-25 07:52:33.910276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'hN>&;b/%9*7B_fh'
    bool_0 = True
    set_0 = {str_0, bool_0}
    bytes_0 = b'\t'
    str_1 = 'T2w[*U\\~?=BW~s5'
    action_module_0 = ActionModule(str_0, bool_0, str_0, set_0, bytes_0, str_1)
    argument_spec__0 = {str_1: set_0}
    provided_arguments__0 = {str_1: set_0}
    dict_0 = {str_1: set_0}
    dict_1 = {'validate_args_context': dict_0}

# Generated at 2022-06-25 07:52:36.828936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    assert True

# Generated at 2022-06-25 07:52:37.812424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 07:52:43.388359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure the class is instantiated correctly
    action_module_0 = ActionModule()

    # Make sure that the data types are correct
    assert(isinstance(action_module_0, ActionModule))

    # Run test case
    test_case_0()


# Generated at 2022-06-25 07:52:47.674757
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_0 = ActionModule()

    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:52:53.551023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    argument_spec = dict()
    provided_arguments = dict()
    tmp = None
    task_vars = dict()
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:53:03.745246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'nl]_pG"I$|wzj+#2'
    bool_0 = True
    str_1 = '#2\\3Ta`%K64)z$h*'
    set_0 = {str_1, bool_0}
    bytes_0 = b'\r'
    str_2 = 'u/b1xV5]OQD0I &9'
    action_module_0 = ActionModule(str_0, bool_0, str_0, set_0, bytes_0, str_1)
    tmp_0 = None
    task_vars_0 = {str_2: str_0, str_1: str_1, str_0: bytes_0}
    result = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:53:16.566540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(test_case_0)
    var_0 = 'Argvalidated'
    action_module_0.run(var_0, var_0)


# Generated at 2022-06-25 07:53:26.218928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'0\x0b\x12\xf1'
    str_0 = 'n_'
    bool_0 = True
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0, bytes_0]
    dict_0 = {bytes_0: str_0, bytes_0: bytes_0, bytes_0: str_0, bytes_0: bytes_0}
    tuple_0 = (bytes_0, str_0, bytes_0, bytes_0, str_0)
    action_module_0 = ActionModule(bool_0, str_0, list_0, str_0, dict_0, tuple_0)


# Generated at 2022-06-25 07:53:36.865606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'j\x12\x1a\x9f\x8b\xf0'
    str_0 = '\x8f\x07\xe9\x1d\xa3&'
    dict_0 = {bytes_0: bytes_0, bytes_0: str_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = False
    list_0 = ['S]\x0b\xdd', str_0, str_0, 'E>\x1e', '\xabZ\x9e\x9f\x88']
    dict_1 = {str_0: str_0, str_0: str_0, str_0: bytes_0, str_0: str_0}

# Generated at 2022-06-25 07:53:46.124759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'mY|\x19N\\\x1e\x07A9(*\x0c6U\x07'
    list_0 = [bool_0]
    str_1 = '\r@r\r(:J'
    dict_0 = {str_0: bool_0, str_0: bool_0, str_1: bool_0, str_0: bool_0}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_0, list_0, str_1, dict_0, tuple_0)

if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-25 07:53:56.497567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    # check for exception when invalid type for tmp
    str_0 = 'Power1'
    int_0 = 0
    list_0 = [str_0]
    tuple_0 = ()
    dict_0 = {str_0: str_0, str_0: int_0, str_0: tuple_0, str_0: list_0}
    try:
        action_module_0.run(tmp=dict_0)
    except Exception:
        pass
    # check for exception when invalid type for task_vars
    str_1 = ' \x0e>#"'
    int_1 = 0
    list_1 = [str_1]
    tuple_1 = ()

# Generated at 2022-06-25 07:54:08.023291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'changed': False, 'msg': 'The arg spec validation passed'}
    dict_1 = {'default': None, 'required': True, 'type': 'list'}
    dict_2 = {'default': None, 'required': False, 'type': 'dict'}
    dict_3 = {'foo': dict_2, 'bar': dict_0}
    dict_4 = {'required': True, 'type': 'list'}
    dict_5 = {'required': True, 'type': 'bool', 'default': False}
    dict_6 = {'name': dict_5, 'arg2': dict_4}
    dict_7 = {'required': False, 'type': 'str'}

# Generated at 2022-06-25 07:54:15.208239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'3\x9c\x87\x9e\xab\x1b\x04m'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bool_0: str_1}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)



# Generated at 2022-06-25 07:54:26.429398
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    int_0 = 0
    str_2 = '\x0c\x0cG\x11k\x11\x1b\x1dk|\x1c\x16\x11\x14k}'
    dict_3 = {}
    bytes_1 = b'y\x1d\x03\x05\x08\x01\x0c\x1a\x1cO\x0c\x10\x1a\x0c\x11\x13'
    list_1 = []
    action_module_1 = ActionModule(None, None, None, None, None, None)
    var_1 = action_module_1.get_args_from_task_vars(dict_3, dict_3)


# Generated at 2022-06-25 07:54:29.762914
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    # Try to get an instance of ActionModule.
    action_module = ActionModule()

    try:
        action_module.run()
    except TypeError as e:
        print("TypeError: {}".format(e))


# Generated at 2022-06-25 07:54:36.899329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = '\x1a&'
    list_0 = [str_0]
    str_1 = '\\'
    dict_0 = {str_1: bool_0}
    tuple_0 = ()
    tuple_1 = (bool_0,)
    tuple_2 = (bool_0, str_0)
    tuple_3 = (bool_0, bool_0, bool_0)
    tuple_4 = (bool_0, bool_0, bool_0, bool_0)
    action_module_0 = ActionModule(bool_0, str_0, list_0, str_1, dict_0, tuple_0)
    action_module_1 = ActionModule(bool_0, str_0, list_0, str_1, dict_0, tuple_1)

# Generated at 2022-06-25 07:54:51.437460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bool_0: str_1}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)
    var_0 = action_

# Generated at 2022-06-25 07:54:56.409854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    int_0 = 0
    str_0 = 'N^\x1bX\xf9\xed\xce\xc3s\x8c'
    str_1 = ' \\aP+&*\x0c k5|'
    str_2 = '\\aP+&*\x0c k5|'
    str_3 = 'l\x02\xb5\x89\x8d\x99\xe3\x1a\x19\xd9\xe4\xa4\xeb\xc4'

# Generated at 2022-06-25 07:55:06.745636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bool_0: str_1}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)
    var_0 = action_

# Generated at 2022-06-25 07:55:16.563054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = 'rN+'
    bool_0 = True
    str_2 = 'I\x17\x9a'
    list_0 = [bool_0, bool_0, bool_0]
    bytes_0 = b'\x9fD\x8c('
    int_0 = 2
    str_3 = '8+\t*\x9bX^\x00\x8a\x1a\x88\x7f^\x8d\x16\x9c\x15P'
    tuple_0 = (str_2, str_2, str_1, str_3, int_0, list_0, str_3, str_3, int_0)
    str_4 = '2m'

# Generated at 2022-06-25 07:55:25.106926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_run_0 = action_module_0.run()
    for question in action_module_0.module_compile.errors:
        action_module_0.module_compile.errors[question]
        with action_module_0.module_compile:
            init_action = action_module_0.init_action
            action_run_1 = action_module_0.run()
    action_module_0.module_compile.header = action_module_0.module_compile.header
    action_module_0.module_compile.template = action_module_0.module_compile.template
    action_module_0.module_compile.question = action_module_0.module_compile.question
    action_module_0.module_compile

# Generated at 2022-06-25 07:55:32.892404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = None
    task_vars = dict()
    var_0 = action_module_0.run(tmp, task_vars)
    bool_0 = None
    str_0 = None
    list_0 = None
    str_1 = None
    dict_0 = None
    tuple_0 = ()

# Generated at 2022-06-25 07:55:42.468379
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    exception_0 = AnsibleValidationErrorMultiple()
    exception_1 = AnsibleValidationErrorMultiple()
    exception_2 = AnsibleValidationErrorMultiple()
    exception_3 = AnsibleValidationErrorMultiple()
    exception_4 = None
    exception_5 = AnsibleValidationErrorMultiple()
    exception_6 = Exception()
    exception_7 = None
    exception_8 = AnsibleValidationErrorMultiple()
    exception_9 = AnsibleValidationErrorMultiple()
    exception_10 = AnsibleValidationErrorMultiple()
    exception_11 = Exception()
    exception_12 = AnsibleValidationErrorMultiple()
    exception_13 = None
    str_0 = None
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}

# Generated at 2022-06-25 07:55:48.294751
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:55:53.856198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Undecided on whether to test it
    # TODO: test what it does with the variables it is passed
    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.args = dict(*args, **kwargs)
    TestModule(my_var='my_value', other_var='other_value')


# Generated at 2022-06-25 07:56:04.488332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    result = super(ActionModule, self).run(tmp, task_vars)
    assert result is not None
    del tmp
    result = super(ActionModule, self).run(tmp, task_vars)
    assert result is not None

    result = super(ActionModule, self).run(tmp, task_vars)
    assert result is not None

if __name__ == "__main__":
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:56:26.395926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'x\x1d\xaf\xbc\x18\xa3\x14Q'
    str_0 = ''
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = False
    str_1 = '1'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bytes_0: dict_0}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)
    assert action_module_0.transfer_files == False

# Generated at 2022-06-25 07:56:34.821426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'bg\x0e\x1a'
    str_0 = None
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [str_1]
    dict_0 = {bytes_0: bytes_0, bytes_0: str_0, bytes_0: str_1, bytes_0: str_0}
    bool_0 = True
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_0, tuple_0)
    action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 07:56:45.024233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bool_0: str_1}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)


# Generated at 2022-06-25 07:56:48.097344
# Unit test for constructor of class ActionModule
def test_ActionModule():
  tmp = 'tmp'
  task_vars = 'task_vars'
  action_module_0 = ActionModule(tmp, task_vars)
  assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:57:00.890734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x91\x12\xa2\x0cD\xbdL'
    str_0 = '1hWn'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0, bytes_0: bytes_0}
    bool_0 = True
    str_1 = 'X\x1a\x93\xc8\x15&"\x1du'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0, bytes_0]
    dict_1 = {str_1: str_1, str_1: bytes_0, str_1: str_0, bytes_0: bytes_0}

# Generated at 2022-06-25 07:57:09.580938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    bool_0 = True
    str_0 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_0 = {}
    tuple_0 = ()
    dict_1 = {}
    dict_2 = {bytes_0: bool_0, str_0: str_0, bytes_0: bool_0, bool_0: str_0}
    tuple_1 = ()
    tuple_2 = ()
    tuple_3 = ()
    tuple_4 = ()
    tuple_5 = ()
    tuple_6 = ()
    tuple_7 = ()
    tuple_8 = ()
    tuple_9 = ()
    tuple_10 = ()
    tuple_11

# Generated at 2022-06-25 07:57:20.144785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 't.x7V\x84\x04\x8e\x8a\xbf'
    list_0 = []
    str_1 = '-\x0e\xaa\x94\x84\x1e\xb5\x86\x9c\xfd\x0f<\x8e'
    dict_0 = {str_1: str_0, str_0: str_0, str_1: str_1, str_0: str_0}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_0, list_0, str_1, dict_0, tuple_0)
    tmp = None
    task_vars = {}
    test_ActionModule_run_0 = action_module

# Generated at 2022-06-25 07:57:31.696326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bool_0: str_1}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)
    var_0 = action_

# Generated at 2022-06-25 07:57:43.164251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1d\xe4\x88\x1e\x9e\x14\x8a\x91\x10\xf7\xd5\xa3\x93\x1a\x16\x9c'
    str_0 = 'if'
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = 'tra$E\x14n\x00\x1a\xdc\xd9\x1b\x83'
    list_0 = [bool_0]

# Generated at 2022-06-25 07:57:51.172237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing for AnsibleError
    bytes_0 = b'\x9a\xd4\xdb\xa8\xa4\xae\x1f\xcc\xd3\x0d'
    bytes_1 = b'\x10\xe1\xcc\xd0\x15\xa8\x9d\x9e\xe0\xdb\x97\x15'
    str_0 = ' \xc7m\xdaE\x9a\x97\xf3\xaa\x92\x99\xa8\x94'
    str_1 = 'r\x80\x15\xf1\xc6\xe6\x99'

# Generated at 2022-06-25 07:58:37.408813
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bytes_0 = b'!'
    str_0 = None
    str_1 = 'r\n'
    list_0 = []
    str_2 = ';c`\x7f\x17\t'
    str_3 = ' \x0f*Z\t\x10'
    dict_0 = {str_1: str_0, str_2: str_3, str_2: str_2}
    tuple_0 = (str_2, str_2)
    action_module_0 = ActionModule(True, '4', list_0, str_1, dict_0, tuple_0)

# Generated at 2022-06-25 07:58:44.767694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    # action_module_run_0 = ActionModule(True, '\\aP+&*\x0c k5|', [True], '\\aP+&*\x0c k5|', {' \\aP+&*\x0c k5|': True, ' \\aP+&*\x0c k5|': ' \\aP+&*\x0c k5|', ' \\aP+&*\x0c k5|': True, True: ' \\aP+&*\x0c k5|'}, ())
    # assert action_module_run_0.run(tmp, task_vars) == dict({'argument_spec_data': {b'y\x99\x16f\x17\xf33\x89': b'

# Generated at 2022-06-25 07:58:50.176443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 't\x17g\x1b\x0bI\x18\x09'
    bool_0 = False
    tuple_0 = ()
    str_1 = 'z\t\x1b\x05\x0b\x05\x00\r'
    str_2 = 'm\x1f!\x1a\x0bu\x00\x16\x00'
    str_3 = '\x1e\tX\x0b\x19\x1b'
    str_4 = '\x1c\x1d\x02'
    dict_0 = {str_0: str_1, str_2: str_3, str_4: str_1}
    tuple_1 = ()

# Generated at 2022-06-25 07:58:58.593624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    str_0 = 'p66e3q0M0j'
    str_1 = 'x'
    str_2 = 'K\r8@'
    dict_1 = {str_2: str_2, str_1: str_1, str_0: str_0, str_1: str_1}
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)


# Generated at 2022-06-25 07:59:02.887600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # AssertionError: Unable to find 'validate_arg_spec' in '{'changed': False, 'msg': 'The arg spec validation passed', 'validate_arg_spec_context': {}}
    assert 'validate_arg_spec' in dict_0.keys()
    # AssertionError: Unable to find 'validate_arg_spec_context' in '{'changed': False, 'msg': 'The arg spec validation passed', 'validate_arg_spec_context': {}}
    assert 'validate_arg_spec_context' in dict_0.keys()


# Generated at 2022-06-25 07:59:10.955189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x06\x0b\xf3\x8b5\x1f\x9b\x9b\x8b'
    str_0 = ':6>E_n\x1c\x1dS\x1c\x1f\x13\x1d\x0bZ\x05\x0f\x16h\x08\x1c\t\x1b'
    dict_0 = {bytes_0: str_0, str_0: bytes_0, bytes_0: bytes_0}
    list_0 = []
    str_1 = '1'

# Generated at 2022-06-25 07:59:22.847288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'6\xbf\xd0\xe6\xdc\xa4c\xf7'
    str_0 = '- &?$'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0]
    str_1 = None
    dict_0 = {bytes_0: str_1, str_0: bytes_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    str_2 = 'O\x9a$\x1d\x19*\x8du\xdc'
    tuple_0 = ()

# Generated at 2022-06-25 07:59:30.325394
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:59:40.881920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bool_0: str_1}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)

# Generated at 2022-06-25 07:59:46.006319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    str_0 = 'J3'
    dict_1 = {}
    tuple_0 = (str_0, dict_1, list_0, dict_1, dict_1)
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)
    assert action_module_0.TRANSFERS_FILES == False


# Generated at 2022-06-25 08:01:10.788688
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 08:01:20.046424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    bytes_1 = b'\xc0\x1f\x04\xf6\xaa\xec\x1b'
    bytes_2 = b'\x89\xcb\xef\x15\xb5\xa1\x16\xcc'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_2, bytes_1: bytes_0, bytes_2: str_0}
    bool_0 = True
    str_1 = '%\x1f\x9f\xf4\x16\x94\x12\xfe'
    list_0 = [bool_0]

# Generated at 2022-06-25 08:01:27.826709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'I'
    str_0 = '1\\'
    bool_0 = True
    str_1 = 'Z\xab'
    list_0 = [bool_0]
    dict_0 = {str_1: bool_0}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_0, tuple_0)
    tmp = None
    task_vars = None
    action_result_0 = action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 08:01:32.869575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bool_0: str_1}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)

# Generated at 2022-06-25 08:01:37.384929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict_22 = dict()
    dict_23 = dict()
    dict_24 = dict()

# Generated at 2022-06-25 08:01:38.162322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 08:01:43.897597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    str_0 = None
    dict_0 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: str_0}
    bool_0 = True
    str_1 = ' \\aP+&*\x0c k5|'
    list_0 = [bool_0]
    dict_1 = {str_1: bool_0, str_1: str_1, str_1: bool_0, bool_0: str_1}
    tuple_0 = ()
    action_module_0 = ActionModule(bool_0, str_1, list_0, str_1, dict_1, tuple_0)

# Generated at 2022-06-25 08:01:54.621561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9c\xf4\x87\x90\xdf\xbf\xa7V\xa1\x95'
    dict_0 = {}
    dict_1 = {bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0, bytes_0: bytes_0}
    bool_0 = True
    str_0 = 'k\x9c\xf7\x81\x92\x8b1\x93\x94\x0f\x8a'
    list_0 = [False]
    dict_2 = {str_0: bytes_0, str_0: str_0, str_0: bytes_0, bool_0: str_0}
    tuple_0 = ()

# Generated at 2022-06-25 08:01:59.527690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'y\x99\x16f\x17\xf33\x89'
    str_0 = ' #{'
    int_0 = 1
    list_0 = [' PqB\n$', 'U}2{g\x0e', False, False, 40, False]
    bool_0 = False
    str_1 = '\x0bP\x19F&;'
    tuple_0 = (bytes_0, bytes_0, bytes_0, bytes_0)
    tuple_1 = ()
    tuple_2 = (False, 40, True, '\\n\x15|', False, False, True, 'jQ5:W]*')