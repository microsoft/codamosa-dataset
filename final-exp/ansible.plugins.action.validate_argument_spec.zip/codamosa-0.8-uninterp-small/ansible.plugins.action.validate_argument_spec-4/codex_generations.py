

# Generated at 2022-06-25 07:52:02.591495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The following testcase causes an exception to be raised.
    #raise NotImplementedError('Test not implemented.')
    pass

# Generated at 2022-06-25 07:52:05.517542
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    int_0 = 5932
    action_module_0 = ActionModule(list_0, bool_0, int_0, bool_0, list_0, int_0)
    assert(isinstance(action_module_0, ActionModule))


# Generated at 2022-06-25 07:52:15.671274
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:52:16.983228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    # TODO: Implement unit test
    assert True == True

test_case_0()

# Generated at 2022-06-25 07:52:22.686789
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    int_0 = 9752
    action_module_0 = ActionModule(list_0, bool_0, int_0, bool_0, list_0, int_0)
    try:
        action_module_0.run()
    except Exception as exception_0:
        print(exception_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:52:32.605866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    int_0 = 5932
    action_module_0 = ActionModule(list_0, bool_0, int_0, bool_0, list_0, int_0)
    assert action_module_0.AUTHOR_OPTION is True
    assert action_module_0.__module__ is '__main__'
    assert action_module_0.BOOLEANS_TRUE is ['yes', 'on', '1', 'true', 'True', 'TRUE', 'Yes', 'YES', 'On', 'ON', 'onen', 'ONEN', 'one']
    assert action_module_0.BYPASS_HOST_LOOP is False
    assert action_module_0.SUPPORTED_FILT

# Generated at 2022-06-25 07:52:39.872120
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    int_0 = 5932
    action_module_0 = ActionModule(list_0, bool_0, int_0, bool_0, list_0, int_0)
    assert action_module_0._display.verbosity >= 0



# Generated at 2022-06-25 07:52:42.344438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()

    ret_obj = ActionModule.run(tmp, task_vars)
    print(type(ret_obj))

# Generated at 2022-06-25 07:52:51.720501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = [bool_0, bool_0, bool_0, bool_0]
    int_0 = 6787
    action_module_0 = ActionModule(list_0, bool_0, int_0, bool_0, list_0, int_0)

    str_0 = 'Z'
    str_1 = 't0+{=('
    str_2 = 'fJ_;'
    dict_0 = {
        'x': str_2,
        'c': str_0,
        str_1: str_0
    }
    dict_1 = {
        'y': str_0,
        'a': str_2,
        't': str_2,
        str_0: str_0
    }

# Generated at 2022-06-25 07:52:58.037705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # input arguments
    tmp = null
    task_vars = null

    # test case 0
    action_module_0 = ActionModule(tmp, task_vars)
    result = action_module_0.run()
    assert(result['failed'] == bool)
    assert(result['msg'] == str)
    assert(result['changed'] == bool)
    assert(result['validate_args_context'] == dict)
    assert(result['argument_spec_data'] == dict)
    assert(result['argument_errors'] == list)

# Generated at 2022-06-25 07:53:05.486381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a instance of class ActionModule with given arguments
    float_0 = 2.0
    bool_0 = True
    int_0 = 136
    int_1 = 7
    bool_1 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, bool_1, list_0)

    task_vars_0 = dict()
    # Run method run of action_module_0
    action_module_0.run(None, task_vars_0)


# Generated at 2022-06-25 07:53:12.823564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Xj|'
    float_0 = 0.7
    float_1 = float_0
    str_1 = '-k6'
    float_2 = 1.11
    str_2 = 'g5'
    int_0 = 59
    float_3 = float_0
    int_1 = int_0
    str_3 = str_2
    argument_spec_data = {str_2: {str_2: [int_1, float_2], str_0: float_0, str_3: float_1}, str_1: {str_1: [float_2, str_0]}, str_0: {str_3: [int_1, str_1]}}
    argument_spec_0 = argument_spec_data

# Generated at 2022-06-25 07:53:14.276700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:53:21.122243
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    float_0 = 0.819473061433
    int_0 = 0
    bool_0 = True
    list_0 = [float_0, int_0]
    str_0 = 'cJ:g$}'
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    bool_1 = action_module_0.get_args_from_task_vars(str_0, bool_0)
    assert bool_1


# Generated at 2022-06-25 07:53:23.115577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance
    action_module_0 = ActionModule()

    # Call method run with all expected parameters
    action_module_0.run()



# Generated at 2022-06-25 07:53:32.510065
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True

# Generated at 2022-06-25 07:53:36.334592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    action_module_run(tmp, task_vars)


# Generated at 2022-06-25 07:53:46.669678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    # Getting already templated vars from AnsibleTaskObject
    var_0 = action_module_0._task.args.get('var_0')
    var_1 = action_module_0._task.args.get('var_1')
    arg_0 = action_module_0._task.args.get('arg_0')
    arg_1 = action_module_0._task.args.get('arg_1')
    arg

# Generated at 2022-06-25 07:53:55.075570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = False
    task_vars = True
    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_module_0.run(tmp, task_vars)



if __name__ == '__main__':
    import sys
    import csv
    data_file = open('../data/imdb.csv', 'r')
    data = csv.reader(data_file)
    for row in data:
        if row[2] == 'Movie':
            print('%s: %s.'%(row[0], row[1]))

# Generated at 2022-06-25 07:54:03.105068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '^<b}r=&'
    int_0 = 143
    bool_0 = False
    list_0 = [int_0, bool_0, int_0]
    action_module_0 = ActionModule(int_0, bool_0, int_0, int_0, bool_0, list_0)
    var_0 = action_module_0.run(str_0)

# Generated at 2022-06-25 07:54:22.426326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize the test variables
    str_0 = 'E<wf3F4+'
    float_0 = 8.0
    int_0 = 8
    bool_0 = True
    float_1 = 3.0
    int_1 = 3
    bool_1 = True
    str_1 = '2<|?w+([>'
    float_2 = 87.0
    int_2 = 41
    bool_2 = True
    str_2 = 'J|,?+<:,'
    float_3 = 1.0
    int_3 = 1
    bool_3 = True
    int_4 = 67
    bool_4 = False
    str_3 = 'k-j=HZ5B'
    float_4 = 6.0
    int_5 = 6
    bool_5 = False

# Generated at 2022-06-25 07:54:29.761746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ','
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)


# Generated at 2022-06-25 07:54:36.728271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize host_vars with data
    host_vars = dict()

    task_vars = dict()

    # Initialize a mock of class TaskExecutor
    class TaskExecutorMock:
        def __init__(self):
            self._task = 0

        def get_task_vars(self, _0):
            dict(zip(['_0'], [_0]))
            return task_vars

    class ModuleDeprecationWarningMock:
        def __init__(self):
            self.msgs = dict()

        def __call__(self, msg):
            self.msgs[msg] = msg

    task_executor = TaskExecutorMock()
    module_deprecation_warning = ModuleDeprecationWarningMock()

    # Initialize an action module

# Generated at 2022-06-25 07:54:46.282716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 100
    list_0 = ['b', 'f', 'A', 't', 'p', 'o']
    str_0 = 'bRg8f<'
    float_0 = 7.274566179544623e-05
    bool_0 = True
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    action_module_0.run(str_0, list_0)


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:54:47.890986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError):
        ActionModule()


# Generated at 2022-06-25 07:54:54.819289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)

    # Test case with no options
    args = {}
    expected = {"msg": 'Module show is not supported on target hosts', "skipped": True, "failed": False}
    result = action_module_0.run(**args)
    assert result == expected

    # Test case with only required options
    args = {"argument_spec": {"type": "dict"}, "provided_arguments": {"name": "foo"}}

# Generated at 2022-06-25 07:54:59.237896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 5.5
    bool_0 = True
    int_0 = 5
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, bool_0)


# Generated at 2022-06-25 07:55:05.144239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool
    str_0 = 'v'
    bool_1 = bool
    dict_0 = {}
    dict_1 = {}
    action_module_0 = ActionModule(bool_0, str_0, bool_1, dict_0, dict_1, dict_1)
    action_module_0.run()
    # Expected exception: SyntaxError


# Generated at 2022-06-25 07:55:06.049491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Run a test case
    test_case_0()


# Generated at 2022-06-25 07:55:12.029712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 89
    list_0 = [bool_0, int_0, int_0]
    float_0 = 88.0
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    bool_0 = action_module_0.run(bool_0)

# Generated at 2022-06-25 07:55:30.087600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _action = ActionModule(None, {}, None, None, [], [])
    assert isinstance(_action, ActionModule)


# Generated at 2022-06-25 07:55:38.332493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '^l3q\t)zZdG/'
    float_0 = 1.0
    int_0 = 26
    bool_0 = True
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    str_1 = 'U&;A\'P8W'
    float_1 = 5.0
    int_1 = 136
    bool_1 = False

# Generated at 2022-06-25 07:55:43.742461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 697
    dict_0 = dict()
    action_module_0 = ActionModule(bool_0, str_1, list_0, int_0, dict_0, dict_0)
    str_0 = action_module_run(str_1, dict_0)
    assert str_0 is not None


# Generated at 2022-06-25 07:55:48.186665
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    tmp_0 = None
    task_vars_0 = dict()
    result_0 = action_module_1.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:55:52.743279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test if ActionModule class is instantiated")
    arg0 = True
    arg1 = False
    arg2 = 68
    instance0 = ActionModule(arg0, arg1, arg2, arg2, arg0, [])
    assert isinstance(instance0, ActionModule)


# Generated at 2022-06-25 07:56:03.488351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    action_module_0.run(str_0, bool_0)


# Generated at 2022-06-25 07:56:11.516135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]

    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)

    result = action_module_0.run(str_0, str_0)

    assert result['failed'] == True
    assert result['msg'] == '"argument_spec" arg is required in args: {}'



# Generated at 2022-06-25 07:56:15.802022
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)

    # Invoke method
    result = action_module_0.run()
    assert result == expected_result

# Generated at 2022-06-25 07:56:22.223383
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    var_0 = action_get_args_from_task_vars(str_0, bool_0)

# Generated at 2022-06-25 07:56:26.992596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'lxlJ8_v7VX\`?`'
    float_0 = 1.7
    int_0 = 81
    bool_0 = False
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)


# Generated at 2022-06-25 07:57:04.876034
# Unit test for constructor of class ActionModule
def test_ActionModule():
  argument_spec = {'argument_spec': 'argument_spec'}
  tmp = "/tmp/ansible_umwJpB/ansible_module_validate_args.zip/ansible/module_utils/"
  task_vars = {'task_vars': 'task_vars'}
  float_0 = 2.0
  bool_0 = True
  int_0 = 136
  int_1 = 13
  ansible_facts = {'ansible_facts': 'ansible_facts'}
  list_0 = [float_0, bool_0, bool_0]
  action_module_0 = ActionModule(float_0, bool_0, int_0, int_1, bool_0, list_0)

# Generated at 2022-06-25 07:57:13.228100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)



# Generated at 2022-06-25 07:57:16.692291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    try:
        ActionModule(tmp, task_vars)
    except AnsibleError as e:
        assert type(e.message) == str
        assert e.message == '"argument_spec" arg is required in args: {}'
    except:
        assert False, 'Uncaught exception raised'


# Generated at 2022-06-25 07:57:25.837849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)

    # Call method run of ActionModule and check the result.
    # If the result is False, go to label L0.
    # L0
    # Check if the value of float_0 is equal to the value of float_0.
    # If the result is True, go to label L1.
    # L1
    # Return the value of float_0
    # Return an instance of ansible.errors.AnsibleError
    pass



# Generated at 2022-06-25 07:57:29.018234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    assert action_module_0.validate_args_context == {}, "Argument \'validate_args_context\' should be equal to {}"


# Generated at 2022-06-25 07:57:36.051739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Create an object of class ActionModule using its constructor
        action_module_0 = ActionModule()
        action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    except (Exception) as err:
        print(err)
        # Raise error if constructor not implemented correctly
        raise AssertionError("Constructor not implemented correctly")


# Generated at 2022-06-25 07:57:42.385630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    result = action_module_2.run(bool_0, list_0)

if __name__ == "__main__":

    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 07:57:45.885077
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    var_0 = action_module_run(str_0, list_0)


# Generated at 2022-06-25 07:57:51.294172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    str_1 = '91=|P-y&G>'
    float_1 = 2.0
    int_1 = 136
    bool_1 = True
    list_1 = [float_1, bool_1, bool_1]
    action_module_1 = ActionModule(float_1, bool_1, int_1, int_1, bool_1, list_1)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:58:00.154012
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Task id is a unique identifier for the task.
    task_id = 13
    # is_failed is a boolean value, representing whether the task failed or not.
    is_failed = False
    # is_changed is a boolean value, representing whether the task changed something or not.
    is_changed = False
    # task_vars is a dict, representing variables that are made available from the task itself, so any module that is executed as part of a task (not lookup plugins) will have access to these variables.
    task_vars = {'a': 'b'}

    action_module_0 = ActionModule(task_id, is_failed, is_changed, task_vars)
    task_vars = {'ansible_facts': {'packages': {'aspell': {'aspell-en': {'state': 'latest'}}}}}

# Generated at 2022-06-25 07:59:11.090848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f@Xu\''
    float_0 = 8.0
    int_0 = 0
    bool_0 = True
    list_0 = ['}', float_0, int_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    obj_0 = action_module_0.run(str_0)


# Generated at 2022-06-25 07:59:15.207788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    int_0 = 9006
    str_0 = ':I:}'
    float_0 = 0.89436066
    list_0 = ['W=Q8H', 'G', float_0, float_0, int_0]
    list_1 = [float_0, bool_0, list_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    var_0 = ActionBase.run(action_module_0, list_0, list_1)

# Generated at 2022-06-25 07:59:23.050112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup some sample data to pass to the action.
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    var_0 = action_get_args_from_task_vars(str_0, bool_0)


if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:59:30.386193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '`\x16\x1c\x1b\x0b;V\x19\x1d\x02\x1fK\x1d\x07\x14\x14\x1e\x0c\x0b\x1e\x1c\x0f\x0c\x04\x14\x1e\x1c9'
    float_0 = 1.3387489722439834e-05
    int_0 = 150
    bool_0 = False
    list_0 = [bool_0, str_0, int_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    dict_0 = dict()

# Generated at 2022-06-25 07:59:37.554771
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # str_0 = '91=|P-y&G>'
    # float_0 = 2.0
    # int_0 = 136
    # bool_0 = True
    # list_0 = [float_0, bool_0, bool_0]
    # action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    pass


# Generated at 2022-06-25 07:59:46.725363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result_0 = ActionModule(bool_0, str_0, float_0)
    assert result_0.run() == {'failed': True,
                              'msg': '"argument_spec" arg is required in args: %s' % (True,),
                              'validate_args_context': {}}

    result_1 = ActionModule(int_0, list_0, str_0)
    assert result_1.run() == {'changed': False, 'validate_args_context': {}, 'msg': 'The arg spec validation passed'}
    assert result_1.run() == {'changed': False, 'validate_args_context': {}, 'msg': 'The arg spec validation passed'}

# Generated at 2022-06-25 07:59:56.116428
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case 0
    str_1 = '91=|P-y&G>'
    float_1 = 2.0
    int_1 = 136
    bool_1 = True
    list_1 = [float_1, bool_1, bool_1]
    action_module_1 = ActionModule(float_1, bool_1, int_1, int_1, bool_1, list_1)
    tmp = None
    task_vars = dict()
    action_module_1.run(tmp, task_vars)


# Generated at 2022-06-25 08:00:04.548287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'hN=ow^U'
    float_0 = 0.55
    int_0 = 683
    bool_0 = True
    list_0 = [float_0, str_0, str_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
    # Should fail with AnsibleError
    try:
        action_module_0.run(str_0, list_0)
    except AnsibleError:
        pass
    except Exception as exception_0:
        raise exception_0
    # Should fail with AnsibleError
    try:
        action_module_0.run(list_0, list_0)
    except AnsibleError:
        pass

# Generated at 2022-06-25 08:00:08.267286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError) as excinfo:
        ActionModule()
    assert '__init__() missing 6 required positional arguments:' in str(excinfo.value)


# Generated at 2022-06-25 08:00:13.672812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '91=|P-y&G>'
    float_0 = 2.0
    int_0 = 136
    bool_0 = True
    list_0 = [float_0, bool_0, bool_0]
    action_module_0 = ActionModule(float_0, bool_0, int_0, int_0, bool_0, list_0)
