

# Generated at 2022-06-25 07:52:06.630382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    float_1 = 608.7
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_1, bool_0, float_0)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)
    assert result['failed'] == True
    assert result['msg'] == 'Validation of arguments failed:\nThe task does not exist: "compare_{{ inventory_hostname }}"'
    assert result['validate_args_context'] == {}
    #assert result['argument_spec_data']

# Generated at 2022-06-25 07:52:15.358622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {-58.1737, -58.1737, -58.1737, -58.1737}
    int_0 = True
    float_0 = -58.1737
    float_1 = 608.7
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_1, bool_0, float_0)
    argument_spec_0 = {
        'argument_spec',
        'provided_arguments'
    }
    action_module_0.run(argument_spec_0, argument_spec_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:52:23.315411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    float_1 = 608.7
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_1, bool_0, float_0)

    #Send in a dict of args
    action_module_0.run(None, {})

    #Send in a task_vars
    action_module_0.run(None, task_vars={})

    #Test a passed case
    action_module_0.run(None, task_vars={'argument_spec': {'arg_name': {'arg_option': 'val'}}})

# Generated at 2022-06-25 07:52:29.738421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = 8.830444444444444
    list_0 = []
    str_0 = 'qoqPxNx'
    list_1 = ['R', 'IJGXfQPt']
    float_0 = 0.034000000000000004
    dict_4 = {'oqYO': 1.6986255538184394}
    dict_5 = {'BlwC': 'jJ', 'HN': 'f', 'ceZF': 'Z'}
    str_2 = '8'
    dict_6 = {'a': 'F', 'Em': 'WVZv', 'h': 'V'}
    list_3 = ['xB', 'h', 'H', 'b', 'WXfgd']

# Generated at 2022-06-25 07:52:32.110017
# Unit test for constructor of class ActionModule
def test_ActionModule():

	# Test for case 0 (example)
    test_case_0()



# Generated at 2022-06-25 07:52:36.903668
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    float_1 = 608.7
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_1, bool_0, float_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:52:46.774247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock for the ActionModule class.
    # This will allow us to intercept calls to the class.
    #
    # A mock is created with a spec. This specifies which
    # class attributes and methods are intercepted, and will
    # raise an error if an attempt is made to access or call
    # something that is not in the spec.
    action_module_0 = mock.Mock(spec=ActionModule)

    # We want to intercept the run method of the class, so
    # we need to assign it to the mock object
    action_module_0.run = ActionModule.run

    # Set up the return values that will be returned when we
    # call action_module_0.run().

# Generated at 2022-06-25 07:52:57.964619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the calling of the function get_args_from_task_vars
    action_module_0 = ActionModule()
    assert action_module_0.get_args_from_task_vars({}, {}) == {}, "Expected %s, but got: %s" % ({}, action_module_0.get_args_from_task_vars({}, {}))
    bool_0 = True
    int_0 = False
    float_0 = 21.94
    int_1 = 0
    float_1 = -333.2532

# Generated at 2022-06-25 07:52:59.072529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# vim: syntax=python

# Generated at 2022-06-25 07:53:04.568982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    float_1 = 608.7
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_1, bool_0, float_0)


# Generated at 2022-06-25 07:53:15.750094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # test case 0
    # TODO: add test case 0 here


# Generated at 2022-06-25 07:53:26.567146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_spec_data = {
        "bool_0": {
            "type": "bool"
        },
        "float_0": {
            "type": "float"
        },
        "float_1": {
            "type": "float"
        },
        "str_0": {
            "type": "str"
        },
        "type_0": {
            "type": "type"
        }
    }
    provided_arguments = {
        "bool_0": True,
        "float_0": -69.1351414938708,
        "float_1": -69.1351414938708,
        "str_0": "xhtxg",
        "type_0": 6.9428357971117e+26
    }

# Generated at 2022-06-25 07:53:32.079943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = 39.69926836500183
    bool_1 = False
    bool_2 = False
    action_module_1 = ActionModule(float_1, float_1, bool_1, float_1, bool_2, float_1)
    print('ActionModule class: %s' % type(action_module_1))


# Generated at 2022-06-25 07:53:40.588731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -78.73546578754805
    float_1 = 100.112252273
    bool_0 = True
    float_2 = 84.3439903386415
    bool_1 = True
    float_3 = 8.455985753573135
    action_module_0 = ActionModule(float_0, float_1, bool_0, float_2, bool_1, float_3)
    task_vars_0 = dict()
    dict_0 = dict()
    dict_0['validate_args_context'] = dict()
    dict_0['validate_args_context']['my_context_key'] = 'my_context_value'

# Generated at 2022-06-25 07:53:47.150283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = -26.310108962049787
    bool_1 = True
    action_module_1 = ActionModule(float_1, float_1, bool_1, float_1, bool_1, float_1)


# Generated at 2022-06-25 07:53:54.026280
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -69.1351414938708
    bool_0 = True
    action_module_0 = ActionModule(float_0, float_0, bool_0, float_0, bool_0, float_0)
    with pytest.raises(AnsibleError) as err:
        action_module_0.run(None, None)
    assert err.value.args[0] == '"argument_spec" arg is required in args: {}'


# Generated at 2022-06-25 07:53:58.259183
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 3286.043356203021
    bool_0 = False
    action_module_0 = ActionModule(float_0, float_0, bool_0, float_0, bool_0, float_0)
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:54:08.840912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestActionModuleRun(unittest.TestCase):

        def setUp(self):
            import copy
            import json


# Generated at 2022-06-25 07:54:09.572532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


test_ActionModule()

# Generated at 2022-06-25 07:54:20.672249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -69.1351414938708
    bool_0 = True
    action_module_0 = ActionModule(float_0, float_0, bool_0, float_0, bool_0, float_0)
    ansible_error_0 = AnsibleError('Incorrect type for provided_arguments, expected dict and got %s')
    str_0 = 'AnsibleError: Incorrect type for provided_arguments, expected dict and got %s'
    str_1 = 'Incorrect type for provided_arguments, expected dict and got %s'

    with pytest.raises((AnsibleError, AnsibleValidationErrorMultiple, Exception)):
        action_module_0.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:54:33.117759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    str_0 = {}
    str_1 = {}
    str_2 = {}

    action_module_0 = ActionModule(dict_0, dict_1, dict_2, str_0, str_1, str_2)
    print(action_module_0)

# Generated at 2022-06-25 07:54:41.314748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_2 = 3.556
    set_0 = set()
    int_0 = False
    bool_3 = True
    bool_0 = False
    action_module_2 = ActionModule(float_2, set_0, int_0, float_2, bool_3, bool_0)
    assert not isinstance(action_module_2, ActionBase)
    assert not isinstance(action_module_2, ActionBase)


# Generated at 2022-06-25 07:54:45.568519
# Unit test for constructor of class ActionModule
def test_ActionModule():
  set_0 = {}
  float_0 = - - float()
  bool_0 = bool()
  action_module_0 = ActionModule(float_0, set_0, set_0, float_0, bool_0, float_0)


# Generated at 2022-06-25 07:54:46.855887
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    print("Success")

# Generated at 2022-06-25 07:54:56.266652
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    action_module_0.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:55:06.308792
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    var_0 = action_module_0.get_args_from_task_vars(float_0, set_0)
    var_1 = action_module_0.get_args_from_task_vars(int_0, set_0)
    var_2 = action_module_0.get_args_from_task_vars(bool_0, bool_0)


# Generated at 2022-06-25 07:55:13.231488
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    float_0 = -10.973
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = False
    bool_0 = True
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    action_module_0.get_args_from_task_vars(None, None)


# Generated at 2022-06-25 07:55:24.429221
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(1.7708303259967266, set(['4', '4', '4', '4']), False, -12.360314149783859, False, -9.284018703860884)
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict) == True
    if isinstance(var_0, dict):
        var_1 = var_0.pop('validate_args_context')
        assert isinstance(var_1, dict) == True
        if isinstance(var_1, dict):
            var_2 = var_1.pop('arg_spec_type')
            assert isinstance(var_2, string_types) == True
            var_3 = var_1.pop('argument_spec')
            assert isinstance

# Generated at 2022-06-25 07:55:32.297281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -93.275
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    var_0 = action_run()
# END


# Generated at 2022-06-25 07:55:35.277869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    var_1 = action_run()



# Generated at 2022-06-25 07:55:49.633661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)



# Generated at 2022-06-25 07:55:55.664965
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    class_0 = ActionModule(None, None, False)
    dict_0 = {}
    dict_0['dict_0']['dict_1'] = 'str_0'
    dict_0['dict_0']['dict_2'] = 'str_0'
    result = class_0.get_args_from_task_vars(dict_0, None)
    assert result == {'dict_0': {'dict_1': 'str_0'}}

# Generated at 2022-06-25 07:55:59.762247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -11.1329
    set_0 = {float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)


# Generated at 2022-06-25 07:56:10.680034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type('None') == type(None)
    assert type('') == type('')
    assert type(True) == type(True)
    assert type(1) == type(1)
    assert type(1.0) == type(1.0)
    assert type([]) == type([])
    assert type({}) == type({})
    assert type(set()) == type(set())
    assert type(ActionModule) == type(ActionModule)
    assert type(False) == type(False)
    assert type(float) == type(float)
    # Test for constructor:
    # ActionModule(float)
    assert type(None) == type(None)
    assert type('') == type('')
    assert type(True) == type(True)
    assert type(1) == type(1)

# Generated at 2022-06-25 07:56:18.643979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -56.78
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = int(float_0)
    task_vars = TestModule0.setUp()
    bool_0 = bool(float_0)
    bool_1 = bool(float_0)
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    result = action_module_0.run(task_vars)
    assert result


# Generated at 2022-06-25 07:56:26.264070
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:56:28.859875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()




# Generated at 2022-06-25 07:56:30.824166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module_0 = ActionModule()
    # Execute method run of ActionModule
    action_module_0.run()


# Generated at 2022-06-25 07:56:35.329678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)


# Generated at 2022-06-25 07:56:45.063632
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    assert(action_module_0.action_name == float_0)
    assert(action_module_0.connection_name == set_0)
    assert(action_module_0._play_context == int_0)
    assert(action_module_0.loader == float_0)
    assert(action_module_0.templar == bool_0)
    assert(action_module_0.shared_loader_obj == float_0)


# Generated at 2022-06-25 07:57:20.120604
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    # Create an instance of the class ActionModule
    action_module_0 = ActionModule(int, int, int, int, int, int)

    # Set values for testing
    argument_spec_0 = {}
    task_vars_0 = {}
    argument_spec_0 = {'float_0': {'type': 'float', 'default': -58.1737}, 'set_0': {'type': 'set', 'default': False}, 'int_0': {'type': 'int', 'default': -3}, 'str_0': {'type': 'str', 'default': 'def'}, 'bool_0': {'type': 'bool', 'default': False}, 'dict_0': {'type': 'dict', 'default': False}}
    result_0 = action_run()

    # Make assertions

# Generated at 2022-06-25 07:57:29.091980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 07:57:35.853473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Testing method constructor of class ActionModule"""
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)

# Generated at 2022-06-25 07:57:39.575447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:57:47.187630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    action_module_0.run(action_module_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:57:49.766515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:57:53.761548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    var_0 = action_run()
    raise var_0
#        self.assertRaises(AnsibleError, action_module_0.run, *[])

# Generated at 2022-06-25 07:57:55.324045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(int_0, dict_0, int_0, set_0, dict_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:57:58.231304
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = None
    validated_arguments = {}

    # Set up mocks
    action_module = ActionModule(task_vars=validated_arguments)
    action_run = action_module.run

    # Run test
    test_case_0(action_run)

# Generated at 2022-06-25 07:58:04.592563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)


# Generated at 2022-06-25 07:59:08.936621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = action_module_0.get_args_from_task_vars()


# Generated at 2022-06-25 07:59:16.081224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # AssertionError: raise_on_missing=True not implemented yet
    with pytest.raises(AssertionError):
        # WARNING: run() takes at most 2 positional arguments (4 given)
        action_module_0 = ActionModule()


# Generated at 2022-06-25 07:59:24.077695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    var_0 = action_run()
    assert var_0 == float_0
    int_1 = False
    action_module_1 = ActionModule(int_0, float_0, set_0, int_0, int_1, bool_0)
    var_1 = action_run()
    assert var_1 == bool_0
    action_module_2 = ActionModule(float_0, float_0, int_1, float_0, float_0, float_0)

# Generated at 2022-06-25 07:59:30.952472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # var_0 is empty
    var_0 = None
    # var_1 is empty
    var_1 = None
    # var_2 is empty
    var_2 = None
    # var_3 is empty
    var_3 = None
    # var_4 is empty
    var_4 = None
    # var_5 is empty
    var_5 = None
    # arg_0 is empty
    arg_0 = None
    # arg_1 is empty
    arg_1 = None
    # arg_2 is empty
    arg_2 = None
    # arg_3 is empty
    arg_3 = None
    # arg_4 is empty
    arg_4 = None
    # arg_5 is empty
    arg_5 = None

# Generated at 2022-06-25 07:59:31.564002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert expected == actual


# Generated at 2022-06-25 07:59:36.373307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for __init__
    set_0 = {40, 46, 14, 88, 23, 86, 26}
    test_module_0 = TestModule(set_0, set_0)
    set_1 = {set_0, set_0, set_0}
    int_0 = False
    action_registry_0 = TestActionRegistry(set_1)
    path_0 = '/etc/hosts'
    action_loader_0 = TestActionLoader(set_1, int_0, action_registry_0, path_0)
    path_1 = '/home/ec2-user/ansible/ansible-project/tasks/test-loop.yaml'
    task_loader_0 = TestTaskLoader(set_1, action_registry_0, action_loader_0, path_1)

# Generated at 2022-06-25 07:59:41.634075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -19.0511
    set_0 = {float_0, float_0, float_0, float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    float_1 = -59.1832
    bool_1 = True
    float_2 = -63.5391
    action_module_0 = ActionModule(float_0, set_0, int_0, float_1, bool_1, float_2)

# Generated at 2022-06-25 07:59:47.975673
# Unit test for constructor of class ActionModule
def test_ActionModule():
	float_0 = -30.838909
	set_0 = {float_0}
	int_0 = True
	bool_0 = False
	action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
	assert isinstance(action_module_0, ActionModule)
	assert action_module_0.check_mode == False
	assert action_module_0.tmp == float_0
	assert action_module_0.play_context == set_0
	assert action_module_0.no_log == int_0
	assert action_module_0.inject == float_0
	assert action_module_0.only_if == bool_0
	assert action_module_0.delegate_to == float_0

# Unit test

# Generated at 2022-06-25 07:59:53.903415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test args
    argspec = {"command": {"required": False, "type": "str"},
               "arg_spec": {"required": False, "type": "dict"},
               "args": {"required": False, "type": "dict"}}
    playbook_vars = {"var_of_things": "astring", "var_of_complex_things": [{'y': 'z', 'x': 'w'}]}
    module_name = "validate_argument_spec"
    module_args = {"argument_spec": {"validation_context": "role", "x": "int", "y": "str"},
                   "provided_arguments": {"x": -58.1737, "y": "astring"}}
    module_kwargs = {}

    # Test functionality
    result = pb_execute_module_with_args

# Generated at 2022-06-25 07:59:57.853977
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    float_0 = -58.1737
    set_0 = {float_0, float_0, float_0, float_0}
    int_0 = True
    bool_0 = False
    action_module_0 = ActionModule(float_0, set_0, int_0, float_0, bool_0, float_0)
    dict_0 = dict([(float_0, float_0)])
    dict_1 = dict([(str, float_0)])
    dict_2 = dict([(str, float_0)])
    dict_3 = dict([(str, float_0)])
    dict_4 = dict([(str, float_0)])
    assert(action_module_get_args_from_task_vars(dict_0, dict_1) == dict_2)