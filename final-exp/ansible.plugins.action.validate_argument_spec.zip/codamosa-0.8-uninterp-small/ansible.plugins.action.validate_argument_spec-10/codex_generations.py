

# Generated at 2022-06-25 07:52:13.154510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    task_vars_0 = action_run()
    var_0 = action_module_0.run(None, task_vars_0)
    var_1 = action_module_0.run(None, None)


# Generated at 2022-06-25 07:52:23.480894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Assumptions
    tmp = None
    task_vars = None
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    # Arguments to run
    tmp = None
    task_vars = None
    # Expected result

# Generated at 2022-06-25 07:52:29.831222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ur;+1.;d//'
    bool_0 = False
    float_0 = 9729.8559
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    str_0 = 'Ew]W8srv'
    bool_0 = False
    float_0 = 7304.3
    dict_0 = dict()
    char_0 = ']'
    short_0 = 5
    int_0 = 8
    long_0 = -35
    long_1 = -35
    long_2 = -35
    long_3 = -35
    long_4 = -35
    long_5 = -35
    long_6 = -35
    long_7 = -35
    long_8

# Generated at 2022-06-25 07:52:34.147359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    assert type(action_module_0) == ActionModule

# Generated at 2022-06-25 07:52:41.450303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # build args
    tmp = None
    task_vars = None

    # no exception raised
    try:
        action_module_0 = ActionModule(tmp, bool_0, str_0, float_0, bool_0, str_0)
        var_0 = action_module_0.run(tmp, task_vars)
        # no exception raised
    except Exception as exc:
        assert False, "Exception raised unexpectedly at code '%s'" % exc

# Generated at 2022-06-25 07:52:47.691409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'SjbGIKf1vJ8rgxT$T@UtY9Xe6U'
    bool_0 = True
    str_1 = 'JE[s'
    int_0 = -4
    bool_1 = False
    str_2 = '.'
    action_module_0 = ActionModule(str_0, bool_0, str_1, int_0, bool_1, str_2)
    assert not action_module_0.run(str_0, bool_0)

# Generated at 2022-06-25 07:52:50.455321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = None
    runner = None

    # Test Template
    # test_ActionModule_run()



# Generated at 2022-06-25 07:52:54.091307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Fe+jV'
    bool_0 = True
    float_0 = 9322.810029985923
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)


# Generated at 2022-06-25 07:53:00.048375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '2_LG)oD-!Xpp!xDA'
    bool_0 = True
    float_0 = 4835.41455
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:53:02.618818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(arg_parse().dest)
    print(arg_parse().add_help)
    print(arg_parse().parse_args)
    print(arg_parse().add_argument)

# Usage
test_ActionModule_run()

# Generated at 2022-06-25 07:53:07.481272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None

    try:
        assert False
    except:
        raise Exception()


# Generated at 2022-06-25 07:53:13.939032
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    var_0 = None
    var_1 = None
    param_0 = None
    param_1 = None
    try:
        var_0 = ActionModule()
        var_1 = var_0.get_args_from_task_vars(param_0, param_1)
    except Exception as exc:
        raise
    else:
        pass
    finally:
        del(var_0)
        del(var_1)


# Generated at 2022-06-25 07:53:18.771630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Note: This is a stub test case.  It should be replaced with a full implementation.
    module = ActionModule(var_0, var_1)
    assert module is not None


# Generated at 2022-06-25 07:53:21.382337
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    obj = ActionModule()
    obj.get_args_from_task_vars(var_0,var_1)



# Generated at 2022-06-25 07:53:22.580448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert (obj is not None)

# Generated at 2022-06-25 07:53:26.486676
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = [ActionBase(),None]
    var_2[0]._task = var_2[1]


# Generated at 2022-06-25 07:53:29.124140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AnsibleError) as excinfo:
        ActionModule(None, None, None, '', '')
    assert str(excinfo.value) == '"argument_spec" arg is required in args: {}'

# Generated at 2022-06-25 07:53:38.680971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arguments = {
        "argument_spec": {
            "name": {
                "required": True,
                "type": "str",
            },
            "password": {
                "required": True,
                "type": "str",
                "no_log": True,
            },
            "port": {
                "default": 22,
                "type": "int",
            },
        },
        "argument_spec": {
            "argument_spec": {
                "required": True,
                "type": "dict",
            },
            "provided_arguments": {
                "required": True,
                "type": "dict",
            },
        },
    }
    module_args = ArgumentSpecValidator(arguments).validate_arguments(arguments, var_0)
    # main

# Generated at 2022-06-25 07:53:40.094587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    validator = ArgumentSpecValidator(var_0)


# Generated at 2022-06-25 07:53:46.670227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create Mock of ActionModule and use as parent class
    mock_ActionModule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    mock_err_msg = "AnsibleError exception raised"
    try:
        argument_spec = None
        provided_arguments = None
        tmp = None
        task_vars = None
        mock_ActionModule.run(tmp=tmp,task_vars=task_vars)
    except AnsibleError as err:
        assert err.message == mock_err_msg
        if str(err) != mock_err_msg:
            raise AssertionError(err)



# Generated at 2022-06-25 07:53:59.104003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    argspec = dict(
        argument_spec=dict(type='dict'),
        provided_arguments=dict(type='dict', default={}),
    )
    module_arguments = dict(
        argument_spec=dict(
            some_key=dict(type='str'),
            another_key=dict(type='str'),
        ),
        provided_arguments=dict(
            some_key='abc',
            another_key=123,
        ),
    )
    module_ansible_result = dict(
        argument_errors=['should be of type <type \'str\'>']
    )
    module_results = dict(
        ansible_module_results=module_ansible_result,
    )

# Generated at 2022-06-25 07:54:09.338609
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result_0 = ActionModule().run(tmp=None, task_vars=dict())
    assert isinstance(result_0, dict)
    assert result_0 == dict()
    result_1 = ActionModule().run(tmp=None, task_vars=dict(argument_spec=dict(), provided_arguments=dict()))
    assert isinstance(result_1, dict)
    assert result_1 == dict()
    try:
        ActionModule().run(tmp=None, task_vars=dict(argument_spec=dict(), provided_arguments=dict(test=1)))
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert repr(e) == repr(AnsibleError('"argument_spec" arg is required in args: {}'))

# Generated at 2022-06-25 07:54:10.794149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module=ActionModule()
    if not isinstance(action_module, ActionModule):
        raise Exception("ActionModule constructor test failed")


# Generated at 2022-06-25 07:54:13.825333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate an object of class ActionModule
    action_module = ActionModule()
    action_module.run()



# Generated at 2022-06-25 07:54:23.520192
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_spec = dict(argument_spec=dict(type='dict', choices=['option1', 'option2']),
                    provided_arguments=dict(type='dict', required=True))

# Generated at 2022-06-25 07:54:26.690482
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_0 = ActionModule()
    argument_spec_0 = {}
    task_vars_0 = {}
    result = action_module_0.get_args_from_task_vars(argument_spec_0, task_vars_0)


# Generated at 2022-06-25 07:54:36.034131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    tmp_0 = None

# Generated at 2022-06-25 07:54:48.564131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # initialize attributes of object
    action_module = ActionModule()
    action_module.action = "module"
    action_module._task = None
    action_module._connection = None
    action_module._play_context = None
    action_module._loader = None
    action_module._templar = None
    action_module._shared_loader_obj = None
    action_module._connection_loader = None
    action_module._task._role = None
    action_module._task._block = None
    action_module._task.args = dict()
    action_module._task.action = "module"
    action_module._task.loop = None
    action_module._task.notify = {}
    action_module._task.loop_control = {}
    action_module._task.tags = set()
    action_module

# Generated at 2022-06-25 07:54:49.741529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 is not None 


# Generated at 2022-06-25 07:54:56.434230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()

    # This is a kludge that uses private members to allow us to call run on
    # action_module_1 in order to test it. This is not how this is intended to be used.
    # _task is a private member of ActionModule, so we can't just set it to what we want.
    # We have to do this weird hacky thing where we make a dummy task that has the same
    # object structure as what action_module_1 would have if it came for a live task,
    # and then set action_module_1's _task to the dummy task.
    # If this breaks, update the code below to match whatever the _task property looks like.
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-25 07:55:16.131267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # a dummy task
    action_module._task = {'args':{
        'argument_spec': {'test_attr': {'type': 'int', 'required': True}},
        'validate_args_context': {'some_thing': 'some_value'},
        'provided_arguments': {'test_attr': 12}
    }}
    # dummy_task_vars
    action_module._templar.template = lambda x: x
    result = action_module.run(tmp=None, task_vars={})
    assert result['validate_args_context'] == {'some_thing': 'some_value'}
    assert 'changed' in result and not result['changed']
    assert 'failed' in result and not result['failed']

# Generated at 2022-06-25 07:55:22.903876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Validate init
    assert isinstance(action_module_0, ActionModule) == True
    assert action_module_0.TRANSFERS_FILES == False

    # Validate run()
    #assert action_module_0.run() == None
    # Do something with the result
    assert True == True # TODO: Use assertions when the result dict is better known.
    assert True == True # TODO: Validate action_module_0.run() against known result.


# Generated at 2022-06-25 07:55:32.378301
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # setup test variables
    argument_spec_data = {'argument_spec': None}
    task_vars = {'argument_spec': None}
    expected_result = {'failed': True, 'msg': '"argument_spec" arg is required in args: {"argument_spec": null}'}
    # run test
    result = action_module_0.run(None, task_vars)
    # asserts
    assert result == expected_result

# Generated at 2022-06-25 07:55:36.927610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    return


# Generated at 2022-06-25 07:55:45.564288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n----------------- test_ActionModule_run -----------------")
    action_module = ActionModule()
    #self, tmp=None, task_vars=None
    print("\n---------------------- test case 0 ----------------------")
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)
    print(result)
    print("\n---------------------- test case 1 ----------------------")
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)
    print(result)
    print("\n---------------------- test case 2 ----------------------")
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)
    print(result)

# Generated at 2022-06-25 07:55:55.325661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    spec = dict(
        argument_spec=dict(
            required=dict(type='str', required=True),
            optional=dict(type='str'),
            choiced=dict(type=['str'], choices=['choice1', 'choice2']),
            required_invalid=dict(type='dict', required=True),
            type_invalid=dict(type='list', elements='str')
        )
    )

    args = {
        'required': 'required-value',
        'optional': 'optional-value',
        'choiced': 'choice1',
        'required_invalid': ['list'],
        'type_invalid': 'invalid-type'
    }

    action_module = ActionModule(task=dict(args=dict(argument_spec=spec, provided_arguments=args)))

# Generated at 2022-06-25 07:56:02.784794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task = DummyTask(dict(name='action_module_0_task', action='action_module_0', module_name='action_module_0', module_complex_args=dict(name='action_module_0_complex_arg')))
    action_module_0._tqm = DummyAnsibleTowerModuleConnection('/opt/ansible_tower/awx/projects/dev/venv/ansible/lib/python3.7/site-packages/ansible_tower/api/awx', 'some_token')
    action_module_0._templar = DummyTemplar()
    action_module_0._shared_loader_obj = DummySharedLoaderObj()



# Generated at 2022-06-25 07:56:10.714605
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_1 = ActionModule()
    # Get the task var called argument_spec. This will contain the arg spec
    # data dict (for the proper entry point for a role).
    argument_spec_data = 'argument_spec'
    task_vars = { argument_spec_data: {} }

    # get_args_from_task_vars returns a dict
    result = action_module_1.get_args_from_task_vars(argument_spec_data, task_vars)
    assert isinstance(result, dict)


# Generated at 2022-06-25 07:56:13.264800
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_0 = ActionModule()
    argument_spec_0 = {}
    task_vars_0 = {}
    assert action_module_0.get_args_from_task_vars(argument_spec_0, task_vars_0) is not None


# Generated at 2022-06-25 07:56:19.728698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # test_case_0
    tmp = None
    task_vars = None
    expected = {'argument_spec_data': {'test': {'type': 'str'}},
                'msg': 'The arg spec validation passed',
                'changed': False}
    argument_spec_data = {}
    provided_arguments = {}
    argument_spec_data['test'] = {'type': 'str'}
    action_module._task.args = {'argument_spec': argument_spec_data,
                                'provided_arguments': provided_arguments}
    result = action_module.run(tmp, task_vars)
    assert result == expected


# Generated at 2022-06-25 07:56:39.736054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result is not None

# Generated at 2022-06-25 07:56:40.862675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.run() == None

# Generated at 2022-06-25 07:56:43.566273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module_run = action_module.run()
    assert action_module_run.get('msg') == 'The arg spec validation passed'
    assert action_module_run.get('changed') is False

# Generated at 2022-06-25 07:56:53.204064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    action_module_3 = ActionModule()
    action_module_4 = ActionModule()
    action_module_5 = ActionModule()
    action_module_6 = ActionModule()
    action_module_7 = ActionModule()
    action_module_8 = ActionModule()
    action_module_9 = ActionModule()
    action_module_10 = ActionModule()
    action_module_11 = ActionModule()
    action_module_12 = ActionModule()
    action_module_13 = ActionModule()
    action_module_14 = ActionModule()
    action_module_15 = ActionModule()
    action_module_16 = ActionModule()
    action_module_17 = ActionModule()
    action_module_18 = ActionModule()
   

# Generated at 2022-06-25 07:56:54.177383
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
	action_module_0 = ActionModule()
	assert action_module_0 != None


# Generated at 2022-06-25 07:56:54.775282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:56:55.663054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:57:04.810870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    # validator.validate() raises an AnsibleError on validation failures, so we need
    # to catch them when running the test
    try:
        result = action_module.run()
        assert result is None # This should be reached if nothing is raised

        # result['failed'] is the only thing we can check, since the result dict is
        # almost entirely composed of dynamic values
        assert result['failed'] == True

    except Exception as e:
        pass

    #
    # Test required args
    #

# Generated at 2022-06-25 07:57:09.142712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    del action_module

# Generated at 2022-06-25 07:57:14.849123
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    module_args_0 = dict()
    module_args_0.update({"validate_args_context": dict()})
    module_args_0.update({"argument_spec": dict()})
    action_module_0.run(arguments=module_args_0, task_vars=dict())


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:57:45.980597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    with pytest.raises(AnsibleError):
        action_module_1.run()


# Generated at 2022-06-25 07:57:48.751628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # call run with correct params
    assert action_module_0.run(tmp=None, task_vars=dict()) is not None


# Generated at 2022-06-25 07:57:52.902786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:57:57.467900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:58:07.513509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0._task.args = dict(validate_args_context=dict(), argument_spec={'key_0': {'required': True, 'type': 'dict'}, 'key_1': {'required': True, 'type': 'dict'}}, provided_arguments={'key_1': {'key_2': 2, 'key_3': 3}, 'key_4': 4, 'key_0': {'key_5': 5, 'key_6': 6}})
    action_module_0._task.action = 'validate_argument_spec'
    action_module_0._task._role = None

# Generated at 2022-06-25 07:58:10.106479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()
    assert result['failed'] is True

# Generated at 2022-06-25 07:58:15.192691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    argspec_0 = {'argument_spec': {}, 'provided_arguments': {}}
    kwargs_0 = {}
    kwargs_0['task_vars'] = {}
    action_module_0.run(**kwargs_0)


# Generated at 2022-06-25 07:58:20.825373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    args = {"provided_arguments": {}, "argument_spec": {}}

# Generated at 2022-06-25 07:58:25.086945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule()


# Generated at 2022-06-25 07:58:25.861629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:59:06.996585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # inputs
    tmp = None
    task_vars = None
    # expected returns
    expected_result = None
    # mock the method call for action_run
    action_module_0 = mock_method(ActionModule, 'action_run')
    result = action_module_0.run(tmp, task_vars)
    assert result == expected_result


# Generated at 2022-06-25 07:59:10.369686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)


# Generated at 2022-06-25 07:59:19.353978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = "/usr/bin/ansible"
    arg_1 = ""
    arg_2 = "ansible"
    arg_3 = 1.0
    arg_4 = False
    arg_5 = "ansible"
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5)
    arg_6 = None
    arg_7 = {}
    action_module_0.run(arg_6, arg_7)


# Generated at 2022-06-25 07:59:23.340105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    var_0 = action_run()
    assert var_0 == False


# Generated at 2022-06-25 07:59:25.148622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run(tmp=None, task_vars=None) == 'The arg spec validation passed'


# Generated at 2022-06-25 07:59:31.055235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # task_vars is a dict of str to any
    task_vars = dict()
    # tmp is a str
    tmp = 'udp'
    # task_vars is a dict of str to any
    task_vars = dict()
    bool_0 = False
    str_0 = 'eQ#;'
    float_0 = -8.3250
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, task_vars)
    action_module_1 = ActionModule(str_0, float_0, float_0, float_0, float_0, task_vars)


# Generated at 2022-06-25 07:59:41.338702
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    str_1 = 'C/h}a3'
    bool_1 = True
    str_2 = 'D|q3'
    float_1 = 33.211
    bool_2 = True
    str_3 = 'S.cS'
    action_module_0.run(str_1, str_2, str_3)
    action_module_0.run(str_1, str_2, str_3)
    action_module_0.run(str_1, str_2, str_3)
    action_module

# Generated at 2022-06-25 07:59:44.987203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    action_module_0.run

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 07:59:48.340016
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '>1z,8Nf?k:e'
    bool_0 = False
    float_0 = 6388.3
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0, bool_0)


# Generated at 2022-06-25 07:59:57.917590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    float_1 = -0.880974
    float_2 = -0.880974
    float_3 = -0.880974
    float_4 = -0.880974
    float_5 = -0.880974
    action_module_0.set_task_vars({})
    # Create instance of class ArgumentSpecValidator
    str_1 = 'Lm#'
    bool_1 = False
    float_6 = -0.880974
    argument_spec_validator_0 = ArgumentSpecValidator

# Generated at 2022-06-25 08:01:35.019227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Jf,hZS9X!_'
    bool_0 = False
    str_1 = 'Jf,hZS9X!_'
    float_0 = 577.80507
    bool_1 = False
    str_2 = 'Jf,hZS9X!_'
    action_module_2 = ActionModule(str_0, bool_0, str_1, float_0, bool_1, str_2)
    assert(action_module_2._task.module_name == 'action')


# Generated at 2022-06-25 08:01:41.519911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'UR(o;;s+50'
    bool_0 = False
    float_0 = 3525.5469
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    tmp = None
    task_vars = {'B', 'L', 'm', '9', '<', 'Y', 'g'}
    var_0 = action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 08:01:42.157097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = action_run()


# Generated at 2022-06-25 08:01:48.333469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Checking for method run')
    float_0 = 4333.86
    float_1 = 5.29
    float_2 = 1.23
    str_0 = '!q,uS6/'
    bool_0 = True
    bool_1 = False
    bool_2 = False
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_1, str_0)
    action_module_0.run(float_0, float_1, float_2)


# Generated at 2022-06-25 08:01:51.483342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule({'argument_spec': {'argument1': {}}, 'provided_arguments': {}}, None, None)
    action_module_0.run()



# Generated at 2022-06-25 08:01:56.976285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '0'
    bool_0 = False
    float_0 = 2435.0
    action_module_0 = ActionModule(str_0, bool_0, str_0, float_0, bool_0, str_0)
    var_0 = action_module_0.run()
    assert var_0 is not None