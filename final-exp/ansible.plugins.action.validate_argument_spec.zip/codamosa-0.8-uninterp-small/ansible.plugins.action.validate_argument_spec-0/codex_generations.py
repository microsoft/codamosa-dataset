

# Generated at 2022-06-25 07:52:15.191166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -623.7
    bytes_0 = b'\xbc3\x8a'
    dict_1 = {float_0: bytes_0, float_0: float_0}
    bool_0 = False
    float_1 = -522.0
    action_module_0 = ActionModule(float_0, bytes_0, bytes_0, dict_1, bool_0, float_1)
    tmp_0 = None
    task_vars_0 = None
    result = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:52:21.777185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -623.7
    bytes_0 = b'\xbc3\x8a'
    dict_0 = {float_0: bytes_0, float_0: float_0}
    bool_0 = False
    float_1 = -522.0
    action_module_0 = ActionModule(float_0, bytes_0, bytes_0, dict_0, bool_0, float_1)
    #assert action_module_0.name == 'validate_argument_spec'
    assert True




# Generated at 2022-06-25 07:52:29.366402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -623.7
    bytes_0 = b'\xbc3\x8a'
    dict_0 = {float_0: bytes_0, float_0: float_0}
    bool_0 = False
    float_1 = -522.0
    action_module_0 = ActionModule(float_0, bytes_0, bytes_0, dict_0, bool_0, float_1)

# Generated at 2022-06-25 07:52:31.603908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:52:32.782654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    case_0 = test_case_0()
    case_0.run()

# Generated at 2022-06-25 07:52:43.507725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -512.0
    bytes_0 = b'k\xbf\x9f'
    bytes_1 = b'\xe3\x18\xd0'
    dict_0 = {float_0: bytes_0, float_0: float_0}
    bool_0 = True
    float_1 = 425.1
    action_module_0 = ActionModule(float_0, bytes_0, bytes_1, dict_0, bool_0, float_1)
    dict_1 = {}
    dict_2 = {}
    action_module_0.transfers = dict_1
    task_vars = dict_2
    result = action_module_0.run(float_0, task_vars)
    assert result is None


# Generated at 2022-06-25 07:52:48.310815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule(float, bytes, bytes, dict, bool, float)
    assert action_module_0 is not None and action_module_1 is not None


# Generated at 2022-06-25 07:52:57.287276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xbc3\x8a'
    float_0 = -623.7
    dict_0 = {float_0: bytes_0, float_0: float_0}
    bool_0 = False
    float_1 = -522.0
    action_module_0 = ActionModule(float_0, bytes_0, bytes_0, dict_0, bool_0, float_1)

    # TODO: fix this
    # action_module_0._task.args.update({'argument_spec': {'name':{'type': 'str', 'required': True}, 'age':{'type': 'int', 'required': False}, 'state':{'type': 'str', 'required': False, 'choices': ['present', 'absent'], 'default': 'present'}}}
    # action_

# Generated at 2022-06-25 07:53:01.210596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -623.7
    bytes_0 = b'\xbc3\x8a'
    dict_0 = {float_0: bytes_0, float_0: float_0}
    bool_0 = False
    float_1 = -522.0
    action_module_0 = ActionModule(float_0, bytes_0, bytes_0, dict_0, bool_0, float_1)

# Generated at 2022-06-25 07:53:02.935213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    action_module_0 = ActionModule(dict_0)
    dict_0 = action_module_0.run()

# Generated at 2022-06-25 07:53:08.019368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert type(action_module_1) == ActionModule
    

# Generated at 2022-06-25 07:53:17.152429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test run() of ActionModule

    Test when args are missing
    Test when arg data is incorrect type
    Test when a required argument is missing
    Test when a required argument is defined as None
    '''
    action_module_0 = ActionModule()

    # Setup task args
    task_args_0 = dict()
    task_args_0['argument_spec'] = {
        'arg_1': {
            'type': 'dict',
            'required': True
        }
    }

    # Setup task vars
    task_vars_0 = dict()

    # Setup additional args
    additional_args_0 = {
        'provided_arguments': {}
    }

    # Setup validation_result

# Generated at 2022-06-25 07:53:21.266796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    vars_0 = None
    output_0 = action_module_0._execute_module(tmp_0, vars_0, complex_args=dict(), task_vars=dict())
    assert output_0 == {'msg': 'The arg spec validation passed', 'changed': False}


# Generated at 2022-06-25 07:53:23.652320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate object of class ActionModule
    action_module_0 = ActionModule()

    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:53:32.872753
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 07:53:33.567447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:53:38.088640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    args_0 = dict()
    kwargs_0 = dict()
    task_vars_0 = dict()

    args = [args_0]
    kwargs = kwargs_0
    task_vars = task_vars_0

    action_module_1.run(*args, **kwargs)

# Generated at 2022-06-25 07:53:46.735027
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_0 = ActionModule()
    assert (isinstance(action_module_0.get_args_from_task_vars(
        argument_spec={}, task_vars={}), dict))
    assert (isinstance(action_module_0.get_args_from_task_vars(
        argument_spec=dict(), task_vars=dict()), dict))
    assert (isinstance(action_module_0.get_args_from_task_vars(
        argument_spec=dict([('A', 'B'), ('C', 'D')]), task_vars=dict()), dict))

# Generated at 2022-06-25 07:53:57.032918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 is not None, "The object ActionModule should not be None"
    assert isinstance(action_module_1.run, types.MethodType), "The object ActionModule should have member run"
    assert callable(action_module_1.run), "The object ActionModule should have a run method"
    assert isinstance(action_module_1.get_args_from_task_vars, types.MethodType), "The object ActionModule should have member get_args_from_task_vars"
    assert callable(action_module_1.get_args_from_task_vars), "The object ActionModule should have a get_args_from_task_vars method"

# Generated at 2022-06-25 07:53:58.569853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:54:07.268707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:54:09.710073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    action_module_1 = ActionModule()
    action_module_1.run(tmp, task_vars)

# Generated at 2022-06-25 07:54:15.652182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_res = {}
    new_instance = action_module_0
    tmp_1 = None
    task_vars_2 = {'role_name': 'test_role',
                   'role_args': {'name': 'test'},
                   'role_path': '',
                   'role_params': {'role_name': 'test_role',
                                   'role_path': '',
                                   'role_args': {'name': 'test'}},
                   'play_context': {'name': 'test'},
                   'name': 'test'}
    test_res['result'] = new_instance.run(tmp_1,
                                          task_vars_2)
    print(test_res)


# Generated at 2022-06-25 07:54:23.534466
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(20*'*')
    action_module_0 = ActionModule()
    tmp = None
    task_vars = {'ansible_net_hostname': 'test'}
    result = action_module_0.run(tmp, task_vars)
    print(result)
    assert result['validate_args_context'] == {}
    assert result['changed'] == False
    assert result['msg'] == 'The arg spec validation passed'


# Generated at 2022-06-25 07:54:31.971389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run = ActionModule()
    argspec = {u'validate_args_context': {'required': False}, u'argument_spec': {'required': True}}
    no_opt_arg_module_run = dict(argument_spec={}, provided_arguments={}, **argspec)
    task_vars = {u'foo': u'bar'}
    with pytest.raises(AnsibleError):
        action_module_run.run(task_vars=task_vars, **no_opt_arg_module_run)
    assert action_module_run.run(task_vars=task_vars, **no_opt_arg_module_run)


# Generated at 2022-06-25 07:54:33.772346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run(task_vars=dict())


# Generated at 2022-06-25 07:54:41.106982
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Run test for  method of class ActionModule

    # These tests should go in a different module really
    # We can't do unit tests on this module until the ArgumentSpecValidator has some better testing
    # But as a starting point, here are a few simple, manual tests
    action_module_0 = ActionModule()
    module_args = dict()
    module_args['argument_spec'] = dict()
    module_args['argument_spec']['name'] = dict()
    module_args['argument_spec']['name']['type'] = 'str'
    module_args['provided_arguments'] = dict()
    module_args['provided_arguments']['name'] = 'some value'
    module_args['validate_args_context'] = dict()

# Generated at 2022-06-25 07:54:46.814215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = {}
    result_0 = action_module_0._execute_module(module_name=None, module_args=None, task_vars=task_vars_0, tmp=tmp_0, delete_remote_tmp=False)
    ok_(result_0['failed'] == False)


# Generated at 2022-06-25 07:54:57.737327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the arguments for the module
    argument_spec = {"argument_spec": {"_aliases": [], "_boolean_actions": [], "_boolean_or_actions": [], "_defaults": {"default": None, "type": "str", "choices": [], "no_log": False}, "_required_one_of": [], "_required_together": [], "_required_together_ignore_missing": [], "_required_when": [], "_required_when_ignore_missing": []}, "msg": "Some failure", "provided_arguments": {"_ansible_parsed": True}, "skipped": False, "validate_args_context": {"module_name": "some_module", "role_name": "some_role"}}

    action_module = ActionModule()

# Generated at 2022-06-25 07:55:04.493341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the mocks for arguments for the action module
    module_args = {}
    module_args['argument_spec_data'] = {}
    module_args['provided_arguments'] = {}
    # Call the method
    action_module_1 = ActionModule()
    action_module_1.run(module_args)

# Generated at 2022-06-25 07:55:21.172943
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Register the task
    action_module_1 = ActionModule()
    task_body = dict()
    action_module_1._task = task_body
    assert action_module_1._task == task_body


# Generated at 2022-06-25 07:55:24.831717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    attr = action_module.__dict__
    assert attr['TRANSFERS_FILES'] == False
    action_module.run(task_vars = {'argument_spec': {'type': 'str', 'default': '{{ "foobar" }}'}})
    action_module.run(task_vars = {'argument_spec': {}})


# Generated at 2022-06-25 07:55:35.863844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fixture_0 = dict(
        argument_spec=dict(
            argument_spec=dict(),
            provided_arguments=dict()
        )
    )
    fixture_1 = dict(
        argument_spec=dict(
            argument_spec=dict(
                a=dict(
                    type='int'
                ),
                b=dict(
                    type='str',
                    default='fish'
                )
            ),
            provided_arguments=dict(
                a=5,
                b='sloth'
            )
        )
    )

# Generated at 2022-06-25 07:55:38.193956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)



# Generated at 2022-06-25 07:55:46.257747
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    args = {}
    args['argument_spec'] = {}
    args['argument_spec']['key1'] = {}
    args['argument_spec']['key1']['type'] = 'str'
    args['provided_arguments'] = {}
    args['provided_arguments']['key2'] = "value1"
    args['validate_args_context'] = {}
    task_vars = {}
    result = action_module.run(None, task_vars)
    assert result['failed']
    assert result['msg'] == 'Incorrect type for key2, expected str and got unicode'
    args['provided_arguments']['key1'] = "value1"
    args['provided_arguments']['key2'] = "value2"

# Generated at 2022-06-25 07:55:55.412332
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = {"validate_args_context": {"some_key": "some_value"}, "validate_args_context": {"some_key": "some_value"}, "validate_args_context": {"some_key": "some_value"}}
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0 == {'ansible_facts': {}, 'changed': False, 'msg': 'The arg spec validation passed', 'validate_args_context': {'some_key': 'some_value'}, 'warnings': []}


# Generated at 2022-06-25 07:55:56.449611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:55:59.064413
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    with pytest.raises(AnsibleError) as err:
        action_module_0.run()


# Generated at 2022-06-25 07:56:10.313039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  ansible_0 = AnsibleError()
  ansible_1 = AnsibleError()
  ansible_2 = AnsibleError()
  ansible_3 = AnsibleError()
  ansible_4 = AnsibleError()
  ansible_5 = AnsibleError()
  ansible_6 = AnsibleError()
  ansible_7 = AnsibleError()
  ansible_8 = AnsibleError()
  ansible_9 = AnsibleError()

  AnsibleError.__init__(ansible_0)
  AnsibleError.__init__(ansible_1)
  AnsibleError.__init__(ansible_2)
  AnsibleError.__init__(ansible_3)
  AnsibleError.__init__(ansible_4)
  AnsibleError.__init__(ansible_5)

# Generated at 2022-06-25 07:56:13.437125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-25 07:56:46.468720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Execute the run method of the ActionModule class with a set of provided arguments
    # and other necessary data
    # Assert that the run method behaves as expected
    assert False

# Generated at 2022-06-25 07:56:54.323278
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # get the class name of module
    action_module_1 = ActionModule()
    print("Class name of module is: %s" % action_module_1.__class__.__name__)

    # get the file name of module
    action_module_2 = ActionModule()
    print("File name of module is: %s" % action_module_2.__module__)

    # get the doc string of module
    action_module_3 = ActionModule()
    print("Doc string of module is: %s" % action_module_3.__doc__)

    # get the value for TRANSFERS_FILES
    action_module_4 = ActionModule()
    print("Value for TRANSFERS_FILES is: %s" % action_module_4.TRANSFERS_FILES)


# Generated at 2022-06-25 07:56:55.418735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:57:00.324744
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    argument_spec = {"name": {"type": "str", "required": True}}
    task_vars = {"name": "harry"}

    action_module_0 = ActionModule()
    expected = {'name': 'harry'}
    out = action_module_0.get_args_from_task_vars(argument_spec, task_vars)
    assert out == expected


# Generated at 2022-06-25 07:57:03.788298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    ansible_vars = dict()
    args = dict()
    tmp = dict()
    action_module_run = action_module.run(tmp, ansible_vars)

# Generated at 2022-06-25 07:57:10.857922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_spec = dict(
        argument_spec=dict(type='dict'),
        provided_arguments=dict(type='dict')
)
    arguments = dict(
        argument_spec=dict(
            src=dict(type='str', required=True),
            dest=dict(type='str', required=True),
            validate_certs=dict(type='bool', default=True),
            client_cert=dict(type='path'),
            client_key=dict(type='path'),
            # ssh-fingerprint is for future use and not currently implemented
            ssh_fingerprint=dict(type='str'),
        ),
        provided_arguments=dict(src='/tmp/src', dest='/tmp/dest')
    )
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:57:15.000210
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:57:19.979042
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_obj = ActionModule()

    # Pass a test in
    # This should pass. However, this test is not currently implemented.
    action_module_obj.run({}, {'test': True})
    assert True

    # Pass a test in that fails
    # This should pass. However, this test is not currently implemented.
    action_module_obj.run({}, {'test': False})
    assert True

    # Pass a test in that raises an exception
    # This should pass. However, this test is not currently implemented.
    action_module_obj.run({}, {'test': True})
    assert True

# Generated at 2022-06-25 07:57:27.065346
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("========================================")
    print("Testing constructor for class ActionModule")
    action_module_0 = ActionModule()
    assert action_module_0 is not None
    print("Testing constructor for class ActionModule: PASSED")


# Generated at 2022-06-25 07:57:27.681365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:58:01.253001
# Unit test for constructor of class ActionModule
def test_ActionModule():
	action_module_0 = ActionModule()

if __name__ == "__main__":
	test_case_0()
	test_ActionModule()

# Generated at 2022-06-25 07:58:07.841401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    float_0 = -1181.0
    str_0 = 'A#=i>f'
    bytes_0 = b'b-\x92\xf1"\xd2g2\xef@\xb6\n\x9aD'
    bytes_1 = b' \xe5v\xd7\x13%\x95\x1e \xcd"\xa3O\xe1|\x02\xd5'
    int_0 = 6

    action_module_0 = ActionModule(tuple_0, float_0, str_0, str_0, bytes_1, int_0)

    assert action_module_0 != None



# Generated at 2022-06-25 07:58:15.793092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # Test for constructor
    str_0 = 'q\xca\x1f'
    bytes_0 = b'\xa6\x0cE'
    str_1 = '\x9dE\x80\xad\x1a\xad'
    tuple_0 = ()
    int_0 = 8

# Generated at 2022-06-25 07:58:23.049033
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1815.0
    str_0 = 'n\t\x15\xd4\x04\x1b\x1f\x9a\xcd\xcf\xaa\xbb\xa8\n\xbc\xe0!\xdf*\x9f\x0b'
    bytes_0 = b'\x13\x8f\x0f\x92\xee'
    tuple_0 = ()
    str_1 = 'm\xde\x8e\x85\xa0\x16X\xa7\x1d\xa6\x97\x12\x11\x16\xa1\xbd\xdf\x0e\xeb\xfc6\x16\xfc\x17\xa6\x94\x05'
   

# Generated at 2022-06-25 07:58:27.098317
# Unit test for constructor of class ActionModule
def test_ActionModule():
  test_case_0()
  test_run()

test_ActionModule()

# Generated at 2022-06-25 07:58:34.997708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Test for ActionModule.run'
    bytes_0 = b' \x05\x8c\x1b\x15\xd3\x8e\x0c\x9f\xa5\x94\x1b\x86\xe2\x0c\x8e\xe5\xcd\xc5\x1c7\xab'
    dict_0 = dict()
    dict_0['key'] = str_0
    dict_0['value'] = bytes_0
    dict_0['key'] = bytes_0
    dict_0['value'] = str_0
    dict_0['key'] = str_0
    dict_0['value'] = bytes_0
    dict_0['key'] = bytes_0
    dict_0['value'] = str_0
    dict

# Generated at 2022-06-25 07:58:47.908122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    float_0 = -1181.0
    str_0 = 'A#=i>f'
    str_1 = 'A#=i>f'
    bytes_0 = b' \xe5v\xd7\x13%\x95\x1e \xcd"\xa3O\xe1|\x02\xd5'
    int_0 = 6
    action_module_0 = ActionModule(tuple_0, float_0, str_0, str_1, bytes_0, int_0)
    str_2 = 'argument_spec'
    dict_0 = dict()
    dict_0['argument_spec'] = str_2
    dict_0['provided_arguments'] = dict()
    dict_0['validate_args_context'] = dict()
    byte

# Generated at 2022-06-25 07:58:56.435273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'b-\x92\xf1"\xd2g2\xef@\xb6\n\x9aD'
    tuple_0 = ()
    float_0 = -1181.0
    str_0 = 'A#=i>f'
    bytes_1 = b' \xe5v\xd7\x13%\x95\x1e \xcd"\xa3O\xe1|\x02\xd5'
    int_0 = 6
    action_module_0 = ActionModule(tuple_0, float_0, str_0, str_0, bytes_1, int_0)
    test_case_0()


# Generated at 2022-06-25 07:59:02.425247
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bytes_0 = b'b(\xad\xea\xc3\xb8k\xee\xcf\x1dL\x97\x1a\xda\xd5\xab\xe5\xed\xee\x1e\x1a\xd9oA\x07\x1a\xc7'
    tuple_0 = ()
    float_0 = -7.994409079820983e+22
    str_0 = 'szI\xa0\x16\x88\x9f\x0b\xa3\x83\x1bI\xb8\xf2\xef'
    action_module_0 = ActionModule(tuple_0, float_0, str_0, str_0, str_0, int())
    dict_0 = dict()
   

# Generated at 2022-06-25 07:59:10.750151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\x12\x8d\x10\xbc\x18\xdb\x8c\x1a\x9f\xe4\x13\xbb\xb0\xd5`\xed\xe7\x8c\xd7\xad\xfa\xca4?\xfe\x86\xb4\xcb\xb8\xcb\xfe\x1f\xb5\x08\x95\x94\x0e\xd1\x8e'
    tuple_0 = ()
    float_0 = 636.0
    str_0 = '\x08\xe44\x12\xdf\xdf\xf70'

# Generated at 2022-06-25 08:00:23.995984
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bytes_0 = b'\xce\xcd\xe2\xbb\xdb\x0e\x02\xf1{\xed\x18'
    int_0 = -114
    str_0 = '\\\x87\xba\x1a\xe7\xcb\xe3\x86\xf0\x86\xdb\xd9\x1f\xc5\x8e\x89\x96\xf4\x94\xe4\xdf'
    int_1 = -13
    str_1 = 'Z\xd0\x91\x03\xcf\xdb\x9a\xbb\xd2\xbe\xcc\x1f\xe4\xaeR\x14\xa2\xb9'

# Generated at 2022-06-25 08:00:29.380237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xab\xcf\xc4\x8d4\xfb\xdb\xb1\x1f\x12\xac\x93\x9f\xeaG\x8b\xcf'
    tuple_0 = ()
    float_0 = 3642.0
    str_0 = '@h\xd2\xdb\x06\xbc\xef\x14\x1a\x9d\x1b\x0f\xfc\x11\x19\x8d\r\x98'

# Generated at 2022-06-25 08:00:31.183495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {}
    result = main(args_0)
    assert result == None, "Expected None"
    return result


# Generated at 2022-06-25 08:00:40.535727
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1c\x95\x81\x1b\xdc#\xa7\xd6\xfc\x8b\x84\xf0\x1a\x07\x8c\xe1\xbd\x86\xc6'
    str_0 = '\x1c\x95\x81\x1b\xdc#\xa7\xd6\xfc\x8b\x84\xf0\x1a\x07\x8c\xe1\xbd\x86\xc6'

# Generated at 2022-06-25 08:00:46.754230
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_3 = ()
    float_4 = -59.0
    str_4 = 'c%&;'
    str_5 = 'zY5}'
    bytes_2 = b'\x89\xe6\xef\x85\xd2,\xe2\xf6\x9f\x10\x85\x86\xc6\x95'
    int_3 = 1
    value_0 = 'sV2?s'
    action_module_1 = ActionModule(tuple_3, float_4, str_4, str_5, bytes_2, int_3)
    var_1 = action_module_1.run(value_0)


# Generated at 2022-06-25 08:00:54.212409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'r '
    list_0 = []
    str_1 = '1 '
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    float_0 = -1281.614
    bytes_0 = b'\x1a\xd3\xde\xf7\xa2\x9e\xaf\x94\xea\x80\x8d\x89\x1c\x9b\x9d\xad0\xab\xea\xad\xda\xdd\x0c\x11'
    dict_1 = {'a': 1, 'b': 2, 'c': 3}
    int_0 = 3

# Generated at 2022-06-25 08:00:59.763909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'b-\x92\xf1"\xd2g2\xef@\xb6\n\x9aD'
    tuple_0 = ()
    float_0 = -1181.0
    str_0 = 'A#=i>f'
    bytes_1 = b' \xe5v\xd7\x13%\x95\x1e \xcd"\xa3O\xe1|\x02\xd5'
    int_0 = 6
    action_module_0 = ActionModule(tuple_0, float_0, str_0, str_0, bytes_1, int_0)
    assert action_module_0.result == {'changed': False, 'msg': 'The arg spec validation passed'}


# Generated at 2022-06-25 08:01:05.185780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'o\xca\x18\x9f'
    tuple_0 = ()
    float_0 = 14.19

# Generated at 2022-06-25 08:01:10.233700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xa3\xad\xb4\xcb\x86\xcb\xa0\t\xb8\x81\x9d\x17\x88\x8b\xb0\xaa\xd5\x15\x8a'
    tuple_0 = ()
    float_0 = -125.0
    str_0 = '-h\xd8\xde\xfc/\x9a\x1f\'\x84\x80\r\xbc\x8e\x8a\xec\x9e'

# Generated at 2022-06-25 08:01:20.022278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'{'
    tuple_0 = ()
    float_0 = -1921.0
    str_0 = 'z/\x8a\xac#'
    bytes_1 = b'\x8f\x9e\x06\x12\xaf\xf4\x0f\xf6;\x1b\x84\x9a\xac\xc2\xdc\x1b\xa6&\x1dQ\x9a'
    int_0 = 1
    action_module_0 = ActionModule(bytes_1, tuple_0, float_0, str_0, bytes_1, int_0)
    result = action_module_0.run(tuple_0, tuple_0)
    assert type(result) == dict