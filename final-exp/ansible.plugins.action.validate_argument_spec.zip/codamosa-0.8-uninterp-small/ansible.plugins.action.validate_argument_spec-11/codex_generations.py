

# Generated at 2022-06-25 07:52:07.852473
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:52:09.650466
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    
    
# Operates on an instance of class ActionModule and returns an instance of ActionBase

# Generated at 2022-06-25 07:52:13.748365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_spec = {'argument_spec': 'argument_spec'}
    param_0 = {'provided_arguments': 'provided_arguments'}
    task_vars = 'task_vars'
    tmp = 'tmp'
    action_module_0 = ActionModule(arg_spec, param_0, task_vars, tmp)
    test_case_0()

# Generated at 2022-06-25 07:52:24.112839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 7414
    set_0 = {int_0}
    bytes_0 = b'6\x05\\\xf0\xdd\x11\x9d\x8e\x19'
    dict_0 = {int_0: int_0, set_0: int_0, bytes_0: int_0}
    int_1 = 260
    tuple_0 = (int_0,)
    action_module_0 = ActionModule(int_0, set_0, bytes_0, dict_0, int_1, tuple_0)
    tmp_0 = None
    task_vars_0 = {bytes_0: int_1}
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert type(result_0) is dict
   

# Generated at 2022-06-25 07:52:28.418949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test case 0
    test_case_0()



# Generated at 2022-06-25 07:52:37.879266
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 8763
    set_0 = {int_0, int_0}
    bytes_0 = b'\x87\xc3\x9a\x1e\x97\xe1\x8f\x0f'
    dict_0 = {bytes_0: set_0, set_0: bytes_0, bytes_0: int_0, bytes_0: bytes_0}
    int_1 = 10771
    tuple_0 = (int_0,)
    action_module_0 = ActionModule(int_0, set_0, bytes_0, dict_0, int_1, tuple_0)
    result = action_module_0.run()
    assert result['msg'] == 'The arg spec validation passed'
    assert result['changed'] == False
    assert result['failed'] == False



# Generated at 2022-06-25 07:52:38.626697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:52:48.218859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 68769
    set_0 = {int_0, int_0}

# Generated at 2022-06-25 07:52:57.279000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'tune': 'adagio'}
    int_0 = 2171
    set_0 = {int_0, int_0}
    bytes_0 = b'\xf4\xa2\x94\xdfm'
    dict_1 = {set_0: set_0, set_0: set_0, int_0: set_0, int_0: int_0}
    tuple_0 = ()
    action_module_0 = ActionModule(int_0, set_0, bytes_0, dict_1, int_0, tuple_0)
    task_vars = dict_0
    result = action_module_0.run(None, task_vars)
    assert result.get('validate_args_context') is dict_0


# Generated at 2022-06-25 07:53:00.710200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = None
    tmp = None
    task_vars = None
    action_module = ActionModule(args, tmp, task_vars)
    try:
        actual = action_module.run(tmp, task_vars)
    except Exception as e:
        print('Caught: %s' % repr(e))
        assert False, 'Unreachable'


# Generated at 2022-06-25 07:53:12.224759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostvars = {}
    task_vars = {}
    result = {}
    tmp = {}
    host_pattern = 'host_pattern'
    ini_path = 'ini_path'
    name = 'name'
    play_context = 'play_context'
    play_context_path = 'play_context_path'
    role_name = 'role_name'
    shared_loader_obj = {}
    any_password_vault = 'any_password_vault'
    any_vars_files = 'any_vars_files'
    any_vault_id = 'any_vault_id'
    any_vault_password_file = 'any_vault_password_file'
    connection = 'connection'
    become = 'become'
    become_method = 'become_method'

# Generated at 2022-06-25 07:53:12.853209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-25 07:53:23.454459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock parameters
    argument_spec = dict()
    provided_arguments = dict()
    task_vars = dict()

    # Create mock objects
    connection = Connection()
    ansible_facts = dict()
    tmp = dict()

    # Create mock module
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
        required_together=None,
        mutually_exclusive=None
    )
    module._socket_path = '/tmp/ansible_action_module.sock'
    module.check_mode = False
    module.no_log = False
    module.params = dict()
    module.system = platform.system()
    # Create mock action module
    action_module = ActionModule()

# Generated at 2022-06-25 07:53:32.790674
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.errors
    import ansible.playbook.task
    import ansible.plugins.action
    import ansible.utils.vars
    import ansible.module_utils.six
    import ansible.module_utils.common.arg_spec
    import ansible.module_utils.errors
    action_module = ansible.plugins.action.ActionModule(ansible.playbook.task.Task(), dict(action=dict()))
    # 'tmp' is deprecated, so this test has no effect.
    # 'task_vars' is required
    with pytest.raises(ansible.errors.AnsibleError) as err:
        action_module.run(tmp=None, task_vars=dict())
    assert "task_vars" in err.value.args[0]
    # 'argument_spec'

# Generated at 2022-06-25 07:53:35.559148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # TODO: Add a test for the run function
    #assert(action_module.run() == True)

# Generated at 2022-06-25 07:53:42.489334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {
        'provided_arguments': {}
    }
    args_1 = {
        'argument_spec': test_case_0.__globals__['int_1']
    }
    vars_1 = {
    }
    vars_0 = {
    }
    kwargs_1 = {
        'tmp': None,
        'module_name': None,
        'module_args': args_0
    }
    kwargs_0 = {
        'task_vars': vars_1
    }
    action_0 = ActionModule()
    args_0_0 = args_1['argument_spec']
    vars_0_0 = vars_0
    args_0_1 = action_0._task.args['provided_arguments']
    args_0

# Generated at 2022-06-25 07:53:48.218572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 68769
    int_1 = {int_0, int_0}
    tmp_0 = ActionModule.TRANSFERS_FILES
    args_0 = {'argument_spec': int_0}
    result_0 = ActionModule.run(tmp_0, args_0)


# Generated at 2022-06-25 07:53:57.722229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup argument_spec_data and provided_arguments.
    argument_spec_data = {
        'param_1': {'required': True, 'type': 'int'},
        'param_2': {'required': False, 'type': 'str'},
        'param_3': {'required': True, 'type': 'str', 'choices': ['foo', 'bar']},
        'states': {'required': False, 'type': 'list'},
        'tasks': {'required': False, 'type': 'list'},
    }

    provided_arguments = {
        'param_1': 123,
        'param_2': 'some string',
        'param_3': 'bar',
    }


# Generated at 2022-06-25 07:54:08.300295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule()
    test_ActionModule._task = {}
    test_ActionModule._task.args = {'argument_spec': {}}
    test_ActionModule._task.args = {'provided_arguments': {}}
    test_ActionModule._task.args = {'validate_args_context': {}}
    test_ActionModule._templar = {'template': {}}
    test_ActionModule._templar.template = 'template'
    result = test_ActionModule.run(None, None)
    assert isinstance(result['changed'], bool)
    assert isinstance(result['msg'], str)
    assert result['failed'] == False
    assert result['validate_args_context'] == 'validate_args_context'


# Generated at 2022-06-25 07:54:10.413733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:54:16.957494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:54:28.041429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # required for assertions
    import ansible.module_utils.errors

    # test case:
    # argument_spec = {}
    # provided_arguments = {}
    # task_vars = {}
    # expected = ansible.module_utils.errors.AnsibleError
    # result = action_module_0.run(task_vars)
    # assert isinstance(result, expected) is True
    # assert result['msg'] == 'Incorrect type for argument_spec, expected dict and got <class \'dict\'>'
    # assert result['failed'] == True
    # assert result['changed'] == False
    # return result

    # test case:
    # argument_spec = {'test': {'type': 'dict'}}
    # provided_arguments = {}
    #

# Generated at 2022-06-25 07:54:35.123410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception as err:
        print("FAIL: " + str(err))
        return 1


# Generated at 2022-06-25 07:54:42.891523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        tmp = None
        task_vars=dict()
        action_module_0 = ActionModule()
        tmp = {}
        assert action_module_0.run(tmp, task_vars) == {'msg': 'AnsibleError - "argument_spec" arg is required in args: {\'validate_argument_spec\': True}', 'failed': True, 'validate_args_context': {'validate_argument_spec': True}}

    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 07:54:53.096206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.task = {"args": {"argument_spec": {"a": {"b": "default"}, "b": {"c": 2}, "c": {"a": 2}}, "provided_arguments": {"c": 2, "d": "a"}, "validate_args_context": {"module_name": "test", "module_path": "test"}}, "action": "validate_argument_spec", "notify": None, "delegate_to": None}
    action_module_0._loader = {"_basedirs": ["/ansible/ansible"], "path_dwim": "/ansible/ansible/lib/ansible/utils/module_docs_fragments"}

# Generated at 2022-06-25 07:55:03.945098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac = ActionModule()
    tmp = None
    task_vars = {
        'argument_spec': {
            'test1': {'type': 'str'},
            'test2': {'type': 'str'},
            'test3': {'type': 'str'}
        },
        'provided_arguments': {
            'test1': 'hello',
            'test2': 'world',
            'test3': '!'
        }
    }
    expected = {
        'changed': False,
        'failed': False,
        'msg': 'The arg spec validation passed',
        'validate_args_context': {}
    }
    actual = ac.run(tmp, task_vars)
    assert actual == expected


# Generated at 2022-06-25 07:55:12.730068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Setup mock values
    tmp = None
    task_vars = {"task var 0": "task var 0"}
    # Execute method
    result = action_module_0.run(tmp, task_vars)
    assert result["msg"] == "The arg spec validation passed"
    assert result["changed"] == False
    assert result["failed"] == False
    assert result["validate_args_context"] == {}



# Generated at 2022-06-25 07:55:14.989730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None
    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-25 07:55:18.692406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None


# Generated at 2022-06-25 07:55:20.632963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0.__class__.__name__ == 'ActionModule'



# Generated at 2022-06-25 07:55:31.823682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 is not None

# Generated at 2022-06-25 07:55:32.973008
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 07:55:34.552786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''
    action_module_0 = ActionModule()
    pass


# Generated at 2022-06-25 07:55:44.652015
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    obj = ActionModule()
    obj._templar = MockTemplar()

    task_vars_0 = { }
    argument_spec_0 = { }
    ret_0 = obj.get_args_from_task_vars(argument_spec_0, task_vars_0)
    assert ret_0 == task_vars_0

    task_vars_1 = { 'scratch0_0': 'scratch1_0' }
    argument_spec_1 = { 'scratch0_0': { 'type': 'str' } }
    ret_1 = obj.get_args_from_task_vars(argument_spec_1, task_vars_1)
    assert ret_1 == task_vars_1



# Generated at 2022-06-25 07:55:52.609713
# Unit test for constructor of class ActionModule
def test_ActionModule():
    args = dict()
    args['argument_spec'] = dict()
    args['conn_path'] = 'conn_path'
    args['play'] = 'play'
    args['task'] = 'task'
    args['remove_partial_charges'] = 'remove_partial_charges'
    args['only_if_command'] = 'only_if_command'
    args['only_if'] = 'only_if'
    args['async_val'] = 'async_val'
    args['first_available_file'] = 'first_available_file'
    args['delegate_to'] = 'delegate_to'
    args['run_once'] = 'run_once'
    args['become_user'] = 'become_user'
    args['set_stats'] = 'set_stats'

# Generated at 2022-06-25 07:55:57.384118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Pass a mock value for tmp
    tmp = None
    # Pass a mock value for task_vars
    task_vars = dict()

    # Call the run method
    # This will fail the test if run() raises an exception
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:55:59.959995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert type(action_module_0) == ActionModule


# Generated at 2022-06-25 07:56:02.773185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    results = []
    # FIXME: replace those with test cases
#     results.append(test_case_0())

    for res in results:
        print(res)

# Generated at 2022-06-25 07:56:10.425821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of the class to be tested
    action_module_0 = ActionModule()

    # Make a mock tmp value
    tmp_0 = 'tmp_0'

    # Make a mock task_vars value
    task_vars_0 = 'task_vars_0'

    # Call the method under test
    result_0 = action_module_0.run(tmp_0, task_vars_0)

    # Assert the results are as expected
    assert result_0 == 'result_0'


# Generated at 2022-06-25 07:56:18.112529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()

    assert action_module_1 is not None
    assert action_module_2 is not None


# Generated at 2022-06-25 07:56:34.447935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)
    assert action_module_0 is not None


# Generated at 2022-06-25 07:56:39.934201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '`X^n*;Y>|\r'
    bool_0 = True
    str_1 = 'set_dscp_mark_class'
    bytes_0 = b'\xe5\x8c\x90\xe1'
    dict_0 = {}
    str_2 = 'set_dscp_mark_class'
    obj_0 = ActionModule(str_0, bool_0, str_1, bytes_0, dict_0, str_2)
    module_attributes = dir(obj_0)
    assert( 'run' in module_attributes )



# Generated at 2022-06-25 07:56:46.178653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)
    var_0 = action_module_0.run(bool_1, str_2)


# Generated at 2022-06-25 07:56:53.442483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)
    var_0 = action_module_0.run(str_0, str_2)

# Generated at 2022-06-25 07:57:01.747303
# Unit test for constructor of class ActionModule
def test_ActionModule():
  str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
  bool_0 = False
  bool_1 = True
  str_1 = '/,'
  str_2 = 'set_dscp_mark_class'
  str_3 = 'set_dscp_mark_class'
  bytes_0 = b'\x17w\xdf\xad'
  dict_0 = {bool_1: str_1}
  action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_3)
  assert bool_0 == action_module_var_0(action_module_0)
  assert str_0 == action_module_var_1(action_module_0)
  assert bool_

# Generated at 2022-06-25 07:57:02.715532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # TODO: Implement test for run of method ActionModule
  return None

# Generated at 2022-06-25 07:57:09.514164
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'q3~Mb`cZ]{'
    int_0 = 171612597
    str_1 = '8'
    str_2 = 'dict'
    bytes_0 = b'\x11\x03\xd6\xca\xa8\x16\x91\x89\x9d\x97'
    dict_0 = {str_2: bool_0}
    action_module_0 = ActionModule(bytes_0, int_0, str_1, str_1, dict_0, str_0)
    action_module_0.run(bytes_0, bool_0)

# Generated at 2022-06-25 07:57:13.019977
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert action_module_0 != None


# Generated at 2022-06-25 07:57:19.444231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = '^\t}]W&\x1f)0I\x0cpi'
    str_1 = 'ansible_facts'
    bool_1 = True
    str_2 = '\x11\x0b\x06'
    bytes_0 = b"\xa6\xcc\xd0"
    dict_0 = {str_1: str_0}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)


# Generated at 2022-06-25 07:57:28.212279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of class
    argument_spec = {'argument_spec': {}}
    provided_arguments = {}
    obj = ActionModule(argument_spec, provided_arguments, argument_spec, action_get_args_from_task_vars, action_run)
    assert not obj.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:57:50.506347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)
    action_module_0.action_get_args_from_task_vars()


# Generated at 2022-06-25 07:57:55.997557
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test 1: Constructor of ActionModule")
    str_0 = '\x02\x04\x02\x04\x02\x04\x04\x04\x02\x04\x02\x02\x02\t\n\n\x10\x12\r\r\r\r\r\r\r\r\r\r\r\r\r'
    bool_1 = True

# Generated at 2022-06-25 07:58:04.851138
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bool_0 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)
    var_0 = action_get_args_from_task_vars(bool_0, str_0)

# Generated at 2022-06-25 07:58:15.083689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)
    str_3 = 'g;3E\x07f\x1f'
    str_4 = '\x1a/\x7f'
    str_5 = 'b*y'

# Generated at 2022-06-25 07:58:15.701076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:58:23.007915
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    bool_2 = True
    str_3 = '0A'
    str_4 = 'I'
    bool_3 = True
    str_5 = 'run'
    bytes_1 = b'\x81\x00\x9ae\x12u\x83'
    dict_1 = {str_0: str_1}
    action_module_1 = ActionModule(str_3, bool_3, str_5, bytes_1, dict_1, str_5)
    argument_spec_data_0 = {bytes_1: str_3}
    task_vars_0 = {str_4: str_4}
    assert not action_module_1.get_args_from_task_vars(argument_spec_data_0, task_vars_0)


# Generated at 2022-06-25 07:58:32.354373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import io
    from ansible.compat.six import StringIO

    # read in the test cases
    fixture = io.open("../tests/fixtures/action_plugins/test_run.json")
    example_test_cases = json.load(fixture)
    fixture.close()

    # setup test cases
    for test_case in example_test_cases:
        result = test_case.get("result")
        expected_result = test_case.get("expected_result")
        result['inventory_hostname'] = 'localhost'

        # run the test case
        check_args = test_case.get("check_args")
        check_result = test_case.get("check_result")
        if check_args:
            module = AnsibleModule(argument_spec=check_args)
            result = self.runner._

# Generated at 2022-06-25 07:58:39.045189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:58:48.299576
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_2 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_2: str_1}
    action_module_0 = ActionModule(str_1, bool_2, str_2, bytes_0, dict_0, str_2)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.TRANSFERS_FILES is False


# Generated at 2022-06-25 07:58:58.764315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test if function definition of run is correct
    try:
        assert inspect.isfunction(ActionModule.run)
    except AssertionError:
        raise AssertionError('{} definition is incorrect'.format('run'))

    # Test if method arg has correct types
    try:
        assert True and isinstance(ActionModule.run.__code__.co_varnames, tuple)
    except AssertionError:
        raise AssertionError('{} does not have correct types for args'.format('run'))

    # Test if method arg has correct value

# Generated at 2022-06-25 07:59:40.914082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'D\x1c=W\x08\t\x09\x15\x18\x1f\x13\x11\x10\x0e'
    bool_0 = True
    str_1 = '?g\x9f\x9d\xc5\xd6\xcf\xcc\xd1\xcf\xd2\xce\xd9\x99\xd1\xb5\xbd\xc5\xd0\xc9\x9a\x9a\x9c\x9b\x97\x9c\x9d\x9c\x9f\x9d\x9d\x9b\x9f'
    bool_1 = False

# Generated at 2022-06-25 07:59:43.171479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Instantiating object using constructor
        ActionModule()
    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 07:59:50.923752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    str_0 = 'Bnaf\x0c\x14\x03\x18\x1c\t\\\x08\x0f\x14\x04\x12\x0f!\x19\x1d\x19\x01\x1f\x16\x1d'
    str_1 = 'action_run'
    str_2 = 'action_run'
    bytes_0 = b'\x07\x1a\x7f'
    dict_0 = {}
    action_module_0 = ActionModule(str_0, bool_0, str_1, bytes_0, dict_0, str_2)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:59:57.293891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)


# Generated at 2022-06-25 08:00:04.269249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'dI?2IUvI*_\x0b"O,E{rG'
    str_1 = '/,'
    bool_0 = False
    bool_1 = True
    str_2 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_1: str_1}
    action_module_0 = ActionModule(str_1, bool_1, str_2, bytes_0, dict_0, str_2)
    action_get_args_from_task_vars(bool_0, str_0)
    action_module_0.run(str_0, str_0)


# Generated at 2022-06-25 08:00:09.288463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '/,'
    bool_0 = True
    str_1 = 'set_dscp_mark_class'
    bytes_0 = b'\x17w\xdf\xad'
    dict_0 = {bool_0: str_0}
    action_module_0 = ActionModule(str_0, bool_0, str_1, bytes_0, dict_0, str_1)
    bool_1 = action_module_run(action_module_0, bool_0, bool_0)

# Generated at 2022-06-25 08:00:18.647849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization of the class object
    bool_0 = False
    str_0 = 'c%~E'
    str_1 = 'validate_argument_spec'
    bytes_0 = b'\x1f\xc9E\x80'
    dict_0 = {str_0: str_1}
    action_module_0 = ActionModule(str_0, bool_0, str_1, bytes_0, dict_0, str_1)
    # case 1
    str_1 = '\x15\x1b\x13'
    dict_0 = {str_0: str_1}
    dict_1 = {str_1: dict_0}
    result_0 = action_module_0.run(dict_0, dict_1)

# Generated at 2022-06-25 08:00:26.181347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ArgumentSpecValidator with argument spec data
    attr_bool_0 = False
    attr_str_0 = None
    attr_str_1 = None
    attr_str_2 = "arg_str_2"
    attr_str_3 = "arg_str_3"
    attr_str_4 = "arg_str_4"
    attr_str_5 = "arg_str_5"
    attr_str_6 = "arg_str_6"
    attr_str_7 = "arg_str_7"
    attr_str_8 = "arg_str_8"
    attr_str_9 = "arg_str_9"
    attr_str_10 = "arg_str_10"

# Generated at 2022-06-25 08:00:32.358000
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    str_0 = 'R|Yj{7>D%%<'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0)
    assert action_module_0.tmp is False
    assert action_module_0.transfers_files is False
    assert action_module_0._task is str_0
    assert action_module_0._connection is str_0
    assert action_module_0._play_context is str_0
    assert action_module_0.shared_loader_obj is str_0
    assert action_module_0._templar is not None


# Generated at 2022-06-25 08:00:40.561626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'set_dscp_mark_class': 10}
    list_0 = [dict_0, dict_0]
    dict_1 = {'set_dscp_mark_class': 2}
    list_1 = [dict_1, dict_1]
    dict_2 = {'set_dscp_mark_class': 5}
    list_2 = [dict_2, dict_2]
    dict_3 = {'set_dscp_mark_class': 20}
    list_3 = [dict_3, dict_3]
    dict_4 = {'set_dscp_mark_class': 5}
    list_4 = [dict_4, dict_4]
    dict_5 = {'set_dscp_mark_class': 100}
    list_5