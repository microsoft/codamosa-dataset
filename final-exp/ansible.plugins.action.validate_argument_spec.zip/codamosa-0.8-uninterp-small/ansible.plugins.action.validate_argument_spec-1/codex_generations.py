

# Generated at 2022-06-25 07:52:15.986824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ",j'oNk$6BGo^q"
    float_0 = 512.0
    dict_0 = {str_0: str_0, float_0: str_0}
    int_0 = 131072
    set_0 = None
    action_module_0 = ActionModule(str_0, dict_0, dict_0, int_0, set_0, set_0)
    try:
        test_case_0()
    except Exception as e:
        assert type(e) == AnsibleValidationErrorMultiple
        assert type(e) == AnsibleValidationErrorMultiple
        assert type(e) == AnsibleValidationErrorMultiple
        assert type(e) == AnsibleValidationErrorMultiple

# Generated at 2022-06-25 07:52:21.327631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    str_0 = "Nvb`'`W8`MO89^K"
    float_0 = 0.14285714285714285
    dict_0 = {str_0: float_0, float_0: float_0}
    int_0 = 524288
    set_0 = None
    action_module_0.run(dict_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:52:32.501676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ",j'oNk$6BGo^q"
    float_0 = 512.0
    dict_0 = {str_0: str_0, float_0: str_0}
    int_0 = 131072
    set_0 = None
    action_module_0 = ActionModule(str_0, dict_0, dict_0, int_0, set_0, set_0)
    argument_spec_0 = {}
    task_vars_0 = {}
    result_0 = action_module_0.run(argument_spec_0, task_vars_0)
    print("ActionModule.run() returned : %s" % result_0)

if __name__ == "__main__":
    print("Running tests on class ActionModule")
    print("====================")
    test

# Generated at 2022-06-25 07:52:39.599982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict()
    params['argument_spec'] = dict()
    params['provided_arguments'] = dict()
    action_module_0 = ActionModule('tmp', 'task_vars')
    result = action_module_0.run(params['argument_spec'], params['provided_arguments'])
    assert(result)

# Generated at 2022-06-25 07:52:49.000125
# Unit test for constructor of class ActionModule
def test_ActionModule():

    str_0 = "o`pw_l)"
    dict_0 = dict()
    dict_1 = dict()
    int_0 = 2096
    set_0 = set()
    set_1 = None
    action_module_0 = ActionModule(str_0, dict_0, dict_1, int_0, set_0, set_1)

    assert dict_0 is not None
    assert dict_1 is not None
    assert not hasattr(action_module_0, "dict_0")
    assert not hasattr(action_module_0, "dict_1")
    assert int_0 is not None
    assert set_0 is not None
    assert set_1 is not None
    assert hasattr(action_module_0, "set_0")

# Generated at 2022-06-25 07:52:50.900983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:53:01.857995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "`x"
    float_0 = 14.0
    dict_0 = {str_0: float_0}
    int_0 = 0
    set_0 = None
    action_module_0 = ActionModule(str_0, dict_0, dict_0, int_0, set_0, set_0)

    # test case
    str_0 = "TF)GOJ&'5+5d5fNl;F8YJc%V+:b!HlIW|"
    float_0 = 473.0
    dict_0 = {str_0: float_0}
    int_0 = 4096
    set_0 = None
    dict_1 = {str_0: float_0}
    set_1 = None


# Generated at 2022-06-25 07:53:08.498013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'gL&iZEDH]P'
    dict_0 = {str_0: str_0, }
    dict_1 = {str_0: dict_0, }
    int_0 = 514
    set_0 = None
    set_1 = {str_0, }
    action_module_0 = ActionModule(str_0, dict_0, dict_1, int_0, set_0, set_1)
    result = action_module_0.run()
    assert result['validate_args_context'] == {}, 'Expected result to contain {}, but it didn\'t'
    assert not result['failed'], 'Expected False, but got {result[\'failed\']}'

# Generated at 2022-06-25 07:53:15.455371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'E'
    float_0 = 512.0
    float_1 = 32768.0
    float_2 = 2.0
    str_1 = "0"
    float_3 = 5.0
    float_4 = 32.0
    str_2 = 'c'
    set_0 = None
    float_5 = 1024.0
    str_3 = 'i'
    float_6 = 1638.4
    float_7 = 0.0
    int_0 = 16384
    float_8 = 10.0
    str_4 = "0,*"
    float_9 = 64.0
    int_1 = 491520
    float_10 = 65535.0
    float_11 = 2048.0
    str_5 = '!i'
    float_12 = 8.

# Generated at 2022-06-25 07:53:23.775603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "f,5vS8W:e|m'%cG<hF,!4?:QHPk-dz+0-XO"
    float_0 = 142290.40625
    dict_0 = {str_0: float_0, float_0: float_0}
    int_0 = 131072
    set_0 = None
    action_module_0 = ActionModule(str_0, dict_0, dict_0, int_0, set_0, set_0)
    with pytest.raises(AnsibleError, match=r'Incorrect type for argument_spec, expected dict and got'):
        action_module_0.run(set_0)


# Generated at 2022-06-25 07:53:38.586086
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    params_0 = dict()
    argument_spec_0 = dict()
    argument_spec_0['argument_spec'] = dict()
    argument_spec_0['argument_spec'] = dict()
    argument_spec_0['validate_args_context'] = dict()
    argument_spec_0['validate_args_context']['module_name'] = 'test'
    argument_spec_0['validate_args_context']['module_path'] = './test.py'

    action_module_0 = ActionModule(set_0, bool_0, str_0, set_0, set_0, float_0)

    with pytest.raises(AnsibleError) as excinfo:
        action_module_0.run(set_0, argument_spec_0)

    exception_msg = excinfo

# Generated at 2022-06-25 07:53:44.839628
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:53:55.291180
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bool_0 = False
    str_0 = '--yaml'
    float_0 = -520.931
    action_module_0 = ActionModule(set_0, bool_0, str_0, set_0, set_0, float_0)
    # The values for module function run are provided here
    tmp = 'tmp'
    task_vars = dict()
    try:
        action_module_0.run(tmp, task_vars)
        assert False
    except ValueError as e:
        assert type(e) == ValueError
    # The return value of method run is a dict, which is passed to the
    # AnsibleModule._execute_module() method. The return value of
    # _execute_module() will be passed to AnsibleModule._load_result() method.


# Generated at 2022-06-25 07:53:58.706484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    action_module_0 = ActionModule(set_0, bool_0, str_0, set_0, set_0, float_0)
    action_module_0.run(tmp=tmp_0, task_vars=task_vars_0)


# Generated at 2022-06-25 07:54:06.784497
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bool_0 = False
    str_0 = '--yaml'
    float_0 = -520.931
    action_module_0 = ActionModule(set_0, bool_0, str_0, set_0, set_0, float_0)

    tmp_0 = 'tmp'
    task_vars_0 = {}

    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0 == None


# Generated at 2022-06-25 07:54:13.465987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(set(), False, '--yaml', set(), set(), -520.931)
    action_module_0.run()
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:54:18.857499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    bool_0 = False
    str_0 = '--yaml'
    float_0 = -520.931
    action_module_0 = ActionModule(set_0, bool_0, str_0, set_0, set_0, float_0)


# Generated at 2022-06-25 07:54:25.018818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = dict()
    bool_0 = False
    str_0 = '*vFkVyNtN'
    float_0 = -269.83917
    action_module_0 = ActionModule(set_0, bool_0, str_0, set_0, set_0, float_0)
    tmp_1 = None
    task_vars_1 = dict()

    # Call method run
    # Return value specification is not checked yet
    action_module_0.run(tmp_1, task_vars_1)

# Generated at 2022-06-25 07:54:30.284090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    set_0 = None
    bool_0 = False
    str_0 = '--yaml'
    float_0 = -520.931

# Generated at 2022-06-25 07:54:34.291233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    bool_0 = False
    str_0 = '--yaml'
    float_0 = -520.931
    action_module_0 = ActionModule(set_0, bool_0, str_0, set_0, set_0, float_0)
    action_module_0.run()
    action_module_0.run()


# Generated at 2022-06-25 07:54:49.713096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = dict()
    var_0['playbook_dir'] = '/ansible/test'
    var_0['play_context'] = '/ansible/test'
    var_0['play'] = '/ansible/test'
    var_0['task'] = '/ansible/test'
    var_1 = dict()
    var_1['inventory'] = '/ansible/test'
    var_1['vars'] = '/ansible/test'
    var_1['vars_prompt'] = '/ansible/test'
    var_1['vars_files'] = '/ansible/test'
    var_1['defaults'] = '/ansible/test'
    var_1['task_vars'] = '/ansible/test'
    var_1['args'] = '/ansible/test'
   

# Generated at 2022-06-25 07:54:52.669938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(var_0, var_1)
    assert isinstance(obj, ActionModule)


# Generated at 2022-06-25 07:55:03.700821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_cases = [
        # Test case 0
        {
            'test_case_number': 0,
            'expected_errors': [],
        },
    ]

    for test_case in test_cases:
        test_case_number = test_case['test_case_number']

        # Perform the test
        module = ActionModule()

        try:
            method_return_value = module.run(var_0, var_1)
        except AnsibleValidationErrorMultiple as e:
            method_return_value = e.args[0]

        # Verify that the method returned the expected value
        assert method_return_value == test_case['expected_errors'], 'Test case number {} failed'.format(test_case_number)

# Generated at 2022-06-25 07:55:08.618352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_2 = ActionBase()
    var_3 = ActionBase()
    # Verify that the object is of the correct type
    assert type(var_3) is ActionBase


# Generated at 2022-06-25 07:55:09.424765
# Unit test for constructor of class ActionModule
def test_ActionModule():

    actionModule = ActionModule()


# Generated at 2022-06-25 07:55:17.975066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get the parameter model and construct the required args
    var_0 = dict()

    var_0['validate_args_context'] = dict()
    var_0['failed'] = False
    var_0['msg'] = 'The arg spec validation passed'
    var_0['changed'] = False
    var_0['stdout'] = ''
    var_0['stdout_lines'] = ['']
    var_0['stdout_json'] = dict()
    var_0['stderr'] = ''
    var_0['stderr_lines'] = ['']
    var_0['rc'] = 0
    var_0['start'] = '2020-10-20 18:55:55.838354'
    var_0['end'] = '2020-10-20 18:55:55.838354'

# Generated at 2022-06-25 07:55:19.431384
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_0.run(tmp=var_1, task_vars=var_0)

# Generated at 2022-06-25 07:55:20.327231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:55:21.403933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var = ActionModule()
    var.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:55:22.820329
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(AnsibleError, match="'argument_spec' arg is required in args: {}"):
        test_case_0()

# Generated at 2022-06-25 07:55:38.199833
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Initialize parameters (init method not called since this is an inline test)
    action_module = ActionModule()
    action_module._templar = None

    task_vars = dict(a=10)
    argument_spec = dict(b=dict(type='int'), c=dict(type='list', default=[]), d=dict(type='list'))

    result = action_module.get_args_from_task_vars(argument_spec=argument_spec, task_vars=task_vars)
    assert result == dict()

    task_vars = dict()
    argument_spec = dict(b=dict(type='int'), c=dict(type='list', default=[]), d=dict(type='list'))


# Generated at 2022-06-25 07:55:46.261387
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def check_obj(obj):
        assert isinstance(obj, ActionModule)
        assert isinstance(obj._task, dict)
        assert isinstance(obj._play_context, dict)
        assert isinstance(obj._loaded_frm_file, dict)
        assert isinstance(obj._task_vars, dict)
        assert isinstance(obj._templar, dict)
        assert isinstance(obj._shared_loader_obj, dict)
        assert isinstance(obj._connection, dict)
        assert isinstance(obj._play, dict)
        assert isinstance(obj._loader, dict)
        #assert isinstance(obj._start_at, dict)
        assert isinstance(obj._step, dict)
        assert isinstance(obj._play_context, dict)
        assert isinstance(obj._play_context, dict)


# Generated at 2022-06-25 07:55:47.987531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run()")
    action_module_obj = ActionModule()
    assert action_module_obj.run()
    del action_module_obj

# Generated at 2022-06-25 07:55:58.657987
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_0 = ActionModule()

    # Set up mock
    url_0 = 'http://docs.ansible.com/ansible/dev_guide/developing_api.html#python-api-2-0'
    url_1 = 'https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/network.py#L1279'


# Generated at 2022-06-25 07:55:59.902958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 07:56:00.891736
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()


# Generated at 2022-06-25 07:56:09.394292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    # TODO Remove this line when it is no longer necessary
    loaded_var_file = {'var': 'file'}

    action_module_1 = ActionModule()
    tmp = None
    task_vars = {'validate_argument_spec': loaded_var_file}
    expected_result_1 = {'failed': False, 'msg': 'The arg spec validation passed'}
    result_1 = action_module_1.run(tmp, task_vars)
    assert result_1 == expected_result_1


# Generated at 2022-06-25 07:56:20.822581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_0 = ActionModule()
    tmp = 'tmp'
    task_vars = {}
    action_module_run_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:56:27.190036
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Run action module
    params = {
        'argument_spec': {
            'a1': {
                'type': 'str'
            },
            'a2': {
                'type': 'list',
                'elements': 'str'
            }
        },
        'validate_args_context': {
            'role': 'test_role',
            'task': 'main',
            'task_path': '/path/to/task',
            'entry_point': 'main'
        },
        'provided_arguments': {
            'a1': 'some string',
            'a2': [
                'somelist'
            ]
        }
    }

    action_module_run = ActionModule()
    action_module_run.run(params)

    # Test assertion

# Generated at 2022-06-25 07:56:32.980322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    spec = {'host': {'type': 'str'}, 'age': {'type': 'int', 'required': True}}
    args = {'host': 'localhost', 'age': 10}

    act_mod = ActionModule()
    result = act_mod.run({}, {'argument_spec': spec, 'provided_arguments': args})
    assert not result['failed']
    assert result['changed'] is False



# Generated at 2022-06-25 07:56:43.950210
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    str_0 = 'z]^*t}sKj>I0|+@'
    dict_0 = {str_0: str_0}
    str_1 = 'JSBV:b%c[!|\x02J1H&'
    tuple_0 = (str_1,)
    bytes_0 = b'*\x1a\xd0\x00\xdb\x17\xaa\x11\x0b\x00\x02\xf4\x03\xb2\x1c\xd7\xc7\x13\x8b\xbf\x94\xbe\xc9'
    float_0 = 0.717073827430001

# Generated at 2022-06-25 07:56:53.314423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get the action class
    action_module = ActionModule()

    # start unit test for method run
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)
    # validation pass
    assert result['changed'] is False
    assert result['failed'] is False

    # start unit test for method run
    tmp = None
    task_vars = None
    result = action_module.run(tmp, task_vars)
    # validation failed, include arg spec data in results
    assert result['argument_spec_data'] == {'test_name': {'type': 'str', 'description': 'Test description'}}
    assert result['argument_errors'] == ['test_name should be a str']

    # start unit test for method run
    tmp = None
    task_v

# Generated at 2022-06-25 07:57:01.746654
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    str_0 = 'S\x11'
    dict_0 = {str_0: str_0}
    str_1 = '\x1f'
    tuple_0 = (str_1,)
    bytes_0 = b'\x0b\x17[\x1a\x0b\x11\x10\x08\x0e\x18\x10\x13'
    float_0 = 16346.9
    str_2 = '\x00\x1d\x03?E\x00\x04\x0e\x18\x1f\x1d\x00'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)
    bool_0 = False
    var_0 = False

# Generated at 2022-06-25 07:57:09.879299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Q/@"\x15eQ0eg`DOhV\x14'
    dict_0 = {str_0: str_0}
    str_1 = 'e\x0c*:oFCP~o]\x0f'
    tuple_0 = (str_1,)
    bytes_0 = b'#\x07\xed\xce\x88\x05\xc3\x1b\xb7\xbd\xbdJ\x88\x18\xa7\xce\x85B\x05\x9d\x1b\x18'
    float_0 = 5937.2796996632605
    str_2 = 'B)ZrF#n6Uv+A=z\x15uw7'
    action_module_0 = Action

# Generated at 2022-06-25 07:57:20.144083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '{J^/H}/YbE?gw'
    dict_0 = {str_0: str_0}
    str_1 = '\x12b-MQUw'
    tuple_0 = (str_1,)
    bytes_0 = b'#\xbb\x04\x1c\x06\x82\n_\x83\x1a'
    float_0 = 582.6395968871887
    str_2 = 'KM\x1f8N:W$-vOz'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)
    str_3 = 'lp"e\x0e^q@h<'

# Generated at 2022-06-25 07:57:31.697055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 223.898273719
    list_0 = [float_0, float_0, float_0, float_0, float_0]
    list_0[0] = float_0
    list_0[1] = 'bt?5m}'
    bytes_0 = b'\x1ch\x16\xc1\xd8\xab\x02\xbeC\x9d\x96\xa2\x14i\x1c\xe8'
    float_1 = float_0
    str_0 = 'as4U6A{UqD'
    float_2 = 4.97
    tuple_0 = (str_0,)
    str_1 = 'G~\x0e'
    tuple_1 = (float_2,)
    list_0[2]

# Generated at 2022-06-25 07:57:43.164440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x14\x15\x16\x17\x18\x19'
    dict_0 = {str_0: str_0}
    str_1 = '\x1a\x1b\x1c\x1d\x1e\x1f'
    tuple_0 = (str_1,)
    bytes_0 = b'\xe4`m\x08\xe8a\x02\xd6\x04Cjk\x18<`i\x9c\xb9'
    float_0 = 2346.457153480026

# Generated at 2022-06-25 07:57:51.202129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    j = dict()
    j['e'] = dict()
    j['e']['f'] = dict()
    j['e']['f']['h'] = dict()
    j['e']['f']['h']['i'] = dict()
    j['e']['f']['h']['i']['j'] = dict()
    j['e']['f']['h']['i']['j']['k'] = dict()
    j['e']['f']['h']['i']['j']['k']['l'] = 'm'
    assert_equal(ActionModule.run('n', 'o', 'p', dict()), j)


assert_equal(test_ActionModule_run(), None)


# Generated at 2022-06-25 07:57:56.403042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '!Me\x14\x14\x1d\x1c\x1dZ\nT\x0c'
    dict_0 = {str_0: str_0}
    str_1 = '\rrJ/W/35=4!4b/'
    tuple_0 = (str_1,)
    bytes_0 = b'\x8d\x0e\x12U\x11\xb8{R\x1fk\x05=\x9a\xcf\xf1'
    float_0 = 11.86826298613274
    str_2 = '"\r\'\t"\r\r\r\r\r\r\\r\r\r\\r\r'

# Generated at 2022-06-25 07:58:06.272795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    tuple_0 = ()
    str_0 = 'Z5F,vN/{Nbo8x36@\x05'
    bytes_0 = b'\x9c\x1d\x9c\x17\t\xab\r\xff\x18\x8b\x9c\x06R\x1e'
    float_0 = 524.6390833207469
    str_1 = 'l)V*'
    action_module_0 = ActionModule(dict_0, tuple_0, str_0, bytes_0, float_0, str_1)
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_0.run()
    action_module_

# Generated at 2022-06-25 07:58:31.693227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'P\x19UunW\x1b{\x1c[p\x1eM-\x10\x14'
    dict_0 = {str_0: AttributeError}
    str_1 = 'X,\x1a}Lb\x15\x15dJ6\x1e?z'
    tuple_0 = (str_1,)
    bytes_0 = b'\x1d\x03\xe0\x014\x08\x7f\x1c\x7fq\x1cFt\x1d\x17'
    float_0 = 0.1493142660490847
    str_2 = 'yS\x03\x04\x08\x11\x14'

# Generated at 2022-06-25 07:58:39.077305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'W;0v\x1b5A]9e'
    dict_0 = {str_0: str_0}
    str_1 = '\tE\x7f\x0c3'
    tuple_0 = (str_1,)
    bytes_0 = b'\xce\x94\x9a\xd6\x1f\xf0'
    float_0 = 63226.28351807906
    float_1 = float_0
    action_module_0 = ActionModule(dict_0, tuple_0, str_0, bytes_0, float_1, str_1)
    var_0 = action_module_0.run(str_0, bytes_0)



# Generated at 2022-06-25 07:58:49.114997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    j_dict_0 = {"type": "dict"}
    j_dict_1 = {"type": "dict"}
    j_dict_2 = {"type": "dict"}
    j_dict_3 = {"type": "dict"}
    j_dict_4 = {"type": "dict"}
    temp_dict = {'type': 'dict'}
    temp_dict2 = {'type': 'dict'}
    temp_dict3 = {'type': 'dict'}
    j_value_0 = "test"
    j_dict_5 = {"type": "dict", "elements": "test"}

# Generated at 2022-06-25 07:58:59.848338
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x1b\x1f;\x1f\x1f'
    dict_0 = {str_0: str_0}
    str_1 = 'N:}N>'
    tuple_0 = (str_1,)

# Generated at 2022-06-25 07:59:09.746362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Hk`r~R?F,-426'
    dict_0 = {str_0: str_0}
    str_1 = 'z&Q/UpYL*Ub[/v='
    tuple_0 = (str_1,)
    bytes_0 = b'\xe4`m\x08\xe8a\x02\xd6\x04Cjk\x18<`i\x9c\xb9'
    float_0 = 2346.457153480026
    str_2 = 'joDX@#t&?<qrbVYlI\x0c,'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)


# Generated at 2022-06-25 07:59:22.819804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new instance of ActionModule
    str_0 = 'Hk`r~R?F,-426'
    dict_0 = {str_0: str_0}
    str_1 = 'z&Q/UpYL*Ub[/v='
    tuple_0 = (str_1,)
    bytes_0 = b'\xe4`m\x08\xe8a\x02\xd6\x04Cjk\x18<`i\x9c\xb9'
    float_0 = 2346.457153480026
    str_2 = 'joDX@#t&?<qrbVYlI\x0c,'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)
    bool_0 = False


# Generated at 2022-06-25 07:59:30.284780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'h%cAP)+**]XaaCS+q3'
    dict_0 = {str_0: str_0}
    str_1 = 'DYh9TBH1<t?#g4Q/;e'
    tuple_0 = (str_1,)
    bytes_0 = b'\xdc\xa0\x8a\x94\xff\xd2L\xef\xd8\x00Y\x8f\x14'
    float_0 = -87.67758634537445
    str_2 = '94w(7|)/C2F>4t9=*'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)
    play_context_0 = action_

# Generated at 2022-06-25 07:59:40.851490
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 9.7417630057
    str_0 = 'p*x^t\x13w@cs0'
    int_0 = 111
    str_1 = 'y,*<\x1b;\x1d'
    str_2 = 'TJzc%u9|K'

# Generated at 2022-06-25 07:59:47.172410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'argument_spec': dict_0, 'provided_arguments': dict_0, 'validate_args_context': dict_0}
    tuple_0 = (dict_0,)
    action_module_0 = ActionModule(dict_0, tuple_0, dict_0, dict_0, dict_0, dict_0)
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = {'tmp': dict_2, 'task_vars': dict_1}
    action_module_0.run(**dict_3)

    # Unknown type
    dict_3 = {'tmp': dict_2, 'task_vars': str_0}
    action_module_0.run(**dict_3)

    # Unknown type

# Generated at 2022-06-25 07:59:53.032010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'Hk`r~R?F,-426'
    dict_0 = {str_0: str_0}
    str_1 = 'z&Q/UpYL*Ub[/v='
    tuple_0 = (str_1,)
    bytes_0 = b'\xe4`m\x08\xe8a\x02\xd6\x04Cjk\x18<`i\x9c\xb9'
    float_0 = 2346.457153480026
    str_2 = 'joDX@#t&?<qrbVYlI\x0c,'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)


# Generated at 2022-06-25 08:00:28.297878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'S_#=l?\x1dT`TInT*'
    int_0 = 0
    float_0 = 9718.355022910798
    complex_0 = complex(str_0)
    set_0 = {int_0, int_0}
    frozenset_0 = frozenset(set_0)
    action_module_0 = ActionModule(frozenset_0, frozenset_0, str_0, set_0, float_0, complex_0)
    str_1 = '&5U0x]^7Hb~v-uY'
    list_0 = ['#', frozenset_0, int_0]
    tuple_0 = (frozenset_0,)

# Generated at 2022-06-25 08:00:35.212331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'context': 'test_context'}
    tuple_0 = ()
    str_0 = '\x89I\x9f$!\x90\x16\xf1\x99\xe7\xbe\x06k\x9b\xd5\x82\xa3'

# Generated at 2022-06-25 08:00:41.810161
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'wq&7>p#b;\nB]D2'
    dict_0 = {str_0: str_0}
    str_1 = '=6RC\x1e\x19F&X9r'
    tuple_0 = (str_1,)
    bytes_0 = b'\xb1(\x19\xb8,\r\x03\x06\x0b\x1b\x1b\x1b]\x80\xa0\xc2'
    float_0 = 9443.878124040478
    str_2 = '+\n}K3Y\x1b<'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)
    bool_0

# Generated at 2022-06-25 08:00:47.509999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'n/}x-BG%cQ5K.H,': 'n/}x-BG%cQ5K.H,'}
    tuple_0 = ('A{YB-w:xf_z\x14i9',)
    str_0 = 'tP\x03\xc6\x99\x0e\x0eeQD\x9a\x10\xcf\x06\xf1\x18\xae\xd1\xaf\xb6\x8e'
    bytes_0 = b'\xae\x85\xec\xa3\xc1\xe0\xf3\xad\x1a\x8d\x9b\xcd\xce\xb2\xc8s\xaa'
    float_0 = 351896.4710

# Generated at 2022-06-25 08:00:52.770547
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create new instance of class
    test_object = ActionModule()

    # TypeError raised by argument specification for tmp
    with pytest.raises(TypeError):
        test_object.run(tmp='test_string')

    # TypeError raised by argument specification for task_vars
    with pytest.raises(TypeError):
        test_object.run(task_vars='test_string')

    # Empty method
    pass

# Generated at 2022-06-25 08:00:59.238806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'ypfUc]<h\x0fAE!\x1a'
    dict_0 = {str_0: str_0}
    str_1 = 'vn\x1f'
    tuple_0 = (str_1,)
    bytes_0 = b'\x94G\x1c\xf2\x11\xb3\xfd\xd0%\xe9\xfd\xc0\x91\x14\xfe\x13\xba\xba'
    float_0 = 88382.07682525967
    str_2 = '\x13l0\x17sx'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)


# Generated at 2022-06-25 08:01:08.707257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'<\x0e\xe5\x9f\x81\x08\xe1\x06'
    dict_0 = {bytes_0: bytes_0}
    # object of type 'ActionModule'
    action_module_0 = ActionModule(dict_0)
    dict_1 = {bytes_0: bytes_0}
    dict_2 = action_module_0.run(dict_1, dict_1)
    int_0 = 207
    bool_0 = bool_0
    assert (dict_2 == dict_1)
    assert (action_module_0.TRANSFERS_FILES == dict_1)
    assert (dict_2 == dict_1)
    assert (dict_2 == dict_2)
    assert (bytes_0 == dict_2)

# Generated at 2022-06-25 08:01:16.548598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '>F&pwx~0DG/0$/'
    dict_2 = {str_0: str_0}
    str_1 = 'Tl`s[sRp``cx=0'
    tuple_0 = (str_1,)
    bytes_0 = b'\xc1\x93\xf8\x80\x89\x0c\t.\x8a\x90\xc7\x9e'
    float_0 = 5795.891575454204
    str_2 = 'm+F~=-]rY)v9uV7'
    action_module_0 = ActionModule(dict_2, tuple_0, str_2, bytes_0, float_0, str_2)

# Generated at 2022-06-25 08:01:27.699526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_1 = '^]4O\x0e?\x0bHS\x1b2S\x15'
    str_0 = '`\x0b\x1c\x1d[\x0b\x1b\x17\x1d'
    tuple_0 = (str_1,)
    dict_0 = {str_0: str_0}
    str_2 = '\x16\x1b\x1b\x1b\x1d\x1couy\x0c'
    str_3 = 'aA\x1d\x1e[\x1d\x1c@\x03\x05\x0b'

# Generated at 2022-06-25 08:01:36.057264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '&:$b`y{*~KS%K'
    dict_0 = {str_0: str_0}
    str_1 = 'E8I4-=7'
    tuple_0 = (str_1,)
    bytes_0 = b'\xff,\x02\xa0^\xcb\x87\x15\x8e?Z\xf3\xef\xbcHa'
    float_0 = 8826.400426756542
    str_2 = 'zWiPI{'
    action_module_0 = ActionModule(dict_0, tuple_0, str_2, bytes_0, float_0, str_2)
    task_vars_0 = None
    action_module_0.run(None, task_vars_0)

# Unit test