

# Generated at 2022-06-25 07:52:15.275934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x91\x89\xd1\x00\xb8\xd5\x1a\xad\x07\x8c\x16\x99\x1e\x85\xfa\x87'
    set_1 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    list_1 = [set_1, set_1, set_1, set_1]

# Generated at 2022-06-25 07:52:23.509383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # tmp=None, task_vars=None
    # test case
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '\t2m5Vpn4v2CGv+}s'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    result = action_module_0.run(None, None)
    assert result['validate_args_context'] == {}

# Generated at 2022-06-25 07:52:36.642260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    f = file('/tmp/ansible_action_plugin__init__.py', 'w+')
    f.close()
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '\t2m5Vpn4v2CGv+}s'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    # Doesn't do anything, but gets the code coverage up


# Generated at 2022-06-25 07:52:46.464740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"\x1c\xbf2%\xf0\xd5=Y\xd2\xdf'!\x80\x85\xef"
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '\t2m5Vpn4v2CGv+}s'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)


# Generated at 2022-06-25 07:52:57.931485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_2 = b'\x8f\xd9\xa1\x1f\x85\xd6\x08\x88'
    set_2 = {bytes_2, bytes_2, bytes_2, bytes_2}
    set_3 = {bytes_2, bytes_2, bytes_2, bytes_2}
    list_1 = [set_2, set_2, set_2, set_2]
    str_1 = '\xaf\xa8\x1d\x16\xb2\x93\x9c\x8a'
    str_2 = '\xbe\x8d\xd4\xbf\x81\x1a\xe8\x19'

# Generated at 2022-06-25 07:53:06.135479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '\t2m5Vpn4v2CGv+}s'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    test_case_0()


# Generated at 2022-06-25 07:53:12.950548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '"js<Y\xa7\xdd\x1c\xacD'

# Generated at 2022-06-25 07:53:23.495023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '\t2m5Vpn4v2CGv+}s'
    bytes_1 = b'#\xed\x80\x98\x1bI\xf2\x11\xa9\x0b\xdb'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    str_1 = 'd_arguments'


# Generated at 2022-06-25 07:53:31.816059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '\t2m5Vpn4v2CGv+}s'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:53:39.309906
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '\t2m5Vpn4v2CGv+}s'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    results_dict = {str_0: True, 'msg': str_0, 'validate_args_context': {}, 'argument_spec_data': {}}
    assert results_dict == action_module_0.run

# Generated at 2022-06-25 07:53:54.317932
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class MockConnection:
        def __init__(self):
            self.data = dict()

        def exec_command(self, cmd, tmp=None, sudoable=True):
            pass

        def put_file(self, in_path, out_path):
            pass

        def fetch_file(self, in_path, out_path):
            pass

    class MockTemplar:
        def __init__(self):
            self.data = dict()

        def set_available_variables(self, variables):
            self.data = variables

        def template(self, var):
            return self.data[var]

    class MockTask:
        def __init__(self):
            self.data = dict()

        def set_args(self, args):
            self.data = args


# Generated at 2022-06-25 07:54:01.170956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    spec = {'required': True, 'type': 'str'}
    argument_spec_data = {'my_str': spec}

    task_vars = {'my_str': 'my str'}
    provided_arguments = {'my_str': 'my str'}

    task_args = {
        'validate_args_context': {},
        'provided_arguments': provided_arguments,
        'argument_spec': argument_spec_data
    }

    action_module = ActionModule(None, task_args, task_vars)

    assert action_module.get_args_from_task_vars(argument_spec_data, task_vars) == {'my_str': 'my str'}

    # run method
    result = action_module.run(None, task_vars)


# Generated at 2022-06-25 07:54:05.453965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test method run of class ActionModule')
    tmp_0 = None
    task_vars_0 = {}
    result_0 = ActionModule.run(tmp_0, task_vars_0)
    print(True)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:54:07.824234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:54:15.098562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_base_instance = ActionBase()
    action_module_instance = ActionModule()
    tmp = None
    task_vars = dict()
    result = action_module_instance.run(tmp, task_vars)
    assert result == action_base_instance.run(tmp, task_vars)

# Testing method run of class ActionModule

# Generated at 2022-06-25 07:54:26.726952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmplar = MagicMock()
    tmplar.template.return_value = dict()

    loader = MagicMock()
    path_exists = MagicMock()
    path_exists.return_value = False
    loader.get_basedir.return_value = '/tmp'
    loader.path_exists.return_value = path_exists
    loader._is_collection_path.return_value = False
    loader.is_file.return_value = False

    variable_manager = MagicMock()
    variable_manager.extra_vars = dict()
    variable_manager.options_vars = dict()
    variable_manager.set_inventory = MagicMock()
    variable_manager.set_task = MagicMock()

    task = MagicMock()
    task.args = dict()

   

# Generated at 2022-06-25 07:54:33.088264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError

    a = '-Úü'
    try:
        test_case_0()
    except AnsibleError:
        pass
    else:
        str_0 = 'Ä\x1cÙ'
        b = '2ÝËÍ¹\n¾¥ÜÛ'

# Generated at 2022-06-25 07:54:38.479059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_args = dict(
        argument_spec=dict(
            argument_name=dict(
                required=True,
                type='str'
            )
        ),
        validate_arguments_from_task_vars=True
    )
    action_module = ActionModule(task=dict(name='test', args=module_args))
    action_module._task.args = dict(validate_arguments_from_task_vars=True, argument_spec=dict(argument_name=dict(required=True, type='str')))
    try:
        action_module.run(tmp=None, task_vars=dict())
    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 07:54:43.927479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {}
    tmp = 'deprecated'

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    action_module.run(tmp, task_vars)



# Generated at 2022-06-25 07:54:46.244558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_ActionModule_0 = ActionModule(None, None, None, None, None, None, None)
    assert isinstance(obj_ActionModule_0, ActionModule)


# Generated at 2022-06-25 07:54:56.809621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    assert (action_module_0._shared_loader_obj == set_0)
    assert (action_module_0._task.args == list_0)
    assert (not action_module_0.no_log)

# Generated at 2022-06-25 07:55:04.062912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    assert not action_module_0.run(), 'If all goes well, action_module_0.run() returns False.'


# Generated at 2022-06-25 07:55:14.788704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    var_0 = action_run()
    var_1 = action_takes_kwargs()
    var_2 = action_async_val()
    var_3 = action_delegate_to()
    var_4 = action_delegate_facts()

# Generated at 2022-06-25 07:55:17.727568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # place into unit test
    # create ActionModule object with required args for object and call run
    pass


# Generated at 2022-06-25 07:55:24.076161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    dict_0 = {}
    dict_1 = {}
    dict_0['this'] = dict_1
    dict_2 = {}
    dict_3 = {}
    dict_2['that'] = dict_3
    list_0 = [dict_0, dict_2]
    str_0 = '9Is\x0c0'
    arguments_spec_0 = dict()
    action_module_0 = ActionModule(bytes_0, dict_0, dict_2, list_0, str_0, str_0)
    data_0 = action_module_0.get_args_from_task_vars(arguments_spec_0, dict_0)

    ActionModule

# Generated at 2022-06-25 07:55:35.366421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    var_0 = action_run()
    if not None:
        action_module_0 = None
    if (not None):
        action_module_0 = None
    if (not None):
        action_module_0 = None
    if (not None):
        action_module

# Generated at 2022-06-25 07:55:44.023901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    # Call action_module_0.run with the appropriate arguments
    pass


# Generated at 2022-06-25 07:55:47.462276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Run test for ActionModule.__init__
    test_case_0()

# Generated at 2022-06-25 07:55:49.328239
# Unit test for constructor of class ActionModule
def test_ActionModule():
	action_module_0 = ActionModule()


# Generated at 2022-06-25 07:55:59.083632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    tmp = None
    task_vars = None
    try:
        action_module_0.run(tmp, task_vars)
    except AnsibleError:
        raise AssertionError

# Generated at 2022-06-25 07:56:09.016727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    var_0 = action_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 07:56:18.613968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test run()")
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:56:24.880616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    with raises(AnsibleError):
        action_module_0.run()

# Generated at 2022-06-25 07:56:29.849595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xee\x98\xdf\x96\xfc\xae\xd6\xa2\x9a\x8e\x93\xa1\xbb\x96\xeb\xb1\x8f\x90'
    set_0 = {}
    set_1 = set({})
    list_0 = [set_0]

# Generated at 2022-06-25 07:56:36.784988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    del tmp_0
    var_0 = action_module_0.run(tmp_0)


# Generated at 2022-06-25 07:56:43.205412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    var_0 = ActionModule(b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X=', set_0, set_0, [set_0, set_0, set_0, set_0], '9Is\x0c0', '9Is\x0c0')
    assert isinstance(var_0.__dict__, dict)



# Generated at 2022-06-25 07:56:53.185765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    var_1 = set()
    var_2 = set()
    var_3 = []
    var_4 = '9Is\x0c0'
    var_5 = '9Is\x0c0'
    var_6 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    assert var_6 != None
    assert var_6._play_context == var_0
    assert var_6._task == var_1
    assert var_6._loader == var_2
    assert var_6._templar == var_3
    assert var_6._shared_loader_obj == var_4

# Generated at 2022-06-25 07:56:57.859602
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xff'
    set_0 = {bytes_0, None, bytes_0, bytes_0}
    list_0 = ['', '', '', '', '']
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, '', '')



# Generated at 2022-06-25 07:57:03.488784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Redirect output to a specific stream
    action_module_0 = ActionModule('3\x1b\x12\\\x0f\\\x9b', '\xfa\x0e\x04\x1e', '\xfa\x0e\x04\x1e', [0, "\xfd\x98\x82\xa4GX\xbb+b\xad\x84X=", "\xfd\x98\x82\xa4GX\xbb+b\xad\x84X=", "\xfd\x98\x82\xa4GX\xbb+b\xad\x84X="], '\xce\x1d', '\xce\x1d')

# Generated at 2022-06-25 07:57:04.942397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner = Runner(action=ActionModule())
    runner.run()

# Generated at 2022-06-25 07:57:30.429014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    assert action_module_0.run()



# Generated at 2022-06-25 07:57:31.804083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:57:43.194797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(not action_module_0.run('tmp0', 'task_vars0'))
    assert(action_module_0.run('tmp1', 'task_vars1'))
    assert(not action_module_0.run())
    assert(action_module_0.run())
    str_0 = '\x1a\x87)Y\x93k\x8ca_\x1d\x15\x12\xdb'
    bytes_0 = b'9b"\x98\xf6\xd0\x1c{'
    assert(not action_module_0.run(str_0, bytes_0))
    assert(not action_module_0.run('tmp2', 'task_vars2'))

# Generated at 2022-06-25 07:57:49.746894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:57:56.599819
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
  set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
  str_0 = '9Is\x0c0'
  list_0 = [set_0, set_0, set_0, set_0]
  action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
  try:
    assert True
  except AssertionError:
    print("Test case ActionModule failed")
  else:
    print("Test case ActionModule passed")


# Generated at 2022-06-25 07:58:01.055984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    assert var_0._task.args.get('argument_spec') is not None
    assert var_0._task.args.get('provided_arguments', {}) is not None



# Generated at 2022-06-25 07:58:01.945030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:58:07.607352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:58:11.329894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = None
    task_vars_0 = None
    obj_0 = ActionModule(tmp_0, task_vars_0)
    result_0 = obj_0.run()
    print(result_0)


# Generated at 2022-06-25 07:58:19.080062
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    int_0 = action_module_run(None, None, None)

if __name__ == '__main__':
	test_case_0()

# Generated at 2022-06-25 07:59:00.073870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)

# Generated at 2022-06-25 07:59:09.993400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b"\x12\x86\x8c\x91\xe0\x18\xc6\x9a\x1c\x91E\x93\x82\xea"
    set_0 = {bytes_0}
    set_1 = set_0
    list_0 = [set_1, set_1, set_1, set_0]
    str_0 = "q[\xe2\xbf\xe8\x0c\x06\xc7\xdc\x19\xee\x97\xbc\x93\xf1\x87\xc2\x96\n"
    str_1 = "\x99\x9f<\x9e\x18\xbb\xb8\x8e\x19"
    action_module_0 = Action

# Generated at 2022-06-25 07:59:16.954745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        tmp = None
        task_vars = None
        action_module_0 = ActionModule(tmp, task_vars)
    except:
        print("Caught exception in constructor of ActionModule")


# Generated at 2022-06-25 07:59:22.019692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    set_0 = {bytes, set_0, list_0, bool, str_0, int, bool}
    result = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0).run(tmp, task_vars)
    assert isinstance(result, dict) == True


# Generated at 2022-06-25 07:59:25.032025
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Nothing to test here
    pass


# Generated at 2022-06-25 07:59:30.357516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:59:39.243593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    var_0 = action_run(set_0)


# Generated at 2022-06-25 07:59:44.389598
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # As op is not given, problem should be raised.
    try:
        ActionModule()
    except Exception as err:
        assert err.args[0] == "missing required positional argument: 'task'"


# Generated at 2022-06-25 07:59:45.576717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 07:59:51.346835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    # TODO: Implement Test
    raise NotImplementedError()


# Generated at 2022-06-25 08:01:23.517151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case where 'provide_arguments' exists and is a dict
    print("test case where 'provide_arguments' exists and is a dict")
    test_case_0()

# Generated at 2022-06-25 08:01:24.810873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    action_module = ActionModule(tmp, task_vars)
    action_module.run()

# Generated at 2022-06-25 08:01:30.653863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'S\x17\xbb\x16\xfb\xc2\x9a\x02\x8c\xeb\xfd\x95\x08\x8c\xac\xa0\x9e\x91\x19h\x98C'}
    dict_0 = {'hostname': 'hostname', 'argument_spec': dict_0, 'provider': dict_0}
    str_0 = '5\\\t\xdb\xe9\x19\xf9\xad\xef\x83\x0e\x1f\x91'
    action_module_0 = ActionModule(str_0, set_0, dict_0, dict_0, str_0, str_0)

# Generated at 2022-06-25 08:01:34.438341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 08:01:42.329625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    value_0 = {'foo': {'required': True, 'type': ['dict', 'int']}, 'bar': {'type': 'list'}}
    globals()['value_0'] = value_0
    with mock.patch('ansible.module_utils.six.string_types', [str]):
        with mock.patch('ansible.module_utils.common.arg_spec.ArgumentSpecValidator.validate', return_value):
            value_0 = action_run()
        with mock.patch('ansible.module_utils.common.arg_spec.ArgumentSpecValidator.validate', return_value):
            value_0 = action_run()


# Generated at 2022-06-25 08:01:49.595761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfd\x98\x82\xa4GX\xbb+b\xad\x84X='
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_0, set_0, set_0]
    str_0 = '9Is\x0c0'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_0)
    assert action_module_0.var_0 == bytes_0, "Expected %s, got %s" % (id(bytes_0), id(action_module_0.var_0))

# Generated at 2022-06-25 08:01:56.650576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'z\x0c\xab\xa9\x9c\x1e$\x8cG\x94\xee\xd2\x14\xa6'
    set_0 = {bytes_0, bytes_0, bytes_0}
    set_1 = {bytes_0, bytes_0, bytes_0}
    list_0 = [set_0, set_1, set_1, set_1]
    str_0 = '<*\x0c'
    str_1 = '1h'
    action_module_0 = ActionModule(bytes_0, set_0, set_0, list_0, str_0, str_1)
    var_0 = action_run()
    assert var_0 == 1

# Test for AnsibleError class