

# Generated at 2022-06-21 03:10:58.731990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Creating instance of the class
    class_instance = ActionModule()

    # Getting the reference of the instance variables
    class_instance_variable = class_instance.run()

    # Checking if the type of the class instance is ActionModule
    assert isinstance(class_instance, ActionModule)


# Generated at 2022-06-21 03:11:05.929624
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Unit test for method get_args_from_task_vars of class ActionModule '''
    action_module = ActionModule()

    args_from_vars = action_module.get_args_from_task_vars({'templated_arg': {'type': 'str'}}, {'templated_arg': '{{ templated_value }}'})
    assert args_from_vars == {'templated_arg': ''}

# Generated at 2022-06-21 03:11:07.267596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 03:11:18.111882
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Unit tests for get_args_from_task_vars() in class ActionModule '''

    from ansible.plugins.action import ActionModule

    # Case1:
    argument_spec = {
        'arg1': {'required': True, 'type': 'str'},
        'arg2': {'required': False, 'type': 'str'}
    }

    task_vars = {'arg1': 'test'}
    action_module = ActionModule(None, None)
    args_test = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert 'arg1' in args_test
    assert 'arg2' not in args_test

    # Case2:

# Generated at 2022-06-21 03:11:25.361153
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    task_vars = {
        'fakeparam': '{{ fakeresult }}'
    }

    class FakeTemplar(object):
        def template(self, data):
            return {'fakeparam': 'fakeresult'}

    action_module = ActionModule()
    action_module._templar = FakeTemplar()
    argument_spec = dict(fakeparam=dict(type='str'))
    result = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert result == {'fakeparam': 'fakeresult'}



# Generated at 2022-06-21 03:11:32.286269
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for error_trace in validation_result.error_messages:
        error_items = error_trace.split('\n')
        # Since this is a string and we can't directly assert on it
        # Instead write an assertion on the elements of the string
        assert isinstance(error_items, list) and len(error_items) == 3
        for error_item in error_items:
            assert isinstance(error_item, string_types)


# Generated at 2022-06-21 03:11:32.912094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:11:39.743584
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Args
    argument_spec = {
        "valid_arg": {"default": "bar", "type": "str"}
    }


# Generated at 2022-06-21 03:11:40.594988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()


# Generated at 2022-06-21 03:11:48.593904
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Unit test for method get_args_from_task_vars of class ActionModule '''
    argument_spec = dict(arg1=dict(type='str', required=True), arg2=dict(type='bool'))

    action = ActionModule()

    # Test that arg1 and arg2 come from task_vars
    task_vars = dict(arg1='VAL', arg2=True)
    args = action.get_args_from_task_vars(argument_spec, task_vars)
    assert args['arg1'] == 'VAL'
    assert args['arg2'] is True

    # Test that arg1 comes from task_vars and arg2 comes from default
    task_vars = dict(arg1='VAL')

# Generated at 2022-06-21 03:12:00.402738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('host', 'user',
                                 password='pass', port='port', private_key_file='abc',
                                 become_method='become_method', become_user='become_user',
                                 become_pass='become_pass', become_exe='become_exe',
                                 become='become', connection='connection', vars='vars',
                                 module_path='module_path', forks='1', remote_tmp='remote_tmp',
                                 check='check', diff='diff')
    assert action_module is not None


# Generated at 2022-06-21 03:12:03.877567
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert mod.TRANSFERS_FILES is False

# Generated at 2022-06-21 03:12:08.562479
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    action_module = ActionModule(
        task=AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=Templar(loader=None),
        shared_loader_obj=None
    )

# Generated at 2022-06-21 03:12:15.273736
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    task_vars = {'key1': 'value1'}
    argument_spec = {'key1': {}}

    # Create object ActionModule
    action_module = ActionModule()

    # Create expected result
    result = {'key1': 'value1'}

    # Run unit test
    assert action_module.get_args_from_task_vars(argument_spec, task_vars) == result

# Generated at 2022-06-21 03:12:23.583156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import unittest
    import sys

    class MyTest(unittest.TestCase):
        '''Class for Unit testing in python'''

        def testmodel1(self):
            '''Unit test 1'''

            my_test = ActionModule()
            my_file = open("delete.txt", "w")
            my_file.close()
            if os.path.isfile("delete.txt"):
                os.remove("delete.txt")
            assert not os.path.isfile("delete.txt")

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-21 03:12:30.729188
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    args = {'foo': {'type': 'str', 'required': True}}
    task_vars = {'foo': 'bar', 'baz': 'qux'}
    args_from_vars = module.get_args_from_task_vars(args, task_vars)
    assert args_from_vars == {'foo': 'bar'}, 'incorrect dict was returned from get_args_from_task_vars'

# Generated at 2022-06-21 03:12:43.080174
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    class DummyTempVar(object):
        def template(self, data):
            for argument_name, argument_attrs in iteritems(data):
                if isinstance(argument_attrs, string_types):
                    data[argument_name] = '%s_template' % argument_attrs
            return data

    class DummyClass(object):
        def __init__(self):
            self._task = DummyTask()

    class DummyTask(object):
        def __init__(self):
            self.args = {
                'validate_args_context': {}
            }

    task_vars = {'var_a': 'value_a', 'var_b': 'value_b'}

    act = ActionModule()
    act._templar = DummyTempVar()
    act._task = DummyTask

# Generated at 2022-06-21 03:12:53.898457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

# Generated at 2022-06-21 03:12:59.888397
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Test for method  get_args_from_task_vars of class ActionModule
    '''
    action_module = ActionModule()
    assert action_module
    argument_spec = dict()
    task_vars = dict()
    result = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert result is None

# Generated at 2022-06-21 03:13:07.900532
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    task_vars = dict(a=1, b=2, c=3)
    mock_self = MockSelf(task_vars)
    argument_spec = dict(a=dict(), b=dict(), d=dict())
    actual = ActionModule.get_args_from_task_vars(mock_self, argument_spec, task_vars)
    expected = dict(a=1, b=2)
    assert actual == expected
    mock_self.templar.template.assert_called_with(expected)



# Generated at 2022-06-21 03:13:25.183324
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Unit test for constructor of class ActionModule
    from ansible.utils.display import Display
    from ansible.plugins.loader import action_loader

    display = Display()
    action_loader._add_directory('./lib/ansible/plugins/action')
    action = action_loader.get('validate_argument_spec', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # first we test the class with actually passing the values
    a = action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:13:32.263243
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    """
    Unit test for method get_args_from_task_vars of class ActionModule
    """
    am = ActionModule(None, None, None, None)
    argument_spec = {"arg1":"attrs1", "arg2":"attrs2"}
    task_vars = {"arg1": "val1", "arg2": "val2"}
    actual = am.get_args_from_task_vars(argument_spec, task_vars)
    expected = {"arg1": "val1", "arg2": "val2"}
    assert actual == expected

# Generated at 2022-06-21 03:13:43.637143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.expect import RoleExpectation
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    import io
    import sys
    import ansible.constants as C
    import ansible.utils.display as display

    display.verbosity = 4
    loader = C.DEFAULT_LOADER


# Generated at 2022-06-21 03:13:51.184443
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    verify_args_from_task_vars(
        argument_spec={},
        task_vars={},
        expected={},
        expected_err_msg=None
    )

    verify_args_from_task_vars(
        argument_spec={
            'arg1': {'type': 'str'},
            'arg2': {'type': 'str'}
        },
        task_vars={},
        expected={},
        expected_err_msg=None
    )


# Generated at 2022-06-21 03:14:02.112509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    action = ActionModule(ImmutableDict(connection=None,
                                        become=None,
                                        become_user=None,
                                        check_mode=False,
                                        diff=None,
                                        play_context=None,
                                        loader=None,
                                        templar=None,
                                        shared_loader_obj=None,
                                        remote_user=None))


# Generated at 2022-06-21 03:14:14.572635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake action module with fake information
    class Fake_ActionModule():
        def __init__(self):
            self._task = Fake_ActionModule_task
            self._templar = Fake_ActionModule_templar
            class Fake_ActionBase():
                def __init__(self):
                    self.result = Fake_ActionBase_result
            class Fake_ActionBase_result():
                def __init__(self):
                    self.update = Fake_ActionBase_result_update
            class Fake_ActionModule_task():
                def __init__(self):
                    self.args = Fake_ActionModule_task_args
                    self.action = 'validate_argument_spec'
                    self.name = 'Validate Arg Spec'

# Generated at 2022-06-21 03:14:23.523816
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.plugins.action.validate_argument_spec import ActionModule
    # action module initialization
    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    # argument_spec
    argument_spec = {
        "interface": {"required": True, "type": "str"},
        "address": {"required": True, "type": "str"}
    }
    # task_vars
    task_vars = {
        "interface": "{{ ansible_bond0.interface }}"
    }
    # action_module.get_args_from_task_vars(argument_spec, task_vars)
    result = action_module.get_args_

# Generated at 2022-06-21 03:14:33.845938
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' define test params '''
    argument_spec = {
        'arg1': {'required': False},
        'arg2': {'required': False, 'type': 'list'},
        'arg3': {'required': False},
        'arg4': {'required': False, 'type': 'dict'},
        'arg5': {'required': False},
        'arg6': {'required': False, 'type': 'list'},
        'arg7': {'required': False},
        'arg8': {'required': False, 'type': 'dict'},
    }
    ansible_module_args = {}


# Generated at 2022-06-21 03:14:35.606136
# Unit test for constructor of class ActionModule
def test_ActionModule():
   # Assert that the class has been created with the correct arguments
   assert ActionModule.__init__(ActionModule, "test_module_name")

# Generated at 2022-06-21 03:14:36.903007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule


# Generated at 2022-06-21 03:15:04.009737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.arg_spec import argument_spec_validator_type

    action = ActionModule(dict(validate_args_context=dict(module='test')))

    # Create a dict of the argument spec data.

# Generated at 2022-06-21 03:15:15.370596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.validation import ErrorMessage
    task_vars = dict()
    task_args = dict(
        argument_spec=dict(
            foo=dict(type='int', default=10, alias=['bar']),
            baz=dict(type='str', default='10', choices=['10', '20']),
            bang=dict(type='str', required=True),
        ),
        validate_args_context='MyArgSpec',
        provided_arguments=dict(
            foo='some_string',
        )
    )

    action_module = ActionModule(None, task_vars)
    result = action_module.run(None, task_vars=task_vars, **task_args)

    assert len(result['argument_errors']) == 2
    assert isinstance

# Generated at 2022-06-21 03:15:25.805155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    import os

    path = os.getcwd()
    os.chdir("test/unit/plugins/modules/ansible-test/ansible_test/modules/")
    print(path)
    loader = DataLoader()

    context = PlayContext()

    # Using more than 'module_name' arg raises an AnsibleError
    with pytest.raises(AnsibleError) as exc:
        ActionModule(dict(module_name="test_module", module_args=dict()), loader=loader, play_context=context)
    assert 'the following arguments are required' in str(exc.value)

    # Using 'module_name

# Generated at 2022-06-21 03:15:35.992668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    validate_spec = {
        'foo': {},
        'bar': {},
        'baz': {'type': 'path'},
        'spam': {'type': 'str'},
        'eggs': {'type': 'str', 'choices': ['yes', 'no']}
    }

    validate_args = {
        'foo': {'foo': 'foo'},
        'bar': dict(),
        'baz': dict(),
        'spam': {'spam': 'spam_value'},
        'eggs': {'eggs': 'bad_egg'}
    }

    # Test with a missing argument spec
    act = ActionModule(dict(task=dict(args=dict()), connection=dict(), play_context=dict()), dict())

# Generated at 2022-06-21 03:15:37.292329
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

# Generated at 2022-06-21 03:15:44.622957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # run_command needs to be stubbed
    def run_command(cmd, tmp_path, sudo_user, become_method=None, verbosity=None, check_rc=False, executable=None, data=None):
        return {'failed': False, 'changed': False, 'rc': 0, 'cmd': cmd}
    # mock_import
    def mock_import(module):
        return None
    # mock_get_module_path
    def mock_get_module_path(module):
        return None
    # mock_action_base
    class mock_action_base(object):
        module = None
        def __init__(self):
            self.transfers = []
            self.noop_on_check_mode = False
            self.become = False
            self.no_log = []

# Generated at 2022-06-21 03:15:55.421416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_text

    from ansible.module_utils.ansible_release import __version__ as ansible_version
    if not PY2 and not ansible_version.startswith('2.10.'):
        # Unittest for ansible==2.10.x
        raise AssertionError('Only supported in Ansible 2.10.9 -> 2.10.13')

    from ansible.plugins.action import ActionModule


# Generated at 2022-06-21 03:16:04.116595
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for get_args_from_task_vars method of class ActionModule
    '''

    # Define task_vars
    task_vars = {
        "argument_spec": {
            "__ansible_validate_options_ip": {
                "default": None,
                "choices": [],
                "aliases": []
            },
            "__ansible_validate_options_netmask": {
                "default": None,
                "choices": [],
                "aliases": []
            }
        },
        "__ansible_validate_options_ip": "1.1.1.1",
        "__ansible_validate_options_netmask": "255.255.255.0"
    }

# Generated at 2022-06-21 03:16:14.092389
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:16:23.465721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    make sure that incorrect args are handled correctly
    '''

    module_args = {
        'validate_args_context': 'test context',
        'argument_spec': dict(valid_arg=dict(type='str')),
        'provided_arguments': dict(valid_arg='foo')
    }

    # Create an instance of this module, then pass in the prepared arguments
    action_plugin = ActionModule(None, None)
    action_plugin.set_task(dict(args=module_args))
    result = action_plugin.run(None, None)

    assert result['changed'] is False
    assert result['msg'] == 'The arg spec validation passed'
    assert 'validate_args_context' in result
    assert result['validate_args_context'] == 'test context'

    # Run the same test

# Generated at 2022-06-21 03:17:04.390548
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-21 03:17:12.055877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_napalm_utils.validate_argument_spec import ArgumentSpecValidator

    arg_spec = {
        'valid_option1': {'type': 'str'},
        'valid_option2': {'type': 'bool'},
        'valid_option3': {'type': 'int'},
        'valid_option4': {'type': 'dict'},
        'valid_option5': {'type': 'list'},
        'valid_option6': {'type': 'bool', 'default': True},
        'valid_option7': {'type': 'dict'},
        'valid_option8': {'type': 'bool', 'choices': [True, False]},
    }


# Generated at 2022-06-21 03:17:14.882720
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:17:25.200511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    from ansible.module_utils.common.arg_spec import ArgumentSpec

    argspec_data = {
        'interface': ArgumentSpec(dict(required=True, type='str')),
        'debug': ArgumentSpec(dict(required=False, type='bool', default=False)),
        'state': ArgumentSpec(dict(required=False, type='str', default='present', choices=['present', 'absent']))
    }

    module_args = {
        'argument_spec': argspec_data,
        'validate_args_context': 'role abc module xyz',
        'provided_arguments': {'interface': 'GigabitEthernet1',
                               'state': 'present'}
    }
    action_module = ActionModule()

# Generated at 2022-06-21 03:17:36.769648
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''Unit test for method get_args_from_task_vars of class ActionModule'''

    # Mock the imports for the module we use in get_args_from_task_vars
    from ansible_collections.ansible.community.plugins.module_utils.six import iteritems, string_types
    from ansible_collections.ansible.community.plugins.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible_collections.ansible.community.plugins.module_utils.errors import AnsibleValidationErrorMultiple
    from ansible_collections.ansible.community.plugins.module_utils.vars import combine_vars

    # Create a mock instance of ActionBase. This is just a test double we can use
    # to call the function we want to test.

# Generated at 2022-06-21 03:17:45.537696
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModule, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect

            # This action can be called from anywhere, so pass in some info about what it is
            # validating args for so the error results make some sense
            result['validate_args_context'] = self._task.args.get('validate_args_context', {})

            if 'argument_spec' not in self._task.args:
                raise AnsibleError('"argument_spec" arg is required in args: %s' % self._task.args)

            # Get the task var called argument_spec. This will

# Generated at 2022-06-21 03:17:55.658362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import unittest.mock

    with unittest.mock.patch.object(ActionModule, 'run') as mock_validate_args:
        mock_validate_args.return_value = {'changed': False,
                                           'failed': False,
                                           'validate_args_context': {},
                                           'msg': 'argument_spec validation passed'}
        action_module = ActionModule(unittest.mock.MagicMock())
        action_module.run()
        mock_validate_args.assert_called_once()

        # Check that the function was called with the correct arguments
        assert mock_validate_args.call_args[1]['task_vars'] == {}
        assert mock_validate_args.call_args[1]['tmp'] is None

# Generated at 2022-06-21 03:18:06.756333
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.module_utils.six import PY2

    # Change dict in python2 to sort dict for more stable output
    if PY2:
        import collections
        def ordered(obj):
            if isinstance(obj, dict):
                return collections.OrderedDict(sorted(obj.items()))
            if isinstance(obj, list):
                return sorted(obj)
            return obj
    else:
        def ordered(obj):
            return obj


# Generated at 2022-06-21 03:18:16.223196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a class for the module
    class Runner(object):
        def __init__(self, source_data):
            self.source_data = source_data
            self.action_results = None

        def run(self, module_args, task_vars=None):
            module_args.update(self.source_data)
            action = ActionModule(self._play_context, module_args, task_vars=task_vars)
            action_results = action.run()

            # Set the result
            self.action_results = action_results

        def get_action_results(self):
            return self.action_results


    # Create an instance of the ActionModule for testing
    # Have arguments that would make the task fail

# Generated at 2022-06-21 03:18:20.355733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.template import Templar
    from ansible.module_utils import basic

    try:
        assert ActionModule(dict(), basic.AnsibleModule, Templar())
    except Exception as err:
        raise Exception(err)
    else:
        print("Unit test for ActionModule constructor: PASS")


# Generated at 2022-06-21 03:20:18.574984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    module_args = dict(
        argument_spec=dict(
            command=dict(required=False, type='str'),
            something=dict(required=False, type='bool'),
            interfaces=dict(required=True, type='list', elements='str')
        ),
        provided_arguments=dict(
            command="show version"
        ),
        validate_args_context=dict(entry_point='task_module', task_name='task 1'),
    )

    module_return_value = action_module.run(task_vars=dict(), **module_args)

    assert module_return_value.get('failed') == True
    assert module_return_value.get('changed') == False

# Generated at 2022-06-21 03:20:28.505833
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_mod = ActionModule(loader=None, task=None, connection=None, play_context=None,
                              loader_cache=None, shared_loader_obj=None, templar=None)
    arg_spec = {
        'arg_one': {'type': 'bool'},
        'arg_two': {'type': str},
        'arg_three': {'type': int},
        'arg_four': {'type': 'list', 'elements': 'str'},
        'arg_five': {'type': 'dict', 'keys': 'str', 'values': str},
    }

# Generated at 2022-06-21 03:20:38.470486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    from ansible.executor.task_result import TaskResult
    from ansible.utils.sentinel import Sentinel
    import pytest
    from ansible.errors import AnsibleActionFail

    task_result = TaskResult(host=Sentinel(), task=Sentinel())
    task_result._result['_ansible_no_log'] = False
    task_result._host = Sentinel()
    task_result._task = {'name' : 'test'}
    task_result._task_fields = {'name' : 'test'}
    task_result._task_action = 'test'
    task_result._task_args = {'validate_args_context' : {'attribute_name' : 'name'}}

# Generated at 2022-06-21 03:20:41.978721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'validate_argument_spec'
    loader = ModuleLoader()
    mod = loader.get(module_name)
    assert mod is not None
    action = mod.action_class()
    assert action.run is not None
