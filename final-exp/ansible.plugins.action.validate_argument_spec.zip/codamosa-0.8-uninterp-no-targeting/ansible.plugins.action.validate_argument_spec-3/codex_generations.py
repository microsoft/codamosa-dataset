

# Generated at 2022-06-21 03:10:57.311565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.collections import ImmutableDict
    class mock_self(object):
        module_args = {'argument_spec': {'foo': {'type': 'str'}, 'bar': {'type': 'int'}},
                       'provided_arguments': {'foo': 'asdf', 'bar': 5}}
        _task = ImmutableDict(args=module_args)
        _shared_loader_obj = None
        _templar = None
        def run(self, tmp=None, task_vars=None):
            return super(mock_self, self).run(tmp, task_vars)

    def mock_super_run(tmp=None, task_vars=None):
        return dict(changed=False, msg="The arg spec validation passed")

    mock_action

# Generated at 2022-06-21 03:11:09.574716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.connection import Connection

    class MockedModule(object):
        def __init__(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            self.task_vars = task_vars
            if tmp is None:
                tmp = dict()
            self.tmp = tmp

    class MockedConnection(object):
        def __init__(self, tmp=None, task_vars=None):
            if tmp is None:
                tmp = dict()
            self.tmp = tmp
            if task_vars is None:
                task_vars = dict()
            self.task_vars = task_vars


# Generated at 2022-06-21 03:11:20.173059
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    This function tests the get_args_from_task_vars method of the class ActionModule.

    :returns: Nothing
    '''

    task_vars = {
        'test': '{{test2}}',
        'test2': '{{test3}}',
        'test3': '3'
    }

    argument_spec = {
        'test': {
            'type': 'str',
            'default': '1'
        }
    }

    action_module = ActionModule()
    action_module._templar = FakeTemplar()
    result = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert result == {'test': '3'}



# Generated at 2022-06-21 03:11:27.761205
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''Unit test for method get_args_from_task_vars of class ActionModule'''
    action_module_obj = ActionModule()

    # Test Arg spec being a dict
    args_from_vars = action_module_obj.get_args_from_task_vars({'state': {'type': 'str'}}, {'state': 'present'})
    assert args_from_vars == {'state': 'present'}

    # Test Arg spec being a list
    args_from_vars = action_module_obj.get_args_from_task_vars({'state': {'type': 'list'}}, {'state': ['present', 'absent']})
    assert args_from_vars == {'state': ['present', 'absent']}

    # Test Arg spec being a boolean
   

# Generated at 2022-06-21 03:11:28.371837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:11:29.810711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionModule)

# Generated at 2022-06-21 03:11:39.894059
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    module = ActionModule()

    # Test invalid argument_spec value
    try:
        module.get_args_from_task_vars(False, {})
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert "Invalid type for argument argument_spec" in str(e)

    # Test invalid task_vars value
    try:
        module.get_args_from_task_vars({}, 'invalid_value')
    except Exception as e:
        assert isinstance(e, AnsibleError)
        assert "Invalid type for argument task_vars" in str(e)

    # Test invalid task_vars value
    try:
        module.get_args_from_task_vars({}, None)
    except Exception as e:
        assert isinstance(e, AnsibleError)


# Generated at 2022-06-21 03:11:40.308918
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:11:46.637923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data1 = {"argument_spec":
        {"arg1": {"type": "bool"}, "arg2": {"type": "int"}, "arg3": {"type": "str"}},
        "provided_arguments": {"arg1": "true", "arg2": 1}}

    data2 = {"argument_spec":
        {"arg1": {"type": "bool"}, "arg2": {"type": "int"}, "arg3": {"type": "str"}},
        "provided_arguments": {"arg1": "true", "arg2": "abc"}}

    task = {"data": data1, "action": "validate_argument_spec"}
    task_manager = ActionModule(task, {})
    task_manager.run(task_vars={"arg2": "abc"})

# Generated at 2022-06-21 03:11:57.725260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' unit test for ansible.plugins.action.validate_argument_spec.ActionModule.run '''

    mock_self = MagicMock()
    mock_self._task = MagicMock()

# Generated at 2022-06-21 03:12:11.093641
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Basic test for method get_args_from_task_vars of class ActionModule
    # Setup Mock
    class MockActionBase(object):
        pass
    action_base = MockActionBase()
    ansible_vars = {
        "ansible_distribution": "Fedora",
        "ansible_distribution_version": "28"
    }
    argument_spec_data = {
        "name": {
            "required": True,
            "type": "str"
        },
        "state": {
            "default": "present",
            "choices": [
                "present",
                "absent"
            ],
            "type": "str"
        }
    }
    test_action_module = ActionModule()

# Generated at 2022-06-21 03:12:23.138391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_single_arg = {'arg1': {
        'type': 'bool',
        'default': False,
        'required': True,
        'choices': [True, False]
    }}
    test_multiple_args = {'arg1': {
        'type': 'bool',
        'default': False,
        'required': True,
        'choices': [True, False]
    }, 'arg2': {
        'type': 'bool',
        'default': False,
        'required': True,
        'choices': [True, False]
    }}

# Generated at 2022-06-21 03:12:32.400275
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_run = ActionModule.run

    # Success tests
    validation_result = ArgumentSpecValidator.ValidationResult()
    validation_result.error_messages = []
    # Invalid ArgumentSpecValidator
    class InvalidArgumentSpecValidator(ArgumentSpecValidator):
        def validate(self, params, target=None, ignore_custom=False, ignore_errors=False):
            return validation_result
    with patch.object(ArgumentSpecValidator, "validate", InvalidArgumentSpecValidator.validate):
        assert isinstance(validation_result, ArgumentSpecValidator.ValidationResult)

    # Invalid ArgumentSpecValidator.ValidationResult
    class InvalidValidationResult(ArgumentSpecValidator.ValidationResult):
        def __init__(self):
            self.errors = None
    validation_result = InvalidVal

# Generated at 2022-06-21 03:12:44.340017
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    test_instance = ActionModule()

    # Test with 'type' not in argument_spec data
    test_instance.task_vars = dict(foo='bar')
    argument_spec = dict(bar='foobar')
    result = test_instance.get_args_from_task_vars(argument_spec=argument_spec, task_vars=test_instance.task_vars)
    expected_result = dict()
    assert result == expected_result

    # Test with 'type' in argument_spec_data
    test_instance.task_vars = dict(foo='bar')
    argument_spec = dict(foo=dict(type=string_types))
    result = test_instance.get_args_from_task_vars(argument_spec=argument_spec, task_vars=test_instance.task_vars)

# Generated at 2022-06-21 03:12:54.625701
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Tests the get_args_from_task_vars method of ActionModule class.
    :return: None
    '''

# Generated at 2022-06-21 03:13:06.370869
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    argument_spec = {
        'arg1': {
            'type': 'str',
            'required': True,
            'default': 'nope'
        },
        'arg2': {
            'type': 'list',
            'required': False,
            'default': 'nope'
        }
    }
    task_vars = {
        'arg1': 'this',
        'arg2': 'that'
    }

    expected_args = {
        'arg1': 'this',
        'arg2': 'that'
    }

    action_module = ActionModule()
    result = action_module.get_args_from_task_vars(argument_spec, task_vars)

    assert result == expected_args


# Generated at 2022-06-21 03:13:08.681234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        am = ActionModule()
    except Exception as e:
        assert(False)

# Test passing in an argument specification that is not a dict

# Generated at 2022-06-21 03:13:10.208473
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    pass

# Generated at 2022-06-21 03:13:20.547616
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    argument_spec_validate_args_context = {
        'operation_type': 'supplychain',
        'operation_name': 'supplychain_info',
        'action_type': 'validate_args',
        'context_info': {
            'file_path': 'tests/unit/plugins/actions/fixtures/test_validate_args/library/supplychain_info',
            'module_path': 'tests/unit/plugins/actions/fixtures/test_validate_args/library/supplychain_info.py'
        }
    }

# Generated at 2022-06-21 03:13:27.694490
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Create mock_task
    mock_task = type('', (), {})()
    mock_task.args = {}

    # Create mock_loader
    mock_loader = type('', (), {})()

    # Create mock_templar
    mock_templar = type('', (), {})()
    mock_templar.template = lambda x: x

    # Create mock_play_context
    mock_play_context = type('', (), {})()
    mock_play_context.connection = 'local'
    mock_play_context.remote_addr = None
    mock_play_context.network_os = None
    mock_play_context.remote_user = None
    mock_play_context.port = None
    mock_play_context.remote_pass = None

    # Create instance of ActionModule
    am = Action

# Generated at 2022-06-21 03:13:47.405018
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for the method ActionModule._get_args_from_task_vars()
    '''

    template_variables = {
        "var_to_be_used_as_a_value": "test_value",
        "var_to_be_used_as_a_list": "test_value",
        "var_to_be_used_as_a_dict": "test_value",
    }

    argument_spec = {
        "var_to_be_used_as_a_value": {"type": 'str'},
        "var_to_be_used_as_a_list": {"type": 'list'},
        "var_to_be_used_as_a_dict": {"type": 'dict'},
    }


# Generated at 2022-06-21 03:13:59.425450
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dict_transformations import _to_lines
    from ansible.module_utils.common.validation import check_type_dict, check_type_bool
    from ansible.module_utils.six import string_types

    # ArgumentSpecValidator class is used in this method
    class ArgumentSpecValidator(object):
        """
        A class which takes a dict as an argument spec and validates
        a provided argument spec against it using the validator function
        """

        def __init__(self, argument_spec):
            self._argument_spec = argument_spec


# Generated at 2022-06-21 03:14:11.681574
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Hide return value of assertEqual
    # pylint: disable=unidiomatic-typecheck
    import ansible.plugins.action as action
    import ansible.module_utils.six as six
    action_module = action.ActionModule(None, dict(), load_fragment_filename=None)
    action_module._templar = six.Moves.mock.MagicMock()
    # pylint: enable=unidiomatic-typecheck


# Generated at 2022-06-21 03:14:13.611746
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-21 03:14:22.762737
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    instance = ActionModule()

    # Test case 1
    argument_spec = {
        'some_arg': {'type': 'str', 'default': 'default value'},
    }
    task_vars = {
        'some_arg': 'task vars value',
    }
    assert 'task vars value' == instance.get_args_from_task_vars(argument_spec, task_vars)['some_arg']

    # Test case 2
    argument_spec = {
        'some_arg': {'type': 'str', 'default': 'default value'},
    }
    task_vars = {
    }
    assert 'default value' == instance.get_args_from_task_vars(argument_spec, task_vars)['some_arg']

    # Test case 3
    argument_

# Generated at 2022-06-21 03:14:32.804658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    real_templar_config = ActionModule._templar._config

    test_action_module = ActionModule(dict())
    test_action_module._templar._config = dict()

    # Test with no argument_spec arg
    try:
        test_task_dict = {'args': {}}
        test_action_module.run(task_vars=test_task_dict)
        assert False, 'Should have raised AnsibleError with no "argument_spec" arg'
    except AnsibleError:
        assert True

    # Test with invalid argument_spec type

# Generated at 2022-06-21 03:14:42.325863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    current_action_name = 'validate_args'
    current_action_path = '{0}/{1}/action_plugins/{2}.py'.format(os.path.dirname(__file__), '..', current_action_name)
    current_action_obj = action_loader.get(current_action_name, current_action_path)
    templar = Templar(loader=None, variables=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:14:51.082549
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    class MyActionModule(ActionModule):
        def __init__(self):
            ActionModule.__init__(self)

        def _templar_template(self, args):
            return args

    # Test when task vars is passed in as None
    my_action_module = MyActionModule()

    try:
        my_action_module.get_args_from_task_vars({}, None)

    except AnsibleError as e:
        assert 'task_vars is None' in e.message

    # Test when argument_spec is an empty dict
    my_action_module = MyActionModule()

    result = my_action_module.get_args_from_task_vars({}, {})

    assert isinstance(result, dict)
    assert len(result) == 0

    # Test with one arg named arg1

# Generated at 2022-06-21 03:14:55.967955
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # arrange
    task_vars = dict()
    action_module_obj = ActionModule(load_libs=False)

    # act
    result = action_module_obj.get_args_from_task_vars({}, task_vars)

    # assert
    assert isinstance(result, dict) is True


# Generated at 2022-06-21 03:15:03.363025
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.plugins.action import ActionBase

    argument_spec = {'test_var': {'type': 'bool'}}
    args = {}
    task_vars = {'test_var': True}

    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    args_from_task_vars = action.get_args_from_task_vars(argument_spec, task_vars)

    assert args_from_task_vars == {'test_var': True}



# Generated at 2022-06-21 03:15:20.848905
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule.ActionModule()
    assert test_object


# Generated at 2022-06-21 03:15:26.629284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule '''

    from ansible.module_utils.common.arg_spec import valid_attrs
    from ansible.module_utils.common.arg_spec import valid_types

    class MockActionModule(ActionModule):
        ''' Mock class for ActionModule '''
        def __init__(self, *args, **kwargs):
            self._task = kwargs.get('task')
            self._connection = kwargs.get('connection')
            self._play_context = kwargs.get('play_context')
            self._loader = kwargs.get('loader')
            self._templar = kwargs.get('templar')
            self._shared_loader_obj = kwargs.get('shared_loader_obj')


# Generated at 2022-06-21 03:15:33.364667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.test.test_validate_argument_spec import ActionModule
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.playbook.play_context import PlayContext

    argument_spec = dict(role=dict(required=True, type="str"),
                         fqdn=dict(required=True, type="str"),
                         ip=dict(required=False, type="str"),
                         port=dict(required=False, type="int", default=8081))

    provided_arguments = dict(role="hadoop",
                              fqdn="test.test.test",
                              ip="1.1.1.1",
                              port=1234)

    task_vars = dict(ip="1.1.1.1", port=1234)

   

# Generated at 2022-06-21 03:15:34.724110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None


# Generated at 2022-06-21 03:15:39.401212
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.plugins.action.validate_arg_spec import ActionModule
    _instance = ActionModule()
    _instance._templar = AnsibleMock()
    _instance._templar.template = lambda x: x

    # 'given_task_vars' is a dict of the form
    # {'arg_name': 'arg_value'[, 'arg_name': 'arg_value', ...]}
    # The argument spec that is checked against is of the form
    # {'arg_name': {'type': 'str', 'required': True, 'default': 'the_default'}}
    # It is expected that the argument spec will have a type field, so that
    # the arg is determined to be from `task_vars`

    # Given a task vars dict with a single arg that matches the argument spec
    #

# Generated at 2022-06-21 03:15:45.784912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule

    '''
    import mock
    import json
    from datetime import datetime

    from copy import deepcopy

    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.validate_arg_spec import ActionModule
    from ansible.plugins.action.validate_arg_spec import test_ActionModule_run as test_ActionModule_vars


# Generated at 2022-06-21 03:15:51.974173
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    file = {
        'path': '/path/to/the/file',
        'state': '{{ state }}'
    }
    task_vars = {
        'state': 'present'
    }
    action = ActionModule()
    assert action.get_args_from_task_vars(file, task_vars) == {'path': '/path/to/the/file', 'state': 'present'}


# Generated at 2022-06-21 03:16:01.451295
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Setup test data
    argument_spec = { 'arg1': {} }
    task_vars = { 'arg1': 10 }

    # Setup mock objects
    mock_task = type('task', (object,), {})()
    mock_task.args = {'arg1': 20}
    mock_templar = type('templar', (object,), {})()
    mock_templar.template = lambda x: x

    # Exercise code
    action_module = ActionModule(task=mock_task, templar=mock_templar)
    args = action_module.get_args_from_task_vars(argument_spec, task_vars)

    # Verify results
    assert args == {'arg1': 20}


# Generated at 2022-06-21 03:16:10.681209
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Test if method `geet_args_from_task_vars` returns the vars of a dict with
    variables expanded.
    '''
    import sys
    import uuid
    # sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../lib/ansible/module_utils'))

    from ansible.errors import AnsibleError
    from ansible.template import Templar
    from ansible.template.safe_eval import safe_eval
    from ansible.utils.vars import combine_vars

    from units.modules.utils import set_module_args


# Generated at 2022-06-21 03:16:11.503667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action.run()

# Generated at 2022-06-21 03:17:01.347307
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Ensures the get_args_from_task_vars method of ActionModule returns expected
        results.
    '''
    from ansible.playbook.task import Task

    from ansible.plugins.loader import action_loader

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager

    action_module = action_loader.get('arg_validator',
                                      task=Task(),
                                      connection=None,
                                      play_context=None,
                                      loader=None,
                                      templar=None,
                                      shared_loader_obj=None)

    action_module._templar.template_data = {}  # pylint: disable=W0212
    task_vars = {'test': 1}

# Generated at 2022-06-21 03:17:10.354389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_spec = dict(argument_spec=dict(
        validate_args_context=dict(),
        required_one_of=dict(type='list', elements='dict', required=True),
        required_together=dict(type='list'),
        mutually_exclusive=dict(type='list'),
        required_by=dict(type='dict'),
        one_of_suboptions=dict(type='dict', elements='dict', required=True)
    ),
                       supports_check_mode=True)

    validator_module_spec = dict(argument_spec=dict(
        argument_spec=dict(type='dict', required=True),
        provided_arguments=dict(type='dict', required=True),
    ),
                                 supports_check_mode=True)

    validator_module = ActionModule()
    validator_module.module

# Generated at 2022-06-21 03:17:16.154627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule should initialize instance of
    ActionModule, with valid ActionBase attributes

    :return: None
    """

    action = ActionModule()
    assert isinstance(action, ActionModule)
    assert isinstance(action, ActionBase)



# Generated at 2022-06-21 03:17:26.251381
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.modules.network.nxos.validate_argument_spec import ActionModule

    from ansible_collections.vyos.vyos.tests.unit.compat import unittest
    from ansible_collections.vyos.vyos.tests.unit.compat.mock import patch

    mock_self = unittest.mock.create_autospec(ActionModule)


# Generated at 2022-06-21 03:17:37.461474
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.six import iteritems

    from ansible.plugins.action.validate_arg_spec import ActionModule

    args = ActionModule(None, None).get_args_from_task_vars({'arg1': {'type': 'str'}}, {'arg1': 'test{{test1}}', 'test1': 'yo'})
    assert(args.get('arg1') == 'testyo')

    args = ActionModule(None, None).get_args_from_task_vars({'arg1': {'type': 'list'}}, {'arg1': 'test{{test1}}', 'test1': ['1', '2', '3']})
    assert(args.get('arg1') == ['1', '2', '3'])

    args = ActionModule(None, None).get_

# Generated at 2022-06-21 03:17:45.931177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeActionModule(ActionModule):
        def __init__(self):
            self._task = FakeActionModule._task
            self._play_context = FakeActionModule._play_context
            self._loader = FakeActionModule._loader
            self._templar = FakeActionModule._templar
            self._shared_loader_obj = FakeActionModule._shared_loader_obj

    # Fake the task attributes
    FakeActionModule._task = {'args': {
        'argument_spec':
            '''
            module_spec:
              description: description1
              required: false
              type: dict
            '''
        }
    }

    FakeActionModule._play_context = {
        'verbosity': 2
    }

    FakeActionModule._loader = None
    FakeActionModule._templar = None
    FakeActionModule._

# Generated at 2022-06-21 03:17:55.174533
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule()
    argument_spec = {
        'arg2': {'type': 'str'},
        'arg1': {'type': 'str'}
    }
    task_vars = {
        'dummy_var': 'dummy',
        'arg1': '{{ lookup("env", "ANSIBLE_NET_SSH_PASS") }}',
        'arg_not_in_arg_spec': 'foo'
    }
    expected_args = {'arg1': 'ansible', 'arg2': ''}
    args = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert args == expected_args


# Generated at 2022-06-21 03:18:03.214920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This is the demo data that will be used to mock the inputs of the method.
    tmp = None
    task_vars = dict()

    # Now create the actual instance of the class with the demo data.
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Populate the instance variables with the demo data.
    action_module._task.args = {}

    # Now we can run the method under test.
    action_module.run(tmp, task_vars)


# Generated at 2022-06-21 03:18:08.388114
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    module = ActionModule(None, None)
    argument_spec = {'arg': {'type': 'str'}}
    task_vars = {'arg': '{{foo}}'}
    result = module.get_args_from_task_vars(argument_spec, task_vars)
    assert result == {'arg': '{{foo}}'}

# Generated at 2022-06-21 03:18:17.803281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the AnsibleModule to be able to call it.
    module = AnsibleModule(argument_spec = {
        'argument_spec': {'required': True, 'type': 'dict'},
        'provided_arguments': {'required': True, 'type': 'dict'}},
        check_invalid_arguments=False)
    action_module = ActionModule(module, 'testhost', {})

    # simulate calling action plugin via ad-hoc

# Generated at 2022-06-21 03:20:08.314696
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test: ActionModule.run()
    # No type specified in argument_spec, so expect one error message
    action = ActionModule(load_fixture_to_task_args('''
        - hosts: localhost
          gather_facts: false

          vars:
            test_args:
              hello: world
          tasks:
            - name: "Validate argument spec"
              debug:
                msg: "validate_argument_spec module should fail"
              validate_argument_spec:
                argument_spec: "{{ test_arg_spec }}"
                provided_arguments: "{{ test_args }}"
                validate_args_context:
                  path: "test/main.yml"
                  entry_point: "test"
          '''))

    result = action.run(task_vars=dict())

# Generated at 2022-06-21 03:20:18.979257
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    task_vars = {
        "person": {
            "name": "Foo",
            "surname": "Bar"
        },
        "my_var": "{{ person.name }}"
    }

    argument_spec = {
        "args_from_vars": {
            "type": 'dict',
            "default": {}
        },
        "provided_arguments": {
            "type": 'dict',
            "default": {}
        }
    }

    action_mod = ActionModule(
        task=None,
        connections=None,
        _play_context=None,
        loader=None,
        templar=Templar(),
        shared_loader_obj=None
    )


# Generated at 2022-06-21 03:20:28.919228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''
    # pylint: disable=protected-access

    # Provide a dict containing the values expected to be instantiated by the __init__
    # method of the class.
    test_args = {}
    test_args['_connection'] = None
    test_args['_play_context'] = None
    test_args['_loader'] = None
    test_args['_templar'] = None
    test_args['_shared_loader_obj'] = None
    test_args['_action'] = None
    test_args['_task'] = None
    test_args['_task_vars'] = None
    test_args['_play'] = None

    # Create an object of class ActionModule
    action_module = ActionModule(**test_args)

# Generated at 2022-06-21 03:20:35.186196
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    import ansible.plugins.action.validate_argument_spec
    # Input args.
    argument_spec = {'arg1': {'type': 'str'}, 'arg2': {'type': 'list'}}
    task_vars = {'arg1': 'val1', 'arg2': ['val2', 'val3']}
    # Create a mock class.
    mock_ActionModuleClass = type('MockActionModuleClass', (object,),
                                  {'_task': type('MockTask', (object,), {'args': {'provided_arguments': {}}})})
    mock_ActionModuleClass._templar = type('MockTemplar', (object,), {'template': lambda self, x: x})
    # Create a mock object.
    mock_ActionModule = mock_ActionModuleClass()


# Generated at 2022-06-21 03:20:38.471284
# Unit test for constructor of class ActionModule
def test_ActionModule():

    actionMod = ActionModule()
    assert type(actionMod) == ActionModule
    assert actionMod._config_spec is None
    assert actionMod.action_loader is not None
    assert actionMod.templar is not None

