

# Generated at 2022-06-21 03:10:59.733416
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''test_ActionModule_get_args_from_task_vars
    '''
    obj = ActionModule('test_task', 'test_play', templar=None)
    argument_spec = {
        'name': {'type': 'str'},
        'age': {'type': 'int'},
        'location': {'type': 'str'}
    }
    task_vars = {'name': 'Fred'}
    actual = obj.get_args_from_task_vars(argument_spec, task_vars)
    assert actual == {'name': 'Fred'}


# Generated at 2022-06-21 03:11:11.177790
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Instantiate class ActionModule
    obj = ActionModule(load_args = dict(task_vars = dict(key1 = 'value1',
        key2 = 'value2',
        key3 = '{{ key1 }}',
        key4 = '{{ key2 }}')))

    # Test method with argument_spec = {'key1':{'required':True, 'type':'str'}, 'key2':{'required':False, 'type':'int'}, 'key3':{'required':False, 'type':'list'}}, task_vars = {'key1': 'value1', 'key2': 'value2', 'key3': '{{ key1 }}', 'key4': '{{ key2 }}'}

# Generated at 2022-06-21 03:11:13.027346
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test the constructor of the class
    result = ActionModule()
    assert result

# Generated at 2022-06-21 03:11:15.895268
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock out the method run of class ActionModule
    module_obj = ActionModule(None, None)
    module_obj.run('test_tmp', 'test_task_vars')



# Generated at 2022-06-21 03:11:25.768368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import copy

    # Mocks
    class MockConnection(object):
        pass

    class MockRunner(object):
        def __init__(self, result=None, task_vars=None):
            self._result = result or dict()
            self.results = []
            self.task_vars = task_vars or dict()

        def get_task_var(self, task_var_name, default=None):
            return self.task_vars.get(task_var_name, default)

        def get_vars(self, play=None, task=None, include_hostvars=False,
                                include_delegate_to=True, default=None):
            if play and task:
                return self.results[task]


# Generated at 2022-06-21 03:11:36.443312
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    task_vars = {'ansible_host': 'test.test.test', 'ansible_username': '{{test_username}}', 'ansible_password': 'test_password', 'ansible_network_os': 'junos'}
    argument_spec = {'ansible_host': {'required': True, 'type': 'str'}, 'ansible_username': {'required': True, 'type': 'str'}, 'ansible_password': {'required': True, 'type': 'str', 'no_log': True}, 'ansible_network_os': {'required': True, 'type': 'str'}}
    action_module = ActionModule()
    args = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert isinstance(args, dict)
    assert args

# Generated at 2022-06-21 03:11:45.361139
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    import unittest
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    del os
    del sys
    import ansible.utils.template as template
    import ansible.utils.vars as vars

    class Templar(template.Templar):
        def __init__(self):
            pass

        def template(self, data, convert_bare=False, preserve_trailing_newlines=True, escape_backslashes=True, fail_on_undefined=True, overrides=None, convert_data=False, disable_lookups=False, escape_errors=False, fail_on_undefined_errors=False, finalize_fail=True):
            return data

# Generated at 2022-06-21 03:11:47.561124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am is not None


# Generated at 2022-06-21 03:11:58.461812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = dict(
        argument_spec=dict(
            test_item=dict(type='str', required=True),
        ),
        provided_arguments=dict(test_item='test_value'),
    )
    task_vars = {}

    task_name = 'test_task_name'
    task_action = 'test_task_action'
    action_module = ActionModule(
        task=dict(name=task_name, action=task_action, args=task_args),
        connection=dict(),
        runner_path='',
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    result = action_module.run(task_vars=task_vars)
    assert result['changed'] is False


# Generated at 2022-06-21 03:12:05.872555
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    args_from_vars = ActionModule({}).get_args_from_task_vars({'arg1': {}, 'arg2': {}}, {'arg1': 'value1', 'arg2': 'value2'})
    assert isinstance(args_from_vars, dict)
    assert 'arg1' in args_from_vars and 'value1' == args_from_vars['arg1']
    assert 'arg2' in args_from_vars and 'value2' == args_from_vars['arg2']


# Generated at 2022-06-21 03:12:11.244800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-21 03:12:23.268095
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    import copy
    import sys
    import unittest

    from ansible.module_utils.six import string_types

    from ..action_module import ActionModule

    class TestActionModule(unittest.TestCase):

        def setUp(self):
            self.action_module = ActionModule()

        def test_get_args_from_task_vars(self):
            arg_spec = {
                'foo': {'type': string_types},
                'bar': {'type': string_types},
                'baz': {'type': string_types}
            }
            task_vars = {
                'foo': '{{ bar }}',
                'bar': '{{ baz }}',
                'baz': 'baz_value'
            }

            result = self.action_module.get_args_from_

# Generated at 2022-06-21 03:12:30.769028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    expected_action_module_args_list = ['argument_spec', 'provided_arguments']
    expected_action_module_args_dict = {'argument_errors': [], 'changed': True,
                                        'msg': 'Validation of arguments failed:\n%s' % '\n'.join(validation_result.error_messages)}
    action_module = ActionModule()
    # test_args_list
    assert action_module.args_list == expected_action_module_args_list
    # test_args_dict
    assert action_module.args_dict == expected_action_module_args_dict

# Generated at 2022-06-21 03:12:43.132230
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action = ActionModule()
    action._templar = type('Templar', (object,), {})
    action._templar.template = lambda x: x

    # test that get_args_from_task_vars() raises the proper exception if argument_spec is None
    try:
        result = action.get_args_from_task_vars(None, {})
        assert False, 'AnsibleError exception should have been raised'
    except AnsibleError as e:
        assert e.message == 'Incorrect type for argument_spec, expected dict and got NoneType'

    # test that get_args_from_task_vars() raises the proper exception if argument_spec is not a dict

# Generated at 2022-06-21 03:12:47.294900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_self = type('',(),{})()
    mock_self.task = type('',(),{'args':{'validate_args_context':{}}})()
    assert isinstance(ActionModule(mock_self), ActionModule)

# Generated at 2022-06-21 03:12:58.492398
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''unit test - get_args_from_task_vars'''
    # instantiate ActionModule
    action = ActionModule
    # mock self, since get_args_from_task_vars is a bound method that takes 'self' as an argument
    self = action()

    # mock objects
    argument_spec = {'one': {}, 'two': {}, 'three': {}}
    task_vars = {
        'one': 'a',
        'two': '{{b}}',
        'three': '{{ansible_host_ip}}',
        'b': 'c',
    }

    # run get_args_from_task_vars with mocked objects
    results = self.get_args_from_task_vars(argument_spec, task_vars)

    # assert that results match expected values
   

# Generated at 2022-06-21 03:13:04.033901
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule '''
    action_module = ActionModule()
    task = dict(args=dict(argument_spec=dict(name=dict(type='str'), version=dict(type='int'))))
    tmp = None
    task_vars = dict()
    action_module.run(tmp, task_vars)

# Generated at 2022-06-21 03:13:11.649705
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test for `ansible.plugins.action.validate_argument_spec.ActionModule.run` method'''   # TODO: (mgoddard) Generalize this string
    action_module = ActionModule()
    params = dict()
    args = dict()
    task = dict()
    task_vars = dict()

    action_module._task = task
    action_module._task.action = 'validate_argument_spec'
    action_module._task.args = args
    action_module._task.args['argument_spec'] = dict()
    action_module._task.args['provided_arguments'] = dict()

    # Test without argument_spec

# Generated at 2022-06-21 03:13:15.830982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create the object without arguments
    action_module_obj = ActionModule()
    # Check the value of attribute TRANSFERS_FILES
    assert action_module_obj.TRANSFERS_FILES == False


# Generated at 2022-06-21 03:13:17.185982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert isinstance(result,ActionModule)


# Generated at 2022-06-21 03:13:34.407241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import create_autospec
    from ansible.utils.vars import combine_vars

    class TestActionModule(ActionModule):
        def get_args_from_task_vars(self, argument_spec, task_vars):
            return self._templar.template({})

        def run(self, tmp=None, task_vars=None):
            return {
                'changed' : False,
                'msg' : "The arg spec validation passed",
                'validate_args_context' : {},
            }

    # Test module initialization
    m1 = TestActionModule()
    assert m1

    # Test ActionModule._templar
    m2 = TestActionModule()
    m2._templar = create

# Generated at 2022-06-21 03:13:46.287134
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    test_module = ActionModule(None, None, None, {})
    arg_spec = {
        'test': {'type': 'str'},
        'loop_test': {'type': 'list'},
        'nested_loop_test': {'type': 'list', 'elements': 'dict', 'options': {'other_key': {'type': 'str'}}}
    }
    task_vars = {
        'test': 'TEST',
        'loop_test': [
            'TEST1',
            'TEST2'
        ],
        'nested_loop_test': [
            {'other_key': 'TEST1'},
            {'other_key': 'TEST2'}
        ]
    }
    result = test_module.get_args_from_task_v

# Generated at 2022-06-21 03:13:58.146548
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:14:09.656328
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define class variables and fixtures
    action = ActionModule()
    action._task = {}
    action._task['args'] = {}
    action._task['args']['validate_args_context'] = {}
    action._task['args']['argument_spec'] = {}
    action._task['args']['provided_arguments'] = {}
    action._task['args']['action_type'] = 'role'
    action._task['args']['role_name'] = 'testrole'
    action._task['args']['entry_point'] = 'testrole'

    # Define test arguments

# Generated at 2022-06-21 03:14:20.525278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing the module used to validate an arg spec in an entry point
    argument_spec = dict(
        argument1=dict(type='str'),
        argument2=dict(type='list', elements='str')
    )

    # Use case 1: No errors
    task_vars = dict(argument1='a', argument2=['b'])
    module = ActionModule()
    module._task = dict(args=dict(argument_spec=argument_spec, provided_arguments=dict(argument1="a", argument2=['b'])))
    result = module.run(task_vars=task_vars)
    assert result['argument_spec_data'] == argument_spec
    assert result['argument_errors'] == []
    assert result['msg'] == 'The arg spec validation passed'

    # Use case 2: Validation error
   

# Generated at 2022-06-21 03:14:26.375847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test import
    from ansible.plugins.action import ActionModule
    # Test the constructor
    action_module = ActionModule()
    # Test the get_args_from_task_vars function
    action_module.get_args_from_task_vars(argument_spec = {'name': {'type': 'str', 'required': True, 'agrs': 'name_val'}, 'type': {'type': 'str', 'required': True}}, task_vars = {'name': 'name_val', 'type': 'type_val'})
    # Test the run function
    action_module.run(tmp = None, task_vars = {'name': 'name_val', 'type': 'type_val'})

# Generated at 2022-06-21 03:14:35.758987
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test for:
    # def run(self, tmp=None, task_vars=None):
    #

    from ansible.plugins.action.validate_argument_spec import ActionModule

    actionModule = ActionModule(None, None, None, None, None)


    # 1.
    # Test case no. 1:
    #   Test case with first param 'tmp' not set
    #
    # Expected result:
    #   In case of no param 'tmp' code should raise an exception 'AnsibleError'
    #
    try:
        result = actionModule.run()
    except Exception as exception:
        if type(exception) is not AnsibleError:
            raise


    # 2.
    # Test case no. 2:
    #   Test case with first param 'tmp' set
    #


# Generated at 2022-06-21 03:14:41.571253
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''Unit tests: test_ActionModule_get_args_from_task_vars'''

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import PY2
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.common.text.converters import to_text

    # Mock variables

# Generated at 2022-06-21 03:14:50.645993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        '''
        Unit test for method run of class ActionModule.
        '''
        # This is the module and args we will emulate for the run of this
        # module by the test.
        ignore_errors = dict()
        ignore_errors['validate_args_context'] = 'I am not a module'
        ignore_errors['argument_spec'] = {
            'name': {'required': True, 'type': 'str'},
            'ignore_errors': {'default': False, 'type': 'bool'}
        }
        ignore_errors['provided_arguments'] = {
            'ignore_errors': True,
        }
        instance = ActionModule()
        # Mock the task vars
        task_vars = dict()
        # First test: Test the case where we provide a list of args

# Generated at 2022-06-21 03:15:00.608528
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''Unit test for method get_args_from_task_vars of class ActionModule'''

    # This method focuses on testing the 'type' of arg spec
    # For more coverage of the arg spec, please see the tests for AnsibleModule
    from ansible.plugins.action.argument_validation import ActionModule
    from ansible.module_utils.six import iteritems

    # Verify that Variable fails.
    args_from_vars = {
        'foo': {
            'type': 'Variable',
        }
    }

    task_vars = {
    }
    action_module = ActionModule()
    with pytest.raises(AnsibleError) as err:
        action_module.get_args_from_task_vars(args_from_vars, task_vars)


# Generated at 2022-06-21 03:15:18.369954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global action_module
    action_module = ActionModule()

# Generated at 2022-06-21 03:15:19.362879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-21 03:15:28.629514
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # A typical data structure for arg_spec from an entry point (a role)
    argument_spec = {
        'name': {'type': 'str'},
        'state': {'type': 'str', 'choices': ['present', 'absent'], 'default': 'present'},
        'force': {'type': 'bool', 'default': False}
    }
    # The values that should pass the validation check
    provided_arguments = {'name': 'something'}
    # The task variables, in case the arg_spec needs to pull in a value
    task_vars = {'name': 'something'}

    # Create the action
    action_module = ActionModule(None, None, None)
    # Create an ActionBase class method (to be called by action_module.run when running the action)

# Generated at 2022-06-21 03:15:39.519382
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    test_action = ActionModule({'name':'test_ActionModule_get_args_from_task_vars'}, None, None)
    expected_result = {
        'one': 'value',
        'two': 2,
        'three': 'three',
        'four': {
            'five': 'five',
            'six': 6
        }
    }

# Generated at 2022-06-21 03:15:41.807302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert len(module._task.args) == 0, "Expected empty args"



# Generated at 2022-06-21 03:15:52.858675
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class DummyModule(object):
        def __init__(self, argument_spec=None, bypass_checks=False, no_log=False, check_invalid_arguments=None, mutually_exclusive=None, required_together=None, required_one_of=None, required_by=None):
            self.argument_spec = argument_spec
            self.bypass_checks = bypass_checks
            self.no_log = no_log
            self.check_invalid_arguments = check_invalid_arguments
            self.mutually_exclusive = mutually_exclusive
            self.required_together = required_together
            self.required_one_of = required_one_of
            self.required_by = required_by
            self.params = dict()

    result = dict()

# Generated at 2022-06-21 03:16:02.465342
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit testing for method get_args_from_task_vars of class ActionModule
    '''

    class AnsibleTemplar:
        '''
        Class AnsibleTemplar
        '''
        def __init__(self):
            self.data = {}

        def template(self, data):
            self.data = data

    class ActionModuleTest(ActionModule):
        '''
        Class ActionModuleTest extends ActionModule
        '''
        def __init__(self, args):
            super(ActionModuleTest, self).__init__(args)
            self._templar = AnsibleTemplar()


# Generated at 2022-06-21 03:16:11.851950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    from ansible.executor.task_result import TaskResult

    from ansible.utils.vars import combine_vars

    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    mock_ActionBase_run = Mock(return_value={})
    mock_ArgumentSpecValidator_validate = Mock(return_value=MockArgumentSpecResults())
    mock_get_args_from_task_vars = Mock(return_value={})
    mock_AnsibleError = Mock()
    mock_combine_vars = Mock(return_value={})

    action_module = ActionModule(Mock(), Mock())
    action_module._templar = Mock()
    action_module.run = mock_ActionBase_

# Generated at 2022-06-21 03:16:22.041251
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    import ansible.plugins.action
    import ansible.utils.vars
    import ansible.template.template
    import ansible.module_utils.common.arg_spec
    import ansible.template.template
    import ansible.template.safe_eval
    import ansible.template
    import ansible.plugins.loader
    import ansible.parsing.vault
    import ansible.parsing.yaml
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.errors
    import sys
    import _frozen_importlib
    import ansible.parsing.vault
    import ansible.parsing.yaml
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible

# Generated at 2022-06-21 03:16:27.650843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule({})
    # We are not actually going to try and use this for anything, but the class
    # __init__ requires a data structure here.

# Generated at 2022-06-21 03:17:10.859739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader

    am_class = action_loader.get('validate_argument_spec', class_only=True)
    kwargs = {
        'validate_args_context': {
            'file': 'my/file.py',
            'line': 42,
            'role': 'myrole',
            'action_name': 'myaction',
        },
        'provided_arguments': {
            'my_arg': 'my_value',
        },
    }
    am = am_class(kwargs, templar=None, connection=None, play_context=None, loader=None, templar_available=False, shared_loader_obj=None)

# Generated at 2022-06-21 03:17:22.886142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(ActionModule, None, {'argument_spec': {'vlan': {'type': 'int', 'required': False, 'default': 0}}})
    assert result['argument_errors'] == []
    result = ActionModule.run(ActionModule, None, {'argument_spec': {'vlan': {'type': 'int', 'required': False, 'default': 0}},
                                                    'provided_arguments': {'vlan': 'a'}})
    assert result['argument_errors'] == ['vlan: Value a (type: str) must be an integer']

# Generated at 2022-06-21 03:17:32.740298
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.six import StringIO
    from ansible.compat.tests import unittest
    from ansible.module_utils.ansible_release import __version__ as ANSIBLE_VERSION
    from ansible.module_utils.ansible_release import __version__, __author__
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.plugins.action.validate_argument_spec import ActionModule

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    class Test_module(unittest.TestCase):
        def setUp(self):
            self.module = MagicMock()
            self.validate_argument_spec = ActionModule()


# Generated at 2022-06-21 03:17:33.360484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 03:17:43.648976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    validate_arg_spec module run() method unit test stub
    """
    import ansible_collections

    ansible_collections.ansible.netcommon.plugins.modules.validate_arg_spec.ActionModule = ActionModule
    argument_spec = {"ip": {"type": "str", "required": True}, "optname": {"type": "str"}}
    provided_arguments = {"ip": "1.1.1.1", "optname": "test"}
    validate_args_context = {}
    task_args = {"argument_spec": argument_spec, "provided_arguments": provided_arguments, "validate_args_context": validate_args_context}
    from ansible.vars.unsafe_proxy import UnsafeProxy #import UnsafeProxy
    task_vars = UnsafeProxy({})
   

# Generated at 2022-06-21 03:17:54.967750
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    import unittest
    import ansible.plugins.action.vars as action

    class FakeTask(object):
        ''' Class that implements a fake task '''
        def __init__(self, task_args, task_options=None):
            self.args = task_args
            self.options = task_options

    class FakeModuleArgs(object):
        ''' Class that implements a fake ModuleArgs object '''
        def __init__(self, args=None, options=None):
            self.args = args
            self.options = options

    class ActionModuleTestCase(unittest.TestCase):
        ''' Class that implements a test case for testing the ActionModule class '''


# Generated at 2022-06-21 03:18:00.568943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    import sys
    import platform

    if platform.system() == 'Windows':
        source_path = "c:\\tmp\\ansible_collections\\redhat\\cloud\\plugins\\action\\validate_argument_spec.py"
    else:
        source_path = "/tmp/ansible_collections/redhat/cloud/plugins/action/validate_argument_spec.py"

    sys.path.append(source_path)
    from validate_argument_spec import ActionModule


# Generated at 2022-06-21 03:18:04.942429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Using the __init__ method to test constructor
    # since the run method is abstract
    action_module = ActionModule()

    assert action_module.TRANSFERS_FILES is False, "TRANSFERS_FILES needs to be set to False for this module"



# Generated at 2022-06-21 03:18:14.536044
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    INPUT_ARGUMENT_SPEC = {
        'arg1': {
            'type': 'str'
        },
        'arg2': {
            'type': 'int'
        }
    }
    INPUT_TASK_VARS = {
        'arg1': '{{value}}',
        'arg2': 10,
        'value': 'foo'
    }
    EXPECTED_RESULT = {
        'arg1': 'foo',
        'arg2': 10
    }

    mocked_action_module = ActionModule(task=None, connection=None, PlayContext=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-21 03:18:23.504556
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:20:12.119436
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    test_action_base = ActionBase()
    test_action_base.name = 'test_action_base_name'
    test_action_base.task_vars = dict()
    test_action_base._task = dict()
    test_action_base._task_fields = dict()
    test_action = ActionModule(test_action_base)

    argument_spec = {'test_argument': {'type': 'str'}}
    task_vars = {'test_argument': 'test_templated_value'}
    expected_args = {'test_argument': 'test_templated_value'}
    args = test_action.get_args_from_task_vars(argument_spec, task_vars)
    assert args == expected_args

# Generated at 2022-06-21 03:20:23.484745
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # NOTE: I believe there are some pieces missing here, but it works for now.
    class TestActionModule(ActionModule):
        def __init__(self, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None):
            self._task = task
            self._connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

    task_vars = {}

    class TestTask(object):
        def __init__(self, args):
            self.args = args

    class TestPlayContext(object):
        def __init__(self, remote_addr, delegated_vars):
            self.remote_addr = remote_

# Generated at 2022-06-21 03:20:26.700636
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule({'argument_spec': {'test_test': {'type': 'str'}}, 'provided_arguments': {'test_test': 'test'}})
    m.run(task_vars={})

# Generated at 2022-06-21 03:20:38.027821
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {"args": {"argument_spec": {"test_arg": {"type": "str"}}, "provided_arguments": {}}}
    action_module._task["args"]["validate_args_context"] = {"module_name": "test_module", "entry_point": "test_entry_point"}

    # Verify that a validation error is returned when the argument spec fails
    action_module._task["args"]["provided_arguments"]["test_arg"] = "test"
    result = action_module.run()
    assert "Validation of arguments failed" in result["msg"]
    assert "failed to match" in result["msg"]
    assert "test_module.test_entry_point.test_arg" in result["msg"]

# Generated at 2022-06-21 03:20:46.162793
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule(None, None)
    assert action_module is not None

    # Validate an argspec against provided data
    result = action_module.get_args_from_task_vars({'argument1': {'type': 'str'}}, {'argument1': '{{ foo }}'})
    assert result['argument1'] == ''

    # Validate an argspec against provided data
    result = action_module.get_args_from_task_vars({'argument1': {'type': 'str'}}, {'argument1': '{{ foo }}'}, foo='bar')
    assert result['argument1'] == 'bar'

    # Validate an argspec against provided data