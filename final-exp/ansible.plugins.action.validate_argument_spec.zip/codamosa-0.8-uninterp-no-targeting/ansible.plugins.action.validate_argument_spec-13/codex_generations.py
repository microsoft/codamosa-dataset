

# Generated at 2022-06-21 03:10:50.521542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = {'name': 'Validating argument spec', 'args': {'argument_spec': None, 'provided_arguments': None}}
    result = {'validate_args_context': {}, 'failed': None,
              'msg': 'The arg spec validation passed', 'changed': False}

    assert ActionModule(task, {}).run() == result



# Generated at 2022-06-21 03:10:51.034496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:11:00.836912
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test ActionModule run method
    '''
    # Create a new instance of the module
    action_module = ActionModule()

    # Define the argument_spec expected by the method
    # argument_spec = {
    #     'argument_spec': {
    #         'type': 'dict',
    #         'required': True,
    #         'default': {},
    #         'options': {}
    #     },
    #     'provided_arguments': {
    #         'type': 'dict',
    #         'required': True,
    #         'default': {},
    #         'options': {}
    #     }
    # }

    # Define the argument_spec as a dict.
    argument_spec = {}

    # Set the argument spec as the action_module's argument spec
    action

# Generated at 2022-06-21 03:11:02.316566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action = ActionModule(None, None, None, None)
    assert test_action

# Generated at 2022-06-21 03:11:03.953933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # FIXME: Implement unit test for this function
    pass

# Generated at 2022-06-21 03:11:05.804173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)


# Generated at 2022-06-21 03:11:16.196851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    from ansible.module_utils.six import string_types
    from ansible.plugins.action import ActionBase
    import ansible
    from ansible.modules.network.ios.validate_argument_spec import ActionModule
    from collections import namedtuple
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    import ansible.module_utils.basic
    import ansible.module_utils.network
    ModuleArgs = namedtuple('ModuleArgs', ['argument_spec', 'provided_arguments'])
    task_vars = {'ansible_facts': {'ansible_net_hostname': 'hostname',
                                   'ansible_net_version': '15.0',
                                   'ansible_net_model': 'IOS-XRv 9000'}}
   

# Generated at 2022-06-21 03:11:19.678876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    A Utility function to unit test ActionModule

    :return: none
    '''
    obj = ActionModule(None, dict(), {})
    obj.run(None, dict())

# Generated at 2022-06-21 03:11:25.909969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(AnsibleError) as excinfo:
        task_vars = {}
        tmp=None
        module = AnsibleModule(argument_spec=dict())
        action = ActionModule(task=dict(args=dict(argument_spec='', provided_arguments='')), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        action.run(tmp, task_vars)
    assert '"argument_spec" arg is required in args: {}' in str(excinfo.value)

# Generated at 2022-06-21 03:11:36.476105
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    class Task:
        def __init__(self, args):
            self._args = args

        def args(self):
            return self._args

    class Templar:
        def template(self, data):
            return data

    # Prepare args
    spec = {
        'name': {'type': string_types()},
        'flag': {'type': 'bool', 'required': False, 'default': False},
        'ports': {'type': 'list'},
        'options': {'type': 'dict'},
    }

    provided_arguments = {
        'name': 'sample_name',
        'flag': True,
        'ports': [80, 443],
        'options': {
            'key1': 'value1',
            'key2': 'value2',
        }
    }


# Generated at 2022-06-21 03:11:48.056237
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    class FakeActionModule:
        def __init__(self):
            self._templar = FakeTemplar()

    class FakeTemplar:
        def template(self, args):
            if type(args) is dict:
                new_args = {}
                for key, value in args.iteritems():
                    new_args[key] = self.template(value)
                return new_args
            elif type(args) is list:
                new_args = []
                for value in args:
                    new_args.append(self.template(value))
                return new_args
            else:
                return args

    # Test that arguments that are not in the task_vars dict are not returned
    action_module = ActionModule()

# Generated at 2022-06-21 03:11:59.313000
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:12:08.523887
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    class MyActionModule(ActionModule):
        def __init__(self, task, connection, play_context, loader=None, templar=None, shared_loader_obj=None):
            self.task = task
            self.connection = connection
            self._play_context = play_context
            self._loader = loader
            self._templar = templar
            self._shared_loader_obj = shared_loader_obj

# Generated at 2022-06-21 03:12:10.835502
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule(None, None, None, None, None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 03:12:23.515698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit testing for method run of class ActionModule'''
    action_module = ActionModule()

    # Testing the case where method run receives no arguments
    # In this case an exception is raised
    try:
        action_module.run()
    except Exception as err:
        assert err.args[0] == 'missing required arguments: tmp, task_vars'

    # Testing the case where method run receives two arguments: tmp and task_vars
    # In this case tmp is ignored
    action_module.run(tmp=None, task_vars=dict())

    # Testing the case where method run receives two arguments: tmp and task_vars;
    # and task_vars has the item 'argument_spec'
    # In this case tmp is ignored

# Generated at 2022-06-21 03:12:30.650159
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule()
    action_module._templar = get_templar()
    action_module._task = get_task()
    action_module._task.args = dict()
    task_vars = dict(arg_name="{{value}}", value="value")
    argument_spec = dict(arg_name=dict(type="str", default=None))
    args = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert args == dict(arg_name="value")


# Generated at 2022-06-21 03:12:42.989736
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for method get_args_from_task_vars of class ActionModule
    '''
    from ansible.plugins.action import ActionModule

    task_vars = {
        'as_dict': {
            'foo': 'bar'
        },
        'as_list': ['foo', 'bar'],
        'as_str': 'foo bar',
    }

    argument_spec = {
        'arg_str': {'type': 'str'},
        'arg_list': {'type': 'list'},
        'arg_dict': {'type': 'dict'},
    }

    action_module = ActionModule(None, None, None, None)
    result = action_module.get_args_from_task_vars(argument_spec, task_vars)

    assert isinstance

# Generated at 2022-06-21 03:12:48.296802
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    # Instance of ActionModule class
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(),
                                 templar=dict(), shared_loader_obj=dict())

    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:12:52.139980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Tests for creating the ActionModule object
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action.argspec_validate import ActionModule as ArgspecValidateActionModule

    test_action_module = ArgspecValidateActionModule(AnsibleModule(
        argument_spec={},
    ))
    assert test_action_module

# Generated at 2022-06-21 03:12:55.197295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.TRANSFERS_FILES is False


# Generated at 2022-06-21 03:13:12.411591
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for method get_args_from_task_vars of class ActionModule
    '''

    action = ActionModule(dict(), dict(), True, None)
    action._templar = FakeTemplar()


# Generated at 2022-06-21 03:13:20.652427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('setup', 'playbook', 'play', 'task', 'args', 'inject', 'loader')
    assert action._name == 'setup'
    assert action._play_context.playbook == 'playbook'
    assert action._play_context.play == 'play'
    assert action._task.name == 'task'
    assert action._task.args == 'args'
    assert action._task.action == 'setup'
    assert action._shared_loader_obj.inject == 'inject'
    assert action._loader.get_all_plugin_loaders() == 'loader'
    assert action.transfers_files == False

# Generated at 2022-06-21 03:13:21.143029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ...

# Generated at 2022-06-21 03:13:30.650567
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Test get_args_from_task_vars against a simple arg spec with only types.
    '''
    # Gather test data
    mock_vars = {
        'a': 'val1',
        'b': 'val2',
        'c': ['val3', 'val4'],
    }
    arg_spec = {
        'param1': {'type': 'str'},
        'param2': {'type': 'str'},
        'param3': {'type': 'list'},
    }
    expected_args = {
        'param1': 'val1',
        'param2': 'val2',
        'param3': ['val3', 'val4'],
    }

    # create mock ActionModule
    tmp = 'test_data'

# Generated at 2022-06-21 03:13:31.239867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:13:35.668519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module
    with pytest.raises(AnsibleError):
        """
        Test the run function of class ActionModule with empty task_vars dict
        """
        module.run(task_vars={})
    with pytest.raises(AnsibleError) as error:
        """
        Test the run function of class ActionModule with incorrect type of argument_spec value
        """
        module.run(task_vars={'argument_spec': 'incorrect_argument_spec'})
        assert error.value.message == 'Incorrect type for argument_spec, expected dict and got %s' % type('incorrect_argument_spec')


# Generated at 2022-06-21 03:13:47.524329
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    argument_spec = {'choices':dict(type='list', choices=['a', 'b', 'c'])}
    argument_spec_data = {'choices':dict(type='list', choices=['a', 'b', 'c'])}
    provided_arguments = {'choices':'a'}

    # Test when task_vars is None
    action_module = ActionModule()
    result = action_module.run(task_vars=None)
    assert result['failed']

    # Test when argument_spec is not in task_vars
    action_module = ActionModule()
    result = action_module.run(task_vars={'argument_spec':argument_spec_data})
    assert result['failed']

    # Test when incorrect type for argument_spec
    action_module = ActionModule()


# Generated at 2022-06-21 03:13:59.557705
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    am = ActionModule(None, None)
    am_ = am
    am_.trusted_task_data = {'template': {'user_name': '{{abc}}', 'password': '{{xyz}}', 'port': 23, 'timeout': 10}}
    am_.trusted_host_data = {'abc': 'def', 'xyz': 'pqr'}
    a_spec_data = {'user_name': {'type': 'str'}, 'password': {'type': 'str', 'no_log': True},
                   'port': {'type': 'int'}, 'timeout': {'type': 'int', 'default': 10}}
    ret = am_.get_args_from_task_vars(a_spec_data, {})

# Generated at 2022-06-21 03:14:00.930812
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj is not None


# Generated at 2022-06-21 03:14:13.367666
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    # setup
    am = ActionModule(
        task=None,
        connection=None,
        _play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    argument_spec = {
        'arg1': {'required': True},
        'arg2': {'default': 'something else'}
    }
    task_vars = {
        'arg1': 'hello',
        'arg2': 'something'
    }
    expectation = {
        'arg1': 'hello',
        'arg2': 'something'
    }

    # test
    result = am.get_args_from_task_vars(argument_spec, task_vars)

    # assert
    assert result == expectation


# Generated at 2022-06-21 03:14:32.350123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(),
                          "Get a list of available updates",
                          "test",
                          "test",
                          "test",
                          "test")
    assert isinstance(action, ActionModule)


# Generated at 2022-06-21 03:14:41.837252
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for method get_args_from_task_vars of class ActionModule
    '''
    from ansible.plugins.loader import action_loader
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.six import StringIO
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.text import to_text

    class MockTaskVars(object):
        '''
        MockTaskVars class
        '''
        def __init__(self):
            self.var_name_arg = {}

    class MockConnection(Connection):
        '''
        MockConnection class
        '''

# Generated at 2022-06-21 03:14:50.805211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.context import context
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    context.CLIARGS = {'module_path': None}
    context.STDOUT_LOGGING_FLAGS = dict()
    context.STDOUT_LOGGING_FLAGS['verbosity'] = 0
    context.STDOUT_LOGGING_FLAGS['log_path'] = None
    context.STDOUT_LOGGING_FLAGS['one_log_per_task'] = False

    variable_manager = VariableManager()
    loader = DataLoader()
    play_context = PlayContext()

    t = Task()
    t._

# Generated at 2022-06-21 03:15:00.694685
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_plugin = ActionModule()
    # noinspection PyArgumentList
    action_plugin._task = mock.MagicMock()
    # noinspection PyArgumentList
    action_plugin._templar = mock.MagicMock()
    # noinspection PyArgumentList
    action_plugin._task.args = {'argument_spec': {}, 'provided_arguments': {}}
    # noinspection PyArgumentList,PyTypeChecker
    action_plugin._templar.template.return_value = {}
    result = action_plugin.run(None, None)
    assert not result['failed']
    # noinspection PyArgumentList
    action_plugin._task.args = {'argument_spec': {}, 'provided_arguments': None}
    result = action_plugin.run(None, None)


# Generated at 2022-06-21 03:15:08.628706
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.six import string_types

    validator = ArgumentSpecValidator({
        'arg1': {'type': 'str'},
        'arg2': {'type': 'list'},
        'arg3': {'type': 'dict'},
        'arg4': {'type': 'int'},
        'arg5': {'type': 'bool', 'default': True}
    })

    class TestActionModule:
        class TestTask:
            class TestArgs:
                def __init__(self, args):
                    self.args = args

            def __init__(self, args):
                self.args = self.TestArgs(args)


# Generated at 2022-06-21 03:15:14.025586
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # unit test for action plugin run method
    module1 = ActionModule()
    try:
        module1.run()
        assert False, "ActionModule run() method raised Exception unexpectedly!"
    except AnsibleError:
        pass
    except Exception as ex:
        assert False, "ActionModule run() method raised %s Exception and did not raise AnsibleError!" % type(ex)

# Generated at 2022-06-21 03:15:14.945719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule()) is ActionModule

# Generated at 2022-06-21 03:15:15.631721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:15:19.778244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        import ansible.modules.system.validate_argument_spec
        ActionModule(ansible.modules.system.validate_argument_spec, {})
        return 'success'
    except Exception as e:
        return repr(e)

# Generated at 2022-06-21 03:15:26.725405
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    action_module_instance = ActionModule()
    result = action_module_instance.get_args_from_task_vars({'name': {'type': 'str'}}, {'name': 'some_name'})
    assert isinstance(result, dict)
    assert result['name'] == 'some_name'

    result = action_module_instance.get_args_from_task_vars({'name': {'type': 'str'}}, {'name': '{{ some_name }}'})
    assert result['name'] == '{{ some_name }}'


# Generated at 2022-06-21 03:16:06.228365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-21 03:16:16.513988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    class DummyTask:
        def __init__(self):
            self.args = {'argument_spec': {}, 'provided_arguments' : {}}
            self.action = 'validate_argument_spec'
            self.name = 'validate_argument_spec'
    class DummyPlayContext:
        pass
    module._task = DummyTask()
    module._play_context = DummyPlayContext()
    module._templar = DummyTemplar()
    with pytest.raises(AnsibleError) as exception_info:
        module.run()
    assert exception_info.value.message == '"argument_spec" arg is required in args: {}'
    module._task.args['argument_spec'] = {}

# Generated at 2022-06-21 03:16:24.719755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleTest(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return {'test': 'test'}

    example_args = {'argument_spec': {
        'test_arg': dict(required=True, type='str'),
        'another_arg': dict(required=False, type='bool')
    },
        'provided_arguments': dict(test_arg='value', another_arg=True),
        'validate_args_context': dict(role_name='test_role')}

    task = dict(action=dict(module=__name__, args=example_args))
    action_module = ActionModuleTest(task, dict())
    result = action_module.run(None, dict())

    assert result['test'] == 'test'

# Generated at 2022-06-21 03:16:25.222549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:16:36.988603
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple
    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import combine_vars

    am = ActionModule({})
    argument_spec = {
        'name': {
            'type': 'str',
            'required': True
        },
        'other': {
            'type': 'str'
        }
    }
    task_vars = {
        'my_name': 'Jane',
    }
    result = am.get_args_from_task_vars(argument_spec, task_vars)
    assert result == {'name': 'Jane'}

# Generated at 2022-06-21 03:16:43.622021
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars

    fake_var = {'var_key': 'var_value'}
    fake_task_vars = {
        'var_val': 'var_val',
        'func_val': '{{ var_key | upper }}'
    }
    tmp = None
    fake_argument_spec = {
        'non_task_var_key': {},
        'var_val': {},
        'same_key': {},
        'func_val': {},
        'template_val': {},
    }

    class mock_ActionBase(ActionBase):
        def __init__(self, tmp, task_vars):
            super(mock_ActionBase, self).__init__(tmp, task_vars)


# Generated at 2022-06-21 03:16:47.111693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actual = ActionModule.run(tmp=None, task_vars=None)
    expected = {
        "ansible_facts": {},
        "changed": False,
        "invocation": {
            "module_args": "",
            "module_complex_args": {}
        },
        "msg": "Hello from the run method"
    }
    assert actual == expected

# Generated at 2022-06-21 03:16:58.111829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Note: this unit test uses a mocked version of ActionBase
    # so that the _connection and _play_context members of a module manager
    # can be set as needed.
    #
    # To test the run method of ActionModule, we'll use the following three inputs
    # to the actionmod:
    #   1. the task data
    #   2. a mocked version of Connection (with a registered take_action())
    #   3. a mocked version of PlayContext (so we can set the connection name)
    #
    # The unit test is in three parts:
    #   1. Create some test data
    #   2. Run the action module
    #   3. Test the result
    create_test_data()

    # Test with a broken connection map

# Generated at 2022-06-21 03:17:08.056264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.validation import ArgumentSpec
    from ansible.plugins.action.argument_validation import ActionModule
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.config
    import ansible.plugins
    import json
    # Create the Task object
    Task_obj = Task()
    Task_obj.args = {'validate_args_context': {},
        'argument_spec': {'name': {'type': 'str'},
                          'age': {'type': 'int'}},
        'provided_arguments': {'name': 'ansible', 'age': '1'}}
    # Create the task queue manager

# Generated at 2022-06-21 03:17:12.422807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The import here is _not_ using a relative import.
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.six import string_types

    task_vars = {
        'first_argument': 'Foo',
        'second_argument': 'Bar',
        'third_argument': True,
    }

    argument_spec = {
        'first_argument': {'type': 'str'},
        'second_argument': {'type': 'str'},
        'third_argument': {'type': 'bool'},
    }

    provided_arguments = {
        'first_argument': 'Foo',
        'second_argument': 'Bar',
        'third_argument': True,
    }


# Generated at 2022-06-21 03:18:23.504722
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    assert True

# Generated at 2022-06-21 03:18:27.943484
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    argument_spec_interfaces_modules = {
        'name': {'type': 'str', 'required': True},
        'description': {'type': 'str', 'required': False},
        'type': {'type': 'str', 'required': True, 'choices': ['management', 'loopback', 'ethernet', 'ethernet-tagged',
                                                             'ethernet-raw', 'aggregate', 'vlan', 'tunnel',
                                                             'bridge', 'bridge-port', 'wireguard']},
        'config': {'type': 'list', 'required': False, 'default': []},
    }

    argument_spec_delete = {
        'name': {'type': 'str', 'required': False},
        'description': {'type': 'str', 'required': False},
    }

# Generated at 2022-06-21 03:18:37.690036
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Unit test code for method get_args_from_task_vars of class ActionModule '''
    class MockTemplar(object):

        def template(self, val):
            return val

    templar = MockTemplar()

    argument_spec_data = {
        'name': {},
        'src': {},
        'dest': {},
        'state': {},
        'other_arg': {},
        'port': {},
        'provider': {},
    }

    task_vars = {
        'name': 'test',
        'provider': 'test-provider',
    }

    action_module = ActionModule(dict(), action=dict(), task=dict())
    action_module._templar = templar

    assert action_module.get_args_from_task

# Generated at 2022-06-21 03:18:41.423726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, templar=None, shared_loader_obj=None)
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-21 03:18:42.064879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 03:18:42.997800
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()
    assert action_module is not None



# Generated at 2022-06-21 03:18:47.952626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    name = 'ActionModule'
    # Create an instance of the class
    actual = ActionModule()
    assert isinstance(actual, ActionModule)
    # Check __module__
    expected = 'ansible_collections.network.nxos.plugins.modules.validate_argument_spec'
    assert actual.__module__ == expected
    # Check __name__
    expected = name
    assert actual.__name__ == expected
    # Check __doc__
    expected = ActionModule.__doc__
    assert actual.__doc__ == expected



# Generated at 2022-06-21 03:18:58.347551
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    test_args = {}
    test_vars = {}

    test_args['first'] = {"type": "str", "default": "firstval"}
    test_args['second'] = {"type": "str", "default": "secondval"}
    test_args['third'] = {"type": "str", "default": "thirdval"}

    test_vars['first'] = "firstval"
    test_vars['second'] = AnsibleUnsafeText("secondval")
    test_vars['third'] = AnsibleUnsafeText("thirdval")


# Generated at 2022-06-21 03:18:59.835099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test for constructor of class ActionModule'''
    act_mod = ActionModule()
    assert act_mod is not None

# Generated at 2022-06-21 03:19:05.008082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    args = {'argument_spec': {'port': {'type': 'int'}, 'server': {'type': 'str'},
                              'host': {'type': 'str'}, 'port': {'type': 'int'}},
            'provided_arguments': {'port': '90'}}
    m._task.args = args
    m._task.args['validate_args_context'] = {'script_name': 'my_script.py',
                                             'inventory_hostname': 'localhost'}
    m._templar = DummyTemplar()
    assert not m.run()['failed']