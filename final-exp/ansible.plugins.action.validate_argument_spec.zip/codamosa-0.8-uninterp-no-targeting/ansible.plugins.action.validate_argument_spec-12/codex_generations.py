

# Generated at 2022-06-21 03:10:48.806094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Test method run of class ActionModule.'''
    action_module = ActionModule(None, {})
    result = action_module.run(None, {})
    assert result['failed']

# Generated at 2022-06-21 03:10:59.204371
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    val_arg_class = ActionModule(
        task=dict(
            args=dict(
                provided_arguments=dict(
                    answer=42,
                    question="Why?"
                ),
                argument_spec=dict(
                    answer=dict(
                        type='int',
                        default=42
                    ),
                    question=dict(
                        type='str',
                        default="What?",
                        choices=["Why?", "What?"]
                    )
                )
            )
        )
    )

    test_vars = dict(
        answer=42,
        question="Why?"
    )

    tmp = val_arg_class.get_args_from_task_vars(
        val_arg_class._task.args['argument_spec'],
        test_vars)

    assert tmp == test_vars

# Generated at 2022-06-21 03:11:10.870537
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    :return: A dict with the following keys:
        - 'failed' (bool): True if the test failed, else False.
        - 'changed' (bool): True if the test changed anything, else False.
        - 'msg' (str): A message about the test result.
    '''
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple

    module = ActionModule()

    # Test when no args come from task_vars
    argument_spec = {'arg1': {'type': 'int'}}
    task_vars = {'arg1': None}

# Generated at 2022-06-21 03:11:21.831292
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.modules.utilities.argument_spec import ArgumentSpec
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple, AnsibleValidationError
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.compat.ipaddress import IPv4Address, IPv6Address


# Generated at 2022-06-21 03:11:30.195286
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Test method get_args_from_task_vars of class ActionModule
    '''
    from ansible.plugins.loader import action_loader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.six import string_types

    action_instance = action_loader.get('net_validate_arg_spec',
                                        task=dict(args=dict(argument_spec=dict(foo=dict(type='bool')))))
    task_vars = dict(foo=True)
    action_instance._templar = dict()
    action_instance._templar.template = lambda x: x

    # Test when variable is present in task variables

# Generated at 2022-06-21 03:11:33.982897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(action_module) == ActionModule

# Generated at 2022-06-21 03:11:42.755159
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    host = MockHost()
    host.vars = {"validate_args_context": "some_ansible_module"}
    queue = MockQueue()
    queue.host_vars = {host: host.vars}
    host.queue = queue
    host.hostname = 'host1'
    # Update the host inventory in the plugin's cache
    ActionModule._inventory = MockInventory(host)
    runner = MockRunner()
    runner.host = host
    runner._hosts_cache = {host.hostname: host}

    plugin = ActionModule(runner)

    task_vars = {
        'validate_args_context': 'some_ansible_module'
    }


# Generated at 2022-06-21 03:11:49.993468
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.six.moves import builtins

    class MockTemplar:
        def template(self, data):
            return combine_vars(data, {'ansible_connection': 'network_cli', 'ansible_network_os': 'ios'})

    class MockTask():
        def __init__(self):
            self.args = dict()
            self.action = 'validate_argument_spec'
            self.action_args = dict()

    class MockPlayContext:
        def __init__(self):
            self.become = None
            self.become_method = None

    class MockAction:
        def __init__(self, action, action_args, task, play_context):
            self._task = MockTask()

# Generated at 2022-06-21 03:12:01.399952
# Unit test for method get_args_from_task_vars of class ActionModule

# Generated at 2022-06-21 03:12:06.617553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    name = 'test_task'
    action_module = ActionModule(name, 'test_task', {})
    assert action_module.name == name
    assert action_module.action_name == 'test_task'
    assert action_module._loader.module_name == 'test_task'
    assert action_module.TRANSFERS_FILES is False


# Generated at 2022-06-21 03:12:11.244389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod

# Generated at 2022-06-21 03:12:15.925303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule = ActionModule()

# python2 -m testtools.run test_validate_args_action_module.py
# python3 -m unittest discover -s ./ -p test_validate_args_action_module.py

# Generated at 2022-06-21 03:12:16.965807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case for constructor
    module = ActionModule()

# Generated at 2022-06-21 03:12:27.781295
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''Unit test for method get_args_from_task_vars of class ActionModule'''
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None)
    argument_spec = dict()
    argument_spec['arg1'] = dict()
    argument_spec['arg2'] = dict()
    task_vars = dict()
    task_vars['arg1'] = '1'
    task_vars['arg2'] = 2
    args_from_vars = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert args_from_vars['arg1'] == '1'
    assert args_from_vars['arg2'] == 2


# Generated at 2022-06-21 03:12:31.755592
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup the test data
    action_module = ActionModule()
    action_module._connection = None
    action_module._task_vars = {}

    # Setup the test task
    task = AnsibleTask()
    action_module._task = task

    # Required args
    task.args = dict()
    task.args["argument_spec"] = dict()
    task.args["provided_arguments"] = dict()

    # test for error when arg spec is not a dict
    argument_spec = list()
    provided_arguments = dict()

    task.args["argument_spec"] = argument_spec
    task.args["provided_arguments"] = provided_arguments
    try:
        result = action_module.run()
    except AnsibleError as e:
        assert "expect dict" in str(e)

    #

# Generated at 2022-06-21 03:12:34.360403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert not action_module.TRANSFERS_FILES
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-21 03:12:45.393030
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule(None, None, None, {}, None)
    action_module._templar = TemplatedModule(None)
    task_vars = {}
    argument_spec = {
        'foo': {'type': 'str'},
        'bar': {'type': 'str'},
        'baz': {'type': 'str'},
        }
    task_vars['foo'] = '{{ bar }}'
    task_vars['bar'] = 'baz'

    #test the case where task_vars is empty
    result = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert 'foo' not in result.keys()
    assert 'bar' not in result.keys()
    assert 'baz' not in result.keys()

# Generated at 2022-06-21 03:12:56.154934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''validate the run() of class ActionModule'''

    # for unit test create a fake class and create a test object
    class FakeArgs(object):
        ''' FakeArgs class '''
        def __init__(self):
            self.argument_spec = None
            self.provided_arguments = None

    class ActionModule_obj(ActionBase):
        ''' ActionBase class '''
        def __init__(self):
            self._task = FakeArgs()

    action_module_obj = ActionModule_obj()

    # mock the argument spec

# Generated at 2022-06-21 03:12:59.360087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Can't really do much here, just make sure it doesn't blow up
    action = ActionModule(dict(foo='bar'))
    assert(action)


# Generated at 2022-06-21 03:13:00.896768
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call the constructor of the class
    ActionModule(dict())

# Generated at 2022-06-21 03:13:15.978847
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    This unit test checks if the constructor of the class ActionModule
    is working properly or not. It takes two parameters as arguments,
    one is tmp and the other is task_vars.
    '''
    from ansible.plugins.action import ActionBase

    ab = ActionBase()
    atm = ActionModule()
    tmp = 'temp'
    task_vars = dict()

    assert ab
    assert atm
    assert isinstance(tmp, string_types)
    assert isinstance(task_vars, dict)



# Generated at 2022-06-21 03:13:24.538264
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    module_arg_spec = {
        'argument_spec': {
            'argument_spec_data': {
                'required': False,
                'type': 'dict'
            },
            'provided_arguments': {
                'required': False,
                'type': 'dict'
            }
        }
    }

    # Test all null value without templated variables
    action_module = ActionModule(ArgumentSpec=module_arg_spec)


# Generated at 2022-06-21 03:13:33.957797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # NOTE: this data structure is not a valid arg spec
    argument_spec = dict(test1=dict(default=False, type='bool'))
    args = dict(argument_spec=argument_spec, provided_arguments=dict(test2=False))

    # argument_spec is required, so fail without it
    result = dict()
    with pytest.raises(AnsibleError) as excinfo:
        ActionModule({'args': {}}, result).run()
    assert 'argument_spec' in str(excinfo)

    # provided_arguments is not required, and defaults to an empty dict
    result = dict()
    assert 'changed' not in result
    assert 'failed' not in result
    assert 'argument_errors' not in result


# Generated at 2022-06-21 03:13:45.645204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    tmp = None
    task_vars = dict()


# Generated at 2022-06-21 03:13:53.052223
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    arg_spec_data = ArgumentSpec.get_argument_spec_data_for_module('test_module')
    self = ActionModule(dict(), dict(), False, dict(), dict(), 'test')
    args = self.get_args_from_task_vars(arg_spec_data, dict())
    assert(isinstance(args, dict))


# Generated at 2022-06-21 03:14:03.565872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    with pytest.raises(AnsibleError) as excinfo:
        action_module.run(None, None)
    assert excinfo.value.args[0] == '"argument_spec" arg is required in args: {}'
    # assert ('"argument_spec" arg is required in args:' in str(excinfo.value))

    task_vars = {'argument_spec': {'arg1': {'type': 'int'}}}
    action_result = action_module.run(None, task_vars)
    assert action_result['msg'] == 'The arg spec validation passed'

    task_vars = {'argument_spec': {'arg1': {'type': 'int'}},
                 'provided_arguments': {'arg1': 1},
                 }

    action

# Generated at 2022-06-21 03:14:09.388662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Function to unit test the constructor of the class
    """
    test_object = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert test_object is not None



# Generated at 2022-06-21 03:14:20.262064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.context import CLIContext
    from ansible.executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    context = CLIContext()
    variable_manager = VariableManager(loader=None)
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 03:14:26.573309
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.errors import AnsibleError
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple
    import os
    import parse

# Generated at 2022-06-21 03:14:35.869842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    class Task(object):
        args = {}

    class Play(object):
        pass
    class MockTemplar(object):
        def template(self, provided_arguments):
            return provided_arguments
    action._templar = MockTemplar()
    action._task = Task()
    action._task.args = {
        'argument_spec': {
            'the_key': {
                'type': 'list',
                'elements': 'str',
                'required': True
            }
        },
        'provided_arguments': {
            'the_key': [1, 2, 3]
        }
    }
    with pytest.raises(AnsibleError) as exc_info:
        action.run()

# Generated at 2022-06-21 03:14:57.162454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionBase = ActionBase()
    assert actionBase.TRANSFERS_FILES == False
    args = {
        'argument_spec': dict(),
        'provided_arguments': dict()
    }
    task = ActionBase.Task(args)
    action = ActionModule(task, {})
    assert action.run(tmp=None, task_vars=None) == {
        'failed': True,
        'msg': '"argument_spec" arg is required in args: {}'
    }


# Generated at 2022-06-21 03:15:04.344106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''action_module.py:ActionModule:Instantiation'''

    collections = None
    config = None
    connection = None
    play_context = None
    task_vars = None

    module = ActionModule(
        collections=collections,
        config=config,
        connection=connection,
        play_context=play_context,
        task_vars=task_vars,
        module_name='action_module.py',
        module_args={
            'argument_spec': {},
            'provided_arguments': {}
        }
    )

    assert module is not None


# Generated at 2022-06-21 03:15:15.074092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    argument_spec = {'argument_spec': {'argument_key': {'type': 'str'}}}
    provided_arguments = {'argument_key': 'argument_value'}
    action_module = ActionModule(None, {'args': {'argument_spec': argument_spec, 'provided_arguments': provided_arguments}})
    actual_result = action_module._task.args
    expected_result = {'argument_spec': {'argument_key': {'type': 'str'}}, 'provided_arguments': {'argument_key': 'argument_value'}}
    assert actual_result == expected_result

# Generated at 2022-06-21 03:15:18.240385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule(dict(action=dict(validate_args_context=dict()), task=dict(args=dict(argument_spec=dict(), provided_arguments=dict()))))
    assert isinstance(obj.run(), dict)


# Generated at 2022-06-21 03:15:18.773496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:15:27.610644
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Test ActionModule get args from task vars '''
    action_module = ActionModule(load_module_specs=False)

    task_vars = {'argument_spec': {'loopback_name': {'type': 'str'}, 'loopback_ip': {'type': 'str'}, 'state': {'type': 'str', 'choices': ['present', 'absent']}}}

    args_dict = action_module.get_args_from_task_vars(task_vars['argument_spec'], task_vars)

    assert 'argument_spec' not in args_dict
    assert 'loopback_name' in args_dict
    assert 'loopback_ip' in args_dict
    assert 'state' in args_dict

# Generated at 2022-06-21 03:15:29.214944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(None, None, None)
    assert obj != None

# Generated at 2022-06-21 03:15:40.093682
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.plugins.action.validate_argument_spec import ActionModule
    from units.mock.loader import DictDataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    dataloader = DictDataLoader({'myplaybook.yml': "[all]\nlocalhost ansible_connection=local\n"})
    inventory = InventoryManager(loader=dataloader, sources='localhost')
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)


# Generated at 2022-06-21 03:15:51.500445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test of module_utils.actions.validate_argument_spec.ActionModule.run'''

    mock_task = {}

    # Setup
    module_args = {'argument_spec': {'argument_name_should_be_required': {'required': True}},
                   'provided_arguments': {'argument_name_should_be_required': 'value'}}
    mock_task['args'] = module_args
    action_module_obj = ActionModule()
    action_module_obj._task = mock_task
    action_module_obj._templar = mock_templar()

    # Test
    result = action_module_obj.run(tmp=None, task_vars={})

    # Check results
    assert result['failed'] == False
    assert result['changed'] == False

# Generated at 2022-06-21 03:16:01.450944
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # pylint: disable=line-too-long
    '''
    Get any arguments that may come from `task_vars`.

    Expand templated variables so we can validate the actual values.

    :param argument_spec: A dict of the argument spec.
    :param task_vars: A dict of task variables.

    :returns: A dict of values that can be validated against the arg spec.
    '''

    # pylint: disable=too-many-branches,too-many-statements,too-many-locals,too-many-nested-blocks

    #
    # Create an instance of the class that we are testing
    #

    # Missing the required argument "loader"
    test_obj = ActionModule(None, None, None)

    #
    # Create mock_argument_spec (necessary for ActionBase

# Generated at 2022-06-21 03:16:48.979438
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test with an empty argument spec.
    argument_spec = {}
    task_vars = {}
    args = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert args == {}

    # Test with arguments present in the argument spec.
    argument_spec = {
        'test_arg1': {},
        'test_arg2': {},
    }
    task_vars = {
        'test_arg1': 'test_value1',
        'test_arg2': 'test_value2',
    }

# Generated at 2022-06-21 03:16:50.051779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()



# Generated at 2022-06-21 03:17:00.024459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1. Test failure
    # Error: argument_spec not in task.args
    def mock_getitem_task(arg):
        if arg == 'args':
            return {}

    with pytest.raises(AnsibleError) as excinfo:
        action_module = ActionModule()
        action_module._task = type("FakeTask",(object,),{"args":{}})()
        action_module.run()

    assert '"argument_spec" arg is required in args' in str(excinfo.value)

    # Error: argument_spec not a dict
    with pytest.raises(AnsibleError) as excinfo:
        action_module = ActionModule()
        action_module._task = type("FakeTask",(object,),{"args":{"argument_spec":""}})()
        action_module.run()

# Generated at 2022-06-21 03:17:04.067268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_loader = None
    mock_D = None
    mock_task = None
    mock_connection = None
    action_module = ActionModule(mock_loader, mock_D, mock_task, mock_connection)
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:17:11.851808
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for the method "get_args_from_task_vars"
    in module "ActionModule"
    '''
    import ansible_collections
    import ansible.plugins
    import ansible.plugins.action
    import ansible.plugins.action.copy
    import ansible.module_utils
    arguments = ('argument_name', 'argument_attrs')
    args_dict = dict()
    args_dict['ansible_collections'] = ansible_collections
    args_dict['ansible'] = ansible
    args_dict['ansible.plugins'] = ansible.plugins
    args_dict['ansible.plugins.action'] = ansible.plugins.action
    args_dict['ansible.plugins.action.copy'] = ansible.plugins.action.copy

# Generated at 2022-06-21 03:17:24.940350
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Unit test for method get_args_from_task_vars of class ActionModule
    # - test_ActionModule_get_args_from_task_vars_with_valid_task_vars_and_arguments
    # - test_ActionModule_get_args_from_task_vars_with_valid_task_vars_and_arguments
    from ansible.modules.network.common.utils import validate_argument_spec
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-21 03:17:36.457942
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from collections import namedtuple
    from ansible.plugins.action.validate_arg_spec import ActionModule
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.parsing.vault import VaultLib
    vault_secrets = {'vault_password': 'vault_password_file_value'}
    fake_vault_lib = VaultLib(vault_secrets)


# Generated at 2022-06-21 03:17:39.449629
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.arg_spec_validator import ActionModule
    a = ActionModule()
    assert isinstance(a, ActionModule)

# Generated at 2022-06-21 03:17:46.547475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    import ansible.modules.utilities.validation.validate_argument_spec
    import pytest


# Generated at 2022-06-21 03:17:56.217107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = {
        'argument_spec': {
            'host': {'required': True, 'type': 'str'},
        },
        'provided_arguments': {
            'host': 'test_argument_specs.com',
        },
        'validate_args_context': {
            'roles': {
                'role_name': 'test',
                'role_path': '/path/to/role',
                'role_args': {'my_role_arg': 'value'},
            },
            'tasks': ['tasks/main.yaml'],
            'task_args': {'my_task_arg': 'value'},
        },
    }

    module_mock = ActionModule(None, params, None, None)


# Generated at 2022-06-21 03:19:36.538705
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    # Build a fake module that has a valid argument spec
    class TestModuleArgs:
        argument_spec = dict(
            arg1=dict(type='str'),
            arg2=dict(type='str'),
            arg3=dict(type='str'),
            arg4=dict(type='str'),
            arg5=dict(type='str')
        )

    test_mod = AnsibleModule(TestModuleArgs())

    arg_spec = test_mod.argument_spec

    task_vars = {}
    expected = {}

    # Test no arg spec
    action_mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_mod._task = ansible.module_utils.basic._AnsibleTask()

    args_

# Generated at 2022-06-21 03:19:48.828885
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.validation import check_type_bool
    action_module = ActionModule()
    action_module._templar = None # not used by this method

# Generated at 2022-06-21 03:19:56.080312
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    action_module_obj = ActionModule()

    argument_spec = dict(
        arg1=dict(type='str'),
        arg2=dict(type='int'),
        arg3=dict(type='bool'),
    )

    task_vars = dict(
        arg1="string value",
        arg2=42,
    )

    expected_output = dict(
        arg1="string value",
        arg2=42,
    )

    result = action_module_obj.get_args_from_task_vars(argument_spec, task_vars)

    assert result == expected_output



# Generated at 2022-06-21 03:20:03.729158
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.compat.tests.mock import patch, MagicMock

    mock_options = MagicMock()
    mock_action = ActionModule(MagicMock(), MagicMock(), mock_options, MagicMock(), MagicMock(), MagicMock(), MagicMock(), MagicMock())

    # Nominal case
    args = {'var1': {'default': 'test'}, 'var2': {'default': 'test'}}
    task_vars = {'var1': 'test', 'var2': 'test'}
    result = mock_action.get_args_from_task_vars(args, task_vars)
    assert result == {'var1': 'test', 'var2': 'test'}

    # No args to get from task_vars

# Generated at 2022-06-21 03:20:12.663574
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest

    from ansible.module_utils.common import AnsibleModule
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator

    spec = {"ssid" : {"required": True, "type": 'str'},
            "vlan" : {"type" : 'int', "default" :1},
            "encryption_protocol" : {"required": True, "type": "str", "choices" : [ "WPA2-AES", "WEP"]}
            }

    data = {"ssid": "test", "encryption_protocol": "WPA2-AES"}
    # valid run

    validator = ArgumentSpecValidator(spec)
    validation_result = validator.validate(data)


# Generated at 2022-06-21 03:20:13.170626
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:20:23.130232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()


# Generated at 2022-06-21 03:20:32.134155
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Unit test for method get_args_from_task_vars of class ActionModule.
    '''
    action_module = ActionModule()

    # Positive tests
    # Test that it pulls args from provided task vars
    args = action_module.get_args_from_task_vars(
        {'arg1': {'type': 'str'}, 'arg2': {'type': 'str'}},
        {'arg1': 'first_arg', 'arg2': 'second_arg'},
    )
    assert (args == {'arg1': 'first_arg', 'arg2': 'second_arg'})

    # Test that it pulls args from provided task vars and un-templates them

# Generated at 2022-06-21 03:20:34.357612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES is False
    assert module._task.action == 'validate_argument_spec'


# Generated at 2022-06-21 03:20:43.399486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up modules as a Quarantine test so that plugins are loaded and we can
    # use the validate_argument_spec action module.
    # This is needed to enable the load_plugins function.
    from ansible.plugins import module_loader
    module_loader.load_plugins()
    # This is needed to enable the register_run_as_root_temporary_path
    # function.
    from ansible.module_utils.basic import AnsibleModule, get_exception
    # This is needed to enable the action module
    from ansible.executor.task_result import TaskResult
    # This is needed to enable the ansible action module
    from ansible.executor.task_queue_manager import TaskQueueManager
    # Needed for the ActionBase class
    from ansible.plugins.action import ActionBase
    # Needed for Quarantine