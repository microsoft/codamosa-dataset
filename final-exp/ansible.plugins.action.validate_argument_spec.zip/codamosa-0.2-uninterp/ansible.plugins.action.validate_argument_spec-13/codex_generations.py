

# Generated at 2022-06-17 10:04:47.258978
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-17 10:04:48.534756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:04:50.207861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:04:59.115230
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_string
    from ansible.module_utils.common.validation import check_type_dict_of_strings
    from ansible.module_utils.common.validation import check_type_dict_of_lists
    from ansible.module_utils.common.validation import check_type_dict_of_dicts

# Generated at 2022-06-17 10:05:06.631163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''

# Generated at 2022-06-17 10:05:16.657439
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.common.validation import check_type_int
    from ansible.module_utils.common.validation import check_type_float
    from ansible.module_utils.common.validation import check_type_path
    from ansible.module_utils.common.validation import check_type_raw
    from ansible.module_utils.common.validation import check_type_set
   

# Generated at 2022-06-17 10:05:18.313831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:05:26.236441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module = ActionModule(
        task=dict(
            args=dict(
                argument_spec=dict(
                    name=dict(type='str'),
                    age=dict(type='int')
                ),
                provided_arguments=dict(
                    name='John',
                    age=20
                )
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-17 10:05:28.137187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 10:05:30.047539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:05:41.880696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module = ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-17 10:05:43.206294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:05:44.650597
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:05:52.228057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_int
    from ansible.module_utils.common.validation import check_type_float
    from ansible.module_utils.common.validation import check_type_path
    from ansible.module_utils.common.validation import check_type_raw
    from ansible.module_utils.common.validation import check_type_jsonarg


# Generated at 2022-06-17 10:06:01.593856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no argument_spec
    action_module = ActionModule()
    action_module._task = {'args': {}}
    try:
        action_module.run()
    except AnsibleError as e:
        assert e.message == '"argument_spec" arg is required in args: {}'

    # Test with argument_spec not dict
    action_module = ActionModule()
    action_module._task = {'args': {'argument_spec': 'not a dict'}}
    try:
        action_module.run()
    except AnsibleError as e:
        assert e.message == 'Incorrect type for argument_spec, expected dict and got <type \'str\'>'

    # Test with provided_arguments not dict
    action_module = ActionModule()

# Generated at 2022-06-17 10:06:02.713955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 10:06:13.432270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of class Task
    task = Task()

    # Set the attributes of task
    task.args = {
        'argument_spec': {
            'name': {
                'type': 'str'
            },
            'state': {
                'type': 'str',
                'default': 'present',
                'choices': ['present', 'absent']
            }
        },
        'provided_arguments': {
            'name': 'test',
            'state': 'present'
        }
    }

    # Set the attributes of ansible_module
   

# Generated at 2022-06-17 10:06:23.574290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of class Task
    task = Task()

    # Set the attributes of the class Task
    task.args = {'argument_spec': {'name': {'type': 'str'}, 'state': {'type': 'str', 'choices': ['present', 'absent']}}, 'provided_arguments': {'name': 'test', 'state': 'present'}}

    # Set the attributes of the class ActionModule
    action_module._task = task
    action_module._templar = Templar()

    # Set the attributes of the class AnsibleModule
    ansible

# Generated at 2022-06-17 10:06:33.921886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {
        'argument_spec': {
            'test_arg': {
                'type': 'bool'
            }
        },
        'provided_arguments': {
            'test_arg': 'true'
        }
    }

    # Create a mock task_vars
    task_vars = {}

    # Create a mock templar
    templar = mock.Mock()
    templar.template.return_value = {
        'test_arg': 'true'
    }

    # Create a mock action_base
    action_base = mock.Mock()

# Generated at 2022-06-17 10:06:43.941175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.module_utils.common.validation import check_type_dict, check_type_list, check_type_str
    from ansible.module_utils.common.validation import check_type_bool, check_type_int, check_type_float
    from ansible.module_utils.common.validation import check_type_jsonarg, check_type_raw, check_type_path
    from ansible.module_utils.common.validation import check_type_file
    from ansible.module_utils.common.validation import check_type_file_or_url
    from ansible.module_utils.common.validation import check_type_ip_address
    from ansible.module_utils.common.validation import check_type_

# Generated at 2022-06-17 10:07:00.061999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create a mock task
    task = MockTask()
    task.args = {
        'argument_spec': {
            'test_arg': {
                'type': 'str',
                'required': True,
                'choices': ['a', 'b', 'c']
            }
        },
        'provided_arguments': {
            'test_arg': 'a'
        }
    }

    # Create a mock task_vars
    task_vars = {
        'test_arg': 'a'
    }

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Run the method under test


# Generated at 2022-06-17 10:07:01.912537
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 10:07:04.201137
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:07:06.484946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that the constructor of ActionModule class works as expected
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:07:15.145717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'argument_spec': {'name': {'type': 'str', 'required': True}},
                 'provided_arguments': {'name': 'test'}}

    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task
    action_module._templar = MockTemplar()

    # Call the run method
    result = action_module.run()

    # Assert that the result is correct
    assert result['changed'] is False
    assert result['msg'] == 'The arg spec validation passed'


# Generated at 2022-06-17 10:07:23.848766
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for method get_args_from_task_vars of class ActionModule
    '''
    # Create a mock object of class ActionModule
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object of class AnsibleModule
    ansible_module_obj = AnsibleModule(argument_spec=dict())

    # Create a mock object of class AnsibleModule
    ansible_module_obj.params = dict()

    # Create a mock object of class AnsibleModule
    ansible_module_obj.params['argument_spec'] = dict()

    # Create a mock object of class AnsibleModule

# Generated at 2022-06-17 10:07:28.786052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, None, None, None, None)
    assert action_module.TRANSFERS_FILES == False


# Generated at 2022-06-17 10:07:36.482788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for method run of class ActionModule '''
    # pylint: disable=protected-access
    action_module = ActionModule()
    action_module._task = MockTask()
    action_module._task.args = {
        'argument_spec': {
            'test_arg': {'type': 'str'},
            'test_arg_2': {'type': 'str'}
        },
        'provided_arguments': {
            'test_arg': 'test_value',
            'test_arg_2': 'test_value_2'
        }
    }
    action_module._templar = MockTemplar()
    result = action_module.run(None, None)
    assert result['changed'] is False
    assert result['msg'] == 'The arg spec validation passed'

# Generated at 2022-06-17 10:07:48.238883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import action_loader
    from ansible.utils.display import Display
    import json
    import os

    display = Display()
    loader = DataLoader()

# Generated at 2022-06-17 10:07:55.467456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module = ActionModule(
        task=dict(
            args=dict(
                argument_spec=dict(
                    name=dict(type='str'),
                    age=dict(type='int')
                ),
                provided_arguments=dict(
                    name='John',
                    age=30
                )
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-17 10:08:11.837654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-17 10:08:23.515957
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils.common.arg_spec.ArgumentSpecValidator class
    class MockArgumentSpecValidator:
        def __init__(self, argument_spec_data):
            self.argument_spec_data = argument_spec_data

        def validate(self, provided_arguments):
            # Create a mock object for the module_utils.common.arg_spec.ValidationResult class
            class MockValidationResult:
                def __init__(self):
                    self.error_messages = []

            validation_result = MockValidationResult()
            if self.argument_spec_data == 'invalid':
                validation_result.error_messages.append('Invalid argument_spec')
            return validation_result

    # Create a mock object for the module_utils.common.arg_spec.ArgumentSpecValid

# Generated at 2022-06-17 10:08:29.484553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no argument_spec
    action_module = ActionModule(dict(), dict())
    action_module._task.args = dict()
    try:
        action_module.run()
        assert False
    except AnsibleError as e:
        assert e.message == '"argument_spec" arg is required in args: {}'

    # Test with incorrect type for argument_spec
    action_module = ActionModule(dict(), dict())
    action_module._task.args = dict(argument_spec='foo')
    try:
        action_module.run()
        assert False
    except AnsibleError as e:
        assert e.message == 'Incorrect type for argument_spec, expected dict and got <class \'str\'>'

    # Test with incorrect type for provided_arguments
    action_module = ActionModule(dict(), dict())


# Generated at 2022-06-17 10:08:36.618232
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_int
    from ansible.module_utils.common.validation import check_type_float
    from ansible.module_utils.common.validation import check_type_path
    from ansible.module_utils.common.validation import check_type_jsonarg
    from ansible.module_utils.common.validation import check_type_raw


# Generated at 2022-06-17 10:08:45.538044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock task
    task = MockTask()

    # Set the task to the action module
    action_module._task = task

    # Create a mock task_vars
    task_vars = dict()

    # Set the task_vars to the action module
    action_module._task_vars = task_vars

    # Create a mock templar
    templar = MockTemplar()

    # Set the templar to the action module
    action_module._templar = templar

    # Create a mock argument_spec
    argument_spec = dict()

    # Set the argument_spec to the task

# Generated at 2022-06-17 10:08:56.121044
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    action_module = ActionModule()
    action_module._task.args = {'argument_spec': {'name': {'type': 'str'}, 'age': {'type': 'int'}}, 'provided_arguments': {'name': 'Ansible', 'age': '10'}}
    action_module._task.args['validate_args_context'] = {'role': 'test_role', 'entry_point': 'main'}
    action_module._templar = None
    action_module._loader = None
    action_module._connection = None
    action_module._play_context = None
    action_module._shared_loader_obj = None
    action_module._task_vars = None
    action_module._tmp = None

# Generated at 2022-06-17 10:09:05.664924
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module = ActionModule(
        task=dict(
            args=dict(
                argument_spec=dict(
                    arg1=dict(type='str'),
                    arg2=dict(type='int')
                ),
                provided_arguments=dict(
                    arg1='value1',
                    arg2=2
                )
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None


# Generated at 2022-06-17 10:09:08.162293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 10:09:13.907495
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 10:09:18.434293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create an instance of class ActionModule
    action_module_instance = ActionModule()

    # Create a mock of class ActionBase
    action_base_instance = ActionBase()

    # Set the attributes of action_base_instance
    action_base_instance.noop_on_check = False
    action_base_instance.always_run = False
    action_base_instance.connection = None
    action_base_instance.remote_user = None
    action_base_instance.remote_pass = None
    action_base_instance.remote_port = None
    action_base_instance.private_key_file = None
    action_base_instance.become = False
    action_base_instance.become_method = None
    action_base_instance

# Generated at 2022-06-17 10:09:54.947690
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 10:09:56.682014
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:09:59.401266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:10:06.074276
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class ActionBase
    action_base_mock = MagicMock()

    # Set the return value of method run of class ActionBase
    action_base_mock.run.return_value = {'failed': False, 'msg': 'The arg spec validation passed'}

    # Set the return value of method run of class ActionModule
    action_module.run = action_base_mock.run

    # Create a mock of class AnsibleModule
    ansible_module_mock = MagicMock()

    # Create a mock of class AnsibleModule

# Generated at 2022-06-17 10:10:15.405051
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 10:10:22.944395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no argument_spec
    action_module = ActionModule(dict(), dict())
    action_module._task = dict()
    action_module._task['args'] = dict()
    action_module._task['args']['argument_spec'] = None
    action_module._task['args']['provided_arguments'] = None
    action_module._task['args']['validate_args_context'] = None
    action_module._templar = None
    try:
        action_module.run(None, None)
        assert False, 'AnsibleError was not raised'
    except AnsibleError as e:
        assert '"argument_spec" arg is required in args: {}' in str(e)

    # Test with no provided_arguments
    action_module = ActionModule(dict(), dict())
   

# Generated at 2022-06-17 10:10:33.512277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.module_utils.common.validation import check_type_dict, check_type_list, check_type_str
    from ansible.module_utils.common.validation import check_type_bool, check_type_int
    from ansible.module_utils.common.validation import check_type_float, check_type_jsonarg
    from ansible.module_utils.common.validation import check_type_path
    from ansible.module_utils.common.validation import check_type_raw
    from ansible.module_utils.common.validation import check_type_set
    from ansible.module_utils.common.validation import check_type_tuple
    from ansible.module_utils.common.validation import check

# Generated at 2022-06-17 10:10:39.004229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.arg_spec import ArgumentSpec
    from ansible.module_utils.common.validation import check_type_dict, check_type_list, check_type_str, check_type_bool
    from ansible.module_utils.common.validation import check_type_dict_of_str, check_type_list_of_str, check_type_list_of_dict
    from ansible.module_utils.common.validation import check_type_dict_of_dict
    from ansible.module_utils.common.validation import check_type_dict_of_dict_of_str
    from ansible.module_utils.common.validation import check_type_dict_of_dict_of_dict
    from ansible.module_utils.common.validation import check_type_dict

# Generated at 2022-06-17 10:10:40.517898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 10:10:48.131283
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        args=dict(
            argument_spec=dict(
                test_arg=dict(type='str'),
                test_arg2=dict(type='str')
            ),
            provided_arguments=dict(
                test_arg='test_value',
                test_arg2='test_value2'
            )
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict(
        changed=False,
        msg='The arg spec validation passed'
    )

    # Create a mock ActionModule
    action_module = ActionModule(task, tmp, task_vars)

    # Call method run of class ActionModule

# Generated at 2022-06-17 10:12:01.375024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class ActionBase
    action_base_mock = MagicMock()

    # Set attributes of action_base_mock
    action_base_mock.run = MagicMock(return_value={'changed': False, 'msg': 'The arg spec validation passed'})

    # Set attributes of action_module
    action_module._task = MagicMock()

# Generated at 2022-06-17 10:12:10.519058
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for method get_args_from_task_vars of class ActionModule
    '''
    action_module = ActionModule()
    argument_spec = {'arg1': {'type': 'str'}, 'arg2': {'type': 'str'}}
    task_vars = {'arg1': '{{ var1 }}', 'arg2': '{{ var2 }}', 'var1': 'value1', 'var2': 'value2'}
    args = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert args == {'arg1': 'value1', 'arg2': 'value2'}

# Generated at 2022-06-17 10:12:20.440944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock action module
    action_module = ActionModule(task, task_vars)

    # Create a mock argument spec
    argument_spec = dict()

    # Create a mock provided arguments
    provided_arguments = dict()

    # Create a mock result
    result = dict()

    # Create a mock validation result
    validation_result = MockValidationResult()

    # Create a mock validator
    validator = MockValidator()

    # Create a mock args from vars
    args_from_vars = dict()

    # Create a mock error messages
    error_messages = list()

    # Create a mock error message
    error_message = 'error message'

    # Create a

# Generated at 2022-06-17 10:12:21.738006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict())

# Generated at 2022-06-17 10:12:34.189960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Set the attributes of the class AnsibleModule
    ansible_module.params = {'argument_spec': {'name': {'type': 'str'}}, 'provided_arguments': {'name': 'test'}}

    # Set the attributes of the class TaskExecutor
    task_executor.task = ansible_module

    # Set the attributes of the class ActionModule
    action_module._task = task_executor

    # Set the attributes of the class AnsibleModule
    ansible

# Generated at 2022-06-17 10:12:42.993908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a dict of arguments required for method run
    tmp = None
    task_vars = dict()

    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)

    # Assert the result
    assert result['failed'] is True
    assert result['msg'] == '"argument_spec" arg is required in args: {}'

# Generated at 2022-06-17 10:12:44.205865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 10:12:45.318041
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-17 10:12:55.658354
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 10:13:01.160538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                argument_spec=dict(
                    test_arg=dict(type='str'),
                ),
                provided_arguments=dict(
                    test_arg='test_value',
                ),
            ),
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict(),
    )
    assert action_module is not None
