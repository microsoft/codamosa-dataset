

# Generated at 2022-06-23 08:50:00.454105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = dict()

    # Test with no argument_spec
    try:
        module.run(None, None)
        assert False, "Failed to raise AnsibleError when there is no argument_spec in task_args"
    except AnsibleError:
        pass

    # Test with invalid argument_spec type
    module._task.args['argument_spec'] = 'Hello world!'
    try:
        module.run(None, None)
        assert False, "Failed to raise AnsibleError when argument_spec is not a dict"
    except AnsibleError:
        pass

    # Test with invalid provided_arguments type
    module._task.args['argument_spec'] = dict()
    module._task.args['provided_arguments'] = ['hello world!']

# Generated at 2022-06-23 08:50:06.939271
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # Instantiate fixture
    class DummyTemplate:
        def template(self, data):
            return {'deployment_server': 'deployment_server', 'ca_cert': 'ca_cert'}
    fixture = ActionModule(
        {'name': 'test_ActionModule_get_args_from_task_vars'},
        DummyTemplate()
    )
    # Call method under test
    task_vars = {'deployment_server': '{{ deployment_server_var }}', 'ca_cert': '{{ ca_cert_var }}'}
    result = fixture.get_args_from_task_vars({'deployment_server': {}, 'ca_cert': {}}, task_vars)
    # Assertions

# Generated at 2022-06-23 08:50:17.051760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.network.common.validators import validate_argument_spec
    import mock
    import os
    import ast

    # This is the 'validate_args' module we are testing
    module_path_to_test = os.path.join(os.path.dirname(__file__), '..', '..', 'library', 'validate_args.py')
    if PY3:
        with open(module_path_to_test, encoding='utf-8') as f:
            module = f.read()
    else:
        with open(module_path_to_test) as f:
            module = f.read()

    module_ast = ast.parse(module, module_path_to_test)
    validate_module_

# Generated at 2022-06-23 08:50:25.302226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import yaml

    # initialize module with yaml doc that contains the arg_spec

# Generated at 2022-06-23 08:50:31.159524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule,
    if validation passes, changed is False and there is no msg'''

    from ansible.plugins.action.validate_argument_spec import ActionModule
    module = ActionModule(None, None, None)
    result = dict()
    result['failed'] = False
    result['validate_args_context'] = {'role': 'my_role'}
    result['changed'] = False
    result['msg'] = 'The arg spec validation passed'

    assert result == module.run()

# Generated at 2022-06-23 08:50:37.328719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest.mock
    mock_ansible_module = unittest.mock.Mock()
    mock_ansible_module.check_mode = False
    mock_ansible_module.params = {}
    mock_ansible_module.tmpdir = None

    test_data = {'something': 'value'}

    with unittest.mock.patch("ansible_collections.ansible.netcommon.plugins.modules.validate_argument_spec.AnsibleModule") as mock_module:
        mock_module.return_value = mock_ansible_module
        action_module = ActionModule(mock_module)


# Generated at 2022-06-23 08:50:47.719094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    This test will validate the run method of class ActionModule to
    validate the argument spec and return the result
    '''

    # get the module data for the action module
    module_data = ActionModule._load_action_plugin('validate_argument_spec')

    # create action module object using the module data
    action_module_obj = module_data.ActionModule(
        task=dict(),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # create task vars, argument spec and provided arguments
    task_vars = dict()
    argument_spec = {
        'valid_argument': {'type': 'str'}
    }

    # when provided arguments is empty
    provided_arguments = dict()


# Generated at 2022-06-23 08:50:50.573404
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Init vars
    tmp = None
    task_vars = None

    # Init class
    obj = ActionModule()

    # Init mocks
    # Empty
    obj._task = Empty()

    # Init class with mocks
    obj = ActionModule(tmp, task_vars)



# Generated at 2022-06-23 08:50:54.307509
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, {})



# Generated at 2022-06-23 08:51:00.182613
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module_object = ActionModule()
    argument_spec = {"name": {"type": "str", "default": "hello"}}
    task_vars = {"name": "world"}
    actual_result = action_module_object.get_args_from_task_vars(argument_spec, task_vars)
    expected_result = {"name": "world"}
    assert(actual_result == expected_result)

# Generated at 2022-06-23 08:51:03.631374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''test instantiation of ActionModule class'''
    action = ActionModule()

    assert type(action) is ActionModule

# Generated at 2022-06-23 08:51:14.174836
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import combine_vars
    import sys

    # for python2
    if sys.version_info[0] < 3:
        string_types = basestring,

    my_task_vars = dict(foo=dict(bar='valid'), baz=dict(banana='valid'),
                        variable_from_templates=dict(a_variable="{{ hostvars['localhost']['value_from_localhost'] }}"))

    # Some tests require a connection to host localhost, so we need to mock that
    # it exists and has some hostvars.
    # host localhost is added by connection plugin, so we need to create a mock
    # connection plugin

# Generated at 2022-06-23 08:51:19.192520
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    act = ActionModule(None, {})

    argument_spec = {'argument_spec': {'tcp_ports': {'type': 'list', 'required': True}},
                     'provided_arguments': {'tcp_ports': [22, '80', '443', '']}}
    result = act.run(task_vars={}, tmp='/tmp', ds=argument_spec)
    assert not result['failed']

    argument_spec = {'argument_spec': {'tcp_ports': {'type': 'list', 'required': True}},
                     'provided_arguments': {'tcp_ports': ['22', '80', '443']}}
    result = act.run(task_vars={}, tmp='/tmp', ds=argument_spec)
    assert result['failed']


# Generated at 2022-06-23 08:51:30.374911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock setup
    class MockTask:
        def __init__(self):
            self.args = {'argument_spec': {'arg': {'type': 'list', 'elements': 'str'}}, 'provided_arguments': {'arg': ['foo']}}
    task = MockTask()

    class MockTemplar:
        def __init__(self):
            pass

        def template(self, template):
            return template

    class MockActionBase(ActionModule):
        def __init__(self):
            self._task = task
            self._templar = MockTemplar()

    # Test action execution
    action_module_obj = MockActionBase()
    result = action_module_obj.run(tmp='', task_vars={})
    print(result)

# Generated at 2022-06-23 08:51:40.783492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionBase

    arg_spec = {
        "name": {"required": True, "type": str},
        "acls": {"required": True, "type": list},
        "new": {"default": False, "type": bool},
        "purge": {"default": False, "type": bool},
    }

    provided_arguments = {
        "name": "somename",
        "acls": ["one","two","three"],
        "new": False,
        "purge": True,
        "other_key": "other",
    }

    module_args = {
        "argument_spec": arg_spec,
        "provided_arguments": provided_arguments,
    }


# Generated at 2022-06-23 08:51:47.797896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import uuid
    # template is an instance of the class ActionModule
    template = ActionModule()
    # No changes in argument_spec
    assert template._task.args.get('validate_args_context') is None
    # The data type of argument spec is a dict
    assert isinstance(template._task.args.get('argument_spec'), dict)
    # The data type of args is a dict
    assert isinstance(template._task.args.get('provided_arguments'), dict)
    # Test that the validate_args_context is not None
    template_return = template.run()
    assert template_return['validate_args_context'] is not None
    # Try using provided_arguments and checks if the type of the provided arguments is dict

# Generated at 2022-06-23 08:51:49.437406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = ActionModule()

# Generated at 2022-06-23 08:51:57.109183
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Validates method get_args_from_task_vars from class ActionModule '''

    #
    # Create legal test data
    #
    task_vars = {
        'arg_string': 'a_value',
        'arg_int': 1
    }
    argument_spec = {
        'arg_string': {'type': 'str'},
        'arg_int': {'type': 'int'},
    }

    #
    # Create test object
    #
    action_module = ActionModule(None, None, {}, None, None, None)

    result = action_module.get_args_from_task_vars(argument_spec, task_vars)

    assert result['arg_string'] == 'a_value'
    assert result['arg_int'] == 1

# Generated at 2022-06-23 08:52:01.292121
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ansible_task_vars = dict()
    ansible_task_vars['arg1'] = 'arg1_value'
    ansible_task_vars['arg2'] = '{{ include_arg2 }}'
    ansible_task_vars['include_arg2'] = '{{ include_arg2 | default(arg2_value) }}'

    test_action_module = ActionModule()
    returned_value = test_action_module.get_args_from_task_vars(
        {'arg1': {'type': 'str', 'required': True},
         'arg2': {'type': 'str', 'required': True}}, ansible_task_vars)

    assert returned_value['arg1'] == "arg1_value"
    assert returned_value['arg2'] == "arg2_value"

# Generated at 2022-06-23 08:52:12.681578
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:52:19.825568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None, None, None, None, None)
    result = action_module.run(tmp=None, task_vars=test_task_vars1)
    assert result['changed'] == False
    assert result['msg'] == 'The arg spec validation passed'

    result = action_module.run(tmp=None, task_vars=test_task_vars2)
    assert result['failed'] == True
    assert result['msg'] == 'Validation of arguments failed:\nname must be a string.'

    result = action_module.run(tmp=None, task_vars=test_task_vars3)
    assert result['failed'] == True
    assert result['msg'] == 'Validation of arguments failed:\nvalidation failure for name'


# Generated at 2022-06-23 08:52:27.676244
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    import ansible.utils.vars as vars
    action_module = ActionModule()
    argument_spec = {
        "test1": {
            "type": "str"
        },
        "test2": {
            "type": "str"
        }
    }
    task_vars={"test1":"value1"}
    # test module with transfer_files  set to False
    assert action_module._transfer_files == False
    result = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert result["test1"] == "value1" and result["test2"] == ""

# Generated at 2022-06-23 08:52:39.153807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    action_module = ActionModule(None, None)
    task_vars = {
        'local_action': {
            'argument_spec': {
                'arg1': {
                    'required': True
                },
                'arg2': {
                    'required': False
                }
            },
            'provided_arguments': {
                'arg1': '{{ arg1 }}'
            }
        },
        'arg1': 'banana'
    }
    result = action_module.run(None, task_vars)
    assert result['failed'] is False
    assert result['changed'] is False
    assert result['msg'] == 'The arg spec validation passed'
    assert result['validate_args_context'] == {'name': 'action'}
   

# Generated at 2022-06-23 08:52:47.906548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    validate_args_context = 'validate_args_context'
    argument_spec = {'param1': {'type': 'list', 'required': True}}
    provided_arguments = {'param1': ['a', 'b', 'c']}

    task = MagicMock(args={'validate_args_context': validate_args_context,
                           'argument_spec': argument_spec,
                           'provided_arguments': provided_arguments})
    task_vars = {}

    setattr(action, '_task', task)

    result = action.run(None, task_vars)
    assert result['changed'] == False
    assert result['msg'] == 'The arg spec validation passed'

    provided_arguments = {'param1': 'a'}
    task = MagicM

# Generated at 2022-06-23 08:52:48.925295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    foo = ActionModule()

    assert foo is not None

# Generated at 2022-06-23 08:52:50.312470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:52:54.244304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test for the constructor of class ActionModule and its functions.
    :return: None
    """
    from ansible.plugins.action.validate_arg_spec import ActionModule
    ActionModule("test_action", {"argument_spec": [1, 2, 3]}, None)



# Generated at 2022-06-23 08:52:55.294199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:53:05.217152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    role_entry_point_args = {'test_arg': {'type': 'int'}}
    new_task_args = {'argument_spec': role_entry_point_args}
    # test data
    provided_args = {'test_arg': 2}
    task = type('TestTask', (object,), {'args': {'argument_spec': role_entry_point_args, 'provided_arguments': provided_args}})
    play = type('TestPlay', (object,), {'name': 'play_name'})
    templar = type('TestTemplar', (object,), {'template': lambda x: x})
    connection = type('TestConnection', (object,), {'name': 'test_connection'})
    test_action_module = ActionModule(task, connection, templar, play)

# Generated at 2022-06-23 08:53:06.017518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-23 08:53:07.952556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule.__init__()
    except Exception as e:
        raise AssertionError("Unexpected exception thrown: " + type(e).__name__)

# Generated at 2022-06-23 08:53:15.797323
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    mock_self = ActionModule()
    mock_self._templar = None
    mock_argument_spec = {"first_name": {"type": "str"}, "last_name": {"type": "str"}}
    mock_task_vars = {"first_name": "Joe", "last_name": "Baggs", "age": 45}
    mock_self.get_args_from_task_vars(mock_argument_spec, mock_task_vars)


# Generated at 2022-06-23 08:53:23.896752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.basic import AnsibleModule

    dict = builtins.__dict__

    # simple mock to replace the one that would be imported by the module
    class MockVarsModule():
        '''
        A simple mock object to replace the real vars module.
        '''
        def combine_vars(self, a, b):
            return dict(list(a.items()) + list(b.items()))

    def fake_import(name, *args):
        if name == 'ansible.module_utils.vars':
            return MockVarsModule()
        else:
            return dict[name]


# Generated at 2022-06-23 08:53:36.273977
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import iteritems
    from ansible.module_utils._text import to_text

    # Construct action module object
    import sys
    import os
    import mock

    # The strategies for the mock are to load some of the files and to return them.
    # The files get loaded in the class ActionBase of module ansible/plugins/action/__init__.py
    # The class ActionModule inherits from class ActionBase.
    # The file module_utils/connection/__init__.py gets loaded as part of file module_utils/connection/network_cli.py
    mock_module_utils_connection = mock.MagicMock()

    mock

# Generated at 2022-06-23 08:53:43.948617
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.validate_argument_spec


# Generated at 2022-06-23 08:53:55.092800
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule()
    task_vars = {
        "name": "test",
        "s": "a"
    }
    # test successful case
    argument_spec = {
        "name": {
            "type": "str",
            "required": True
        },
        "state": {
            "type": "str",
            "choices": ["present", "absent", "local_purge"],
            "default": "present"
        }
    }
    expected = {
        "name": "test",
        "state": "present"
    }
    actual = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert actual == expected

    # test failure case (name is missing in task_vars)

# Generated at 2022-06-23 08:54:03.210683
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    module = ActionModule(None, None)

    # Validate arguments from task_vars when set
    data = {'argument_spec': {'arg_1': {}}, 'argument_spec_data': {'arg_1': {}}}
    task_vars = {'arg_1': 'arg_1_value'}
    assert module.get_args_from_task_vars(data['argument_spec'], task_vars) == {'arg_1': 'arg_1_value'}

    # Validate arguments from task_vars when not set
    data = {'argument_spec': {'arg_1': {}}, 'argument_spec_data': {'arg_1': {}}}
    task_vars = {}

# Generated at 2022-06-23 08:54:16.400691
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg1 = {'argument_spec': {'attrs': {'required': False, 'type': 'dict', 'options': {'name': {'required': True, 'type': 'str', 'choices': None}}}}}
    arg2 = {}
    act = ActionModule()
    res = act.run(tmp=None, task_vars=arg1)
    assert 'msg' in res, "Failed to get msg in result"
    assert 'argument_spec_data' in res, "Failed to get argument_spec_data in result"
    assert 'changed' not in res, "Is getting changed in result"
    assert 'argument_errors' in res, "Failed to get argument_errors in result"
    assert 'validate_args_context' in res, "Failed to get validate_args_context in result"

# Generated at 2022-06-23 08:54:28.199103
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ## Arrange ##
    # Create a mock for class ActionModule
    action_module_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None,
                                   shared_loader_obj=None)

    argument_spec = dict(
        ip_addr=dict(type='str'),
        port=dict(type='int'),
        ports=dict(type='list'),
        ip_addrs=dict(type='list'),
    )

    task_vars = dict(ip_addr='1.2.3.4', port=1234, ports=[5678, 9012], ip_addrs=[])

    ## Act ##
    result = action_module_instance.get_args_from_task_vars(argument_spec, task_vars)

    ## Assert ##


# Generated at 2022-06-23 08:54:31.619303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test for `run` method of class ActionModule '''

    # Method `run` is not tested here because it is checked
    # indirectly in test_roles_validate_role_test_args.py

# Generated at 2022-06-23 08:54:42.217728
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    nova_conf_path = '/etc/nova/nova.conf'

# Generated at 2022-06-23 08:54:50.014109
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    module = ActionModule()
    result = module.get_args_from_task_vars({'a': {'type': 'str'}}, {'a': '{{ b }}'})
    assert(result == {'a': '{{ b }}'})


# Generated at 2022-06-23 08:54:52.174958
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
        assert True
    except:
        assert False


# Generated at 2022-06-23 08:55:00.663874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Unit test '''
    import copy

    data = {'module_name': 'validate_argument_spec',
            'args': {'argument_spec': {'src': {'type': 'path'}, 'dest': {'type': 'path'}},
                     'provided_arguments': {'src': '/home/me/myfile', 'dest': '/tmp/myfile'}},
            'defaults': {'parameter': 'value'}}

    action_module = ActionModule()
    action_module._task = copy.deepcopy(data)
    result = action_module.run(None, None)
    assert result['validate_args_context'] == {}

    # No argument_spec in args
    action_module = ActionModule()
    action_module._task = copy.deepcopy(data)
    del action

# Generated at 2022-06-23 08:55:12.298302
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    # get_args_from_task_vars should expand template variables which are
    # fetched from task_vars.
    class ActionModuleTest(ActionModule):
        def __init__(self):
            self._task = MockTask()
            self._templar = MockTemplar()

    action_module_test = ActionModuleTest()
    # Argument spec
    argument_spec = {
        'argument_spec_one': {'type': 'bool'},
        'argument_spec_two': {'type': 'list'}
    }

    # Provided dict with argument data

# Generated at 2022-06-23 08:55:22.886216
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for action_plugin.ActionModule.get_args_from_task_vars
    '''
    # Mock 'ActionModule' class
    class MockModule():
        PLUGIN_TYPE = 'action'
        args = {}

    # Mock 'ActionBase' class
    class MockActionBase(ActionModule):
        '''
        Mock 'action_plugin.ActionBase' class
        '''
        def __init__(self):
            self._task = MockModule()
            self._templar = MockTemplar()

    # Mock 'Templar' class
    class MockTemplar():
        def template(self, data):
            return data

    # Test 'get_args_from_task_vars' method

# Generated at 2022-06-23 08:55:27.923670
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import mock
    from ansible.errors import AnsibleError
    from ansible.plugins.action.validate_arguments import ActionModule
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple

    argument_spec_data = dict(
        foo=dict(type='str', required=True),
        bar=dict(type='int', required=True, aliases=['baz']),
    )

    action_module = ActionModule(dict(), dict(AA_BB_CC=None, argument_spec=argument_spec_data))

    def get_args_from_task_vars_side_effect(asd, task_vars):
        return dict(foo='foo', bar='1')

    action

# Generated at 2022-06-23 08:55:38.124729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.get_args_from_task_vars = lambda a, b: {}
    m._task = object()
    m._task.args = {}

    invalid_arg_specs = [
        # arg 'argument_spec' not in args
        {},

        # arg 'argument_spec' is not a dict
        {'argument_spec': 'a string'},

        # arg 'collections' is not a list
        {'argument_spec': {'a_key': 'a_value'}, 'collections': {'a_key': 'a_value'}},
    ]

    for invalid_arg_spec in invalid_arg_specs:
        m._task.args = invalid_arg_spec

# Generated at 2022-06-23 08:55:46.569182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # https://github.com/ansible/ansible/blob/devel/test/units/plugins/action/test_validate_argument_spec.py
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator


# Generated at 2022-06-23 08:55:59.437127
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.six.moves import StringIO

    module_output = b'''{
        "msg": "The arg spec validation passed",
        "ansible_facts": {
            "discovered_interpreter_python": "/usr/bin/python"
        },
        "_ansible_verbose_always": true,
        "changed": false
    }'''

    module_path = 'ansible.plugins.action.validate_argument_spec'
    module_name = 'validate_argument_spec'
    task_vars = {
        "validate_args_context": {
            "module_path": module_path,
            "module_args": "",
            "module_name": module_name
        }
    }


# Generated at 2022-06-23 08:56:11.136786
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for method get_args_from_task_vars of class ActionModule
    '''
    def get_test_args(test_name):
        '''
        Get the test arguments for a specific test name
        :param test_name: Name of the test
        :returns: test argument dictionary
        '''

        result = None

        if test_name == 'test_empty_arg_spec':
            result = dict(
                argument_spec=dict(),
                task_vars=dict(),
                expected_result=dict(),
            )


# Generated at 2022-06-23 08:56:16.167679
# Unit test for constructor of class ActionModule
def test_ActionModule():
    argument_spec = dict(
        argument_spec=dict(type='dict', default={}),
        provided_arguments=dict(type='dict', default={}),
    )
    action_module = ActionModule()
    action_module.set_task(argument_spec)



# Generated at 2022-06-23 08:56:23.714776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.utilities.validate_argument_spec import ActionModule
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.common.dict_transformations import recursive_diff
    action_module = ActionModule()
    spec = dict(
        one=dict(required=True, type='list'),
        two=dict(type='list'),
        three=dict(required=True, choices=['valid_choice'])
    )
    provided_args = dict(one=[1,2,3], two=[], three='valid_choice')
    result = action_module.run(task_vars=dict())
    assert result.get('failed') is True
    assert 'argument_spec' in result.get('msg')

# Generated at 2022-06-23 08:56:31.056584
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Tests the class ActionModule method get_args_from_task_vars.
    '''
    # Create an argument specification
    argument_spec = {
        'arg1': {'type': 'str'},
        'arg2': {'type': 'list'}
    }
    # Create the task variables
    task_vars = {
        'arg1': '{{ ansible_host }}',
        'arg2': ['one', 'two', 3]
    }
    # Create the object ActionModule
    am = ActionModule()
    # create the templar object
    am._templar = am._shared_loader_obj.templar
    # create the template object
    am._templar._available_variables = {'ansible_host': 'localhost'}
    args_from_vars

# Generated at 2022-06-23 08:56:32.866553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run() == None

# Generated at 2022-06-23 08:56:44.578326
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Unit tests for method get_args_from_task_vars of class ActionModule. '''

    # import the module
    from ansible.plugins.action.validate_argument_spec import ActionModule

    # create an instance of the action plugin, and set up values needed for it to run
    am = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    argument_spec = {
        'host': {'type': 'str'},
        'port': {'type': 'int'},
        'group': {'type': 'list'},
    }

# Generated at 2022-06-23 08:56:56.663091
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    task_vars = dict()
    action_module = None

    # test 1
    # returns None if argument_spec is not provided
    input_argument_spec = None
    task_vars = dict()
    result = action_module.get_args_from_task_vars(input_argument_spec, task_vars)
    assert result is None
    # test 2
    # returns None if argument_spec is empty
    input_argument_spec = dict()
    task_vars = dict()
    result = action_module.get_args_from_task_vars(input_argument_spec, task_vars)
    assert result is None
    # test 3
    # returns None if task_vars is not provided
    input_argument_spec = {'test':'test'}
    task_vars = None

# Generated at 2022-06-23 08:57:08.323284
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    def add_vars(vars):
        '''
        A mock method that adds variables to task_vars
        '''
        for k in vars:
            task_vars[k] = vars[k]

    def template(arg_spec):
        '''
        A mock method that does the templating and returns the args
        '''
        return arg_spec

    task_vars = {}
    action_module = ActionModule()
    action_module.get_args_from_task_vars = ActionModule.get_args_from_task_vars
    action_module._templar = lambda: None
    action_module._templar.template = template

# Generated at 2022-06-23 08:57:15.563399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(provided_arguments={}, argument_spec={})),
        connection=None,
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert type(action_module) == ActionModule


# Generated at 2022-06-23 08:57:27.102231
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    argument_spec={
        'arg1': {'type': 'str', 'required': True},
        'arg2': {'type': 'int', 'required': True},
        'arg3': {'type': 'bool', 'required': False},
    }

    # task vars should contain all arguments
    task_vars=dict(arg1='test', arg2=1, arg3=True)

    # The test class
    TestClass=type('TestClass', (object,), dict(run=ActionModule.run))

    # Test expected output
    assert TestClass().get_args_from_task_vars(argument_spec, task_vars) =={'arg1': 'test', 'arg2': 1, 'arg3': True}

    # task vars should not contain all arguments

# Generated at 2022-06-23 08:57:35.287027
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    argument_spec = {'test': {'type': 'str'}, 'test1': {'type': 'int'}}
    task_vars = {'test1': 1}
    action_module = ActionModule()
    action_module._templar = Templar()
    result = action_module.get_args_from_task_vars(argument_spec, task_vars)
    assert result == {'test1': 1}


# Generated at 2022-06-23 08:57:47.395663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit tests for action plugin
    '''

# Generated at 2022-06-23 08:57:48.358942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if not ActionModule.__doc__:
        raise AssertionError("No docstring provided for ActionModule")

# Generated at 2022-06-23 08:57:51.310917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:58:00.127013
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    '''
    Unit test for method get_args_from_task_vars of class ActionModule
    :return: Nothing
    '''
    module = ActionModule()
    argument_spec = {'argument_name_1': {}, 'argument_name_2': {}, 'argument_name_3': {}}
    task_vars = {'argument_name_1': 'var1', 'argument_name_2': 'var2',
                 'argument_name_4': 'var4'}
    assert module.get_args_from_task_vars(argument_spec, task_vars) == {'argument_name_1': 'var1',
                                                                        'argument_name_2': 'var2'}



# Generated at 2022-06-23 08:58:12.445658
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    m = ActionModule(None, None, None, None)

    # Test that a prompt_yes_no arg is correctly validated
    arg_spec = {'ipv4_address': {'type': 'str'}}
    task_vars = {'ipv4_address': '192.168.0.1'}
    assert m.get_args_from_task_vars(arg_spec, task_vars) == task_vars

    # Test that a non str type is correctly validated
    arg_spec = {'list_of_ipv4_address': {'type': 'list'}}
    task_vars = {'list_of_ipv4_address': ['192.168.0.1', '192.168.0.2', '192.168.0.3']}
    assert m.get_args

# Generated at 2022-06-23 08:58:18.569406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    argument_spec = {
        'foo': {'type': 'str'},
        'bar': {'type': 'str', 'required': True},
        'baz': {'type': 'str'},
        'qux': {'type': 'str', 'required': True},
    }

    provided_arguments = {
        'foo': 'some foo value',
        'bar': 'some bar value',  # required field
        'baz': 'some baz value',
    }

    provided_arguments_2 = {
        'foo': 'some foo value',
        'bar': 'some bar value',  # required field
        'qux': 'some qux value',  # required field
    }


# Generated at 2022-06-23 08:58:29.762535
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    tmplar = FakeTemplar()
    module_args = {
        'argument_spec': {
            'friendly_name': {},
            'bgp_as': {},
            'vrf': {},
            'update_source': {},
        }
    }
    task_vars = {
        'friendly_name': 'my_bgp',
        'bgp_as': 64514,
        'vrf': 'default',
        'update_source': 'Loopback0',
    }

    # This action can be called from anywhere, so pass in some info about what it is
    # validating args for so the error results make some sense

# Generated at 2022-06-23 08:58:41.277991
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given a mocked AnsibleTask
    from mock import Mock
    from ansible.module_utils.common.validation import ValidationError
    task_mock = Mock()
    task_mock.args = {'argument_spec': {'test': {}}, 'provided_arguments': {},
                      'validate_args_context': {'context': 'context', 'context_element': 'context_element'}}
    task_mock.action = 'validate_argument_spec'
    task_mock.name = 'Validate an argument specification'
    # And a ActionModule class object
    action_module = ActionModule(task=task_mock, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # When I run the action module
    res = action_

# Generated at 2022-06-23 08:58:52.310359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create variable test_AnsibleActionBase_dict
    # create variable test_AnsibleActionBase_dict
    test_AnsibleActionBase_dict = {}
    test_AnsibleActionBase_dict['foo'] = 'bar'
    # create variable test_get_args_from_task_vars
    # create variable test_get_args_from_task_vars
    test_get_args_from_task_vars = {}
    test_get_args_from_task_vars['foo'] = 'bar' 
    # create variable test_validate_argument_spec_run
    # create variable test_validate_argument_spec_run
    test_validate_argument_spec_run = {}   

# Generated at 2022-06-23 08:59:01.130680
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''
    # Test setup
    class ArgumentSpecValidator():
        '''Test class for ArgumentSpecValidator'''
        def __init__(self, arg_spec):
            '''Test class for ArgumentSpecValidator'''
            # Test setup
            self.arg_spec = arg_spec
            self.error_messages = []

        def validate(self, args):
            '''Test class for ArgumentSpecValidator'''
            # Test setup
            if len(self.arg_spec) < len(args):
                self.error_messages.append('arg_spec is less than args')
            return self

    class TestActionBase():
        '''Test class for ActionBase'''

# Generated at 2022-06-23 08:59:14.912243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create mock objects
    spec = {'argument_spec': {'argument_spec_data': {'type': 'dict'}}, 'provided_arguments': {'argument_spec_data': 'test'}}
    action_module = ActionModule()
    action_module._task.args = spec
    action_module._templar.template = lambda x: x

    # assert that an exception is thrown for an incorrect type
    try:
        action_module.run({})
        assert False
    except:
        assert True

    # assert that an exception is thrown for an incorrect type
    spec['provided_arguments'] = 'test'
    try:
        action_module.run({})
        assert False
    except:
        assert True

    # assert that an exception is thrown for missing arg_spec

# Generated at 2022-06-23 08:59:26.748975
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.module_utils.six import string_types
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # Test for empty argument_spec
    ansible_variable = dict()
    argument_spec = dict()
    action_module = ActionModule()
    action_module._templar = Templar(play_context=PlayContext())
    args = action_module.get_args_from_task_vars(argument_spec=argument_spec, task_vars=ansible_variable)
    assert args == dict()

    # Test for argument_spec dict with non-template variables
    ansible_variable = dict()
    argument_spec = dict(argument1=dict(type=int, default=10))
    action_module = ActionModule()

# Generated at 2022-06-23 08:59:38.444043
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.utils.vars import combine_vars

    # imports for unit testing
    import os
    import six
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.utils.vars import combine_vars

    # prepare testing data
    testdata_arg_spec = {'hostname': {'type': 'str'},
                         'username': {'type': 'str'},
                         'password': {'type': 'str'},
                         'port': {'type': 'int'}}

    testdata_task_vars = {"hostname": "{{ username }}@{{ hostname }}", "username": "test", "password": "test", "port": 22}

# Generated at 2022-06-23 08:59:42.423364
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    ''' Unit test for `get_args_from_task_vars` method '''
    action_module = ActionModule(
        task=dict(
            args=dict(
                argument_spec=dict(
                    a=dict(type='bool'),
                    b=dict(type='list')
                ),
                provided_arguments=dict(
                    a=bool('true'),
                    b=list()
                )
            ),
            action=dict(module='test_module', args=dict())
        )
    )

    task_vars = dict(a=bool('false'),
                     b=list(['123', '456']))

    args = action_module.get_args_from_task_vars(action_module._task.args.get('argument_spec'),
                                                 task_vars)


# Generated at 2022-06-23 08:59:50.457756
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    task_vars = dict()
    my_action = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test a regular variable
    # Setup
    argument_spec = {'name': {'type': 'str'}}
    task_vars['my_var'] = 'my_value'

    expected_result = {'name': 'my_value'}

    # Run test
    result = my_action.get_args_from_task_vars(argument_spec, task_vars)

    # Assertions
    assert expected_result == result

    # Test the variable is expanded
    # Setup
    task_vars = dict()
    task_vars['my_var'] = '{{ my_value }}'
