

# Generated at 2022-06-11 12:49:54.861004
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:50:01.707418
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test the constructor of class ActionModule
    '''
    argument_spec = {
        'argument_spec': {'required': True, 'type': 'dict'},
        'provided_arguments': {'required': True, 'type': 'dict'},

        # Optional fields.
        'validate_args_context': {'type': 'dict'},
    }
    action_module = ActionModule(load_params=argument_spec,
                                 templar=None,
                                 loader=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 12:50:02.242252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 2

# Generated at 2022-06-11 12:50:11.095018
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():

    from ansible.module_utils.six import iteritems
    from ansible.module_utils.ansible_collections.misc.not_a_real_collection.plugins.modules import validate_argument_spec

    source_dict = dict(b='{{a}}', f='{{e}}', h='{{g}}')
    templated_dict = dict(b='1', f='5')
    provided_dict = dict(a='1', e='5')
    expected_dict = dict(a='1', e='5')

    results = validate_argument_spec.ActionModule.get_args_from_task_vars(source_dict, provided_dict)
    assert(len(results) == len(expected_dict))
    for key, value in iteritems(results):
        assert(value == expected_dict[key])

# Generated at 2022-06-11 12:50:20.699178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ######################################
    module = ActionModule()
    action_base = ActionBase()
    module._templar = action_base._templar

    action_base.connection = {} # mock it since we don't care about this for this test
    action_base._task.args = {'argument_spec': {'a': {'type': 'str'}, 'b': {'type': 'dict'}},
                              'provided_arguments': {'a': 1, 'b': 'foo'}}
    module._task = action_base._task
    module._tmpdir = "/tmp"
    result = module.run()
    assert result['failed']

# Generated at 2022-06-11 12:50:21.247088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:50:30.288833
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    ArgumentSpecValidator = get_import('ansible.module_utils.common.validation.validators.ArgumentSpecValidator')
    system_vars = {}
    connection = None
    # Test with empty args
    args = {}
    module = ''
    inject = {}
    task_vars = {}
    tmp = None
    _task = mock_task(module, args, inject, task_vars)
    test_obj = ActionModule(_task, connection, system_vars=system_vars)
    with pytest.raises(AnsibleError) as excinfo:
        test_obj.run()
    assert 'both "argument_spec" and "provided_arguments" args are required in args: {}' in str(excinfo.value)

    # Test with empty provided_arguments

# Generated at 2022-06-11 12:50:38.903435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    association_spec = {
        'argument_spec': {'state': {'choices': ['present', 'absent']}},
        'required_one_of': [['state']],
        'mutually_exclusive': [['overrides', 'data']],
        'required_if': [['interface_device', 'network']],
        'required_together': [['interface_vlan', 'interface_device']]
    }
    validate_args_context = {'role name': 'test_role', 'defaults': 'main.yml', 'entry_point': 'main'}
    arguments = {'state': 'present', 'interface_vlan': 'vlan.yml', 'interface_device': 'device.yml'}

# Generated at 2022-06-11 12:50:47.546231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.errors import AnsibleValidationErrorMultiple
    from ansible.utils.vars import combine_vars
    from ansible.plugins.action import ActionBase
    from ansible.module_utils.common._collections_compat import Mapping

    class ActionModule(ActionBase):
        ''' Validate an arg spec'''

        TRANSFERS_FILES = False


# Generated at 2022-06-11 12:50:54.465872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Verify all options are initialized correctly'''
    action = ActionModule(load_from_file_module=None, task_vars={})

    assert action._task is None
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is not None
    assert action._templar is not None
    assert action._shared_loader_obj is not None
    assert action._action is None
    assert action._task_vars is None
    assert action._remote_user is None
    assert action._connection_user is None
    assert action._play_context is None


# Generated at 2022-06-11 12:51:06.438896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = {'foo': 'bar'}

    action_module = ActionModule()

    # Test with no argument_spec provided
    action_module._task = {'args': {}}

    try:
        action_module.run(tmp, task_vars)
        assert False
    except AnsibleError:
        assert True

    # Test with incorrect type for argument_spec
    action_module._task = {'args': {'argument_spec': 'foo'}}

    try:
        action_module.run(tmp, task_vars)
        assert False
    except AnsibleError:
        assert True

    # Test with incorrect type for provided_arguments
    action_module._task = {'args': {'argument_spec': {}, 'provided_arguments': []}}


# Generated at 2022-06-11 12:51:16.124517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test case:
    Validate a simple argument spec, with some arguments provided.

    The provided argument should be validated against the arg spec.
    '''
    # Arrange
    tmp = None
    task_vars = {
        'test_key1': 'test_value1',
        'test_key2': 'test_value2',
    }

    args = {
        'argument_spec': {
            'test_key1': {'type': 'str'},
            'test_key2': {'type': 'str'},
            'test_key3': {'type': 'str'},
        },
        'provided_arguments': {
            'test_key1': 'test_value1',
        }
    }
    module = ActionModule(dict(), dict())

    # Act
    result

# Generated at 2022-06-11 12:51:24.304861
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins.action.arg_validation
    import ansible.module_utils.common.arg_spec

    action_module_class = ansible.plugins.action.arg_validation.ActionModule
    action_module = action_module_class(
        loader=None,
        task=None,
        connection=None,
        play_context=None,
        loader_cache=False,
        shared_loader_obj=False,
        final_q=False,
        result_q=False,
    )

    given_msg = 'Error: argument_spec arg is required in args: {}'
    expected_msg = '"argument_spec" arg is required in args: {}'

# Generated at 2022-06-11 12:51:31.613763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    task_args = {'validate_args_context': 'test_context', 'argument_spec': {'dest': {'type': 'path'}, 'force': {'type': 'bool'}}, 'provided_arguments': {'dest': '/tmp/test', 'force': 'yes'}}
    task_vars = {'dest': '/test', 'force': 'yes'}
    module.run(task_args=task_vars)
    # module.run(task_args=task_vars)

# Generated at 2022-06-11 12:51:39.866235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = "reboot"
    action = "foo"
    name = "reboot test"
    src = "/tmp/this.file"
    dest = "/tmp/that.file"
    set_type_warning = "task/%s/%s/" % (module, action)
    task_vars = dict(config=dict(src=src, dest=dest))
    action_base = ActionBase(name, task_vars, tmp=dest)
    action_module = ActionModule(name, action_base._task, action_base._connection, action_base._play_context, action_base._loader, action_base._templar, action_base._shared_loader_obj)
    assert isinstance(action_module, ActionModule)
    assert isinstance(ActionModule, type)

# Generated at 2022-06-11 12:51:48.107132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections
    import tempfile
    import os
    import shutil
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
    from ansible.module_utils.errors import AnsibleValidationError

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.validate_argument_spec import ActionModule
    from ansible.utils.vars import combine_vars

    ROLE_TEST_DIR = tempfile.mkdtemp()
    TEST_ENTRY_POINT_PATH = os.path.join(ROLE_TEST_DIR, 'test_entry_point.yaml')
    TEST_ARG_SPEC = os.path

# Generated at 2022-06-11 12:51:52.719007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(False, 'ArgumentSpecValidatorTest',
                                 {'validate_args_context': {}},
                                 {'argument_spec': {}, 'provided_arguments': {}},
                                 {})

    assert action_module.run() == {'argument_errors': [], 'changed': False,
                                   'msg': 'The arg spec validation passed',
                                   'validate_args_context': {}}



# Generated at 2022-06-11 12:51:54.318532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule({}, {}) 
    return action_mod


# Generated at 2022-06-11 12:52:03.082162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a mock task argument to pass in to the action module
    def mock_task():
        return {
            'action': {
                '__ansible_module__': 'test_module',
                '__ansible_arguments__': {
                    'key': 'test-val',
                },
            },
        }

    # create a mock loader to load the args
    def mock_loader():
        return {
            'test_module': {
                'argument_spec': {
                    'key': {
                        'required': True,
                        'type': 'str',
                    },
                },
                'defaults': {
                    'key': 'test-default',
                },
            },
        }

    # create a mock templar to expand variables in the args
    def mock_templar(template):
        expanded_args

# Generated at 2022-06-11 12:52:12.206565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    module = sys.modules[__name__]
    action_module_class = getattr(module, 'ActionModule')
    print(action_module_class)

    action_module_instance = action_module_class()
    print(action_module_instance)

    action_module_instance._task.args = dict()
    action_module_instance.action_set_attributes()

    action_module_instance._task.args = dict()
    action_module_instance.action_set_attributes()
    action_module_instance.action_set_attributes(argument_spec=dict())
    action_module_instance.action_set_attributes(argument_spec=dict(title=dict(type='str')))

# Generated at 2022-06-11 12:52:20.241568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True is True

# Generated at 2022-06-11 12:52:23.951811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    test_ActionModule function does unit test for constructor of class ActionModule
    """
    result = {}
    argument_spec_data = {}
    provided_arguments = {}

    action_module = ActionModule()
    action_module.run(result, argument_spec_data, provided_arguments)

# Generated at 2022-06-11 12:52:32.376552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test if ActionModule throws an exception when task_vars is None
    if task_vars is None:
        raise AnsibleError('"task_vars" arg is required in args: %s' % task_vars)

    # test if ActionModule throws an exception when argument_spec_data is not of type dict
    if not isinstance(argument_spec_data, dict):
        raise AnsibleError('Incorrect type for argument_spec, expected dict and got %s' % type(argument_spec_data))

    # test if ActionModule throws an exception when provided_arguments is not of type dict
    if not isinstance(provided_arguments, dict):
        raise AnsibleError('Incorrect type for provided_arguments, expected dict and got %s' % type(provided_arguments))


# Generated at 2022-06-11 12:52:41.433211
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockActionModule:
        def __init__(self):
            self.tmp = None
            self.task_vars = None

        def run(self, tmp, task_vars):
            self.tmp = tmp
            self.task_vars = task_vars

    action_obj = MockActionModule()
    mock_task_vars = ['test_task_vars']

    class MockTask:
        def __init__(self):
            self.args = None

        def get_args(self):
            return self.args

    mock_task = MockTask()
    mock_task.args = {'validate_args_context': 'test_validate_args_context'}
    mock_ActionModule = ActionModule.run(action_obj, mock_task, mock_task_vars)

    assert mock_

# Generated at 2022-06-11 12:52:48.447356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.validate_arg_spec
    # Create instance of class ActionModule
    action_module = ansible.plugins.action.validate_arg_spec.ActionModule(None, dict(), None)
    # Test method run
    # Create dict of arguments to be passed to method run
    arguments = dict(argument_spec={'hostname': {'type': 'str'}}, provided_arguments={'hostname': 'switch_name'})
    print(action_module.run(None, arguments))

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:52:52.592095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test is designed to test the run method of class ActionModule

    # Arrange
    tmp = None
    task_vars = dict()

    action_base = ActionBase()
    action_module = ActionModule(action_base, dict())

    # Act
    action_module.run(tmp, task_vars)

    # Assert
    assert True

# Generated at 2022-06-11 12:52:53.109011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:52:54.187213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if ActionModule:
        assert 'ActionModule' in str(ActionModule)

# Generated at 2022-06-11 12:53:03.287505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.plugins import module_loader

    ansible_path = module_loader._find_plugin('action', 'validate_arg_spec')
    args = {
        "argument_spec": {"test1": {"default": False, "type": "bool"}, "test2": {"type": "str"}},
        "provided_arguments": {"test1": True}
    }
    module_name = 'validate_arg_spec'
    module_args = args
    action_result = {
        "changed": False,
        "msg": "The arg spec validation passed"
    }

# Generated at 2022-06-11 12:53:10.952300
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    module = ActionModule(dict(argument_spec={'arg1': {'required': True}},
                               provided_arguments={'arg1': '{{ var1 }}'}),
                          dict(validate_args_context={"module_name": "test_module_name"}))

    mock_templar = MockTemplar()
    module._templar = mock_templar

    module.noop_task_vars = dict(var1='value1')
    module.task_vars = dict(var1='value1')

    result = module.get_args_from_task_vars({"arg1": {"required": True}}, module.noop_task_vars)
    assert result == {'arg1': 'echo_value'}

# Generated at 2022-06-11 12:53:35.891998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule

    :returns: None
    '''
    # Test: Validate `run` method of `ActionModule` class.
    # Arrange
    test_data = dict(
        action='test',
        argument_spec=dict(
            argument1=dict(
                type='str',
                choices=['test']
            )
        ),
        provided_arguments=dict(argument1='test'),
        validate_args_context=dict(
            entry_point='test_entry_point'
        )
    )

    module_name = 'ansible.plugins.action.validate_argument_spec'
    task_dict = dict(abc='xyz', defg='hijk')
    mock_task = MagicMock()
    mock_task.args = test_data

# Generated at 2022-06-11 12:53:44.566518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test to validate method run of class ActionModule.
    '''
    actionmodule_validate_argument_spec = ActionModule()
    actionmodule_validate_argument_spec.root_tmp_path = '/your/root/tmp/path'
    actionmodule_validate_argument_spec.templar = 1
    actionmodule_validate_argument_spec.play = 1
    actionmodule_validate_argument_spec.play_context = 1
    actionmodule_validate_argument_spec.task_vars = {'var1':1, 'var2':2, 'var3':3}
    actionmodule_validate_argument_spec.task = 1
    actionmodule_validate_argument_spec._task = 1


# Generated at 2022-06-11 12:53:53.476632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {
        'validate_args_context': {
            'module': 'network.ios.ios_command',
            'filename': '/home/runner/.ansible/tmp/ansible-local-20972e11xjofb/tmp-23995T30TzcPwydH/network.ios.ios_command.py'
        },
        'changed': False,
        'msg': 'The arg spec validation passed'
    }
    action_module = ActionModule()
    
    action_module.ensure_in_tmp = lambda x,y: None
    action_module._execute_module = lambda x,y: data
    action_module._low_level_execute_command = lambda x,y: data
    action_module.cleanup = lambda : None
   
    action_module.noop_on_check

# Generated at 2022-06-11 12:54:02.279434
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    instance = ActionModule()
    # Test argument_spec with value as dict
    argument_spec = {
        "arg1": {
            "required": True,
            "type": "str"
        },
        "arg2": {
            "required": False,
            "type": "bool"
        }
    }
    task_vars = {
        "arg1": "hello",
        "arg2": True,
        "test_var": "{{arg1}}"
    }
    expected_results = {
        'arg1': "hello",
        'arg2': True,
        'test_var': "hello"
    }
    result = instance.get_args_from_task_vars(argument_spec, task_vars)
    assert result == expected_results, 'Result is not as expected'
   

# Generated at 2022-06-11 12:54:10.089922
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader

    host = '127.0.0.1'
    play_context = PlayContext()
    play_context.connection = host
    play_context.network_os = 'test'

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager()
    variable_manager.set_inventory(inventory)

    module = action_loader.get('validate_argument_spec',
                               class_only=True)
    module = module()
    module._shared_loader_obj = loader


# Generated at 2022-06-11 12:54:18.170676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.argument_validation import ArgumentSpecValidator, BooleanArgumentSpec, StrArgumentSpec, DictArgumentSpec, ListArgumentSpec, RawArgumentSpec

    for _action in [
        'get_args_from_task_vars',
        'run',
    ]:
        assert hasattr(ActionModule, _action), 'Action %s does not have method %s' % (ActionModule.__name__, _action)

    action_module = ActionModule(task={})

    # run 1
    try:
        action_module.run()
    except AnsibleError as e:
        assert '"argument_spec" arg is required in args: {}' in e.message, e.message

    # run 2

# Generated at 2022-06-11 12:54:27.151386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for class ``ActionModule``'''


# Generated at 2022-06-11 12:54:35.671170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    am = ActionModule()

    # Create a mock
    mock = Mock()

    # Mock the ansible_facts dict

# Generated at 2022-06-11 12:54:44.743624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.common.arg_spec import (is_argument_spec, ArgumentSpecValueError)

    # The cases for test_ActionModule_run() are stored in a fixture
    # files/validate_arg_spec/test_args_run, as a list of dicts, one
    # dict per case.
    test_args_run = load_data_file()

    def load_data_file():
        '''
        Load the data file and return it
        '''
        import os, yaml
        fixture_path = os.path.join(os.path.dirname(__file__), 'test_args_run')

# Generated at 2022-06-11 12:54:46.000196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-11 12:55:27.423068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import shutil

    from ansible_collections.community.network.plugins.module_utils.network.common.module import ModuleFailJson
    from ansible_collections.community.network.plugins.module_utils.network.common.module import ModuleExitJson
    from ansible_collections.community.network.plugins.module_utils.network.common.module import ModuleFailJsonException
    from ansible_collections.community.network.plugins.module_utils.network.common.module import ModuleExitJsonException
    from ansible_collections.community.network.plugins.module_utils.network.common.module import ModuleReturnValue
    from ansible_collections.community.network.plugins.module_utils.network.common.module import MODULE_ARGS

# Generated at 2022-06-11 12:55:31.977632
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    task_vars = {'arg_spec_test': '{{ arg_spec_test_value }}'}
    args_from_task_vars = ActionModule.get_args_from_task_vars(task_vars, task_vars)
    assert args_from_task_vars == {'arg_spec_test': '{{ arg_spec_test_value }}'}

# Generated at 2022-06-11 12:55:32.494417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:55:39.546213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    class TestActionModule(ActionModule):
        def get_args_from_task_vars(self, argument_spec, task_vars):
            return {'arg1': 'value1'}

    task_vars = {'arg1': 'value1', 'arg2': 'value2'}
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    class MockTask(Task):
        pass
    task = MockTask()

    # The actual test: missing argument_spec

# Generated at 2022-06-11 12:55:48.297025
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
  # Create an instance of ArgumentSpecValidator
  asv = ArgumentSpecValidator(
        {
            'first': {'type': 'bool'},
            'second': {'type': 'str'},
            'third': {'type': 'str', 'default': 'three'},
        },
        always_validate_spec=True
    )

  # Create the instance of ActionModule

# Generated at 2022-06-11 12:55:56.677460
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create an instance of ModulesLoader class
    from ansible.plugins.loader import modules_loader
    modules_loader.add_directory('./unit/plugins/modules')
    m = modules_loader.get('validate_argument_spec')

    # Create an instance of ActionModule class
    action = ActionModule(
        connection=None,
        task_vars=None,
        tempdir=None,
        load_path=None,
        module_name='validate_argument_spec',
        module_args={}
        )

    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()

# Generated at 2022-06-11 12:56:06.391735
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(None, task_vars={'validate_args_context': 'my_playbook_key1.my_playbook_key2.my_playbook_key3'},
                              argument_spec={'test_required_key': {'required': True, 'type': 'str'},
                                             'test_choices_key': {'type': 'str', 'choices': ['choice1', 'choice2']}},
                              provided_arguments={'test_required_key': 'test_required_key_value',
                                                  'test_choices_key': 'choice2'})
    assert result['changed'] is False
    assert result['msg'] == 'The arg spec validation passed'

# Generated at 2022-06-11 12:56:08.021740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        x = ActionModule()
        assert False
    except Exception:
        assert True
    return

# Generated at 2022-06-11 12:56:11.754207
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of the class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-11 12:56:13.244153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Test(ActionModule):
        def run(*_):
            pass

    assert Test


# Generated at 2022-06-11 12:57:23.321077
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import json
    import os
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.six import string_types

    # Mock the task_vars to validate
    task_vars = dict(
        interface_name='GigabitEthernet0/0/2',
        interface_speed='1G',
        link_state='up',
    )

    # Mock the task result and args
    task_result = TaskResult()

    # Get the path to the validate_args_test.json file
    test_file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'validate_args_test.json')

    # Load the arg spec data

# Generated at 2022-06-11 12:57:24.212347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t.TRANSFERS_FILES is False

# Generated at 2022-06-11 12:57:31.847326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    module = ActionModule()
    argument_spec_data = {
        'validate_args_context': {
            'var_name': 'validate_argument_spec_test',
            'task_name': 'validate_args_test'
        }
    }
    provided_arguments = {
        'ip': '1.1.1.1',
        'username': 'test'
    }
    task = dict(
        args=dict()
    )
    task_vars = dict()
    module._task = task

    # Act
    result = module.run(None, task_vars)

    # Assert
    assert result['failed']
    assert result['msg'] == '"argument_spec" arg is required in args: {}'

    # Arrange

# Generated at 2022-06-11 12:57:39.770257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six.moves import StringIO
    from ansible.utils import context_objects as co
    from ansible.utils.vars import combine_vars

    import pytest

    from ansible import context

    from ansible.module_utils.basic import AnsibleModule

    from ansible.plugins.action.validate_argument_spec import ActionModule

    argument_spec_data = {
        'foo': {
            'type': 'int',
            'required': True
        },
        'bar': {
            'type': 'list',
            'required': False
        },
        'baz': {
            'type': 'str',
            'required': True
        }
    }

    provided_arguments = {
        'foo': 1,
        'baz': 'hello'
    }

# Generated at 2022-06-11 12:57:42.141483
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None,
                 shared_loader_obj=None)

# Generated at 2022-06-11 12:57:49.745117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The tests:
    # Different ways to get invalid values for the arg spec.
    argument_spec_data = {
        'name': {'type': 'str'},
        'config': {'type': 'dict'},
        'other': {'type': 'list'},
    }

    # A dict that is missing keys.
    missing_keys = {}
    # A dict with invalid types.
    invalid_types = {
        'name': 'the_name',
        'config': [1, 2, 3],
        'other': {'invalid': 'list'},
    }
    # A dict with invalid values.

# Generated at 2022-06-11 12:57:58.762089
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    # Test a successful validation result.
    action_module._task.args = dict(
        argument_spec=dict(
            state=dict(type='str', choices=['present', 'absent'], default='present'),
            name=dict(type='str', required=True),
        ),
        provided_arguments=dict(
            state='present',
            name='my_entity',
        )
    )
    result = action_module.run(None, None)
    assert not result.get('failed')

    # Test a failed validation result.

# Generated at 2022-06-11 12:58:06.737981
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Parameters
    module_defaults = {}
    module_defaults['argument_spec'] = {}
    module_defaults['provided_arguments'] = {}
    module_defaults['validate_args_context'] = {}

    # Test cases
    def get_test_results(test_case):
        # Execution
        runner_args = {}
        runner_args['module_defaults'] = module_defaults
        runner_args['username'] = ''
        runner_args['password'] = ''
        runner = ActionModule(runner_args)
        # Arguments
        runner_args = {}
        runner_args['argument_spec'] = test_case['input']['argument_spec']
        runner_args['provided_arguments'] = test_case['input']['provided_arguments']

# Generated at 2022-06-11 12:58:14.290294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    # ansible.plugins.action.ActionBase.run()
    # ansible.plugins.action.__init__.ActionBase.__init__()
    action_base_instance = ActionBase()
    # ansible.plugins.action.ActionBase.__init__()
    # ansible.plugins._module_finder.ModuleFinder()
    # ansible.plugins._module_finder.ModuleFinder.add_directory()
    # ansible.plugins._module_finder.ModuleFinder._get_paths()
    # ansible.plugins._module_finder.ModuleFinder._get_paths_from_module_utils()
    # ansible.plugins._module_finder.ModuleFinder._get_paths_from_ansiballz_cache()
    # ansible.module_utils.ansiballz._load_

# Generated at 2022-06-11 12:58:17.003045
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = dict(validate_args_context=dict(name='test'))

    try:
        action = ActionModule(dict(), dict(task=dict(args=data)))
    except Exception as e:
        raise e
