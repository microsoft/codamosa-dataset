

# Generated at 2022-06-11 12:49:55.654627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.

    :return: None.
    '''
    from ansible.executor.task_result import TaskResult

    module = ActionModule()

    task_result = TaskResult()

    module.module_defaults = {}
    module.tmp = ''
    module.action = ''
    module.set_task_result(task_result)


# Generated at 2022-06-11 12:50:04.901250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader as plugin_loader

    # This pickle represents a call to the action module with 'argument_spec' and
    # 'provided_arguments' set. This is what is expected to be found in the
    # self._task.args variable member.

# Generated at 2022-06-11 12:50:10.218850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test_ActionModule()
        Test constructor for class ActionModule
    '''
    action_module = ActionModule(
        {'argument_spec': {'foo': {'type': 'str'}}},
        {'ansible_module_name': 'test'},
        None,
        None,
        None,
        None
    )
    assert isinstance(action_module, ActionModule)

# Test for method run with invalid argument

# Generated at 2022-06-11 12:50:11.021697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Pass - Should not fail
    ActionModule()

# Generated at 2022-06-11 12:50:20.656941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import BytesIO
    from ansible.plugins.action.argspec import ActionModule as argspec
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    play_context = PlayContext()
    play_context.network_os = 'foo'
    play_context.remote_addr = '1.1.1.1'
    play_context.accelerate = 0
    play_context.verbosity = 0

# Generated at 2022-06-11 12:50:22.306692
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert('Validate an arg spec') == action._action_type_name

# Generated at 2022-06-11 12:50:31.330766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-11 12:50:39.833698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule

    # We need a fake module as we are not running a real playbook
    fake_module = AnsibleModule(argument_spec={})
    am = ActionModule(fake_module, '', '', [])

    # args for the test
    provided_arguments = {'foo': 'bar'}
    argument_spec = {
        'foo': {'type': 'str'}
    }

    args = {
        'validate_args_context': 'xyz',
        'argument_spec': argument_spec,
        'provided_arguments': provided_arguments
    }

    # Set the task args to the args dict.
    am._task.args = args

    # Run the module
    result = am.run(None, None)
    assert not result['failed']

# Generated at 2022-06-11 12:50:41.572995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule("a", "b", "c", "d")
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:50:50.655326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.validation import has_tag
    from ansible.module_utils.common.validation import is_required
    from ansible.module_utils.common.validation import is_type
    from ansible.module_utils.common.validation import has_at_least_one_key
    from ansible.module_utils.common.validation import contains_only_keys
    from ansible.module_utils.common.validation import is_value_in

    # create arg spec

# Generated at 2022-06-11 12:51:03.277063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with mock.patch('ansible.plugins.action.ActionBase.run', mock.Mock(return_value={ 'msg': 'mocked', 'failed': False })):
        action_plugin = ActionModule()
        action_plugin._task.args = {}
        action_plugin._task.args['provided_arguments'] = {}
        action_plugin._task.args['argument_spec'] = {}
        action_plugin.run()
        assert action_plugin.run() == {'failed':True,
        'msg':'Validation of arguments failed:\nA dictionary of arguments must be provided\nThe following arguments are required:',
        'argument_spec_data':{},
        'argument_errors':['A dictionary of arguments must be provided','The following arguments are required:']}


# Generated at 2022-06-11 12:51:11.882544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''test run method of class ActionModule'''
    task_vars = dict(testvar='testing1')
    action = ActionModule(dict(action='test', task_vars=task_vars))
    ansible_result = dict(failed=False, msg='')
    action._execute_module = lambda *args, **kwargs: ansible_result
    args = dict()

# Generated at 2022-06-11 12:51:21.093181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    # format the module's args for unit testing
    args = {'provided_arguments': {'a': 'b'}, 'argument_spec': {'a': {'type': string_types}}}

    provided_arguments = args.get('provided_arguments')
    argument_spec = args.get('argument_spec')
    if 'validate_args_context' in args:
        validate_args_context = args.get('validate_args_context')
    else:
        validate_args_context = {}


# Generated at 2022-06-11 12:51:21.900960
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:51:25.108581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    spec = {}
    spec['validate_argument_spec'] = {'argument_spec': {'connection': {'required': True, 'type': 'str'}}, \
                                      'provided_arguments': {'connection': 'network_cli'}}
    mod = ActionModule(None, spec, None)

# Generated at 2022-06-11 12:51:35.011937
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_module_val = ActionModule(create_dir=None, tmpdir=None)

    result = test_module_val.run(None, None)

    # Check the output of the module with the expected result.
    assert result['validate_args_context'] == None

    test_module_val_1 = ActionModule(create_dir=None, tmpdir=None)

    test_action_module_vars = {"_ansible_diff": False,
                               "_ansible_ignore_errors": None,
                               "argument_spec": {"arg1": {"type": "bool",
                                                          "required": True},
                                                 "arg2": {"type": "dict",
                                                          "required": False}}}


# Generated at 2022-06-11 12:51:42.964987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import __builtin__
    import contextlib
    if sys.version_info[0] < 3:
        import mock
        from StringIO import StringIO
    else:
        from unittest import mock
        from io import StringIO
    mock_open_name = 'ansible.plugins.action.validate_args.open'

# Generated at 2022-06-11 12:51:46.066830
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Save the current module state
    saved_state = dict()

    # Set the module state to a known value
    action = ActionModule()

    # Assert that the module state was not modified
    assert saved_state == dict()


# Generated at 2022-06-11 12:51:46.931102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict(), dict(), dict())

# Generated at 2022-06-11 12:51:55.251239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Play, PlayContext, Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 12:52:12.167493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize the test action module with required input params
    ACTION_MODULE = ActionModule()
    ACTION_MODULE._task = dict()
    ACTION_MODULE._task['args'] = dict()
    ACTION_MODULE._task['args']['argument_spec'] = dict()
    ACTION_MODULE._task['args']['argument_spec']['name'] = dict()
    ACTION_MODULE._task['args']['argument_spec']['name']['type'] = 'str'
    ACTION_MODULE._task['args']['provided_arguments'] = dict()
    ACTION_MODULE._task['args']['provided_arguments']['name'] = 'Jai'
    ACTION_MODULE._task['args']['validate_args_context'] = dict()

# Generated at 2022-06-11 12:52:20.501049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # Arg spec validation
    with pytest.raises(AnsibleError, match='"argument_spec" arg is required in args:'):
        module.run(tmp=None, task_vars=dict())

    with pytest.raises(AnsibleError, match='Incorrect type for argument_spec, expected dict and got'):
        module.run(tmp=None, task_vars=dict(argument_spec="a string"))

    with pytest.raises(AnsibleError, match='Incorrect type for provided_arguments, expected dict and got'):
        module.run(
            tmp=None,
            task_vars=dict(argument_spec=dict(), provided_arguments="a string")
        )

    # Provided arguments validation

# Generated at 2022-06-11 12:52:29.132007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = {}
    result['validate_args_context'] = {}

    #test with no argument_spec given
    task_vars = dict()

    test_module = ActionModule(None, None)
    test_module._task = None
    test_module._task.args = {'argument_spec': None, 'provided_arguments': dict()}
    test_module._templar = None
    with pytest.raises(AnsibleError) as excinfo:
        test_module.run(None, task_vars)
    assert excinfo.value.args[0] == '"argument_spec" arg is required in args: {}'

    #test with bad argument_spec given
    task_vars = dict()

# Generated at 2022-06-11 12:52:32.229235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule
    '''
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module


# Generated at 2022-06-11 12:52:34.782261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test for class ActionModule

    :return: None
    '''
    # Test for class ActionModule without parameters
    action_module = ActionModule()
    assert action_module is not None



# Generated at 2022-06-11 12:52:44.113742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase

    # create an instance of ActionBase
    actionBaseObj = ActionBase()

    # create an instance of PlayContext
    playContextObj = PlayContext()

    # create an instance of ActionModule by passing PlayContext obj and emtpy dict
    actionModuleObj = ActionModule(playContextObj, dict())

    # create an empty dict
    test = dict()

    # storing fake data in test dict

# Generated at 2022-06-11 12:52:53.028612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # When the second argument is None, the first one is returned
    assert combine_vars(None, None) is None
    # When the second argument is None, the first one is returned
    assert combine_vars(a=1, b=2) == {'a': 1, 'b': 2}
    # When the second argument is None, the first one is returned
    assert combine_vars(a=1, b=2) is not {'a': 1, 'b': 2}
    # When the second argument is None, the first one is returned
    assert combine_vars(a=1, b=2, provided_arguments={'c': 3}, d=5) == {'a': 1, 'b': 2, 'c': 3, 'd': 5}
    # When the second argument is None, the first one is returned
   

# Generated at 2022-06-11 12:52:53.829261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert len(ActionModule.ARG_SPEC) == 3

# Generated at 2022-06-11 12:52:58.014056
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action_result = {}
    argument_spec = {}
    error_msg = {}
    action.run(action_result, argument_spec, error_msg)
    assert action_result['failed'] == False and action_result['msg'] == 'The arg spec validation passed'

# Generated at 2022-06-11 12:53:06.534898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up the module instance
    arg_spec_data = {'arg1': {'type': 'str'}, 'arg2': {'type': 'int'}, 'arg3': {'type': 'bool'}}
    provided_arguments = {'arg1': 'foo', 'arg3': True}
    task_vars = {'ansible_facts': {'ansible_default_ipv4': {'interface': 'eth0'}}}
    result = {'ansible_facts': {'ansible_default_ipv4': {'interface': 'eth0'}}}

    # create a MockActionModule instance, initialized by another mock object
    mock_action = {'run': ActionModule(task=MockModuleExecutor(), connection=MockConnection()).run}

    # configure the mock action object

# Generated at 2022-06-11 12:53:32.076551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:53:32.693661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:53:33.210996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:53:40.784468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task={
            'name': 'test',
            'args': {
                'argument_spec': {
                    'name': {
                        'type': 'str'
                    },
                    'state': {
                        'type': 'str',
                        'choices': ['present', 'absent']
                    }
                },
                'validate_args_context': {
                    'module_name': 'test',
                    'entry_point': 'test_name'
                }
            }
        },
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert(isinstance(module, ActionModule))



# Generated at 2022-06-11 12:53:49.568729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_module = ActionModule()
    # Test when no argument_spec is passed
    result = test_action_module.run(
        {"validate_args_context":{},
         "argument_spec":{}})
    assert result.get('failed') is True
    assert result.get('msg') == '"argument_spec" arg is required in args: {}'

    # Test when argument_spec in not a dictionary
    result = test_action_module.run(
        {"validate_args_context":{},
         "argument_spec":"sample"})
    assert result.get('failed') is True
    assert result.get('msg') == 'Incorrect type for argument_spec, expected dict and got <class \'str\'>'

    # Test when argument_spec is correct but provided_arguments is not
    result = test

# Generated at 2022-06-11 12:53:58.406084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import copy
    from pprint import pprint

    from ansible.errors import AnsibleError
    from ansible.module_utils.common.validation import check_type_bool, check_type_int, check_type_str, check_type_dict, check_type_list
    from ansible.module_utils.common.arg_spec import ArgumentSpecValidator, argument_spec_required_and_type_validator, argument_spec_type_validator
    from ansible.module_utils.six import string_types, binary_type
    from ansible.module_utils.six.moves import _thread_locals

    # Create a class we can use to instantiate an instance of ActionModule
    class TestActionModule():
        def __init__(self, task):
            self._task = task


# Generated at 2022-06-11 12:54:06.665758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import merge_hash
    action = AnsibleActionModule()
    action.connection = FakeConnection()
    action.task = FakeTask()
    action._templar = FakeTemplar()

    # test with a few basic args
    action.run(task_vars={'foo': 'bar', 'baz': 'qux'})
    assert action.task.args['provided_arguments'] == {'foo': 'bar'}

    # test with nested dict args
    action.run(task_vars=merge_hash(action.task.args, {'foo': {'quux': 'quuux'}}))
    assert action.task.args['provided_arguments'] == {'foo': {'quux': 'quuux'}}

    # test with a list arg

# Generated at 2022-06-11 12:54:14.728816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy class for this test
    class DummyClass:
        pass

    # Dummy task with args
    args = {'argument_spec': {'test': {}}, 'provided_arguments': {}}
    task = DummyClass()
    task.args = args

    # Dummy action object
    action = ActionModule(task, {})

    # Unit test
    with pytest.raises(AnsibleError) as excinfo:
        action.run()
    assert 'dict' in str(excinfo.value)

    # Dummy task with args
    args = {'argument_spec': {'test': {}}, 'provided_arguments': 'abc'}
    task = DummyClass()
    task.args = args

    # Dummy action object
    action = ActionModule(task, {})

    # Unit test


# Generated at 2022-06-11 12:54:23.549303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test method run of class ActionModule

    :return: None
    '''

    class MyTask(object):
        def __init__(self, args=None):
            self.args = args

    # TaskVars is not used by get_args_from_task_vars
    task_vars = {}

    # Use this to trap the __init__ for AnsibleError for testing
    class MyAnsibleError(Exception):
        pass

    # Use this to trap __init__ for AnsibleValidationErrorMultiple for testing
    class MyAnsibleValidationErrorMultiple(Exception):
        pass

    # Validate an argument specification against a provided set of data

# Generated at 2022-06-11 12:54:24.404923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert(actionModule)

# Generated at 2022-06-11 12:54:58.252837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert not hasattr(action, 'tmp')
    assert hasattr(action, 'run')
    assert hasattr(action, 'get_args_from_task_vars')


# Generated at 2022-06-11 12:55:00.666389
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for constructor of class ActionModule '''

    action_module = ActionModule()

    assert action_module is not None

# Generated at 2022-06-11 12:55:06.605985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = {}
    task = {}
    connection = {}
    play_context = {}
    loader = {}
    templar = {}
    shared_loader_obj = {}
    action_base = {}
    # ActionModule(self, _connection, _play_context, _loader, _templar, _shared_loader_obj, task)
    act_mod = ActionModule(host, connection, play_context, loader, templar, shared_loader_obj, task, action_base)
    assert isinstance(act_mod, ActionModule)

# Generated at 2022-06-11 12:55:15.121455
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup action module object for test
    # We use the same object for each test so that we don't need to recreate the object for each test
    # This is done so that we can test the run method of the class
    module_args = {}
    action = ActionModule(load_ansible_module_def=True, task_vars=dict(ma_arg1='hello'))
    action.__dict__.update({'_task_fields': ['module_args', 'module_name']})

    # Test: Too few arguments
    # Expect: AnsibleError
    module_args.update({
        'argument_spec': {'name': {}},
        'provided_arguments': {'name': 'hello'}
    })
    action.__dict__.update(module_args)

# Generated at 2022-06-11 12:55:16.026356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None)

# Generated at 2022-06-11 12:55:27.903246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule'''
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole

    module_args = {}
    module_args['validate_args_context'] = {
        'name': 'testing',
        'path': 'path/to/testing',
    }
    module_args['argument_spec'] = {
        'argument_1': {
            'type': 'str',
            'default': 'default_value',
        },
        'argument_2': {
            'type': 'str'
        }
    }

# Generated at 2022-06-11 12:55:29.591398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(load_context_data=None)
    assert action_module_obj is not None

# Generated at 2022-06-11 12:55:36.987414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    # Load action plugin
    action = action_loader.get('validate_argument_spec', task=Task(), play_context=PlayContext(), new_stdin=None)

    # Set data for test (argument_spec and provided_arguments)
    action._task.args = {'argument_spec': {'test_req_arg': {'required': True, 'type': 'str'},
                                           'test_opt_arg': {'required': False, 'type': 'str'},
                                           'test_opt_arg2': {'required': False, 'type': 'list'},
                                           },
                         'provided_arguments': {},
                         }

# Generated at 2022-06-11 12:55:39.255468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert type(am.argument_spec) == dict

# Generated at 2022-06-11 12:55:42.359930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)


from ansible.module_utils._text import to_text
import json
from ansible.module_utils.common.json_dict import AnsibleJSONEncoder



# Generated at 2022-06-11 12:56:50.593186
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    action_module = ActionModule(connection=None, _task=None)
    action_module._templar = type('', (), {})()
    action_module._templar.template = lambda value: value
    argument_spec = {
        'foo': {
            'required': True
        },
        'baz': {
            'required': True
        },
        'qux': {
            'required': False
        }
    }
    task_vars = {
        'foo': 'bar',
        'baz': 'zab',
        'answer': 42,
        'list': [1, 2, 3],
    }
    returned = action_module.get_args_from_task_vars(argument_spec, task_vars)

# Generated at 2022-06-11 12:56:52.371911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)
    action_module = ActionModule()
    assert(action_module)

# Generated at 2022-06-11 12:57:01.033242
# Unit test for method get_args_from_task_vars of class ActionModule
def test_ActionModule_get_args_from_task_vars():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager

    x = VariableManager()
    x.set_host_variable('server1', 'should_be_overridden', 'this should be overridden')
    x.set_host_variable('server1', 'should_not_be_overridden', 'this should not be overridden')
    x.set_host_variable('server1', 'password', 'this is the password')

    y = PlayContext()
    y.variable_manager = x

    task_vars = dict(should_be_overridden=True,
                     should_not_be_overridden=False,
                     password="{{ 'password should be overridden' }}"
    )


# Generated at 2022-06-11 12:57:09.092284
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_instance = ActionModule()
    result = action_module_instance.run()
    assert result['failed'] == True
    assert result['msg'] == '"argument_spec" arg is required in args: {}'

    result = action_module_instance.run(task_vars = {'argument_spec':{'name':{'type': 'str'}}})
    assert result['failed'] == True
    assert result['msg'] == '"provided_arguments" arg is required in args: {}'

    result = action_module_instance.run(task_vars = {'argument_spec':{'name':{'type': 'str'}}, 'provided_arguments':{'name':'test'}})
    assert result['failed'] == False
    assert result['msg'] == 'The arg spec validation passed'

# Generated at 2022-06-11 12:57:10.898148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)


# Generated at 2022-06-11 12:57:19.490350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    argument_spec = {'a': {'type': 'int'}, 'b': {'type': 'str'}}
    provided_arguments = {'a': 1, 'b': 'foo'}

    test_args = {'argument_spec': argument_spec,
                 'provided_arguments': provided_arguments}


# Generated at 2022-06-11 12:57:21.302164
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None))

# Generated at 2022-06-11 12:57:22.138061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:57:29.533051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C

    class AnsibleCallback(CallbackBase):
        """
        AnsibleCallback
        """
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'

        def __init__(self, display=None):
            super(AnsibleCallback, self).__init__(display=display)

        def v2_playbook_on_play_start(self, play):
            pass

    class TestPlayContext(PlayContext):
        def __init__(self):
            pass


# Generated at 2022-06-11 12:57:37.107637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    spec_validator_result = ArgumentSpecValidatorResult()
    spec_validator_result.add_error_message(AnsibleValidationErrorMultiple([
        ('var1', 'Var1 is required'), ('var2', 'Var2 should be string')]))

    argument_spec_data = {'var1': {'required': True, 'type': 'str'}, 'var2': {'required': True, 'type': 'str'}}
    provided_arguments = {'var1': 'test1', 'var2': ['test2']}

    action_module = ActionModule(None, None, None)
    action_module._templar = {'template': lambda arg: arg}