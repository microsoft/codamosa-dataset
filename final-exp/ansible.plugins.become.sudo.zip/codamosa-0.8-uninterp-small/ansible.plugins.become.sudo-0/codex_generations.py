

# Generated at 2022-06-25 08:15:30.932889
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo hello"
    shell = None
    becomecmd = become_module_0.get_option('become_exe') or become_module_0.name
    become_module_0.get_option('become_user') or ''
    flags = become_module_0.get_option('become_flags') or ''
    prompt = ''
    if become_module_0.get_option('become_pass'):
        become_module_0.prompt = '[sudo via ansible, key=%s] password:' % become_module_0._id
        if flags:  # this could be simplified, but kept as is for now for backwards string matching
            flags = flags.replace('-n', '')

# Generated at 2022-06-25 08:15:37.806725
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ''

    expected_result = 'sudo '
    actual_result = become_module_0.build_become_command(cmd, shell)
    assert actual_result == expected_result


# Generated at 2022-06-25 08:15:43.613327
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_1 = 'cmd_1'
    shell_2 = 'shell_2'
    assert become_module_0.build_become_command(cmd_1, shell_2) == '[sudo via ansible, key=%s] password:' % become_module_0._id



# Generated at 2022-06-25 08:15:52.638855
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Construct all the options
    ansible_become_user_option = 'root'
    ansible_become_exe_option = 'sudo'
    ansible_become_flags_option = '-H -S -n'
    ansible_become_pass_option = None
    become_module_0.set_options(dict(become_user=ansible_become_user_option, become_exe=ansible_become_exe_option, become_flags=ansible_become_flags_option, become_pass=ansible_become_pass_option))
    cmd = 'ls -l'
    shell = None # Test with None shell param

# Generated at 2022-06-25 08:16:01.498890
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Test case 0:
    # Test with ``become_pass=True`` and ``become_flags='-H -S -n'``
    become_pass = True
    become_flags = '-H -S -n'
    cmd = 'pwd'
    shell = 'sh'

    become_module_0 = BecomeModule()
    become_module_0.prompt = ''
    become_module_0.get_option = lambda key: True if key == 'become_pass' else False
    become_module_0.get_option = lambda key: become_flags if key == 'become_flags' else False
    command = become_module_0.build_become_command(cmd, shell)

    assert "'become_user': False" in command, "become_user is not added to the command"

# Generated at 2022-06-25 08:16:05.374617
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "ls"
    shell = "/bin/sh"
    become_module_1.get_option = get_option_mock

    assert become_module_1.build_become_command(cmd, shell) == ""

# Generated at 2022-06-25 08:16:08.439248
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd_1 = become_module_1.build_become_command(cmd='test', shell='test')
    assert(cmd_1 == 'sudo -H -S -n test')


# Generated at 2022-06-25 08:16:16.962739
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'abc'
    shell = '/bash'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n /bash -c \'abc && echo BECOME-SUCCESS-epkmnnhjtpbqdxhdzmyhajnqnqdvokjm\''

# Generated at 2022-06-25 08:16:25.249307
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_obj_0 = BecomeModule()
    cmd = 'sudo -H -S -n -u root bash -c echo BECOME-SUCCESS-vfdkqmiprxiguqchjhkozcfmyneddwqt ; LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8 LC_MESSAGES=en_US.UTF-8 /usr/bin/python -Es /tmp/ansible-tmp-1586394959.97-45652457321703/AnsiballZ_set_fact.py'
    shell = 'bash'

# Generated at 2022-06-25 08:16:34.592889
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = "echo foo"
    shell_0 = True
    become_module_0.get_option = MagicMock(return_value='flags_0')
    become_module_0._build_success_command = MagicMock(return_value='become_module__build_success_command_0')
    become_module_0.become_user = MagicMock(return_value='user_0')
    become_module_0.become_exe = MagicMock(return_value='become_exe_0')
    become_module_0.become_pass = None
    become_command_0 = become_module_0.build_become_command(cmd_0, shell_0)

# Generated at 2022-06-25 08:16:48.031328
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    source_command = ['ls']
    shell = "/bin/sh"
    become_module_0 = BecomeModule()
    actual_return_value = become_module_0.build_become_command(source_command, shell)

# Generated at 2022-06-25 08:16:50.254945
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'abs'
    shell = 'csh'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n abs'

# Generated at 2022-06-25 08:16:58.888493
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert become_module_0.build_become_command("test", False) == "test"

# Generated at 2022-06-25 08:17:07.872060
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = MagicMock(side_effect=['', '', '', '', '', '', ''])
    assert become_module_0.build_become_command('', False) is ''
    become_module_0.get_option.side_effect = None


test_become_module_1 = BecomeModule()
test_become_module_1.get_option = MagicMock(side_effect=['', '', '', '', '', '', ''])


# Generated at 2022-06-25 08:17:15.724171
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    from ansible.module_utils._text import to_bytes
    cmd_0 = to_bytes("pwd")
    shell_0 = "foo"
    assert become_module_0._build_success_command(cmd_0, shell_0) == "&& /bin/sh -c 'echo %s; %s' || /bin/sh -c 'echo %s; %s'" % (become_module_0.success_key, cmd_0, become_module_0.success_key, cmd_0)
    assert become_module_0._build_success_command(cmd_0, None) == "&& %s || (%s)" % (cmd_0, cmd_0)

# Generated at 2022-06-25 08:17:25.026220
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = ''
    shell_0 = ''
    out_0 = become_module_0.build_become_command(cmd_0, shell_0)
    assert out_0 == ''
    become_module_1 = BecomeModule()
    cmd_1 = ''
    shell_1 = 'ps'
    out_1 = become_module_1.build_become_command(cmd_1, shell_1)
    assert out_1 == ''
    become_module_2 = BecomeModule()
    cmd_2 = 'whoami'
    shell_2 = ''
    out_2 = become_module_2.build_become_command(cmd_2, shell_2)
    assert out_2 == 'sudo -H -S -n whoami'
    become_module

# Generated at 2022-06-25 08:17:30.441596
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo "Hello world"'
    shell = 'sh'
    ret = become_module_0.build_become_command(cmd, shell)
    actual_output = ret
    expected_output = 'sudo -H -S -n sh -c \'echo "Hello world"\''
    assert actual_output == expected_output


# Generated at 2022-06-25 08:17:38.842637
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'sudo -H -S -n -p \"sudo password:\" -u root echo ok'
    shell = '/bin/sh'
    result = become_module_0.build_become_command(cmd, shell)
    assert isinstance(result, str)

    become_module_0 = BecomeModule()
    cmd = 'sudo -H -S -p \"sudo password:\" -u root echo ok'
    shell = '/bin/sh'
    result = become_module_0.build_become_command(cmd, shell)
    assert isinstance(result, str)

    become_module_0 = BecomeModule()
    cmd = 'sudo -H -S -n  -u root echo ok'
    shell = '/bin/sh'
    result = become_module_0.build

# Generated at 2022-06-25 08:17:45.000680
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    become_module.become_cmd = 'ansible'
    cmd = 'echo 1'
    shell = 'echo 1'

    become_module.prompt = ''
    assert become_module.build_become_command(cmd, shell) == 'sudo ansible -H -S -n ansible -m raw -a "echo 1"' # default

    become_module.prompt = 'test'
    become_module.get_option = lambda x: x == 'become_exe' and 'ansible' or ''
    become_module.become_exe = become_module.get_option('become_exe')

    assert become_module.build_become_command(cmd, shell) == 'sudo ansible -H -S -p "test" ansible -m raw -a "echo 1"'



# Generated at 2022-06-25 08:17:50.373881
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'echo -n "something"'
    shell_0 = '/bin/sh'
    became_cmd_0 = become_module_0.build_become_command(cmd_0, shell_0)
    assert became_cmd_0 == 'sudo -H -S -n /bin/sh -c \'echo -n "something" && sleep 0\'', "become_cmd_0: %s" % became_cmd_0


test_case_0()

# Generated at 2022-06-25 08:18:11.263474
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.options['become_user'] = None
    become_module_1.options['become_pass'] = None
    become_module_1.options['become_exe'] = None
    become_module_1.options['become_flags'] = None
    cmd = ['foo', 'bar']
    shell = False
    expected = 'sudo -H -S foo bar'
    actual = become_module_1.build_become_command(cmd, shell)
    assert actual == expected
    become_module_2 = BecomeModule()
    become_module_2.options['become_user'] = None
    become_module_2.options['become_pass'] = None
    become_module_2.options['become_exe'] = None
    become_

# Generated at 2022-06-25 08:18:23.497723
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    assert become_module.build_become_command("echo hello", "bash") == "sudo -H -S -n bash -c 'echo hello'"
    assert become_module.build_become_command("echo hello", "sh") == "sudo -H -S -n sh -c \"echo hello\""

    become_module.prompt = None
    become_module.set_options(become_pass='bad_passwd')

    # Make sure that the password option gets passed to sudo with the -p option
    assert become_module.build_become_command("echo hello", "bash") == "sudo -H -S bash -c 'echo hello' -p \"sudo via ansible, key=%s] password:\"" % become_module._id

# Generated at 2022-06-25 08:18:31.354758
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = MagicMock(side_effect=[None, '', '', '', None])
    become_module_0._build_success_command = MagicMock(return_value='/usr/local/bin/python')
    become_module_0._id = 'abc'
    assert become_module_0.build_become_command('/opt/ansible/bin/ansible', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=abc] password:" /usr/local/bin/python'
    become_module_0.get_option = MagicMock(side_effect=['sudo', '-H -S', '', '', None]) 

# Generated at 2022-06-25 08:18:43.250140
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_1 = BecomeModule()
    become_module_1.prompt = 'Sorry, a password is required to run sudo'
    become_module_2 = BecomeModule()
    become_module_3 = BecomeModule()
    become_module_3.prompt = 'Sorry, a password is required to run sudo'
    become_module_4 = BecomeModule()
    become_module_5 = BecomeModule()
    become_module_6 = BecomeModule()
    become_module_6.prompt = 'Sorry, a password is required to run sudo'
    become_module_7 = BecomeModule()
    become_module_8 = BecomeModule()
    become_module_9 = BecomeModule()
    become_module_10 = BecomeModule()

# Generated at 2022-06-25 08:18:54.700580
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_pass = 'foobar'
    become_exe = 'some_path/some_bin'
    become_flags = '-H -foobar'
    become_user = 'some_user'

    # Test with no cmd
    payload = {}
    payload['cmd'] = ''
    payload['shell'] = '/bin/bash -c'

    become_module_0 = BecomeModule()
    become_module_0.options = payload
    become_module_0.get_option = lambda x: None
    assert become_module_0.build_become_command(become_module_0.options['cmd'], become_module_0.options['shell']) == ''

    # Test with cmd and no options
    payload = {}
    payload['cmd'] = 'echo foobar'

# Generated at 2022-06-25 08:19:02.813970
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.prompt = str()
    become_module_0.get_option = MagicMock(return_value='become_exe')
    if sys.version_info < (2, 7, 8):
        # Python 2.7.7 doesn't support mock.patch.multiple
        # https://bugs.python.org/issue17826
        mock_get_option = patch.multiple(become_module_0, get_option=DEFAULT)
    else:
        mock_get_option = unittest.mock.patch.multiple(become_module_0, get_option=DEFAULT)
    mock_get_option.start()


# Generated at 2022-06-25 08:19:11.420734
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = '42'

    become_module._load_options(become_user='alice', become_pass='pass@word1', become_exe='SUDO', become_flags='-H -S -n')
    assert become_module.build_become_command('echo test', '') == 'SUDO -H -S -p "[sudo via ansible, key=42] password:" -u alice echo test'

    become_module._load_options(become_user='alice', become_pass='pass@word1', become_exe='SUDO', become_flags='')

# Generated at 2022-06-25 08:19:15.350915
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    ret = become_module_0.build_become_command('cmd', 'sh')

    assert "sudo -H -S cmd" == ret



# Generated at 2022-06-25 08:19:25.900368
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_2 = BecomeModule()
    become_module_2.set_option('become_flags', '-H -S -n')
    become_module_3 = BecomeModule()
    become_module_3.set_option('become_flags', '-H -S -n')
    become_module_3.set_option('become_pass', False)
    become_module_4 = BecomeModule()
    become_module_4.set_option('become_flags', '-H -S -n')
    become_module_4.set_option('become_pass', False)
    become_module_4.set_option('become_user', 'root')
    become_module_5 = BecomeModule()

# Generated at 2022-06-25 08:19:29.781864
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_0()

if __name__ == "__main__":
    import os
    import sys
    import unittest
    sys.path.append(os.path.realpath(os.path.join(os.getcwd(), 'tests')))
    # print sys.path
    from test_BecomeModule import test_BecomeModule_build_become_command
    unittest.main()

# Generated at 2022-06-25 08:19:50.611397
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    result = become_module_0.build_become_command('cmd', '')

    assert result == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:"   cmd' % (become_module_0._id), 'method build_become_command of class BecomeModule failed'

# Generated at 2022-06-25 08:19:55.135547
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    my_cmd = "/usr/bin/ansible all -m ping"
    ret_val = become_module.build_become_command(my_cmd, None)
    assert ret_val == 'sudo -H -S -n "/usr/bin/ansible all -m ping"'

# Generated at 2022-06-25 08:20:01.235635
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command("ls", True) == "sudo -H -S -n sudoflag sudoprompt sudouser sudocommand || (/bin/sh -c 'echo BECOME-SUCCESS-bdqndqyshyknuaujailmyovrkudrzlxa ; /bin/ls')"


# Generated at 2022-06-25 08:20:08.642440
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo test"
    shell = "sh"
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n sh -c \'echo test; rc=$?; [ $rc -ne 0 ] && exit $rc;\'', "Test Failed"



# Generated at 2022-06-25 08:20:15.242410
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Positive test
    result = BecomeModule.build_become_command(None, {'become_user': 'root', 'become_pass': None, 'become_exe': 'sudo', 'become_flags': '-H -S -n', '_id': 'c97f8f76-e9e9-4b6a-b6bd-0f46c28b87d7', 'success_cmd': 'test'})
    assert type(result) is str

    # Negative test

# Generated at 2022-06-25 08:20:22.824420
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.prompt = None
    become_module_0.get_option=lambda *args, **kwargs: (None if args[0]=='become_pass' else '')
    become_module_0._id=''
    become_module_0._build_success_command=lambda *args, **kwargs: '"echo" "hello"'
    assert become_module_0.get_option('become_pass')==''
    assert become_module_0._id==''
    assert become_module_0._build_success_command('"echo" "hello"', None)=='"echo" "hello"'
    assert become_module_0.prompt==None

# Generated at 2022-06-25 08:20:25.374305
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # arrange

    become_module_1 = BecomeModule()

    cmd = "echo 'hi'"
    shell = "sh"

    # act
    r = become_module_1.build_become_command(cmd, shell)

    # assert
    if r == "sudo -H -S -n sh -c 'echo ''hi'' && sleep 0'":
        print("Assertion passed")
    else:
        print("Assertion failed")

# Generated at 2022-06-25 08:20:29.414641
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0._id = 'SudoBecomePluginTestCase'
    become_module_0.prompt = ''
    cmd = ['ls']
    shell = ''

    result = become_module_0.build_become_command(cmd, shell)
    assert result == 'sudo ls'

# Generated at 2022-06-25 08:20:38.939062
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command("ls -l", "sh") == "sudo -H -S -n sh -c 'ls -l'"
    become_module_1 = BecomeModule()
    become_module_1.prompt = None
    become_module_1.get_option = BecomeModule.get_option.__get__(become_module_1)
    become_module_1.get_option.__func__.__globals__['ansible_become_pass'] = "PASSWORD"
    assert become_module_1.build_become_command("ls -l", "sh") == "sudo -H -S sh -c 'ls -l'"

# Generated at 2022-06-25 08:20:43.493182
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = MagicMock()
    become_module_0._build_success_command = MagicMock()
    cmd = 'echo'
    shell = False
    assert become_module_0.build_become_command(cmd, shell) == become_module_0._build_success_command(cmd, shell)
    assert become_module_0.build_become_command(cmd, shell) == become_module_0._build_success_command.return_value
    become_module_0._build_success_command.assert_called_with(cmd, shell)


# Generated at 2022-06-25 08:21:20.761533
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'command'
    shell = 'shell'
    become_cmd = become_module_0.build_become_command(cmd, shell)
    assert become_cmd == "'sudo' '-H -S -n' '' '' 'command'"

# Generated at 2022-06-25 08:21:23.070868
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command(cmd, shell=None) == cmd

# Generated at 2022-06-25 08:21:30.902898
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = 'cat /etc/foo'
    shell = 'shell /bin/sh'
    become_module_0 = BecomeModule()
    become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:21:36.346335
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    # cmd is a null string
    assert become_module_1.build_become_command("", "") == ""
    # cmd is not a null string
    assert become_module_1.build_become_command("echo 'hi'", "/bin/sh") == "sudo -H -S -n /bin/sh -c \"echo 'hi'\""

# Generated at 2022-06-25 08:21:40.724804
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_target_0 = BecomeModule()
    # Note: cmd == None
    testcase_helper_cmd = None
    # Note: shell == None
    testcase_helper_shell = None
    # Note: return == None
    testcase_helper_return = None
    assert test_target_0.build_become_command(testcase_helper_cmd, testcase_helper_shell) == testcase_helper_return, """Test failure on line 6"""

# Generated at 2022-06-25 08:21:42.402590
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # pass in default arguments to become_module_0.build_become_command
    become_module_0.build_become_command()


# Generated at 2022-06-25 08:21:47.215886
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('', False) == ''

# Generated at 2022-06-25 08:21:57.618960
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.become_pass = None
    become_module_0.become_exe = None
    become_module_0.become_flags = None
    become_module_0.become_user = None
    cmd = 'id'
    shell = None

    ans = become_module_0.build_become_command(cmd, shell)
    assert ans == 'sudo -H -S -n id', "FAIL: test_BecomeModule_build_become_command"


# Generated at 2022-06-25 08:22:04.790639
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    expected_0 = 'sudo -H -S ls'
    actual_0 = become_module_0.build_become_command(cmd, '')
    assert actual_0 == expected_0


# Generated at 2022-06-25 08:22:13.492229
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    arguments_0 = {'become_user': 'sudo_user', 'become_flags': 'sudo_flags', 'become_pass': 'sudo_pass', 'cmd': 'become_cmd', 'exe': 'sudo_exe', 'shell': 'sudo_shell'}
    become_module_0 = BecomeModule()
    return_value_0 = become_module_0.build_become_command(**arguments_0)

# Generated at 2022-06-25 08:23:35.792866
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command('echo "testing"','sh') == 'sudo -H -S -n -p "[sudo via ansible, key=bbe507a8c8f9a9ba95d23fde5d5bda5b] password:" -u root echo "testing"'
    become_module_2 = BecomeModule()
    become_module_2._task.become_pass = 'test_ansible'
    assert become_module_2.build_become_command('echo "testing"','sh') == 'sudo -H -S -p "[sudo via ansible, key=9ec9b05a3474fae1c8f8f855d52c00a7] password:" -u root echo "testing"'

# Generated at 2022-06-25 08:23:41.941041
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "some_command"
    shell = None
    ret = become_module_1.build_become_command(cmd, shell)
    assert ret == 'some_command'

# Generated at 2022-06-25 08:23:43.656237
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "cmd"
    shell = "shell"
    result = become_module_0.build_become_command(cmd, shell)
    assert isinstance(result, str)


# Generated at 2022-06-25 08:23:49.643365
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = "echo -n '$(whoami)' ; echo; exit 0"
    shell_0 = 'sh'
    # Exception raised while parsing method arguments
    try:
        become_module_0.build_become_command(cmd_0, shell_0)
    except SystemExit as e:
        assert e.args[0] == 1
    except TypeError as e:
        print(e)
    else:
        raise Exception("Failed to raise exception")


# Generated at 2022-06-25 08:23:54.118414
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    assert become_module_1.build_become_command(cmd="", shell="") == ""



# Generated at 2022-06-25 08:24:01.202041
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_obj_0 = BecomeModule()
    cmd = '/bin/true'
    shell = None
    become_module_obj_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:24:07.464453
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = MagicMock(return_value='some value')
    become_module_1.name = 'sudo'
    become_module_1._id = 'some id'
    become_module_1.prompt = None
    become_module_1._build_success_command = MagicMock(return_value='some cmd')
    result = become_module_1.build_become_command('some cmd', 'some shell')
    assert result == 'sudo -H -S -p "[sudo via ansible, key=some id] password:" -u some value some cmd'

# Generated at 2022-06-25 08:24:15.934912
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # checks for user in env variable
    become_module_0 = BecomeModule()
    become_module_0.prompt = '[sudo via ansible, key=c9c46eaa0d7c3d099026a3d8b17c1f0a] password:'
    become_module_0.become_pass = 'False'
    become_module_0.get_option = lambda a: 'True' if a == 'become_pass' else None
    become_module_0.get_option.__name__ = lambda : "become_pass"
    become_module_0.become_user = 'False'
    become_module_0.get_option = lambda a: 'True' if a == 'become_user' else None

# Generated at 2022-06-25 08:24:22.088503
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = ['command1']
    expected = 'sudo command1'
    assert become_module_1.build_become_command(cmd, '/bin/sh') == expected
    cmd = ['/bin/sh', '-c', 'command2']
    expected = 'sudo /bin/sh -c command2'
    assert become_module_1.build_become_command(cmd, '/bin/sh') == expected


# Generated at 2022-06-25 08:24:26.815296
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "Hello"
    shell = "user"
    setattr(become_module_0, "_id", "3a02a27d-2b82-4e8c-8533-15c1b1d010ac")
    become_module_0.get_option = lambda *x: "sudo" if x[0] else "Sorry, try again."
    become_module_0.prompt = ''
    result = become_module_0.build_become_command(cmd, shell)
    assert result == 'sudo -p "[sudo via ansible, key=3a02a27d-2b82-4e8c-8533-15c1b1d010ac] password:" "Hello"'