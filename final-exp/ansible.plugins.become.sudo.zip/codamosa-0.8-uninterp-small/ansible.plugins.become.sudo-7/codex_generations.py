

# Generated at 2022-06-25 08:15:25.030203
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = 'ls'
    shell = 'sh'
    become_module_0.prompt = 'Password'
    become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:15:27.363608
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    cmd = "/bin/ls"
    result = become_module_0.build_become_command(cmd, None)

    assert result == '/bin/ls'


# Generated at 2022-06-25 08:15:36.825414
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    test_module_1 = dict(name='module1', args='--extra-vars=\"@module1.yml\"')
    test_shell_1 = '/bin/sh'
    become_module_1 = BecomeModule()

    test_module_2 = dict(name='module2', args='--extra-vars=\"@module2.yml\"')
    test_shell_2 = '/bin/bash'
    become_module_2 = BecomeModule()

    test_module_3 = dict(name='module3', args='--extra-vars=\"@module3.yml\"')
    test_shell_3 = '/bin/sh'
    become_module_3 = BecomeModule()

    test_module_4 = dict(name='module4', args='--extra-vars=\"@module4.yml\"')
    test_

# Generated at 2022-06-25 08:15:43.312217
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    become_module_0.prompt = None
    become_module_0.is_fork = None
    become_module_0.is_tty = None

    become_module_0.prompt = '[sudo via ansible, key=5U6-HUd8h9bJjda2Q3dz3Q] password: '
    become_module_0.is_fork = True
    become_module_0.is_tty = False
    args = ('become cmd test', 'cmd')
    kwargs = {}
    expected_result = 'sudo -p "[sudo via ansible, key=5U6-HUd8h9bJjda2Q3dz3Q] password: "  cmd'
    actual_result = become_module_0.build_bec

# Generated at 2022-06-25 08:15:52.616712
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Function to check that build command returns the correct command to be executed
    def check_cmd_execution(cmd, 
                    shell, 
                    become_exe = 'sudo',
                    become_flags = '-H -S -n',
                    become_pass = "",
                    become_user = 'root',
                    expected_command = "sudo -H -S -n sudo -u root -s"):
        become_module = BecomeModule()
        become_module._id = "0"
        # Set the relevant beome options to the values provided
        become_module.become_exe = become_exe
        become_module.become_flags = become_flags
        become_module.become_pass = become_pass
        become_module.become_user = become_user



# Generated at 2022-06-25 08:15:54.824799
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # test for string_type
    assert type(become_module_0.build_become_command('cmd', None)) is str

# Generated at 2022-06-25 08:16:03.376202
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmnd1 = 'ansible.module_utils.basic.AnsibleModule'
    cmd2 = 'ansible.module_utils.basic.AnsibleModule'
    if isinstance(cmnd1, str):
        cmnd1 = str(cmnd1).encode('utf-8')
    if isinstance(cmd2, str):
        cmd2 = str(cmd2).encode('utf-8')
#    become_module_0.get_option('become_exe')
#    become_module_0.get_option('become_user')
    become_module_0.become_flags = '-H -S -n'
    become_module_0.get_option('become_pass')

# Generated at 2022-06-25 08:16:06.737105
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = ("whoami")
    shell = ("/bin/sh")
    become_module_1.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:16:17.340947
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # No user or password
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda cmd, shell: 'echo success'
    assert become_module.build_become_command('whoami', False) == 'sudo echo success'
    assert become_module.build_become_command('whoami', True) == 'sudo -s echo success'
    assert become_module.prompt == ''
    answer = become_module.get_success_command_output('success')
    assert answer == 'success'

    # No password
    become_module = BecomeModule()
    become_module.get_option = lambda x: 'user1' if x == 'become_user' else None

# Generated at 2022-06-25 08:16:25.430239
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    shell = '/bin/sh'
    become_module_0.prompt = ''
    become_module_0._id = '0f8a7a3f3ba04d717f5250d8a7b0f2b9'
    become_module_0.get_option = MagicMock(side_effect=lambda v: {'become_exe': 'sudo', 'become_flags': '-H -n', 'become_user': 'root'}[v])
    become_module_0._build_success_command = MagicMock(return_value='ls')
    become_module_0.no_passwords = True
    ret = become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:16:30.492000
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    int_0 = 1520
    set_0 = {int_0, int_0, int_0}
    int_1 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:16:35.520932
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    
    test_case_0()



# Generated at 2022-06-25 08:16:38.328388
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_1 = BecomeModule()

    var_1 = become_module_1.build_become_command()

    assert var_1 == None

# Generated at 2022-06-25 08:16:48.008095
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert var_0 == u'sudo -H -S -p "[sudo via ansible, key=%s] password:" -u "%s" env ANSIBLE_COMMAND="%s" "%s"' % (become_module_0._id, "", "", "")
    become_module_0.prompt = 'string_0'
    var_0 = become_module_0.build_become_command(int_0, set_0)
    int_1 = 258
    set_1 = {int_0, int_1}
    become_module

# Generated at 2022-06-25 08:16:49.605640
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Test case 0
    test_case_0()


if __name__ == '__main__':

    # Test case 0
    test_case_0()

# Generated at 2022-06-25 08:16:53.013090
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {int_0, int_0, int_0}
    var_0 = become_build_become_command(int_0, set_0)

    # Ensure return code is correct
    assert var_0 == set_0

# Generated at 2022-06-25 08:16:56.034443
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:17:00.983269
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    try:
        become_module_0 = BecomeModule()
        set_0 = set()
        str_0 = become_module_0.build_become_command(0, set_0)
    except Exception as err:
        assert err.__class__.__name__ == "TypeError"
        assert 'int' in str(err)
        assert "'command'" in str(err)
        assert 'NoneType' in str(err)


# Generated at 2022-06-25 08:17:04.499408
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_1 = set()
    var_2 = become_module_0.build_become_command(var_1, var_1)


# Generated at 2022-06-25 08:17:10.924807
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = mock_get_option
    become_module_0._build_success_command = mock__build_success_command
    become_module_0.prompt = mock_prompt
    become_module_0._id = mock__id
    cmd_0 = mock_cmd
    shell_0 = mock_shell
    var_0 = become_module_0.build_become_command(cmd_0, shell_0)
    expected_value_0 = 'sudo -H -S -n -u root /bin/sh -c \'"\'"\'echo $? && sleep 0\'"\'"\''
    assert var_0 == expected_value_0

# Generated at 2022-06-25 08:17:21.431828
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert var_0 == None


# Generated at 2022-06-25 08:17:31.890486
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    config = {
        'become_exe': 'sudo',
        'become_flags': '-H -S -n',
        'become_pass': '',
        'become_user': '',
    }
    become = BecomeModule(**config)

    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    config['become_pass'] = 'secret'
    become = BecomeModule(**config)

    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "sudo via ansible, key=password: " ls'

    config['become_flags'] = '-H -S -n -D'
    config['become_user'] = 'nopasswduser'

# Generated at 2022-06-25 08:17:34.134571
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_0()


# Generated at 2022-06-25 08:17:35.732635
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command('foo', None) is not None

# Generated at 2022-06-25 08:17:39.529540
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    int_0 = 256
    set_1 = {int_0, int_0, int_0}
    tuple_0 = become_build_become_command(int_0, set_1)
    assert tuple_0[0] == 256
    assert tuple_0[1] == set_0


# Generated at 2022-06-25 08:17:42.083726
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)

    return become_module_0

# Generated at 2022-06-25 08:17:43.554168
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case #0
    assert test_case_0()


# Generated at 2022-06-25 08:17:49.051024
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.become.tests.test_become import (
        BecomeBase,
    )

    become_module_0 = BecomeModule()
    become_module_0.setup(become_base_0)
    # check successful call
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert var_0 == 'test_suite_BecomeModule_build_become_command_str_0'

# Generated at 2022-06-25 08:17:51.673794
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    set_0 = build_become_command("ls -l", "/bin/bash")
    assert set_0 == "sudo -H -S -n ls -l"
    fail("method build_become_command of class BecomeModule is not working correctly")


# Generated at 2022-06-25 08:17:53.495578
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Execute method
    result_0 = become_module_0.build_become_command()
    # Test for proper type
    assert isinstance(result_0, str)

# Generated at 2022-06-25 08:18:05.491299
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Message from user
    become_module_0 = BecomeModule()
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    var_0 = become_build_become_command(int_0, set_0)

# Generated at 2022-06-25 08:18:14.896530
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    set_5 = {78, 79}
    become_module_3 = BecomeModule()
    int_4 = 145
    int_1 = 257
    set_1 = {int_1, int_1, int_1}
    int_2 = 2
    set_2 = {int_2, int_2, int_2}
    set_3 = {150, 151}
    int_3 = 304
    set_4 = {int_3, int_3, int_3}
    test_cases_0 = [((int_4, set_1),), ((int_2, set_2),), ((int_1, set_3),), ((int_3, set_4),), ((78, set_5),)]
    for test_case in test_cases_0:
        test_case_0(*test_case)

# Generated at 2022-06-25 08:18:23.634593
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    input0 = {'become_exe': 'become_exe', 'become_flags': 'become_flags', 'become_pass': 'become_pass', 'become_user': 'become_user', 'become_method': 'become_method', 'become_info': 'become_info'}
    expected_output = 'become_exe become_flags -u become_user -p "Sorry, try again." become_method cmd'
    become_module_0 = BecomeModule()
    become_module_0.set_options(input0)
    output = become_module_0._build_become_command(expected_output, False)
    assert output == expected_output

# Generated at 2022-06-25 08:18:26.448849
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # fail: Sorry, try again.
    # missing: Sorry, a password is required to run sudo
    # missing: sudo: a password is required
    # mock: yes
    # test: no
    # test: yes
    # test: no
    # test: no
    # test: yes
    # test: no
    test_case_0()

# Generated at 2022-06-25 08:18:33.953094
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Calling build_become_command with arguments (self, cmd, shell)
    var_0 = "echo small"
    var_1 = "echo small"
    become_module_0 = BecomeModule()
    become_module_0.build_become_command(var_0, var_1)

# Generated at 2022-06-25 08:18:43.288075
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    result = become_module_1.build_become_command("sudo", "bash")
    assert result == "sudo -H -u root bash -c 'sudo -k && sudo -H -S -u root -p \"[sudo via ansible, key=12345] password:\" /bin/sh -c '\"'\"'echo BECOME-SUCCESS-tqksaatqeyvnrzfjszgizdmmzryjtqjr';\"'\"'\"'\"'/bin/sh -c '\"'\"'chmod u+x /tmp/ansible-tmp-1511473329.97-787700656860826 && sleep 0'\"'\"''\"'\"''"


# Generated at 2022-06-25 08:18:50.468438
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    with pytest.raises(TypeError):
        become_module = BecomeModule()
        module_0 = 257
        set_arg_0 = {module_0, module_0, module_0}
        test_case_0(module_0, set_arg_0)

# Generated at 2022-06-25 08:18:56.941967
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:19:01.214018
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)
    print("var_0: ", var_0)

if __name__ == "__main__":
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:19:10.720630
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert var_0 is not None
    become_module_0.name = 'sudo'
    var_1 = become_module_0.build_become_command(int_0, set_0)
    assert var_1 is not None
    become_module_0.build_option_dict()
    become_module_0.get_option('become_exe')
    become_module_0.get_option('become_flags')
    become_module_0.get_option('become_pass')

# Generated at 2022-06-25 08:19:37.162737
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {257, 256, 258}
    var_0 = become_build_become_command(257, set_0)
    print("Variable var_0: " + str(var_0))
    set_1 = {'sudo'}
    var_1 = become_build_become_command(257, set_1)
    print("Variable var_1: " + str(var_1))
    print("Variable var_1: " + str(var_1))
    print("Variable var_1: " + str(var_1))


# Generated at 2022-06-25 08:19:48.666578
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test for method build_become_command of class BecomeModule
    # Test 1: All arguments are valid
    # Test 2: Any argument is invalid/not available

    # Test 1
    become_module_0 = BecomeModule()
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assertEquals(var_0, var_0)

    # Test 2
    become_module_1 = BecomeModule()
    int_1 = 257
    set_1 = {int_0, int_0, int_0}
    var_1 = become_module_0.build_become_command(int_1, set_1)

# Generated at 2022-06-25 08:19:51.322833
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = 'sudo'
    var_0 = become_module_0.build_become_command('pwd', str_0)


if __name__ == '__main__':
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:19:59.242647
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 256
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_module_0._build_success_command(int_0, set_0)
    var_1 = become_module_0.get_option('become_pass')
    var_2 = become_module_0.get_option('become_flags')
    str_0 = var_2
    var_3 = become_module_0.get_option('become_pass')
    str_1 = var_3
    str_2 = '1'
    var_4 = become_module_0.get_option('become_exe')
    str_3 = var_4
    str_4 = '2'

# Generated at 2022-06-25 08:20:07.161134
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = 257
    shell = {257, 257, 257}
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(cmd, shell)
    if var_0 != "sudo '257'" :
        raise AssertionError("Test 2 faild")
    cmd = 257
    shell = {257, 257, 257}
    become_module_0 = BecomeModule()
    become_module_0.set_option('become_flags', '-H -S -n')
    var_0 = become_module_0.build_become_command(cmd, shell)
    if var_0 != "sudo '257'" :
        raise AssertionError("Test 3 faild")
    cmd = 257
    shell = {257, 257, 257}
    become_module_0

# Generated at 2022-06-25 08:20:10.840510
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    var_0 = 257
    var_1 = {var_0}
    become_module_0 = BecomeModule()
    var_2 = become_module_0.build_become_command(var_0, var_1)

# Generated at 2022-06-25 08:20:18.738840
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = lambda x: set()
    become_module_0._build_success_command = lambda a, b: 'a b c'

    assert become_module_0.build_become_command('a', 'b') == 'a b c'
    assert become_module_0.build_become_command('a b', 'c') == 'a b c'
    assert become_module_0.build_become_command('a b c', 'd') == 'a b c'
    assert become_module_0.build_become_command('', 'a') == 'a b c'
    assert become_module_0.build_become_command('a', '') == 'a b c'


# Generated at 2022-06-25 08:20:24.831669
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:20:28.668250
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    set_0 = {'a', 'a', 'a'}
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command('a', set_0)
    assert var_0 == 'sudo  -H -S -n  -p "[sudo via ansible, key=a] password:"   a'

# Generated at 2022-06-25 08:20:33.546920
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    var_0 = become_module_0.build_become_command(int_0, set_0)
    print(var_0)

# Generated at 2022-06-25 08:21:26.135176
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    sudo_0 = BecomeModule()
    sudo_exe_0 = 'sudo'
    sudo_flags_0 = '-H -S -n'
    sudo_user_0 = 'root'
    sudo_prompt_0 = '[sudo via ansible, key=abc123] password:'
    cmd_0 = 'cat /etc/passwd'
    shell_0 = '/usr/bin/sh'
    result_0 = sudo_0.build_become_command(cmd_0, shell_0)
    assert result_0 == 'sudo -H -S -n -u root -p "%s" "/usr/bin/sh -c \'cat /etc/passwd && sleep 0\'"' % sudo_prompt_0
    sudo_prompt_0 = '[sudo via ansible, key=abc123] password:'

# Generated at 2022-06-25 08:21:28.964259
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command({}, {})

# Generated at 2022-06-25 08:21:31.918855
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)

# Generated at 2022-06-25 08:21:36.461297
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "arg_0"
    shell = "arg_1"
    var_1 = become_module_0.build_become_command(cmd, shell)

    assert var_1 == "sudo -H sh -c 'echo BECOME-SUCCESS-qxmqwjqxjmqxxkqpfdmjyrgmb; \
        LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8 LC_MESSAGES=en_US.UTF-8 /bin/sh -c '\\''( umask 77 && \
        /bin/sh ) || ([ $$ -eq 0 ] && ( umask 77 && /bin/sh ) || exit 0)'\\'''", "build_become_command failed"

# Generated at 2022-06-25 08:21:39.013285
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:21:43.730537
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Set up parameters
    cmd = 257
    shell = {cmd, cmd, cmd}
    
    # Test method
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:21:46.504989
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Case 0

    int_0 = 257

    set_0 = {int_0, int_0, int_0}

    become_module_0 = BecomeModule()

    var_0 = become_module_0.build_become_command(int_0, set_0)

    print(var_0)


# Generated at 2022-06-25 08:21:49.854464
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(257, {257, 257, 257})


# Generated at 2022-06-25 08:21:54.131626
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(0, 0)
    assert var_0 == become_build_become_command(0, 0)


# Generated at 2022-06-25 08:21:58.812824
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 5
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:23:35.599927
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)

# Generated at 2022-06-25 08:23:41.370683
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command(int(10), set()) == set()


# Generated at 2022-06-25 08:23:48.348642
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)
    assert set_0 == [int_0, int_0, int_0]

# Generated at 2022-06-25 08:23:58.650081
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert(become_module_0.build_become_command("/usr/bin/foo", "TEST_CASE_1") is None)
    assert(become_module_0.build_become_command("/usr/bin/foo", "TEST_CASE_2") is None)
    assert(become_module_0.build_become_command("/usr/bin/foo", "TEST_CASE_3") is None)
    assert(become_module_0.build_become_command("/usr/bin/foo", "TEST_CASE_4") is None)
    assert(become_module_0.build_become_command("/usr/bin/foo", "TEST_CASE_5") is None)

# Generated at 2022-06-25 08:24:03.902315
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    int_1 = 256
    set_0 = {int_0, int_1}
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:24:13.082205
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ""
    shell = ""

# Generated at 2022-06-25 08:24:14.636706
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 257
    set_0 = {int_0, int_0, int_0}
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)

# Generated at 2022-06-25 08:24:22.247788
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:24:23.377950
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_0()

# Generated at 2022-06-25 08:24:29.931841
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = become_module_0._get_options()
    str_0 = become_module_0._build_success_command(int_0, set_0)
    int_0 = 257
    str_1 = become_module_0._build_success_command(int_0, set_0)
    set_1 = {str_0, str_0, str_0, str_1}
    str_2 = become_module_0.build_become_command(int_0, set_1)
    assert str_2 == 'sudo -p "Sorry, try again."'