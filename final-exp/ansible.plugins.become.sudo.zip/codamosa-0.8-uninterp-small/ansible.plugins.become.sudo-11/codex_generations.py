

# Generated at 2022-06-25 08:15:32.816110
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # test case 1
    become_module = BecomeModule(load_options_from_file=False)
    become_module.set_options(dict(become_exe='sudoplaybook', become_flags='-n', become_user='root', become_pass='y'))
    result = become_module.build_become_command('mycommand', 'sh')
    assert result == 'sudoplaybook -n -p "[sudo via ansible, key=%s] password:" -u root sh -c \'echo BECOME-SUCCESS-eo; mycommand\' && echo BECOME-SUCCESS-po' % (become_module._id)
    # test case 2
    become_module = BecomeModule(load_options_from_file=False)

# Generated at 2022-06-25 08:15:43.121875
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
   become_module_0 = BecomeModule()

   become_module_0.prompt = '[sudo via ansible, key=0dae6e3f6a8e4987a18fddc0f0e2dcb8] password:'

   become_module_0.build_become_pass = 'become_pass'
   become_module_0.build_become_flags = '-H -S -n'
   become_module_0.build_become_user = 'become_user'
   become_module_0.build_safe_args = 'safe_args'

   # Test build_become_command() method with shell set to True and become exe set to False.
   become_module_0.build_become_command('cmd', True)


# Generated at 2022-06-25 08:15:47.719738
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    # test cases
    assert become_module.build_become_command('/bin/bash', 'shell') == 'sudo -H -S -n /bin/bash'


# Generated at 2022-06-25 08:15:51.031753
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ["test_cmd"]
    shell = "test_shell"
    result = become_module_0.build_become_command(cmd, shell)
    assert result == "sudo -H -S -n -p \"[sudo via ansible, key=ansible] password:\" test_cmd"

# Generated at 2022-06-25 08:15:58.707152
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo hello world"
    shell = True
    assert become_module_0.build_become_command(cmd, shell) == "sudo -H -S -n -p \"[sudo via ansible, key=aabbccddee] password:\" -u root sh -c 'echo hello world'"

    cmd = "echo hello world"
    shell = False
    assert become_module_0.build_become_command(cmd, shell) == "sudo -H -S -n -p \"[sudo via ansible, key=aabbccddee] password:\" -u root echo hello world"

# Test case for class BecomeModule

# Generated at 2022-06-25 08:16:05.801058
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:16:15.684159
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    become_module_0._id = '8e55c7694a6f4d28ae58e65b8e8f25c1'
    cmd = 'whoami'
    shell = 'sh'
    assert(become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n -p "[sudo via ansible, key=8e55c7694a6f4d28ae58e65b8e8f25c1] password:" -u root sh -c "whoami"')

# Generated at 2022-06-25 08:16:19.537172
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ['/usr/bin/python']
    shell = False
    assert become_module_0.build_become_command(cmd, shell) == "sudo  -p \"Sorry, a password is required\"  /usr/bin/python"

# Generated at 2022-06-25 08:16:25.295483
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    become_module_0._id = '2001'
    become_module_0.prompt = '2001'
    become_module_0.prompt_re = '2001'
    become_module_0._display.warning('2001')
    become_module_0._display.vvvv('2001')
    cmd_0 = ""
    shell_0 = False

    ret = become_module_0.build_become_command(cmd_0, shell_0)
    assert ret == 'sudo -c \'echo %s; %s\' ' % (become_module_0._text_type(become_module_0._SUCCESS_KEY), cmd_0)

# Generated at 2022-06-25 08:16:33.007130
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo'
    shell = False
    v0 = become_module_0.build_become_command(cmd, shell)
    v0 = v0.split(' ')
    assert v0[0] == 'sudo'
    assert v0[1] == '-H'
    assert v0[2] == '-S'
    assert v0[3] == '-n'
    assert v0[4] == 'echo'


# Generated at 2022-06-25 08:16:45.612901
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command('cmd', 'shell') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-lcqpmlqelgqesbqnqmvsohjqmqnqcqn; %(cmd)s\'', 'Test case build_become_command failed'


# Generated at 2022-06-25 08:16:53.791866
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_2 = BecomeModule()
    become_module_3 = BecomeModule()
    become_module_4 = BecomeModule()
    become_module_5 = BecomeModule()
    become_module_6 = BecomeModule()
    become_module_7 = BecomeModule()
    become_module_8 = BecomeModule()
    become_module_9 = BecomeModule()
    become_module_10 = BecomeModule()
    become_module_11 = BecomeModule()
    become_module_12 = BecomeModule()
    become_module_13 = BecomeModule()
    become_module_14 = BecomeModule()
    become_module_15 = BecomeModule()
    become_module_16 = BecomeModule()
    become_module_17 = BecomeModule()
    become_module_18 = BecomeModule()
   

# Generated at 2022-06-25 08:16:58.548527
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo hello'
    shell = '/bin/bash'
    expected_value = 'sudo -S -n -p ' + repr(become_module_0.prompt) + ' ' + repr(cmd)
    actual_value = become_module_0.build_become_command(cmd, shell)
    assert actual_value == expected_value

# Generated at 2022-06-25 08:17:08.358128
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'cat /etc/resolv.conf'
    shell_0 = 'bash'
    become_cmd_0 = become_module_0.build_become_command(cmd_0, shell_0)
    assert become_cmd_0 == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-xwphjhfgtbkwucitvfshztjfxytbcmzt; /bin/sh -c "cat /etc/resolv.conf"\' ', 'Command returned did not match expected command'

# Generated at 2022-06-25 08:17:16.014433
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0._play_context = dict(
        # ansible 2.9
        become_user='test1',
        become_pass='test2',
        become_method='test3',
        become_exe='test4',
        become_flags='test5',
        # ansible<2.9
        become_user='test6',
        become_pass='test7',
        become_method='test8',
        become_exe='test9',
        become_flags='test10',
    )
    become_module_0.get_option = lambda x: become_module_0._play_context[x]

    cmd = "ls -l"

    # No become_user nor become_pass
    become_module_0._id = 'none'
    assert become_

# Generated at 2022-06-25 08:17:22.777727
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'command'
    shell = True
    # Call method
    desired_output = "sudo -H -S -n -u root '%s'" % ("bash -c 'command'")
    actual_output = become_module_0.build_become_command(cmd, shell)
    # Ensure that output is as expected
    assert actual_output == desired_output, "%s != %s" % (actual_output, desired_output)

# Generated at 2022-06-25 08:17:32.288652
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # test with cmd = ''
    become_module_1 = BecomeModule()
    cmd = ''
    shell = True
    ret = become_module_1.build_become_command(cmd, shell)
    assert ret == cmd

    # test with cmd = '<command> <args>'
    become_module_2 = BecomeModule()
    cmd = '<command> <args>'
    shell = True
    ret = become_module_2.build_become_command(cmd, shell)
    assert ret.endswith('<command> <args>')

    # test with cmd = ['<command>', '<args>']
    become_module_3 = BecomeModule()
    cmd = ['<command>', '<args>']
    shell = True

# Generated at 2022-06-25 08:17:40.441514
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_config_option = lambda x: 'ansible'
    assert become_module_1.build_become_command("ansible", "ansible") == "sudo -H -S -n  ansible"

    become_module_2 = BecomeModule()
    become_module_2.get_config_option = lambda x: ''
    assert become_module_2.build_become_command("ansible", "ansible") == "sudo -H -S -n -u ansible ansible"

    become_module_3 = BecomeModule()
    become_module_3.get_config_option = lambda x: ''
    become_module_3.get_option = lambda x: ''
    become_module_3.prompt = 'ansible'
    become_

# Generated at 2022-06-25 08:17:45.106916
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    assert become_module.build_become_command(['/bin/foo', '-c', '/usr/bin/id', '-z'], 'bash') == \
        'sudo -H -S -n /bin/bash -c \'sudo -u root -H -S -n  -p "Become password:"  "/bin/foo" "-c" "/usr/bin/id" "-z" && sleep 0'

    become_module_2 = BecomeModule()
    become_module_2.get_option = lambda x: None


# Generated at 2022-06-25 08:17:47.420381
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ''
    shell = True
    assert become_module_0.build_become_command(cmd, shell) is not None



# Generated at 2022-06-25 08:17:59.040696
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test 1 - test with simple command
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -n /bin/sh -c \'echo "hello"\''


# Generated at 2022-06-25 08:18:03.821506
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command('cat', 'shell') == "sudo -H -S -n cat"
    become_module_2 = BecomeModule()
    become_module_2.become_flags_1 = '-a'
    assert become_module_2.build_become_command('cat', 'shell') == "sudo -H -S -a cat"
    become_module_3 = BecomeModule()
    become_module_3.become_user_1 = 'ansible'
    assert become_module_3.build_become_command('cat', 'shell') == "sudo -H -S -n -u ansible cat"
    become_module_4 = BecomeModule()

# Generated at 2022-06-25 08:18:05.004442
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()


# Generated at 2022-06-25 08:18:11.467728
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=qwerty] password:'
    become_module._id = 'qwerty'
    become_module.get_option = lambda x: ''

    cmd_0 = 'whoami'
    shell_0 = False
    assert become_module.build_become_command(cmd_0, shell_0) == 'sudo -H -S -n -p "[sudo via ansible, key=qwerty] password:" whoami'

    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command(cmd_0, shell_0) == 'sudo -H -S -n -p "[sudo via ansible, key=qwerty] password:" whoami'

    become

# Generated at 2022-06-25 08:18:21.094345
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda option: None
    become_module_1.prompt = ''
    become_module_1._id = 'ansible-generated'
    cmd='ls -la /any/path'
    shell='/bin/sh'
    result = become_module_1.build_become_command(cmd, shell)
    assert result == 'sudo -H -S  ls -la /any/path'


# Generated at 2022-06-25 08:18:25.981503
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    print("Testing build_become_command")
    assert become_module_1.build_become_command('echo "Hello World"','1') == 'sudo -H -S -n echo "Hello World"'
    become_module_2 = BecomeModule(become_pass='test', become_user='test')
    assert become_module_2.build_become_command('echo "Hello World"','1') == 'sudo -H -S -p "test" -u test echo "Hello World"'
    become_module_3 = BecomeModule(become_flags='test', become_user='test')
    assert become_module_3.build_become_command('echo "Hello World"','1') == 'sudo test -u test echo "Hello World"'

# Generated at 2022-06-25 08:18:32.174270
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_pass = '1q2w3e'
    become_user = 'root'
    become_exe = 'sudo'
    become_flags = ''

    become_module = BecomeModule()

    become_module.set_option('become_pass', become_pass)
    become_module.set_option('become_user', become_user)
    become_module.set_option('become_exe', become_exe)
    become_module.set_option('become_flags', become_flags)

    cmd = 'ls -a /tmp'
    shell = '/bin/sh'

    result = become_module.build_become_command(cmd, shell)

    print(result)

test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:18:43.316935
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0._id = "8e0d75b0-c699-11e7-b822-f05032aab43b"
    become_module_0.prompt = "sudo password:"
    cmd_0 = "echo"
    shell_0 = "bash"
    ret_0 = become_module_0.build_become_command(cmd_0, shell_0)
    assert become_module_0.prompt == "[sudo via ansible, key=8e0d75b0-c699-11e7-b822-f05032aab43b] password:"

# Generated at 2022-06-25 08:18:54.501808
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bcm = BecomeModule()
    bcm.get_option=lambda : {}
    cmd = 'whoami'
    shell = '/bin/bash'
    assert bcm.build_become_command(cmd, shell) == 'sudo -H -S whoami'
    bcm.get_option=lambda x: {'become_flags':'--ask-pass --verbose'}[x]
    assert bcm.build_become_command(cmd, shell) == 'sudo --ask-pass --verbose whoami'
    bcm.get_option=lambda x: {'become_user':'root'}[x]
    assert bcm.build_become_command(cmd, shell) == 'sudo -H -S -u root whoami'

# Generated at 2022-06-25 08:18:58.571698
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = None

    shell = None

    assert (become_module_0.build_become_command(cmd, shell) == None)