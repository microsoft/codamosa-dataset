

# Generated at 2022-06-25 08:15:31.317378
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()

    become_module_0.set_options({'become_flags': '-H -S -n'})
    c = become_module_0.build_become_command('echo "123"', True)
    assert c == 'sudo -H -S -n sh -c \'echo "123"\''

    become_module_0.set_options({'become_flags': '-H -S'})
    c = become_module_0.build_become_command('echo "123"', False)
    assert c == 'sudo -H -S python -c \'import sys; sys.stdout.write("123")\''

    become_module_0.set_options({'become_flags': ''})

# Generated at 2022-06-25 08:15:33.516038
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'ls'
    shell = '/bin/bash'
    expected_cmd = 'sudo -H -S -n -u root ls'
    result_cmd = become_module_1.build_become_command(cmd, shell)
    assert result_cmd == expected_cmd

# Generated at 2022-06-25 08:15:43.669165
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:15:50.936909
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    expected_result_0 = 'sudo -H -S -n -p \"[sudo via ansible, key=a5deb5f5ccd4311f805de5c098d0f2c6] password:\" -u user0 \'echo -n anzu\'\''
    actual_result_0 = become_module_0.build_become_command('echo -n anzu', True)
    assert actual_result_0 == expected_result_0, "Failed test_BecomeModule_build_become_command"


# Generated at 2022-06-25 08:15:57.607909
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with options.become_user=bob and options.become_pass=secret
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda key: 'bob' if key == 'become_user' else 'secret' if key == 'become_pass' else None
    become_module_1._id = '06'
    assert become_module_1.build_become_command(cmd='ls', shell=False) == 'sudo -p "[sudo via ansible, key=06] password:" -u bob ls'


# Generated at 2022-06-25 08:16:07.581712
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert "/bin/sh -c 'sudo -S -p \"sudo via ansible, key='' password:\" -u root /bin/sh -c '\"'\"'echo BECOME-SUCCESS-fkyaatrrvfedhjxzdwkqixqcvq; /bin/sh -c 'ansible-tmp-1538166498.89-284745642917657'\"'\"''\"'\"'" == become_module_0.build_become_command('ansible-tmp-1538166498.89-284745642917657', '/bin/sh')


# Generated at 2022-06-25 08:16:14.366458
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    opts = {
        'become_exe': 'sudo',
        'become_flags': '-H -S -n',
        'become_pass': ''
    }
    become_module_1.get_option = lambda key: opts.get(key)
    become_module_1._build_success_command = lambda cmd, shell: '/bin/sh -c %s' % repr('echo "foo"')
    result = become_module_1.build_become_command('echo "foo"', '/bin/sh')
    assert result == "/bin/sh -c 'echo \"foo\"'", result
# /Unit test for method build_become_command of class BecomeModule


# Generated at 2022-06-25 08:16:20.316710
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Unit test for empty cmd
    become_module_1 = BecomeModule({'become_user': ''})
    cmd = ''
    shell = ''
    result = become_module_1.build_become_command(cmd, shell)
    assert result == ''

    # Unit test for non-empty cmd
    become_module_2 = BecomeModule({'become_user': ''})
    cmd = 'ls'
    shell = ''
    result = become_module_2.build_become_command(cmd, shell)
    assert result == "sudo -H -S -n /bin/sh -c 'ls'"

# Generated at 2022-06-25 08:16:27.066980
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = '/bin/true'
    shell = '/usr/bin/env'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n /usr/bin/env -c \'BECOME_METHOD=sudo /bin/true\''

# Generated at 2022-06-25 08:16:33.675253
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_3 = BecomeModule()
    become_module_3.get_option = lambda *a, **kw: 'password'
    become_module_3.prompt = '[sudo via ansible, key=key000] password:'
    become_module_3._build_success_command = lambda *a, **kw: 'command'
    cmd = 'test'
    shell = 'shell'
    result = become_module_3.build_become_command(cmd, shell)
    assert result == 'sudo -p "%s" -u test command' % (become_module_3.prompt)

# Generated at 2022-06-25 08:16:43.897868
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    result = become_module._build_become_command('cat /etc/motd', shell=False)
    assert result == 'sudo -H -S -n cat /etc/motd'



# Generated at 2022-06-25 08:16:52.955509
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    assert 'become_user' in become_module_0.options
    become_module_0.options.become_user = None
    cmd = 'test -r /etc/shadow'
    shell = '/bin/sh'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n test -r /etc/shadow'
    become_module_0.fail = 'sudo: a password is required'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n test -r /etc/shadow'
    assert become_module_0.prompt == '[sudo via ansible, key=None] password:'
    become_module_0.options.become_user = 'root'

# Generated at 2022-06-25 08:16:59.750562
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    comebecomecmd_var = become_module_0.get_option('become_exe')
    flags_var = become_module_0.get_option('become_flags')
    prompt_var = ''
    result = become_module_0.build_become_command(cmd='cmd_var', shell='shell_var')
    assert ' '.join([comebecomecmd_var, flags_var, prompt_var, become_module_0._build_success_command(cmd='cmd_var', shell='shell_var')]) == result


# Generated at 2022-06-25 08:17:10.522512
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('', '') == ''

# Generated at 2022-06-25 08:17:18.363907
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = []
    shell = ""
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n %s' % (shell)
    cmd = ''
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n %s' % (shell)

# Unit tests for class BecomeModule

# Generated at 2022-06-25 08:17:22.071031
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls -l'
    shell = '/bin/sh'
    become_module_0.build_become_command(cmd, shell)



# Generated at 2022-06-25 08:17:29.031076
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command('echo hello', 'sh') == 'sudo sh -c \'echo hello\''

    become_module_2 = BecomeModule(dict(become_user='frei', become_pass='supersecretpass'))
    assert become_module_2.build_become_command('echo hello', 'sh') == 'sudo -p "[sudo via ansible, key=%s] password:" -u frei sh -c \'echo hello\'' % become_module_2._id

# Generated at 2022-06-25 08:17:36.006173
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    args = dict(
        cmd='/bin/whoami',
        shell='/bin/sh',
        prompt='[sudo via ansible, key=Z8EVvZcJxokt1BM0ph0L8tjxaAVtFhSZ] password:',
    )
    actual = BecomeModule._build_become_command(**args)
    expected = 'sudo -p "[sudo via ansible, key=Z8EVvZcJxokt1BM0ph0L8tjxaAVtFhSZ] password:" /bin/whoami'
    assert actual == expected


# Generated at 2022-06-25 08:17:38.955105
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = "python -c 'print(1)'"
    shell = None
    expected = become_module.build_become_command(cmd, shell)
    assert type(expected) is str
    assert 'sudo' in expected

# Generated at 2022-06-25 08:17:44.803935
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    args = (["command"], "shell")
    kwargs = {}
    r = become_module.build_become_command(*args, **kwargs)
    assert isinstance(r, type(''))

# Generated at 2022-06-25 08:18:00.844950
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.prompt = 'prompt'
    cmd = r'"echo 1"'
    shell = 'sh'
    expected = [r'sudo -H -S -n -p "prompt" -u root "sh -c \'"\'\'""\'\'"\'echo 1"\'"\'""\'\'"\'"']
    actual = become_module_0.build_become_command(cmd, shell)
    assert actual == expected


# Generated at 2022-06-25 08:18:06.539735
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = 1234
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module.name = "sudo"
    # test first case
    cmd = "echo"
    shell = True
    expected = "sudo -H -S -n -p \" [sudo via ansible, key=1234] password:\"  /bin/sh -c 'echo'"
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected
    # test second case
    cmd = "echo"
    shell = False
    expected = "sudo -H -S -n -p \" [sudo via ansible, key=1234] password:\"  echo"
    actual = become_module.build_become_command

# Generated at 2022-06-25 08:18:12.761532
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'whoami'
    shell = '/bin/sh'
    becomecmd = 'sudo'
    flags = '-H -S -n'
    prompt = ''
    prompt_value = '[sudo via ansible, key=test_case_1] password:'
    ansible_become_pass = 'aslkdfjasdf'
    user = '-u root'
    expect_result = 'sudo -H -S -n  -u root sh -c whoami'
    user_value = ''
    become_module._id = 'test_case_1'

    # Case 1: without become_pass
    ret = become_module.build_become_command(cmd, shell)
    assert ret == expect_result

    # Case 2: become_pass is empty

# Generated at 2022-06-25 08:18:20.210896
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd, shell = ('ps -ef','/bin/sh')
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module_0._pid, 'ps -ef')

# Unit testing for function run

# Generated at 2022-06-25 08:18:29.215196
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'mycommand'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd,shell) == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-vzqfqyvyqjzgqfxigvaqfbzfgtj; mycommand\' || (echo BECOME-FAILURE-vzqfqyvyqjzgqfxigvaqfbzfgtj; exit 1)'


# Generated at 2022-06-25 08:18:35.401092
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command('whoami', True) == 'sudo -H -S -n whoami'
    assert become_module.build_become_command('whoami', False) == 'sudo -H -S -n whoami'
    assert become_module.build_become_command('/bin/whoami', True) == 'sudo -H -S -n /bin/whoami'
    assert become_module.build_become_command('/bin/whoami', False) == 'sudo -H -S -n /bin/whoami'
    become_module.name = 'su'
    assert become_module.build_become_command('whoami', True) == 'su -c whoami'

# Generated at 2022-06-25 08:18:44.593306
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.become_user = 'root'
    become_module.become_pass = None
    cmd = 'ls -la'
    shell = None
    assert become_module.build_become_command(cmd, shell) == 'sudo -H -S -n ls -la'

    become_module.become_pass = '123456'
    assert become_module.build_become_command(cmd, shell) == 'sudo -H -S -p "[sudo via ansible, key=become0] password:" -u root ls -la'

    become_module.become_exe = 'sudo'

# Generated at 2022-06-25 08:18:49.381840
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = {'password': ''}
    become_module_0.get_option = {'user': ''}
    become_module_0.get_option = {'flags': '-H -S -n'}
    become_module_0.get_option = {'executable': ''}
    cmd = 'cmd_value_1'
    shell = 'shell_value_2'
    assert become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:18:58.975672
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_obj_0 = BecomeModule()
    cmd_0 = 'foo'
    shell_0 = 'fish'
    become_module_obj_0.build_become_command(cmd_0, shell_0)

if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:19:05.080348
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()

    # test for base case when cmd is None
    assert become_module.build_become_command(None, True) == None

    # test for base case when cmd is not None
    assert become_module.build_become_command('ls -la', True) == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls -la')

    # test for case when become_pass is not None
    become_module.options['become_pass'] = 'password'

# Generated at 2022-06-25 08:19:16.551924
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = './bin/ansible'
    shell = None
    become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:19:26.249395
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "ls -l"
    shell = "/bin/bash"
    become_flags = "-H -S -n"
    become_module_0.get_option = create_mock(become_module_0.get_option, ['become_exe', 'become_flags'])
    become_module_0.get_option.become_exe = "sudo"
    become_module_0.get_option.become_flags = become_flags
    expected_output = "sudo -H -S -n ls -l"
    actual_output = become_module_0.build_become_command(cmd, shell)
    assert_equals(actual_output, expected_output)

# Generated at 2022-06-25 08:19:32.264544
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    FILL_VALUE = 'a'

    cmd = FILL_VALUE

# Generated at 2022-06-25 08:19:37.264554
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo test'
    shell = 'sh'
    cmd_out = become_module_0.build_become_command(cmd, shell)
    cmd_expected = 'sudo -H -S -n -p "[sudo via ansible, key=0e8e0d2360aad6440a5cb5c5a124f0c7] password:" -u root sh -c \'"echo test"\' && echo ansible-command > /dev/null 2>&1'
    assert cmd_out == cmd_expected



# Generated at 2022-06-25 08:19:48.664382
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # We initialize an instance of class BecomeModule
    become_module_0 = BecomeModule()

    become_module_0.set_options(
        connection='local',
        become_exe='become_exe_value',
        become_flags='become_flags_value',
        become_pass='become_pass_value',
        become_user='become_user_value',
        shell='shell_value'
    )

    become_module_0.set_options(direct={'no_log': True})

    shell = 'shell_value'
    cmd = 'cmd_value'


# Generated at 2022-06-25 08:19:57.075315
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    become_module_1.set_option('become_exe', 'sudo')
    become_module_1.set_option('become_flags', '-H -S -n')
    become_module_1.set_option('become_pass', 'ansible')
    become_module_1.set_option('become_user', 'root')

    cmd = 'whoami'
    shell = 'sh'
    actual_result = become_module_1.build_become_command(cmd, shell)

    expected_result = "sudo -H -S -n -u root 'sh -c '\"'\"'echo $0 && whoami'\"'\"''"

    assert actual_result == expected_result

# Generated at 2022-06-25 08:20:06.757835
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.prompt = None
    become_module_1.get_option = (lambda x: None)
    cmd = 'cmd'
    shell = False
    result = become_module_1.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n cmd'
    shell = True
    result = become_module_1.build_become_command(cmd, shell)
    assert result == "sudo -H -S -n sh -c 'cmd'"
    become_module_1.get_option = (lambda x: 'sudo_exe')
    result = become_module_1.build_become_command(cmd, shell)
    assert result == "sudo_exe -H -S -n sh -c 'cmd'"
    become

# Generated at 2022-06-25 08:20:14.737939
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1._id = '1'
    become_module_1.prompt = 'password: '
    become_module_1.get_option = lambda name: None
    cmd = 'ls'
    shell = '/bin/sh'
    expected_result = None
    assert become_module_1.build_become_command(cmd, shell) == expected_result

    become_module_2 = BecomeModule()
    become_module_2.name = 'sudo'
    become_module_2._id = '1'
    become_module_2.prompt = 'password: '
    become_module_2.get_option = lambda name: None
    cmd = 'ls'
    shell = '/bin/sh'

# Generated at 2022-06-25 08:20:19.253361
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    testcmd = "sudo -S -p 'SUDO password:' -u root echo 'success' && echo 'success'"
    become_module_1.get_option = lambda x: ''
    become_module_1._id = 'abc'
    become_module_1.prompt = ''
    result = become_module_1.build_become_command('echo "success"', shell='/bin/bash')
    assert result == testcmd


# Generated at 2022-06-25 08:20:24.614874
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    results = []
    # TEST CASE 1
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda x: None
    results.append(become_module_1.build_become_command('ls', '/bin/bash') == 'sudo ls')

    # TEST CASE 2
    become_module_2 = BecomeModule()
    become_module_2.get_option = lambda x: 'foo' if x == 'become_user' else 'bar'
    become_module_2._build_success_command = lambda x, y: "sucess"
    results.append(become_module_2.build_become_command('ls', '/bin/bash') == 'sudo -H -S -n -p "foo" -u bar sucess')

    return results

