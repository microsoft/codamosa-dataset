

# Generated at 2022-06-25 08:15:27.157241
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda arg: ''
    become_module.name = 'sudo'
    assert become_module.build_become_command('hostname', 'sh') == 'sudo -H -S -n hostname'

# Generated at 2022-06-25 08:15:36.797708
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.become_user = 'test_become_user_0'
    become_module_0.become_pass = 'test_become_pass_0'
    become_module_0.become_exe = 'test_become_exe_0'
    become_module_0.become_flags = 'test_become_flags_0'
    become_module_0.get_option = get_option_0
    cmd = 'test_cmd_0'
    shell = 'test_shell_0'

# Generated at 2022-06-25 08:15:43.290600
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # call build_become_command() of BecomeModule object
    cmd = become_module_0.build_become_command(['ls', '-l'], True)
    assert(cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\' ' % (become_module_0.success_key, 'ls -l'))

# Test case when become executable set to su
    become_module_0.get_option = mock.Mock(return_value = 'su')
    cmd = become_module_0.build_become_command(['ls', '-l'], True)

# Generated at 2022-06-25 08:15:46.547404
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.build_become_command('', False)

# Generated at 2022-06-25 08:15:53.434243
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:16:02.267834
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # create an instance of the class BecomeModule
    become_module = BecomeModule()
    # call the method build_become_command with an instance of the class Command (class Command is defined in common.py)
    # that has the following command and shell
    # 'command': '/usr/bin/ls', 'shell': '/bin/sh'
    becomecmd = become_module.build_become_command(new_command, shell='/bin/sh')

    # assert that build_become_command returns the following string, taking into account that the shell is /bin/sh and the command is /usr/bin/ls
    assert becomecmd == 'sudo /bin/sh -c \'echo BECOME-SUCCESS-wkdsilcovzfkvvefjpvmrfhkejirbwio; /usr/bin/ls\' '

# Generated at 2022-06-25 08:16:09.757235
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = '/bin/somecommand'
    shell = 'shell'
    become_module_0._build_success_command()
    become_module_0._build_success_command(cmd)
    become_module_0._build_success_command(cmd, shell)
    become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:16:13.262130
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()


# Generated at 2022-06-25 08:16:18.968005
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.shell = None
    become_module_0.prompt = None
    become_module_0.get_option.return_value = None
    cmd = "ls"
    shell = True
    assert become_module_0.build_become_command(cmd, shell) == 'sudo ls'
    return 'unit_test_success'


# Generated at 2022-06-25 08:16:22.802493
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda *args, **kwargs: None
    cmd = ''
    shell = ''
    expected = 'sudo '
    actual = become_module_1.build_become_command(cmd, shell)
    assert actual == expected


# Generated at 2022-06-25 08:16:42.139660
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Good test
    cmd = 'command'
    shell = True
    become_module.set_options(become_exe='test_become_exe', become_flags='test_become_flags', become_user='test_become_user', become_pass='test_become_pass')
    become_command = become_module.build_become_command(cmd=cmd, shell=shell)

# Generated at 2022-06-25 08:16:50.587886
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "ansible all -i ./ansible_hosts -m ping"
    shell = None
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -p "[sudo via ansible, key=77d3de8f2efa4485ae86da2aaed5d5f5c9954baa] password:" -u root "ansible all -i ./ansible_hosts -m ping"'



# Generated at 2022-06-25 08:16:53.978606
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = ['ls']
    shell = 'bash'
    result = become_module_1.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n  ls'


# Generated at 2022-06-25 08:16:58.037617
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo'
    shell = 'sh'
    res = become_module_0.build_become_command(cmd, shell)
    assert res == 'sudo -H -S -n sh -c \'echo\'', 'Test Failed'

# Testing if the function fails when become_user does not exist

# Generated at 2022-06-25 08:17:04.097533
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    args = {u'cmd': u'echo foo', u'shell': u'/bin/sh'}
    kwargs = {}
    become_module_0 = BecomeModule()
    return_value = become_module_0.build_become_command(**args)
    assert return_value == u'sudo /bin/sh -c \'echo "$(printf \'"\'"\'%s\'"\'"\' "$(printf \'"\'"\'%s\'"\'"\' \'"\'"\'"\'"\'echo foo\'"\'"\'"\'"\'))"\'', "Incorrect return value %s" % return_value


# Generated at 2022-06-25 08:17:13.381363
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Failure case : Invalid arguments
    cmd = ['ansible', '--version']
    assert become_module_0.build_become_command(cmd, None) != 'sudo -H -S -n -u  ansible --version'

    # Failure case : Missing values for required arguments
    cmd = 'ansible --version'
    assert become_module_0.build_become_command(cmd, None) != 'sudo -H -S -n -u  ansible --version'

    # Failure case : Invalid option for become_user
    become_module_0.set_become_user("")
    cmd = 'ansible --version'

# Generated at 2022-06-25 08:17:24.777667
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    commands = (u'ls -al', u'/usr/bin/python', u'', None)
    shell = (u'bash', u'zsh', u'', None)
    become_exe = (u'sudo', u'', None)
    become_user = (u'james', u'', None)
    become_flags = (u'-H -S -n', u'', None)
    become_pass = (u'321', u'', None, None)
    prompt = (u'[sudo via ansible, key=None] password:', u'', None, None)

# Generated at 2022-06-25 08:17:34.234787
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = 'ls'
    shell = '/bin/sh -c'
    becomecmd = 'sudo'
    flags = '-H -S -n'
    prompt = '-p "password:"'
    user = '-u root'
    successcmd = '/bin/sh -c \'echo BECOME-SUCCESS-qhfabmxdkqjgxmjizxbfddfll; /bin/sh -c ' + '\'' + cmd + '\'' + '\''
    #become_module_0 = BecomeModule()
    become_module_0 = BecomeModule(
        become_pass='password',
        become_user='root',
        become_exe='sudo',
        become_flags='-H -S -n'
    )
    becomecmd = 'sudo'

# Generated at 2022-06-25 08:17:41.899213
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = mock.Mock(side_effect=[None, '-H -S -n', '', None, None, 'root', None, None])
    become_module_1.prompt = None
    assert become_module_1.build_become_command('cmd', 'shell') == 'sudo -H -S -n  cmd'
    assert become_module_1.prompt is None
    become_module_1.get_option = mock.Mock(side_effect=[None, '-H -S -n', '', 'pwd', None, '', None, None])
    become_module_1.prompt = None

# Generated at 2022-06-25 08:17:50.812402
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    print(repr(become_module_0))

    assert(str(become_module_0.build_become_command('', False)) == 'sudo -H -S -n -u root  bash -c \'""\'')

    assert(str(become_module_0.build_become_command('', True)) == 'sudo -H -S -n -u root  sh -c \'""\'')

    assert(str(become_module_0.build_become_command('whoami', False)) == 'sudo -H -S -n -u root  bash -c \'whoami\'')

    assert(str(become_module_0.build_become_command('whoami', True)) == 'sudo -H -S -n -u root  sh -c \'whoami\'')

    become_

# Generated at 2022-06-25 08:18:02.184323
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo 1'
    shell = 'sh'
    result = become_module_0.build_become_command(cmd, shell)
    assert result == "'sudo' -H -S -n  'sh' -c 'echo 1'"


# Generated at 2022-06-25 08:18:14.751080
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1._id = 'ansible-become-test'
    become_module_1.prompt = None
    become_module_1._get_option = lambda x: None
    become_module_1._build_success_command = lambda x, y: x
    cmd = become_module_1.build_become_command("ls", True)
    assert cmd == 'sudo -H -S -n -p "sudo via ansible, key=ansible-become-test password:" ls'

    become_module_2 = BecomeModule()
    become_module_2._id = 'ansible-become-test'
    become_module_2.prompt = None
    become_module_2._get_option = lambda x: None
    become_module_2._build

# Generated at 2022-06-25 08:18:21.883924
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x:None
    become_module._build_success_command = lambda x:None
    become_module._id = '1'
    cmd = "pwd"
    shell = 'shell'
    become_module.prompt = None
    become_module.build_become_command(cmd,shell)
    assert become_module.build_become_command(cmd,shell) == 'sudo -H -S -n pwd'
    become_module.prompt = 'Prompt: '
    become_module.get_option = lambda x:x
    become_module.get_option('become_pass')
    become_module.build_become_command(cmd,shell)
    assert become_module.build_become_command(cmd,shell)

# Generated at 2022-06-25 08:18:30.335927
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "needle in a haystack"
    shell = "shell"
    result_1 = become_module_1.build_become_command(cmd, shell)
    assert result_1 == "sudo -H -S -n /bin/sh -c 'echo %s; %s'" % (become_module_1._SUCCESS_HASH, cmd)

    become_module_2 = BecomeModule()
    cmd = "needle in a haystack"
    shell = "shell"
    become_module_2.prompt = "[sudo via ansible, key=%s] password:" % become_module_2._id
    result_2 = become_module_2.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:18:37.843965
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    shell = None
    become_module_0.set_become_plugin_options({'become_exe':'become_exe','become_flags':'become_flags','become_pass':'become_pass','become_user':'become_user'})
    retVal = become_module_0.build_become_command(cmd, shell)
    assert retVal == 'sudo -H -S -n -p "[sudo via ansible, key=None] password:" -u become_user succeed_without_changes; if [ $? -eq 0 ]; then echo \'BECOME-SUCCESS-njvgaqhugfqcqzoqkqwvzcierdtyycoe\n\'; fi'

# Unit

# Generated at 2022-06-25 08:18:40.940969
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_3 = BecomeModule()
    test_case_3 = become_module_3.build_become_command('test_cmd', 'sh')
    assert test_case_3 == 'sudo -H -S -n test_cmd'

# Generated at 2022-06-25 08:18:45.912248
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    # Testing with a string value assigned to cmd
    # Testing with a string value assigned to shell
    # Testing with a string value assigned to prompt
    cmd = 'sudo'
    shell = 'echo'
    prompt = 'sudo'
    expected_response = 'sudo -H -S -n -p "sudo"  echo'
    become_module_0.prompt = prompt
    become_module_0.get_option = lambda s: True
    answer = become_module_0.build_become_command(cmd, shell)
    assert answer == expected_response


# Generated at 2022-06-25 08:18:52.040403
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = []
    shell = None
    assert become_module_0.build_become_command(cmd, shell) == cmd, \
        'Expected {} but returned {}'.format(cmd, become_module_0.build_become_command(cmd, shell))
    cmd = ["echo", "first", "second"]
    shell = None
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n echo first second', \
        'Expected {} but returned {}'.format(['sudo -H -S -n echo first second'], become_module_0.build_become_command(cmd, shell))
    cmd = []
    shell = "/bin/sh"

# Generated at 2022-06-25 08:19:00.983218
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo foo"
    shell = None
    assert become_module_0.build_become_command(cmd=cmd, shell=shell) == "sudo  -H -S  -np '[sudo via ansible, key=a23c6d1500ef6ca213c6a5e5c5ce5e5f] password:'  -u root /bin/sh -c 'echo foo' && echo 'ansible_become_success' || echo 'ansible_become_failed'"
    assert become_module_0.prompt == '[sudo via ansible, key=a23c6d1500ef6ca213c6a5e5c5ce5e5f] password:'

# Generated at 2022-06-25 08:19:06.308168
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    # Calling method build_become_command with argument cmd = abcd and shell = True
    result = become_module_1.build_become_command("abcd", True)

    # Asserting the result of the method with expected value
    expected_value = "sudo -H -S -n abcd"
    assert result == expected_value

# Generated at 2022-06-25 08:19:31.440320
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'echo'
    shell = '/bin/sh'
    become_module_1._id = '12345'
    become_module_1._verbose = True
    become_module_1.prompt = None
    become_module_1.get_option = lambda opt_name: None
    become_module_1._build_success_command = lambda cmd, shell: cmd
    assert become_module_1.build_become_command(cmd, shell) == 'sudo -p "[sudo via ansible, key=12345] password:" echo'
    become_module_2 = BecomeModule()
    become_module_2._id = '12345'
    become_module_2._verbose = True
    become_module_2.prompt = None

# Generated at 2022-06-25 08:19:37.757563
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_2 = BecomeModule()

    raise NotImplementedError("Test cases for BecomeModule.build_become_command() are not implemented.")

if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:19:42.014812
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    # test case build_become_command_0
    cmd = None
    shell = None
    assert become_module_1.build_become_command(cmd, shell) == None



# Generated at 2022-06-25 08:19:45.276291
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command('', '') == 'sudo -H -S -n /bin/sh -c %s'

# Generated at 2022-06-25 08:19:49.579525
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = MagicMock()
    become_module_0.get_option.return_value = None
    cmd = 'cmd'
    shell = 'shell'
    assert become_module_0.build_become_command(cmd, shell) == 'cmd'


# Generated at 2022-06-25 08:19:58.048899
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo test'
    shell = 'sh'
# Method invocation
    result_1 = become_module_0.build_become_command(cmd, shell)
    print(result_1)
    assert result_1 == 'sudo -H -S -n sh -c \'' + cmd + '\''

# Example test cases as string literals
    result_2 = become_module_0.build_become_command('echo test', 'sh')
    print(result_2)
    assert result_2 == 'sudo -H -S -n sh -c \'echo test\''
    result_3 = become_module_0.build_become_command('echo test', 'csh')
    print(result_3)

# Generated at 2022-06-25 08:20:06.908163
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()

    test_options = [{ 'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root', 'become_pass': None }, { 'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root', 'become_pass': None }]

    test_args = [{ 'cmd': 'whoami', 'shell': False }, { 'cmd': 'whoami', 'shell': False }]

    test_return = [{ 'return': 'sudo -H -S -n -u root /bin/sh -c \'whoami\'' }, { 'return': 'sudo -H -S -n -u root /bin/sh -c \'whoami\'' }]


# Generated at 2022-06-25 08:20:14.788193
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    test_cmd = ['cat', '/tmp/foo']
    result = become_module.build_become_command(test_cmd, 'sh')
    assert result == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-vaqdvepvlvaldsrnfgskbkdcyqvnwjss; /usr/bin/python && sleep 0\'; ret=$?; test $ret -eq 0 -o $ret -eq 1; ( exit $ret )'

    test_cmd = ['cat', '/tmp/foo']
    result = become_module.build_become_command(test_cmd, '/bin/bash')

# Generated at 2022-06-25 08:20:18.990667
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    c = become_module_1.build_become_command('foo', False)
    assert c == 'sudo -H -S -n foo'


# Generated at 2022-06-25 08:20:28.330725
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  # Test case 0:
  # Test case: 
  #   method: build_become_command
  #   cmd: 
  #   shell: 
  #   build_become_command: None
  #   cmd_prefix: 
  #   cmd_suffix: 
  #   runas_prompt: None
  #   become_prompt: None
  #   become_user: None
  #   become_pass: None
  #   become_exe: None
  #   become_flags: None
  #   prompt_success: None
  #   stdin_add_newline: None

  become_module_0 = BecomeModule()
  cmd_0 = None
  shell_0 = None
  build_become_command_0 = None
  cmd_prefix_0 = None
  cmd_

# Generated at 2022-06-25 08:21:11.575462
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Replace ansible.plugins.become.BecomeBase().get_option()
    ansible.plugins.become.BecomeBase.get_option = lambda self, option: {'ansible_sudo_user': 'alice'}.get(option)
    # Test 'cmd' argument of build_become_command() method
    cmd = 'ls'
    # Test 'shell' argument of build_become_command() method
    shell = '/usr/local/bin/bash'
    # Test call to build_become_command() method
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n -u alice "/usr/local/bin/bash -c \'ls\'"'


# Generated at 2022-06-25 08:21:17.979758
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """
    build_become_command(self, cmd, shell) method of class BecomeModule
    """
    become_module_1 = BecomeModule()
    # Trigger a TypeError
    try:
        become_module_1.build_become_command(cmd, shell)
    except TypeError:
        pass

if __name__ == "__main__":
    import sys
    import doctest
    failed, _ = doctest.testmod()
    if failed ==0:
        print("*** ALL TESTS PASSED ***")
    sys.exit(failed)

# Generated at 2022-06-25 08:21:25.567561
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ''
    shell = False
    add_script_wrapper = False
    become_module_0.build_become_command(cmd, shell, add_script_wrapper)

# Generated at 2022-06-25 08:21:35.969762
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test 1
    become_module_1 = BecomeModule()
    
    become_module_1.get_option = lambda x: 'sudo'
    become_module_1.set_option = lambda x, y: None
    become_module_1._build_success_command = lambda x, y: x
    become_module_1.prompt = 'prompt'
    become_module_1.name = 'name'
    
    assert become_module_1.build_become_command('ls -l', 'shell') == 'sudo -p "prompt" ls -l'


# Generated at 2022-06-25 08:21:42.081593
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
# Test failure case with no parameters
    assert become_module_1.build_become_command() == None
# Test failure case with invalid parameters
    data = {'a': 'b'}
    assert become_module_1.build_become_command(**data) == None
    data = {'a': 'b', 'c': 'd'}
    assert become_module_1.build_become_command(**data) == None
    data = {'a': 'b', 'c': 'd', 'e': 'f'}
    assert become_module_1.build_become_command(**data) == None
    data = {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}
    assert become_module_1

# Generated at 2022-06-25 08:21:53.666814
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.set_options(direct={'become_pass': 'secret', 'become_user': 'newuser'})
    assert become_module_1.build_become_command('ls', 'sh') == 'sudo -p "[sudo via ansible, key=%s] password:" -u newuser sh -c \'echo BECOME-SUCCESS-ofjiqvcvbbbvsoivoqhjtwxjxnrqbbkwd; %s\'' % (become_module_1._id, 'ls')
    become_module_2 = BecomeModule()
    become_module_2.set_options(direct={'become_pass': 'secret', 'become_user': 'newuser'})
    assert become_module_2.build_become

# Generated at 2022-06-25 08:22:02.266617
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_command = 'echo "Hello"'
    shell = '/bin/sh'
    become_exe = 'sudo'
    become_flags = '-H -S -n'
    become_user = 'root'
    become_pass = ''

    become_module = BecomeModule()
    become_module.set_option('become_exe', become_exe)
    become_module.set_option('become_flags', become_flags)
    become_module.set_option('become_user', become_user)
    become_module.set_option('become_pass', become_pass)

    returned_value = become_module.build_become_command(become_command, shell)
    assert returned_value == 'sudo -H -S -n echo "Hello"'

# Test case where Ansible user is not 'root

# Generated at 2022-06-25 08:22:04.590027
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    # Expected result for input "self" = become_module_1, with empty content arg: cmd & shell
    expected_output = ''
    output = become_module_1.build_become_command(None, None)
    assert output == expected_output


# Generated at 2022-06-25 08:22:09.414982
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    assert become_module_1.build_become_command("ls -l", None) == "sudo  -H -S -n  ls -l"


# Generated at 2022-06-25 08:22:15.507169
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'test'
    shell = 'test'
    become_module_1.build_become_command(cmd, shell)
    become_module_1.fail = ['test']
    become_module_1.missing = ['test']
    become_module_1.build_become_command(cmd, shell)