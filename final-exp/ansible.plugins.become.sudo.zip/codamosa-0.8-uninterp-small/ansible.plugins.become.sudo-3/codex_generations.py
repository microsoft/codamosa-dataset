

# Generated at 2022-06-25 08:15:31.848296
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule(
        become_exe='become_exe_1',
        become_flags='become_flags_1',
        become_pass='become_pass_1',
        become_user='become_user_1',
        shell='shell_1'
    )

    result = become_module_1.build_become_command(
        cmd='cmd_1',
        shell='shell_2'
    )

    # AssertionError: Expected 'cmd_1' to equal 'sudo -n -u become_user_1 -p "sudo via ansible, key=become_flags_1] password: " shell_2'
    #               cmd_1
    #               -
    #               sudo -n -u become_user_1 -p "sudo via ansible, key=become

# Generated at 2022-06-25 08:15:41.644672
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ansible'
    shell = '/bin/sh'

    # Mock arguments
    options = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root'}
    become_module_0._options = options

    # Invoke method
    ansible_become_user = become_module_0.get_option('become_user')
    ansible_become_exe = become_module_0.get_option('become_exe')
    ansible_become_flags = become_module_0.get_option('become_flags')
    ansible_become_password = become_module_0.get_option('become_password')
    ansible_become_prompt = become

# Generated at 2022-06-25 08:15:49.457801
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """Check that method build_become_command returns expected output."""
    become_module = BecomeModule()
    become_module.get_option = lambda x: ''
    become_module._build_success_command = lambda x,y: '^' + x + '$'
    assert become_module.build_become_command('the command', '/bin/sh') == 'sudo -H -S -n ^the command$'

# Generated at 2022-06-25 08:15:58.946818
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_2 = BecomeModule()
    become_module_3 = BecomeModule()
    become_module_4 = BecomeModule()

#    assert become_module_0.build_become_command(cmd, shell) == , 'Failed test build_become_command'
#    assert become_module_1.build_become_command(cmd, shell) == , 'Failed test build_become_command'
#    assert become_module_2.build_become_command(cmd, shell) == , 'Failed test build_become_command'
#    assert become_module_3.build_become_command(cmd, shell) == , 'Failed test build_become_command'
#    assert become_module_4.build_become_command(cmd,

# Generated at 2022-06-25 08:16:02.619849
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    retval = become_module_0.build_become_command('/usr/bin/python','shell')
    print(retval)
    assert retval == 'sudo '
    assert retval == '/usr/bin/python'
    assert retval == 'shell'



# Generated at 2022-06-25 08:16:09.780975
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_obj = BecomeModule()
    cmd = "cmd"
    shell = "shell"
    expected_build_become_command_result = "sudo -H -S -n"
    build_become_command_result = become_module_obj.build_become_command(cmd, shell)

    assert expected_build_become_command_result == build_become_command_result

# Generated at 2022-06-25 08:16:16.056786
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.become_pass = None
    become_module_0.become_user = None
    assert become_module_0.build_become_command('sudo', shell=False) == 'sudo'

# Generated at 2022-06-25 08:16:23.499252
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.build_become_command('cmd', 'shell_type')

results = []  # type: List[TestCaseResults]

results.append(
    InfraOutput(
        host='host',
        cmd='sudobecomeplugin_build_become_command.py',
        output='''<class 'ansible.plugins.become.sudo.BecomeModule'>
Method: build_become_command''',
    )
)

#
# Run all tests
#


# Generated at 2022-06-25 08:16:26.691208
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command(['/bin/ls', '-la'], 'bash') == 'sudo -SHn /bin/ls -la'


# Generated at 2022-06-25 08:16:29.770427
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'id'
    become_module.get_option = mock.MagicMock()
    become_module.get_option.return_value = ''
    res = become_module.build_become_command(cmd, True)
    assert res == 'sudo -H -S -n -p "[sudo via ansible, key=] password:" id'

# Generated at 2022-06-25 08:16:39.112300
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'somecmd'
    shell = False
    assert become_module_1.build_become_command(cmd, shell) == 'sudo -H -S -n -p "someprompt" -u someuser someothercmd'

# Generated at 2022-06-25 08:16:47.264363
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_exe = 'become_exe'
    become_flags = 'become_flags'
    become_pass = False
    become_user = 'become_user'
    cmd = 'cmd'
    env = 'env'
    prompt = 'prompt'
    shell = 'shell'
    success_cmd = 'success_cmd'
    success_command = 'success_command'

    become_module_0 = BecomeModule()
    become_module_0.get_option = Mock(return_value=become_exe)
    become_module_0.get_option = Mock(return_value=become_flags)
    become_module_0.get_option = Mock(return_value=become_pass)
    become_module_0.get_option = Mock(return_value=become_user)
    become

# Generated at 2022-06-25 08:16:50.272007
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:16:54.411814
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    actual_result = become_module.build_become_command("command", "shell")
    expected_result = "sudo -H -S sh -c 'echo BECOME-SUCCESS-iunrncqsmtmmjdfcnvmgmqmsqg; command'"
    assert actual_result == expected_result


# Generated at 2022-06-25 08:17:00.783941
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd=''
    shell=''
    assert become_module_0.build_become_command(cmd,shell) == None
    cmd=''
    shell=''
    assert become_module_0.build_become_command(cmd,shell) == None
    cmd=''
    shell=''
    assert become_module_0.build_become_command(cmd,shell) == None
    cmd=''
    shell=''
    assert become_module_0.build_become_command(cmd,shell) == None

# Generated at 2022-06-25 08:17:10.569335
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.set_options({'become_user': 'root', 'become_pass': 'pass', 'become_exe': 'sudo'})
    become_module.prompt = '[sudo via ansible, key=8dd7c19ac11ae86efab7c5b36e8dcdc2] password:'

    # Normal call of build_become_command with success expected
    cmd = "hostname"
    result = become_module.build_become_command(cmd=cmd, shell=None)

# Generated at 2022-06-25 08:17:21.286754
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._build_success_command = lambda cmd, shell: cmd
    assert become_module.build_become_command('ls -la /', True) == 'sudo -H -S -n ls -la /'
    become_module.become_flags='-E'
    assert become_module.build_become_command('ls -la /', True) == 'sudo -E ls -la /'
    become_module.become_flags='-E -n'
    assert become_module.build_become_command('ls -la /', True) == 'sudo -E ls -la /'
    become_module.become_flags='-n -E'

# Generated at 2022-06-25 08:17:26.654270
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = ["ls","/"]
    shell = "shell"
    becomecmd = become_module_0.build_become_command(cmd, shell)
    assert becomecmd == "sudo -H -S -n -p \"Sorry, try again.\" -u root shell -c 'ls /'"

# Generated at 2022-06-25 08:17:29.169728
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert(become_module_0.build_become_command("", "") == "")


# Generated at 2022-06-25 08:17:35.812357
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "whoami"
    shell = "bash"
    expected_output = "sudo -H -S -n -p \"[sudo via ansible, key=%s] password:\" -u root whoami" % become_module_1._id
    actual_output = become_module_1.build_become_command(cmd, shell)
    assert expected_output == actual_output, "Test Failed: expected output: " + expected_output + " does not match with the actual output: " + actual_output


# Generated at 2022-06-25 08:17:52.527100
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with user and password
    become_module_1 = BecomeModule()
    become_module_1.set_options(dict(become_user='test_user', become_pass='test_pass'))

# Generated at 2022-06-25 08:17:58.899476
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Test function build_become_command of class BecomeModule with command_1

    # Test for command_1 and shell_1
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command(command_1, shell_1) == 'sudo echo "Hello"'
    # Test for command_1 and shell_2
    become_module_2 = BecomeModule()
    assert become_module_2.build_become_command(command_1, shell_2) == 'sudo -s -c \'echo "Hello"\''
    # Test for command_1 and shell_3
    become_module_3 = BecomeModule()
    assert become_module_3.build_become_command(command_1, shell_3) == 'sudo -c "echo \\"Hello\\""'
    # Test for command

# Generated at 2022-06-25 08:18:03.568517
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()


# Generated at 2022-06-25 08:18:07.907614
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bmc = BecomeModule()
    bmc.get_option = lambda x: None
    assert bmc.build_become_command('ls', None) == 'sudo -H -S -n ls'
    bmc.get_option = lambda x: '-u test_user' if x == 'become_user' else None
    assert bmc.build_become_command('ls', None) == 'sudo -H -S -n -u test_user ls'
    bmc.get_option = lambda x: '-p "test_prompt" -u test_user' if x == 'become_flags' else None
    assert bmc.build_become_command('ls', None) == 'sudo -p "test_prompt" -u test_user ls'

# Generated at 2022-06-25 08:18:11.543397
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = mock.MagicMock(return_value=None)
    become_module.get_option.__getitem__ = mock.MagicMock(return_value=None)

    become_module._id = 'x'

    actual_output = become_module.build_become_command('test_cmd', shell='test_shell')

    assert actual_output == 'sudo -H -S test_cmd'


# Generated at 2022-06-25 08:18:19.501754
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    args = {'cmd': 'rhel'}
    kwargs = {'shell': 'bash'}
    except_value = "'NoneType' object is not callable"
    try:
        become_module.build_become_command(**args, **kwargs)
    except TypeError as e:
        assert str(e) == except_value

# Generated at 2022-06-25 08:18:28.945199
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Test build_become_command when cmd is none
    cmd = None
    shell = None
    assert become_module_0.build_become_command(cmd, shell) is None
    # Test build_become_command when cmd is not none
    cmd = 'echo hello'
    shell = '/bin/sh'
    become_module_0.get_option = lambda x: None
    become_module_0.name = 'sudo'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo  -S -n /bin/sh -c \'"\'\'"\'echo hello\'"\'\'"\''
    become_module_0.become_exe = 'doas'

# Generated at 2022-06-25 08:18:33.541275
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'echo "hello world"'
    shell = False
    result = become_module_1.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u root echo "hello world"' % (become_module_1._id)


# Generated at 2022-06-25 08:18:38.275508
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = str()
    shell = False

    # Invoke method
    become_module_0.build_become_command(cmd, shell)
    from pprint import pprint    
    pprint(str(cmd))



# Generated at 2022-06-25 08:18:46.002137
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # default options
    become_module_0.get_option = lambda x: None
    cmd = "ls /"
    result = become_module_0.build_become_command(cmd, None)
    assert result == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-icyydbwzqfrqkqcqxiwxvxkajgvcqhui; %s\'' % (cmd)

    # with flag
    become_module_0.get_option = lambda x: 'sudo' if x == 'become_exe' else '-H -S -n' if x == 'become_flags' else None
    cmd = "ls /"

# Generated at 2022-06-25 08:19:09.682248
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "test"
    shell = "sh"
    assert become_module_1.build_become_command(cmd, shell)
    cmd = ""
    shell = ""
    assert become_module_1.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:19:16.258997
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'cd /root'
    become_module_0.prompt = '[sudo via ansible, key=become_pass] password:'
    become_module_0.get_option = MagicMock(return_value=False)
    become_module_0.get_option.side_effect = [become_module_0.name, '-H -S', become_module_0.prompt, become_module_0.name]
    assert become_module_0.build_become_command(cmd, True) == "sudo -H -S -p \"%s\" %s" % (become_module_0.prompt, become_module_0.name)



# Generated at 2022-06-25 08:19:23.807755
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    print('1 cmd = "", shell = ""; expected = "" ')
    cmd = ""
    shell = ""
    actual = become_module.build_become_command(cmd, shell)
    expected_actual = ""
    print('actual = ', actual, '; expected = ', expected_actual)
    assert actual == expected_actual

    print('2 cmd = "ls -l", shell = ""; expected = "sudo -p "[sudo via ansible, key=%s] password: " -u root ls -l"')
    cmd = "ls -l"
    shell = ""
    actual = become_module.build_become_command(cmd, shell)
    expected_actual = 'sudo -p "[sudo via ansible, key=%s] password: " -u root ls -l'
    print

# Generated at 2022-06-25 08:19:27.726917
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = "123"
    become_module.prompt = "password:"
    become_module.get_option = lambda x: None
    assert become_module.build_become_command("test", "shell") == "'/usr/bin/sudo' '' '-p \"password:\"' ' test'"


# Generated at 2022-06-25 08:19:29.599878
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "command1"

    # Call method
    result = become_module_0.build_become_command(cmd, None)
    assert "sudo command1" == result


# Generated at 2022-06-25 08:19:36.328371
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    user = 'cred_user'
    # Empty password
    become_module_0.set_options(become_pass='')
    become_module_0.set_options(become_user=user)
    try:
        retval = become_module_0.build_become_command('cd /var/tmp; ls', None)
    except:
        retval = False
    assert retval == 'sudo -H -S -n -u cred_user cd /var/tmp; ls'


# Generated at 2022-06-25 08:19:46.273276
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0._id = "fake_id"
    become_module_0.prompt = "fake_prompt"
    cmd = "fake_command"
    shell = "fake_shell"
    result = become_module_0._build_success_command("fake_command", "fake_shell")
    expected_result = "bash -c 'echo %s; %s'" % (become_module_0._id, become_module_0._build_success_command(cmd, shell))
    assert result == expected_result


# Generated at 2022-06-25 08:19:49.746069
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ''
    shell = True
    become_module_0.build_become_command(cmd, shell)
    actual = become_module_0.prompt
    assert actual == '[sudo via ansible, key=fake-id-0] password:'


# Generated at 2022-06-25 08:19:56.214970
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    #
    test_case = dict(
        cmd=['/bin/sh', '-c', '! true'],
        succeed_without_password=True,
    )
    #
    for k in test_case:
        if k not in ['cmd']:
            become_module_0.set_option(k, test_case[k])
    #
    result = become_module_0.build_become_command(**test_case)
    assert result == "sudo -H -S -n /bin/sh -c '! true'"


# Generated at 2022-06-25 08:19:58.056331
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    pass

# Generated at 2022-06-25 08:20:28.354866
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    become_module_0 = BecomeModule()

    var_0 = become_module_0.build_become_command(str_0, bytes_0)
    var_1 = become_module_0.build_become_command(str_0, var_0)
    var_2 = become_module_0.build_become_command(bytes_0, bytes_0)
    var_3 = become_module_0.build_become_command(var_1, var_2)
    assert var_0 == var_1
    assert not var_2 == var_

# Generated at 2022-06-25 08:20:38.643957
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'

    become_module_0 = BecomeModule()
    assert become_module_0.get_option('become_exe') is None
    assert become_module_0.get_option('become_flags') is None
    assert become_module_0.get_option('become_pass') is None
    assert become_module_0.get_option('become_user') is None
    assert become_module_0.prompt == ''
    var_0 = become_module_0.build_become_command(str_0, bytes_0)

# Generated at 2022-06-25 08:20:41.916627
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Case 0
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    var_0 = become_module_0.build_become_command(str_0, bytes_0)


# Generated at 2022-06-25 08:20:47.083770
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = ';\x1c\x0c\x1c\x04\x04'
    bytes_0 = b'\x81\x13\x8b{\xfe\xee\xf6\xb5\x8c'
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(str_0, bytes_0)


# Generated at 2022-06-25 08:20:54.429504
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(str_0, bytes_0)
    assert var_0 == None


# Generated at 2022-06-25 08:20:59.515447
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    var_0 = become_module_0.build_become_command(str_0, bytes_0)



# Generated at 2022-06-25 08:21:06.439307
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(str_0, bytes_0)


# Generated at 2022-06-25 08:21:10.903583
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # TODO: implement unit test build_become_command
    become_module_0 = BecomeModule()
    # var_0 = become_module_0.build_become_command()
    # assert var_0 == ...,  "Return value not as expected"


# Generated at 2022-06-25 08:21:18.964572
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    str_1 = '\x0b{`nHd\x0bcN'
    bytes_1 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    become_module_0 = BecomeModule()
    var_28 = become_module_0.get_option('become_exe')
    var_20 = become_module_0.get_option('become_flags')
    var_39 = become_module_0.get_option('become_pass')
    var_

# Generated at 2022-06-25 08:21:23.331797
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    var_0 = become_build_become_command(str_0, bytes_0)

# Generated at 2022-06-25 08:22:11.372422
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    test_case_0()


# Generated at 2022-06-25 08:22:19.635045
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    var_0 = become_module_0.build_become_command(str_0, bytes_0)
    assert var_0 == 'sudo -H -S -n -p "sudo via ansible, key=f7676e13-dce7-43c1-8f25-a85b1f79d02a password:" -u root echo \"$SHELL\" && echo \"$HOME\"', 'Failed'


# Generated at 2022-06-25 08:22:20.733517
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_0()


# Generated at 2022-06-25 08:22:23.022453
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with str and test with bytes
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(str_0, bytes_0)


# Generated at 2022-06-25 08:22:25.203519
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_0()
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command()


# Generated at 2022-06-25 08:22:31.707300
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    obj_0 = BecomeModule()
    become_exe_0 = 'sudo'
    flags_0 = '-H -S -n'
    become_pass_0 = 'True'
    prompt_0 = '-p "Sorry, try again."'
    become_user_0 = 'root'
    cmd_0 = 'date'
    shell_0 = 'True'
    var_0 = obj_0.build_become_command(cmd_0, shell_0)


# Generated at 2022-06-25 08:22:42.762241
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    seq_0 = iter(range(3, 9))
    assert become_module_0.build_become_command('sudo -u root -n -H -S', '%s') == 'sudo -u root -n -H -S /bin/sh -c "unset BASH_ENV; unset ENV; echo BECOME-SUCCESS-zchcrjnqxqxqcqfxzknpsdkkwluyxzgm;"'

# Generated at 2022-06-25 08:22:52.294334
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    opts = {
        "become_exe": "sudo",
        "become_flags": "",
        "become_pass": "root",
        "become_user": ""
    }
    cmd = "whoami"
    shell = "sh"
    return_value = become_module_0.build_become_command(cmd, shell)
    assert return_value == "sudo -p \"sudo via ansible, key=%s] password:\" %s" % (become_module_0._id, cmd)

if __name__ == "__main__":
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:22:56.720932
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'

    become_module_0 = BecomeModule()

    var_0 = become_module_0.build_become_command(str_0, bytes_0)
    print(var_0)

# Generated at 2022-06-25 08:23:03.090798
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    var_0 = become_module_0.build_become_command(str_0, bytes_0)
    assert var_0 == 'sudo -n /bin/sh -c \'echo PLySkXsLsDLRnL-W-aYY; echo PLySkXsLsDLRnL-W-aYY\''
    str_1 = '\x0b{`nHd\x0bcN'

# Generated at 2022-06-25 08:24:40.821169
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import random

    for i in range(1000):
        cmd = ''


# Generated at 2022-06-25 08:24:47.248237
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module_0 = get_become_plugin('sudo')
    become_module_0 = BecomeModule()
    var_0 = become_module_0.is_become_needed()
    become_module_0.run(None, None)
    var_1 = become_module_0.get_option('become_exe')
    var_2 = become_module_0.get_option('become_flags')
    str_0 = '\x0b{`nHd\x0bcN'
    bytes_0 = b'oH\x9c\x83\xeaQ\x0f\xf9\xd0*\xdf\xed'
    var_3 = become_module_0._build_success_command(str_0, bytes_0)

# Generated at 2022-06-25 08:24:52.361487
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    str_0 = '\x07\x03|\x00\x1b\x07\x17\x1d\x0c\x07\x00\x03\x0c'

# Generated at 2022-06-25 08:24:58.547532
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    '''
    Tests that the method build_become_command correctly builds 
    a string to be used in become
    '''
    sudo_become_plugin_dict = {'password': '',
                                     'user': 'casper',
                                     'flags': '',
                                     'executable': ''}
    privilege_escalation_dict = {'become_flags': '',
                                     'become_user': 'casper',
                                     'become_exe': 'sudo'}
    plugin_options_dict = {'esc': 'sudo', 
                                 'p' : '',
                                 'u': 'casper'}
    ansible_become_password = ''
    cmd = 'ls'
    shell = 'sh'

# Generated at 2022-06-25 08:25:08.478396
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'sudo'
    shell = 'bash'
    var_0 = become_module_0.build_become_command(cmd, shell)
    assert var_0 == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u root bash -c \'echo BECOME-SUCCESS-biwzemiqjgkttbuklhlojldhufyhobta; /bin/bash -c "echo BECOME-SUCCESS-biwzemiqjgkttbuklhlojldhufyhobta; /usr/bin/python && exit 0"\'' % become_module_0._id

    cmd = 'sudo'
    shell = 'bash'
    become_module_0.set_

# Generated at 2022-06-25 08:25:17.910376
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test cases
    str_1 = ''
    bytes_1 = b'\x0f\x9cG\x1a\x0b\x8f\xbf\xda\x1f\x1e\x15M\x80\xc6\xec\x0e\xc9X'
    become_module_1 = BecomeModule()
    var_1 = become_build_become_command(str_1, bytes_1)

    str_2 = 'c\xeb[\x1e'
    bytes_2 = b'\x11\x0c\xe3\x91'
    become_module_2 = BecomeModule()
    var_2 = become_build_become_command(str_2, bytes_2)


# Generated at 2022-06-25 08:25:25.409629
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = 'y\x0b'
    bytes_0 = b'\x17\x15\xcc\xffH$\xee\xfc\xbb\x17\xe8\xed'
    var_0 = become_module_0.build_become_command(str_0, bytes_0)

