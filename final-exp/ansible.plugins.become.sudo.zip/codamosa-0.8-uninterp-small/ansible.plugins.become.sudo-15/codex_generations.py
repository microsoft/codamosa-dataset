

# Generated at 2022-06-25 08:15:31.487133
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule(
        {'become_exe': 'become',
         'become_flags': '-kKt',
         'prompt': 'prompt',
         'become_pass': 'False',
         'become_user': 'be_user',
         'ansible_become_password': 'dat_pass'},
        1
    )
    expected = 'become -kKt -p "prompt" -u be_user bash -c "echo BECOME-SUCCESS-pjqerqgqfwpvuthkmihqinwjldkulgjy" && sleep 0"'
    assert become_module_1.build_become_command(None, None) == expected


# Generated at 2022-06-25 08:15:37.873748
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "test"
    shell = ""
    become_module_1.build_become_command(cmd, shell)
    assert become_module_1 is not None


# Generated at 2022-06-25 08:15:46.972475
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    # test with just_a_command
    arg_0 = 'just_a_command'
    arg_1 = False
    expected_output = '/usr/bin/sudo -H -S -n just_a_command'
    assert become_module_1.build_become_command(arg_0, arg_1) == expected_output
    # test with just_a_command
    arg_0 = 'just_a_command'
    arg_1 = False
    expected_output = '/usr/bin/sudo -H -S -n just_a_command'
    assert become_module_1.build_become_command(arg_0, arg_1) == expected_output

# Generated at 2022-06-25 08:15:50.700303
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    try:
        cmd = 'test'
        shell = 'bash'
        become_module_1.build_become_command(cmd, shell)
    except:
        print("Method build_become_command() raised Exception unexpectedly!")


# Generated at 2022-06-25 08:15:56.056334
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Call method
    cmd = "/usr/bin/sed -i 's/3.10.0-327.28.3.el7.x86_64/3.10.0-693.2.2.el7.x86_64/g' "
    shell = 'sh'
    result = become_module_0.build_become_command(cmd, shell)
    # No command returned
    assert result is None


# Generated at 2022-06-25 08:16:04.205863
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Missing configuration args
    become_module.get_option = lambda x: ""
    assert become_module.build_become_command("foo", "/bin/sh") == 'sudo -n foo'

    # With config args
    become_module.get_option = lambda x: None
    become_module.get_option = lambda x: "foo"
    assert become_module.build_become_command("foo", "/bin/sh") == 'sudo -H -S -n -u foo foo'

    # With prompt
    become_module.get_option = lambda x: None
    become_module.get_option = lambda x: "foo"
    become_module.get_option = lambda x: "bar"
    become_module.get_option = lambda x: "baz"
    assert become

# Generated at 2022-06-25 08:16:08.691210
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command("cmd300", "shell300") == """sudo  -p "[sudo via ansible, key=%s] password:"  -u root "('shell300', u'cmd300')" """ % (become_module_0._id)

# Generated at 2022-06-25 08:16:15.542880
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()

    cmd = ['ping', '-c', '5', 'localhost']
    shell = 'bash'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/bash -c "ping -c 5 localhost"'

    cmd = ['/sbin/reboot']
    shell = 'csh'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/csh -c "/sbin/reboot"'

    cmd = ['ls -l']
    shell = 'sh'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/sh -c "ls -l"'

# Generated at 2022-06-25 08:16:18.671413
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('echo test', 'sh') == 'sudo -H -S -n sh -c \'echo test\''


# Generated at 2022-06-25 08:16:21.434240
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "test"
    shell = "test"
    become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:16:31.127880
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """Test become command building"""
    become_module_0 = BecomeModule()
    cmd = '/bin/ls'
    shell = '/bin/sh'
    res = become_module_0.build_become_command(cmd, shell)
    assert res == 'sudo -H -S -n -p [sudo via ansible, key=] password: -u  /bin/sh -c \'echo BECOME-SUCCESS-hjzkkhjxeeuabxmwfhdjxzuwmhtyejkr; /bin/ls\''

# Generated at 2022-06-25 08:16:40.761366
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command(cmd="cd /tmp", shell=None) is not None, "The build_become_command method of class BecomeModule did not return a proper value for command \"cd /tmp\""
    assert become_module_0.build_become_command(cmd="cd /tmp", shell=None) == 'sudo -H -S -n  cd /tmp', "The build_become_command method of class BecomeModule did not return a proper value for command \"cd /tmp\""

# Generated at 2022-06-25 08:16:47.574101
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    cmd = "ls"
    shell = "zsh"
    become_exe = "sudo"
    become_flags = "-H -S -n"
    become_pass = "password"
    become_user = "root"
    prompt = "[sudo via ansible, key=%s] password:" % become_module_1._id
    user = "-u %s" % become_user
    expected_output = " ".join([become_exe, become_flags, prompt, user, become_module_1._build_success_command(cmd, shell)])

    output = become_module_1.build_become_command(cmd, shell)

    assert(output == expected_output)

# Generated at 2022-06-25 08:16:49.634778
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    shell = 'bash'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n ls'


# Generated at 2022-06-25 08:16:56.721608
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_option('become_pass', 'spameggs')
    become_module_0.set_option('become_user', 'spamspam')
    become_module_0.set_option('become_exe', 'eggs')
    become_module_0.set_option('become_flags', '-n')
    become_module_0._id = 'spamviking'

    # Check for the specific case of a command of `None`
    assert become_module_0.build_become_command(None, None) is None


# Generated at 2022-06-25 08:17:08.315813
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test cases for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:17:14.205732
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.options = {'become_flags': '-H -S -n', 'become_pass': 'test', 'become_exe': 'sudo',
                             'become_user': 'testuser'}
    become_module._id = 'testID'
    result = become_module.build_become_command('testcmd', 'testshell')
    assert result == 'sudo -H -S -p "[sudo via ansible, key=testID] password:" -u testuser testcmd'

# Generated at 2022-06-25 08:17:18.043019
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    sudo_command = become_module.build_become_command('/bin/ls', 'bash')
    assert sudo_command == "sudo -H -S -n /bin/ls", "Method build_become_command() of class BecomeModule is not correct"


# Generated at 2022-06-25 08:17:23.233324
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    input_cmd = ""
    input_shell = ""
    expected_output = 'sudo -H -S -p "[sudo via ansible, key=] password:" "" ""'
    result = become_module_0.build_become_command(input_cmd, input_shell)
    assert result == expected_output


# Generated at 2022-06-25 08:17:27.358725
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command(['echo foo > bar', 'echo bar > foo'], 'bash') == 'sudo -H -S -n -p "[sudo via ansible, key=become_0] password:"  bash -c \'echo foo\u003e bar; echo bar\u003e foo\' || echo BECOME-SUCCESS-uoojhitzmbkugfkcifmqwqkqomqklnnq && echo BECOME-SUCCESS-uoojhitzmbkugfkcifmqwqkqomqklnnq'


# Generated at 2022-06-25 08:17:40.441952
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Simple case
    assert become_module_0.build_become_command("ls /tmp/", "shell") == "sudo -H -S -n ls /tmp/"
    # More complex case
    become_module_0.become_pass = "secret"
    assert become_module_0.build_become_command("ls /tmp/", "shell") == "sudo -H -S -p \"Sorry, try again.\" ls /tmp/"


# Generated at 2022-06-25 08:17:42.270683
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    result = become_module_1.build_become_command("command","shell")
    assert result == "sudo -H -S -n  command", "Command was: "+result



# Generated at 2022-06-25 08:17:51.757140
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda x: 'bar'
    assert become_module_1.build_become_command('foo', 'bar') == 'sudo -H -S -p "[sudo via ansible, key=yG9Xx15R] password:" -u bar foo'

    become_module_1.get_option = lambda x: 'foobar'
    become_module_1.prompt = 'su - foobar -c '
    assert become_module_1.build_become_command('foo', 'bar') == 'sudo -H -S -p "su - foobar -c " -u foobar foo'

    become_module_1.get_option = lambda x: 'foobar'
    become_module_1.prompt = ''
    assert become_

# Generated at 2022-06-25 08:17:54.752353
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    setattr(become_module_0,'get_option',lambda self, option: None)
    setattr(become_module_0,'_build_success_command',lambda self, cmd, shell: cmd)
    assert become_module_0.build_become_command('pwd', None) == 'sudo  -n   pwd'

# Generated at 2022-06-25 08:17:57.993467
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "net user /add testuser password"
    shell = "/bin/sh"
    become_cmd = "sudo net user /add testuser password"
    assert become_module_1.build_become_command(cmd,shell) ==  become_cmd, "The become command is not correct"

# Generated at 2022-06-25 08:18:05.875091
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0._id = "test"
    cmd = "test"
    shell = False
    become_module_0.prompt = ""
    become_module_0.options = {
        'become_user': 'test',
        'become_pass': 'test',
        'become_flags': '-n'
    }
    result = become_module_0.build_become_command(cmd, shell)
    assert result == 'sudo -n -p "[sudo via ansible, key=test] password:" -u test "test"'


# Generated at 2022-06-25 08:18:10.996934
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "cmd"
    shell = "shell"
    result = become_module_0.build_become_command(cmd, shell)
    assert 'sudo -H -S -n "cmd"' == result
    cmd = ""
    result = become_module_0.build_become_command(cmd, shell)
    assert '' == result



# Generated at 2022-06-25 08:18:18.750143
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    command_0 = ''
    shell_0 = None
    # become_cmd should be ''
    become_cmd = become_module_0.build_become_command(command_0, shell_0)
    assert become_cmd == ''


# Generated at 2022-06-25 08:18:23.591425
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    test_cmd_0 = 'ls -ld $HOME'

    test_result_0 = become_module_0.build_become_command(test_cmd_0, True)
    assert test_result_0 == 'sudo -H -S -n  -u  bash -c \'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/games:/usr/games && export PATH&& ls -ld $HOME\''

    test_result_1 = become_module_0.build_become_command(test_cmd_0, False)
    assert test_result_1 == 'sudo -H -S -n  -u  ls -ld $HOME'

# Generated at 2022-06-25 08:18:28.346564
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = "uptime"
    shell_0 = "none"
    becomecmd_0 = "sudo"
    ansible_become_flags_0 = "-H -S -n"
    ansible_become_user_0 = ""
    ansible_become_password_0 = ""
    become_module_0_become_command_0 = become_module_0.build_become_command(cmd_0, shell_0)
    assert become_module_0_become_command_0 == "sudo -H -S -n uptime"
