

# Generated at 2022-06-25 08:15:32.087368
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.set_options({'become_user': 'administrator'})
    become_module_1.set_options({'become_pass': 'password'})
    become_module_1.set_options({'expand_vars': True})
    become_module_1.set_options({'encrypt_password': True})
    become_module_1.set_options({'encrypt_password_prompt': True})
    become_module_1.set_options({'ask_vault_pass': True})
    cmd_for_become = become_module_1.build_become_command("/bin/echo '{{ansible_password}}'", '/bin/sh -c')
    assert become_module_1.name in cmd_for_bec

# Generated at 2022-06-25 08:15:42.438186
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    test_cmd = '/usr/bin/whoami'
    test_shell = 'sh'
    expected_command = '/usr/bin/sudo -H -S -u root /bin/sh -c \'/usr/bin/whoami; echo $?\' > /dev/null 2>&1'
    assert become_module.build_become_command(test_cmd, test_shell) == expected_command, \
        'build_become_command() produced an unexpected output.'

    test_cmd = 'whoami'
    test_shell = '/bin/sh'
    expected_command = '/usr/bin/sudo -H -S -u root /bin/sh -c \'whoami; echo $?\' > /dev/null 2>&1'
    assert become_module.build_become_command

# Generated at 2022-06-25 08:15:52.566006
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_options(direct=dict(become_user='', become_flags='', become_pass='', become_exe=''))
    assert become_module_0.build_become_command('cmd', 'sh') == 'sudo -H -S -n cmd'
    become_module_0.set_options(direct=dict(become_user='buser', become_flags='-p', become_pass='', become_exe=''))
    assert become_module_0.build_become_command('cmd', 'sh') == 'sudo -H -S -p -u buser cmd'

# Generated at 2022-06-25 08:16:01.462126
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'test command'
    shell = 'test shell'
    try:
        assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n -p "Sorry, a password is required to run sudo" test shell -c \'test command; echo ansible_become_success_0; echo ansible_become_success_0 | base64\''
    except AssertionError:
        print('Expected: sudo -H -S -n -p "Sorry, a password is required to run sudo" test shell -c \'test command; echo ansible_become_success_0; echo ansible_become_success_0 | base64\'')

# Generated at 2022-06-25 08:16:06.781320
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Arrange
    become_module = BecomeModule()
    cmd = "cat /etc/ansible/hosts"
    shell = "/bin/sh"
    become_module.get_option = MagicMock(return_value=None)
    # Act and Assert
    assert become_module.build_become_command(cmd, shell) == "sudo cat /etc/ansible/hosts"


# Generated at 2022-06-25 08:16:14.304194
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.loader import become_loader

    cmd = 'ls /tmp'
    become_module = become_loader.get('sudo')()
    assert become_module is not None

    # when become_exe = None
    become_module.set_options(dict(become_exe=None, become_user='ansible', become_pass=None, become_flags=None))
    actual_result = become_module.build_become_command(cmd, None)
    expected_result = 'sudo -H -S -n -u ansible /bin/sh -c \'echo %s; %s; echo %s\'' % (become_module.success_key, cmd, become_module.success_key)
    assert actual_result == expected_result

    # when become_pass = None
    become_module.set_options

# Generated at 2022-06-25 08:16:22.326195
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:16:30.540611
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = "ls"
    shell = "/bin/sh"
    become_exe = become_module.get_option('become_exe') or become_module.name
    flags = become_module.get_option('become_flags') or ''
    prompt = ''
    if become_module.get_option('become_pass'):
        become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
        if flags:  # this could be simplified, but kept as is for now for backwards string matching
            flags = flags.replace('-n', '')
        prompt = '-p "%s"' % (become_module.prompt)

    user = become_module.get_option('become_user') or ''

# Generated at 2022-06-25 08:16:40.738055
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_options({'prompt': None, '_prompt': '[sudo via ansible, key=h89e9ljvdz8nsuad1l855oxw1bzzc6rz] password:', '_id': 'h89e9ljvdz8nsuad1l855oxw1bzzc6rz', 'become_pass': 'pass', 'become_flags': '-H -S -n'})

# Generated at 2022-06-25 08:16:43.703620
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command('echo test', '/bin/sh') == 'sudo  -p "[sudo via ansible, key=zdIYkY2kKj] password:"  -u'

# Generated at 2022-06-25 08:16:53.423890
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.build_become_command('/bin/ls', '')
    become_module_1 = BecomeModule()
    become_module_1.build_become_command(None, None)
    become_module_2 = BecomeModule()
    become_module_2.build_become_command('/usr/bin/whoami', '')


if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:16:55.809337
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = 'echo FCouet'
    shell = '/bin/sh'

    # Test become_exe option
    beco

# Generated at 2022-06-25 08:17:01.446902
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    become_cmd = become_module.build_become_command("foo", shell=None)
    assert become_cmd == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-hqgjfotemywzkfedzakpevledzaugjzy; foo\''

    become_cmd = become_module.build_become_command(["foo", "bar"], shell=None)
    assert become_cmd == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-hqgjfotemywzkfedzakpevledzaugjzy; foo; bar\''

    become_cmd = become_module.build_become_command("foo", shell="sh")
    assert become_cmd

# Generated at 2022-06-25 08:17:06.430862
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'cmd'
    shell = 'shell'
    become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:17:10.837314
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_options(
        become_pass=None,
        become_user='slurm',
        become_flags='--',
        become_exe='sudo',
    )
    assert become_module_0.build_become_command(cmd='/bin/sleep 5', shell='/bin/sh') == 'sudo -- -u slurm /bin/sleep 5'
    assert become_module_0.build_become_command(cmd='/bin/sleep 5', shell='/bin/csh') == 'sudo -- -u slurm /bin/sleep 5'



# Generated at 2022-06-25 08:17:16.277746
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "some command"
    shell = False
    # No return value, method called on mocked object
    become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:17:25.257719
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_instance = BecomeModule({})
    # prepare arguments for method build_become_command of class BecomeModule
    cmd = 'cmd'
    shell = 'ps'
    become_module_instance.get_option = MagicMock(side_effect=[None, None, None, None, None, None, None, None, None, 'SUDO_PASSWORD'])
    become_module_instance._build_success_command = MagicMock(return_value='SUCCESS')
    assert become_module_instance.build_become_command(cmd, shell) == 'sudo -n -H -S -p "Sorry, a password is required to run sudo" SUCCESS'

# Generated at 2022-06-25 08:17:34.906996
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test for positive case
    cmd = '[become_exe] [become_flags] [prompt] [user] [nopass] [cmd]'
    expected_output = 'sudo -H -S [prompt] -u root [nopass] [cmd]'
    positive_result = become_module.build_become_command(cmd, 'shell')
    assert positive_result == expected_output

    # Test for negative case
    become_module._id = '123'
    cmd = '[become_exe] [become_flags] [prompt] [user] [nopass] [cmd]'
    become_module.prompt = ''

# Generated at 2022-06-25 08:17:46.536243
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Build command when become_exe, become_flags, become_pass, and become_user are empty
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command("cmd", True) == "sudo cmd"

    # Build command when become_exe, become_flags, become_pass, and become_user are not empty
    become_module_0 = BecomeModule(dict(become_exe='sudo', become_flags='-H -S -n', become_pass='', become_user='ansible'))
    assert become_module_0.build_become_command("cmd", True) == "sudo -H -S -n -u ansible cmd"

    # Build command when become_exe and become_user are empty and become_flags and become_pass are not empty
    become_module_0 = BecomeModule

# Generated at 2022-06-25 08:17:49.928907
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = "cmd"
    shell = "shell"

    ret = become_module_0.build_become_command(cmd, shell)

    assert ret == None
    print("test_BecomeModule_build_become_command passed")


# Generated at 2022-06-25 08:18:01.200852
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = "command"
    shell = "shell"
    result = become_module.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n command'

test_case_0()

# Generated at 2022-06-25 08:18:11.303839
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda x: ''
    become_module_1._build_success_command = lambda x, y: x
    become_module_1._id = 'test'
    # test 1 - with no options
    test_0_1_result = become_module_1.build_become_command("commandstring", "shellexe")
    test_0_1_expected = "sudo -H -S -n commandstring"
    assert test_0_1_result == test_0_1_expected
    # test 2 - with flags (including special case: no -n option)
    become_module_1.get_option = lambda x: '-S -k'
    test_0_2_result = become_module_1.build_become_

# Generated at 2022-06-25 08:18:22.640858
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = mock.Mock(return_value='Sudo_become_plugin')
    become_module._build_success_command = mock.Mock(return_value='Success_command')
    become_module.build_become_command('Command', 'Shell')
    become_module.get_option.assert_any_call('become_exe')
    become_module.get_option.assert_any_call('become_flags')
    become_module.get_option.assert_any_call('become_pass')
    become_module._build_success_command.assert_called_once_with('Command', 'Shell')

# Generated at 2022-06-25 08:18:31.071901
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.set_options({'become_exe': '/usr/bin/sudo', 'become_flags': '-H -n', 'become_pass': 'password1', 'become_user': 'root'})
    cmd = 'echo hello world'
    shell = 'bash'

    become_module_1._build_success_command(cmd, shell)

    assert become_module_1.build_become_command(cmd, shell) == '/usr/bin/sudo  -p "[sudo via ansible, key=d58d31c46251522b]" password: -u root /bin/sh -c \'"\'\'\'"\'\'"\'echo hello world"\'\'\'"\'\'"\'\''

# Generated at 2022-06-25 08:18:37.914187
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'pwd'
    shell = True
    assert(become_module_0.build_become_command(cmd, shell) == 'sudo -S -p "[sudo via ansible, key=%s] password:" pwd' % become_module_0._id)

# Generated at 2022-06-25 08:18:43.110823
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Unit test to execute normal case
    become_module_1 = BecomeModule()
    become_module_1.get_option = MagicMock(return_value=None)
    become_module_1._build_success_command = MagicMock(return_value="ls -l")

# Generated at 2022-06-25 08:18:54.489883
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()
    
    become_module.set_options({'become_flags': '-H -S -n'})
    become_module.set_options({'become_exe': 'sudo'})
    
    # Check command for none user
    cmd = "id"
    shell = "/bin/bash"
    becomecmd = become_module.build_become_command(cmd, shell)
    assert becomecmd == 'sudo -H -S -n id'

    # Check command for sudo user
    become_module.set_options({'become_user': 'sudo'})
    becomecmd = become_module.build_become_command(cmd, shell)
    assert becomecmd == 'sudo -H -S -n -u sudo id'

    # Check command for sudo user with become_pass option
   

# Generated at 2022-06-25 08:19:00.844947
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = 'ls'
    shell = False

    res = become_module_0.build_become_command(cmd, shell)

    assert res == 'sudo -H -S -n  ls'

    # cmd = 'ls'
    # shell = True
    #
    # res = become_module_0.build_become_command(cmd, shell)
    #
    # assert res == 'sudo -H -S -n  /bin/sh -c \'ls\''

# Generated at 2022-06-25 08:19:10.499336
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command('ls -al', 'shell') == 'sudo -H -S -n ls -al'
    become_module._options['become_exe'] = 'sudo'
    assert become_module.build_become_command('ls -al', 'shell') == 'sudo -H -S -n ls -al'
    become_module._options['become_flags'] = '-H -S -n'
    assert become_module.build_become_command('ls -al', 'shell') == 'sudo -H -S -n ls -al'
    become_module._options['become_flags'] = '-H -S'

# Generated at 2022-06-25 08:19:16.510044
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = mock_get_option()

    result = become_module_1.build_become_command('command', 'shell')

    expected = 'sudo -H -S -n -u user -p "password:" env shell -c \'command\''
    assert result == expected


# Generated at 2022-06-25 08:19:48.293086
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Try one command.
    cmd = '/bin/true'
    shell = '/bin/sh'
    become_module = BecomeModule()
    become_module.get_option = MagicMock(side_effect=['sudo', ''])
    become_module._build_success_command = MagicMock(return_value=' && echo ansible_become_success')
    result = become_module.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:19:57.382962
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    assert become_module_0.build_become_command('', '') == ''

    assert become_module_0.build_become_command('', '') == ''

    become_module_0.set_options({'become_exe': 'sudo'})

    become_module_0.set_options({'become_flags': '-H -S -n'})

    become_module_0.set_options({'prompt': '[sudo via ansible, key=U6w8Z6Q2N6] password:'})

    become_module_0.set_options({'become_user': 'root'})


# Generated at 2022-06-25 08:20:06.744461
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:20:10.977414
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'pwd'
    shell = '/bin/sh'
    output = become_module.build_become_command(cmd, shell)
    assert output == 'sudo  -H -S -n  pwd'


# Generated at 2022-06-25 08:20:19.374716
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "test_cmd"
    shell = "test_shell"
    become_module_1.get_option = MagicMock(return_value="test_become_exe")
    result = become_module_1.build_become_command(cmd, shell)
    assert result == " -H -S -n test_cmd"


# Generated at 2022-06-25 08:20:28.356172
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.become import BecomeModule

    become_module = BecomeModule()
    cmd = ""
    shell = "sh"
    assert become_module.build_become_command(cmd, shell) == "sudo -H -S sh -c 'echo BECOME-SUCCESS-kjhluiytfri; LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8 LC_MESSAGES=en_US.UTF-8 /bin/sh -c '"'"'""'"'"''"
    shell = "csh"

# Generated at 2022-06-25 08:20:38.645003
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_options = {}
    becomecmd = "sudo"
    user = ""
    prompt = ""
    flags = ""
    cmd = "/etc/passwd"
    ret = becomecmd
    ret += " "
    ret += prompt
    ret += " "
    ret += flags
    ret += " "
    ret += ""
    ret += " "
    ret += "/bin/sh -c 'echo BECOME-SUCCESS-rpkzjblycyyocufgjnrqcfmbhpppmlqk; "
    ret += cmd
    ret += "'"
    become_module_0 = BecomeModule()
    become_module_0.options = become_options
    become_module_0.get_option = lambda x: None

# Generated at 2022-06-25 08:20:47.020204
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    config_module_1 = {'ansible_become_exe': 'sudo', 'ansible_become_user': 'root', 'ansible_become_flags': '-H -S -n'}
    become_module_1.set_options(config_module_1)

    cmd_module_1 = 'whoami'
    shell_module_1 = False

    assert become_module_1.build_become_command(cmd_module_1, shell_module_1) == 'sudo -H -S -n -u root whoami'



# Generated at 2022-06-25 08:20:55.590675
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()
    options = become_module.options

    # Input values for the method build_become_command
    cmd = 'ls -lrt'
    shell = '/bin/bash'

    # Output values for the method build_become_command
    exec_cmd = 'sudo -H -S -n -u root ls -lrt'

    # Invoke the method build_become_command
    build_become_command = become_module.build_become_command(cmd, shell)

    assert exec_cmd == build_become_command

# Generated at 2022-06-25 08:21:04.169334
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda x: None
    become_module_1._id = 'some_value'

    # cmd is empty
    assert become_module_1.build_become_command('', 'some_value') == ''



# Generated at 2022-06-25 08:21:59.323013
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = mock.Mock(return_value='')
    cmd = '[ -d /var/run/ansible ] || mkdir -p /var/run/ansible'
    shell = 'shell'
    res = become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:22:04.952354
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = '/bin/sh'
    shell = '/bin/sh'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n -u root /bin/sh'


# Generated at 2022-06-25 08:22:12.871658
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = MagicMock()
    become_module.get_option.return_value = 'sudo'
    become_module._build_success_command = MagicMock()
    become_module._build_success_command.return_value = 'echo hi'

    become_module.build_become_command('echo hi', False)
    become_module.get_option.assert_any_call('become_exe')
    become_module._build_success_command.assert_called_with('echo hi', False)
    assert len(become_module.get_option.mock_calls) == 4, 'incorrect number of calls to get_option()'

# Generated at 2022-06-25 08:22:16.314917
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    shell = ''
    become_module_0.options = {}
    retval = become_module_0.build_become_command(cmd, shell)
    assert retval == 'sudo ls'


# Generated at 2022-06-25 08:22:26.914307
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'sudo '
    shell_0 = False
    ActualReturnValue_0 = become_module_0.build_become_command(cmd_0, shell_0)
    assert ActualReturnValue_0 == 'sudo sudo -H -S -n -p "[sudo via ansible, key=None] password:"  "echo \'BECOME-SUCCESS-frdsfhcnuqagvfmyjkdnzgskwqwqr\'" 1>&2 && echo \'BECOME-SUCCESS-frdsfhcnuqagvfmyjkdnzgskwqwqr\'', "Function build_become_command did not return expected value"

    cmd_1 = 'sudo '
    shell_1 = True
    ActualReturnValue_1

# Generated at 2022-06-25 08:22:31.135361
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "$HOME/.ansible/tmp/ansible-tmp-1551115265.7-17443221834616/AnsiballZ_command.py"
    shell = "/bin/sh"
    assert isinstance(become_module_0.build_become_command(cmd,shell), str)



# Generated at 2022-06-25 08:22:40.735524
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo hello'
    shell = '/bin/bash'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/bash -c \'(echo \\"$ANSIBLE_SUDO_PASS\\"; echo hello) | sudo -S -p "[sudo via ansible, key=%s] password:" -u root 2>/dev/null\' ' % (become_module_0._id)
    cmd = 'echo hello'
    shell = '/bin/bash'

# Generated at 2022-06-25 08:22:45.395305
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('cmd', False) == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-kcjcpvbvghgkixhoizfhjnfdbwyrwxyu; /bin/sh -c "cmd"\' && (echo BECOME-SUCCESS-kcjcpvbvghgkixhoizfhjnfdbwyrwxyu; exit 0)'


# Generated at 2022-06-25 08:22:52.475625
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = None
    shell = None
    cmd = become_module_0.build_become_command(cmd, shell)
    cmd = become_module_0.build_become_command(cmd, shell)
    cmd = become_module_0.build_become_command(cmd, shell)
    cmd = become_module_0.build_become_command(cmd, shell)
    cmd = become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:22:59.315722
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Define variable 'cmd'
    cmd = "ls -l"
    # Define variable 'shell'
    shell = "/bin/bash"
    # Define variable 'become_module'
    become_module = BecomeModule()
    # Call method(apply options)
    become_module.set_options()
    # Call method(set option value)
    become_module.set_option("become_exe", "sudo")
    # Call method(set option value)
    become_module.set_option("become_flags", "")
    # Call method(get option value)
    become_exe = become_module.get_option("become_exe")
    # Call method(get option value)
    become_flags = become_module.get_option("become_flags")
    # Call method(get option value)


# Generated at 2022-06-25 08:24:33.675710
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda section, key: ''
    real_cmd = become_module_1.build_become_command('A command', 'A shell')
    assert real_cmd == 'sudo -H -S -n "A command"'



# Generated at 2022-06-25 08:24:37.835968
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'some_input'
    shell = 'some_input'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo  -n -H -S /bin/sh -c \'some_input\''

# Generated at 2022-06-25 08:24:40.904000
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    test_cmd = 'ls'
    test_shell = '/bin/sh'
    become_module_0.build_become_command(test_cmd, test_shell)


# Generated at 2022-06-25 08:24:43.919020
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_build_become_command = BecomeModule()
    assert become_module_build_become_command.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -n test_cmd'

test_case_0()
test_BecomeModule_build_become_command()
print('Tests Passed')

# Generated at 2022-06-25 08:24:52.228271
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = ['echo', '"Hello"']
    become_user = 'root'
    become_flags = '-H -S -n'
    become_pass = 'abcde'
    become_exe = 'sudo'

# Generated at 2022-06-25 08:24:58.457208
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmdarg = ['ansible', '-i',  '"/home/jiafeng/ansible/inventory"', '-m',  'setup', '-a',  'filter=ansible_distribution']
    shell = 'bash'
    become_cmd = become_module_0.build_become_command(cmdarg, shell)

# Generated at 2022-06-25 08:25:08.419468
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    shell = 'bash'
    become_module_0.get_option = lambda x: None

# Generated at 2022-06-25 08:25:17.855559
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # become_options_1 = {'become_exe': 'su', 'become_user': 'root'}
    # become_module_1 = BecomeModule(**become_options_1)
    become_module_1 = BecomeModule()
    become_module_1.set_become_plugin_options({'become_exe': 'su', 'become_user': 'root'})
    # become_module_1.config = {'test': 'testvar'}
    cmd = "testcmd"
    shell = "/bin/bash"
    with mock.patch.object(become_module_1, 'get_option') as mock_get_option:
        mock_get_option.return_value = 'su'
        actual = become_module_1.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:25:22.902993
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    print("become_module_1.build_become_command('cd /tmp', True) -> " + become_module_1.build_become_command('cd /tmp', True))
