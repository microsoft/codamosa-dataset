

# Generated at 2022-06-25 08:15:36.640284
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # 1.
    become_module_0 = BecomeModule()
    cmd_0 = ['command0', 'command1']
    shell_0 = False
    assert become_module_0.build_become_command(cmd_0, shell_0) == 'sudo -H -S -n command0 command1'

    # 2.
    become_module_1 = BecomeModule()
    cmd_1 = ['command0', 'command1']
    shell_1 = True
    assert become_module_1.build_become_command(cmd_1, shell_1) == 'sudo -H -S -n sh -c \'""command0"" command1\''

    # 3.
    become_module_2 = BecomeModule()
    cmd_2 = ['command0', 'command1']
    shell_2 = True
    become_module_

# Generated at 2022-06-25 08:15:41.201089
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert len(become_module.build_become_command(cmd = u'ls', shell = u'/bin/sh')) != 0, "Returned string of length > 0"
    assert len(become_module.build_become_command(cmd = '', shell = u'/bin/sh')) == 0, "Returned string of length = 0"

# Generated at 2022-06-25 08:15:45.927286
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'test_cmd'
    shell_0 = 'test_shell'
    assert become_module_0.build_become_command(cmd_0, shell_0) == 'sudo -H -S -n -p "[sudo via ansible, key=all] password:" -u root sh -c \'echo BECOME-SUCCESS-all; test_cmd\''


# Generated at 2022-06-25 08:15:54.538393
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    c1 = ('/usr/bin/python',)
    s1 = '/bin/sh'
    c2 = ('/bin/bash', '-c', 'ls')
    s2 = '/bin/bash'
    become_module_0 = BecomeModule()
    ret = become_module_0.build_become_command(c1, s1)
    assert ret == "/usr/bin/sudo -H -S -n 'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin ; export PATH ; '/usr/bin/python'"
    ret = become_module_0.build_become_command(c2, s2)

# Generated at 2022-06-25 08:15:57.090235
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    command = become_module_0.build_become_command("/bin/bash","False")
    print(command)

# Generated at 2022-06-25 08:16:09.579568
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_1 = BecomeModule()

    # Initializing with empty values as below,
    # because these values get assigned at the time of instantiation
    become_module_1.prompt = ''
    become_module_1._id = ''

    # cmd will have the command to be executed
    cmd = "/bin/true"

    # shell will have the shell-type being used
    shell = "/bin/sh"

    # Making call to the method being tested
    # 'super(BecomeModule, self).build_become_command(cmd, shell)'
    # sets cmd = super(BecomeModule, self).build_success_command(new_cmd, shell).
    # Since we are not modifying new_cmd its value remains the same
    # which is the output of the method being tested
    become_module_1.build_become_

# Generated at 2022-06-25 08:16:18.402423
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    cmd = 'foo bar'
    shell = 'sh'
    ret = become_module.build_become_command(cmd, shell)
    assert ret == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u root sh -c \'(umask 222 && foo bar)\'' % become_module._id


test_case_0()
test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:16:23.739288
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'string'
    shell = 'string'
    becomecmd_retval_0 = become_module_0.build_become_command(cmd, shell)
    assert becomecmd_retval_0 == 'sudo -H -S -n -p "sudo via ansible, key=%s"] password:" -u root su - root -c string' or becomecmd_retval_0 == "sudo -H -S -p 'sudo via ansible, key=%s] password:' -u root bash -c 'set -eu +o pipefail; string'"

# Generated at 2022-06-25 08:16:26.657522
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()

    assert become_module_0.prompt == '[sudo via ansible, key=%s] password:' % become_module_0._id


# Generated at 2022-06-25 08:16:29.866555
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = ''
    shell = ''
    become_module._build_success_command = lambda cmd, shell: 'cmd'

    become_module.get_option = lambda _: ''

    # call build_become_command
    become_module.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:16:45.165573
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    becomecmd = become_module.get_option('become_exe') or become_module.name
    flags = become_module.get_option('become_flags') or ''
    prompt = ''
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    if flags:  # this could be simplified, but kept as is for now for backwards string matching
        flags = flags.replace('-n', '')
    prompt = '-p "%s"' % (become_module.prompt)
    user = become_module.get_option('become_user') or ''
    if user:
        user = '-u %s' % (user)
    cmd_0 = 'sleep 10'
    shell_0 = True
    success_cmd

# Generated at 2022-06-25 08:16:52.709696
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "ls"
    shell = "sh"
    assert become_module_1.build_become_command(cmd, shell) == "sudo -H -S -n -p \"Sorry, try again.\" -u root sh -c 'echo BECOME-SUCCESS-jyvhbltsmsjpmnjgxnmatzirvklaczqj; if command -v /usr/bin/python >/dev/null 2>&1; then /usr/bin/python -c \"print(\\\"ls\\\")\"; else python -c \"print(\\\"ls\\\")\"; fi'"


# Generated at 2022-06-25 08:16:55.721897
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    input_cmd, input_shell = '', 'sh'
    assert become_module_0.build_become_command(input_cmd, input_shell) is None


# Generated at 2022-06-25 08:17:03.709621
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    becomecmd = become_module.get_option('become_exe') or become_module.name

    flags = become_module.get_option('become_flags') or ''
    prompt = ''
    if become_module.get_option('become_pass'):
        become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id

        if flags:  # this could be simplified, but kept as is for now for backwards string matching
            flags = flags.replace('-n', '')
        prompt = '-p "%s"' % (become_module.prompt)

    user = become_module.get_option('become_user') or ''
    if user:
        user = '-u %s' % (user)


# Generated at 2022-06-25 08:17:09.346308
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('echo ""', 'echo ""') == 'sudo -H -S -n  echo ""'
    # TODO: test raise with assertion
    # assert become_module_0.build_become_command() == "TypeError('build_become_command() missing 1 required positional argument: \'cmd\'')"

# Generated at 2022-06-25 08:17:13.838840
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_arg_0 = 'who -a'
    boolean_arg_0 = False
    str_variable_0 = become_module_0.build_become_command(str_arg_0, boolean_arg_0)
    if str_variable_0:
        print(str_variable_0)

test_BecomeModule_build_become_command()
test_case_0()

# Generated at 2022-06-25 08:17:24.777174
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = MagicMock(side_effect = ['sudo'])
    become_module_1.get_option = MagicMock(side_effect = ['-H -S -n'])
    become_module_1.get_option = MagicMock(side_effect = [None])
    become_module_1.get_option = MagicMock(side_effect = [''])
    become_module_1.get_option = MagicMock(side_effect = ['ls-al'])
    become_module_1.get_option = MagicMock(side_effect = [False])
    become_module_1.get_option = MagicMock(side_effect = ['root'])

# Generated at 2022-06-25 08:17:25.583739
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert True



# Generated at 2022-06-25 08:17:35.185249
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.become_flags = None
    become_module_0.get_option = lambda *args, **kwargs : True
    become_module_0.prompt = None
    become_module_0.get_become_option = lambda *args, **kwargs : 'become_exe'
    become_module_0.key = 'bebebe'
    become_module_0._id = 'a'
    become_module_0._build_success_command = lambda *args, **kwargs : 'cmd'
    res = become_module_0.build_become_command('not_a_cmd', 'not_a_shell')

# Generated at 2022-06-25 08:17:46.575611
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:17:56.755020
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Automated test of code
    # Unit test for method build_become_command of class BecomeModule
    become_module_0 = BecomeModule()
    become_module_0.options = {become_module_0: become_module_0}
    become_module_0.get_option = {become_module_0: become_module_0}
    str_0 = become_build_become_command(set_0, dict_0)
    # Passes 1 out of 1 test(s)
    # Generated: Thu, 04 Apr 2019 23:33:31 GMT; User time: 0ms; System time: 0ms


# Generated at 2022-06-25 08:18:05.903251
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    sudo_0 = BecomeModule()
    str_0 = 'Something that is not None'
    assert sudo_0.build_become_command(str_0, None) == 'sudo  -H -S -n  -c \'sudo  -H -S -n  sh -c "Something that is not None"\''
    str_1 = 'Something that is not None'
    assert sudo_0.build_become_command(str_1, '') == 'sudo  -H -S -n  -c \'sudo  -H -S -n  sh -c "Something that is not None"\''
    str_2 = 'Something that is not None'

# Generated at 2022-06-25 08:18:10.593312
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_1 = become_module_0.build_become_command(set_0, dict_0)
    assert var_1 == None


# Generated at 2022-06-25 08:18:16.030228
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = become_module_0.build_become_command(" sudo -n -S", ' reboot_enable_ssh')
    print("--------- TEST: test_BecomeModule_build_become_command ----------------")
    print(" str_0 : %s" % (str_0))
    print("-------------------------------------------------")
    print(" str_0 : %s" % (str_0))
    print("-------------------------------------------------")
    assert str_0 == ' sudo -n -S'


# Generated at 2022-06-25 08:18:24.369224
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    list_0 = ["sudo", "-H -S -n", "", "", ""]
    var_0 = become_build_become_command(list_0, dict_0)
    assert var_0 == 'sudo -H -S -n "" "" ""', 'Incorrect return value of become_build_become_command; return value is %s instead of "sudo -H -S -n "" "" """' % var_0

# Generated at 2022-06-25 08:18:29.526163
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    become_module_0.build_become_command(set_0, dict_0)

# Generated at 2022-06-25 08:18:34.487711
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    print('Testing build_become_command')
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)
    print(var_0)



# Generated at 2022-06-25 08:18:43.841600
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    v_list_0 = list()
    become_module_0._id = list()
    become_module_0.prompt = list()
    var_0 = become_module_0._build_success_command(v_list_0, v_list_0)
    become_module_0.prompt = None
    become_module_0.become_exe = None
    become_module_0.become_flags = None
    become_module_0.become_user = None
    become_module_0.become_pass = None
    become_module_0.name = str()


# Generated at 2022-06-25 08:18:54.534336
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    string_0 = BecomeModule()
    string_0.set_option('become_user', 'root')
    string_0.set_option('become_pass', 'mysupersecret')

    string_0.prompt = 'password: '
    assert string_0.build_become_command('cd /tmp/', False) == 'sudo -p "password: " -u root cd /tmp/'
    string_0.set_option('become_pass', None)

    assert string_0.build_become_command('cd /tmp/', False) == 'sudo -p "password: " -u root cd /tmp/'

    string_0.set_option('become_pass', None)
    string_0.set_option('become_exe', 'sudo')

# Generated at 2022-06-25 08:18:58.571281
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = dict()
    shell = dict()
    assert become_module.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:19:14.692702
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    list_0 = []
    list_1 = []

    assert become_module_0.build_become_command(list_0, list_1) == become_build_become_command(list_0, list_1)

# Generated at 2022-06-25 08:19:25.577252
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_module_0.build_become_command(set_0, dict_0)
    var_1 = become_module_0.build_become_command(set_0, dict_0)
    var_2 = become_module_0.build_become_command(set_0, dict_0)

# Generated at 2022-06-25 08:19:30.347342
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)

# Generated at 2022-06-25 08:19:32.152450
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  become_module_0 = BecomeModule()
  str_0 = become_module_0.build_become_command(str_0, str_0)
  print(str_0)


# Case 1
test_case_0()

# Generated at 2022-06-25 08:19:35.088737
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = "'/bin/ls'"
    shell_0 = "'/bin/bash'"
    print(become_module_0.build_become_command(cmd_0, shell_0))


# Generated at 2022-06-25 08:19:46.536384
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0 = become_module_0
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)
    assert become_module_0._id == var_0


# Generated at 2022-06-25 08:19:51.215515
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_module_0.build_become_command(set_0, dict_0)

# Generated at 2022-06-25 08:19:58.157511
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0}
    dict_0 = {become_module_0: become_module_0}
    var_0 = become_build_become_command(set_0, dict_0)
    var_1 = become_build_become_command(set_0, dict_0)
    var_2 = become_build_become_command(set_0, dict_0)
    var_3 = become_build_become_command(set_0, dict_0)
    var_4 = become_build_become_command(set_0, dict_0)


# Generated at 2022-06-25 08:20:01.512355
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    set_0 = {BecomeModule(): BecomeModule()}
    dict_0 = {BecomeModule(): set_0, BecomeModule(): set_0}
    var_0 = BecomeModule().build_become_command(set_0, dict_0)

# Generated at 2022-06-25 08:20:06.738229
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(become_module_0, {become_module_0: become_module_0, become_module_0: become_module_0})


# Generated at 2022-06-25 08:20:33.286303
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)


# Generated at 2022-06-25 08:20:41.288783
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)

# Generated at 2022-06-25 08:20:45.366814
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd_0 = 'chmod u+x /home/vagrant/.ssh/authorized_keys;'
    shell_0 = False
    become_module_0.build_become_command(cmd_0, shell_0)



# Generated at 2022-06-25 08:20:51.282892
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = become_module_0.build_become_command(become_module_0, become_module_0)
    assert cmd_0 == become_module_0


# Generated at 2022-06-25 08:21:00.733046
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {'become_flags': '-H -S -n', 'become_pass': '', 'become_exe': 'sudo', 'become_user': ''}
    dict_1 = {'become_flags': '', 'become_pass': '', 'become_exe': '', 'become_user': ''}
    become_module_0.set_options(dict_0)
    assert become_module_0.build_become_command() == 'sudo -H -S -n'
    become_module_0.set_options(dict_1)
    assert become_module_0.build_become_command() == 'sudo'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:21:06.197385
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    var_0 = become_build_become_command(become_module_0, dict_0)


# Generated at 2022-06-25 08:21:08.309957
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0 is not None, "Access not granted"
    assert become_module_0 == 0.5, "assertions are not equal"


# Generated at 2022-06-25 08:21:11.725039
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-25 08:21:17.204580
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_1 = {become_module_0}
    dict_2 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_1}
    var_0 = become_build_become_command(set_1, dict_2)


# Generated at 2022-06-25 08:21:25.160972
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    print("Testing method build_become_command")
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_module_0.build_become_command(set_0, dict_0)
    assert not var_0, "Unreachable code"


# Generated at 2022-06-25 08:21:48.090762
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)


# Generated at 2022-06-25 08:21:58.136675
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    assert become_module_0.build_become_command(set_0, dict_0) == 'sudo -H -S -n -p "Sorry, a password is required to run sudo" -u root'

# Generated at 2022-06-25 08:22:08.983622
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.become = 'sudo'
    become_module_0.become_flags = '-H -S -n'
    become_module_0.prompt = '[sudo via ansible, key=%s] password:' % 'e2b9ca3e3da54d3596cbbb8cf8eae11f'
    become_module_0.become_user = 'root'
    become_module_0.get_option = get_option_mock
    become_module_0._id = 'e2b9ca3e3da54d3596cbbb8cf8eae11f'
    become_module_0.name = 'sudo'

# Generated at 2022-06-25 08:22:17.072656
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case 0
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_module_0.build_become_command(set_0, dict_0)
    if (var_0):
        print("Testcase 0: PASS Test passed")
    else:
        print("Testcase 0: FAIL Test failed")

# Generated at 2022-06-25 08:22:25.265483
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)
    assert var_0 == (become_module_0, become_module_0, become_module_0)

# Generated at 2022-06-25 08:22:30.319017
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_1 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_1 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_1}
    var_1 = become_module_0.build_become_command(set_1, dict_1)
    return var_1


# Generated at 2022-06-25 08:22:38.568704
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_module_0.build_become_command(set_0, dict_0)


# Generated at 2022-06-25 08:22:42.684758
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    shell_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    var_0 = become_module_0.build_become_command(cmd_0, shell_0)

# Generated at 2022-06-25 08:22:51.117754
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)

# Generated at 2022-06-25 08:22:59.250657
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    shell_0 = {'a': 'b'}
    cmd_0 = {'d': set(['cd', 'ls']), 'cd': 'ss', 'ls': 'c'}
    become_module_0 = BecomeModule()
    become_module_0.get_option()
    become_module_0.get_option()
    become_module_0.name = 's'
    become_module_0.become_flags = '-H -S -n'
    become_module_0.become_exe = 'sudo'
    become_module_0.get_option(cmd_0)
    become_module_0.prompt = ' ls'
    become_module_0.get_option()
    become_module_0.get_option()
    var_0 = become_module_0.build_bec

# Generated at 2022-06-25 08:23:47.310421
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = become_module_0.build_become_command(1, "")
    # Check return values
    assert type(cmd_0).__name__ == 'str'


# Generated at 2022-06-25 08:23:58.199133
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmds = [
        '/bin/whoami',
        '/bin/whoami',
        '/bin/whoami',
        '/bin/whoami',
        '/bin/whoami',
    ]

# Generated at 2022-06-25 08:24:04.341769
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_module_0.build_become_command(set_0, dict_0)

    return var_0


# Generated at 2022-06-25 08:24:15.413898
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'test'
    shell = '/bin/bash'
    actual_result = become_module.build_become_command(cmd=cmd, shell=shell)
    assert actual_result == cmd
    cmd = 'test'
    shell = '/bin/bash'
    actual_result = become_module.build_become_command(cmd=cmd, shell=shell)
    assert actual_result == cmd
    cmd = 'test'
    shell = None
    actual_result = become_module.build_become_command(cmd=cmd, shell=shell)
    assert actual_result == cmd
    cmd = 'test'
    shell = None
    actual_result = become_module.build_become_command(cmd=cmd, shell=shell)
    assert actual_result == cmd
    cmd

# Generated at 2022-06-25 08:24:22.220846
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)


# Generated at 2022-06-25 08:24:26.436623
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = {become_module_0, become_module_0, become_module_0, become_module_0}
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)
    assert var_0 == "sudo -H -S -n  -c 'cd \"$HOME\" && echo \"(cwd: `pwd`)\"; "

# Generated at 2022-06-25 08:24:36.940531
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Local variables for test
    arg_0 = 'cmd'
    arg_1 = 'shell'
    # Testing 'all' in case 1.
    set_0 = {arg_0, arg_0, arg_0, arg_0}
    dict_0 = {arg_0: arg_0, arg_0: arg_0, arg_0: arg_0, arg_0: set_0}
    var_0 = become_build_become_command(set_0, dict_0)
    # Testing 'any' in case 1.
    set_1 = {arg_1, arg_1, arg_1, arg_1}
    dict_1 = {arg_1: arg_1, arg_1: arg_1, arg_1: arg_1, arg_1: set_1}

# Generated at 2022-06-25 08:24:46.634997
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_options({'become_flags': '', 'become_exe': 'sudo', 'become_user': 'root', 'become_pass': ''})
    var_0 = become_module_0.build_become_command('/bin/bash', 'posix')

    # Test output
    assert var_0 == 'sudo -u root /bin/bash'

    become_module_0 = BecomeModule()
    become_module_0.set_options({'become_flags': '', 'become_exe': 'sudo', 'become_user': 'root', 'become_pass': 'test'})
    var_0 = become_module_0.build_become_command('/bin/bash', 'posix')

    # Test output


# Generated at 2022-06-25 08:24:50.046926
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with only 'cmd' parameter
    cmd = 'sudo'
    shell = ''
    become_module_1 = BecomeModule()
    become_module_1.build_become_command(cmd, shell)

    # Test with 'cmd' and 'shell' parameters
    cmd = 'sudo'
    shell = '/bin/bash'
    become_module_2 = BecomeModule()
    become_module_2.build_become_command(cmd, shell)



# Generated at 2022-06-25 08:24:54.939447
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_option(('become_exe',))
    become_module_0.set_option({'become_pass': '', 'become_user': ''})
    become_module_0.get_option('')
    become_module_0.name = 'sudo'
    become_module_0.prompt = 'Sorry: a password is required to run sudo'
    assert isinstance(become_module_0.build_become_command('', ''), str)

