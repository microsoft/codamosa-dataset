

# Generated at 2022-06-25 08:15:31.081670
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Unit test for build_become_command with None cmd
    result = become_module.build_become_command(None, None)
    assert result is None

    # Unit test for build_become_command with string cmd
    result = become_module.build_become_command("cmd", None)
    assert result == 'sudo -H -S -n -p "[sudo via ansible, key=] password:" -u "" cmd'

if __name__ == "__main__":
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:15:41.594307
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # Test Inputs
    cmd = "echo hello"
    shell = 'shell'

    # Expected Outputs
    expected_result = 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u  %s\'echo hello\''%(become_module_0._id, become_module_0._build_success_command(cmd, shell))

    # Test execution
    become_module_0.build_become_command(cmd, shell)

    # Test Result
    assert become_module_0.build_become_command(cmd, shell) == expected_result

# Execute `unittest`
if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 08:15:44.401724
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command('echo hello', '/bin/sh') == 'sudo -H -S -n -p "[sudo via ansible, key=become_1] password:" -u root /bin/sh -c \'echo hello\''

# Generated at 2022-06-25 08:15:48.531639
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  become_module = BecomeModule()

  assert become_module.build_become_command('whoami', None) == 'sudo -p "[sudo via ansible, key=c09f5f89b6830c74ba7f43e52b22a7a4] password:" whoami'

# Generated at 2022-06-25 08:15:50.481640
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command(cmd, shell) is None

# Generated at 2022-06-25 08:15:59.611357
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = "ansible -m ping all"
    shell = None
    become_module_1.build_become_command(cmd, shell)
    cmd = "ansible -m ping all"
    shell = "/bin/bash"
    become_module_1.build_become_command(cmd, shell)
    cmd = "ansible -m ping all"
    shell = "cmd.exe"
    become_module_1.build_become_command(cmd, shell)
    cmd = "ansible -m ping all"
    shell = "powershell"
    become_module_1.build_become_command(cmd, shell)
    cmd = "ansible -m ping all"
    shell = "system"

# Generated at 2022-06-25 08:16:03.592577
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    x = become_module_0.build_become_command('foo', 'bar')
    assert x in ['foo', 'sudo foo', 'sudo -- foo', 'sudo -s foo', 'sudo -s -- foo']


# Generated at 2022-06-25 08:16:07.268106
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_1 = BecomeModule()
    test_case_1.build_become_command("whoami", "user")
    test_case_1.build_become_command("whoami", "user")


# Generated at 2022-06-25 08:16:14.613581
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Case 0 - if cmd is empty return value of super method and set prompt and user
    cmd = ''
    shell = 'shell'
    become_module._id = 'id'
    become_module.prompt = 'prompt'
    become_module.get_option = lambda name : '' if name == 'become_user' else 'super'
    assert become_module.build_become_command(cmd, shell) == 'super'
    assert become_module.prompt == 'prompt'
    assert become_module.user == ''

    # Case 1 - if become_flags does not contain -n, set prompt and user
    cmd = 'cmd'
    shell = 'shell'
    become_module._id = 'id'
    become_module.prompt = 'prompt'
    become_

# Generated at 2022-06-25 08:16:20.381957
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ["echo", "hello"]
    shell = True
    result = become_module_0.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n -p "Sorry, try again." -u root echo "hello"'


if __name__ == "__main__":
    test_BecomeModule_build_become_command()


# Generated at 2022-06-25 08:16:26.763862
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.prompt = '[sudo via ansible, key=%s] password:' % self._id
    become_module_1.prompt = '-p "%s"' % (self.prompt)



# Generated at 2022-06-25 08:16:32.375699
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    check_list = ['whoami', 'whoami']
    check_list_0 = become_module_0.get_option('become_pass')
    check_list_1 = become_module_0.get_option('become_exe')
    check_list_2 = become_module_0.get_option('become_flags')
    check_list_3 = become_module_0.get_option('become_user')
    check_list_4 = become_module_0.prompt
    check_list_5 = become_module_0._id
    check_list_6 = become_module_0.get_option('become_exe')
    if '':
        check_list_6 = check_list_6 or become_module_0.name
    check

# Generated at 2022-06-25 08:16:40.904725
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Set up test case input
    become_module = BecomeModule()
    cmd = '/bin/true'
    shell = None

    # Execute test case function
    expected_result = "/bin/sh -c 'true && echo %s'" % (become_module.success_key)
    test_result = become_module.build_become_command(cmd, shell)
    
    # Check test case results
    assert expected_result == test_result


if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:16:48.590664
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ['echo', 'Hello World!']
    shell = '/path/to/bash'
    cmd_func = become_module_0.build_become_command(cmd, shell)
    print(cmd_func)


# Generated at 2022-06-25 08:16:57.049286
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Testing become_pass=None
    # Test with default become_pass
    become_module_0 = BecomeModule()

    # Testing become_pass='', become_user='', become_exe='sudo', become_flags='-H -S -n'
    cmd = 'ls'
    shell = 'sh'
    become_module_0.build_become_command(cmd, shell)

    # Testing become_pass=None, become_user='', become_exe='sudo', become_flags='-H -S -n'
    cmd = 'ls'
    shell = 'sh'
    become_module_0.build_become_command(cmd, shell)

    # Testing become_pass=None, become_user='', become_exe='sudo', become_flags='-H '
    become_module_1 = BecomeModule()
    cmd

# Generated at 2022-06-25 08:17:01.804409
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert become_module_0.build_become_command("sudo -u root date", 'bash') == 'sudo -H -S -p "[sudo via ansible, key=x] password:" -u root bash -c "date"', 'Failed to build the become command'


# Generated at 2022-06-25 08:17:04.069504
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'id'
    shell = False
    result = become_module.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n id'


# Generated at 2022-06-25 08:17:13.347118
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Instantiate class
    become_module_0 = BecomeModule()

    # Set options and values
    become_module_0.become_exe = 'sudo'
    become_module_0.become_flags = '-H -S -n'
    become_module_0.become_user = 'root'
    become_module_0.prompt = '[sudo via ansible, key=%s] password:'
    become_module_0.plugin_options = None
    become_module_0.set_shell_options('/bin/sh')
    command = ''
    shell = True

    # Execute method
    output = become_module_0.build_become_command(command, shell)

    # Test output

# Generated at 2022-06-25 08:17:18.630730
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test when the command argument is empty
    result = become_module.build_become_command(cmd="", shell=None)
    assert result == None


# Generated at 2022-06-25 08:17:23.660753
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # build_become_command(cmd, shell)
    # Cmd - command to execute
    # For example 'echo test'
    # Shell - shell type to execute the command
    # For example 'bash'
    become_module = BecomeModule()
    cmd = ''
    shell = ''
    become_module.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:17:29.349349
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()


# Generated at 2022-06-25 08:17:38.091678
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0._id = 'w4w4pt4t4'
    become_module_0.prompt = 'y5y5q5q5'
    become_module_0._id = '56ta7ze6'
    become_module_0.prompt = 'l6l6b6b6'
    become_module_0._id = 'zje6dfdv'
    become_module_0.prompt = '8k8k68k6'
    become_module_0._id = 'a9r6w8rs'
    become_module_0.prompt = 'r9r9v9v9'
    become_module_0._id = 'jjgj6hna'

# Generated at 2022-06-25 08:17:40.833173
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_mock = ['echo', 'Hello']
    shell_mock = 'foo'
    result = become_module_0.build_become_command(cmd_mock, shell_mock)
    assert True


# Generated at 2022-06-25 08:17:44.240376
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()
    become_module.prompt = "Password:"
    
    # Test simple case (where cmd is not empty) 
    cmd = 'ls'
    shell = 'test shell'
    become_module.get_option = lambda name: None

    expected_result = 'sudo -H -S -n ls'
    result = become_module.build_become_command(cmd, shell)
    assert result == expected_result

# Generated at 2022-06-25 08:17:45.896783
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # TODO: Write unit test for build_become_command
    assert True


# Generated at 2022-06-25 08:17:53.429077
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'Passage'
    become_module.get_option = Mock(return_value=None)
    become_module._build_success_command = Mock(return_value='whoami')
    become_module.build_become_command('whoami', shell=False)
    cmd_expect = ' '.join(['sudo', '', '', '-u ', 'whoami'])
    assert cmd_expect == become_module._cmd


# Generated at 2022-06-25 08:18:02.933662
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # state 0
    test_case_0_cmd_0 = 'passwd'
    test_case_0_shell_0 = False
    test_case_0_become_exe_0 = 'sudo'
    test_case_0_become_flags_0 = '-H -S -n'
    test_case_0_become_pass_0 = None
    test_case_0_become_user_0 = 'root'

    # state 0

# Generated at 2022-06-25 08:18:06.285546
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "command"
    shell = "shell"
    result = become_module_0.build_become_command(cmd, shell)
    assert '-H -S -n  -p "[sudo via ansible, key=]" password:' in result

# Generated at 2022-06-25 08:18:08.414281
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo'
    
    # Test
    #assert become_module_0.build_become_command(cmd, '') == None

# Generated at 2022-06-25 08:18:10.477800
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls'
    shell = True
    res = become_module_0.build_become_command(cmd, shell)
    assert res == 'sudo su -c "ls"'


# Generated at 2022-06-25 08:18:23.109810
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Declare object of class BecomeModule
    become_module = BecomeModule()
    # Attempt to execute method build_become_command of class BecomeModule
    try:
        become_module.build_become_command()
    # Raise exception
    except Exception as e:
        print('Exception raised: ' + type(e).__name__)
        print('Message: ' + e.message)
        print('Object of class BecomeModule has not been created')
    # No exception is raised
    else:
        print('Object of class BecomeModule has been created')
        print('Method build_become_command of class BecomeModule executed successfully')
    # End try block

# Generated at 2022-06-25 08:18:27.305116
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    dict_0 = {}
    str_0 = 'n'
    assert become_module_0.build_become_command(dict_0, str_0) != 'sudo '

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:18:30.593298
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    sudo_obj = BecomeModule()
    assert sudo_obj.name == 'sudo'

# Generated at 2022-06-25 08:18:36.079406
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1 = become_module_1
    var_1 = become_module_1.become_flags = var_1
    become_module_1.build_become_command(cmd, shell)
    become_build_become_command(cmd, shell)
    str_2 = 'Sorry, try again.'
    str_3 = become_module_1.fail
    assert str_2 in str_3


# Generated at 2022-06-25 08:18:41.155903
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_module_0.build_become_command(dict_0, str_0)


# Generated at 2022-06-25 08:18:47.403096
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = MagicMock(side_effect=[None, None, True, 'password'])
    become_module_0._build_success_command = MagicMock(return_value=';')
    str_0 = 'command'
    str_1 = 'shell'
    var_0 = become_module_0.build_become_command(str_0, str_1)
    var_1 = become_module_0.build_become_command(str_0, str_1)
    str_2 = 'n'
    var_2 = become_module_0.build_become_command(str_2, str_1)
    str_3 = 'n'
    var_3 = become_module_0.build_become_command

# Generated at 2022-06-25 08:18:55.101446
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    dict_0 = {}
    str_0 = 'aa'
    var_0 = become_module_0.build_become_command(dict_0, str_0)
    assert isinstance(var_0, str)
    str_0 = 'aa'
    var_1 = become_module_0.build_become_command(dict_0, str_0)
    assert isinstance(var_1, str)
    str_1 = 'aa'
    var_2 = become_module_0.build_become_command(dict_0, str_1)
    assert isinstance(var_2, str)


import platform
var_1 = platform.system()
var_2 = platform.release()
var_3 = platform.version()

# Generated at 2022-06-25 08:19:01.895876
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('/bin/cat', 'True') == 'sudo -H -S -n /bin/cat'


# Generated at 2022-06-25 08:19:11.009768
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = 'p'
    str_1 = 'e'
    str_2 = 'y'
    str_3 = '%'
    str_4 = 'l'
    str_5 = 'o'
    str_6 = 'O'
    str_7 = 'X'
    str_8 = 'p'
    str_9 = 'E'
    str_10 = 'r'
    list_0 = [str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8, str_9, str_10]
    str_11 = ''.join(list_0)

# Generated at 2022-06-25 08:19:23.251873
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    dict_0 = {'become_flags': '', 'become_pass': True, 'become_user': 'user_1', 'become_exe': 'sudo', 'prompt': 'prompt_1'}
    str_0 = 'command_1'
    var_0 = BecomeModule.build_become_command(dict_0, str_0)
    assert isinstance(var_0, str)
    assert var_0 == 'sudo -H -S -p "prompt_1" -u user_1 ' + 'command_1'
    dict_1 = {'prompt': 'prompt_2', 'become_flags': '', 'become_pass': True, 'become_user': 'user_1', 'become_exe': 'sudo'}
    str_1 = 'command_2'


# Generated at 2022-06-25 08:19:38.788702
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    become_module_0.name = 'sudo'

    # 'become_pass' option isn't set
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_module_0.build_become_command(dict_0, str_0)
    assert var_0 == 'sudo -H -S -n -u root n'

    # 'become_user' option isn't set
    become_module_0.flags = '-H'

# Generated at 2022-06-25 08:19:49.429673
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.become = None
    become_module_0.prompt = 'ansible_become_pass'
    become_module_0.become_user = 'ansible_become_user'
    become_module_0.get_option = get_option_0()
    become_module_0.conn_cmds = 'Connection object command mangler'
    become_module_0.get_option_int = get_option_int_0()
    become_module_0.get_option_bool = get_option_bool_0()
    become_module_0.conn_cmds = 'Connection object command mangler'
    become_module_0.get_option_str = get_option_str_0()
    become_module_0.conn_cmd

# Generated at 2022-06-25 08:19:52.975060
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bcmd = BecomeModule()
    bcmd.prompt = 'password:'
    x = bcmd.build_become_command(['test'], 'bash')
    assert x == 'sudo -H -S -n -p "password:"  test'

# Generated at 2022-06-25 08:19:59.893548
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

  # Test case 0
  if True:
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)

  # Test case 1
  if True:
    become_module_1 = BecomeModule()
    dict_1 = {become_module_1: become_module_1, become_module_1: become_module_1, become_module_1: become_module_1}
    str_1 = 'l'
    var_1 = become_build_become_command(dict_1, str_1)

  # Test

# Generated at 2022-06-25 08:20:08.889134
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    become_module_0.build_become_command(dict_0, str_0)
    return None


# Generated at 2022-06-25 08:20:13.120907
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = ''
    str_1 = 'n'
    var_0 = become_module_0.build_become_command(str_0, str_1)
    assert var_0 == str_0




# Generated at 2022-06-25 08:20:20.043033
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    client = ansible.module_utils.basic.AnsibleModule(get_option='sudo')
    become_module_0 = BecomeModule(client)
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)

# Generated at 2022-06-25 08:20:25.883009
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # First test case
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_module_0.build_become_command(dict_0, str_0)

# Generated at 2022-06-25 08:20:27.384713
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case that fails
    test_case_0()



# Generated at 2022-06-25 08:20:37.373823
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = {become_module_0: become_module_0}
    shell_0 = '*Z'
    str_0 = become_module_0._build_success_command(cmd_0, shell_0)
    assert str_0 == ' && '.join(('', 'true'))

    str_1 = become_module_0._build_success_command(cmd_0, shell_0)
    assert str_1 == ' && '.join(('', 'true'))

    str_2 = become_module_0._build_success_command(cmd_0, shell_0)
    assert str_2 == ' && '.join(('', 'true'))


# Generated at 2022-06-25 08:21:03.945785
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    args = []
    if len(args) == 2:
        test_case_0()


# Generated at 2022-06-25 08:21:09.618487
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Instantiate class
    become_module_0 = BecomeModule()
    # Get options
    var_0 = become_module_0.get_option('become_exe')
    # Get options
    var_1 = become_module_0.get_option('become_pass')
    # Get options
    var_2 = become_module_0.get_option('become_user')
    # Get options
    var_3 = become_module_0.get_option('become_flags')
    # Build become command
    str_0 = ''
    str_1 = 'shell'
    var_4 = become_build_become_command(str_0, str_1)
    # AssertionError
    assert var_4 == var_4

# Generated at 2022-06-25 08:21:16.025609
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_module_0.build_become_command(dict_0, str_0)


# Generated at 2022-06-25 08:21:20.683382
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_4 = BecomeModule()
    str_0 = 'L'
    dict_0 = {become_module_4: become_module_4, become_module_4: become_module_4, become_module_4: become_module_4}
    var_0 = become_module_4._build_success_command(dict_0, str_0)
    dict_1 = {become_module_4: become_module_4, become_module_4: become_module_4, become_module_4: become_module_4}
    str_1 = 'n'
    var_1 = become_module_4.build_become_command(dict_1, str_1)

# Generated at 2022-06-25 08:21:25.886535
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)
    assert var_0 == 'sudo -n -u root -p "[sudo via ansible, key=3e3da9c9fce9db0e49aca0f219cc81f2] password:" true'

# Generated at 2022-06-25 08:21:37.579619
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_2 = BecomeModule()

# Generated at 2022-06-25 08:21:44.115343
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)


# Generated at 2022-06-25 08:21:47.047140
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = '+'
    assert '+' in become_build_become_command(dict_0, str_0)



# Generated at 2022-06-25 08:21:56.363460
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)



# Generated at 2022-06-25 08:21:59.825714
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test for variants that don't contain the key #
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_module_0.build_become_command(dict_0, str_0)
    print(var_0)


# Generated at 2022-06-25 08:22:54.243261
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)
    var_1 = become_build_become_command(dict_0, str_0)
    var_2 = become_build_become_command(dict_0, str_0)



# Generated at 2022-06-25 08:22:59.224655
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    str_1 = ''
    if (str_1 == 'n'):
        str_0 = '-H -S sudo -n -u $(which nmap)'
    str_2 = become_build_become_command(dict_0, str_0)
    return str_2


# Generated at 2022-06-25 08:23:04.799959
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # cmd=var_args, shell=var_kwargs
    become_module_1 = BecomeModule()
    dict_0 = {become_module_1: become_module_1, become_module_1: become_module_1}
    str_0 = 'p'
    var_0 = become_build_become_command(dict_0, str_0)


# Generated at 2022-06-25 08:23:11.212133
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)

# Generated at 2022-06-25 08:23:13.597024
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)
    assert var_0 is None


# Generated at 2022-06-25 08:23:20.432211
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_0 = 'n'
    str_1 = ''
    str_2 = build_become_command(str_0, str_1)
    assert str_2 == ""


# Generated at 2022-06-25 08:23:24.350352
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)



# Generated at 2022-06-25 08:23:28.350980
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)


# Generated at 2022-06-25 08:23:32.740713
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    var_0 = become_build_become_command(dict_0, str_0)



# Generated at 2022-06-25 08:23:38.127809
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    dict_0 = {become_module_0: become_module_0, become_module_0: become_module_0, become_module_0: become_module_0}
    str_0 = 'n'
    str_1 = become_build_become_command(dict_0, str_0)
    print(str_1)


test_case_0()
test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:25:27.523253
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.get_option = MagicMock()
    become_module_0.get_option.return_value = '1g63'
    var_0 = MagicMock()
    var_0.cmd = '$'
    str_0 = '9i'
    var_1 = become_module_0.build_become_command(var_0, str_0)
    assert True