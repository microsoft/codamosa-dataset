

# Generated at 2022-06-25 08:15:30.011713
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    
    # If the become executable is not set, the 'sudo' should be returned
    cmd_0 = become_module_0.build_become_command("", "/bin/bash")
    assert(cmd_0.startswith("sudo"))
    assert(cmd_0.endswith("/bin/bash"))

    # If the become flags are set, they should be appended to the executable
    become_module_0.become_flags = "-y -f"
    cmd_1 = become_module_0.build_become_command("", "/bin/bash")
    assert(cmd_1.startswith("sudo -y -f /bin/bash"))

    # If the become user is set, they should be appended to the executable
    become_module_0.become_flags

# Generated at 2022-06-25 08:15:33.860749
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Imports should be avoid in the test cases
    # For the time being ansible.module_utils.basic has been patched
    cmd = become_module_0.build_become_command('test', 'shell')
    assert cmd == 'sudo -H -S -n  test', 'Failed to assert command with shell = shell'

# Generated at 2022-06-25 08:15:35.991709
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('this is my command', 'shell') == "sudo -H -S -n  this is my command"


# Generated at 2022-06-25 08:15:46.945468
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Test 1: no command passed, cmd is None
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda x: None
    result = become_module_1.build_become_command(None, None)
    assert result == None

    # Test 2: command passed and all optional parameters are None
    become_module_2 = BecomeModule()
    become_module_2.get_option = lambda x: None
    cmd = 'ls /etc'
    shell = 'bash'
    result = become_module_2.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n ls /etc'

    # Test 3: command passed, optional become_exe and become_flags are None
    become_module_3 = BecomeModule()

# Generated at 2022-06-25 08:15:48.925042
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command('true', True) == 'sudo -H -S -n true'

# Generated at 2022-06-25 08:15:56.609138
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'id'
    shell = 'sh'
    #1. become_exe not set, become_flags not set, become_user not set, become_pass not set
    become_module_1.set_options(option_dict={})
    assert become_module_1.build_become_command(cmd, shell) == 'sudo -H -S -n id'
    #2. become_exe not set, become_flags not set, become_user not set, become_pass is set
    become_module_2 = BecomeModule()
    become_module_2.set_options(option_dict={'become_pass': 'ansible'})

# Generated at 2022-06-25 08:15:58.586046
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    assert become_module_1.build_become_command("ls") == "sudo ls"


# Generated at 2022-06-25 08:16:03.923462
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # initial args for test
    cmd = 'echo "ansible"'; shell = False
    # initial return values for test
    initial_return_values = [False, True]
    # invoke method on class
    return_value = become_module_0.build_become_command(cmd=cmd, shell=shell)
    # compare return values and initial return values
    assert return_value == initial_return_values[0]
    # return args
    return [cmd, shell]


# Generated at 2022-06-25 08:16:10.095483
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    # Tests for become_exe with values 'sudo'
    become_exe = 'sudo'

    # Tests for become_flags with values ''
    become_flags = ''

    # Tests for become_user with values ''
    become_user = ''

    becomecmd =  become_exe or become_module_0.name

    flags = become_flags or ''
    prompt = ''

    user = become_user or ''

# Generated at 2022-06-25 08:16:19.715983
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = '/bin/false'
    shell = '/bin/sh'
    become_module_0.get_option = MagicMock()
    become_module_0.get_option.return_value = '-H -S -n'
    become_module_0._build_success_command = MagicMock()
    become_module_0._build_success_command.return_value = '\'ls -la\''
    expected = 'sudo -H -S -n \'ls -la\''

    actual = become_module_0.build_become_command(cmd, shell)

    assert expected == actual

# Generated at 2022-06-25 08:16:27.694043
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Test with default values
    become_module_0.get_option = lambda key: ''
    cmd = ''
    shell = ''
    output = become_module_0.build_become_command(cmd, shell)
    assert output == cmd


# Generated at 2022-06-25 08:16:42.145334
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()

    become_module._build_success_command = lambda : 'command'
    become_module.get_option = lambda : 'default'
    cmd = ''
    shell = ''

    # Test 1:
    command = become_module.build_become_command(cmd, shell)
    assert command == 'sudo -H -S -n command'

    # Test 2:
    become_module.get_option = lambda : 'become_exe'
    command = become_module.build_become_command(cmd, shell)
    assert command == 'become_exe -H -S -n command'

    # Test 3:
    become_module.get_option = lambda : 'become_flags'
    command = become_module.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:16:49.363925
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    assert become_module.build_become_command(cmd=cmd, shell=shell) == 'ansible-become-method-0 ansible-become-flags-0 ansible-become-prompt-0 -u ansible-become-user-0 ansible-become-success-command-0', 'Method build_become_command() failed'

# Generated at 2022-06-25 08:16:56.172722
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    print ("\nUnit test for method build_become_command of class BecomeModule")

    become_module_0 = BecomeModule()

    print ("\nmethod test case 0")

    become_module_0.set_options({'become_exe':'sudo', 'become_pass':'', 'become_flags':'-H -S -n'})

    cmd = 'echo hello'
    shell = 'sh'

    cmd_output = become_module_0.build_become_command(cmd, shell)
    print ("\nUnit test output: %s" % cmd_output)
    assert cmd_output == 'echo hello'


# Generated at 2022-06-25 08:16:59.407063
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    m = become_module_0
    m.get_option = lambda x: None
    m._build_success_command = lambda x, y: 'echo test_build_become_command'
    assert m.build_become_command('ansible_cmd', 'ansible_shell') == 'sudo  -H -S -n  echo test_build_become_command'



# Generated at 2022-06-25 08:17:08.675689
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_option('become_flags', None)
    become_module_0.set_option('become_exe', 'sudo')
    become_module_0.set_option('become_user', 'root')
    become_module_0.set_option('become_pass', None)
    assert become_module_0.build_become_command('echo "success"', 'bash') == ' '.join(('sudo',  '-H -S -n', '', '-u', 'root', 'echo "success"'))


# Generated at 2022-06-25 08:17:11.963874
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "ls"
    shell = "sh"
    assert become_module_0.build_become_command(cmd, shell) == "sudo -H -S -n -u root sh -c 'LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8 LC_MESSAGES=en_US.UTF-8 /bin/sh -c \"\"\"ls\"\"\"'"

# Generated at 2022-06-25 08:17:21.592690
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'echo abc'
    shell = '/bin/bash'
    become_cmd = become_module.build_become_command(cmd, shell)
    assert become_cmd == 'sudo -H -n /bin/bash -c \'(echo \"$(echo $?; echo abc)\") | "cat"\'', 'become_cmd is not as expected'


# Generated at 2022-06-25 08:17:31.930646
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ""
    shell = "sh"
    become_module_0.get_option = Mock(return_value='')
    assert isinstance(become_module_0.build_become_command(cmd, shell), str)
    cmd = "command"
    shell = "sh"
    assert isinstance(become_module_0.build_become_command(cmd, shell), str)
    cmd = "command"
    shell = "bash"
    assert isinstance(become_module_0.build_become_command(cmd, shell), str)
    cmd = "command"
    shell = "zsh"
    assert isinstance(become_module_0.build_become_command(cmd, shell), str)


# Generated at 2022-06-25 08:17:40.140596
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = []
    shell = ''

    # unit test for command with cmd option, shell option and become_pass option set
    become_module_0.get_option = unit_test_get_option
    become_module_0.get_option = types.MethodType(lambda self, x: 'become_exe' if x == 'become_exe' else 'become_pass' if x == 'become_pass' else 'become_flags' if x == 'become_flags' else 'become_user' if x == 'become_user' else None, become_module_0)
    become_module_0.set_option = types.MethodType(lambda self, x, y: None, become_module_0)
    become_module_0.get_option = types.Method

# Generated at 2022-06-25 08:17:51.183554
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_2 = BecomeModule()
    become_module_3 = BecomeModule()
    become_module_4 = BecomeModule()
    become_module_5 = BecomeModule()

    become_module_1.set_options({'become_pass': 'pass123'})
    become_module_2.set_options({'become_pass': 'pass123',
                                 'become_user': 'bob',
                                 'become_exe': 'runas',
                                 'become_flags': '-c'})

# Generated at 2022-06-25 08:17:57.449926
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    # no input
    expected = None
    returned = become_module.build_become_command(None, None)
    assert returned == expected

    become_module = BecomeModule()
    # just init become_exe
    become_module.become_exe = 'sudo'
    become_module.become_flags = ''
    expected = "sudo  -H -S -n  /bin/bash -c 'echo BECOME-SUCCESS-makwkbwgwuserfrpjftpszlfjnrcbpxmz; /bin/bash'"
    returned = become_module.build_become_command('/bin/bash -c', '/bin/bash')
    print(returned)
    assert returned == expected


# Generated at 2022-06-25 08:18:06.154452
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'cmd'
    shell = 'csh'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u root "cmd"' % (become_module_0._id)
    cmd = 'cmd'
    shell = 'sh'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u root sh -c \'"cmd"\'' % (become_module_0._id)

# Generated at 2022-06-25 08:18:09.466279
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    cmd = 'string'
    shell = 'string'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -S -p "[sudo via ansible, key=None] password:" -u string /bin/sh -c "string"'


# Generated at 2022-06-25 08:18:14.505642
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  try:
    become_module_ = BecomeModule()
    # Test with good parameters
    cmd = 'some_command'
    shell = False

    become_module_.build_become_command(cmd, shell)
    # Test with bad parameters
    become_module_.build_become_command(cmd, shell)
  except Exception as inst:
    print("An exception occurred: " + str(inst))


# Generated at 2022-06-25 08:18:19.331359
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case 0
    become_module_0 = BecomeModule()
    cmd = "echo 'Hello'"
    shell ="sh"
    expected = "sudo -H -S -n  echo 'Hello'"
    observed = become_module_0.build_become_command(cmd, shell)
    assert observed == expected

# Generated at 2022-06-25 08:18:28.912025
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.prompt = None
    become_module_1._id = '1'
    cmd_17 = 'test_cmd'
    shell_18 = True
    become_module_1.get_option = MagicMock(name='get_option')
    become_module_1.get_option.side_effect = ['sudo', '-H -S -n', '', 'root']
    become_module_1._build_success_command = MagicMock(name='_build_success_command')
    become_module_1._build_success_command.return_value = 'built_success_command'
    actual = become_module_1.build_become_command(cmd_17, shell_18)

# Generated at 2022-06-25 08:18:37.532698
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test with None shell
    cmd = "/usr/bin/whoami"
    shell = None
    result = become_module._build_success_command(cmd,shell)
    assert result == cmd

    # Test with /bin/sh shell
    cmd = "/usr/bin/whoami"
    shell = "/bin/sh"
    result = become_module._build_success_command(cmd,shell)
    assert result == "'%s'" % cmd

    # Test with /bin/zsh shell
    cmd = "/usr/bin/whoami"
    shell = "/bin/zsh"
    result = become_module._build_success_command(cmd,shell)
    assert result == '%s -c "%s"' % (shell, cmd)

    # Test with /usr/bin/bash shell


# Generated at 2022-06-25 08:18:45.369019
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'test_cmd'
    shell = 'test_shell'
    become_module_0.get_option = MagicMock(return_value=None)
    become_module_0.get_option.return_value = None
    become_module_0.get_option.return_value = None
    become_module_0.get_option.return_value = None
    become_module_0.get_option.return_value = None
    become_module_0.get_option.return_value = None
    become_module_0._build_success_command = MagicMock(return_value='test_cmd')
    become_module_0._build_success_command.return_value = 'test_cmd'
    assert become_module_0.build_become_command

# Generated at 2022-06-25 08:18:48.524466
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    result = become_module_0.build_become_command(TEST_CMD, None)
    assert result == "sudo -H -S -n -p \"%s\" -u root %s" % (become_module_0.prompt, TEST_CMD)

# Generated at 2022-06-25 08:18:57.120975
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    assert become_module_0.build_become_command(["/bin/sh", "-c", "echo foo"], True) == "sudo -H -S -n /bin/sh -c 'echo foo'"


# Generated at 2022-06-25 08:19:08.722001
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.get_option = lambda option: None
    cmd = 'some command'
    shell = '/bin/sh'

    assert become_module_1._build_success_command(cmd, shell) == '-c %s' % shell
    assert become_module_1.build_become_command(cmd, shell) == 'sudo -H -S -n -c /bin/sh'

    become_module_2 = BecomeModule()
    become_module_2.get_option = lambda option: None
    become_module_2.get_option = lambda option: '/some/path/to/sudo' if option == 'become_exe' else None
    cmd = 'some command'
    shell = '/bin/sh'

    assert become_module_2._build_success_

# Generated at 2022-06-25 08:19:13.956198
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

# Generated at 2022-06-25 08:19:17.980093
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_method_0 = BecomeModule._build_become_command('become_exe_0', 'cmd_0')
    assert become_method_0 == 'sudo -H -S -n -p \"[via ansible, key=become_user] password:\" -u become_user success_cmd_0'

# Generated at 2022-06-25 08:19:27.591102
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # test example 1 with existing password parameter
    become_module_1 = BecomeModule()
    become_module_1.prompt = None
    become_module_1.get_option = lambda x: None
    become_module_1.get_option.__dict__['_ansible_check_mode'] = False
    become_module_1.get_option.__dict__['_ansible_no_log'] = True
    become_module_1.get_option.__dict__['_ansible_verbosity'] = 0
    become_module_1.get_option.__dict__['_ansible_selinux_special_fs'] = ["fuse", "nfs", "vboxsf", "ramfs"]

# Generated at 2022-06-25 08:19:33.684042
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_exe_0 = become_module_0.get_option('become_exe') or become_module_0.name
    flags_0 = become_module_0.get_option('become_flags') or ''
    prompt_0 = ''
    if become_module_0.get_option('become_pass'):
        prompt_0 = '-p "%s"' % (become_module_0.prompt)
    user_0 = become_module_0.get_option('become_user') or ''
    if user_0:
        user_0 = '-u %s' % (user_0)
    cmd_0 = 'this is a command'
    shell_0 = 'True'
    cmd_1 = become_module_0.build_become

# Generated at 2022-06-25 08:19:43.618254
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    becomecmd = "sudo"
    flags = "-H -S -n"
    prompt = "-p 'prompt:'"
    user = "-u root"
    cmd = "ls -l"
    shell = "/bin/sh"
    assert become_module_0.build_become_command(cmd, shell) == "sudo -H -S -n -p 'prompt:' -u root ls -l"

# Generated at 2022-06-25 08:19:56.402695
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case 0
    become_module_0 = BecomeModule()
    cmd = "echo 1"
    shell = "bash"
    become_exe_0 = ''
    become_flags_0 = '-H -S -n'
    become_pass_0 = ''
    become_module_0.set_options({'become_exe': become_exe_0, 'become_flags': become_flags_0, 'become_pass': become_pass_0})
    become_module_0.set_context(dict(become_check=dict()))
    output = become_module_0.build_become_command(cmd, shell)
    assert output == "sudo -H -S -n -S /bin/sh -c 'echo 1' 2> /dev/null"
    # Test case 1
    become_module

# Generated at 2022-06-25 08:20:06.717637
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Setup test environment
    become_module_1 = BecomeModule()
    become_module_1.get_option = MagicMock()
    become_module_1.get_option.side_effect = lambda x: {'become_exe': x,
        'become_flags': x, 'become_pass': x, 'become_user': x,
        '_build_success_command': x}[x]
    cmd = 'echo 0'
    shell = 'shell'
    become_cmd = 'sudo -H -S -n -p "password:" -u become_user _build_success_command'
    # Execute build_become_command method of become_module_1 object
    result = become_module_1.build_become_command(cmd, shell)
    raise_error = False
    assert_equal

# Generated at 2022-06-25 08:20:10.059309
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd, shell = 'cmd', 'shell'
    result = become_module.build_become_command(cmd, shell)
    assert result == 'sudo cmd'
