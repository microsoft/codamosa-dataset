

# Generated at 2022-06-25 08:15:26.885014
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo 'hello'"
    shell = '/bin/bash'
    become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:15:36.769129
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = "/foo bar"
    shell = "/bin/sh"

    becomecmd = become_module.get_option('become_exe') or become_module.name
    flags = become_module.get_option('become_flags') or ''
    prompt = ''
    user = become_module.get_option('become_user') or ''
    if user:
        user = '-u %s' % (user)
    assert become_module.build_become_command(cmd, shell) == ' '.join([becomecmd, flags, prompt, user, become_module._build_success_command(cmd, shell)])
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id

# Generated at 2022-06-25 08:15:40.643094
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.set_option('become_flags', '-H -S -n')
    become_module_1.set_option('become_exe', 'sudo')
    become_module_1.set_option('become_pass', None)
    assert become_module_1.build_become_command('whoami', 'shell') == 'sudo -H -S whoami'

# Generated at 2022-06-25 08:15:48.047054
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    #cmd, shell=None):
    become_module_1 = BecomeModule()

    # cmd = 'echo', shell = None
    assert become_module_1.build_become_command('echo', None) == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:"  echo' % become_module_1._id

    # cmd = 'ls', shell = True
    assert become_module_1.build_become_command('ls', True) == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:"  /bin/sh -c "ls"' % become_module_1._id

    # cmd = 'ls', shell = False

# Generated at 2022-06-25 08:15:52.104660
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Call build_become_command with cmd = 'ls' and shell = 'bash'
    result = become_module.build_become_command('ls', 'bash')
    assert result == 'sudo -p "[sudo via ansible, key=default] password:" -u root bash -c "ls"'


# Generated at 2022-06-25 08:15:55.324282
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('cmd', 'shell') == 'sudo -H -S -n  "cmd"'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:15:59.897498
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo this is a test'
    shell = '/bin/sh'
    become_module_0.get_option = MagicMock(return_value = '/usr/bin/sudo')
    become_module_0._build_success_command = MagicMock(return_value = 'echo this is a test')


# Generated at 2022-06-25 08:16:03.891170
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "ls"
    shell = "/bin/bash"
    result = become_module_0.build_become_command(cmd, shell)
    r_expected = "sudo  -H -S -n /bin/bash -c 'ls && sleep 0'"
    assert result == r_expected, "Failed to run build_become_command test_case_1"

# Generated at 2022-06-25 08:16:10.681843
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Ensure we have a user to run in
    become_module_0.set_options({'become_user': 'asdf'})
    c_cmd = 'nonsense'
    c_shell = '/bin/sh'
    actual_result = become_module_0.build_become_command(c_cmd, c_shell)
    expected_result = 'sudo -H -S -n -u asdf /bin/sh -c \'%s\'' % c_cmd
    assert(actual_result == expected_result)

# Generated at 2022-06-25 08:16:22.049565
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    # Test 1
    become_module_1.module._options['become_exe'] = 'sudo'
    become_module_1.module._options['become_flags'] = '-H -S -n'
    become_module_1.module._options['become_pass'] = 'test'
    become_module_1.module._options['become_user'] = 'ansible'
    cmd_1 = 'test'
    shell_1 = '/bin/sh'

# Generated at 2022-06-25 08:16:32.371250
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()

    # Test with no cmd
    become_module.get_option = lambda x: None
    assert become_module.build_become_command(None, None) == None

    # Test with cmd
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('/bin/ls', None) == "sudo -n true"

# Generated at 2022-06-25 08:16:42.353264
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('ls -l', 'sh') == 'sudo  -H -S -n  -u root sh -c \'echo ~ && ls -l\''
    assert become_module_0.build_become_command('ls -l', 'csh') == 'sudo  -H -S -n  -u root csh -c \'echo ~ && ls -l\''
    become_module_0.get_option = lambda *args: None
    assert become_module_0.build_become_command('ls -l', 'sh') == 'sudo  -H -S -n  sh -c \'echo ~ && ls -l\''

# Generated at 2022-06-25 08:16:50.899826
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_test = BecomeModule()
    assert become_module_test.build_become_command('') == 'sudo -H -S -n'
    assert become_module_test.build_become_command('', 'foo') == 'sudo -H -S -n'
    assert become_module_test.build_become_command('foo') == 'sudo -H -S -n foo'
    assert become_module_test.build_become_command('foo', 'shell') == 'sudo -H -S -n foo'

# Generated at 2022-06-25 08:16:59.554573
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.set_options({'become_pass': True})

    #
    # Test case: password required
    #
    cmd = "ls"
    expected_become_cmd = "sudo -p \"sudo via ansible, key=None] password:\" ls"
    become_cmd = become_module.build_become_command(cmd=cmd, shell='')
    assert become_cmd == expected_become_cmd

    #
    # Test case: no password required
    #
    become_module.set_options({'become_pass': False})
    cmd = "ls"
    expected_become_cmd = "sudo -n ls"
    become_cmd = become_module.build_become_command(cmd=cmd, shell='')
    assert become_cmd

# Generated at 2022-06-25 08:17:11.172962
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Case 1
    become_module.prompt = None
    cmd = 'ls'
    shell = '/bin/sh'
    become_module.get_option = lambda x: ''
    actual = become_module.build_become_command(cmd, shell)
    assert actual == 'sudo -H -S -n  /bin/sh -c \'LS_COLORS=""; export LS_COLORS; ls\' || (' \
                     'command -v python >/dev/null 2>&1 && python -c \'import os; os.execvp("ls", ["ls"])\')'

    # Case 2
    become_module.prompt = None
    cmd = 'ls'
    shell = '/bin/sh'
    become_module._build_success_command = lambda cmd, shell: 'ls'


# Generated at 2022-06-25 08:17:21.348838
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    become_module_0.prompt = '[sudo via ansible, key=06435d477b] password:'

    # Test for no options case
    # cmd = 'pwd'
    # shell = 'sh'
    # expected_result = 'sudo -H -S -n sh -c \'echo BECOME-SUCCESS-pjqkyvvrusauqwzx; LC_ALL=C /usr/bin/pwd\''
    # assert become_module_0.build_become_command(cmd, shell) == expected_result

    # Test for password option
    # cmd = 'pwd'
    # shell = 'sh'
    # expected_result = 'sudo -H -S -p "[sudo via ansible, key=06435d477b] password:" sh -

# Generated at 2022-06-25 08:17:30.561746
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ''
    shell = ''
    become_module_0.become_pass = ''
    become_module_0.prompt = ''
    become_module_0._id = ''
    become_module_0.become_flags = ''
    become_module_0.become_user = ''
    become_module_0._build_success_command = lambda cmd, shell: cmd
    value = become_module_0.build_become_command(cmd, shell)
    assert value == "sudo "

become_module_0 = BecomeModule()
become_module_1 = BecomeModule()


# Generated at 2022-06-25 08:17:31.433721
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    yield test_case_0
#

# Generated at 2022-06-25 08:17:35.499380
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    become_module_0.prompt = 'word'
    cmd = 'echo True'
    shell = 'False'

    otpt = become_module_0.build_become_command(cmd, shell)

    assert otpt == 'sudo -p "word" -u root echo True'

# Generated at 2022-06-25 08:17:45.540678
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """
    Testing BecomeModule.build_become_command() method
    """

    # Arrange

    become_module = BecomeModule()

    cmd = 'pwd'
    shell = '/sbin/nologin -s /bin/sh'

    # Act
    becomecmd = become_module.build_become_command(cmd, shell)

    # Assert

    assert becomecmd == 'sudo -H -S -n /sbin/nologin -s /bin/sh -c \'(exec /bin/sh -c "pwd" </dev/null; exit) | (read -p \"[sudo via ansible, key=None] password:\" REPLY; echo $REPLY)\''


# Generated at 2022-06-25 08:17:54.136100
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)



# Generated at 2022-06-25 08:18:02.771895
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    var_0 = BecomeModule()
    var_1 = None
    var_2 = set()
    # Testing for empty command
    var_3 = var_0.build_become_command(var_1, var_2)
    # Testing for empty command
    var_4 = var_0.build_become_command(var_1, var_2)
    # Testing if build_become_command returns a string
    assert isinstance(var_0.build_become_command(var_1, var_2), str)
    # Testing if become_exe is set to sudo or not
    assert 'sudo' == var_0.get_option('become_exe')
    # Testing if the output is same or not
    assert var_3 == var_4


# Generated at 2022-06-25 08:18:08.740575
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:18:10.271917
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert_equal(expected, BecomeModule.build_become_command(int_0, set_0))

# Generated at 2022-06-25 08:18:16.177722
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)
    var_0 = become_build_become_command(int_0, set_0)
    var_0 = become_build_become_command(int_0, set_0)
    var_0 = become_build_become_command(int_0, set_0)
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:18:25.179006
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = set()
    # The following test case is to test whether the assert (become_module_0.get_option('become_user') or '') is true and pass

    int_0 = 2
    assert (become_module_0.get_option('become_user') or '')
    # The following test case is to test whether the assert (become_module_0.get_option('become_exe') or become_module_0.name) is true and pass

    assert (become_module_0.get_option('become_exe') or become_module_0.name)
    # The following test case is to test whether the assert (((become_module_0.get_option('become_flags') or '').replace('-n', '') +

# Generated at 2022-06-25 08:18:27.225393
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Initialize become_module_0 object
    become_module_0 = BecomeModule()

    assert become_module_0 != None


# Generated at 2022-06-25 08:18:36.788759
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command("", "") == "sudo -- bash -c 'echo BECOME-SUCCESS-aaaa; %s'"
    assert become_module_0.build_become_command("", "") == "sudo -n -- bash -c 'echo BECOME-SUCCESS-aaaa; %s'"
    assert become_module_0.build_become_command("", "") == "sudo -n -p \"\" -- bash -c 'echo BECOME-SUCCESS-aaaa; %s'"

# Generated at 2022-06-25 08:18:40.274746
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Testcase 0
    test_case_0()

if __name__ == '__main__':
    # Unit test for method build_become_command of class BecomeModule
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:18:42.132011
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = 2
    shell = set()
    res = become_module_0.build_become_command(cmd, shell)

# Generated at 2022-06-25 08:18:50.432046
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 0
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:19:00.296835
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # @param become_module_0 Object of class BecomeModule to test
    # @param int_0 Value for become_module_0.get_option('become_exe')
    # @param set_0 Value for become_module_0.get_option('become_flags')
    become_module_0 = BecomeModule()
    int_0 = 2
    set_0 = set()
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert var_0 != None
    assert var_0 != ''

# Generated at 2022-06-25 08:19:03.386695
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = set()
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:19:05.549230
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = set()
    int_0 = 2
    become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:19:08.578853
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:19:09.884153
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert become_module_0.build_become_command(int_0, set_0) == var_0


# Generated at 2022-06-25 08:19:12.178859
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    #TODO: Test with different inputs and verify output
    test_case_0()


# Generated at 2022-06-25 08:19:13.821270
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # TODO: Unit test for method build_become_command of class BecomeModule
    pass

# Generated at 2022-06-25 08:19:19.203281
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Declaration of variables

    # Test commands

    # Test body

    # Test return value
    assert var_0 == 'sudo -H -S -n -p "[sudo via ansible, key=2] password:" -u root /bin/sh -c \'echo BECOME-SUCCESS-npbocdgzfkxzjgnxgozdvzvfhkxzwlbt; /usr/bin/python\''

# Generated at 2022-06-25 08:19:23.004267
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)

# Generated at 2022-06-25 08:19:36.120593
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    string_0 = become_module_0.build_become_command()

# Generated at 2022-06-25 08:19:41.931166
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 08:19:46.088929
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    set_0 = set()
    int_0 = 2
    var_0 = become_module_0.build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:19:48.663147
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:19:52.051736
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    set_0 = set()
    int_0 = 2
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)



# Generated at 2022-06-25 08:19:55.798697
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    int_0 = 0
    set_0 = set()
    var_0 = become_build_become_command(int_0, set_0)
    if (var_0 is None):
        print('Test passed!')
    else:
        print('Test failed!')



# Generated at 2022-06-25 08:20:06.246349
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.name = 'sudo'
    become_module_0.fail = ('Sorry, try again.',)
    become_module_0.missing = ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    var_0 = become_module_0.build_become_command('ls', False)
    var_1 = become_module_0.build_become_command('ls', True)
    var_2 = become_module_0.build_become_command('sudo -s', False)
    var_3 = become_module_0.build_become_command('sudo -s', True)
    set_0 = set()
    var_4 = become_module_0.build_become_command('ls', set_0)



# Generated at 2022-06-25 08:20:10.476374
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Setup
    int_0 = 2
    set_0 = set()

    # Run
    become_module_0 = BecomeModule()
    result_0 = become_module_0.build_become_command(int_0, set_0)



# Generated at 2022-06-25 08:20:14.387251
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    arg_0 = 2
    arg_1 = set()
    become_module_0 = BecomeModule()
    become_module_0.build_become_command(arg_0, arg_1)

# Generated at 2022-06-25 08:20:22.564525
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    ansible_0 = AnsibleModule()
    become_module_0.get_option = MagicMock()
    become_module_0._build_success_command = MagicMock()

    ansible_0.module_utils.basic._ANSIBLE_ARGS = MagicMock()
    ansible_0.get_bin_path = MagicMock()
    ansible_0.get_bin_path.return_value = 'any_string'
    ansible_0.templar = MagicMock()
    become_module_0.templar = ansible_0.templar
    set_0 = set()
    exp_0 = False
    ansible_0.templar.template.return_value = exp_0
    ansible_0.get_bin_path

# Generated at 2022-06-25 08:20:43.016274
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)
    exceptions.AssertionError()


# Generated at 2022-06-25 08:20:45.950170
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = 'set this'
    shell_0 = '/usr/bin/sh'

    # Call method
    result_0 = become_module_0.build_become_command(cmd_0, shell_0)

    # Check result
    assert result_0.startswith('sudo -H -S -n /usr/bin/sh -c \'set this ; echo ansible_become_ok') is True


# Generated at 2022-06-25 08:20:51.695995
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    try:
        self.assertEqual(int_0, var_0)
    except AssertionError as e:
        print('AssertionError: ', e)
        print('Expected: ', int_0, 'Actual: ', var_0)

# Generated at 2022-06-25 08:20:52.665790
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

# Generated at 2022-06-25 08:20:55.746506
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    int_0 = 2
    set_0 = set()
    become_module_0.build_become_command(int_0, set_0)

# Generated at 2022-06-25 08:21:01.669433
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # int_0 = 2
    # set_0 = set()


# Generated at 2022-06-25 08:21:05.008481
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)

# Generated at 2022-06-25 08:21:12.909994
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

  # Test case for first if condition.
  int_0 = None
  set_0 = set()
  become_module_0 = BecomeModule()
  var_1 = become_build_become_command(int_0, set_0)
  # Assertion
  assert var_1 is None

  # Test case for second if condition.
  int_1 = ""
  set_0 = set()
  become_module_0 = BecomeModule()
  var_1 = become_build_become_command(int_1, set_0)
  # Assertion
  assert var_1 is None

  # Test case for final else condition.
  int_2 = "/bin/ls"
  set_0 = set()
  become_module_0 = BecomeModule()
  var_1 = become_build_become_command

# Generated at 2022-06-25 08:21:15.643630
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int0 = 2
    set0 = set()
    become_module0 = BecomeModule()
    become_build_become_command(int0, set0)


# Generated at 2022-06-25 08:21:21.232426
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:21:57.680190
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # This test case is based on an issue reported in PR #38684.
    set_0 = {'16', 'roles/cloud-sql-proxy', None, 0, 'foobar'}
    int_0 = 1
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(set_0, int_0)
    pass



# Generated at 2022-06-25 08:22:05.051868
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)
    if (not (var_0 == become_module_0)):
        raise ValueError


if (__name__ == '__main__'):
    test_case_0()

# Generated at 2022-06-25 08:22:07.588551
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_0 = become_module_1
    int_0 = 2
    set_0 = set
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert (var_0 is not None)


# Generated at 2022-06-25 08:22:13.057371
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    fail = ({'fail', 'missing'}, 'Sorry, try again.',)
    set_0 = set()
    become_module_0 = BecomeModule()
    become_module_0.prompt = '[sudo via ansible, key=%s] password:' % become_module_0._id
    var_0 = become_build_become_command(becomecmd, shell)
    fail[1] = ('Sorry, try again.',)
    fail[0].add('missing')
    fail[0].add('fail')
    become_module_0._build_success_command(cmd, shell)


# Generated at 2022-06-25 08:22:15.888410
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:22:22.211914
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    set_0 = set()
    int_0 = 2
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert var_0 is not None

# Generated at 2022-06-25 08:22:23.639535
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Inject the build_become_command method on the class to be tested
    BecomeModule.build_become_command = become_build_become_command
    # Call the method
    test_case_0()


# Generated at 2022-06-25 08:22:26.935260
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 1
    set_0 = set()

    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert var_0 is not None

# Testing method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:22:31.100439
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    var_0 = [2, set()]  # var_0
    become_module_0 = BecomeModule()
    become_module_1 = BecomeModule()

    var_1 = become_module_0.build_become_command(var_0[0], var_0[1])

    var_2 = become_module_1.build_become_command(var_0[0], var_0[1])

    assert var_1 == var_2

# Generated at 2022-06-25 08:22:34.390915
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_0()

# Generated at 2022-06-25 08:23:47.315618
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:23:49.333694
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    int_0 = 2
    set_0 = set()
    var_0 = become_build_become_command(int_0, set_0)

# Generated at 2022-06-25 08:23:51.556198
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_case_0()


# Generated at 2022-06-25 08:23:59.473555
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Tests against a generated command using the defaults

    generated_cmd = "sudo -H -S -n -p '[sudo via ansible, key=9e80efa7b4e2f8d54e54530a3da06ac3] password:' -u root  'echo BECOME-SUCCESS-oidmhfvptdzgzyphtcwjwzfhifvmelnns' && sleep 0"

    test_cmd = "echo BECOME-SUCCESS-oidmhfvptdzgzyphtcwjwzfhifvmelnns"
    become_module = BecomeModule()
    become_module._id = "9e80efa7b4e2f8d54e54530a3da06ac3"
    ansible_shell = set()
    actual_command = become_

# Generated at 2022-06-25 08:24:05.311739
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # mock for sudo
    sudo = mocker.Mock(name="sudo")
    sudo.configure_mock(
        get_option=lambda x: {
            "become_exe": "sudo",
            "become_flags": "-H -S -n",
            "become_pass": None,
            "become_user": "root"
        }.get(x),
        prompt="[sudo via ansible, key=%s] password:"
    )
    # execute test
    assert become_module_0.build_become_command(int_0, set_0) == "sudo -H -S -n root"


# Generated at 2022-06-25 08:24:14.908260
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # test_case_0
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_build_become_command(int_0, set_0)
    int_0 = 3
    set_0 = set()
    var_0 = become_build_become_command(int_0, set_0)
    int_0 = 2
    set_0 = None
    var_0 = become_build_become_command(int_0, set_0)
    int_0 = 3
    set_0 = None
    var_0 = become_build_become_command(int_0, set_0)


# Generated at 2022-06-25 08:24:22.440481
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-25 08:24:24.105461
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module_0 = BecomeModule()
    var_0 = module_0.build_become_command()


# Generated at 2022-06-25 08:24:27.719090
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    int_0 = 2
    set_0 = set()
    become_module_0 = BecomeModule()
    var_0 = become_module_0.build_become_command(int_0, set_0)
    assert var_0 is None


# Generated at 2022-06-25 08:24:34.803846
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Instantiate BecomeModule
    become_module_0 = BecomeModule()
    # set values
    become_module_0
    become_module_0.get_option = MagicMock(return_value='sudo')
    # set values
    become_module_0
    become_module_0.get_option = MagicMock(return_value='')
    # set values
    become_module_0
    become_module_0.get_option = MagicMock(return_value='mike')
    # set values
    become_module_0
    become_module_0.get_option = MagicMock(return_value='sudo')
    # set values
    become_module_0
    become_module_0.get_option = MagicMock(return_value='')
    # set values
    become_module_