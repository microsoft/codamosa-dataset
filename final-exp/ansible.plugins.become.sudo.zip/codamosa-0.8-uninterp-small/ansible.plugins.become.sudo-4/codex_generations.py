

# Generated at 2022-06-25 08:15:29.940269
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'string'
    shell = 'string'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n -p "%s" -u %s %s %s' % ("[sudo via ansible, key=%s] password:" % become_module_0._id, become_module_0.get_option('become_user') or '', become_module_0._build_success_command(cmd, shell), shell)

# Generated at 2022-06-25 08:15:33.989563
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd = 'uname'
    shell = '/bin/bash'
    assert become_module_1.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/bash -c \'echo ~ && sleep 0\' && /bin/bash -c \'uname && sleep 0\' || /bin/bash -c \'echo BECOME-SUCCESS-nqucgosicfghjpavumlrzkxefyj; /bin/bash -c "uname" && sleep 0\''


# Generated at 2022-06-25 08:15:38.441061
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    become_module.build_become_command("echo 'test'", None)
    become_module.build_become_command("echo 'test'", "")
    become_module.build_become_command("echo 'test'", "sh")
    become_module.build_become_command("echo 'test'", "bash")

# Generated at 2022-06-25 08:15:47.698124
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = 'command'
    shell = False

    become_module = BecomeModule()
    become_module._id = '0'
    become_module.get_option = lambda option: None
    become_module._low_level_shell = False
    become_module._shell = False
    become_module._connection = None
    become_module._sub_become_method = None
    become_module._sub_become_exe = None
    become_module._sub_become_user = None
    become_module._sub_become_flags = None
    become_module._sub_become_pass = None
    become_module._sub_become_prompt = None
    become_module._sub_become_exe_args = None
    become_module.prompt = None

    assert become_module.build_become_

# Generated at 2022-06-25 08:15:53.918823
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    exit_0, stdout_1, stderr_1 = become_module_1.build_become_command('whoami', '/bin/sh')
    assert exit_0 == 0
    assert stdout_1 == ''
    assert stderr_1 == ''
    exit_2, stdout_3, stderr_3 = become_module_1.build_become_command('whoami', '/bin/sh')
    assert exit_2 == 0
    assert stdout_3 == ''
    assert stderr_3 == ''

# Generated at 2022-06-25 08:16:01.062080
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    # case 0
    assert become_module_1.build_become_command(cmd=None, shell=False) == None
    # case 1
    assert become_module_1.build_become_command(cmd='cmd', shell=None) == 'cmd'
    # case 1
    assert become_module_1.build_become_command(cmd='cmd', shell=False) == 'cmd'
    # case 1
    assert become_module_1.build_become_command(cmd='cmd', shell=True) == 'bash -c "cmd" && exit 0'

# Generated at 2022-06-25 08:16:08.814196
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'when run sudo -H -S -n -p \"[sudo via ansible, key=None] password:\" -u ansible_user "echo Foo &gt; bar.txt" 2&gt;/dev/null &gt;/dev/null'
    assert become_module_0.build_become_command(cmd, shell=False) == 'when run sudo -H -S -n -p \"[sudo via ansible, key=None] password:\" -u ansible_user "echo Foo &gt; bar.txt" 2&gt;/dev/null &gt;/dev/null'

# Generated at 2022-06-25 08:16:16.172548
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  become_module = BecomeModule()
  ret = become_module.build_become_command(cmd='ls', shell='ls')
  print (ret)

if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:16:21.322058
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # test case:
    become_module_1 = BecomeModule()
    # run the test:
    result = become_module_1.build_become_command('echo "hello world"', True)
    # assert the result
    assert(result == 'sudo -H -S -n /bin/sh -c \'"\'"\'echo "hello world" && sleep 0\'"\'"\'')


# Generated at 2022-06-25 08:16:30.227683
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_options({'become_user': u'root'})
    become_module_0.set_options({'become_exe': 'sudo'})
    become_module_0.set_options({'become_pass': 'secret'})
    become_module_0.set_options({'verbosity': 0})
    # Test skipping due to missing command
    assert become_module_0.build_become_command(None, True) is None
    # Test command built and with correct prompt
    assert become_module_0.build_become_command('ls', True) == "sudo -n -H -S -p \"sudo password: \" -u root \"ls && echo success\""


# Generated at 2022-06-25 08:16:41.091697
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    # Test with a command that contains single or double quotes.
    cmd_1 = """false"""
    become_module_1.build_become_command(cmd_1, "shell")
    # Test with a command that contains single or double quotes.
    cmd_2 = """false"""
    become_module_1.build_become_command(cmd_2, "shell")

# Generated at 2022-06-25 08:16:49.529675
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "echo 'Hello World'"
    shell = 'sh'

    expected_result = "sudo  -H -S -n  -p \"\"  -u root  sh -c 'echo '\''Hello World'\''' 2>&1"
    result = become_module_0.build_become_command(cmd, shell)
    assert result == expected_result

# Generated at 2022-06-25 08:16:58.081592
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()

    # 1.
    #
    # Test case 1
    #
    # No options set, except for become_exe, which is set to sudo by
    # default.
    #

    assert become_module_0.build_become_command("whoami", True) == "sudo -H -S -n -p \"SUDO-SUCCESS-tjgx5tlwcwntpeih\" /bin/sh -c 'echo ~ && sleep 0' && whoami"


    # 2.
    #
    # Test case 2
    #
    # become_flags set to -u user, this should make the built command look
    # like:
    #
    # sudo -u user -H -S -n -p "SUDO-SUCCESS-tjgx5

# Generated at 2022-06-25 08:17:04.277523
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = "rm -rf /root/test.yaml"
    shell = "/bin/sh"

    become_command = become_module.build_become_command(cmd, shell)

    assert become_command == "sudo -H -S rm -rf /root/test.yaml"

# Generated at 2022-06-25 08:17:13.480918
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Example command
    example_cmd = 'echo test command'

    # Example shell value
    example_shell = False

    # Example options
    example_options = {
        'become_flags': '',
        'become_user': 'example user',
        'become_pass': 'example password',
        'become_exe': 'sudo',
    }

    # Expected result
    expected_result = 'sudo -H -S -u example user -p "[sudo via ansible, key=0] password:" "echo test command"'

    become_module_1 = BecomeModule()

    actual_result = become_module_1.build_become_command(example_cmd, example_shell)

    assert expected_result == actual_result, "Expected: {} != Actual: {}".format(expected_result, actual_result)

# Generated at 2022-06-25 08:17:15.928967
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('ls', False) is None


# Generated at 2022-06-25 08:17:25.295915
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

# Generated at 2022-06-25 08:17:34.947609
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = '0'
    become_module.prompt = ''
    cmd = "command"
    shell = "shell"
    becomecmd = become_module.build_become_command(cmd, shell)
    assert "sudo -H -S" in becomecmd
    assert "sudo via ansible, key=0" in becomecmd
    become_module._id = '1'
    becomecmd = become_module.build_become_command(cmd, shell)
    assert "sudo via ansible, key=1" in becomecmd
    become_module.prompt = 'test'
    becomecmd = become_module.build_become_command(cmd, shell)
    assert "test" in becomecmd
    assert '-n' in becomecmd



# Generated at 2022-06-25 08:17:42.285904
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('whoami', False) == 'sudo -H -S -n -p "Sorry, a password is required to run sudo" '
    assert become_module_0.build_become_command('/usr/bin/whoami', False) == 'sudo -H -S -n -p "Sorry, a password is required to run sudo" '
    assert become_module_0.build_become_command('whoami', True) == 'sudo -H -S -n -p "Sorry, a password is required to run sudo" /bin/sh -c '

# Generated at 2022-06-25 08:17:44.504452
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'ls -l'
    shell = '/bin/sh'
    assert(become_module_0.build_become_command(cmd, shell) == 'sudo -H -S \'-p "\'\'[sudo via ansible, key=None] password:\'\'\'\'" ls -l')


# Generated at 2022-06-25 08:18:01.530001
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    become_module.set_option('become_exe', 'sudo')
    become_module.set_option('become_user', 'root')
    become_module.set_option('become_flags', '-H -S -n')
    become_module.set_option('become_pass', '')

    cmdline = 'echo hello'
    shell = '/bin/sh'

    become_cmdline = become_module.build_become_command(cmdline, shell)

    assert become_cmdline == "sudo -H -S -n 'echo hello'"

# Generated at 2022-06-25 08:18:03.527600
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'echo 123'
    shell = 'sh'
    assert become_module_0.build_become_command(cmd, shell) == 'sudo -H -S -n echo 123'

# Generated at 2022-06-25 08:18:09.202039
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'cmd'
    shell = 'shell'
    result = become_module_0.build_become_command(cmd, shell)
    assert result == 'sudo -S -n \'cmd\''


# Generated at 2022-06-25 08:18:15.544514
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = "ls -l"

    # Call build_become_command with shell=True
    assert become_module.build_become_command(cmd, shell=False) == 'sudo -H -S -n ls -l'
    assert become_module.build_become_command(cmd, shell=True) == 'sudo -H -S -n /bin/sh -c "ls -l"'
    assert become_module.build_become_command(cmd, shell=True) == become_module.build_become_command(cmd, shell=True)



# Generated at 2022-06-25 08:18:23.497799
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  # Instantiate an instance of BecomeModule
  become_module_0 = BecomeModule()
  # Create a variable for argument 'cmd'
  cmd_1 = 'test'
  # Create a variable for argument 'shell'
  shell_1 = None
  # Call become_module_0.build_become_command with the values, 
  # cmd_1 for the argument 'cmd' and 
  # shell_1 for the argument 'shell'
  # and return the method's return value to a variable
  value = become_module_0.build_become_command(cmd_1, shell_1)
  print(value)


# Generated at 2022-06-25 08:18:29.237986
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.set_options({'become_user':'root'})
    become_module_1.set_options({'become_pass':'test'})

    cmd = '/bin/ls'
    shell = '/bin/bash'
    # create array of expected and actual return values

# Generated at 2022-06-25 08:18:35.070526
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    # Input params
    cmd = ''
    shell = 'sh'
    # Output returns
    output = become_module_0.build_become_command(cmd, shell)
    # Assertions
    assert output == ''

# Generated at 2022-06-25 08:18:44.565113
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    become_module_1.vars = dict()
    become_module_1.vars['ansible_become_exe'] = 'sudo'
    become_module_1.vars['ansible_become_user'] = 'root'
    become_module_1.vars['ansible_become_pass'] = 'ansible'
    become_module_1.vars['ansible_become_flags'] = '-H -S -n'
    cmd = "echo 'Hello' ; echo 'World'"
    result = become_module_1.build_become_command(cmd, 'shell')

# Generated at 2022-06-25 08:18:48.011043
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_obj = BecomeModule()
    assert become_module_obj.build_become_command(cmd='command', shell='shell') == 'sudo -H -S -n command'
    assert become_module_obj.build_become_command(cmd='command', shell='shell') == 'sudo -H -S -n command'

# Generated at 2022-06-25 08:18:55.545248
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_option('become_pass', False)
    cmd_0 = 'some_command'
    shell_0 = 'some_shell'
    succeed = become_module_0.build_become_command(cmd_0, shell_0)
    assert 'sudo' in succeed

# Generated at 2022-06-25 08:19:04.714057
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'test'
    shell = 'test'
    become_module_0.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:19:06.984968
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Case 0
    cmd = "echo Hello world"
    shell = "/bin/bash"

    result = become_module.build_become_command(cmd, shell);

    assert result == 'sudo '

# Generated at 2022-06-25 08:19:09.676325
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = "hostname"

    assert become_module_0.build_become_command(cmd, shell) == "sudo -H -S -n hostname"

# Generated at 2022-06-25 08:19:15.121099
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()

    cmd = ""
    shell = ""
    expected_cmd = "sudo "
    assert become_module_0.build_become_command(cmd, shell) == expected_cmd

    cmd = "sh"
    shell = ""
    expected_cmd = "sudo  sh"
    assert become_module_0.build_become_command(cmd, shell) == expected_cmd

    cmd = "echo test"
    shell = "/bin/sh"
    expected_cmd = "sudo sh -c 'echo test'"
    assert become_module_0.build_become_command(cmd, shell) == expected_cmd

    cmd = "test"
    shell = "/bin/sh"
    expected_cmd = "sudo sh -c 'test'"
    assert become_module_0.build_become

# Generated at 2022-06-25 08:19:17.749108
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    
    cmd = 'pwd'
    shell = 'sh'

    become_module_1.build_become_command(cmd, shell)


# Generated at 2022-06-25 08:19:27.454232
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Initialize become_module_1
    become_module_1 = BecomeModule()

    # Initialize input parameters
    cmd = "/usr/bin/python -c 'import os; print os.environ' >/tmp/test_build_become_command.output"
    shell = '/bin/bash'
    become_module_1.prompt = "Password:"

    # Run method build_become_command of become_module_1 and set actual to the output
    actual = become_module_1.build_become_command(cmd, shell)

    # Set expected to expected result
    expected = "sudo -S -p \"Password:\" -u root /bin/bash -lc 'import os; print os.environ' >/tmp/test_build_become_command.output"

    # Compare actual with expected

# Generated at 2022-06-25 08:19:35.421034
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ["echo", "'foo'"]
    shell = False
    expected = "sudo -H -S -n -p \"Sorry, a password is required to run sudo\" -u root echo 'foo'"

    result = become_module_0.build_become_command(cmd, shell)
    if result != expected:
        raise AssertionError("Result = %s, Expected = %s" %(result, expected))


# Generated at 2022-06-25 08:19:48.292325
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bc = BecomeModule()

    # Testing command with shell quoted ';'
    bc._id = '123'
    bc.prompt = '[sudo via ansible, key=123] password:'
    cmd = 'cat /tmp/passwd; echo "123" >> /tmp'
    expected_cmd = "sudo -H -S -p '%s' -u root sh -c 'echo BECOME-SUCCESS-123; %s'" % (bc.prompt, bc._shell._quote(cmd))
    assert bc.build_become_command(cmd, bc._shell) == expected_cmd

    # Testing command with shell quoted ';' and changed option values
    bc._id = '456'
    bc.prompt = '[sudo via ansible, key=456] password:'

# Generated at 2022-06-25 08:19:57.382402
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case 0
    become_module_0 = BecomeModule()

    # Test case 1
    become_module_1 = BecomeModule()
    become_module_1._id = 'e7952a8c13ac9acf54e66b2d2f8ceebc'
    become_module_1.prompt = ''
    become_module_1.get_option = lambda _: ''

    # Test case 2
    become_module_2 = BecomeModule()
    become_module_2._id = '49e7f181e2fb8fe7d4a4c661d4f9b41c'
    become_module_2.prompt = ''
    become_module_2.get_option = lambda _: 'sudo_become_plugin'

    # Test case 3
    become_module_3 = Become

# Generated at 2022-06-25 08:20:02.331751
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'test'
    shell = True
    assert become_module_0.build_become_command(cmd, shell) == 'sudo env sudo_flags="-H -S -n" sudo_prompt="[sudo via ansible, key=%(become_identity)s] password:" sudo_user=""  test'

# Generated at 2022-06-25 08:20:29.212322
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    hasattr(become_module_0, '_id')
    become_module_0._id = '9a959e38da3dd76a2565a1b1e25b8a8b'
    command = 'echo test'
    shell = '/usr/bin/sh'
    become_module_0.get_option = lambda self, x: None
    become_module_0.get_option = lambda self, x: '-S -H -n'
    become_module_0.get_option = lambda self, x: ''
    cmd = become_module_0.build_become_command(command, shell)

# Generated at 2022-06-25 08:20:39.227936
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module_0 = BecomeModule()
    # Test with cmd = ['a', 'b'] and shell = False
    cmd = ['a', 'b']
    shell = False
    # Test with become_exe = '' and become_flags = '' and become_pass = '',
    # user = ''
    become_module_0.set_options(become_exe='', become_flags='', become_pass='', user='')
    output = "'sudo ' '-n' ' ' 'a b'"
    assert become_module_0.build_become_command(cmd,shell) == output

    # Test with become_exe = 'SUDO' and become_flags = '-H -S -n' and become_pass = '',
    # user = 'root'

# Generated at 2022-06-25 08:20:47.921631
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_options({'become_exe': 'sudo', 'become_flags': '-p %(become_prompt)s', 'become_pass': True, 'become_user': 'root'})
    become_module_0._id = 'some id'
    become_module_0.prompt = 'Password:'
    cmd = 'some command'
    shell = False
    result = become_module_0.build_become_command(cmd, shell)
    assert result == 'sudo -p "[sudo via ansible, key=some id] password:" -u root "some command"'

# Generated at 2022-06-25 08:20:53.951872
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd_0 = str()
    shell_0 = str()
    become_cmd_str_0 = str()

    become_cmd_str_1 = become_module_0.build_become_command(cmd_0, shell_0)

    assert become_cmd_str_0 == become_cmd_str_1

# Generated at 2022-06-25 08:20:58.771833
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'cmd'
    shell = 'shell'

    # Verify return value
    assert(become_module_0.build_become_command(cmd, shell) == "sudo -H -S -n -p \"[sudo via ansible, key=%s] password:\" -u root \"{0}\"".format(cmd))

# Generated at 2022-06-25 08:21:03.712308
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    str_arg_0 = 'foo'
    bool_arg_0 = True
    become_module_0.build_become_command(str_arg_0, bool_arg_0)


# Generated at 2022-06-25 08:21:08.722776
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = '\'cmd\''
    shell = ''
    result = True
    if become_module_0.build_become_command(cmd, shell) != '\' sudo -H -S -n \'cmd\'':
        result = False
    if result is True:
        print('Unit test for method build_become_command of class BecomeModule is passed')
    else:
        print('Unit test for method build_become_command of class BecomeModule is failed')


# Generated at 2022-06-25 08:21:13.281961
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    become_module_0.set_options({})
    become_module_0._id = '1'
    become_module_0.is_playbook = False
    become_module_0.prompt = ''
    become_module_0.sensitive_output = False
    become_module_0.get_option = BecomeModule.get_option
    become_module_0._build_success_command = become_module_0.build_success_command
    if become_module_0.__class__.__name__ not in ('BecomeModule', ):
        return
    string_0 = 'sh -c \'echo BECOME-SUCCESS-1; /bin/sh\'\n'
    # become_module_0._id = '1'

# Generated at 2022-06-25 08:21:17.984467
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = 'echo hello'
    shell = '/bin/bash'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == 'sudo -H -S -n /bin/bash -c \'%s\'' % cmd

    options = { 'become_pass': 'abcd' }
    become_module = BecomeModule(
        task_vars={},
        options=options,
        become_loader=None
    )
    actual = become_module.build_become_command(cmd, shell)
    assert actual == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" /bin/bash -c \'%s\'' % (become_module._id, cmd)

# Generated at 2022-06-25 08:21:25.225191
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()
    cmd_1 = "echo 'hello world'"
    shell_1 = True
    result_1 = become_module_1.build_become_command(cmd_1, shell_1)
    assert result_1 == "sudo -H -S -n -p \"Sorry, a password is required to run sudo: \" /bin/sh -c 'echo '\"'\"'hello world'\"'\"' && echo '\"'\"'SUDO-SUCCESS-xxxxx'\"'\"'' || echo '\"'\"'SUDO-FAILURE-xxxxx'\"'\"''\n"


# Generated at 2022-06-25 08:21:59.993763
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = ['']
    shell = False
    result = become_module_0.build_become_command(cmd, shell)
    print('Expected: sudo ansible_become_exe', 'Returned: ' + str(result))


# Generated at 2022-06-25 08:22:02.153443
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module_0 = BecomeModule()
    cmd = ''
    shell = ''

    # Call method
    c = become_module.build_become_command(cmd, shell)
    assert c == cmd


# Generated at 2022-06-25 08:22:07.490187
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command("echo 'Hello World'", shell=False) == \
        'sudo -H -S -n -p "[sudo via ansible, key=7e5c5d5edfdbc6f9ce914d0c8f66cf67] password:" -u root echo \'Hello World\''
    assert become_module.build_become_command("echo 'Hello World'", shell=True) == \
        'sudo -H -S -n -p "[sudo via ansible, key=7e5c5d5edfdbc6f9ce914d0c8f66cf67] password:" -u root bash -c "echo \'Hello World\'"'



# Generated at 2022-06-25 08:22:12.889715
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_1 = BecomeModule()

    print('Test 0, return value of method build_become_command:')
    print('  build_become_command(cmd="echo test", shell="/bin/bash")')

# Generated at 2022-06-25 08:22:16.564860
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    cmd = "ls"
    shell = "shell"
    become_module.build_become_command(cmd, shell)

if __name__ == '__main__':
    test_case_0()
    test_BecomeModule_build_become_command()

# Generated at 2022-06-25 08:22:19.492202
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    cmd = 'cmd'
    shell = False
    expected_result = 'sudo -H -S -n cmd'
    assert become_module_0.build_become_command(cmd, shell) == expected_result


# Generated at 2022-06-25 08:22:28.770139
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    assert become_module.build_become_command("cmd", False) == "sudo -H -S -n  cmd"
    assert become_module.build_become_command("cmd", True) == "sudo -H -S -n 'cmd'"
    become_module.flags = "-H -S -n"
    assert become_module.build_become_command("cmd", False) == "sudo -H -S -n  cmd"
    assert become_module.build_become_command("cmd", True) == "sudo -H -S -n 'cmd'"
    become_module.flags = ""
    assert become_module.build_become_command("cmd", False) == "sudo -H -S -n  cmd"

# Generated at 2022-06-25 08:22:35.031220
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_test_0 = BecomeModule()
    become_module_test_0.set_option(module_utils.Basic._load_params('become_flags', '-H -S', 'become_flags', '="/usr/bin/sudo"', 'become_pass'))
    become_module_test_0.set_option(module_utils.Basic._load_params('become_pass', '123456', 'become_pass', '"123456"', 'become_pass'))
    become_module_test_0.set_option(module_utils.Basic._load_params('become_exe', '"/usr/bin/sudo"', 'become_exe', '="sudo"', 'become_exe'))

# Generated at 2022-06-25 08:22:42.154576
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda name : None
    cmd = 'some command'
    shell = True
    expected_result = ' '.join(['sudo', '', '', '', become_module._build_success_command(cmd, shell)])
    result = become_module.build_become_command(cmd, shell)
    assert expected_result == result

# Generated at 2022-06-25 08:22:44.650895
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_0 = BecomeModule()
    assert become_module_0.build_become_command('ls') == 'sudo -H -S -n -p "Sorry, a password is required to run sudo" ls'
test_BecomeModule_build_become_command()