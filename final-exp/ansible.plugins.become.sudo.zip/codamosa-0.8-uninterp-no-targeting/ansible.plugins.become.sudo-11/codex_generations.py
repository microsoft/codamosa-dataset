

# Generated at 2022-06-21 03:34:22.830060
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # import library
    import sys
    sys.path.append('/usr/share/ansible')

    # init object
    obj = BecomeModule()
    obj.get_option = lambda x: None

    # test cases
    ###
    # exception
    ###
    # cannot find option
    try:
        obj.build_become_command(None, None)
    except RuntimeError as e:
        assert e.args[0] == 'Internal Error: this module should not be used with become'
    # cannot find flag name
    obj.get_option = lambda x: None if x == 'become_flags' else ''
    try:
        obj.build_become_command(None, None)
    except RuntimeError as e:
        assert e.args[0] == 'Internal Error: this module requires become_flags'

   

# Generated at 2022-06-21 03:34:34.474299
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Init and create instance of class
    b = BecomeModule(dict(), 'ansible')
    # Test with cmd and shell and sudo_user
    cmd = ['ls', '-la']
    shell = 'ansibleshell'
    b.set_options(dict(become_user='ansible'))
    b.set_options(dict(become_flags='-H -S -n'))
    actual = b.build_become_command(cmd, shell)
    expected = 'sudo -H -S -n -p "[sudo via ansible, key=ansible] password:" -u ansible ansibleshell -c \'setfacl -R -m u:"www-data":rwX -m u:`whoami`:rwX /var/www/ && ls -la\''

# Generated at 2022-06-21 03:34:44.286174
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # mock class BecomeBase
    class BecomeBaseMock(object):
        def get_option(self, k):
            return None

    # mock class PlayContext
    class PlayContextMock(object):
        def __init__(self, is_become):
            self.become = is_become
            self.become_method = 'sudo'
            self.become_user = 'tom'
    
    # setup module
    test_module = BecomeModule()
    test_module.get_option = BecomeBaseMock.get_option
    test_module._id = 1
    test_module.prompt = ''
    test_module._build_success_command = BecomeBase._build_success_command

    test_play_context = PlayContextMock(False)

# Generated at 2022-06-21 03:34:54.923375
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    """
    Test become module
    """
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    become_module = BecomeModule(play_context)

    options = {
        'become_exe': 'sudo',
        'become_flags': '',
        'become_user': 'root',
        'become_pass': '',
    }

    option_vars = {
        'ansible_become_exe': 'sudo',
        'ansible_become_flags': '',
        'ansible_become_user': 'root',
        'ansible_become_pass': '',
    }

    become_module._id = 'password'
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module

# Generated at 2022-06-21 03:35:06.239919
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # to be able to run this test independently outside of ansible,
    # we need to simulate a fake AnsibleOptions object.
    class AnsibleOptions():
        def __init__(self,
                     become_flags = '',
                     become_pass = '',
                     become_exe = '',
                     become_user = ''):
            self.become_flags = become_flags
            self.become_pass = become_pass
            self.become_exe = become_exe
            self.become_user = become_user
    my_opt = AnsibleOptions()


# Generated at 2022-06-21 03:35:13.496771
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    b = BecomeModule()
    assert hasattr(b, 'name')
    assert hasattr(b, 'build_become_command')
    assert hasattr(b, 'fail')
    assert hasattr(b, 'missing')
    # Make sure that a failed attempt triggers the right error message
    assert b.fail[0] == 'Sorry, try again.'
    # Make sure that missing sudo rights trigger the right error message
    assert b.missing[0] == 'Sorry, a password is required to run sudo'

# Generated at 2022-06-21 03:35:19.038612
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    module = BecomeModule(get_option=lambda x: None)
    module.build_become_command(cmd='whoami', shell='/bin/bash')
    assert module.fail == ('Sorry, try again.',)
    assert module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')



# Generated at 2022-06-21 03:35:29.257436
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Create a BecomeModule with all options
    bm_1 = BecomeModule(play_context=None, connection=None, become_app=None, become_exe=None, become_flags=None, become_pass=True, become_user=None, become_password=None)

    assert bm_1.name == 'sudo'
    assert bm_1.fail == ('Sorry, try again.',)
    assert bm_1.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

    assert bm_1._validate_options() == False

    # Create a BecomeModule with no options

# Generated at 2022-06-21 03:35:40.270439
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    import json
    from ansible.plugins.loader import become_loader

    class MockOptions():
        sudo_pass = None
        become_pass = None
        become_prompt = None
        become_method = 'sudo'
        become_exe = None
        become_user = None
        become_flags = None
        become_ask_pass = False

    become_options = MockOptions()
    become_options.become_user = 'root'
    become_options.become_pass = 'somepass'
    become_options.become_exe = 'sudo'
    become_options.become_flags = '-H -S -n'
    become_options.become_prompt = '[sudo via ansible, key=some_id] password:'

    fake_loader = become_loader
    fake_loader.become_password

# Generated at 2022-06-21 03:35:40.915720
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    return BecomeModule()

# Generated at 2022-06-21 03:35:46.303844
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert BecomeModule()

# Generated at 2022-06-21 03:35:53.580932
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import sys, os
    test_sys_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    if test_sys_path not in sys.path:
        sys.path.append(test_sys_path)

    from ansible.plugins.become import BecomeModule
    result = BecomeModule.build_become_command('Hello World!', 'bash' )
    assert result == 'sudo -H -S -n "eval echo \'$$$?\'" && Hello World! && eval echo \'$$$?\''



# Generated at 2022-06-21 03:36:05.294728
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    become_module.prompt = ''
    become_module.get_option = lambda x: None
    cmd = '/bin/foo'
    shell = '/bin/bash -c'
    result = become_module.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n /bin/bash -c \'/bin/foo\''

    become_module.get_option = lambda x: 'H'
    cmd = '/bin/foo'
    shell = '/bin/bash -c'
    result = become_module.build_become_command(cmd, shell)
    assert result == 'sudo -H /bin/bash -c \'/bin/foo\''

    become_module.get_option = lambda x: 'S'
    cmd = '/bin/foo'

# Generated at 2022-06-21 03:36:15.880318
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    import os
    import json
    import copy
    import sys

    cwd = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(cwd + "/../../"))

    from ansible.module_utils._text import to_bytes
    from ansible.utils.unicode import to_unicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.become import get_become_plugin


# Generated at 2022-06-21 03:36:27.147717
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule()
    assert b.build_become_command('') == 'sudo '
    b.options['become_user'] = 'bob'
    assert b.build_become_command('') == 'sudo -u bob '
    b.options['become_pass'] = 'secret'
    assert b.build_become_command('') == 'sudo -u bob -p "[sudo via ansible, key=] password:" secret'
    b.options['become_exe'] = 'doas'
    b.options['become_user'] = None
    b.options['become_flags'] = '-n'
    assert b.build_become_command('') == 'doas secret'

# Generated at 2022-06-21 03:36:30.820217
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_module = BecomeModule()
    assert become_module.name == 'sudo'
    assert become_module.fail == ('Sorry, try again.',)
    assert become_module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:36:38.198282
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(
        become_flags='-H -S -n',
        become_pass='thePass',
        become_exe='theExec',
        become_user='theUser')
    become._id = 'the_id'

    assert become.build_become_command(None, None) is None

    cmd = become.build_become_command('ls /tmp', None)
    assert cmd == 'theExec -H -S -p "[sudo via ansible, key=the_id] password:" -u theUser ls /tmp'

# Generated at 2022-06-21 03:36:40.763938
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule(connection=None, loader=None, options=None, shell=None)
    assert bm.name == "sudo"

# Generated at 2022-06-21 03:36:48.080464
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Create instance of class BecomeModule
    become_module = BecomeModule()

    # Check attributes of instance are equal to default values
    assert become_module.name == "sudo"
    assert become_module.fail == ('Sorry, try again.',)
    assert become_module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    assert become_module.prompt == None
    assert become_module._id == None
    assert become_module.become_pass == None

# Generated at 2022-06-21 03:36:54.198300
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # create an object of class BecomeModule
    become_module = BecomeModule()
    # define method arguments
    cmd = '<some command>'
    result = become_module.build_become_command(cmd, shell=None)
    # Check the result is as expected
    assert result == 'sudo -H -S -n <some command>'

    # define method arguments
    cmd = '<some command>'
    become_module.password = '<password>'
    result = become_module.build_become_command(cmd, shell=None)
    # Check the result is as expected
    assert result == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" <some command>' % become_module._id

# Generated at 2022-06-21 03:37:16.364131
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_arg = {
        'become_exe': 'sudo',
        'become_flags': '-H -S -n',
        'become_pass': True,
        'become_user': 'root'
    }
    b = BecomeModule(**become_arg)
    cmd = '/bin/ls -al'
    shell = 'bash'
    b.build_become_command(cmd, shell)

# Generated at 2022-06-21 03:37:24.763705
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    become_module.get_option = lambda name: None
    assert become_module.build_become_command('', '') == ''

    become_module.get_option = lambda name: 'sudo'
    assert become_module.build_become_command('', '') == ''
    assert become_module.build_become_command('ls', '') == 'sudo ls'

    become_module.get_option = lambda name: 'become'
    assert become_module.build_become_command('', '') == ''
    assert become_module.build_become_command('ls', '') == 'become ls'

    become_module.get_option = lambda name: 'become'
    become_module._build_success_command = lambda cmd, shell: 'true'

# Generated at 2022-06-21 03:37:38.076388
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-21 03:37:46.081936
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """Verify the command added to invoke sudo"""
    become = BecomeModule()
    become.get_option = lambda option: {
        'become_user': None,
        'become_exe': 'become',
        'become_flags': None,
        'become_pass': None,
    }[option]
    cmd = become.build_become_command('test command', shell='/bin/sh')
    assert cmd.startswith('become')
    for word in cmd.split():
        assert word in (
            'become',
            'test',
            'command',
            '-S',
            '-n',
            '-H',
        )

# Generated at 2022-06-21 03:37:57.044556
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    import os
    import sys
    import unittest
    import ansible.plugins.become.sudo
    import ansible.playbook
    import ansible.utils
    import ansible.vars


# Generated at 2022-06-21 03:38:06.316544
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.become import BecomeModule
    become_module = BecomeModule()

# Generated at 2022-06-21 03:38:12.937405
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_mock = BecomeModule()

    # Test case: no password required
    become_mock.get_option = lambda option: None
    assert become_mock.build_become_command('ls', True) == "sudo -H -S -n /bin/sh -c 'ls'"

    # Test case: password required
    become_mock.prompt = None
    become_mock.get_option = lambda option: 'a_password'
    assert become_mock.build_become_command('ls', True) == 'sudo -H -S -p "[sudo via ansible, key=1f3cd3e3b7e1237b] password:" -u root /bin/sh -c \'ls\''

# Generated at 2022-06-21 03:38:22.929103
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_plugin = BecomeModule()
    become_plugin._id = '17d0bf68-5b42-4b5d-8d38-af5ddc1fbcd5'
    become_plugin.prompt = None

    become_plugin.set_options({
        'become_exe': '',
        'become_flags': '',
        'become_pass': None,
        'become_user': '',
    })
    assert become_plugin.build_become_command("echo '{}'".format(become_plugin._id), "") == \
        "sudo -H -S echo '17d0bf68-5b42-4b5d-8d38-af5ddc1fbcd5'"
    assert become_plugin.prompt is None

    become_plugin.set_options

# Generated at 2022-06-21 03:38:27.101998
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    p = BecomeModule()
    assert p.name == 'sudo'
    assert p.fail == ('Sorry, try again.',)
    assert p.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    assert 'sudo_become_plugin' in p.options._ini_settings

# Generated at 2022-06-21 03:38:33.323485
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert BecomeModule().build_become_command("/bin/whoami", '') == "sudo -H -S -n  /bin/whoami"
    assert BecomeModule().build_become_command("/bin/whoami", '') == "sudo -H -S -n  /bin/whoami"
    assert BecomeModule().build_become_command("/bin/whoami", '') == "sudo -H -S -n  /bin/whoami"
    assert BecomeModule().build_become_command("/bin/whoami", '') == "sudo -H -S -n  /bin/whoami"
    assert BecomeModule().build_become_command("/bin/whoami", '') == "sudo -H -S -n  /bin/whoami"

# Generated at 2022-06-21 03:38:51.662577
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    """Test of constructor of class BecomeModule"""
    module = BecomeModule('sudo', 'test_become_user', 'test_become_exe', 'test_become_flags', 
        'test_become_pass')
    result = (module.get_option('become_user') == 'test_become_user') and \
            (module.get_option('become_exe') == 'test_become_exe') and \
            (module.get_option('become_flags') == 'test_become_flags') and \
            (module.get_option('become_pass') == 'test_become_pass')
    return result


# Generated at 2022-06-21 03:39:03.418314
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import sys
    # if no input parameter, then return None
    become_module = BecomeModule(None)
    assert become_module.build_become_command(None, None) is None

    # if no command, then return None
    become_module = BecomeModule({})
    assert become_module.build_become_command(None, None) is None

    # the default case
    become_module = BecomeModule({})
    become_module.prompt = 'password:'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('cmd', 'shell') == 'sudo -H -S -n cmd'


if __name__ == '__main__':
    import sys

# Generated at 2022-06-21 03:39:13.913211
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bcmd = BecomeModule(None, dict(become_exe='become_exe', become_user='become_user'))
    bcmd.prompt = 'prompt'
    bcmd._build_success_command = lambda cmd, shell: '_build_success_command:%s' % cmd

    cmd, prompt, success_cmd = bcmd.build_become_command('shell -c "that_cmd"', 'shell')
    assert cmd == 'become_exe -u become_user _build_success_command:shell -c "that_cmd"'
    assert prompt == None
    assert success_cmd == '_build_success_command:shell -c "that_cmd"'

    bcmd.prompt = None

# Generated at 2022-06-21 03:39:21.058675
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    options = {'become': True, 'become_method': 'sudo',
               'become_user': 'sammy', 'verbosity': 5}
    become = BecomeModule(None, options, False)
    print(become.config)
    print(become.config['become_pass'])
    # print(become.prompt)
    # print(become.build_become_command('ls', '/bin/sh'))

if __name__ == "__main__":
    test_BecomeModule()

# Generated at 2022-06-21 03:39:28.642978
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """
    When the become flags are passed to the become method, it should
    use the become flags passed by the user instead of default flags.
    """
    # Arange
    flags = '-H -S'
    become_plugin = BecomeModule(None, dict(become_flags=flags))

    # Act
    actual_command = become_plugin.build_become_command("", "")

    # Assert
    assert actual_command == "sudo %s -n" % flags


# Generated at 2022-06-21 03:39:40.644121
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import sys

    become = BecomeModule(
        loader=None,
        variables={
            'ansible_become_pass': 'test_ansible_become_pass',
            'ansible_become_user': 'test_ansible_become_user',
            'ansible_become_exe': 'test_ansible_become_exe',
            'ansible_become_flags': 'test_ansible_become_flags',
        },
    )

    class FakeModule(object):
        def __init__(self, name, no_log=False):
            self.name = name
            self.no_log = no_log

    fake_shell = FakeModule('shell', no_log=False)
    cmd = "echo 'test'"


# Generated at 2022-06-21 03:39:49.694050
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    plugin = BecomeModule()
    assert plugin.build_become_command(None, None) == ''
    assert plugin.build_become_command('', None) == 'sudo -H -S -n bash -c "while [ 1 ]; do echo -n \'\'; done"'
    plugin.set_options(become_exe='doas', become_flags='-l', become_pass='foobar', become_user='root')
    assert 'doas -l -p "doas via ansible, key=None] password:" -u root bash -c "while [ 1 ]; do echo -n \'\'; done"' in plugin.build_become_command('', None)

# Generated at 2022-06-21 03:39:54.917247
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    m = BecomeModule()
    assert m.name == "sudo"
    assert m.fail == ('Sorry, try again.',)
    assert m.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:40:02.493445
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # data
    executable = '/usr/bin/sudo'
    success_command = 'echo $HOME'
    flags = '-H -S'
    prompt = '[sudo via ansible, key=dummy] password:'
    user = 'foobar'

    # create instance
    become = BecomeModule()

    # set test environment
    become.prompt = prompt

    # test - default options
    become_cmd = become.build_become_command(success_command, None)
    assert become_cmd == '{0} -H -S -n echo $HOME'.format(executable)

    # test - explicit options
    become.options = {
        'become_exe': executable,
        'become_flags': flags,
        'become_pass': 'somepass',
        'become_user': user
    }


# Generated at 2022-06-21 03:40:13.938583
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # pylint: disable=unused-argument
    def exec_module(module_name=None, module_args=None, tmp=None, task_vars=None, **kwargs):
        plugin = BecomeModule()
        return plugin.build_become_command('cat test.txt', '/bin/sh')
    # pylint: enable=unused-argument

    # Test 1
    test_data = {
        'become_user': 'root',
        'become_pass': 'supersecret',
        'become_exe': 'sudo',
        'become_flags': '-H -S -n'
    }
    # Test 1a - default values
    result = exec_module(module_args=test_data)

# Generated at 2022-06-21 03:40:44.109046
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    launch_cmd = 'echo test'
    cmd = become_module.build_become_command(launch_cmd, False)
    assert cmd == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u root "echo test"' % (become_module._id)

    become_module.set_become_plugin_options(dict(become_flags='-H -S -n', become_user='root', become_pass='Password1!'))
    cmd = become_module.build_become_command(launch_cmd, False)
    assert cmd == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" -u root "echo test"' % (become_module._id)

# Generated at 2022-06-21 03:40:57.841939
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    """
    Test constructor and get_option, get_variable functions
    """

    # test case 1
    test_class = BecomeModule(None, become_pass='password1', become_exe='exe', become_flags='flags', become_user='user',
                              ansible_become_user='user1', ansible_become_pass='password2', ansible_become_exe='exe2',
                              ansible_become_flags='flags2', ansible_sudo_user='user2', ansible_sudo_pass='password3',
                              ansible_sudo_exe='exe3', ansible_sudo_flags='flags3')
    assert test_class.name == 'sudo'
    assert test_class.fail == ('Sorry, try again.',)

# Generated at 2022-06-21 03:41:05.931262
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Initialization
    become_mod = BecomeModule()
    become_mod._id = 'test'
    cmd_test = ['ls', '-lh']

    # Execution
    sudo_result = become_mod.build_become_command(cmd_test, None)

    # Assertion
    assert sudo_result == 'sudo -H -S -n  ls -lh'


# Generated at 2022-06-21 03:41:07.458832
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_plugin = BecomeModule()
    become_plugin._check_required_become_vars()

# Generated at 2022-06-21 03:41:09.507617
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule({}, {}, {}, {})
    assert bm is not None

# Generated at 2022-06-21 03:41:16.172591
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert become.name == 'sudo'
    assert len(become.fail) == 1
    assert len(become.missing) == 2


# Generated at 2022-06-21 03:41:21.661206
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule()
    assert(bm.name == 'sudo')
    assert(bm.fail == ('Sorry, try again.',))
    assert(bm.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required'))

# Generated at 2022-06-21 03:41:31.327077
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-21 03:41:39.417636
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    becomeModule = BecomeModule(
        options={'become': True, 'become_user': 'root'},
        internal_pipe=None,
        loader=None,
        play_context=None
    )

    cmd = 'cat /etc/shadow'
    shell = '/bin/sh'
    expected = 'sudo -H -S -n -u root /bin/sh -c \'echo %s; %s\'' % (cmd, cmd)
    assert becomeModule.build_become_command(cmd, shell) == expected

# Generated at 2022-06-21 03:41:48.433719
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule()

    result = module.build_become_command("/foo/bar/bin/baz", "/bin/bash")
    assert result == "/usr/bin/sudo -H -S /bin/bash -c '/foo/bar/bin/baz'"

    result = module.build_become_command("/foo/bar/bin/baz", "/bin/sh")
    assert result == "/usr/bin/sudo -H -S /bin/sh -c '/foo/bar/bin/baz'"

    result = module.build_become_command("/foo/bar/bin/baz", "/bin/ksh")
    assert result == "/usr/bin/sudo -H -S /bin/sh -c '/foo/bar/bin/baz'"


# Generated at 2022-06-21 03:42:36.974148
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    b=BecomeModule('','',"")
    assert(b.name=='sudo')
    assert(b.fail[0]=='Sorry, try again.')
    assert(b.missing[0]=='Sorry, a password is required to run sudo')


# Generated at 2022-06-21 03:42:48.943960
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.set_option('become_user', 'admin')
    become.set_option('become_pass', True)
    become.set_option('become_exe', 'sudo')
    become.set_option('become_flags', '-H -S')

    assert become.build_become_command(['/usr/bin/id', '-un'], False) == ''
    assert become.build_become_command(['/usr/bin/id', '-un'], True) == ''

    become.set_play_context({'remote_user': 'jdoe'})

# Generated at 2022-06-21 03:42:59.035244
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(dict(become_pass="bar"))

    # test become_pass without become_flags
    result = become.build_become_command('cat foo', 'shell')
    assert result.startswith('sudo -p')

    # test become_pass with -n in become_flags
    become.get_option = lambda name: '-n' if name == 'become_flags' else None
    result = become.build_become_command('cat foo', 'shell')
    assert result.startswith('sudo -n -p')

    # test become_pass with other become_flags
    become.get_option = lambda name: '-H -S' if name == 'become_flags' else None
    result = become.build_become_command('cat foo', 'shell')
    assert result.startswith

# Generated at 2022-06-21 03:43:01.080827
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_module = BecomeModule()
    assert become_module.name == 'sudo'

# Generated at 2022-06-21 03:43:05.960387
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_module = BecomeModule()
    assert become_module.name == 'sudo'
    assert become_module.fail == ('Sorry, try again.',)
    assert become_module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:43:09.376083
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    test = BecomeModule()
    assert test is not None


# Generated at 2022-06-21 03:43:18.767152
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    class Options():
        become = None
        become_user = 'user'
        become_method = 'sudo'
        become_pass = 'pwd'
        become_exe = 'become'
        become_flags = 'flags'

    class FakeBecomeModule(BecomeModule):
        def __init__(self):
            self.get_option = Options.__dict__.get
            self.prompt = ''

    b = FakeBecomeModule()
    cmd = 'sudo -u user -H -S -n -p "password:" "echo yes"'
    returned_cmd = b.build_become_command("echo yes", True)
    assert returned_cmd == cmd

# Generated at 2022-06-21 03:43:28.926728
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become = BecomeModule()
    become.become_flags = '-H'
    become.prompt = 'password:'

    # test empty command
    assert become.build_become_command(None, False) == None

    # test only shell
    assert become.build_become_command(None, True) == 'sudo -H -s -p "password:"'

    # test command and shell
    assert become.build_become_command('ls', True) == 'sudo -H -s -p "password:"'

    # test command without shell
    assert become.build_become_command('ls', False) == 'sudo -H -p "password:" ls'

    # test with sudo password
    become.become_pass = True

# Generated at 2022-06-21 03:43:41.226638
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module_instance = BecomeModule()

    assert become_module_instance.build_become_command('cat /var/log/messages', 'shell') == 'sudo -H -S -n -p "[sudo via ansible, key=None] password:" cat /var/log/messages'
    assert become_module_instance.build_become_command('cat /var/log/messages', 'shell') == 'sudo -H -S -n -p "[sudo via ansible, key=None] password:" cat /var/log/messages'
    assert become_module_instance.build_become_command('cat /var/log/messages', 'shell') == 'sudo -H -S -n -p "[sudo via ansible, key=None] password:" cat /var/log/messages'

    become_module_instance.get

# Generated at 2022-06-21 03:43:50.937442
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    become_module = BecomeModule()
    fake_args = type('', (), {})
    fake_args.become_pass = None
    fake_args.prompt = ''
    fake_args.become_exe = None
    fake_args.become_flags = None
    fake_args.become_user = None

    # Success test
    fake_module = type('', (), {})
    fake_module.run_command = lambda x, shell=None: ['test_command' + x]
    become_module.set_module = lambda x: fake_module

    fake_options = type('', (), {})
    fake_options.become_pass = None
    fake_options.become_exe = None
    fake_options.become_flags = None
    fake_options.become_user = None
    become