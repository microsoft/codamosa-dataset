

# Generated at 2022-06-21 03:34:17.019218
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    becomeModule = BecomeModule()
    assert becomeModule
    assert becomeModule.name == 'sudo'
    assert becomeModule.fail == ('Sorry, try again.',)
    assert becomeModule.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:34:25.263476
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    class Connection():
        def __init__(self):
            self.become_pass = None
            self._shell = None
            self.become = True

    class Options():
        def __init__(self):
            self.become_pass = None
            self.become_user = None
            self.become_exe = None
            self.become_flags = None

    class Runner():
        def __init__(self):
            self.connection = Connection()
            self.options = Options()

    options = Options()
    runner = Runner()
    connection = Connection()
    become = BecomeModule(runner, connection, options)
    cmd = 'powershell.exe'
    shell = 'powershell'

    # Empty cmd
    become.build_become_command(None, shell)

    # User and become_exe

# Generated at 2022-06-21 03:34:28.145541
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    m = BecomeModule({'become_flags': '-Z'})
    assert 'sudo -Z -- ansible-test-echo' == m._build_success_command('ansible-test-echo', False)



# Generated at 2022-06-21 03:34:35.088524
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule()
    assert become.build_become_command("hostname", shell = True) == "sudo -H -S -n -p \"[sudo via ansible, key=%s] password:\"  hostname" % become._id
    assert become.get_option("become_exe") == "sudo"
    assert become.get_option("become_user") == "root"

# Generated at 2022-06-21 03:34:39.935929
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    import json

# Generated at 2022-06-21 03:34:41.187260
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule()
    assert bm.name == 'sudo'

# Generated at 2022-06-21 03:34:49.034168
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Test for constructor with no values
    become = BecomeModule(dict())
    assert become.name == 'sudo'
    assert become.fail == ('Sorry, try again.',)
    assert become.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

    # Test for constructor with values
    become_values = {
        'become_exe': 'sudo exe',
        'become_flags': 'sudo flags',
        'become_pass': 'sudo pass',
        'become_user': 'sudo user'
    }

    become = BecomeModule(become_values)
    assert become.name == 'sudo'
    assert become.fail == ('Sorry, try again.',)
    assert become.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

    #

# Generated at 2022-06-21 03:35:01.576699
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case 1:
    # sudo executable location = sudo, default
    # sudo options = -H -S -n, default
    # sudo password = None, default
    # sudo user = root, default
    # cmd = /bin/sh
    # expected = sudo -H -S -n /bin/sh
    become_cmd = '/bin/sh'
    test_cmd = '/bin/sh'
    test_opt = {
        'become_exe': 'sudo',
        'become_flags': '-H -S -n',
        'become_user': 'root',
        'become_pass': None
    }
    bm = BecomeModule(play_context=dict(become=True, **test_opt))

# Generated at 2022-06-21 03:35:07.717795
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    options = {"become_user":"root", "become_pass": "test1234", "become_exe":"sudo"}
    become_module = BecomeModule()
    become_module.set_options(direct=options)
    assert become_module.get_option("become_user") == "root"
    assert become_module.get_option("become_pass") == "test1234"
    assert become_module.get_option("become_exe") == "sudo"


# Generated at 2022-06-21 03:35:19.142205
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_user = 'test_user'
    become_exe = 'test_exe'
    become_flags = 'test_flags'
    become_pass = 'test_pass'

    become_plugin = BecomeModule()

    become_plugin.get_option = lambda x: {
        'become_user': become_user, 'become_exe': become_exe,
        'become_flags': become_flags, 'become_pass': become_pass
    }.get(x)

    # Test for build_become_command function
    command = 'test'
    become_command = become_plugin.build_become_command(command, False)

# Generated at 2022-06-21 03:35:31.240013
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    sudo_become_module = BecomeModule()

    # Test when all option are set
    options = {
        'become_pass': 'somepassword',
        'become_user': 'someuser',
        'become_exe': 'someexe',
        'become_flags': 'someflags'
    }
    options['prompt'] = ''
    sudo_become_module.set_options(options)
    cmd = "whoami"
    shell = 'sh'
    assert sudo_become_module.build_become_command(cmd, shell) == "someexe someflags -p \"[sudo via ansible, key=default] password:\" -u someuser /bin/sh -c 'echo %s; %s'" % (sudo_become_module._id, cmd)

    # Test when only become_pass is

# Generated at 2022-06-21 03:35:34.759002
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    '''
    Test constructor of class BecomeModule
    '''
    become = BecomeModule()
    assert become is not None
    assert become.name is not None
    assert become.fail is not None
    assert become.missing is not None

# Generated at 2022-06-21 03:35:43.377843
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.loader import become_loader

    become_plugin = become_loader.get('sudo')
    become = BecomeModule(None, become_plugin)

    become.prompt = ''
    become.success_key = ''

    cmd = become.build_become_command('ls', '/bin/sh')

    assert cmd == 'sudo -H -S -n  sh -c "ls"'

    cmd = become.build_become_command('ls', '/bin/csh')

    assert cmd == 'sudo -H -S -n  csh -c \'ls\''

# Generated at 2022-06-21 03:35:48.606816
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes, to_native, to_text
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection.ssh import Connection
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import connection_loader

    connection = connection_loader.get('local', class_only=True)()
    play_context = PlayContext()

    assert connection._play_context is None
    connection._load_play_context(play_context)
    assert connection._play_context == play_context

    become_plugin = become_loader.get('sudo', class_only=True)()

    become_plugin.set_connection(connection)

    become_plugin.set

# Generated at 2022-06-21 03:35:52.237908
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    becomemod=BecomeModule()
    becomemod._id=1
    assert becomemod.fail == ('Sorry, try again.',)
    assert becomemod.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    becomemod.build_become_command('cmd',shell='shell')

# Generated at 2022-06-21 03:35:55.620471
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    x = BecomeModule();
    assert x.name == 'sudo'
    assert x.fail == ('Sorry, try again.',)
    assert x.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')


# Generated at 2022-06-21 03:36:07.254319
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule()
    module._id = '1234'
    module.prompt = 'password:'
    module.get_option = lambda s: None
    assert module.build_become_command('ls', True) == 'sudo -H -S -p "password:" ls'
    assert module.build_become_command('ls', False) == 'sudo -H -S -p "password:" ls'
    module.get_option = lambda s: None if s == 'become_pass' else '-n'
    assert module.build_become_command('ls', True) == 'sudo -H -n -p "password:" ls'
    assert module.build_become_command('ls', False) == 'sudo -H -n -p "password:" ls'

# Generated at 2022-06-21 03:36:14.833170
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Create become module object
    becomeModule = BecomeModule(None, {})

    # Asserts
    assert becomeModule.name == 'sudo', 'becomeModule.name should be sudo'
    assert becomeModule.fail == ('Sorry, try again.',), 'becomeModule.fail should be Sorry, try again.'
    assert becomeModule.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required'), 'becomeModule.missing should be Sorry, a password is required to run sudo, sudo: a password is required'


# Generated at 2022-06-21 03:36:26.514592
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-21 03:36:37.180332
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    # test empty command
    assert become.build_become_command([], None) == ''
    # test empty become exe
    become.set_options(become_exe = '')
    assert become.build_become_command(['echo', 'foo'], None) == ('sudo -H -S -n /bin/sh -c \'%s\'' % 'echo foo')
    # test empty become flags
    become.set_options(become_flags = '')
    assert become.build_become_command(['echo', 'foo'], None) == ('sudo -H -S /bin/sh -c \'%s\'' % 'echo foo')
    # test with become password
    become.set_options(become_pass = 'foo')

# Generated at 2022-06-21 03:36:47.950181
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule({})
    assert bm.name == 'sudo'
    assert bm.prompt == ''

    bm = BecomeModule({'become_pass': 'testpasswd'})
    assert bm.name == 'sudo'
    assert bm.prompt == '[sudo via ansible, key=ansible] password:'

# Generated at 2022-06-21 03:36:51.163536
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    my_module = BecomeModule()
    assert 'Sorry, try again.' in my_module.fail
    assert 'Sorry, a password is required to run sudo' in my_module.missing

# Generated at 2022-06-21 03:36:58.517486
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # This class is the only "become" plugin called by Ansible
    # Check if the command is built correctly by this class
    becomeModule = BecomeModule()
    # For arguments, we use variables that contain the same values
    # as the variables defined in the arguments of the method build_become_command
    cmd = 'echo "pwd" | sudo -S -u root -p "[sudo via ansible, key=%s] password:" ls' % becomeModule._id
    shell = True
    sudo_cmd = becomeModule.build_become_command(cmd, shell)
    print("Command: '%s'" % sudo_cmd)

# Generated at 2022-06-21 03:37:06.485932
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """ The build_become_command method should build the command to execute
        with sudo. The command should include:

        * the sudo executable
        * the sudo flags
        * the password prompt
        * the user (if specified)
        * the success command

        This test function checks for:
        * the sudo executable
        * the sudo flags
        * the sudo password prompt
        * the sudo user (if specified)
    """

    class MockBecomeModule(BecomeModule):
        def _build_success_command(self, cmd, shell):
            return 'this_is_the_success_command_passed_to_sudo'

    # No sudo password prompt or sudo user specified
    sudo_become_plugin = MockBecomeModule({'become_flags': 'this_are_the_flags'})

    # Run the test

# Generated at 2022-06-21 03:37:14.412586
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule(
        become_exe='sudo',
        become_user='user',
        become_pass='password',
        become_flags='-n'
    )
    assert(become.get_option('become_exe') == 'sudo')
    assert(become.get_option('become_user') == 'user')
    assert(become.get_option('become_pass') == 'password')
    assert(become.get_option('become_flags') == '-n')

# Generated at 2022-06-21 03:37:25.204621
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    from plugintest import PluginTestBase, AnsibleModuleMock

    class BecomeModuleTest(PluginTestBase):
        pass

    # Case 1: id is None
    BecomeModuleTest.setUp()
    module = AnsibleModuleMock()
    BecomeModuleTest.become = BecomeModule(BecomeModuleTest.task, module)
    BecomeModuleTest.become.become_pass = None
    cmd = "echo test"
    shell = False
    exp_cmd = "[sudo via ansible, key=None] password: echo test"
    assert BecomeModuleTest.become.build_become_command(cmd, shell) == exp_cmd

    # Case 2: id is not None
    BecomeModuleTest.setUp()
    module = AnsibleModuleMock()

# Generated at 2022-06-21 03:37:31.514417
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    my_become = BecomeModule(None, None)
    # testes that _build_success_command default arguments are in fact 'true' and 'sh'
    assert my_become._build_success_command() == "sh -c 'echo BECOME-SUCCESS-nbgssmeeelmklzsfbqmalkeqyqcqg; /usr/bin/env bash'"

# Generated at 2022-06-21 03:37:42.480377
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert BecomeModule(
        become_pass=None,
        become_user='test',
        become_exe=None,
        become_flags=None
    ).build_become_command('echo test', '/bin/bash') == "sudo -u test echo test"

    assert BecomeModule(
        become_pass='test',
        become_user='test',
        become_exe=None,
        become_flags=None
    ).build_become_command('echo test', '/bin/bash') == "sudo -u test -p \"%s\" echo test"


# Generated at 2022-06-21 03:37:53.583523
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Check for default options
    plugin = BecomeModule()
    assert plugin.get_option('become_user') is None
    assert plugin.get_option('become_exe') == 'sudo'
    assert plugin.get_option('become_flags') == '-H -S -n'
    assert plugin.get_option('become_pass') is None
    assert plugin.success_key == 'sudo: all'
    assert plugin.success_key_re == '^sudo: all$'

    # Check that after initialization options contain correct values
    plugin = BecomeModule()
    plugin.set_options(become_user='user', become_pass='pass', become_exe='exe', become_flags='flags')
    assert plugin.get_option('become_user') == 'user'

# Generated at 2022-06-21 03:37:57.169217
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    (becomecmd, flags, prompt, user, successcmd) = BecomeModule().build_become_command('', 'shell')
    assert becomecmd == 'sudo'
    assert flags == '-H -S -n'
    assert user == '-u root'

# Generated at 2022-06-21 03:38:07.898935
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert isinstance(BecomeModule(), BecomeBase)

# Generated at 2022-06-21 03:38:18.715871
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    common_arguments = ['become_exe', 'become_user', 'become_flags']

# Generated at 2022-06-21 03:38:28.813015
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(loader=None, shared_loader_obj=None, options=dict(become_pass='password', become_exe='/usr/bin/sudo', become_flags='-H -S -n', become_prompt='[sudo via ansible, key=XXXXXX] password: ', become_user='root'))

# Generated at 2022-06-21 03:38:31.891064
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert BecomeModule(load_options={"become_user": "root", "become_pass": "password", "become_exe": "sudo", "become_flags": "-H -S -n"}).name == "sudo"

# Generated at 2022-06-21 03:38:38.761281
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    becomemod = BecomeModule()
    assert becomemod.fail == ('Sorry, try again.',)
    assert becomemod.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    assert becomemod.get_option('become_exe') == 'sudo'
    assert becomemod.get_option('become_flags') == '-H -S -n'
    assert becomemod.get_option('become_user') == 'root'

# Generated at 2022-06-21 03:38:49.349778
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bMod = BecomeModule()
    import os
    os.environ['ANSIBLE_BECOME_USER'] = 'test_user'
    os.environ['ANSIBLE_BECOME_FLAGS'] = '-H -S -n'
    os.environ['ANSIBLE_SUDO_PASS'] = 'test_pass'

    # Test 1 - when no become_pass is set
    become_cmd = bMod.build_become_command('ls -l /tmp', True)
    assert become_cmd == 'sudo -H -S -n -u test_user bash -c ' \
                         '"$SHELL -c \'ls -l /tmp\'"'

    # Test 2 - when become_pass is set
    bMod.sudo_pass = os.environ['ANSIBLE_SUDO_PASS']
    become

# Generated at 2022-06-21 03:39:00.846100
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.become import BecomeModule
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import become_loader

    # Test with no become options
    plugin_options = {}
    p = BecomeModule(task_vars={}, become_options=plugin_options)
    p.setup()
    p._id = "test_id"
    cmd = p.build_become_command("/bin/foo", None)
    assert "/bin/foo" == cmd

    # Test with become_user but no become_pass
    plugin_options = {'become_user': 'test_become_user'}
    p = BecomeModule(task_vars={}, become_options=plugin_options)
    p.setup()

# Generated at 2022-06-21 03:39:07.102842
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Arrange
    test_value = BecomeModule()
    test_value.prompt = '[sudo via ansible, key=%s] password:'
    test_value._id = 1
    cmd = 'whoami'
    shell = 'sh'
    # Act
    result = test_value.build_become_command(cmd, shell)
    # Assert
    assert result == 'sudo -H -S -n -u root whoami'

# Generated at 2022-06-21 03:39:17.959229
# Unit test for constructor of class BecomeModule
def test_BecomeModule():

    bm = BecomeModule()
    bm.name='sudo'
    bm.options['become_exe']='sudo'
    bm.options['become_flags']='-H -S -n'
    bm.options['become_user']='root'
    assert bm.build_become_command("ls","/bin/sh")=="sudo -H -n -u root /bin/sh -c 'echo BECOME-SUCCESS-a2hxcmx1c2wxZG5mdWVtY2lja2UrZGVhbAo=;'"

# Generated at 2022-06-21 03:39:24.128298
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert hasattr(BecomeModule, 'name')


# TODO(gjohnson): legacy tests named sudo_pass_* are using
# inventory variables not available to this plugin.  Need
# to investigate why this plugin is using old sudo fact names
# and not using sudo_<option>

# Generated at 2022-06-21 03:39:52.236429
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    plugin = BecomeModule()
    plugin._id = 'id1234'
    assert plugin.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=id1234] password:" ls'
    assert plugin.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=id1234] password:" ls'
    plugin.set_options(dict(become_flags='-H -S -n', become_pass=True, become_exe='sudo', become_user=None))
    assert plugin.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=id1234] password:" ls'

# Generated at 2022-06-21 03:39:57.039177
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    b = BecomeModule()
    assert b.name == 'sudo'
    assert b.fail == ('Sorry, try again.',)
    assert b.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:39:58.110793
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert BecomeModule is not None
    

# Generated at 2022-06-21 03:40:11.433710
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-21 03:40:22.100745
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._options = {'become_pass': '', 'become_exe': '', 'become_user': ''}

    assert become_module.build_become_command('some command', None) == 'sudo -H -S  some command'
    become_module._options['become_flags'] = '-H -S -n'
    assert become_module.build_become_command('some command', None) == 'sudo -H -S -n some command'
    become_module._options['become_flags'] = '-H'
    become_module._options['become_pass'] = 'secret'

# Generated at 2022-06-21 03:40:32.465122
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-21 03:40:43.154368
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    shell = '/bin/sh'
    cmd = 'ls'
    become_exe = '/bin/sudo'
    become_flags = '-H -S -n'
    become_user = 'admin'
    become_pass = 'admin'
    bm = BecomeModule()
    
    bm.set_options({'become_exe': become_exe, 'become_flags': become_flags, 'become_user': become_user, 'become_pass': become_pass})


# Generated at 2022-06-21 03:40:51.211621
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # create a mock inventory
    inv = MockInventory()

    # create a mock module options
    opt = MockOptions()

    #create a instance of BecomeModule
    sudo_plugin = BecomeModule(inv, opt)

    # the command to be executed
    cmd = "ls -l"

    # the shell to be used
    shell = "/bin/sh"

    # execute the build_become_command function
    become_cmd = sudo_plugin.build_become_command(cmd, shell)

    # assert that the output of the build_become_command is as expected
    assert become_cmd == 'sudo -H -S -n -u root /bin/sh -c "ls -l"'

# Generated at 2022-06-21 03:40:59.471082
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert(BecomeModule.build_become_command("ls","bash"))=='sudo -H -S -p "[sudo via ansible, key=c71127b8c970f613bd6a] password:" -u root ls'
    assert(BecomeModule.build_become_command("ls","bash",become_exe="su",become_flags="-",become_user="admin"))=='su -p "[sudo via ansible, key=c71127b8c970f613bd6a] password:" - admin ls'

# Generated at 2022-06-21 03:41:04.568282
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    b = BecomeModule()
    assert b.name == 'sudo'
    assert b.fail == ('Sorry, try again.',)
    assert b.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:41:49.950392
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import sys, os
    parentdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    sys.path.insert(0, parentdir)

    f = BecomeModule(None)
    f.set_options({"become_user": "mpi", "become_exe": "sudo"})
    result = f.build_become_command("whoami", None)

    assert result == 'sudo -u mpi whoami'

# Generated at 2022-06-21 03:41:59.709981
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.loader import become_loader
    from ansible.parsing.plugin_docs import read_docstring

    class Args:
        become_user = None
        become_flags = None
        become_exe = None
        become_pass = None
        shell = '/bin/sh'

    # Test for IDENTITY loader --> no change
    new_become = become_loader.get('identity', None)()

    args = Args()
    args.become_exe = 'sudo'
    args.become_flags = '-H'
    args.become_user = 'root'
    args.become_pass = 'password'
    cmd = "test_cmd"
    new_cmd = new_become.build_become_command(cmd, args.shell)
    assert new_cmd

# Generated at 2022-06-21 03:42:01.627076
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule()
    assert bm.name == 'sudo'

# Generated at 2022-06-21 03:42:02.738293
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule()
    assert become.name == 'sudo'

# Generated at 2022-06-21 03:42:08.284715
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Setup the test object
    sudo_mod = BecomeModule()
    sudo_mod.prompt = '[sudo via ansible, key=123456] password:'
    sudo_mod._id = 123456

    # Build the command
    cmd, shell = sudo_mod.build_become_command('/usr/bin/echo', '/bin/bash')

    # Check the command that is built
    assert cmd == 'sudo -p "[sudo via ansible, key=123456] password:" /usr/bin/echo'
    assert shell is None

# Generated at 2022-06-21 03:42:14.844212
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule()

    cmd = 'cd /tmp'
    shell = '/bin/sh'

    result = module.build_become_command(cmd, shell)

    assert result.endswith('; cd /tmp')

# Generated at 2022-06-21 03:42:18.005586
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    obj = BecomeModule()
    assert isinstance(obj, BecomeModule)
    assert obj.name == 'sudo'
    assert obj.fail == ('Sorry, try again.',)
    assert obj.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:42:27.050383
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule()
    bm.name = "sudo"
    bm.fail = ('Sorry, try again.',)
    bm.missing = ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    assert bm.name == "sudo"
    assert bm.fail == ('Sorry, try again.',)
    assert bm.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# unit test for build_become_command

# Generated at 2022-06-21 03:42:29.839423
# Unit test for constructor of class BecomeModule
def test_BecomeModule():

    module = BecomeModule()

    assert module.name == 'sudo', 'Should match the class sudo'

# Generated at 2022-06-21 03:42:39.998956
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Default values before calling method build_become_command
    assert become_module.get_option('become_exe') is None
    assert become_module.get_option('become_flags') is None
    assert become_module.get_option('become_pass') is None
    assert become_module.prompt is None
    assert become_module.get_option('become_user') is None

    # Command to be run as root
    become_module.get_option = lambda x: None
    result = become_module.build_become_command('ls', '/bin/false')

# Generated at 2022-06-21 03:44:14.677221
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    target = BecomeModule(
            remote_user='root',
            become_pass='root_secret',
            become_exe='sudo'
    )
    assert target.plugin_options['become_exe'] == 'sudo'
    assert target.plugin_options['become_pass'] == 'root_secret'

