

# Generated at 2022-06-21 03:34:17.659185
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """Unit test for method build_become_command of class BecomeModule"""
    become_plugin = BecomeModule()
    cmd = 'echo success'
    shell = '/bin/bash'
    become_plugin.build_become_command(cmd, shell)
    assert become_plugin._cmd == 'echo success'

# Generated at 2022-06-21 03:34:25.700088
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Create a test object
    become_module = BecomeModule(None, None)

    # Create an example options dictionary
    options = {
        "become_user": "root",
        "become_exe": "sudo",
        "become_flags": "-H -S -n",
        "become_pass": "C0mpl1c4t3d%Pa66w0rD",
        "prompt": "[sudo via ansible, key=%(become_id)s] password:",
    }

    # Set options
    become_module.set_options(options)

    # Create an example command string
    command = "/usr/bin/resource /etc/systemd/system/service.service"

    # Run build_become_command with command

# Generated at 2022-06-21 03:34:37.341277
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become._id = '0123456789'
    become.prompt = 'not_default'
    become._shell = 'python'
    become.get_option = lambda option: None

    # Test without options
    command = become.build_become_command('ls', 'python')

# Generated at 2022-06-21 03:34:40.599752
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule()
    bm.check = 'ansible.plugins.become.check.Check'
    bm.info = dict(become_user='foo')
    assert 'Sorry, a password is required to run sudo' in bm.missing

# Generated at 2022-06-21 03:34:48.727616
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule()
    # simple case - no options
    cmd = b.build_become_command('ls /tmp/', 'bash')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'%s\'\n' % 'ls /tmp/'
    cmd = b.build_become_command('ls /tmp/', 'csh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'%s\'\n' % 'ls /tmp/'

    # case: fflags
    b.set_options(dict(become_flags='-E'))
    cmd = b.build_become_command('ls /tmp/', 'bash')

# Generated at 2022-06-21 03:35:01.372233
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule()
    cmd = "/usr/bin/date"
    become.shell = "bash"
    become.get_option = lambda x: None
    become.become_cmd = become.build_become_command(cmd, become.shell)
    assert become.become_cmd == "sudo -H -S -n bash -c 'echo BECOME-SUCCESS-gxxjryvsjfzvjcgybfnddtfmnjmtmguz; /usr/bin/date' || echo 'BECOME-SUCCESS-gxxjryvsjfzvjcgybfnddtfmnjmtmguz' && (echo BECOME-SUCCESS-gxxjryvsjfzvjcgybfnddtfmnjmtmguz; /usr/bin/date)"

# Unit

# Generated at 2022-06-21 03:35:09.511527
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    module = BecomeModule(get_option=lambda x: None)
    module.name = 'sudo'
    assert module.name == 'sudo'
    assert module.fail == ('Sorry, try again.',)
    assert module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    module.success_key = 'abc'
    cmd = ['ls', '-lrt']
    result = module._build_success_command(cmd, None)
    assert result == 'ls -lrt; echo %s' % module.success_key
    assert module.build_become_command('ls -lrt', None) == 'sudo -H -S -n ls -lrt; echo %s' % module.success_key

# Generated at 2022-06-21 03:35:21.958773
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
  # become_exe
  b1 = BecomeModule()
  b1.get_option = lambda x: None
  b1.set_option('become_exe', 'sudo')
  assert b1._become_exe == 'sudo'
  b1.set_option('become_exe', 'doas')
  assert b1._become_exe == 'doas'

  # become_flags
  b2 = BecomeModule()
  b2.get_option = lambda x: None
  b2.set_option('become_flags', '-H -S')
  assert b2._become_flags == '-H -S'
  b2.set_option('become_flags', '-h')
  assert b2._become_flags == '-h'


# Generated at 2022-06-21 03:35:23.576283
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    b = BecomeModule()
    assert b.get_option('become_exe') == 'sudo'

# Generated at 2022-06-21 03:35:30.834210
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    result = type('', (), {})()
    result.name = 'sudo'
    result.get_option = type('', (), {'__call__': lambda self,*args: 'root'})()
    result.prompt = '[sudo via ansible, key=elwejfo] password:'
    becomecmd = 'sudo -H -S -p "%s" -u %s' % (result.prompt, result.get_option('become_user'))
    assert BecomeModule().build_become_command('/bin/true', False) == becomecmd + ' /bin/true'


# Generated at 2022-06-21 03:35:43.281467
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    module = BecomeModule()
    assert module.name == 'sudo'
    assert module.fail == ('Sorry, try again.',)
    assert module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

    module = BecomeModule(dict())
    assert module.name == 'sudo'
    assert module.fail == ('Sorry, try again.',)
    assert module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')


# Generated at 2022-06-21 03:35:53.582385
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
  # Test 1: no password
  bc = BecomeBase()
  bc.get_option = lambda s, d='': ''
  assert bc.build_become_command('blah', True) == 'sudo -H -S blah'
  bc.get_option = lambda s, d='': 'sudo'
  assert bc.build_become_command('blah', True) == 'sudo -H -S blah'
  bc.get_option = lambda s, d='': 'SUDO'
  assert bc.build_become_command('blah', True) == 'SUDO -H -S blah'
  bc.get_option = lambda s, d='': '-n'
  assert bc.build_become_command('blah', True) == 'sudo -H -n blah'
  bc.get_

# Generated at 2022-06-21 03:36:05.294693
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Initialize the BecomeModule class instance
    module = BecomeModule(
        become_username=None,
        become_password=None,
        become_exe=None,
        become_flags=None,
        prompt=None,
        become_pass=None,
        become_user=None,
        _id=None,
        executable=None,
        success_cmd='',
        _success_rc=None
    )

    # Initialize build_become_command() input parameter as required
    cmd = ''
    shell = 'shell'

    # Execute build_become_command() method
    build_become_command_output = module.build_become_command(cmd, shell)

    # Execute build_become_command() method without input parameter to make sure that it returns ''
    build_become_command_output

# Generated at 2022-06-21 03:36:15.880049
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Call method without cmd argument
    assert become_module.build_become_command('', False) == ''

    become_module.get_option = lambda name: None
    become_module.get_option = lambda name: None
    become_module.prompt = None

    # Call method with cmd argument '/bin/ls' and shell False.
    assert become_module.build_become_command('/bin/ls', False) == 'sudo -H -S -n /bin/ls'

    # Call method with cmd argument '/bin/ls' and shell True.

# Generated at 2022-06-21 03:36:19.994768
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule()
    assert become.name == 'sudo'
    assert become.fail == ('Sorry, try again.',)
    assert become.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:36:20.629486
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    pass

# Generated at 2022-06-21 03:36:31.730287
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils._text import to_bytes, to_native

    # Shared variables for testing
    test_command = 'echo "Hello"'
    test_shell = '/bin/sh'
    test_password = 'sudoPassword'
    test_user = 'alice'
    test_expect_pass = '[sudo via ansible, key=%s] password: %s' % (BecomeBase._id, test_password)

    # Test scenario #1
    test_plugin_instance = BecomeModule()
    test_plugin_instance.prompt = None

    # Test scenario #1.1
    test_plugin_instance.task_vars = {}
    test_plugin_instance.options = {
        'become': True, 'become_user': None, 'become_pass': None
    }

    cmd = test

# Generated at 2022-06-21 03:36:39.443935
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_options = {'become_pass': 'somevalue',
                      'become_exe': 'somevalue',
                      'become_user': 'somevalue',
                      'become_flags': 'somevalue'}
    become_module = BecomeModule(None, become_options)
    become_module._id = 'somevalue'
    become_module.prompt = 'somevalue'
    result = become_module.build_become_command('cmd', 'shell')

    assert result == 'somevalue somevalue -p "somevalue" -u somevalue cmd'

# Generated at 2022-06-21 03:36:42.702359
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Test the constructor
    module = BecomeModule()
    assert module.name == 'sudo'
    assert module.fail == ('Sorry, try again.',)
    assert module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:36:53.493760
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(None, None, None)

    become.get_option = MagicMock(return_value=None)
    become.prompt = None

    assert become.build_become_command('command1', '/bin/bash') == "sudo ternary(become.get_option('become_flags')|bool, become.get_option('become_flags')|default('-H -S -n'), '') ternary(become.get_option('become_user')|bool, '-u ' + become.get_option('become_user')|string, '') command1"

    become.get_option = MagicMock(return_value='-K -S -n')

# Generated at 2022-06-21 03:36:58.991943
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bm = BecomeModule()

# Generated at 2022-06-21 03:37:01.321597
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    '''
    Unit test for constructor of class BecomeModule.
    '''
    return_value = BecomeModule()
    assert isinstance(return_value, BecomeModule)



# Generated at 2022-06-21 03:37:08.276066
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert BecomeModule.name == 'sudo'
    assert BecomeModule.fail == ('Sorry, try again.',)
    assert BecomeModule.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

    # test build_become_command

# Generated at 2022-06-21 03:37:19.183196
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(config={}, options={}, shell=None)
    cmd = 'command'
    res = become.build_become_command(cmd, 'shell')
    assert res == 'sudo command'

    become._id = 'cmd_id'
    become.prompt = ''
    res = become.build_become_command(cmd, 'shell')
    assert res == 'sudo command'

    become._id = 'cmd_id'
    become.prompt = None
    become.get_option = lambda x: None
    res = become.build_become_command(cmd, 'shell')
    assert res == 'sudo command'

    become._id = 'cmd_id'
    become.prompt = None
    become.get_option = lambda x: None
    become.become_pass = 'password'
   

# Generated at 2022-06-21 03:37:22.374902
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Test constructor of class
    x = BecomeModule()
    y = BecomeModule()

    if not isinstance(x, BecomeModule):
        raise
    if not isinstance(y, BecomeModule):
        raise

if __name__ == '__main__':
    test_BecomeModule()

# Generated at 2022-06-21 03:37:33.746892
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    class Options():
        def __init__(self, become_exe=None, become_flags=None, become_user=None):
            self.become_exe = become_exe
            self.become_flags = become_flags
            self.become_user = become_user

    bm = BecomeModule(Options())

    # test_build_become_command_missing_flags_user
    bm.get_option = lambda opt: None
    assert bm.build_become_command("test1", "test2") == 'sudo echo $?; test1'

    # test_build_become_command_missing_flags
    bm.get_option = lambda opt: None
    bm.get_option("become_user")
    assert bm.build_become_command("test1", "test2")

# Generated at 2022-06-21 03:37:39.144332
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-21 03:37:47.399380
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # For this test we have to mock methods and attributes of the tested class
    # Create object of the tested class
    sudo_obj = BecomeModule()
    # Create a variable, to bind the mocked methods and attributes to it
    sudo_obj_dict = dict()

    # Define the mocked methods
    def mocked_get_option(self, option):
        return sudo_obj_dict[option]
    sudo_obj.get_option = types.MethodType(mocked_get_option, sudo_obj)

    def mocked__build_success_command(self, cmd, shell):
        return 'command built'
    sudo_obj._build_success_command = types.MethodType(mocked__build_success_command, sudo_obj)

    # Define the mocked attributes

# Generated at 2022-06-21 03:37:53.793832
# Unit test for constructor of class BecomeModule
def test_BecomeModule():

    # Class object creation
    obj = BecomeModule()
    assert obj

    # test method get_option()
    options = {'become_flags': '--flags', 'become_pass': 'test-pass',
        'become_user': 'test-user', 'become_exe': 'test-exe'}
    for opt, val in options.items():
        setattr(obj, '_options', {opt: val})
        assert val == obj.get_option(opt)

# Generated at 2022-06-21 03:37:57.337076
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    plugin = BecomeModule()
    assert plugin.name == 'sudo'
    assert plugin.fail == ('Sorry, try again.',)
    assert plugin.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')


# Generated at 2022-06-21 03:38:11.966100
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become_cmd = become.build_become_command('/bin/bash -c \'echo BECOME_WHOAMI: $(whoami); echo BECOME_SUDO_WHOAMI: $(sudo whoami)\'', shell=True)
    assert become_cmd == 'sudo -H -S -n -p "[sudo via ansible, key=default] password:" -u root "/bin/bash -c \'echo BECOME_WHOAMI: $(whoami); echo BECOME_SUDO_WHOAMI: $(sudo whoami)\'" && echo BECOME_SUCCESS'

# Generated at 2022-06-21 03:38:21.865470
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bcmd = BecomeModule()
    bcmd.prompt = '[sudo via ansible, key={%(become_id)s}] password:'
    bcmd.cmd = 'id'
    bcmd.shell = True
    bcmd.become_user = 'testuser'
    bcmd.become_pass = 'testpass'
    bcmd._id = 'testid'
    bcmd.become_exe = 'testsudo'
    bcmd.become_flags = '-t'
    assert 'echo "[sudo via ansible, key=testid] password:"|testsudo -t -p "[sudo via ansible, key=testid] password:" -u testuser sh -c id' == bcmd.build_become_command(cmd = 'id', shell=True)



# Generated at 2022-06-21 03:38:24.937501
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    try:
        BecomeModule()
    except Exception:
        assert False, "Failed to create BecomeModule"

# Generated at 2022-06-21 03:38:27.431746
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    b = BecomeModule()
    assert b.fail == ('Sorry, try again.',)
    assert b.missing == ('Sorry, a password is required to run sudo',
                         'sudo: a password is required')

# Generated at 2022-06-21 03:38:38.043173
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test if the become command is correctly built when no arguments are given
    become = BecomeModule(become_plugin_options=None)
    assert(become.build_become_command('', False) == 'sudo -H -S -n ')

    # Test if the become command is correctly built when only the user is given
    become = BecomeModule(become_plugin_options={'become_user': 'foo'})
    assert(become.build_become_command('', False) == 'sudo -H -S -n -u foo ')

    # Test if the become command is correctly built when only the password is given
    become = BecomeModule(become_plugin_options={'become_pass': 'bar'})

# Generated at 2022-06-21 03:38:48.965214
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # become_exe and become_user are not set, they will default
    become_exe = 'sudo'
    become_user = 'root'
    become_flags = '-H -S'
    become_pass = 'test'
    cmd = 'echo "test_method_build_become_command"'
    shell = '/bin/bash'
    expected_become_cmd = 'sudo -H -S -p "sudo via ansible, key=test_become_module password:" -u root /bin/bash -c "echo \\"test_method_build_become_command\\""'
    module = BecomeModule(become_exe=become_exe, become_user=become_user, become_flags=become_flags, become_pass=become_pass)
    become_cmd = module.build_become_command

# Generated at 2022-06-21 03:38:50.264316
# Unit test for constructor of class BecomeModule

# Generated at 2022-06-21 03:38:57.648422
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    a = BecomeModule()
    a.build_become_command('ls','/bin/sh')
    assert a.get_option('become_exe') == 'sudo'
    assert a.get_option('become_flags') == '-H -S -n'
    assert a.get_option('become_pass') == None
    assert a.get_option('become_user') == None
try:
    test_BecomeModule()
except:
    pass

# Generated at 2022-06-21 03:39:08.728951
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    m = BecomeModule()
    assert m.build_become_command("ls", "") == "sudo -H -S -n  ls"
    assert m.build_become_command("ls", "sh") == "sudo -H -S -n  ls"
    assert m.build_become_command("ls", "csh") == "sudo -H -S -n  ls"
    assert m.build_become_command("ls", "fish") == "sudo -H -S -n  ls"
    assert m.build_become_command("ls", "powershell") == "sudo -H -S -n  ls"
    assert m.build_become_command("ls", "cmd") == "sudo -H -S -n  ls"

# Generated at 2022-06-21 03:39:17.167538
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule('sudo', {
        'become_exe': 'sudo',
        'become_flags': '-H -S -n',
        'become_pass': 'PASSWORD',
        'become_user': 'USER'
    })
    assert become.get_option('become_exe') == 'sudo'
    assert become.get_option('become_flags') == '-H -S -n'
    assert become.get_option('become_pass') == 'PASSWORD'
    assert become.get_option('become_user') == 'USER'
    assert become.get_option('become_method') == 'sudo'
    assert become.fail == ('Sorry, try again.',)

# Generated at 2022-06-21 03:39:49.345233
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_become = BecomeModule(None, dict(), False, False)
    # test case 1: cmd is not set
    assert test_become.build_become_command(None, False) == []

    # test case 2: cmd is set, become_exe, become_user and become_pass is set
    test_become.get_option = lambda x: {'become_exe': 'sudo',
                                        'become_flags': '-H -S -n',
                                        'become_pass': 'password',
                                        'become_user': 'user'}.get(x, None)
    cmd = test_become.build_become_command('/usr/bin/whoami', False)

# Generated at 2022-06-21 03:40:00.758173
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    klass = BecomeModule()

    assert klass.get_option('become_exe') == 'sudo'
    assert klass.get_option('become_flags') == '-H -S -n'
    assert klass.get_option('become_user') == 'root'
    assert klass.get_option('become_pass') == None
    assert klass.get_option('prompt') == None

    klass = BecomeModule(dict(become_exe='/usr/local/bin/my_sudo', become_flags='-H -S', become_user='ansible_agent', become_pass='hunter2'), None)

    assert klass.get_option('become_exe') == '/usr/local/bin/my_sudo'

# Generated at 2022-06-21 03:40:13.131217
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import tempfile
    temp_dir = tempfile.gettempdir()
    test_become_exe = 'test_become_exe'
    
    test_command = 'test command'
    
    # test case with no become_exe, no become_user, no become_pass
    test_obj = BecomeModule({'become_exe': ''}, {}, {'become_user': ''}, {'become_pass': ''})
    expected_cmd = test_command
    actual_cmd = test_obj.build_become_command(test_command, temp_dir)
    
    assert(actual_cmd == expected_cmd)

    # test case with no become_exe, no become_user, but with become_pass

# Generated at 2022-06-21 03:40:22.601636
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    class Options(object):
        def __init__(self):
            self.become_user = "root"
            self.become_pass = "pass"
            self.become_exe = "sudo"
            self.become_flags = "-H -S -n"
            self.become_method = ""

    opts = Options()
    b = BecomeModule(opts)
    assert b is not None
    assert b.get_option("become_user") == opts.become_user
    assert b.get_option("become_pass") == opts.become_pass
    assert b.get_option("become_exe") == opts.become_exe
    assert b.get_option("become_flags") == opts.become_flags

# Generated at 2022-06-21 03:40:32.716806
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule({})
    become._id = 'test-value'

    assert become.build_become_command(['some command'], None) == 'some command'

    become.prompt = ''
    become.become_pass = ''
    assert become.build_become_command(['some command'], None) == 'sudo -H -S -n some command'

    become.become_pass = 'secret'
    assert become.build_become_command(['some command'], None) == 'sudo -H -S -p "[sudo via ansible, key=test-value] password:" some command'

    become.become_exe = 'become cmd'

# Generated at 2022-06-21 03:40:43.340681
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import pytest
    from test.unit.become.test_become_shell import module_args

    # TODO: should be moved to Pytest Fixtures
    # create test object
    args = module_args()
    args.update(dict(
        become_user='bar',
        become_pass='{vault}pass',
        become_exe='foo',
        become_flags='-H -S -n',
    ))
    obj = BecomeModule(**args)

    cmd = obj.build_become_command('id', 'sh')

# Generated at 2022-06-21 03:40:52.603366
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-21 03:41:00.089833
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    class Options(object):
        def __init__(self, key, value):
            setattr(self, key, value)

    class OptionsDotDict(object):
        def __getattr__(self, name):
            return Options(name, None)

    become = BecomeModule(
        OptionsDotDict(),
        OptionsDotDict(),
        OptionsDotDict(),
        OptionsDotDict()
    )
    assert become.name == 'sudo'
    assert become.fail == ('Sorry, try again.',)

# Generated at 2022-06-21 03:41:09.979912
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    plugin = BecomeModule(dict(
        become_exe='sudo',
        become_user='user_name',
        become_flags='-H -S -n',
        become_pass='pass',
        become_pass_prompt='[sudo via ansible, key=%s] password:',
        become_success_command='',
    ), shell=None)
    cmd = ['echo', 'a', 'b', 'c']
    assert plugin.build_become_command(cmd, shell=None) == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" -u user_name echo a b c' % (plugin._id)


# Common return message for command errors not handled by runner

# Generated at 2022-06-21 03:41:12.739860
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Constructor test:
    module = BecomeModule()
    assert module.name == 'sudo'

# Generated at 2022-06-21 03:41:59.561627
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda *a: None

    # Test case:
    assert (
        'sudo -H -S -p "test prompt" foo'
        == become._build_success_command('foo', None)
    )

# Generated at 2022-06-21 03:42:10.472657
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    becomecmd = 'sudo'
    flags = '-H'
    prompt = ''
    user = 'user1'
    cmd = 'echo "hello"'
    shell = '/bin/bash'

    become_module = BecomeModule()
    become_module.get_option = MagicMock(return_value=None)
    become_module.get_option.side_effect = [becomecmd, flags, prompt, user, cmd, shell]
    become_module._build_success_command = MagicMock(return_value='')

    result = become_module.build_become_command(cmd, shell)
    assert become_module.get_option.call_count == 6
    become_module._build_success_command.assert_called_with(cmd, shell)

# Generated at 2022-06-21 03:42:13.411120
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    assert BecomeModule(dict(play=dict(become=dict(method='sudo')))) is not None

# Generated at 2022-06-21 03:42:14.844392
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_module = BecomeModule()
    assert become_module

# Generated at 2022-06-21 03:42:21.595484
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule(dict(become_exe='sudo',
                               become_pass='secret',
                               become_user='user',
                               become_flags='-H -S -n',
                               _id='123'))

    # Verify sudo with pass
    module.prompt = ''
    cmd = module.build_become_command('/bin/ls', 'sh')
    assert cmd == 'sudo -H -S -p "123" -u user sh -c \'/bin/ls\''

    # Verify sudo without pass
    module = BecomeModule(dict(become_exe='sudo',
                               become_user='user',
                               become_flags='-H -S -n',
                               _id='123'))

    module.prompt = ''

# Generated at 2022-06-21 03:42:30.484041
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import os
    import os.path
    import sys
    import tempfile
    import uuid
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.abspath(__file__), '../../..')))
    from lib.helpers.plugin_module_utils import get_plugin_class_list

    try:
        tmp_dir = os.environ['CUSTOM_TEST_DIR']
    except KeyError:
        tmp_dir = tempfile.gettempdir()
    plugin_class_list = get_plugin_class_list()
    for plugin in plugin_class_list:
        if plugin.__name__ == 'BecomeModule':
            obj = plugin()
            break

    os.environ['ANSIBLE_BECOME_EXE'] = ''


# Generated at 2022-06-21 03:42:40.342941
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda key: None

    assert become.build_become_command('foo', 'bar') == 'sudo foo'

    become.get_option = lambda key: 'sudo' if key == 'become_exe' else '-H -S -n' if key == 'become_flags' else None
    assert become.build_become_command('foo', 'bar') == 'sudo -H -S -n foo'

    become.get_option = lambda key: 'root' if key == 'become_user' else None
    assert become.build_become_command('foo', 'bar') == 'sudo  -H -S -n -u root foo'

    become.get_option = lambda key: 'pass' if key == 'become_pass' else None

# Generated at 2022-06-21 03:42:46.408980
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_module = BecomeModule(play_context=None, new_stdin=None)
    assert become_module.name == 'sudo'
    assert become_module.fail == ('Sorry, try again.',)
    assert become_module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')


# Generated at 2022-06-21 03:42:57.795023
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.flags = ''
    become.prompt = '[sudo via ansible, key=stdin] password:'
    # spaces are needed for this test
    become.success_cmd = 'whoami'
    become.name = 'sudo'
    become.user = 'ansible'
    arguments = {'become_user': 'ansible', 'become_exe': 'sudo', 'become_pass': '123'}
    # expected result: sudo -p "[sudo via ansible, key=stdin] password:" -u ansible whoami
    result = become.build_become_command(['whoami'], '/bin/bash', arguments)
    assert result == 'sudo -p "[sudo via ansible, key=stdin] password:" -u ansible whoami'

# Generated at 2022-06-21 03:43:09.222450
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # mock a become plugin class that the mocked input can call the build_become_command method
    class MockClass():
        def get_option(self, option):
            if option == 'become_exe':
                return 'sudo'
            if option == 'become_flags':
                return '-H -S -n'
            if option == 'become_user':
                return 'test'
            if option == 'become_pass':
                return None
            else:
                return ''

    cmd = ''
    shell = ''
    mockClass = MockClass()
    become_command = BecomeModule.build_become_command(mockClass, cmd, shell)