

# Generated at 2022-06-21 03:34:21.661518
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # instantiate a become module passing in a dict with become plugin options
    become_module = BecomeModule(dict())

    # Test default 'become_flags' of -H -S -n
    assert 'sudo -H -S -n -u test_user echo hello world' == become_module.build_become_command('echo hello world', 'sh')
    # Test given 'become_flags' of -H
    become_module = BecomeModule(dict(become_flags='-H'))
    assert 'sudo -H -u test_user echo hello world' == become_module.build_become_command('echo hello world', 'sh')
    # Test given 'become_flags' of empty string
    become_module = BecomeModule(dict(become_flags=''))

# Generated at 2022-06-21 03:34:25.070465
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    plugin = BecomeModule()

    assert plugin.name == 'sudo'
    assert plugin.fail == ('Sorry, try again.',)
    assert plugin.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:34:36.721896
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_plugin = BecomeModule()

    # Test with cmd and shell but not include -n flag in become_flags
    cmd = '/bin/ls'
    shell = '/bin/sh'
    become_plugin.get_option = lambda *args: None
    become_plugin.get_option.__dict__.__setitem__('become_flags', '-H -S')
    become_plugin._build_success_command = lambda *args: ' ' + shell + ' -c "' + cmd + '"'
    become_plugin.prompt = ''
    become_plugin.fail = ('Sorry, try again.',)
    become_plugin.missing = ('Sorry, a password is required to run sudo', 'sudo: a password is required')


# Generated at 2022-06-21 03:34:43.957890
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    """
    Constructor for the module
    """
    from ansible.plugins.loader import become_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    templar = Templar(loader=None, variables=VariableManager())
    pc = PlayContext()
    pc.prompt = 'password: '
    become_loader.get('sudo')
    bm = BecomeModule(PlayContext(pc, None, None))
    bm.templar = templar

# Generated at 2022-06-21 03:34:46.741308
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    plugin = BecomeModule(None)

    #Test the attributes of class
    assert plugin.name == 'sudo'
    assert plugin.fail == ('Sorry, try again.',)
    assert plugin.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')


# Generated at 2022-06-21 03:34:59.393628
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    import os

    becomecmd = BecomeModule()
    cmd = 'some command'
    flags = 'some flags'
    user = 'some user'
    prompt = 'some prompt'
    password = 'some password'
    becomecmd_exe = 'becomecmd_exe'
    expected_return = ' '.join([becomecmd_exe, flags, prompt, user, becomecmd._build_success_command(cmd, 'shell')])

    becomecmd.get_option = lambda x: {'become_exe': becomecmd_exe, 'become_flags': flags, 'become_user': user,
                                      'become_pass': password}.get(x)
    becomecmd.prompt = prompt
    becomecmd._build_success_command = lambda x, y: becomecmd._build_success_command(x, y)

    assert become

# Generated at 2022-06-21 03:35:04.533796
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    class FakeShell(object):
        exec_dir = None

    class FakeModule(object):
        def __init__(self):
            self.shell = FakeShell()
            self.get_option = BecomeModule.get_option

    become_mod = BecomeModule(FakeModule())
    become_mod.get_option = BecomeModu

# Generated at 2022-06-21 03:35:15.957000
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule()
    module.get_option = lambda option: None
    assert 'sudo -H -S -n $SHELL -c \'echo BECOME-SUCCESS-vkaznlwzwjshgrgdiucmfmixtmwuwmqm; /bin/sh -c "ls -l"\'' == module.build_become_command('ls -l', shell='/bin/sh')
    module.get_option = lambda option: 'sudo' if option == 'become_exe' else None

# Generated at 2022-06-21 03:35:27.179605
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    class Options:
        become_pass = None
        become_user = None

    class PluginOptions:
        become_user = None
        become_exe = None
        become_flags = None

    import random
    random_int = random.randint(0, 100000)

    become = BecomeModule(become_prompts=None, stdin=None)
    become.check_mode = False
    become.get_option = lambda key: getattr(PluginOptions, key)
    become.set_options = lambda **kwargs: setattr(Options, key, value)

    become.set_options(become_user='testuser')
    cmd = 'ps -ef'

    cmd_sudo_testuser = 'sudo ' \
                        '-u testuser ' \
                        'ps -ef'

    cmd_sudo_testuser_

# Generated at 2022-06-21 03:35:34.257399
# Unit test for constructor of class BecomeModule
def test_BecomeModule():

    def get_option(option):
        options = {
            'become': True,
            'become_user': 'root',
            'become_exe': 'sudo',
            'become_pass': 'password',
            'become_flags': '-H -S -n',
            'become_method': 'sudo',
            'connection': 'local'
        }
        return options.get(option)

    b = BecomeModule(get_option=get_option)

    cmd = ''
    shell = '/bin/sh'
    result = b.build_become_command(cmd, shell)

# Generated at 2022-06-21 03:35:48.561358
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Testing the command built when not specifying a password
    become = BecomeModule(become_pass=None)
    command = become.build_become_command('cmd', 'shell')
    assert command == 'sudo -H -S [SUCCESS=1] /bin/sh -c \'(cmd)\''

    # Testing the command built when specifying a password
    become = BecomeModule(become_pass='pass')
    command = become.build_become_command('cmd', 'shell')
    assert command == 'sudo -H -S -p "[sudo via ansible, key=None] password:" [SUCCESS=1] /bin/sh -c \'(cmd)\''


# Generated at 2022-06-21 03:35:56.633782
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import unittest
    import os

    class BecomeModuleTestCase(unittest.TestCase):
        def setUp(self):
            self.become_module = BecomeModule()

            # self.become_module.get_option = lambda x: ''
            # self.become_module._id = 'fake_id'
            # self.become_module.prompt = 'fake_prompt'

        def tearDown(self):
            del self.become_module

        def test_build_become_command_with_shell_requires_become_user(self):
            os.environ['SHELL'] = 'bash'
            self.become_module.get_option = lambda x: ''
            self.become_module._id = 'fake_id'

# Generated at 2022-06-21 03:36:09.731603
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bm = BecomeModule()

    bm.prompt = 'sudo password:'
    bm._id = 'test'
    bm.options = {
        'become_user': 'sanders',
        'become_pass': '',
        'become_flags': '-H -S -n',
    }

    # test with shell=True
    cmd = 'sudo -i'
    becomecmd = bm.build_become_command(cmd, True)
    assert bm.prompt == 'sudo password:'

# Generated at 2022-06-21 03:36:10.612171
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    becomemodule = BecomeModule(None)
    assert becomemodule

# Generated at 2022-06-21 03:36:18.993242
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bcm = BecomeModule()
    bcm.prompt = ''
    bcm.get_option = lambda x: ''

# Generated at 2022-06-21 03:36:25.065121
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    module = BecomeModule(
        become_pass='',
        become_user='',
        become_exe='',
        become_flags='',
        connection='',
        remote_tmp='',
        executable='',
        cmd='',
        shell='',
        no_log=False,
        check=False,
        always=False,
        become_prompt='',
        sudo_flags='')

# Generated at 2022-06-21 03:36:29.861650
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    from ansible.module_utils.six import PY3

    if PY3:

        # class_attrs -- attributes for constructing a BecomeModule
        class_attrs = \
        {
        "get_option":
        {
            'become_exe': '/usr/local/bin/sudo',
            'become_flags': '-H -S -n',
            'become_pass': None,
            'become_user': 'none'
        }
        }

        bs_module = BecomeModule(class_attrs)

        expected_cmd = '/usr/local/bin/sudo -H -S -n none'

        assert bs_module.build_become_command(cmd='', shell='') == expected_cmd


if __name__=='__main__':
    test_BecomeModule()

# Generated at 2022-06-21 03:36:38.054108
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become_module_obj = BecomeModule()
    assert become_module_obj.name == 'sudo'
    assert become_module_obj.fail == ('Sorry, try again.',)
    assert become_module_obj.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

    assert 'sudo' in become_module_obj.build_become_command('', 'shell')
    assert 'ansible' in become_module_obj.build_become_command('', 'shell')

# Generated at 2022-06-21 03:36:45.628528
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    ls = "ls"
    shell = False
    cmd = "ansible-sudo"
    become_exe = "ansible-sudo"
    become_flags = "-H -S -n"
    become_user = None
    become_pass = None
    prompt = ""
    m = BecomeModule(ls, cmd, become_exe, become_flags, become_user, become_pass, prompt, shell)

    m.build_become_command(ls, shell)

# Generated at 2022-06-21 03:36:50.885430
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    plugin = BecomeModule(None, None, {}, {}, None, None)

    assert plugin.name == "sudo"
    assert plugin.get_option("become_pass") == None
    assert plugin.get_option("become_user") == "root"
    assert plugin.get_option("become_exe") == "sudo"
    assert plugin.get_option("become_flags") == "-H -S -n"

# Generated at 2022-06-21 03:37:04.680834
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    class Options():
        def __init__(self, become_exe, become_flags, become_pass, become_user):
            self.become_exe = become_exe
            self.become_flags = become_flags
            self.become_pass = become_pass
            self.become_user = become_user

    options = Options(become_exe="BECOME_EXE",
                      become_flags="BECOME_FLAGS",
                      become_pass="password",
                      become_user="USER")

    sudo_module = BecomeModule([], options)
    assert sudo_module.get_option('become_exe') == "BECOME_EXE"
    assert sudo_module.get_option('become_flags') == "-n BECOME_FLAGS"

# Generated at 2022-06-21 03:37:16.502193
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
   become_exe_1 = BecomeModule(dict(become_exe='/usr/bin/sudo', become_user='root', become_flags='-H'))
   become_exe_2 = BecomeModule(dict(become_exe='/usr/bin/sudo', become_user='root', become_flags='-H'))
   assert become_exe_1.get_option('become_exe')== become_exe_2.get_option('become_exe')
   
   become_exe_1 = BecomeModule(dict(become_exe='/usr/bin/sudo', become_user='root', become_flags='-H'))
   become_exe_2 = BecomeModule(dict(become_exe='/usr/bin/sudo_1', become_user='root', become_flags='-H'))
   assert become_exe

# Generated at 2022-06-21 03:37:21.916352
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test command is echo pusheen
    command = 'echo pusheen'
    # Test a command that is not None
    assert BecomeModule.build_become_command(command, 'shell') == 'sudo -H -S -n echo pusheen'
    # Test that command is None
    assert BecomeModule.build_become_command(None, 'shell') == None


# Test for method get_option of class BecomeModule

# Generated at 2022-06-21 03:37:23.270185
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    """Test module functions"""

    # Constructor
    sudo_plugin = BecomeModule()

    assert sudo_plugin is not None

# Generated at 2022-06-21 03:37:35.342388
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Test with no command
    become_module = BecomeModule()
    assert become_module.build_become_command(cmd=None, shell=None) is None

    # Test with a command but no ansible_become options
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls -l', '/bin/sh') is None

    # Test with a command and ansible_become_exe options
    become_module.get_option = lambda x: '/usr/bin/sudo' if x == 'become_exe' else None
    become_module._build_success_command = lambda c, s: c
    assert become_module.build_become_command('ls -l', '/bin/sh') == '/usr/bin/sudo ls -l'

    # Test with a command

# Generated at 2022-06-21 03:37:45.106232
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become._id = 0
    become.get_option = lambda option: None
    assert become.build_become_command("bash", True) == "sudo bash"
    become.get_option = lambda option: "sudo" if option == "become_exe" else None
    assert become.build_become_command("bash", True) == "sudo sudo -H -S bash"
    become.get_option = lambda option: "" if option == "become_flags" else None
    assert become.build_become_command("bash", True) == "sudo sudo bash"
    become.get_option = lambda option: "root" if option == "become_user" else None
    assert become.build_become_command("bash", True) == "sudo sudo -u root bash"
    become.get_option

# Generated at 2022-06-21 03:37:56.484243
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    command = "echo 'hello world'"
    shell = "/bin/sh"
    plugin = BecomeModule()

    plugin.get_option = MagicMock(return_value = False)
    plugin._build_success_command = MagicMock(return_value = command)

    plugin.build_become_command(command, shell)
    assert plugin.get_option.call_count == 3

    plugin.get_option.assert_called_with('become_exe')
    assert plugin.prompt == None
    args, kwargs = plugin._build_success_command.call_args
    assert args == (command, shell)
    assert kwargs == {}


    plugin.get_option = MagicMock(return_value = 'sudo')
    plugin._build_success_command = MagicMock(return_value = command)

   

# Generated at 2022-06-21 03:38:05.804296
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    class mock_self():
        def __init__(self):
            self._id = '12345'
    test_self = mock_self()
    # test with no become_exe
    test_self.get_option = lambda option: None
    expected = '/bin/sh -c \'echo BECOME-SUCCESS-12345; /bin/sh\''
    actual = BecomeModule.build_become_command(test_self, '/bin/sh', False)
    assert expected == actual

    # test with become_exe
    test_self.get_option = lambda option: 'sudo' if option == 'become_exe' else None
    expected = 'sudo /bin/sh -c \'echo BECOME-SUCCESS-12345; /bin/sh\''

# Generated at 2022-06-21 03:38:11.015317
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    mod = BecomeModule()
    output = mod.build_become_command('ls -a', '/bin/sh')
    assert output == 'sudo  -H -S -p "[sudo via ansible, key=%s] password:"  -u root ls -a'
    output = mod.build_become_command('ls -a', '/bin/sh')
    assert output == 'sudo  -H -S -p "[sudo via ansible, key=%s] password:"  -u root ls -a'

# Generated at 2022-06-21 03:38:13.572496
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    plugin = BecomeModule(dict(a=1, b=2), become_method='sudo')
    assert plugin._become == 'sudo'
    assert plugin.a == 1
    assert plugin.b == 2


# Generated at 2022-06-21 03:38:28.501269
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # this line is important for unit test to be able to load the plugin module
    become = BecomeModule()
    # this line is important for unit test to be able to load the plugin module
    command = become.build_become_command(['ls'], 'shell')
    # this line is important for unit test to be able to load the plugin module
    assert command == 'sudo -H -S -n ls'


# Generated at 2022-06-21 03:38:38.853266
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    my_become_module = BecomeModule(
        become_user='USERNAME', become_flags='-H -S -n', become_exe='SUDO', become_pass='PASSWORD'
    )
    assert my_become_module.name == 'sudo'
    assert my_become_module.fail == ('Sorry, try again.',)
    assert my_become_module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    assert my_become_module.get_option('become_user') == 'USERNAME'
    assert my_become_module.get_option('become_pass') is None
    assert my_become_module.get_option('become_exe') == 'SUDO'

# Generated at 2022-06-21 03:38:49.433816
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import json
    import sys

    class Structure:
        def __repr__(self):
            return json.dumps(self.__dict__, indent=4)

    # Prepare test data
    options = Structure()
    options.become_exe = ''
    options.become_flags = ''
    options.become_pass = None
    options.become_user = ''
    options.become = True

    c = BecomeModule(Structure(), 'sudo', options)
    c._id = 'id'
    c.prompt = '[sudo via ansible, key=%s] password:'

    class LocalReturnCode(BecomeBase):
        def __init__(self, returncode):
            self.returncode = returncode

        def accumulate(self, other):
            self.returncode = other.returncode

    c

# Generated at 2022-06-21 03:39:00.847011
# Unit test for constructor of class BecomeModule

# Generated at 2022-06-21 03:39:01.425654
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    _ = BecomeModule()

# Generated at 2022-06-21 03:39:06.917672
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    c = BecomeModule()
    assert c.name == 'sudo'
    assert c.fail == ('Sorry, try again.',)
    assert c.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    assert c.build_become_command([], []) == None
    assert c.build_become_command('', '') == ''

# Generated at 2022-06-21 03:39:12.750269
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule()
    become.get_option = lambda x: None
    assert become.build_become_command("ls","/bin/sh") == "sudo -H -S -p \"[sudo via ansible, key=%s] password:\"  ls" % become._id

# Generated at 2022-06-21 03:39:22.618051
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    args = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': 'faked', 'become_user': 'root'}
    potential_become = BecomeModule(**args)

    # Test attributes
    assert potential_become._id == "become"
    assert potential_become.name == "sudo"
    assert potential_become._display.verbosity == 2
    assert potential_become.fail == ('Sorry, try again.',)
    assert potential_become.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    assert potential_become._options['become_exe'] == "sudo"
    assert potential_become._options['become_flags'] == "-H -S -n"
    assert potential_

# Generated at 2022-06-21 03:39:26.740224
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    m = BecomeModule(vars={'ansible_ssh_pass': 'test'}, become_args="-l %h %u")

# Generated at 2022-06-21 03:39:38.009267
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule(
        remote_user='ansible',
        become_pass='spam',
        become_user='root',
        become_exe='/usr/bin/sudo',
        become_flags=''
    )
    cmd = 'ansible-testenv'
    shell = '/bin/sh'
    becomecmd = module.build_become_command(cmd, shell)
    assert becomecmd == '/usr/bin/sudo -p "[sudo via ansible, key=ansible] password:" -u root /bin/sh -c \'ansible-testenv; echo $?\' | tail -n +3'

# Generated at 2022-06-21 03:40:11.767301
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b_mod = BecomeModule()
    assert b_mod.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    assert b_mod.build_become_command('ls', '/bin/sh', exe='/bin/doas') == 'sudo -H -S -n ls'
    assert b_mod.build_become_command('ls', '/bin/sh', flags='-l') == 'sudo -l ls'
    assert b_mod.build_become_command('ls', '/bin/sh', user='someone') == 'sudo -H -S -n -u someone ls'
    assert b_mod.build_become_command('ls', '/bin/sh', user='someone', flags='-l') == 'sudo -l -u someone ls'
    assert b_mod

# Generated at 2022-06-21 03:40:22.258342
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule({})
    b.prompt = '[sudo via ansible, key=0e84143c-fe1a-11e8-bc65-0242c0a81002] password:'
    b._build_success_command = lambda x, shell: 'printf "All good" && exit 0'
    b._id = '0e84143c-fe1a-11e8-bc65-0242c0a81002'
    assert b.build_become_command(['printf "some command"'], shell=True) == \
        'sudo -p "%s" -u root printf "All good" && exit 0' % b.prompt

# Generated at 2022-06-21 03:40:32.562296
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    def _get_args(options):
        # Helper function to return args for BecomeModule
        # Cannot use mock here as it requires python 2.7
        args = {}
        args['become_pass'] = options.get('become_pass')
        args['become_user'] = options.get('become_user')
        args['become_exe'] = options.get('become_exe')
        args['become_flags'] = options.get('become_flags')
        return args

    def _test_become_command(options, expected_cmd):
        # Helper function to test become command
        args = _get_args(options)
        obj = BecomeModule(become_pass=options.get('become_pass'))
        obj.runner = mock.MagicMock()
        obj.runner.shell

# Generated at 2022-06-21 03:40:43.226278
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    b = BecomeModule()

    # defaults
    assert(b.name == 'sudo')
    assert(b.fail == ('Sorry, try again.',))
    assert(b.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required'))
    assert(b.default_exes == ['/usr/bin/sudo'])
    assert(b.get_option('become_exe') == 'sudo')
    assert(b.get_option('become_flags') == '-H -S -n')
    assert(b.get_option('become_pass') is None)
    assert(b.get_option('become_user') == 'root')
    assert(b.prompt == '')
    assert(b._is_shell() is False)

# Generated at 2022-06-21 03:40:49.527722
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    def get_option(option):
        if option == 'become_exe':
            return 'sudo'
        elif option == 'become_user':
            return 'root'
        return None

    become_plugin = BecomeModule('some_task', dict(), False)
    become_plugin.get_option = get_option
    become_plugin._id = 'some_id'

    assert become_plugin.build_become_command('command', True) == "sudo -u root /bin/sh -c 'command'"



# Generated at 2022-06-21 03:41:00.394262
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Checks whether creating a BecomeModule object with an undefined become_user
    # uses the specified default
    assert bool(BecomeModule(dict(become_user=None), 1)) is True
    # Checks whether creating a BecomeModule object with a defined become_user
    # uses the specified value
    assert bool(BecomeModule(dict(become_user='test'), 1)) is True
    # Checks whether creating a BecomeModule object with an undefined become_pass
    # uses the specified default
    assert bool(BecomeModule(dict(become_pass=None), 1)) is True
    # Checks whether creating a BecomeModule object with a defined become_pass
    # uses the specified value
    assert bool(BecomeModule(dict(become_pass='test'), 1)) is True

# Generated at 2022-06-21 03:41:10.004973
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # test the happy case
    become_plugin = BecomeModule(None, remote_user="foo", become_exe='sudo', become_flags='-H -S -n', become_user='testuser', become_pass=None)
    new_cmd = become_plugin.build_become_command("test_command", "test_shell")
    assert new_cmd == "sudo -H -S -n testuser  test_command"

    # test option become_exe is not specified
    become_plugin = BecomeModule(None, remote_user="foo", become_exe=None, become_flags='-H -S -n', become_user='testuser', become_pass=None)
    new_cmd = become_plugin.build_become_command("test_command", "test_shell")

# Generated at 2022-06-21 03:41:20.324773
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    import getpass
    module = BecomeModule(
        become_pass='not_my_password',
        become_user=getpass.getuser(),
        become_exe='/usr/bin/sudo',
        become_flags='-E -H -S -n'
    )
    cmd = module.build_become_command('echo "hello"', "/usr/bin/bash")
    assert cmd == '/usr/bin/sudo -E -H -S -n /bin/sh -c "echo \\"hello\\""'
    cmd = module.build_become_command('echo "hello"', "/usr/bin/zsh")
    assert cmd == '/usr/bin/sudo -E -H -S -n /bin/sh -c "echo \\"hello\\""'

# Generated at 2022-06-21 03:41:30.910463
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    #### Test with no flags
    become_module = BecomeModule()
    become_module.set_options({
        'become_exe': 'sudo',
        'become_pass': None,
        'become_user': None,
        'become_flags': '',
    })
    assert become_module.build_become_command('echo', False) == 'echo'
    assert become_module.build_become_command('echo', True) == 'sudo sh -c "echo"'
    #### Test with no flags and user
    become_module = BecomeModule()
    become_module.set_options({
        'become_exe': 'sudo',
        'become_pass': None,
        'become_user': 'operator',
        'become_flags': '',
    })
    assert become_module

# Generated at 2022-06-21 03:41:41.702941
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    class MyBecomeModule(BecomeModule):
        _id = '0123456789abcdef'
    # A specially crafted command with shell=False
    special_cmd = ['some', 'command', 'with', 'spaces', '&&', 'some other', 'command', 'with', 'spaces']
    # An ordinary command with shell=False
    normal_cmd = ['some', 'command', 'with', 'spaces']
    # An ordinary command with shell=True
    normal_cmd_sh = ['some command with spaces']

    class MyVarsModule:
        def __init__(self, become_exe='', become_flags='', become_pass='', become_user=''):
            self.become_exe = become_exe
            self.become_flags = become_flags
            self.become_pass = become_pass

# Generated at 2022-06-21 03:42:05.892830
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    b_module = BecomeModule()
    assert 'sudo' == b_module.name
    assert ('Sorry, try again.',) == b_module.fail
    assert ('Sorry, a password is required to run sudo', 'sudo: a password is required') == b_module.missing

# Generated at 2022-06-21 03:42:18.567659
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """Simulate a scenario where user "ansible" is becoming 'root' using sudo, using password.
    A shell command 'uname -r' should be executed as root. The shell is bash and the command is
    executed on the remote machine.
    """

    # Test: No become_pass
    become_module_no_become_pass = BecomeModule(load_options_json=None)
    cmd1 = "uname -r"
    shell1 = 'bash'
    become_user1 = 'root'
    for option in ['become_exe', 'become_flags', 'become_user']:
        become_module_no_become_pass.set_option(option, None)
    become_module_no_become_pass.set_option('become_user', become_user1)
    become_module_

# Generated at 2022-06-21 03:42:24.005038
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    module = BecomeModule()
    assert module.name == 'sudo'
    assert module.fail == ('Sorry, try again.',)
    assert module.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')

# Generated at 2022-06-21 03:42:31.277876
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    # Testing in Python 2
    if sys.version_info.major == 2:
        assert isinstance(BecomeBase(), BecomeBase)
        return
    # Testing in Python 3
    # Testing with get_option, no become
    become_mock = mock.Mock()
    become_mock.get_option.side_effect = ['sudo', '', '', '', '']
    assert become_mock.build_become_command('ls -l', 'shell') == 'sudo -H -S -n /bin/sh -c \'ls -l\'', "Run without become"
    # Testing with get_option, with become
    become_mock = mock.Mock()
    become_mock.get_option.side_effect = ['sudo', '', '-n', 'user', '']

# Generated at 2022-06-21 03:42:40.816549
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Creating a mock object of class BecomeModule
    mock_module = BecomeModule()

    # Creating a mock of function get_option of class BecomeModule
    mock_module.get_option = mock_module.get_option
    # Changing the return value of function get_option
    mock_module.get_option.return_value = 'sudo'

    # Creating a mock of super function build_become_command of class BecomeBase
    mock_module.build_become_command = mock_module.build_become_command

# Generated at 2022-06-21 03:42:50.350998
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    sudo = BecomeModule(None,
        become_exe='sudo',
        become_flags='-H -S -n',
        become_user='ansible',
        become_pass='secret',
        become_method='sudo',
    )
    assert sudo.name == 'sudo'
    assert sudo.fail == ('Sorry, try again.',)
    assert sudo.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')
    assert sudo.prompt == '[sudo via ansible, key=sudo] password:'

# Generated at 2022-06-21 03:42:57.865653
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_cmd = 'sudo -H -S -n -u root /bin/sh -c \'echo BECOME-SUCCESS-smskwu; echo BECOME-SUCCESS-smskwu\' && sleep 0'
    obj = BecomeModule(dict(become_user='root'))
    assert become_cmd == obj.build_become_command('/bin/sh -c \'echo BECOME-SUCCESS-smskwu; echo BECOME-SUCCESS-smskwu\' && sleep 0', '/bin/sh')


# Generated at 2022-06-21 03:43:02.727813
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    become = BecomeModule()
    assert become.fail == ('Sorry, try again.',)
    assert become.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')


# Generated at 2022-06-21 03:43:08.067578
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    bcmd = BecomeModule()
    assert bcmd.name == 'sudo'

    assert bcmd.fail == ('Sorry, try again.',)
    assert bcmd.missing == ('Sorry, a password is required to run sudo', 'sudo: a password is required')



# Generated at 2022-06-21 03:43:14.469029
# Unit test for constructor of class BecomeModule
def test_BecomeModule():
    obj = BecomeModule()
    attrs = [
        obj.fail,
        obj.missing,
        obj.prompt,
        obj.name,
        obj.unprivileged_user_prompt,
    ]
    assert all([hasattr(obj, k) for k in attrs])

# Generated at 2022-06-21 03:44:09.852420
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import ansible.plugins.become.sudo as sudo
    import copy
    sudo.BecomeModule.get_option = get_option
    sudo.BecomeModule.name = 'sudo'
    sudo.BecomeModule.prompt = '[sudo via ansible, key=%s] password:'
    sudo.BecomeModule.get_option = get_option_success
    sudo.BecomeModule._id = 'key'
    shell = False
    cmd = 'id'
    expected = ' '.join(['sudo', '', '-p "key"', 'id'])
    actual = sudo.BecomeModule(display='myhost').build_become_command(cmd, shell)
    assert expected == actual

    sudo.BecomeModule.get_option = get_option_fail