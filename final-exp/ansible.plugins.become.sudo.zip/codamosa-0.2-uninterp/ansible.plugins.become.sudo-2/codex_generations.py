

# Generated at 2022-06-17 10:28:29.512956
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module.get_option.__doc__ = 'get_option'
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._build_success_command.__doc__ = '_build_success_command'
    become_module._id = '1234567890'
    become_module._id.__name__ = '_id'
    become_module._id.__doc__

# Generated at 2022-06-17 10:28:39.709178
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'

    # Test with no options
    assert become_module.build_become_command('ls', False) == 'sudo ls'
    assert become_module.build_become_command('ls', True) == 'sudo -s ls'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', False) == 'sudo ls'

# Generated at 2022-06-17 10:28:50.237137
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:28:55.380509
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:29:04.634980
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-n' if x == 'become_flags' else 'root' if x == 'become_user' else None

# Generated at 2022-06-17 10:29:15.275046
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda option: None
    become_module._build_success_command = lambda cmd, shell: cmd
    become_module._id = '12345'

    # Test with no options
    cmd = 'ls'
    shell = '/bin/sh'
    expected_cmd = 'sudo ls'
    assert become_module.build_become_command(cmd, shell) == expected_cmd

    # Test with become_exe option
    become_module.get_option = lambda option: 'su' if option == 'become_exe' else None
    expected_cmd = 'su ls'
    assert become_module.build_become_command(cmd, shell) == expected_cmd

    # Test with become_flags option

# Generated at 2022-06-17 10:29:25.696449
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '123'

    # Test with no options
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo ls'

    # Test with become_exe
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo ls'

    # Test with become_flags
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    cmd = become.build_become_command

# Generated at 2022-06-17 10:29:36.529574
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule(dict(), 'sudo', False)
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''

    # Test with become_exe
    become = BecomeModule(dict(become_exe='/usr/bin/sudo'), 'sudo', False)
    assert become.build_become_command('ls', '/bin/sh') == '/usr/bin/sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''

    # Test with become_flags

# Generated at 2022-06-17 10:29:45.252090
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo ~ && echo $HOME\' && echo BECOME-SUCCESS-ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo ~ && echo $HOME\' && echo BECOME-SUCCESS-ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module

# Generated at 2022-06-17 10:29:54.564646
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'password:'
    become_module.get_option = lambda x: None
    become_module._id = '12345'
    become_module.name = 'sudo'
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', 'shell') == 'sudo -p "password:" echo "success"'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('echo "test"', 'shell') == 'sudo -H -S -p "password:" echo "success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build

# Generated at 2022-06-17 10:30:06.639737
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'

    # Test with no options
    cmd = 'echo "test"'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd, shell) == 'sudo echo "test"'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'sudo echo "test"'

    # Test with become_flags

# Generated at 2022-06-17 10:30:16.739381
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = 'password:'
    become.get_option = lambda x: None

    # Test default
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become._success_key, 'ls')

    # Test with become_user
    become.get_option = lambda x: 'testuser' if x == 'become_user' else None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n -u testuser /bin/sh -c \'echo %s; %s\'' % (become._success_key, 'ls')

    # Test with become_pass

# Generated at 2022-06-17 10:30:24.308472
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls -l', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls -l'
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls -l', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls -l'

# Generated at 2022-06-17 10:30:33.084920
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = 'abc123'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'

# Generated at 2022-06-17 10:30:39.187617
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test'

    # test with no options
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo ls'

    # test with become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', False)
    assert cmd == 'doas ls'

    # test with become_flags
    become.get_option = lambda x: '-n' if x == 'become_flags' else None
    cmd = become.build_become_command('ls', False)

# Generated at 2022-06-17 10:30:47.331777
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "test"'
    become_module._id = 'test'
    assert become_module.build_become_command('', '') == 'sudo echo "test"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('', '') == 'sudo echo "test"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('', '') == 'sudo -H -S -n echo "test"'
    become_module.get

# Generated at 2022-06-17 10:30:57.515711
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:31:08.211800
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'

    # Test with no options
    cmd = 'ls -l'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd, shell) == 'sudo ls -l'

    # Test with become_exe option
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'sudo ls -l'

    # Test with become_flags option

# Generated at 2022-06-17 10:31:15.939907
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:31:27.232096
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:31:46.004219
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    cmd = 'ls -l'
    shell = '/bin/sh'
    assert become.build_become_command(cmd, shell) == 'sudo -H -S -p "%s" ls -l' % become.prompt
    become.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become.build_become_command(cmd, shell) == 'sudo -H -S -p "%s" ls -l' % become.prompt
    become.get_option = lambda x: '-n' if x == 'become_flags' else 'root' if x == 'become_user' else None

# Generated at 2022-06-17 10:31:55.229696
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._id = '12345'
    become_module._build_success_command = lambda x, y: 'success_command'

    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_user'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo -u become_user success_command'
    become_module.get_option = lambda x: 'become_flags'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo -u become_user become_flags success_command'
    become_

# Generated at 2022-06-17 10:32:04.916756
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:'
    become._id = '12345'
    become.get_option = lambda x: None
    assert become.build_become_command('ls', 'shell') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', 'shell') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:32:15.310828
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:'
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'

# Generated at 2022-06-17 10:32:21.942357
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__module__ = 'ansible.plugins.become'
    become.get_option.__doc__ = 'Mock method'
    become.get_option.__dict__ = {}
    become._build_success_command = lambda x, y: 'echo "success"'
    become._build_success_command.__name__ = '_build_success_command'
    become._build_success_command.__module__ = 'ansible.plugins.become'
    become._build_success_command.__doc__ = 'Mock method'
    become._build

# Generated at 2022-06-17 10:32:33.522638
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: ''
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_bec

# Generated at 2022-06-17 10:32:41.430692
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no become_pass
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '1234'
    assert become_module.build_become_command('ls', 'shell') == 'sudo -H -S -n ls'

    # Test with become_pass
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '1234'
    become_module.get_option = lambda x: 'password' if x == 'become_pass' else None

# Generated at 2022-06-17 10:32:50.360890
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: ''
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    assert become_module.build_become_command('ls', '/bin/csh') == 'sudo -c "ls"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:32:58.181466
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = 'test_id'

    assert become_module.build_become_command('ls', 'shell') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'shell') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'shell') == 'sudo -H -S -n ls'
    become_module.get

# Generated at 2022-06-17 10:33:04.420447
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test_id'

    # Test with no options
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo ls'

    # Test with become_user
    become.get_option = lambda x: 'test_user' if x == 'become_user' else None
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo -u test_user ls'

    # Test with become_pass
    become.get_option = lambda x: 'test_pass' if x == 'become_pass' else None
    cmd = become.build_become_command

# Generated at 2022-06-17 10:33:33.779470
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:33:43.601001
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: x
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._id = '123'
    become_module.name = 'sudo'

    # Test 1: No options set
    cmd = 'ls -l'
    shell = '/bin/sh'
    expected_cmd = 'sudo -H -S -n ls -l'
    assert become_module.build_become_command(cmd, shell) == expected_

# Generated at 2022-06-17 10:33:53.588676
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '12345'
    become._build_success_command = lambda x, y: 'echo "success"'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:33:59.503398
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:'
    become.get_option = lambda x: None
    become._id = '123'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -u ls ls'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n -u ls ls'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n -u ls ls'


# Generated at 2022-06-17 10:34:10.485866
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    assert become.build_become_command('echo "test"', '/bin/sh') == 'sudo echo "success"'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('echo "test"', '/bin/sh') == 'sudo echo "success"'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'

# Generated at 2022-06-17 10:34:21.215250
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n -H'

# Generated at 2022-06-17 10:34:35.444288
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S'

# Generated at 2022-06-17 10:34:45.465119
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'
    become_module.prompt = 'prompt'

    # Test with no options
    cmd = 'cmd'
    shell = 'shell'
    assert become_module.build_become_command(cmd, shell) == 'sudo success_command'

    # Test with become_exe option
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'become_exe success_command'

    # Test with become_flags option
    become_module.get_option

# Generated at 2022-06-17 10:34:57.443693
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.set_options(dict(become_exe='sudo', become_flags='-H -S -n', become_user='root', become_pass='pass'))
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=None] password:" -u root sh -c \'echo BECOME-SUCCESS-ls; ls\' && echo BECOME-SUCCESS-ls'
    become_module.set_options(dict(become_exe='sudo', become_flags='-H -S -n', become_user='root', become_pass=''))

# Generated at 2022-06-17 10:35:09.574054
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = '12345'
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda cmd, shell: cmd

    # Test with no become_pass
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_pass
    become_module.get_option = lambda x: 'password' if x == 'become_pass' else None
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'

    # Test with become_user
    become_

# Generated at 2022-06-17 10:36:15.552170
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:36:23.603132
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'

    # Test with no options
    cmd = 'ls -la'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd, shell) == 'sudo ls -la'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'sudo ls -la'

    # Test with become_flags

# Generated at 2022-06-17 10:36:34.648299
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = '123'

    # Test with no options
    cmd = become.build_become_command('echo "test"', False)
    assert cmd == 'sudo -H -S -n echo "success"'

    # Test with become_user
    become.get_option = lambda x: 'testuser' if x == 'become_user' else None
    cmd = become.build_become_command('echo "test"', False)
    assert cmd == 'sudo -H -S -n -u testuser echo "success"'

    # Test with become_flags

# Generated at 2022-06-17 10:36:45.740210
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '123'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:36:53.213903
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '123'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -p "[sudo via ansible, key=123] password:" echo "success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "success"'
    become_module.get_option = lambda x: '-H -S'

# Generated at 2022-06-17 10:37:02.555308
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no flags
    cmd = 'ls'
    shell = '/bin/sh'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command(cmd, shell) == 'sudo ls'

    # Test with flags
    cmd = 'ls'
    shell = '/bin/sh'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command(cmd, shell) == 'sudo -H -S -n ls'

    # Test with flags

# Generated at 2022-06-17 10:37:12.848673
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'

    # Test with no options
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'

    # Test with become_exe
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'

    # Test with become_flags

# Generated at 2022-06-17 10:37:19.321460
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:37:26.456663
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')

# Generated at 2022-06-17 10:37:38.187610
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda option: None
    become_module._build_success_command = lambda cmd, shell: cmd
    become_module._id = 'test_id'
    become_module.prompt = None

    assert become_module.build_become_command('test_cmd', False) == 'sudo test_cmd'
    assert become_module.build_become_command('test_cmd', True) == 'sudo -s test_cmd'

    become_module.get_option = lambda option: 'test_become_exe'
    assert become_module.build_become_command('test_cmd', False) == 'test_become_exe test_cmd'

    become_module.get_option = lambda option: 'test_become_flags'
    assert become_module