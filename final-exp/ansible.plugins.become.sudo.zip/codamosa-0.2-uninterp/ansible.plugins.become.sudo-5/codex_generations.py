

# Generated at 2022-06-17 10:28:34.015295
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'shell') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'shell') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'shell') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:28:43.058238
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('/bin/ls', '/bin/sh') == '/bin/ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('/bin/ls', '/bin/sh') == 'sudo /bin/ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:28:48.455292
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-17 10:28:56.349079
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = 'abcdef'
    become._build_success_command = lambda x, y: 'echo "success"'
    assert become.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S echo "success"'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S echo "success"'
    become.get_option = lambda x: '-H -S -n'
    become.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:29:04.714421
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'

    # Test with no options
    assert become.build_become_command('ls', False) == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become._success_key, 'ls')
    assert become.build_become_command('ls', True) == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become._success_key, 'ls')

    # Test with become_exe

# Generated at 2022-06-17 10:29:15.351519
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:29:25.764685
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.set_options(direct={'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root', 'become_pass': 'pass'})
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" -u root sh -c \'echo BECOME-SUCCESS-ls; ls\'' % become._id
    become.set_options(direct={'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root', 'become_pass': ''})

# Generated at 2022-06-17 10:29:36.193863
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')

# Generated at 2022-06-17 10:29:44.930580
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule()
    cmd = 'ls -l'
    shell = '/bin/sh'
    result = become.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n /bin/sh -c \'%s\'' % cmd

    # Test with become_user
    become = BecomeModule()
    become.set_options(dict(become_user='testuser'))
    cmd = 'ls -l'
    shell = '/bin/sh'
    result = become.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n -u testuser /bin/sh -c \'%s\'' % cmd

    # Test with become_pass
    become = BecomeModule()

# Generated at 2022-06-17 10:29:50.431744
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo -H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'sudo -H -S -n'
    become.get_option = lambda x: 'sudo'

# Generated at 2022-06-17 10:30:06.046823
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '123'

    # Test with no options set
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo echo "success"'

    # Test with become_exe set
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo echo "success"'

    # Test with become_flags set
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None


# Generated at 2022-06-17 10:30:16.716898
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    cmd = 'ls'
    shell = '/bin/sh'
    become_module.build_become_command(cmd, shell)
    assert become_module.cmd == 'sudo -H -S -n /bin/sh -c \'%s\'' % cmd

    # Test with become_user
    become_module = BecomeModule()
    cmd = 'ls'
    shell = '/bin/sh'
    become_module.set_options(become_user='test')
    become_module.build_become_command(cmd, shell)
    assert become_module.cmd == 'sudo -H -S -n -u test /bin/sh -c \'%s\'' % cmd

    # Test with become_pass
    become_module = BecomeModule()

# Generated at 2022-06-17 10:30:22.989664
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt

# Generated at 2022-06-17 10:30:32.827681
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'test_prompt'
    become_module.get_option = lambda option: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -p "test_prompt" test_cmd'

    become_module.get_option = lambda option: 'test_become_user' if option == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -p "test_prompt" -u test_become_user test_cmd'

    become_module.get_option = lambda option: 'test_become_exe' if option == 'become_exe' else None
    assert become_module

# Generated at 2022-06-17 10:30:39.550913
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': '', 'become_user': 'root'}
    assert become.build_become_command('ls', False) == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u root /bin/sh -c \'ls\'' % become._id

# Generated at 2022-06-17 10:30:47.480518
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    bm = BecomeModule()
    cmd = bm.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (bm.success_key, 'ls')

    # Test with become_exe
    bm = BecomeModule()
    bm.set_options(dict(become_exe='/usr/bin/sudo'))
    cmd = bm.build_become_command('ls', '/bin/sh')
    assert cmd == '/usr/bin/sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (bm.success_key, 'ls')

    # Test with become_flags
    bm = BecomeModule()

# Generated at 2022-06-17 10:30:57.514164
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "hello"'
    become_module._id = '123'
    assert become_module.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "hello"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "hello"'

# Generated at 2022-06-17 10:31:08.220276
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module

# Generated at 2022-06-17 10:31:15.939517
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'root'

# Generated at 2022-06-17 10:31:27.232980
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt

# Generated at 2022-06-17 10:31:46.817004
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_user
    become_module = BecomeModule()
    become_module.set_options(dict(become_user='test_user'))
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n -u test_user ls'

    # Test with become_pass
    become_module = BecomeModule()
    become_module.set_options(dict(become_pass='test_pass'))
    cmd = become_module.build_become_command('ls', False)

# Generated at 2022-06-17 10:31:53.437358
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = 'id'
    become_module._build_success_command = lambda x, y: 'success_command'

    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become_module.get_option

# Generated at 2022-06-17 10:32:00.110966
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: '"%s"' % x
    become._id = '123'

    # Test with no options
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo "ls"'

    # Test with become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'doas "ls"'

    # Test with become_flags
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:32:09.352538
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls -l', 'sh') == 'sudo -H -S -n sh -c \'echo %s; LS_COLORS=""; export LS_COLORS; ls -l\'' % (become_module._success_rc)

    # Test with become_user
    become_module = BecomeModule()
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None

# Generated at 2022-06-17 10:32:20.692678
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "Hello"'
    become_module._id = 'abc123'
    assert become_module.build_become_command('echo "Hello"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=abc123] password:" echo "Hello"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('echo "Hello"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=abc123] password:" echo "Hello"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_

# Generated at 2022-06-17 10:32:33.184662
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -p "%s" echo "success"' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -p "%s" echo "success"' % become_module.prompt

# Generated at 2022-06-17 10:32:43.972949
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '12345'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
   

# Generated at 2022-06-17 10:32:54.063342
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no options
    cmd = 'ls'
    shell = '/bin/sh'
    expected = 'sudo ls'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    expected = 'doas ls'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_flags

# Generated at 2022-06-17 10:33:06.243626
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = '12345'

    # Test default values
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'

    # Test with become_exe
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'

    # Test with become_flags
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_bec

# Generated at 2022-06-17 10:33:15.438162
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = 'test_id'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    become.get_option = lambda x: 'test_flags' if x == 'become_flags' else None
    assert become.build_become_command('test_cmd', 'test_shell') == 'sudo test_flags test_cmd'
    become.get_option = lambda x: 'test_user' if x == 'become_user' else None

# Generated at 2022-06-17 10:33:48.663480
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_

# Generated at 2022-06-17 10:33:58.013068
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo SUCCESS'
    become._id = 'abc123'

    # Test with no options
    cmd = become.build_become_command('echo hello', False)
    assert cmd == 'sudo -H -S -n echo SUCCESS'

    # Test with become_exe
    become.get_option = lambda x: 'pbrun' if x == 'become_exe' else None
    cmd = become.build_become_command('echo hello', False)
    assert cmd == 'pbrun -H -S -n echo SUCCESS'

    # Test with become_flags

# Generated at 2022-06-17 10:34:09.379341
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with default options
    become_module = BecomeModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 10:34:20.380897
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__getitem__ = lambda x, y: None
    become.get_option.__contains__ = lambda x, y: False
    become.get_option.get = lambda x, y: None
    become.get_option.getboolean = lambda x, y: False
    become.get_option.getint = lambda x, y: 0
    become.get_option.getlist = lambda x, y: []
    become.get_option.getfloat = lambda x, y: 0.0
    become.get_option.getdict = lambda x, y: {}

# Generated at 2022-06-17 10:34:29.926354
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '12345'

    # Test with no options
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo echo "success"'

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'doas echo "success"'

    # Test with become_flags
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become_

# Generated at 2022-06-17 10:34:37.349539
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule()
    cmd = 'ls'
    shell = '/bin/sh'
    expected_cmd = 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become._success_key, cmd)
    assert become.build_become_command(cmd, shell) == expected_cmd

    # Test with become_exe
    become = BecomeModule()
    become.set_options(dict(become_exe='/usr/bin/sudo'))
    cmd = 'ls'
    shell = '/bin/sh'
    expected_cmd = '/usr/bin/sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become._success_key, cmd)

# Generated at 2022-06-17 10:34:45.562177
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'test_prompt'
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None
    assert become_module.build_become_

# Generated at 2022-06-17 10:34:57.575486
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:'
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x

    # Test with no options
    cmd = 'ls'
    shell = '/bin/sh'
    expected = 'sudo ls'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    expected = 'sudo ls'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected



# Generated at 2022-06-17 10:35:09.576732
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '1234567890'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._id, 'ls')
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._id, 'ls')

# Generated at 2022-06-17 10:35:19.485180
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id


# Generated at 2022-06-17 10:36:34.295203
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda key: None
    become_module.prompt = None
    become_module._id = '123'
    become_module._build_success_command = lambda cmd, shell: cmd
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda key: 'sudo' if key == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda key: '-H -S -n' if key == 'become_flags' else None

# Generated at 2022-06-17 10:36:41.338243
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._build_success_command = lambda x, y: '"%s"' % x
    become_module._id = '12345'

    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S "ls"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n "ls"'
    become_module.get_option = lambda x: '-H -S -n'
    become_module.get_option = lambda x: '-H -S -n'
    become_

# Generated at 2022-06-17 10:36:50.345721
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None

    # Test with no options set
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # Test with become_exe set
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'doas -H -S -n /bin/sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # Test with become_flags set

# Generated at 2022-06-17 10:36:56.488605
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'
    become._build_success_command = lambda x, y: 'success'
    assert become.build_become_command('cmd', 'shell') == 'sudo success'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('cmd', 'shell') == 'sudo success'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('cmd', 'shell') == 'sudo -H -S -n success'

# Generated at 2022-06-17 10:37:06.050092
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no become_pass
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module.prompt = None
    become_module._id = '12345'
    assert become_module.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -n echo "success"'

    # Test with become_pass
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.get_option = lambda x: 'test' if x == 'become_pass' else None
    become_module._build_success_command = lambda x, y: 'echo "success"'

# Generated at 2022-06-17 10:37:15.058195
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.set_options({'become_user': 'test_user', 'become_pass': 'test_pass', 'become_exe': 'test_exe', 'become_flags': 'test_flags'})
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'test_exe test_flags -p "[sudo via ansible, key=test_user] password:" -u test_user sh -c \'echo BECOME-SUCCESS-test_cmd; test_cmd\' && (echo BECOME-SUCCESS-test_cmd; exit 0)'

# Generated at 2022-06-17 10:37:25.772316
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = 'test'
    become.get_option = lambda x: None
    assert become.build_become_command('test', False) == 'sudo -H -S -p "test" test'
    become.get_option = lambda x: 'test'
    assert become.build_become_command('test', False) == 'sudo -H -S -p "test" -u test test'
    become.get_option = lambda x: '-n'
    assert become.build_become_command('test', False) == 'sudo -H -S -p "test" -u test test'
    become.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:37:37.913079
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test_id'

    # Test with no options
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'sudo test_cmd'

    # Test with become_exe
    become.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'test_become_exe test_cmd'

    # Test with become_flags

# Generated at 2022-06-17 10:37:48.117901
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:37:57.228605
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: '"%s"' % x
    become_module._id = '12345'

    # Test empty command
    assert become_module.build_become_command('', 'shell') == ''

    # Test command without become_pass
    assert become_module.build_become_command('ls', 'shell') == 'sudo "ls"'

    # Test command with become_pass
    become_module.get_option = lambda x: 'pass' if x == 'become_pass' else None
    assert become_module.build_become_command('ls', 'shell') == 'sudo -p "[sudo via ansible, key=12345] password:" "ls"'

    # Test command