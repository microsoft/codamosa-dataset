

# Generated at 2022-06-17 10:28:29.371777
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: '"echo success"'
    assert become_module.build_become_command('echo hello', '/bin/sh') == 'sudo -H -S -n "echo success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('echo hello', '/bin/sh') == 'sudo -H -S -n "echo success"'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('echo hello', '/bin/sh') == 'sudo -H -S "echo success"'

# Generated at 2022-06-17 10:28:40.599279
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt

# Generated at 2022-06-17 10:28:48.234328
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'test_prompt'
    become_module._id = 'test_id'
    become_module.get_option = lambda option: None
    become_module._build_success_command = lambda cmd, shell: cmd
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -p "test_prompt" test_cmd'
    become_module.get_option = lambda option: 'test_become_user' if option == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -p "test_prompt" -u test_become_user test_cmd'
    become_module.get

# Generated at 2022-06-17 10:28:56.251815
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__doc__ = 'get_option'
    become.get_option.__dict__ = {}
    become.get_option.__module__ = 'ansible.plugins.become.sudo'
    become.get_option.__defaults__ = (None,)
    become.get_option.__code__ = compile('get_option', '<string>', 'lambda')
    become.get_option.__globals__ = {}
    become.get_option.__closure__ = None
    become.get_option.__annotations__ = {}
    become

# Generated at 2022-06-17 10:28:59.743187
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = '123'
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'


# Generated at 2022-06-17 10:29:05.919625
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': None, 'become_user': None}
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option.__dict__ = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': '', 'become_user': None}
    assert become.build_bec

# Generated at 2022-06-17 10:29:16.135530
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = 'test_id'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:29:26.358792
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n'
    become_module.prompt = '[sudo via ansible, key=123] password:'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" ls'

# Generated at 2022-06-17 10:29:36.717636
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'
    become_module.prompt = None
    assert become_module.build_become_command('ls', 'sh') == 'sudo ls'
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -u test_user ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:29:45.400199
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -p "%s" echo "success"' % become_module.prompt

    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n -p "%s" echo "success"' % become_module.prompt


# Generated at 2022-06-17 10:29:57.843091
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'password:'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "password:" ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "password:" ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "password:" ls'

# Generated at 2022-06-17 10:30:06.229877
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {'become_user': None, 'become_pass': None, 'become_exe': None, 'become_flags': None}
    become._build_success_command = lambda x, y: 'echo "success"'
    become._build_success_command.__name__ = '_build_success_command'
    become._build_success_command.__dict__ = {'become_user': None, 'become_pass': None, 'become_exe': None, 'become_flags': None}

    # test with no

# Generated at 2022-06-17 10:30:16.716894
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'shell') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'shell') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'shell') == 'sudo -H -S -n ls'
    become_module

# Generated at 2022-06-17 10:30:24.279860
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:30:33.085320
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._id = '12345'
    become_module.prompt = None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module

# Generated at 2022-06-17 10:30:39.639288
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None

    # Test with no options
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_pass
    become.get_option = lambda x: 'test' if x == 'become_pass' else None
    become.prompt = None
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -p "sudo via ansible, key=test password:" ls'

    # Test with become_user
    become.get_option = lambda x: 'test' if x == 'become_user' else None
    become.prompt = None
    cmd = become.build_bec

# Generated at 2022-06-17 10:30:49.318976
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S'

# Generated at 2022-06-17 10:30:58.777987
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no options
    cmd = 'ls'
    shell = '/bin/sh'
    expected_cmd = 'sudo ls'
    assert become_module.build_become_command(cmd, shell) == expected_cmd

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    expected_cmd = 'doas ls'
    assert become_module.build_become_command(cmd, shell) == expected_cmd

    # Test with become_flags

# Generated at 2022-06-17 10:31:08.391861
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no become_pass
    become = BecomeModule()
    become.set_options(direct={'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root'})
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n -u root sh -c \'LS_COLORS=""; export LS_COLORS; command ls\'', cmd

    # Test with become_pass
    become = BecomeModule()
    become.set_options(direct={'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root', 'become_pass': 'password'})
    cmd = become.build_become_command('ls', 'sh')


# Generated at 2022-06-17 10:31:16.032629
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'test_prompt'
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'test_success_command'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -p "test_prompt" test_success_command'
    become_module.get_option = lambda x: 'test_become_user' if x == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -u test_become_user -p "test_prompt" test_success_command'
    become_module

# Generated at 2022-06-17 10:31:32.039308
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None

# Generated at 2022-06-17 10:31:43.365464
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test with no options
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')

    # Test with become_exe option
    become_module.set_options(become_exe='/usr/bin/sudo')
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == '/usr/bin/sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')

    # Test with become_flags option

# Generated at 2022-06-17 10:31:52.574989
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = 'test_id'
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -n test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe -H -S -n test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None
    assert become_module.build_become_command

# Generated at 2022-06-17 10:32:02.796213
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:32:10.926177
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -n test_cmd'
    become_module.get_option = lambda x: 'test_become_user' if x == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -n -u test_become_user test_cmd'

# Generated at 2022-06-17 10:32:17.421128
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule()
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n sh -c "ls"'

    # Test with become_user
    become = BecomeModule()
    become.set_options(dict(become_user='test'))
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n -u test sh -c "ls"'

    # Test with become_flags
    become = BecomeModule()
    become.set_options(dict(become_flags='-E'))
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -E -S -n sh -c "ls"'

    # Test with

# Generated at 2022-06-17 10:32:27.625689
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:32:35.227359
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "Success"'
    become._id = '12345'
    become.prompt = None

    assert become.build_become_command('ls', '/bin/sh') == 'sudo echo "Success"'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo echo "Success"'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n echo "Success"'

# Generated at 2022-06-17 10:32:45.324978
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule()
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # Test with become_user
    become = BecomeModule()
    become.set_options(dict(become_user='myuser'))
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n -u myuser /bin/sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # Test with become_exe
    become = BecomeModule()

# Generated at 2022-06-17 10:32:51.508526
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'true'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S true'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S true'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n true'

# Generated at 2022-06-17 10:33:16.060528
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'id'

    # Test 1: no options
    cmd = 'ls'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd, shell) == 'sudo ls'

    # Test 2: become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'sudo ls'

    # Test 3: become_flags
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None


# Generated at 2022-06-17 10:33:21.569559
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '123'

    # test default
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # test with become_flags
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    cmd = become.build_become_command('ls', '/bin/sh')

# Generated at 2022-06-17 10:33:34.665173
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = '123'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:33:43.659635
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become._id = 'test_id'
    become._build_success_command = lambda x, y: 'echo "success"'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: 'test_user' if x == 'become_user' else None
    become.get_option.__name__ = 'get_option'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n -u test_user echo "success"'

# Generated at 2022-06-17 10:33:53.614517
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'test'
    become_module._id = 'test'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test', 'test') == 'sudo -H -S -p "test" test'
    become_module.get_option = lambda x: 'test'
    assert become_module.build_become_command('test', 'test') == 'sudo -H -S -u test -p "test" test'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('test', 'test') == 'sudo -H -S -p "test" test'
    become_module.get_option = lambda x: '-n -H'

# Generated at 2022-06-17 10:33:59.526436
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: 'root'

# Generated at 2022-06-17 10:34:10.515318
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = '12345'
    become_module.name = 'sudo'
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'

# Generated at 2022-06-17 10:34:21.248891
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:34:35.470662
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no options
    cmd = become_module.build_become_command('ls', 'sh')
    assert cmd == 'sudo ls'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    cmd = become_module.build_become_command('ls', 'sh')
    assert cmd == 'sudo ls'

    # Test with become_flags
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:34:45.356575
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:'
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'

    # Test with no options
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo echo "success"'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo echo "success"'

    # Test with become_flags

# Generated at 2022-06-17 10:35:26.924271
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'

    # Test with no options
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'

    # Test with become_flags
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_bec

# Generated at 2022-06-17 10:35:35.686566
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:35:41.526284
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = '12345'

    # Test default options
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'

    # Test become_user
    become.get_option = lambda x: 'testuser' if x == 'become_user' else None
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n -u testuser echo "success"'

    # Test become_pass
    become.get_option = lambda x: 'testpass' if x == 'become_pass' else None


# Generated at 2022-06-17 10:35:52.037487
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    # Test with become_user
    become_module.get_option = lambda x: 'user' if x == 'become_user' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n -u user ls'

    # Test with become_pass
    become_module.get_option = lambda x: 'pass' if x == 'become_pass' else None

# Generated at 2022-06-17 10:35:57.630260
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = '123456789'
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'

    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S echo "success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:36:07.149944
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '1234567890'

    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:36:17.115471
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('foo', 'bar') == 'sudo -H -S foo'
    become_module.get_option = lambda x: 'baz'
    assert become_module.build_become_command('foo', 'bar') == 'baz -H -S foo'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('foo', 'bar') == 'baz -H -S foo'
    become_module.get_option = lambda x: '-H -n'


# Generated at 2022-06-17 10:36:27.060416
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id

# Generated at 2022-06-17 10:36:38.210241
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become_module.get_option = lambda x: 'become_user'
    assert become_module.build_become

# Generated at 2022-06-17 10:36:43.347943
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build

# Generated at 2022-06-17 10:38:17.310407
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'abc123'

    # Test default values
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c ls'

    # Test become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'doas -H -S -n /bin/sh -c ls'

    # Test become_flags
    become.get_option = lambda x: '-E' if x == 'become_flags' else None
    assert become.build_become_

# Generated at 2022-06-17 10:38:26.449535
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt