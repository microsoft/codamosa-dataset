

# Generated at 2022-06-17 10:28:34.055312
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''
    become.get_option = lambda x: 'sudo'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None

# Generated at 2022-06-17 10:28:44.948818
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id

# Generated at 2022-06-17 10:28:51.271823
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None

# Generated at 2022-06-17 10:28:55.997299
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: 'true'
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._id = 'test_id'
    become_module.name = 'sudo'

    # Test with no options
    cmd = 'ls'
    shell = 'sh'
    expected = 'sudo true'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_exe

# Generated at 2022-06-17 10:29:03.633080
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become._build_success_command = lambda x, y: 'echo "test"'

    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n -p "%s" echo "test"' % become.prompt
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n -p "%s" echo "test"' % become.prompt

    become.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:29:14.736846
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: x
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._id = 'id'
    become_module._id.__name__ = '_id'

    # Test with no options
    assert become_module.build_become_command('cmd', 'shell') == 'sudo cmd'

    # Test with become_exe

# Generated at 2022-06-17 10:29:25.254314
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '12345'

    # no options
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'

    # become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'doas ls'

    # become_flags
    become.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -n ls'

    #

# Generated at 2022-06-17 10:29:30.143890
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: 'echo "test"'
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._id = 'test_id'
    become_module.name = 'sudo'
    assert become_module.build_become_command('echo "test"', 'bash') == 'sudo -p "[sudo via ansible, key=test_id] password:" echo "test"'

# Generated at 2022-06-17 10:29:37.585075
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo -H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'sudo -H -S -n'
    become.get_option = lambda x: 'root'
   

# Generated at 2022-06-17 10:29:45.921812
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {}
    become.get_option.__self__ = become
    become.get_option.__func__ = become.get_option
    become.get_option.__code__ = become.get_option.__code__
    become.get_option.__defaults__ = become.get_option.__defaults__
    become.get_option.__kwdefaults__ = become.get_option.__kwdefaults__
    become.get_option.__annotations__ = become.get_option.__annotations__
    become.get

# Generated at 2022-06-17 10:29:58.528828
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -u test_user test_cmd'
    become_module.get_option = lambda x: 'test_flags' if x == 'become_flags' else None
    assert become_module.build_become_command('test_cmd', 'test_shell')

# Generated at 2022-06-17 10:30:06.445903
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule()
    become.get_option = lambda x: None
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # Test with become_exe
    become = BecomeModule()
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # Test with become_flags
    become = BecomeModule()

# Generated at 2022-06-17 10:30:16.740055
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', False) == 'sudo echo "success"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', False) == 'sudo echo "success"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('echo "test"', False) == 'sudo -H -S -n echo "success"'

# Generated at 2022-06-17 10:30:24.331101
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become_module.get_option = lambda x: 'become_pass'
    become_module._id = 'id'

# Generated at 2022-06-17 10:30:34.096751
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(None)
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S'

# Generated at 2022-06-17 10:30:45.888173
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S'

# Generated at 2022-06-17 10:30:57.449985
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id

# Generated at 2022-06-17 10:31:08.174069
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('foo', 'bar') == 'sudo foo'
    become_module.get_option = lambda x: 'baz'
    assert become_module.build_become_command('foo', 'bar') == 'baz foo'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('foo', 'bar') == 'sudo -H -S foo'
    become_module.get_option = lambda x: '-H -S -n'
    become_module.get_option = lambda x: 'baz'
    assert become_module

# Generated at 2022-06-17 10:31:15.913163
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = 'test_id'
    become._build_success_command = lambda x, y: 'echo "success"'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo echo "success"'
    become.get_option = lambda x: 'test_user'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -u test_user echo "success"'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S echo "success"'
    become.get_option = lambda x: 'test_pass'


# Generated at 2022-06-17 10:31:27.197499
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = '12345'

    # Test with no options
    cmd = become.build_become_command('echo "test"', 'sh')
    assert cmd == 'sudo -H -S -n echo "success"'

    # Test with become_user
    become.get_option = lambda x: 'test_user' if x == 'become_user' else None
    cmd = become.build_become_command('echo "test"', 'sh')
    assert cmd == 'sudo -H -S -n -u test_user echo "success"'

    # Test with become_pass

# Generated at 2022-06-17 10:31:47.610968
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_user' if x == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -u test_become_user test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None
    assert become_module

# Generated at 2022-06-17 10:31:53.926082
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None

    # Test with no options
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_user
    become.get_option = lambda x: 'testuser' if x == 'become_user' else None
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n -u testuser ls'

    # Test with become_flags
    become.get_option = lambda x: '-K' if x == 'become_flags' else None
    cmd = become.build_become_command

# Generated at 2022-06-17 10:32:00.315099
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = 'abc123'

    # Test with no options
    cmd = become_module.build_become_command('echo "test"', '/bin/sh')
    assert cmd == 'sudo echo "success"'

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become_module.build_become_command('echo "test"', '/bin/sh')
    assert cmd == 'doas echo "success"'

    # Test with become_flags

# Generated at 2022-06-17 10:32:06.268010
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '123'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -p "[sudo via ansible, key=123] password:" echo "success"'

# Generated at 2022-06-17 10:32:16.780234
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = '123'

    # Test with no options
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_user
    become_module.get_option = lambda x: 'user' if x == 'become_user' else None
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n -u user ls'

    # Test with become_pass
    become_module.get_option = lambda x: 'pass' if x == 'become_pass' else None

# Generated at 2022-06-17 10:32:27.578974
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'

    # Test default values
    assert become_module.build_become_command('echo "test"', False) == 'sudo -H -S -n echo "success"'
    assert become_module.build_become_command('echo "test"', True) == 'sudo -H -S -n sh -c "echo \\"success\\""'

    # Test with become_user
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None

# Generated at 2022-06-17 10:32:34.716172
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x

    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:32:45.066192
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option

# Generated at 2022-06-17 10:32:54.766912
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_bec

# Generated at 2022-06-17 10:33:06.294433
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    b = BecomeModule()
    cmd = b.build_become_command('ls', 'shell')
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_user
    b = BecomeModule()
    b.set_options(direct={'become_user': 'testuser'})
    cmd = b.build_become_command('ls', 'shell')
    assert cmd == 'sudo -H -S -n -u testuser ls'

    # Test with become_flags
    b = BecomeModule()
    b.set_options(direct={'become_flags': '-l'})
    cmd = b.build_become_command('ls', 'shell')
    assert cmd == 'sudo -l ls'

    # Test with become_pass
    b = BecomeModule()

# Generated at 2022-06-17 10:33:43.556380
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '123'

    # Test with no options
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo ls'

    # Test with become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', False)
    assert cmd == 'doas ls'

    # Test with become_flags
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    cmd = become.build_become_command('ls', False)


# Generated at 2022-06-17 10:33:53.567931
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = '12345'
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
   

# Generated at 2022-06-17 10:33:59.483372
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule()
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_user
    become = BecomeModule()
    become.set_options(dict(become_user='testuser'))
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n -u testuser ls'

    # Test with become_pass
    become = BecomeModule()
    become.set_options(dict(become_pass='testpass'))
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become

# Generated at 2022-06-17 10:34:10.452916
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become_module.get_option = lambda x: 'become_user'

# Generated at 2022-06-17 10:34:21.175635
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no become_pass
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become._build_success_command = lambda x, y: 'success_command'
    become._id = 'id'
    assert become.build_become_command('cmd', 'shell') == 'sudo -H -S success_command'

    # Test with become_pass
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.side_effect = lambda x: 'pass' if x == 'become_pass' else None
    become._build_success_command

# Generated at 2022-06-17 10:34:35.443633
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {'become_exe': None, 'become_flags': None, 'become_pass': None, 'become_user': None}
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option.__dict__ = {'become_exe': 'doas', 'become_flags': '-E', 'become_pass': None, 'become_user': None}

# Generated at 2022-06-17 10:34:45.465035
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'bash') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'bash') == 'sudo -H -S -p "%s" ls' % become_module.prompt

# Generated at 2022-06-17 10:34:57.450155
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')

# Generated at 2022-06-17 10:35:09.574595
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:35:19.485223
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '12345'

    # Test with no options
    cmd = 'ls'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd, shell) == 'sudo ls'

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'doas ls'

    # Test with become_flags
    become_module.get_option = lambda x: '-E' if x == 'become_flags' else None
    assert become_

# Generated at 2022-06-17 10:36:23.549712
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_bec

# Generated at 2022-06-17 10:36:34.650038
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda option: None
    become_module._build_success_command = lambda cmd, shell: cmd
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    assert become_module.build_become_command('ls', True) == 'sudo -H -S -n sh -c "ls"'
    become_module.get_option = lambda option: 'sudo' if option == 'become_exe' else None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    assert become_module.build_become_command('ls', True) == 'sudo -H -S -n sh -c "ls"'
    become_module.get_

# Generated at 2022-06-17 10:36:45.743682
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test with no options
    cmd = "echo 'Hello World'"
    shell = "/bin/sh"
    expected_result = "sudo -H -S -n /bin/sh -c 'echo '\\''Hello World'\\'' && sleep 0'"
    result = become_module.build_become_command(cmd, shell)
    assert result == expected_result

    # Test with options
    become_module.set_options(dict(become_exe='/usr/bin/sudo', become_flags='-H -S -n', become_user='root', become_pass='password'))

# Generated at 2022-06-17 10:36:53.214419
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_bec

# Generated at 2022-06-17 10:37:02.554549
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Initialize the class
    become_module = BecomeModule()

    # Test with no arguments
    cmd = become_module.build_become_command(None, None)
    assert cmd == None

    # Test with no arguments
    cmd = become_module.build_become_command('', '')
    assert cmd == ''

    # Test with no arguments
    cmd = become_module.build_become_command('command', 'shell')
    assert cmd == 'sudo -H -S -n command'

    # Test with no arguments
    become_module.prompt = 'prompt'
    cmd = become_module.build_become_command('command', 'shell')
    assert cmd == 'sudo -H -S -p "prompt" command'

    # Test with no arguments
    become_module.prompt = 'prompt'

# Generated at 2022-06-17 10:37:12.851708
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt

# Generated at 2022-06-17 10:37:24.184857
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (
        become_module.success_key, 'ls')

    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (
        become_module.success_key, 'ls')

    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:37:32.741491
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'
    become_module.prompt = None
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become_module.get_option

# Generated at 2022-06-17 10:37:40.124164
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: ''
    become_module._id = '123'
    become_module._build_success_command = lambda x, y: 'echo "Success"'
    assert become_module.build_become_command('echo "Hello"', 'sh') == 'sudo -H -S -n -p "[sudo via ansible, key=123] password:" -u  echo "Success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('echo "Hello"', 'sh') == 'sudo -H -S -n -p "[sudo via ansible, key=123] password:" -u  echo "Success"'
    become_module.get_option

# Generated at 2022-06-17 10:37:46.790479
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo echo "success"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo echo "success"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None