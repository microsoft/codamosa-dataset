

# Generated at 2022-06-17 10:28:34.110424
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module

# Generated at 2022-06-17 10:28:45.029742
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_rc, 'ls')
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_rc, 'ls')

# Generated at 2022-06-17 10:28:51.320105
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()

    # Test with no arguments
    cmd = become.build_become_command(None, None)
    assert cmd == None

    # Test with arguments
    cmd = become.build_become_command('ls', None)
    assert cmd == 'sudo -H -S -n ls'

    # Test with arguments and become_user
    become.set_options({'become_user': 'testuser'})
    cmd = become.build_become_command('ls', None)
    assert cmd == 'sudo -H -S -n -u testuser ls'

    # Test with arguments and become_pass
    become.set_options({'become_pass': 'testpass'})
    cmd = become.build_become_command('ls', None)

# Generated at 2022-06-17 10:29:02.108298
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123456789'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=123456789] password:" ls'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=123456789] password:" ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command

# Generated at 2022-06-17 10:29:13.913153
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'

    # Test with no options
    cmd = 'ls'
    shell = '/bin/bash'
    expected_result = 'sudo ls'
    assert become_module.build_become_command(cmd, shell) == expected_result

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    expected_result = 'sudo ls'
    assert become_module.build_become_command(cmd, shell) == expected_result

    # Test with become_flags

# Generated at 2022-06-17 10:29:24.531480
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: '"%s"' % x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n "ls"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n "ls"'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S "ls"'

# Generated at 2022-06-17 10:29:36.145139
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'

    # Test with no options
    cmd = 'test_cmd'
    assert become_module.build_become_command(cmd, False) == 'sudo test_cmd'
    assert become_module.build_become_command(cmd, True) == 'sudo -s test_cmd'

    # Test with become_exe
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, False) == 'test_become_exe test_cmd'
    assert become_module.build

# Generated at 2022-06-17 10:29:44.930674
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test_id'
    assert become.build_become_command('test_cmd', 'test_shell') == 'sudo test_cmd'
    become.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become.build_become_command('test_cmd', 'test_shell') == 'test_become_exe test_cmd'
    become.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:29:50.435987
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with default values
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become._success_key, 'ls')

    # Test with custom values
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:29:59.074033
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '12345'

    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:30:16.605842
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no options
    cmd = 'ls -l'
    expected_cmd = 'sudo ls -l'
    assert become_module.build_become_command(cmd, None) == expected_cmd

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    expected_cmd = 'doas ls -l'
    assert become_module.build_become_command(cmd, None) == expected_cmd

    # Test with become_flags

# Generated at 2022-06-17 10:30:24.288117
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '12345'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
   

# Generated at 2022-06-17 10:30:33.084704
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '12345'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-H'
    assert become_module.build_become_command

# Generated at 2022-06-17 10:30:39.638670
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module.name = 'sudo'
    become_module._id = '12345'
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:30:47.526877
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '123'

    # Test with no options
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_user
    become.get_option = lambda x: 'test' if x == 'become_user' else None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n -u test ls'

    # Test with become_pass
    become.get_option = lambda x: 'test' if x == 'become_pass' else None
    cmd = become.build_become

# Generated at 2022-06-17 10:30:57.532932
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:31:08.210896
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_exe
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'doas -H -S -n ls'

    # Test with become_flags
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module

# Generated at 2022-06-17 10:31:18.106404
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = 'test_id'
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -p "[sudo via ansible, key=test_id] password:" test_cmd'
    become_module.get_option = lambda x: 'test_become_user' if x == 'become_user' else None

# Generated at 2022-06-17 10:31:28.552797
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module.get_option.__doc__ = 'Mock method'
    become_module._build_success_command = lambda x, y: 'echo "Hello"'
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._build_success_command.__doc__ = 'Mock method'
    become_module._id = '12345'
    become_module._id.__name__ = '_id'

# Generated at 2022-06-17 10:31:37.673608
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x

    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else 'root' if x == 'become_user' else None
   

# Generated at 2022-06-17 10:31:55.510547
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no options
    cmd = 'ls -l'
    expected_cmd = 'sudo ls -l'
    assert become_module.build_become_command(cmd, None) == expected_cmd

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    expected_cmd = 'doas ls -l'
    assert become_module.build_become_command(cmd, None) == expected_cmd

    # Test with become_flags
    become_module.get_option = lambda x: '-H -S'

# Generated at 2022-06-17 10:32:05.169866
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:32:15.361649
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '12345'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_

# Generated at 2022-06-17 10:32:21.994327
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = None
    become._build_success_command = lambda x, y: x

    # Test with no options
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo ls'

    # Test with become_exe
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo ls'

    # Test with become_flags
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    cmd = become.build_become_command('ls', 'sh')

# Generated at 2022-06-17 10:32:33.541080
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\''
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\''
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:32:44.164376
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test with no options
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')

    # Test with become_user
    become_module.set_options(dict(become_user='test_user'))
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n -u test_user /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')

    # Test with become_pass

# Generated at 2022-06-17 10:32:54.209633
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'

# Generated at 2022-06-17 10:33:06.243530
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')

# Generated at 2022-06-17 10:33:15.437816
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = '123'
    become_module._build_success_command = lambda cmd, shell: cmd

    # Test with no options
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'doas -H -S -n ls'

    # Test with become_flags

# Generated at 2022-06-17 10:33:23.041557
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:33:53.588458
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become._id = '123'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:34:02.984778
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt

# Generated at 2022-06-17 10:34:08.012359
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: 'echo "test"'
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._id = '123'
    become_module._id.__name__ = '_id'

    # Test with no options
    assert become_module.build_become_command('echo "test"', False) == 'sudo -p "[sudo via ansible, key=123] password:" echo "test"'

    # Test with become_exe

# Generated at 2022-06-17 10:34:13.705647
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:34:23.230057
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '1234567890'

    # Test with no options
    assert become_module.build_become_command('echo "hello"', '/bin/bash') == 'sudo echo "success"'

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "hello"', '/bin/bash') == 'doas echo "success"'

    # Test with become_flags

# Generated at 2022-06-17 10:34:36.049255
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'

    # Test with no options
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'

    # Test with become_exe
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'

    # Test with become_flags
    become_module.get_option = lambda x: 'become_flags' if x == 'become_flags' else None
    assert become_module

# Generated at 2022-06-17 10:34:45.464843
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no options
    cmd = 'ls'
    shell = '/bin/sh'
    expected = 'sudo ls'
    assert become_module.build_become_command(cmd, shell) == expected

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    expected = 'sudo ls'
    assert become_module.build_become_command(cmd, shell) == expected

    # Test with become_flags

# Generated at 2022-06-17 10:34:57.442669
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_bec

# Generated at 2022-06-17 10:35:05.476657
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-17 10:35:15.412037
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case 1
    become = BecomeModule()
    become.set_options(direct={'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root'})
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test case 2
    become = BecomeModule()
    become.set_options(direct={'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_user': 'root', 'become_pass': 'password'})
    cmd = become.build_become_command('ls', 'sh')

# Generated at 2022-06-17 10:36:09.767404
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = 'test_id'

    # Test with no options
    cmd = become_module.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'sudo -H -S -n test_cmd'

    # Test with become_exe
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    cmd = become_module.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'test_become_exe -H -S -n test_cmd'

    # Test with become_flags

# Generated at 2022-06-17 10:36:18.755246
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_

# Generated at 2022-06-17 10:36:27.185240
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'password:'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -p "password:" ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "password:" ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "password:" ls'

# Generated at 2022-06-17 10:36:38.244592
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', True) == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" ls' % become_module._id
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', True) == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" ls' % become_module._id

# Generated at 2022-06-17 10:36:49.226160
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = '12345'
    become_module.get_option = lambda x: None

    # Test with no become_pass
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_pass
    become_module.get_option = lambda x: 'pass' if x == 'become_pass' else None
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" -u root ls'

    # Test with become_pass and become_user

# Generated at 2022-06-17 10:36:55.737971
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'test_success_command'

    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_success_command'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe -H -S test_success_command'
    become_module.get_option = lambda x: 'test_become_flags'

# Generated at 2022-06-17 10:37:05.971184
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'

    # Test with no options
    cmd = 'test_cmd'
    shell = 'test_shell'
    assert become_module.build_become_command(cmd, shell) == 'sudo test_cmd'

    # Test with become_exe
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'test_become_exe test_cmd'

    # Test with become_flags
    become_module.get_

# Generated at 2022-06-17 10:37:10.259744
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    cmd = 'ls -l'
    shell = '/bin/sh'
    result = become_module.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, cmd)

    # Test with become_exe
    become_module = BecomeModule()
    become_module.set_options(become_exe='/usr/bin/sudo')
    cmd = 'ls -l'
    shell = '/bin/sh'
    result = become_module.build_become_command(cmd, shell)

# Generated at 2022-06-17 10:37:18.896393
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "Hello World"'
    become_module._id = '12345'

    assert become_module.build_become_command('', '') == 'sudo echo "Hello World"'
    assert become_module.build_become_command('', 'sh') == 'sudo sh -c \'echo "Hello World"\''
    assert become_module.build_become_command('', 'csh') == 'sudo csh -c \'echo "Hello World"\''
    assert become_module.build_become_command('', 'fish') == 'sudo fish -c \'echo "Hello World"\''

    become_module.get_option

# Generated at 2022-06-17 10:37:26.312075
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_