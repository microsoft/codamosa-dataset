

# Generated at 2022-06-17 10:28:33.841026
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '12345'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-H'

# Generated at 2022-06-17 10:28:43.058016
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test with no options
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')

    # Test with become_exe
    become_module.set_options(dict(become_exe='/usr/bin/sudo'))
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == '/usr/bin/sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')

    # Test with become_flags

# Generated at 2022-06-17 10:28:48.454722
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    b = BecomeModule()
    cmd = b.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_user
    b = BecomeModule()
    b.set_options(direct={'become_user': 'foo'})
    cmd = b.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n -u foo ls'

    # Test with become_flags
    b = BecomeModule()
    b.set_options(direct={'become_flags': '-l'})
    cmd = b.build_become_command('ls', 'sh')
    assert cmd == 'sudo -l ls'

    # Test with become_pass
    b = BecomeModule()
   

# Generated at 2022-06-17 10:28:56.348984
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:29:04.714477
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: '"%s"' % x
    become_module._id = 'test_id'

    # test default values
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n "ls"'

    # test with become_user
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n -u test_user "ls"'

    # test with become

# Generated at 2022-06-17 10:29:15.350087
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None
    assert become_module.build_

# Generated at 2022-06-17 10:29:25.804197
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': '', 'become_user': 'root'}
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u root sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\'' % become._id

# Generated at 2022-06-17 10:29:36.556864
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(None, {}, None)
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: '"%s"' % x
    become._id = 'abc'

    # Test default values
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n "ls"'

    # Test with become_user
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n -u root "ls"'

    # Test with become_pass

# Generated at 2022-06-17 10:29:45.288415
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = 'test_id'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=test_id] password:" echo "test"'
    become.get_option = lambda x: 'test_user' if x == 'become_user' else None
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=test_id] password:" -u test_user echo "test"'
    become.get_option = lambda x: 'test_pass' if x == 'become_pass' else None
    assert become.build_become

# Generated at 2022-06-17 10:29:50.618920
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None

# Generated at 2022-06-17 10:30:00.141253
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': '', 'become_user': ''}
    assert become.build_become_command('ls', False) == 'sudo -H -S -n ls'
    become.get_option.__dict__ = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': '', 'become_user': 'root'}
    assert become.build_

# Generated at 2022-06-17 10:30:10.778060
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = '123'

    # Test default values
    assert become.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'

    # Test become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become.build_become_command('echo "test"', '/bin/sh') == 'doas -H -S -n echo "success"'

    # Test become_flags
    become.get_option = lambda x: '-E' if x == 'become_flags' else None


# Generated at 2022-06-17 10:30:22.403872
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '12345'
    become._build_success_command = lambda x, y: x
    become.name = 'sudo'

    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S'
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:30:28.152397
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:30:38.362647
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '123456789'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')
    become_module.get_

# Generated at 2022-06-17 10:30:46.771008
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None

    # Test with no options
    cmd = 'ls -l'
    shell = '/bin/sh'
    expected = 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (BecomeBase.SUCCESS_KEY, cmd)
    assert become.build_become_command(cmd, shell) == expected

    # Test with become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    expected = 'doas -H -S -n /bin/sh -c \'echo %s; %s\'' % (BecomeBase.SUCCESS_KEY, cmd)

# Generated at 2022-06-17 10:30:57.493331
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become.get_option = lambda x: '-H'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H ls'

# Generated at 2022-06-17 10:31:08.176862
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None

    # Test with no options set
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # Test with become_pass set
    become.get_option = lambda x: 'test' if x == 'become_pass' else None
    become.prompt = None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -p "test" /bin/sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

# Generated at 2022-06-17 10:31:18.016390
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'

# Generated at 2022-06-17 10:31:28.524822
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__self__ = become
    become.get_option.__dict__ = {}
    become.get_option.__doc__ = None
    become.get_option.__defaults__ = None
    become.get_option.__closure__ = None
    become.get_option.__code__ = None
    become.get_option.__globals__ = None
    become.get_option.__annotations__ = None
    become.get_option.__kwdefaults__ = None
    become.get_option.__name__ = 'get_option'

# Generated at 2022-06-17 10:31:44.728309
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda option: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda option: '-n' if option == 'become_flags' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda option: '-n' if option == 'become_flags' else 'root' if option == 'become_user' else None

# Generated at 2022-06-17 10:31:55.159045
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule()
    become.prompt = None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\''

    # Test with become_user
    become = BecomeModule()
    become.prompt = None
    become.set_options(dict(become_user='test_user'))
    cmd = become.build_become_command('ls', '/bin/sh')

# Generated at 2022-06-17 10:32:04.870898
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'


# Generated at 2022-06-17 10:32:09.047550
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = 'abc'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n echo "success"'


# Generated at 2022-06-17 10:32:16.981051
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule()
    b.prompt = '[sudo via ansible, key=%s] password:'
    b._id = '1234567890'
    b.get_option = lambda x: None
    assert b.build_become_command('echo hello', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=1234567890] password:" echo hello'
    b.get_option = lambda x: '-H -S -n'
    assert b.build_become_command('echo hello', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=1234567890] password:" echo hello'
    b.get_option = lambda x: '-H -S'

# Generated at 2022-06-17 10:32:27.601846
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'success_command'
    assert become.build_become_command('cmd', 'shell') == 'sudo success_command'
    become.get_option = lambda x: 'become_exe'
    assert become.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become.get_option = lambda x: 'become_flags'
    assert become.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become.get_option = lambda x: 'become_pass'
    become._id = 'id'

# Generated at 2022-06-17 10:32:35.107345
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '12345'

    # Test with no options
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo ls'

    # Test with become_exe
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo ls'

    # Test with become_flags
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    cmd = become.build_become_

# Generated at 2022-06-17 10:32:45.294334
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no options
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo ls'

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'doas ls'

    # Test with become_flags
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    cmd = become_module.build_

# Generated at 2022-06-17 10:32:51.488474
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '12345'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:32:56.761532
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = '123'
    become_module.name = 'sudo'
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -p "[sudo via ansible, key=123] password:" echo "success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n -p "[sudo via ansible, key=123] password:" echo "success"'

# Generated at 2022-06-17 10:33:11.169283
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:33:19.480658
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo success'
    become_module._id = '12345'
    assert become_module.build_become_command('echo test', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo success'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo test', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo success'

# Generated at 2022-06-17 10:33:29.158372
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=123] password:'
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = 123

    # no options
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -p "[sudo via ansible, key=123] password:" echo "success"'

    # become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become.build_become_command('echo "test"', 'sh') == 'doas -p "[sudo via ansible, key=123] password:" echo "success"'

    # become_flags

# Generated at 2022-06-17 10:33:36.798002
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n -p "test"'

# Generated at 2022-06-17 10:33:47.087104
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'

    # Test with no options
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become._success_key, 'ls')

    # Test with become_user
    become.get_option = lambda x: 'test_user' if x == 'become_user' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n -u test_user /bin/sh -c \'echo %s; %s\'' % (become._success_key, 'ls')

    # Test with become_exe
    become

# Generated at 2022-06-17 10:33:57.185776
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:34:08.389206
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'

    # Test default
    assert become_module.build_become_command('command', 'shell') == 'sudo success_command'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('command', 'shell') == 'sudo success_command'

    # Test with become_flags
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:34:19.911469
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo'
    become_module._id = 'test'
    assert become_module.build_become_command('echo', 'sh') == 'sudo -H -S -n echo'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo', 'sh') == 'sudo -H -S -n echo'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:34:29.627926
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = 'test_id'

    # Test default values
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (BecomeBase.SUCCESS_KEY, 'ls')

    # Test with become_user
    become.get_option = lambda x: 'test_user' if x == 'become_user' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n -u test_user /bin/sh -c \'echo %s; %s\'' % (BecomeBase.SUCCESS_KEY, 'ls')

# Generated at 2022-06-17 10:34:38.116796
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'


# Generated at 2022-06-17 10:35:10.383670
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:35:19.989982
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '123'

    # test default
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    # test with become_user
    become.get_option = lambda x: 'testuser' if x == 'become_user' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n -u testuser ls'

    # test with become_pass
    become.get_option = lambda x: 'testpass' if x == 'become_pass' else None
    assert become.build_become_command

# Generated at 2022-06-17 10:35:26.924182
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else 'root' if x == 'become_user' else None

# Generated at 2022-06-17 10:35:35.686948
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:35:41.525598
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no arguments
    become_module = BecomeModule(None, None)
    cmd = become_module.build_become_command(None, None)
    assert cmd == ''

    # Test with arguments
    become_module = BecomeModule(None, None)
    become_module.get_option = lambda x: None
    cmd = become_module.build_become_command('ls', None)
    assert cmd == 'sudo -H -S -n ls'

    # Test with arguments and become_pass
    become_module = BecomeModule(None, None)
    become_module.get_option = lambda x: None
    become_module.get_option = lambda x: 'test_password' if x == 'become_pass' else None
    cmd = become_module.build_become_command('ls', None)

# Generated at 2022-06-17 10:35:47.745294
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '12345'

    # Test with no options
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'

    # Test with become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'doas ls'

    # Test with become_flags
    become.get_option = lambda x: '-E' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -E ls'

    # Test with

# Generated at 2022-06-17 10:35:54.655554
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '12345'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root'

# Generated at 2022-06-17 10:36:04.932416
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'root'

# Generated at 2022-06-17 10:36:15.489161
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    become_module._id = '123'
    become_module._build_success_command = lambda cmd, shell: cmd
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:36:23.586585
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test_id'

    # Test with no options set
    cmd = become.build_become_command('echo "Hello World"', False)
    assert cmd == 'sudo echo "Hello World"'

    # Test with become_exe set
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become.build_become_command('echo "Hello World"', False)
    assert cmd == 'doas echo "Hello World"'

    # Test with become_flags set
    become.get_option = lambda x: '-n' if x == 'become_flags' else None
    cmd = become.build_bec

# Generated at 2022-06-17 10:37:13.544608
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: ''
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else ''
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else ''

# Generated at 2022-06-17 10:37:24.963694
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test 1:
    #   - become_exe: sudo
    #   - become_flags: -H -S -n
    #   - become_pass: None
    #   - become_user: root
    #   - cmd: echo 'Hello World'
    #   - shell: /bin/sh
    #   - expected: sudo -H -S -n echo 'Hello World'
    become_exe = 'sudo'
    become_flags = '-H -S -n'
    become_pass = None
    become_user = 'root'
    cmd = 'echo \'Hello World\''
    shell = '/bin/sh'
    expected = 'sudo -H -S -n echo \'Hello World\''
    become_module = BecomeModule()

# Generated at 2022-06-17 10:37:37.544313
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: x
    become_module._build_success_command.__name__ = '_build_success_command'

    # test default values
    cmd = 'ls -l'
    shell = '/bin/bash'
    expected = 'sudo -H -S -n ls -l'
    assert become_module.build_become_command(cmd, shell) == expected

    # test become_exe

# Generated at 2022-06-17 10:37:48.064993
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x

    assert become_module.build_become_command('ls', False) == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -p "%s" ls' % become_module.prompt

# Generated at 2022-06-17 10:37:57.214394
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda option: None
    become_module._build_success_command = lambda cmd, shell: cmd
    become_module._id = '12345'

    # Test with no options set
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo ls'

    # Test with become_user set
    become_module.get_option = lambda option: 'test_user' if option == 'become_user' else None
    cmd = become_module.build_become_command('ls', False)
    assert cmd == 'sudo -u test_user ls'

    # Test with become_exe set
    become_module.get_option = lambda option: 'doas' if option == 'become_exe' else None
    cmd

# Generated at 2022-06-17 10:38:08.875183
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_

# Generated at 2022-06-17 10:38:17.365277
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: 'echo "test"'
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._id = 'test'
    become_module._id.__name__ = '_id'
    become_module.name = 'sudo'
    become_module.name.__name__ = 'name'