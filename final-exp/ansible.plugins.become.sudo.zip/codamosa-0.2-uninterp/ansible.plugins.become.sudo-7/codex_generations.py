

# Generated at 2022-06-17 10:28:28.588344
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_

# Generated at 2022-06-17 10:28:34.502189
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:'
    become._id = '12345'
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:28:45.392348
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'

# Generated at 2022-06-17 10:28:52.364363
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = 'test_id'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=test_id] password:" echo "success"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=test_id] password:" echo "success"'
    become_module.get_option = lambda x: '-n'

# Generated at 2022-06-17 10:29:02.590545
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module.get_option.__doc__ = 'Mock method'
    become_module.get_option.__dict__ = {}
    become_module.get_option.__module__ = 'ansible.plugins.become.sudo'
    become_module.get_option.__defaults__ = (None,)
    become_module.get_option.__kwdefaults__ = None
    become_module.get_option.__closure__ = None
    become_module.get_option.__annotations__ = {}
    become_module

# Generated at 2022-06-17 10:29:14.460856
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.set_options(dict(become_exe='sudo', become_flags='-H -S -n', become_user='root', become_pass=''))
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.set_options(dict(become_exe='sudo', become_flags='-H -S -n', become_user='root', become_pass='pass'))
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" -u root ls' % become_module._id

# Generated at 2022-06-17 10:29:25.055902
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None

    # Test 1: No options
    cmd = 'ls -l'
    shell = '/bin/sh'
    expected = 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, cmd)
    assert become_module.build_become_command(cmd, shell) == expected

    # Test 2: With become_user
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None

# Generated at 2022-06-17 10:29:36.309100
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'
    become_module.prompt = None

    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:29:45.054924
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'

    assert become_module.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:29:54.402981
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S -n'

# Generated at 2022-06-17 10:30:10.756336
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:30:22.405487
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags' if x == 'become_flags' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become_module.get_

# Generated at 2022-06-17 10:30:26.805108
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._id = '12345'
    become_module.prompt = None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module

# Generated at 2022-06-17 10:30:37.477559
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:30:46.168899
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'test_prompt'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'test_success_command'
    become_module._id = 'test_id'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -p "test_prompt" test_success_command'
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -u test_user -p "test_prompt" test_success_command'

# Generated at 2022-06-17 10:30:57.447638
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = '12345'
    become_module.prompt = None
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-12345; %s\'' % 'ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-12345; %s\'' % 'ls'
    become_module.get_option = lambda x: '-H -S'


# Generated at 2022-06-17 10:31:08.174358
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:31:15.912663
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else 'root' if x == 'become_user' else None

# Generated at 2022-06-17 10:31:27.197395
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'

    # Test with no options
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become.success_key, 'ls')

    # Test with become_pass
    become.get_option = lambda x: 'password' if x == 'become_pass' else None
    become.get_option.__name__ = 'get_option'
    cmd = become.build_become_command('ls', False)

# Generated at 2022-06-17 10:31:37.485510
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\''
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\''

# Generated at 2022-06-17 10:31:59.323325
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:32:09.166491
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become.prompt

# Generated at 2022-06-17 10:32:20.176669
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'
    become._build_success_command = lambda x, y: x

    # Test with no become_pass
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n -u root ls'

    # Test with become_pass
    become.get_option = lambda x: 'pass' if x == 'become_pass' else None
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -p "[sudo via ansible, key=123] password:" -u root ls'

# Generated at 2022-06-17 10:32:27.601026
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no become_pass
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -n test_cmd'

    # Test with become_pass
    become_module.get_option = lambda x: 'test_pass' if x == 'become_pass' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -p "[sudo via ansible, key=test_id] password:" -u test_cmd'

# Generated at 2022-06-17 10:32:35.066759
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '12345'

    # Test default values
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    # Test become_exe
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    # Test become_flags
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:32:45.270977
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.loader import become_loader
    become_loader.add_directory('./lib/ansible/plugins/become')
    become_plugin = become_loader.get('sudo')
    become_plugin.set_options(dict(become_flags='-H -S -n', become_user='root', become_pass='secret'))

# Generated at 2022-06-17 10:32:51.487839
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '123'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._id, 'ls')
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._id, 'ls')

# Generated at 2022-06-17 10:32:58.256114
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = None

    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\''
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\''
    become.get_option = lambda x: '-H -S'

# Generated at 2022-06-17 10:33:07.308392
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '12345'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-H'
    assert become_module.build_

# Generated at 2022-06-17 10:33:16.038010
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:33:47.937431
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '12345'

    # test with no options
    cmd = 'ls'
    shell = '/bin/bash'
    assert become_module.build_become_command(cmd, shell) == 'sudo ls'

    # test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'sudo ls'

    # test with become_flags

# Generated at 2022-06-17 10:33:54.399478
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:33:59.865591
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '12345'

    # Test with no options
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_user
    become.get_option = lambda x: 'testuser' if x == 'become_user' else None
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n -u testuser ls'

    # Test with become_pass
    become.get_option = lambda x: 'testpass' if x == 'become_pass' else None
    cmd = become.build_become_command('ls', False)

# Generated at 2022-06-17 10:34:10.741981
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = 'test_id'
    become_module._build_success_command = lambda x, y: 'echo "test"'
    assert become_module.build_become_command('', '') == 'sudo -H -S echo "test"'
    become_module.get_option = lambda x: 'test_user'
    assert become_module.build_become_command('', '') == 'sudo -H -S -u test_user echo "test"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('', '') == 'sudo -H -S -n -u test_user echo "test"'


# Generated at 2022-06-17 10:34:21.495581
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:'
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'

# Generated at 2022-06-17 10:34:35.550805
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    cmd = 'ls'
    shell = '/bin/sh'
    expected_result = 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (BecomeBase.SUCCESS_KEY, cmd)
    assert become_module.build_become_command(cmd, shell) == expected_result

    # Test with become_exe
    become_module = BecomeModule()
    become_module.set_options(dict(become_exe='/usr/bin/sudo'))
    cmd = 'ls'
    shell = '/bin/sh'

# Generated at 2022-06-17 10:34:45.441415
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.set_options(direct={'become_user': 'user', 'become_pass': 'pass', 'become_exe': 'sudo', 'become_flags': '-H -S -n'})
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" -u user sh -c \'echo BECOME-SUCCESS-ls; ls\' && echo BECOME-SUCCESS-ls' % become._id
    become.set_options(direct={'become_user': 'user', 'become_pass': 'pass', 'become_exe': 'sudo', 'become_flags': '-H -S'})
    assert become.build

# Generated at 2022-06-17 10:34:57.404435
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: ''
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:35:05.208359
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: '"%s"' % x
    become_module._id = 'abcdefg'

    # Test with no options
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo "ls"'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo "ls"'

    # Test with become_flags

# Generated at 2022-06-17 10:35:14.139225
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'password:'
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -p "password:" ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -p "password:" ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -p "password:" ls'

# Generated at 2022-06-17 10:36:16.851856
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    assert become_module.build_become_command('ls', True) == 'sudo -H -S -n bash -c "ls"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    assert become_module.build_become_command('ls', True) == 'sudo -H -S -n bash -c "ls"'
    become_

# Generated at 2022-06-17 10:36:27.028941
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', 'sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:36:35.374946
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'id'

    # Test with no options
    cmd = 'ls'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd, shell) == 'sudo ls'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'sudo ls'

    # Test with become_flags

# Generated at 2022-06-17 10:36:41.735984
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test with no options set
    cmd = 'ls'
    shell = '/bin/sh'
    expected = 'sudo ls'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_exe set
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    expected = 'doas ls'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_flags set

# Generated at 2022-06-17 10:36:50.615132
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n sh -c \'( umask 77 && ls )\''
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n sh -c \'( umask 77 && ls )\''
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:36:56.636719
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '12345'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" echo "success"'
    become_module.get_option = lambda x: '-H'
    assert become_module.build_

# Generated at 2022-06-17 10:37:01.554711
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'test_prompt'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'test_success_command'
    become_module._id = 'test_id'

    # Test with no options
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo test_success_command'

    # Test with become_exe
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe test_success_command'

    # Test with become_flags


# Generated at 2022-06-17 10:37:12.772857
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__module__ = 'ansible.plugins.become'
    become.get_option.__doc__ = 'Mock of get_option'
    become.get_option.__dict__ = {}
    become._build_success_command = lambda x, y: 'echo "success"'
    become._build_success_command.__name__ = '_build_success_command'
    become._build_success_command.__module__ = 'ansible.plugins.become'

# Generated at 2022-06-17 10:37:19.298604
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module

# Generated at 2022-06-17 10:37:25.322892
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'

    # test default values
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'

    # test become_exe
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'

    # test become_flags