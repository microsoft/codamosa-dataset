

# Generated at 2022-06-17 10:28:34.066915
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:28:44.977300
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n'
    become_module.get_option = lambda x: 'root'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -u root ls'
    become_module.get_

# Generated at 2022-06-17 10:28:50.526421
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__doc__ = 'Mock method'
    become.get_option.__dict__ = {}
    become.get_option.__module__ = 'ansible.plugins.become'
    become.get_option.__defaults__ = (None,)
    become.get_option.__code__ = type(become.get_option).__code__
    become.get_option.__globals__ = globals()
    become.get_option.__closure__ = (None,)

# Generated at 2022-06-17 10:28:56.961036
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '123'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:29:04.999815
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become_module.get_option = lambda x: 'become_pass'
    become_module._id = 'id'

# Generated at 2022-06-17 10:29:15.537960
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:'
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'

# Generated at 2022-06-17 10:29:25.913501
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: x
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._id = '12345'
    become_module._id.__name__ = '_id'

    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'

# Generated at 2022-06-17 10:29:36.581297
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '12345'
    become_module.prompt = None

    # Test with no options set
    cmd = 'ls -l'
    shell = '/bin/bash'
    expected = 'sudo ls -l'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_exe set
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    expected = 'doas ls -l'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    #

# Generated at 2022-06-17 10:29:45.277074
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module

# Generated at 2022-06-17 10:29:54.603720
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n'
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id

# Generated at 2022-06-17 10:30:10.757760
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test_id'

    # Test with no options
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'sudo test_cmd'

    # Test with become_exe
    become.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'test_become_exe test_cmd'

    # Test with become_flags

# Generated at 2022-06-17 10:30:22.403701
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''
    become_module.get_option = lambda x: '-H -S' if x == 'become_flags' else None
   

# Generated at 2022-06-17 10:30:26.805370
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -n test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe -H -S -n test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None
    assert become_module.build_become_command

# Generated at 2022-06-17 10:30:37.484398
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'
    assert become_module.build_become_command('echo hello', 'sh') == 'sudo -H -S echo hello'
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None
    assert become_module.build_become_command('echo hello', 'sh') == 'sudo -H -S -u test_user echo hello'
    become_module.get_option = lambda x: 'test_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:30:46.167861
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no become_pass
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'

    # Test with become_pass
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.get_option.side_effect = {'become_pass': 'pass'}.get
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'

# Generated at 2022-06-17 10:30:57.447215
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:31:08.173962
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = 'test_id'
    become_module.prompt = 'test_prompt'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'test_success_command'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_success_command'
    become_module.get_option = lambda x: 'test_become_user' if x == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -u test_become_user test_success_command'

# Generated at 2022-06-17 10:31:15.914099
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__doc__ = 'get_option'
    become.get_option.__module__ = 'ansible.plugins.become'
    become.get_option.__defaults__ = (None,)
    become.get_option.__kwdefaults__ = None
    become.get_option.__annotations__ = {}
    become.get_option.__dict__ = {}
    become.get_option.__closure__ = None
    become.get_option.__code__ = None
    become.get_option.__globals__ = {}
    become

# Generated at 2022-06-17 10:31:27.197451
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = 'test_id'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe -H -S test_cmd'
    become_module.get_option = lambda x: 'test_become_flags' if x == 'become_flags' else None

# Generated at 2022-06-17 10:31:37.486260
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:31:59.406305
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n -p "%s" echo "success"' % become_module.prompt
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n -p "%s" echo "success"' % become_module.prompt

# Generated at 2022-06-17 10:32:09.168934
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test'

    # Test default values
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    # Test with become_pass
    become.get_option = lambda x: 'test' if x == 'become_pass' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=test] password:" ls'

    # Test with become_user
    become.get_option = lambda x: 'test' if x == 'become_user' else None
    assert become

# Generated at 2022-06-17 10:32:20.678383
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = 'id'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'

    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'become_exe'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become_module.get_option = lambda x: 'become_flags'
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'
    become_module.get_option

# Generated at 2022-06-17 10:32:33.161192
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda option: None
    become_module._build_success_command = lambda cmd, shell: ' '.join(['"', cmd, '"'])

    # Test with no options
    cmd = 'ls -l'
    expected_cmd = 'sudo "ls -l"'
    assert become_module.build_become_command(cmd, None) == expected_cmd

    # Test with become_exe option
    become_module.get_option = lambda option: 'doas' if option == 'become_exe' else None
    expected_cmd = 'doas "ls -l"'
    assert become_module.build_become_command(cmd, None) == expected_cmd

    # Test with become_flags option

# Generated at 2022-06-17 10:32:43.971138
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ""
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = "12345"

    assert become_module.build_become_command("ls", "/bin/sh") == "sudo -H -S -p \"[sudo via ansible, key=12345] password:\" ls"
    become_module.get_option = lambda x: "sudo" if x == "become_exe" else None
    assert become_module.build_become_command("ls", "/bin/sh") == "sudo -H -S -p \"[sudo via ansible, key=12345] password:\" ls"
    become_module.get_option = lambda x: "sudo"

# Generated at 2022-06-17 10:32:54.063599
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    cmd = 'ls'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/sh -c \'%s\'' % cmd

    # Test with become_exe
    become_module = BecomeModule()
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = 'ls'
    shell = '/bin/sh'
    assert become_module.build_become_command(cmd, shell) == 'doas -H -S -n /bin/sh -c \'%s\'' % cmd

    # Test with become_flags
    become_

# Generated at 2022-06-17 10:33:06.243350
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'

    cmd = 'echo "hello"'
    shell = '/bin/sh'

    # test default
    assert become_module.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/sh -c "echo \\"hello\\""'

    # test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/sh -c "echo \\"hello\\""'

    # test with become

# Generated at 2022-06-17 10:33:15.990681
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_

# Generated at 2022-06-17 10:33:23.056801
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: None
    become_module._id = 'test_id'
    become_module._build_success_command = lambda x, y: 'success_command'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo success_command'
    become_module.get_option = lambda x: 'test_become_exe'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'test_become_exe success_command'
    become_module.get_option = lambda x: 'test_become_flags'

# Generated at 2022-06-17 10:33:34.928220
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda cmd, shell: cmd
    become._id = 'test_id'

    # Test with no options
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'sudo test_cmd'

    # Test with become_exe
    become.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'test_become_exe test_cmd'

    # Test with become_flags

# Generated at 2022-06-17 10:34:03.853405
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_bec

# Generated at 2022-06-17 10:34:11.950290
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:34:22.355217
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "%s" ls' % become_module.prompt

# Generated at 2022-06-17 10:34:35.828598
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '12345'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root'

# Generated at 2022-06-17 10:34:45.464087
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: '"%s"' % x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n "ls"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n "ls"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n "ls"'


# Generated at 2022-06-17 10:34:57.443483
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(None, None, None, None, None, None, None, None)
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'success'
    become._id = 'id'
    become.prompt = None

    # test with no options
    assert become.build_become_command('cmd', 'shell') == 'sudo success'

    # test with become_exe
    become.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become.build_become_command('cmd', 'shell') == 'become_exe success'

    # test with become_flags
    become.get_option = lambda x: 'become_flags' if x == 'become_flags' else None
    assert become

# Generated at 2022-06-17 10:35:09.574005
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'password:'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H -S'
    assert become_module.build_become_command('ls', False) == 'sudo -H -S -n ls'
    become_module.get_option = lambda x: '-H'

# Generated at 2022-06-17 10:35:19.484381
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become = BecomeModule(None, None, None, None)
    cmd = 'ls'
    shell = '/bin/sh'
    expected = 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (BecomeBase.SUCCESS_KEY, cmd)
    actual = become.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_exe
    become = BecomeModule(None, None, None, None)
    become.set_options(dict(become_exe='/usr/bin/sudo'))
    cmd = 'ls'
    shell = '/bin/sh'

# Generated at 2022-06-17 10:35:26.905267
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '123'
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S ls'

# Generated at 2022-06-17 10:35:35.893645
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_become_command('ls', 'sh')

# Generated at 2022-06-17 10:36:38.562779
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:'
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H'

# Generated at 2022-06-17 10:36:49.446419
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '123'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "success"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "success"'

# Generated at 2022-06-17 10:36:55.888777
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: x
    become_module._build_success_command.__name__ = '_build_success_command'
    become_module._id = '123'

    assert become_module.build_become_command('ls', 'bash') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" ls'
    become_module.get_option = lambda x: '-n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:37:06.031160
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-17 10:37:16.370825
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:37:23.309358
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda x: ''
    become_module._build_success_command = lambda x, y: x
    become_module._id = '1234567890'

    # Test with no options
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'

    # Test with become_exe
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else ''
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo ls'

    # Test with become_flags
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else ''


# Generated at 2022-06-17 10:37:32.704048
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module.success_key, 'ls')

    # Test with become_user
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None

# Generated at 2022-06-17 10:37:40.083364
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'

    # Test with no arguments
    cmd = become.build_become_command('', '')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo ~ && sleep 0\''

    # Test with become_pass
    become.get_option = lambda x: 'password' if x == 'become_pass' else None
    become.get_option.__name__ = 'get_option'
    cmd = become.build_become_command('', '')

# Generated at 2022-06-17 10:37:45.743330
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    cmd = 'echo hello'
    shell = '/bin/sh'
    become_exe = 'sudo'
    become_flags = '-H -S -n'
    become_user = 'root'
    become_pass = 'password'
    become_cmd = ' '.join([become_exe, become_flags, '-p "%s"' % become.prompt, '-u %s' % become_user, become._build_success_command(cmd, shell)])
    assert become.build_become_command(cmd, shell) == become_cmd
    become.set_options(become_pass=become_pass)

# Generated at 2022-06-17 10:37:56.901425
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls -l', '/bin/sh') == 'sudo -H -S -p "%s" ls -l' % become.prompt
    become.get_option = lambda x: '-n'
    assert become.build_become_command('ls -l', '/bin/sh') == 'sudo -H -S -p "%s" ls -l' % become.prompt
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls -l', '/bin/sh') == 'sudo -H -S -p "%s" ls -l' % become