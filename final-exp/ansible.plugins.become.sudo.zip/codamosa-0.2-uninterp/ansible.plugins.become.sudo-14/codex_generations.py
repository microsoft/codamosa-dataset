

# Generated at 2022-06-17 10:28:27.925862
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = 'test_id'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -p "[sudo via ansible, key=test_id] password:" test_cmd'
    become_module.get_option = lambda x: 'test_user' if x == 'become_user' else None
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S -p "[sudo via ansible, key=test_id] password:" -u test_user test_cmd'

# Generated at 2022-06-17 10:28:34.416182
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'echo "success"'
    become._id = 'abc'
    assert become.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None

# Generated at 2022-06-17 10:28:43.083142
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = 'test'
    become_module._id = 'test'
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'

    assert become_module.build_become_command('echo "test"', '/bin/bash') == 'sudo -H -S echo "success"'
    become_module.get_option = lambda x: 'test'
    assert become_module.build_become_command('echo "test"', '/bin/bash') == 'sudo -H -S -p "test" -u test echo "success"'
    become_module.get_option = lambda x: '-n'

# Generated at 2022-06-17 10:28:51.463971
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with default values
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''

    # Test with custom values
    become.get_option = lambda x: {
        'become_exe': 'sudo_exe',
        'become_flags': '-H -S -n -E',
        'become_pass': 'pass',
        'become_user': 'user',
    }.get(x)
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id

# Generated at 2022-06-17 10:29:02.132179
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "hello"'
    become_module._id = '123'
    assert become_module.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "hello"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "hello"'
    become_module.get_option = lambda x: '-H -S -n'
    become_module.get_

# Generated at 2022-06-17 10:29:13.950888
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '123'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "success"'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=123] password:" echo "success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_

# Generated at 2022-06-17 10:29:24.569289
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '12345'
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
   

# Generated at 2022-06-17 10:29:36.145102
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__doc__ = 'Mock method'
    become.get_option.__module__ = 'ansible.plugins.become'
    become.get_option.__dict__ = {}
    become.get_option.__defaults__ = (None,)
    become.get_option.__kwdefaults__ = {}
    become.get_option.__closure__ = ()
    become.get_option.__code__ = compile('def get_option(self, x):\n    return None\n', '<string>', 'exec')
    become.get_

# Generated at 2022-06-17 10:29:44.894786
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test'

    # Test with no options
    cmd = become.build_become_command('test', False)
    assert cmd == 'sudo -H -S -n test'

    # Test with become_user
    become.get_option = lambda x: 'user' if x == 'become_user' else None
    cmd = become.build_become_command('test', False)
    assert cmd == 'sudo -H -S -n -u user test'

    # Test with become_pass
    become.get_option = lambda x: 'pass' if x == 'become_pass' else None
    cmd = become.build_

# Generated at 2022-06-17 10:29:50.409720
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'

    # Test with no options
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_exe
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test with become_flags
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    cmd = become.build_become_command('ls', 'sh')
    assert cmd

# Generated at 2022-06-17 10:30:06.020012
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module._id = '12345'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become_module._success_key, 'ls')

# Generated at 2022-06-17 10:30:16.717567
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'test_id'

    # Test with no options
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'sudo test_cmd'

    # Test with become_exe
    become.get_option = lambda x: 'test_become_exe' if x == 'become_exe' else None
    cmd = become.build_become_command('test_cmd', 'test_shell')
    assert cmd == 'test_become_exe test_cmd'

    # Test with become_flags

# Generated at 2022-06-17 10:30:22.990631
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module.get_option = lambda option: None
    become_module._id = 'test_id'
    become_module._build_success_command = lambda cmd, shell: cmd

    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo test_cmd'
    become_module.get_option = lambda option: 'test_become_user'
    assert become_module.build_become_command('test_cmd', 'test_shell') == 'sudo -u test_become_user test_cmd'
    become_module.get_option = lambda option: 'test_become_flags'

# Generated at 2022-06-17 10:30:32.829083
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S -n'
    become.get_option = lambda x: 'root'

# Generated at 2022-06-17 10:30:39.550666
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-17 10:30:49.208908
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda option: None
    become_module.prompt = None
    become_module._id = '123'
    become_module._build_success_command = lambda cmd, shell: cmd

    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become_module.get_option = lambda option: 'sudo' if option == 'become_exe' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

# Generated at 2022-06-17 10:30:58.716634
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: 'success_command'
    become._id = 'id'
    assert become.build_become_command('cmd', 'shell') == 'sudo success_command'
    become.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become.build_become_command('cmd', 'shell') == 'become_exe success_command'
    become.get_option = lambda x: 'become_flags' if x == 'become_flags' else None
    assert become.build_become_command('cmd', 'shell') == 'become_exe become_flags success_command'

# Generated at 2022-06-17 10:31:08.391822
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo echo "success"'
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo echo "success"'
    become_module.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become_module.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'
    become

# Generated at 2022-06-17 10:31:16.053462
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = 'abc'

    # Test default values
    assert become_module.build_become_command('', '') == 'sudo -H -S -n echo "success"'

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become_module.build_become_command('', '') == 'doas -H -S -n echo "success"'

    # Test with become_flags

# Generated at 2022-06-17 10:31:27.301445
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda key: None
    become_module.prompt = None
    become_module._id = '12345'
    become_module._build_success_command = lambda cmd, shell: cmd
    assert become_module.build_become_command('ls -l', '/bin/sh') == 'sudo -H -S -n -p "[sudo via ansible, key=12345] password:" ls -l'
    become_module.get_option = lambda key: '-H -S -n'
    assert become_module.build_become_command('ls -l', '/bin/sh') == 'sudo -H -S -n -p "[sudo via ansible, key=12345] password:" ls -l'

# Generated at 2022-06-17 10:31:47.663604
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test with no options
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''

    # Test with become_user
    become_module.set_options(dict(become_user='testuser'))
    cmd = become_module.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n -u testuser /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''

    # Test with become_flags

# Generated at 2022-06-17 10:31:53.903560
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(None, {}, None)
    become.prompt = None
    become.get_option = lambda x: None
    assert become.build_become_command('ls', None) == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', None) == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become.build_become_command('ls', None) == 'sudo -H -S -n ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:32:02.901112
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__doc__ = 'Mock method'
    become._build_success_command = lambda x, y: 'echo "success"'
    become._build_success_command.__name__ = '_build_success_command'
    become._build_success_command.__doc__ = 'Mock method'
    become._id = '12345'
    become._id.__name__ = '_id'
    become._id.__doc__ = 'Mock method'
    become.name = 'sudo'
    become.name.__name__ = 'name'


# Generated at 2022-06-17 10:32:10.976089
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'
    become.get_option = lambda x: 'root' if x == 'become_user' else None
    assert become.build_

# Generated at 2022-06-17 10:32:17.472364
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = None
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '123'

    # Test with no flags, no user, no password
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo ls'

    # Test with flags, no user, no password
    become.get_option = lambda x: '-H -S -n'
    cmd = become.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n ls'

    # Test with flags, user, no password

# Generated at 2022-06-17 10:32:27.625756
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._id = '12345'
    become._build_success_command = lambda x, y: 'echo "success"'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: '-H -S'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'
    become.get_option = lambda x: '-H -S -n'
    assert become.build_become_command('echo "test"', 'sh') == 'sudo -H -S -n echo "success"'

# Generated at 2022-06-17 10:32:33.756396
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '12345'

    # Test with no options
    cmd = become.build_become_command('/bin/ls', 'sh')
    assert cmd == 'sudo -H -S -n /bin/ls'

    # Test with become_user
    become.get_option = lambda x: 'jdoe' if x == 'become_user' else None
    cmd = become.build_become_command('/bin/ls', 'sh')
    assert cmd == 'sudo -H -S -n -u jdoe /bin/ls'

    # Test with become_flags
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:32:44.369781
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: '"%s"' % x
    become_module._id = '123'
    become_module.prompt = None

    # Test with no options
    cmd = 'ls'
    shell = 'sh'
    become_module.build_become_command(cmd, shell)
    assert become_module.cmd == 'sudo "ls"'

    # Test with become_exe
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    become_module.build_become_command(cmd, shell)
    assert become_module.cmd == 'doas "ls"'

    # Test with become_flags
    become_

# Generated at 2022-06-17 10:32:54.326997
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    b = BecomeModule()
    cmd = b.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''

    # Test with become_user
    b = BecomeModule()
    b.set_options(dict(become_user='testuser'))
    cmd = b.build_become_command('ls', '/bin/sh')
    assert cmd == 'sudo -H -S -n -u testuser /bin/sh -c \'echo BECOME-SUCCESS-ls; /bin/sh -c "ls"\''

    # Test with become_pass
    b = BecomeModule()

# Generated at 2022-06-17 10:33:06.248016
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -n -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S' if x == 'become_flags' else None
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -p "%s" ls' % become.prompt
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None

# Generated at 2022-06-17 10:33:43.600038
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = '12345'
    become_module._build_success_command = lambda x, y: 'echo "success"'
    assert become_module.build_become_command('echo "test"', False) == 'sudo -H -S echo "success"'
    assert become_module.build_become_command('echo "test"', True) == 'sudo -H -S -s echo "success"'
    become_module.get_option = lambda x: '-H -S -n'
    assert become_module.build_become_command('echo "test"', False) == 'sudo -H -S echo "success"'

# Generated at 2022-06-17 10:33:53.590469
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None

    # Test with no options
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n sh -c \'echo BECOME-SUCCESS-ls; ls\' && (echo BECOME-SUCCESS-ls; exit 0)'

    # Test with become_exe
    become.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become.build_become_command('ls', 'sh')
    assert cmd == 'doas -H -S -n sh -c \'echo BECOME-SUCCESS-ls; ls\' && (echo BECOME-SUCCESS-ls; exit 0)'

    #

# Generated at 2022-06-17 10:33:59.504370
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with no options
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    cmd = become_module.build_become_command('ls', 'sh')
    assert cmd == 'sudo -H -S -n sh -c \'echo BECOME-SUCCESS-ls; LS_COLORS=""; export LS_COLORS; ls\''

    # Test with become_exe
    become_module = BecomeModule()
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    cmd = become_module.build_become_command('ls', 'sh')

# Generated at 2022-06-17 10:34:10.486315
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'success_command'
    become_module._id = 'id'

    # Test with no options
    assert become_module.build_become_command('cmd', 'shell') == 'sudo success_command'

    # Test with become_exe
    become_module.get_option = lambda x: 'become_exe' if x == 'become_exe' else None
    assert become_module.build_become_command('cmd', 'shell') == 'become_exe success_command'

    # Test with become_flags
    become_module.get_option = lambda x: 'become_flags' if x == 'become_flags' else None
    assert become_module

# Generated at 2022-06-17 10:34:21.214323
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    become_module.get_option.__name__ = 'get_option'
    become_module._build_success_command = lambda x, y: x
    become_module._build_success_command.__name__ = '_build_success_command'

    # Test with no options
    cmd = 'ls -l'
    shell = '/bin/sh'
    expected = 'sudo ls -l'
    actual = become_module.build_become_command(cmd, shell)
    assert actual == expected

    # Test with become_user

# Generated at 2022-06-17 10:34:35.444080
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-17 10:34:45.465707
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule(None, None, None, None, None, None)
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', None) == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id
    become_module.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become_module.build_become_command('ls', None) == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become_module._id

# Generated at 2022-06-17 10:34:57.441282
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "success"'
    become_module._id = '12345'

    # Test with no options set
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'sudo -H -S -n echo "success"'

    # Test with become_exe set
    become_module.get_option = lambda x: 'doas' if x == 'become_exe' else None
    assert become_module.build_become_command('echo "test"', '/bin/sh') == 'doas -H -S -n echo "success"'

    # Test with become_flags set

# Generated at 2022-06-17 10:35:05.476138
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.set_options(dict(become_exe='sudo', become_flags='-H -S -n', become_user='root', become_pass=''))
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'
    become_module.set_options(dict(become_exe='sudo', become_flags='-H -S', become_user='root', become_pass='test'))
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" -u root ls' % become_module._id

# Generated at 2022-06-17 10:35:10.912820
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._build_success_command = lambda x, y: x
    become._id = '123'

    # test default values
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    # test custom values
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else '-H -S' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'

    # test custom values with password

# Generated at 2022-06-17 10:36:19.787491
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test 1
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "hello"'
    become_module._id = '12345'
    assert become_module.build_become_command('', '') == 'sudo echo "hello"'

    # Test 2
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module._build_success_command = lambda x, y: 'echo "hello"'
    become_module._id = '12345'
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id

# Generated at 2022-06-17 10:36:27.725090
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {'become_exe': None, 'become_flags': None, 'become_pass': None, 'become_user': None}
    become.name = 'sudo'
    assert become.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" ls' % become._id

# Generated at 2022-06-17 10:36:38.278861
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=%s] password:' % become._id
    become.get_option = lambda x: None
    become.get_option.__name__ = 'get_option'
    become.get_option.__dict__ = {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': None, 'become_user': None}
    become._build_success_command = lambda x, y: 'echo "hello"'
    assert become.build_become_command('echo "hello"', 'sh') == 'sudo -H -S -n echo "hello"'

# Generated at 2022-06-17 10:36:49.255706
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._build_success_command = lambda x, y: x
    become_module._id = '123'

    # Test default values
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n ls'

    # Test with become_user
    become_module.get_option = lambda x: 'testuser' if x == 'become_user' else None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -n -u testuser ls'

    # Test with become_flags

# Generated at 2022-06-17 10:36:55.764109
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.get_option = lambda x: None
    become_module.prompt = None
    become_module._id = '12345'
    become_module.name = 'sudo'
    become_module._build_success_command = lambda x, y: x
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', 'sh') == 'sudo -H -S -p "[sudo via ansible, key=12345] password:" ls'
    become_module.get_option = lambda x: '-H'
    assert become_module

# Generated at 2022-06-17 10:37:05.976229
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = 'password:'
    become._id = '12345'
    become._build_success_command = lambda x, y: x
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become.get_option = lambda x: 'sudo' if x == 'become_exe' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become.get_option = lambda x: '-H -S -n' if x == 'become_flags' else None
    assert become.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls'
    become.get_

# Generated at 2022-06-17 10:37:10.240705
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = ''
    become_module._id = '12345678901234567890123456789012'
    become_module.get_option = lambda x: None
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345678901234567890123456789012] password:" ls'
    become_module.get_option = lambda x: '-n'
    assert become_module.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=12345678901234567890123456789012] password:" ls'
    become_module.get_option

# Generated at 2022-06-17 10:37:18.896921
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    become.prompt = None
    become._id = '123'

    # Test default values
    cmd = become.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo %s; %s\'' % (become._success_key, 'ls')

    # Test with become_pass
    become.get_option = lambda x: 'test' if x == 'become_pass' else None
    cmd = become.build_become_command('ls', False)

# Generated at 2022-06-17 10:37:29.423056
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = ''
    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = '123'

    # no flags, no user, no password
    assert become.build_become_command('/bin/ls', '/bin/sh') == '/bin/ls'

    # no flags, no user, with password
    become.get_option = lambda x: 'secret' if x == 'become_pass' else None
    assert become.build_become_command('/bin/ls', '/bin/sh') == 'sudo -p "[sudo via ansible, key=123] password:" /bin/ls'

    # flags, no user, no password

# Generated at 2022-06-17 10:37:39.054666
# Unit test for method build_become_command of class BecomeModule