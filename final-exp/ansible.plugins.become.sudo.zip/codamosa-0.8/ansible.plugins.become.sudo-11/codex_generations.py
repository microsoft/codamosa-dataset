

# Generated at 2022-06-11 13:15:26.874027
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule({}, [])
    # Python 3's shlex doesn't work with unicode input
    shell = 'sh' if become.HAS_UNICODE else u'bash'

    def compare(become, cmd, expect_cmd, extra_vars=None):
        if extra_vars is not None:
            become.extra_vars = extra_vars
        if shell == 'sh':
            cmd = cmd.encode('utf-8')
        act_cmd = become.build_become_command(cmd, shell)
        assert act_cmd == expect_cmd
        if shell == 'sh':
            act_cmd = act_cmd.decode('utf-8')
        act_success_cmd = become._build_success_command(cmd, shell, act_cmd)
        assert act_success_cmd == expect

# Generated at 2022-06-11 13:15:37.947900
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes

    runner = BecomeModule(ImmutableDict({
        'remote_user': 'ansible',
        'transport': 'ssh',
        'connection': 'ssh',
        'become_user': 'root',
        'become_pass': 'secret',
    }))

    cmd_with_shell = runner.build_become_command(['/bin/sh', '-c', 'pwd'], True)
    cmd_without_shell = runner.build_become_command('pwd', False)

    assert to_bytes("sudo -p \"{0}\" -u root /bin/sh -c 'pwd'".format(runner.prompt)) == cmd_with_shell
   

# Generated at 2022-06-11 13:15:48.740715
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import os
    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.close()
    os.remove(tmp.name)
    tmp_path = tmp.name
    become = BecomeModule(
            become_user='ansible_become_user',
            become_exe='ansible_become_exe',
            become_flags='ansible_become_flags',
            become_pass='ansible_become_pass',
            cmd='ansible_cmd',
            shell='ansible_shell'
    )

# Generated at 2022-06-11 13:15:58.976127
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    m = BecomeModule()
    assert m.get_option('become_exe') == 'sudo'
    assert m.get_option('become_user') == 'root'

    assert m.build_become_command('ls /tmp', None) == 'sudo -H -S -n /bin/sh -c "ls /tmp;"'
    assert m.build_become_command('ls /tmp', '/bin/sh') == 'sudo -H -S -n /bin/sh -c "ls /tmp;"'
    assert m.build_become_command('ls /tmp', '/bin/bash') == 'sudo -H -S -n /bin/sh -c "ls /tmp;"'

# Generated at 2022-06-11 13:16:06.861690
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    print("\nUnit test for method 'build_become_command' of class 'BecomeModule' ...")
    host_vars = {'ansible_become_user': 'test_user', 'ansible_become_pass': 'test_password', 'ansible_become_flags': '-H -S -n -p "%(prompt)s"'}
    test_object = BecomeModule(load_info=None, variable_manager=None, options=host_vars)
    # Without become_user
    print("\n[DEBUG] Using options: %s and command %s" % (test_object.get_option('become_flags'), test_object.build_become_command(cmd='test_command', shell='test_shell')))
    # With become_user

# Generated at 2022-06-11 13:16:16.849588
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    class Args:
        become_exe = None
        become_flags = None
        become_pass = None
        become_user = None

    args = Args()
    become_pass = 'toto'

    args.become_pass = become_pass
    args.become_flags = '-n'
    args.become_exe = 'sudo'
    args.become_user = 'user'
    b = BecomeModule(None, args, None, None)
    cmd = b._build_success_command("whoami", ["whoami"])
    assert cmd == "whoami"
    sudo_cmd = b.build_become_command(cmd, ["whoami"])
    a = " ".join(sudo_cmd)

# Generated at 2022-06-11 13:16:23.544999
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.set_options(dict(become_user='alex', become_pass='asdf'))
    become.prompt = None
    cmd = become.build_become_command('do_something', 'shell')
    assert cmd == 'sudo -H -S -p "[sudo via ansible, key=] password:" -u alex sh -c \'echo %s; do_something && echo %s\'' % (
        become._success_key, become._success_key)

# Generated at 2022-06-11 13:16:30.017500
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # empty arguments
    become = BecomeModule()

    # no arguments
    cmd = become.build_become_command(None, None)
    assert cmd == None

    # test with some arguments
    cmd = become.build_become_command("ls -al", "/bin/sh")
    assert cmd == 'sudo -H -S -n /bin/sh -c \'%s\'' % ("ls -al")

    # populate the object
    become = BecomeModule()
    become.prompt = 'become password: '
    become.get_option = lambda key: {
        'become_user': 'root',
        'become_pass': 'secret',
        'become_exe': 'sudo',
        'become_flags': '',
    }.get(key, None)

    # test with different options
    cmd

# Generated at 2022-06-11 13:16:40.327190
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bm = BecomeModule()

    # Test options with default values
    bm.get_option = lambda key : None

    # cmd without prompt
    cmd = bm.build_become_command('ls -al', '/usr/bin/sh')
    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo ~ && echo $HOME\' && /bin/sh -c \'ls -al\''

    # cmd with prompt
    bm.get_option = lambda key : True if key == "become_pass" else None
    cmd = bm.build_become_command('ls -al', '/usr/bin/sh')
    assert cmd == 'sudo -H -S -p "password:" -n /bin/sh -c \'echo ~ && echo $HOME\' && /bin/sh -c \'ls -al\''

# Generated at 2022-06-11 13:16:50.092376
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import ansible.plugins.become as become
    cmd = become.BecomeModule(shell=None, become_exe='sudo', become_flags='-H -S -n', become_user=None, become_pass=None)
    assert cmd.build_become_command('some_command', shell=False) == 'sudo -H -S -n some_command'
    assert cmd.build_become_command('some_command', shell=True) == 'sudo -H -S -n sh -c "some_command"'

    cmd = become.BecomeModule(shell=None, become_exe='sudo', become_flags='-H -S -n', become_user='root', become_pass=None)

# Generated at 2022-06-11 13:17:05.078141
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import tempfile
    # create a temporary empty script to be used in place of a real one
    temp_script = tempfile.mkstemp()[1]
    with open(temp_script, 'wb') as f:
        f.write('')
    # create an instance of our BecomeModule
    bm = BecomeModule(play_context=dict(become_exe='sudo', become_user='root', become_pass='', become_flags='-n'),
                      shell=None, loader=None)

    # test the coomand generated by default
    cmd_generated = bm.build_become_command(temp_script, shell=False)

# Generated at 2022-06-11 13:17:14.592456
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with a pipeline
    cmd = "echo foo; echo bar"
    for shell in ('/bin/sh', '/bin/bash'):
        expected_cmd = [
            'sudo',
            '-H -S -n',
            '-u root',
            'sh -c {0}'.format(shell.replace('/', r'\/')).join(['\''] * 2),
            'echo foo; echo bar',
        ]

        became = BecomeModule(
            become_flags='-H -S -n',
            become_user='root',
            become_pass='',
            become_exe='sudo'
        )
        actual_cmd = became.build_become_command(cmd, shell)
        assert actual_cmd == ' '.join(expected_cmd)


# Generated at 2022-06-11 13:17:24.913330
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = "ls"
    shell = "/bin/sh"
    self = BecomeModule()
    self.get_option = lambda foo: None
    with pytest.raises(AttributeError):
        self.build_become_command(cmd, shell)

    self.get_option = lambda foo: 1
    with pytest.raises(TypeError):
        self.build_become_command(cmd, shell)

    self.get_option = lambda foo: "/bin/sudo"
    with pytest.raises(TypeError):
        self.build_become_command(cmd, shell)

    self.get_option = lambda foo: None
    self.get_option = lambda foo: "foo"
    self._build_success_command = lambda foo: None

# Generated at 2022-06-11 13:17:35.586013
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule('', {})
    become_module.prompt = '[sudo via ansible, key=%s] password:' % become_module._id
    sudo_cmd = 'sudo -n %s' % become_module._build_success_command('shell_cmd', 'sh')
    assert become_module.build_become_command('shell_cmd', 'sh') == sudo_cmd

    become_module.prompt = ''
    assert become_module.prompt == ''
    sudo_cmd_w_options = 'sudo -H -S -p "[sudo via ansible, key=%s] password:" -u testuser %s' \
                          % (become_module._id, become_module._build_success_command('shell_cmd', 'sh'))

# Generated at 2022-06-11 13:17:43.299486
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    sudo_become = BecomeModule()
    sudo_become.set_options(dict(become=True, become_user='foo', become_pass='pass',
                                 become_exe='sudo_exe', become_flags='-H -S -n -E'))

    assert sudo_become.build_become_command('id', shell=None) == 'sudo_exe -H -S -E -u foo /bin/sh -c \'(echo %^%$^SUDO_PROMPT$^%^^% && ' + \
                                                                  'sleep 1 && echo pass) | sudo_exe -H -S -n -u foo -p "pass" id\''


# Generated at 2022-06-11 13:17:44.787626
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_cmd = isinstance(BecomeModule(), BecomeBase)
    assert become_cmd

# Generated at 2022-06-11 13:17:54.371680
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    options=dict()
    options['become_pass'] = None
    options['become_flags'] = '-H -S -n'
    b = BecomeModule()
    b.set_options(options)
    cmd = 'grep test /tmp/abc'
    shell = '/bin/bash'
    expected_cmd = 'sudo -H -S -n /bin/bash -c \'echo %s; %s\'' % (b._generate_success_command(), cmd)
    # Test
    result = b.build_become_command(cmd, shell)
    assert (result == expected_cmd)


# Generated at 2022-06-11 13:18:03.936562
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # pylint: disable=protected-access
    cls = BecomeModule({})
    assert cls.build_become_command('/bin/foo', False) == 'sudo -H -S -n /bin/foo'
    assert cls.build_become_command('/bin/bar', True) == 'sudo -H -S -n sh -c "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin; /bin/bar"'
    assert cls.build_become_command('/bin/foo', False) == 'sudo -H -S -n /bin/foo'
    cls.become_pass = 'somepassword'

# Generated at 2022-06-11 13:18:16.242567
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bm = BecomeModule(become_pass='s3cr3t', become_user='me')
    assert bm.build_become_command("whoami", shell='/bin/bash') == 'sudo -H -S -p "[sudo via ansible, key=ansible-sudo-1] password:" -u me /bin/bash -c "whoami"'
    bm.become_flags = "-H -S -n"
    assert bm.build_become_command("whoami", shell='/bin/bash') == 'sudo -H -S -p "[sudo via ansible, key=ansible-sudo-2] password:" -u me /bin/bash -c "whoami"'
    bm.become_flags = "HnS"

# Generated at 2022-06-11 13:18:25.480714
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Arrange
    cmd_input  = "echo -v"
    shell_input = "bash"
    become_exe = "sudo"
    become_flags = "-H -S -n"
    become_user = "root"
    become_pass = "secretpassword1"
    become_plugin = BecomeModule()
    become_plugin.def_flags = "-H -S -n"
    become_plugin._id = "053f3396500e0d8c6a80b0f40ac6d0ed"
    become_plugin.prompt = "[sudo via ansible, key=053f3396500e0d8c6a80b0f40ac6d0ed] password:"

    # Method call
    # Actual

# Generated at 2022-06-11 13:18:40.691362
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cls_instance = BecomeModule(None, {}, {}, {}, {})
    assert cls_instance.build_become_command("cat /etc/shadow", False) == "sudo -H -S  -p \"[sudo via ansible, key=None] password:\"  -u root 'cat /etc/shadow; echo \"$?\"'"

# Generated at 2022-06-11 13:18:52.111791
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_object = BecomeModule()
    test_object._build_success_command = lambda cmd, shell: "[%s]" % cmd
    cmd = "ls"
    shell = "TEST_SHELL"

    # Test method with default values
    becomecmd = "sudo"
    flags = ''
    prompt = ''
    user = ''
    expected = "%s %s %s %s [%s]" % (becomecmd, flags, prompt, user, cmd)

    result = test_object.build_become_command(cmd, shell)
    assert(expected == result)

    # Test method with provided but empty values
    test_object.become_pass = ''
    test_object.become_user = ''
    test_object.become_flags = ''

# Generated at 2022-06-11 13:18:57.187105
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_base_instance = BecomeModule()
    become_base_instance._id = '123456789'
    src_command = 'whoami'
    expected_command = "sudo -H -S -p '[sudo via ansible, key=123456789] password:' -u root /bin/sh -c 'whoami'"
    assert become_base_instance.build_become_command('whoami', '/bin/sh') == expected_command


# Generated at 2022-06-11 13:19:07.469891
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule()

    # Run a specific test case
    test_case = 'test_case1'
    if test_case == 'test_case1':
        cmd = 'ls -l'
        shell = 'sh'
        user = 'user1'
        prompt = 'this is a prompt'
        b.prompt = prompt
        b._id = 1
        b._success_cmd = 'echo 0'

        # Expected command
        expected = "sudo -p \"%s\" -u %s %s" % (prompt, user, 'echo 0')

        b.set_options(become_pass=True, become_user=user)
        assert b.build_become_command(cmd, shell) == expected
    elif test_case == 'test_case2':
        cmd = 'ls -l'


# Generated at 2022-06-11 13:19:16.498349
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Monkeypatch AnsibleModule
    from ansible.module_utils.basic import AnsibleModule, get_distribution
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    AnsibleModule.run_command = lambda self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False: (0, to_bytes(''), '')
    # Create BecomeModule instance
    become = BecomeModule()
    become.get_option = lambda option: getattr(become, option)
    become.prompt = ''

# Generated at 2022-06-11 13:19:20.983335
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test 1 when self.prompt = None
    set_prompt = None
    cmd = 'command'
    shell = '/bin/bash'
    options = {
        'become_flags': '-H -S -n',
        'become_exe': 'sudo',
        'become_pass': None,
        'become_user': 'root'
    }
    become_module = BecomeModule(None)
    become_module.prompt = set_prompt
    become_module.set_options(options)
    command = become_module.build_become_command(cmd, shell)

    assert command == 'sudo -H -S -n /bin/bash -c \'echo %s; %s\'' % (
        become_module.success_key, cmd)

    # Test 2 when self.prompt =

# Generated at 2022-06-11 13:19:30.077763
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.errors import AnsibleError
    from ansible.plugins.become import BecomeBase
    from ansible.plugins.become import BecomeModule

    become_cmd = BecomeModule('sudo')
    become_exe = become_cmd._get_option_become_exe()
    become_flags = become_cmd._get_option_become_flags()
    become_pass = None
    become_user = become_cmd._get_option_become_user() or ''
    user = None
    shell = '/bin/bash'
    test_cmd = ['whoami']

    # Test with no arguments
    cmd = become_cmd.build_become_command([], shell)

# Generated at 2022-06-11 13:19:39.296087
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_module = BecomeModule()
    #initialize variables for test
    test_module.prompt = ''
    test_module._id = 'id-test'
    test_module.get_option = None
    test_module._build_success_command = None
    shell = '/bin/sh'
    #test1
    test_module.get_option = lambda x: {'become_exe': '', 'become_flags': '', 'become_pass': '', 'become_user': ''}.get(x, None)
    test_module._build_success_command = lambda x, shell: 'test_build_success_command'
    cmd = 'test_cmd'
    result = test_module.build_become_command(cmd, shell)

# Generated at 2022-06-11 13:19:47.720802
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule()
    assert module.build_become_command("echo ok", shell="echo") == "echo ok"
    assert module.build_become_command("echo ok", shell="/bin/sh") == "/bin/sh -c 'echo ok'"
    assert module.build_become_command('echo "1 2"', shell="/bin/sh") == "/bin/sh -c 'echo \\\"1 2\\\"'"
    assert module.build_become_command(["echo", "1 2"], shell="/bin/sh") == "/bin/sh -c 'echo 1 2'"
    assert module.build_become_command(["echo", "1 2"], shell="/bin/sh", executable="/bin/csh") == "/bin/csh -c 'echo 1 2'"

# Generated at 2022-06-11 13:19:56.888757
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Arrange
    # Create mock object of class BecomeModule
    BecomeModule.__module__ = 'ansible_collections.ansible.builtin.plugins.become.sudo'
    mock_obj = BecomeModule()

    # set values for class variables
    mock_obj.name = 'sudo'
    mock_obj.get_option('become_exe')
    mock_obj.get_option('become_flags')
    mock_obj.get_option('become_pass')
    mock_obj.get_option('become_user')
    mock_obj.prompt = '[sudo via ansible, key=%s] password:' % mock_obj._id

    # Act
    # call the method GetOption() of class BecomeModule

# Generated at 2022-06-11 13:20:27.607957
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule()
    b.get_option = lambda x: None
    b._build_success_command = lambda cmd, shell: '__SUCCESS_COMMAND'
    assert b.build_become_command("/usr/bin/true", "sh") == "/usr/bin/sudo -H -S __SUCCESS_COMMAND"
    assert b.build_become_command("/usr/bin/true", "sh") == "/usr/bin/sudo -H -S -n __SUCCESS_COMMAND"
    assert b.build_become_command(None, "sh") is None

# Generated at 2022-06-11 13:20:37.351713
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    assert become.build_become_command('', False) == ''
    assert become.build_become_command('', True) == ''
    assert become.build_become_command('ls -l', False) == 'sudo -H -S -n  ls -l'
    assert become.build_become_command('ls -l', True) == 'sudo -H -S -n  ls -l'
    become.prompt = 'prompt'
    become.get_option = lambda x: None
    assert become.build_become_command('ls -l', False) == 'sudo -H -S -n -p "prompt"  ls -l'

# Generated at 2022-06-11 13:20:42.270459
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    mod = BecomeModule()
    mod._id = "_id"
    mod.prompt = "prompt"
    mod.get_option = lambda x: "get_option"

    assert mod.build_become_command("cmd", "shell") == 'sudo -H -S -p "prompt" -u get_option "(echo become_success_marker; (cmd); exit 0)"'

# Generated at 2022-06-11 13:20:51.469118
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule()

    # cmd is empty
    cmd = module.build_become_command("", "/bin/bash")
    assert cmd == ""

    # cmd is empty, but with a prompt
    module.prompt = "password:"
    cmd = module.build_become_command("", "/bin/bash")
    assert cmd == ""

    # cmd is not empty, without prompt
    cmd = module.build_become_command("ls", "/bin/bash")
    assert cmd == "sudo -H -S ls"

    # cmd is not empty, without prompt, but with user and flags
    module.become_user = "test"
    module.become_flags = "-H -S"
    cmd = module.build_become_command("ls", "/bin/bash")

# Generated at 2022-06-11 13:21:01.003004
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule(
        module_args=dict(),
        task_vars=dict(),
        connection='ssh'
    )
    # Becoming some user using old syntax
    become_module.get_option = lambda x: None
    become_module.get_become_option = lambda x: None
    become_module.prompt = '[sudo via ansible, key={0}] password:'.format(become_module._id)

    # Becoming root
    become_module.get_become_option = lambda x: 'root' if x == 'become_user' else None

# Generated at 2022-06-11 13:21:10.560655
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import pytest

    # there's no need to do an actual plugin lookup here
    become = BecomeModule(load_name='test_become', become_method_name='sudo')

    cmd = '/bin/foo'
    shell = '/bin/sh'

    become.get_option = lambda x: None
    become._build_success_command = lambda x, y: x
    become._id = 'become_id'

    # test with default options
    assert become.build_become_command(cmd, shell) == 'sudo -H -S -n /bin/foo'

    # test with different become_exe
    become.get_option = lambda x: 'foo' if x == 'become_exe' else None

# Generated at 2022-06-11 13:21:19.002128
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    becomecmd = ('Sorry, try again.',)
    fail = ('//usr/local/bin/sudo', '-H', '-S', '-n', '-u', 'test', '-p', '"[sudo via ansible, key=%s] password:"')
    missing = ('//usr/local/bin/sudo', '-H', '-S', '-u', 'test', '-p', '"[sudo via ansible, key=%s] password:"')
    missing_pass = ('//usr/local/bin/sudo', '-H', '-S', '-n', '-u', 'test')
    test_command = "cd /tmp"
    shell = '/usr/bin/sh'
    plugin = BecomeModule()
    plugin._id = 1234

# Generated at 2022-06-11 13:21:28.103812
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import sys
    if sys.version_info[0] < 3 or sys.version_info[1] < 5:
        import mock
    else:
        from unittest import mock
    bm = BecomeModule()
    bm.run_command = mock.MagicMock()
    bm.get_option = mock.MagicMock()

    # Test 1:
    #  become_exe  = None
    #  become_user = None
    #  become_pass = None
    #  become_flags = None
    bm.get_option.side_effect = [None, None, None, None]
    bm.get_option.return_value = None
    cmd = bm.build_become_command('/bin/true', 'sh')

# Generated at 2022-06-11 13:21:35.743944
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule()
    module._id = 'f4c4e9ea-d4c4-4bb7-8f04-2fa18c65fa97'
    module.prompt = None
    module.set_options({'become_exe': None, 'become_flags': '-H -S -n',
                        'become_pass': None, 'become_user': None})
    cmd = 'ls -l'
    cmd = module.build_become_command(cmd, None)
    assert(cmd == 'sudo -H -S -n ls -l')

    module.set_options({'become_exe': 'su', 'become_flags': '-',
                        'become_pass': None, 'become_user': None})

# Generated at 2022-06-11 13:21:44.008549
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule(
        become_pass=None,
        become_exe='sudo',
        become_flags=None,
    )


# Generated at 2022-06-11 13:22:44.899787
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_obj = BecomeModule(None)

    test_obj.get_option = MagicMock()
    test_obj.get_option.side_effect = ['become_exe', 'become_flags', 'become_pass', 'become_user']

    test_obj._build_success_command = MagicMock()
    test_obj._build_success_command.return_value = 'cmd'

    cmd = ''
    shell = 'shell'
    result = test_obj.build_become_command(cmd, shell)
    assert result == 'sudo -H -S -n -p "[sudo via ansible, key=None] password:" -u become_user cmd'

    cmd = 'cmd'
    result = test_obj.build_become_command(cmd, shell)

# Generated at 2022-06-11 13:22:54.316613
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test default
    become_flags = ""
    become_pass = ""
    become_user = ""
    cmd = "id -u"
    shell = "/bin/bash"
    become_exe = "sudo"

    bm = BecomeModule()
    bm.get_option = lambda s: {
        "become_flags": become_flags,
        "become_pass": become_pass,
        "become_exe": become_exe,
        "become_user": become_user,
    }[s]
    assert bm.build_become_command(cmd, shell) == ' '.join([become_exe, become_flags, become_user, 'id -u'])

    # Test user
    become_flags = ""
    become_pass = ""
    become_user = "ansible"
   

# Generated at 2022-06-11 13:23:02.168779
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    command = become_module.build_become_command(cmd='ls', shell='/bin/bash')
    assert 'sudo -H -S -p "[sudo via ansible, key=become_id] password:" ls' == command

    become_module = BecomeModule()
    become_module.get_option = lambda a: ''
    command = become_module.build_become_command(cmd='ls', shell='/bin/bash')
    assert 'sudo -H -S ls' == command

    become_module = BecomeModule()
    become_module.get_option = lambda a: '-H -S -n'
    become_module.prompt = 'prompt: '
    command = become_module.build_become_command(cmd='ls', shell='/bin/bash')

# Generated at 2022-06-11 13:23:11.112891
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.plugins.loader import become_loader
    become_plugin_class = become_loader.get('sudo')
    become_plugin = become_plugin_class()

    # test with no options set
    cmd = 'ls'
    shell = '/bin/sh'
    expected_become_cmd = 'sudo -H -S -n /bin/sh -c ' + shlex_quote('%s ; echo BECOME-SUCCESS-%s' % (cmd, id(become_plugin)))
    actual_become_cmd = become_plugin.build_become_command(cmd, shell)
    assert actual_become_cmd == expected_become_cmd

    # test with

# Generated at 2022-06-11 13:23:20.335455
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Prepare inputs
    task_vars = dict(
        ansible_become_password="test123",
        ansible_become_user="become_user",
        ansible_become_exe="become_exe",
        ansible_become_flags="become_flags",
        ansible_perms_exec="ansible_perms_exec",
        ansible_perms_read="ansible_perms_read",
        ansible_perms_write="ansible_perms_write",
        ansible_perms_special="ansible_perms_special"
    )
    tmp = BecomeModule(become_options=dict(), loader=None, variables=task_vars)
    cmd = "cmd"
    executable = "/bin/bash"

    # Call the function under test

# Generated at 2022-06-11 13:23:23.600772
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert 'sudo -H -S -p "xxx" -u root bash -c \'echo BECOME-SUCCESS-XXXXXXXXXXXXXXXXXXXX\'' == \
        BecomeModule(None, {}).build_become_command('echo BECOME-SUCCESS-XXXXXXXXXXXXXXXXXXXX', '/bin/bash')

# Generated at 2022-06-11 13:23:31.861014
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule()
    # Test default instance i.e. no become_* option defined
    cmd = b.build_become_command('whoami', 'shell')
    assert cmd == 'sudo -n -H -S  /bin/sh -c \'whoami\'', "Command for default instance is wrong"

    b = BecomeModule(dict(become=True, become_method='sudo', become_user='fuxi', become_pass='mypass', become_exe='/usr/local/bin/sudo', become_flags='-H -S -n'))
    # Test all options defined case
    cmd = b.build_become_command('whoami', 'shell')

# Generated at 2022-06-11 13:23:38.570277
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins.become import BecomeBase

    mock_cmd = '/bin/false'
    vm = BecomeModule(BecomeBase())
    vm.set_options(ImmutableDict(become_user='auser', become_pass='true', become_flags='-H -S -n', become_exe='/bin/become'))
    assert vm.build_become_command(mock_cmd, '/bin/sh') == '/bin/become -H -S -n -p "Sorry, try again." -u auser /bin/sh -c \'/bin/false\''

# Generated at 2022-06-11 13:23:45.843193
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # No password, no flags, no user
    result = become_module.build_become_command(cmd='do_something', shell=None)
    assert result == 'sudo /bin/sh -c \'echo ~ && ( do_something )\''

    # With flags, no user
    become_module.set_options(direct={'become_flags': '-H -S -n'})
    result = become_module.build_become_command(cmd='do_something', shell=None)
    assert result == 'sudo -H -S -n /bin/sh -c \'echo ~ && ( do_something )\''

    # No password, with user, no flags

# Generated at 2022-06-11 13:23:50.490967
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    plugin = BecomeModule(
            become_pass='fake_pass',
            become_exe='fake_become_exe',
            become_flags='fake_become_flags',
            become_user='fake_become_user'
    )
    assert plugin.build_become_command(cmd='fake_cmd', shell='fake_shell') == 'fake_become_exe fake_become_flags -p "[sudo via ansible, key=%s] password:" -u fake_become_user fake_cmd' % plugin._id