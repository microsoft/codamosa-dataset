

# Generated at 2022-06-11 13:15:23.666244
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    cmd = ['/usr/bin/foo']
    shell = '/bin/sh'
    become_user = 'kenny'
    become_exe = 'sudo'
    become_pass = 'secret'
    become_flags = '-H -S'

# Generated at 2022-06-11 13:15:34.586691
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class PrivEscOptions(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class PlayContext(object):
        def __init__(self, **kwargs):
            self.become = PrivEscOptions(**kwargs)

    class RunnerOptions(object):
        def __init__(self, **kwargs):
            self.become = PrivEscOptions(**kwargs)

    class Runner(object):
        def __init__(self, **kwargs):
            self.options = RunnerOptions(**kwargs)


# Generated at 2022-06-11 13:15:41.998652
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Set up plugin options
    become_exe = 'sudo'
    become_flags = '-H -S -n'
    become_user = 'admin'
    become_pass = 'password'
    become_command_prefix = 'ab -n'

    # Set up cmd to become
    cmd = ['some_command', 'some_arg']

    become = BecomeModule()
    become.set_options(direct=None, become_exe=become_exe, become_flags=become_flags, become_user=become_user, become_pass=become_pass, become_command_prefix=become_command_prefix)

    result = become.build_become_command(cmd, 'some_shell')


# Generated at 2022-06-11 13:15:52.892945
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    args = dict(cmd='mycommand')

    # Test with set become_exe, become_flags and become_user
    become = BecomeModule(
        dict(
            become_exe='/usr/bin/sudo',
            become_flags='-H -S -n',
            become_user='someuser'
        ),
        **args
    )
    result = become.build_become_command('mycommand', 'shell')
    assert result == '/usr/bin/sudo -H -S -n -u someuser /bin/sh -c mycommand'

    # Test with empty become_flags
    become = BecomeModule(
        dict(
            become_exe='/usr/bin/sudo',
            become_flags='',
            become_user='someuser'
        ),
        **args
    )
    result = become.build_

# Generated at 2022-06-11 13:16:02.950020
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    class TestObject(object):
        def __init__(self, become_flags, become_user, become_pass):
            self.get_option = lambda name: {
                'become_flags': become_flags,
                'become_user': become_user,
                'become_pass': become_pass,
            }[name]

    become = BecomeModule()

    # Tests for no flags, no user, no pass
    test_object = TestObject('', '', '')
    result = 'sudo  -H -S -n  /bin/sh -c '
    assert become.build_become_command('/bin/sh', '/bin/sh') == result

    # Tests for flags, no user, no pass
    test_object = TestObject('-f', '', '')

# Generated at 2022-06-11 13:16:08.869267
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # argspec = inspect.getargspec(BecomeModule.build_become_command)
    args = ['ls -la', '/bin/sh']
    kwargs = {}
    expected_cmd = 'sudo -l -H -S -n ls -la'

    # create instance of class
    become_module = BecomeModule()
    # set up options
    become_module.options = {}
    # test method
    cmd = become_module.build_become_command(*args, **kwargs)
    # assert test results
    assert cmd == expected_cmd

# Generated at 2022-06-11 13:16:18.990985
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    module = BecomeModule()

    cmd = 'echo test-cmd'
    shell = '/bin/bash'


# Generated at 2022-06-11 13:16:28.098366
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    class DummyBecomeModule(BecomeModule):
        def __init__(self):
            self.get_option = lambda x: None

    #
    # Test without become_user value
    #
    become_module = DummyBecomeModule()
    cmd = 'echo "hello world"'
    shell = '/bin/sh'
    res = become_module.build_become_command(cmd, shell)
    assert res == "sudo -S -n '%s'" % (become_module._build_success_command(cmd, shell))

    #
    # Test with become_user value
    #
    become_module.get_option = lambda x: 'root' if x == 'become_user' else None
    cmd = 'echo "hello world"'
    shell = '/bin/sh'

# Generated at 2022-06-11 13:16:38.739360
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Normal testing
    become_module = BecomeModule()
    become_module.get_option = lambda id: None
    become_module._build_success_command = lambda cmd, shell: "'" + cmd + "'"
    # Running the test
    assert become_module.build_become_command('uptime', 'sh') == "sudo -H -S -n 'uptime'"
    assert become_module.build_become_command('uptime', 'csh') == "sudo -H -S -n 'uptime'"
    # Testing with become_user
    become_module.get_option = lambda id: 'foo' if id == 'become_user' else None
    assert become_module.build_become_command('uptime', 'sh') == "sudo -H -S -n -u foo 'uptime'"
    assert become

# Generated at 2022-06-11 13:16:48.833512
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    d = {'ansible_become_exe': 'sudo', 'ansible_become_flags': '-H -S -n', 'ansible_become_user': 'root'}
    b = BecomeModule(become_pass=None, become_exe='sudo', become_flags=None, become_prompt='', become_user='root')
    b = BecomeModule(become_pass=None, become_exe=None, become_flags=None, become_prompt='', become_user='root')
    b = BecomeModule(become_pass=None, become_exe=None, become_flags='', become_prompt='', become_user='root')

# Generated at 2022-06-11 13:17:01.527466
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(None)
    cmd = "whoami"
    shell = "/bin/sh"

    become.get_option = lambda x: None

    test = become.build_become_command(cmd, shell)
    expected = 'sudo {} whoami'.format(shell or '')
    assert test == expected, ("%s returned %s" % (test, expected))

    become.get_option = lambda x: "sudo"
    become.prompt = None
    test = become.build_become_command(cmd, shell)
    expected = 'sudo {} whoami'.format(shell or '')
    assert test == expected, ("%s returned %s" % (test, expected))

    become.prompt = '[sudo via ansible, key=%s] password:'

# Generated at 2022-06-11 13:17:11.944594
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    test_input = {}


# Generated at 2022-06-11 13:17:19.017785
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-11 13:17:29.979681
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    plugin = BecomeModule()

    def new_get_option(option):
        if option == 'become_exe':
            return 'sudo'
        elif option == 'become_flags':
            return '-H -S -n'
        elif option == 'become_user':
            return 'root'
        else:
            return None

    plugin.get_option = new_get_option

    cmd = plugin.build_become_command('some_cmd', None)
    assert cmd == 'some_cmd'

    cmd = plugin.build_become_command('echo hello', None)
    assert cmd == 'echo hello'

    cmd = plugin.build_become_command('exit 0', 'sh')

# Generated at 2022-06-11 13:17:39.417681
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(become_method_name='sudo', become_exe='sudo', become_flags='-H -S -n', become_pass=True)
    cmd = ['setup', '-i', '-T']
    expect_cmd = "sudo -H -S -n -p \"%s\"  -u root bash -c 'echo %s; %s; echo %s;'" % (
        '%s',
        become._build_success_command('', True) % '/bin/sh',
        ' '.join(cmd),
        become._build_success_command('', True) % '/bin/sh'
    )
    tested_cmd = become.build_become_command(cmd, True)
    assert tested_cmd == expect_cmd

# Generated at 2022-06-11 13:17:50.418941
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    host = {}
    task = {}
    become_user = 'root'
    become_exe = '/bin/sudo'
    become_flags = '-H -S -n'
    become_pass = ''
    become_args = ''

    module = 'some_module'
    module_args = 'arg1 arg2'
    m_abspath = '/path/to/' + module
    m_args_str = m_abspath + ' ' + module_args

    shell = '/bin/sh'
    result = BecomeModule(task, become_user, become_exe, become_flags, become_pass, become_args, None, host).build_become_command(m_args_str, shell)
    assert result == '/bin/sudo -H -S -n /path/to/some_module arg1 arg2'

# Generated at 2022-06-11 13:18:00.892015
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bcmd = BecomeModule(runner=None)
    assert bcmd.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'

    bcmd = BecomeModule(runner=None, become_flags='-H -S -n', become_exe='sudo', become_user='admin')
    assert bcmd.build_become_command('ls', 'sh') == 'sudo -H -S -n ls'

    bcmd = BecomeModule(runner=None, become_exe='sudo', become_flags='-H -S -n', become_pass='secret')
    bcmd.prompt = '[sudo via ansible, key=myid] password:'
    assert bcmd.build_become_command('ls', 'sh') == 'sudo -H -S -p "mypromptpassword:" ls'

# Generated at 2022-06-11 13:18:07.524326
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_object = BecomeModule()
    become_exe = 'sudo'
    become_user = 'testuser'
    become_flags = '-n -H -S'
    become_pass = None

    assert test_object.build_become_command("", "") == ""
    assert test_object.build_become_command("command", "") == "sudo -n -H -S command"
    assert test_object.build_become_command("command", "bash") == "sudo -n -H -S bash -c 'command'"
    assert test_object.build_become_command("command", "psql") == "sudo -n -H -S psql -c 'command'"

    test_object.become_exe = become_exe
    test_object.become_user = become_user
    test_object

# Generated at 2022-06-11 13:18:18.304551
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # input arguments
    cmd = ['/bin/ls', '-l']
    shell = '/bin/sh'

    # output of method build_become_command
    cmd_expected = 'sudo -H -S -n -p "[sudo via ansible, key=ansible] password:" -u root /bin/sh -c "ls -l" && echo BECOME-SUCCESS-ansible'

    bm = BecomeModule()
    bm.prompt = '[sudo via ansible, key=ansible] password:'
    bm._id = 'ansible'
    cmd_actual = bm.build_become_command(cmd, shell)
    assert cmd_expected == cmd_actual

# Generated at 2022-06-11 13:18:27.064303
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    sudo_become_module = BecomeModule()
    sudo_become_module.prompt = None
    sudo_become_module.password = None
    sudo_become_module.name = 'sudo'
    sudo_become_module._id = 'ansible-sudo-0'
    sudo_become_module.get_option = lambda key: None
    sudo_become_module._build_success_command = lambda cmd, shell: None

    # test with no cmd
    assert sudo_become_module.build_become_command(None, None) is None

    # test with cmd and no become_user
    actual_cmd = sudo_become_module.build_become_module('test cmd', 'test shell')
    assert actual_cmd.endswith('test cmd')

    # test with cmd and become_user

# Generated at 2022-06-11 13:18:36.823599
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    username = 'alice'
    password = 'Password123!'
    become = BecomeModule(dict(become_user=username, become_pass=password, become_exe='sudo', become_flags='-H'))
    cmd = '/bin/ls -la'
    shell = '/bin/sh'
    assert become.build_become_command(cmd, shell) == 'sudo -H -p "[sudo via ansible, key=%s] password:" -u %s sh -c "if ( /bin/sh -c \'%s\' ) ; then exit 0; else /bin/echo BECOME-SUCCESS-%s; fi"' % (become._id, username, cmd, become._id)

# Generated at 2022-06-11 13:18:48.509750
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    plugin_instance = BecomeModule()
    plugin_instance.get_option = lambda x: None
    plugin_instance._id = 'test_id'

    # start testing
    cmd = "/bin/ls"
    shell = False
    expected = "/usr/bin/sudo -n -S /bin/ls"
    assert expected == plugin_instance.build_become_command(cmd, shell)

    shell = True
    expected = "/usr/bin/sudo -n -S -s '/bin/ls'"
    assert expected == plugin_instance.build_become_command(cmd, shell)

    plugin_instance.get_option = lambda x: 'sudo'
    expected = "/usr/bin/sudo -n -S /bin/ls"
    assert expected == plugin_instance.build_become_command(cmd, shell)

    plugin_instance

# Generated at 2022-06-11 13:18:56.197720
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become._id = '3fbc2dac-7307-11e6-bde6-34363bc7c4c0'

    # Case: No arguments
    cmd = ''
    shell = '/bin/sh'
    expected = "sudo -H -S -n -p \"[sudo via ansible, key=3fbc2dac-7307-11e6-bde6-34363bc7c4c0] password: \"  ''"
    assert become.build_become_command(cmd, shell) == expected

    cmd = 'ls'
    shell = '/bin/sh'

# Generated at 2022-06-11 13:18:57.109260
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    assert '' == ''


# Generated at 2022-06-11 13:19:07.387299
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule({}, {}, {}, {})

    cmd = 'foo'
    shell = '/bin/sh'

    become_module.set_option('become_exe', '-f')
    become_module.set_option('become_flags', '-H')
    become_module.set_option('become_pass', 'bar')
    become_module.set_option('become_user', 'foobar')


# Generated at 2022-06-11 13:19:12.560610
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    b = BecomeModule()

    cmd = 'ls -la'
    shell = 'command'

    assert '/bin/sh -c echo ~ && printf \'%s\0\' \'123\'', b.build_success_command(shell, cmd, '123')
    assert 'sudo -H -S -n -u root /bin/sh -c echo ~ && printf \'%s\0\' \'123\'', b.build_become_command(cmd, shell)

# Generated at 2022-06-11 13:19:20.383857
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    plugin = BecomeModule()
    global PASSWORD
    PASSWORD = 'passw0rd'

    assert plugin.build_become_command('/usr/bin/whoami', '/bin/false') == 'sudo -H -S -n -p "[sudo via ansible, key=%s] password:" "/usr/bin/whoami ; true"' % plugin._id
    # Test for password, command and shell specified
    assert plugin.build_become_command('/usr/bin/whoami', '/bin/bash') == 'sudo -H -S -p "[sudo via ansible, key=%s] password:" "/usr/bin/whoami ; /bin/bash"' % plugin._id
    # Test for no password, command and shell specified
    assert plugin.build_become_command('/usr/bin/whoami', '/bin/bash')

# Generated at 2022-06-11 13:19:22.678575
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    obj = BecomeModule()
    assert obj.build_become_command(None,None) == None
    assert obj.build_become_command("",None) == ""
    assert obj.build_become_command("ls",None) == "sudo -H -S -n ls"


# Generated at 2022-06-11 13:19:31.981609
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test that it correctly escapes the command to be run
    # by sudo when building the command line
    become = BecomeModule()
    become.get_option = lambda option: None

    cmd = ['echo', '"quoted"']

# Generated at 2022-06-11 13:19:34.938310
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    m = BecomeModule('sudo')
    m.prompt = ''
    m.prompt_re = ''
    cmd = m.build_become_command('some command', 'some shell')
    assert cmd == "sudo -H -S -n 'some shell -c \"some command\"'"
    cmd = m.build_become_command('', 'some shell')
    assert cmd == "sudo -H -S -n some shell"


# Generated at 2022-06-11 13:19:46.608925
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None
    cmd = "command"
    shell = "/bin/sh"
    # Test 1: sudo not installed
    become.get_option = lambda x: None
    assert become.build_become_command(cmd, shell)
    # Test 2: sudo installed, but not configured
    become.get_option = lambda x: "/usr/bin/sudo" if x == "become_exe" else None
    assert become.build_become_command(cmd, shell) == "/usr/bin/sudo -n  command"
    # Test 3: sudo installed and configured
    #   > sudo_setup["become_exe"] == "/usr/bin/sudo"

# Generated at 2022-06-11 13:19:55.348947
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test case when cmd is None
    become_module = BecomeModule(dict(ansible_become_user=None, ansible_become_pass=None, ansible_become_exe=None, ansible_become_flags=None),sep=None)
    assert become_module.build_become_command(cmd=None, shell=None) is None

    # Test case when cmd is not None
    become_module = BecomeModule(dict(ansible_become_user=None, ansible_become_pass=None, ansible_become_exe=None, ansible_become_flags=None),sep=None)
    assert become_module.build_become_command(cmd='ls', shell=None) == 'sudo -H -S ls'


# Generated at 2022-06-11 13:20:03.800697
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.loader import become_loader
    plugin = become_loader.get('sudo')
    cmd = '/bin/foo'
    shell_true = True
    shell_false = False

    become_base = BecomeModule()

    # test for shell=None and with sudo_pass
    become_base.prompt = None
    become_base._options = {
        'become_pass': 'bar',
        'become_user': None,
        'become_flags': None,
        'become_exe': None,
    }
    result = become_base._build_success_command(cmd, shell_false)
    assert result == cmd

    # test for shell=None and without sudo_pass
    become_base._options['become_pass'] = None
    result = become_base._build_success_command

# Generated at 2022-06-11 13:20:12.185449
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    context = {'become_exe': 'sudo', 'become_user': 'root', 'become_pass': '123456', 'become_flags': '-H -S -n'}
    cmd = 'ls'
    shell = '/bin/bash'
    expected = 'sudo -H -S -p "[sudo via ansible, key=None] password:" -u root "ls"'

    result = become_module.build_become_command(cmd, shell)

    assert(expected == result)
    #assert(expected == become_module.build_become_command(cmd, shell))

if __name__ == '__main__':
    test_BecomeModule_build_become_command()

# Generated at 2022-06-11 13:20:21.721026
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    m_module = make_module('', '', {'become_user': None, 'become_exe': 'sudo', 'become_pass': None, 'become_flags': '-H -S'})
    result = m_module.build_become_command('cmd', 'shell')
    assert result == 'sudo -H -S cmd'

    m_module.become_pass = 'pass'
    result = m_module.build_become_command('cmd', 'shell')
    assert result == 'sudo -H -Sp "cmd"'

    m_module.become_pass = None
    m_module.ansible_become_user = 'user'
    result = m_module.build_become_command('cmd', 'shell')
    assert result == 'sudo -H -S -u user cmd'

   

# Generated at 2022-06-11 13:20:30.799383
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    mod = BecomeModule()
    mod._id = '12345'

    # test with become_pass, flags and user
    cmd = 'foo'
    mod._options['become_pass'] = '88888888'
    mod._options['become_flags'] = '-o foo -H -S -n'
    mod._options['become_user'] = 'bar'
    expected = 'sudo -o foo -H -S -p "[sudo via ansible, key=12345] password:" -u bar /bin/sh -c \'"foo"\' > /dev/null && (echo "BECOME-SUCCESS-12345"; exit 0)'
    actual = mod.build_become_command(cmd, '/bin/sh')
    assert actual == expected

    # test with become_pass, no flags, user

# Generated at 2022-06-11 13:20:40.477934
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule()
    b.set_options({
        'become_exe': "new_sudo.sh",
        'become_flags': "-H -S -p \"Hello World\"",
        'become_user': "user1",
        'become_pass': "secret",
    })

# Generated at 2022-06-11 13:20:49.803554
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    m = BecomeModule()

    b = m.build_become_command(cmd='ls', shell='sh')
    assert b == 'sudo -H -S ls'

    m.prompt = None
    m.set_options(become_pass='abc', become_flags='-H -S -n', become_exe='/usr/bin/sudo')
    b = m.build_become_command(cmd='ls', shell='sh')
    assert b == '/usr/bin/sudo -H -S -p "ls" ls'

    m.prompt = None
    m.set_options(become_pass='abc', become_flags='-H -S -n', become_exe='/usr/bin/sudo', become_user='AAA')

# Generated at 2022-06-11 13:20:54.582533
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = 'test123'
    cmd = 'ls -la'
    shell = '/bin/bash'
    becomecmd = become_module.build_become_command(cmd, shell)
    assert becomecmd == 'sudo -H -S -p "[sudo via ansible, key=test123] password:"  ls -la'


# Generated at 2022-06-11 13:21:04.739973
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    bm = BecomeModule()

    assert bm.build_become_command('whoami', '/bin/bash') == 'sudo -H -S -n whoami'
    assert bm.build_become_command('whoami', '/bin/bash') == 'sudo -H -S -n whoami'
    bm.set_options(become_user='root')
    assert bm.build_become_command('whoami', '/bin/bash') == 'sudo -H -S -n -u root whoami'
    bm.set_options(become_user='root', become_flags='-H')
    assert bm.build_become_command('whoami', '/bin/bash') == 'sudo -H -S -n -u root whoami'

# Generated at 2022-06-11 13:21:14.936971
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # create plugin instance
    plugin = BecomeModule()

    # test building of a command with sudo as become_exe, empty become_flags,
    # empty become_user, empty become_pass and shell cmd
    plugin.set_options(dict(become_exe='sudo', become_flags='', become_user='', become_pass=''))
    cmd = "/bin/sh -c 'echo SUCCESS'"
    assert plugin.build_become_command(cmd, False) == "sudo /bin/sh -c 'echo SUCCESS'"

    # test building of a command with sudo as become_exe, -Hn as become_flags,
    # root as become_user, empty become_pass and shell cmd

# Generated at 2022-06-11 13:21:23.580482
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible import context

    become_plugin = BecomeModule()
    become_plugin._id = 'abc123'

    # Test with empty options
    become_plugin.options = {}
    cmd = 'command string'
    shell = '/bin/bash'
    becomecmd = become_plugin.build_become_command(cmd, shell)
    assert becomecmd == 'sudo -H -S -n /bin/bash -c \'%s; echo %s; exit 0\'' % (cmd, BecomeBase.SUCCESS_KEY)

    # Test with options specified
    become_plugin.options = {
        'become_flags': '--machine-readable',
        'become_user': 'becomeuser',
        'become_pass': 'changeme!'
    }
    becomecmd = become_plugin.build_become_command

# Generated at 2022-06-11 13:21:32.056669
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Becoming root with become_pass and become_flags
    b = BecomeModule()
    b.set_options(become_flags=u'-H -S -n', become_pass=u'xyz', become_user=None)

# Generated at 2022-06-11 13:21:39.753767
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # Test with become_pass is empty string
    become = BecomeModule()
    become.get_option = lambda option: option == 'become_pass' and '' or ''
    become.prompt = ''
    become._build_success_command = lambda cmd, shell: 'SUCC'
    become_command = become.build_become_command('mycmd', False)
    assert become_command == 'sudo  -S SUCC', \
        'Build become command without password should return "sudo  -S SUCC"'

    # Test with become_pass is set
    become = BecomeModule()
    become.get_option = lambda option: option == 'become_pass' and 'BECOME_PASS' or ''
    become.prompt = '[sudo via ansible, key=%s] password:' % (become._id)
    become._build

# Generated at 2022-06-11 13:21:48.186596
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # all flags
    plugin = BecomeModule()
    plugin.set_options({'become_exe': 'sudo', 'become_user': 'root', 'become_flags': '-H -S -n', 'become_pass': 'password'})
    cmd = 'ls'
    shell = '/bin/bash'
    expected = 'sudo -H -S -p "sudo via ansible, key=1 password:" -u root /bin/bash -c "ls"'
    actual = plugin.build_become_command(cmd, shell)
    assert actual == expected, 'Expected command to be %s, but got %s' % (expected, actual)

    # all flags with inverted order
    plugin = BecomeModule()

# Generated at 2022-06-11 13:21:56.781967
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    ################
    # Constructor
    ################

    # Instanciate a BecomeModule object with a fake ansible_become_exe
    become_exe = "sudo"
    fake_become_exe = "/bin/sudo"
    sudo_become_module = BecomeModule(play_context=None, become_exe=fake_become_exe)

    ################
    # build_become_command(cmd, shell) method
    ################

    # Test case 1: No arguments
    cmd = None
    shell = None
    expected_result = cmd
    real_result = sudo_become_module.build_become_command(cmd, shell)
    assert real_result == expected_result

    # Test case 2: cmd has a value
    cmd = "echo hello"

# Generated at 2022-06-11 13:22:05.630379
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    ansible_module = BecomeModule()
    cmd_input = 'echo "hello"'
    shell = 'sh'

    # When defaults are set and no override options are set
    ansible_module.get_option = MagicMock(return_value=None)
    ansible_module._build_success_command = MagicMock(return_value='"echo" "hello"')
    result = ansible_module.build_become_command(cmd_input, shell)
    expected = 'sudo -H -S -n "echo" "hello"'
    print(result)
    assert result == expected

    # When become_user is set to "admin"
    ansible_module.get_option = MagicMock(side_effect=['admin', None, None])

# Generated at 2022-06-11 13:22:12.410503
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_cmd = BecomeModule(None, {}, {'command': 'echo'})

    # Test no become_exe
    become_cmd.get_option = lambda option: None
    assert become_cmd.build_become_command('echo', shell='bash') == 'echo'

    # Test no cmd
    become_cmd.get_option = lambda option: None
    assert become_cmd.build_become_command('', shell='bash') == ''

    # Test no options
    become_cmd.get_option = lambda option: None
    assert become_cmd.build_become_command('echo', shell='bash') == 'sudo echo'



# Generated at 2022-06-11 13:22:20.954527
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Ensure AnsibleModule is available
    try:
        from ansible.module_utils.common.removed import removed_class
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        AnsibleModule = removed_class("AnsibleModule")
        from ansible.module_utils.basic import AnsibleModule

    # Ensure become is available
    try:
        from ansible.plugins.become import BecomeBase
    except ImportError:
        BecomeBase = removed_class("BecomeBase")

    # Instantiate module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )

    # Instantiate become plugin
    become = BecomeModule()

    # Ensure the constructor of BecomeBase was called.

# Generated at 2022-06-11 13:22:29.735595
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.loader import become_loader
    plugin = become_loader.get('sudo')()
    assert plugin.build_become_command(cmd=None, shell=None) == None

    # Test execution of become_command with become_pass option provided
    cmd = 'ls'
    shell = '/bin/bash'
    sudo_command = plugin.build_become_command(cmd=cmd, shell=shell)
    # we only want to verify that the substring '-p "[sudo via ansible, key=' is present in the resulting command
    # string. The key is randomly generated by the BecomeBase class and therefore not deterministic to test. We
    # only want to test for the existence of the substring, and not for the specific string.
    #
    # NOTE: Removing this case as it is not deterministic, as the key is

# Generated at 2022-06-11 13:22:51.525401
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.become import BecomeBase
    from ansible.plugins.loader import become_loader

    class Dummy_become_loader(object):
        def get(self, name, *args, **kwargs):
            class Dummy_super(object):
                pass
            obj = Dummy_super()
            obj._id = '1234'
            obj.get_option = lambda x: None
            obj._build_success_command = lambda x, y: 'succeeded'
            return obj

    become_loader.get = Dummy_become_loader().get

    become = become_loader.get('sudo', '', {}, {}, {})
    assert become.build_become_command('whoami', '') == 'sudo -p "[sudo via ansible, key=1234] password:" succeeded'

   

# Generated at 2022-06-11 13:23:00.399986
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible import constants
    from ansible.utils.encrypt import get_diffiehellman
    from six import StringIO
    from collections import namedtuple

    constants.DEFAULT_HASHED_DIFFIE_HELLMAN_GROUP = 2
    constants.DEFAULT_HASHED_DIFFIE_HELLMAN_KEY_LENGTH = 2048
    dh = get_diffiehellman()
    keys = namedtuple('ApiKeys', ['shared','private','public'])
    keys.private = dh.gen_private_key().private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption())

# Generated at 2022-06-11 13:23:09.708406
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.prompt = '[sudo via ansible, key=ANSIBLE_TESTING] password:'
    become._id = "ANSIBLE_TESTING"

    assert become._build_success_command('somecommand', '/bin/bash') == '''bash -c "echo SUDO-SUCCESS-ANSIBLE_TESTING; somecommand"'''
    assert become.build_become_command('somecommand', '/bin/bash') == '''[sudo via ansible, key=ANSIBLE_TESTING] password: sudo -S -p "[sudo via ansible, key=ANSIBLE_TESTING] password:" bash -c "echo SUDO-SUCCESS-ANSIBLE_TESTING; somecommand"'''

    become.prompt = ''

# Generated at 2022-06-11 13:23:14.736867
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # arrange
    becomemodule = BecomeModule('tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp', 'tcp')
    cmd = 'ls'
    shell = 'tcp'

    # act
    result = becomemodule.build_become_command(cmd, shell)

    # assert
    assert result == 'sudo -n ls'



# Generated at 2022-06-11 13:23:23.458442
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    # method called with shell being "sh"
    become_module_sh = BecomeModule(
        become_method='sudo',
        become_user='user',
        become_exe='become_exe',
        become_flags='become_flags',
        become_pass='become_pass',
        prompt='prompt',
        become_prompt='become_prompt',
        _success_cmd='success_cmd',
        _success_msg='success_msg',
        _fail_cmd='fail_cmd',
        _fail_msg='fail_msg',
        _missing_cmd='missing_cmd',
        _missing_msg='missing_msg',
        become_output='become_output',
        become_method_user='become_method_user',
        prompt_re='prompt_re'
    )

    sh

# Generated at 2022-06-11 13:23:31.723217
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    shell = {'SHELL': '/bin/sh', 'JAVA_HOME': '/jdk1.8.0_25/jre'}
    become_pass = 'dummypass123'

    # Test empty cmd
    cmd = None
    expected = ''
    become = BecomeModule()
    assert become.build_become_command(cmd, shell) == expected

    # Test simple command
    cmd = 'ls -l'
    expected = cmd
    become = BecomeModule()
    assert become.build_become_command(cmd, shell) == expected

    # Test simple command with become option
    become = BecomeModule()
    become.set_options(become_pass=become_pass, become_user=None, become_exe=None, become_flags=None)
    cmd = 'ls -l'

# Generated at 2022-06-11 13:23:39.503202
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    def create_options(become_exe=None, become_flags=None, become_user=None, become_pass=None):
        options = {
            'become_exe': become_exe,
            'become_flags': become_flags,
            'become_user': become_user,
            'become_pass': become_pass
        }
        return options

    # Test options:
    #    become_exe:   sudo
    #    become_flags: -H -S -n
    #    become_user:  root
    #    become_pass:  pass1
    options = create_options(become_pass="pass1")
    bm = BecomeModule(create_task(options), create_connection(options))
    cmd = "id -u"
    becomecmd = bm.build_become_

# Generated at 2022-06-11 13:23:46.725443
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # SETUP
    mod = BecomeModule()

    # VERIFY
    # -n flag when no become_pass and no user specified
    cmd = "/bin/sh -c 'echo i am user'"
    become_cmd = mod.build_become_command(cmd, True)
    assert become_cmd == 'sudo -H -S -n /bin/sh -c \'echo i am user\''

    # -n flag when become_pass and no user specified
    mod.get_option = lambda x: '123' if x == 'become_pass' else None
    become_cmd = mod.build_become_command(cmd, True)
    assert become_cmd == 'sudo -H -S -p "[sudo via ansible, key=become_plugin_%s] password:" /bin/sh -c \'echo i am user\''

# Generated at 2022-06-11 13:23:53.030659
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.become import cloexec_pass_fds

    b = BecomeModule()
    assert b

    b.get_option = lambda x: None
    b.prompt = ''

    # test no input
    cmd = b.build_become_command(None, False)
    assert cmd == None

    # test become_pass set, flags -n
    b.get_option = lambda x: ''
    b.get_option.side_effect = {'become_user': '', 'become_pass': '', 'become_flags': '-n'}.get
    cmd = b.build_become_command('ls', False)
    assert cmd == 'sudo -H -S -p "Sorry, a password is required to run sudo"  ls'

# Generated at 2022-06-11 13:23:59.185551
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bc = BecomeModule({},{})
    bc.prompt = ''
    bc.get_option = lambda c: None
    # assert on simple string
    assert bc.build_become_command('123','') == '123'

    assert bc.build_become_command('ansible','') == 'ansible'
    assert bc.build_become_command(['sudo','ansible'],'') == 'sudo ansible'

    # assert on list of string
    assert bc.build_become_command(['sudo','ansible'],'') == 'sudo ansible'
    assert bc.build_become_command(['sudo','ansible'],'') == 'sudo ansible'

# Generated at 2022-06-11 13:24:38.901215
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    assert become.build_become_command('/bin/foo', shell='/bin/bash') == '/bin/foo'
    assert become.build_become_command(None, None) is None

    become.set_options(become_flags='-foo')
    assert become.build_become_command('/bin/foo', shell='/bin/bash') == '/usr/bin/sudo -foo /bin/bash -c \'/bin/foo\''

    become.set_options(become_user='foo')
    assert become.build_become_command('/bin/foo', shell='/bin/bash') == '/usr/bin/sudo -foo -u foo /bin/bash -c \'/bin/foo\''

    become.set_options(become_pass='foo')
    become._

# Generated at 2022-06-11 13:24:46.943852
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    host_vars = {}
    new_stdin = ''
    become_exe = 'sudo'
    become_flags = '-H -S -n'
    become_user = 'root'
    become_pass = None
    prompt = '[sudo via ansible, key=%s] password:'
    cmd = 'echo test'
    # Init BecomeModule class
    sudo = BecomeModule()
    sudo._id = '6cb0fe6e-cb6b729ce3c3'
    # Test sudo command with become_pass
    become_pass = 'mypassword'
    new_cmd, new_stdin = sudo._build_success_command(cmd, 'sh')
    new_become_cmd = sudo.build_become_command(new_cmd, 'sh')

# Generated at 2022-06-11 13:24:56.211576
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_instance = BecomeModule()
    cmd = "/usr/bin/python -c 'print(\"hello\")'"
    shell = "/usr/bin/python"
    become_instance.set_option('become_exe', 'sudo')
    become_instance.set_option('become_flags', '-H -S')
    become_instance.set_option('become_user', 'root')


# Generated at 2022-06-11 13:25:04.888650
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    bm = BecomeModule()
    bm.prompt = 'password:'

    assert bm.build_become_command("", "sh") == "sudo"
    assert bm.build_become_command("", "sh") == "sudo"

    bm.set_options({'become_user': 'test'})
    assert bm.build_become_command("", "sh") == "sudo -u test"
    assert bm.build_become_command("", "sh") == "sudo -u test"

    bm.set_options({'become_exe': 'sudox'})
    assert bm.build_become_command("", "sh") == "sudox -u test"

# Generated at 2022-06-11 13:25:12.401600
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.module_utils._text import to_text
    import pytest

    become_option = {
        'become_exe': None,
        'become_flags': '',
        'become_pass': None,
        'become_user': 'root',
    }

    # test signature
    become_instance = BecomeModule(become_option)

    # test simple case
    cmd = become_instance.build_become_command(['whoami'], False)
    assert cmd == "sudo -u root -H -S -n echo ~root && whoami"

    # test with pass
    become_instance.set_options({'become_pass': 'testpass'})
    cmd = become_instance.build_become_command(['whoami'], False)