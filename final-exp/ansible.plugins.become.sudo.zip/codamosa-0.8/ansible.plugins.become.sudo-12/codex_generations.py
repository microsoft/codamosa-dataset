

# Generated at 2022-06-11 13:15:26.000560
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    class_init = BecomeModule('')
    
    assert class_init._build_success_command('ls', '/bin/sh') == 'ls && echo BECOME-SUCCESS-hjuyywer'
    assert class_init.build_become_command('ls', '/bin/sh') == 'sudo -H -S ls && echo BECOME-SUCCESS-hjuyywer'

    class_init.prompt = '[sudo via ansible, key=hjuyywer] password:'
    assert class_init.build_become_command('ls', '/bin/sh') == 'sudo -H -S -p "[sudo via ansible, key=hjuyywer] password:" ls && echo BECOME-SUCCESS-hjuyywer'

# Generated at 2022-06-11 13:15:37.189030
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    becomecmd = 'sudo'
    flags = '-H -S -n'
    prompt = ''
    user = '-u %s' % ('root')
    bcmd_flags = ' '.join([becomecmd, flags, prompt, user])
    bcmd1 = ' '.join([bcmd_flags, 'bash -c "id; ANSIBLE_PRIVATE_DATA=XXdebugxx /bin/sh -c \'echo BECOME-SUCCESS-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX >> /dev/null\'"'])


# Generated at 2022-06-11 13:15:47.747428
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Note: in the test below, we must always use "self.get_option"
    # and not "self._play_context.become_options[option]"
    # because the latter will not work on a "BecomeModule" object.

    become = BecomeModule(None, {})

    become.set_options(dict(become_exe="sudo",
                            become_flags='-H -S -n',
                            become_pass=False))

    (cmd, prompt) = become.build_become_command('some command', 'some shell')

    assert cmd == "sudo -H -S -n some command"
    assert prompt == ""

    become.set_options(dict(become_exe="sudo",
                            become_flags='-H -S',
                            become_pass=True))
    (cmd, prompt)

# Generated at 2022-06-11 13:15:58.279149
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # given
    become_module = BecomeModule()

    become_module.prompt = "[sudo via ansible, key=4321] password:"
    become_module._id = "4321"
    become_module.get_option = lambda v: None

    # when
    cmd = "/bin/ls -l"
    result = become_module._build_success_command(cmd, "/bin/sh")

    # then

# Generated at 2022-06-11 13:16:06.513829
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    options = {'become_user': 'testuser'}
    become.set_options(var_options=options)
    cmd = become.build_become_command('echo hello world', shell='/bin/bash')
    assert cmd == '/bin/bash -c echo hello world'

    options = {'become_user': 'testuser', 'become_pass': 'testpass'}
    become.set_options(var_options=options)
    cmd = become.build_become_command('echo hello world', shell='/bin/bash')
    assert cmd == 'sudo -S -p "[sudo via ansible, key=%s] password:" -u testuser /bin/bash -c echo hello world' % become._id


# Generated at 2022-06-11 13:16:16.435360
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    plugin = BecomeModule()
    cmd = 'echo "test"'
    shell = '/bin/bash'

    # Test with all options set to root and return as expected
    plugin.set_option('become_exe', '/usr/bin/sudo')    
    plugin.set_option('become_flags', '-H -S -n')
    plugin.set_option('become_user', 'root')
    plugin.set_option('become_pass', None)
    result = plugin.build_become_command(cmd, shell)
    assert result == '/usr/bin/sudo -H -S -n echo "test"', "BecomeModule Test result expected: '/usr/bin/sudo -H -S -n echo \"test\"', get: " + result + " instead."

    # Test with all options set to some user, become_pass

# Generated at 2022-06-11 13:16:26.336985
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    m = BecomeModule()
    assert m.build_become_command('yum update', 'mksh') == "sudo -H -S -n mksh -c 'yum update'"
    assert m.build_become_command('yum update', 'sh') == "sudo -H -S -n sh -c 'yum update'"
    assert m.build_become_command('yum update', 'csh') == "sudo -H -S -n csh -c 'yum update'"
    assert m.build_become_command('yum update', 'python') == "sudo -H -S -n python -c 'yum update'"
    assert m.build_become_command('yum update', None) == "sudo -H -S -n yum update"

# Generated at 2022-06-11 13:16:36.704679
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module._id = 'abc123'
    become_module.get_option = lambda option: None

    assert become_module.build_become_command('xyz', shell=False) == 'sudo -H -S -n xyz'
    assert become_module.build_become_command('xyz', shell=True) == 'sudo -H -S -n sh -c "xyz"'

    become_module.get_option = lambda option: 'sudo' if option == 'become_exe' else None
    assert become_module.build_become_command('xyz', shell=False) == 'sudo -H -S -n xyz'

# Generated at 2022-06-11 13:16:47.046341
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = None
    become_module.get_option = lambda option: None
    become_module.get_option = lambda option, default: default
    become_module._build_success_command = lambda cmd, shell: cmd
    become_module.options = dict()
    become_module.options['_ansible_shell_executable'] = '/bin/sh'
    cmd = 'ls -l /'

    # Test with a no option set
    assert become_module.build_become_command(cmd, False) == cmd

    # Test with become_pass option set
    become_module.options['become_pass'] = 'mypassword'
    become_module.options['become_user'] = 'myuser'

# Generated at 2022-06-11 13:16:51.355819
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become_exe = '/usr/bin/sudo'
    become_flags = '-H -S -n'
    become_user = 'root'
    become_pass = 'password'

    shell = '/bin/bash -c'
    cmd = 'ls -l'


# Generated at 2022-06-11 13:17:03.812248
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.become import BecomeBase
    from unittest.mock import patch
    from .fixtures.base_plugin_fixture import get_plugin_fixture
    from .fixtures.become_fixture import (get_become_base_fixture, get_become_module_fixture)

    # We need to mock BecomeBase method _id to return a fixed string
    # for reproducible test.
    #
    # We need to mock BecomeBase method _build_success_command to
    # return a fixed string for reproducible test.
    #
    # We need to mock BecomeBase method get_option to return a fixed
    # string for reproducible test.

# Generated at 2022-06-11 13:17:09.524212
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()
    become_module.prompt = '[sudo via ansible, key=xxx] password:'
    become_module._id = 'xxx'

    result = become_module.build_become_command('/bin/bash', '/bin/sh')
    assert result == 'sudo -p "[sudo via ansible, key=xxx] password:" /bin/bash && echo BECOME-SUCCESS-xxx'

# Generated at 2022-06-11 13:17:17.860401
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule(dict())
    cmd = "ls -l"
    shell = "/bin/sh"
    assert ' '.join(b.build_become_command(cmd, shell)) == "sudo -H -S -n /bin/sh -c 'echo BECOME-SUCCESS-ajndlqrnqhxqgqwiyialeoqllmhikcdl; %s'" % cmd
    assert b.prompt == '[sudo via ansible, key=ajndlqrnqhxqgqwiyialeoqllmhikcdl] password:'
    cmd = "whoami"

# Generated at 2022-06-11 13:17:28.494358
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule()
    module.get_option = lambda x: {'become_exe': 'sudo', 'become_flags': '', 'become_pass': '', 'become_user': ''}[x]

    assert module.build_become_command('echo $TERM', False) == 'sudo -p "[sudo via ansible, key=] password:" -u  echo $TERM'
    assert module.build_become_command('echo $TERM', True) == 'sudo -p "[sudo via ansible, key=] password:" -u  echo \'$TERM\''

    module.get_option = lambda x: {'become_exe': 'sudo', 'become_flags': '-H -S -n', 'become_pass': '', 'become_user': ''}[x]

# Generated at 2022-06-11 13:17:38.986346
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module = BecomeModule(None)
    module.prompt = None
    module.get_option = lambda option: None
    module._build_success_command.return_value = '<cmd>'

    module.build_become_command('', 'shell')
    assert module._build_success_command.call_count == 1
    assert module.get_option.call_count == 0
    assert module.prompt is None
    assert module.cmd == '<cmd>'

    module.build_become_command('', 'foo')
    assert module._build_success_command.call_count == 2
    assert module.get_option.call_count == 0
    assert module.prompt is None
    assert module.cmd == '<cmd>'

    module.get_option.return_value = 'sudo'
    module.build

# Generated at 2022-06-11 13:17:47.441113
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # This program requires sudo access as root to be of any use
    c = BecomeModule(None, {}, become_method='sudo', become_user='root')
    assert c.build_become_command('echo hello') == 'sudo -H -S -n -u root "echo hello"'

    # This program requires sudo access as root to be of any use
    c = BecomeModule(None, {}, become_method='sudo', become_user='root', become_pass='hunter2')
    assert c.build_become_command('echo hello') == 'sudo -H -S -p "[sudo via ansible, key=<NOSECRET>] password:" -u root "echo hello"'

# Generated at 2022-06-11 13:17:58.671697
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    b = BecomeModule()
    b.prompt = 'test'
    cmd = "echo '123'"
    shell = '/bin/sh'
    become_exe = 'sudo'
    become_flags = ''
    become_user = ''
    become_pass = 'test'
    id = '1234567890'
    expected_result = "sudo -p \"%s\" -u %s '%s'" % (b.prompt, become_user, cmd)
    b.get_option = lambda x: vars()[x]
    assert expected_result == b.build_become_command(cmd, shell)

    become_exe = 'sudo'
    become_flags = ''
    become_user = 'test'
    become_pass = ''
    id = '1234567890'

# Generated at 2022-06-11 13:18:06.428765
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    import sys
    import os
    import tempfile
    from ansible.executor.task_result import TaskResult
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.plugins.become import BecomeModule
    ###########################################################################
    # Given:
    command = '/usr/local/bin/ansible -m systemd -a "name=foo state=started"'

# Generated at 2022-06-11 13:18:19.020599
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    test_obj = BecomeModule()
    cmd = 'ls'
    test_obj.get_option = lambda x: None
    assert cmd == test_obj.build_become_command(cmd, 'shell')

    test_obj.get_option = lambda x: 'sudo'
    assert cmd == test_obj.build_become_command(cmd, 'shell')

    test_obj.get_option = lambda x: 'sudo -H -S -n'
    assert cmd == test_obj.build_become_command(cmd, 'shell')

    test_obj.get_option = lambda x: 'sudo2'
    assert cmd == test_obj.build_become_command(cmd, 'shell')

    test_obj.get_option = lambda x: ''

# Generated at 2022-06-11 13:18:27.989632
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule(None)
    become_module._id = 'test_id'
    become_module.prompt = '[sudo via ansible, key=test_id] password:'

    # test with only required options
    become_module.get_option = lambda option: None
    cmd_result = become_module.build_become_command("echo 'test'", 'shell')
    cmd_expected = 'sudo -H -S -n -p "{prompt}" echo \'test\''.format(prompt=become_module.prompt)
    assert cmd_result == cmd_expected, "  Expected: {expected}\n Got:{result}".format(expected=cmd_expected, result=cmd_result)
    print("test_BecomeModule_build_become_command() passed!")

    # test with become_user


# Generated at 2022-06-11 13:18:40.440220
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test the build_become_command method of the class SudoModule
    #
    # With the following inputs there should be the following outputs:
    #
    # Inputs:
    #   self - The object instance of the class BecomeModule
    #   cmd - The command to be executed
    #   shell None
    #
    # Outputs:
    #   The command as a string that will be executed by the class
    #   BecomeBase

    # Create a new instance of the class SudoModule
    testcase = BecomeModule(play_context=dict(become_user='sudo_user'), check_mode=False)

    # Set the AnsibleModule object of the class SudoModule instance
    testcase.get_option = lambda x: None

    # Create the actual inputs for the build_become_command method

# Generated at 2022-06-11 13:18:51.884097
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Create test object with some attributes set
    test_become_module = BecomeModule()
    test_become_module.prompt = 'test_prompt'
    test_become_module._id = 'testid'
    test_become_module._build_success_command = lambda x, y: 'success_command'

    # Test
    test_become_pass = False
    test_become_user = 'testuser'
    test_become_flags = '-H -S -n'
    test_become_exe = 'sudo'
    test_cmd = 'test_cmd'
    result = test_become_module.build_become_command(test_cmd, False)
    assert result == test_become_exe + ' -H -S -n' + ' "success_command"'
   

# Generated at 2022-06-11 13:19:00.530852
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    from ansible.plugins.loader import become_loader
    plugin = become_loader.get('sudo', class_only=True)()

    plugin.prompt = None
    plugin.get_option = lambda k: None
    plugin._id = '111111'
    shell = '/bin/sh'

    # No options
    result = plugin.build_become_command('ls', shell)
    assert result == 'sudo -H -S -n /bin/sh -c \'(echo %s; echo %s) | %s -S && %s\'' % (
        plugin._success_key,
        plugin._success_key,
        plugin.name,
        'ls'
    )

    # No become user
    plugin.get_option = lambda k: 'sudo' if k == 'become_exe' else None
    result = plugin

# Generated at 2022-06-11 13:19:10.737761
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Test with default value for become_flags
    res = BecomeModule('sudo', become_pass=None).build_become_command(['some', 'command'], 'shell')
    assert res == "sudo -H -S -n some command"

    res = BecomeModule('sudo', become_pass=None).build_become_command(['some', 'command'], 'command')
    assert res == "sudo -H -S -n some command"

    res = BecomeModule('sudo', become_pass=None).build_become_command(['some', 'command'], 'powershell')
    assert res == "sudo -H -S -n some command"

    res = BecomeModule('sudo', become_pass=None).build_become_command(['some', 'command'], 'ps')

# Generated at 2022-06-11 13:19:19.046707
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(
        task_uuid='0e7c1ae9',
        become_pass='MyPass',
        become_user='admin',
        become_exe='/usr/bin/sudo',
        become_flags='-H -S -n',
        become_pass_prompt='sudo password'
    )
    assert become.build_become_command('/bin/ls', False) == '/usr/bin/sudo -H -S -p "sudo password" -u admin /bin/ls'
    assert become.build_become_command('/bin/ls', True) == '/usr/bin/sudo -H -S -p "sudo password" -u admin "/bin/sh -c \'LC_ALL=C /bin/ls\'"'

# Generated at 2022-06-11 13:19:24.309383
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():

    class Args(object):
        def __init__(self, exe='/usr/bin/sudo', flags='-H -S -n', pass_prompt=''):
            self.become_exe = exe
            self.become_flags = flags
            self.become_pass = pass_prompt

    sudo_opt = {
        'become_exe': Args(exe='/usr/bin/sudo'),
        'become_flags': Args(flags='-H -S -n'),
        'become_pass': Args(pass_prompt='mypassword'),
        'become_user': Args(pass_prompt='myuser'),
    }

    def get_option(self, option):
        return sudo_opt[option]

    sudo_mod = BecomeModule()

# Generated at 2022-06-11 13:19:33.334050
# Unit test for method build_become_command of class BecomeModule

# Generated at 2022-06-11 13:19:42.501829
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    becomecmd = 'sudo'
    flags = '-H -S -n'
    prompt = '-p "[sudo via ansible, key=7a9c38] password:"'
    user = '-u jdoe'
    cmd = 'ACTUAL_COMMAND_GOES_HERE'
    shell = '/bin/sh'
    expected = ' '.join([becomecmd, flags, prompt, user, 'sh -c \'%s\'' % cmd])

    become = BecomeModule()
    become._id = '7a9c38'
    become.prompt = '[sudo via ansible, key=7a9c38] password:'
    become.get_option = lambda x: prompt if x == 'become_pass' else flags

# Generated at 2022-06-11 13:19:51.183924
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_pass = ''
    become_user = ''
    become_exe = ''
    become_flags = ''
    cmd = 'echo hi'
    result = 'sudo  -S -n  /bin/sh -c \'echo hi\''
    become = BecomeModule(remote_user='root', become_pass=become_pass, become_user=become_user, become_exe=become_exe, become_flags=become_flags)
    assert(become.build_become_command(cmd, '/bin/sh') == result)

    become_pass = 'secret'
    become_exe = 'sudo'
    become_flags = '-H -S -n'
    cmd = 'echo hi'

# Generated at 2022-06-11 13:19:59.806776
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    def assertEqual(a,b):
        if a != b:
            raise Exception("%s != %s"%(a,b))

    bm = BecomeModule()
    
    bm.get_option = lambda x : None
    bm._build_success_command = lambda x,y : x
    bm._id = '123123123123'
    bm.prompt = ''

    commands = [
        'ls -l',
        '/usr/bin/python -c "import os; print os.getcwd()"',
    ]

    for cmd in commands:
        assertEqual(bm.build_become_command(cmd, ''), cmd)

    bm.get_option = lambda x : (x == 'become_user' and 'foo') or None

# Generated at 2022-06-11 13:20:17.800234
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(None, {}, {}, None, None)

    become.get_option = lambda option: ''

    cmd = become.build_become_command('/usr/bin/id', False)

    assert cmd == 'sudo -H -S -n /bin/sh -c \'echo BECOME-SUCCESS-xvnzhwtkcriemmzdqgwpivkvztcklm; /usr/bin/id\' || echo \'Error in sudo test.\''


# Generated at 2022-06-11 13:20:26.898945
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(become_pass=None)
    command = '/bin/foo'
    command_with_prompt = '"/bin/foo"'
    shell = '/bin/bash'

    # user, no prompt, no flags
    cmd = become.build_become_command(command, shell)
    assert cmd == 'sudo -u foo /bin/bash -c ' + command_with_prompt
    become.set_options(become_flags='')

    # user, no prompt, explicit no flags
    cmd = become.build_become_command(command, shell)
    assert cmd == 'sudo -u foo /bin/bash -c ' + command_with_prompt
    become.set_options(become_flags='-n')

    # user, no prompt, no -n flags

# Generated at 2022-06-11 13:20:36.485183
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule(None, {}, 'a_request_id')

    # Command is build correctly with default values
    cmd = '/bin/foo'
    shell = '/bin/sh'
    become.get_option = lambda x: None
    result = become._build_success_command(cmd, shell)
    if result != '/bin/sh -c \'/bin/foo\'':
        raise AssertionError('Expected: /bin/sh -c \'/bin/foo\', got %s' % result)

    # The command is build correctly with no arguments
    cmd = None
    result = become._build_success_command(cmd, shell)
    if result != '':
        raise AssertionError('Expected: \'\', got %s' % result)

    # The command is build correctly when the user is not root and there

# Generated at 2022-06-11 13:20:46.535104
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    # Setup
    become = BecomeModule(
        become_method='sudo',
        become_exe=None,
        become_pass=None,
        become_user=None,
        become_flags=None,
        become_exe_args='',
        )
    become.set_options(
        direct={'become': {'become_method': 'sudo', 'become_exe': None, 'become_pass': None, 'become_user': None, 'become_flags': None, 'become_exe_args': ''}},
        variable_manager=None,
        loader=None,
        )

    # Test 1
    input_cmd = 'echo Hello World'
    input_shell = '/bin/sh'
    actual = become.build_become_command(input_cmd, input_shell)
    expected

# Generated at 2022-06-11 13:20:51.390266
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()

    cmd = 'ls'
    shell = '/bin/zsh'

    # become_exe not defined
    become._options = {
        'become_user': 'root',
        'become_pass': '123',
        'become_flags': '-H -S -n',
        'become_exe': None,
    }
    become.prompt = ''
    become._id = 'mykey'
    cmd_actual = become.build_become_command(cmd, shell)
    assert cmd_actual == 'sudo -H -S -p "[sudo via ansible, key=mykey] password:" -u root "/bin/zsh -c \'ls && sleep 0\'"'
    assert become.prompt == '[sudo via ansible, key=mykey] password:'

    # become_flags

# Generated at 2022-06-11 13:20:56.883571
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    module_test = BecomeModule(None, {}, {}, ['/bin/sh', '-c', 'test'])
    assert module_test.build_become_command('test', None) == 'sudo -H -S -n test'
    module_test.prompt = 'test'
    assert module_test.build_become_command(None, None).split() == ['sudo', '-H', '-S', '-p', '"test"', 'test']

# Generated at 2022-06-11 13:21:06.895571
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # Test for "become_exe" option and "become_user" option
    become_module.set_options(become_user='ansible', become_pass='example', become_exe='/usr/bin/sudo', become_flags=None)
    assert become_module.build_become_command('/usr/bin/whoami', '') == 'exec /usr/bin/sudo -H -S -u ansible /usr/bin/whoami'
    assert become_module.prompt == r'[sudo via ansible, key=\d+] password:'

    # Test for "prompt" option
    become_module.set_options(become_user='ansible', become_pass='example', become_exe='/usr/bin/sudo', become_flags=None)
    assert become

# Generated at 2022-06-11 13:21:15.614777
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become = BecomeModule()
    become.get_option = lambda x: None

    # Check basics
    assert become.build_become_command('whoami', None) == 'sudo -H -S -n whoami'
    become.get_option = lambda x: 'foo'
    assert become.build_become_command('whoami', None) == 'sudo foo whoami'
    become.get_option = lambda x: '-E'
    assert become.build_become_command('whoami', None) == 'sudo -E -H -S -n whoami'
    become.get_option = lambda x: '-E -U'
    assert become.build_become_command('whoami', None) == 'sudo -E -U -H -S -n whoami'

    # Check user option
    become.get_option

# Generated at 2022-06-11 13:21:24.500684
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    become_module = BecomeModule()

    # case 1: Build command, no cmd, no shell
    cmd = None
    shell = None
    result = become_module._build_success_command(cmd, shell)
    assert(result == '')

    # case 2: Build command, cmd is not None, shell is None
    cmd = 'ls'
    shell = None
    result = become_module._build_success_command(cmd, shell)
    assert(result == 'true')

    # case 3: Build command, cmd is not None, shell is Bourne-like shell (e.g. sh, bash)
    cmd = 'ls'
    shell = 'sh'
    result = become_module._build_success_command(cmd, shell)
    assert(result == 'true')

    # case 4: Build command, cmd is not None,

# Generated at 2022-06-11 13:21:32.748811
# Unit test for method build_become_command of class BecomeModule
def test_BecomeModule_build_become_command():
    """Unit test for method build_become_command of class BecomeModule"""
    ansible_module = BecomeModule()
    ansible_module._id = 'test_id'
    ansible_module.prompt = 'test_prompt'
    ansible_module.get_option = lambda key: None
    ansible_module._build_success_command = lambda cmd, shell: cmd
    assert ansible_module.build_become_command('test_cmd', 'test_shell') == 'sudo -H -S test_cmd'
    ansible_module.get_option = lambda key: 'test_become_user' if key == 'become_user' else None