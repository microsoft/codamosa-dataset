

# Generated at 2022-06-22 18:12:31.358197
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading

    ##### Tests for line 37 #################
    #
    # Check that function @pysnooper.snoop() is disabled at line 36 if
    # pysnooper.DISABLED == True
    if True:
        def test():
            assert pysnooper.snoop() == pysnooper.snoop
        class MyClass:
            pass
        assert pysnooper.snoop() == test
        assert pysnooper.snoop() == MyClass
        pysnooper.DISABLED = True
        assert pysnooper.snoop() == test
        assert pysnooper.snoop() == MyClass
        pysnooper.DISABLED = False
        assert p

# Generated at 2022-06-22 18:12:35.174077
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False) as sut:
        print('hi')

# Generated at 2022-06-22 18:12:36.759421
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:12:44.291377
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False) is not None
    assert get_write_function(lambda s: s, False) is not None
    assert get_write_function(utils.WritableStream(), False) is not None
    assert get_write_function('', False) is not None

    with pycompat.open_file('test_get_write_function.txt', 'w') as f:
        assert get_write_function(f, False) is not None



# Generated at 2022-06-22 18:12:49.356384
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from . import output
    from .output import make_unicode_write_function
    from .utils import temp_file

    with temp_file() as t:
        write = make_unicode_write_function(output.FileWriter(t, True))
        assert (write('This is a\n') is None)
        assert (t.read() == 'This is a\n')

        write('This is a 2\n')
        assert (t.read() == 'This is a 2\n')

        write('This is a 3\n')
        assert (t.read() == 'This is a 3\n')



# Generated at 2022-06-22 18:12:54.010081
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = pycompat.StringIO()
    trace = Tracer(output)
    trace.write("Hello swaroop")
    assert output.getvalue() == "Hello swaroop\n"


# Generated at 2022-06-22 18:13:05.812322
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    from pytest import raises
    from . import utils_overwrite as utils
    from .utils import SniffIO
    from . import pysnooper

    with SniffIO() as sniffio:
        with pysnooper.SnoopIO(0) as s:
            with raises(ValueError) as exc_info:
                print('hello', file=s)
                raise ValueError('world')


# Generated at 2022-06-22 18:13:12.223821
# Unit test for constructor of class Tracer
def test_Tracer():
    # output=None
    # watch=(), watch_explode=(), depth=1
    # prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False
    output = ''
    watch = ['foo']
    watch_explode = ['self', 'foo']
    depth = 2
    prefix = '@@@'
    overwrite = True
    thread_info = True
    custom_repr = [('foo', 'bar'), ('self', 'test')]
    max_variable_length = 199
    normalize = True
    relative_time = True


# Generated at 2022-06-22 18:13:22.791175
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from unittest import mock
    from pysnooper.pysnooper import GetWriteFunction, Tracer
    from pysnooper.pysnooper import DISABLED
    from pysnooper.utils import ensure_tuple, get_path_and_source_from_frame
    from pysnooper.variables import CommonVariable, Exploding
    import inspect
    import collections.abc
    import builtins
    import functools
    import threading
    import datetime
    import sys
    import pycompat
    import collections.abc
    import os

    class mock_frame:
        def __init__(self):
            self._f_code = None
            self._f_lineno = None
            self._f_trace = None
            self._f_back = None

# Generated at 2022-06-22 18:13:24.438595
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:27.031394
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:29.013899
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert list(UnavailableSource()) == [u'SOURCE IS UNAVAILABLE']

# Generated at 2022-06-22 18:13:32.636696
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    obj = Tracer('output')
    assert obj.__exit__(1, 2, 3) == None
    assert obj.__exit__(1, None, 3) == None

# Generated at 2022-06-22 18:13:40.695512
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path1 = pycompat.text_type(utils.temp_file_path + '1')
    path2 = pycompat.text_type(utils.temp_file_path + '2')

    with open(path1, 'w') as f:
        f.write('hey!')
    with open(path2, 'w') as f:
        f.write('what?')

    file_writer = FileWriter(path1, overwrite=True)
    file_writer.write('hi\n')

    with open(path1) as f:
        assert f.read() == 'hi\n'  # tested

    file_writer.write('yo\n')

    with open(path1) as f:
        assert f.read() == 'hi\nyo\n'  # tested

    file_writer2 = FileWriter

# Generated at 2022-06-22 18:13:52.752221
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    import sys
    import types
    import unittest
    import unittest.mock
    import contextlib
    # Copied from https://github.com/cool-RR/pysnooper/blob/0c9b8a8d9a9e08d0a18a0ed8cc2f633d0d84e1f3/test_parts/test_snoop.py#L38-L53.

# Generated at 2022-06-22 18:13:55.794514
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write("\n hello world")
    tracer.write("\n hello world")
    tracer.write("\n hello world")

# Generated at 2022-06-22 18:13:57.993349
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    import sys
    import re
    UnavailableSource().__getitem__(0)



# Generated at 2022-06-22 18:13:59.809715
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    o = Tracer()
    assert isinstance(o, Tracer)



# Generated at 2022-06-22 18:14:02.399320
# Unit test for constructor of class Tracer
def test_Tracer():
    from pysnooper import snoop
    def foo():
        print('foo')
    bar = snoop()(foo)
    bar()


# Generated at 2022-06-22 18:14:08.819588
# Unit test for constructor of class FileWriter
def test_FileWriter():
    output_file_path = 'testing_output_file.txt'
    s = 'Testing'
    write = FileWriter(output_file_path, overwrite=True)
    write(s)
    with open(output_file_path, 'r') as f:
        assert s == f.read()

    # check that successive writes append instead of overwriting
    s2 = 'Appended text'
    write(s2)
    with open(output_file_path, 'r') as f:
        assert s + s2 == f.read()
    os.remove(output_file_path)



# Generated at 2022-06-22 18:14:16.564141
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    from .pycompat import StringIO

    f = StringIO()
    assert get_write_function(f, False) == f.write
    f = StringIO()
    assert get_write_function(f.write, False) == f.write
    f = StringIO()
    assert get_write_function(f.write, True) == f.write
    f = StringIO()

# Generated at 2022-06-22 18:14:22.826938
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t = Tracer(thread_info=True)
    assert t.set_thread_info_padding('123-a') == '123-a   '
    assert t.set_thread_info_padding('1234-aa') == '1234-aa '
    assert t.set_thread_info_padding('123-a') == '123-a   '


# Generated at 2022-06-22 18:14:25.485232
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # No arguments, no returned value
    tracer = pysnooper.snoop()
    with tracer:
        pass


# Generated at 2022-06-22 18:14:30.923583
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()

if sys.version_info >= (3, 8):
    def get_frame_source(frame_or_code):
        return frame_or_code.f_code.co_code
else:
    def get_frame_source(frame_or_code):
        code = frame_or_code.f_code
        try:
            return code.co_filename, code.co_firstlineno, code.co_code
        except AttributeError:
            return UnavailableSource()



# Generated at 2022-06-22 18:14:36.958627
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # call case
    import types
    import sys
    class SomeClass(object):
        def __init__(self):
            self.a = 3

        def some_method(self):
            self.a = 3
    def some_method():
        pass
    def some_generator_method():
        r = yield None
    def some_coroutine_method():
        yield None
    def some_async_generator_method():
        await None
        yield None
    def snoop(*args, **kwargs):
        pass
    def explosion():
        pass
    def snoop_gen(*args, **kwargs):
        yield None
    def explosion_gen():
        yield None
    def snoop_coro(*args, **kwargs):
        yield None
    def explosion_coro():
        yield None

# Generated at 2022-06-22 18:14:41.497502
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import contextlib
    with contextlib.ExitStack() as stack:
        temp = stack.enter_context(tempfile.NamedTemporaryFile())
        temp.write(b'j')
        temp.seek(0)

        writer = FileWriter(temp.name, True)
        writer.write(u'a')
        writer.overwrite = False
        writer.write(u'b')
        with open(temp.name, 'rb') as f:
            assert f.read() == 'ab'.encode()
        writer.write(u'c')
        writer.write(u'd')
        with open(temp.name, 'rb') as f:
            assert f.read() == 'abcd'.encode()

# Generated at 2022-06-22 18:14:50.945656
# Unit test for method write of class Tracer
def test_Tracer_write():
    import tempfile
    test_Tracer = Tracer()
    try:
        with tempfile.TemporaryDirectory() as temp_dir:
            test_Tracer._write = open(os.path.join(temp_dir,'temp.txt'), "w")
            test_Tracer.write("Hola")
            test_Tracer.write("Adios")
            with open(os.path.join(temp_dir,'temp.txt'), "r") as f:
                for line in f:
                    assert line == "Hola\n" or line == "Adios\n"
    except:
        raise

# Generated at 2022-06-22 18:14:59.306784
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import inspect
    import _ast
    import shutil
    import pandas
    import re
    import io
    import functools
    import json
    import traceback
    import csv
    import ast
    import copy
    import os
    import tempfile
    import sys
    import datetime
    import unittest
    import itertools
    import contextlib
    import time
    import threading
    import pycompat
    import test
    import opcode
    import utils
    with open('../test_output/test_Tracer___enter__.txt', 'w') as file:
        file.write("")
    @test.snoop(watch=('self.a',), thread_info=True)
    def some_function():
        x = 1
        y = 1
        return x + y
   

# Generated at 2022-06-22 18:15:01.784518
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[3:4] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:15:05.518339
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    with pycompat.open(__file__) as f:
        source = f.read().splitlines()
    unavailable_source = UnavailableSource()
    assert source[3] == unavailable_source[3] == 'def test_UnavailableSource():'



# Generated at 2022-06-22 18:15:09.878157
# Unit test for constructor of class Tracer
def test_Tracer():
    import sys
    import StringIO

    tracer = Tracer(output=StringIO.StringIO())
    old_trace_func = sys.gettrace()
    sys.settrace(tracer.trace)
    try:
        1 + 1
        assert False     # Must not reach here
    except ZeroDivisionError:
        pass
    sys.settrace(old_trace_func)
    assert True



# Generated at 2022-06-22 18:15:22.085132
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    temp_directory = tempfile.TemporaryDirectory()
    filename = os.path.join(temp_directory.name, 'test_file.py')
    with open(filename, 'w', encoding='utf-8') as f:
        f.write('a=5')
    import datetime
    frame = inspect.currentframe()
    module_dict = datetime.__dict__
    module_dict['__loader__'] = None
    result = get_path_and_source_from_frame(frame)
    assert result[0].endswith('inspect.py')
    assert result[1] is not None
    frame = inspect.currentframe()
    module_dict['__loader__'] = frame
    result = get_path_and_source_from_frame(frame)
    assert result[0].endsw

# Generated at 2022-06-22 18:15:26.370292
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    exception_type = None
    exception_value = None
    exception_traceback = None
    tracer.write = MagicMock()
    tracer.__exit__(exception_type, exception_value, exception_traceback)
    assert tracer.write.call_count == 1
    assert tracer.write.call_args[0][0] == "\n    Elastic time: 0:00:00.000001"


# Generated at 2022-06-22 18:15:28.462567
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-22 18:15:36.480754
# Unit test for function get_local_reprs
def test_get_local_reprs():
    d = datetime_module.datetime.now()
    number = 7
    result = get_local_reprs(inspect.currentframe().f_back, watch=(),
                             custom_repr=(
                                 (datetime_module.datetime.__class__,
                                  lambda x: 'datetime({})'.format(x)),
                                 (int, lambda x: x * 2),
                             ))
    assert result == {'d': 'datetime(%s)' % d, 'number': 14,
                      'result': '<OrderedDict len=2>'}



# Generated at 2022-06-22 18:15:42.178412
# Unit test for constructor of class FileWriter
def test_FileWriter():
    Writer = FileWriter
    test_cases = [
    ('hello', False, b''),
    ('hello', True, b'hello'),
    ]
    for path, overwrite, expected_result in test_cases:
        writer = Writer(path, overwrite)
        writer.write(u'something')
        with open(path, 'rb') as f:
            result = f.read()
        assert result == expected_result, (path, overwrite, expected_result)
    # Cleanup
    os.remove(u'hello')




# Generated at 2022-06-22 18:15:51.710818
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    _watch = []
    _watch_explode = []
    _depth = 1
    _prefix = ''
    _overwrite = False
    _thread_info = False
    _custom_repr = []
    _max_variable_length = 100
    _normalize = False
    _relative_time = False
    tracer = Tracer(_overwrite, _watch, _watch_explode, _depth, _prefix, _thread_info, _custom_repr,
                    _max_variable_length, _normalize, _relative_time)
    assert tracer._overwrite == _overwrite
    assert tracer._watch == _watch
    assert tracer._watch_explode == _watch_explode
    assert tracer._depth == _depth
    assert tracer._prefix == _prefix
    assert tracer._thread_info == _

# Generated at 2022-06-22 18:16:03.641258
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import shutil
    file_path = 'FileWriter_test_' + str(datetime_module.datetime.now()) + '.txt'
    fw = FileWriter(file_path, overwrite=True)
    s = 'abcdefghijklmnopqrstuvwxyz123456789'
    for i in range(100):
        fw.write(s[:i])
    assert os.path.isfile(file_path)
    assert open(file_path, 'r').read() == s[:i]
    fw = FileWriter(file_path, overwrite=False)
    for i in range(100):
        fw.write(s[:i])
    assert os.path.isfile(file_path)

# Generated at 2022-06-22 18:16:16.203815
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global DISABLED
    DISABLED = False
    output = io.StringIO()
    watch = ('main.a', 'main.b', 'main.c')
    watch_explode = ('main.foo', 'self')
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False

    pysnooper.snoop(output=output, watch=watch, watch_explode=watch_explode, depth=depth, prefix=prefix, overwrite=overwrite, thread_info=thread_info, custom_repr=custom_repr, max_variable_length=max_variable_length, normalize=normalize, relative_time=relative_time)

# Generated at 2022-06-22 18:16:20.476416
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo():
        inner_foo = 1
        import sys
        return locals()
    assert get_local_reprs(
        inspect.currentframe(),
        watch=[CommonVariable('inner_foo'),
               CommonVariable('sys')]
    ) == foo()



# Generated at 2022-06-22 18:16:23.068453
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == \
           u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:16:28.785447
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'
    assert uas[1] == u'SOURCE IS UNAVAILABLE'
    assert uas[2] == u'SOURCE IS UNAVAILABLE'
    assert uas[3] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:16:39.106432
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import time
    path = "tests/test_FileWriter_output.txt"
    content0 = "content0\n"
    content1 = "content1\n"
    overwrite = True
    writeFunc = get_write_function(path, overwrite)
    assert os.path.isfile(path) is False
    writeFunc(content0)
    assert os.path.isfile(path) is True
    with open(path, 'r') as f:
        assert f.read() == content0
    writeFunc(content1)
    with open(path, 'r') as f:
        assert f.read() == content0 + content1
    time.sleep(0.1)
    overwrite = False
    writeFunc = get_write_function(path, overwrite)
    writeFunc(content0)
   

# Generated at 2022-06-22 18:16:46.741910
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile

    def test_write_to_file(writer, content, expected_content):
        if isinstance(content, pycompat.text_type):
            content = content.encode('utf-8')
        writer.write(content)
        with open(writer.path, 'rb') as f:
            assert f.read() == expected_content

    temporary_file = tempfile.NamedTemporaryFile()
    writer = FileWriter(temporary_file.name, overwrite=False)
    test_write_to_file(writer, b'a', b'a')
    test_write_to_file(writer, b'b', b'ab')

    writer = FileWriter(temporary_file.name, overwrite=False)
    test_write_to_file(writer, b'a', b'ab')

   

# Generated at 2022-06-22 18:16:51.944184
# Unit test for constructor of class FileWriter
def test_FileWriter():
    output = FileWriter("./TestFileWriter", False)
    assert output.path == "./TestFileWriter"
    assert not output.overwrite
    output = FileWriter("./TestFileWriter", True)
    assert output.path == "./TestFileWriter"
    assert output.overwrite
    return True



# Generated at 2022-06-22 18:17:02.558834
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    from threading import current_thread
    from time import sleep
    tracer = Tracer(output=None, depth=1, prefix='',
                    overwrite=False, thread_info=True, custom_repr=(),
                    max_variable_length=100, normalize=False, relative_time=False)
    # Set thread name list
    thread_names = ["one", "two", "three", "four"]
    # Set thread padding length
    tracer.thread_info_padding = 0
    # Setup thread_info
    thread_info = str(current_thread().ident)+'-'+thread_names[0]

    # Get current thread padding length
    current_thread_len = len(thread_info)
    thread_info_padding = current_thread_len

    # Create a thread list to check with thread names

# Generated at 2022-06-22 18:17:08.737522
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
        tracer = Tracer()
        tracer._is_internal_frame = lambda frame: False
        def function():
            pass
        function.__code__ = __code__ = object()
        tracer.target_codes = set()
        actual = tracer(function)
        assert tracer.target_codes == {__code__}
        assert function != actual
        assert function.__code__ == actual.__code__

    # Unit test for method _is_internal_frame of class Tracer

# Generated at 2022-06-22 18:17:11.964765
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[0], pycompat.string_type)


# Generated at 2022-06-22 18:17:19.192247
# Unit test for constructor of class Tracer
def test_Tracer():
    import sys
    import __main__
    import unittest
    from unittest.mock import patch

    test_cases = []
    class TestCase(unittest.TestCase):
        def runTest(self):
            with patch.object(sys, 'stdout') as stdout_mock:
                print(self.comment)
                self.tracer(self.function)

    def get_testcase(comment, **tracer_kwargs):
        def test(self):
            self.comment = comment
            self.function = function
            self.tracer = Tracer(**tracer_kwargs)
        return test

    function = lambda: None

# Generated at 2022-06-22 18:17:22.738706
# Unit test for function get_write_function
def test_get_write_function():
    assert sys.stderr.encoding
    assert isinstance(get_write_function(None, False), collections.Callable)



# Generated at 2022-06-22 18:17:31.097530
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    # Create a dummy frame
    import inspect
    source = 'a = 1'

    def foobar():
        pass

    foobar_code = foobar.__code__
    foobar_globals = dict(foobar.__globals__)
    foobar_globals['__name__'] = '__main__'
    foobar_frame = types.FrameType(None, foobar_globals, None, None,
                                   (foobar_code,), None)
    foobar_frame.f_lineno = 1
    path, result = get_path_and_source_from_frame(foobar_frame)

# Generated at 2022-06-22 18:17:39.117666
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    path, source = get_path_and_source_from_frame(sys._getframe())
    assert any(source)
    assert path == __file__

    def no_globals():
        exec("a = 5")
    path, source = get_path_and_source_from_frame(sys._getframe())
    assert any(source)
    assert path in __file__, path

    def source_from_loader():
        source = 'lol'
        def some_func():
            pass
    path, source = get_path_and_source_from_frame(sys._getframe())
    assert any(source)
    assert path == __file__


# Generated at 2022-06-22 18:17:47.421852
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import os, shutil, tempfile
    temp_dir = tempfile.mkdtemp()
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()

# Generated at 2022-06-22 18:17:52.805141
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import unittest
    class Tracer___call___TestCase(unittest.TestCase):
        def test_Tracer___call___TestCase(self):
            sys.stdout.write('unit test for Tracer.__call__\n')
    unittest.main()

# Generated at 2022-06-22 18:18:01.083382
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import io
    import unittest
    import unittest.mock
    import datetime
    #from pysnooper.snoop_use import Tracer
    #from pysnooper.snoop_use import get_write_function
    #from pysnooper.snoop_use import pycompat
    #from pysnooper.snoop_use import pycompat, utils, opcode, inspect
    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.saved_stdout = sys.stdout
            self.saved_stderr = sys.stderr
            self.saved_datetime = datetime_module.datetime
            sys.stdout = io.StringIO()

# Generated at 2022-06-22 18:18:03.554732
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  snoopObj1 = SnoopObj()
  snoopObj1.__enter__()


# Generated at 2022-06-22 18:18:04.718615
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-22 18:18:08.724581
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, False)
    write('Hello')
    write = get_write_function(open('z.txt', 'w'), False)
    write('Hello, world!')
    write('Goodbye!')
    write = get_write_function(sys.stdout, False)
    write('Hello, world!')
    write('Goodbye!')


# Generated at 2022-06-22 18:18:21.742696
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from ..testing.temp_folder import WorkingFolder, Folder
    from ..testing import assert_not_raised, assert_equal
    from . import utils

    timestamp = datetime_module.datetime.now().strftime("%Y%m%d%H%M")
    filename = 'FileWriterTestFile' + timestamp + '.txt'
    assert_not_raised(Exception, utils.FileWriter, filename, True)

    with WorkingFolder() as working_folder:
        assert_equal(working_folder.path.joinpath(filename).exists(), False)
        utils.FileWriter(filename, True).write("test")
        assert_equal(working_folder.path.joinpath(filename).exists(), True)
        utils.FileWriter(filename, True).write("test")

# Generated at 2022-06-22 18:18:23.348396
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert isinstance(UnavailableSource()[0], str)



# Generated at 2022-06-22 18:18:24.881532
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-22 18:18:33.709258
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    @pysnooper.snoop(depth=1)
    def foo():
        bar()
    @pysnooper.snoop(depth=1)
    def bar():
        bar()
    # Doesn't work on module level
    #foo()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-22 18:18:43.410010
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():

    import random
    import collections
    random.seed(0)

    results = []
    okay = []

    def assert_equal(expected, actual):
        if expected != actual:
            results.append((expected, actual))
        else:
            okay.append((expected, actual))

    ###########################################################################
    # Write tests here using assert_equal()
    ###########################################################################
    import io
    from collections import defaultdict
    class Mydict(defaultdict):
        def __missing__(self, key):
            return '{' + key + '}'
    def myformat(fmt_str):
        return fmt_str.format_map(Mydict(default_factory=str))
    _file = io.StringIO()
    newline = '\n'

# Generated at 2022-06-22 18:18:48.064708
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        bar()
        bar()

    @pysnooper.snoop()
    def bar():
        1 // 0
        return 'aaa'

    # Ensure the exception is raise
    with pytest.raises(ZeroDivisionError):
        foo()



# Generated at 2022-06-22 18:18:52.797810
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class Test:
        def a(self):
            pass
    Test_a = Tracer()(Test.a)
    assert Test_a.__self__ == Test
    assert Test_a.__name__ == 'a'

    obj = Test()
    obj.a()



# Generated at 2022-06-22 18:19:02.671898
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import datetime
    import pycompat
    import pysnooper
    sut = pysnooper.Tracer(...)
    sut.thread_local = (datetime.datetime(2019, 1, 1), datetime.datetime(2020, 1, 1), datetime.datetime(2019, 1, 1))
    sut.frame_to_local_reprs = {..., ..., ...}
    sut.start_times = {..., ..., ...}
    frame = ...
    exc_type = ...
    exc_value = ...
    exc_traceback = ...
    expected = ...
    actual = sut.__exit__(frame, exc_type, exc_value, exc_traceback)
    assert expected == actual



# Generated at 2022-06-22 18:19:10.721970
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert os.path.isfile(__file__), "The test file is missing?!?"
    frame = inspect.currentframe()
    filename, source = get_path_and_source_from_frame(frame)
    assert source[0] == '# Unit test for function get_path_and_source_from_frame'
    assert os.path.basename(filename) == os.path.basename(__file__)



# Generated at 2022-06-22 18:19:16.934572
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    def do_test_FileWriter_write():
        file_writer = FileWriter(path='test.txt', overwrite=True)
        file_writer.write('test')
        with open('test.txt') as f:
            assert f.read() == 'test'
        file_writer.write('test')
        with open('test.txt') as f:
            assert f.read() == 'testtest'
        assert file_writer.overwrite is False
        os.remove('test.txt')
    try:
        do_test_FileWriter_write()
    except Exception:
        os.remove('test.txt')
        raise


# Generated at 2022-06-22 18:19:21.092379
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    path = tempfile.mkstemp()[1]
    file_writer = FileWriter(path, True)
    file_writer.write('a')
    file_writer.write('b')
    with open(path, 'r') as f:
        assert f.read() == 'ab'
    os.remove(path)



# Generated at 2022-06-22 18:19:28.425745
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs(frame={'a': 1, 'b': 2},
                           watch=[{'a': 1, 'b': 2}]) == {'a': '1', 'b': '2'}
    assert get_local_reprs(frame={}, watch=[{'a': 1, 'b': 2}]) == {'a': '1', 'b': '2'}



# Generated at 2022-06-22 18:19:37.635354
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    import textwrap
    import os
    def f():
        y = '''
        x = 17
        return x
        '''
        x = eval(y)
        return x
    frame = inspect.currentframe().f_back

# Generated at 2022-06-22 18:19:42.806204
# Unit test for method write of class Tracer
def test_Tracer_write():
    logfile = os.path.abspath(os.path.join(os.path.dirname(__file__), '../log/log.txt'))
    logger = logging.getLogger('pysnooper')
    logger.setLevel(logging.INFO)
    handler = logging.FileHandler(logfile)
    logger.addHandler(handler)
    tracer = Tracer(watch=('a'))
    tracer.write('a')
    f = open(logfile, 'r')
    lines = f.readlines()
    print(lines)
    assert lines[-1] == 'a\n'
    

# Generated at 2022-06-22 18:19:44.790878
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(overwrite=True):
        pass


# Generated at 2022-06-22 18:19:46.515021
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-22 18:19:49.034927
# Unit test for constructor of class Tracer
def test_Tracer():
    import pysnooper
    assert pysnooper.Tracer(1,2,3) is None

# Generated at 2022-06-22 18:19:56.071191
# Unit test for function get_write_function
def test_get_write_function():
    class FakeStream(object):
        def __init__(self):
            self.content = ''
        def write(self, s):
            self.content += s
    fake_stream = FakeStream()
    write = get_write_function(fake_stream, overwrite=False)
    write('a')
    write('b')
    assert fake_stream.content == 'ab'
    assert fake_stream.content is not 'ab'
    assert fake_stream.content is not u'ab'
    assert fake_stream.content is not b'ab'



# Generated at 2022-06-22 18:20:00.094492
# Unit test for method write of class Tracer
def test_Tracer_write():
    outerr = []
    output_function = lambda s: outerr.append(s)
    tracer = Tracer(output=output_function)
    tracer.write("This is the message")
    assert outerr == ['This is the message\n']


# Generated at 2022-06-22 18:20:14.288613
# Unit test for constructor of class Tracer
def test_Tracer():
    '''
    The code in the Tracer constructor is a little bit too convoluted to
    test without rewriting it.
    All we can do is test the end result.
    '''
    watch = ('foo', 'self')
    watch_explode = ('x',)
    depth = 3
    prefix = 'foo'
    overwrite = True
    thread_info = True
    custom_repr = (
        (lambda x: True, lambda x: 'this is a custom repr'),
        (lambda x: False, lambda x: 'this is a custom repr for false'),
    )
    max_variable_length = 42
    normalize = True
    relative_time = True


# Generated at 2022-06-22 18:20:26.788157
# Unit test for constructor of class Tracer
def test_Tracer():

    # Check normal boolean values
    try:
        Tracer(output=True)
        Tracer(output=False)
    except Exception:
        assert False

    # Check invalid argument output types
    try:
        Tracer(output=3)
        assert False
    except RuntimeError:
        assert True

    # Check the default argument type
    try:
        Tracer()
        assert True
    except Exception:
        assert False

    # Check invalid type of argument watch
    try:
        Tracer(watch=True)
        assert False
    except RuntimeError:
        assert True

    # Check valid argument types for argument watch

# Generated at 2022-06-22 18:20:33.285437
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = pysnooper.snoop(thread_info=True)
    current_thread = threading.current_thread()
    thread_info = "{ident}-{name} ".format(ident=current_thread.ident, name=current_thread.getName())
    t = tracer.set_thread_info_padding(thread_info)
    assert t == thread_info.ljust(30)

# Generated at 2022-06-22 18:20:46.709385
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    python_def = inspect.currentframe().f_code
    source_path, source = get_path_and_source_from_frame(inspect.currentframe())
    source_path = source_path if not False else os.path.basename(source_path)
    if 'snoop' not in globals():
        snoop = Tracer(output=sys.stdout,watch=(), watch_explode=(), depth=1,prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    if 'thread_global' not in globals():
        thread_global = threading.local()
    if 'DISABLED' not in globals():
        DISABLED = False

# Generated at 2022-06-22 18:20:52.749291
# Unit test for method write of class Tracer
def test_Tracer_write():
    class TestTracer(Tracer):
        def write(self, s):
            return s
    snooper = TestTracer()
    expected_value = "ZZZ "+u'{self.prefix}{s}\n'.format(s='Test')
    snooper.prefix = "ZZZ "
    assert snooper.write('Test') == expected_value


# Generated at 2022-06-22 18:21:02.610020
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test_helper(pysnooper_obj, trace_func_args, expected_result):
        import sys

        # Mock object that needs to be restored
        old_get_write_function = utils.get_write_function
        old_get_path_and_source_from_frame = utils.get_path_and_source_from_frame

        class MockWriteFunc(object):
            def __init__(self):
                self.write_result = []

            def __call__(self, s):
                self.write_result.append(s)

        mock_write_func_obj = MockWriteFunc()
        pysnooper_obj._write = mock_write_func_obj
        utils.get_write_function = lambda *args, **kwargs: mock_write_func_obj


# Generated at 2022-06-22 18:21:04.822717
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    assert tracer.trace(inspect.currentframe(), None, None)



# Generated at 2022-06-22 18:21:10.914790
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        x = 1
        y = 2
        z = 3
        return locals()
    frame = f.__code__.co_code
    assert f() == get_local_reprs(frame)



# Generated at 2022-06-22 18:21:17.611794
# Unit test for function get_write_function
def test_get_write_function():
    from .testing import utils

    stdout = utils.WritableStream()
    assert get_write_function(stdout, overwrite=True) == stdout.write

    with utils.TempFile() as t:
        output, overwrite = t.path, True
        write = get_write_function(output, overwrite)
        write('hello')
        with open(output, 'rt') as f:
            assert f.read() == 'hello'
        write(' world')
        with open(output, 'rt') as f:
            assert f.read() == 'hello world'
        with pycompat.testing.assert_raises(Exception):
            write(' exception')



# Generated at 2022-06-22 18:21:21.198926
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:21:29.802301
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    cls = Tracer
    import os
    from pysnooper.utils import get_write_function, CommonVariable, \
        Exploding, BaseVariable, get_path_and_source_from_frame
    from pysnooper.utils import ensure_tuple, \
        get_local_reprs, \
        truncate
    import inspect
    import functools
    import threading
    import pycompat
    import sys
    import datetime
    import opcode
    import itertools
    import traceback
    cls.test_cls = cls

# Generated at 2022-06-22 18:21:39.832417
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert_raises(TypeError, "snoop = Tracer(); snoop()")
    snoop = Tracer()
    def function():
        # line 1
        a = 1
        # line 2
        b = 2
        return 3
    wrapper = snoop(function)
    stream = io.StringIO()
    snoop._write = stream.write
    wrapper()
    assert stream.getvalue() == (
        "Call ended by exception\n"
        "    Starting var:.. a = 1\n"
        "    New var:....... b = 2\n"
        "    Return value:.. 3\n"
    )
    def function():
        raise Exception()
    wrapper = snoop(function)
    stream = io.StringIO()
    snoop._write = stream.write

# Generated at 2022-06-22 18:21:45.131355
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    root = 'dummy'
    path = utils.create_unique_temp_file(root=root)
    FileWriter(path, overwrite=True).write(u'hello')

    with open(path, 'r') as f:
        content = f.read()
    assert content == u'hello'
    os.remove(path)



# Generated at 2022-06-22 18:21:46.776999
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    UnavailableSource()[0]



# Generated at 2022-06-22 18:21:52.996631
# Unit test for method write of class Tracer
def test_Tracer_write():
    global outputfile
    outputfile = StringIO()
    def test_fn():
        a = 1
        b = 2
        return a + b
    snoop = Tracer(watch=('a', 'b'), output=outputfile)
    with snoop:
        test_fn()

    assert outputfile.getvalue() == "Source path:... tests/test_api.py\n" \
           "    New var:....... a = 1\n" \
           "    New var:....... b = 2\n"



# Generated at 2022-06-22 18:21:57.788227
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import tempfile
    from . import utils
    def get_content(path):
        with open(path) as f:
            content = f.read()
        return content
    with tempfile.NamedTemporaryFile(delete=False) as f:
        path = f.name
        s = 'content'
        write = FileWriter(path, False).write
        write(s)
        assert s == get_content(path)
        write(s)
        assert s + s == get_content(path)
        write = FileWriter(path, True).write
        write(s)
        assert s == get_content(path)
        write(s)
        assert s == get_content(path)
    os.unlink(path)



# Generated at 2022-06-22 18:22:03.126412
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test that this decorator can be used on classes and functions.
    def foo():
        pass
    class Bar:
        def foo(self):
            pass
    assert isinstance(Tracer()(foo), type(foo))
    assert isinstance(Tracer()(Bar), type(Bar))


# Generated at 2022-06-22 18:22:14.833956
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    """ Tests method set_thread_info_padding of class Tracer to verify
    the following feature "On multi-threaded apps identify which thread are
    snooped in output" """

    def target_function():
        pass

    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding("4-main ") == "4-main "
    assert tracer.set_thread_info_padding("4-thread1") == "4-thread1"
    assert tracer.set_thread_info_padding("4-thread2") == "4-thread2 "
    assert tracer.set_thread_info_padding("4-thread1") == "4-thread1 "
    assert tracer.set_thread_info_padding("4-main ") == "4-main     "

# Unit

# Generated at 2022-06-22 18:22:21.024869
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()

    path, code_lines = get_path_and_source_from_frame(frame)
    assert code_lines[0] == 'def test_get_path_and_source_from_frame():'




# At the moment the signature is used read-only, and is immutable.
# This may change in the future.

# Generated at 2022-06-22 18:22:31.835401
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from . import _temp_folder
    from .utils import delete_file
    import tempfile
    with _temp_folder():
        # First test: FileWriter should create the file if it doesn't exist
        file_path = tempfile.mktemp()
        delete_file(file_path)
        file_writer = FileWriter(file_path, overwrite=False)
        file_writer.write(u'Hello, world!')
        with open(file_path, encoding='utf-8') as f:
            assert f.read() == 'Hello, world!'
        # Second test: FileWriter should append to the file if it exists and
        # `overwrite` is False
        file_writer.write(u' Good-bye, world!')
        with open(file_path, encoding='utf-8') as f:
            assert f.read