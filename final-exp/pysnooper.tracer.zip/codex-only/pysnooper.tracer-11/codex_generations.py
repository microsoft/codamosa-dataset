

# Generated at 2022-06-22 18:12:26.063821
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import io
    def dummy(x):
        return 4

    file_name = utils.get_file_name_of_function(dummy)
    frame = sys._getframe(0)
    frame.f_globals['__name__'] = 'dummy'
    frame.f_code.co_filename = file_name
    class MyLoader(object):
        @staticmethod
        def get_source(name):
            assert name == 'dummy'
            return io.StringIO('def foo():\n    return 14\n')
    frame.f_globals['__loader__'] = MyLoader()
    assert get_path_and_source_from_frame(frame) == (file_name, ['def foo():', '    return 14', ''])



# Generated at 2022-06-22 18:12:35.366855
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import mock
    from pytest import raises
    import pysnooper
    from pysnooper.tracer import Tracer, get_write_function
    from pysnooper.utils import BaseVariable
    # ensure that both base class and concrete class are tested
    for cls in [pysnooper.tracer.Tracer, Tracer]:
        # prepare
        t = cls(mock.Mock())
        # action
        with t:
            pass
        # assert

# Generated at 2022-06-22 18:12:42.638474
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    with utils.temp_file() as temp_file:
        fw1, fw2 = [FileWriter(temp_file, False), FileWriter(temp_file, True)]
        fw1.write(u'hello')
        fw1.write(u'world')
        fw2.write(u'hi')
        with open(temp_file) as f:
            assert f.read() == u'helloworld'



# Generated at 2022-06-22 18:12:52.686898
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from .testing import assert_equal
    path = 'a/b.c'
    overwrite = False
    FileWriter(path, overwrite)
    assert_equal(open(path).read(), '')
    writer = FileWriter(path, overwrite)
    writer.write('hello')
    assert_equal(open(path).read(), 'hello')
    writer.write('world')
    assert_equal(open(path).read(), 'helloworld')
    overwrite = True
    writer = FileWriter(path, overwrite)
    writer.write('hello')
    assert_equal(open(path).read(), 'hello')
    writer.write('world')
    assert_equal(open(path).read(), 'world')
    writer.write('\n')
    assert_equal(open(path).read(), 'world\n')



# Generated at 2022-06-22 18:12:56.345112
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())

    current_path = __file__
    if current_path.lower().endswith('.pyc'):
        current_path = current_path[:-1]
    assert current_path == f()[0]

    assert (__file__, UnavailableSource()) == f()  # noqa
    x = object()
    assert (__file__, UnavailableSource()) == f()  # noqa
    del x
    assert (__file__, UnavailableSource()) == f()  # noqa



# Generated at 2022-06-22 18:13:05.033983
# Unit test for function get_write_function
def test_get_write_function():
    # Writing to stderr
    assert callable(get_write_function(None, False))

    # Writing to a stream
    assert callable(get_write_function(utils.WritableStream(), False))

    # Writing to a file
    assert callable(get_write_function('/tmp/bla.txt', False))

    # Writing to a file with overwrite
    assert callable(get_write_function('/tmp/bla.txt', True))

    # Writing to a function
    assert callable(get_write_function(lambda x: x, False))



# Generated at 2022-06-22 18:13:11.445378
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest
    output = io.StringIO()
    sys.stdout = output

    snooper = Tracer(output=None)
    # TODO(kszucs): add a test for normalize
    # TODO(kszucs): add a test for relative_time
    # TODO(kszucs): add a test for custom_repr

    @snooper(watch=['x', 'y'], watch_explode=['z'], depth=1, prefix='### ',
             overwrite=False, thread_info=False)
    def test_function(x, y=None, *args, **kwargs):
        '''Docstring of test function'''
        w = 0
        return w

    test_function(1, 2)

# Generated at 2022-06-22 18:13:22.135430
# Unit test for constructor of class FileWriter
def test_FileWriter():
    f = FileWriter('/tmp/test.log', overwrite=False)
    f.write('hello world\n')
    f.write('hello world\n')
    f.write('hello world\n')
    f1 = FileWriter('/tmp/test.log', overwrite=True)
    f1.write('try to overwrite\n')
    f1.write('hello world\n')

if pycompat.PY2:
    def _compute_start_and_end(start, end):
        """Normalize start and end to be something slice() can use.

        Under Python 2, slice() doesn't accept None

        """
        if start is None:
            start = 0
        if end is None:
            end = sys.maxsize
        return start, end

        # `slice.start` and `slice.stop

# Generated at 2022-06-22 18:13:33.424445
# Unit test for function get_local_reprs
def test_get_local_reprs():

    def foo(x):
        '''asdf'''
        z = 3
        bar = [x + z, x - z]
        print(bar)
        bar.append('a')
        return bar

    watch = (CommonVariable('bar', False, False),)

    frame = inspect.currentframe()
    code = frame.f_code
    frame = frame.f_back
    code = frame.f_code
    frame = frame.f_back
    code = frame.f_code
    frame = frame.f_back
    code = frame.f_code
    frame = frame.f_back
    code = frame.f_code
    frame = frame.f_back
    code = frame.f_code
    frame = frame.f_back
    code = frame.f_code
    frame = frame.f_

# Generated at 2022-06-22 18:13:38.554453
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os

    for overwrite in (True, False):
        with tempfile.NamedTemporaryFile() as output_file:
            file_writer = FileWriter(output_file.name, overwrite)
            file_writer.write(u'hello')
            assert os.path.exists(output_file.name)
            with open(output_file.name, 'r') as output_file:
                assert output_file.read() == 'hello'



# Generated at 2022-06-22 18:13:50.072597
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t = Tracer()
    assert t.set_thread_info_padding("hi") == "hi     "
    assert t.set_thread_info_padding("hello") == "hello  "
    assert t.set_thread_info_padding("hello") == "hello  "
    assert t.set_thread_info_padding("hi") == "hi     "
    assert t.set_thread_info_padding("hello") == "hello  "
    assert t.set_thread_info_padding("hi") == "hi     "
    assert t.set_thread_info_padding("hi") == "hi     "
    assert t.set_thread_info_padding("hello") == "hello  "
    assert t.set_thread_info_padding("hi") == "hi     "

# Generated at 2022-06-22 18:13:59.879420
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from . import watch
    from .autowatch import AutoWatch
    from .variables import List, Tuple

    def foo(bar):
        x = 3
        y = 4
        z = 5
        return bar

    source = inspect.getsource(foo)

    frame = utils.get_frame_from_source_code(source)
    result = get_local_reprs(frame)
    assert result == {'bar': '<unknown>', 'x': '3', 'y': '4', 'z': '5'}

    frame = utils.get_frame_from_source_code(source)
    result = get_local_reprs(frame, watch=(watch.x,))

# Generated at 2022-06-22 18:14:01.932603
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[5] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:09.983609
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_name = 'temp_FileWriter_write.txt'
    content = u'foobar'
    file_writer = FileWriter(file_name, overwrite=True)
    file_writer.write(content)
    with open(file_name, 'rb') as existing_file:
        assert existing_file.read() == (content + '\n').encode('utf-8')
    os.remove(file_name)
    file_writer = FileWriter(file_name, overwrite=False)
    file_writer.write(content)
    with open(file_name, 'rb') as existing_file:
        assert existing_file.read() == (content + '\n').encode('utf-8')
    file_writer.write(content)

# Generated at 2022-06-22 18:14:17.217419
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import pickle
    from io import StringIO

    class Tracer_Test(unittest.TestCase):
        def test_all(self):
            global DISABLED
            DISABLED = False
            with Tracer() as tracer:
                @tracer
                def test_all1(a, b):
                    c = a + b
                    return c
                out = StringIO()
                test_all1(2, 3, output=out)
                self.assertEqual(out.getvalue(), '\n'.join([
                    '    Elapsed time: 0:00:00.000019',
                ]))

# Generated at 2022-06-22 18:14:18.061354
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    assert True


# Generated at 2022-06-22 18:14:25.739299
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavail = UnavailableSource()
    assert unavail[0] == u'SOURCE IS UNAVAILABLE'
    assert unavail[1] == u'SOURCE IS UNAVAILABLE'
    assert unavail[2] == u'SOURCE IS UNAVAILABLE'
    assert unavail[3] == u'SOURCE IS UNAVAILABLE'
    assert unavail[4] == u'SOURCE IS UNAVAILABLE'
    assert unavail[5] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:31.923272
# Unit test for constructor of class Tracer

# Generated at 2022-06-22 18:14:39.592487
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import pytest
    from . import testing_utils
    from .pdb_clone.pdb import Pdb
    with pytest.raises(SystemExit):
        testing_utils.run_python_process_with_pdb_clone(Pdb, '''
            if 1:
                import sys
                pdb = sys._getframe().f_back.f_globals['__builtins__']['__import__']('pdb')
                pdb.set_trace()
                x = 1
                x = 2
                x = 3
                x = 4
        ''')



# Generated at 2022-06-22 18:14:41.420494
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[2] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:53.357586
# Unit test for constructor of class Tracer
def test_Tracer():
    import sys
    import threading
    from time import time
    #### ALL of the following arguments should be modified with the right
    #### values:
    #    output: sys.stdout
    #    watch: ()
    #    watch_explode: ()
    #    depth: 1
    #    prefix: ''
    #    overwrite: False
    #    thread_info: False
    #    custom_repr: ()
    #    max_variable_length: 100
    #    normalize: False
    #    relative_time: False

# Generated at 2022-06-22 18:15:01.652551
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    file_path = tempfile.mktemp(prefix='FileWriter_write_test_')
    fw = FileWriter(file_path, True)
    assert fw.overwrite
    fw.write('foo')
    with open(file_path) as f:
        file_content = f.read()
        assert file_content == 'foo'
    assert not fw.overwrite
    fw.write('bar')
    with open(file_path) as f:
        file_content = f.read()
        assert file_content == 'foo\nbar'



# Generated at 2022-06-22 18:15:03.085261
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[0], unicode)



# Generated at 2022-06-22 18:15:14.164940
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Test the real use case of the function (the debugger usually uses
    # it with a frame much higher on the stack).
    def f():
        def g():
            __, source = get_path_and_source_from_frame(sys._getframe())
            assert source[0] == 'def g():'
        g()

    f()

    # Test the case where the source is unavailable.
    def h():
        # Mock the __loader__ to return a source that does not work.
        __loader__ = object()
        __, source = get_path_and_source_from_frame(sys._getframe())
        assert source[0] == 'SOURCE IS UNAVAILABLE'

    h()

    # Test that the cache works.
    def i():
        def j():
            __, source = get_path_and_

# Generated at 2022-06-22 18:15:24.886804
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    get_path_and_source_from_frame(inspect.currentframe())


if pycompat.PY2:

    class FrameIterator(object):
        def __init__(self, tb):
            self.tb = tb
            self.tb_next = tb.tb_next
            while self.tb_next.tb_next is not None:
                self.tb_next = self.tb_next.tb_next

        def __iter__(self):
            return self

        def __next__(self):
            if self.tb is None:
                raise StopIteration
            frame = self.tb.tb_frame
            self.tb = self.tb.tb_next
            return frame

        next = __next__


else:
    FrameIterator

# Generated at 2022-06-22 18:15:27.703725
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:15:38.026504
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(AssertionError):
        Tracer(depth=0)

    with pytest.raises(AssertionError):
        Tracer(depth=-1)

    with pytest.raises(AssertionError):
        Tracer(depth=1.1)

    with pytest.raises(AssertionError):
        Tracer(output=0)

    with pytest.raises(AssertionError):
        Tracer(watch=0)
        Tracer(watch_explode=0)

    with pytest.raises(AssertionError):
        Tracer(custom_repr=0)

    with pytest.raises(AssertionError):
        Tracer(custom_repr=((object, None),))


# Generated at 2022-06-22 18:15:40.509455
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    assert source[-1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:15:49.953616
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    if DISABLED:
        return
    import unittest
    import unittest.mock
    from . import utils

    class Tracer___call__Test(unittest.TestCase):
        def test(self):
            tracer = pysnooper.Tracer(None, watch=('foo', 'bar'))
            class Function(object):
                def __init__(self):
                    pass
                def function(self, foo):
                    bar = foo + 1
                    return bar

            function = Function().function
            result = tracer(function)
            self.assertIs(result, function)
            with unittest.mock.patch.object(tracer, 'trace') as mock_method:
                result = function(1)
            self.assertEqual(result, 2)
            mock_method.assert_has

# Generated at 2022-06-22 18:15:54.321971
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer.watch = ['foo', 'self']
    frame = inspect.currentframe()
    tracer.frame_to_local_reprs[frame] = get_local_reprs(frame, 
                                                         watch=tracer.watch)

    tracer.__enter__()

    assert stack == [sys.gettrace()]
    assert thread_global.__dict__['depth'] == 0
    assert tracer.target_frames == {frame}
    assert tracer.start_times == {frame: datetime_module.datetime.now()}
    assert sys.gettrace() == tracer.trace


# Generated at 2022-06-22 18:16:05.485533
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.thread_info_padding = 0
    test_thread_info = '1-A '
    test_result = tracer.set_thread_info_padding(test_thread_info)
    assert test_thread_info.ljust(test_result) == test_result
    
    tracer.thread_info_padding = 3
    test_thread_info = '1-A'
    test_result = tracer.set_thread_info_padding(test_thread_info)
    assert test_thread_info.ljust(test_result) == test_result
    
    tracer.thread_info_padding = 3
    test_thread_info = '123-ABC'
    test_result = tracer.set_thread_info_padding(test_thread_info)
    assert test

# Generated at 2022-06-22 18:16:07.760309
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write('a')
    tracer.write('b')

# Generated at 2022-06-22 18:16:12.914994
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import threading
    pysnooper.snoop(thread_info=True)
    @pysnooper.snoop()
    def foo():
        with pysnooper.snoop():
            pass
    threading.Thread(target=foo).start()
    foo()


# Generated at 2022-06-22 18:16:22.648343
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import os
    test_dir = utils.get_test_dir()
    filename = os.path.join(test_dir, 'test.txt')

    # writing to stderr
    out = get_write_function(None, None)
    out('hello')

    # writing to an output object
    output = io.StringIO()
    out = get_write_function(output, None)
    out('hello')
    assert output.getvalue() == 'hello'

    # writing to a file with overwrite=False
    get_write_function(filename, False)('hello')
    with open(filename) as f:
        assert f.read() == 'hello'
    get_write_function(filename, False)('world')

# Generated at 2022-06-22 18:16:33.066636
# Unit test for method write of class Tracer
def test_Tracer_write():
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-22 18:16:42.267107
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    # The thread_info string will contain the thread id and the thread name
    # separated by a dash.
    current_thread = threading.current_thread()
    thread_info_string = '{}-{} '.format(current_thread.ident,
                                         current_thread.getName())

    tracer.set_thread_info_padding(thread_info_string)
    # All thread_info strings should have the same length
    assert tracer.thread_info_padding == len(thread_info_string)

    # Now we create a thread with an even longer thread_info string
    # to see if the padding is adjusted

# Generated at 2022-06-22 18:16:53.991294
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    @pysnooper.snoop()
    def myfunc():
        pass

    assert myfunc.__name__ == 'myfunc'
    assert myfunc.__doc__ == ''

    @pysnooper.snoop()
    def myfunc():
        """my docstring"""

    assert myfunc.__doc__ == 'my docstring'

    @pysnooper.snoop()
    def myfunc(a, b, c=42, *args, d='foo', **kwargs):
        pass

    assert myfunc.__name__ == 'myfunc'
    assert myfunc.__doc__ == ''

# Generated at 2022-06-22 18:17:03.684893
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = utils.make_mock_frame([(1, 'a'), (2, 'b')])
    assert get_local_reprs(frame, ('a', 'b')) == {'a': '1', 'b': '2'}
    assert get_local_reprs(frame, ('a', 'b'), max_length=1) == {'a': '1', 'b': '2'}
    assert get_local_reprs(frame, ('a', 'b'), max_length=0) == {'a': '1', 'b': '2'}
    assert get_local_reprs(frame, ('a', 'b'), max_length=1, normalize=True) == {'a': '1', 'b': '2'}

# Generated at 2022-06-22 18:17:11.551475
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    test_tracer = Tracer(thread_info=True)
    current_thread = threading.current_thread()
    new_thread_info_padding = len(
        "{ident}-{name} ".format(ident=current_thread.ident,
                                 name=current_thread.getName())
    )
    assert test_tracer.thread_info_padding < new_thread_info_padding
    assert test_tracer.set_thread_info_padding(
        "{ident}-{name} ".format(ident=current_thread.ident,
                                 name=current_thread.getName())
    ) == "{ident}-{name} ".format(ident=current_thread.ident,
                                  name=current_thread.getName()).ljust(new_thread_info_padding)
    assert test_tracer.thread

# Generated at 2022-06-22 18:17:19.268766
# Unit test for constructor of class FileWriter
def test_FileWriter():
    def test_impl(path, overwrite, content):
        file_writer = FileWriter(path, overwrite)
        file_writer.write(content)
        with open(path, 'r') as output_file:
            assert output_file.read() == content

    # Test with path.
    test_path = './test.txt'
    test_content = 'TEST CONTENT'
    test_impl(test_path, True, test_content)
    test_impl(test_path, False, test_content)
    test_impl(test_path, True, test_content)
    if os.path.exists(test_path): # Test with relative path
        os.remove(test_path)

    # Test with non-folder path
    test_path = '.txt'
    test_content = 'TEST CONTENT'

# Generated at 2022-06-22 18:17:22.774530
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    return doctest.run_docstring_examples(Tracer.__call__, globals())

# Generated at 2022-06-22 18:17:29.802859
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  TRACER = Tracer()
  TRACER.thread_info_padding = 20
  # print(TRACER.trace(object, 'line', None))
  # print(TRACER.trace(object, 'opcode', None))
  # print(TRACER.trace(object, 'return', None))
  # print(TRACER.trace(object, 'exception', None))
  print(TRACER.trace(object, 'call', None))


# Generated at 2022-06-22 18:17:36.559016
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with io.StringIO() as io_str:
        global_event = []
        output = io_str
        watch = []
        watch_explode = []
        depth = 1
        prefix = ''
        overwrite = False
        thread_info = False
        custom_repr = []
        max_variable_length = 100
        normalize = False
        relative_time = False
        Tracer.__init__(output, watch, watch_explode, depth,
                 prefix, overwrite, thread_info, custom_repr,
                 max_variable_length, normalize, relative_time)
        frame = inspect.currentframe()
        event = 'call'
        arg = None
        with pytest.raises(Exception) as excinfo:
             Tracer.trace(frame, event, arg)

# Generated at 2022-06-22 18:17:43.413254
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import StringIO
    try:
        old_stdout = sys.stdout
        out = StringIO.StringIO()
        sys.stdout = out
        t = Tracer()
        t.write('a')
        t.write('b')
        t.write('c')
        out.seek(0)
        assert out.read() == 'a\nb\nc\n'
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-22 18:17:56.229445
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import pathlib

    temporary_directory = pathlib.Path(tempfile.gettempdir())

    def test_FileWriter(path, overwrite, expected_overwrite_behavior,
                        expected_file_contents):
        writer = FileWriter(path, overwrite)
        writer.write('line 1\nline 2\nline 3')
        assert writer.overwrite == expected_overwrite_behavior
        assert open(path, 'r').read() == expected_file_contents

    test_FileWriter(
        temporary_directory / 'test_FileWriter.txt',
        overwrite=True,
        expected_overwrite_behavior=False,
        expected_file_contents=(
            'line 1\n'
            'line 2\n'
            'line 3'
        )
    )


# Generated at 2022-06-22 18:18:07.560570
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import threading
    global snoop
    snoop = Tracer()
    old_trace = sys.gettrace()
    assert snoop._is_internal_frame(sys._getframe().f_back)
    try:
        with snoop:
            assert sys.gettrace() is snoop.trace
            assert thread_global.depth == -1
            assert snoop.thread_local.original_trace_functions == [old_trace]
            assert not snoop.target_frames
            assert snoop.frame_to_local_reprs == {}
            assert snoop.start_times == {}
            assert snoop.last_source_path is None
    finally:
        assert sys.gettrace() is old_trace
        assert thread_global.__dict__.get('depth', 0) == 0
        assert sn

# Generated at 2022-06-22 18:18:14.246580
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs(None, {'a': 1, 'b': 2}, max_length=1) == {
        'a': '1', 'b': '2'
    }
    assert get_local_reprs(None, {'a': 1, 'b': []}, max_length=1, normalize=True) == {
        'a': '1',
        'b': '[...]'
    }



# Generated at 2022-06-22 18:18:23.982401
# Unit test for constructor of class FileWriter
def test_FileWriter():
    try:
        os.remove('tmp.txt')
    except OSError:
        pass

    writer = FileWriter('tmp.txt', True)
    writer('hi')

    with open('tmp.txt', 'r') as file:
        assert file.read() == 'hi'

    writer = FileWriter('tmp.txt', False)
    writer('hi')

    with open('tmp.txt', 'r') as file:
        assert file.read() == 'hihi'

    writer('hi')

    with open('tmp.txt', 'r') as file:
        assert file.read() == 'hihihi'

    os.remove('tmp.txt')



# Generated at 2022-06-22 18:18:26.318335
# Unit test for function get_write_function
def test_get_write_function():
    class Writable(object):
        def write(self, s): pass
    get_write_function(Writable(), False)() # Shouldn't raise anything



# Generated at 2022-06-22 18:18:35.985686
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from .test_monkeypatch import assert_equal
    from .test_monkeypatch import assert_true
    from .test_monkeypatch import assert_false
    from .test_monkeypatch import assert_raises
    with utils.TempFolder() as temp_folder:
        filename = temp_folder/'test.txt'
        FileWriter(filename, True).write('Hello')
        FileWriter(filename, False).write(' World')
        with open(filename, 'r', encoding='utf-8') as f:
            assert_equal(f.read(), 'Hello World')
        assert_raises(ValueError, FileWriter, 'mydir/myfile.txt', False)



# Generated at 2022-06-22 18:18:44.591996
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from garlicsim.general_misc import temp_file
    from garlicsim.general_misc import temp_folder
    import os
    import pytest

    # First, a test where we just write to a file
    with temp_file() as tmp_file:
        file_writer = FileWriter(tmp_file, overwrite=False)
        assert file_writer.path == tmp_file

        file_writer.write('hello there')

        with open(tmp_file) as f:
            assert f.read() == 'hello there'

    # Now, a test where we append to a file
        file_writer.write('from there')

        with open(tmp_file) as f:
            assert f.read() == 'hello therefrom there'

    # And now a test where we overwrite a file

# Generated at 2022-06-22 18:18:55.227332
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Setup
    import sys, os
    output = sys.stdout
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    tracer = pysnooper.Tracer(output=output, watch=watch,
                              watch_explode=watch_explode, depth=depth,
                              prefix=prefix, overwrite=overwrite,
                              thread_info=thread_info,
                              custom_repr=custom_repr,
                              max_variable_length=max_variable_length,
                              normalize=normalize, relative_time=relative_time)

    g = 0


# Generated at 2022-06-22 18:19:04.935579
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    watch = ('foo', 'self')
    depth = 2
    prefix = "ZZZ "
    overwrite = False
    thread_info = True
    custom_repr = ((type, custom_repr_func),
            (condition2, custom_repr_func2))
    max_variable_length = 200
    normalize = False
    relatiive_time = True
    # we assume that output exists
    output = sys.stdout
    watch_explode = ('foo', 'self')

# Generated at 2022-06-22 18:19:12.647659
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import threading
    tracer = Tracer(thread_info=True)
    thread_info = "1234-thread_name "
    thread_info_padded = tracer.set_thread_info_padding(thread_info)
    assert thread_info_padded == thread_info
    thread_info = "1234-thread_name_shorter_than_the_previous "
    thread_info_padded = tracer.set_thread_info_padding(thread_info)
    assert thread_info_padded == thread_info
    thread_info = "1234-thread_name_longer_than_the_previous "
    thread_info_padded = tracer.set_thread_info_padding(thread_info)
    assert thread_info_padded == thread_info

# Generated at 2022-06-22 18:19:15.741572
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Initialized
    tracer = Tracer()
    assert tracer

    # Invalid inputs
    # TODO: Add more tests

    # Valid inputs
    with tracer:
        pass

    assert tracer


# Generated at 2022-06-22 18:19:16.951116
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[0], unicode)



# Generated at 2022-06-22 18:19:18.224731
# Unit test for constructor of class UnavailableSource

# Generated at 2022-06-22 18:19:23.563562
# Unit test for constructor of class FileWriter
def test_FileWriter():
    content = 'hello\n'
    with pycompat.temp_file() as temp_path:
        writer = FileWriter(temp_path, overwrite=True)
        writer.write(content)
        with open(temp_path, 'rb') as f:
            assert f.read() == content.encode('utf-8')
        writer.write(content)
        with open(temp_path, 'rb') as f:
            assert f.read() == content.encode('utf-8') * 2



# Generated at 2022-06-22 18:19:34.720972
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    def compare_file_content(path, expected_content):
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        assert content == expected_content
    file_writer = FileWriter('testFileWriterWrite.txt', True)
    file_writer.write('123')
    compare_file_content('testFileWriterWrite.txt', '123')
    file_writer.write('\n123')
    compare_file_content('testFileWriterWrite.txt', '123\n123')
    file_writer.write('\n123')
    compare_file_content('testFileWriterWrite.txt', '123\n123\n123')
    # delete testing file
    os.remove('testFileWriterWrite.txt')
test_FileWriter_write()



# Generated at 2022-06-22 18:19:41.879797
# Unit test for constructor of class Tracer
def test_Tracer():
    output = mock.Mock()
    prefix = 'XXX '
    depth = 2
    watch = ('a',)
    watch_explode = ('b',)
    overwrite = True
    thread_info = True
    custom_repr = ((int, lambda x: 'Int: {}'.format(x)),)
    max_variable_length = 100
    normalize = False
    tracer = Tracer(
        output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr,
        max_variable_length, normalize,
    )
    assert tracer.watch == [CommonVariable('a'), Exploding('b')]
    assert tracer.write == output.write
    assert tracer.depth == 2
    assert tracer.prefix == prefix
    assert tracer.thread_info == thread_info

# Generated at 2022-06-22 18:19:47.986607
# Unit test for function get_local_reprs
def test_get_local_reprs():
    locals_ = {'a': 1, 'b': 2}
    frame = sys._getframe()
    frame.f_locals = locals_
    assert get_local_reprs(frame) == locals_

    frame.f_locals = {'a': 1, 'b': 2, 'x': 10}
    locals_['x'] = 10
    assert get_local_reprs(frame) == locals_


# Generated at 2022-06-22 18:19:52.372944
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def dummy_function(): pass
    frame = inspect.currentframe().f_back
    path_and_source = get_path_and_source_from_frame(frame)
    assert path_and_source[0] == __file__
    assert path_and_source[1] == UnavailableSource()



# Generated at 2022-06-22 18:20:00.570033
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        return a
    frame = utils.get_frame(f)

    assert get_local_reprs(frame) == {
        'a': '1'
    }

    assert get_local_reprs(frame, [CommonVariable('a')]) == {
        'a': '1'
    }

    assert get_local_reprs(frame, [CommonVariable('b')]) == {}

    assert get_local_reprs(get_frame(lambda a, b: None),
                           [CommonVariable('b')]) == {
        'b': '<unknown>'
    }



# Generated at 2022-06-22 18:20:09.210140
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer1 = pysnooper.Snooper(thread_info=True)
    tracer1.set_thread_info_padding("0-MainThread ")
    assert tracer1.thread_info_padding == 14
    tracer1.set_thread_info_padding("0-Thread2    ")
    assert tracer1.thread_info_padding == 14



# Generated at 2022-06-22 18:20:14.987187
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter('test', True)
    assert file_writer.path == 'test'
    assert file_writer.overwrite == True

    file_writer.write('hello')
    with open('test', 'r') as f:
        assert f.read() == 'hello'
    file_writer.write('world')
    with open('test', 'r') as f:
        assert f.read() == 'helloworld'
    os.remove('test')



# Generated at 2022-06-22 18:20:16.453242
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # FIXME
    assert False

# Generated at 2022-06-22 18:20:18.887542
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert False # TODO: implement your test here


# Generated at 2022-06-22 18:20:23.135106
# Unit test for method write of class Tracer
def test_Tracer_write():
    from io import StringIO
    f = StringIO()
    Tracer(f).write("test")
    assert f.getvalue()=="test\n", "Tracer.write() function not working"


# Generated at 2022-06-22 18:20:32.784490
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo():
        a = 'meow'  # line 1
        b = 'kitty'  # line 2
        c = 'meow'
        d = 'meow'
        e = 'meow'
        f = 'meow'
        g = 'meow'
        h = 'meow'
        i = 'meow'
        j = 'meow'
        k = 'meow'
        l = 'meow'
        m = 'meow'
        n = 'meow'
        return locals()

    frame = foo.__code__.co_filename, foo.__code__.co_firstlineno, foo.__code__.co_code, locals()
    frame = inspect.getframeinfo(frame)

# Generated at 2022-06-22 18:20:46.392765
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    def fn(a):
        return a + 1
    def fn2(a):
        raise Exception()
    def mock_write(s):
        return s
    t = Tracer(watch=('a',), watch_explode=None, output=None, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    t._write = mock_write
    t.trace(fn.__code__.__globals__['frame'], 'call', fn.__code__.co_consts[0])

    assert t.trace(fn.__code__.__globals__['frame'], 'line', fn.__code__.co_consts[0]) == t.trace
    assert t

# Generated at 2022-06-22 18:20:51.259072
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    from .test import assert_equal
    path = tempfile.mktemp()
    fw = FileWriter(path, True)
    fw.write('abcdefg')
    assert_equal(open(path).read(), 'abcdefg')



# Generated at 2022-06-22 18:21:00.410695
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_folder:
        path = os.path.join(temp_folder, 'test_file')
        file_writer = FileWriter(path, True)
        file_writer.write('Hello\n')
        file_writer.write('World!\n')
        with open(path) as f:
            assert f.read() == 'Hello\nWorld!\n'
        file_writer = FileWriter(path, False)
        file_writer.write('Hello again!\n')
        with open(path) as f:
            assert f.read() == 'Hello\nWorld!\nHello again!\n'



# Generated at 2022-06-22 18:21:06.779609
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # Make sure FileWriter.write doesn't delete file if overwrite = False
    import tempfile
    for overwrite in (True, False):
        with tempfile.NamedTemporaryFile(mode='w+b') as f:
            f.write('This is a test'.encode('utf-8'))
            f.flush()
            FileWriter(f.name, overwrite).write("Test")
            f.seek(0)
            assert f.read().decode('utf-8') == 'This is a testTest'


# Generated at 2022-06-22 18:21:18.802153
# Unit test for function get_write_function
def test_get_write_function():
    assert isinstance(get_write_function(None, None), collections.Callable)
    assert isinstance(get_write_function('abc.txt', None), collections.Callable)
    assert isinstance(get_write_function(open('abc.txt', 'w'), None), collections.Callable)
    assert isinstance(get_write_function(sys.stderr, None), collections.Callable)
    class CustomStream(object):
        def write(self, data):
            pass
    assert isinstance(get_write_function(CustomStream(), None), collections.Callable)
    class CustomStream2(object):
        def __init__(self, file_object):
            self.file_object = file_object
        def write(self, data):
            self.file_object.write(data)

# Generated at 2022-06-22 18:21:22.525318
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer.__enter__()
    assert tracer.__enter__() == None


# Generated at 2022-06-22 18:21:36.069659
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    new_snooper = Tracer()
    sample_calling_frame = inspect.currentframe().f_back

    # mocking function get_write_function
    sample_output = 'I/O'
    called_get_write_function_get_write_function_output, called_get_write_function_overwrite = None, None
    def mock_get_write_function(output, overwrite):
        nonlocal called_get_write_function_get_write_function_output, called_get_write_function_overwrite, sample_output
        called_get_write_function_get_write_function_output = 'I/O'
        called_get_write_function_overwrite = 'I/O'
        if output == 'I/O':
            return output
        if overwrite == 'I/O':
            return overwrite
       

# Generated at 2022-06-22 18:21:38.394198
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    function = lambda: None
    result = tracer(function)
    assert isinstance(result, function.__class__)


# Generated at 2022-06-22 18:21:41.670206
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_Tracer___call__.__tracebackhide__ = True
    pytest.fail("Not implemented")

# Generated at 2022-06-22 18:21:51.797086
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer(
        output='output.log',
        watch=['watch'],
        watch_explode=['watch_explode'],
        depth=1,
        prefix='prefix',
        overwrite=False,
        thread_info=False,
        custom_repr=(),
        max_variable_length=100,
        normalize=False,
        relative_time=False,
    )
    frame = inspect.currentframe()
    assert tracer.trace(frame, 'call', None) == tracer.trace
    assert tracer.trace(frame, 'call', None) == tracer.trace
    assert tracer.trace(frame, 'return', None) == tracer.trace
    assert tracer.trace(frame, 'exception', (TypeError, TypeError('test'), None)) == tracer.trace

# Generated at 2022-06-22 18:21:53.358469
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[0], str)



# Generated at 2022-06-22 18:21:57.179599
# Unit test for function get_write_function
def test_get_write_function():
    print('\nFile: test_write_function')
    # Test 1: standard output
    write_function = get_write_function(output=None, overwrite=False)
    write_function('Testing!')



# Generated at 2022-06-22 18:22:02.167062
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_frame = sys._getframe()
    path, source = get_path_and_source_from_frame(test_frame)
    assert path == __file__
    assert source[1] == '    test_frame = sys._getframe()'



# Generated at 2022-06-22 18:22:06.932605
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def a_function():
        return inspect.currentframe()
    frame = a_function()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert ''.join(source).strip() == ''.join(open(__file__, 'rb').read().splitlines()).strip()



# Generated at 2022-06-22 18:22:09.605346
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:22:14.192773
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(watch=('foo', 'list_variable'),
                watch_explode=('bar', 'dict_variable'),
                depth=1,
                prefix='*** ') as tracer:
        stack = tracer.thread_local.__dict__['original_trace_functions']
        assert stack == [None]
        assert tracer.depth == 1
        assert tracer.prefix == '*** '
        assert (tracer.watch ==
                [CommonVariable('foo'), CommonVariable('list_variable'),
                 Exploding('bar'), Exploding('dict_variable')])


# Closing over variables to let them be detected in the next test

# Generated at 2022-06-22 18:22:16.356475
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:22:27.638718
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer(sys.stdout)
    tracer.thread_info = False
    tracer.normalize = True
    tracer.relative_time = False
    tracer.thread_info_padding = 0
    tracer.last_source_path = None
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    class ___scope__():
        def __enter__(self):
            None
        def __exit__(self, type, value, traceback):
            None
    scope = ___scope__()
    scope.__enter__()