

# Generated at 2022-06-22 18:12:24.922816
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    thread_info = tracer.set_thread_info_padding("thread_info")
    assert thread_info == "thread_info           "

if __name__ == '__main__':
    ### Unit tests for the pysnooper class
    import pytest

    try:
        from unittest import mock
    except ImportError:
        import mock

    @pytest.fixture
    def sys_module_property_mocks(request, monkeypatch):
        '''
        Mocks the important properties of sys module.
        '''
        monkeypatch.setattr('sys.stderr', StringIO())
        monkeypatch.setattr('sys.stdout', StringIO())
        monkeypatch.setattr('sys.version_info', (3, 5))

# Generated at 2022-06-22 18:12:34.439158
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def _test(**kwargs):
        frame = inspect.currentframe()
        return get_local_reprs(frame, **kwargs)
    assert _test(watch=(), custom_repr=(), normalize=True) == {}
    assert _test(watch=[], custom_repr=(), normalize=True) == {}
    test_variable = CommonVariable('variable', 0, 1)
    assert _test(watch=test_variable, normalize=True) == {
        'variable': '1'
    }
    assert _test(watch=test_variable, normalize=False) == {
        'variable': '1'
    }
    assert _test(watch=(test_variable,), normalize=True) == {
        'variable': '1'
    }

# Generated at 2022-06-22 18:12:45.544479
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, False)
    assert callable(write)
    write = get_write_function('/tmp/a', False)
    assert callable(write)
    write = get_write_function('/tmp/a', True)
    assert callable(write)
    write = get_write_function(lambda x: None, False)
    assert callable(write)
    write = get_write_function(open('/tmp/a', 'w'), False)
    assert callable(write)
    with pycompat.raise_ub(TypeError):
        get_write_function('/tmp/a', False)
    class NonCallable(object): pass
    with pycompat.raise_ub(TypeError):
        get_write_function(NonCallable(), False)

# Generated at 2022-06-22 18:12:49.971120
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0]

try:
    CURRENT_WORK_DIRECTORY = os.getcwd().decode('utf-8')
except UnicodeDecodeError:
    print('Your current work directory seems to have a non-ASCII name, '
          'which is not supported by the debugger yet.')


# Generated at 2022-06-22 18:12:55.910323
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class A:
        def __init__(self):
            self.foo = True
        def bar(self):
            pass
    def foo():
        pass
    assert isinstance(Tracer()(A), type)
    assert isinstance(Tracer()(foo), functools.partial)


# Generated at 2022-06-22 18:13:04.305706
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    snoop = pysnooper.Snoop()
    def foo():
        pass
    
    foo = snoop(foo)
    assert foo.__name__ == 'foo'
    assert not pycompat.iscoroutinefunction(foo)
    assert not pycompat.isasyncgenfunction(foo)
    assert not inspect.isgeneratorfunction(foo)
    
    def bar(arg):
        return arg
    
    bar = snoop(bar)
    assert bar.__name__ == 'bar'
    assert not pycompat.iscoroutinefunction(bar)
    assert not pycompat.isasyncgenfunction(bar)
    assert not inspect.isgeneratorfunction(bar)
    
    def baz(arg):
        yield arg
    
    baz = snoop(baz)
    assert b

# Generated at 2022-06-22 18:13:07.389070
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()['whatever'] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:10.370480
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    u = UnavailableSource()
    assert u[0] == u'SOURCE IS UNAVAILABLE'
    try:
        u[1]
    except IndexError:
        pass


  

# Generated at 2022-06-22 18:13:17.469221
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    @pysnooper.snoop(prefix="ZZZ", depth=2)
    def test():
        print("test")

    @pysnooper.snoop(prefix="ZZZ", depth=4)
    def test2():
        print("ZZZ")

    @pysnooper.snoop(prefix="ZZZ", depth=5)
    def test5():
        print("ZZZ")


# Generated at 2022-06-22 18:13:26.281171
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    assert frame is not None  # This will fail if `cute_inspect.tests` is
                              # itself run with `cute_inspect` activated

    def _get_function_source(function):
        frame = inspect.currentframe()
        assert frame is not None
        filename, source_lines = (get_path_and_source_from_frame(frame))
        source_lines = source_lines[frame.f_lineno-1:]
        end = source_lines.index('')
        return '\n'.join(source_lines[:end])

    assert 'def test_get_path_and_source_from_frame():' in \
           _get_function_source(test_get_path_and_source_from_frame)



# Generated at 2022-06-22 18:13:36.075858
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # Test that `FileWriter.write` writes s to the file
    import tempfile
    try:
        with tempfile.NamedTemporaryFile() as temp_file:
            file_name = temp_file.name
            file_writer = FileWriter(file_name, True)
            file_writer.write('A')
            file_writer.write('B')
            file_writer.write('C')
            temp_file.flush()
            with open(file_name, 'r') as output_file:
                output = output_file.read()
        assert output == 'ABC'
    except IOError:
        # If py.test was started with the `-n` flag, the tempfile will be on a
        # different computer, and we can't write to it.
        pass



# Generated at 2022-06-22 18:13:47.009184
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    from mock import patch
    patch('threading.current_thread').start()
    patch('threading.Thread.getName').start()
    patch('threading.Thread.ident').start()
    t = Tracer()
    t.set_thread_info_padding("11-A")
    t.set_thread_info_padding("111-A")
    assert t.set_thread_info_padding("1-B") == "1-B      "
    assert t.set_thread_info_padding("11-B") == "11-B     "
    assert t.set_thread_info_padding("111-B") == "111-B    "



snoop = Tracer



# Generated at 2022-06-22 18:13:51.207898
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import testing_tools as testing_tools_module
    assert 'test_get_path_and_source_from_frame' in globals()
    assert get_path_and_source_from_frame(inspect.currentframe())[0] == testing_tools_module.__file__



# Generated at 2022-06-22 18:13:52.456087
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert True # TODO: implement your test here


# Generated at 2022-06-22 18:13:55.674998
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    if DISABLED:
        return
    trace = Tracer(output=None)
    trace.__enter__()
    trace.write('test')
    trace.__exit__(None, None, None)
    pass

# Generated at 2022-06-22 18:14:05.629817
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from .main import FileWriter, open_file_writer
    from .utils import TemporaryFolder
    from .pycompat import PathLike


    class Path(PathLike):
        def __init__(self, path):
            self.path = path

        def __fspath__(self):
            return self.path

    def test_ordinary():
        path = Path('tmp_file')
        fw = open_file_writer(path)
        assert fw is not None
        assert isinstance(fw, FileWriter)
        assert fw.overwrite

    def test_folder():
        with TemporaryFolder() as f:
            path = f.make_path('tmp_file')
            fw = open_file_writer(path)
            assert fw is not None
            assert isinstance(fw, FileWriter)
            assert not f

# Generated at 2022-06-22 18:14:11.861591
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    path = tempfile.mkdtemp() + '/test.txt'
    with open(path, 'w') as f:
        f.write('original content')
    FileWriter(path, overwrite=True).write('new content')
    with open(path, 'r') as f:
        assert f.read() == 'new content'
    FileWriter(path, overwrite=False).write('new content')
    with open(path, 'r') as f:
        assert f.read() == 'original content\nnew content'

# Generated at 2022-06-22 18:14:24.327737
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    import datetime
    from contextlib import redirect_stdout

    class FakeFile:
        def __init__(self):
            self.text = ''
        def write(self, text):
            self.text += text

    class FakeDateTime:
        def now(self):
            return datetime.datetime.now()
        def time(self):
            return datetime.datetime.now().time()

    f = FakeFile()
    with redirect_stdout(f):
        with Tracer(output=f) as p:
            pass
        with Tracer(output=f, thread_info=True) as p:
            pass
        with Tracer(output=f, normalize=True) as p:
            pass
        with Tracer(output=f, relative_time=True) as p:
            pass

# Generated at 2022-06-22 18:14:31.196122
# Unit test for constructor of class Tracer
def test_Tracer():
    # Necessary to make test self-contained
    def get_path_and_source_from_frame(frame):
        source = []
        path = frame.f_code.co_filename
        with TextIOWrapper(open(path, encoding='utf-8'), encoding='utf-8') as f:
            for line in f:
                source.append(line)
        return path, source

    def get_local_reprs(frame, watch, custom_repr, max_length, normalize):
        return {'foo': 'bar'}

    def get_write_function(output, overwrite):
        return lambda x: x

    class CustomVariable(object):

        def __init__(self, var_name):
            pass


# Generated at 2022-06-22 18:14:34.695687
# Unit test for constructor of class FileWriter
def test_FileWriter():
    temp_file = pycompat.temp_file()
    f = FileWriter(temp_file, False)
    assert f.path == temp_file
    assert f.overwrite == False


# Generated at 2022-06-22 18:14:40.591226
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[2] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[42] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[1000] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:47.248209
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import io
    import sys
    global test_Tracer___exit__
    if test_Tracer___exit__.__doc__ is None:
        test_Tracer___exit__.__doc__ = ""
    else:
        test_Tracer___exit__.__doc__ += "\n"
    test_Tracer___exit__.__doc__ += "    broken line: "
    test_Tracer___exit__.__doc__ += sys._getframe().f_code.co_filename
    test_Tracer___exit__.__doc__ += ":%d (test_Tracer___exit__)\n" % sys._getframe().f_lineno
    def test_func1(x):
        """doc1"""
        return x + 1

# Generated at 2022-06-22 18:14:54.954210
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # test thread_info not None
    tracer = Tracer(thread_info=True)
    thread_info = tracer.set_thread_info_padding('abc')
    assert thread_info == 'abc'
    thread_info = tracer.set_thread_info_padding('a')
    assert thread_info == 'a   '
    tracer = Tracer(thread_info=False)
    thread_info = tracer.set_thread_info_padding('abc')
    assert thread_info == ''

# Generated at 2022-06-22 18:15:01.850726
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    import sys

    # Given
    obj = Tracer("/dev/null")
    obj.write("hello")
    obj.write("world")
    # When
    output = sys.stdout
    sys.stdout = io.StringIO()
    obj.write("hello")
    output = sys.stdout.getvalue().strip()
    sys.stdout = output
    # Then
    assert(output == 'hello')



# Generated at 2022-06-22 18:15:08.013735
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import math, numpy as np
    local_reprs = get_local_reprs(inspect.currentframe())
    assert (local_reprs['math'] == utils.get_shortish_repr(math))
    assert (local_reprs['np'] == utils.get_shortish_repr(np))
    assert (local_reprs['test_get_local_reprs'] ==
            utils.get_shortish_repr(test_get_local_reprs))



# Generated at 2022-06-22 18:15:17.136050
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    (function_filename, function_source) = get_path_and_source_from_frame(
        inspect.currentframe())
    this_module = sys.modules[__name__]
    (module_filename, module_source) = get_path_and_source_from_frame(
        inspect.getmodule(this_module).__globals__)
    assert function_filename == __file__
    assert function_source == open(function_filename, 'rb').read().splitlines()

    assert module_filename == this_module.__file__
    expected_module_source = open(module_filename, 'rb').read().splitlines()
    assert module_source == expected_module_source



# Generated at 2022-06-22 18:15:18.736521
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0:10] == u'SOURCE IS U'



# Generated at 2022-06-22 18:15:30.353556
# Unit test for constructor of class FileWriter
def test_FileWriter():
    """
    Test constructor of class FileWriter.
    """

# Generated at 2022-06-22 18:15:39.814864
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    from time import time
    from time import sleep
    from time import time
    import filecmp
    import tempfile
    FILE_NAME = 'tempfile.txt'
    temp_folder = tempfile.mkdtemp()
    temp_file = os.path.join(temp_folder, FILE_NAME)
    content = 'hello world'
    def write_function(s):
        with open(temp_file, 'a') as f:
            f.write(s)
    write = get_write_function(temp_file, overwrite=False)
    write(content)
    sleep(0.1)
    write = get_write_function(temp_file, overwrite=True)
    write(content)
    with open(temp_file, 'r') as f:
        content_1 = f.read

# Generated at 2022-06-22 18:15:49.852252
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, overwrite=False) is sys.stderr.write
    assert get_write_function('foo', overwrite=False) is FileWriter(
        'foo', False).write
    file_writer = FileWriter('foo', True)
    assert get_write_function(file_writer.write, overwrite=False) is \
           file_writer.write
    import StringIO
    assert get_write_function(StringIO.StringIO(), overwrite=False) is \
           StringIO.StringIO().write

# Generated at 2022-06-22 18:16:02.170525
# Unit test for constructor of class FileWriter
def test_FileWriter():
    def check_FileWriter_overwrite(write, s, s_expected):
        write(s)
        with open('tmp.txt', 'r', encoding='utf-8') as f:
            s_actual = f.read()
        assert s_actual == s_expected, (s_actual, s_expected)

    s_expected = ''
    write = FileWriter('tmp.txt', overwrite=True)
    check_FileWriter_overwrite(write, 'first line\n', 'first line\n')
    write = FileWriter('tmp.txt', overwrite=False)
    check_FileWriter_overwrite(write, 'second line\n', 'first line\nsecond line\n')
    write = FileWriter('tmp.txt', overwrite=True)

# Generated at 2022-06-22 18:16:10.189797
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import sys
    import threading
    import traceback
    import unittest.mock

    @pysnooper.snoop()
    def f():
        pass

    m = unittest.mock.MagicMock()

# Generated at 2022-06-22 18:16:12.095992
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:16:22.280392
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import cool_python_lib
    import collections
    for key, value in get_local_reprs(frame=None).items():
        assert len(value) == 0
    for key, value in get_local_reprs(inspect.currentframe()).items():
        assert value[0] == '▪'
    cool_python_lib.get_type_names.number_of_calls = 0

# Generated at 2022-06-22 18:16:25.062070
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
	pysnooper.snoop('../tests/fixtures/test_watch_vars.py')
	__tracebackhide__ = True
	

# Generated at 2022-06-22 18:16:34.165469
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    from . import temp_file

# Generated at 2022-06-22 18:16:35.990988
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0] # Doesn't raise



# Generated at 2022-06-22 18:16:39.841252
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    snoop = Tracer(max_variable_length=100)
    __tracebackhide__ = True # hide from pytest traceback reporting
    def one():
        x = 3
        y = 4
    def two():
        one()
    with snoop:
        two()
    assert True # did not crash
test_Tracer_trace()


# Generated at 2022-06-22 18:16:44.112464
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # coverage: ignore
    t = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                                            prefix='', overwrite=False, thread_info=False, custom_repr=(),
                                            max_variable_length=100, normalize=False, relative_time=False)

    # coverage: ignore
    # coverage: include
    t.__enter__()

# Generated at 2022-06-22 18:16:55.784182
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import shutil
    from . import utils
    import pycompat

    def create_file(path, content):
        with open(path, 'w', encoding='utf-8') as output_file:
            output_file.write(content)

    if os.path.isfile('output1.txt'):
        os.remove('output1.txt')
    if os.path.isfile('output2.txt'):
        os.remove('output2.txt')

    test_content = 'test_FileWriter_write'
    file_writer = FileWriter('output1.txt', True)
    assert file_writer.overwrite is True
    file_writer.write(test_content)
    file_writer.write(test_content)

# Generated at 2022-06-22 18:16:57.943959
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    assert isinstance(tracer, Tracer)

    assert not DISABLED



# Generated at 2022-06-22 18:17:00.717479
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    try:
        source[0]
        assert False, "Didn't raise `IndexError`"
    except IndexError:
        pass



# Generated at 2022-06-22 18:17:04.302120
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    function_or_class = pysnooper.snoop()
    getting_local_reprs = function_or_class.__enter__()
    try:
        getting_local_reprs = None
        pass
    except:
        getting_local_reprs = None
        raise


# Generated at 2022-06-22 18:17:11.821917
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """Unit test for method trace of class Tracer"""
    import traceback
    from .utils import BaseVariable

    class Tracer:
        """This class contains tracing functions."""

        def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
                     prefix='', overwrite=False, thread_info=False, custom_repr=(),
                     max_variable_length=100, normalize=False, relative_time=False):
            self._write = get_write_function(output, overwrite)


# Generated at 2022-06-22 18:17:13.288312
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    file = tempfile.TemporaryFile()
    writer = FileWriter(file, True)
    writer.write('hello')



# Generated at 2022-06-22 18:17:15.157651
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-22 18:17:28.292806
# Unit test for function get_write_function
def test_get_write_function():
    class fake_file_object:
        def __init__(self):
            self.contents = []

        def write(self, s):
            self.contents.append(s)

    fake_file_object = fake_file_object()

    write_function = get_write_function(fake_file_object, overwrite=False)
    write_function(u'wee')
    assert fake_file_object.contents == [u'wee'], fake_file_object.contents

    write_function = get_write_function(u'wah', overwrite=True)
    write_function(u'wee')
    with open(u'wah') as f:
        assert f.read() == u'wee'
    os.remove(u'wah')

    write_function = get_write_function

# Generated at 2022-06-22 18:17:37.045161
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    class Tester:
        """
        Wrapper class so that tests can be written.
        """
        def __init__(self, max_len=30):
            self.max_len = max_len
        def test(self, thread_info):
            tracer = Tracer()
            tracer.thread_info = True
            tracer.thread_info_padding = self.max_len
            return tracer.set_thread_info_padding(thread_info)
    # Tests for Tracer on method set_thread_info_padding
    tester = Tester()
    assert tester.test('1-Thread1') == '1-Thread1'.ljust(tester.max_len)

# Generated at 2022-06-22 18:17:46.614544
# Unit test for constructor of class FileWriter
def test_FileWriter():
    new_line = '\n'
    output_string1 = new_line.join(['line1', 'line2', 'line3'])
    output_string2 = new_line.join([output_string1, 'line4', 'line5', 'line6'])
    path = 'test.txt'
    if os.path.isfile(path):
        os.remove(path)
    fileWriter = FileWriter(path, False)
    fileWriter.write(output_string1)
    fileWriter.write(output_string2)
    with open(path, 'r', encoding='utf-8') as test_file:
        content = test_file.read()
        assert content == output_string2
    if os.path.isfile(path):
        os.remove(path)



# Generated at 2022-06-22 18:17:57.796724
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    #
    # Tests for the enter method of class Tracer
    #
    # If a function decorator is found, skip lines until an actual
    # function definition is found
    #
    frame = frame_factory()
    frame.f_lineno = 1
    frame.f_code = MagicMock()
    frame.f_code.co_filename = 'filename'
    source = ['@pysnooper.snoop', 'def foo():']
    source = source_factory(source)
    frame.f_code.co_code = [x for x in source]
    self = MagicMock()

# Generated at 2022-06-22 18:18:00.677673
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:18:09.185173
# Unit test for constructor of class FileWriter
def test_FileWriter():
    def check_write(writer, s, *args):
        writer.write(s)
        path = writer.path
        with open(path, 'r', encoding='utf-8') as output_file:
            assert output_file.read() == s
    writer = FileWriter('test_FileWriter.txt', overwrite=True)
    check_write(writer, '1')
    check_write(writer, '2')
    writer = FileWriter('test_FileWriter.txt', overwrite=True)
    check_write(writer, '1')
    writer = FileWriter('test_FileWriter.txt', overwrite=False)
    check_write(writer, '2')
    os.remove('test_FileWriter.txt')



# Generated at 2022-06-22 18:18:12.556711
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    fw = FileWriter('temp.txt', True)
    fw.write('hello')
    import os
    assert open('temp.txt').read() == 'hello'
    os.remove('temp.txt')



# Generated at 2022-06-22 18:18:21.706826
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def dummy_function(a, b, c):
        return a * b * c
    frame = inspect.currentframe().f_back
    locals_ = frame.f_locals
    locals_.update(dict(a=1, b=2, c=3))
    variables = [CommonVariable('a'), CommonVariable('b'),
                 CommonVariable('c'), CommonVariable('d')]
    assert get_local_reprs(frame, variables) == {'a': '1',
                                                 'b': '2',
                                                 'c': '3',
                                                 'd': 'Exploding'}



# Generated at 2022-06-22 18:18:29.940193
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import os
    import pycompat
    import pycompat # pylint: disable=redefined-outer-name
    import utils
    import utils # pylint: disable=redefined-outer-name
    import pycompat
    import pycompat # pylint: disable=redefined-outer-name
    import inspect
    import inspect # pylint: disable=redefined-outer-name
    import threading
    import threading # pylint: disable=redefined-outer-name
    import functools
    import functools # pylint: disable=redefined-outer-name
    import pycompat
    import pycompat # pylint: disable=redefined-outer-name
    import pycompat
    import pycompat # pylint: disable=redefined-outer-name

# Generated at 2022-06-22 18:18:32.260837
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    x = UnavailableSource()
    assert x[0] == 'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:18:42.580909
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import os

    import sys
    import threading


    import re


# Generated at 2022-06-22 18:18:47.684950
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    if DISABLED:
        return
    # Test 1:
    tracer1 = Tracer(thread_info=True)
    current_thread = threading.current_thread()
    thread_info = "{ident}-{name} ".format(ident=current_thread.ident, name=current_thread.getName())
    thread_info1 = tracer1.set_thread_info_padding(thread_info)
    # Test 2:
    tracer2 = Tracer(thread_info=True)
    thread_info2 = tracer2.set_thread_info_padding(thread_info + 'X')
    # Test 3:
    tracer3 = Tracer(thread_info=True)
    current_thread = threading.current_thread()

# Generated at 2022-06-22 18:18:54.863522
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    thread_info = "Thread_2-main "
    padding = len("Thread_1-main ")
    tracer.thread_info_padding = padding
    assert tracer.set_thread_info_padding(thread_info) == thread_info.ljust(padding), "Test Failed"
    thread_info = "Thread_1-main "
    assert tracer.set_thread_info_padding(thread_info) == thread_info.ljust(padding), "Test Failed"

# Generated at 2022-06-22 18:19:01.848291
# Unit test for method write of class Tracer
def test_Tracer_write():
    try:
        from StringIO import StringIO as BytesIO
    except ImportError:
        from io import BytesIO
    file = BytesIO()
    tracer = Tracer(file)
    tracer.write('dafdf')
    assert file.getvalue() == 'dafdf\n'
    file = BytesIO()
    tracer = Tracer(file, prefix='hello')
    tracer.write('dafdf')
    assert file.getvalue() == 'hellodafdf\n'


# Generated at 2022-06-22 18:19:14.444384
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global DISABLED
    DISABLED = False

    class MockOverwrite(object):
        def __init__(self): pass
        def write(self, *args, **kw): pass
        def flush(self): pass

    class MockFunction(object):
        def __init__(self): pass
        def __call__(self, *args): pass

    class MockClass(object):
        def __init__(self): pass
        @staticmethod
        def func(): pass

    class MockClass2(object):
        def __init__(self): pass
        @property
        def prop(self): pass

    class MockClass3(object):
        def __init__(self): pass
        def __getattr__(self, attr): pass

    class MockClass4(object):
        def __init__(self): pass

# Generated at 2022-06-22 18:19:24.636041
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_function_name = 'test_function'
    test_function = lambda x:x+1
    def test_function_decorated(x):
        return x+1
    @snoop
    def test_function_decorated2(x):
        return x+1

    test_function_wrapped = Tracer()(test_function)
    test_function_decorated_wrapped = Tracer()(test_function_decorated)
    test_function_decorated2_wrapped = test_function_decorated2
    assert test_function.__name__ == test_function_name
    assert test_function_decorated.__name__ == test_function_name
    assert test_function_wrapped.__name__ == test_function_name
    assert test_function_decorated_

# Generated at 2022-06-22 18:19:31.799781
# Unit test for constructor of class Tracer
def test_Tracer():
    write = lambda s: sys.stdout.write(s.encode('utf-8'))

    @Tracer(output=write, watch='self', depth=2)
    def foo(obj, a, b):
        return a + b

    def bar():
        return foo(-1, 1, 2)

    bar()

if __name__ == '__main__':
    test_Tracer()

# vim: expandtab tabstop=4 shiftwidth=4 softtabstop=4

# Generated at 2022-06-22 18:19:40.103828
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = pysnooper.Tracer(output = None, watch = (), watch_explode = (), depth = 1, prefix = '', overwrite = False, thread_info = False, custom_repr = (), max_variable_length = 100, normalize = False, relative_time = False)
    assert tracer._write is None
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info is False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local
    assert tracer.custom_repr

# Generated at 2022-06-22 18:19:43.169044
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    doctest.run_docstring_examples(Tracer, globals(), optionflags=doctest.ELLIPSIS,)

# Generated at 2022-06-22 18:19:45.705946
# Unit test for constructor of class FileWriter
def test_FileWriter():
    f = FileWriter('a.txt', True)
    assert f.path == 'a.txt'
    assert f.overwrite == True



# Generated at 2022-06-22 18:19:49.682398
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  from pyquickhelper.pycode.pysnooper_helper import test_Tracer___call___engine
  return test_Tracer___call___engine(Tracer)


# Generated at 2022-06-22 18:19:55.338916
# Unit test for method write of class Tracer
def test_Tracer_write():
    with open('temp.txt', 'w') as f:
        tracer = Tracer(output=f)
    tracer.write('test')
    with open('temp.txt', 'r') as f:
        assert f.read() == 'test\n'
    os.remove('temp.txt')


# Generated at 2022-06-22 18:19:57.952992
# Unit test for method write of class Tracer
def test_Tracer_write():
    t = Tracer()
    t.write("Hola")
    print("Se supone que este mensaje no sale")
# test unitario para el metodo top level 

# Generated at 2022-06-22 18:20:06.014500
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import testing_tools
    get_path_and_source_from_frame.__globals__['__name__'] = 'test'
    get_path_and_source_from_frame.__globals__['__file__'] = 'testing.py'
    def f(x):
        pass
    frame = testing_tools.get_frame(f)
    path, source = get_path_and_source_from_frame(frame)
    assert path == os.path.realpath(__file__)
    assert source[2].startswith('def f(x):')
test_get_path_and_source_from_frame()



# Generated at 2022-06-22 18:20:16.277146
# Unit test for function get_write_function
def test_get_write_function():
    def write_to_string_builder(output, string_builder):
        write = get_write_function(output, None)
        write('Writing to string builder.')
    string_builder = pycompat.StringIO()
    write_to_string_builder(string_builder, string_builder)
    assert string_builder.getvalue() == 'Writing to string builder.'

    write_to_string_builder(None, string_builder)
    assert string_builder.getvalue() == \
           'Writing to string builder.'                             '\n'       \
           'Writing to string builder.'                             '\n'

    string_builder.seek(0)
    string_builder.truncate()
    write_to_string_builder('x', string_builder)

# Generated at 2022-06-22 18:20:23.887164
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    class DoubleClosing(object):
        def __init__(self):
            self.closed = False
        def __enter__(self):
            pass
        def __exit__(self, exc_type, exc_value, exc_traceback):
            if self.closed:
                raise Exception('expected only one call to __exit__')
            self.closed = True
    with DoubleClosing() as obj:
        pass

# Generated at 2022-06-22 18:20:32.089068
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[5] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-5] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[100] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-100] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:33.489700
# Unit test for method write of class Tracer
def test_Tracer_write():
    tr = Tracer()
    tr.write("hello")

# Generated at 2022-06-22 18:20:46.761597
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    def f1():
        pass
    def f2():
        pass

    def f3():
        pass
    def f4():
        pass
    f1 = f2
    f3 = f4
    tracer = pysnooper.Snooper().tracer
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert not tracer.thread_info
    assert tracer.thread_info_padding == 0
    assert tracer.__class__.__dict__.get('target_codes') is None
    assert tracer.__class__.__dict__.get('target_frames') is None
    assert tracer

# Generated at 2022-06-22 18:20:53.789245
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.thread_info_padding = 3
    assert tracer.set_thread_info_padding("1") == "1  "
    assert tracer.set_thread_info_padding("12") == "12 "
    assert tracer.set_thread_info_padding("123") == "123"
    assert tracer.set_thread_info_padding("1234") == "1234"
    assert tracer.thread_info_padding == 4


# Generated at 2022-06-22 18:20:56.167904
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-22 18:21:07.281791
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    temp_file = tempfile.mkstemp()[1]
    file_writer = FileWriter(temp_file, True)
    file_writer.write('test1')
    assert open(temp_file).read() == 'test1', 'Write method failed.'
    file_writer.write('test2')
    assert open(temp_file).read() == 'test2', 'Write method failed.'
    file_writer = FileWriter(temp_file, False)
    file_writer.write('test3')
    assert open(temp_file).read() == 'test2test3', 'Write method failed.'
    file_writer.write('test4')
    assert open(temp_file).read() == 'test2test3test4', 'Write method failed.'
    os.remove(temp_file)



# Generated at 2022-06-22 18:21:10.593407
# Unit test for constructor of class Tracer
def test_Tracer():
    Tracer()

if __name__ == '__main__':
    test_Tracer()

# Generated at 2022-06-22 18:21:14.490687
# Unit test for function get_write_function
def test_get_write_function():
    o = pycompat.BytesIO()
    assert callable(get_write_function(o, overwrite=None))


# Generated at 2022-06-22 18:21:27.166578
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from . import utils
    from . import opcode
    from .utils import C, N, S
    tracer = Tracer()
    tracer.depth = 0
    tracer.target_codes = {N('code object')}
    tracer.target_frames = set()
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.thread_local = C(__dict__={'original_trace_functions': [N('test_Tracer___enter__.<locals>')]})
    tracer.last_source_path = None
    tracer.max_variable_length = None
    tracer.normalize = False
    tracer.relative_time = False

# Generated at 2022-06-22 18:21:29.310936
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[4] == u'SOURCE IS UNAVAILABLE'


unavailable_source = UnavailableSource()



# Generated at 2022-06-22 18:21:37.061031
# Unit test for function get_write_function
def test_get_write_function():
    assert_raises(Exception, get_write_function, None, True)
    assert get_write_function(None, False)
    assert get_write_function(sys.stderr, False)
    assert callable(get_write_function(sys.stderr, False))
    assert callable(get_write_function(sys.stderr.write, False))
    assert callable(get_write_function(utils.WritableStream(sys.stderr), False))



# Generated at 2022-06-22 18:21:50.016409
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.watch = ['foo']
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.depth = 1
    tracer.prefix = ''
    tracer.thread_info = False
    tracer.thread_info_padding = 0
    assert tracer.depth >= 1
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.thread_local = threading.local()
    tracer.last_source_path = None
    tracer.max_variable_length = 100
    tracer.normalize = False
    tracer.relative_time = False
    
    
    tracer.trace_generator = test_Tracer__wrap_function_generator_wrapper()
   

# Generated at 2022-06-22 18:22:02.274007
# Unit test for function get_write_function
def test_get_write_function():
    test_file_name1 = 'test_file.txt'
    test_file_name2 = 'test_file2.txt'
    test_file_name3 = 'test_file3.txt'
    test_content = 'This is some test content.'

    if os.path.exists(test_file_name1):
        os.remove(test_file_name1)

    with open(test_file_name1, 'a') as f:
        write = get_write_function(f, overwrite=True)
        write(test_content)
    with open(test_file_name1, 'r') as f:
        assert f.read(len(test_content)) == test_content

    if os.path.exists(test_file_name2):
        os.remove(test_file_name2)

# Generated at 2022-06-22 18:22:02.999269
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  pass

# Generated at 2022-06-22 18:22:09.518000
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # test whether this method work when padding==0
    tracer = Tracer()
    thread_info = tracer.set_thread_info_padding("thread_info")
    assert(thread_info == "thread_info")
    # test whether this method work when padding!=0
    tracer = Tracer()
    thread_info = tracer.set_thread_info_padding("thread_info")
    thread_info = tracer.set_thread_info_padding("thread_info")
    assert(thread_info == "thread_info    ")


if __name__ == '__main__':
    test_Tracer_set_thread_info_padding()

# Generated at 2022-06-22 18:22:11.503906
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write('test')
    pass
test_Tracer_write()

# Generated at 2022-06-22 18:22:23.680848
# Unit test for constructor of class Tracer
def test_Tracer():
    log = StringIO()
    # Test default values
    s = Tracer(output=log)
    assert s.watch == tuple()
    assert s.depth == 1
    assert s.prefix == ''
    assert s.overwrite == False
    assert s.thread_info == False
    assert s.custom_repr == tuple()
    assert s.max_variable_length == 100
    assert s.normalize == False

    # Test non-default values
    s = Tracer(output=log, watch="watch", watch_explode="watch_explode",
               depth=2, prefix='prefix', overwrite=True,
               thread_info=True, custom_repr="custom_repr",
               max_variable_length=200, normalize=True)
    assert s.watch == ("watch",)
    assert s.depth == 2