

# Generated at 2022-06-22 18:12:38.364995
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)

    # Using default arguments
    # tracer = Tracer()
    # assert hasattr(tracer, '_write')

    # try:
    #     tracer = Tracer(output="out.log")
    #     assert hasattr(tracer, '_write')
    # except OSError:
    #     print("File Error: out.log")

    # Using a custom function for output
    import sys
    tracer = Tracer(output=sys.stdout.write)
    # assert hasattr(tracer, '_write')

    # Using a

# Generated at 2022-06-22 18:12:41.860675
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer(watch=['bar'], custom_repr=[(Type1, Type1.repr)])
    tracer.__enter__()
    assert_equals(tracer.frame_to_local_reprs, {})
    assert_equals(tracer.target_codes, set())
    assert_equals(tracer.target_frames, set())

# Generated at 2022-06-22 18:12:46.574255
# Unit test for constructor of class FileWriter
def test_FileWriter():
    content = u'Content'
    test_path = 'write_test.txt'
    try:
        FileWriter(test_path, overwrite = True).write(content)
        with open(test_path, 'r', encoding = 'utf-8') as test_file:
            test_file_content = test_file.read()
        assert content == test_file_content
    finally:
        os.remove(test_path)
    return True



# Generated at 2022-06-22 18:12:47.628539
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

"""
## Snoop
"""


# Generated at 2022-06-22 18:12:57.980667
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import sys
    from io import StringIO
    import os
    import tempfile
    from pysnooper import snoop, Tracer
    from .utils import get_path_and_source_from_frame

    snoop_sources_fn = os.path.join('tests', 'snoop_sources')

    def fn():
        a = 'example'
        return a

    #
    # Test when no file is passed to pysnooper.
    #

    # Test when no file is passed to pysnooper.
    tracer = Tracer()
    snooped_wrapper = tracer(fn)

    # Capture and verify output.
    stdout_backup = sys.stdout
    sys.stdout = output = StringIO()


# Generated at 2022-06-22 18:13:02.539403
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from .test_shit import assert_equal
    file_writer = FileWriter('test_path', True)
    assert_equal('test_path', file_writer.path)
    assert_equal(True, file_writer.overwrite)


# Generated at 2022-06-22 18:13:04.210544
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[0], str)



# Generated at 2022-06-22 18:13:10.507085
# Unit test for constructor of class Tracer
def test_Tracer():
    class Foo:
        def __init__(self, n):
            self.n = n

    custom_repr = (
        (Foo, lambda foo: 'Foo({foo.n})'.format(**locals())),
        (str, lambda s: 'str({s!r})'.format(**locals())),
    )

    def test_function(n):
        foo = Foo(n)
        return 'hello ' + foo.n

    tracer = Tracer(custom_repr=custom_repr, watch=('foo', 'n'))
    decorated = tracer(test_function)
    expected_decorated = '<function test_function at {}>'.format(
        hex(id(test_function))
    )
    assert str(decorated) == expected_decorated


# Generated at 2022-06-22 18:13:18.462990
# Unit test for method write of class Tracer
def test_Tracer_write():
    des = '''
    Write formatted string and a new line to output file
    '''
    output_file = 'test.out'
    prefix = '#'
    s = 'foo'
    tracer = Tracer(output=output_file)
    tracer.write(s)
    with open(output_file, 'r') as f:
        data = f.read()
        assert data=='#foo \n', 'Failed to write formatted string and a new line to output file'
    os.remove(output_file)


# Generated at 2022-06-22 18:13:23.432981
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    assert tracer.set_thread_info_padding('thread1') == 'thread1'
    assert tracer.set_thread_info_padding('thread2') == 'thread2   '
    tracer.thread_info_padding = 3 # set the padding to 3 manually
    assert tracer.set_thread_info_padding('thread1') == 'thread1   '

# Generated at 2022-06-22 18:13:28.508715
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer._is_internal_frame = lambda frame: True
    with tracer:
        pass
    tracer._is_internal_frame = lambda frame: False
    with utils.assert_raises(AssertionError):
        with tracer:
            pass

# Generated at 2022-06-22 18:13:31.371811
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer(output=None)

    with pytest.raises(KeyError):
        tracer.__exit__(None, None, None)


# Generated at 2022-06-22 18:13:39.826463
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from sys import gettrace
    from datetime import datetime
    from contextlib import closing
    obj = Tracer()
    # before context
    assert(gettrace() is None)
    assert(obj.start_times == {})
    assert(obj.target_frames == set())
    assert(obj.thread_local.__dict__ == {})
    # enter
    with obj:
        # inside context
        assert(gettrace() is obj.trace)
        frame = inspect.currentframe().f_back
        calling_frame = frame.f_back
        assert(obj.frame_to_local_reprs == {})
        assert(obj.start_times[calling_frame] <= datetime.now())
        assert(obj.target_frames == {calling_frame})

# Generated at 2022-06-22 18:13:44.948354
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter(path='./file_writer.txt', overwrite=True)
    assert file_writer.path == './file_writer.txt'
    assert file_writer.overwrite == True
    assert callable(file_writer.write)



# Generated at 2022-06-22 18:13:47.166296
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(sys.stderr, False)
    write(u'fuck')



# Generated at 2022-06-22 18:13:52.495686
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    path = get_unused_file_name()
    fw = FileWriter(path, True)
    fw.write(u'Hello world!')
    assert open(path, encoding='utf-8').read() == u'Hello world!'
    fw.write(u'Hello world again!')
    assert open(path, encoding='utf-8').read() == u'Hello world again!'
    os.unlink(path)


# Generated at 2022-06-22 18:14:03.897459
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pytest
    from .test_utils import assert_equal
    from .test_utils import expected_output
    @pysnooper.snoop()
    def func(a, b, c=1):
        return a, b, c
    func(1, 2, 3)
    with pytest.raises(ValueError):
        func(1, 2, c=3, d=4)
    try:
        func(1, 2, d=4)
    except TypeError:
        pass
    else:
        raise AssertionError()
    with pytest.raises(ZeroDivisionError):
        func(1, 2, 3)
        func(1, 2, c=3)
        1/0

# Generated at 2022-06-22 18:14:10.381615
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        variable_with_str_error = str
        variable_with_str_error()
    try:
        test_function()
    except Exception as e:
        _, _, tb = sys.exc_info()
        frame = tb.tb_frame
        path, source = get_path_and_source_from_frame(frame)
        assert path == frame.f_code.co_filename
        assert source[frame.f_lineno-1].strip() == \
               'variable_with_str_error()'
        assert source[frame.f_lineno].startswith('variable_with_str_error')



# Generated at 2022-06-22 18:14:17.433386
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper.trace_out import get_path_and_source_from_frame
    from pysnooper.local_vars import get_local_reprs
    from pysnooper.utils import get_shortish_repr
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.pycompat import pycompat
    import inspect
    import threading
    import functools
    import opcode
    import sys
    import datetime
    import itertools
    import os
    import traceback
    from pysnooper.watch_variables import watch_variables
   

# Generated at 2022-06-22 18:14:18.632936
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0]



# Generated at 2022-06-22 18:14:21.433325
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    assert source[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:29.815562
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys, os
    if sys.platform == 'win32':
        path = ""
    else:
        path = "/home/www-data/web2py"
    class DummyTracer:
        DISABLED = False
        prefix = ''
        max_variable_length = 100
        thread_info = False
        thread_info_padding = 0

# Generated at 2022-06-22 18:14:38.099187
# Unit test for function get_path_and_source_from_frame

# Generated at 2022-06-22 18:14:45.750793
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    import sys, os


    def check(func, source_lines):

        def get_lines_from_frame(frame):
            _, source_lines = get_path_and_source_from_frame(frame)
            return source_lines

        frame = sys._getframe().f_back # pylint: disable=protected-access

        assert func.__code__.co_filename == frame.f_code.co_filename
        assert get_lines_from_frame(frame) is source_lines

    def check_source_is_unavailable(func):
        def get_lines_from_frame(frame):
            _, source_lines = get_path_and_source_from_frame(frame)
            return source_lines

        frame = sys._getframe().f_back # pylint: disable=protected-access

# Generated at 2022-06-22 18:14:54.557570
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    from .utils import text_write_function
    from .utils import binary_write_function

    assert get_write_function(output=None, overwrite=False) == text_write_function(sys.stderr)
    assert get_write_function(output=None, overwrite=True) == text_write_function(sys.stderr)
    assert get_write_function(output=sys.stderr, overwrite=False) == text_write_function(sys.stderr)
    assert get_write_function(output=sys.stderr, overwrite=True) == text_write_function(sys.stderr)
    assert get_write_function(output=sys.stdout, overwrite=False) == text_write_function(sys.stdout)

# Generated at 2022-06-22 18:15:01.849855
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def print_locals(frame):
        for key, value in frame.f_locals.items():
            yield key, utils.get_shortish_repr(value)
    frame = utils.get_caller_frame()
    locals_result = dict(print_locals(frame.f_back))
    get_local_reprs_result = get_local_reprs(frame.f_back)
    assert locals_result == get_local_reprs_result


# Generated at 2022-06-22 18:15:05.851434
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io.StringIO()
    t = Tracer(output=output, watch=['foo'])
    with t:
        foo = 'bar'
        t.write('Test method write')

    assert output.getvalue().strip() == \
            'Test method write'



# Generated at 2022-06-22 18:15:16.530659
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def test_function(a, b, c, d, e, f_local, g_cellvar):
        f_local = 6
        g_cellvar = 8
        return locals()

    frame = utils.FakeFrame(test_function, {'a': 1, 'b': 2,
                                            'c': 3, 'd': 4,
                                            'e': 5, 'f': 6,
                                            'g': 7})
    result = get_local_reprs(frame)

# Generated at 2022-06-22 18:15:25.093201
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import pytest
    def custom_repr(x):
        return 'This is a custom repr for {}'.format(x)
    class MyClass(object):
        def __init__(self, x):
            self.x = x
        def __repr__(self):
            return 'MyClass(x=%r)' % self.x
    def f(a, b=17, *args, **kwargs):
        c = a + b
    # Test that watch works
    my_variable = CommonVariable(name='my_variable')
    watch = [my_variable]
    my_frame = f.__code__.co_firstlineno
    assert get_local_reprs(watch=watch) == {'my_variable': '{}'}

# Generated at 2022-06-22 18:15:27.166329
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:15:32.490088
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(max_variable_length=10)
    def f():
        pass
    assert Tracer(max_variable_length=10)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    import pytest
    pytest.main(args=['-v'])

# Generated at 2022-06-22 18:15:39.762251
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .utils import temp_file
    assert(not os.path.exists(temp_file))
    FileWriter(temp_file,True).write('test write')
    assert(os.path.exists(temp_file))

    with open(temp_file, 'r', encoding='utf-8') as f:
        assert(f.read() == 'test write')

    FileWriter(temp_file,True).write('additional test')
    with open(temp_file, 'r', encoding='utf-8') as f:
        assert(f.read() == 'additional test')

    os.remove(temp_file)



# Generated at 2022-06-22 18:15:43.960373
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    import sys

    s = io.StringIO()
    t = Tracer(s)
    t.write("test")
    out = s.getvalue()
    assert out == "test\n"


# Generated at 2022-06-22 18:15:48.016937
# Unit test for function get_local_reprs
def test_get_local_reprs():
    expected_output = {'a': '1'}
    def test_function(a):
        test_frame = inspect.currentframe()
        output = get_local_reprs(test_frame)
        assert output == expected_output
    test_function(1)



# Generated at 2022-06-22 18:15:55.748181
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    ### Testing Tracer.__enter__: ###########################################################################################################
    #                                                                                                                                       #
    def test_enter_without_Kwargs___If_DISABLED___Then_Tracer_does_nothing_returns_nothing():
        # Arrange:
        tracer = Tracer()
        # Act:
        actual = tracer.__enter__()
        # Assert:
        assert actual is None
    #                                                                                                                                       #
    def test_enter_with_Kwargs___If_DISABLED___Then_Tracer_does_nothing_returns_nothing():
        # Arrange:
        tracer = Tracer(None, None)
        # Act:
        actual = tracer.__enter__()
        # Assert:
        assert actual is None
    #                                

# Generated at 2022-06-22 18:16:04.179312
# Unit test for method write of class Tracer
def test_Tracer_write():
    '''
    Unit test for method write of class Tracer
    '''
    test_snoop = Tracer(watch=(), watch_explode=(), depth = 1, prefix = '',
                        overwrite = False, thread_info = False, 
                        custom_repr = (), max_variable_length = 100,
                        normalize = False, relative_time = False)
    assert isinstance(test_snoop, pysnooper.tracer.Tracer)
    test_snoop._write = None
    assert test_snoop.write('test') is None


# Generated at 2022-06-22 18:16:12.865541
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    s = 'test_FileWriter_write'
    write = FileWriter('test_FileWriter_write_file',True)
    write.write(s)
    with open('test_FileWriter_write_file', 'r') as f:
        assert f.read() == s
    write.write(s)
    with open('test_FileWriter_write_file', 'r') as f:
        assert f.read() == s + s
    os.remove('test_FileWriter_write_file')

#-------------------------------------------------------------------------------
### Alpha code: used for experimental purposes.


# Generated at 2022-06-22 18:16:22.648554
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import mock
    import pytest
    # Mock attributes and methods of classes


# Generated at 2022-06-22 18:16:24.574613
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    u = UnavailableSource()


# Generated at 2022-06-22 18:16:33.820852
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_writer = FileWriter('test_file_writer', False)
    file_writer.write('something')
    with open('test_file_writer', 'r') as f:
        lines = f.readlines()
    assert len(lines) == 1
    assert lines[0] == 'something'

    file_writer.write('something else')
    with open('test_file_writer', 'r') as f:
        lines = f.readlines()
    assert len(lines) == 2
    assert lines[0] == 'something'
    assert lines[1] == 'something else'

    file_writer.write('boom')
    with open('test_file_writer', 'r') as f:
        lines = f.readlines()
    assert len(lines) == 3
    assert lines[0] == 'something'


# Generated at 2022-06-22 18:16:36.886817
# Unit test for constructor of class FileWriter
def test_FileWriter():
    output_file = FileWriter('test_file', True)
    assert output_file.path == 'test_file'
    assert output_file.overwrite



# Generated at 2022-06-22 18:16:39.025459
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    output = []
    tracer = Tracer(output)
    tracer.__enter__()
    tracer.__exit__(None, None, None)
    return output

# Generated at 2022-06-22 18:16:46.614674
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from unittest.mock import Mock
    from unittest import TestCase
    tracer = Tracer()
    tracer.write = Mock()
    tracer.target_frames = set([1,2])
    tracer.start_times = {1: 100, 2: 200}
    tracer.frame_to_local_reprs = {1: 'aaaaaaaaaa', 2: 'bbbbbbbbbb'}
    tracer.__exit__(Exception, Exception("s"), None)
    assert tracer.write.call_args_list == [(' ' * 4 * 5 + 'Elapsed time: 0:00:00.000000\n',)]
    assert tracer.target_frames == set([])
    assert tracer.start_times == {2: 200}
    assert tracer.frame_to_local_repr

# Generated at 2022-06-22 18:16:58.142253
# Unit test for constructor of class Tracer
def test_Tracer():
    def f():
        pass
    watch = ('foo',)
    def custom_repr(x):
        return "custom!"

    s = Tracer(output='test_snoop.log', watch=watch, custom_repr=((list,
                custom_repr),), max_variable_length=2)
    assert s.watch == [CommonVariable('foo')]
    assert s.write == pycompat.print_
    assert s.target_codes == set([f.__code__])
    assert s.custom_repr == ((list, custom_repr),)
    assert s.max_variable_length == 2

    s = Tracer(output='test_snoop.log', watch_explode='foo')
    assert s.watch == [Exploding('foo')]


# Generated at 2022-06-22 18:17:08.570194
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    test_cases = [
        # Each test case is of the form (input, expected), where input is the input to method __call__ and expected is the expected output.
        (
            (
                'function_or_class',
            ),
            None,
        ),
    ]
    for args, expected in test_cases:
        with unittest.mock.patch('sys.stdout') as mock_stdout:
            actual = Tracer(*args)
            assert actual == expected, 'For input args=' + str(args) + ' the output was ' + str(actual) + ' which did not equal ' + str(expected) + '.'

# Generated at 2022-06-22 18:17:11.675218
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    a = FileWriter('output.txt', overwrite=True)
    a.write('ef')
    a.write('gh')

# Generated at 2022-06-22 18:17:21.313295
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  target = snoop.Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='',
                        overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100,
                        normalize=False, relative_time=False)
  target.watch = [v if isinstance(v, snoop.basevariable.BaseVariable)
                  else snoop.commonvariable.CommonVariable(v)
                  for v in utils.ensure_tuple(())
                 ] + [v if isinstance(v, snoop.basevariable.BaseVariable)
                      else snoop.exploding.Exploding(v)
                      for v in utils.ensure_tuple(())
                     ]
  target.frame_to_local_reprs = {}
  target.start_times = {}
 

# Generated at 2022-06-22 18:17:32.369926
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    # current_thread.ident = 0
    current_thread_id = threading.current_thread().ident
    current_thread_id = current_thread_id if current_thread_id else 0
    thread_info = "{}-{} ". format(current_thread_id, threading.current_thread().getName())
    # {}-{} is 8
    assert tracer.thread_info_padding == thread_info.__len__()
    tracer2 = Tracer(thread_info=True)
    # thread_ident 2
    thread2_info = "{}-{} ". format(2, threading.current_thread().getName())
    # padding of 2 is 8
    assert tracer2.thread_info_padding == thread_info.__len__()
   

# Generated at 2022-06-22 18:17:37.101125
# Unit test for constructor of class Tracer
def test_Tracer():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

DISABLED = False



# Generated at 2022-06-22 18:17:42.352914
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    source[0] = 3
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    source[-1] = 3
    assert source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:56.044731
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Tracer>Tracer.trace
    # called iff (DISABLED or (self._is_internal_frame(inspect.currentframe().f_back) or (frame in self.target_frames) or (frame.f_code in self.target_codes))) and (frame not in self.target_frames or (self.depth == 1))
    
    import pytest
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import mock_open
    
    _trace_return_value_p1 = MagicMock()
    _trace_return_value_p2 = MagicMock()
    _trace_return_value_p3 = MagicMock()
    _trace_return_value_p4 = MagicMock()
    _trace_return_value

# Generated at 2022-06-22 18:18:01.312096
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    for key in (1, '1', slice(1,2)):
        assert UnavailableSource()[key] == u'SOURCE IS UNAVAILABLE'
    assert list(iter(UnavailableSource())) == list(range(sys.maxsize))
    assert len(UnavailableSource()) == sys.maxsize


# Generated at 2022-06-22 18:18:09.443904
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        bar()

    def bar():
        baz()

# TODO: Write the actual unit tests.



# Generated at 2022-06-22 18:18:12.142020
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func():
        pass
    assert get_path_and_source_from_frame(frame=func.__code__.co_code)



# Generated at 2022-06-22 18:18:23.926501
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    # Ensure that we start with thread_info_padding as 0
    assert tracer.thread_info_padding == 0
    # Ensure that a set of strings with a common max length is padded
    assert tracer.set_thread_info_padding('123') == '123   '
    assert tracer.set_thread_info_padding('123') == '123   '
    assert tracer.set_thread_info_padding('12345') == '12345 '
    assert tracer.set_thread_info_padding('12345') == '12345 '
    assert tracer.set_thread_info_padding('12345') == '12345 '
    # Ensure that a set of strings with a common max length is not padded

# Generated at 2022-06-22 18:18:27.942590
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[2] == u'SOURCE IS UNAVAILABLE'
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:18:31.123695
# Unit test for function get_write_function
def test_get_write_function():
    assert callable(get_write_function(None, False))
    assert callable(get_write_function('', False))
    assert callable(get_write_function(sys.stderr, False))



# Generated at 2022-06-22 18:18:42.184883
# Unit test for method write of class Tracer
def test_Tracer_write():
    '''
    A function that unit tests the write method of class Tracer.
    '''
    tracer_object = Tracer()
    with captured_stdout() as output:
        tracer_object.write('foo')
    output = output.getvalue().rstrip().splitlines()
    assert output == ['    foo']
    with captured_stdout() as output:
        tracer_object = Tracer(output=sys.stdout,
                               prefix='Foo',
                               max_variable_length=None)
        tracer_object.write('foo')
    output = output.getvalue().rstrip().splitlines()
    assert output == ['Foo    foo']

# Generated at 2022-06-22 18:18:45.284086
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    snooper = pysnooper.Snooper(watch='')
    with snooper:
        sum(1 for i in range(4))
        for i in range(4): print(i)
        raise NameError

test_Tracer_trace()

# Demo of function Tracer.__call__(self, function_or_class)

# Generated at 2022-06-22 18:18:55.650007
# Unit test for function get_local_reprs
def test_get_local_reprs():
    class MyType:
        def __repr__(self):
            return 'tada!'
    my_type = MyType()
    assert get_local_reprs(sys._getframe(), custom_repr={MyType: "MyType"},
                           watch=[BaseVariable('my_type')]) == {
        'my_type': 'MyType'
    }
    assert get_local_reprs(sys._getframe(), custom_repr={MyType: "MyType"},
                           max_length=7,
                           watch=[BaseVariable('my_type')]) == {
        'my_type': '...da!'
    }

# Generated at 2022-06-22 18:18:58.387832
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    u = UnavailableSource()
    try:
        u[0]
    except:
        raise Exception("__getitem__ method of UnavailableSource class is not implemented")



# Generated at 2022-06-22 18:19:06.897824
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .utils import TemporaryDirectory
    import time
    with TemporaryDirectory() as temp_dir:
        temp_file = temp_dir / 'temp_file'
        file_writer = FileWriter(temp_file, False)
        file_writer.write('My message.')
        time.sleep(0.1)
        assert open(temp_file, 'r').read() == 'My message.'
        file_writer.write('My second message.')
        time.sleep(0.1)
        assert open(temp_file, 'r').read() == 'My message.My second message.'
        file_writer = FileWriter(temp_file, True)
        file_writer.write('My third message.')
        time.sleep(0.1)
        assert open(temp_file, 'r').read() == 'My third message.'




# Generated at 2022-06-22 18:19:10.875464
# Unit test for method write of class Tracer
def test_Tracer_write():
    file_like = io.StringIO()
    tracer = Tracer(file_like)
    tracer.write('abc')
    assert file_like.getvalue() == 'abc\n'
test_Tracer_write()

# Generated at 2022-06-22 18:19:15.691214
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[5] == u'SOURCE IS UNAVAILABLE'
    assert uas[-7] == u'SOURCE IS UNAVAILABLE'
    assert uas[0] == u'SOURCE IS UNAVAILABLE'
    assert uas[-11] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:19:26.876520
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    class MockedTracer(Tracer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.thread_info_padding = 0

    tracer = MockedTracer(thread_info=True)
    for i in range(10):
        thread_info = tracer.set_thread_info_padding("-MainThread-")
        assert thread_info == "-MainThread-".ljust(len("-MainThread-"))
    for i in range(10):
        thread_info = tracer.set_thread_info_padding("-Thread-1-")
        assert thread_info == "-Thread-1-".ljust(len("-MainThread-"))
    for i in range(10):
        thread_info = tracer.set_thread_info_

# Generated at 2022-06-22 18:19:36.973591
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    @pysnooper.snoop()
    def test_method():
        a = 1
        return a
    a = test_method
    T = Tracer()
    def t():
        a = 1
        T.trace(1,1,1)
        return a
    t()
    # write test
    T.write("test_write")
    # set_thread_info_padding test
    thread_info = T.set_thread_info_padding("test_thread_info")
    # _is_internal_frame
    assert T._is_internal_frame(1) == False
    # test for __init__

# Generated at 2022-06-22 18:19:43.017436
# Unit test for method write of class Tracer
def test_Tracer_write():
    Tracer.write(Tracer,u'What is Lorem Ipsum?')
    Tracer.write(Tracer,u'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.')

test_Tracer_write()



# Generated at 2022-06-22 18:19:45.386531
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource().__getitem__(0) == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:19:53.151891
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    path1 = os.path.join(tempfile.gettempdir(), "test_FileWriter.txt")
    path2 = os.path.join(tempfile.gettempdir(), "test_FileWriter2.txt")
    fio = FileWriter(path1, True)
    fio.write('test')
    fio = FileWriter(path1, False)
    fio.write('test_append')
    fio = FileWriter(path2, True)
    fio.write('test_new_file')


# Generated at 2022-06-22 18:19:55.148391
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:19:58.681934
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper.snoop import Tracer
    tracer = Tracer()
    def func():
        pass
    assert callable(tracer.__call__(func))
test_Tracer___call__()


# Generated at 2022-06-22 18:20:02.308675
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer_instance = Tracer(output='test.log')
    tracer_instance.write('test')
    with open('test.log') as f:
        actual_string = f.read()
    os.remove('test.log')
    return assert_equals(actual_string, 'test\n')

# Generated at 2022-06-22 18:20:15.120877
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    class MockFileObject(pycompat.Mock):
        def write(self, s):
            pass
    file_object = MockFileObject()

    # If the path is not exist and overwrite is True,
    # then this file will be created
    file_writer = FileWriter("path_not_exist", True)
    file_writer.write("hello")
    # If the file is already created and overwrite is True,
    # then the content will be overwritten in the existing file
    file_writer.write("world")
    file_writer.write("!!")
    # If the file is already created and overwrite is False,
    # then the content will be appended in the existing file
    file_writer_1 = FileWriter("path_not_exist", False)
    file_writer_1.write("hello")
    file_writer_1

# Generated at 2022-06-22 18:20:27.196306
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.thread_info_padding == 0
    assert tracer.set_thread_info_padding("") == "          "
    assert tracer.thread_info_padding == 10
    assert tracer.set_thread_info_padding("") == "          "
    assert tracer.thread_info_padding == 10
    assert tracer.set_thread_info_padding("1-T1 ") == "1-T1     "
    assert tracer.thread_info_padding == 10
    assert tracer.set_thread_info_padding("12345-T1 ") == "12345-T1 "
    assert tracer.thread_info_padding == 10

# Generated at 2022-06-22 18:20:30.047758
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:34.474766
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    for i in range(1, 100):
        thread_info = tracer.set_thread_info_padding(str(i))
        assert len(thread_info) == tracer.thread_info_padding
        if i != 99:
            assert thread_info[-1] == " "


# Generated at 2022-06-22 18:20:46.013591
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    @snoop
    def foo():
        x = 1234
        y = 5678
        y = 6789
        return y

    out = []
    foo.snooper._write = out.append
    foo()

    actual = ''.join(out)
    expected = """\
    Starting var:.. x = 1234
    New var:....... y = 5678
    Modified var:.. y = 6789
    Return value:.. 6789
    Elapsed time: 0:00:00
"""
    assert actual == expected, '%r != %r' % (actual, expected)

Tracer.__call__.__test__ = False # to avoid nose to execute it as a test


# Generated at 2022-06-22 18:20:52.161577
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io.StringIO()
    prefix = "zzz"
    normalize = True
    with Tracer(output, normalize=normalize, prefix=prefix) as tracer:
        tracer.write("test_message")
    assert output.getvalue() == "zzztest_message\n"


# Generated at 2022-06-22 18:20:57.207886
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs(None) == {}
    def f(a):
        a += 1
        b = 2
        return a
    frame = inspect.currentframe()
    frame = frame.f_back.f_back
    assert get_local_reprs(frame) == {'a': '3', 'b': '2'}
test_get_local_reprs()



# Generated at 2022-06-22 18:20:59.099443
# Unit test for method __call__ of class Tracer

# Generated at 2022-06-22 18:21:10.323449
# Unit test for function get_write_function
def test_get_write_function():
    import inspect
    assert inspect.isfunction(get_write_function(None, True))
    assert inspect.isfunction(get_write_function(None, False))
    assert inspect.isfunction(get_write_function(lambda s: None, True))
    assert inspect.isfunction(get_write_function(lambda s: None, False))
    assert inspect.isfunction(get_write_function(open(__file__, 'w'), True))
    assert inspect.isfunction(get_write_function(open(__file__, 'w'), False))
    assert inspect.isfunction(get_write_function(sys.stderr, True))
    assert inspect.isfunction(get_write_function(sys.stderr, False))

# Generated at 2022-06-22 18:21:13.728325
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[:] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:21:22.935300
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    from pysnooper import snoop, thread_global
    thread_global.depth = 0
    @snoop(thread_info=True)
    def f(x):
        pass
    f(1)
    thread_global.depth = 1
    @snoop(thread_info=True)
    def g(x):
        pass
    g(2)
    
    

# Generated at 2022-06-22 18:21:36.156965
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import tempfile
    import os

    def run_test(lines):
        lines = list(lines)
        line1 = lines[0]
        if not line1.startswith('#'):
            lines.insert(0, '# -*- coding: utf-8 -*-')
            line2 = lines[1]
            if not line2.startswith('#'):
                lines.insert(1, '#')
        path = tempfile.NamedTemporaryFile(suffix='.py').name
        with open(path, 'w', encoding='utf-8') as f:
            for line in lines:
                f.write(line + os.linesep)
        frame = inspect.currentframe()
        return get_path_and_source_from_frame(frame)


# Generated at 2022-06-22 18:21:42.707742
# Unit test for method write of class FileWriter

# Generated at 2022-06-22 18:21:52.641703
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import io
    import pycompat
    import os
    import pathlib
    content = 'content'
    def get_content(p):
        with open(p, 'r', encoding='utf8') as f:
            return f.read().strip()

# Generated at 2022-06-22 18:21:56.177345
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test_function():
        @pysnooper.snoop()
        def _inner():
            pass
        _inner()
    test_function()


# Generated at 2022-06-22 18:21:59.567193
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable = UnavailableSource()
    available = [1, 2, 3]
    assert unavailable[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable[0:1] == u'SOURCE IS UNAVAILABLE'
    assert (unavailable[0:1] ==
            unavailable[0:1] ==
            unavailable[0] == u'SOURCE IS UNAVAILABLE')
    assert unavailable == UnavailableSource()
    assert available == [1, 2, 3]
    assert unavailable is not UnavailableSource()
    assert unavailable != '    '
    assert unavailable != [1, 2, 3]
    assert available != unavailable



# Generated at 2022-06-22 18:22:04.776174
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding("a") == "a".ljust(1)
    assert tracer.set_thread_info_padding("123") == "123".ljust(3)

    tracer.thread_info_padding = 3
    assert tracer.set_thread_info_padding("1") == "1".ljust(3)
    assert tracer.set_thread_info_padding("123") == "123".ljust(3)

    tracer.thread_info_padding = 5
    assert tracer.set_thread_info_padding("1") == "1".ljust(5)
    assert tracer.set_thread_info_padding("123") == "123".ljust(5)    
    
    
    
    
    


# Generated at 2022-06-22 18:22:10.842883
# Unit test for constructor of class FileWriter
def test_FileWriter():
    fw = FileWriter('/tmp/some_file', False)
    assert isinstance(fw, FileWriter)
    assert fw.path == '/tmp/some_file'
    assert fw.overwrite == False


# Generated at 2022-06-22 18:22:23.267812
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True, output=False)
    assert tracer.thread_info_padding == 0
    current_thread = threading.current_thread()

    thread_info = "{ident}-{name} ".format(ident=current_thread.ident, name=current_thread.getName())
    thread_info = tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == 0

    thread_info = "{ident}-{name}".format(ident=current_thread.ident, name=current_thread.getName())
    thread_info = tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == 1