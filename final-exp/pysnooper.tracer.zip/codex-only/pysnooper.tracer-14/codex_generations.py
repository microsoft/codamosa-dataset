

# Generated at 2022-06-22 18:12:33.261079
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[11] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:12:35.953850
# Unit test for constructor of class FileWriter
def test_FileWriter():
    FileWriter('test/test_FileWriter/', True).write('test')
    with open('test/test_FileWriter/', 'r') as f:
        s = f.read()
        assert s == 'test'



# Generated at 2022-06-22 18:12:37.392494
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:12:38.185455
# Unit test for constructor of class Tracer
def test_Tracer():
    print('Starting test_Tracer()')



# Generated at 2022-06-22 18:12:41.414316
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from nose.tools import assert_equal
    tracer = Tracer()
    tracer.watch = [ "test" ]
    tracer.write = lambda s: print(s)
    frame = FrameType(
        f_globals = {
            "test": 1
        }
    )
    tracer.trace(frame, "line", 1)


# Generated at 2022-06-22 18:12:46.519236
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    with mock.patch.object(utils,'files',{'/test.py':['1','2','3','4']}):
        output = six.moves.StringIO()
        snoop = Tracer(output)
        thread_info = snoop.set_thread_info_padding("MainThread-0")
        expected_thread_info = "MainThread-0".ljust(len("MainThread-0 "))
        assert thread_info == expected_thread_info
        thread_info = snoop.set_thread_info_padding("MainThread-1")
        expected_thread_info = "MainThread-1".ljust(len("MainThread-0 "))
        assert thread_info == expected_thread_info


# Generated at 2022-06-22 18:12:47.567019
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    obj = Tracer()
    isinstance(obj, Tracer)



# Generated at 2022-06-22 18:12:51.755131
# Unit test for constructor of class FileWriter
def test_FileWriter():
    test_path = 'test_path'
    test_overwrite = True
    test_write_function = FileWriter(test_path, test_overwrite)
    assert isinstance(test_write_function, FileWriter)
    assert test_write_function.path == test_path
    assert test_write_function.overwrite == test_overwrite


# Generated at 2022-06-22 18:13:01.661460
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    '''test_Tracer_set_thread_info_padding

    Tests set_thread_info_padding
    '''
    tracer = Tracer()

    # Test that the thread_info_padding is adjusted to
    # the length of the longest thread_info
    thread_info1 = tracer.set_thread_info_padding('1-abc')
    thread_info2 = tracer.set_thread_info_padding('2-xyz')
    thread_info3 = tracer.set_thread_info_padding('3-a')
    thread_info4 = tracer.set_thread_info_padding('4-xy')

    assert (thread_info1 == '1-abc ')
    assert (thread_info2 == '2-xyz ')
    assert (thread_info3 == '3-a   ')


# Generated at 2022-06-22 18:13:04.376728
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:10.733016
# Unit test for method set_thread_info_padding of class Tracer

# Generated at 2022-06-22 18:13:14.903966
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    test_write = io.StringIO()
    tracer = Tracer(test_write)
    tracer.write('aaa')
    assert test_write.getvalue() == 'aaa\n'
test_Tracer_write()


# Generated at 2022-06-22 18:13:16.962679
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:26.072747
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper.tracer import BaseVariable, CommonVariable, Watch
    from pysnooper.tracer import DISABLED, Tracer

    # @pytest.fixture
    # def class_var():
    #     return BaseVariable()

    # @pytest.fixture
    # def common_var():
    #     return CommonVariable()

    # @pytest.fixture
    # def depth():
    #     return 1

    # @pytest.fixture
    # def function_or_class():
    #     return BaseVariable()

    # @pytest.fixture
    # def output():
    #     return BaseVariable()

    # @pytest.fixture
    # def prefix():
    #     return BaseVariable()

    # @pytest.fixture
    # def watch():


# Generated at 2022-06-22 18:13:29.064870
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert eval(compile('get_local_reprs(locals())', '<string>', 'single')) == get_local_reprs(locals(), ())



# Generated at 2022-06-22 18:13:34.086954
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from .testing.test_common import write_to_string
    fs = FileWriter('test.txt', True)
    assert isinstance(fs.path, pycompat.text_type)
    fs.write('17')
    with open('test.txt', 'r') as f:
        result = f.read()
    assert result == '17'



# Generated at 2022-06-22 18:13:41.511609
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import pysnooper
    import inspect
    import os.path
    import pysnooper
    import inspect
    import os.path

    def test_Tracer_trace():
        from _pysnooper import utils
        import sys
        import pysnooper
        import inspect
        import os.path

        def test_Tracer_trace():
            from _pysnooper import utils
            import sys
            import pysnooper
            import inspect
            import os.path

            def test_Tracer_trace():
                from _pysnooper import utils
                import sys
                import pysnooper
                import inspect
                import os.path

                def test_Tracer_trace():
                    from _pysnooper import utils
                    import sys
                    import pysnooper
                    import inspect

# Generated at 2022-06-22 18:13:53.320862
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import tempfile
    
    def make_file(content):
        with open(path, 'wb') as f:
            f.write(content.encode('utf-8'))

    def diff(a, b):
        return list(collections.OrderedDict.fromkeys(a).symmetric_difference(b))


# Generated at 2022-06-22 18:14:04.985998
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import pytest
    from io import StringIO
    from pysnooper.snoop import Tracer
    from pysnooper.utils import get_write_function
    output = StringIO()
    write = get_write_function(output)
    tracer = Tracer()
    assert tracer.thread_info_padding == 0
    thread_info = tracer.set_thread_info_padding('0-0')
    assert thread_info == '0-0'
    assert tracer.thread_info_padding == 3
    thread_info = tracer.set_thread_info_padding('0000-0')
    assert thread_info == '0000-0'
    assert tracer.thread_info_padding == 7
    thread_info = tracer.set_thread_info_padding('000-00000000000000')
    assert thread_

# Generated at 2022-06-22 18:14:06.986402
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:14:13.847702
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_path = os.path.join(os.path.dirname(__file__), 'test.py')
    with open(test_path, 'rb') as test_file:
        test_source = test_file.read()
    frame = utils.get_frame_from_function(lambda: 1)
    frame.f_code.co_filename = test_path
    path, source = get_path_and_source_from_frame(frame)
    assert path == test_path
    assert source == [pycompat.text_type(x, 'utf-8') for x in
                      test_source.splitlines()]



# Generated at 2022-06-22 18:14:19.998163
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[None] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[999] == u'SOURCE IS UNAVAILABLE'
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:14:27.523990
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path, source = get_path_and_source_from_frame(sys._getframe())
    out_path = path.strip('.py') + '_out.txt'
    writer = FileWriter(out_path, True)
    writer.write(source)
    writer.write(source)
    try:
        with open(out_path, 'r', encoding='utf-8') as f:
            first_contents = f.read()
            assert first_contents == source
    finally:
        os.remove(out_path)

test_FileWriter()



# Generated at 2022-06-22 18:14:37.715817
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    with utils.TempFolder() as temp_folder:
        test_file_path = temp_folder.path / 'test_file.txt'
        test_file_writer = FileWriter(test_file_path, overwrite=True)
        test_file_writer.write('abc')
        with open(test_file_path, 'r') as test_file:
            assert test_file.read() == 'abc'
        test_file_writer.write('def')
        with open(test_file_path, 'r') as test_file:
            assert test_file.read() == 'def'
test_FileWriter_write()



# Generated at 2022-06-22 18:14:40.913956
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    # `test_UnavailableSource___getitem__` is annotated with `@patch(...)` on
    # `Debugger.py`, because it fails in that class.
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[256] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:43.102099
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    @pysnooper.snoop()
    def Foo():
        try:
            return 1
        except Exception as e:
            return e
    

# Generated at 2022-06-22 18:14:54.361578
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = 'hello'
        z = 42
        w = {'a': 'b'}
        v = classmethod(lambda cls: None)
        print('hi')
        import sys
        import io
        return locals()
    x = 42
    y = 'hello'
    locals_dict = f(x)
    frame = inspect.getouterframes(inspect.currentframe())[1][0]
    assert get_local_reprs(frame, normalize=True) == {
        'x': '42',
        'y': 'hello',
        'z': '42',
        'w': '{\'a\': \'b\'}',
        'v': 'classmethod',
    }



# Generated at 2022-06-22 18:15:00.197968
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return inspect.currentframe()
    frame = f()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0].startswith(
        u'from .get_path_and_source_from_frame import test_get_path_and_source_from_frame'
    )

# Generated at 2022-06-22 18:15:02.540420
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert (list(UnavailableSource()[:10]) ==
            [u'SOURCE IS UNAVAILABLE'] * 10)


# Generated at 2022-06-22 18:15:07.771518
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    s = UnavailableSource()
    assert s[0] == u'SOURCE IS UNAVAILABLE'
    assert s[2] == u'SOURCE IS UNAVAILABLE'
    assert len(s) == float('inf')
    assert sys.version_info[0] == 2 or isinstance(s[0], str)



# Generated at 2022-06-22 18:15:09.143167
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[2] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:15:13.563609
# Unit test for method write of class Tracer
def test_Tracer_write():
    '''
    Test that we can write something to the console.
    '''
    try:
        output = io.StringIO()
        tracer = Tracer(output=output)
        tracer.write('hello from write')
        assert output.getvalue() == 'hello from write\n'
    except Exception as e:
        raise e


# Generated at 2022-06-22 18:15:21.058838
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.set_thread_info_padding("999-Thread 1")
    assert tracer.thread_info_padding == len("999-Thread 1")
    tracer.set_thread_info_padding("9-T1")
    assert tracer.thread_info_padding == len("999-Thread 1")
    tracer.set_thread_info_padding("999-Thread 123")
    assert tracer.thread_info_padding == len("999-Thread 123")

# Generated at 2022-06-22 18:15:32.705704
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    try:
        import pysnooper_b85fa8b8fa9b4de9b9f3
        print("pysnooper imported successfully")
        #pysnooper_b85fa8b8fa9b4de9b9f3.DISABLED = True
    except:
        pass
    # Test Set 1
    # Call the __exit__ method of Tracer
    tracer = pysnooper_b85fa8b8fa9b4de9b9f3.Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    tracer.__exit__(false, false, false)
    #pysno

# Generated at 2022-06-22 18:15:36.886232
# Unit test for constructor of class Tracer
def test_Tracer():
    f = lambda: None
    Tracer(watch="a")
    Tracer(depth=2)
    Tracer(prefix="a")
    Tracer(overwrite=True)
    Tracer(thread_info=True)
    Tracer(watch=(1, 2))
    Tracer(watch_explode=f)


# Generated at 2022-06-22 18:15:44.577512
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # See comments in the code above
    from pysnooper import snoop
    from pysnooper.variables import CommonVariable, Exploding

    # Initializes the parameter of method trace for unit test
    snooper = snoop(watch=('foo', 'self'),
                    custom_repr=(),
                    depth=3,
                    normalize=True)
    frame = inspect.currentframe()
    frame.f_globals = frame.f_globals = frame.f_code = frame.f_trace = None
    thread_global.depth = 0
    # We need to mock the following 
    # frame.f_code = frame.f_trace = frame.f_globals = frame.f_locals = None
    # thread_global.depth = 0
    frame_to_local_reprs = {}


# Generated at 2022-06-22 18:15:53.299111
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():

    class Tracer:
        def __init__(self, output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False):
            self.output = output
            self.watch = watch
            self.watch_explode = watch_explode
            self.depth = depth
            self.prefix = prefix
            self.overwrite = overwrite
            self.thread_info = thread_info
            self.custom_repr = custom_repr
            self.max_variable_length = max_variable_length
            self.normalize = normalize
            self.relative_time = relative_time


# Generated at 2022-06-22 18:16:02.032914
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    path = tempfile.mkdtemp()
    writer = FileWriter(path + '/file', False)
    writer.write('Hello')
    writer.write('World')
    writer.write('Again')
    writer = FileWriter(path + '/file', True)
    writer.write('Hello')
    writer.write('World')
    writer.write('Again')
    with open(path + '/file') as file:
        assert file.read() == 'HelloWorldAgain'
    with open(path + '/file') as file:
        assert file.read() == 'HelloWorldAgain'



# Generated at 2022-06-22 18:16:10.066420
# Unit test for function get_write_function
def test_get_write_function():
    try:
        bad_write_function = get_write_function(None, overwrite=True)
    except Exception:
        pass
    else:
        raise AssertionError('get_write_function did not raise exception when '
                             'called with overwrite=True and output=None')
    write_to_stderr = get_write_function(None, overwrite=False)
    write_to_file = get_write_function(os.path.join(os.path.dirname(
        __file__), '.debugger_write_test_file.txt'), overwrite=True)
    write_to_file(u'hello')

# Generated at 2022-06-22 18:16:21.122507
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    from . import pycompat
    from .utils import normalize_repr
    from .variables import Literal
    from .api import state_is_tracing

    assert state_is_tracing() == False
    assert normalize_repr(str(datetime_module.datetime.now())) in \
           normalize_repr(test_FileWriter_write.__doc__)

    assert not os.path.exists('test_FileWriter_write.txt')
    if pycompat.PY2:
        output = 'test_FileWriter_write.txt'
        writer = FileWriter(output, overwrite=True)
        writer.write(u"הענקר")
        writer.write(u"קנפרות")

# Generated at 2022-06-22 18:16:22.212512
# Unit test for method write of class Tracer
def test_Tracer_write():
    assert True

# Generated at 2022-06-22 18:16:30.166066
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    snoop = pysnooper.Snooper(thread_info=True, normalize=True)
    thread1_info = '11-ThreadA '
    thread2_info = '22-ThreadB '

    assert snoop.set_thread_info_padding(thread1_info) == thread1_info
    assert snoop.set_thread_info_padding(thread2_info) == \
           thread2_info + thread1_info.replace(thread1_info, '')


# Generated at 2022-06-22 18:16:37.897779
# Unit test for constructor of class Tracer
def test_Tracer():
    from io import StringIO as sio
    output = sio()

# Generated at 2022-06-22 18:16:45.663915
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass
    foo_code = foo.__code__
    bad_code = inspect.currentframe().f_code
    assert Tracer(watch=('x',)).watch == [BaseVariable('x')]
    assert Tracer(watch_explode=('y',)).watch == [Exploding('y')]
    assert Tracer(watch=('x', bad_code)).watch == [BaseVariable('x')]
    assert Tracer(watch=(foo_code, 'x')).watch == [BaseVariable(foo_code),
                                                   BaseVariable('x')]

    # Cannot watch both foo() and "foo" at the same time. If we do, we won't
    # know which one is the caller.
    # Currently we only support watching on callers, not callees.

# Generated at 2022-06-22 18:16:57.230109
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import unittest
    from .testing.test_utils.asserting import assert_equal
    frame = inspect.currentframe()
    def call_get_path_and_source_from_frame():
        return get_path_and_source_from_frame(frame)
    class TestCase(unittest.TestCase):
        def test(self):
            path, source = call_get_path_and_source_from_frame()
            assert_equal(path, __file__)

# Generated at 2022-06-22 18:16:58.929981
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:02.446572
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    try:
        source = UnavailableSource()
        source[0]
    except Exception as e:
        assert False, (
            'Unexpected exception `%s` raised when getting from unavailable '
            'source' % e
        )

# Generated at 2022-06-22 18:17:07.969002
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    from io import StringIO
    from pysnooper import snoop
    from pysnooper.utils import get_write_function,get_local_reprs
    from pysnooper.utils import safe_repr

    @snoop()
    def foo():
        return 1

    foo()
    try:
        foo()
    except Exception:
        pass


# Generated at 2022-06-22 18:17:19.534993
# Unit test for constructor of class FileWriter
def test_FileWriter():
    my_path = '/home/my/path'
    my_s = 'This is a string\n'

    # Test for overwriting
    fw_overwrite = FileWriter(my_path, True)
    assert fw_overwrite.path == my_path
    assert fw_overwrite.overwrite == True
    fw_overwrite.write(my_s)
    with open(my_path, 'r', encoding='utf-8') as file:
        assert file.read() == my_s
    # Now overwrite should be False
    assert fw_overwrite.overwrite == False

    # Test for not overwriting
    os.remove(my_path)
    fw_no_overwrite = FileWriter(my_path, False)
    assert fw_no_overwrite.path == my_path

# Generated at 2022-06-22 18:17:25.379570
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    x = UnavailableSource()
    assert x[0] == u'SOURCE IS UNAVAILABLE'
    assert x[1] == u'SOURCE IS UNAVAILABLE'
    assert x[3] == u'SOURCE IS UNAVAILABLE'




# Generated at 2022-06-22 18:17:34.792133
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import shlex
    import shutil
    import tempfile
    from subprocess import Popen, PIPE
    from my_python_toolbox import misc

    def get_content(path):
        with open(path, 'rb') as f:
            return f.read()


# Generated at 2022-06-22 18:17:45.937485
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    frame = mock.MagicMock()
    frame.f_code = 'some code object'
    frame.f_trace.__name__ = '__name__'
    frame.f_back = mock.MagicMock()
    frame.f_trace = mock.MagicMock()
    with mock.patch('pysnooper.snoop.Tracer.__init__') as mck_init:
        mck_init.return_value = None
        mck_is_internal_frame = mock.patch('pysnooper.snoop.Tracer._is_internal_frame').start()
        mck_is_internal_frame.return_value = True
        with pysnooper.snoop.Tracer() as inst:
            mock_currentframe = mock.MagicMock()
            mock_currentframe.f_

# Generated at 2022-06-22 18:17:57.461892
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    my_snooper = Tracer()
    my_snooper.frame_to_local_reprs = {'frame':'local_repr'}
    my_snooper.start_times = {'frame':'start_time'}
    my_snooper.target_codes = {'target_code'}
    my_snooper.target_frames = {'target_frame'}
    my_snooper.thread_local.original_trace_functions = ['original_trace_function']
    my_snooper.prefix = 'prefix'
    my_snooper.thread_info = True
    my_snooper.thread_info_padding = 0
    my_snooper.last_source_path = 'last_source_path'
    my_snooper.normalize = False

# Generated at 2022-06-22 18:18:08.430961
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # Check if FileWriter throws error if overwrite is True and
    # it is not a file path.
    with pytest.raises(Exception) as excinfo:
        FileWriter('not file path', True)
    assert 'can only be used when writing content to file' in str(excinfo.value)

    # Check if write method of FileWriter throws error if overwrite is True
    # and it is not a file path.
    with pytest.raises(Exception) as excinfo:
        writer = FileWriter('not file path', False)
        writer.write('something')
    assert 'can only be used when writing content to file' in str(excinfo.value)

    # Check if write method of FileWriter throws error if output is not a
    # path.

# Generated at 2022-06-22 18:18:20.782902
# Unit test for function get_write_function
def test_get_write_function():
    class FakeWritableStream(utils.WritableStream):
        def write(self, string):
            pass

    fake_writable_stream = FakeWritableStream()
    stderr = sys.stderr
    if stderr is not sys.__stderr__:
        stderr_backup = sys.stderr
        sys.stderr = sys.__stderr__

# Generated at 2022-06-22 18:18:23.399445
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    # Test __getitem__ of class UnavailableSource
    u = UnavailableSource()
    assert u[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:30.681076
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # Test when `overwrite` is False
    assert os.path.exists("tmp.txt") == False
    fw1 = FileWriter("tmp.txt", False)
    fw1.write("nep = w")
    fw1.write("ep = u")
    fw1.write("p = ve")
    fw1.write(" = g")
    fw1.write("a = c")
    fw1.write("s = t")
    fw1.write("d = tr")
    fw1.write("w = r")
    fw1.write("u = n")
    assert os.path.exists("tmp.txt")

# Generated at 2022-06-22 18:18:41.722724
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding('a') == 'a    '
    assert tracer.set_thread_info_padding('aa') == 'aa   '
    assert tracer.set_thread_info_padding('aa') == 'aa   '
    assert tracer.set_thread_info_padding('aaa') == 'aaa  '
    assert tracer.set_thread_info_padding('aaa') == 'aaa  '
    assert tracer.set_thread_info_padding('aaaa') == 'aaaa '
    assert tracer.set_thread_info_padding('aaaa') == 'aaaa '
    assert tracer.set_thread_info_padding('aaaaa') == 'aaaaa'

# Generated at 2022-06-22 18:18:46.465636
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    try:
        UnavailableSource()[0]
    except (IndexError, TypeError) as e:
        raise AssertionError("Constructor of class UnavailableSource is "
                             "badly implemented: %s" % e)



# Generated at 2022-06-22 18:18:56.145159
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from io import StringIO
    from datetime import datetime
    from time import time

    import pytest

    from .utils import test_variable_tracer

    from .utils import fake_frame

    def function():
        pass

    def function_with_args(a, b=4):
        c = EvalVariable('a + b', frame=frame)

    def function_with_kwargs(a, b=4):
        c = EvalVariable('a + b', frame=frame)

    frame = fake_frame(function)
    frame_with_args = fake_frame(function_with_args, args=(1,), kwargs={})
    frame_with_kwargs = fake_frame(function_with_kwargs, args=(1,), kwargs={
        'b': 5
    })


# Generated at 2022-06-22 18:19:02.317249
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(sys.stderr, False)
    write(b'hello')
    write = get_write_function(None, False)
    write(b'hello')
    write = get_write_function(lambda s: s, False)
    write(b'hello')
    write = get_write_function(b'output.txt', True)
    write(b'hello')
# /Unit test for function get_write_function



# Generated at 2022-06-22 18:19:13.390638
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = os.path.join(os.path.dirname(__file__), 'test_output.txt')
    try:
        os.remove(path)
    except OSError:
        pass
    fw = FileWriter(path, True)
    fw.write('x' * 1000)
    size = os.stat(path).st_size
    assert size >= 1000
    fw.write('x' * 1000)
    new_size = os.stat(path).st_size
    assert new_size >= size + 1000
    fw.write('x' * 1000)
    new_new_size = os.stat(path).st_size
    assert new_new_size == new_size



# Generated at 2022-06-22 18:19:18.808925
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    def f(var1):
        var2 = 'a'
        return var1 + var2
    output = io.StringIO()
    tracer._write = lambda x: output.write(x)
    wrapped_f = tracer(f)
    assert wrapped_f(1) == 2
    # TODO: test Tracer with generators
    assert output.getvalue().splitlines() == [
        "Call........... 13     var1 = 1",
        "Call........... 14     var2 = 'a'",
        "Return value:.. var1 + var2",
        "Elapsed time:   0:00:00.000002"
    ]


# Generated at 2022-06-22 18:19:22.652368
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper 
    
    @pysnooper.snoop()
    def f():
        pass
    
    assert f != f.__wrapped__
    assert f() == f.__wrapped__()

# Generated at 2022-06-22 18:19:31.702916
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    test_cases = [("a", 4, "a   "),
                  ("aaaa", 4, "aaaa"),
                  ("aa", 2, "aa"),
                  ("a", 2, "a "),
                  ]
    for thread_info, thread_info_padding, expected in test_cases:
        tracer = Tracer()
        tracer.thread_info_padding = thread_info_padding
        actual = tracer.set_thread_info_padding(thread_info)
        if actual != expected:
            print("Expected:", expected, "Actual:", actual, sep="\n")


# Generated at 2022-06-22 18:19:40.012487
# Unit test for function get_write_function
def test_get_write_function():
    from .variables import FunctionVariable
    def my_function(): pass
    variables = (FunctionVariable(my_function),)
    # First test when `output` is not a path
    # First try with a function as `output`
    write_function = get_write_function(print, False)
    write_function('hello world')
    # Now try with a stream as `output`
    output = utils.WritableStream(python2_compatibility_string=True)
    write_function = get_write_function(output, False)
    write_function('hello world')
    assert output.text == 'hello world'
    # Now test when `output` is a path
    # First create the file
    path = 'my_file.txt'
    FileWriter(path, True).write('hello world')

# Generated at 2022-06-22 18:19:52.253545
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    """
    Unit tests for method __call__ of class Tracer
    """
    from pysnooper import snoop
    try:
        @snoop()
        def foo():
            pass
    except NotImplementedError:
        pass
    else:
        assert False

    try:
        @snoop()
        async def foo():
            pass
    except NotImplementedError:
        pass
    else:
        assert False

    try:
        @snoop()
        async def foo():
            yield 1
    except NotImplementedError:
        pass
    else:
        assert False

    try:
        @snoop(normalize=True, thread_info=True)
        def foo():
            pass
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-22 18:19:58.613594
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        f()
    try:
        f()
    except Exception:
        frame = sys.exc_info()[2].tb_frame
        filename, source = get_path_and_source_from_frame(frame)
        assert source[frame.f_lineno - 1].strip() == 'f()'
        assert os.path.basename(filename) == 'test_debugger.py'


# Local cache
line_cache = {}



# Generated at 2022-06-22 18:20:07.189284
# Unit test for function get_local_reprs
def test_get_local_reprs():
    # Test with a frame:
    frame = sys._getframe()
    class Foo:
        def __repr__(self):
            return '<Foo>'
    assert get_local_reprs(frame, watch=[CommonVariable('x')]) == {
        '__name__': 'test_get_local_reprs',
        '__spec__': '',
        'frame': '<frame object at 0x{:x}>'.format(id(frame)),
        'result': '...',
        'x': '<Foo>',
    }

# Generated at 2022-06-22 18:20:12.837370
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with mock.patch.object(utils, 'write_function') as write_function:
        tracer = Tracer()
        with tracer:
            pass

    expected_calls = [
        mock.call('', overwrite=False),
    ]
    assert write_function.call_args_list == expected_calls

# Generated at 2022-06-22 18:20:25.987961
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import os
    import platform
    if not os.access("Tracer_write.txt", os.W_OK):
        print("Cannot write to 'Tracer_write.txt'")
        print("Returning without testing method write of class Tracer")
        return
    if os.path.getsize("Tracer_write.txt") != 0:
        print("'Tracer_write.txt' must be empty for this test to run")
        print("Returning without testing method write of class Tracer")
        return
    g = open("Tracer_write.txt", "w")
    s = "Hello World"
    #This is a happy case
    t = Tracer(g)
    result = t.write(s)

# Generated at 2022-06-22 18:20:28.555222
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper.tracer import Tracer
    print(Tracer.trace(Tracer, 1, 'call', 'arg'))

# Generated at 2022-06-22 18:20:35.565958
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import io
    import os
    import pytest

    stream = io.StringIO()
    file_writer = FileWriter(stream, False)
    file_writer.write('first line')
    file_writer.write('second line')
    assert stream.getvalue() == 'first linesecond line'

    with pytest.raises(Exception):
        file_writer = FileWriter(stream, True)
    with pytest.raises(Exception):
        open('test_FileWriter_write.txt', 'w').close()
        file_writer = FileWriter('test_FileWriter_write.txt', True)
        file_writer.write('a line')
        file_writer.write('another line')
        with open('test_FileWriter_write.txt') as f:
            assert f.read() == 'a line'

# Generated at 2022-06-22 18:20:44.382511
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import io
    import threading
    import time
    
    class Foo:
        def bar(self):
            pass
    
    
    
    
    @pysnooper.snoop()
    def test_function():
        time.sleep(0.1)
    
    
    @pysnooper.snoop(watch=('local_var_to_watch',))
    def test_local_var_watching():
        local_var_to_watch = 1
    
    
    @pysnooper.snoop(watch_explode=('local_var_to_watch',))
    def test_local_var_exploding():
        local_var_to_watch = {'key': 1}
    
    

# Generated at 2022-06-22 18:20:55.427977
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import inspect
    import functools

    """ Test with function decorated using snoop """
    @pysnooper.snoop()
    def func_with_decorator():
        return -1

    assert inspect.isgeneratorfunction(func_with_decorator.__wrapped__)
    assert not inspect.isgeneratorfunction(func_with_decorator)
    assert func_with_decorator() == -1

    """ Test with function not decorated using snoop """
    def func_without_decorator():
        return -1

    assert func_without_decorator() == -1

    """ Test with class decorated using snoop """
    class ClassWithDecorator():

        def __init__(self, value):
            self.value = value


# Generated at 2022-06-22 18:21:07.008562
# Unit test for method write of class Tracer
def test_Tracer_write():

    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def assert_writes(s, *args, **kwargs):
        output = StringIO()
        with Tracer(output, *args, **kwargs):
            pass
        assert output.getvalue() == s


# Generated at 2022-06-22 18:21:09.528372
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with Tracer() as tracer:
        pass
    return


# Generated at 2022-06-22 18:21:13.278731
# Unit test for constructor of class FileWriter
def test_FileWriter():
    x = FileWriter("hello.txt", False)
    assert str(x.path) == "hello.txt"
    assert not x.overwrite



# Generated at 2022-06-22 18:21:16.638523
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    thread_info = "id-name"
    instance = Tracer()
    result = instance.set_thread_info_padding(thread_info)
    assert result == "id-name "


# Generated at 2022-06-22 18:21:18.039019
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-22 18:21:23.138592
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        return 1
    assert get_path_and_source_from_frame(test_function.__code__.co_filename)



# Generated at 2022-06-22 18:21:26.305684
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    x = UnavailableSource()[:]
    assert x == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:21:33.087304
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = os.path.expanduser("~/Desktop/output.txt")

    # Test for constructor of class FileWriter
    fw = FileWriter(path, True)
    assert fw.path == path
    assert fw.overwrite == True
    fw = FileWriter(path, False)
    assert fw.overwrite == False

    # Test for write function of class FileWriter
    fw.write("test")
    with open(path, 'r') as f:
        assert f.read() == "test"
    fw.write("python")
    with open(path, 'r') as f:
        assert f.read() == "testpython"


# Generated at 2022-06-22 18:21:41.670209
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs(
        frame=frame.f_back,
        watch=[CommonVariable("spam"), CommonVariable("eggs")],
        custom_repr={("spam", 0): "foo"},
    ) == {'spam': 'foo', 'ham': '"bli"'}
    assert get_local_reprs(
        frame=frame.f_back,
        custom_repr={("spam", 0): "foo"},
        normalize=True,
    ) == collections.OrderedDict((('spam', 'foo'), ('ham', 'bli')))

# Generated at 2022-06-22 18:21:44.231608
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:21:45.348904
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-22 18:21:48.747888
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = '~/file'
    filewriter = FileWriter(path, True)
    assert filewriter.path == os.path.expanduser(path)
    assert filewriter.overwrite == True


# Generated at 2022-06-22 18:21:51.758017
# Unit test for method write of class Tracer
def test_Tracer_write():
    """Testing for whether a write method of class Tracer can be called.
    """
    exc = None
    try:
        Tracer().write('snoop')
    except Exception as e:
        exc = e
    assert exc is None

# Generated at 2022-06-22 18:21:56.782307
# Unit test for function get_write_function
def test_get_write_function():
    write_function = get_write_function(None, False)
    assert write_function == sys.stderr.write
    write_function = get_write_function(sys.stdout, False)
    assert write_function == sys.stdout.write

    with open('file.txt', 'wb') as f:
        write_function = get_write_function(f, False)
        write_function(b'spam')

    with open('file.txt', 'rb') as f:
        assert f.read() == b'spam'
    os.remove('file.txt')

    write_function = get_write_function(lambda s: None, False)
    assert write_function is None.__call__



# Generated at 2022-06-22 18:22:04.774619
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    current_thread = threading.current_thread()
    expected_thread_info = "{ident}-{name} ".format(
        ident=current_thread.ident, name=current_thread.getName())
    assert tracer.set_thread_info_padding(expected_thread_info) == expected_thread_info
    assert tracer.set_thread_info_padding("test") == "test ".ljust(len(expected_thread_info))

# Generated at 2022-06-22 18:22:11.076982
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test with no watch arguments
    with Tracer(watch=[]):
        foo = 1
        bar = 2
    # Test with watch arguments
    with Tracer(watch=['foo', 'bar']):
        foo = 1
        bar = 2



# Generated at 2022-06-22 18:22:23.237144
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import os
    import datetime
    import pysnooper.utils
    import datetime_module
    import pycompat
    import pysnooper.snoop
    import sys
    import inspect
    import pysnooper.tracer
    import pysnooper.writer
    import functools
    import pysnooper.variables
    import pysnooper.thread_global
    from io import StringIO
    import pycompat
    import pysnooper.pycompat
    import pysnooper.overwrite_file
    import threading
    import pysnooper.opcode

    def test_Tracer___exit___ten_times():
        for test_number in range(1, 11):
            snooper = pysnooper.snoop.snoop


# Generated at 2022-06-22 18:22:33.225781
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper import snoop
    def deco_snoop(snooper):
        def decorator(f):
            @functools.wraps(f)
            def function_wrapper(self, *args, **kwargs):
                with snooper:
                    return f(self, *args, **kwargs)
            return function_wrapper
        return decorator
    # snoop = deco_snoop(snooper)
    #   def test_Tracer___call__(self):