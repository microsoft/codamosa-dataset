

# Generated at 2022-06-22 18:12:30.001191
# Unit test for constructor of class FileWriter
def test_FileWriter():
    output = 'try'
    try:
        FileWriter(output, False)
    except Exception:
        assert False
    try:
        FileWriter(output, True)
    except Exception:
        assert False


# Generated at 2022-06-22 18:12:31.786788
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:12:38.364506
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile

    # using `with open` to create a file in the same directory in which
    # the unit test is run
    with open('test_FileWriter_write_file.txt', 'w') as f:
        pass
    path = f.name

    try:
        writer = FileWriter(path, False)
        content = 'test_FileWriter_write'
        writer.write(content)

        with open(path, 'r') as f:
            assert f.read() == content

        writer.overwrite = True
        writer.write('second_time')
        with open(path, 'r') as f:
            assert f.read() == 'second_time'
    finally:
        os.remove(path)



# Generated at 2022-06-22 18:12:44.668221
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import unittest
    class Foo:
        def __init__(self):
            self.a = 1
            self.b = 0
    def foo():
        a = 1

    try:
        from unittest import mock
        from unittest.mock import call
        from inspect import currentframe
        from builtins import exec
        import sys
        from datetime import datetime
    except ImportError:
        import mock
        from mock import call
        import sys
        from inspect import currentframe
        from types import CodeType, FrameType
        from io import StringIO
        from datetime import datetime

        class _patch(object):
            def __init__(self, *args, **kwargs):
                pass
            def __enter__(self):
                pass

# Generated at 2022-06-22 18:12:53.995084
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y):
        pass
    frame = sys._getframe()
    assert get_local_reprs(frame) == {'f': repr(f), 'x': '<unused>', 'y': '<unused>'}
    frame = frame.f_back
    assert get_local_reprs(frame) == {'frame': repr(frame)}
    assert get_local_reprs(frame, [CommonVariable('frame')]) == {'frame': repr(frame)}
    assert get_local_reprs(frame, [CommonVariable('frame')]) == {'frame': repr(frame)}
    assert get_local_reprs(frame, [CommonVariable('frame', extract_expression=lambda x: x)]) == {'frame': 'frame'}

# Generated at 2022-06-22 18:13:05.323981
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    self = Tracer()

    source_path_1 = 'yada/yada/module.py'
    source_line_1 = 'x = "hi"'
    source_path_2 = 'yada/yada/module.py'
    source_line_2 = 'x = "bye"'
    source_path_3 = 'yada/yada/module.py'
    source_line_3 = 'x = "bye"'
    var_1 = 'x'
    local_repr_1 = '"hi"'
    var_2 = 'x'
    local_repr_2 = '"yada"'
    # TODO: Write test(s) for this method
    raise NotImplementedError()

# Generated at 2022-06-22 18:13:11.730994
# Unit test for constructor of class Tracer
def test_Tracer():
    output = []

    snoop = Tracer(output=output)
    with snoop:
        pass

    assert len(output) == 1
    assert 'Elapsed time:' in output[0]

    # Test custom repr
    def custom_repr(x):
        return 'custom_repr'

    snoop = Tracer(output=output, custom_repr=((object, custom_repr),))

    class A(object):
        pass

    a = A()

    with snoop:
        a

    assert 'custom_repr' in output[-1]

    with snoop:
        a.__dict__

    assert 'custom_repr' not in output[-1]

    # Test custom representation function
    snoop = Tracer(output=output, custom_repr=custom_repr)


# Generated at 2022-06-22 18:13:14.652780
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from pysnooper import snoop

    def my_func():
        a = 3

    snoop(my_func)()

    assert True

# Generated at 2022-06-22 18:13:18.158163
# Unit test for method write of class Tracer
def test_Tracer_write():
    """Unit tests for Tracer.write"""
    tracer = Tracer(output='log/test.log')
    tracer.write("Hello World!")
    tracer._write

# Generated at 2022-06-22 18:13:26.584872
# Unit test for function get_write_function
def test_get_write_function():
    class Stream(utils.WritableStream):
        def __init__(self):
            self.content = []
        def write(self, s):
            self.content.append(s)
        def getvalue(self):
            return ''.join(self.content)
    stream = Stream()
    assert get_write_function(stream)() is None
    assert get_write_function(stream, False)() is None
    assert get_write_function(stream.write, False)() is None
    with utils.temporary_file() as f:
        writer = get_write_function(f, True)
        writer('foo')
        writer('bar')
        with open(f) as fp:
            assert fp.read() == 'foobar'
    assert get_write_function(None, False)() is None


# Generated at 2022-06-22 18:13:36.633442
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import pickle
    import tempfile
    import zlib
    with tempfile.SpooledTemporaryFile() as temp_file:
        file_writer = FileWriter(temp_file, True)
        file_writer.write('Hi\n')
        file_writer.write('there\n')
        file_writer.close()
        temp_file.seek(0)
        assert temp_file.read() == 'Hi\nthere\n'
    with tempfile.NamedTemporaryFile(delete=False) as temp_file:
        path = temp_file.name
        file_writer = FileWriter(path, True)
        file_writer.write('Hi\n')
        file_writer.write('there\n')
        file_writer.close()

# Generated at 2022-06-22 18:13:37.926848
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    t = Tracer()
    t.__enter__()


# Generated at 2022-06-22 18:13:38.697472
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass

# Generated at 2022-06-22 18:13:50.112278
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from garlicsim.general_misc import fs
    from garlicsim.general_misc.temp_value import TempValue, temp_value
    from garlicsim.general_misc import temp_file_tools

    with temp_file_tools.create_temp_file(
        'w', temp_value('.txt')
    ) as (_, file_path):
        file_writer = FileWriter(file_path, True)
        file_writer.write('Hello')
        file_writer.write('\n')
        file_writer.write('world!')
        assert fs.read(file_path) == 'Hello\nworld!'
        file_writer.write('\n')
        file_writer.write('blah blah blah')
        assert fs.read(file_path) == 'Hello\nworld!\nblah blah blah'



# Generated at 2022-06-22 18:14:00.816797
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter('test', overwrite=False)
    assert file_writer.path == 'test', \
           'FileWriter.__init__() failing to set path correctly'
    assert file_writer.overwrite == False, \
           'FileWriter.__init__() failing to set overwrite correctly'
    # test that write function works as intended
    file_writer.write('Test string')
    with open('test', 'r', encoding='utf-8') as test_file:
        assert test_file.read() == 'Test string', \
               'FileWriter.write() failed to write to test file'
    # test that overwrite works as intended
    file_writer.write('Appended string')

# Generated at 2022-06-22 18:14:09.167720
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile

    path = pycompat.Path(tempfile.mktemp())
    file_writer = FileWriter(path, True)
    assert file_writer.overwrite

    file_writer.write('abc')
    assert file_writer.path == path
    assert file_writer.overwrite == False

    with open(path, 'r') as file:
        assert file.read() == 'abc'

    file_writer.write('def')
    with open(path, 'r') as file:
        assert file.read() == 'def'

    file_writer.write('123')
    with open(path, 'r') as file:
        assert file.read() == '123'

    file_writer.write('456')

# Generated at 2022-06-22 18:14:18.520650
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    snoop = Tracer()
    assert snoop.thread_info_padding == 0
    snoop.set_thread_info_padding('foobar')
    assert snoop.thread_info_padding == 6
    snoop.set_thread_info_padding('foobar1')
    assert snoop.thread_info_padding == 7
    snoop.set_thread_info_padding('foobar1')
    assert snoop.thread_info_padding == 7
    snoop.set_thread_info_padding('foobar2')
    assert snoop.thread_info_padding == 7
    snoop.set_thread_info_padding('')
    assert snoop.thread_info_padding == 7


# Generated at 2022-06-22 18:14:20.923138
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0:5] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:22.945162
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:31.711357
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import warnings
    warnings.filterwarnings("ignore", ".+inspect.getargspec.+",
                            DeprecationWarning)

    import inspect
    import copy
    import pytest
    from unittest.mock import MagicMock, patch

    from threading import Lock
    from collections import OrderedDict
    from .utils import SetterDict

    from . import pycompat
    from .snoop import Tracer, DISABLED
    from .snoop import get_write_function

    class ClassForTest():

        def decorated_method(self):
            pass



# Generated at 2022-06-22 18:14:36.925639
# Unit test for function get_write_function
def test_get_write_function():
    def write_to_stderr(s):
        stderr = sys.stderr
        try:
            stderr.write(s)
        except UnicodeEncodeError:
            # God damn Python 2
            stderr.write(utils.shitcode(s))

    assert get_write_function(None, False) == write_to_stderr



# Generated at 2022-06-22 18:14:38.260618
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Initializing Tracer
    snoop = Tracer()
    assert snoop != None


# Generated at 2022-06-22 18:14:39.783795
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Calling with insufficient arguments
    # Calling with arguments of incorrect type
    # Calling with correct arguments
    pass

# Generated at 2022-06-22 18:14:45.454085
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass
    def bar():
        pass

    t = Tracer(watch=("foo", "bar"))

    assert not t._is_internal_frame(foo)
    assert t._is_internal_frame(t.__enter__)

    assert isinstance(t.watch[0], CommonVariable)
    assert isinstance(t.watch[1], CommonVariable)

    t2 = Tracer(watch_explode=("foo", "bar"))

    assert isinstance(t2.watch[0], Exploding)
    assert isinstance(t2.watch[1], Exploding)


# Generated at 2022-06-22 18:14:56.433215
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    target_depth = 1
    output = None
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False

    print('\n### Unit test for method __enter__ of class Tracer:')
    t = Tracer(output, watch, watch_explode, depth, prefix, overwrite,
               thread_info, custom_repr, max_variable_length, normalize, relative_time)
    print('Assert class Tracer is subclass of object')
    if not issubclass(Tracer, object):
        print('--> Failing test')
        return -1
    else:
        print('--> Passing test')

# Generated at 2022-06-22 18:14:58.873262
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[5:5] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[0:1] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:15:02.840294
# Unit test for method write of class Tracer
def test_Tracer_write():
    with io.StringIO() as s:
        tracer = Tracer(output=s, override_write=True)
        tracer.write("this is a test")
    assert s.getvalue() == "this is a test\n"


# Generated at 2022-06-22 18:15:13.928518
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import os
    import sys
    import tempfile
    import inspect
    import itertools
    import functools
    import threading
    import time
    import datetime
    import traceback
    import opcode
    import pysnooper._snoop_constants
    import pysnooper._snoop_utils
    import pysnooper._snoop_variable
    import pysnooper._snoop_variable_explode
    import varname
    import pysnooper.threads as thread_module
    import pysnooper.utils as utils
    import pysnooper.pycompat as pycompat
    import pysnooper.datetime_module
    DISABLED = pysnooper._snoop_constants.DISABLED
    CommonVariable = pysnooper._sno

# Generated at 2022-06-22 18:15:24.154104
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """Test Tracer.__exit__
    """
    def test_Tracer___exit___helper(event, exc_type, exc_value, exc_traceback):
        try:
            raise ValueError("test")
        except:
            exc_type_, exc_value_, exc_traceback_ = sys.exc_info()
            if exc_type_ is not None:
                assert isinstance(exc_type_, Exception)
            assert isinstance(exc_traceback_, traceback.__Traceback__)
            assert exc_type_ == exc_type
            assert exc_value_ == exc_value
            assert exc_traceback_ == exc_traceback

    def test_Tracer___exit___no_args():
        """Test Tracer.__exit__ no_args
        """
        # No args
       

# Generated at 2022-06-22 18:15:32.934605
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(output=None, overwrite=False)
    assert get_write_function(output='path/to/file', overwrite=True)
    assert get_write_function(output=sys.stdout, overwrite=False)
    assert get_write_function(output=sys.stdout.write, overwrite=False)
    assert get_write_function(output=utils.WritableStream())
    try:
        assert get_write_function(output=False, overwrite=True)
    except Exception as e:
        assert '`overwrite=True` can only be used' in str(e)



# Generated at 2022-06-22 18:15:37.378440
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import datetime
    frame = sys.modules['datetime'].datetime.now.__code__ .co_consts[0].co_filename
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == datetime.datetime.now.__code__.co_filename
    assert source == UnavailableSource()



# Generated at 2022-06-22 18:15:44.921078
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = pysnooper.Snooper()
    assert tracer.set_thread_info_padding("Thread 0") == "Thread 0"
    assert tracer.set_thread_info_padding("Thread 1") == "Thread 1       "
    assert tracer.set_thread_info_padding("Thread 2") == "Thread 2       "
    assert tracer.set_thread_info_padding("Thread 201") == "Thread 201     "
    assert tracer.set_thread_info_padding("Thread 21") == "Thread 21      "
    assert tracer.set_thread_info_padding("Thread 31") == "Thread 31      "
    assert tracer.set_thread_info_padding("Thread 11") == "Thread 11      "
    assert tracer.set_thread_info_padding("Thread 12") == "Thread 12      "

# Generated at 2022-06-22 18:15:53.580349
# Unit test for method __exit__ of class Tracer

# Generated at 2022-06-22 18:16:04.713506
# Unit test for constructor of class FileWriter

# Generated at 2022-06-22 18:16:06.919849
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource(), UnavailableSource)



# Generated at 2022-06-22 18:16:10.587947
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    us = UnavailableSource()
    assert us[0] == u'SOURCE IS UNAVAILABLE'


_compiler_cache_lock = threading.Lock()
_compiler_cache = {}



# Generated at 2022-06-22 18:16:13.389472
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_consts[0].co_consts[0])



# Generated at 2022-06-22 18:16:20.202357
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8') as f:
        print('This is a unit test for method write of class FileWriter', file=f)
        f.flush()
        name = f.name
    fn = FileWriter(name, False)
    fn.write(u'\nThis is a unit test for method write of class FileWriter\n')


# Generated at 2022-06-22 18:16:25.994652
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_writer = FileWriter('a_file.txt', overwrite=False)
    file_writer.write("line 1\n")
    assert open('a_file.txt').read() == "line 1\n"
    file_writer.write("line 2\n")
    assert open('a_file.txt').read() == "line 1\nline 2\n"


# Generated at 2022-06-22 18:16:33.099226
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    expected_result = (os.path.abspath('cute_source.py'),
                       ['def f():\n', '    return 3\n', '\n'])
    with open('cute_source.py', 'w') as f:
        f.write(expected_result[1][0] + expected_result[1][1] +
                expected_result[1][2])

    def f():
        return 3

    result = get_path_and_source_from_frame(f.__code__.co_filename, f.__code__)
    assert result == expected_result



# Generated at 2022-06-22 18:16:37.597984
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:16:39.917858
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # check that it raises an exception when try to overwrite if not overwrite
    # is set
    try:
        FileWriter('file.log', False).write('what')
    except Exception:
        pass



# Generated at 2022-06-22 18:16:47.246635
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop()
    def function():
        pass

    assert isinstance(function, functools.partial)

    @pysnooper.snoop(watch=('foo.bar', 'self.baz'))
    def function():
        pass

    assert isinstance(function, functools.partial)
    assert len(function.keywords) == 1
    assert function.keywords['watch'] == ('foo.bar', 'self.baz')

    @pysnooper.snoop(watch=('foo', 'self'))
    def function():
        pass

    assert isinstance(function, functools.partial)
    assert len(function.keywords) == 1
    assert function.keywords['watch'] == ('foo', 'self')


# Generated at 2022-06-22 18:16:54.210593
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter('a', True)
    assert file_writer.path == 'a'
    assert file_writer.overwrite is True
    file_writer.write('b')
    assert file_writer.path == 'a'
    assert file_writer.overwrite is False
    file_writer.write('b')
    f = open('a', 'r')
    assert f.read() == 'b'



# Generated at 2022-06-22 18:17:01.212258
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .test_utils import test_utils
    import tempfile
    import collections

    _, file_name = tempfile.mkstemp()

    frame = test_utils.DummyFrame({'__name__': 'my_module',
                                   '__file__': file_name})
    frame.f_code = frame.f_code = collections.namedtuple('code',
                                                         'co_filename')(
                                                             file_name)

# Generated at 2022-06-22 18:17:08.973807
# Unit test for constructor of class Tracer
def test_Tracer():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        output_file_path = os.path.join(tmp, 'snoop.log')
        with open(output_file_path, 'w'):
            pass
        def hello():
            pass
        tracer = Tracer(output_file_path)
        tracer(hello)
        assert tracer
        assert tracer.watch
        assert tracer.frame_to_local_reprs
        assert tracer.start_times
        assert tracer.depth
        assert tracer.prefix
        assert tracer.thread_info
        assert tracer.thread_info_padding
        assert tracer.target_codes
        assert tracer.target_frames
        assert tracer.thread_local
        assert tracer.custom_repr


# Generated at 2022-06-22 18:17:16.597676
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'fixtures/test_FileWriter.txt'
    f1 = FileWriter(path, True)
    f1.write('hello')
    f2 = FileWriter(path, False)
    f2.write('world')
    assert open(path, 'r').read() == 'helloworld'


# Generated at 2022-06-22 18:17:28.675661
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from unittest import TestCase
    from unittest import mock

    class MockFunction:
        __code__ = mock.Mock()

    class MockFrame:
        f_back = mock.Mock(return_value=mock.Mock(f_back=None))

    class MockThreadGlobal:
        depth = -1

    class MockThreadLocal:
        original_trace_functions = []

    def MockGetWriteFunction(output, overwrite):
        return mock.Mock()

    class MockDatetimeModule:
        class datetime:
            class time:
                pass

    tracer = Tracer()
    tracer._write = mock.Mock()
    tracer.frame_to_local_reprs = mock.Mock()
    tracer.start_times = {}
    tracer.depth = 1
    tr

# Generated at 2022-06-22 18:17:33.000308
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    s = Tracer()
    assert s.set_thread_info_padding('1-1') == '1-1'
    assert s.set_thread_info_padding('10-1') == '10-1'
    assert s.set_thread_info_padding('100-1') == '100-1 '


# Generated at 2022-06-22 18:17:38.171104
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'my_file_name'
    x = FileWriter(path, overwrite=True)
    x.write('foo')
    assert x.path == path
    assert not x.overwrite



# Generated at 2022-06-22 18:17:46.049654
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # First unit test: make sure it works with a regular module loaded from a
    # .py file.
    frame = sys._getframe(0)
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name in [__file__, __file__.rstrip('c')]
    assert source[0].startswith('def ')

    # Second unit test: Make sure it works with a module which was compiled
    # from .py to .pyc, then loaded.
    def get_mod_c_file_name(mod_name):
        import imp
        import os
        assert mod_name == 'snekometer_tests_data'
        assert os.path.split(__file__)[-1] == 'snekometer_tests.py'
        return os.path

# Generated at 2022-06-22 18:17:57.501296
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def get_frame():
        def f(a, b):
            x = 1
            y = 2
            return x + y
        return inspect.currentframe().f_back
    frame = get_frame()
    assert get_local_reprs(frame) == {'a': '1', 'b': '2', 'x': '1', 'y': '2'}

# Generated at 2022-06-22 18:18:08.431580
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo():
        x = 3
        y = 4
        z = 5
        def bar():
            x = 6
            y = 7
            z = 8
            bar_frame = inspect.currentframe()
            assert get_local_reprs(bar_frame, watch=(x, y, z)) == {'z': '8', 'y': '7'}
            assert get_local_reprs(bar_frame, watch=[z]) == {'z': '8'}
            assert get_local_reprs(bar_frame, watch=[x, z]) == {'z': '8', 'x': '6'}
            bar_arg_frame = inspect.currentframe(1)
            assert 'z' in get_local_reprs(bar_arg_frame, watch=[z])

# Generated at 2022-06-22 18:18:10.493494
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[5] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:22.253347
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import tracer
    tracer.DISABLED = False
    tracer.thread_global.depth = -1

    def _get_new_trace_function(func):
        ''' Assumes that the original trace function did not change inside
        the context.
        '''
        with tracer.Tracer(output=None):
            pass
        return func.f_trace
    #
    # set up caller
    caller = inspect.currentframe().f_back
    original_trace_function = _get_new_trace_function(caller)
    stack = tracer.thread_local.original_trace_functions
    #
    # begin test
    with tracer.Tracer(output=None):
        # test internals
        assert sys.gettrace() == tracer.Tracer.trace

# Generated at 2022-06-22 18:18:24.802151
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write("test")
    assert tracer._write("test\n") == "test\n"


# Generated at 2022-06-22 18:18:27.341180
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[100] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:35.829067
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y):
        '''
        >>> x = 1; y = 2
        >>> f(3, 4)
        >>> print(x, y)
        '''
        x = x, y; y = 1
        a = 'a', 'b'; b = 2
        c = 'c'; d = 'd'
        pprint(get_local_reprs(current_frame, watch=(CommonVariable(('x',)), CommonVariable(('a',)))))
    utils.run_on_new_thread(f, 3, 4)


# Generated at 2022-06-22 18:18:44.493094
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return 'This is line 1!\nThis is line 2!\n'

    def g():
        return 'This is line 1!\r\nThis is line 2!\r\n'

    def h():
        return b'This is line 1!\r\nThis is line 2!\r\n'

    def i():
        return u'This is line 1!\r\nThis is line 2!\r\n'

    def j():
        return b'\xef\xbb\xbfThis is line 1!\r\nThis is line 2!\r\n'

    result = get_path_and_source_from_frame(inspect.currentframe())[1]

# Generated at 2022-06-22 18:18:55.168590
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    """Unit test for method __enter__ of class Tracer"""
    @pysnooper.snoop()
    def foo():
        x = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1
        zz = 1


# Generated at 2022-06-22 18:19:04.785641
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile

    def create_test_file(file_name):
        with open(file_name, 'wb') as f:
            f.write('a\nb\nc')
        return file_name


# Generated at 2022-06-22 18:19:15.821253
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from .utils import get_source_lines, MockWriter

    writer = MockWriter()

    @pysnooper.snoop(output=writer)
    def function():
        name = 'Dummy'
        return 42

    function()
    output = writer.getvalue()
    source_lines = get_source_lines(function)
    expected = [
        'Source path:... ' + inspect.getsourcefile(function),
        'Elapsed time: 0:00:00.000000',
        '    Line No: 4 ' + source_lines[0].strip(),
        'Starting var:.. name = "Dummy"',
        '    Line No: 5 ' + source_lines[1].strip(),
        'Return value:.. 42',
        '',
    ]
    assert output.splitlines() == expected

# Generated at 2022-06-22 18:19:26.894044
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest

    class TestTracer(unittest.TestCase):
        def test_init_1(self):
            self.assertIsInstance(tracer, Tracer)

        def test_init_2(self):
            self.assertIsInstance(tracer.watch, list)

        def test_init_3(self):
            self.assertIsInstance(tracer.watch_explode, list)

        def test_init_4(self):
            self.assertEqual(tracer.depth, 1)

        def test_init_5(self):
            self.assertEqual(tracer.prefix, '')

        def test_init_6(self):
            self.assertEqual(tracer._write, print)


# Generated at 2022-06-22 18:19:36.904901
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        return a, b

    frame = f.__code__.co_firstlineno
    frame = sys._getframe(frame)

    # regular test
    assert get_local_reprs(frame) == collections.OrderedDict([('a', '1'),
                                                              ('b', '2')])

    # test with maximum length
    assert get_local_reprs(frame, max_length=0) == collections.OrderedDict([('a', '1'),
                                                                            ('b', '2')])
    assert get_local_reprs(frame, max_length=1) == collections.OrderedDict([('a', '1'),
                                                                            ('b', '2')])
    assert get_local_reprs

# Generated at 2022-06-22 18:19:46.986263
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def function(a, b, c=3):
        d, e, f = 4, 5, 6
        g = 7
        h, i, j, k = [1, 2, 3, 4]
        return h

    frame = utils.get_frame(function, locals=dict(a=1, b=2, g=8))
    assert get_local_reprs(frame) == {'a': '1', 'b': '2', 'c': '3', 'd': '4',
                                      'e': '5', 'f': '6', 'g': '8', 'h': '1',
                                      'i': '2', 'j': '3', 'k': '4'}



# Generated at 2022-06-22 18:19:57.474620
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import random

    random.random()
    _local_list = []
    _local_dict = {}

    _local_list.append(random.random())
    _local_dict[random.random()] = random.random()

    _local_list.append(random.random())
    _local_dict.pop(random.random())

    _local_list.append(random.random())

    _local_list[-1] = random.random()

    _local_dict[random.random()] = random.random()

    _local_dict.pop(random.random())

    random.random()
    random.random()
    random.random()


# Generated at 2022-06-22 18:20:01.630722
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import io
    import contextlib
    with contextlib.redirect_stdout(io.StringIO()) as new_stdout:
        tracer = Tracer('hello')
        tracer.write('world')
        assert new_stdout.getvalue().endswith('hello')

# Generated at 2022-06-22 18:20:11.567711
# Unit test for method write of class Tracer
def test_Tracer_write():
    import pysnooper
    test_s = 'test_s'
    test_write = Tracer._write
    test_output = test_write(test_s)
    assert test_output == test_s
    # def test_Tracer_write(test_s):
    #     test_s = 'test_s'
    #     test_write = Tracer(test_s)
    #     assert test_write == test_s


# Generated at 2022-06-22 18:20:25.110377
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import unittest.mock
    open_mock = unittest.mock.MagicMock()
    with unittest.mock.patch('%s.open' % __name__, open_mock):
        file_writer = FileWriter('some_path', False)
        file_writer.write('abc')
        file_writer.write('def')
        file_writer.write('ghi')

    open_mock.assert_called_once_with('some_path', 'a',
                                      encoding='utf-8')
    write_mock = open_mock.return_value.__enter__.return_value.write

# Generated at 2022-06-22 18:20:29.933387
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def some_function():
        return get_path_and_source_from_frame(inspect.currentframe())
    file_name = inspect.getsourcefile(test_get_path_and_source_from_frame)
    assert some_function() == (file_name,
                               open(file_name).read().splitlines())



# Generated at 2022-06-22 18:20:32.376964
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert 'SOURCE IS UNAVAILABLE' == unavailable_source[0]


# Generated at 2022-06-22 18:20:46.140939
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys, tempfile, unittest

    def foo():
        pass

    def foo_gen():
        yield 1
        yield 2
        yield 3

    def foo_gen_with_exception_inside():
        yield 1
        yield 2
        yield 3
        raise Exception('Test exception')

    def foo_with_exception():
        raise Exception('Test exception')

    def foo_with_explode():
        foo = 'bar'
        foo.explode

    def foo_with_snoop_on_itself():
        return foo_with_snoop_on_itself

    def large_amount_of_output():
        return '\n'.join(['>' * 200] * 100)


# Generated at 2022-06-22 18:20:55.544625
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import inspect
    import io
    import threading

    from . import utils

    from .utils import PY35, PY352, PY37

    import sys

    if PY352:
        thread_local_name = '_local'
    else:
        thread_local_name = '_Thread__local'

    def get_snooper_and_snoop(snoop_line_generator_or_line_count):
        _output = io.StringIO()
        snooper = Tracer(_output.write)
        if not isinstance(snoop_line_generator_or_line_count, int):
            def line_generator():
                for line in snoop_line_generator_or_line_count:
                    yield line
            snoop_line_generator_or_line_

# Generated at 2022-06-22 18:21:02.189910
# Unit test for method write of class Tracer
def test_Tracer_write():
    def write(s):
        assert s == "test\n"
    tracer = Tracer(watch=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False, output=write)
    tracer.write('test')


# Generated at 2022-06-22 18:21:10.053472
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    from pysnooper.tracer import Tracer
    tracer = Tracer(thread_info=True, output=sys.stdout)
    thread1_info1 = "123-"
    thread1_info2 = "123-hello"
    thread2_info1 = "456-"
    thread2_info2 = "456-world"
    assert tracer.thread_info_padding == 0
    assert tracer.set_thread_info_padding(thread1_info1) == thread1_info1.ljust(len(thread1_info2))
    assert tracer.thread_info_padding == len(thread1_info2)
    assert tracer.set_thread_info_padding(thread2_info1) == thread2_info1.ljust(len(thread2_info2))
    assert tracer.thread_info

# Generated at 2022-06-22 18:21:17.987777
# Unit test for method write of class Tracer
def test_Tracer_write():
    stderr = io.StringIO()
    write = get_write_function(stderr, False)
    prefix = 'xx'
    tracer = Tracer(write, prefix=prefix)
    message = 'abc'
    tracer.write(message)
    assert stderr.getvalue() == '%s%s\n' % (prefix, message)

    stderr = io.StringIO()
    tracer = Tracer(write, prefix='yy')
    message = 'def'
    tracer.write(message)
    assert stderr.getvalue() == '%s%s\n' % (prefix, message)



# Generated at 2022-06-22 18:21:28.511288
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func(a, b, c):
        return a, b, c

    my_object = object()
    assert get_local_reprs(frame=utils.get_frame(func),
                           watch=(),
                           custom_repr={},
                           max_length=None,
                           normalize=False) == {'a': '1',
                                                'b': '2',
                                                'c': '3'}
    assert get_local_reprs(frame=utils.get_frame(func),
                           watch=(),
                           custom_repr={},
                           max_length=None,
                           normalize=True) == {'a': '1',
                                               'b': '2',
                                               'c': '3'}

    assert get_local_repr

# Generated at 2022-06-22 18:21:33.616646
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    try:
        UnavailableSource[0]
    except Exception as e:
        assert False, (
            "Unexpected exception "
            "'%s' from UnavailableSource.__getitem__." % repr(e))
    else:
        assert True, "UnavailableSource.__getitem__ works as expected."


# Generated at 2022-06-22 18:21:42.049667
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from contextlib import contextmanager
    from acme import bar
    from acme import foo

    global trace_depth
    trace_depth = 0

    @contextmanager
    def assert_depth(depth):
        global trace_depth
        trace_depth = 0
        yield
        assert trace_depth == depth, 'Depth is not {}'.format(depth)

    def test_exit_depth():
        global trace_depth
        try:
            with Tracer():
                pass
        except:
            pass
        else:
            assert False, 'Invalid trace depth {}'.format(trace_depth)
        assert trace_depth == 0, 'Depth is not 0'

    # With global_trace_depth > 0, trace function is ignored in Tracer.__enter__
    global_trace_depth = 4

# Generated at 2022-06-22 18:21:47.980414
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Perhaps this test should be in another file.
    import StringIO
    output = StringIO.StringIO()
    tracer = Tracer(output, watch=('self',))

    # This test is too complicated.
    # Perhaps it should be broken down.

    class Foo(object):

        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

        def get_b(self):
            return self.b

        def get_c(self):
            return self.c

        def set_c(self, c):
            self.c = c

        def get_a(self):
            return self.a

        @tracer
        def do_stuff(self, x):
            self.set_c(x)


# Generated at 2022-06-22 18:21:49.305721
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[7], str)


# Generated at 2022-06-22 18:21:50.362120
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-22 18:21:55.227685
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    import shutil

    with tempfile.TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, 'dummy.txt')
        writer = FileWriter(path, overwrite=True)
        assert writer.write('1\n') is None
        assert writer.write('2\n') is None
        with open(path, encoding='utf-8') as file:
            content = file.read()
        assert content == '1\n2\n'
        shutil.rmtree(temp_dir)


# Generated at 2022-06-22 18:22:06.626666
# Unit test for method trace of class Tracer
def test_Tracer_trace():
   global DISABLED
   DISABLED = False
   import sys
   sys.argv = ['pysnooper', sys.argv[0]]
   class Tracer_object:
      def __init__(self):
         self.watch = []
         self.frame_to_local_reprs = {}
         self.start_times = {}
         self.depth = 1
         self.prefix = ''
         self.overwrite = False
         self.thread_info = False
         self.custom_repr = ()
         self.max_variable_length = 100
         self.normalize = False
         self.relative_time = False
         self._write = sys.stderr.write
         self.target_codes = set()
         self.target_frames = set()
         self.thread_local = threading.local()

# Generated at 2022-06-22 18:22:16.206927
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest

    def test_return_value():
        def foo():
            return 1
        with Tracer() as tracer:
            result = tracer(foo)()
        assert 1 == result

    def test_raise_exception():
        def foo():
            raise ValueError("foo error")
        with Tracer() as tracer:
            with pytest.raises(ValueError):
                tracer(foo)()

    def test_break_loop():
        def foo():
            for i in range(2):
                yield i
        with Tracer() as tracer:
            generator = tracer(foo)()
            assert next(generator) == 0
            assert next(generator) == 1
            with pytest.raises(StopIteration):
                next(generator)

    test_return_value()
   

# Generated at 2022-06-22 18:22:27.528486
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    # sys.path.append('..')
    # from pysnooper import utils

    # with Tracer(normalize=False, overwrite=False) as tracer:
    #     x = 1
    #     y = 2
    #     z = 3
    #     tracer.write('Hello world!')
    #     x = 'abc'
    #     y = 'def'
    #     z = 'ghi'
    #     x = 'jkl'
    #     x = 'mno'
    #     x = 'pqr'
    #     tracer.write('Hello once again!')
    #
    # print(utils.traceback_format(tracer.__enter__.__code__.co_filename,
    #                              tracer.__enter__.__code__.co