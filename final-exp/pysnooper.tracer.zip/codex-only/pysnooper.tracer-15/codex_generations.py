

# Generated at 2022-06-22 18:12:38.422685
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import pytest
    import os.path, pickle, io
    import shutil, stat
    import tempfile
    import coolname
    line = u"""This is the first line in a test text file.
This is the second line in a test text file.
This is the third line in a test text file.
This is the fourth line in a test text file.
This is the fifth line in a test text file.
"""
    # Create a text file and append one line to it
    path = os.path.join(tempfile.gettempdir(), u'FileWriterTestFile.txt')
    FileWriter(path, overwrite=True).write(line)
    content = open(path, u'r').read()
    assert content == line, (u"Failed to write a line to a new text file")
    # Append one line to the text

# Generated at 2022-06-22 18:12:46.606132
# Unit test for function get_write_function
def test_get_write_function():
    # Test 1:
    test_get_write_function_with_output(output=None)
    # Test 2:
    test_get_write_function_with_output(output=sys.stdout)
    # Test 3:
    with utils.FileWriter(output=os.devnull) as fw:
        test_get_write_function_with_output(output=fw)
    # Test 4:
    test_get_write_function_with_output(output=os.devnull)
    # Test 5:

# Generated at 2022-06-22 18:12:47.413213
# Unit test for method write of class Tracer
def test_Tracer_write():
    assert True


# Generated at 2022-06-22 18:12:49.016584
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource(), collections.Sequence)



# Generated at 2022-06-22 18:12:54.167617
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # calling Tracer.__exit__ with dummy data
    # No exception should be thrown
    tracer = Tracer()
    tracer.__exit__(None, None, None)


# Unit tests for method set_thread_info_padding of class Tracer

# Generated at 2022-06-22 18:13:03.111372
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    from . import utils
    from . import pysnooper
    from .utils import AttributeDict
    from .tracer import Tracer
    from .variable import BaseVariable, CommonVariable
    from .variable import Exploding
    from .variable import InverseExploding
    from .variable import Normalizing
    from .tracer import DISABLED
    def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False):
        self._write = get_write_function(output, overwrite)


# Generated at 2022-06-22 18:13:05.793431
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()['asdf'] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:11.524942
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    assert source[1] == u'SOURCE IS UNAVAILABLE'
    with pycompat.assert_raises(KeyError):
        source[2]


# We split the implementation of `.Snapshot` and `.FrameSnapshot` between two
# files here to make the code more readable. This is the second file.


# Generated at 2022-06-22 18:13:22.190594
# Unit test for constructor of class FileWriter
def test_FileWriter():

    class MockWritableStream(object):
        def write(self, s):
            pass

    output = MockWritableStream()
    write_function = get_write_function(output, overwrite=True)
    assert isinstance(write_function, collections.Callable)

    test_path = 'test.txt'

    assert not os.path.isfile(test_path)
    write_function = get_write_function(test_path, overwrite=True)
    write_function('Testing the overwriting operation')
    assert os.path.isfile(test_path)

    with open(test_path, 'r') as fd:
        assert fd.read() == 'Testing the overwriting operation'

    write_function('Testing the appending operation')

# Generated at 2022-06-22 18:13:24.148020
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:35.244228
# Unit test for constructor of class Tracer
def test_Tracer():
    output = StringIO()
    s = Tracer(output=output, watch=(
        'x',
        ('y', lambda x: x + 1),
        'y',
        ('self', lambda self: self),
        'self',
        ('bar', lambda self: self.bar),
        'bar',
    ))

    @s
    class Foo(object):
        bar = 1

        def __init__(self):
            self.y = 2
            self.x = 1

        def baz(self, x):
            self.x = x
            self.y += x
            self.bar += x
            self.bar += 1
            return self.x

    foo = Foo()
    assert foo.baz(3) == 3
    assert 'x = 3' in output.getvalue()
    assert 'y = 5'

# Generated at 2022-06-22 18:13:36.870166
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    _pysnooper.Tracer.__exit__

# Generated at 2022-06-22 18:13:37.843034
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Implement your own test here
    pass

# Generated at 2022-06-22 18:13:49.555063
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    _trace_plotter = Tracer()
    _watch = ('foo', 'self')
    _watch_explode = ('foo', 'self')
    _depth = 2
    _prefix = 'ZZZ '
    _thread_info = True
    _normalize = False
    _relative_time = False
    _custom_repr = ()
    _max_variable_length = 100
    _source_path = r'D:\GitHub\pysnooper\pysnooper.py'

# Generated at 2022-06-22 18:13:58.399007
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    snooper = Tracer()
    def f():
        pass  # line 1
    def g():
        pass
    def h():
        pass
    def i():
        pass
    f2 = snooper(f)
    g2 = snooper(g)
    h2 = snooper(h)
    i2 = snooper(i)
    # Check that the wrapped functions have the correct names
    assert f2.__name__ == f.__name__ == 'f'
    assert g2.__name__ == g.__name__ == 'g'
    assert h2.__name__ == h.__name__ == 'h'
    assert i2.__name__ == i.__name__ == 'i'


# Generated at 2022-06-22 18:14:07.491132
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo():
        a, b, c, d, e, f, g, h, i, j = range(10)
        return locals()
    frame = foo.__code__.create_frame(foo.__globals__, ())
    frame.f_locals = foo()
    assert get_local_reprs(frame) == {
        'a': '0', 'b': '1', 'c': '2', 'd': '3', 'e': '4',
        'f': '5', 'g': '6', 'h': '7', 'i': '8', 'j': '9',
    }

# Generated at 2022-06-22 18:14:10.497123
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    s = 'hello, hello'
    path = 'test.txt'
    a = FileWriter(path, True)
    a.write(s)
    os.remove(path)
# test_FileWriter_write()



# Generated at 2022-06-22 18:14:12.386124
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:14.593582
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import tests.unit
    tests.unit.test_method(Tracer, 'trace')


# Generated at 2022-06-22 18:14:25.893199
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    tracer = Tracer(watch=('j', ))

    def func(i, j, k):
        return i, j, k

    @tracer
    def inner(i, j, k):
        return func(i, j, k)

    class MyTestCase(unittest.TestCase):
        def test_m(self):
            inner(1, 2, 3)

    # Run unit tests
    # unittest.TextTestRunner().run(unittest.TestLoader().loadTestsFromTestCase(MyTestCase))
    unittest.main(module=__name__, exit=False, buffer=True)


if __name__ == "__main__":
    test_Tracer_trace()

# Generated at 2022-06-22 18:14:33.430627
# Unit test for function get_local_reprs
def test_get_local_reprs():
    myscope = {}  # The locals
    exec("a = 3; b = 'abc'", None, myscope)
    frame = utils.Frame(myscope, None)
    assert get_local_reprs(frame) == {'a': 3, 'b': "'abc'"}
    # We can pass in a `watch` sequence of variables or tuples that we want
    # to see
    assert get_local_reprs(frame, watch=(('a',), ('b',))) == {'a': 3, 'b': "'abc'"}
    # Let's see a dict with some big values
    myscope['c'] = dict.fromkeys(range(300))

# Generated at 2022-06-22 18:14:42.775686
# Unit test for function get_write_function
def test_get_write_function():
    output = None
    write = get_write_function(output, overwrite=False)
    write('hello there')
    assert sys.stderr.getvalue() == 'hello there'

    output = io.StringIO()
    write = get_write_function(output, overwrite=False)
    write('hello there')
    assert output.getvalue() == 'hello there'

    output = 'somefile.txt'
    write = get_write_function(output, overwrite=True)
    write('hello there')
    assert len(Path(output).read_text()) > 0 # there is some content

    output = 'somefile.txt'
    Path(output).write_text('some old text')
    write = get_write_function(output, overwrite=True)
    write('hello there')
    assert Path(output).read_text

# Generated at 2022-06-22 18:14:54.282067
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func(a, b, c):
        a = b = c = (1, 2, 3)
        d = e = f = (4, 5, 6)
        d = 7
        e = 8
        f = 9
        g = h = i = (10, 11, 12)
        j = k = l = (13, 14, 15)
        return a, b, c, d, e, f, g, h, i, j, k, l

    frame = utils.exec_func_in_new_frame(func, (1, 2, 3), {})


# Generated at 2022-06-22 18:15:05.056737
# Unit test for constructor of class Tracer
def test_Tracer():
    output = io.StringIO()
    t = Tracer(output=output,
                                 watch="abc", watch_explode="kwargs", depth=3,
                                 prefix='PREFIX ', overwrite=True,
                                 thread_info=False, custom_repr=(),
                                 max_variable_length=100, normalize=False,
                                 relative_time=False)
    assert t._write == output.write
    assert t.watch == [CommonVariable("abc"), Exploding("kwargs")]
    assert t.frame_to_local_reprs == {}
    assert t.start_times == {}
    assert t.depth == 3
    assert t.prefix == 'PREFIX '
    assert t.thread_info == False
    assert t.thread_info_padding == 0
    assert t.target_codes == set

# Generated at 2022-06-22 18:15:12.005632
# Unit test for function get_local_reprs
def test_get_local_reprs():
    locals_dict = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    global_dict = {}
    exec('a = 1; b = 2; c = 3; d = 4', global_dict, locals_dict)
    assert get_local_reprs(global_dict['__traceback_hide_frames__'].tb_frame) == collections.OrderedDict([('a', '1'), ('b', '2'), ('c', '3'), ('d', '4')])

# Generated at 2022-06-22 18:15:18.729623
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    start_time = datetime_module.datetime.now()
    tracer = Tracer()
    tracer.__enter__()
    end_time = datetime_module.datetime.now()
    thread_global.depth = 0
    return (start_time, end_time)


# Generated at 2022-06-22 18:15:28.433106
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    file_writer = FileWriter(tempfile.gettempdir() + '/temp_output.txt', True)
    file_writer.write('first line')
    file_writer.write('second line')
    assert(open(tempfile.gettempdir() + '/temp_output.txt',
                'r').read() == 'first linesecond line')
    file_writer.overwrite = True
    file_writer.write('next line')
    assert(open(tempfile.gettempdir() + '/temp_output.txt',
                'r').read() == 'next line')
    os.remove(tempfile.gettempdir() + '/temp_output.txt')



# Generated at 2022-06-22 18:15:38.504208
# Unit test for function get_write_function
def test_get_write_function():

    class DummyOutputStream(utils.WritableStream):
        pass
    class DummyOutputStream2(utils.WritableStream):
        pass

    write_to_stderr = sys.stderr.write
    output_path = 'output'

    assert write_to_stderr == get_write_function(sys.stderr, False)
    assert write_to_stderr == get_write_function(sys.stderr, overwrite=False)
    with pytest.raises(Exception):
        get_write_function(sys.stderr, True)

    os.remove(output_path)

    write_to_output_file_func = get_write_function(output_path, True)
    assert isinstance(write_to_output_file_func, collections.Callable)

    assert isinstance

# Generated at 2022-06-22 18:15:45.658860
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import tempfile
    import threading
    import logging
    import pycompat
    import textwrap
    import pysnooper
    import pytest
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysno

# Generated at 2022-06-22 18:15:50.758462
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as dir:
        temp_path = os.path.join(dir, "temp_file.txt")
        fwriter = FileWriter(temp_path, overwrite=False)
        fwriter.write("stuff")
        fwriter.write("stuff")
        with open(temp_path, 'r') as file:
            assert file.read() == "stuff"



# Generated at 2022-06-22 18:16:02.881825
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    s = UnavailableSource()
    assert s[0] == 'SOURCE IS UNAVAILABLE'
    assert s[:] == 'SOURCE IS UNAVAILABLE'
    assert s[1:2] == 'SOURCE IS UNAVAILABLE'
    assert s[:1] == 'SOURCE IS UNAVAILABLE'
    assert s[1:] == 'SOURCE IS UNAVAILABLE'
    assert s[:2:] == 'SOURCE IS UNAVAILABLE'
    assert s[1:2] == 'SOURCE IS UNAVAILABLE'
    assert s[1::2] == 'SOURCE IS UNAVAILABLE'
    assert s[::2] == 'SOURCE IS UNAVAILABLE'
    assert s[2::2] == 'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:16:10.158355
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(pdb_frame)[0] == __file__
    assert len(get_path_and_source_from_frame(pdb_frame)[1]) > 0
    def function():
        return get_path_and_source_from_frame(pdb_frame)
    assert get_path_and_source_from_frame(function.__code__.co_filename) == \
        get_path_and_source_from_frame(function.__code__.co_filename)
    assert get_path_and_source_from_frame(function.__code__.co_filename) != \
        get_path_and_source_from_frame(__file__)



# Generated at 2022-06-22 18:16:14.268155
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  global DISABLED
  DISABLED = False
  output = StringIO()
  s = Tracer(output=output)
  def foo():
    pass
  s.__call__(foo)

# Test for method set_thread_info_padding of class Tracer

# Generated at 2022-06-22 18:16:16.586805
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source = UnavailableSource()
    source[0]


# Generated at 2022-06-22 18:16:19.494341
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = "ws_test.txt"
    writer = FileWriter(path, True)

    try:
        writer.write("first line\n")
        with open(path) as f:
            assert f.read() == "first line\n"

        writer.write("second line\n")
        with open(path) as f:
            assert f.read() == "second line\n"
    finally:
        try:
            os.remove(path)
        except:
            pass



# Generated at 2022-06-22 18:16:30.116347
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    import pytest
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    with pytest.raises(IndexError):
        source[1]
# `opcode.opmap` is kept here because it is not defined in Python 3.5.2
# (which is the latest available Python version on Travis CI)

# Generated at 2022-06-22 18:16:38.880525
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Setup
    output = StringIO()
    watch = ('x', 'y')
    watch_explode = ('z',)
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    normalize = False
    relative_time = False
    tracer = Tracer(output=output, watch=watch, watch_explode=watch_explode,
                    depth=depth, prefix=prefix, overwrite=overwrite,
                    thread_info=thread_info, custom_repr=custom_repr,
                    max_variable_length=max_variable_length, normalize=normalize,
                    relative_time=relative_time)
    def function_or_class():
        return

# Generated at 2022-06-22 18:16:42.113548
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[23] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[9] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source['bla'] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:16:53.759373
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import random
    sys.path.append('./pysnooper/')
    from pysnooper import tracer as t
    ## test case 1:
    # Input:
    #   function_or_class="dfg"
    #   cls.__dict__="asd"
    #   attr_name="dfg"
    #   attr="dfg"
    #   simple_wrapper="dfg"
    #   function="dfg"
    #   generator_wrapper="dfg"
    #   function_or_class=None
    # Expected Output:
    #   function_or_class=None
    # Actual Output:
    DISABLED="asd"
    pycompat.iscoroutinefunction="asd"

# Generated at 2022-06-22 18:17:01.212393
# Unit test for constructor of class FileWriter
def test_FileWriter():
    the_file = open("test_file", "w")
    the_file.close()
    output = FileWriter("test_file", True)
    output.write("this is a test")
    assert open("test_file", "r").read().strip() == "this is a test"
    output = FileWriter("test_file", False)
    output.write("test")
    assert open("test_file", "r").read().strip() == "this is a testtest"
    the_file.close()
    os.remove("test_file")



# Generated at 2022-06-22 18:17:03.442302
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-22 18:17:07.730106
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    a=random.randint(0,10)
    b=random.randint(0,10)
    @pysnooper.snoop(watch_explode=('a'))
    def add(a,b):
        a+=b
        return a
    print(add(a,b))

# Generated at 2022-06-22 18:17:17.840499
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    m = UnavailableSource()
    assert m[0] == u'SOURCE IS UNAVAILABLE'
    assert m[-1] == u'SOURCE IS UNAVAILABLE'
    assert m[0:1] == u'SOURCE IS UNAVAILABLE'
    assert m[0:7] == u'SOURCE IS UNAVAILABLE'
    assert m[0:-1] == u'SOURCE IS UNAVAILABLE'
    assert m[-11:12] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:17:30.061094
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pytest
    from pysnooper.utils import get_write_function
    from pysnooper.tracer import Tracer
    from pysnooper.variable_trace import CommonVariable
    from pysnooper.variable_trace import Exploding
    from pysnooper.variable_trace import BaseVariable
    import inspect
    import functools
    import threading
    import sys
    import opcode
    import traceback
    import os
    import itertools
    import datetime

    # Mocks and stubs:
    class MockFrame:
        def __init__(self):
            self.f_code = MockCode()
            self.f_lineno = None
            self.f_back = None
            self.f_locals = {}


# Generated at 2022-06-22 18:17:34.385612
# Unit test for method write of class Tracer
def test_Tracer_write():
    write1 = Tracer._write
    write2 = get_write_function(sys.stdout)
    write3 = get_write_function(r"C:\Users\Administrator\Desktop\pysnooper_test.txt")
    write4 = get_write_function(None)
    for string in 'python', 'is', 'very', 'cool':
        write1(string)
        write2(string)
        write3(string)
        write4(string)


# Generated at 2022-06-22 18:17:42.348514
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import builtins
    import inspect
    import mock
    import six
    import threading
    import time
    import unittest
    import unittest.mock
    import warnings
    import sys

    from pysnooper.tracing import Tracer  # noqa


    class TracerTest(unittest.TestCase):

        @mock.patch('pysnooper.tracing.get_write_function')
        def setUp(self, *_: unittest.mock.Mock) -> None:
            self.function_or_class = unittest.mock.Mock()
            self.output = unittest.mock.Mock()
            self.watch = unittest.mock.Mock()
            self.watch_explode = unittest.mock.Mock()
           

# Generated at 2022-06-22 18:17:44.324627
# Unit test for function get_write_function
def test_get_write_function():
    output = sys.stderr
    write = get_write_function(output, False)
    write('test')
#print(test_get_write_function)



# Generated at 2022-06-22 18:17:56.589718
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, False) # output to stderr
    write('hello\n')

    class StringIO:
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s
    output = StringIO()
    write = get_write_function(output, False) # output to StringIO
    write('hello\n')

    def write_to_file(s):
        with open('test_file', 'a') as file:
            file.write(s)
    write = get_write_function(write_to_file, False)
    write('hello\n')
    write('world\n')
    with open('test_file') as file:
        assert file.read() == 'hello\nworld\n'

# Generated at 2022-06-22 18:18:05.924521
# Unit test for method write of class Tracer
def test_Tracer_write():
    pysnooper.register_trace()

    @pysnooper.snoop()
    def foo():
        pass

    with open('test_Tracer_write.log', 'w') as f:
        foo()
        f.flush()
        with open('test_Tracer_write.log', 'r') as f:
            assert f.readline() == 'Source path:... ./pysnooper.py\n'
        assert os.stat('test_Tracer_write.log').st_size > 0
        os.remove('test_Tracer_write.log')


# Generated at 2022-06-22 18:18:17.766815
# Unit test for constructor of class FileWriter
def test_FileWriter():
    tmp_file = pycompat.Path(__file__).parent / 'tmp_FileWriter.log'

# Generated at 2022-06-22 18:18:27.935038
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    from unittest.mock import MagicMock
    from threading import Thread
    import time
    t = Tracer()

    len_thread_info = len(t.set_thread_info_padding('hello'))
    thread_info = 'hello'
    assert t.set_thread_info_padding(thread_info) == thread_info.ljust(len_thread_info)
    thread_info = 'hello1'
    assert t.set_thread_info_padding(thread_info) == thread_info.ljust(len_thread_info)
    thread_info = 'hello12'
    assert t.set_thread_info_padding(thread_info) == thread_info.ljust(len_thread_info)

    def f(t):
        thread_info = 'hello1'
        t.set_thread

# Generated at 2022-06-22 18:18:30.231900
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    uas = UnavailableSource()
    assert uas[1:2] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:32.142699
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()['foo'] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:42.473815
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    temp_dir = tempfile.TemporaryDirectory()
    temporary_path = pycompat.Path(temp_dir.name) / 'file'

    writer = FileWriter(temporary_path, overwrite=True)
    writer.write(u'test')
    assert temporary_path.read_text(encoding='utf-8') == u'test'
    writer.write(u' test')
    assert temporary_path.read_text(encoding='utf-8') == u'test test'

    writer = FileWriter(temporary_path, overwrite=False)
    writer.write(u'test')
    assert temporary_path.read_text(encoding='utf-8') == u'test test\ntest'
    writer.write(u' test')

# Generated at 2022-06-22 18:18:44.631305
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert list(UnavailableSource()) == \
           list([u'SOURCE IS UNAVAILABLE'])



# Generated at 2022-06-22 18:18:52.957438
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    unavailable_source_lines = [line
                                for line in unavailable_source]
    assert unavailable_source_lines == [u'SOURCE IS UNAVAILABLE']



# Generated at 2022-06-22 18:19:04.751052
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False) is sys.stderr.write
    assert get_write_function(sys.stdout, False) is sys.stdout.write
    assert callable(get_write_function(utils.StringIO(), False))
    assert get_write_function('/tmp/x', False) is FileWriter('/tmp/x', False).write
    assert get_write_function('/tmp/x', True) is FileWriter('/tmp/x', True).write
    assert callable(get_write_function(lambda s: None, False))
    try:
        get_write_function(utils.StringIO(), True)
    except Exception:
        pass
    else:
        raise Exception

# Generated at 2022-06-22 18:19:12.720816
# Unit test for function get_write_function
def test_get_write_function():
    def write_to_stderr(s):
        sys.stderr.write(s)
    def write_to_given_stream(stream):
        def write(s):
            stream.write(s)
        return write
    assert get_write_function(None, False) == write_to_stderr
    assert get_write_function('foo', False) == FileWriter('foo', False).write
    assert get_write_function(write_to_stderr, False) == write_to_stderr
    assert get_write_function(sys.stdout, False) == write_to_given_stream(sys.stdout)
    assert get_write_function('foo', True) == FileWriter('foo', True).write

# Generated at 2022-06-22 18:19:18.316781
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer(watch=())

    # tests of no_skip
    assert tracer._is_internal_frame(inspect.currentframe()) == False
    assert tracer._is_internal_frame(inspect.currentframe().f_back) == True

    frame = inspect.currentframe()
    frame.f_code.co_filename = Tracer.__call__.__code__.co_filename
    assert tracer._is_internal_frame(frame) == False
    


# Generated at 2022-06-22 18:19:23.252306
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    from bdd_tester_common import bdd_tester_common
    logger = bdd_tester_common.setup_logging(filename="test_Tracer_set_thread_info_padding.log", level=logging.DEBUG)
    logger.info("Running Test: test_Tracer_set_thread_info_padding")
    test_Tracer = Tracer()
    test_Tracer.thread_info_padding = 0
    test_Tracer.set_thread_info_padding("test_thread")
    logger.info(str(test_Tracer.thread_info_padding))
    logger.info(str(len("test_thread")))
    assert test_Tracer.thread_info_padding == len("test_thread")

# Generated at 2022-06-22 18:19:27.456136
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:19:31.154950
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    uas = UnavailableSource()
    i = 0
    while True:
        try:
            uas[i]
            i += 1
        except IndexError:
            break
    assert i == 1, (i, uas)




# Generated at 2022-06-22 18:19:32.435887
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0]



# Generated at 2022-06-22 18:19:35.924231
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'
    try:
        unavailable_source[1:2]
        assert False
    except TypeError:
        pass



# Generated at 2022-06-22 18:19:38.944146
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def a():
        b()
    def b():
        get_path_and_source_from_frame(inspect.currentframe())
    a()



# Generated at 2022-06-22 18:19:48.656440
# Unit test for function get_write_function
def test_get_write_function():
    # Test with None as output
    write_function = get_write_function(None, False)
    assert output_equals_stderr(write_function, "test")

    # Test with a writable stream as output
    import io
    output = io.BytesIO()
    write_function = get_write_function(output, False)
    assert write_function("test") == 4
    output.seek(0)
    assert output.read().decode("utf-8") == "test"
    output.close()

    # Test with a function as output
    def output_function(text):
        return len(text)
    write_function = get_write_function(output_function, False)
    assert write_function("test") == 4

    # Test with a string as output
    output = "out.txt"
   

# Generated at 2022-06-22 18:19:53.847479
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[-1] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[-2] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:19:57.955486
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def trace_helper():
        with Tracer():
            x = 1
            try:
                assert x == 2
            except AssertionError:
                pass
    return trace_helper


# Generated at 2022-06-22 18:20:07.018461
# Unit test for function get_write_function
def test_get_write_function():
    print('test_get_write_function')
    with open('/tmp/test_get_write_function', 'w') as f:
        assert get_write_function(f, False) == f.write
        assert get_write_function(f, True) == f.write
        assert get_write_function(None, False) == sys.stderr.write
        assert get_write_function(None, True) == sys.stderr.write
        assert get_write_function('/tmp/test_get_write_function', False) != f.write
        assert get_write_function('/tmp/test_get_write_function', True) != f.write
        def func(s):
            print('hi', repr(s))
        assert get_write_function(func, False) == func



# Generated at 2022-06-22 18:20:09.506762
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    '''
    This is a testing function
    '''
    pass

# Generated at 2022-06-22 18:20:13.902887
# Unit test for function get_write_function
def test_get_write_function():
    string_buffer = utils.StringBuffer()
    write_function = get_write_function(string_buffer, overwrite=False)
    assert write_function('hello')
    assert string_buffer.getvalue() == 'hello'



# Generated at 2022-06-22 18:20:19.470177
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import os, sys, re
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(delete=True)

# Generated at 2022-06-22 18:20:22.772798
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    print("testing __enter__")
    # This function uses a Python function that is not available in IronPython
    print("(not implemented)")



# Generated at 2022-06-22 18:20:28.990754
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from .mock_io import get_mock_io_files, MockFile
    # Test Tracer.__call__()
    # (pdb) TestTracer___call__.test_Tracer___call__()
    t = Tracer()
    outf = MockFile()
    errf = MockFile()
    with get_mock_io_files(stdout=outf, stderr=errf):
        @t
        def foo(x, y=2):
            z = [3, 4]
            return x + y + z[0]

        # Shouldn't print anything on first call
        foo(1)
        assert outf.data == ''

        # Second call should print first
        foo(1)

# Generated at 2022-06-22 18:20:37.894813
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def f():
        eval('')

    frame = sys._getframe(0)

    import inspect
    def g():
        return inspect.currentframe()

    # This makes sure we get the right source code if we can't get it
    # directly from the source code loader, i.e. if we need to read it from a
    # file.
    from random import randint
    frame = g()
    frame.f_globals['__name__'] = '_test_cute_profile_{}'.format(randint(0, 10**10))

    frame.f_code.co_filename = 'foo.py'
    path, source = get_path_and_source_from_frame(frame)
    assert path == 'foo.py'
    assert source == UnavailableSource()

    # Creating a new frame and setting the

# Generated at 2022-06-22 18:20:48.097322
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    DISABLED = False
    global thread_global
    thread_global = threading.local()
    SOURCE = """def foo():
        pass"""

    class TestTracer_trace(unittest.TestCase):
        def setUp(self):
            self.snooper = Tracer(output=BytesIO(), watch=('foo',))

        def test_trace(self):
            self.snooper.watch = ('x', 'y')
            self.snooper.depth = 2
            self.snooper.prefix = ''
            self.snooper.thread_info = False
            self.snooper.thread_info_padding = 0
            self.snooper.target_codes = set()
            self.snooper.target_frames = set()

# Generated at 2022-06-22 18:20:55.582835
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path_to_file = 'tests/debug_value/FileWriter/file_to_be_overwritten.txt'
    if os.path.exists(path_to_file):  # if file exists then delete it
        os.remove(path_to_file)
    file_write = FileWriter(path_to_file, False)
    text_to_write = 'text to write'
    file_write.write(text_to_write)
    with open(path_to_file, 'r', encoding='utf-8') as file:
        written_content = file.read()
    assert written_content == text_to_write, "FileWriter is not working as expected"



# Generated at 2022-06-22 18:21:07.114519
# Unit test for function get_local_reprs
def test_get_local_reprs():
    class LocalReprObject(object):
        def __repr__(self):
            return 'Special repr'
    assert get_local_reprs(None, watch=[
        CommonVariable('a', 'b', 'c', 'd'),
        CommonVariable('e', 'f', 'g', 'h'),
    ], custom_repr={LocalReprObject: 'LocalReprObject'}) == {
        'b': 'Special repr',
        'd': 'Special repr',
        'f': 'Special repr',
        'h': 'Special repr',
        'a': '<CommonVariable: a=b>',
        'c': '<CommonVariable: c=d>',
        'e': '<CommonVariable: e=f>',
        'g': '<CommonVariable: g=h>',
    }
    assert get_

# Generated at 2022-06-22 18:21:18.008069
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.watch = [
        v if isinstance(v, BaseVariable) else CommonVariable('v')
        for v in utils.ensure_tuple('v')
    ]
    tracer.frame_to_local_reprs = {'frame': {}}
    tracer.start_times = {'frame': 'start_time'}
    tracer.depth = 1
    tracer.prefix = ''
    tracer.thread_info = False
    tracer.thread_info_padding = 0
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.custom_repr = tuple()
    tracer.last_source_path = None
    tracer.max_variable_length = 100
    tracer.normalize = False
   

# Generated at 2022-06-22 18:21:24.657608
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    snoop = pysnooper.snoop(thread_info=True)
    @snoop
    def test_set_thread_info_padding():
        time.sleep(0.1)
        time.sleep(0.1)
    test_set_thread_info_padding()

# Generated at 2022-06-22 18:21:35.783762
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os

    file_path = tempfile.NamedTemporaryFile(delete=False).name
    my_writer = FileWriter(file_path, overwrite=True)
    my_writer.write('my_text')
    with open(file_path, 'r', encoding='utf-8') as my_file:
        assert my_file.read() == 'my_text'

    my_writer.write('my_text')
    with open(file_path, 'r', encoding='utf-8') as my_file:
        assert my_file.read() == 'my_textmy_text'

    os.remove(file_path)
test_FileWriter_write()



# Generated at 2022-06-22 18:21:43.405135
# Unit test for function get_write_function
def test_get_write_function():
    with utils.output_captured(get_write_function(None, False)) as output:
        print(123)
    assert output.getvalue() == '123\n'
    with utils.output_captured(get_write_function(sys.stderr, False)) as output:
        print(123)
    assert output.getvalue() == '123\n'
    with utils.output_captured(get_write_function(sys.stdout, False)) as output:
        print(123)
    assert output.getvalue() == '123\n'
    with utils.output_captured(get_write_function(utils.WritableFileLikeObject(), False)) as output:
        print(123)
    assert output.getvalue() == '123\n'

# Generated at 2022-06-22 18:21:51.245581
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # Scenario 1: Thread info for current thread is shorter than padding
    tracer = Tracer()
    result = tracer.set_thread_info_padding('(0) MainThread')
    expected = '(0) MainThread '
    assert result == expected

    # Scenario 2: Thread info for current thread is longer than padding
    tracer.set_thread_info_padding('(100864) Thread-1')
    result = tracer.set_thread_info_padding('(19) Thread-2')
    expected = '(19) Thread-2   '
    assert result == expected


# Generated at 2022-06-22 18:22:04.192500
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.tracer = Tracer()
            self.test_function = lambda self: None
            self.test_code = self.test_function.__code__

        def test_simple_function(self):
            self.tracer.target_codes.add(self.test_code)
            self.tracer.__enter__()
            self.assertEqual(sys.gettrace(), self.tracer.trace)
            self.assertEqual(self.tracer.thread_local.__dict__.get('original_trace_functions', []),
                             [None])
            self.tracer.__exit__(None, None, None)
            self.assertEqual(sys.gettrace(), None)

       

# Generated at 2022-06-22 18:22:11.729493
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-1] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[100] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-100] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:22:25.592226
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer.trace = Mock()
    tracer.write = Mock()
    tracer.prefix = None
    tracer.depth = 20
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    calling_frame = MagicMock()
    calling_frame.__dict__['f_back'] = {}
    setattr(calling_frame, 'f_code', {})
    calling_frame.__dict__['f_trace'] = Mock()