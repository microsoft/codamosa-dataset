

# Generated at 2022-06-22 18:12:24.141262
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, False)
    write('hello')
    assert sys.stderr.getvalue() == 'hello'

    sys.stderr.seek(0)
    sys.stderr.truncate()

    from .pycompat import StringIO
    output_stream = StringIO()
    write = get_write_function(output_stream, False)
    write('world')
    assert output_stream.getvalue() == 'world'

    output_stream.seek(0)
    output_stream.truncate()
    write = get_write_function(pycompat.Path('ha.txt'), False)
    write('dada')
    assert output_stream.getvalue() == ''
    assert pycompat.Path('ha.txt').read_text() == 'dada'

   

# Generated at 2022-06-22 18:12:26.588656
# Unit test for constructor of class Tracer
def test_Tracer():
    assert inspect.isfunction(Tracer(watch=('foo',))(lambda x:x))


# Generated at 2022-06-22 18:12:27.886871
# Unit test for constructor of class Tracer
def test_Tracer():
    import doctest
    doctest.testmod()


# Generated at 2022-06-22 18:12:29.639138
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[3] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:12:30.447011
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[100] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:12:38.847191
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    exc = None
    try:
        import IPython
    except ImportError:
        pass
    else:
        try:
            ipython_shell = IPython.get_ipython()
            ipython_shell.magic('load_ext autoreload')
            ipython_shell.magic('autoreload 1')
            ipython_shell.magic('autoreload 2')
        except Exception as e:
            exc = e
        else:
            assert ipython_shell.autoreload.magic_autoreload(arg_s='1') == ''
            assert ipython_shell.autoreload.magic_autoreload(arg_s='2') == ''

    import StringIO


# Generated at 2022-06-22 18:12:45.012843
# Unit test for constructor of class Tracer
def test_Tracer():
    p1 = Tracer(watch=('l','m','n'))
    try:
        assert p1.watch == [CommonVariable('l'), CommonVariable('m'), CommonVariable('n')]
        assert p1.frame_to_local_reprs == {}
        assert p1.start_times == {}
        assert p1.depth == 1
        assert p1.prefix == ''
        assert p1.thread_info == False
        assert p1.thread_info_padding == 0
        assert p1.target_codes == set()
        assert p1.target_frames == set()
        assert p1.custom_repr == ()
        assert p1.last_source_path == None
    except BaseException as e:
        print("test_Tracer() failed.")
        print(e.args)
        print(e)


# Generated at 2022-06-22 18:12:50.898515
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import pysnooper
    class Mock(object):
        def __init__(self):
            self.max_variable_length = 100
            self.normalize = False
            self.relative_time = False
            self.prefix = u''
            self.thread_info = False
            self.thread_info_padding = 0
            self.watch = []
            self.watch_explode = []
            self._write = pysnooper._write_log_stderr
            self.custom_repr = []
    import datetime
    import re
    import tempfile
    import os
    import os.path
    t = Tracer()
    m = Mock()
    import threading
    t.thread_local = threading.local()
    t.thread_local.original_trace_functions = []


# Generated at 2022-06-22 18:13:01.496615
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from pysnooper import snoop
    import datetime_module
    import pycompat
    import threading
    import utils
    import inspect
    import functools
    import sys
    import itertools
    import pycompat
    import opcode
    import traceback
    # from pysnooper.utils import Tracer, get_path_and_source_from_frame, \
    #                             get_write_function, get_local_reprs
    # from pysnooper.variable import CommonVariable, BaseVariable, Exploding
    # reload all [variable] module to pick up any change
    import importlib
    importlib.reload(variable)
    # reload all [utils] module to pick up any change
    import importlib
    importlib.reload(utils)
    
    
    # test function

# Generated at 2022-06-22 18:13:04.488646
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    for arg in [
        (None,),
        ([],),
        ([None],),
        ([5],),
        ([-6.14],),
        (['value'],),
        ([6.14, 'value'],),
        ([6.14, 'value', 7],),
        ([6.14, 'value', None],),
        ([6.14, None, 7],),
    ]:
        with pytest.raises(TypeError):
            pysnooper.Snooper(*arg)



# Generated at 2022-06-22 18:13:05.628515
# Unit test for method write of class Tracer
def test_Tracer_write():
    r = Tracer(output=sys.stdout)
    r.write("test")
    assert True

# Generated at 2022-06-22 18:13:15.309115
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from . import variables
    from . import utils
    from . import test_utils
    from . import test_variables

    # First we'll make sure it does what it's supposed to:
    def f_a(x):
        def g_a():
            frame = inspect.currentframe()
            local_reprs = get_local_reprs(frame)
            return {'x': x, 'y': 5} == dict(local_reprs)

        return g_a()

    assert f_a(1)

    def f_b(x):
        def g_b():
            frame = inspect.currentframe()
            local_reprs = get_local_reprs(frame)
            return {'x': x, 'y': 5} == dict(local_reprs)


# Generated at 2022-06-22 18:13:17.839930
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, None)
    write('test')
    assert True
#test_get_write_function()



# Generated at 2022-06-22 18:13:22.345678
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def x():
        get_path_and_source_from_frame(sys._getframe())
    filename, source_lines = get_path_and_source_from_frame(sys._getframe())
    assert source_lines[0] == u'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-22 18:13:32.073507
# Unit test for function get_write_function
def test_get_write_function():
    # `stdout` is a string
    assert get_write_function(stdout, overwrite=True) is None
    # `stderr` is a string
    assert get_write_function(stderr, overwrite=True) is None
    # FileWriter is callable
    assert callable(get_write_function(FileWriter(stdout, overwrite=True),
                                       overwrite=True))
    # `overwrite` can only be used on FileWriter
    assert not callable(get_write_function(stderr, overwrite=True))
    # `output` can only be None, callable or FileWriter
    assert not callable(get_write_function('', overwrite=True))



# Generated at 2022-06-22 18:13:40.270223
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .utils import temp_file

    # This is a copy and paste from test_a_function() of conftest.py

    with temp_file() as (file, filename):
        with pysnooper.snoop(f=file, func_to_decorate=a_function) as snoop:
            a_function(1, 2, 3, a='a', b='b', c='c')
        with open(filename) as f:
            output = f.read()

    # End copy and pasted code

    # Now the actual unit test
    assert len(snoop.start_times) == 1
    assert len(snoop.thread_local.original_trace_functions) == 1
    assert len(snoop.target_frames) == 1

# Generated at 2022-06-22 18:13:44.645558
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import doctest
    return doctest.run_docstring_examples(get_path_and_source_from_frame, globals(),
                                          name='get_path_and_source_from_frame')



# Generated at 2022-06-22 18:13:48.455896
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    def f():
        return 42
    assert UnavailableSource()[f.func_code.co_firstlineno + 1] == \
                                            u'SOURCE IS UNAVAILABLE'
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:13:50.462835
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    for i in (0, 1, 2):
        assert unavailable_source[i] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:00.375595
# Unit test for function get_local_reprs
def test_get_local_reprs():
    class C:
        def __repr__(self):
            return '<C>'

    def f(x):
        y = 2
        z = 3
        c = C()
        a = [x, y, 1, 2, 3]
        b = {'x': x, 'y': y, 'z': z, 'c': c, 'a': a, 'z': [3, 2], 'e': {}}
        d = (x, y, 1, 2, 3)
        e = [[], {}, {'x': x, 'y': y, 'z': z, 'c': c, 'a': a, 'z': [3, 2], 'e': {}}]

# Generated at 2022-06-22 18:14:11.452684
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from . import test_pysnooper
    from .utils import get_write_function
    from . import snooper_class


    from .utils import get_local_reprs
    from .utils import BaseVariable
    from .utils import CommonVariable
    from .utils import Exploding


    import contextlib
    import inspect
    import threading
    import sys
    import functools
    import datetime as datetime_module
    import pycompat
    import six
    import types
    import itertools
    import traceback
    import os


    import opcode

    DISABLED = False
    thread_global = threading.local()


    def test_get_path_and_source_from_frame():
        from . import utils
        from .utils import get_path_and_

# Generated at 2022-06-22 18:14:14.844941
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest  # type: ignore
    with pytest.raises(pytest.SkipTest):
        import pysnooper
        pysnooper.snoop(prefix="ZZZ ")


# Generated at 2022-06-22 18:14:26.692991
# Unit test for method write of class Tracer
def test_Tracer_write():
    with tempfile.TemporaryDirectory() as tmpdir:
        write_file = os.path.join(tmpdir, 'tmp.log')
        tracer = Tracer(watch=('bar', 'baz'), overwrite=True)
        tracer.write('{}', '--')
        def write_func(s):
            with open(write_file, 'a') as f:
                f.write(s)
        tracer._write = write_func
        tracer.write('{indent}Elapsed time: line_no')
        with open(write_file, 'r') as f:
            assert len(list(f.readlines())) == 1
        tracer = Tracer(watch=('bar', 'baz'), prefix='PREFIX', overwrite=True)

# Generated at 2022-06-22 18:14:27.602562
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    UnavailableSource()['foo']



# Generated at 2022-06-22 18:14:30.671086
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:39.111075
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile('w+', encoding='utf-8')
    temp_file_name = temp_file.name
    temp_file.write('bla')
    temp_file.seek(0)
    assert temp_file.read() == 'bla'
    temp_file.close()

    file_writer = FileWriter(temp_file_name, True)
    file_writer.write('hello')
    with open(temp_file_name, 'r') as new_temp_file:
        assert new_temp_file.read() == 'hello'
    os.unlink(temp_file_name)



# Generated at 2022-06-22 18:14:45.073380
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def f(x):
        y = x * 2
        return y

    snoop = Tracer(watch='y')
    frame = inspect.currentframe().f_back
    frame.f_trace = snoop.trace
    snoop.target_codes.add(f.__code__)
    snoop.target_frames.add(frame)
    f(10)
    get_write_function('temp.txt', True).close()
    assert open('temp.txt', 'r').read().strip() == '''\
        Call ended by exception
        Return value:.. 20
    '''
    os.remove('temp.txt')


# Generated at 2022-06-22 18:14:47.979158
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    utils.run_test(Tracer, 'Tracer.__exit__')



# Generated at 2022-06-22 18:14:57.606618
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func(x):
        y = 'hello'
        z = y
        assert y == 'hello'
    frame = utils.capture_frame(func, ('x', 'y', 'z', 'q', 'w'))
    assert get_local_reprs(frame) == {
        'x': '\'the x\'',
        'y': '\'hello\'',
        'z': '\'hello\'',
        'q': '???'
    }
    assert get_local_reprs(frame, max_length=4) == {
        'x': '\'the x\'',
        'y': '\'he...\'',
        'z': '\'he...\'',
        'q': '???'
    }

# Generated at 2022-06-22 18:15:07.782190
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # 
    #     def test_set_trace_function(self):
    #         with self.snoop() as spy:
    #             import trace
    #             trace.stack_entry_delegate = spy
    #             string = 'Spam!'
    #         self.assertEqual(spy.trace_entries[-1].frame.f_locals['string'], 'Spam!')
    #         self.assertEqual(spy.trace_entries[-2].frame.f_locals['spy'], spy)
    # 
    pass # Won't reach this line



if __name__ == '__main__':
    from pysnooper import snoop
    import pysnooper.utils as utils
    snoop(utils.truncate)


### EOF ###
#

# Generated at 2022-06-22 18:15:16.628786
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # test if __init__() works well
    fw = FileWriter('foo.txt', True)
    assert fw.path == 'foo.txt'
    assert fw.overwrite == True

    # test if write() works well
    fw.write('test')

    with open('foo.txt', 'r') as f:
        line = f.read()
    assert line == 'test'

    # test if `write` can append string to the end of the file
    fw.write('\ntest')
    with open('foo.txt', 'r') as f:
        line = f.read()

    assert line == 'test\ntest'
    os.remove('foo.txt')


# Generated at 2022-06-22 18:15:17.424108
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass

# Generated at 2022-06-22 18:15:25.353940
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    _output = sys.stdout
    _watch = ('self',)
    _watch_explode = ()
    _depth = 1
    _prefix = ''
    _overwrite = False
    _thread_info = False
    _custom_repr = ()
    _max_variable_length = 100
    _normalize = False
    _relative_time = False
    _ = Tracer(_output=_output, watch=_watch, 
        watch_explode=_watch_explode, depth=_depth, 
        prefix=_prefix, overwrite=_overwrite, 
        thread_info=_thread_info, custom_repr=_custom_repr, 
        max_variable_length=_max_variable_length, 
        normalize=_normalize, relative_time=_relative_time)
    assert True

# Generated at 2022-06-22 18:15:32.301313
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    #
    # The code below will be executed when run in a Python
    # interpreter, but ignored when imported as a module
    #
    ########################################################################
    # function test_Tracer___enter__
    ########################################################################
    # call
    ########################################################################
    # function test_Tracer___enter__
    ########################################################################
    # return
    ########################################################################
    # return
    pass


# Generated at 2022-06-22 18:15:41.055774
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = 2
        z = 3
        g = lambda: 4
        return f
    f_ = f(1)
    frame = f_.__code__.co_firstlineno - 1
    assert get_local_reprs(frame + 2) == {
        'x': '1',
        'y': '2',
        'z': '3',
        'g': '<function f.<locals>.<lambda> at 0x...>',
        'f': '<function f at 0x...>'
    }

    class C:
        @classmethod
        def method(cls):
            x = 1
        normal = 2
        def __repr__(self):
            return 'repr'
    c = C()
    frame = c.method.__code__.co_

# Generated at 2022-06-22 18:15:43.326515
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:15:48.657652
# Unit test for method write of class Tracer
def test_Tracer_write():
    # Verify that the call to the write() method of class Tracer appends a
    # newline character to the string passed.
    outfile = io.StringIO()
    with Tracer(output=outfile) as tracer:
        def test():
            tracer.write('One line')
        test()
    result = outfile.getvalue().rstrip()
    expected = 'One line'
    assert result == expected
    

# Generated at 2022-06-22 18:15:56.754393
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    try:
        unavailable_source[0.5]
    except TypeError:
        pass
    else:
        assert False, "The index must be an integer."
    try:
        unavailable_source[0:1]
    except TypeError:
        pass
    else:
        assert False, "The index must be an integer."



# Generated at 2022-06-22 18:16:03.170606
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper

    @pysnooper.snoop()
    def a():
        b()
        c()
        d()

    @pysnooper.snoop()
    def b():
        pass

    @pysnooper.snoop()
    def c():
        pass

    @pysnooper.snoop()
    def d():
        d()

    a()

# Generated at 2022-06-22 18:16:10.717054
# Unit test for function get_write_function
def test_get_write_function():
    from . import logging_tools
    output = logging_tools.Logger()
    write = get_write_function(output, False)
    write('123')
    assert output.get_log() == ['123']
    output = logging_tools.Logger()
    write = get_write_function(output, True)
    write('123')
    assert output.get_log() == ['123']
    output = logging_tools.Logger()
    write = get_write_function(output, False)
    write(u'\u041a')
    assert output.get_log() == ['\xd0\x90']
    output = logging_tools.Logger()
    write = get_write_function(output, True)
    write(u'\u041a')

# Generated at 2022-06-22 18:16:21.598018
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import string

    # Building a tracer
    tracer = Tracer(watch=())

    # Case 1: thread_info = ""
    thread_info = ""
    func_result = tracer.set_thread_info_padding(thread_info)
    assert func_result == ""
    assert tracer.thread_info_padding == 0

    # Case 2: thread_info = "ABC"
    thread_info = "ABC"
    tracer.thread_info_padding = string.ascii_uppercase
    func_result = tracer.set_thread_info_padding(thread_info)
    assert func_result == "ABC "
    assert tracer.thread_info_padding == len("ABC ")

    # Case 3: thread_info = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


# Generated at 2022-06-22 18:16:26.961964
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer_object=Tracer(watch='',watch_explode='',depth=1,prefix='',overwrite=1)
    thread_info="thread"
    thread_info_string=tracer_object.set_thread_info_padding(thread_info)
    thread_info_string=thread_info_string.strip()
    assert thread_info == thread_info_string


# Generated at 2022-06-22 18:16:30.858839
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    with utils.temporary_file() as f:
        writer = FileWriter(f, False)
        writer.write(u'hello')
        writer.write(u' world')
        with open(f) as f:
            assert f.read() == u'hello world'



# Generated at 2022-06-22 18:16:33.201933
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer(None, None)
    assert tracer._is_internal_frame(None) == False
    pass


# Generated at 2022-06-22 18:16:42.389215
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import random
    import string

    random_generator = random.Random()  # create a random generator

    def random_string(min_chars=0, max_chars=8):
        """ Generate a random string of fixed length """
        return ''.join(random_generator.choice(string.ascii_lowercase + string.digits) for _ in range(random.randint(min_chars, max_chars)))

    def random_int():
        """ Generate a random int """
        return random_generator.randint(0, 10)

    def random_float():
        """ Generate a random float """
        return random_generator.uniform(-1, 1)


# Generated at 2022-06-22 18:16:44.644666
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()[1]
    assert unavailable_source == 'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:16:56.275823
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from pytest import raises
    from datetime import datetime

    output_filename = datetime.now().strftime('output_%Y-%m-%d-%H-%M-%S.txt')

    output_file = FileWriter(output_filename, True)
    assert output_file.path == output_filename
    assert output_file.overwrite
    output_file.write('hello world')
    with open(output_filename, 'r') as f:
        output_content = f.read()
    assert output_content == 'hello world'
    assert not output_file.overwrite

    output_file = FileWriter(output_filename, False)
    assert output_file.path == output_filename
    assert not output_file.overwrite
    output_file.write('great world')

# Generated at 2022-06-22 18:17:04.264372
# Unit test for constructor of class Tracer
def test_Tracer():
    # pylint: disable=unused-variable
    @pysnooper.snoop(watch=('g', 'h.foo', 'h.foo2', 'h.foo4'),
                     watch_explode=('h', 'h.foo5'))
    def f(z):
        g = 8
        h = SimpleNamespace(foo=7, foo2=lambda x: x+1, foo3=3)
        h.foo4 = 4
        del h.foo3
        h.foo5 = [1, 2, 3]
        raise ValueError
        return z + g + h.foo
    f(1)



# Generated at 2022-06-22 18:17:11.775828
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_path_and_source(frame):
        file_name, source = get_path_and_source_from_frame(frame)
        return file_name, source[frame.f_lineno-1]

    assert get_path_and_source(inspect.currentframe()) == \
        (__file__, 'def test_get_path_and_source_from_frame():')


if hasattr(sys, '_getframe'):
    current_frame = lambda depth=0: sys._getframe(depth + 1)
else:
    def current_frame(depth=0):
        """Return the frame object for the caller's stack frame."""
        try:
            raise Exception
        except Exception:
            return sys.exc_info()[2].tb_frame.f_back


# Generated at 2022-06-22 18:17:19.357403
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    cases = utils.generate_cases([
        ([None, None, None], {}),
        ([None, None, None], dict(DISABLED=False)),
        ([None, None, None], dict(DISABLED=True)),
    ])
    for case in cases:
        try:
            exc_type, exc_value, exc_traceback, kwargs = case
            # Setup
            Tracer.__exit__(exc_type, exc_value, exc_traceback, **kwargs)
        except BaseException as e:
            raise AssertionError(
                'The case did not pass: exc_type={exc_type}, '
                'exc_value={exc_value}, exc_traceback={exc_traceback}, '
                'kwargs={kwargs}'.format(**locals())
            ) from e




# Generated at 2022-06-22 18:17:29.376672
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    class Tracer:
        def __init__(self):
            pass
        def __enter__(self):
            pass
        def __exit__(self, exc_type, exc_value, exc_traceback):
            pass

    tracer = Tracer()
    tracer.__enter__()
    tracer.__exit__(None, None, None)
    # Unit test for method checkDepth of class Tracer
    def test_Tracer_checkDepth():
        class Tracer:
            def __init__(self):
                pass
            def __enter__(self):
                pass
            def __exit__(self, exc_type, exc_value, exc_traceback):
                pass

        tracer = Tracer()
        tracer.__enter__()
        tracer.__exit__(None, None, None)



# Generated at 2022-06-22 18:17:32.212164
# Unit test for constructor of class Tracer
def test_Tracer(): #pylint: disable=missing-docstring
    @snoop()
    def foo(): #pylint: disable=unused-variable
        pass
    assert foo #pylint: disable=pointless-statement


# Generated at 2022-06-22 18:17:40.019769
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[20] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[-1] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[-10] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:41.837111
# Unit test for function get_write_function
def test_get_write_function():
    check_write = get_write_function(None, False)
    check_write("Hello!\n")


# Generated at 2022-06-22 18:17:48.994626
# Unit test for constructor of class Tracer

# Generated at 2022-06-22 18:17:58.048032
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w') as tmp:
        write_path = sys.stdout.name

        output_callback = lambda x: x.rstrip('\r\n')
        output_callback.__name__ = 'output_callback'

        get_write_function(tmp.name)
        get_write_function(tmp)
        get_write_function(sys.stdout)
        get_write_function(write_path)
        get_write_function(output_callback)
        get_write_function(None)
        get_write_function()

# Generated at 2022-06-22 18:18:05.282170
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import threading
    from datetime import datetime
    from ..utils import pycompat
    r = Tracer()
    s = pycompat.threading_get_ident()
    t = threading.current_thread()
    r.set_thread_info_padding("{ident}-{name} ".format(ident=t.ident, name=t.getName()))
    assert r.thread_info_padding == len(str(s)) + 1



# Generated at 2022-06-22 18:18:12.111860
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    from . import pycompat
    if pycompat.PY2:
        import codecs
        write = get_write_function(codecs.open('file.txt', 'w', encoding='utf-8'), False)
    else:
        write = get_write_function('file.txt', False)
    write('Hello, world!')
    assert (utils.file_contents('file.txt') == 'Hello, world!')



# Generated at 2022-06-22 18:18:23.666291
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # path is string or path-like
    # overwrite is True or False
    # An exception should be raised if overwrite is true, but path is not a string
    FileWriter('/tmp/my_file', True)
    FileWriter('/tmp/my_file', False)
    FileWriter(u'/tmp/my_file', True)
    FileWriter(u'/tmp/my_file', False)
    assert pycompat.PY2 or pycompat.PY3
    if pycompat.PY2:
        # make sure it works in Python 2
        FileWriter(unicode('/tmp/my_file'), True)
        FileWriter(unicode('/tmp/my_file'), False)

# Generated at 2022-06-22 18:18:25.351764
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:18:36.082324
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    if not os.path.exists('output_file.txt'):
        with open('output_file.txt', 'w'):
            pass

    f = FileWriter('output_file.txt', overwrite=False)
    f.write('hello')
    with open('output_file.txt', encoding='utf-8') as fp:
        assert fp.read() == ('hello' if pycompat.PY2 else 'hello\n')

    f.write('bye')
    with open('output_file.txt', encoding='utf-8') as fp:
        assert fp.read() == ('hellobye' if pycompat.PY2 else 'hello\nbye\n')

    os.remove('output_file.txt')



# Generated at 2022-06-22 18:18:44.614906
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils

    class MockWritableStream(object):
        def __init__(self):
            self.written_texts = []
        def write(self, text):
            self.written_texts.append(text)

    mock_writable_stream = MockWritableStream()
    mock_write_function = lambda text: None
    assert get_write_function(None, False) is sys.stderr.write
    assert get_write_function(None, True) is sys.stderr.write
    assert get_write_function(mock_writable_stream, False) is mock_writable_stream.write
    assert get_write_function(mock_writable_stream, True) is mock_writable_stream.write
    assert get_write_function(mock_write_function, False)

# Generated at 2022-06-22 18:18:45.372451
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-22 18:18:55.641232
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import time
    import datetime as datetime_module
    import inspect
    import os
    import opcode
    import traceback
    import functools
    from pysnooper import utils
    from pysnooper import pycompat
    from pysnooper import thread_global
    from pysnooper.variable import Variable
    from pysnooper.variable import Exploding
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import BaseVariable
    from pysnooper.code_cache import get_path_and_source_from_frame
    from pysnooper.writer import get_write_function
   
    DISABLED = False
    try:
        from pysnooper.writer import DISABLED
    except ImportError:
        pass


# Generated at 2022-06-22 18:19:04.931303
# Unit test for method write of class Tracer
def test_Tracer_write():
    # Test with output specified but overwrite is False
    file_name = "test_Tracer_write_file.txt"
    os.chdir(os.path.expanduser('~'))
    output = open(file_name, mode='w')
    tracer = pysnooper.snoop(output=output, overwrite=False)
    tracer.write('test1')
    # Close the file output
    output.close()
    # Open the file output
    output = open(file_name, mode='r')
    # Read the file output
    output_read = output.readline().strip('\n')
    # Close the file output
    output.close()
    # Check the output
    assert output_read == 'test1', "Error of testing method"


# Generated at 2022-06-22 18:19:11.158153
# Unit test for constructor of class FileWriter
def test_FileWriter():
    test_write = FileWriter('test_FileWriter.txt', False)
    assert test_write.path == 'test_FileWriter.txt'
    assert not test_write.overwrite
    test_write.write('test_FileWriter')
    test_write = FileWriter('test_FileWriter.txt', True)
    assert test_write.path == 'test_FileWriter.txt'
    assert test_write.overwrite
    test_write.write('test_FileWriter')
    try:
        os.remove('test_FileWriter.txt')
    except OSError:
        pass

# Generated at 2022-06-22 18:19:15.781401
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # Fails when values of `s` and `output_file` doesn't match
    import tempfile
    file_writer = FileWriter(tempfile.TemporaryFile(), False)
    # Should pass
    file_writer.write("s")
    # Should pass
    file_writer.write("")
    # Should pass
    file_writer.write("yo")



# Generated at 2022-06-22 18:19:26.742436
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .variables import Variable

    def f():
        a = 42
        b = 'abc'
        c = Variable('d')
        e = Variable('f', lambda frame: {'f': frame.f_locals['a'] + 1})
        g = {'a': 'xyz', 'b': (1, 2, 3)}
        return a + b

    frame = utils.get_caller_frame().f_back
    assert get_local_reprs(frame, custom_repr={int: '<int %s>'}) == {
        'a': '<int 42>', 'b': "'abc'", 'c': "Variable('d')", 'e':
                                          "Variable('f', <function f at 0x...>)"
    }

# Generated at 2022-06-22 18:19:30.800001
# Unit test for constructor of class FileWriter
def test_FileWriter():
    _write_file = FileWriter(path='test_FileWriter', overwrite=True)
    assert _write_file.path == 'test_FileWriter'
    assert _write_file.overwrite is True
    _write_file.write('test_FileWriter')



# Generated at 2022-06-22 18:19:34.281384
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    class Foo(object):
        def foo(self):
            return 1
    f = Foo()
    @pysnooper.snoop()
    def bar():
        return 2
    f.foo()
    bar()
    

# Generated at 2022-06-22 18:19:41.161506
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    current_thread = threading.current_thread()
    thread_info = current_thread.getName()

    tracer.set_thread_info_padding(thread_info)
    if len(thread_info) > tracer.thread_info_padding:
        tracer.thread_info_padding = len(thread_info)
    assert tracer.set_thread_info_padding(thread_info) == thread_info.ljust(
        tracer.thread_info_padding)

    thread_info = 'test'
    assert tracer.set_thread_info_padding(thread_info) == thread_info.ljust(
        tracer.thread_info_padding)


# Generated at 2022-06-22 18:19:50.541822
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)

    thread_info = tracer.set_thread_info_padding('main-MainThread')
    assert thread_info == 'main-MainThread'

    thread_info = tracer.set_thread_info_padding('1-Foo')
    assert thread_info == '1-Foo     ', 'Thread info not padded as expected'

    thread_info = tracer.set_thread_info_padding('1-Foo')
    assert thread_info == '1-Foo     ', 'Thread info not padded as expected'


# Generated at 2022-06-22 18:20:01.557073
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # TODO: since the Tracer class is so complex, maybe cover each of its methods separately, rather than all at once
    global DISABLED
    DISABLED=False
    class SomeClass(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
            # for test_method_not_in_class
            self.z = 3
        @pysnooper.snoop()
        def foo(self):
            return self.x + self.y
        @pysnooper.snoop()
        def bar(self):
            return self.x * self.y
    @pysnooper.snoop()
    def foo(x, y):
        return x + y

# Generated at 2022-06-22 18:20:07.101619
# Unit test for method write of class Tracer
def test_Tracer_write():
    dummyfd = open(os.devnull, 'w')
    with Tracer(output=dummyfd) as tracer:
        tracer.write('123')
        assert True


# Generated at 2022-06-22 18:20:14.918492
# Unit test for function get_write_function
def test_get_write_function():
    with open('temp.txt', 'w') as f:
        new_write_function = get_write_function(f, False)
        new_write_function('TEST')
    assert open('temp.txt').read() == 'TEST'
    os.remove('temp.txt')
    with open('temp.txt', 'w') as f:
        new_write_function = get_write_function(f, True)
        new_write_function('TEST')
    assert open('temp.txt').read() == 'TEST'
    os.remove('temp.txt')


# Generated at 2022-06-22 18:20:20.432109
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    try:
        source = UnavailableSource()[1]
    except:
        print('Exception in test_UnavailableSource')
    if (source != u'SOURCE IS UNAVAILABLE'):
        print('test_UnavailableSource failed')


# Generated at 2022-06-22 18:20:30.539519
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def _test_snooper_method(snooper):
        @snooper
        def func():
            a = 1
            a = 2
            return a
        func()
        func.__code__.co_filename = "blah"
        original_write = snooper.write
        snooper.write = lambda x: None
        snooper.thread_info = True
        snooper.target_codes = set()
        snooper.target_frames = set()
        snooper.set_thread_info_padding = lambda x: x
        snooper.target_codes.add(func.__code__)
        for frame in utils.frame_generator_from(func):
            frame.f_trace = snooper.trace
            snooper.target_frames.add(frame)


# Generated at 2022-06-22 18:20:35.635580
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame_info = inspect.getframeinfo(test_get_path_and_source_from_frame)
    result = get_path_and_source_from_frame(frame_info.frame)
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert isinstance(result[0], str)
    assert isinstance(result[1], list)
    assert result[0] == frame_info.filename
    assert result[1][frame_info.lineno - 1].lstrip() == \
        frame_info.code_context[0]
test_get_path_and_source_from_frame()



# Generated at 2022-06-22 18:20:36.709422
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
      with pytest.raises(NotImplementedError):
        Tracer().__exit__()



# Generated at 2022-06-22 18:20:45.243038
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    class TestFile(object):
        """
        A mockup of a writable stream.
        """
        def __init__(self):
            self.contents = ''

        def write(self, s):
            self.contents += s


    def get_write_function(output, overwrite=False):
        """
        This is the real tested method, but there's no more tests for
        it because it's also tested indirectly by test_FileWriter_write.
        """
        is_path = isinstance(output, (pycompat.PathLike, str))
        if overwrite and not is_path:
            raise Exception('`overwrite=True` can only be used when writing '
                            'content to file.')
        if output is None:
            def write(s):
                stderr = sys.stderr

# Generated at 2022-06-22 18:20:55.481158
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from . import variables
    def foo(a, b):
        return a+b
    class Bar(object):
        values = (1, 2, 3)
        def __repr__(self):
            return 'Bar(' + repr(self.values) + ')'
    bar = Bar()
    x = 'x'
    y = 'y'
    z = 'z'
    d = {'a': 1, 'b': 2}
    t = (1, 2, 3)
    a = 'a'
    def f(x):
        return x * 2
    def g(x):
        return x / 2

# Generated at 2022-06-22 18:21:04.328038
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    '''Unit test for method __exit__ of class Tracer

    '''
    def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False):
        self._write = get_write_function(output, overwrite)

        self.watch = [
            v if isinstance(v, BaseVariable) else CommonVariable(v)
            for v in utils.ensure_tuple(watch)
         ] + [
             v if isinstance(v, BaseVariable) else Exploding(v)
             for v in utils.ensure_tuple(watch_explode)
        ]
        self.frame_to_local_re

# Generated at 2022-06-22 18:21:07.271502
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:21:12.660360
# Unit test for constructor of class FileWriter
def test_FileWriter():
    writer = FileWriter('/tmp/debbug_log.txt', False)
    assert writer.path == '/tmp/debbug_log.txt'
    assert writer.overwrite == False



# Generated at 2022-06-22 18:21:16.121146
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = True
    assert DISABLED
    DISABLED = False
    assert not DISABLED
    with Tracer() as tracer:
        tracer.__exit__(1, 2, 3)

# Generated at 2022-06-22 18:21:28.530426
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import unittest
    from unittest.mock import MagicMock
    self = Tracer(watch='foo')
    write = MagicMock(name='write')
    depth = 1
    prefix = ''
    cls_name = "Klass"
    meth_name = 'meth'
    cls = MagicMock(name='cls')
    cls.__name__ = cls_name
    setattr = MagicMock(name='setattr')
    function = MagicMock(name='function')
    function.__name__ = meth_name
    wrapped_function = MagicMock(name='wrapped_function')
    wrapped_function_name = 'wrapped_' + meth_name
    wrapped_function.__name__ = wrapped_function_name

# Generated at 2022-06-22 18:21:31.558980
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Call with correct arguments.
    # No exception should be thrown.
    # No return value should be given.
    pass


# Generated at 2022-06-22 18:21:33.568262
# Unit test for method write of class Tracer
def test_Tracer_write():
    tr = Tracer()
    tr.write("hello")

test_Tracer_write()


# Generated at 2022-06-22 18:21:41.987382
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # test normal case
    path = './test.txt'
    write_func = FileWriter(path, False)
    write = write_func.write
    write('test')
    with open(path, 'r') as f:
        assert f.read() == 'test'
    # test overwirte
    write_func = FileWriter(path, True)
    write = write_func.write
    write('test')
    with open(path, 'r') as f:
        assert f.read() == 'test'
    # test raise exception
    try:
        FileWriter(path, 1)
    except Exception:
        pass
    else:
        assert 1 == 0
    # test write to file
    write_func = FileWriter(path, False)
    write = write_func.write
    write('test')


# Generated at 2022-06-22 18:21:43.427095
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def f(): pass
    s = Tracer()
    s(f)

# Generated at 2022-06-22 18:21:44.191442
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-22 18:21:53.611072
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import collections
    import re
    import tempfile

    _tmpprefix = tempfile.mktemp()

    @pysnooper.snoop(output=_tmpprefix)
    def foo(x):
        for i in range(x):
            pass

    foo(3)
    with open(_tmpprefix, 'r') as f:
        log = f.read()
    assert re.search(
        r'[\d-]{10} [\d:\.]{12} Call... foo\(3\)',
        log,
    )
    assert re.search(
        r'[\d-]{10} [\d:\.]{12} Line.... 5',
        log,
    )

# Generated at 2022-06-22 18:21:55.158396
# Unit test for constructor of class FileWriter
def test_FileWriter():
    FileWriter('', False)



# Generated at 2022-06-22 18:22:00.983588
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        for x in range(10):
            print(x)
    g_frame = sys._getframe().f_back
    assert get_path_and_source_from_frame(g_frame) == (f.__code__.co_filename,
                                                       inspect.getsourcelines(f)[0])



# Generated at 2022-06-22 18:22:09.971222
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import shutil
    import tempfile
    import os
    if os.path.exists('temp_test_FileWriter_write'):
        shutil.rmtree('temp_test_FileWriter_write')
    os.mkdir('temp_test_FileWriter_write')
    os.chdir('temp_test_FileWriter_write')
    def assert_content(expected_content):
        with open('output.txt', 'r') as f:
            actual_content = f.read()
        if actual_content != expected_content:
            raise AssertionError('\n'.join((
                'Assertion failed!',
                'Expected content:\n%s' % expected_content,
                'Actual content:\n%s' % actual_content
            )))
    # Try to write content to file
    FileWriter

# Generated at 2022-06-22 18:22:22.178230
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer._write = Mock()
    stack = tracer.thread_local.origial_trace_functions = []
    stack.append(MagicMock())
    sys.settrace = MagicMock()
    calling_frame = MagicMock()
    calling_frame.f_code = MagicMock()
    calling_frame.f_trace = MagicMock()
    inspect.currentframe.return_value = MagicMock()
    inspect.currentframe.return_value.f_back = calling_frame
    calling_frame.f_code.co_filename = Tracer.__enter__.__code__.co_filename
    start_time = datetime_module.datetime.now()
    duration = datetime_module.datetime.now() - start_time
    elapsed_time_string = py