

# Generated at 2022-06-22 18:12:31.831682
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = '/tmp/test_FileWriter_write.txt'
    content = 'hello'
    with open(path, 'w') as f:
        f.write(content)

    f = FileWriter(path, True)
    f.write("world\n")

    with open(path, 'r') as f:
        assert f.read() == 'world\n'

    f.write(" foo\n")

    with open(path, 'r') as f:
        assert f.read() == 'world\n foo\n'

    os.remove(path)

# Generated at 2022-06-22 18:12:35.752193
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    current_thread = threading.current_thread()
    thread_info = "{ident}-{name} ".format(ident=current_thread.ident,
                                           name=current_thread.getName())
    assert tracer.set_thread_info_padding(thread_info) == thread_info



# Generated at 2022-06-22 18:12:38.689947
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer._write = lambda x: print(x)
    from pysnooper.utils import test_decorator
    with test_decorator(tracer):
        print(1)
        raise Exception("hehe")
        return 3

# Generated at 2022-06-22 18:12:39.885639
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:12:41.428827
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_filename)[1] \
                                                                      == 'def f():'
# /Unit test for function get_path_and_source_from_frame



# Generated at 2022-06-22 18:12:48.051583
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest

    from pysnooper.pycompat import StringIO
    from pysnooper.pysnooper import Tracer

    output = StringIO()
    tracer = Tracer(output=output)
    saved_trace = sys.gettrace()
    tracer.__enter__()
    assert tracer.trace is sys.gettrace()
    tracer.__exit__(None, None, None)
    assert saved_trace is sys.gettrace()
    tracer.__enter__()
    assert tracer.trace is sys.gettrace()
    tracer.__exit__(None, None, None)
    assert saved_trace is sys.gettrace()

# Generated at 2022-06-22 18:12:59.387316
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class TestTracer___call__:
        def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
                     prefix='', overwrite=False, thread_info=False, custom_repr=(),
                     max_variable_length=100, normalize=False, relative_time=False):
            self._write = get_write_function(output, overwrite)

            self.watch = [
                v if isinstance(v, BaseVariable) else CommonVariable(v)
                for v in utils.ensure_tuple(watch)
             ] + [
                 v if isinstance(v, BaseVariable) else Exploding(v)
                 for v in utils.ensure_tuple(watch_explode)
            ]
            self.frame_to_local_reprs = {}
            self.start

# Generated at 2022-06-22 18:13:05.569118
# Unit test for constructor of class FileWriter
def test_FileWriter():
    output_path = '/tmp/no-2.log'
    content_1 = 'write once'
    content_2 = 'write twice'
    write_1 = FileWriter(output_path, overwrite=True)
    write_1(content_1)
    with open(output_path, 'r') as output_file:
        assert output_file.read() == content_1
    write_2 = FileWriter(output_path, overwrite=False)
    write_2(content_2)
    with open(output_path, 'r') as output_file:
        assert output_file.read() == content_1 + content_2
    os.remove(output_path)



# Generated at 2022-06-22 18:13:08.120825
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:11.561206
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = pysnooper.snoop(thread_info=True)
    thread1 = threading.Thread(target=tracer)
    thread2 = threading.Thread(target=tracer)
    thread1.start()
    thread1.join()
    thread2.start()
    thread2.join()
    assert tracer.thread_info_padding == 15


# Generated at 2022-06-22 18:13:18.751264
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()

    assert source[0] == u'SOURCE IS UNAVAILABLE'
    assert source[1] == u'SOURCE IS UNAVAILABLE'
    assert source[2] == u'SOURCE IS UNAVAILABLE'
    assert source[-1] == u'SOURCE IS UNAVAILABLE'
    assert source[-2] == u'SOURCE IS UNAVAILABLE'
    assert source[-3] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:25.965317
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    f = FileWriter(path=None, overwrite=False)
    assert f.write('hi') == None
    f = FileWriter(path=None, overwrite=True)
    assert f.write('hi') == None
    f = FileWriter(path='hi.txt', overwrite=True)
    assert f.write('hi') == None
    f = FileWriter(path='hi.txt', overwrite=False)
    assert f.write('hi') == None


duration_unit_names_in_order = dict(
    (name, i)
    for i, name in enumerate(('seconds', 'minutes', 'hours', 'days', 'months',
                              'years'))
)



# Generated at 2022-06-22 18:13:33.116456
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    try:
        raise Exception()
    except Exception:
        assert isinstance(UnavailableSource()[0], unicode)
    try:
        raise Exception()
    except Exception:
        assert isinstance(UnavailableSource()[-1], unicode)
    try:
        raise Exception()
    except Exception:
        assert isinstance(UnavailableSource()[0:1], list)
    try:
        raise Exception()
    except Exception:
        assert isinstance(UnavailableSource()[0:1], list)



# Generated at 2022-06-22 18:13:40.952932
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global DISABLED

    def fake_write(s): pass

    def fake_function(a, b):
        return a + b

    def test_function_decorator():
        @snooper.snoop()
        def f(a, b):
            return a + b

        assert f(1, 2) == 3
        assert f.__name__ == 'f'
        assert inspect.getsource(f) == inspect.getsource(fake_function)
        DISABLED = True
        assert f(1, 2) == 3
        # XXX:
        # for some reason, in Python 2.7, PyCharm is printing to stdout in the
        # decorator, and it shouldn't.
        # TODO: investigate the reason
        #


# Generated at 2022-06-22 18:13:52.717739
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def my_function():
        def my_inner_function():
            a = 3
            b = 'a'
            c = 23
            return a + len(b) + c
        x = [my_inner_function(), 4]
        d = {'a': 3}
        return x, d

    assert get_local_reprs(inspect.currentframe().f_back) == {
        'a': '3', 'b': '"a"', 'c': '23', 'x': '[7, 4]', 'd': "{'a': 3}",
    }

# Generated at 2022-06-22 18:13:57.259164
# Unit test for constructor of class Tracer
def test_Tracer():
    class Foo:
        def __init__(self): self.foo = 0
        @pysnooper.snoop(watch_explode=('self',))
        def bar(self, x):
            self.foo += 1
            return x

    foo = Foo()
    foo.bar(5)

# Unit tests for method 'set_thread_info_padding'

# Generated at 2022-06-22 18:14:06.729188
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    def foo():
        pass
    def foo_coroutine():
        yield
    def foo_generator():
        yield
    def foo_asyncgen():
        yield
    def method(self):
        pass
    @tracer
    def decorated():
        pass
    class C:
        @tracer
        def method(self):
            pass
    assert not inspect.iscoroutinefunction(tracer(foo_coroutine))
    assert inspect.iscoroutinefunction(foo_coroutine)
    assert inspect.isgeneratorfunction(tracer(foo_generator))
    assert inspect.isgeneratorfunction(foo_generator)
    assert inspect.iscoroutinefunction(tracer(foo_asyncgen))
    assert inspect.iscoroutinefunction(foo_asyncgen)

# Generated at 2022-06-22 18:14:08.986697
# Unit test for constructor of class FileWriter
def test_FileWriter():
    new_FileWriter = FileWriter('test', False)
    assert new_FileWriter.path == 'test'
    assert new_FileWriter.overwrite is False
    



# Generated at 2022-06-22 18:14:09.538834
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass

# Generated at 2022-06-22 18:14:16.939990
# Unit test for method write of class Tracer
def test_Tracer_write():
    from _pytest.monkeypatch import MonkeyPatch
    monkeypatch = MonkeyPatch()
    original_open = open
    def open_mock(filename, mode):
        if filename.endswith(".py"):
            return MagicMock(spec=TextIOBase)
        return original_open(filename, mode)
    monkeypatch.setattr(builtins, 'open', open_mock)
    import inspect
    import pysnooper
    import os
    import re
    import tempfile
    import textwrap
    import time
    import traceback
    global_vars = globals()
    watch = ['foo']
    output_handle = None
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize

# Generated at 2022-06-22 18:14:27.198972
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, 'file.txt')
        file_writer = FileWriter(path, False)
        file_writer.write(u'hey')
        expected_contents = u'hey'
        with open(path) as f:
            actual_contents = f.read()
        assert actual_contents == expected_contents

        file_writer = FileWriter(path, True)
        file_writer.write(u'hey again')
        expected_contents = u'hey again'
        with open(path) as f:
            actual_contents = f.read()
        assert actual_contents == expected_contents



# Generated at 2022-06-22 18:14:33.878930
# Unit test for constructor of class FileWriter
def test_FileWriter():
    assert FileWriter('1.txt', overwrite=True).overwrite is True
    assert FileWriter('1.txt', overwrite=False).overwrite is False
    assert FileWriter(pycompat.PathLike('1.txt'), overwrite=True).overwrite is True
    assert FileWriter(pycompat.PathLike('1.txt'), overwrite=False).overwrite is False



# Generated at 2022-06-22 18:14:39.604390
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import os
    import threading
    from pysnooper import snoop

    @snoop
    def test_func():
        f = open('/tmp/snooper.1234.test_func.log', 'w')
        f.write('log\n')
        f.close()

    @snoop
    def test_func_with_exception1():
        try:
            test_func2()
        except Exception:
            pass

    @snoop
    def test_func_with_exception2():
        try:
            test_func2()
        except Exception as e:
            raise e

    @snoop
    def test_func2():
        raise Exception('test exception')

    def test_thread_func():
        test_func()

    test_func()
    test_func

# Generated at 2022-06-22 18:14:42.916205
# Unit test for constructor of class FileWriter
def test_FileWriter():
    FileWriter('hi', True).__getattribute__('write')('hi')
    try:
        FileWriter(1, True)
        assert False, 'Expected Exception to be raised'
    except Exception as e:
        assert type(e) == Exception



# Generated at 2022-06-22 18:14:46.524318
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__,
        open(__file__, encoding='utf-8').read().splitlines())



# Generated at 2022-06-22 18:14:56.905080
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    @pysnooper.snoop()
    def foo():
        x = 3
        y = x + 4
        return y
    foo()
    '''
    Line 1: Source path:... /Users/eran/github/pysnooper/pysnooper/snoop.py
    Line 2: Source path:... /Users/eran/github/pysnooper/pysnooper/snoop.py
    Line 3: Source path:... /Users/eran/github/pysnooper/pysnooper/snoop.py
    Line 3: New var:....... x = 3
    Line 3: New var:....... y = 7
    Line 3: Return value:.. 7
    Line 3: Elapsed time: 0:00:00.000001
    '''

# Generated at 2022-06-22 18:15:02.436659
# Unit test for function get_write_function
def test_get_write_function():
    assert inspect.ismethod(get_write_function(None, False))
    assert inspect.ismethod(get_write_function(utils.WritableStream(), False))
    assert inspect.isfunction(get_write_function(lambda s: s.split(), False))
    assert inspect.ismethod(get_write_function(utils.WritableStream(), False))
    assert inspect.ismethod(get_write_function(utils.WritableStream(), False))
    assert inspect.ismethod(get_write_function(utils.WritableStream(), False))
    


# Generated at 2022-06-22 18:15:13.492519
# Unit test for constructor of class Tracer
def test_Tracer():
    from pysnooper import lsnoop, GlobalVars, LocalVars
    # Testing the argument `watch` defined in the constructor of class Tracer
    for watch in [('foo',), ('foo', 'bar')]:
        _tracer = Tracer(watch=watch)
        assert _tracer.watch == [GlobalVars('foo'), GlobalVars('bar')]
    for watch in [(1,), (1, 'bar')]:
        _tracer = Tracer(watch=watch)
        assert _tracer.watch == [LocalVars(1), GlobalVars('bar')]
    for watch in [(1, 'foo'), (2, 'foo'), (3, 'foo')]:
        _tracer = Tracer(watch=watch)

# Generated at 2022-06-22 18:15:24.039870
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from inspect import getsource
    from io import StringIO
    import sys

    def f():

        def h():
            pass

        return 1, 2, 3

    def g():
        pass

    # __call__ is called by the decorated f
    out = StringIO()
    tracer = Tracer(output=out)
    result = tracer(f)
    getsource(result)
    out.seek(0)
    sys.stdout.write(out.read())

    # __call__ can be called by a function g which is not decorated by pysnooper
    out2 = StringIO()
    tracer2 = Tracer(output=out2)
    result = tracer2(g)
    getsource(result)
    out2.seek(0)
    sys.stdout.write(out2.read())


# Generated at 2022-06-22 18:15:32.400592
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, False)
    write('blah')  # Should write to stderr
    s = b''
    write = get_write_function(lambda s2: s.__iadd__(s2), False)
    write('blah')  # Should add to `s`
    assert s == b'blah'
    s = b''
    write = get_write_function(utils.WritableStream(s), False)
    write('blah')  # Should add to `s`
    assert s == b'blah'



# Generated at 2022-06-22 18:15:38.871342
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = 'test_output_file.txt'
    try:
        f = FileWriter(path, True)
        f.write('1')
        f.write('2')
        f.write('3')
        with open(path, 'r') as output_file:
            s = output_file.read()
        assert s == '123'
    finally:
        if os.path.exists(path):
            os.remove(path)
        assert not os.path.exists(path)


episode_number = itertools.count()



# Generated at 2022-06-22 18:15:49.485971
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    snooper = _snoop()
    snooper.depth = 1
    snooper.target_codes.add(test_Tracer_trace.__code__)
    snooper.target_frames.add(inspect.currentframe())
    snooper.watch = [('foo.bar', 'hello')]
    snooper.watch_explode = [('foo.bar', 'hello')]
    snooper.custom_repr = ((((type,), repr),),)
    snooper.max_variable_length = 100
    snooper.normalize = False
    snooper.relative_time = False
    snooper.frame_to_local_reprs = {}
    snooper.start_times = {}
    #snoopper.thread_local = threading.local()
   

# Generated at 2022-06-22 18:16:01.987984
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    import importlib.util
    import shutil

    def create_dummy_file_with_content(content):
        tempdir = tempfile.mkdtemp()
        path = os.path.join(tempdir, 'file.py')
        with open(path, 'wb') as f:
            f.write(content)
        return path

    def create_dummy_module_with_content(content):
        tempdir = tempfile.mkdtemp()
        dummy_module_name = 'dummy_module'
        path = os.path.join(tempdir, dummy_module_name + '.py')
        with open(path, 'wb') as f:
            f.write(content)

# Generated at 2022-06-22 18:16:03.549960
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    self = Tracer()

    self.__enter__()

# Generated at 2022-06-22 18:16:10.805976
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def test_func(a, b, c=None, d=None):
        e = 'hi'
        f = 5
        g = lambda: 7
        h = lambda x: x * 8
        i = 9
        return i

    frame = inspect.currentframe().f_back
    frame.f_locals.update(locals())
    frame.f_locals['g'] = lambda: 3
    frame.f_locals['j'] = 10
    frame.f_locals['var'] = 123

    def custom_repr(x, max_length=None):
        return 'custom repr'


# Generated at 2022-06-22 18:16:19.264023
# Unit test for constructor of class FileWriter
def test_FileWriter():
    def make_test(overwrite):
        def test():
            s = 'hello world!'
            path = utils.make_temp_file()
            writer = FileWriter(path, overwrite)
            writer.write(s)
            with open(path, encoding='utf-8') as f:
                assert f.read() == (s if overwrite else s * 2)
        return test

    test_FileWriter_overwrite_true = make_test(True)
    test_FileWriter_overwrite_false = make_test(False)



# Generated at 2022-06-22 18:16:27.766203
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, None)
    assert write is not None
    write = get_write_function(sys.stderr, None)
    assert write is not None
    write = get_write_function(False, None)
    assert write is None
    write = get_write_function(True, None)
    assert write is None
    write = get_write_function('test.log', True)
    assert write is not None
    write = get_write_function('test.log', False)
    assert write is not None
assert test_get_write_function() is None


# Generated at 2022-06-22 18:16:38.022335
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_name = 'file_writer_test.txt'
    try:
        from os import remove
        remove(file_name)
    except:
        pass
    file_writer = FileWriter(file_name, False)
    file_writer.write('test1')
    with open(file_name, 'r') as f:
        assert f.read() == 'test1'
    file_writer.write('test2')
    with open(file_name, 'r') as f:
        assert f.read() == 'test1test2'
    file_writer = FileWriter(file_name, True)
    file_writer.write('test3')
    with open(file_name, 'r') as f:
        assert f.read() == 'test3'
    file_writer.write('test4')

# Generated at 2022-06-22 18:16:44.577758
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import unittest

    class TestCase(unittest.TestCase):
        def test_it(self):
            if sys.version_info.major == 2:
                path = os.path.join(os.path.dirname(__file__), 'data',
                                    'get_path_and_source_from_frame.py')
            else:
                path = os.path.join(os.path.dirname(__file__), 'data',
                                    'get_path_and_source_from_frame-py3.py')
            with open(path, 'r', encoding='utf8') as f:
                source = f.read()
            source = source.splitlines()

            frame = inspect.currentframe()
            result = get_path_and_source_from_frame(frame)
            self.assertE

# Generated at 2022-06-22 18:16:56.274841
# Unit test for constructor of class Tracer
def test_Tracer():
    from unittest.mock import patch, Mock
    from .utils import get_local_reprs
    from .variable import CommonVariable, Exploding

    # Test preparation:
    # Pretend that we are in a thread, so that later we can poke it
    thread_global.__dict__['depth'] = -1

    # Test execution:
    tracer = Tracer(output=None,
                    watch=('foo', 'bar',
                           ('baz', 'self')),
                    watch_explode=('spam', 'eggs'),
                    depth=2, prefix='>>>')

    def test_func(foo):
        bar = foo + 1  # noqa
        return bar

    # This is all the instrumentation of the function we're testing.
    test_func = tracer._wrap_function(test_func)

   

# Generated at 2022-06-22 18:17:05.538982
# Unit test for constructor of class Tracer
def test_Tracer():
    # _write is a function that writes to file or stdout, or captures output.
    # capturing is necessary to test that the output is as desired.
    # also capture time output by writing our own time function.
    write_result = []
    def _write(s):
        write_result.append(s)
    # a class for testing
    class b:
        def __init__(self):
            self.a = 3
    # a module for testing
    a = 3
    # function for testing
    @pysnooper.snoop(watch=('a','c','b'))
    def f(c):
        a = 5
        d = b()
        print('printing something')
        return c+a
    f(1)

# Generated at 2022-06-22 18:17:11.018823
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # testing normal return
    def func(x):
        return x + 5
    def func(x):
        return x + 5
    # testing return with exception
    def func(x):
        raise Exception("oops!")
        return x + 5


# Generated at 2022-06-22 18:17:17.627157
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def f():
        x = 1
        s = 's'

    def decorator_factory(*args, **kwargs):
        def decorator(function):
            return function
        return decorator

    @decorator_factory()
    def g():
        x = 1
        s = 's'

    @snoop()
    def h():
        x = 1
        s = 's'

    for _ in [f, g, h]:
        c = Tracer.__call__
        assert c.trace(_) == c



# Generated at 2022-06-22 18:17:29.994733
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper.utils
    # Prepare test data
    frame = None
    event = 'call'
    arg = None
    tracer = Tracer()
    tracer.start_times = {frame: pysnooper.utils.datetime.datetime(2019, 4, 2, 1, 21, 48, 113579)}
    tracer.write = lambda s: None
    tracer.prefix = ''
    tracer.thread_info = False
    tracer.thread_info_padding = 0
    tracer.target_codes = set([])
    tracer.target_frames = set()
    tracer.thread_local = pysnooper.utils.threading.local()
    tracer.custom_repr = ()
    tracer.last_source_path = None

# Generated at 2022-06-22 18:17:38.145068
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.thread_info_padding == 0
    assert tracer.set_thread_info_padding("123") == "123 "
    assert tracer.thread_info_padding == 3
    assert tracer.set_thread_info_padding("123") == "123 "
    assert tracer.thread_info_padding == 3
    assert tracer.set_thread_info_padding("12") == "12  "
    assert tracer.thread_info_padding == 3
    assert tracer.set_thread_info_padding("12") == "12  "
    assert tracer.thread_info_padding == 3
    assert tracer.set_thread_info_padding("12345") == "12345"
    assert tracer.thread_info_padding == 5
    assert tr

# Generated at 2022-06-22 18:17:46.115185
# Unit test for method trace of class Tracer
def test_Tracer_trace():

    # Test if the trace function returns the method trace if an exception
    # is raised
    def test_Tracer_trace_function(trace, frame, event, arg):
        return trace(frame,event,arg)

    tracer = Tracer()

    assert tracer.trace(frame, event, arg) == tracer.trace

    # Test if the trace function returns the method trace if an exception
    # is raised
    def test_Tracer_trace_function(trace, frame, event, arg):
        return trace(frame,event,arg)

    tracer = Tracer()

    assert tracer.trace(frame, event, arg) == tracer.trace

    # Test if the trace function returns the method trace if an exception
    # is raised
    def test_Tracer_trace_function(trace, frame, event, arg):
        return trace

# Generated at 2022-06-22 18:17:52.996148
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    FileWriter('test_FileWriter_write', True).write(u"foo\n")
    assert open('test_FileWriter_write').read() == u"foo\n"
    FileWriter('test_FileWriter_write', False).write(u"bar\n")
    assert open('test_FileWriter_write').read() == u"foo\nbar\n"
    os.remove('test_FileWriter_write')



# Generated at 2022-06-22 18:17:55.594491
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:06.800771
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    import os
    import pysnooper
    import sys
    import tempfile

    output = io.StringIO()
    tracer = pysnooper.Tracer(output=output)
    def test_Tracer():
        with tracer:
            pass
    test_Tracer()
    assert output.getvalue() == ''
    output.close()

    with tempfile.NamedTemporaryFile() as file:
        tracer = pysnooper.Tracer(output=file.name, overwrite=True)
        with tracer:
            pass
        result = file.read().decode()
    assert result == ''

    stdout = sys.stdout
    stdout_fd = stdout.fileno()
    stdout = open(os.dup(stdout_fd), 'w')

# Generated at 2022-06-22 18:18:17.234114
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    temp_path = tempfile.NamedTemporaryFile().name
    writer = FileWriter(temp_path, overwrite=True)
    with open(temp_path, 'w', encoding='utf-8') as f:
        f.write('Hello, world!\n')
        writer.write('He')
        writer.write('y!\n')
        writer.write('What about a Hebrew שלום?\n')
    with open(temp_path, 'r', encoding='utf-8') as f:
        assert f.read() == "Hello, world!\nHey!\nWhat about a Hebrew שלום?\n"



# Generated at 2022-06-22 18:18:19.690824
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:18:25.019926
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .utils import temp_file
    with temp_file(prefix='test_FileWriter_write') as path:
        file_writer = FileWriter(path, overwrite=True)
        file_writer.write('line1\n')
        file_writer.write('line2')
        with open(path, 'r') as f:
            assert f.read() == 'line1\nline2'



# Generated at 2022-06-22 18:18:31.199691
# Unit test for method write of class Tracer
def test_Tracer_write():
    # Test method snippet to check that the contents of file is same as expected
    expected_output = "test line"
    with open("Tracer_write_output.txt", mode='w') as f:
        write = get_write_function(f, True)
        write("test line")
    with open("Tracer_write_output.txt", mode='r') as f:
        assert f.read() == expected_output


# Generated at 2022-06-22 18:18:42.068300
# Unit test for function get_write_function
def test_get_write_function():
    import six
    import io
    assert get_write_function(None, False)('hi') is None
    assert get_write_function(io.BytesIO(), False)('hi') is None
    assert get_write_function(sys.stderr, False)('hi') is None
    assert get_write_function(six.moves.StringIO(), False)('hi') is None
    assert get_write_function('hi.txt', False)('hi') is None
    class MyWritableStream(object):
        def __init__(self):
            self.result = None
        def write(self, s):
            self.result = s
    writable_stream = MyWritableStream()
    assert get_write_function(writable_stream, False)('hi') is None

# Generated at 2022-06-22 18:18:53.949113
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # If we simply call self.trace(frame, event, arg) then Tracer.__exit__ will be executed
    # in the calling frame (i.e. the next frame in stack) but not in the current frame.
    # The following code will cause a RecursionError.
    from .utils import get_path_and_source_from_frame
    import inspect
    import os
    import pycompat
    import sys
    import threading
    frame = inspect.currentframe()
    caller = inspect.getouterframes(frame, 2)[1].frame
    event = 'exception'
    trace = (None, None, None)
    arg = (ValueError, ValueError("'c'"), trace)
    sys_trace = sys.gettrace()
    sys.settrace(snooper.snoop().trace)
    snooper

# Generated at 2022-06-22 18:19:04.041968
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    depth = None
    thread_global = threading.local()
    thread_global.__dict__.setdefault('depth', -1)
    calling_frame = inspect.currentframe().f_back
    def _is_internal_frame(frame):
        return frame.f_code.co_filename == Tracer.__enter__.__code__.co_filename
    if not (_is_internal_frame(calling_frame)):
        calling_frame.f_trace = Tracer.trace
        Tracer.target_frames.add(calling_frame)
    stack = Tracer.thread_local.__dict__.setdefault(
        'original_trace_functions', []
    )
    stack.append(sys.gettrace())

# Generated at 2022-06-22 18:19:11.744701
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_file = temp_dir + '/test'
    string_to_be_written = 'this is the string to be written'
    test_output = FileWriter(temp_file, True)
    test_output.write(string_to_be_written)
    with open(temp_file) as f:
        assert f.read() == string_to_be_written



# Generated at 2022-06-22 18:19:19.767698
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class Class:
        pass


    class TracerSubclass(Tracer):
        def __init__(self):
            pass


    def function():
        pass


    def function_generator():
        yield None


    def function_generator_throwing():
        yield None
        raise Exception('Hi!')


    def function_coroutine():
        yield None


    def function_coroutine_throwing():
        yield None
        raise Exception('Hi!')


    assert isinstance(Tracer()(Class), Class)
    assert isinstance(TracerSubclass()(Class), Class)
    assert isinstance(Tracer()(function), function)
    assert isinstance(Tracer()(function_generator), function_generator)

# Generated at 2022-06-22 18:19:24.182310
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    s = UnavailableSource()
    assert s[0] == u'SOURCE IS UNAVAILABLE'
    assert s[1] == u'SOURCE IS UNAVAILABLE'
    assert s[2] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:19:25.873684
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-22 18:19:36.112268
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    """Test Tracer.__enter__"""
    output = StringIO()
    tracer = Tracer(output=output, watch=('var', 'other_var'))
    frame = MockFrame(code=MockCode(co_filename='foo.py', co_name='function_name'),
                      f_globals={'var': 'value', 'other_var': 'value2'})

    # Test if Tracer.frame_to_local_reprs is populated with
    # the reprs of the watched variables
    assert {} == tracer.frame_to_local_reprs
    tracer.__enter__()
    assert {'var': "'value'", 'other_var': "'value2'"} == tracer.frame_to_local_reprs

    # Test if Tracer.target_codes is filled with co_

# Generated at 2022-06-22 18:19:44.761085
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()

    tracer.depth = 1
    tracer.thread_info = False
    tracer.thread_info_padding = 0
    tracer.target_codes = set('')
    tracer.target_frames = set('')
    tracer._write = lambda x: None

    tracer.thread_local = threading.local()
    tracer.thread_local.original_trace_functions = []
    tracer.start_times = {}
    tracer.start_times[None] = datetime_module.datetime.now()


    with tracer:
        pass

# Generated at 2022-06-22 18:19:46.637116
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False)('foo') is None



# Generated at 2022-06-22 18:19:57.170283
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    thread_info = 'Thread_info_'
    current_thread_len = len(thread_info)
    tracer.thread_info_padding = max(tracer.thread_info_padding, current_thread_len)
    thread_info = thread_info.ljust(tracer.thread_info_padding)
    assert thread_info == 'Thread_info_ '
    thread_info_2 = 'Thread_info_2'
    current_thread_len = len(thread_info_2)
    tracer.thread_info_padding = max(tracer.thread_info_padding, current_thread_len)
    thread_info_2 = thread_info_2.ljust(tracer.thread_info_padding)
    assert thread_info_2 == 'Thread_info_2 '

# Generated at 2022-06-22 18:20:01.630980
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    def f():
        g()
    def g():
        source_path, source_lines = get_path_and_source_from_frame(
            inspect.currentframe())
        assert source_path == inspect.getsourcefile(f)
        assert source_lines[0] == 'def f():'
    f()



# Generated at 2022-06-22 18:20:07.788434
# Unit test for constructor of class Tracer
def test_Tracer():
    assert Tracer(output='/dev/null').output == '/dev/null'
    assert Tracer(output=None).output == sys.stdout
    assert Tracer(output='/dev/null', thread_info=True).thread_info



# Generated at 2022-06-22 18:20:16.698877
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def a():
        b()
    def b():
        c()
    def c():
        import inspect
        frame = inspect.currentframe()
        return get_path_and_source_from_frame(frame)

    path, source = c()
    assert source[0] == 'def a():'
    assert source[1] == '    b()'
    assert source[2] == 'def b():'
    assert source[3] == '    c()'
    assert source[4] == 'def c():'
    assert source[5] == '    import inspect'
    assert source[6] == '    frame = inspect.currentframe()'
    assert source[7] == '    return get_path_and_source_from_frame(frame)'



# Generated at 2022-06-22 18:20:23.280384
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert hasattr(unavailable_source, '__getitem__')
    assert unavailable_source[10] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[1000] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-1000] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:27.389285
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'
    assert uas[-1] == u'SOURCE IS UNAVAILABLE'
    assert uas[1000000] == u'SOURCE IS UNAVAILABLE'
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:20:33.092015
# Unit test for constructor of class FileWriter
def test_FileWriter():
    fw = FileWriter('C:/Users/user/Desktop/debugging.txt', True)
    fw.write("Hello")
    fw.write("World")
    fw1 = FileWriter('C:/Users/user/Desktop/debugging.txt', False)
    fw1.write("Hello")
    fw1.write("World")


# Generated at 2022-06-22 18:20:46.534123
# Unit test for method write of class Tracer
def test_Tracer_write():
    from inspect import currentframe
    import io
    import os
    import threading
    import datetime
    import time
    import traceback

    output = io.StringIO()
    write = get_write_function(output, False)
    tracer = Tracer(output, depth=3, thread_info=True)
    calling_frame = currentframe().f_back
    thread_global = threading.local()

    thread_global.__dict__.setdefault('depth', -1)
    thread_global.depth += 1
    indent = ' ' * 4 * thread_global.depth
    timestamp = "timestamp"
    thread_local = threading.local()
    thread_local.__dict__.setdefault('original_trace_functions', [])

# Generated at 2022-06-22 18:20:52.382650
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    output = io.StringIO()
    with Tracer(output=output, watch='foo'):
        foo = 'bar'
    lines = output.getvalue().strip().splitlines()
    assert lines[0].endswith('Starting var:.. foo = bar')
    assert lines[1].endswith('Return value:.. bar')



# Generated at 2022-06-22 18:21:02.320920
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Num args: 8
    class MockFrame(object):
        def __init__(self, f_code, f_lineno, f_lasti, event, arg):
            self.f_code = f_code
            self.f_lineno = f_lineno
            self.f_lasti = f_lasti
            self.f_trace = None
            self.f_back = None

    class MockCode(object):
        def __init__(self, co_filename, co_code):
            self.co_filename = co_filename
            self.co_code = co_code

    class MockObject(object):
        def __init__(self, pass_code):
            self.pass_code = pass_code


# Generated at 2022-06-22 18:21:10.071507
# Unit test for function get_write_function
def test_get_write_function():
    output = None
    write_function = get_write_function(output, False)
    assert callable(write_function)

    output = sys.stderr
    write_function = get_write_function(output, False)
    assert callable(write_function)
    assert callable(write_function)

    output = os.devnull
    write_function = get_write_function(output, False)
    assert callable(write_function)

    output = os.path.join(os.path.expanduser('~'), 'my.txt')
    write_function = get_write_function(output, False)
    assert callable(write_function)
    assert isinstance(write_function, FileWriter)

    output = os.path.join(os.path.expanduser('~'), 'my.txt')


# Generated at 2022-06-22 18:21:13.002753
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    x = UnavailableSource()
    assert x[0] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:21:18.324801
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper.logging import SimpleLogger
    logger = SimpleLogger(print)
    tracer = Tracer(watch=(('x'),), depth=1)
    tracer.write = logger.write
    def foo():
        x = 3
        y = 4
        return x + y
    def bar():
        return foo()

    bar()

if __name__ == '__main__':
    test_Tracer_trace()

# Generated at 2022-06-22 18:21:24.964390
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    def function(p1, p2):
        return p1 + p2

    with pysnooper.snoop(watch=('p1', ['p2'], {'p3': 'p4'})):
        (function(1, 2), function("a", "b"), function([1, 2], [3, 4]))



# Generated at 2022-06-22 18:21:36.245618
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # Test the normal case.
    snooper = Tracer(thread_info=True)
    padding = snooper.set_thread_info_padding("thread info")
    assert padding == "thread info     "

    # Test multi-threading
    jobs = []
    for i in range(5):
        job = threading.Thread(target=snooper.set_thread_info_padding, args=("thread info" + str(i),))
        jobs.append(job)

    for job in jobs:
        job.start()

    for job in jobs:
        job.join()

    padding = snooper.set_thread_info_padding("thread info")
    assert padding == "thread info 1   "


# Generated at 2022-06-22 18:21:40.244729
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f(x):
        i = 1
        return x + 2
    frame = _get_my_frame()
    assert get_path_and_source_from_frame(frame) == (
        frame.f_code.co_filename, [
            'def f(x):',
            '    i = 1',
            '    return x + 2',
        ])



# Generated at 2022-06-22 18:21:51.062576
# Unit test for constructor of class Tracer
def test_Tracer():
    import tempfile
    import os
    import time
    import shutil

    sources_path = os.path.abspath(os.path.realpath('tests/sources'))
    shutil.copytree(sources_path, os.path.join(tempfile.gettempdir(), 'sources'))
    sources_path = os.path.join(tempfile.gettempdir(), 'sources')

    import tests.sources.pysnooper_tests_source
    from tests.sources.pysnooper_tests_source import *

    test_path = os.path.join(sources_path, 'pysnooper_tests_source.py')

    # Test with custom output file
    f = open(os.path.join(tempfile.gettempdir(), 'test.log'), 'w')

# Generated at 2022-06-22 18:21:52.809164
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()['bla'] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:21:55.753640
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[30] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:21:59.668615
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[10] == u'SOURCE IS UNAVAILABLE'
    assert uas[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:22:08.983170
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import re
    import os
    import pytest

    def test_function(s):
        return s
    tracer = Tracer(output=sys.stdout)#, normalize=True)

    if not os.path.exists("tracer_test_log.txt"):
        os.mknod("tracer_test_log.txt")
    log = open("tracer_test_log.txt", "r+")
    stdout = sys.stdout
    sys.stdout = log
    wrapped_function = tracer._wrap_function(test_function)
    # print(wrapped_function.__code__.co_filename)
    # print(test_function.__code__.co_filename)
    wrapped_function("test1")
    log.seek(0)
    tracer_

# Generated at 2022-06-22 18:22:15.821667
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import garlicsim
    import pytest
    import os

    assert garlintest.file_writer.FileWriter('').path == os.getcwd()
    assert garlintest.file_writer.FileWriter('../').path == '../'
    assert garlintest.file_writer.FileWriter(os.getcwd() + '/..').path == '../'

    with pytest.raises(AssertionError):
        garlintest.file_writer.FileWriter(1)

    with pytest.raises(AssertionError):
        garlintest.file_writer.FileWriter(1.2)



# Generated at 2022-06-22 18:22:16.569155
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-22 18:22:26.151264
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import os
    import tempfile
    # This is a temporary file, so the implicit encoding is utf-8.
    filename = tempfile.mktemp()
    # Test the constructor.
    fw = FileWriter(filename, False)
    assert fw.path == filename
    assert fw.overwrite == False

    # Test the write method.
    # We'll write a non-ascii string.
    fw.write(''.join(chr(i) for i in range(0xa0, 0x100)))
    fw.write('\nThis is crap\n')
    os.remove(filename)
