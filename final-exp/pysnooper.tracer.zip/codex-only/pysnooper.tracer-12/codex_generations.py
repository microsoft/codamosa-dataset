

# Generated at 2022-06-22 18:12:37.206553
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import random
    random.seed(0)
    def foo():
        return random.randint(0, 10)

    tracer = Tracer(output=sys.stderr)
    def test_inexcept(tracer):
        try:
            foo()
        except Exception:
            pass
        else:
            raise RuntimeError("boom")
        with tracer:
            pass
    test_inexcept(tracer)
    def test_outexcept(tracer):
        with tracer:
            foo()
            raise RuntimeError("boom")
    test_outexcept(tracer)


# Generated at 2022-06-22 18:12:38.754156
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    t = Tracer()
    assert t.__exit__(None, None, None) is None

# Generated at 2022-06-22 18:12:43.887184
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from pysnooper import snoop
    from pysnooper.utils import get_output
    @snoop()
    def test1():
        a = 1
        a += 2
        return a
    test1()
    print(get_output())
    assert False # TODO: implement your test here


# Generated at 2022-06-22 18:12:50.292045
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    class Test():
        def __init__(self):
            self.int = 1
            self.string = 'a'
            self.list = [1, 2, 3]
            self.dict = {1:1, 2:2, 3:3}

    t = Test()
    function = lambda:1
    frame = inspect.currentframe()
    event = "call"
    arg = None
    frame.f_locals['function'] = function
    frame.f_locals['t'] = t
    frame.f_lineno = 20
    frame.f_code.co_filename = 'test.py'
    frame.f_code.co_code = bytes('a','ascii')
    original_trace = sys.gettrace()
    sys.settrace(tracer.trace)

# Generated at 2022-06-22 18:13:00.425546
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    import shutil
    tmp_dir = tempfile.mkdtemp()
    tmp_file_name = pycompat.text_type(os.path.join(tmp_dir, 'my_file.txt'))
    text = 'Hello, world!'
    FileWriter(tmp_file_name, overwrite=True).write(text)
    with open(tmp_file_name, 'r') as f:
        assert f.read() == text
    FileWriter(tmp_file_name, overwrite=False).write(text)
    with open(tmp_file_name, 'r') as f:
        assert f.read() == text * 2
    shutil.rmtree(tmp_dir)



# Generated at 2022-06-22 18:13:08.216722
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer.start_times = {'self': mock.MagicMock(), 'frame': mock.MagicMock()}
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.thread_local = threading.local()
    tracer.thread_info = False
    tracer.thread_info_padding = 2
    tracer.last_source_path = 'bar'
    tracer.depth = -1
    tracer.max_variable_length = False
    tracer.normalize = True
    tracer.relative_time = False
    tracer.watch = {}
    tracer.frame_to_local_reprs = {}
    # Assert that the class Tracer's method __enter__ raises no exceptions.

# Generated at 2022-06-22 18:13:11.856820
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        pass
    frame = test_function.__code__.co_filename
    assert frame == test_function.__code__.co_filename
    assert frame == inspect.getframeinfo(frame).filename
    assert frame == get_path_and_source_from_frame(frame)[0]

# Generated at 2022-06-22 18:13:20.816584
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    DISABLED = False
    s = Tracer()
    def f():
        print("1")
        print("2")
        return 33
    s.trace(f.__code__, 'call', None)
    s.trace(f.__code__, 'exception', None)
    s.trace(f.__code__, 'line', None)
    s.trace(f.__code__, 'return', None)
    s.trace(f.__code__, 'return', None)
    DISABLED = True
test_Tracer_trace()


# Generated at 2022-06-22 18:13:25.401388
# Unit test for method write of class Tracer
def test_Tracer_write():
    with mock.patch.object(Tracer, '_write') as mock_write:
        def test_write(s):
            snooper = Tracer()
            snooper.write(s)
            mock_write.assert_called_once_with(u'{s}\n'.format(**locals()))
        test_write('test')
        mock_write.reset_mock()
        test_write('test2')



# Generated at 2022-06-22 18:13:28.507304
# Unit test for function get_write_function
def test_get_write_function():
    assert True
    # output = None
    # overwrite = False
    # write = get_write_function(output, overwrite)
    # assert True



# Generated at 2022-06-22 18:13:37.906400
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def dummy_frame():
        return sys._getframe(1)

    def test_dummy_frame_works():
        import sys
        def foo():
            myvar = 1
        sys._getframe(0).f_locals['myvar']

    assert test_dummy_frame_works() == 1

    result = get_path_and_source_from_frame(dummy_frame())
    assert result[0].endswith('test_pdb_obj.py')
    assert result[1][1] == '        import sys'


if pycompat.PY2:
    def get_path_and_source_from_code(code):
        """Get the source code from the given code object."""

# Generated at 2022-06-22 18:13:49.596418
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.watch = []
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.depth = 1
    tracer.prefix = ''
    tracer.thread_info = False
    tracer.thread_info_padding = 0
    assert tracer.depth >= 1
    tracer.target_codes = set()
    tracer.target_frames = set()
    class thread_local:
        def __init__(self):
            pass
    tracer.thread_local = thread_local()
    tracer.custom_repr = ()
    tracer.last_source_path = None
    tracer.max_variable_length = 100
    tracer.normalize = False
    tracer.relative_time = False

# Generated at 2022-06-22 18:13:53.692805
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import testme
    import inspect
    import os.path

    path_and_source = get_path_and_source_from_frame(inspect.currentframe())
    assert path_and_source[0] == testme.__file__
    assert os.path.basename(path_and_source[0]) == 'testme.py'



# Generated at 2022-06-22 18:13:55.380013
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:14:02.235552
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import tempfile
    output_file_path = tempfile.mkstemp()[1]
    file_writer = FileWriter(output_file_path,
                             overwrite=True)
    file_writer.write('Something\n')
    with open(output_file_path, 'r',
                  encoding='utf-8') as output_file:
        content = output_file.read()
    os.remove(output_file_path)
    assert content == 'Something\n'



# Generated at 2022-06-22 18:14:04.887914
# Unit test for function get_write_function
def test_get_write_function():
    class Stderr:
        def write(self, s):
            print(s)

    assert get_write_function is None
    get_write_function(Stderr(), True)



# Generated at 2022-06-22 18:14:13.960316
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import collections
    ascii_text = ''.join(chr(x) for x in range(32, 127))
    ascii_text_with_new_line = '\n'.join(textwrap.wrap(ascii_text, width=10))
    assert len(ascii_text) == 95
    assert len(ascii_text_with_new_line) == 95 + 4

    @pysnooper.snoop(watch_explode=('*', 'ascii_text', 'self'))
    def foo(ascii_text, self):
        for x in range(32, 127):
            ascii_text += chr(x)
            a = self.bar(ascii_text)
            yield a


# Generated at 2022-06-22 18:14:23.659088
# Unit test for method write of class Tracer
def test_Tracer_write():
    with tempfile.NamedTemporaryFile() as f:
        write = Tracer(output=f, thread_info=True).write
        write(u'foo')
        write(u'bar')
        with utils.temporarily_set_preferred_encoding('ascii'):
            write(u'Glück auf')
        write(u'baz')
        f.flush()
        with f.file as f:
            assert f.read() == (
                'foo\n'
                'bar\n'
                'baz\n'
            )


# Generated at 2022-06-22 18:14:25.670965
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[3] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:28.272933
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    thread_info = "foo"
    thread_info_padded = tracer.set_thread_info_padding(thread_info)
    assert thread_info_padded == "foo   "

# Generated at 2022-06-22 18:14:39.793550
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # Write something to a nonexisting file
    fw = FileWriter('test.txt', True)
    fw.write('Test string')
    assert os.path.isfile('test.txt')
    os.remove('test.txt')
    # Check that overwrite flag is set to False after first use of the
    # FileWriter
    assert not fw.overwrite
    # Write something to an existing file
    with open('test.txt', 'wb') as output_file:
        output_file.write(b'Old string')
    assert os.path.isfile('test.txt')
    # Check that the old content was deleted
    fw.write('Test string')
    expected_content = 'Test string'
    with open('test.txt', 'r') as input_file:
        content = input_file.read()
   

# Generated at 2022-06-22 18:14:46.389776
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils

    assert get_write_function(utils.StdErr(), True)
    assert get_write_function(utils.StdErr(), False)
    assert get_write_function(utils.StdOut(), True)
    assert get_write_function(utils.StdOut(), False)
    assert get_write_function(None, True)
    assert get_write_function(None, False)
    assert get_write_function(lambda: None, True)
    assert get_write_function(lambda: None, False)
    assert get_write_function('/dev/null', True)
    assert get_write_function('/dev/null', False)
    assert get_write_function(utils.get_path('/dev/null'), True)

# Generated at 2022-06-22 18:14:56.869905
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    """
    Unit test for function get_path_and_source_from_frame.
    To run this test, run the following in python:
    ```
    import sys
    sys.path.insert(0, '..')
    import test_get_path_and_source_from_frame
    test_get_path_and_source_from_frame.test_get_path_and_source_from_frame()
    ```
    """

    from .testing import assert_equal

    def function_to_trace():
        a = 1
        b = 2
        return a, b

    frame = inspect.currentframe()
    while frame:
        frame = frame.f_back
        if frame.f_code.co_name == 'function_to_trace':
            break
    else:
        raise AssertionError


# Generated at 2022-06-22 18:15:04.449605
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer() as t:
        assert t.watch == []
        assert t.depth == 1
        assert t.prefix == ''
        assert t.thread_info is False
        assert t.custom_repr == tuple()
        assert t.max_variable_length == 100

    with Tracer(watch=('foo', 'self'), watch_explode=('bar', 'self')) as t:
        assert t.watch == [CommonVariable('foo'), CommonVariable('self'),
                           Exploding('bar'), Exploding('self')]
        assert type(t.watch[0]) == CommonVariable
        assert type(t.watch[2]) == Exploding
        assert t.depth == 1


# Generated at 2022-06-22 18:15:11.721922
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import re
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b'a')
        temp.flush()
        f = FileWriter(temp.name, False)
        f.write(u'b')
        with open(temp.name, 'rb') as temp:
            assert re.match(b'a.*b', temp.read(), re.DOTALL)
        f.write(u'c')
        f.write(u'd')
        with open(temp.name, 'rb') as temp:
            assert re.match(b'a.*b.*c.*d', temp.read(), re.DOTALL)
        f.overwrite = True
        f.write(u'e')

# Generated at 2022-06-22 18:15:14.085497
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[100] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:15:24.799146
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    file_writer = FileWriter(temp_file.name, overwrite=False)
    file_writer.write(u"Hello World!")
    with open(temp_file.name, 'r') as f:
        assert f.read() == "Hello World!"
    file_writer = FileWriter(temp_file.name, overwrite=True)
    file_writer.write(u"Hello World!")
    with open(temp_file.name, 'r') as f:
        assert f.read() == "Hello World!"
    file_writer = FileWriter(temp_file.name, overwrite=False)
    file_writer.write(u"Hello World!")

# Generated at 2022-06-22 18:15:28.544667
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io_module.StringIO()
    tracer = Tracer(output=output)
    tracer.write('test')
    assert output.getvalue() == 'test\n'


# Generated at 2022-06-22 18:15:30.944064
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(g, h):
        i = 1
        j = 2
        return i
    frame = inspect.currentframe().f_back
    assert get_local_reprs(frame) == \
           {'g': 'function', 'h': 'None', 'i': '1', 'j': '2'}



# Generated at 2022-06-22 18:15:40.357302
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(TypeError):
        Tracer()

    with Tracer(output=None):
        pass

    with Tracer(watch=[]):
        pass

    with Tracer(watch=['a']):
        pass

    with Tracer(watch={'a': 1}):
        pass

    with Tracer(watch=(['a'], {'a': 1})):
        pass

    with Tracer(watch_explode=[]):
        pass

    with Tracer(watch_explode=set()):
        pass

    with Tracer(watch_explode=['a']):
        pass

    with Tracer(watch_explode=set(['a'])):
        pass

    with Tracer(watch_explode=(['a'], set(['a']))):
        pass


# Generated at 2022-06-22 18:15:49.787083
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test custom_repr
    def custom_repr_func1(x):
        return '1'

    def custom_repr_func2(x):
        return '2'

    # test max_variable_length
    assert Tracer(max_variable_length=100, custom_repr=((int, custom_repr_func1),
                              (str, custom_repr_func2))).max_variable_length == 100
    assert Tracer(max_variable_length=0).max_variable_length == 100
    assert Tracer(max_variable_length=None).max_variable_length is None

    # test custom_repr

# Generated at 2022-06-22 18:16:00.519473
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_string = '''def f():
    pass
'''
    with utils.temp_dir(test_string) as path:
        module_name = os.path.splitext(os.path.basename(path))[0]
        sys.path.append(os.path.dirname(path))
        module = __import__(module_name)
        frame = module.f.__code__.co_firstlineno + 1
        result = get_path_and_source_from_frame(frame)
        assert result == (path, test_string.splitlines(True) + [u''])
        os.remove(path)


# #############################################################################



# Generated at 2022-06-22 18:16:02.032235
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with Tracer(output=pycompat.bytesio()):
        pass

# Generated at 2022-06-22 18:16:06.565473
# Unit test for function get_write_function
def test_get_write_function():
    # The case of output=None
    write = get_write_function(None, False)
    assert write is not None

    # The case of output is a callable
    def output(s):
        pass
    write = get_write_function(output, False)
    assert write is output

    # The case of output is a writable stream
    import io
    output = io.StringIO()
    write = get_write_function(output, False)
    write('hello')
    assert output.getvalue() == 'hello'

    # The case of output is a path
    import tempfile
    import os
    temp_folder = tempfile.mkdtemp()
    path = os.path.join(temp_folder, 'file.txt')
    write = get_write_function(path, False)
    write('hello')


# Generated at 2022-06-22 18:16:10.689620
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    args = []
    kwargs = {}
    actual = Tracer().__call__(lambda *args, **kwargs: None)(*args, **kwargs)
    expected = None
    assert actual == expected


# Generated at 2022-06-22 18:16:18.103810
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .variables import CommonVariable

    def f():
        a = 5; b = 6
        return a + b

    frame = f.func_code.co_firstlineno + 1
    result = {'a': '5', 'b': '6'}
    assert get_local_reprs(frame, normalize=True) == result
    assert get_local_reprs(frame, normalize=False) == result




# Generated at 2022-06-22 18:16:23.656625
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # TODO: Test that IPython history loading works
    # TODO: Test that `import pytest` works
    # TODO: Test that `from` import works
    # TODO: Test that `from .` import works
    raise NotImplementedError()



# Generated at 2022-06-22 18:16:29.193790
# Unit test for method write of class Tracer
def test_Tracer_write():
    # test case 1
    #@pysnooper.snoop()
    def myFunc():
        print("hello world")
    f =Tracer()
    f.write("here")
    f.write("here")
    #print("a")
    #assert f.write("here") == True
    # test case 2
    #assert f.write("here") == True


# Generated at 2022-06-22 18:16:35.605222
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    directory_path = tempfile.mkdtemp(prefix='python-pdbx_')
    filename = 'test-file_write.txt'
    file_path = os.path.join(directory_path, filename)
    test_string = 'test'
    writer = FileWriter(file_path, True)
    writer.write(test_string)
    assert(os.path.isfile(file_path))
    with open(file_path, 'r') as f:
        read_string = f.read()
    assert(test_string == read_string)



# Generated at 2022-06-22 18:16:39.429763
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest_snoop

    # Basic usage
    tracer = pytest_snoop.snoop.Tracer()
    tracer._write = lambda x: x
    with tracer:
        with tracer:
            pass
    assert not tracer.target_frames


# Generated at 2022-06-22 18:16:43.349939
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func(a, b):
        x = 1; y = 2; z = 3
        return a, b

    frame = inspect.currentframe()
    frame = frame.f_back
    assert get_local_reprs(frame) == {'a': '1', 'b': '2', 'x': '1', 'y': '2', 'z': '3'}



# Generated at 2022-06-22 18:16:45.275130
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print("In Tracer_trace()")
    print("===============================")


# Generated at 2022-06-22 18:16:54.485164
# Unit test for function get_write_function
def test_get_write_function():
    s = 'abcde'
    output_1 = print
    output_2 = sys.stderr
    output_3 = None
    output_4 = 'test.txt'
    write_1 = get_write_function(output_1, False)
    write_2 = get_write_function(output_2, False)
    write_3 = get_write_function(output_3, False)
    write_4 = get_write_function(output_4, True)
    write_1(s)
    write_2(s)
    write_3(s)
    write_4(s)



# Generated at 2022-06-22 18:16:58.542439
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    from . import debugger
    source = debugger.UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    assert source[1] == u'SOURCE IS UNAVAILABLE'
    assert source[2] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:04.273325
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    @pysnooper.snoop(watch=('i','j','k'))
    def func(i,j):
        if i!=0:
            i-=1
            func(i,j)
        else:
            k=j/0
    try:
        func(2,4)
    except:
        pass


# Generated at 2022-06-22 18:17:11.799042
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, None)
    assert isinstance(write, collections.Callable)
    #assert write()
    write = get_write_function('/temp/log.txt', False)
    assert isinstance(write, collections.Callable)
    #assert write()
    write = get_write_function('/temp/log.txt', True)
    assert isinstance(write, collections.Callable)
    #assert write()
    import io
    output = io.StringIO()
    write = get_write_function(output, None)
    assert isinstance(write, collections.Callable)
    #assert write()
    write = get_write_function(lambda x: None, None)
    assert isinstance(write, collections.Callable)
    #assert write()



# Generated at 2022-06-22 18:17:18.793259
# Unit test for function get_write_function
def test_get_write_function():
    class FileObject:
        def __init__(self):
            self.content = b''
        def write(self, content):
            self.content += content
        def __repr__(self):
            return repr(self.content)
    class Kia:
        def __init__(self):
            self.content = b''
        def write(self, content):
            raise Exception('Kia is not happy')
    file_object = FileObject()
    kia = Kia()
    write = get_write_function(file_object, False)
    write(b'Hi')
    assert file_object.content == b'Hi'
    write(b' There')
    assert file_object.content == b'Hi There'
    write = get_write_function(sys.stderr, False)

# Generated at 2022-06-22 18:17:30.438923
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass

    def bar():
        raise NotImplementedError("please implement bar")
    # Test pysnooper.Tracer(output=None, watch=(), watch_explode=(), depth=1,
    #                       prefix='', overwrite=False, thread_info=False,
    #                       custom_repr=(), max_variable_length=100,
    #                       normalize=False):
    with Tracer(watch=("e",), custom_repr=((str, str.upper),)):
        foo()
    with Tracer(watch_explode=("e",), custom_repr=((str, str.upper),)):
        foo()
    with Tracer(watch=("e",), custom_repr=((str, str.upper),)):
        e = "abc"
        foo()


# Generated at 2022-06-22 18:17:36.865078
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import StringIO
    import pysnooper
    import types

    @pysnooper.snoop()
    def div(x, y):
        return x / y
    assert isinstance(div, types.FunctionType)

    @pysnooper.snoop()
    class Div(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __call__(self):
            return self.x / self.y

    assert isinstance(Div, type)

    ### Make the tests repeatable: ###########################################
    #                                                                        #

# Generated at 2022-06-22 18:17:38.860714
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False)('bla') == None



# Generated at 2022-06-22 18:17:47.069358
# Unit test for constructor of class FileWriter
def test_FileWriter():
    output_file_path = os.path.expandvars('%TEMP%\\file_writer.txt')
    write = FileWriter(output_file_path, False)
    write('This is a test')
    assert os.path.exists(output_file_path)
    with open(output_file_path, 'r', encoding='utf-8') as output_file:
        content = output_file.read()
        assert content == 'This is a test'
    write = FileWriter(output_file_path, True)
    write('This is another test')
    with open(output_file_path, 'r', encoding='utf-8') as output_file:
        content = output_file.read()
        assert content == 'This is another test'



# Generated at 2022-06-22 18:17:58.188727
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    buf = io.StringIO()
    tracer = Tracer(watch=('a', 'b', 'c', 'd'))
    tracer._write = buf.write
    frame = inspect.currentframe().f_back
    frame.f_code = test_Tracer_trace.__code__
    frame.f_locals = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    tracer.trace(frame, 'call', None)
    frame.f_locals = {'a': 5, 'b': 2, 'c': 3, 'd': 4}
    tracer.trace(frame, 'call', None)
    frame.f_locals = {'a': 5, 'b': 6, 'c': 7, 'd': 8}
    tracer.trace

# Generated at 2022-06-22 18:18:03.885256
# Unit test for constructor of class Tracer
def test_Tracer():
    instance = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    assert DISABLED

DISABLED = False


# Generated at 2022-06-22 18:18:10.996968
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', delete=False,
                                     encoding='utf-8') as output_file:
        output_file_path = output_file.name
    output_file = FileWriter(output_file_path, overwrite=True)
    output_file.write('Hello world\n')
    with open(output_file_path, 'a', encoding='utf-8') as output_file:
        output_file.write('Hello world\n')
    output_file.write('Hello world\n')
    with open(output_file_path, 'r', encoding='utf-8') as output_file:
        assert output_file.read() == 'Hello world\nHello world\n'
    os.remove(output_file_path)



# Generated at 2022-06-22 18:18:13.654704
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[0:10], unicode)
    assert isinstance(UnavailableSource()[0:10], basestring)

assert UnavailableSource()[0:10] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:24.889855
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import pytest
    from garlicsim.general_misc import cute_testing
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()
    write_function = FileWriter(temp_file.name, overwrite=True).write
    with pytest.raises(TypeError):
        # Can't overwrite if not writing to file
        FileWriter(write_function, overwrite=True)
    for overwrite, number_of_writes in [(True, 1), (False, 2)]:
        file_writer = FileWriter(temp_file.name, overwrite=overwrite)
        write_function = file_writer.write
        with open(temp_file.name, 'w') as f:
            f.write('')

# Generated at 2022-06-22 18:18:31.316574
# Unit test for constructor of class FileWriter
def test_FileWriter():
    if os.path.isdir(os.path.expanduser('~/temp')):
        import tempfile
        path = tempfile.mkdtemp(dir=os.path.expanduser('~/temp'))
    else:
        path = os.path.expanduser('~/temp')

    path = os.path.join(path, 'test.txt')
    fw = FileWriter(path, False)
    fw.write('hello world 1\n')
    fw.write('hello world 2\n')
    fw.write('hello world 3\n')
    fw = FileWriter(path, True)
    fw.write('hello world 1\n')
    fw.write('hello world 2\n')
    fw.write('hello world 3\n')

# Generated at 2022-06-22 18:18:42.143850
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import sys
    import os
    import shutil

    assert callable(get_write_function(None, False))
    temp_dir = tempfile.gettempdir()
    path = tempfile.mktemp(dir=temp_dir)
    write = get_write_function(path, False)
    assert callable(write)
    write('abc')
    with open(path, 'r') as f:
        assert f.read() == 'abc'
    write = get_write_function(path, True)
    assert callable(write)
    write('def')
    with open(path, 'r') as f:
        assert f.read() == 'def'
    write = get_write_function(sys.stderr, False)
    assert callable(write)
    write('ghi')

# Generated at 2022-06-22 18:18:43.896658
# Unit test for constructor of class Tracer
def test_Tracer():
    from pysnooper import Tracer
    tracer = Tracer()
    with tracer:
        a = 1
        b = 2
        c = a + b

# Generated at 2022-06-22 18:18:46.828228
# Unit test for constructor of class Tracer
def test_Tracer():
    from .test import test_utils

    test_utils.simple_test_caller(test_utils.test_Tracer)

DISABLED = False


# Generated at 2022-06-22 18:18:56.219136
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t = Tracer(thread_info=True)
    assert t.set_thread_info_padding('123') == '123'.ljust(3)
    assert t.set_thread_info_padding('1234') == '1234'.ljust(3)
    assert t.set_thread_info_padding('123') == '123'.ljust(4)
    assert t.set_thread_info_padding('123') == '123'.ljust(4)
    assert t.set_thread_info_padding('1234') == '1234'.ljust(4)
    assert t.set_thread_info_padding('123') == '123'.ljust(4)
    assert t.set_thread_info_padding('1234') == '1234'.ljust(4)

# Generated at 2022-06-22 18:19:05.588251
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # We're only testing the cases we actually use, not all the cases
    # that get_path_and_source_from_frame() supports.
    def f():
        pass # Use this function as the frame.
    frame = f.__code__.co_firstlineno - 1
    file_name, source = get_path_and_source_from_frame(f.__code__)
    assert file_name == __file__
    assert source[frame].strip() == 'def f():'

    g = lambda: None
    __loader__ = g.__code__.co_firstlineno - 1
    file_name, source = get_path_and_source_from_frame(g.__code__)
    assert file_name == __file__
    assert source[__loader__].strip() == 'g = lambda: None'

# Generated at 2022-06-22 18:19:16.159865
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest

    @pytest.mark.parametrize('snoop_kwargs, debug_func_kwargs', [
        ({}, {}),
        ({'depth': 2}, {'depth': 2}),
        ({'watch': 'foo'}, {'watch': 'foo'}),
        ({'watch_explode': 'bar'}, {'watch_explode': 'bar'}),
    ])
    def test(monkeypatch, snoop_kwargs, debug_func_kwargs):
        orig_debug_func = debug.DebugFunc
        debug.DebugFunc = Mock()

        def restore_debug_func():
            debug.DebugFunc = orig_debug_func

        request = mock.Mock()
        request.addfinalizer(restore_debug_func)


# Generated at 2022-06-22 18:19:19.202866
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    assert tracer.thread_info_padding == 0
    assert tracer.set_thread_info_padding('foo') == 'foo'
    assert tracer.thread_info_padding == 3
    

# Generated at 2022-06-22 18:19:25.661307
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer.__enter__()
    assert thread_global.depth == -1
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info is False
    assert tracer.thread_info_padding == 0
    assert tracer.thread_local
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.custom_repr == ()
    assert tracer.last_source_path is None
    assert tracer.max_variable_length == 100
    assert tracer.normalize is False
    assert tracer.relative_time is False


# Generated at 2022-06-22 18:19:35.956224
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test function trace()
    # Tests the branch that event == 'return'
    # Tests the branch that not ended_by_exception:
    #     Tests the branch that self.max_variable_length (99) < length of arg
    def function():
        pass
    tracer = Tracer()
    tracer.watch = [].append
    tracer.watch_explode = [].append
    tracer.depth = 1
    tracer.prefix = u''
    tracer.overwrite = False
    tracer.thread_info = False
    tracer.custom_repr = ()
    tracer.max_variable_length = 100
    tracer.normalize = False
    tracer.relative_time = False
    tracer.set_thread_info_padding = MagicMock()
    tracer.write = MagicMock

# Generated at 2022-06-22 18:19:38.236973
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io.StringIO()
    with Tracer(output) as tracer:
        tracer.write("")
    assert output.getvalue() == "\n"


# Generated at 2022-06-22 18:19:41.155324
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    a = UnavailableSource()
    assert a[1] == 'SOURCE IS UNAVAILABLE'
    import pytest
    with pytest.raises(TypeError):
        a['5']



# Generated at 2022-06-22 18:19:52.946333
# Unit test for function get_write_function
def test_get_write_function():
    import types
    import tempfile
    def func():
        pass
    assert isinstance(get_write_function(None), types.FunctionType)
    temp_path = tempfile.NamedTemporaryFile().name
    assert isinstance(get_write_function(temp_path), types.FunctionType)
    assert isinstance(get_write_function(func), types.FunctionType)
    assert isinstance(get_write_function(sys.stdout), types.FunctionType)
    assert isinstance(get_write_function(0), AssertionError)
    assert isinstance(get_write_function((0,0)), AssertionError)
    assert isinstance(get_write_function([]), AssertionError)
    assert isinstance(get_write_function(''), AssertionError)

# Generated at 2022-06-22 18:20:01.368963
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.set_thread_info_padding("thread_01-main")
    assert tracer.thread_info_padding == 13
    tracer.set_thread_info_padding("thread_01-dummy")
    assert tracer.thread_info_padding == 13
    tracer.set_thread_info_padding("thread_02-main")
    assert tracer.thread_info_padding == 14
    tracer.set_thread_info_padding("t-dummy")
    assert tracer.thread_info_padding == 14

test_Tracer_set_thread_info_padding() # Unit test for method set_thread_info_padding of class Tracer

# Generated at 2022-06-22 18:20:14.132441
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import tempfile

    def assert_text_equals_file(path, text):
        with open(path) as f:
            assert f.read() == text

    path = os.path.join(tempfile.gettempdir(), 'FileWriter_write_test.txt')
    file_writer = FileWriter(path, overwrite=True)
    file_writer('abc')
    assert_text_equals_file(path, 'abc')
    file_writer('def')
    assert_text_equals_file(path, 'abcdef')
    file_writer('ghi')
    assert_text_equals_file(path, 'abcdefghi')
    os.remove(path)

test_FileWriter_write()



# Generated at 2022-06-22 18:20:25.441743
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as tempdir:
        path = os.path.join(tempdir, 'log.txt')
        fw = FileWriter(path, overwrite=False)
        fw.write('hello')
        fw.write('world')
        fw.write('!!!')
        fw.write('@')
        fw.write('$')
        fw.write('^')
        fw.write('&')

        with open(path) as f:
            contents = f.read()
        assert contents == 'hello'+'world'+'!!!'+'@'+'$'+'^'+'&'



# Generated at 2022-06-22 18:20:36.469973
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from .test_utils import assert_equal
    import tempfile

    def test(overwrite, content):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            file_writer = FileWriter(f.name, overwrite)
            file_writer.write(content)
        if overwrite:
            # If you ask FileWriter to overwrite, then only the last content
            # will stick.
            assert_equal(open(f.name, encoding='utf-8').
                         read(), content)
        else:
            # If you ask FileWriter not to overwrite, then everything will
            # stick.
            assert_equal(open(f.name, encoding='utf-8').read(),
                         content + content)
        os.unlink(f.name)



# Generated at 2022-06-22 18:20:41.532496
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    class myclass():
        """myclass is just a class that extends the Tracer class, to test """
        def __init__(self):
            self.thread_info_padding = 0

    s = myclass()
    string = "thread0"
    assert s.set_thread_info_padding(string) == "thread0"
    string = "thread01"
    assert s.set_thread_info_padding(string) == "thread01"
    string = "thread02"
    assert s.set_thread_info_padding(string) == "thread02"
    string = "thread03"
    assert s.set_thread_info_padding(string) == "thread03"
    string = "thread04"
    assert s.set_thread_info_padding(string) == "thread04"
    string = "thread05"

# Generated at 2022-06-22 18:20:46.212273
# Unit test for method write of class Tracer
def test_Tracer_write():
    with TemporaryDirectory() as temp_dir:
        temp_file = os.path.join(temp_dir, 'temp_file.txt')
        with Tracer(output=temp_file) as tracer:
            tracer.write('test')
        with open(temp_file, 'r') as f:
            assert f.read() == 'test\n'

# Generated at 2022-06-22 18:20:55.603539
# Unit test for constructor of class Tracer
def test_Tracer():
    def func(*args, **kwargs):
        pass

    tracer = Tracer(watch=('args', 'kwargs'))
    tracer(func)


### Patching in debugging tools: ##############################################
#                                                                             #
#                                                                             #
#  This is a tricky one. We want to patch in a debugging tool into the        #
#  function you're debugging. But in Python, C functions are not accessible   #
#  from Python code. So in order to do this, we need to do some black magic.  #
#  We basically create an empty Python function, walk through its bytecode,   #
#  and find a spot where we can patch in some Python code. Then, we'll       #
#  overwrite some of the bytecode with Python bytecode that does our job.     #
#  See https://

# Generated at 2022-06-22 18:21:06.139615
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class Foo(object):
        def __init__(self): pass
    def bar(*args, **kwargs): pass
    t = Tracer()
    with pycompat.mock.patch.object(Tracer, '_wrap_function') as mock_method:
        t(Foo)
        t(bar)
        assert mock_method.call_count == 2
        mock_method.assert_has_calls([pycompat.mock.call(Foo), pycompat.mock.call(bar)], any_order=True)
        mock_method.reset_mock()
        t(Foo)
        t(bar)
        assert mock_method.call_count == 0

# Generated at 2022-06-22 18:21:11.006040
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'some_file.py'
    overwrite = True
    file_writer = FileWriter(path, overwrite)
    assert file_writer.path == path
    assert file_writer.overwrite == overwrite

# Generated at 2022-06-22 18:21:15.598860
# Unit test for constructor of class FileWriter
def test_FileWriter():
    assert pycompat.text_type(FileWriter('a', True)) == 'FileWriter(\'a\', True)'
    assert pycompat.text_type(FileWriter('a', False)) == 'FileWriter(\'a\', False)'


# Generated at 2022-06-22 18:21:28.238362
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_filename)[0] == \
          f.__code__.co_filename
    assert get_path_and_source_from_frame(f.__code__.co_filename)[1] == \
          UnavailableSource()
    assert get_path_and_source_from_frame(inspect.currentframe())[0] == \
          __file__
    assert (get_path_and_source_from_frame(inspect.currentframe())[1][:2] ==
            [u'# Unit test for function get_path_and_source_from_frame',
             u'def test_get_path_and_source_from_frame():'])



# Generated at 2022-06-22 18:21:32.673213
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    trace_obj = Tracer()
    trace_obj.set_thread_info_padding('thread0')
    thread_info = trace_obj.set_thread_info_padding('thread1')
    assert thread_info == 'thread1 '

# Generated at 2022-06-22 18:21:37.829653
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writer = FileWriter('some_file.txt', overwrite=True)
    writer.write('hello')
    with open('some_file.txt') as f:
        assert f.read() == 'hello'
    writer.write(' world')
    with open('some_file.txt') as f:
        assert f.read() == 'hello world'
    os.remove('some_file.txt')




# Generated at 2022-06-22 18:21:47.935567
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w+', encoding='utf-8') as f:
        fw = FileWriter(f.name, overwrite=True)
        content = 'שלום עולם'
        fw.write(content)
        f.seek(0)
        contents_from_file = f.read()
        assert contents_from_file == content
        fw.write(content)
        f.seek(0)
        contents_from_file2 = f.read()
        assert contents_from_file2 == content


# Generated at 2022-06-22 18:21:59.070218
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # This is a bit hacky, but it's the best I could come up with.
    def get_path_and_source_from_frame_inner(frame):
        return get_path_and_source_from_frame(frame)

    def returns_15():
        return 15
    with utils.suppress_traceback_decorator:
        assert get_path_and_source_from_frame_inner(returns_15.__code__. \
                                                    co_firstlineno - 1) == \
               (__file__, UnavailableSource())
    def returns():
        return 15
    returns.__module__ = 'realfake'

# Generated at 2022-06-22 18:22:08.727926
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def get_line_no_for_call(target_frame):
        """Return the line number where the target frame was called"""
        # Parse traceback to find the line that is calling the target frame
        trb = inspect.trace()
        # This line of traceback is the one where the target frame was called
        call_frame = [f[0] for f in trb if f[0] is target_frame][0]
        call_line_no = call_frame.f_lineno
        return call_line_no

    def test_tracer_is_set_on_call_trace():
        def test_func():
            return "hello"
        with Tracer():
            test_func()

# Generated at 2022-06-22 18:22:14.002395
# Unit test for constructor of class FileWriter
def test_FileWriter():
    test_path = os.path.expanduser('~/pdb-test-output.txt')
    fw = FileWriter(test_path, overwrite=True)
    assert isinstance(fw, FileWriter)
    assert pycompat.text_type(os.path.expanduser('~/pdb-test-output.txt')) == fw.path
    assert fw.overwrite
    return


# Generated at 2022-06-22 18:22:26.108183
# Unit test for function get_write_function
def test_get_write_function():
    temp_dir = utils.temp_folder()
    path = temp_dir.joinpath / 'temp.txt'
    write, path_to_write = get_write_function(path, False)
    write('hello')
    path_to_write.read_text() == 'hello'
    write, path_to_write = get_write_function(path, True)
    write('hello')
    path_to_write.read_text() == 'hello'
    content_written = []
    write, path_to_write = get_write_function(lambda s: content_written.append(s))
    write('hello')
    assert content_written == ['hello']
    try:
        write, path_to_write = get_write_function([], False)
    except Exception:
        e = sys.exc_info