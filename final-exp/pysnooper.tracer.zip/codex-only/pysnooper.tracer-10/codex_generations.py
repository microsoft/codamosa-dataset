

# Generated at 2022-06-22 18:12:29.823182
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', delete=False) as f:
        f.write('def x(): return 3\n')
    frame = inspect.currentframe()
    assert frame.f_code.co_filename == __file__
    path, source = get_path_and_source_from_frame(frame)
    os.unlink(f.name)
    assert path == f.name
    assert source == ['def x(): return 3\n']
test_get_path_and_source_from_frame()



# Generated at 2022-06-22 18:12:34.826819
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # Create a FileWriter object
    try:
        fw = FileWriter('fw_test_file.txt', overwrite=True)
    # if the file does not exist, an exception is raised
    except IOError:
        pass
    # changing the value of the attribute overwrite
    fw.overwrite = False
    # will write now
    fw.write('This are the content of the file')



# Generated at 2022-06-22 18:12:36.039759
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer(sys.stdout):
        pass


# Generated at 2022-06-22 18:12:46.370882
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, False)
    write(u"write to sys.stderr")

    write = get_write_function(u"debugger log.txt", True)
    write(u"write to a file with overwrite")

    try:
        write = get_write_function(u"debugger log.txt", False)
        assert False
    except Exception:
        pass

    class MyStream(str):
        def write(self, s):
            assert False

    write = get_write_function(MyStream(), False)
    write(u"write to a stream")

    write = get_write_function(lambda s: print(s), False)
    write(u"write to a custom function")
    return True


# Generated at 2022-06-22 18:12:51.619416
# Unit test for constructor of class FileWriter
def test_FileWriter():
    writer = FileWriter('test1.txt', True)
    writer.write('abc')
    writer = FileWriter('test1.txt', False)
    writer.write('def')
    with open('test1.txt', 'r') as output_file:
        assert output_file.read() == 'abcdef'
    with open('test1.txt', 'w') as output_file:
        output_file.write('')



# Generated at 2022-06-22 18:12:56.094394
# Unit test for function get_write_function
def test_get_write_function():
    dummy_path_like = lambda: None
    dummy_path_like.__fspath__ = lambda self: '<path>'
    dummy_writable_stream = lambda: None
    dummy_writable_stream.write = lambda self, s: None
    assert get_write_function(None, False) is not None
    assert get_write_function(dummy_path_like(), False) is not None
    assert get_write_function(dummy_writable_stream(), False) is not None
    assert get_write_function(lambda s: None, False) is not None
    assert get_write_function(lambda s: None, True) is None



# Generated at 2022-06-22 18:13:06.536206
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    tracer = pysnooper.Tracer()
    tracer.target_codes = set()
    class A:
        pass
    A.__code__ = A
    tracer.target_codes.add(A)
    tracer.target_frames = set()
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    frame = inspect.currentframe()
    tracer.target_frames.add(frame)
    tracer.frame_to_local_reprs[frame] = {}
    tracer.start_times[frame] = datetime_module.datetime.now()
    tracer.thread_local = threading.local()
    tracer.__exit__(None, None, None)

# Generated at 2022-06-22 18:13:12.475153
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    snooper = utils.Mock(_write=None, depth=1, prefix='',
                                    thread_info_padding=0,
                                    target_codes=[], target_frames=[],
                                    frame_to_local_reprs={},
                                    start_times={}, thread_local=utils.Mock(__dict__={'original_trace_functions':[]}),
                                    max_variable_length=100,
                                    relative_time=False,
                                    normalize=False, )
    snooper.write = utils.Mock()
    snooper.__exit__(False, False, False)
    snooper.write.assert_called_with('Elapsed time: 0:00:00')


# Generated at 2022-06-22 18:13:15.626327
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    try:
        x = UnavailableSource()[0]
    except:
        raise AssertionError("Should not have raised")
    else:
        assert x == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:25.153099
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w+', delete=False,
                                     encoding='utf-8') as output_file:
        file_name = output_file.name
        file_writer1 = FileWriter(file_name, overwrite=True)
        file_writer2 = FileWriter(file_name, overwrite=False)
        try:
            assert file_writer1.overwrite
            assert not file_writer2.overwrite
            file_writer1.write('test1')
            file_writer1.write('test2')
            file_writer2.write('test3')
            with open(file_name) as input_file:
                file_content = input_file.read()
            os.remove(file_name)
        except TypeError:
            assert False

    assert file_content

# Generated at 2022-06-22 18:13:36.075731
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.set_thread_info_padding("thread_info")
    print(tracer.thread_info_padding)
    tracer.set_thread_info_padding("thread_info_1")
    print(tracer.thread_info_padding)
    tracer.set_thread_info_padding("thread_info_2")
    print(tracer.thread_info_padding)
    tracer.set_thread_info_padding("thread_info_3")
    print(tracer.thread_info_padding)
    tracer.set_thread_info_padding("thread_info_4")
    print(tracer.thread_info_padding)
    tracer.set_thread_info_padding("thread_info_5")
    print(tracer.thread_info_padding)
   

# Generated at 2022-06-22 18:13:39.260322
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(watch=('foo', 'self'))
    def foo(self, bar):
        foo = 0
        return 1 + foo
    assert foo(1, 2) == 1


# Generated at 2022-06-22 18:13:44.230987
# Unit test for constructor of class FileWriter
def test_FileWriter():
    ''' Test the constructor of FileWriter
    '''
    output = 'testdir/trace_overwrite'
    overwrite = True
    file_writer = FileWriter(output, overwrite)
    assert file_writer.path == output
    assert file_writer.overwrite == overwrite



# Generated at 2022-06-22 18:13:50.462320
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    try:
        tmp_file = tempfile.NamedTemporaryFile(mode='w')
        file_writer = FileWriter(tmp_file.name, overwrite=True)
        file_writer.write(u'foo\n')
        file_writer.write(u'bar')
        with open(tmp_file.name, 'r') as f:
            assert f.read() == 'foo\nbar'
    finally:
        tmp_file.close()



# Generated at 2022-06-22 18:14:01.169785
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    if pycompat.PY2:
        test_file_name = 'test_getting_source.py'
    else:
        test_file_name = 'test_getting_source_3.py'
    this_dir = os.path.dirname(os.path.abspath(__file__))
    for module in (None, 'test'):
        if module is None:
            frame = inspect.currentframe()
        else:
            import test
            frame = test.__dict__['test_get_path_and_source_from_frame']. \
                                                                      __code__
            frame = frame.co_consts[0].__code__
        result = get_path_and_source_from_frame(frame)
        assert isinstance(result, tuple)
        assert result[0].endswith

# Generated at 2022-06-22 18:14:02.908353
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:12.670570
# Unit test for function get_write_function
def test_get_write_function():
    class StubWritableStream(object):
        def __init__(self):
            self.s = ''
        def write(self, s):
            self.s += s

    def test_function(s):
        return s + '<test_function>'

    assert get_write_function(None, False)('<test>') == '<test>'
    assert get_write_function(test_function, False)('<test>') == '<test><test_function>'
    ws = StubWritableStream()
    get_write_function(ws, False)('<test>')
    assert ws.s == '<test>'
    get_write_function('/tmp/__temp_file__', True)('<test>')

# Generated at 2022-06-22 18:14:25.131090
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global DISABLED
    DISABLED = False
    print('Testing {}...'.format(Tracer.__call__.__name__))

    # Test case 1:
    # - Input: 
    #   + function_or_class: 
    # - Expected output: 
    def func():
        pass
    DISABLED = True
    expected_output = func
    output = Tracer().__call__(func)
    assert output == expected_output, 'Expected: {}. Got: {}'.format(expected_output, output)
    DISABLED = False

    # Test case 2:
    # - Input: 
    #   + function_or_class: 
    # - Expected output: 
    class Class:
        pass
    DISABLED = True
    expected_output = Class
    output = Tr

# Generated at 2022-06-22 18:14:33.025235
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper.tracing import get_local_reprs
    from pysnooper import utils
    from pysnooper.utils import is_composing_method
    from pysnooper.variables import CommonVariable
    from pysnooper.variables import Exploding
    from pysnooper.variables import BaseVariable
    import threading
    import sys
    import inspect
    from pysnooper.pycompat import pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import io
    import functools
    import datetime
    import pysnooper.thread_global
    import pysnooper.DISABLED
    import pysnooper.opcode
    import datetime
    import pysnooper.datetime_module
    import traceback

# Generated at 2022-06-22 18:14:37.715945
# Unit test for function get_write_function
def test_get_write_function():
    for output in [
        None,
        lambda s: None,
        utils.WritableStream.adapt_to_stream(lambda s: None),
    ]:
        assert get_write_function(output, None) is not None
    utils.AssertRaises(lambda: get_write_function(None, True))



# Generated at 2022-06-22 18:14:42.436943
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    s = u'He said "wow!"'
    write1 = FileWriter(tempfile.mktemp(), overwrite=True).write
    write2 = FileWriter(tempfile.mktemp(), overwrite=False).write

    write1(s)
    write2(s)
    write2(s)

    with open(tempfile.mktemp()) as f:
        assert f.read() == s

    with open(tempfile.mktemp()) as f:
        assert f.read() == s + s


# Generated at 2022-06-22 18:14:54.235955
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as tracer:
        tracer.thread_local.__dict__['original_trace_functions'] = []
        tracer.start_times = {}
        exc_type, exc_value, exc_traceback = None, None, None
        tracer.__exit__(exc_type, exc_value, exc_traceback)
        assert callable(tracer.trace)
        assert tracer.thread_local.__dict__['original_trace_functions'] == []
        assert tracer.start_times == {}
        assert tracer._write == sys.stdout.write
        assert tracer.watch == []
        assert tracer.frame_to_local_reprs == {}
        assert tracer.depth == 1
        assert tracer.prefix == ''
        assert tracer.thread_info == False
       

# Generated at 2022-06-22 18:14:58.959085
# Unit test for constructor of class FileWriter
def test_FileWriter():
    try:
        output = FileWriter('test_output.txt', True)
        assert output.path == 'test_output.txt'
        assert output.overwrite == True
        assert hasattr(output, 'write')
        assert callable(output.write)
    finally:
        import os
        os.remove('test_output.txt')



# Generated at 2022-06-22 18:15:08.691534
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    output_file = io.StringIO()
    s = Tracer(output_file)
    #test case 1
    c = 1
    #test case 2
    def foo(a, b=2):
        pass
    s.target_codes = {foo.__code__}
    s.target_frames = {}
    s.frame_to_local_reprs = {}
    s.start_times = {}
    thread_global.depth = -1
    debug_function_name = "snoop"
    calling_frame = inspect.currentframe().f_back
    #test case 3
    with s:
        pass
    stack = {foo.__code__}
    stack.append(sys.gettrace())
    sys.settrace(s.trace)
    #test case 4

# Generated at 2022-06-22 18:15:17.434901
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    file = tempfile.NamedTemporaryFile(delete=False)
    file.close()
    file_writer = FileWriter(file.name, overwrite=False)
    file_writer.write('foo')
    file_writer.write('bar')
    with open(file.name, 'rb') as opened_file:
        assert opened_file.read() == 'foobar'
    file_writer.overwrite = True
    file_writer.write('foo')
    file_writer.write('bar')
    with open(file.name, 'rb') as opened_file:
        assert opened_file.read() == 'foobar'
    os.remove(file.name)



# Generated at 2022-06-22 18:15:19.142767
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    t = Tracer()
    assert t.trace(None, None, None) == t.trace


# Generated at 2022-06-22 18:15:24.704124
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test_1():
        x = 0
        y = x + 1
        def foo():
            pass
        # global x
        x = 1
        f = lambda x: x + 1
        return x
    tracer=Tracer()
    tracer.trace(test_1.__code__, 'c', None)
    print("Success")


# Generated at 2022-06-22 18:15:35.930771
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import tempfile

    @pysnooper.snoop()
    def foo():
        bar = 1

    assert foo.__wrapped__.__code__ is not foo.__code__
    assert foo.__wrapped__.__code__ is not Tracer.__call__.__code__

    with tempfile.TemporaryFile('r+') as output:
        @pysnooper.snoop(output=output)
        def foo():
            bar = 1

        foo()
        output.seek(0)
        output_lines = output.readlines()


# Generated at 2022-06-22 18:15:41.687706
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'file_writer.txt'
    if os.path.exists(path):
        os.remove(path)
    file_writer = FileWriter(path, False)
    # First write
    file_writer.write('abc')
    # Second write
    file_writer.write('def')
    # First overwrite
    file_writer = FileWriter(path, True)
    file_writer.write('ghi')
    # Second overwrite
    file_writer.write('jkl')
    os.remove(path)



# Generated at 2022-06-22 18:15:51.256618
# Unit test for constructor of class Tracer
def test_Tracer():
    """
    This is a unit test for the constructor of class Tracer.

    Args:
        None

    Returns:
        None

    """
    # Start with a simple successful test
    assert Tracer()

    # Test overwrite argument
    assert Tracer(overwrite=True)

    # Test custom_repr argument
    assert Tracer(custom_repr=[(str, None)])

    # Test max_variable_length argument
    assert Tracer(max_variable_length=0)

    # Test normalize argument
    assert Tracer(normalize=True)

    # Test relative_time argument
    assert Tracer(relative_time=True)

    # Test output argument
    # assert Tracer(output=open('file_path','w'))
    assert Tracer(output=io.StringIO())

    # Test watch argument


# Generated at 2022-06-22 18:15:55.019079
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # self = <pysnooper.tracing.Tracer object at 0x0000021D8F35E7F0>, function_or_class = {function}
    pass


# Generated at 2022-06-22 18:15:58.774537
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_path_and_source(frame):
        return get_path_and_source_from_frame(frame)[1]

    (path, source) = get_path_and_source_from_frame(inspect.currentframe())
    assert source[6] == '        (path, source) = get_path_and_source_from_frame(inspect.currentframe())'

    source = get_path_and_source(inspect.currentframe())
    assert source[7] == '    source = get_path_and_source(inspect.currentframe())'



# Generated at 2022-06-22 18:16:01.066023
# Unit test for constructor of class FileWriter
def test_FileWriter():
    """
    >>> file_writer = FileWriter('test.txt', True)
    >>> file_writer.write('hello world!')
    """



# Generated at 2022-06-22 18:16:05.616452
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test_function():
        return 1
    tracer = Tracer()
    tracer.trace = MagicMock()
    tracer.trace(None, 'event', None)
    tracer.trace.assert_called_once_with(None, 'event', None)


# Unit tests for method _wrap_class of class Tracer

# Generated at 2022-06-22 18:16:10.373531
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(NotImplementedError):
        with Tracer(thread_info=True):
            pass
    with pytest.raises(NotImplementedError):
        with Tracer(normalize=True, thread_info=True):
            pass

# Generated at 2022-06-22 18:16:21.317052
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def test_function(a, b, c, d):
        e = f = g = h = i = j = k = l = m = n = o = p = q = r = s = t = u = v = w = x = y = z = a
        b = 'b'
        c = None
        d = 4
        e = ['e']
        f = {'f': 'f'}
        g = {'g': {'g': 'g'}}
        h = u'h'
        i = b'i'
        j = b"j"
        k = bytearray(b"k")
        l = True
        m = False
        n = 5
        o = 6.
        p = 7
        q = 8.
        r = 9.
        s = 'n\n'
       

# Generated at 2022-06-22 18:16:28.317050
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    """
    __enter__ of class Tracer
    """

    # set up
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100)
    # testing

    # test case 1
    try:
        tracer.__enter__()
    except Exception as e:
        pass
    assert True

    # teardown
    del tracer


# Generated at 2022-06-22 18:16:29.946303
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:16:37.382939
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer_obj=Tracer()
    tracer_obj.thread_info_padding=0
    current_thread=threading.current_thread()
    tracer_obj.set_thread_info_padding("{ident}-{name}".format(ident=current_thread.ident, name=current_thread.getName()))
    assert tracer_obj.thread_info_padding==len("{ident}-{name}".format(ident=current_thread.ident, name=current_thread.getName()))

# Generated at 2022-06-22 18:16:45.261525
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    frame = inspect.currentframe().f_back
    frame.f_code = inspect.currentframe.__code__
    frame.f_lineno = inspect.currentframe.__code__.co_firstlineno + 3
    source = inspect.getsource(inspect.currentframe)
    source_list = source.split('\n')
    source = source_list
    arg = [None, None, None]
    assert(code_byte == 102)
    code_byte = frame.f_code.co_code[frame.f_lasti]
    thread_global.depth = 1
    self.write(
        '{indent}Elapsed time: {elapsed_time_string}'.format(**locals())
    )

# Generated at 2022-06-22 18:16:56.776689
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        a = 1
        b = 'c'
        c = None
        d = (1, 2, 3)
        e = [4, 5, 6]
        f = {7, 8, 9}
        for i in range(3):
            pass
        return x
    frame = f.__code__.co_code
    result = get_local_reprs(frame)
    assert result == {'i': '3', 'f': '{9, 8, 7}', 'd': '(1, 2, 3)', 'g': 'error',
                      'a': '1', 'b': '"c"', 'c': 'None', 'x': 'error', 'e': '[4, 5, 6]'}
test_get_local_reprs()



# Generated at 2022-06-22 18:16:58.497890
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:00.582824
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:04.187019
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    obj = Tracer(prefix="")
    obj.write = lambda x: print(x)
    def f():
        return 1
    def g():
        return 1
    import sys
    sys.settrace(obj.trace)
    f()
    sys.settrace(None)


# Generated at 2022-06-22 18:17:05.370750
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    UnavailableSource()[0]
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:17:12.602333
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import tests
    (path, source) = get_path_and_source_from_frame(
        tests.get_function_definition_frame(test_get_path_and_source_from_frame)
    )
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-22 18:17:21.493039
# Unit test for function get_write_function
def test_get_write_function():
    test_data = (
        (None, 'Hello world'),
        (sys.stdout, 'Hello world'),
        (sys.stderr, 'Hello world'),
        (lambda s: print('lambda:', s), 'Hello world'),
        (pycompat.Path(__file__) / 'test.out', 'Hello\nworld'),
    )
    for output, expected_output in test_data:
        write = get_write_function(output, False)
        write(expected_output)
        if isinstance(output, pycompat.PathLike):
            assert output.read_text(encoding='utf-8') == expected_output
        elif isinstance(output, str):
            assert open(output, 'rb').read().decode('utf-8') == expected_output

# Generated at 2022-06-22 18:17:24.073790
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    line = UnavailableSource()[1]
    assert line == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:29.412366
# Unit test for method write of class Tracer
def test_Tracer_write():
    file = StringIO()
    tracer = Tracer(file)
    tracer.write('test line 1')
    assert file.getvalue() == 'test line 1\n'
    file.truncate(0)
    tracer.write('test line 2')
    assert file.getvalue() == 'test line 2\n'


# Generated at 2022-06-22 18:17:31.999167
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():

    # Operation
    t = Tracer()
    t.__enter__()

    # Check
    assert True == True # dummy statement for demo purposes


# Generated at 2022-06-22 18:17:42.113484
# Unit test for constructor of class FileWriter
def test_FileWriter():
    pathname = 'tfile'
    with open(pathname, "w", encoding='utf-8') as f:
        f.write("I am existing\n")
    f = FileWriter(pathname, overwrite = True)
    f.write("Write to me\n")
    f.write("Write to me more\n")
    with open(pathname, "r", encoding='utf-8') as f:
        assert f.read() == "Write to me\nWrite to me more\n"
    os.remove(pathname)


# Generated at 2022-06-22 18:17:49.256526
# Unit test for constructor of class Tracer
def test_Tracer():
    # a function for calling Tracer in the local scope
    def tracer(input_watch,input_watch_explode,input_depth,
               input_prefix,input_overwrite,input_thread_info,input_custom_repr,
               input_max_variable_length,input_normalize,input_relative_time):
        return Tracer(watch=input_watch, watch_explode=input_watch_explode, depth=input_depth,
                      prefix=input_prefix, overwrite=input_overwrite, thread_info=input_thread_info,
                      custom_repr=input_custom_repr, max_variable_length=input_max_variable_length,
                      normalize=input_normalize, relative_time=input_relative_time)

    # Test invalid input types

# Generated at 2022-06-22 18:17:50.384099
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-22 18:17:59.984711
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    assert tracer.__enter__() is None
    thread_global.depth = -1
    thread_global.depth += 1
    thread_local = threading.local()
    assert (tracer.thread_local.__dict__.setdefault('original_trace_functions', []) == [])
    calling_frame = inspect.currentframe().f_back
    assert not tracer._is_internal_frame(calling_frame)
    calling_frame.f_trace = tracer.trace
    tracer.target_frames.add(calling_frame)
    pysnooper.snoop(depth=1)
    with tracer:
        pass
    assert thread_global.depth == -1
    assert thread_local.__dict__.setdefault('original_trace_functions', [])
   

# Generated at 2022-06-22 18:18:09.518628
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import doctest
    from itertools import count as count_generator
    from . import tests
    from .tests import test_utils

    frame = test_utils.get_fake_frame()
    frame.f_globals = {'__loader__': doctest,
                       '__name__': 'doctest'}
    frame.f_code.co_filename = os.path.join(
        tests.__path__[0], 'tests_for_get_path_and_source_from_frame.py'
    )
    fake_source = os.linesep.join(str(i) for i in count_generator(1))
    with open(frame.f_code.co_filename, 'wb') as f:
        f.write(fake_source.encode('utf-8'))

    assert get_

# Generated at 2022-06-22 18:18:11.712498
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:18:23.354893
# Unit test for constructor of class Tracer
def test_Tracer():
    try:
        import pytest
    except ImportError:
        pytest = None

    tracer = Tracer()
    assert utils.ensure_tuple(tracer.watch) == ()
    assert utils.ensure_tuple(tracer.watch_explode) == ()
    assert isinstance(tracer._write, io.IOBase)
    assert tracer.depth == 1
    assert not tracer.thread_info
    assert tracer.max_variable_length == 100
    assert tracer.normalize is False
    assert tracer.relative_time is False

    if pytest:
        tracer = Tracer(watch=('foo', 'bar'))

# Generated at 2022-06-22 18:18:24.679409
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    var = random.randint(1,10)
    #random number
    assert not Tracer.__init__(var)

# Generated at 2022-06-22 18:18:29.664219
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter('test', False)
    assert file_writer.path == 'test'
    assert file_writer.overwrite == False
    assert callable(file_writer.write)
    file_writer.write('a')
    with open('test', 'r') as f:
        assert f.read() == 'a'
    file_writer.write('b')
    with open('test', 'r') as f:
        assert f.read() == 'ab'
    os.remove('test')



# Generated at 2022-06-22 18:18:40.926788
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    # Test 1
    thread_info = tracer.set_thread_info_padding("12-test ")
    assert thread_info == "12-test ".ljust(len("12-test "))
    # Test 2
    thread_info = tracer.set_thread_info_padding("12345-test ")
    assert thread_info == "12345-test ".ljust(len("12345-test "))
    # Test 3
    thread_info = tracer.set_thread_info_padding("123-test ")
    assert thread_info == "123-test ".ljust(len("12345-test "))
    # Test 4
    thread_info = tracer.set_thread_info_padding("")

# Generated at 2022-06-22 18:18:53.049025
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def not_a_coroutine():
        pass
    def is_a_coroutine():
        yield
    def generator_func():
        yield

    @pysnooper.snoop()
    def not_a_coroutine_wrapped():
        pass
    with pytest.raises(NotImplementedError):
        @pysnooper.snoop()
        def is_a_coroutine_wrapped():
            yield
    decorated_generator_func = pysnooper.snoop()(generator_func)

    assert not_a_coroutine_wrapped() == None
    assert decorated_generator_func().__next__() == None
    assert inspect.isgeneratorfunction(decorated_generator_func)

# Generated at 2022-06-22 18:18:54.253946
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # TODO: Write unit tests for this function
    pass



# Generated at 2022-06-22 18:19:04.323008
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # import the module and set up some variables for testing
    global DISABLED
    DISABLED = False
    m = importlib.import_module('pysnooper')
    m.line_no = 3
    m.source_path = 'test_pysnooper.py'
    m.source = ['def x():', '    pass', '    pass', '    pass']

    def t():
        return 'trace'

    def g():
        yield 'generator'
        yield 'generator'
        yield 'generator'

    def d(n):
        if n <= 0:
            return
        else:
            d(n - 1)

    # create a Tracer object
    tracer = m.Tracer(m.get_write_function('output.log'))
    tracer.write = t
    tr

# Generated at 2022-06-22 18:19:07.040060
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    pysnooper.snoop()

# Generated at 2022-06-22 18:19:16.834844
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = os.path.join(utils.test_folder, 'output.txt')
    with open(path, 'w') as output_file:
        output_file.write('foo')

# Generated at 2022-06-22 18:19:28.241195
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Move test code into method so it doesn't pollute the global namespace.
    def test_func():
        pass
    # Test passing callables.
    decorated_func = pysnooper.snoop()(test_func)
    assert decorated_func() is None
    # Test passing classes.
    @pysnooper.snoop()
    class TestClass(object):
        def __init__(self):
            pass
        def method(self):
            pass
    assert TestClass().method() is None
    # Test passing instance methods.
    obj = TestClass()
    decorated_method = pysnooper.snoop()(obj.method)
    obj.method = decorated_method
    assert obj.method() is None
    # Test passing simple generators.

# Generated at 2022-06-22 18:19:32.308837
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import builtins
    builtins.__dict__.setdefault('_print', print)
    builtins._print('Testing method __enter__ of class Tracer')
    builtins._print('Checking... set_thread_info_padding')
test_Tracer___enter__()


# Generated at 2022-06-22 18:19:37.640830
# Unit test for constructor of class FileWriter
def test_FileWriter():
    s = 'hello'
    path = '/tmp/thing'
    overwrite_true = FileWriter(path, True)
    overwrite_true.write(s)
    assert os.path.exists(path)
    with open(path) as f:
        assert f.read() == s

    overwrite_false = FileWriter(path, False)
    overwrite_false.write(s)
    with open(path) as f:
        assert f.read() == s + s



# Generated at 2022-06-22 18:19:47.652631
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    path = pycompat.Path(tempfile.mktemp())
    try:
        if path.exists():
            path.unlink()
        assert not path.exists()
        FileWriter(path, overwrite=True).write('abc')
        assert path.exists()
        assert pycompat.text_type(path.read_text('utf-8')) == 'abc'
        FileWriter(path, overwrite=False).write('def')
        assert pycompat.text_type(path.read_text('utf-8')) == 'abc\ndef'
    finally:
        path.unlink()
    assert not path.exists()

# Generated at 2022-06-22 18:19:52.722425
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = 'abc' * x
        del y
        return y
    try:
        f(1)
    except:
        frame = sys.exc_info()[2].tb_frame.f_back
        assert get_local_reprs(frame) == {'x': '1', 'y': '<undefined>'}


# Generated at 2022-06-22 18:20:02.517362
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def f():
        pass

    def g(x):
        pass

    def h(y):
        pass

    def main():
        f()
        g(1)
        h(2)
        i()

    def i():
        pass

    snoop_output = StringIO()

    tracer = Tracer(watch=['x'], depth=1, output=snoop_output)

    with tracer:
        main()


# Generated at 2022-06-22 18:20:07.944132
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper

    @pysnooper.snoop()
    def my_func():
        a = 1
        a += 2
        return a

    my_func()



# Generated at 2022-06-22 18:20:10.225100
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Create an instance of Tracer
    tracer = Tracer()


# Generated at 2022-06-22 18:20:17.723390
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    from pprint import pprint
    from contextlib import redirect_stdout

    mock_file = io.StringIO()
    redirect_stdout(mock_file)
    @pysnooper.snoop(watch=('x', 'y'))
    def f(x, y):
        pass
    f(1, 2)
    f(3, 4)
    output = mock_file.getvalue().strip()

# Generated at 2022-06-22 18:20:28.936114
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = sys._getframe()
    def function(a, b, c):
        pass
    assert next(iter(function.__code__.co_varnames)) == 'a'
    fn_vars = [CommonVariable(name) for name in function.__code__.co_varnames]
    assert '<cute_inspect.variables.CommonVariable ("a")>' in str(fn_vars[0])
    assert '<cute_inspect.variables.CommonVariable ("b")>' in str(fn_vars[1])
    assert '<cute_inspect.variables.CommonVariable ("c")>' in str(fn_vars[2])
    frame_locals = {
        'x': '‍',
        'y': 'מ'
    }
    frame.f

# Generated at 2022-06-22 18:20:30.578612
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:33.091700
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper

# Generated at 2022-06-22 18:20:45.941889
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    snoop = Tracer(thread_info=True)
    t0, t1, t2, t3, t4 = [threading.Thread(target=threading_fn,
                                            args=(i,))
                          for i in range(5)]
    snoop.set_thread_info_padding("")
    assert snoop.thread_info_padding == 0
    t0.start()
    t1.start()
    t2.start()
    t3.start()
    t4.start()
    t0.join()
    t1.join()
    t2.join()
    t3.join()
    t4.join()
    assert snoop.thread_info_padding == 29


# Generated at 2022-06-22 18:20:55.363587
# Unit test for method write of class Tracer
def test_Tracer_write():
    snoop = Tracer(output=_write_to_list)
    with snoop:
        pass
    class Test(object):
        @snoop
        def method(self):
            pass
    t = Test()
    t.method()
    print("test_Tracer_write:", str(snoop.write("test_Tracer_write")))

# Generated at 2022-06-22 18:21:06.928830
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'filewriter_test.txt'
    FileWriter(path, True).write('1\n')
    FileWriter(path, True).write('2\n')
    FileWriter(path, False).write('3\n')
    FileWriter(path, False).write('4\n')
    FileWriter(path, True).write('5\n')
    FileWriter(path, True).write('6\n')
    with open(path, 'r') as file:
        assert file.read() == '5\n6\n'
    os.remove(path)

    FileWriter(path, False).write('5\n')
    with open(path, 'r') as file:
        assert file.read() == '5\n'
    os.remove(path)


# Generated at 2022-06-22 18:21:18.824305
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function(x):
        def inner_function(y):
            return y + x
        return inner_function(3)
    assert get_path_and_source_from_frame(inspect.currentframe()) == (inspect.getfile(function),
                                                                     UnavailableSource())
    assert get_path_and_source_from_frame(inspect.currentframe().f_back) == (inspect.getfile(function),
                                                                              UnavailableSource())
    assert get_path_and_source_from_frame(inspect.currentframe().f_back.f_back) == \
                                                                      (inspect.getfile(function),
                                                                       UnavailableSource())

# Generated at 2022-06-22 18:21:29.984110
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    s = Tracer()
    assert s.set_thread_info_padding("abc") == "abc"
    assert s.set_thread_info_padding("abcde") == "abcde"
    assert s.set_thread_info_padding("abc") == "abc  "
    assert s.set_thread_info_padding("") == "     "
    assert s.set_thread_info_padding("a") == "a    "
    assert s.set_thread_info_padding("abcdefg") == "abcdefg"
    assert s.set_thread_info_padding("abcd efg") == "abcd efg"
    assert s.set_thread_info_padding("abcde fg") == "abcde fg"

# Generated at 2022-06-22 18:21:31.975896
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    sys.settrace(Tracer(globals(), locals()).trace)
    t = "test"
    print(t)
# test_Tracer_trace()
# Tests:


# Generated at 2022-06-22 18:21:39.863984
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    res = Tracer().set_thread_info_padding("   ")
    assert res == "   "

    res = Tracer().set_thread_info_padding("     ")
    assert res == "     "

    res = Tracer().set_thread_info_padding("         ")
    assert res == "         "

    res = Tracer().set_thread_info_padding("   X")
    assert res == "   X    "

    res = Tracer().set_thread_info_padding("     A")
    assert res == "     A  "

    res = Tracer().set_thread_info_padding("         ")
    assert res == "         "

# Generated at 2022-06-22 18:21:43.515675
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    for method_name, method in (
        ('__call__', Tracer.__call__),
    ):
        yield (check_method, method_name, method)


# Generated at 2022-06-22 18:21:53.215042
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import inspect
    from datetime import datetime
    orig_time = datetime.now
    def mock_now(self):
        return datetime.now()
    datetime.now = mock_now
    orig_write = sys.stdout.write
    orig_flush = sys.stdout.flush
    write_data = []
    def mock_write(data):
        write_data.append(data)
    sys.stdout.write = mock_write
    sys.stdout.flush = lambda: None

# Generated at 2022-06-22 18:22:05.417858
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import datetime

    with pytest.raises(NotImplementedError):
        @pysnooper.snoop()
        async def foo():
            pass

    with pytest.raises(NotImplementedError):
        @pysnooper.snoop()
        async def foo():
            yield

    def foo(bar):
        baz = 'baz'
        return bar * len(baz)

    snoop = pysnooper.snoop()
    foo_snoop = snoop(foo)

    assert foo_snoop.__name__ == 'foo'
    assert foo_snoop(2) == 4

    # 1 because foo's decorator is '@pysnooper.snoop()'
    assert thread_global.__dict__['depth'] == 1


# Generated at 2022-06-22 18:22:12.395403
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = pysnooper.Snooper(thread_info=True)

    assert tracer.thread_info

    tracer.set_thread_info_padding("MainThread-123 ")
    tracer.set_thread_info_padding("Thread-789 ")
    assert tracer.thread_info_padding == len("Thread-789 ")



# Generated at 2022-06-22 18:22:15.734521
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:22:19.588246
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    uas = UnavailableSource()
    assert uas[0] == 'SOURCE IS UNAVAILABLE'


# this should be kept in sync with `repr.repr` in the standard library

# Generated at 2022-06-22 18:22:29.565123
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .pycompat import StringIO
    import contextlib
    output_stream = StringIO()
    writer = FileWriter(output_stream, overwrite=False)
    writer.write('yo')
    assert output_stream.getvalue() == 'yo'
    writer.write('deo')
    assert output_stream.getvalue() == 'yodeo'
    output_stream.close()
    with contextlib.closing(StringIO()) as output_stream:
        writer = FileWriter(output_stream, overwrite=True)
        writer.write('yo')
        assert output_stream.getvalue() == 'yo'
        writer.write('deo')
        assert output_stream.getvalue() == 'yodeo'