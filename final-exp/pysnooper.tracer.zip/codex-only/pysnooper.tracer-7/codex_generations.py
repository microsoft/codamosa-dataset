

# Generated at 2022-06-22 18:12:37.643431
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    output = None
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    tracer = Tracer(output=output, watch=watch, watch_explode=watch_explode, depth=depth,
                    prefix=prefix, overwrite=overwrite, thread_info=thread_info, custom_repr=custom_repr,
                    max_variable_length=max_variable_length, normalize=normalize, relative_time=relative_time)
    # Tests
    assert tracer

# Generated at 2022-06-22 18:12:41.158893
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    _ = None
    _ = [
        None,
    ][0]
    return _

# Generated at 2022-06-22 18:12:48.808975
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED  # pylint:disable=global-statement
    DISABLED = False
    if DISABLED:
        return
    thread_global = utils.thread_global  # pylint:disable=invalid-name
    target_codes = Tracer.target_codes
    target_frames = Tracer.target_frames
    frame_to_local_reprs = Tracer.frame_to_local_reprs
    start_times = Tracer.start_times
    depth = Tracer.depth
    base = Tracer()
    base.write("testing function trace")
    thread_global.__dict__.setdefault('depth', -1)
    calling_frame = inspect.currentframe().f_back
    if not base._is_internal_frame(calling_frame):
        calling_frame.f_trace

# Generated at 2022-06-22 18:12:59.315017
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def z(a, b, c=3, d=[4]):
        e = [5]
        f = lambda x, y=8, z=[9]: None
        return f(g[0])

    class X(object):
        def __repr__(self):
            return 'an X'

    x = X()
    g = ['x', 'y', 'z']

    def test_case(watch, expected_local_reprs):
        result = get_local_reprs(z.__code__.func_code, watch)
        assert result == expected_local_reprs


# Generated at 2022-06-22 18:13:01.637338
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:04.376068
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()['x'] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:13.844548
# Unit test for constructor of class Tracer
def test_Tracer():
    # To test the Tracer class, it is easiest to use a dummy sys.stdout:

    output = io.StringIO()

    @snoop(output)
    def f(x, y):
        z = x + y
        z += 1
        return z

    f(1, 2)

# Generated at 2022-06-22 18:13:22.549188
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
   tracer = Tracer(prefix='ZZZ ')
   print(tracer.prefix)
   tracer.thread_local.frame_to_local_reprs = {
   }
   tracer.thread_local.original_trace_functions = []
   tracer.start_times[534] = tracer.start_times[534] = datetime_module.datetime.now()
   tracer.target_frames.add(534)
   tracer.target_codes.add(534)
   sys.settrace(534)

# Generated at 2022-06-22 18:13:24.316094
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[tuple()] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:33.251471
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io.StringIO()
    with io.open(os.devnull, 'w') as dev_null:
        monkeypatch = pytest.importorskip('monkeypatch').MonkeyPatch()
        with monkeypatch.context():
            pysnooper._globals.write_function = lambda x: dev_null.write(x)
            with Tracer(output):
                pass
    output_string = output.getvalue()
    assert 'Source path:...' in output_string
    assert 'Elapsed time: ' in output_string
    assert 'Starting var:.. __name__' in output_string



# Generated at 2022-06-22 18:13:34.344984
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'path/file'
    overwrite = False
    file_writer = FileWriter(path, overwrite)
    assert file_writer.path == path
    assert file_writer.overwrite == overwrite


# Generated at 2022-06-22 18:13:45.610938
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter(output=None, overwrite=False)
    stderr = sys.stderr
    try:
        sys.stderr = io = pycompat.StringIO()
        file_writer.write('foobar')
    finally:
        sys.stderr = stderr
    assert io.getvalue() == 'foobar'
    with pycompat.open_file('test_write_output.txt', 'w') as f:
        file_writer = FileWriter(output=f, overwrite=True)
        file_writer.write('foobar')
    with pycompat.open_file('test_write_output.txt', 'r') as f:
        assert f.read() == 'foobar'

# Generated at 2022-06-22 18:13:55.758774
# Unit test for constructor of class Tracer
def test_Tracer():
    from unittest.mock import Mock, patch

    def f():
        for i in range(2):
            yield i

    mock_write = Mock()
    with patch('pysnooper.core.get_write_function') as mock_get_write_function:
        mock_get_write_function.return_value = mock_write
        s = Tracer()
        s(f)()

    output = '\n'.join(c[0][0] for c in mock_write.call_args_list)

# Generated at 2022-06-22 18:13:57.878998
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    us = UnavailableSource()[:1]
    assert us == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:07.153537
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    root = os.path.dirname(__file__)
    test_file_name = os.path.join(root, 'files', 'test.py')

    def test_file():
        return 'x'
    test_file.__code__.co_filename = test_file_name
    test_file.__globals__['__file__'] = test_file_name

    path, source = get_path_and_source_from_frame(inspect.currentframe())
    assert path == __file__
    assert source[:5] == ['#', '# Copyright 2019 Ram Rachum and collaborators.',
                          '# This program is distributed under the MIT license.',
                          '', '']

    path, source = get_path_and_source_from_frame(inspect.currentframe(1))

# Generated at 2022-06-22 18:14:08.727398
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()['a'] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:16.469084
# Unit test for constructor of class Tracer
def test_Tracer():
    # These are just smoke tests to make sure that the @pysnooper.snoop
    # decorator won't blow up.

    @snoop
    def foo():
        pass

    foo()

    @snoop(watch=('foo', ))
    def bar(foo):
        pass

    bar(foo=42)

    @snoop(watch_explode=('foo', ))
    def baz(foo):
        pass

    baz(foo=[])

    @snoop(depth=2)
    def quux(foo):
        foo()

    @snoop
    def foo():
        pass

    quux(foo)

    @snoop(prefix='ZZZZ ')
    def quux(foo):
        pass

    quux(foo)


# Generated at 2022-06-22 18:14:25.802622
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from tempfile import NamedTemporaryFile
    from os.path import exists
    from os import remove
    with NamedTemporaryFile() as temp_file:
        path = temp_file.name

        fw = FileWriter(path, True)
        assert fw.overwrite is True

        fw.write('hello')
        assert fw.overwrite is False

        assert exists(path)

        with open(path, 'w') as f:
            f.write('')

        fw.write('hello')
        with open(path) as f:
            assert f.read() == 'hello'

        remove(path)


# Generated at 2022-06-22 18:14:29.609462
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function(): pass
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[frame.f_lineno - 1].strip() == 'frame = inspect.currentframe()'
test_get_path_and_source_from_frame()



# Generated at 2022-06-22 18:14:37.716178
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    test_snoop = pysnooper.snoop(output="test_log", watch='self.a', watch_explode='self.b')
    class Test(object):
        def __init__(self):
            self.a = 1
            self.b = [[1,2]]
        @test_snoop
        def f(self):
            self.a += 1
            self.b.append(self.b[-1][0] + self.b[-1][1])
            print(self.a, self.b)
    test = Test()
    test.f()
    test.f()
    test.f()
    test.f()


# Generated at 2022-06-22 18:14:40.361737
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .tests import get_local_reprs_test
    get_local_reprs_test.get_local_reprs_tester()


# Generated at 2022-06-22 18:14:45.587868
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import __file__ as this_file
    frame = sys._getframe()  # This is the frame of this function.
    path, source = get_path_and_source_from_frame(frame)
    assert os.path.samefile(path, this_file)
    assert source == inspect.getsource(test_get_path_and_source_from_frame) \
                        .splitlines()
frame_internal_attribute_names = set(dir(frame))


BRACE_COUNT_PATTERN = re.compile('[{}]')


# Generated at 2022-06-22 18:14:51.193431
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    log_file = StringIO()
    def _():
        try:
            pass
        except:
            import traceback
            traceback.print_exc()
    with pysnooper.snoop(log_file, depth=10):
        _()
    print(log_file.getvalue())


# Generated at 2022-06-22 18:14:56.032277
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.set_thread_info_padding("t1")
    assert tracer.thread_info_padding == 2
    tracer.set_thread_info_padding("t123456789")
    assert tracer.thread_info_padding == 9

if __name__  == '__main__':
    test_Tracer_set_thread_info_padding()

# Generated at 2022-06-22 18:14:58.867457
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Get the type of the self
    _Tracer = Tracer()

    def test_function():
        pass

    # calling the function with the arguments
    assert isinstance(_Tracer.__call__(test_function), type(test_function))

# Generated at 2022-06-22 18:15:08.579012
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # happy case
    try:
        os.remove('tests/test_output.txt')
    except FileNotFoundError:
        pass
    temp = FileWriter('tests/test_output.txt', overwrite=True)
    assert temp.path == 'tests/test_output.txt'
    assert temp.overwrite == True
    # overwrite=False
    temp = FileWriter('tests/test_output.txt', overwrite=False)
    assert temp.path == 'tests/test_output.txt'
    assert temp.overwrite == False
    # overwrite=True
    os.remove('tests/test_output.txt')
    temp = FileWriter('tests/test_output.txt', overwrite=True)
    assert temp.path == 'tests/test_output.txt'
    assert temp.overwrite == True
    # overwrite=False
   

# Generated at 2022-06-22 18:15:18.307358
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # given
    path = 'test_FileWriter_write.txt'
    overwrite = True

    # and
    write = FileWriter(path, overwrite).write
    write('foo')
    with open(path, 'r') as file:
        assert file.read() == 'foo'

    # and
    os.remove(path)

    # and
    overwrite = False

    # and
    write = FileWriter(path, overwrite).write
    write('foo')
    write('bar')
    with open(path, 'r') as file:
        assert file.read() == 'foo'

    # and
    os.remove(path)

    # and
    overwrite = True

    # and
    write = FileWriter(path, overwrite).write
    write('foo')
    write('bar')

# Generated at 2022-06-22 18:15:28.857808
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import datetime
    from datetime import datetime as DT
    from . import pysnooper
    from .. import utils
    tracer = pysnooper.Snooper(None)
    tracer.frame_to_local_reprs = {None: {'a': 1}}
    tracer.start_times = {None: DT(2020, 8, 27, 23, 59, 59, 999999)}
    tracer.__exit__(None, None, None)
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert utils.get_write_function_args()[0] == '    Elapsed time: 0:00:00'


# Generated at 2022-06-22 18:15:32.299916
# Unit test for constructor of class Tracer
def test_Tracer():
    try:
        Tracer(1, 2, 3, 4, 5, 6)
    except TypeError:
        pass
    else:
        assert False, 'Tracer should throw TypeError'


# Generated at 2022-06-22 18:15:37.794915
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = x + 1
        z = y + x
        return 1

    frame = f.__code__.co_firstlineno
    frame = inspect.currentframe()
    frame = utils.get_outer_frame(frame, 3)
    vars_dict = get_local_reprs(frame)
    assert vars_dict == {'x': '1', 'y': '2', 'z': '3'}



# Generated at 2022-06-22 18:15:39.482589
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert (UnavailableSource()[142] ==
            u'SOURCE IS UNAVAILABLE')


# Generated at 2022-06-22 18:15:46.774865
# Unit test for constructor of class Tracer
def test_Tracer():
    class Class(object):
        def __init__(self):
            self.x = 3

        def method(self):
            self.y = self.x * 2

        @pysnooper.snoop()
        def method_decorated(self):
            self.z = self.x * 3

    obj = Class()
    obj.method()
    obj.method_decorated()


### Unit testing of decorator #################################################
#

# Generated at 2022-06-22 18:15:54.899992
# Unit test for constructor of class Tracer
def test_Tracer():
    _CHECK_ALL_EXCEPTIONS = ('watch', 'watch_explode', 'depth', 'prefix',
                             'overwrite', 'thread_info',
                             'custom_repr', 'max_variable_length')
    assert set(CHECK_ALL_EXCEPTIONS) == set(_CHECK_ALL_EXCEPTIONS)

    # 1. Test that all the constructor parameters are set correctly
    tracer = Tracer(output=nonsense, watch=nonsense, watch_explode=nonsense,
                    depth=nonsense, prefix=nonsense, overwrite=nonsense,
                    thread_info=nonsense, custom_repr=nonsense,
                    max_variable_length=nonsense)
    assert tracer._write is nonsense
    assert tracer.watch is nonsense
    assert tracer.depth is nonsense
    assert tracer.prefix is nonsense


# Generated at 2022-06-22 18:16:05.885917
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():

    # Set up mock patch for write
    write_patch = mock.patch.object(Tracer, 'write')
    mock_write = write_patch.start()

    # Set up mock patch for _is_internal_frame
    _is_internal_frame_patch = mock.patch.object(Tracer, '_is_internal_frame')
    mock__is_internal_frame = _is_internal_frame_patch.start()
    mock__is_internal_frame.return_value = True

    # Set up mock patch for context manager
    context_patch = mock.patch.object(Tracer, '__enter__')
    mock_context = context_patch.start()

    with Tracer() as tracer:
        pass

    assert mock_write.mock_calls == []
    mock__is_internal_frame.assert_called_

# Generated at 2022-06-22 18:16:18.560107
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func(a, b, c, d=1, e=[]):
        f = a + b
        g = f + c
        return d + e
    frame = func.__code__.co_filename, func.__code__.co_firstlineno, func.__code__.co_name, ['a', 'b', 'c', 'd', 'e', 'f', 'g']
    frame = inspect.getframeinfo(frame)

    assert get_local_reprs(frame.frame, watch=(
        BaseVariable('x', lambda frame: 42, 'int'),
        BaseVariable('y', lambda frame: 42, ['int']),
        BaseVariable('z', lambda frame: 42),
    ), custom_repr=[
        (type(42), lambda x: 'the answer')
    ]) == collections.OrderedDict

# Generated at 2022-06-22 18:16:28.238894
# Unit test for function get_write_function
def test_get_write_function():
    import sys

    expected_output_1 = sys.stdout
    expected_output_2 = 'this is a path'
    expected_output_3 = lambda x: 'lambda'

    actual_output_1 = get_write_function(sys.stdout, False)
    actual_output_2 = get_write_function(expected_output_2, False)
    actual_output_3 = get_write_function(expected_output_3, False)

    assert actual_output_1 == expected_output_1
    assert actual_output_2 == FileWriter(expected_output_2, False).write
    assert actual_output_3 == expected_output_3



# Generated at 2022-06-22 18:16:37.163999
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from os.path import join, exists
    from os import getcwd, remove
    from random import randint
    from time import time

    conditional_paint = False
    file_name_pattern = 'test_FileWriter_write_' + str(time()) + '_%d.txt'
    folder_to_create = join(getcwd(), str(randint(0, 10000)) + '_' + str(time()))
    file_name = file_name_pattern % 1
    path = join(folder_to_create, file_name)

    if exists(path):
        remove(path)

    file_writer = FileWriter(path, True)
    file_writer.write(u'foo')
    file_writer.write(u'bar')

    assert exists(path)

# Generated at 2022-06-22 18:16:39.319602
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    trace = Tracer(watch=('local_reprs',))
    result = trace(get_local_reprs)
    assert result is get_local_reprs

# Generated at 2022-06-22 18:16:40.761206
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:16:51.809165
# Unit test for constructor of class Tracer
def test_Tracer():

    import io
    import unittest

    from . import utils

    class SnoopTests(unittest.TestCase):
        def setUp(self):
            self.output_buffer = io.StringIO()

        def test_constructor_defaults(self):
            tracer = Tracer(self.output_buffer.write)
            self.assertEquals(tracer.depth, 1)
            self.assertEquals(tracer.prefix, '')
            self.assertFalse(tracer.overwrite)
            self.assertEquals(tracer.thread_info_padding, 0)
            self.assertEquals(tracer.thread_info, False)
            self.assertEquals(tracer.custom_repr, ())



# Generated at 2022-06-22 18:17:02.364088
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    '''Test case for method trace of class Tracer.
    '''
    # Mock out local_reprs
    get_local_reprs = utils.Mock(return_value=dict(a="some value"))

    # Bad variable names that should be quoted
    variable_names_to_quote = '\x00', ' ', '\n'

    # Special variable names
    variable_names_to_repr = 'a', 'b'

    # Normal variable names
    variable_names_normal = 'c', 'd'

    local_reprs = {}
    for name in variable_names_to_quote:
        local_reprs[name] = 'some value'
    for name in variable_names_to_repr:
        local_reprs[name] = name

# Generated at 2022-06-22 18:17:08.295096
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from . import TEST_DIRECTORY
    test_out_file = path_join(TEST_DIRECTORY, 'test_out.txt')
    open(test_out_file, 'w').close()   # Clear file
    with Tracer(output=test_out_file):
        a = 1
        b = 2
        c = (1, 2, 3)
    capturer = Capturer(source='test_out.txt')
    capturer.assert_contains(
        r'''^    Starting var:.. a = 1
    Starting var:.. b = 2
    Starting var:.. c = \(1, 2, 3\)
    ''')

# Generated at 2022-06-22 18:17:20.388100
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    with tempfile.NamedTemporaryFile('wb', suffix='.py') as f:
        f.write('a\n# -*- coding: utf-8 -*-\nb\n'.encode('utf-8'))
        f.flush()

        path = f.name
        loader = SourceLoader(path)
        frame = inspect.currentframe()
        frame.f_globals['__loader__'] = loader
        assert get_path_and_source_from_frame(frame) == (path, ['a','b'])
    with tempfile.NamedTemporaryFile('wb', suffix='.py') as f:
        f.write('a\n# -*- coding: latin-1 -*-\nb\n'.encode('latin-1'))
        f.flush()

# Generated at 2022-06-22 18:17:24.692501
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[:] == u'SOURCE IS UNAVAILABLE', repr(UnavailableSource()[:])
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:17:29.656116
# Unit test for constructor of class Tracer
def test_Tracer():
    global DISABLED
    assert Tracer().depth == 1
    try:
        DISABLED = True
        assert Tracer().depth == 1
        DISABLED = False
        assert Tracer().depth == 1
        DISABLED = True
        assert Tracer(depth=2).depth == 2
    finally:
        DISABLED = False



# Generated at 2022-06-22 18:17:33.674952
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    x = UnavailableSource()
    assert x[0] == u'SOURCE IS UNAVAILABLE'
    assert x[-1] == u'SOURCE IS UNAVAILABLE'
    assert x[1] == u'SOURCE IS UNAVAILABLE'
    assert x[100] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:41.688624
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import tempfile
    import textwrap
    from .utils import FakeModule
    from .utils import FakeModuleClass
    from .utils import FakeModuleFunction
    from .utils import FakeModuleMethod
    from .utils import FakeModuleStaticMethod

    @pysnooper.snoop()
    def _simple_function(my_arg):
        tmp = my_arg.upper()
        tmp = tmp.lower()
        return tmp

    with tempfile.NamedTemporaryFile(mode='r') as f:
        _simple_function("AbCdEf")
        output = f.read()

    assert output.startswith("Source path:... ")

# Generated at 2022-06-22 18:17:48.903086
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from multimethod import multimethod

    @multimethod
    def get_path_and_source_from_frame(self, frame):
        pass

    @multimethod
    def get_local_reprs(self, frame, watch, custom_repr):
        pass

    @multimethod
    def pycompat_timedelta_format(self, duration):
        pass

    @multimethod
    def pycompat_time_isoformat(self, time, timespec):
        pass
    

# Generated at 2022-06-22 18:17:57.693594
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    snooper = pysnooper.Snooper(watch=Variable('foo'), depth=8, thread_info=True)
    snooper.write = mock.MagicMock()
    def _is_internal_frame(self, frame): return True
    snooper._is_internal_frame = mock.MagicMock(side_effect=_is_internal_frame)
    def _is_internal_frame(self, frame): return False
    snooper._is_internal_frame = mock.MagicMock(side_effect=_is_internal_frame)
    snooper.__enter__()

# Generated at 2022-06-22 18:17:59.162683
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()



# Generated at 2022-06-22 18:18:01.312158
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert list(UnavailableSource()) == ['SOURCE IS UNAVAILABLE'] * 14



# Generated at 2022-06-22 18:18:10.368611
# Unit test for constructor of class Tracer
def test_Tracer():

    write = mock.Mock()
    output = mock.Mock()
    output.write = write
    overwrite = mock.Mock()

    # Trace an empty function
    tracer = Tracer(output=output, overwrite=overwrite)
    with tracer:
        def test_function():
            pass
        test_function()

    # Trace a function that returns a value
    tracer = Tracer(output=output, overwrite=overwrite)
    with tracer:
        def test_function2():
            return 'hi'
        test_function2()

    # Trace a function that returns nothing
    tracer = Tracer(output=output, overwrite=overwrite)
    with tracer:
        def test_function3():
            return
        test_function3()

    # Trace a function that takes arguments
    tracer = Tracer

# Generated at 2022-06-22 18:18:19.535472
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # Passing a string
    fw = FileWriter('/home/me/somedir/somename.txt', overwrite=True)
    assert fw.path == '/home/me/somedir/somename.txt'
    assert fw.overwrite == True

    # Passing a PathLike object
    path = pycompat.PathLike('/home/me/somedir/somename.txt')
    fw = FileWriter(path, overwrite=True)
    assert fw.path == '/home/me/somedir/somename.txt'
    assert fw.overwrite == True



# Generated at 2022-06-22 18:18:21.039366
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    FileWriter(path, overwrite).write(s)



# Generated at 2022-06-22 18:18:23.304719
# Unit test for constructor of class FileWriter
def test_FileWriter():
    obj = FileWriter('path', True)
    assert obj.path == 'path'
    assert obj.overwrite is True


# Generated at 2022-06-22 18:18:33.402987
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def real_decorator(global_1):
        global global_to_inner
        global_to_inner = global_1
        # Define a function "decorated" inside the decorator:
        def decorated(fname):
            pass
        global_to_inner.append(decorated)
        return decorated
    class FixArgs:
        def __init__(self, *args):
            self.args = args
        def __call__(self, f):
            def wrapped(*args, **kwargs):
                return f(*(self.args + args), **kwargs)
            return wrapped
    def func_1():
        global global_to_outer
        global_to_outer = global_to_inner
    import functools
    import inspect
    import sys

# Generated at 2022-06-22 18:18:35.597569
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[:] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:44.416454
# Unit test for function get_write_function
def test_get_write_function():

    # Should fail if trying to use overwrite without a path as a file
    error_raised = False
    try:
        get_write_function(output=object(), overwrite=True)
    except:
        error_raised = True
    assert error_raised

    # Should accept strings as file paths
    write = get_write_function(output='file.txt', overwrite=True)
    assert callable(write)

    # Should accept binary file objects
    write = get_write_function(output=open('file.txt', 'wb'), overwrite=True)
    assert callable(write)

    # Should accept text file objects
    write = get_write_function(output=open('file.txt', 'w'), overwrite=True)
    assert callable(write)

    # Should accept binary streams

# Generated at 2022-06-22 18:18:51.374787
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    assert(isinstance(tracer,Tracer))
    tracer.thread_info_padding = 0
    tracer.thread_info = True
    thread_info = "2-Thread-3 "
    tracer.set_thread_info_padding(thread_info)
    assert(tracer.thread_info_padding == len(thread_info))

# Generated at 2022-06-22 18:18:52.842149
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert str(Tracer()) == 'Tracer()'



# Generated at 2022-06-22 18:18:55.645580
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        n = get_path_and_source_from_frame(inspect.currentframe())
        assert n == (__file__, inspect.getsourcelines(foo)[0])
    foo()



# Generated at 2022-06-22 18:18:57.665902
# Unit test for method write of class Tracer
def test_Tracer_write():
    Tracer.write(Tracer, pysnooper.DISABLED)


# Generated at 2022-06-22 18:19:02.014594
# Unit test for method write of class Tracer
def test_Tracer_write():
    global trace_write_method
    trace_write_method = []
    def do_nothing(s):
        trace_write_method.append(s)
    def do_nothing2(*args, **kwargs):
        pass
    test = Tracer(do_nothing)
    setattr(test, "_write", do_nothing2)
    test.write("hello")
    assert trace_write_method == ["hello"]
    test.write("hello2")
    assert trace_write_method == ["hello", "hello2"]
    test.prefix = "prefix1"
    test.write("hello3")
    assert trace_write_method == ["hello", "hello2", "prefix1hello3"]
    test.write("hello4")

# Generated at 2022-06-22 18:19:07.040407
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper

    #####################################################################
    # Tracer.__enter__() - no test yet:
    pytest.skip('Not tested')
    #####################################################################




# Generated at 2022-06-22 18:19:14.262539
# Unit test for function get_write_function
def test_get_write_function():
    with pytest.raises(Exception):
        get_write_function('file.txt', True)
    with open('file.txt', 'w') as file:
        def write_to_file(s):
            file.write(s.encode())
        write_to_file = get_write_function(write_to_file, overwrite=False)
        write_to_file('Hi!')
        file.seek(0)
        assert file.read() == 'Hi!'
test_get_write_function()



# Generated at 2022-06-22 18:19:18.959680
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test with parameter `watch`
    # Test with parameter `depth`
    # Test with parameter `prefix`
    # Test with parameter `overwrite`
    # Test with parameter `thread_info`
    # Test with parameter `custom_repr`
    # Test with parameter `max_variable_length`
    # Test with parameter `normalize`
    # Test with parameter `relative_time`
    pass


# Generated at 2022-06-22 18:19:23.748483
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    thread_info = tracer.set_thread_info_padding("1234-thread1 ")
    assert thread_info == "1234-thread1 "
    thread_info = tracer.set_thread_info_padding("123-thread2 ")
    assert thread_info == "123-thread2 ".ljust(tracer.thread_info_padding)



# Generated at 2022-06-22 18:19:26.287831
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:19:29.995073
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    trace = Tracer()
    trace.write = Mock()

    trace.__exit__(None, None, None)
    trace.write.assert_called_once_with('    Elapsed time: 0:00:00.000000')

# Generated at 2022-06-22 18:19:38.944065
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    import os

    x = 1
    current_frame = inspect.currentframe()
    assert current_frame.f_locals['x'] == 1
    (filename, source) = get_path_and_source_from_frame(current_frame)
    assert source[current_frame.f_lineno - 1].strip() == 'x = 1'
    with tempfile.NamedTemporaryFile('w+b', prefix='test_', suffix='py',
                                     delete=False) as file:
        file.write(b'a = 1\nb = 2\nc = 3')

# Generated at 2022-06-22 18:19:48.369180
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    class Mock:
        def __init__(self):
            self.frame = self
            self.f_code = self
            self.f_lineno = None
        def __enter__(self):
            pass
        def __exit__(self, ex_type, ex_value, ex_traceback):
            pass
        def __getattr__(self, name):
            return Mock()
    p = Mock()
    snoop = Tracer()
    with snoop:
        p.f_lineno = 1
        p.f_back = Mock()
        p.f_back.f_lineno = 2

# Generated at 2022-06-22 18:20:00.468168
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = 2
        z = 3
        return locals()
    variables = [CommonVariable('z', 'z'),
                 CommonVariable('y', 'y', value_repr_args=(1, '2')),
                 CommonVariable('x', 'x', value_repr_args=(1, '2'))]

# Generated at 2022-06-22 18:20:04.084782
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    available_source = UnavailableSource()
    assert available_source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:10.433508
# Unit test for constructor of class FileWriter
def test_FileWriter():
    for path in ('spam', 'eggs'):
        for overwrite in (True, False):
            write, path, overwrite = FileWriter(path, overwrite), path, overwrite
            assert write('Hello, world!') == None
            assert write.path == path
            assert write.overwrite == overwrite
            # When `overwrite` is `False`, new content is appended:
            overwrite = not overwrite
            assert write.overwrite == overwrite
            with open(path, 'r') as read_file:
                assert read_file.read() == 'Hello, world!'
            if overwrite:
                # The file was created, and we're still overwriting:
                assert write('Goodbye, world!') == None
                with open(path, 'r') as read_file:
                    assert read_file.read() == 'Goodbye, world!'


# Generated at 2022-06-22 18:20:17.755702
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def test_func():
        "Nothing to do."
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
    frame = utils.get_frame(test_func)
    local_reprs_dict = get_local_reprs(frame)
    assert local_reprs_dict == {'a': '1', 'b': '2', 'c': '3', 'd': '4', 'e': '5', 'f': '6', 'g': '7'}
    local_reprs_dict = get_local_reprs(frame, (CommonVariable('a'),))

# Generated at 2022-06-22 18:20:25.988382
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # setup
    tracer = Tracer()
    thread_info_padding = 10
    tracer.thread_info_padding = thread_info_padding

    # Act 1
    thread_info = tracer.set_thread_info_padding('test')

    # Assert 1
    assert thread_info == 'test'.ljust(thread_info_padding)

    # Act 2
    thread_info = tracer.set_thread_info_padding('test!')
    # Assert 2
    assert thread_info == 'test!'.ljust(thread_info_padding)


# Generated at 2022-06-22 18:20:30.526225
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    for i in (0, 1, 2, -1, -2):
        assert unavailable_source[i] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:37.687723
# Unit test for function get_write_function
def test_get_write_function():
    import sys
    import io
    import pickle
    from pathlib import Path
    from bugzoo.core.fileio import TemporaryDirectory
    s = u'Hi there!'
    write = get_write_function(sys.stderr, False)
    write(s)
    stream = io.StringIO()
    write = get_write_function(stream, False)
    write(s)
    assert stream.getvalue() == s
    with TemporaryDirectory() as d:
        path = Path(d) / 'file'
        write = get_write_function(path, True)
        write(s)
        with path.open() as fp:
            assert fp.read() == s



# Generated at 2022-06-22 18:20:44.361272
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
  exception = None
  try:
    tracer.__enter__()
  except Exception as exception:
    pass
  return exception


# Generated at 2022-06-22 18:20:46.023611
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:50.496649
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_the_thing():
        return get_path_and_source_from_frame(sys._getframe())
    assert get_the_thing() == os.path.abspath(__file__), __file__



# Generated at 2022-06-22 18:21:01.888943
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys

    class Foo:
        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.c = self.a + self.b + 1

        def get_a(self):
            return self.a

    class Bar:
        def __init__(self):
            self.foo = Foo(1, 2)

        def get_foo(self):
            return self.foo

    @snoop()
    def foo_foo(foo):
        foo.a += 1
        foo.b += 1

    @snoop(watch=('self', 'foo'))
    def foo_bar(bar):
        bar.foo.a += 1
        bar.foo.b += 1

    buffer = io.StringIO()
    tracer = Tracer

# Generated at 2022-06-22 18:21:05.684291
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter('/home/filewriter.test', 'True')
    output_file = open('/home/filewriter.test', 'w', encoding='utf-8')
    output_file.write('test')
    output_file.close()



# Generated at 2022-06-22 18:21:11.717736
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    snooper = None
    def test():
    
        global snooper
        snooper = pysnooper.snoop()
        snooper.__enter__()
    
    test()
    

# Generated at 2022-06-22 18:21:15.145119
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write('test write')

# This test is copied verbatim from the source, so as to ensure it contains the
# original namespace, which this test needs, but it is not the same as the
# original test. I apologize for that.

# Generated at 2022-06-22 18:21:27.165515
# Unit test for method write of class Tracer
def test_Tracer_write():
    global DISABLED
    output_list = []
    def my_write(s):
        output_list.append(s)
    tracer = Tracer(output=my_write)
    tracer.write("line 1")
    tracer.write("line 2")
    tracer.prefix="PREFIX "
    tracer.write("line 3")
    assert output_list == ["line 1\n", "line 2\n", "PREFIX line 3\n"]
    try:
        DISABLED = True
        tracer.write("line 4")
        assert output_list == ["line 1\n", "line 2\n", "PREFIX line 3\n"]
    finally:
        DISABLED = False

test_Tracer_write()


# Generated at 2022-06-22 18:21:30.843603
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert isinstance(get_path_and_source_from_frame(
        inspect.currentframe())[1], list)
test_get_path_and_source_from_frame()



# Generated at 2022-06-22 18:21:35.838825
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = inspect.currentframe()
    assert get_local_reprs(frame) == {'frame': '<frame>'}
    del frame
    assert get_local_reprs(inspect.currentframe()) == {'frame': '<frame>'}



# Generated at 2022-06-22 18:21:43.312856
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    class Foo:
        def method(self):
            return 42
    foo = Foo()
    from .core import PY2

# Generated at 2022-06-22 18:21:52.993211
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def my_function(x):
        a = 7
        b = (1, 2)
        try:
            1 / 0
        except:
            c = 'Something happened.'
        return x * a * len(b)
    frame = inspect.currentframe().f_back
    watch = (CommonVariable('b[0]'), CommonVariable('x'),
             CommonVariable('c'),
             CommonVariable('my_function(3)'))
    result = get_local_reprs(frame, watch=watch, max_length=28,
                             normalize=True)
    assert result == {'x': '3', 'a': '7', 'b[0]': '1', 'b': '(1, 2)',
                      'c': "'Something happened.'",
                      'my_function(3)': '21'}
    assert get

# Generated at 2022-06-22 18:21:54.158076
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    us = UnavailableSource()
    assert us[3] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:21:55.758159
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-22 18:21:57.652296
# Unit test for constructor of class Tracer
def test_Tracer():
    assert Tracer()

# Unit tests for function get_write_function

# Generated at 2022-06-22 18:22:04.306211
# Unit test for constructor of class FileWriter
def test_FileWriter():
    fw = FileWriter("foo.txt", overwrite = True)
    fw.write("foo")
    fw = FileWriter("foo.txt", overwrite = False)
    fw.write("bar")
    # Test that the file has been created
    with open("foo.txt", "r") as f:
        text = f.read()
        assert text == "foo\nbar"



# Generated at 2022-06-22 18:22:15.259534
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Pickling should be tested
    # but I don't know how to do it
    # skipping for now
    # (could not find example online)
    output = StringIO()
    def func():
        return 42
    @snoop(watch=('x',), output=output)
    def deco_func():
        x = None
        x = func()
        return x
    deco_func()
    expected = """Source path:... pysnooper/snoop.py
    New var:....... x = None
    Starting var:.. x = None
    New var:....... x = 42
    Elapsed time: 0:00:00.000001
    Return value:.. 42\n"""
    assert output.getvalue() == expected


# Generated at 2022-06-22 18:22:20.832569
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    # It's a class because it doesn't really have any data and we want the
    # instance to be lightweight
    assert isinstance(UnavailableSource(), UnavailableSource)

    # It should act like a list, so that `.join()` can be called on it.
    assert UnavailableSource().join([]) == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:22:27.374854
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def func():
        pass

    class Foo():
        def method(self):
            pass

    class Bar():
        @property
        def method(self):
            pass

    tracer = Tracer()

    assert tracer(func) != func
    assert tracer(Foo) != Foo
    assert tracer(Foo().method) != Foo().method
    assert tracer(Bar().method) != Bar().method

test_Tracer___call__()

