

# Generated at 2022-06-22 18:12:26.350177
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()


# Generated at 2022-06-22 18:12:35.623288
# Unit test for constructor of class Tracer
def test_Tracer():
    call_depth = 0
    def write(s):
        assert call_depth >= 0
        assert s[-1] == '\n'
    tracer = Tracer(write)
    tracer.__call__(write)
    tracer.__call__(test_Tracer)
    tracer.__call__(test_Tracer)
    tracer.__call__(test_Tracer)
    tracer.__call__(test_Tracer)
    tracer.__call__(test_Tracer)
    assert tracer.__call__(test_Tracer) == test_Tracer
    assert tracer.__call__(write) == write
    assert tracer.__enter__() is None


### Functions and classes for getting a source file from a frame: ###########
#                                                                           #
#

# Generated at 2022-06-22 18:12:42.301542
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # Test local variable line_info first
    tracer = Tracer()
    line_info = tracer.set_thread_info_padding("")
    assert line_info == " " * tracer.thread_info_padding
    # Test thread_info_padding second
    tracer_1 = Tracer()
    # Check thread name as word and a digit
    line_info_1 = tracer_1.set_thread_info_padding("MainThread-1 ")
    assert line_info_1 == "MainThread-1"
    # Check thread name as only word
    line_info_2 = tracer_1.set_thread_info_padding("MainThread ")
    assert line_info_2 == "MainThread-1"
    # Check thread name as only digit
    line_info_3 = tracer_1.set_

# Generated at 2022-06-22 18:12:50.048300
# Unit test for constructor of class FileWriter
def test_FileWriter():
    fw = FileWriter(path="/tmp/test.txt", overwrite=True)
    # Write a string
    fw.write('This is a test')
    # Make sure it is not appending to the file
    fw.overwrite = False
    fw.write('Second test')
    # Make sure it is appending to the file
    with open("/tmp/test.txt", 'r') as output_file:
        assert output_file.read() == 'This is a testSecond test'



# Generated at 2022-06-22 18:13:01.217654
# Unit test for function get_local_reprs
def test_get_local_reprs():
    try:
        raise
    except:
        frame = sys.exc_info()[2].tb_frame.f_back

# Generated at 2022-06-22 18:13:08.713467
# Unit test for function get_local_reprs
def test_get_local_reprs():

    def foo():
        return get_local_reprs(inspect.currentframe())
    assert foo() == {'foo': 'foo()'}
    a = 1
    assert foo() == {'a': '1', 'foo': 'foo()'}
    def foo():
        a = 2
        b = 3
        return get_local_reprs(inspect.currentframe())
    assert foo() == {'a': '2', 'b': '3', 'foo': 'foo()'}
    def foo():
        a = 2
        b = 3
        c = 4
        return get_local_reprs(inspect.currentframe())
    assert foo() == {'a': '2', 'b': '3', 'c': '4', 'foo': 'foo()'}



# Generated at 2022-06-22 18:13:20.862155
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    mock_frame = collections.namedtuple('MockFrame', ('f_globals', 'f_code'))
    mock_frame.f_globals = {'__name__': 'x', '__loader__': None}
    mock_frame.f_code = type('Code', (), {'co_filename': 'file.py'})()


# Generated at 2022-06-22 18:13:33.160451
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import os, sys
    from collections import OrderedDict
    from io import StringIO
    import pytest
    import pysnooper
    import pycompat
    import utils
    import inspect
    import functools
    import threading
    import importlib
    import time
    import re
    import traceback

    class TestTracerClass(object):
        def test_method(self):
            pass
    test_TracerClass_instance = TestTracerClass()

    def test_function():
        pass

    def test_decorator(function):
        return function
    test_decorator = test_decorator(test_function)

    def test_generator():
        yield
        yield 1
        yield 2
        yield 3
    test_generator = test_decorator(test_generator)



# Generated at 2022-06-22 18:13:35.986285
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.thread_info_padding = 0
    tracer.set_thread_info_padding('123')
    assert tracer.thread_info_padding == 3


# Generated at 2022-06-22 18:13:42.368225
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    import inspect
    import linecache

    def this_function_name():
        return inspect.getframeinfo(inspect.currentframe()).function

    test_source_lines = [
        "def " + this_function_name() + "():",
        "    return [line.strip() for line in " + repr(inspect.getsource(this_function_name).strip()) + ".splitlines()]"
    ]

    result = get_path_and_source_from_frame(inspect.currentframe())
    assert result[0].endswith('test_get_path_and_source_from_frame.py')
    assert result[1] == test_source_lines

    # Make sure the caching works
    assert get_path_and_source_from_frame(inspect.currentframe()) is result



# Generated at 2022-06-22 18:13:54.115804
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = '/tmp/test_FileWriter_content.txt'
    FileWriter(path, True).write('test_FileWriter_content')

    assert os.path.isfile(path)

    with open(path, 'r') as f:
        content = f.read()
    assert content == 'test_FileWriter_content'

    # now test the case when overwrite is False
    prev_mtime = os.path.getmtime(path)
    FileWriter(path, False).write('more content')
    # check the file exists
    assert os.path.isfile(path)
    # check the mtime is not changed
    assert os.path.getmtime(path) == prev_mtime
    # check the content is appended
    with open(path, 'r') as f:
        content = f.read()


# Generated at 2022-06-22 18:14:00.877732
# Unit test for function get_write_function
def test_get_write_function():
    from . import common_testing

    def file_writer_mock(path, mode, content):
        assert path == 'output_path'
        assert mode == 'w'
        assert content == 'hello world'

    with common_testing.TempFolder() as temp_folder:
        with common_testing.MockFileWriter(file_writer_mock):
            write_function = get_write_function('output_path', True)
            write_function('hello world')



# Generated at 2022-06-22 18:14:01.765831
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0]



# Generated at 2022-06-22 18:14:09.918156
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """
    Testing method __exit__ of class Tracer
    """
    print("")
    print("Testing method __exit__ of class Tracer")
    print("")

    import datetime
    import os

    import threading

    import pycompat

    def get_write_function(output, overwrite):
        import sys

        def write_function(s):
            if sys.version_info[0] >= 3:
                sys.stdout.buffer.write(s.encode())
            else:
                sys.stdout.write(s.encode())

    class BaseVariable(object):
        """An abstract base class for representing variables to
        watch for.
        """

        def __init__(self, name, name_set=None):
            self.name = name

# Generated at 2022-06-22 18:14:13.092126
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from sugar_document import Document
    from . import test_utils

    temp_file = test_utils.temporary_file()
    writer = FileWriter(temp_file, True)
    writer.write('a')
    writer.write('b')
    writer.write('c')
    with open(temp_file, 'r') as f:
        assert f.read() == 'abc'



# Generated at 2022-06-22 18:14:25.493867
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    import os
    temp_file = tempfile.mkstemp()
    dir_name = os.path.dirname(temp_file[1])
    os.close(temp_file[0])

    FileWriter(temp_file[1], False).write("1\n")
    with open(temp_file[1]) as file_name:
        assert file_name.read()=="1\n"

    FileWriter(temp_file[1], False).write("2\n")
    with open(temp_file[1]) as file_name:
        assert file_name.read()=="1\n2\n"

    FileWriter(temp_file[1], True).write("3\n")
    with open(temp_file[1]) as file_name:
        assert file_name.read()

# Generated at 2022-06-22 18:14:33.248681
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  from types import FunctionType
  from types import MethodType
  from types import TracebackType
  from unittest import TestCase
  from unittest.mock import patch
  
  import inspect
  
  import _pysnooper
  import _pysnooper.trace_factory
  
  # This test string will be used to capture the output of a mocked out write method
  test_string = ''
  
  # In this decorator method, the mock will capture the output of the write method
  # and allow it to be tested in this unit test.

# Generated at 2022-06-22 18:14:40.870005
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Setup
    output = None
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    tracer = Tracer(output, watch, watch_explode, depth, prefix,
                    overwrite, thread_info, custom_repr,
                    max_variable_length, normalize, relative_time)

    # Run
    func = tracer.__call__()

    # Assert
    assert isinstance(func, FunctionType)
    assert func.__name__ == 'simple_wrapper'

# Generated at 2022-06-22 18:14:45.196510
# Unit test for method write of class Tracer
def test_Tracer_write():
    class UnitTestTracer(Tracer):
        def __init__(self, *args, **kwargs):
            self.lines = []
            Tracer.__init__(self, *args, **kwargs)
        def _write(self, s):
            self.lines.append(s)

    tracer = UnitTestTracer()
    tracer.write('hello world')
    assert tracer.lines == ['hello world\n']

# Generated at 2022-06-22 18:14:56.257143
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # set up
    self = Tracer()
    if DISABLED:
        return
    thread_global.__dict__.setdefault('depth', -1)
    calling_frame = inspect.currentframe().f_back
    if not self._is_internal_frame(calling_frame):
        calling_frame.f_trace = self.trace
        self.target_frames.add(calling_frame)

    stack = self.thread_local.__dict__.setdefault(
        'original_trace_functions', []
    )
    stack.append(sys.gettrace())
    self.start_times[calling_frame] = datetime_module.datetime.now()
    sys.settrace(self.trace)

    # body of __exit__
    if DISABLED:
        pass
    stack = self.thread_local

# Generated at 2022-06-22 18:15:03.785214
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .watch import Watch
    from .variables import EasyAccess, Exploding, Variable
    def namedtuple(typename, field_names, raw_data):
        class NamedTuple(object):
            def __getitem__(self, i):
                return raw_data[i]
            def __iter__(self):
                return iter(raw_data)
            def __len__(self):
                return len(raw_data)
            __getattr__ = __getitem__
        return NamedTuple()
    class Meta(type):
        __instancecheck__ = (lambda self, instance:
                             isinstance(instance, tuple) or
                             isinstance(instance, self))
    class NT(tuple, metaclass=Meta):
        _fields = list('abcd')

# Generated at 2022-06-22 18:15:06.533483
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[3] == 'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:15:14.125119
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.thread_info_padding == 0
    tracer.set_thread_info_padding("4444-Thread-1 ")
    assert tracer.thread_info_padding == 16
    tracer.set_thread_info_padding("555-Thread-2 ")
    assert tracer.thread_info_padding == 16
    tracer.set_thread_info_padding("66666-Thread-3 ")
    assert tracer.thread_info_padding == 18


# Generated at 2022-06-22 18:15:18.540624
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    utils.assert_equals(
        # returns:
        DISABLED
        or
        # just a little sanity check that we can enter and exit the same
        # context manager.
        not DISABLED
    )

# Generated at 2022-06-22 18:15:22.006172
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False) is sys.stderr.write
    assert isinstance(get_write_function(open(__file__, 'w'), False),
                      collections.abc.Callable)



# Generated at 2022-06-22 18:15:29.002342
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Some boilerplate to setup a module and an example function to decorate:
    test_module = types_module.ModuleType('test_module')
    test_module.__dict__.update(globals())
    def test_function():
        pass
    sys_modules_backup = sys.modules
    sys.modules[test_module.__name__] = test_module

# Generated at 2022-06-22 18:15:30.172041
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with pytest.raises(NameError):
        test_Tracer___enter__()


# Generated at 2022-06-22 18:15:32.049229
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert (UnavailableSource()[0] ==
            u'SOURCE IS UNAVAILABLE')



# Generated at 2022-06-22 18:15:39.998321
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop()
    def foo():
        var = 'foo'
        return var

    assert isinstance(foo.__wrapped__, types.FunctionType)
    assert isinstance(foo.__wrapped__.__wrapped__, types.FunctionType)
    assert foo.__wrapped__.__name__ == 'foo'
    assert foo.__wrapped__ is not foo

    assert foo.__wrapped__.__wrapped__.__name__ == 'foo'
    assert foo.__wrapped__.__wrapped__ is not foo
    assert foo.__wrapped__.__wrapped__ is not foo.__wrapped__



# Generated at 2022-06-22 18:15:44.422619
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    ## Tracer.__exit__
    tc = Tracer(None, None, None, None)
    tc.target_codes.add(test_Tracer___exit__.__code__)

    tc2 = Tracer(None, None, None, None, True)
    tc2.target_codes.add(test_Tracer___exit__.__code__)

# Generated at 2022-06-22 18:15:46.389564
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[(1, 2)] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:15:50.159741
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == inspect.getfile(
                                                                    test_get_path_and_source_from_frame), \
        'get_path_and_source_from_frame() - failed'



# Generated at 2022-06-22 18:16:02.796038
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.thread_info_padding = 0
    thread_info = tracer.set_thread_info_padding("")
    assert thread_info == ""
    thread_info = tracer.set_thread_info_padding("     ")
    assert thread_info == "     "
    thread_info = tracer.set_thread_info_padding("   ")
    assert thread_info == "   "
    thread_info = tracer.set_thread_info_padding("   j")
    assert thread_info == "   j"
    thread_info = tracer.set_thread_info_padding("     j")
    assert thread_info == "     j"

    tracer.thread_info_padding = 3
    thread_info = tracer.set_thread_info_padding("")
   

# Generated at 2022-06-22 18:16:10.597451
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pytest import raises
    tracer = Tracer(watch=('x', 'y'), custom_repr=((int, lambda x: '<%s>' % x),))
    def foo(x, y):
        return x + y
    foo(1, y=2)
    tracer.write('')
    foo(3, y=4)
    tracer.write('')
    foo(0, 2)
    tracer.write('')
    with raises(NotImplementedError):
        tracer(asyncio.coroutine(foo))
    tracer(asyncio.coroutine(foo))
    tracer.write('')

# Generated at 2022-06-22 18:16:21.487200
# Unit test for function get_write_function
def test_get_write_function():
    write_to_stderr_function = functools.partial(get_write_function, None)
    assert isinstance(write_to_stderr_function(), pycompat.callable_type)

    string_io = utils.get_string_io()
    write_to_stream_function = functools.partial(get_write_function, string_io)
    assert isinstance(write_to_stream_function(), pycompat.callable_type)

    write_to_file_function = functools.partial(get_write_function, 'tmp.txt')
    assert isinstance(write_to_file_function(), pycompat.callable_type)

    with pycompat.open_file('tmp.txt', 'rt') as f:
        assert f.read() == ''

# Generated at 2022-06-22 18:16:25.717107
# Unit test for method write of class Tracer
def test_Tracer_write():
    x = Tracer()
    x.write('a')
    # Should print a:
    print(x._write)


# Generated at 2022-06-22 18:16:34.863023
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Another way to start the test, but currently we have no parameter to
    # give.
    #test_func.test_instance_method(Tracer, '__enter__')
    with pytest.raises(ImportError) as excinfo:
        from pysnooper import snoop
        import logging
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.DEBUG)

        ### first use case
        def test_snooper_basic():
            @snoop()
            def get_primes(n):
                return [x for x in range(2, n)
                        if not any(x % y == 0 for y in range(2, x))]

            return get_primes(10)

        test_snooper_basic()

        ### second use case

# Generated at 2022-06-22 18:16:40.016593
# Unit test for method write of class Tracer
def test_Tracer_write():
    from io import StringIO
    from unittest.mock import Mock
    with StringIO() as output_stream:
        with Tracer(output=output_stream):
            Tracer.write(Mock(), 'hello')
            Tracer.write(Mock(), 'world')
        output_stream.seek(0)
        assert output_stream.read() == 'hello\nworld\n'



# Generated at 2022-06-22 18:16:41.575687
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(sys.stdout, False) == sys.stdout.write



# Generated at 2022-06-22 18:16:49.167660
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import random
    import string
    import filecmp
    letters = [letter for letter in string.ascii_letters]
    file_name = "".join(random.choices(letters, k=10))
    string_to_write = "".join(random.choices(letters, k=100))
    file_writer = FileWriter(file_name, True)
    file_writer.write(string_to_write)
    with open(file_name, encoding='utf-8') as file:
        assert file.read() == string_to_write




# Generated at 2022-06-22 18:16:51.228903
# Unit test for constructor of class FileWriter
def test_FileWriter():
    FileWriter('/tmp/test_file.txt', overwrite=True)



# Generated at 2022-06-22 18:16:54.322805
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'Dummy'
    s = FileWriter(path, True)
    assert s.path == path
    assert s.overwrite == True


# Generated at 2022-06-22 18:17:02.410496
# Unit test for constructor of class Tracer
def test_Tracer():
    test_engine = {
        "output": None,
        "watch": (1, 2, 3),
        "watch_explode": (4, 5, 6),
        "depth": 2,
        "prefix": "PREFIX ",
        "overwrite": True,
        "thread_info": True,
        "custom_repr": ((object, str),),
        "max_variable_length": 100,
        "normalize": False,
        "relative_time": False
    }

    tracer = Tracer(**test_engine)

    for key, value in test_engine.items():
        assert getattr(tracer, key) == value

# Generated at 2022-06-22 18:17:07.756194
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t = Tracer(thread_info=True)
    thread_info = "2-PID3"
    assert t.set_thread_info_padding(thread_info) == "2-PID3 "
    thread_info = "1234-PID5678"
    assert t.set_thread_info_padding(thread_info) == "1234-PID5678 "
    thread_info = "97-PID38"
    assert t.set_thread_info_padding(thread_info) == "1234-PID5678 "



# Generated at 2022-06-22 18:17:16.891100
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    def write_file(overwrite):
        content = b'Hello world!\n'
        with tempfile.TemporaryFile() as output_file:
            file_writer = FileWriter(output_file, overwrite)
            file_writer.write(content)
            output_file.seek(0)
            return output_file.read()
    assert write_file(True) == content



# Generated at 2022-06-22 18:17:28.700821
# Unit test for constructor of class Tracer
def test_Tracer():
    from tempfile import mkstemp
    from os import close, remove
    from io import TextIOWrapper
    from contextlib import ExitStack
    from pysnooper.utils import shortish_repr
    from pysnooper import strings_with_quotes
    # Test pysnooper.strings_with_quotes
    if strings_with_quotes('"abc"') != '"abc"':
        raise AssertionError()
    if strings_with_quotes('\'abc\'') != '"abc"':
        raise AssertionError()
    if strings_with_quotes('r"abc"') != 'r"abc"':
        raise AssertionError()
    if strings_with_quotes('b"abc"') != 'b"abc"':
        raise AssertionError()
    # Test

# Generated at 2022-06-22 18:17:31.787783
# Unit test for method write of class Tracer
def test_Tracer_write():
    with StringIO() as output:
        tracer = Tracer(output)
        line = 'Just a line'
        tracer.write(line)
        output.seek(0)
        line1 = output.readline()
        assert line1 == line

# Generated at 2022-06-22 18:17:38.121789
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    snoop_instance = pysnooper.snoop()
    def fun(*args, **kwargs):
        pass
    function = fun
    result = snoop_instance.__call__(function)
    assert result is not None


# Generated at 2022-06-22 18:17:46.997024
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as directory_path:
        file_path = os.path.join(directory_path, 'test_FileWriter.txt')
        output_file = open(file_path, 'w')
        content = ['This is a test for constructor of class FileWriter',
                   'This is the second line of this test.']
        output_file.writelines(content)
        output_file.close()
        file_writer = FileWriter(file_path, False)
        file_writer.write(content[0])
        file_writer.write(content[1])
        with open(file_path, 'r', encoding='utf-8') as output_file:
            actual = output_file.readlines()
        assert actual == content + content

# Generated at 2022-06-22 18:17:50.435166
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global DISABLED
    DISABLED = False
    tracer = Tracer()
    tracer.__enter__()
    # test disabled
    DISABLED = True
    tracer.__enter__()

# Generated at 2022-06-22 18:17:57.723404
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_writer = FileWriter(r'C:\Users\Ram\Desktop\tmp.txt', True)
    file_writer.write('I am writing data to file')
    file_writer = FileWriter(r'C:\Users\Ram\Desktop\tmp.txt', False)
    file_writer.write('I am writing data to file again')
    output_file = open(r'C:\Users\Ram\Desktop\tmp.txt', 'r')
    file_writer.write(output_file.read())

# Generated at 2022-06-22 18:18:00.249077
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:03.173370
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    doctest.testmod(verbose=False)

# Unit tests for method __enter__ of class Tracer

# Generated at 2022-06-22 18:18:10.740583
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper import snoop

    @snoop()
    def foo(x):
        print('hello')
        y = x + 1
        print('hello world')
        return y

    expected_output = '''
    Source path:... {filename}
    {indent}Call to........ foo
    hello
    {indent}New var:....... y = 2
    hello world
    {indent}Return value:.. 2
    {indent}Returned from.. foo
    '''.format(filename=__file__,
               indent=' ' * 4)

    assert foo(1) == 2

    actual_output = CAPTURER.captured_text
    assert expected_output in actual_output
    # print('\n', actual_output, '\n')


# Generated at 2022-06-22 18:18:13.634865
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from . import test_get_local_reprs
    test_get_local_reprs.test_get_local_reprs(get_local_reprs)



# Generated at 2022-06-22 18:18:19.691872
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function(x, y):
        print(x + y)
        print(x + y)
        print(x + y)
        print(x + y)
    ((file_name, source),) = inspect.stack()[1:2]
    assert get_path_and_source_from_frame(inspect.currentframe()) == (file_name, source)



# Generated at 2022-06-22 18:18:28.807159
# Unit test for constructor of class Tracer
def test_Tracer():
    def func(a):
        """Function definition."""
        b = {'a' : 'aaa', 'b' : 'bbb'}
        c = 'ccc'
        return a
    @Tracer()
    def func2(a):
        """Function definition"""
        b = {'a' : 'aaa', 'b' : 'bbb'}
        c = 'ccc'
        return a
    @Tracer(output='output.txt')
    def func3(a, b):
        """Function definition"""
        e = a + b
        return e
    @Tracer(watch=['b'])
    def func4(a):
        """Function definition"""
        b = 'bbb'
        c = 'ccc'
        return a

# Generated at 2022-06-22 18:18:40.211695
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass

    tracer = Tracer(overwrite=True)
    tracer.__call__(foo)
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.custom_repr == ()
    assert tracer.max_variable_length == 100

    tracer = Tracer(depth=2, watch='foo', prefix='XXX ',
                    thread_info=True, custom_repr=((type(1), lambda x: 'hello'),
                                                   (lambda x: True, lambda x: 'world')),
                    max_variable_length=20, normalize=True,
                    relative_time=True)

    tracer.__call__(foo)
    assert tracer.depth == 2

# Generated at 2022-06-22 18:18:43.827368
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:18:54.801564
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import os
    import inspect
    obj_pysnooper = pysnooper.snoop(normalize=True)
    assert(isinstance(obj_pysnooper, pysnooper.snooper.Tracer))
    # test output path
    assert(obj_pysnooper._write.__name__ == 'write_function_to_file')
    # test max_variable_length
    assert(obj_pysnooper.max_variable_length == 100)
    # test normalize
    assert(obj_pysnooper.normalize == True)
    # test target_codes
    def test_func():
        return
    obj_test_func = pysnooper.snoop()(test_func)

# Generated at 2022-06-22 18:18:58.552933
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[-1] == 'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[1000] == 'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:19:06.486629
# Unit test for function get_write_function
def test_get_write_function():
    def test_f(x, *, output=None, overwrite=False):
        write = get_write_function(output, overwrite)
        write('Some data')
        assert write.__name__ == 'write'

    test_f(output=None)
    test_f(output=sys.stderr)

    test_f(output=sys.stdout)
    test_f(output=sys.stderr)

    def output(s):
        print('output', repr(s))

    test_f(output=output)

    test_f(output=utils.WritableStream.create_from(sys.stdout))
    test_f(output=utils.WritableStream.create_from(sys.stderr))



# Generated at 2022-06-22 18:19:16.544099
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from os.path import join, dirname
    from . import fakes
    from . import debuggees

    help_me_debug_me_function = debuggees.HelpMeDebugMeFunction()

    _, source_lines_list = get_path_and_source_from_frame(
        debuggees.HelpMeDebugMeFunction.__code__.co_filename
    )

    assert source_lines_list == fakes.source_lines_list

    _, source_lines_list = get_path_and_source_from_frame(
        help_me_debug_me_function.__code__.co_filename
    )

    assert source_lines_list == fakes.source_lines_list


# Generated at 2022-06-22 18:19:26.588385
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pysnooper.snoop(watch_explode=("*",))
    pysnooper.snoop(watch=("*",))
    pysnooper.snoop(depth=2)
    pysnooper.snoop(prefix='')
    pysnooper.snoop(overwrite=False)
    pysnooper.snoop(thread_info=False)
    pysnooper.snoop(custom_repr=())
    pysnooper.snoop(max_variable_length=100)
    pysnooper.snoop(normalize=False)
    pysnooper.snoop(relative_time=False)


# Generated at 2022-06-22 18:19:27.836789
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-22 18:19:30.549697
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  node = Tracer()
  code = ''
  eval(code)
  node.set_live_node_visitor(LiveNodeVisitor())


# Generated at 2022-06-22 18:19:39.378735
# Unit test for method write of class Tracer
def test_Tracer_write():
    from pysnooper.testing import capture_stdout
    from pysnooper.snoop import Tracer
    import datetime as dt
    #test case_1
    with capture_stdout() as output:
        with Tracer(overwrite=True) as tr:
            tr.write("Hello-World")
    assert output.getvalue() == "\nHello-World\n"
    #test case_2
    with capture_stdout() as output:
        with Tracer(overwrite=True) as tr:
            tr.write("Hello-World")
    assert output.getvalue() == "Hello-World\n"
    #test case_3
    with capture_stdout() as output:
        with Tracer(overwrite=False) as tr:
            tr.write("Hello-World")

# Generated at 2022-06-22 18:19:44.682728
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with default args
    tracer = Tracer()
    
    # Test with optional args
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    


# Generated at 2022-06-22 18:19:55.757389
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    ''' Method write of class FileWriter should write to a file with correct encoding '''
    import tempfile
    import time

    with tempfile.TemporaryDirectory() as path:
        path = os.path.join(path, 'file.txt')
        fw = FileWriter(path, False)

        fw.write('abc')

        with open(path, 'rb') as file:  # unit test to see if encoding is utf-8
            content = file.read()

        assert content == b'abc'

        fw.write('示例')

        with open(path, 'rb') as file:  # unit test to see if encoding is utf-8
            content = file.read()

        assert content == b'abc\xe7\xa4\xba\xe4\xbe\x8b'



# Generated at 2022-06-22 18:20:05.299830
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=True, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    tracer.set_thread_info_padding('1234-main')
    assert tracer.thread_info_padding == 9
    tracer.set_thread_info_padding('1234-Thread')
    assert tracer.thread_info_padding == 12
    tracer.set_thread_info_padding('1234-main')
    assert tracer.thread_info_padding == 12
    tracer.set_thread_info_padding('')
    assert tracer.thread_info_padding == 12


# Generated at 2022-06-22 18:20:06.869951
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-22 18:20:16.645285
# Unit test for method write of class Tracer
def test_Tracer_write():
    p = re.compile("^\s*\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{6}"
        " \[\d+\]\s*\[\w+\]\s*{'enter': \d+, 'exit': \d+}$")
    class t1(object):
        def __init__(self, argv):
            self.argv = argv
            self.depth = 0
            self.write = self.__dict__['write']
            self.prefix = self.__dict__['prefix']
    t1 = t1(1)
    t2 = utils.Mock(t1)
    t3 = utils.Mock(t1)

# Generated at 2022-06-22 18:20:26.125092
# Unit test for constructor of class FileWriter
def test_FileWriter():
    content1 = '''
    This is a test of file 'test.txt'
    '''

    content2 = '''
    This is a test of file 'test.txt'
    This is a second test of file 'test.txt'
    '''
    path = 'test.txt'
    with open(path,'w') as output_file:
        output_file.write(content1)

    file_writer_obj = FileWriter(path, overwrite=False)
    file_writer_obj.write(content1)
    with open(path,'r') as output_file:
        assert output_file.read() == content2


# Generated at 2022-06-22 18:20:30.670296
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == 'SOURCE IS UNAVAILABLE'
    assert uas[1] == 'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:20:31.831072
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer():
        pass


# Generated at 2022-06-22 18:20:40.500606
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global DISABLED
    DISABLED = False
    # Case 1
    case = 1
    DISABLED = True
    assert Tracer().__call__(test_Tracer___call__)() is None
    # Case 2
    case = 2
    DISABLED = False
    assert Tracer().__call__(test_Tracer___call__)() is None

# Generated at 2022-06-22 18:20:43.519638
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
# Unit tests for class UnavailableSource



# Generated at 2022-06-22 18:20:48.511353
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[1] == u'SOURCE IS UNAVAILABLE'
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:20:53.519307
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()

    tracer.set_thread_info_padding('123')
    assert tracer.thread_info_padding == 3

    tracer.set_thread_info_padding('12345')
    assert tracer.thread_info_padding == 5

    tracer.set_thread_info_padding('12345')
    assert tracer.thread_info_padding == 5


# Generated at 2022-06-22 18:21:06.342306
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def test_function(a, b, c=None):
        x = a + b
        y = a - b
        return x, y
    my_dict = {'ppam': 'eggs', 'kuku': 1, 'baba': (1, 2, 3, 4)}
    my_set = set((1, 2, 3, 4))
    my_tuple = (1, 2, 3, 4, 5)
    my_list = [1, 2, 3, 4, 5]
    my_exploding_variable = Exploding(my_dict)

# Generated at 2022-06-22 18:21:09.659958
# Unit test for method write of class Tracer
def test_Tracer_write():
    obj = pysnooper.snoop()

    obj.write('Some output.')


# Generated at 2022-06-22 18:21:14.604961
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test for method __enter__ of class Tracer
    # test for case __enter__(self)
    global DISABLED
    if DISABLED:
        DISABLED = False
    print('DISABLED', DISABLED)
    tracer = Tracer()
    tracer.__enter__()

# Generated at 2022-06-22 18:21:27.166177
# Unit test for function get_write_function
def test_get_write_function():
    # setup
    import io
    import tempfile
    temp_fd, temp_path = tempfile.mkstemp()
    temp_file = os.fdopen(temp_fd, 'w')
    output_stream = io.StringIO()
    function_output = lambda s: print(s)
    write_path = lambda s: temp_file.write(s)
    def test(output, overwrite, expected):
        write = get_write_function(output, overwrite)
        write('testing')
        if isinstance(output, (pycompat.PathLike, str)):
            temp_file.close()
            with open(temp_path) as f:
                assert f.read() == expected
        else:
            assert output.getvalue() == expected

# Generated at 2022-06-22 18:21:37.992380
# Unit test for constructor of class Tracer
def test_Tracer():
    def dummy_write(s):
        pass

    t1 = Tracer()
    assert t1.prefix == '', t1.prefix
    assert t1.watch == [], t1.watch
    assert t1.depth == 1, t1.depth
    assert t1.write == dummy_write, t1.write
    assert t1.thread_info is False, t1.thread_info
    assert t1.thread_info_padding == 0, t1.thread_info_padding
    assert t1.custom_repr == (("\n", "\\n"),), t1.custom_repr
    assert t1.last_source_path is None, t1.last_source_path
    assert t1.max_variable_length == 100, t1.max_variable_length
    assert t1.normalize is False

# Generated at 2022-06-22 18:21:50.141265
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import io
    import pysnooper.utils
    # Input Parameters
    __self = Tracer(output=io.StringIO(), watch=(), watch_explode=(), depth=1,
                    prefix='', overwrite=False, thread_info=False, custom_repr=(),
                    max_variable_length=100, normalize=False, relative_time=False)
    __self.target_codes = set()
    __self.target_frames = set()
    __self.start_times = {}
    __klass = 'Tracer'
    __method = '__exit__'
    __self._write = pysnooper.utils.get_write_function(__self.output, __self.overwrite)


# Generated at 2022-06-22 18:22:02.323526
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    f = FileWriter('watcher_log_file.txt', overwrite=False)
    f.write('hi all...')
    f2 = open('watcher_log_file.txt', 'r')
    assert f2.read() == 'hi all...'
    # f.write('hi all again...')
    f2.close()
    f = FileWriter('watcher_log_file.txt', overwrite=False)
    f.write('hi all again...')
    f2 = open('watcher_log_file.txt', 'r')
    assert f2.read() == 'hi all...hi all again...'
    f2.close()
    f = FileWriter('watcher_log_file.txt', overwrite=True)
    f.write('hi all third...')

# Generated at 2022-06-22 18:22:04.647760
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    u = UnavailableSource()
    assert u[5] == u'SOURCE IS UNAVAILABLE'


already_errored = set()



# Generated at 2022-06-22 18:22:10.168499
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)

    with pytest.raises(NotImplementedError):
        tracer.set_thread_info_padding('')


# Generated at 2022-06-22 18:22:12.367139
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pytest_helper.set_trace_for_final_call()
## test_Tracer___call__()


# Generated at 2022-06-22 18:22:24.919070
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8') as temp_file:
        path = temp_file.name
        with open(path, 'w', encoding='utf-8') as file_:
            file_.write('hello\n')
        with open(path, 'r', encoding='utf-8') as file_:
            assert file_.read() == 'hello\n'
        file_writer = FileWriter(path, True)
        file_writer.write('hello')
        file_writer.write('again')
        with open(path, 'r', encoding='utf-8') as file_:
            assert file_.read() == 'helloagain'
        file_writer.write('\n')
        file_writer = FileWriter(path, False)
        file_writer.write

# Generated at 2022-06-22 18:22:33.805211
# Unit test for constructor of class FileWriter
def test_FileWriter():

    # 1. open file and append lines to it.
    _file_path = 'foo.txt'
    _file_content = ['a', '\n', 'b', '\n', 'c']
    _FileWriter = FileWriter(_file_path, False)
    for line in _file_content:
        if line == '\n':
            print('\n')
        else:
            print(line)
        _FileWriter.write(line)

    with open(_file_path, 'rb') as opened_file:
        _result = opened_file.read().splitlines()
    print(_result)
    assert _result == [
        'a'.encode('utf-8'),
        'b'.encode('utf-8'),
        'c'.encode('utf-8')
    ]