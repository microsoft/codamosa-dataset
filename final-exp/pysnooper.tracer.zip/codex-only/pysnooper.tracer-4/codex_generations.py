

# Generated at 2022-06-22 18:12:21.277414
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    with utils.redirect_stdout(StringIO()) as io:
        tracer.write('hello')
        assert io.getvalue() == 'hello\n'

# Generated at 2022-06-22 18:12:24.404531
# Unit test for function get_local_reprs
def test_get_local_reprs():
    x = 1
    result = get_local_reprs(inspect.currentframe())
    assert result == {'x': '1'}



# Generated at 2022-06-22 18:12:24.932220
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    UnavailableSource()[0]



# Generated at 2022-06-22 18:12:26.821256
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f(): pass
    frame = inspect.currentframe().f_back
    source0 = """# coding = utf-8
'''doc'''
asd = 1
""".split('\n')
    result = get_path_and_source_from_frame(frame)
    assert result == (__file__, source0)



# Generated at 2022-06-22 18:12:36.067768
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED

# Generated at 2022-06-22 18:12:37.172489
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[42], unicode)


# Generated at 2022-06-22 18:12:39.684144
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io.StringIO()
    tracer = Tracer(output, depth=2)
    tracer.write("foo")
    output.seek(0)
    assert "foo" == output.read().strip()


# Generated at 2022-06-22 18:12:44.952406
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs({'__name__': '__main__'}) == {'__name__': "'__main__'"}
    assert get_local_reprs({'__name__': '__main__', 'blah_blah_blah': 'hi'}) == \
                            {'__name__': "'__main__'", 'blah_blah_blah': "'hi'"}
    assert get_local_reprs({'__name__': '__main__', 'blah_blah_blah': 'hi'},
                           watch=(CommonVariable('__file__'), )) == \
                           {'__name__': "'__main__'", 'blah_blah_blah': "'hi'",
                            '__file__': repr(__file__)}



# Generated at 2022-06-22 18:12:50.457345
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .testing.temp_file import TempFile
    try:
        temp_file = TempFile()
        writer = FileWriter(temp_file.path, False)
        writer.write('abc')
        writer.write('def')
        assert utils.read_file(temp_file.path) == 'abcdef'
    finally:
        temp_file.close()



# Generated at 2022-06-22 18:12:52.914069
# Unit test for method write of class Tracer
def test_Tracer_write():
    Tracer.DISABLED = False
    tracer = Tracer()
    tracer.write("test")
    return True

# Unit tests for method trace of class Tracer

# Generated at 2022-06-22 18:13:05.781578
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(TypeError):
        Tracer(watch=1, watch_explode=2)
    with pytest.raises(TypeError):
        Tracer(watch=1, watch_explode=2)
    with pytest.raises(TypeError):
        Tracer(watch=(1, 2), watch_explode=3)
    with pytest.raises(TypeError):
        Tracer(watch=[1, 2], watch_explode=[3, 4])
    with pytest.raises(TypeError):
        Tracer(watch=[1, 2], watch_explode=[3, 4], depth='a')
    with pytest.raises(TypeError):
        Tracer(watch=[1, 2], watch_explode=[3, 4], depth='a', prefix=True)

# Generated at 2022-06-22 18:13:07.728622
# Unit test for constructor of class Tracer
def test_Tracer():
    fp = io.StringIO()
    t = Tracer(fp)
    t.write('Hello world')
    msg = u'Hello world\n'
    eq_(fp.getvalue(), msg)


# Generated at 2022-06-22 18:13:09.993118
# Unit test for method write of class Tracer
def test_Tracer_write():
    with io.StringIO() as f:
        tracer = Tracer(output=f)
        tracer.write('hello')
        tracer.write('world')

        assert f.getvalue() == 'hello\nworld\n'


# Generated at 2022-06-22 18:13:12.235704
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # __exit__ is tested indirectly during tests for __enter__
    pass

# Generated at 2022-06-22 18:13:22.790668
# Unit test for method write of class Tracer
def test_Tracer_write():
    # Check with normal parameter
    test_class = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    expected = u'{self.prefix}{s}\n'.format(self=test_class, s='s')
    actual = test_class._write(s='s')
    assert expected == actual
    # Check with empty parameter
    test_class = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)

# Generated at 2022-06-22 18:13:27.643407
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'a.txt'
    fw = FileWriter(path, False)
    assert fw.path == path
    assert fw.overwrite == False
    
    fw = FileWriter(path, True)
    assert fw.path == path
    assert fw.overwrite == True
    return


# Generated at 2022-06-22 18:13:29.797092
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_object = UnavailableSource()
    assert unavailable_object[123] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:38.877694
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[:] == u'SOURCE IS UNAVAILABLE'
    assert uas[1] == u'SOURCE IS UNAVAILABLE'
    assert uas[2:5] == u'SOURCE IS UNAVAILABLE'
    assert uas[-5:] == u'SOURCE IS UNAVAILABLE'
    assert uas[-5:5] == u'SOURCE IS UNAVAILABLE'
    assert uas[:] == u'SOURCE IS UNAVAILABLE'
    assert uas[1] == u'SOURCE IS UNAVAILABLE'
    assert uas[2:5] == u'SOURCE IS UNAVAILABLE'
    assert uas[-5:] == u'SOURCE IS UNAVAILABLE'
    assert uas[-5:5] == u

# Generated at 2022-06-22 18:13:46.854891
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    output = io.StringIO()
    kwargs = {
        'output': output,
        'thread_info': True,
    }
    tracer = Tracer(**kwargs)
    assert tracer.set_thread_info_padding('123') == '123   '
    assert tracer.set_thread_info_padding('12345') == '12345 '
    assert tracer.set_thread_info_padding('1234567890') == '1234567890'

# Generated at 2022-06-22 18:13:56.428567
# Unit test for function get_local_reprs
def test_get_local_reprs():
    blah = CommonVariable('blah')
    alice = CommonVariable('alice')
    dave = CommonVariable('dave')
    fred = CommonVariable('fred')
    assert get_local_reprs(inspect.stack()[0][0], watch=(blah,),
                           custom_repr={datetime_module.datetime:
                                        lambda obj: 'custom!'}) == \
           {'blah': "True", 'alice': '5', 'fred': 'custom!'}

# Generated at 2022-06-22 18:14:06.385320
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    """
    NOTE: We could use pytest for this kind of unit test but we are using this function to test the function itself.
    """
    tracer = Tracer()
    thread_ident = threading.current_thread().ident
    thread_name = threading.current_thread().getName()
    thread_info = "{ident}-{name} ".format(ident=thread_ident, name=thread_name)
    tracer.thread_info_padding = 0
    assert tracer.set_thread_info_padding(thread_info) == "14-MainThread"
    tracer.thread_info_padding = len(thread_info)
    assert tracer.set_thread_info_padding(thread_info) == "14-MainThread"
    tracer.thread_info_padding = len(thread_info) * 2

# Generated at 2022-06-22 18:14:10.028902
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter('test.py', True)
    file_writer.write('test')
    with open('test.py', 'r') as f:
        file_content = f.read()
        assert file_content == 'test'
    os.remove('test.py')



# Generated at 2022-06-22 18:14:21.625981
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import io

    tracer = Tracer(io.StringIO())

    class CustomException(Exception):
        pass

    def check(plain_func, with_snoop, exception_handler):
        with_snoop_output = io.StringIO()
        tracer = Tracer(with_snoop_output)
        try:
            with_snoop()
        except Exception as e:
            exception_handler(e)

        plain_func_output = io.StringIO()
        tracer = Tracer(plain_func_output)
        try:
            plain_func()
        except Exception as e:
            exception_handler(e)

        assert with_snoop_output.getvalue() == plain_func_output.getvalue()


# Generated at 2022-06-22 18:14:23.926364
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert hasattr(UnavailableSource(), '__getitem__')
test_UnavailableSource()



# Generated at 2022-06-22 18:14:25.802258
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:14:30.530556
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False,
                    custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)

    s = 'prefixs'
    expected = 'prefixs\n'
    real = tracer.write(s)
    assert real == expected


# Generated at 2022-06-22 18:14:34.019354
# Unit test for constructor of class FileWriter
def test_FileWriter():
    x = FileWriter('test_path', overwrite=True)
    assert x.write.__self__.path == 'test_path'
    assert x.write.__self__.overwrite == True



# Generated at 2022-06-22 18:14:37.715917
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pytest.raises(NotImplementedError, match='normalize is not supported with thread_info'):
        Tracer(normalize=True, thread_info=True)


# Generated at 2022-06-22 18:14:38.607044
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()


# Generated at 2022-06-22 18:14:45.496313
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    """
    Write the content `s` to file in `self.path`
    """
    with open('temp_write.txt', 'w', encoding='utf-8') as temp:
        temp.write('')
    fw = FileWriter('temp_write.txt', True)
    fw.write('abc')
    with open('temp_write.txt', 'r', encoding='utf-8') as temp:
        assert temp.read() == 'abc'
    fw.write('bcd')
    with open('temp_write.txt', 'r', encoding='utf-8') as temp:
        assert temp.read() == 'bcd'
    os.remove('temp_write.txt')



# Generated at 2022-06-22 18:14:56.432667
# Unit test for function get_write_function
def test_get_write_function():
    from . import testing_tools
    from .utils import WritableFile

    with testing_tools.StdoutStderrSwapper() as swapped:
        assert get_write_function(None, False) is swapped.stderr.write
        assert get_write_function(None, True) is swapped.stderr.write

        assert get_write_function(WritableFile(file=None), False) is None
        assert get_write_function(WritableFile(file=None), True) is None

        with testing_tools.UserFile(write_to_file=False) as user_file:
            assert get_write_function(WritableFile(file=user_file),
                                      False) is user_file
            assert get_write_function(WritableFile(file=user_file),
                                      True) is user_file


# Generated at 2022-06-22 18:15:02.791175
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from pysnooper.wrappers import Tracer
    tracer = Tracer()

    try:
        raise Exception("some exception")
    except Exception as exc:
        tracer.trace(None, 'exception', exc)

    tracer.write = lambda s:s
    tracer.__exit__(*sys.exc_info())
    assert tracer.thread_local.original_trace_functions == []


# Generated at 2022-06-22 18:15:12.042124
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def test_snoop_decorator(snoop_decorator):
        snoop_decorator()
    from pysnooper.tracing import Tracer
    from pysnooper import pysnooper
    from pysnooper.base_variable import CommonVariable, Exploding
    from pysnooper.utils import get_write_function
    from pysnooper import utils
    from pysnooper import pycompat

    assert snoop_decorator() == None
    assert snoop_decorator() == None
    assert snoop_decorator() == None


# Generated at 2022-06-22 18:15:15.763015
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:15:24.808454
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    import sys
    # capture output to stdout
    oldstdout = sys.stdout
    newstdout = io.StringIO()
    sys.stdout = newstdout
    # test for method write of class Tracer
    # test for method write of class Tracer without parameter s
    try:
        t = Tracer()
        t.write()
        assert False
    except TypeError as e:
        assert True
    # test for method write of class Tracer with normal s
    try:
        t = Tracer()
        t.write("hello")
        assert True
    except TypeError as e:
        assert False
    # test for method write of class Tracer with normal s and prefix

# Generated at 2022-06-22 18:15:30.843836
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    os.path.isfile = MagicMock(return_value=True)
    with patch('builtins.open', mock_open(read_data='toto')) as mock_file:
        result = Tracer()._Tracer__exit__()
        assert result == None
        assert mock_file.called
        assert os.path.isfile.called

# Generated at 2022-06-22 18:15:40.280260
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import threading
    import time
    import unittest
    import os
    import tempfile
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import ANY

    # Mocking methods
    def mock_get_write_function(output, overwrite):
        return ANY

    def mock_get_path_and_source_from_frame(frame):
        return ANY

    def mock_get_local_reprs(frame, watch, custom_repr, max_length,
                             normalize):
        return {}

    # Patching
    pysnooper._get_write_function = mock_get_write_function
    pysnooper._utils.get_path_and_source_from_frame = mock_get_path_and

# Generated at 2022-06-22 18:15:49.744244
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import io
    import sys

    # Test for a normal case
    # Test for a normal case
    with io.StringIO() as out:
        with pysnooper.snoop(output=out, watch='hello'):
            hello = 'foo'

    # Test for the case where we're not doing anything because thread_local.depth
    # is not 0
    thread_local.depth = 1
    out = io.StringIO()
    with pysnooper.snoop(output=out, watch='hello'):
        hello = 'foo'
    thread_local.depth = 0

    # Test for the case where we're not doing anything because
    # self.depth is 1 and the calling function is internal
    out = io.StringIO()

# Generated at 2022-06-22 18:16:02.795283
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    nt.assert_equal(tracer_0.watch, [])
    nt.assert_equal(tracer_0.frame_to_local_reprs, {})
    nt.assert_equal(tracer_0.target_codes, set())
    nt.assert_equal(tracer_0.target_frames, set())
    nt.assert_equal(tracer_0.thread_local.__dict__['original_trace_functions'], [])

    tracer_1 = Tracer(watch='let_me_see')
    nt.assert_equal(tracer_1.watch, [CommonVariable('let_me_see')])

    tracer_2 = Tracer(depth=2)

# Generated at 2022-06-22 18:16:04.360836
# Unit test for function get_path_and_source_from_frame

# Generated at 2022-06-22 18:16:05.923889
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    u = UnavailableSource()[0]
    assert u == u'SOURCE IS UNAVAILABLE'




# Generated at 2022-06-22 18:16:18.556435
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .test_utils import create_fake_python_file
    import tempfile
    import os

    def foo():
        a = 1
        b = 2
        c = 1 + 3
        return (a, b, c)

    try:
        source, path = get_path_and_source_from_frame(foo.__code__.co_filename,
                                                      foo.__code__.co_name)
        assert False, '`foo` ran on test machine, should have failed'
    except Exception:
        pass

    with tempfile.NamedTemporaryFile(delete=False) as temp_file:
        temp_file_name = temp_file.name

# Generated at 2022-06-22 18:16:25.489953
# Unit test for function get_write_function
def test_get_write_function():
    assert callable(get_write_function(None, False))
    assert get_write_function('C:\\', False) is FileWriter
    assert get_write_function(open('C:\\', 'w'), False) is open
    assert callable(get_write_function(print, False))
    assert get_write_function(open('C:\\', 'w'), True) is FileWriter



# Generated at 2022-06-22 18:16:28.700390
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    def some_function():
        with pysnooper.snoop() as s:
            return 1
    with pytest.raises(KeyError):
        some_function()



# Generated at 2022-06-22 18:16:37.552870
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .variables import BaseVariable
    class MockVariable(BaseVariable):
        def get_value(self, frame):
            return 'mock_value'
        def items(self, frame, normalize=False):
            yield self.name, 'mock_value'
    def test():
        a, b = MockVariable('a'), MockVariable('b')
        c = 'c'
        d = 'd'
        get_local_reprs(sys._getframe(), watch=(a, b), custom_repr={str: lambda x: 'string'})
        return locals()
    result = get_local_reprs(test(), custom_repr={str: lambda x: 'string'})

# Generated at 2022-06-22 18:16:43.573948
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        file_path = os.path.join(temp_dir, 'my_output_file.txt')
        file_writer = FileWriter(file_path, overwrite=True)
        s = 'my text'
        file_writer.write(s)
        with open(file_path, 'r') as f:
            assert f.read() == s
        file_writer.write('asdf')
        with open(file_path, 'r') as f:
            assert f.read() == s + 'asdf'



# Generated at 2022-06-22 18:16:55.242112
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # Test with a string path
    file_writer = FileWriter('sample.txt', False)
    assert(file_writer.path == 'sample.txt')
    assert(file_writer.overwrite == False)
    # Test without overwrite
    file_writer.write('test')
    with open('sample.txt', 'r', encoding='utf-8') as input_file:
        assert(input_file.read() == 'test')
    file_writer.write('test2')
    with open('sample.txt', 'r', encoding='utf-8') as input_file:
        assert(input_file.read() == 'testtest2')
    os.remove('sample.txt')
    # Test with overwrite
    file_writer.overwrite = True
    file_writer.write('test')

# Generated at 2022-06-22 18:16:57.158598
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    u = UnavailableSource()
    assert u[0] == 'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-22 18:16:58.502370
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    memoryview(UnavailableSource()[1:1])



# Generated at 2022-06-22 18:17:04.493737
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False)('foo') == None
    write = get_write_function(None, True)
    assert write('foo') == None
    assert write(1) == None
    with pytest.raises(Exception):
        get_write_function(None, True)
test_get_write_function._test_name = 'get_write_function'



# Generated at 2022-06-22 18:17:10.320070
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import __file__
    from .utils import get_current_frame
    frame = get_current_frame()
    path_and_source = get_path_and_source_from_frame(frame)
    assert path_and_source[0] == __file__


# Generated at 2022-06-22 18:17:15.371325
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Tests for various values of `self.depth`

    # Tests for `self.frame_to_local_reprs`, `self.start_times`
    # and `self.target_frames`

    # Tests for `self.thread_local`

    pass


# Generated at 2022-06-22 18:17:20.958936
# Unit test for method write of class Tracer
def test_Tracer_write():

    mock_write = mock.Mock()
    tracer = Tracer(mock_write)
    tracer.write('test')

    mock_write.assert_called_once_with('test')

# Generated at 2022-06-22 18:17:28.434616
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[2] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[10] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-2] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[1:2] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[20::10] == 'SOURCE IS UNAVAILABLE'

test_UnavailableSource()



# Generated at 2022-06-22 18:17:37.082822
# Unit test for function get_write_function
def test_get_write_function():
    import os
    import tempfile

# Generated at 2022-06-22 18:17:43.495416
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    s = "var_repr, max_length=None, custom_repr=()"
    value, max_length, custom_repr = s.split(",")
    value = value.split("=")[1]
    max_length = max_length.split("=")[1]
    custom_repr = custom_repr.split("=")[1]
    return value, max_length, custom_repr


# Unit tests for the file

# Generated at 2022-06-22 18:17:47.346444
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == uas[1] == uas[-1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:48.606608
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-22 18:17:59.017682
# Unit test for constructor of class FileWriter
def test_FileWriter():
    test_string = 'test string'

    file_path_overwrite = pycompat.os_path.join(pycompat.os_path.dirname(__file__), 'test_file_writer_overwrite')

    file_path_append = pycompat.os_path.join(pycompat.os_path.dirname(__file__), 'test_file_writer_append')

    file_writer_overwrite = FileWriter(file_path_overwrite, True)
    file_writer_append = FileWriter(file_path_append, False)

    file_writer_overwrite.write(test_string)

    with open(file_path_overwrite, 'r') as file:
        assert file.read() == test_string

    file_writer_overwrite.write(test_string)


# Generated at 2022-06-22 18:18:09.116642
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from . import variables
    from . import debuggee
    code = compile('def f():\n    a = 1\n    b = 2\n    c = 3',
                   '<fake_filename>', 'exec')
    code = code.co_consts[0]


    variable_a = variables.Variable('a')
    variable_b = variables.Variable('b')
    variable_c = variables.Variable('c')
    variable_d = variables.Variable('d')

    def custom_repr(obj):
        if obj == 2:
            return '<two>'

    def custom_repr2(obj):
        if isinstance(obj, debuggee.Debuggee):
            return '<debuggee>'

    frame = inspect.currentframe()
    frame = frame.f_back.f_back # we want to

# Generated at 2022-06-22 18:18:20.622044
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert source is not None
    lines = source[frame.f_lineno - 2:frame.f_lineno + 2]
    assert len(lines) == 5
    assert lines[2].startswith('    def test_get_path_and_source_from_frame():')
    assert lines[3].startswith('        frame = inspect.currentframe()')
    assert lines[4].startswith('        path, source = get_path_and_source_from_frame(frame)')
    assert lines[3].endswith(' = inspect.currentframe()')
test_get_path_and_source_from_frame()



# Generated at 2022-06-22 18:18:29.345669
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test_case(output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr, max_variable_length, normalize, relative_time, frame, event, arg, expected):
        # Write your code here to make the test pass
        #print('frame:', frame)
        #print('event:', event)
        #print('arg:', arg)
        #print('expected:', expected)
        tracer = Tracer(output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr, max_variable_length, normalize, relative_time)
        actual = tracer.trace(frame, event, arg)
        assert actual == expected
        #print('actual:', actual)
        #print('#####################################################################')


# Generated at 2022-06-22 18:18:40.686066
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # If a FileOutput object is passed to Tracer, it writes its output to the
    # file.
    with tempfile.TemporaryDirectory() as base_dir:
        file_path = os.path.join(base_dir, 'foo.log')
        output = FileOutput(file_path)
        tracer = Tracer(output=output)
        with tracer:
            pass
        with open(file_path) as f:
            actual = f.read()

# Generated at 2022-06-22 18:18:53.206531
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    from . import utils

    with utils.temp_folder() as temp_folder:
        path_1 = os.path.join(temp_folder, 'test_1.py')
        with open(path_1, 'wb') as f:
            f.write(
                b'first line\n'
                b'#coding: utf-8\n'
                b'second line\n'
                b'third line\n'
            )
        path_2 = os.path.join(temp_folder, 'test_2.py')
        with open(path_2, 'wb') as f:
            f.write(
                b'first line\n'
                # No coding
                b'second line\n'
                b'\xffthird line\n'
            )



# Generated at 2022-06-22 18:18:55.414562
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:19:05.039194
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    from types import FrameType
    from types import TracebackType
    from types import CodeType
    from pprint import pprint
    class TestTracer_trace(unittest.TestCase):
        """
        Test class for method `trace` of class `Tracer`.
        """
        def test_with_self(self):
            """
            Test the method `trace` of class `Tracer` with a instance as `self`.
            """
            # Create a `Tracer` instane as `self`.
            watch = ('foo',)
            self = Tracer(watch=watch)
            # Create a `FrameType` instance.
            co_filename = 'test_snooper.py'
            co_firstlineno = 33
            co_name = 'test'

# Generated at 2022-06-22 18:19:14.525481
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    get_write_function = utils.get_write_function
    import inspect
    import functools
    import datetime
    import threading
    # testcase 1: correct testcase for set_thread_info_padding
    snooper = Tracer(_watch=())
    snooper.set_thread_info_padding(" ")
    assert snooper.thread_info_padding == 2

    # testcase 2: incorrect testcase for set_thread_info_padding
    snooper = Tracer(_watch=())
    snooper.set_thread_info_padding(" ")
    assert snooper.thread_info_padding == 2


# Generated at 2022-06-22 18:19:17.765096
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    fw = FileWriter(tf.name, True)
    fw.write('hi')
    print(open(tf.name, 'r').read())
    tf.close()




# Generated at 2022-06-22 18:19:21.844506
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_name = "test_FileWriter.txt"
    if os.path.exists(file_name):
        try:
            os.remove(file_name)
        except PermissionError:
            pass
    assert not os.path.exists(file_name)
    file_writer = FileWriter(file_name, overwrite=True)
    assert not os.path.exists(file_name)
    file_writer.write('hello!')
    assert os.path.exists(file_name)
    with open(file_name, encoding='utf-8') as f:
        assert f.read() == 'hello!'
    os.remove(file_name)



# Generated at 2022-06-22 18:19:25.338560
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(NotImplementedError):
        Tracer(thread_info=True, normalize=True)


# Generated at 2022-06-22 18:19:35.673773
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with pytest.raises(Exception) as exception_info:
        raise Exception
    expected_exception = exception_info.value
    assert expected_exception
    def test_function():
        pass
    snoop = Tracer(prefix="", custom_repr=[])
    exception_info = None
    try:
        with snoop:
            raise expected_exception
    except Exception as exception_info:
        pass
    actual_exception = exception_info
    assert actual_exception == expected_exception

    with pytest.raises(Exception) as exception_info:
        raise Exception
    expected_exception = exception_info.value
    assert expected_exception
    def test_function():
        pass
    snoop = Tracer(prefix="", custom_repr=[])
    exception_info = None

# Generated at 2022-06-22 18:19:42.256735
# Unit test for function get_write_function
def test_get_write_function():
    # noinspection PyUnresolvedReferences
    '''
    >>> class FileLikeObject:
    ...     def __init__(self):
    ...         self.content = ''
    ...     def write(self, s):
    ...         self.content += s
    ...     def read(self):
    ...         return self.content
    >>> f = FileLikeObject()
    >>> write = get_write_function(f)
    >>> write('123')
    >>> write('456')
    >>> f.read()
    '123456'

    >>> write = get_write_function(None)
    >>> write('123')
    123
    '''



# Generated at 2022-06-22 18:19:50.346682
# Unit test for constructor of class Tracer
def test_Tracer():
    def _test_write(s):
        _test_write.result.append(s)
    _test_write.result = []

    watch_var = CommonVariable('watch_var')
    watch_var.value = 7
    watch_list = CommonVariable('watch_list')
    watch_list.value = [1, 2]
    watch_dict = CommonVariable('watch_dict')
    watch_dict.value = {'a': 'b'}
    watch_explode = Exploding('watch_explode')
    watch_explode.value = {'a': 'b'}

    write = _test_write
    watch = [watch_var, watch_list, watch_dict]
    watch_explode = [watch_explode]
    depth = 2
    prefix = 'ZZZ '
    overwrite = False
   

# Generated at 2022-06-22 18:19:54.669937
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'
    assert uas[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:01.807078
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tester = Tracer(
        output=None,
        watch=(),
        watch_explode=(),
        depth=1,
        prefix='',
        overwrite=False,
        thread_info=False,
        custom_repr=(),
        max_variable_length=100,
        normalize=False,
        relative_time=False,
    )
    tester.__enter__()
    assert thread_global.depth == -1
    assert tester.frame_to_local_reprs == {}
    assert tester.start_times == {}



# Generated at 2022-06-22 18:20:06.688603
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = '/tmp/FileWriterTest.txt'
    s = 'output string'
    fwriter = FileWriter(path, overwrite=True)
    fwriter.write(s)
    with open(path, 'r') as fp:
        assert fp.read() == s
    fwriter.write(s)
    with open(path, 'r') as fp:
        assert fp.read() == s * 2




# Generated at 2022-06-22 18:20:16.586755
# Unit test for constructor of class Tracer
def test_Tracer():
    s = StringIO()
    # Test default values
    tracer = Tracer(output=s)
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_info_padding == 0
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False
    assert tracer.relative_time == False
    # Test setting to other values

# Generated at 2022-06-22 18:20:22.131531
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function_under_test():
        frame = inspect.currentframe()
        return get_path_and_source_from_frame(frame)

    filename, source = function_under_test()
    assert source[1] == '    filename, source = function_under_test()'



# Generated at 2022-06-22 18:20:34.696160
# Unit test for method trace of class Tracer

# Generated at 2022-06-22 18:20:39.012047
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print(pysnooper.snoop())

###########################################################################
### Unit tests for PySnooper: #############################################
#                                                                         #

# Generated at 2022-06-22 18:20:48.202386
# Unit test for constructor of class FileWriter
def test_FileWriter():
    def test_writer(writer, text):
        writer.write(text)
        with open(writer.path, 'r') as output_file:
            assert output_file.read() == text
    writer = FileWriter(os.path.join(os.getcwd(), 'test.txt'), overwrite = True)
    test_writer(writer, 'Hello\n')
    test_writer(writer, 'World\n')
    writer = FileWriter(os.path.join(os.getcwd(), 'test.txt'), overwrite = False)
    test_writer(writer, 'Hello\n')
    test_writer(writer, 'World\n')
    writer = FileWriter(os.path.join(os.getcwd(), 'test.txt'), overwrite = True)
    test_writer(writer, 'Hello\n')
    test_

# Generated at 2022-06-22 18:20:51.760351
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'some/non/existing/path'
    fw = FileWriter(path, True)
    assert fw.path == path
    assert fw.overwrite == True


# Generated at 2022-06-22 18:20:56.834180
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile

    def f():
        pass
    assert callable(f)
    assert isinstance(f, collections.Callable)


timestamp_template = '<div style="background-color: #eee; ' \
                     'border-radius: 3px; padding: 5px 10px;">' \
                     '%s</div>'



# Generated at 2022-06-22 18:21:01.457925
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(TypeError) as exc_info:
        Tracer(0)
    assert exc_info.value.args[0] == (
        'output must be a file, a string or None, not "int"'
    )

# Generated at 2022-06-22 18:21:02.934297
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Call Tracer.__exit__(...)
    pass



# Generated at 2022-06-22 18:21:09.440355
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Simple values
    assert Tracer().trace(frame=None, event="", arg=None)
    assert Tracer().trace(frame=None, event="", arg=1)
    assert Tracer().trace(frame=None, event="", arg=0)
    assert Tracer().trace(frame=None, event="", arg=())
    assert Tracer().trace(frame=None, event="", arg=[])
    assert Tracer().trace(frame=None, event="", arg={})
    assert Tracer().trace(frame=None, event="", arg="")
    assert Tracer().trace(frame=None, event="", arg=object)


# Generated at 2022-06-22 18:21:15.697262
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import doctest
    #import sys; sys.path.append('../../')
    from garlicsim.general_misc.cute_testing import frame_like
    doctest.DocTestSuite(get_local_reprs, checker=frame_like)



# Generated at 2022-06-22 18:21:28.421991
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys

    class DummyFile:

        def __init__(self):
            self.contents = ''

        def write(self, string):
            self.contents += string

        def getvalue(self):
            return self.contents

    def foo1():
        foo2()

    def foo2():
        foo3()

    def foo3():
        pass

    output = DummyFile()
    # Without thread info
    with Tracer(output=output):
        foo1()

# Generated at 2022-06-22 18:21:29.942030
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass # TODO

# Generated at 2022-06-22 18:21:34.741944
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    obj = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    obj.__enter__()

 
    # Check type of argument
    assert isinstance(obj, Tracer)
    # Check if __enter__ raises errors
    assert not utils.run_raises(obj.__enter__)
    # Check __enter__'s returned value type
    assert isinstance(obj.__enter__(), types.TraceType)



# Generated at 2022-06-22 18:21:43.106935
# Unit test for function get_write_function
def test_get_write_function():
    # Let's make sure it writes the right thing to right places
    write_stderr = get_write_function(None, False)
    write_stderr('What is this?')
    assert 'What is this?' in utils.get_std_output(sys.stderr)
    if sys.version_info >= (3, 3):
        os.remove('cute_stderr')
    else:
        # We're too dumb to know how to change the default stderr stream, so let's
        # just patch the `assert` statement to not cause an exception.
        def patched_assert(condition, *args, **kwargs):
            pass
        assert patched_assert(*(1 == 1), 'assert does not work')
    assert utils.get_std_output(sys.stderr) == ''

    write_

# Generated at 2022-06-22 18:21:52.863105
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from . import utils

    # encoidng 'utf-8' can be used but is not required.
    test_encoding = ['utf-8', 'utf-8-sig', 'utf-16', 'utf-32', 'cp1252',
                     'latin-1', 'ascii', 'gbk', 'gb18030']
    for enc in test_encoding:
        try:
            fw = FileWriter('test.txt', True)
            fw_out = fw.write('abcd\n')
            with open('test.txt', mode='r', encoding=enc) as f:
                text = f.read()
                assert text == 'abcd\n'
        except AssertionError:
            continue
        else:
            os.remove('test.txt')
            return
    raise Ass

# Generated at 2022-06-22 18:21:56.146299
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    func_address = -1326290968
    method_of_class_object = -1326290968
    #self.start_times
    pass

# Generated at 2022-06-22 18:22:00.843536
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import builtins
    builtins.__dict__['_pysnooper_test_'] = True
    import __main__
    __main__.__dict__.pop('_pysnooper_test_', None)
    import sys


# Generated at 2022-06-22 18:22:03.037710
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write('test_Tracer_write')

 

# Generated at 2022-06-22 18:22:11.342753
# Unit test for function get_local_reprs
def test_get_local_reprs():
    x = 27
    y = 'hello'
    z = [2, 3, 4]
    a = {5, 6, 7}
    b = {3: 'hello', 4: 22}
    c = 100

    def get_everything():
        return x, y, z, a, b, c

    def get_external_local_variable():
        return x

    def get_external_global_variable():
        return c

    def get_external_global_variable2():
        return c

    def get_external_local_variable2():
        return x

    frame = get_everything.__code__.__closure__[0].cell_contents.f_back

# Generated at 2022-06-22 18:22:23.406781
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import sys
    import re
    import datetime as datetime_module
    import itertools
    import utils
    from . import pycompat

    # regular string
    frame = call_on_frame(lambda: 5)
    assert get_local_reprs(frame) == collections.OrderedDict(x='5')

    # with custom repr
    frame = call_on_frame(lambda: datetime_module.datetime.now())
    assert get_local_reprs(frame, custom_repr={
        datetime_module.datetime: lambda x: 'today',
    }) == collections.OrderedDict(x='today')

    # with shortening
    frame = call_on_frame(lambda: range(100))