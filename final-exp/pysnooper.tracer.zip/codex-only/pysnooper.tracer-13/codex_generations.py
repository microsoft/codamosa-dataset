

# Generated at 2022-06-22 18:12:29.636580
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'
    assert uas[100] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:12:31.437029
# Unit test for method write of class Tracer
def test_Tracer_write():
    test_string = "Test string"
    output = "output.txt"
    s = Tracer(output)
    s.write(test_string)
    assert open(output, "r").read().strip() == test_string
    os.remove(output)


# Generated at 2022-06-22 18:12:39.451983
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func():
        x = 3
        y = [1, 2, 3]
        z = {'a': 7}
        a = {'b': {'c': 'd'}}
        b = ('a', ('b', ('c', 'd')))
        c = [{'a': {'b': 'c'}}]
        d = {'a': [{'b': 'c'}]}
        e = {'a': 'b'}
        f = [{'a': 'b'}]
        g = [1, 2]
        h = 'x' * 1000
        i = 'tooshort'

    func()

    frame = sys._getframe()

# Generated at 2022-06-22 18:12:47.718425
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    thread_info = ""
    assert tracer.set_thread_info_padding(thread_info) == thread_info
    thread_info = "123-Thread-1 "
    assert tracer.set_thread_info_padding(thread_info) == thread_info
    thread_info = "12345-Thread-1 "
    assert tracer.set_thread_info_padding(thread_info) == thread_info
    thread_info = "1234-Thread-1 "
    assert tracer.set_thread_info_padding(thread_info) == thread_info
    thread_info = "12345-Thread-1 "
    assert tracer.set_thread_info_padding(thread_info) == "12345-Thread-1 "

# Generated at 2022-06-22 18:12:49.886641
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[15] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-22 18:13:01.217525
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from .utils import CallingObject
    from pysnooper import snoop
    from .dummy_io import DummyIO
    import re
    import threading
    # no exception
    with snoop(output=DummyIO()) as dummy_io:
        with snoop():
            with snoop():
                pass
    assert re.search("Elapsed time: \d+\s*Elapsed time: \d+", dummy_io.output)
    assert dummy_io.output.count("Elapsed time: ") == 2
    dummy_io.clear()
    # no exception
    with snoop(output=DummyIO()) as dummy_io:
        with snoop(relative_time=True):
            with snoop(relative_time=True):
                pass

# Generated at 2022-06-22 18:13:02.740577
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:12.550943
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile

    path = tempfile.gettempdir()
    file_name = '_test.log'
    content = 'hello'
    FileWriter(path + '\\' + file_name, True).write(content)
    assert content in open(path + '\\' + file_name, encoding='utf-8').read()
    FileWriter(path + '\\' + file_name, False).write(content)
    assert content * 2 in open(path + '\\' + file_name, encoding='utf-8').read()
    FileWriter(path + '\\' + file_name, True).write(content)
    assert content in open(path + '\\' + file_name, encoding='utf-8').read()



# Generated at 2022-06-22 18:13:13.473490
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Tracer.__enter__() implementation
    raise SkipTest # implemented in Python

# Generated at 2022-06-22 18:13:15.892684
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer.__enter__()
    # assert some results here
    assert True # TODO: implement your test here


# Generated at 2022-06-22 18:13:24.806654
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    '''
    >>> with open('_trace.out', 'w') as f:
    ...     tracer = Tracer(output=f, watch=('a', 'self'))
    ...     with tracer:
    ...         a = 10
    >>> with open('_trace.out') as f:
    ...     lines = list(f)
    >>> assert lines == ["    Starting var:.. a = 10\\n",
    ...                  "    New var:....... self = <__main__.Test object at 0x7fbc50ce0f60>\\n"]
    >>> os.remove('_trace.out')
    '''
    class Test(object):
        def __init__(self, a):
            self.a = a


# Generated at 2022-06-22 18:13:27.742081
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:13:32.751671
# Unit test for method write of class Tracer
def test_Tracer_write():
    output_path = "test_Tracer_write.txt"
    t = Tracer(output=output_path,depth=1)
    t.write("test")
    t.write("test2")
    with open(output_path) as f:
        assert f.read() == "test\ntest2\n"

# Generated at 2022-06-22 18:13:40.326084
# Unit test for function get_write_function
def test_get_write_function():
    import io
    my_string = 'yay'
    write = get_write_function(None, False)
    assert write(my_string) is None
    my_stream = io.StringIO()
    write = get_write_function(my_stream, False)
    assert write(my_string) is None
    assert my_stream.getvalue() == my_string
    write = get_write_function(lambda x: None, False)
    assert write(my_string) is None
    assert my_stream.getvalue() == my_string
    my_file = 'my_file.txt'
    write = get_write_function(my_file, True)
    assert my_file not in os.listdir('.')
    write(my_string)
    assert my_file in os.listdir('.')


# Generated at 2022-06-22 18:13:51.616014
# Unit test for function get_write_function
def test_get_write_function():
    from . import testing
    from . import shared_modules
    from .pycompat import StringIO

    with testing.TestCase(shared_modules.sys) as test_case:
        with test_case.assertRaises(Exception) as cm:
            get_write_function(None, overwrite=True)
        assert str(cm.exception) == ('`overwrite=True` can only be used when '
                                     'writing content to file.')
        test_case.testing.assert_true(callable(get_write_function(None)))
        test_case.testing.assert_true(callable(get_write_function(sys.stderr)))
        test_case.testing.assert_true(callable(get_write_function(StringIO())))



# Generated at 2022-06-22 18:13:56.371835
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False)
    assert get_write_function('foo', False)
    assert get_write_function(sys.stderr, False)
    assert get_write_function(sys.stderr.write, False)
    assert get_write_function(False, False) is None
    assert get_write_function(lambda: True, False)



# Generated at 2022-06-22 18:14:02.954162
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f(): return # This is a test 3
        # This is a test 2
        # This is a test 1
    frame = sys._getframe()
    frame = frame.f_back
    (_, source) = get_path_and_source_from_frame(frame)
    assert source == [
        u'def f(): return # This is a test 3',
        u'    # This is a test 2',
        u'    # This is a test 1',
    ]



# Generated at 2022-06-22 18:14:12.719832
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .test_utils import MagicMock, call
    import sys
    import types

    def fake_get_source(name):
        return 'This is %s' % name

    fake_loader = MagicMock(spec=types.ModuleType)
    fake_loader.get_source.side_effect = fake_get_source

    def fake_frame(name, globals):
        return types.FrameType(globals, {}, name, '', 0, '', None, None, None)

    def fake_module(name, loader=None):
        globals = locals = {}
        if loader is None:
            loader = MagicMock(spec=types.ModuleType)
            loader.get_source.side_effect = ImportError
        import imp
        imp.init_builtin(name) # To set up `sys` object


# Generated at 2022-06-22 18:14:16.125481
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    def test():
        with Tracer():
            pass
    assert sys.gettrace() is None
    test()
    assert sys.gettrace() is None



# Generated at 2022-06-22 18:14:27.445142
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = utils.random_string()
    s = utils.random_string()
    try:
        os.remove(path)
    except OSError:
        pass
    file_writer = FileWriter(path, False)
    assert not os.path.exists(path)
    file_writer.write(s)
    assert os.path.exists(path)
    with open(path) as f:
        assert f.read() == s
    #
    file_writer = FileWriter(path, True)
    with open(path) as f:
        content_before = f.read()
    file_writer.write(s)
    with open(path) as f:
        content_after = f.read()
    assert content_before != content_after
    assert content_after == s
    #


# Generated at 2022-06-22 18:14:28.445393
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()


# Generated at 2022-06-22 18:14:40.141493
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    import functools
    import types

    def assert_source_and_path(py_file_path, func, expected_source,
                               expected_path):
        frame = func.__code__.co_filename = py_file_path
        source_and_path = get_path_and_source_from_frame(func.__code__)
        assert source_and_path == (expected_path, expected_source)

    with tempfile.NamedTemporaryFile(suffix='.py') as py_file:
        py_file.write(b'coding = "gbk"\n')

# Generated at 2022-06-22 18:14:47.023220
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # reqs:
    #    1. it should output 'Elapsed time ...' in snoop file
    #    2. it should set back sys.settrace(None) if there is nothing to snoop
    #    3. it should set back original trace function if original trace function exists
    #    4. it should do nothing if there is nothing to snoop
    #    5. it should set back sys.settrace(original_trace_function) if original_trace_function exists
    #    6. it should set back original trace function if there is no original trace function
    #    7. it should set back sys.settrace(None) if there is no original trace function

    import sys, pip._vendor.six, threading
    filename = "snoop.out"
    test_string = "test string"

# Generated at 2022-06-22 18:14:48.379960
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-22 18:14:54.678539
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    obj_list=[
        {
            'event': 'call',
            'frame': inspect.currentframe(),
            'arg': None
        },
        {
            'event': 'call',
            'frame': inspect.currentframe(),
            'arg': None
        },
        {
            'event': 'return',
            'frame': inspect.currentframe(),
            'arg': None
        }
    ]
    for item in obj_list:
        pass




# Generated at 2022-06-22 18:15:02.639584
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile, os
    with tempfile.TemporaryDirectory() as temp_dir:
        my_file = os.path.join(temp_dir, 'my_file')
        file_writer = FileWriter(my_file, overwrite=True)

        file_writer.write('Hello')
        with open(my_file, 'r') as f:
            assert f.read() == 'Hello'

        file_writer.write(' world')
        with open(my_file, 'r') as f:
            assert f.read() == 'Hello world'



# Generated at 2022-06-22 18:15:13.598797
# Unit test for function get_write_function
def test_get_write_function():
    def some_write(s):
        pass
    class Stream(object):
        def write(self, s):
            pass
    get_write_function(some_write, False)
    get_write_function(Stream(), False)
    get_write_function(sys.stdout, False)
    get_write_function(sys.stderr, False)
    get_write_function(None, False)
    get_write_function(utils.WritableStream(), False)
    get_write_function(utils.BytesStream(), False)
    with pycompat.temp_test_file(suffix='.txt') as f:
        get_write_function(f.name, False)
        get_write_function(f.name, True)
        f.write(b'x' * 65000)
        f.flush

# Generated at 2022-06-22 18:15:21.058604
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import tempfile
    d = tempfile.TemporaryDirectory()
    file_writer = FileWriter(os.path.join(d.name, 'test.txt'), True)
    file_writer.write('spam')
    file_writer.write('eggs')
    with open(os.path.join(d.name, 'test.txt'), 'r') as file:
        assert file.read() == 'spameggs'
    d.cleanup()


# Generated at 2022-06-22 18:15:28.255372
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from .utils import setup_redirect
    from .utils import setup_redirect_two
    from .utils import teardown_redirect
    from .utils import teardown_redirect_two
    from .utils import redirect_stdout
    from .utils import redirect_stderr
    from .utils import TestCase
    from .utils import RedirectStdoutTo
    from .utils import RedirectStderrTo
    from .utils import redirect_stdout_fd
    import io
    import os
    import sys
    import mock
    import pycompat
    import threading
    import datetime
    if pycompat.PY2:
        import __builtin__ as builtins
    else:
        import builtins
    class Test_Tracer___enter__(TestCase):
        def setUp(self):
            self

# Generated at 2022-06-22 18:15:35.908914
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from . import test_utils
    tempfile_path = pycompat.text_type(test_utils.make_temp_file())
    for overwrite in (True, False):
        file_writer = FileWriter(tempfile_path, overwrite)
        for s in [u'hello', u'world']:
            file_writer.write(s)

        with open(tempfile_path, 'r', encoding='utf-8') as f:
            assert f.read() == u'helloworld' if overwrite else u'hello'



# Generated at 2022-06-22 18:15:38.751727
# Unit test for constructor of class FileWriter
def test_FileWriter():
    fw = FileWriter('a.txt', True)
    fw.write('a')
    assert fw.path == 'a.txt'
    assert fw.overwrite == False
    fw.write('a')




# Generated at 2022-06-22 18:15:45.568158
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def some_function():
        a = 3
        locals()['b'] = 'x'
        return (a, b, c)
    frame = sys._getframe()
    assert get_local_reprs(frame) == {'frame': '<frame object at 0x%x>' % id(frame)}
    frame = some_function.func_code.co_consts[0]
    assert get_local_reprs(frame) == {'a': '3', 'b': "'x'", 'c': '<unbound>'}


# Generated at 2022-06-22 18:15:53.997381
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file_name = temp_file.name
    temp_file.close()
    assert os.path.exists(temp_file_name)

    with open(temp_file_name, 'a') as f:
        f.write('lorem ipsum')

    output_writer = FileWriter(temp_file_name, overwrite=True)
    output_writer.write('hello world')
    with open(temp_file_name, 'r') as f:
        assert f.read() == 'hello world'
    output_writer.write('abc')
    with open(temp_file_name, 'r') as f:
        assert f.read() == 'hello worldabc'

# Generated at 2022-06-22 18:16:04.040566
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'TEST_FILE'
    try:
        writer = FileWriter(path, False)
        assert writer.path == os.path.abspath(path)
        assert writer.overwrite is False
        writer.write('hello')
        with open(path, 'r') as r:
            assert r.read() == 'hello'
        writer.write(' world')
        with open(path, 'r') as r:
            assert r.read() == 'hello world'
        writer = FileWriter(path, True)
        writer.write('hello')
        with open(path, 'r') as r:
            assert r.read() == 'hello'
    finally:
        os.unlink(path)


# Generated at 2022-06-22 18:16:16.591606
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    #__salt__
    '''
    Unit test for method __exit__ of class pysnooper.tracer.Tracer
    '''
    class Mock_exc_traceback():
        '''
        Mock class to mimic traceback.TracebackException object
        '''
        def __init__(self, value, tb, exc_traceback, limit=None):
            self.value = value
            self.tb = tb
            self.exc_traceback = exc_traceback
        def __repr__(self):
            return str(self.value)
    #1.
    with pysnooper.snoop():
        pass
    #2.
    with pysnooper.snoop():
        raise Exception
    #3.

# Generated at 2022-06-22 18:16:24.066455
# Unit test for method write of class Tracer
def test_Tracer_write():
    from io import StringIO
    from contextlib import contextmanager
    from pysnooper import snoop
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function

    @contextmanager
    def test_write():
        with StringIO() as sio:
            yield sio


    @snoop()
    def foo():
        pass

    with test_write() as sio:
        foo()

# Generated at 2022-06-22 18:16:25.108705
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-22 18:16:30.858375
# Unit test for constructor of class FileWriter
def test_FileWriter():
    temp_file_path = pycompat.Path(utils.RandomNameCreator.create()). \
                     resolve().with_suffix('.txt')
    content = utils.RandomNameCreator.create()
    file_writer = FileWriter(temp_file_path, False)
    file_writer.write(content)
    with file_writer.path.open() as file:
        assert file.read() == content



# Generated at 2022-06-22 18:16:32.124378
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-22 18:16:41.582146
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    output = io.StringIO()
    try:
        write = get_write_function(output, overwrite=False)
        write('hello\n')
        assert output.getvalue() == 'hello\n'
    finally:
        if output is not None:
            output.close()
    path = tempfile.mkstemp()[1]
    try:
        write = get_write_function(path, overwrite=True)
        write('hello\n')
        with open(path, 'r') as f:
            content = f.read()
        assert content == 'hello\n'
    finally:
        os.remove(path)
    try:
        write = get_write_function(path, overwrite=False)
        assert False
    except Exception:
        pass



# Generated at 2022-06-22 18:16:46.310546
# Unit test for constructor of class FileWriter
def test_FileWriter():
    try:
        FileWriter(__file__, overwrite=True)
        with open(__file__, 'a', encoding='utf-8') as f:
            initial_length = len(f.readlines())

        FileWriter(__file__, overwrite=False).write('hi')
        with open(__file__, 'a', encoding='utf-8') as f:
            assert len(f.readlines()) == initial_length + 1

        FileWriter(__file__, overwrite=True).write('hi again')
        with open(__file__, 'a', encoding='utf-8') as f:
            assert len(f.readlines()) == 1
    finally:
        with open(__file__, 'w', encoding='utf-8') as f:
            pass


# Generated at 2022-06-22 18:16:57.184503
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    '''
    Unit test for method write of class FileWriter.
    '''
    import tempfile
    import os
    
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = os.path.join(tmp_dir, 'a.txt')
        a = FileWriter(tmp_path, overwrite=True)
        a.write(u'α')
        with open(tmp_path, 'r') as file_:
            assert file_.read().strip() == u'α'
        b = FileWriter(tmp_path, overwrite=False)
        b.write(u'β')
        with open(tmp_path, 'r') as file_:
            assert file_.read().strip() == u'αβ'

# Generated at 2022-06-22 18:16:58.632897
# Unit test for constructor of class Tracer
def test_Tracer():
    Tracer()


# Unit tests for methods of class Tracer

# Generated at 2022-06-22 18:17:07.123965
# Unit test for function get_write_function
def test_get_write_function():
    from .test import assert_equal
    from .tests.pickle_test import PickleTest
    assert_equal(get_write_function(None, None), sys.stderr.write)
    assert_equal(get_write_function(sys.stderr, None), sys.stderr.write)
    assert_equal(get_write_function(str(PickleTest), None),
                 type(PickleTest).write)
    assert_equal(get_write_function(sys.stdout, None), sys.stdout.write)
    assert_equal(get_write_function('out', None), type(FileWriter(None, None)).write)
    assert_equal(get_write_function('out', True), type(FileWriter(None, None)).write)

# Generated at 2022-06-22 18:17:19.368509
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import types
    import threading
    import inspect
    import traceback

    import pysnooper._snoop
    import pysnooper._utils
    import pysnooper._thread

    old_stderr = sys.stderr

# Generated at 2022-06-22 18:17:20.872445
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(
        inspect.currentframe()
    )[0] == __file__



# Generated at 2022-06-22 18:17:24.016814
# Unit test for method write of class FileWriter
def test_FileWriter_write():

    cls = FileWriter(path='', overwrite=True)
    assert cls.overwrite == True
    assert cls.path == ''

    cls.write('hello')
    assert cls.overwrite == False

    cls = FileWriter(path='', overwrite=False)
    assert cls.overwrite == False
    assert cls.path == ''

    cls.write('hello')
    assert cls.overwrite == False


# Generated at 2022-06-22 18:17:27.776948
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import __main__
    __main__.__dict__['__builtins__']['__import__'] = 1
    tracer = Tracer()
    with tracer:
        pass


# Generated at 2022-06-22 18:17:35.025618
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .test_tools.asserting import assert_same_structure as as_s
    output_path = os.path.join(os.path.dirname(__file__), 'bwahahahahahahah.txt')
    file_writer = FileWriter(output_path, overwrite=True)
    assert os.path.exists(output_path)
    file_writer.write('bwahahahahahahah')
    with open(output_path, 'r', encoding='utf-8') as file:
        text = file.read()
    assert text == 'bwahahahahahahah'
    os.remove(output_path)



# Generated at 2022-06-22 18:17:39.161676
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from . import pysnooper
    pysnooper.set_trace()
    x = 1
    x = 2
    x = 3
    x = 4

# Generated at 2022-06-22 18:17:40.840357
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:17:47.631398
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import tempfile
    temp_dir_path = tempfile.mkdtemp()
    path = os.path.join(temp_dir_path, 'test.txt')
    with open(path, 'w') as f:
        f.write('spam')
    file_writer = FileWriter(path, overwrite=True)
    file_writer.write('eggs')
    with open(path) as f:
        assert f.read() == 'eggseggs'
    file_writer.write('bacon')
    with open(path) as f:
        assert f.read() == 'eggseggsbacon'
    import shutil
    shutil.rmtree(temp_dir_path, ignore_errors=True)



# Generated at 2022-06-22 18:17:58.582294
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper.snoop import Snoop
    from pysnooper.snoop import CommonVariable
    from pysnooper.snoop import BaseVariable
    from pysnooper.snoop import Exploding
    from pysnooper.snoop import get_path_and_source_from_frame
    import threading
    import inspect
    import utils
    import pycompat
    import DISABLED
    import opcode
    import itertools
    import traceback
    import datetime
    import datetime_module
    import pycompat
    import os
    import functools
    import sys
    import thread_global
    # Initialize test variables

# Generated at 2022-06-22 18:18:08.803482
# Unit test for constructor of class FileWriter
def test_FileWriter():
    try:
        from StringIO import StringIO
        from StringIO import StringIO as BytesIO
    except ImportError:
        from io import StringIO
    from sweet_inspect import utils
    # StringIO is for testing whether the writable or wb parameter is
    # called in the write() method
    output_stream_writable = StringIO()
    output_stream_writable.write = lambda s: output_stream_writable.write(s)
    output_stream_hex = BytesIO()
    output_stream_hex.write = lambda s: output_stream_hex.write(s)
    # Now, test if the write() method is called in the following situations
    file_writer_string = FileWriter('sweet.txt', False)
    file_writer_string.write('xxx')

# Generated at 2022-06-22 18:18:11.049277
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:18:16.796750
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    with tempfile.NamedTemporaryFile() as file_:
        # Testing write function when output is None
        write_function = get_write_function(None, None)
        assert(write_function('any string') == None)

        # Testing write function when output is a callable
        def write_to_file(txt):
            with open(file_.name, 'a') as file:
                file.write(str(txt))
        assert(get_write_function(write_to_file, None)('func')('txt') == None)

        # Testing write function when output is a string
        write_function = get_write_function(file_.name, overwrite=True)
        assert(write_function('write function') == None)

# Generated at 2022-06-22 18:18:27.341802
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    case1 = tracer.set_thread_info_padding('t1-f1 ')
    assert case1 == 't1-f1 '.ljust(tracer.thread_info_padding)

    case2 = tracer.set_thread_info_padding('t1-f1 ')
    assert case2 == 't1-f1 '.ljust(tracer.thread_info_padding)

    case3 = tracer.set_thread_info_padding('t1-f1 ')
    assert case3 == 't1-f1 '.ljust(tracer.thread_info_padding)

    case4 = tracer.set_thread_info_padding('t2-f1 ')

# Generated at 2022-06-22 18:18:38.930810
# Unit test for function get_write_function
def test_get_write_function():
    output_stream = utils.WritableStream()
    write = get_write_function(output_stream, True)
    assert callable(write)
    write(u'hello')
    assert output_stream.getvalue() == u'hello'

    write = get_write_function(None, True)
    try:
        assert write(u'hello') is None
        assert False
    except UnicodeEncodeError:
        # God damn Python 2
        pass

    write = get_write_function(lambda s: None, False)
    assert write(u'hello') is None

    write = get_write_function(u'/f', False)
    write(u'hello')
    assert utils.read_file(u'/f') == u'hello'

    write = get_write_function(u'/f', True)
   

# Generated at 2022-06-22 18:18:51.551408
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test the function snoop() from the module pysnooper
    import inspect
    import functools
    snoop = pysnooper.snoop

    class A:
        @snoop()
        def f(self): print('A.f()')

        @property
        @snoop()
        def x(self):
            print('A.x')
            return 42

        def g(self): return self.f()

        @classmethod
        @snoop()
        def h(cls): print('A.h()')


    a = A()

    assert isinstance(A.f, inspect._empty)
    assert isinstance(A.x, property)

    assert not isinstance(A.g, inspect._empty)
    assert not isinstance(A.h, inspect._empty)


# Generated at 2022-06-22 18:18:57.405049
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter('test.txt', True)
    file_writer.write('test content')
    with open('test.txt', 'r') as f:
        content = f.read()
    assert content == 'test content'
    file_writer.write('test content 2')
    with open('test.txt', 'r') as f:
        content = f.read()
    assert content == 'test contenttest content 2'



# Generated at 2022-06-22 18:18:59.240863
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource().__getitem__(0) == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:19:07.062659
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # Check if write can only be called once when overwrite=True
    class MockPythonFile:
        def __init__(self):
            self.content = []

        def write(self, s):
            self.content.append(s)

    f = FileWriter(MockPythonFile(), True)
    f.write("a")
    assert f.content == ["a"]

    f = FileWriter(MockPythonFile(), True)
    f.write("a")
    f.write("b")
    assert f.content == ["a"]

    # Check if write can be called multiple times when overwrite=False
    f = FileWriter(MockPythonFile(), False)
    f.write("a")
    f.write("b")
    assert f.content == ["a", "b"]



# Generated at 2022-06-22 18:19:08.507816
# Unit test for method write of class Tracer
def test_Tracer_write():
    a= Tracer()
    a.write("test_line")


# Generated at 2022-06-22 18:19:17.609339
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer_in  = Tracer(thread_info=True)
    tracer_out = Tracer(thread_info=False)
    with tracer_in:
        assert tracer_in.thread_info_padding == 0
        assert tracer_in.set_thread_info_padding("abc") == "abc"
        assert tracer_in.thread_info_padding == 3
        assert tracer_in.set_thread_info_padding("defg") == "defg   "
        assert tracer_in.thread_info_padding == 3
        assert tracer_in.set_thread_info_padding("hijklmnop") == "hijklmnop"
        assert tracer_in.thread_info_padding == 8
    assert tracer_in.thread_info_padding == 8

# Generated at 2022-06-22 18:19:22.287287
# Unit test for method write of class Tracer
def test_Tracer_write():
    class WriteMock:
        def __init__(self):
            self.output = []

        def __call__(self, s):
            self.output.append(s)

    output = WriteMock()
    tracer = Tracer(output=output)
    tracer.write("Snoop")
    assert output.output == ['Snoop\n']


# Generated at 2022-06-22 18:19:33.446245
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        g = 68
        return g
    frame = inspect.currentframe().f_back
    assert get_local_reprs(frame) == {'g': '68'}
    assert get_local_reprs(frame, watch=[CommonVariable('g')]) == {
        'g': '68',
        'g (CommonVariable)': '68'
    }

    from .variables import CommonVariable
    class MyVariable(CommonVariable):
        def items(self, frame, normalize=False):
            return {self.name + ' (my)': self.get(frame, normalize)}

    my_var = MyVariable('h')
    assert get_local_reprs(frame, watch=[my_var]) == {'h (my)': ''}



# Generated at 2022-06-22 18:19:34.748802
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame # dummy



# Generated at 2022-06-22 18:19:39.764409
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t = Tracer(thread_info=True)
    assert t.set_thread_info_padding("1-abc") == "1-abc"
    assert t.set_thread_info_padding("12-abc") == "12-abc"
    assert t.set_thread_info_padding("123-abc") == "123-abc "


# Generated at 2022-06-22 18:19:51.182903
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    with open('test.txt', 'w+') as output_file:
        output_file.write('We will see if this is replaced.\n')
    writer = FileWriter('test.txt', overwrite=True)
    writer.write('This is written in the file.\n')
    with open('test.txt', 'r') as output_file:
        assert output_file.read() == 'This is written in the file.\n'
    writer.write('This is also written in the file.\n')
    with open('test.txt', 'r') as output_file:
        assert output_file.read() == 'This is written in the file.\n' \
                                     'This is also written in the file.\n'



# Generated at 2022-06-22 18:19:53.499680
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__(): assert UnavailableSource()[5] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:19:55.023965
# Unit test for method write of class Tracer
def test_Tracer_write():
  tr = Tracer()
  tr.write("test")


# Generated at 2022-06-22 18:19:58.804327
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    buf = io.StringIO()
    tracer = Tracer(output=buf, normalize=True,
                    watch='yourString')
    tracer.write('yourString')
    assert buf.getvalue() == 'yourString\n'



# Generated at 2022-06-22 18:20:03.864342
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    from . import output
    from .output import safe_print
    from . import test_utils
    output_types = (
        None,
        output.StdoutOutput(),
        output.StderrOutput(),
        tempfile.TemporaryFile('w'),
        test_utils.StringIO(),
    )
    for output_ in output_types:
        write = get_write_function(output_, overwrite=False)
        write(u'hello world\n')
        write(u'goodbye world\n')
        write(u'hello world\n')
    return
test_get_write_function()


# Generated at 2022-06-22 18:20:13.060888
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import shutil
    import os
    with open('test_write/test.txt', 'w') as f:
        f.write('a')
    with FileWriter('test_write/test.txt', overwrite=True) as f:
        f.write('b')
    with open('test_write/test.txt', 'r') as f:
        assert f.read() == 'b'
    os.remove('test_write/test.txt')
    os.removedirs('test_write')

# Generated at 2022-06-22 18:20:25.988530
# Unit test for constructor of class Tracer

# Generated at 2022-06-22 18:20:28.521823
# Unit test for constructor of class Tracer
def test_Tracer():
    assert Tracer(watch=('foo', 'bar')).watch
    assert Tracer(watch_explode=('foo', 'bar')).watch


# Generated at 2022-06-22 18:20:30.011325
# Unit test for function get_local_reprs
def test_get_local_reprs():
    raise NotImplementedError


# Generated at 2022-06-22 18:20:32.173700
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    assert tracer.__enter__() is None

# Generated at 2022-06-22 18:20:37.771866
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[:] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[:5:2] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-22 18:20:47.885481
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import _pysnooper
    global t_
    t_ = _pysnooper.Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    def test_func():
        a = 1
        b = 2
        print("Print line")
        return a+b
    real_trace = sys.gettrace()
    Tracer.trace(t_, sys._getframe(), 'call', None)
    assert sys.gettrace() == t_.trace
    sys.settrace(real_trace)

test_Tracer_trace()
print("test Tracer.trace passed") 

# Generated at 2022-06-22 18:20:54.147847
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    from . import state
    un = UnavailableSource()
    assert un[0] == u'SOURCE IS UNAVAILABLE'
    assert un[0] == un[1] == un[10]
    assert un[:] == state.flip(lines=u'SOURCE IS UNAVAILABLE\n')
    assert un[1:3] == state.flip(lines=u'SOURCE IS UNAVAILABLE\n')
test_UnavailableSource___getitem__()



# Generated at 2022-06-22 18:21:00.162875
# Unit test for constructor of class FileWriter
def test_FileWriter():
    class FileObject:
        def write(self, msg):
            print('msg')
    src = str(pycompat.Path(__file__).parent / 'src')
    fw1 = FileWriter(src + '/output.log', False)
    fw2 = FileWriter(src + '/output.log', True)
    s = 'Hello'
    assert fw1.write(s) is None
    assert fw2.write(s) is None



# Generated at 2022-06-22 18:21:01.415403
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-22 18:21:09.630221
# Unit test for constructor of class FileWriter
def test_FileWriter():
    my_path = os.path.join(os.path.dirname(__file__),
                           'FileWriter_test_output.txt')

# Generated at 2022-06-22 18:21:17.827051
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import pytest
    # Unit test whether `get_local_reprs` returns the right thing.
    def f():
        x = 1
        y = 2
        z = 3

    frame = inspect.currentframe()
    frame = frame.f_back

    local_reprs = get_local_reprs(frame, watch=[CommonVariable('v')],
                                             max_length=4)
    assert local_reprs == {'x': '1', 'y': '2', 'z': '3'}

    class MyClass(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __repr__(self):
            return '<MyClass x=%s y=%s>' % (self.x, self.y)

# Generated at 2022-06-22 18:21:28.463174
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .models import Shtock
    shmonty = Shtock(name='shmonty', price=-1)
    assert get_local_reprs(frame=None,
                           watch=(CommonVariable(shmonty, 'price'),)) == {
        'shmonty.price': '-1'
    }
    assert get_local_reprs(frame=None,
                           watch=(CommonVariable(shmonty, 'name'),)) == {
        'shmonty.name': 'shmonty'
    }
    assert pycompat.PY2 or len(get_local_reprs(frame=None,
                                               watch=(CommonVariable(shmonty,
                                                                     'name'),),
                                               custom_repr={str: repr}))

# Generated at 2022-06-22 18:21:39.047873
# Unit test for function get_write_function
def test_get_write_function():
    import contextlib
    import io

    # Test that get_write_function handles None, path and callable
    # argument correctly.

    # When output=None
    write = get_write_function(None, False)
    assert getattr(write, '__code__', None) is None

    # When output=path
    write = get_write_function('/tmp/foo.txt', True)
    assert getattr(write, '__code__', None) is None

    # When output=callable
    log = []
    def output_function(s):
        log.append(s)
    write = get_write_function(output_function, False)
    assert getattr(write, '__code__', None) is not None

    # Test that get_write_function handles file-like argument correctly.
    # This relies on

# Generated at 2022-06-22 18:21:42.717777
# Unit test for constructor of class Tracer
def test_Tracer():
    assert inspect.isfunction(Tracer.__init__)
    assert Tracer.__init__.__code__.co_argcount == 12


# Generated at 2022-06-22 18:21:48.153014
# Unit test for constructor of class FileWriter
def test_FileWriter():
    fw = FileWriter('tmp.txt', True)
    assert fw.overwrite == True
    fw.write('hello world')
    assert fw.overwrite == False

    fw = FileWriter(b'tmp.txt', True)
    assert fw.overwrite == True
    fw.write('hello world')
    assert fw.overwrite == False



# Generated at 2022-06-22 18:21:59.237108
# Unit test for method write of class Tracer
def test_Tracer_write():
  frame = inspect.currentframe().f_back
  source_path, source = get_path_and_source_from_frame(frame)
  line_no = frame.f_lineno
  source_line = source[line_no - 1]
  # timestamp = str(time.time())
  # thread_info = "{ident}-{name} ".format(
  #                 ident=threading.current_thread().ident, name=threading.current_thread().getName())
  timestamp = ' '*15
  thread_info = "0-MainThread "
  indent = ' ' * 4 * thread_global.depth
  tracer = Tracer(normalize=True)

# Generated at 2022-06-22 18:22:05.839007
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    assert isinstance(get_write_function(None, False),
                      functools.partial)
    assert isinstance(get_write_function(utils.StringIO(), False),
                      functools.partial)
    assert isinstance(get_write_function(utils.StringIO(), True),
                      functools.partial)
    assert isinstance(get_write_function(str(utils.TemporaryFile()), True),
                      FileWriter)




# Generated at 2022-06-22 18:22:16.178993
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from test_utils import DummyFile
    from pysnooper import Variable
    import threading
    import ctypes
    import pysnooper
    import inspect
    import functools
    import pycompat
    import sys
    import itertools
    import traceback
    import os
    import datetime as datetime_module
    import pysnooper.utils
    import pysnooper.pycompat
    class ThreadGlobal:
        pass
    thread_global = ThreadGlobal()
    def test_get_write_function():
        dummy_file = DummyFile()
        f = pysnooper.get_write_function(dummy_file, overwrite=False)
        f(u'first line')
        assert dummy_file.lines == [u'first line\n']
        f(u'second line')

# Generated at 2022-06-22 18:22:27.490736
# Unit test for constructor of class FileWriter
def test_FileWriter():
    def test(s, expect_s, overwrite, path, expect_path):
        writer = FileWriter(path, overwrite)
        writer.write(s)
        with open(expect_path, 'r') as output_file:
            assert output_file.read() == expect_s
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w') as tf:
        test('abcd', 'abcd', True, tf.name, tf.name)
        test('efgh', 'abcd'+'efgh', False, tf.name, tf.name)
        with tempfile.NamedTemporaryFile(mode='w') as tf2:
            test('ijkl', 'ijkl', False, tf2.name, tf2.name)