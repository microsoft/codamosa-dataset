

# Generated at 2022-06-16 19:15:34.844191
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test for method trace of class Tracer
    # Input arguments:
    #   frame :
    #   event :
    #   arg :
    # Output:
    #   return value :
    #   frame :
    #   event :
    #   arg :
    #   indent :
    #   timestamp :
    #   thread_info :
    #   line_no :
    #   source_line :
    #   newish_string :
    #   name :
    #   value_repr :
    #   candidate_line_no :
    #   candidate_source_line :
    #   code_byte :
    #   ended_by_exception :
    #   return_value_repr :
    #   exception :
    pass


# Generated at 2022-06-16 19:15:40.602033
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_write_function
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.variable import get_local_reprs
    from pysnooper.variable import thread_global
    from pysnooper.variable import DISABLED

    # 1. Call to exit
    # 2. Check if the frame is in the

# Generated at 2022-06-16 19:15:44.345576
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:15:51.374984
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import functools
    import inspect
    import threading
    import datetime
    import traceback
    import itertools
    import opcode
    import pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable

# Generated at 2022-06-16 19:16:03.501677
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import time
    import threading
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.inspect
    import pysnooper.datetime_module
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.inspect
    import pysnooper.datetime_module
    import pysnooper.utils
    import pysnooper.pycompat
    import pys

# Generated at 2022-06-16 19:16:15.147215
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import pytest
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import collections
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
   

# Generated at 2022-06-16 19:16:20.612869
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:27.971546
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import os
    import threading
    import datetime
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:35.566130
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat


# Generated at 2022-06-16 19:16:48.298980
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:59.647090
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import Variable
    from pysnooper.variable import VariableList
    from pysnooper.variable import VariableDict
    from pysnooper.variable import VariableSet
    from pysnooper.variable import VariableTuple
    from pysnooper.variable import VariableFrozenset
    from pysnooper.variable import VariableDeque
    from pysnooper.variable import VariableChainMap
    from pysnooper.variable import VariableCounter
    from pysnooper.variable import VariableOrderedDict
   

# Generated at 2022-06-16 19:18:07.237885
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import traceback
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.tracer
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.threading
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysno

# Generated at 2022-06-16 19:18:12.684230
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('tests/test_debugger.py')
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')
    assert f()[1][1].startswith('    def f():')



# Generated at 2022-06-16 19:18:13.409072
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-16 19:18:23.785025
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import os
    import get_write_function
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DIS

# Generated at 2022-06-16 19:18:34.062617
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import inspect
    import threading
    import functools
    import datetime
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:18:45.271753
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import traceback
    import itertools
    import os
    import pycompat
    import opcode
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:50.844540
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')



# Generated at 2022-06-16 19:18:59.933130
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.tracer
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.threading
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.pycompat
    import pysnooper.DISABLED
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.get_write_function


# Generated at 2022-06-16 19:19:09.226918
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile
    import textwrap
    import types
    import unittest

    class TestCase(unittest.TestCase):
        def test_get_path_and_source_from_frame(self):
            source = textwrap.dedent('''
                def foo():
                    pass
            ''')
            with tempfile.NamedTemporaryFile(suffix='.py', delete=False) as f:
                f.write(source.encode('utf-8'))

# Generated at 2022-06-16 19:21:14.659327
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:21:27.516325
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr
            sys.stdout = io.StringIO()
            sys.stderr = io.StringIO()

        def tearDown(self):
            sys.stdout = self.stdout
            sys.stderr = self.stderr

        def test_constructor(self):
            # Test constructor of class Tracer
            # Test default values
            tracer = Tracer()
            self.assertEqual(tracer.watch, [])
            self.assertEqual(tracer.depth, 1)
            self.assertEqual(tracer.prefix, '')

# Generated at 2022-06-16 19:21:39.405125
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import datetime
    import os
    import pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.DISABLED
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.utils
    import pysnooper.pycompat
    import pysno

# Generated at 2022-06-16 19:21:51.314873
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:22:03.826597
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import io
    import sys
    import pycompat
    import os
    import os.path
    import io
    import sys
    import pycompat
    import os
    import os.path
    import io
    import sys
    import pycompat
    import os
    import os.path
    import io
    import sys
    import pycompat
    import os
    import os.path
    import io
    import sys
    import pycompat
    import os
    import os.path
    import io
    import sys
    import pycompat
    import os
    import os.path
    import io
    import sys
    import pycompat
    import os
    import os.path

# Generated at 2022-06-16 19:22:05.455683
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Test for method __exit__ of class Tracer
    # This test is not implemented
    pass


# Generated at 2022-06-16 19:22:18.727965
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    from . import utils
    from .utils import get_path_and_source_from_frame
    from .variable import CommonVariable, Exploding, BaseVariable
    from . import DISABLED
    from . import thread_global
    from . import pycompat
    from .utils import get_write_function
    from . import datetime_module
    from . import inspect
    from . import functools
    from . import itertools
    from . import traceback
    from . import opcode
    from . import pycompat
    from . import utils
    from .utils import get_path_and_source_from_frame

# Generated at 2022-06-16 19:22:25.733436
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:22:35.873075
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import threading
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils

# Generated at 2022-06-16 19:22:47.904618
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_watch(self):
            self.snooper.watch = ['foo']
            self.assertEqual(self.snooper.watch, [CommonVariable('foo')])

        def test_watch_explode(self):
            self.snooper.watch_explode = ['foo']
            self.assertEqual(self.snooper.watch_explode, [Exploding('foo')])

        def test_watch_explode_and_watch(self):
            self.snooper.watch = ['foo']