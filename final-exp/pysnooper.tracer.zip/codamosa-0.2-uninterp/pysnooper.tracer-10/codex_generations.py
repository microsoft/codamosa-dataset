

# Generated at 2022-06-16 19:15:58.359729
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    def g():
        return get_path_and_source_from_frame(inspect.currentframe())
    g.__code__ = types.CodeType(0, 0, 0, 0, b'c\x00\x00d\x01\x00d\x02\x00k\x03\x00r\x04\x00|\x00\x00d\x05\x00S\x00', (), (), ('f', 'g'), '', '', 1, b'', (), ())
    assert g() == ('', UnavailableSource())
test_get_path_and_source_

# Generated at 2022-06-16 19:16:11.542824
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import traceback
    import unittest
    import unittest.mock
    import warnings

    class Tracer___exit__Tests(unittest.TestCase):
        def setUp(self):
            self.snooper = pysnooper.snoop()
            self.snooper.write = unittest.mock.Mock()
            self.snooper.thread_local = threading.local()
            self.snooper.thread_local.original_trace_functions = []
            self.snooper.start_times = {}
            self.snooper.frame_to_local_reprs = {}
            self.snooper.target_codes = set()
            self.snooper.target_frames = set()

# Generated at 2022-06-16 19:16:22.147929
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import shutil
    import io
    import sys
    import contextlib
    import pathlib
    import six
    import pytest

    def test_write_function(write_function, text):
        write_function(text)
        write_function(text)

    def test_write_function_with_overwrite(write_function, text):
        write_function(text)
        write_function(text)

    def test_write_function_with_overwrite_and_path(write_function, text):
        write_function(text)
        write_function(text)

    def test_write_function_with_overwrite_and_path_and_unicode(write_function, text):
        write_function(text)
        write_function(text)


# Generated at 2022-06-16 19:16:26.770794
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def f():'



# Generated at 2022-06-16 19:16:33.894929
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_write_function
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.BaseVariable
    import pysnooper.DISABLED
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global

# Generated at 2022-06-16 19:16:41.825822
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import datetime
    import datetime_module
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:16:53.165284
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import os
    import datetime_module
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:16:56.933278
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][1].startswith('def f():')



# Generated at 2022-06-16 19:16:59.492093
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(sys._getframe(1))
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:17:06.724357
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
   

# Generated at 2022-06-16 19:17:45.226108
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_default_constructor(self):
            self.assertEqual(self.snooper.watch, [])
            self.assertEqual(self.snooper.depth, 1)
            self.assertEqual(self.snooper.prefix, '')
            self.assertEqual(self.snooper.thread_info, False)
            self.assertEqual(self.snooper.custom_repr, ())
            self.assertEqual(self.snooper.max_variable_length, 100)

# Generated at 2022-06-16 19:17:53.756499
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import datetime
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:03.659549
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import os.path
    import time
    import datetime
    import pytest
    import pycompat
    import os
    import sys
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import os
    import sys
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import os
    import sys
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import os
    import sys
    import re
    import collections
    import datetime as datetime_module
    import it

# Generated at 2022-06-16 19:18:15.726882
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import datetime
    import pycompat
    import utils
    import get_path_and_source_from_frame
    import thread_global
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import get_write_function
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import datetime
    import pycompat
    import utils
    import get_path_and_source_from_frame
    import thread_global
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
   

# Generated at 2022-06-16 19:18:25.041120
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import os
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import os
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import dat

# Generated at 2022-06-16 19:18:35.207504
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import datetime
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:46.125864
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import contextlib
    import pytest

    def test_write_function(write_function, expected_output):
        with contextlib.redirect_stdout(io.StringIO()) as stdout:
            write_function('hello')
            assert stdout.getvalue() == expected_output

    def test_write_function_with_overwrite(write_function, expected_output):
        with contextlib.redirect_stdout(io.StringIO()) as stdout:
            write_function('hello')
            assert stdout.getvalue() == expected_output


# Generated at 2022-06-16 19:18:50.773331
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import datetime
    import os
   

# Generated at 2022-06-16 19:18:55.710655
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def f():'



# Generated at 2022-06-16 19:19:00.458725
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:19:53.674617
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import BaseVariable
    import CommonVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:02.317039
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import contextlib
    import pytest

    @contextlib.contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        sys.stderr = io.StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr

    def test_get_write_function_with_output(output, expected_output):
        with capture_stderr() as stderr:
            write = get_write_function(output, False)
            write('test')
            assert stderr.getvalue() == expected_output


# Generated at 2022-06-16 19:20:08.586235
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'
    assert source[-1] == 'test_get_path_and_source_from_frame()'
test_get_path_and_source_from_frame()



# Generated at 2022-06-16 19:20:11.375320
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:20:23.374661
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path

# Generated at 2022-06-16 19:20:28.657612
# Unit test for method __exit__ of class Tracer

# Generated at 2022-06-16 19:20:41.065275
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test that Tracer is a callable
    assert callable(Tracer)

    # Test that Tracer has the correct attributes
    assert hasattr(Tracer, '__init__')
    assert hasattr(Tracer, '__call__')
    assert hasattr(Tracer, 'write')
    assert hasattr(Tracer, '__enter__')
    assert hasattr(Tracer, '__exit__')
    assert hasattr(Tracer, '_is_internal_frame')
    assert hasattr(Tracer, 'set_thread_info_padding')
    assert hasattr(Tracer, 'trace')

    # Test that Tracer has the correct methods
    assert callable(Tracer.__init__)
    assert callable(Tracer.__call__)
    assert callable(Tracer.write)

# Generated at 2022-06-16 19:20:52.428599
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import p

# Generated at 2022-06-16 19:21:00.924546
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, 'test.txt')
        file_writer = FileWriter(path, overwrite=True)
        file_writer.write('hello')
        with open(path, 'r') as f:
            assert f.read() == 'hello'
        file_writer.write('world')
        with open(path, 'r') as f:
            assert f.read() == 'helloworld'



# Generated at 2022-06-16 19:21:13.261155
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import os
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:24:09.845200
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import contextlib
    import io
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.tracer
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.inspect
    import pysnooper.datetime_module
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.threading
    import pysnooper.functools
    import pysnooper.traceback
    import pysnooper.inspect
    import pysnooper.get_write_function
    import pysnooper.get

# Generated at 2022-06-16 19:24:20.631315
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
   

# Generated at 2022-06-16 19:24:29.979335
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import os
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import pycompat
    import BaseVariable
    import CommonVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp