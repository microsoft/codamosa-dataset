

# Generated at 2022-06-16 19:15:20.804526
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import os
    import sys
    import tempfile
    import unittest
    import pysnooper
    import datetime
    import time
    import threading
    import traceback
    import inspect
    import functools
    import pycompat
    import utils
    import opcode
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:15:33.316473
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import utils
    import thread_global
    import datetime_module
    import os
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import get_write_function
    import pycompat
   

# Generated at 2022-06-16 19:15:39.846995
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import pycompat
    import opcode
    import os
    import itertools
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global

# Generated at 2022-06-16 19:15:48.658015
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:16:01.012984
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_output(self):
            @self.snooper
            def foo():
                pass
            foo()
            self.assertTrue(self.output.getvalue())

        def test_watch(self):
            @self.snooper(watch=('foo',))
            def foo():
                foo = 1
            foo()
            self.assertIn('foo = 1', self.output.getvalue())


# Generated at 2022-06-16 19:16:13.417024
# Unit test for method trace of class Tracer

# Generated at 2022-06-16 19:16:20.055254
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import os
    import pycompat
    import opcode
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:27.467579
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import datetime_module
    import pycompat
    import thread_global
    import inspect
    import get_path_and_source_from_frame
    import get_write_function
    import utils
    import DISABLED
    import CommonVariable
    import BaseVariable
    import Exploding
    import thread_global
    import pycompat
    import os
    import pycompat
    import utils
    import datetime_module
    import pycompat
    import thread_global
    import inspect
    import get_path_and_source_from_frame
    import get_write_function
    import utils
   

# Generated at 2022-06-16 19:16:35.049789
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.DISABLED
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.pycompat
    import pys

# Generated at 2022-06-16 19:16:47.829456
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import pysnooper
    import sys
    import threading
    import traceback
    import types
    import unittest
    import unittest.mock
    import warnings
    import weakref
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_write_function
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.variable import get_local_reprs
    from pysnooper.variable import get_shortish_repr
    from pysnooper.variable import truncate

# Generated at 2022-06-16 19:17:14.423053
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())



# Generated at 2022-06-16 19:17:26.736417
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    import os
    import shutil
    import sys
    import types
    import importlib
    import inspect
    import random
    import string
    import time
    import unittest
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
    import importlib.abc
   

# Generated at 2022-06-16 19:17:36.505510
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = 'test_FileWriter_write.txt'
    if os.path.exists(path):
        os.remove(path)
    assert not os.path.exists(path)
    file_writer = FileWriter(path, overwrite=True)
    file_writer.write('hello')
    with open(path, 'r') as f:
        assert f.read() == 'hello'
    file_writer.write('world')
    with open(path, 'r') as f:
        assert f.read() == 'world'
    file_writer.write('!')
    with open(path, 'r') as f:
        assert f.read() == 'world!'
    os.remove(path)
    assert not os.path.exists(path)



# Generated at 2022-06-16 19:17:39.413058
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:17:50.223462
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:56.609398
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__, source_lines)
source_lines = get_path_and_source_from_frame(inspect.currentframe())[1]



# Generated at 2022-06-16 19:18:05.193729
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = x + 1
        z = x + 2
        return y + z
    frame = inspect.currentframe()
    frame = frame.f_back
    assert get_local_reprs(frame) == {'x': '0', 'y': '1', 'z': '2'}
    assert get_local_reprs(frame, watch=[CommonVariable('x')]) == {'x': '0'}
    assert get_local_reprs(frame, watch=[CommonVariable('x'), CommonVariable('y')]) == {'x': '0', 'y': '1'}

# Generated at 2022-06-16 19:18:16.461988
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.watch
    import pysnooper.watch.utils
    import pysnooper.watch.pycompat
    import pysnooper.watch.opcode
    import pysnooper.watch.thread_global
    import pysnooper.watch.watch
    import pysnooper.watch.watch.utils
    import pysnooper.watch.watch.pycompat
    import pys

# Generated at 2022-06-16 19:18:25.515050
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
   

# Generated at 2022-06-16 19:18:30.176987
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())



# Generated at 2022-06-16 19:18:59.812417
# Unit test for method trace of class Tracer

# Generated at 2022-06-16 19:19:08.354122
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import datetime
    import time
    import sys
    import threading
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import os
    import utils
    import thread_global
    import pycompat
    import datetime_module
    import pycompat
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import os
    import utils
    import thread_global
    import pycompat
    import datetime_module
    import pycompat
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import os
    import utils
    import thread_global
    import pycompat
    import datetime_module


# Generated at 2022-06-16 19:19:21.365607
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import sys
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import sys
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect


# Generated at 2022-06-16 19:19:32.747811
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (
        __file__,
        UnavailableSource()
    )
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (
        __file__,
        UnavailableSource()
    )
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno

# Generated at 2022-06-16 19:19:43.193123
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper import snoop
    from pysnooper.utils import get_write_function
    from pysnooper.tracer import Tracer
    from pysnooper.variables import CommonVariable
    from pysnooper.variables import Exploding
    from pysnooper.variables import BaseVariable
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import time_isoformat
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isas

# Generated at 2022-06-16 19:19:46.118916
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())

    assert f()[0] == __file__
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')



# Generated at 2022-06-16 19:19:57.903640
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED

    # Unit test for method __init__ of class Tracer
    def test_Tracer___init__():
        import sys
        import inspect
        import threading
        import functools
        import itertools
        import opcode
        import traceback
        import pycompat
        import datetime
        import os
        import utils
        import thread_global
        import get_path_and_source

# Generated at 2022-06-16 19:20:09.764522
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import pytest
    from . import utils
    with tempfile.TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, 'test.txt')
        file_writer = FileWriter(path, overwrite=True)
        file_writer.write('abc')
        with open(path, 'r') as f:
            assert f.read() == 'abc'
        file_writer.write('def')
        with open(path, 'r') as f:
            assert f.read() == 'abcdef'
        file_writer = FileWriter(path, overwrite=False)
        file_writer.write('ghi')
        with open(path, 'r') as f:
            assert f.read() == 'abcdefghi'
        file

# Generated at 2022-06-16 19:20:21.310686
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:32.571829
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import os
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:21:29.659054
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import datetime
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:21:33.565798
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert foo() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:21:43.444542
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import sys
    import io
    import datetime
    import threading
    import pysnooper
    import inspect
    import functools
    import os
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function


# Generated at 2022-06-16 19:21:55.654088
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import itertools
    import traceback
    import os
    import opcode
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:22:06.500512
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import os
    import inspect
    import functools
    import threading
    import pycompat
    import datetime
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global
    import pycompat
    import datetime_module
    import inspect
    import functools
    import threading
    import pycompat
    import datetime
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global
    import pycompat
    import datetime_module
    import inspect
    import functools
    import threading
    import pycompat
    import datetime
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global

# Generated at 2022-06-16 19:22:19.409146
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import inspect
    import threading
    import functools
    import datetime
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_write_function
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:22:31.676229
# Unit test for constructor of class Tracer

# Generated at 2022-06-16 19:22:35.993799
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.DISABLED
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.Tracer
    import pysnooper.snoop


# Generated at 2022-06-16 19:22:47.950000
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import datetime
    import threading
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_write_function
    import get_path_and_source_from_frame
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:22:56.608827
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import time
    import unittest
    import unittest.mock
    import warnings