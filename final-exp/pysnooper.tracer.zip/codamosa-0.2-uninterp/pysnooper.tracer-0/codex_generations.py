

# Generated at 2022-06-16 19:15:29.909895
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import pysnooper.utils
    import pysnooper.tracer
    import pysnooper.variable
    import pysnooper.common
    import pysnooper.exploding
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.threading
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.opcode
    import pysnooper.traceback
    import pysnooper.sys
    import pysnooper.DISABLED
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.utils
    import pysnooper.pycompat

# Generated at 2022-06-16 19:15:38.109948
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import functools
    import inspect
    import threading
    import datetime
    import pysnooper
    import pycompat
    import utils
    import opcode
    import traceback
    import thread_global
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:15:47.386370
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import os
    import threading
    import inspect
    import functools
    import pycompat
    import utils
    import opcode
    import traceback
    import datetime
    import pycompat
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:15:59.928768
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import pycompat
    import os
    import traceback
    import opcode
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import DISABLED
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:12.611659
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    from . import utils
    from . import pycompat
    from . import debugger
    from . import test_utils
    from . import test_utils_2
    from . import test_utils_3
    from . import test_utils_4
    from . import test_utils_5
    from . import test_utils_6
    from . import test_utils_7
    from . import test_utils_8
    from . import test_utils_9
    from . import test_utils_10
    from . import test_utils_11
    from . import test_utils_12
    from . import test_utils_13
    from . import test_utils_14
    from . import test_utils_15

# Generated at 2022-06-16 19:16:19.577186
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import types
    import unittest
    import unittest.mock
    import warnings
    import weakref
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.variable.common
    import pysnooper.variable.exploding
    import pysnooper.variable.base
    import pysnooper.variable.utils
    import pysnooper.variable.utils.utils
    import pysnooper.variable.utils.utils.pycompat
    import pysnooper.variable.utils.utils.pycompat.collections_abc
    import pysnooper.variable.utils.utils.pycompat.collections_abc.Iterable
   

# Generated at 2022-06-16 19:16:26.973743
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_write_function
    import DISABLED
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding

# Generated at 2022-06-16 19:16:31.662672
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:16:41.306248
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import itertools
    import traceback
    import utils
    import thread_global
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import get_write_function
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:16:52.689343
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:26.599901
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import pysnooper
    import inspect
    import threading
    import functools
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import os
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:17:36.657529
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return g()
    def g():
        return h()
    def h():
        return i()
    def i():
        return j()
    def j():
        return k()
    def k():
        return l()
    def l():
        return m()
    def m():
        return n()
    def n():
        return o()
    def o():
        return p()
    def p():
        return q()
    def q():
        return r()
    def r():
        return s()
    def s():
        return t()
    def t():
        return u()
    def u():
        return v()
    def v():
        return w()
    def w():
        return x()
    def x():
        return y()
    def y():
        return z()

# Generated at 2022-06-16 19:17:47.926885
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import collections
    import itertools
    import types
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.variable.base
    import pysnooper.variable.common
    import pysnooper.variable.exploding
    import pysnooper.variable.custom_repr
    import pysnooper.variable.custom_repr.datetime
    import pysnooper.variable.custom_repr.numpy
    import pysnooper.variable.custom_repr.pandas
    import pysnooper.variable.custom_

# Generated at 2022-06-16 19:18:00.442332
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import contextlib
    import pytest
    import six

    @contextlib.contextmanager
    def temp_file():
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_file_path = os.path.join(temp_dir, 'temp_file')
            yield temp_file_path

    def test_write_function(write_function, expected_output):
        with io.StringIO() as output:
            with contextlib.redirect_stdout(output):
                write_function('test')
            assert output.getvalue() == expected_output

    def test_write_function_with_overwrite(write_function, expected_output):
        with temp_file() as temp_file_path:
            write_function

# Generated at 2022-06-16 19:18:03.988321
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')



# Generated at 2022-06-16 19:18:11.852594
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import pycompat
    import opcode
    import os
    import utils
    import thread_global
    import pycompat
    import datetime_module
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import threading
    import inspect
    import functools
    import pycompat
    import utils
    import threading
    import sys
    import inspect
    import pycompat
    import datetime_module
    import os
    import utils
    import threading
    import sys
    import inspect
    import pycompat
    import datetime_module
   

# Generated at 2022-06-16 19:18:22.450689
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import unittest
    import unittest.mock
    import warnings
    import weakref
    from pysnooper.utils import (
        get_path_and_source_from_frame,
        get_shortish_repr,
        truncate,
    )
    from pysnooper.variables import (
        BaseVariable,
        CommonVariable,
        Exploding,
    )
    from pysnooper.watch import (
        get_local_reprs,
    )
    from pysnooper.writer import (
        get_write_function,
    )
    class TestTracer___exit__(unittest.TestCase):
        def setUp(self):
            self.snooper

# Generated at 2022-06-16 19:18:28.827071
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test that the constructor of class Tracer works
    tracer = Tracer()
    assert tracer.watch == []
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.custom_repr == ()
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False
    assert tracer.relative_time == False

    tracer = Tracer(watch='foo', watch_explode='bar', depth=2,
                    prefix='ZZZ ', overwrite=True, thread_info=True,
                    custom_repr=((int, lambda x: x + 1),),
                    max_variable_length=200, normalize=True, relative_time=True)

# Generated at 2022-06-16 19:18:37.217191
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import datetime
    import itertools
    import functools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:47.399272
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:19:41.994612
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import traceback
    import threading
    import itertools
    import opcode
    import pycompat
    import utils
    import datetime
    import os
    import threading
    import inspect
    import functools
    import traceback
    import threading
    import itertools
    import opcode
    import pycompat
    import utils
    import datetime
    import os
    import threading
    import inspect
    import functools
    import traceback
    import threading
    import itertools
    import opcode
    import pycompat
    import utils
    import datetime
    import os
    import threading
    import inspect
    import functools
    import traceback
    import threading
    import itertools
   

# Generated at 2022-06-16 19:19:54.805381
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import datetime
    import functools
    import inspect
    import threading
    import traceback
    import pycompat
    import opcode
    import pysnooper.utils as utils
    import pysnooper.pycompat as pycompat
    import pysnooper.thread_global as thread_global
    import pysnooper.get_write_function as get_write_function
    import pysnooper.get_path_and_source_from_frame as get_path_and_source_from_frame
    import pysnooper.get_local_reprs as get_local_reprs
    import pysnooper.BaseVariable as BaseVariable
    import pysnooper.CommonVariable as CommonVariable
    import pysnooper.Exploding as Exploding
    import pysno

# Generated at 2022-06-16 19:20:06.759478
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tracer = Tracer()
            self.tracer.write = unittest.mock.Mock()

        def test_trace_call(self):
            frame = unittest.mock.Mock()
            frame.f_code = unittest.mock.Mock()
            frame.f_code.co_filename = 'test_Tracer_trace.py'
            frame.f_code.co_name = 'test_trace_call'
            frame.f_code.co_firstlineno = 10
            frame.f_code.co_code = b'\x00'
            frame.f_lasti = 0

# Generated at 2022-06-16 19:20:15.066508
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import time
    import datetime
    import io
    import contextlib
    import sys
    import os
    import shutil
    import tempfile
    import pytest
    import os.path
    import time
    import datetime
    import io
    import contextlib
    import sys
    import os
    import shutil
    import tempfile
    import pytest
    import os.path
    import time
    import datetime
    import io
    import contextlib
    import sys
    import os
    import shutil
    import tempfile
    import pytest
    import os.path
    import time
    import datetime
    import io
    import contextlib
    import sys
    import os
    import shut

# Generated at 2022-06-16 19:20:25.364407
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import contextlib
    import functools
    import inspect
    import threading
    import datetime
    import itertools
    import traceback
    import pycompat
    import opcode
    import utils
    import thread_global
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:32.935582
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == inspect.getfile(test_get_path_and_source_from_frame)
    assert source[inspect.getsourcelines(test_get_path_and_source_from_frame)[1]] == '    path, source = get_path_and_source_from_frame(frame)'



# Generated at 2022-06-16 19:20:44.192228
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys

    def test_write_function(write_function, expected_output):
        output = io.StringIO()
        write_function(output)
        assert output.getvalue() == expected_output

    test_write_function(get_write_function(None, False), 'hello')
    test_write_function(get_write_function(io.StringIO(), False), 'hello')
    test_write_function(get_write_function(lambda s: s.write('hello'), False),
                        'hello')

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-16 19:20:53.732773
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = x + 1
        return y
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    assert get_local_reprs(frame) == {'x': '1', 'y': '2'}
    assert get_local_reprs(frame, watch=[CommonVariable('x')]) == {'x': '1', 'y': '2'}
    assert get_local_reprs(frame, watch=[CommonVariable('x'), CommonVariable('y')]) == {'x': '1', 'y': '2'}

# Generated at 2022-06-16 19:21:05.447437
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import sys
    import io
    import pytest
    import contextlib
    import shutil
    import os.path
    import six
    import six.moves
    import six.moves.builtins

    def test_write(output, expected_output, expected_output_path=None,
                   expected_output_content=None, overwrite=False):
        write = get_write_function(output, overwrite)
        write('Hello world!')
        if expected_output is not None:
            assert expected_output == 'Hello world!'
        if expected_output_path is not None:
            assert os.path.isfile(expected_output_path)
            with open(expected_output_path, 'rb') as f:
                assert f.read() == expected_output_content

# Generated at 2022-06-16 19:21:16.685751
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import pytest
    import pysnooper
    import threading
    import time
    import datetime
    import inspect
    import functools
    import pycompat
    import utils
    import opcode
    import traceback
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:22:45.947283
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')
    assert f()[1][1].startswith('    def f():')
    assert f()[1][2].startswith('        return get_path_and_source_from_frame(inspect.currentframe())')
    assert f()[1][3].startswith('    assert f()[0].endswith(\'test_get_path_and_source_from_frame.py\')')

# Generated at 2022-06-16 19:22:51.159745
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test the method trace of class Tracer
    # Arrange
    tracer = Tracer()
    frame = inspect.currentframe()
    event = 'call'
    arg = None
    # Act
    result = tracer.trace(frame, event, arg)
    # Assert
    assert result == tracer.trace


# Generated at 2022-06-16 19:22:58.176439
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import random
    import string
    import sys
    import pytest
    import os.path
    import pycompat
    import six
    import time
    import datetime
    import random
    import string
    import sys
    import pytest
    import os.path
    import pycompat
    import six
    import time
    import datetime
    import random
    import string
    import sys
    import pytest
    import os.path
    import pycompat
    import six
    import time
    import datetime
    import random
    import string
    import sys
    import pytest
    import os.path
    import pycompat
    import six
    import time
    import datetime
    import random
    import string
    import sys
   

# Generated at 2022-06-16 19:23:02.577978
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][1].startswith('def f():')



# Generated at 2022-06-16 19:23:12.827020
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.utils import DISABLED
    from pysnooper.utils import thread_global
    from pysnooper.utils import datetime_module
    from pysnooper.utils import inspect
    from pysnooper.utils import functools
    from pysnooper.utils import os
    from pysnooper.utils import opcode
    from pysnooper.utils import traceback
    from pysnooper.utils import itertools
    from pysnooper.utils import CommonVariable
    from pysnooper.utils import BaseVariable

# Generated at 2022-06-16 19:23:22.044671
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:23:31.793451
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import sys
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import sys
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os
    import inspect


# Generated at 2022-06-16 19:23:43.498954
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:23:52.686868
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass

    def bar():
        pass

    def baz():
        pass

    def qux():
        pass

    def quux():
        pass

    def coroutine():
        yield

    def generator():
        yield

    def async_generator():
        yield

    def test_function():
        foo()
        bar()
        baz()
        qux()
        quux()

    def test_function_with_depth():
        foo()
        bar()
        baz()
        qux()
        quux()

    def test_function_with_depth_and_watch():
        foo()
        bar()
        baz()
        qux()
        quux()

    def test_function_with_depth_and_watch_explode():
        foo()
        bar()


# Generated at 2022-06-16 19:24:03.948810
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_default_watch(self):
            self.assertEqual(self.snooper.watch, [])

        def test_default_watch_explode(self):
            self.assertEqual(self.snooper.watch_explode, [])

        def test_default_depth(self):
            self.assertEqual(self.snooper.depth, 1)

        def test_default_prefix(self):
            self.assertEqual(self.snooper.prefix, '')
