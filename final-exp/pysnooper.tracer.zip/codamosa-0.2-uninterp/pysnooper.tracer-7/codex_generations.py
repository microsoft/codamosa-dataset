

# Generated at 2022-06-16 19:16:08.933502
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import sys
    import inspect
    import threading
    import functools
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:16:17.342258
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:16:27.649651
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    from . import utils

    def write_to_stderr(s):
        sys.stderr.write(s)

    def write_to_stdout(s):
        sys.stdout.write(s)

    def write_to_file(s):
        with open(tempfile.mktemp(), 'w') as f:
            f.write(s)

    def write_to_file_with_overwrite(s):
        with open(tempfile.mktemp(), 'w') as f:
            f.write(s)


# Generated at 2022-06-16 19:16:38.334117
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import opcode
    import traceback
    import itertools
    import datetime
    import pysnooper
    import utils
    import pycompat
    import thread_global
    import pycompat
    import inspect
    import functools
    import threading
    import opcode
    import traceback
    import itertools
    import datetime
    import pysnooper
    import utils
    import pycompat
    import thread_global
    import pycompat
    import inspect
    import functools
    import threading
    import opcode
    import traceback
    import itertools
    import datetime
    import pysnooper
    import utils
    import pycompat

# Generated at 2022-06-16 19:16:50.258458
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import os.path
    import shutil
    import sys
    import time
    import datetime
    import pytest
    import pycompat
    import time
    import datetime
    import pytest
    import pycompat
    import time
    import datetime
    import pytest
    import pycompat
    import time
    import datetime
    import pytest
    import pycompat
    import time
    import datetime
    import pytest
    import pycompat
    import time
    import datetime
    import pytest
    import pycompat
    import time
    import datetime
    import pytest
    import pycompat
    import time
    import datetime
    import pytest
    import pycompat
    import time
    import datetime
    import pytest
   

# Generated at 2022-06-16 19:17:00.594462
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_output(self):
            @self.snooper
            def foo(x):
                return x

            foo(1)
            self.assertIn('Return value:.. 1', self.output.getvalue())

        def test_watch(self):
            @self.snooper(watch=('x',))
            def foo(x):
                return x

            foo(1)
            self.assertIn('New var:....... x = 1', self.output.getvalue())


# Generated at 2022-06-16 19:17:05.756237
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = sys._getframe(0)
    frame.f_globals['__name__'] = '__main__'
    frame.f_code.co_filename = __file__
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:17:17.170407
# Unit test for method trace of class Tracer

# Generated at 2022-06-16 19:17:28.664377
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import sys
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:17:38.467356
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile
    import types

    def get_frame():
        return inspect.currentframe()

    def get_source_from_frame(frame):
        return get_path_and_source_from_frame(frame)[1]

    def get_source_from_function(function):
        return get_source_from_frame(function.__code__.co_firstlineno)

    def get_source_from_code(code):
        return get_source_from_frame(code.co_firstlineno)

    def get_source_from_module(module):
        return get_source_from_frame(module.__file__)

    def get_source_from_file(file_name):
        return get_source_from_frame(file_name)


# Generated at 2022-06-16 19:18:15.392324
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_write_function
    import get_path_and_source_from_frame
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:18:24.840929
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import BaseVariable
    import CommonVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:35.015519
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())

# Generated at 2022-06-16 19:18:46.088591
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import pycompat
    import opcode
    import itertools
    import traceback
    import os
    import utils
    import pycompat
    import thread_global
    import datetime_module
    import inspect
    import functools
    import pycompat
    import opcode
    import itertools
    import traceback
    import os
    import utils
    import pycompat
    import thread_global
    import datetime_module
    import inspect
    import functools
    import pycompat
    import opcode
    import itertools
    import traceback
    import os
    import utils
    import pycompat
    import thread_global
    import datetime_module
    import inspect
   

# Generated at 2022-06-16 19:18:50.782108
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper

# Generated at 2022-06-16 19:18:52.447451
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with Tracer() as tracer:
        pass


# Generated at 2022-06-16 19:18:56.773247
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())



# Generated at 2022-06-16 19:19:03.954796
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    from . import utils
    from . import pycompat
    from . import thread_global
    from . import opcode
    from . import inspect
    from . import functools
    from . import threading
    from . import datetime
    from . import os
    from . import traceback
    from . import itertools
    from . import utils
    from . import pycompat
    from . import thread_global
    from . import opcode
    from . import inspect
    from . import functools
    from . import threading
    from . import datetime


# Generated at 2022-06-16 19:19:16.287887
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:19:26.074520
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import os
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import CommonVariable
    import BaseVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:20:25.445749
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import datetime_module
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:20:33.209620
# Unit test for constructor of class Tracer
def test_Tracer():
    # pylint: disable=unused-variable
    @snoop(watch=('a', 'b'))
    def foo(a, b):
        return a + b

    @snoop(watch=('a', 'b'), watch_explode=('a', 'b'))
    def bar(a, b):
        return a + b

    @snoop(watch=('a', 'b'), watch_explode=('a', 'b'), depth=2)
    def baz(a, b):
        return a + b

    @snoop(watch=('a', 'b'), watch_explode=('a', 'b'), depth=2, prefix='ZZZ ')
    def qux(a, b):
        return a + b


# Generated at 2022-06-16 19:20:44.386147
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import datetime
    import pysnooper
    import pycompat
    import utils
    import thread_global
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import datetime
    import pysnooper
    import pycompat
    import utils
    import thread_global
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import datetime
    import pysnooper
    import pycompat
    import utils

# Generated at 2022-06-16 19:20:51.236241
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'
    assert source[-1] == 'test_get_path_and_source_from_frame()'
    del frame
test_get_path_and_source_from_frame()



# Generated at 2022-06-16 19:21:03.331820
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import contextlib
    import pytest
    import sys
    import io
    import tempfile
    import os
    import shutil
    import sys
    import contextlib
    import pytest
    import sys
    import io
    import tempfile
    import os
    import shutil
    import sys
    import contextlib
    import pytest
    import sys
    import io
    import tempfile
    import os
    import shutil
    import sys
    import contextlib
    import pytest
    import sys
    import io
    import tempfile
    import os
    import shutil
    import sys
    import contextlib
    import pytest
    import sys
    import io
    import tempfile
    import os
    import shutil
   

# Generated at 2022-06-16 19:21:15.330307
# Unit test for constructor of class Tracer
def test_Tracer():
    output = io.StringIO()
    tracer = Tracer(output, watch=('foo', 'bar'), watch_explode=('self', 'baz'),
                    depth=2, prefix='ZZZ ', overwrite=True, thread_info=True,
                    custom_repr=((type1, custom_repr_func1),
                                 (condition2, custom_repr_func2), ...),
                    max_variable_length=100, normalize=False,
                    relative_time=False)
    assert tracer._write == output.write
    assert tracer.watch == [CommonVariable('foo'), CommonVariable('bar'),
                            Exploding('self'), Exploding('baz')]
    assert tracer.depth == 2
    assert tracer.prefix == 'ZZZ '
    assert tracer.thread_info == True
    assert tr

# Generated at 2022-06-16 19:21:27.878346
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import datetime
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED


# Generated at 2022-06-16 19:21:39.617496
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
   

# Generated at 2022-06-16 19:21:49.091879
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pysnooper
    import sys
    import threading
    import types
    import unittest

    class Tracer___enter__TestCase(unittest.TestCase):
        def test_it(self):
            import pysnooper
            import sys
            import threading
            import types
            import unittest

            class Tracer___enter__TestCase(unittest.TestCase):
                def test_it(self):
                    # TODO: Implement test
                    pass

            unittest.main()

        def test_it(self):
            # TODO: Implement test
            pass

    unittest.main()


# Generated at 2022-06-16 19:22:01.816511
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import os
    import sys
    import tempfile
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
   

# Generated at 2022-06-16 19:24:18.489860
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.variable import get_local_reprs
    from pysnooper.variable import get_path_and_source_from_frame
    from pysnooper.variable import utils
    from pysnooper.variable import pycompat
    from pysnooper.variable import threading
    from pysnooper.variable import inspect
    from pysnooper.variable import functools
    from pysnooper.variable import datetime_module
    from pysnooper.variable import os

# Generated at 2022-06-16 19:24:28.649492
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False)
    assert get_write_function(sys.stdout, False)
    assert get_write_function(sys.stderr, False)
    assert get_write_function(sys.stdout.buffer, False)
    assert get_write_function(sys.stderr.buffer, False)
    assert get_write_function(utils.WritableStream(sys.stdout), False)
    assert get_write_function(utils.WritableStream(sys.stderr), False)
    assert get_write_function(utils.WritableStream(sys.stdout.buffer), False)
    assert get_write_function(utils.WritableStream(sys.stderr.buffer), False)
    assert get_write_function(utils.WritableStream(sys.stdout), False)
