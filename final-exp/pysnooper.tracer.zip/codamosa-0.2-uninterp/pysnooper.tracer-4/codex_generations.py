

# Generated at 2022-06-16 19:15:24.623389
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import six
    import pathlib
    import subprocess
    import contextlib
    import time

    def get_file_contents(path):
        with open(path, 'rb') as f:
            return f.read().decode('utf-8')

    def get_file_contents_and_delete(path):
        result = get_file_contents(path)
        os.remove(path)
        return result

    def get_file_contents_and_delete_with_pathlib(path):
        result = get_file_contents(str(path))
        path.unlink()
        return result


# Generated at 2022-06-16 19:15:35.428887
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:15:46.207893
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import threading
    import traceback
    import functools
    import inspect
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.Tracer

# Generated at 2022-06-16 19:15:49.936314
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert foo() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:16:02.012635
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:16:14.089173
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import threading
    import time
    import traceback
    import datetime
    import functools
    import inspect
    import itertools
    import pycompat
    import opcode
    import utils
    import thread_global
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:16:20.424456
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.tracer
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.datetime_module
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.get_write_function
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
   

# Generated at 2022-06-16 19:16:27.829327
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import itertools
    import os
    import utils
    import pycompat
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:33.437319
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (
        __file__,
        inspect.getsource(test_get_path_and_source_from_frame).splitlines()
    )
test_get_path_and_source_from_frame()



# Generated at 2022-06-16 19:16:41.492479
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = x + 1
        z = y + 2
        return z
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    assert get_local_reprs(frame) == {'x': '1', 'y': '2', 'z': '4'}
    assert get_local_reprs(frame, watch=[CommonVariable('z')]) == {'z': '4'}
    assert get_local_reprs(frame, watch=[CommonVariable('z')],
                           custom_repr={int: lambda x: x + 1}) == {'z': '5'}

# Generated at 2022-06-16 19:17:17.487399
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path

# Generated at 2022-06-16 19:17:28.898659
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_write_function
    import get_path_and_source_from_frame
    import get_local_reprs
    import DISABLED
    import threading
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_

# Generated at 2022-06-16 19:17:34.452701
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.variables import CommonVariable
    from pysnooper.variables import Exploding
    from pysnooper.variables import BaseVariable
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import time_isoformat
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isasyncgenfunction

# Generated at 2022-06-16 19:17:37.642990
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     inspect.getsourcelines(
                                                         test_get_path_and_source_from_frame)[0])



# Generated at 2022-06-16 19:17:49.001077
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import os
    import threading
    import inspect
    import functools
    import datetime
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:01.294001
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import os.path
    import time
    import datetime
    import pytest
    import os
    import sys
    import os.path
    import time
    import datetime
    import pytest
    import os
    import sys
    import os.path
    import time
    import datetime
    import pytest
    import os
    import sys
    import os.path
    import time
    import datetime
    import pytest
    import os
    import sys
    import os.path
    import time
    import datetime
    import pytest
    import os
    import sys
    import os.path
    import time
    import datetime
    import pytest
    import os
    import sys
    import os.path
    import time
    import dat

# Generated at 2022-06-16 19:18:14.081711
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile
    import textwrap
    import tokenize

    def get_source_from_frame(frame):
        return get_path_and_source_from_frame(frame)[1]

    # Test that we can get the source from a file
    source = textwrap.dedent('''
        def foo():
            return 'bar'
    ''')
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
        f.write(source)

# Generated at 2022-06-16 19:18:24.269871
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import threading
    import time
    import random
    import pycompat
    import pycompat.collections_abc
    import pycompat.functools
    import pycompat.inspect
    import pycompat.itertools
    import pycompat.os
    import pycompat.sys
    import pycompat.threading
    import pycompat.time
    import pycompat.types
    import pycompat.unittest
    import pycompat.unittest.mock
    import pycompat.weakref
    import pycompat.weakref.ref
    import pycompat.weakref.proxy
    import pycompat.weakref.weakref
    import pycompat.weakref.weakproxy
    import py

# Generated at 2022-06-16 19:18:27.081420
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(watch=('foo', 'bar')):
        foo = 'foo'
        bar = 'bar'
        baz = 'baz'


# Generated at 2022-06-16 19:18:36.447180
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isasyncgenfunction
    from pysnooper.utils import isgeneratorfunction
    from pysnooper.utils import BaseVariable
    from pysnooper.utils import CommonVariable
    from pysnooper.utils import Exploding
    from pysnooper.utils import DISABLED
   

# Generated at 2022-06-16 19:19:04.531041
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    def foo():
        pass
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     inspect.getsourcelines(foo)[0])



# Generated at 2022-06-16 19:19:11.400114
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import six
    import pathlib

    def write_to_file(s):
        with open(temp_file_path, 'w') as f:
            f.write(s)

    def write_to_file_pathlib(s):
        with open(temp_file_path_pathlib, 'w') as f:
            f.write(s)

    def write_to_stream(s):
        stream.write(s)

    def write_to_stream_pathlib(s):
        stream_pathlib.write(s)

    def write_to_stream_pathlib_text(s):
        stream_pathlib_text.write(s)


# Generated at 2022-06-16 19:19:22.666029
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import datetime
    import threading
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import os
    import datetime_module
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:19:34.239055
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return 1
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())
    assert get_path_and_source_from_frame

# Generated at 2022-06-16 19:19:44.173034
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return g()
    def g():
        return h()
    def h():
        return i()
    def i():
        return j()
    def j():
        return k()
    def k():
        return l()
    def l():
        return m()
    def m():
        return n()
    def n():
        return o()
    def o():
        return p()
    def p():
        return q()
    def q():
        return r()
    def r():
        return s()
    def s():
        return t()
    def t():
        return u()
    def u():
        return v()
    def v():
        return w()
    def w():
        return x()
    def x():
        return y()
    def y():
        return z()

# Generated at 2022-06-16 19:19:56.269739
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import sys
    import pytest
    import os.path
    import pycompat
    import datetime
    import time
    import sys
    import os
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import sys
    import os
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import sys
    import os
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import sys
    import os
    import re
    import collections
    import datetime as datetime_module

# Generated at 2022-06-16 19:20:00.947737
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        pass
    frame = test_function.__code__.co_filename
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     UnavailableSource())



# Generated at 2022-06-16 19:20:11.623605
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DIS

# Generated at 2022-06-16 19:20:24.927059
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable


# Generated at 2022-06-16 19:20:37.309034
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:21:15.332694
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import sys
    import io
    import shutil
    import contextlib
    import sys
    import pytest
    import six
    import pathlib
    import io

    @contextlib.contextmanager
    def temp_dir():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)

    def test_write_function(write_function, expected_output):
        with io.StringIO() as output:
            with contextlib.redirect_stdout(output):
                write_function('hello')
            assert output.getvalue() == expected_output


# Generated at 2022-06-16 19:21:27.882024
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import datetime
    import threading
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global

# Generated at 2022-06-16 19:21:39.618755
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.variable import BaseVariable
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import time_isoformat
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isasyncgenfunction

# Generated at 2022-06-16 19:21:51.777533
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    from io import StringIO
    from pysnooper import snoop
    import threading
    import time
    import datetime
    import os
    import pycompat
    import inspect
    import functools
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import pycompat
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import utils
    import pycompat
    import datetime_module
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:22:03.874304
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    from pysnooper import snoop
    from pysnooper.utils import get_write_function
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isasyncgenfunction
    from pysnooper.utils import isgeneratorfunction
    from pysnooper.utils import time_isoformat
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import BaseVariable
    from pysnooper.utils import CommonVariable
    from pysnooper.utils import Exploding

# Generated at 2022-06-16 19:22:10.981936
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:22:22.001403
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import types
    import unittest
    import unittest.mock
    import warnings
    import weakref
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable
    import pysnooper.variable

# Generated at 2022-06-16 19:22:33.795330
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import threading
    import time
    import random
    import functools
    import inspect
    import traceback
    import datetime
    import itertools
    import pycompat
    import opcode
    import functools
    import inspect
    import threading
    import traceback
    import datetime
    import itertools
    import pycompat
    import opcode
    import functools
    import inspect
    import threading
    import traceback
    import datetime
    import itertools
    import pycompat
    import opcode
    import functools
    import inspect
    import threading
    import traceback
    import datetime
    import itertools
    import pycompat
    import opcode
    import functools

# Generated at 2022-06-16 19:22:40.626812
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import pysnooper
    import pycompat
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import utils
    import pycompat
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:22:51.285575
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import threading
    import time
    import random
    import traceback
    import functools
    import inspect
    import pycompat
    import datetime
    import pysnooper
    import utils
    import opcode
    import pycompat
    import thread_global
    import pycompat
    import datetime_module
    import pycompat
    import utils
    import opcode
    import pycompat
    import thread_global
    import pycompat
    import datetime_module
    import pycompat
    import utils
    import opcode
    import pycompat
    import thread_global
    import pycompat
    import datetime_module
    import pycompat
    import utils

# Generated at 2022-06-16 19:24:16.437247
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import get_write_function
    import DISABLED
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding

# Generated at 2022-06-16 19:24:26.798585
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import threading
    import itertools
    import opcode
    import functools
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import inspect
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import inspect
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import inspect
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import inspect
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import inspect
    import pycompat
    import utils
    import thread_global
    import dat