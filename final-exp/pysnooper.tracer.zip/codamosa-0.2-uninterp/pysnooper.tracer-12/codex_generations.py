

# Generated at 2022-06-16 19:15:41.068557
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__, source_lines)
source_lines = get_path_and_source_from_frame(sys._getframe())[1]



# Generated at 2022-06-16 19:15:44.084024
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename
    assert get_path_and_source_from_frame(frame) == (__file__, UnavailableSource())



# Generated at 2022-06-16 19:15:57.205570
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import datetime
    import os
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import itertools
    import collections
    import types
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.datetime_module
    import pysnooper.threading
    import pysnooper.os
    import pysnooper.traceback
    import pysnooper.itertools
    import pysnooper.types
    import pysnooper.collections
    import pysnooper.pycompat
   

# Generated at 2022-06-16 19:16:10.437318
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import sys
    import os
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils


# Generated at 2022-06-16 19:16:18.197327
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        ab = 28
        ac = 29
        ad = 30
        ae = 31
        af = 32
        ag = 33
        ah = 34
        ai = 35
        aj = 36
        ak = 37
        al = 38


# Generated at 2022-06-16 19:16:19.532151
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test for the method trace of class Tracer
    # Arrange
    # Act
    # Assert
    pass

# Generated at 2022-06-16 19:16:30.914311
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y, z):
        a = 1
        b = 2
        c = 3
        return a + b + c
    frame = inspect.currentframe()
    frame = frame.f_back
    assert get_local_reprs(frame) == {'x': '1', 'y': '2', 'z': '3', 'a': '1',
                                      'b': '2', 'c': '3'}
    assert get_local_reprs(frame, watch=[CommonVariable('a')]) == {'x': '1',
                                                                  'y': '2',
                                                                  'z': '3',
                                                                  'a': '1',
                                                                  'b': '2',
                                                                  'c': '3'}
    assert get_local_re

# Generated at 2022-06-16 19:16:39.974312
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import traceback
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:16:51.190183
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import datetime_module
    import utils
    import thread_global
    import DISABLED
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_write_function
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:01.416129
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import os
    import tempfile
    import shutil
    import sys
    import pytest
    import pathlib
    from . import utils
    from .utils import WritableStream
    from . import pycompat

    def test_write(output, overwrite, expected_output):
        write = get_write_function(output, overwrite)
        write('hello')
        if isinstance(output, (pycompat.PathLike, str)):
            with open(output, 'r') as f:
                assert f.read() == expected_output
        elif output is None:
            assert sys.stderr.getvalue() == expected_output
        elif callable(output):
            assert output.getvalue() == expected_output
        else:
            assert output.getvalue() == expected_output


# Generated at 2022-06-16 19:17:30.228308
# Unit test for constructor of class Tracer
def test_Tracer():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_output():
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    with capture_output() as output:
        with Tracer(watch=('a', 'b')):
            a = 1
            b = 2
            c = 3
            print('hello')
            print('world')

    assert output.getvalue() == '''\
New var:....... a = 1
New var:....... b = 2
hello
world
'''


# Generated at 2022-06-16 19:17:38.790713
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    import io
    import os
    import tempfile
    import sys
    import pytest
    import os.path
    import shutil
    import time
    import pycompat
    import re
    import contextlib
    import sys
    import io
    import os
    import tempfile
    import pytest
    import os.path
    import shutil
    import time
    import pycompat
    import re
    import contextlib
    import sys
    import io
    import os
    import tempfile
    import pytest
    import os.path
    import shutil
    import time
    import pycompat
    import re
    import contextlib
    import sys
    import io
    import os
    import tempfile
    import pytest
    import os.path
    import shutil
    import time

# Generated at 2022-06-16 19:17:49.794835
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.utils import threading
    from pysnooper.utils import inspect
    from pysnooper.utils import functools
    from pysnooper.utils import datetime_module
    from pysnooper.utils import os
    from pysnooper.utils import opcode
    from pysnooper.utils import traceback
    from pysnooper.utils import DISABLED
    from pysnooper.utils import thread_global
    from pysnooper.utils import BaseVariable
    from pysnooper.utils import CommonVariable

# Generated at 2022-06-16 19:18:01.671170
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import contextlib
    import sys
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import contextlib
    import sys
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import contextlib
    import sys
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import contextlib
    import sys
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest

# Generated at 2022-06-16 19:18:14.221347
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    from .utils import WritableStream
    import sys
    import io
    import os
    import tempfile
    import pytest
    import contextlib
    import shutil
    import os.path
    import six
    import pathlib

    @contextlib.contextmanager
    def temp_dir():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)

    def test_write_function(output, expected_output, expected_output_type,
                            overwrite=False):
        write = get_write_function(output, overwrite)
        assert callable(write)
        write('test')
        if expected_output_type == 'file':
            assert os.path.isfile(expected_output)

# Generated at 2022-06-16 19:18:24.265779
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
   

# Generated at 2022-06-16 19:18:25.661726
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test that Tracer() works
    Tracer()


# Generated at 2022-06-16 19:18:29.178826
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert foo() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:18:32.142768
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:18:39.130574
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    import sys
    import unittest
    import unittest.mock

    class TracerTest(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.tracer = Tracer(output=self.output)

        def test_trace_call(self):
            def function():
                pass

            frame = utils.make_fake_frame(function)
            self.tracer.trace(frame, 'call', None)
            self.assertEqual(self.output.getvalue(),
                             '    Call:....... 1     def function():\n')

        def test_trace_return(self):
            def function():
                pass

            frame = utils.make_fake_frame(function)

# Generated at 2022-06-16 19:19:27.169201
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import pycompat
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:19:38.764329
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.tracer = Tracer(output=self.output)

        def test_default_values(self):
            self.assertEqual(self.tracer.watch, [])
            self.assertEqual(self.tracer.depth, 1)
            self.assertEqual(self.tracer.prefix, '')
            self.assertEqual(self.tracer.thread_info, False)
            self.assertEqual(self.tracer.custom_repr, ())
            self.assertEqual(self.tracer.max_variable_length, 100)

# Generated at 2022-06-16 19:19:51.413936
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import unittest
    import unittest.mock
    import warnings

    class TestTracer___exit__(unittest.TestCase):
        def setUp(self):
            self.tracer = pysnooper.Snooper(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
            self.tracer._write = unittest.mock.Mock()
            self.tracer.target_codes = set()
            self.tracer.target_frames = set()
            self.tracer.thread_local = threading.local

# Generated at 2022-06-16 19:20:03.528214
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global

# Generated at 2022-06-16 19:20:09.982725
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import sys
    import io
    import shutil
    import contextlib
    import six
    import pytest
    import os.path
    import pathlib
    import sys
    import io
    import six
    import pytest
    import os.path
    import pathlib
    import sys
    import io
    import six
    import pytest
    import os.path
    import pathlib
    import sys
    import io
    import six
    import pytest
    import os.path
    import pathlib
    import sys
    import io
    import six
    import pytest
    import os.path
    import pathlib
    import sys
    import io
    import six
    import pytest
    import os.path
    import pathlib
    import sys
    import io
    import six


# Generated at 2022-06-16 19:20:21.715865
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import pysnooper
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:20:30.456897
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:43.206030
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import sys
    import traceback
    import itertools
    import opcode
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import sys
    import traceback
    import itertools
    import opcode
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat

# Generated at 2022-06-16 19:20:48.283575
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test for watch
    @pysnooper.snoop(watch=('foo', 'bar'))
    def foo(a, b):
        return a + b

    # Test for watch_explode
    @pysnooper.snoop(watch_explode=('foo', 'bar'))
    def foo(a, b):
        return a + b

    # Test for depth
    @pysnooper.snoop(depth=2)
    def foo(a, b):
        return a + b

    # Test for prefix
    @pysnooper.snoop(prefix='ZZZ ')
    def foo(a, b):
        return a + b

    # Test for thread_info

# Generated at 2022-06-16 19:20:55.297459
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """
    Test for method trace of class Tracer
    """
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of class Tracer
    # Test for method trace of

# Generated at 2022-06-16 19:21:39.718735
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__, UnavailableSource())
    assert get_path_and_source_from_frame(frame) is get_path_and_source_from_frame(frame)
    assert get_path_and_source_from_frame(frame) is not get_path_and_source_from_frame(frame)



# Generated at 2022-06-16 19:21:44.783244
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:21:57.625859
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools

# Generated at 2022-06-16 19:22:07.571876
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import unittest.mock
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import utils
    import opcode
    import traceback
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:22:19.756532
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import io
    import unittest
    import unittest.mock
    import pysnooper

    class TestTracerTrace(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.tracer = pysnooper.Snooper(self.output)
            self.frame = unittest.mock.Mock()
            self.frame.f_code = unittest.mock.Mock()
            self.frame.f_code.co_filename = 'test.py'

# Generated at 2022-06-16 19:22:31.779843
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest
    import unittest.mock

    class TracerTest(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.tracer = Tracer(output=self.output)

        def test_output(self):
            self.assertEqual(self.tracer._write, self.output.write)

        def test_watch(self):
            self.assertEqual(self.tracer.watch, [])

        def test_watch_explode(self):
            self.assertEqual(self.tracer.watch_explode, [])

        def test_depth(self):
            self.assertEqual(self.tracer.depth, 1)


# Generated at 2022-06-16 19:22:35.951559
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return 1
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())



# Generated at 2022-06-16 19:22:41.907976
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')



# Generated at 2022-06-16 19:22:52.387076
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:23:03.071703
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import sys
    import threading
    import inspect
    import functools
    import datetime
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.pycompat
    import pysnooper.DISABLED
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysno