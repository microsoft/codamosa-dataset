

# Generated at 2022-06-16 19:15:26.876884
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import shutil
    import io
    import sys
    import pytest
    import six
    import pathlib
    import contextlib
    import six
    import io
    import sys
    import os
    import tempfile
    import shutil
    import pathlib
    import contextlib
    import pytest
    import six
    import io
    import sys
    import os
    import tempfile
    import shutil
    import pathlib
    import contextlib
    import pytest
    import six
    import io
    import sys
    import os
    import tempfile
    import shutil
    import pathlib
    import contextlib
    import pytest
    import six
    import io
    import sys
    import os
    import tempfile
    import shutil
    import pathlib
    import contextlib

# Generated at 2022-06-16 19:15:36.422600
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import datetime
    import functools
    import inspect
    import threading
    import traceback
    import pycompat
    import opcode
    import pysnooper.utils as utils
    import pysnooper.pycompat as pycompat
    import pysnooper.thread_global as thread_global
    import pysnooper.get_write_function as get_write_function
    import pysnooper.get_path_and_source_from_frame as get_path_and_source_from_frame
    import pysnooper.get_local_reprs as get_local_reprs
    import pysnooper.BaseVariable as BaseVariable
    import pysnooper.CommonVariable as CommonVariable
    import pysnooper.Exploding as Exploding
   

# Generated at 2022-06-16 19:15:47.352452
# Unit test for method trace of class Tracer

# Generated at 2022-06-16 19:15:59.927998
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import datetime
    import threading
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
   

# Generated at 2022-06-16 19:16:04.314416
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     inspect.getsourcelines(
                                                         test_get_path_and_source_from_frame)[0])



# Generated at 2022-06-16 19:16:15.470226
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import functools
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:21.805387
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import os
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:16:22.941297
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-16 19:16:29.534970
# Unit test for constructor of class Tracer
def test_Tracer():
    def test_function():
        pass

    # Test that the constructor works with no arguments
    Tracer()

    # Test that the constructor works with all arguments
    Tracer(output=sys.stdout, watch=('foo',), watch_explode=('bar',),
           depth=2, prefix='ZZZ ', overwrite=True, thread_info=True,
           custom_repr=((type(None), lambda x: 'None'),),
           max_variable_length=200, normalize=True, relative_time=True)

    # Test that the constructor works with all arguments, but with
    # watch and watch_explode as strings instead of tuples

# Generated at 2022-06-16 19:16:39.193056
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass
    def bar():
        pass
    def baz():
        pass
    def qux():
        pass

    def test_watch():
        with Tracer(watch=('foo', 'bar')):
            foo = 1
            bar = 2
            baz = 3
            qux = 4

    def test_watch_explode():
        with Tracer(watch_explode=('foo', 'bar')):
            foo = [1, 2, 3]
            bar = {'a': 1, 'b': 2}
            baz = 3
            qux = 4

    def test_depth():
        with Tracer(depth=2):
            foo()
            bar()
            baz()
            qux()


# Generated at 2022-06-16 19:17:15.697311
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper import snoop
    import sys
    import os
    import inspect
    import threading
    import itertools
    import opcode
    import traceback
    import functools
    import pycompat
    import datetime
    import datetime_module
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:17:27.588038
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        ab = 28
        ac = 29
        ad = 30
        ae = 31
        af = 32
        ag = 33
        ah = 34
        ai = 35
        aj = 36
        ak = 37
        al = 38


# Generated at 2022-06-16 19:17:37.581623
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:17:48.876840
# Unit test for constructor of class Tracer

# Generated at 2022-06-16 19:17:57.736686
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__, source)
source = get_path_and_source_from_frame(test_get_path_and_source_from_frame.__code__.co_filename,
                                        test_get_path_and_source_from_frame.__code__.co_firstlineno)[1]



# Generated at 2022-06-16 19:18:06.041866
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import types
    import unittest
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.variables import CommonVariable, Exploding
    from pysnooper.variables import BaseVariable
    from pysnooper.variables import get_local_reprs
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.utils import DISABLED
    from pysnooper.utils import get_write_function
    from pysnooper.utils import opcode
    from pysnooper.utils import thread_global
    from pysnooper.utils import datetime_module

# Generated at 2022-06-16 19:18:17.006561
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:25.789311
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools

# Generated at 2022-06-16 19:18:35.651259
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
   

# Generated at 2022-06-16 19:18:41.596564
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return 1
    frame = inspect.currentframe()
    frame = frame.f_back
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[frame.f_lineno - 1].strip() == 'def f():'



# Generated at 2022-06-16 19:19:31.441685
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test for watch
    tracer = Tracer(watch=('foo', 'bar'))
    assert len(tracer.watch) == 2
    assert isinstance(tracer.watch[0], CommonVariable)
    assert isinstance(tracer.watch[1], CommonVariable)
    assert tracer.watch[0].name == 'foo'
    assert tracer.watch[1].name == 'bar'

    # Test for watch_explode
    tracer = Tracer(watch_explode=('foo', 'bar'))
    assert len(tracer.watch) == 2
    assert isinstance(tracer.watch[0], Exploding)
    assert isinstance(tracer.watch[1], Exploding)
    assert tracer.watch[0].name == 'foo'
    assert tracer.watch[1].name == 'bar'

# Generated at 2022-06-16 19:19:41.712260
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        bb = 28
        cc = 29
        dd = 30
        ee = 31
        ff = 32
        gg = 33
        hh = 34
        ii = 35
        jj = 36
        kk = 37
        ll

# Generated at 2022-06-16 19:19:54.720491
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import os
    import get_write_function
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DIS

# Generated at 2022-06-16 19:19:59.375510
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][1] == 'def f():'



# Generated at 2022-06-16 19:20:10.937241
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import os
    import tempfile
    import shutil
    import sys
    import time
    import contextlib
    import threading
    import traceback
    from . import utils
    from . import pycompat
    from . import test_utils
    from . import test_utils_2
    from . import test_utils_3

    def test_get_write_function_1():
        with test_utils.TempFolder() as temp_folder:
            temp_file_path = temp_folder / 'temp_file.txt'
            write = get_write_function(temp_file_path, overwrite=True)
            write('hello')
            with open(temp_file_path, 'r') as f:
                assert f.read() == 'hello'
            write('world')

# Generated at 2022-06-16 19:20:23.172195
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:28.547618
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import contextlib
    import functools
    import inspect
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:20:35.376787
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import types
    import unittest
    import unittest.mock
    import warnings
    import weakref
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat


# Generated at 2022-06-16 19:20:47.966350
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import get_local_reprs
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.utils import inspect
    from pysnooper.utils import threading
    from pysnooper.utils import datetime_module
    from pysnooper.utils import opcode
    from pysnooper.utils import traceback
    from pysnooper.utils import functools
    from pysnooper.utils import DISABLED
   

# Generated at 2022-06-16 19:20:55.091589
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import functools
    import inspect
    import threading
    import datetime
    import os
    import pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.DISABLED
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_write_function
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils


# Generated at 2022-06-16 19:21:45.737125
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import random
    import string
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-16 19:21:58.825322
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    from .utils import WritableStream
    import sys
    import io
    import os
    import tempfile
    import shutil
    import pytest
    import contextlib
    import os
    import sys
    import tempfile
    import shutil
    import pytest
    import contextlib

    def test_write_to_file(output, overwrite, expected_content):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = os.path.join(temp_dir, 'test.txt')
            write = get_write_function(output, overwrite)
            write('hello')
            write('world')
            if expected_content is not None:
                with open(path, 'r') as f:
                    assert f.read() == expected_content
            else:
                assert not os.path

# Generated at 2022-06-16 19:22:08.323411
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import p

# Generated at 2022-06-16 19:22:20.214481
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import mock
    import pysnooper
    import sys
    import inspect
    import datetime
    import threading
    import functools
    import os
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:22:32.362570
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass
    def bar():
        pass
    def baz():
        pass
    def qux():
        pass
    def quux():
        pass
    def corge():
        pass
    def grault():
        pass
    def garply():
        pass
    def waldo():
        pass
    def fred():
        pass
    def plugh():
        pass
    def xyzzy():
        pass
    def thud():
        pass

    def test_watch():
        @snoop(watch=('foo', 'bar', 'baz'))
        def foo():
            bar = 1
            baz = 2
            qux = 3
            quux = 4
            corge = 5
            grault = 6
            garply = 7
            waldo = 8

# Generated at 2022-06-16 19:22:37.145307
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() is f()



# Generated at 2022-06-16 19:22:48.226690
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import os
    import datetime_module
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:22:56.726422
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import sys
    import os
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:23:08.193236
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import datetime
    import os
    import pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.thread_global

# Generated at 2022-06-16 19:23:09.866286
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert foo() == (__file__, open(__file__, 'rb').read().splitlines())
    assert foo() is foo()

