

# Generated at 2022-06-16 19:15:33.581637
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:15:39.955336
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import datetime
    import sys
    import threading
    import traceback
    import unittest
    import unittest.mock
    import pysnooper.utils
    import pysnooper.tracer
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.inspect
    import pysnooper.DISABLED
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_write_function
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.utils
    import pysnooper.pycompat

# Generated at 2022-06-16 19:15:44.854903
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'
    assert source[-1] == 'test_get_path_and_source_from_frame()'



# Generated at 2022-06-16 19:15:49.439239
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(watch=('foo', 'bar'))
    def foo(bar):
        foo = bar
        return foo

    foo(1)


# Generated at 2022-06-16 19:16:01.580668
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
   

# Generated at 2022-06-16 19:16:13.772667
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import io
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.tracer
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.threading
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.DISABLED
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.get_write_function
    import pysnooper.get_path_and

# Generated at 2022-06-16 19:16:20.230768
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import get_write_function
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isasyncgenfunction
    from pysnooper.utils import get_shortish_repr
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Expl

# Generated at 2022-06-16 19:16:31.623726
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import pytest
    import re
    import sys
    import os
    import os.path
    import shutil
    import tempfile
    import time
    import traceback
    import types
    import warnings
    import weakref
    import functools
    import inspect
    import opcode
    import os
    import sys
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import pytest
    import pycompat
    from .variables import CommonVariable, Exploding, BaseVariable
    from . import utils, pycompat
    if pycompat.PY2:
        from io import open
    import os
    import pytest
    import pycompat


# Generated at 2022-06-16 19:16:40.489644
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import pycompat
    import opcode
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pys

# Generated at 2022-06-16 19:16:51.733934
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pysnooper
    import sys
    import threading
    import time
    import unittest

    class Tracer___enter__Test(unittest.TestCase):
        def test_it(self):
            # Arrange
            output = []
            tracer = pysnooper.Tracer(output.append)
            tracer.depth = 1
            tracer.target_codes = set()
            tracer.target_frames = set()
            tracer.thread_local = threading.local()
            tracer.start_times = {}
            tracer.frame_to_local_reprs = {}
            tracer.last_source_path = None
            tracer.max_variable_length = 100
            tracer.normalize = False
            tracer.relative_time = False
            tracer.thread_info

# Generated at 2022-06-16 19:17:22.080333
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     UnavailableSource())



# Generated at 2022-06-16 19:17:31.122453
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os


# Generated at 2022-06-16 19:17:43.572665
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import threading
    import time
    import datetime
    import traceback
    import functools
    import inspect
    import pycompat
    import pysnooper
    import utils
    import opcode
    import thread_global
    import pycompat
    import datetime_module
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:54.126850
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_output(self):
            self.snooper.write('foo')
            self.assertEqual(self.output.getvalue(), 'foo\n')

        def test_watch(self):
            self.snooper.watch = ['foo']
            self.assertEqual(self.snooper.watch, [CommonVariable('foo')])

        def test_watch_explode(self):
            self.snooper.watch_explode = ['foo']

# Generated at 2022-06-16 19:18:03.924975
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import CommonVariable
    import Exploding
    import BaseVariable
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import CommonVariable
    import Exploding
    import BaseVariable
    import get_path_and_source_from_frame
    import get

# Generated at 2022-06-16 19:18:15.918897
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:25.160444
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test that Tracer() works
    Tracer()
    # Test that Tracer(watch=...) works
    Tracer(watch=('foo', 'bar'))
    # Test that Tracer(watch_explode=...) works
    Tracer(watch_explode=('foo', 'bar'))
    # Test that Tracer(watch=..., watch_explode=...) works
    Tracer(watch=('foo', 'bar'), watch_explode=('baz', 'qux'))
    # Test that Tracer(depth=...) works
    Tracer(depth=2)
    # Test that Tracer(prefix=...) works
    Tracer(prefix='ZZZ ')
    # Test that Tracer(overwrite=...) works
    Tracer(overwrite=True)
    # Test that Tracer(thread_info=...) works


# Generated at 2022-06-16 19:18:35.360694
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:18:41.640383
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:18:43.162052
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_firstlineno)



# Generated at 2022-06-16 19:19:28.163918
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper import snoop
    from pysnooper.utils import get_write_function
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isasyncgenfunction
    from pysnooper.utils import isgeneratorfunction
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import time_isoformat
    from pysnooper.utils import BaseVariable
    from pysnooper.utils import CommonVariable
    from pysnooper.utils import Expl

# Generated at 2022-06-16 19:19:39.100043
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass
    def bar():
        pass
    def baz():
        pass

    # Test watch
    tracer = Tracer(watch=('foo', 'bar'))
    assert tracer.watch == [CommonVariable('foo'), CommonVariable('bar')]
    tracer = Tracer(watch=('foo', 'bar', 'baz'))
    assert tracer.watch == [CommonVariable('foo'), CommonVariable('bar'), CommonVariable('baz')]

    # Test watch_explode
    tracer = Tracer(watch_explode=('foo', 'bar'))
    assert tracer.watch == [Exploding('foo'), Exploding('bar')]
    tracer = Tracer(watch_explode=('foo', 'bar', 'baz'))

# Generated at 2022-06-16 19:19:47.422861
# Unit test for method __exit__ of class Tracer

# Generated at 2022-06-16 19:19:58.782545
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import datetime
    import sys
    import threading
    import time
    import traceback
    import unittest
    import unittest.mock
    import warnings
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.tracer
    import pysnooper.variable
    import pysnooper.variable.common
    import pysnooper.variable.exploding
    import pysnooper.variable.base
    import pysnooper.variable.utils
    import pysnooper.variable.utils.get_path_and_source_from_frame
    import pysnooper.variable.utils.get_local_reprs
    import pysnooper.variable.utils.get_shortish_repr
    import pysno

# Generated at 2022-06-16 19:20:10.529073
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import random
    import string
    import io
    import contextlib
    import sys
    import os
    import shutil
    import tempfile
    import pytest
    import os.path
    import random
    import string
    import io
    import contextlib
    import sys
    import os
    import shutil
    import tempfile
    import pytest
    import os.path
    import random
    import string
    import io
    import contextlib
    import sys
    import os
    import shutil
    import tempfile
    import pytest
    import os.path
    import random
    import string
    import io
    import contextlib
    import sys
    import os
    import shutil

# Generated at 2022-06-16 19:20:22.555829
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    import io
    import sys
    import os
    import tempfile
    import shutil
    import contextlib
    import pytest
    import os.path
    import os
    import sys
    import io
    import tempfile
    import shutil
    import contextlib
    import pytest
    import os.path
    import os
    import sys
    import io
    import tempfile
    import shutil
    import contextlib
    import pytest
    import os.path
    import os
    import sys
    import io
    import tempfile
    import shutil
    import contextlib
    import pytest
    import os.path
    import os
    import sys
    import io
    import tempfile
    import shutil
    import contextlib
    import pytest
    import os.path

# Generated at 2022-06-16 19:20:31.105872
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import contextlib
    import functools
    import inspect
    import threading
    import datetime
    import itertools
    import traceback
    import pycompat
    import opcode
    import pysnooper
    import utils
    import thread_global
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:20:38.683837
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import pysnooper
    import unittest
    import io
    import os
    import tempfile
    import shutil
    import contextlib

    class TestTracerTrace(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'temp_file')
            self.temp_file_handle = open(self.temp_file, 'w')
            self.temp_file_handle.close()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-16 19:20:44.069945
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path

# Generated at 2022-06-16 19:20:53.704782
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass

    def bar():
        pass

    def baz():
        pass

    def qux():
        pass

    def quux():
        pass

    def coro():
        yield

    def gen():
        yield

    def async_gen():
        yield

    def coro_gen():
        yield

    def async_coro_gen():
        yield

    def async_coro():
        yield

    def test_function(function, depth, expected_target_codes):
        tracer = Tracer(depth=depth)
        tracer(function)
        assert tracer.target_codes == expected_target_codes

    test_function(foo, 1, {foo.__code__})
    test_function(foo, 2, {foo.__code__})

# Generated at 2022-06-16 19:22:23.406755
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import threading
    import inspect
    import functools
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:22:34.340714
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:22:40.763018
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (
        __file__,
        inspect.getsourcelines(test_get_path_and_source_from_frame)[0]
    )
test_get_path_and_source_from_frame()



# Generated at 2022-06-16 19:22:44.517988
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')


# Generated at 2022-06-16 19:22:51.325507
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import unittest

    class Tracer___exit__Test(unittest.TestCase):
        def test_it(self):
            def test_function():
                with pysnooper.snoop():
                    pass
            with self.assertRaises(AssertionError):
                test_function()
    unittest.main()


# Generated at 2022-06-16 19:22:54.720032
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:23:06.105229
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import types
    import unittest
    import unittest.mock
    import pysnooper.utils
    import pysnooper.tracer

    class TestTracerTrace(unittest.TestCase):
        def setUp(self):
            self.mock_frame = unittest.mock.Mock()
            self.mock_frame.f_code = unittest.mock.Mock()
            self.mock_frame.f_code.co_filename = 'mock_co_filename'
            self.mock_frame.f_code.co_code = 'mock_co_code'
            self.mock_frame.f_code.co_name = 'mock_co_name'
            self.mock_frame.f_lineno = 1
           

# Generated at 2022-06-16 19:23:15.401364
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile
    import types
    import unittest
    import zipfile

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file_path = os.path.join(self.temp_dir, 'test.py')
            with open(self.temp_file_path, 'w') as temp_file:
                temp_file.write('def foo():\n    pass\n')
            self.temp_zip_path = os.path.join(self.temp_dir, 'test.zip')

# Generated at 2022-06-16 19:23:23.311794
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat

# Generated at 2022-06-16 19:23:32.493966
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
