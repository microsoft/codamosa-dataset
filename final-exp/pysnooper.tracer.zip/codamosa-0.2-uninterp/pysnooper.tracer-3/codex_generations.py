

# Generated at 2022-06-16 19:15:30.943064
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import unittest

    class Tracer___exit__Test(unittest.TestCase):
        def test_it(self):
            def test_function():
                with pysnooper.snoop():
                    pass
            with self.assertRaises(KeyError):
                test_function()

    unittest.main()


# Generated at 2022-06-16 19:15:38.542308
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_default_values(self):
            self.assertEqual(self.snooper.watch, [])
            self.assertEqual(self.snooper.depth, 1)
            self.assertEqual(self.snooper.prefix, '')
            self.assertEqual(self.snooper.thread_info, False)
            self.assertEqual(self.snooper.custom_repr, ())
            self.assertEqual(self.snooper.max_variable_length, 100)

# Generated at 2022-06-16 19:15:44.589061
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == __file__
    assert source[0].startswith('def test_get_path_and_source_from_frame():')
    assert source[-1].startswith('test_get_path_and_source_from_frame()')
test_get_path_and_source_from_frame()



# Generated at 2022-06-16 19:15:47.797883
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    file_name, source = get_path_and_source_from_frame(f.__code__.co_firstlineno)
    assert file_name == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:15:50.551524
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test for method __call__ of class Tracer
    #
    # This method is tested in test_snoop.py
    pass


# Generated at 2022-06-16 19:16:02.551786
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    from . import utils
    from .utils import WritableStream

    def write_to_file(s):
        with open(temp_file_path, 'w') as f:
            f.write(s)

    def write_to_stream(s):
        stream.write(s)

    def write_to_stdout(s):
        sys.stdout.write(s)

    def write_to_stderr(s):
        sys.stderr.write(s)

    def write_to_none(s):
        pass

    def write_to_writable_stream(s):
        writable_stream.write(s)


# Generated at 2022-06-16 19:16:14.442109
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import os
    import tempfile
    import shutil
    import contextlib
    import sys
    import pytest

    @contextlib.contextmanager
    def temp_dir():
        temp_dir_path = tempfile.mkdtemp()
        try:
            yield temp_dir_path
        finally:
            shutil.rmtree(temp_dir_path)

    def test_write_function(write_function, expected_output):
        with temp_dir() as temp_dir_path:
            output_path = os.path.join(temp_dir_path, 'output.txt')
            write_function(output_path)
            with open(output_path, 'r') as f:
                output = f.read()
        assert output == expected_output


# Generated at 2022-06-16 19:16:19.164611
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][1] == 'def f():'



# Generated at 2022-06-16 19:16:30.352752
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        c = 3
        return a, b, c
    frame = inspect.currentframe().f_back
    assert get_local_reprs(frame) == {'a': '1', 'b': '2', 'c': '3'}
    assert get_local_reprs(frame, watch=(CommonVariable('a'),)) == {'a': '1'}
    assert get_local_reprs(frame, watch=(CommonVariable('a'),
                                         CommonVariable('b'),
                                         CommonVariable('c'))) == {'a': '1',
                                                                   'b': '2',
                                                                   'c': '3'}

# Generated at 2022-06-16 19:16:39.616987
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import pytest
    import shutil
    import sys
    import io
    import contextlib
    import random
    import string
    import time
    import os.path
    import datetime
    import re
    import sys
    import os
    import pycompat
    import re
    import os.path
    import sys
    import os
    import pycompat
    import re
    import os.path
    import sys
    import os
    import pycompat
    import re
    import os.path
    import sys
    import os
    import pycompat
    import re
    import os.path
    import sys
    import os
    import pycompat
    import re
    import os.path
    import sys
    import os
    import pycompat
    import re

# Generated at 2022-06-16 19:17:09.717364
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:17:20.843386
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:17:25.487579
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return inspect.currentframe()
    frame = f()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:17:32.705407
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import pytest
    import os
    import sys
    import io
    import py

# Generated at 2022-06-16 19:17:40.401019
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile
    import types
    import unittest
    import zipfile

    class TestCase(unittest.TestCase):
        def test_get_path_and_source_from_frame(self):
            def test_function():
                return inspect.currentframe()

            frame = test_function()
            path, source = get_path_and_source_from_frame(frame)
            self.assertEqual(path, __file__)
            self.assertEqual(source[0], 'def test_function():')

            def test_function():
                return inspect.currentframe()

            frame = test_function()
            path, source = get_path_and_source_from_frame(frame)
            self.assertEqual(path, __file__)
            self

# Generated at 2022-06-16 19:17:50.778270
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import os
    import threading
    import datetime
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:01.906328
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test for default values
    tracer = Tracer()
    assert tracer.watch == []
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.custom_repr == ()
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False
    assert tracer.relative_time == False

    # Test for custom values

# Generated at 2022-06-16 19:18:09.474171
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test for method trace of class Tracer
    # Input arguments:
    #   frame :
    #   event :
    #   arg :
    # Return type:
    #   The return type of this method is unknown/undocumented. Please, refer
    #   to the method's description for more details.
    # TODO: Implement this method!
    raise NotImplementedError("Method not implemented!")


# Generated at 2022-06-16 19:18:16.007468
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(watch=('a', 'b'), watch_explode=('c', 'd'), depth=3,
                prefix='ZZZ ', overwrite=True, thread_info=True,
                custom_repr=((type1, custom_repr_func1),
                             (condition2, custom_repr_func2),),
                max_variable_length=100, normalize=False, relative_time=False):
        pass


# Generated at 2022-06-16 19:18:25.224915
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:18:57.307996
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import datetime
    import datetime_module
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:19:03.875399
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'
    assert source[-1] == 'test_get_path_and_source_from_frame()'



# Generated at 2022-06-16 19:19:16.288616
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_default_constructor(self):
            self.assertEqual(self.snooper.watch, [])
            self.assertEqual(self.snooper.watch_explode, [])
            self.assertEqual(self.snooper.depth, 1)
            self.assertEqual(self.snooper.prefix, '')
            self.assertEqual(self.snooper.overwrite, False)
            self.assertEqual(self.snooper.thread_info, False)

# Generated at 2022-06-16 19:19:26.005330
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import tempfile
    import shutil
    import sys
    import types

    def get_path_and_source_from_frame(frame):
        globs = frame.f_globals or {}
        module_name = globs.get('__name__')
        file_name = frame.f_code.co_filename
        cache_key = (module_name, file_name)
        try:
            return source_and_path_cache[cache_key]
        except KeyError:
            pass
        loader = globs.get('__loader__')

        source = None
        if hasattr(loader, 'get_source'):
            try:
                source = loader.get_source(module_name)
            except ImportError:
                pass
            if source is not None:
                source

# Generated at 2022-06-16 19:19:27.058488
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-16 19:19:38.666940
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import six
    import pathlib
    import contextlib

    @contextlib.contextmanager
    def temp_dir():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)

    def test_write_function(write_function, expected_output):
        output = io.StringIO()
        write_function(output)
        assert output.getvalue() == expected_output

    def test_write_function_with_path(write_function, expected_output,
                                      overwrite):
        with temp_dir() as temp_dir:
            path = os.path.join(temp_dir, 'file.txt')


# Generated at 2022-06-16 19:19:41.460804
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_filename,
                                          f.__code__.co_firstlineno)



# Generated at 2022-06-16 19:19:54.456229
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import itertools
    import opcode
    import traceback
    import functools
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import pycompat
    import os
    import DISABLED
    import get_write_function
    import inspect
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:19:57.965005
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:20:09.814286
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    from . import utils
    from .utils import WritableStream

    def write_to_file(s):
        with open(temp_file_path, 'w') as f:
            f.write(s)

    def write_to_stream(s):
        stream.write(s)

    def write_to_stdout(s):
        sys.stdout.write(s)

    def write_to_stderr(s):
        sys.stderr.write(s)

    def write_to_writable_stream(s):
        writable_stream.write(s)

    temp_file_path = tempfile.mktemp()
    stream = io.StringIO()
    writable_stream

# Generated at 2022-06-16 19:20:38.058804
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.trace(frame=None, event=None, arg=None)


# Generated at 2022-06-16 19:20:43.155161
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())



# Generated at 2022-06-16 19:20:53.136183
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with default args
    tracer = Tracer()
    assert tracer.watch == []
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.custom_repr == ()
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False
    assert tracer.relative_time == False
    # Test with custom args
    tracer = Tracer(watch=('foo', 'bar'), depth=2, prefix='ZZZ ',
                    thread_info=True, custom_repr=((type1, custom_repr_func1),
                                                   (condition2, custom_repr_func2)),
                    max_variable_length=200, normalize=True, relative_time=True)
    assert tracer.watch

# Generated at 2022-06-16 19:21:01.360183
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    output = io.StringIO()
    with Tracer(output, watch=('foo', 'bar'), watch_explode=('baz', 'qux'),
                depth=2, prefix='ZZZ ', overwrite=True, thread_info=True,
                custom_repr=((type1, custom_repr_func1),
                             (condition2, custom_repr_func2), ...),
                max_variable_length=100, normalize=False, relative_time=False):
        pass


# Generated at 2022-06-16 19:21:13.624794
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import sys
    import io
    import shutil
    import contextlib
    import six
    import pytest
    import pathlib

    @contextlib.contextmanager
    def temp_file_path(content=None):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            if content:
                f.write(content)
        try:
            yield f.name
        finally:
            os.remove(f.name)

    @contextlib.contextmanager
    def temp_file_object(content=None):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            if content:
                f.write(content)

# Generated at 2022-06-16 19:21:20.693335
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys

    def f():
        return inspect.currentframe()

    frame = f()
    path, source = get_path_and_source_from_frame(frame)
    assert path == os.path.abspath(__file__)
    assert source == open(path, 'rb').read().splitlines()

    def g():
        return inspect.currentframe()

    frame = g()
    path, source = get_path_and_source_from_frame(frame)
    assert path == os.path.abspath(__file__)
    assert source == open(path, 'rb').read().splitlines()

    def h():
        return inspect.currentframe()

    frame = h()
    path, source = get_path_and_source_from_frame(frame)

# Generated at 2022-06-16 19:21:25.641569
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_output(self):
            @self.snooper
            def foo():
                pass
            foo()
            self.assertTrue(self.output.getvalue().startswith('Line 1: def foo():'))

        def test_watch(self):
            @self.snooper(watch=('foo',))
            def foo():
                foo = 'bar'
            foo()
            self.assertTrue(self.output.getvalue().endswith('New var:....... foo = bar\n'))


# Generated at 2022-06-16 19:21:37.397288
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_default_values(self):
            self.assertEqual(self.snooper.watch, [])
            self.assertEqual(self.snooper.depth, 1)
            self.assertEqual(self.snooper.prefix, '')
            self.assertEqual(self.snooper.thread_info, False)
            self.assertEqual(self.snooper.custom_repr, ())
            self.assertEqual(self.snooper.max_variable_length, 100)

# Generated at 2022-06-16 19:21:45.610215
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    from .utils import get_write_function, get_path_and_source_from_frame, CommonVariable, BaseVariable, Exploding
    from . import DISABLED
    from . import datetime_module
    from . import pycompat
    from . import utils
    from . import thread_global
    from .utils import get_write_function, get_path_and_source_from_frame, CommonVariable, BaseVariable, Exploding
    from . import DISABLED
    from . import datetime_module
    from . import pycompat
    from . import utils

# Generated at 2022-06-16 19:21:58.764599
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import inspect
    import threading
    import itertools
    import opcode
    import traceback
    import functools
    import datetime
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:22:33.457185
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import os
    import pycompat
    import opcode
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:22:39.428861
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import traceback
    import unittest
    import unittest.mock
    import pysnooper.utils
    import pysnooper.tracer
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.DISABLED
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.Base

# Generated at 2022-06-16 19:22:50.497230
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import io
    import threading
    import time
    import datetime
    import os
    import inspect
    import functools
    import pycompat
    import traceback
    import opcode
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:22:57.897776
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import pytest
    import pysnooper
    import datetime
    import threading
    import inspect
    import functools
    import os
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:23:09.011754
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import sys
    import pytest
    import os.path
    import re
    import datetime
    import time
    import sys
    import os
    import re
    import datetime
    import time
    import sys
    import os
    import re
    import datetime
    import time
    import sys
    import os
    import re
    import datetime
    import time
    import sys
    import os
    import re
    import datetime
    import time
    import sys
    import os
    import re
    import datetime
    import time
    import sys
    import os
    import re
    import datetime
    import time
    import sys
    import os
    import re
    import datetime
    import time
    import sys

# Generated at 2022-06-16 19:23:18.793794
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import types
    import unittest
    import unittest.mock
    import warnings
    import weakref
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.variable.common
    import pysnooper.variable.exploding
    import pysnooper.variable.watch
    import pysnooper.variable.watch.common
    import pysnooper.variable.watch.exploding
    import pysnooper.variable.watch.watch
    import pysnooper.variable.watch.watch.common
    import pysnooper.variable.watch.watch.exploding
    import pysnooper.variable.watch.watch.watch
    import p

# Generated at 2022-06-16 19:23:26.092546
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return 1
    frame = inspect.currentframe()
    frame = frame.f_back
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[frame.f_lineno - 1].strip() == 'def f():'



# Generated at 2022-06-16 19:23:27.568152
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-16 19:23:38.898243
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:23:50.635846
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import traceback
    import unittest
    import unittest.mock
    import warnings

    class TestTracer___exit__(unittest.TestCase):
        def test_it(self):
            # Arrange
            tracer = pysnooper.Tracer()
            tracer.target_codes = set()
            tracer.target_frames = set()
            tracer.frame_to_local_reprs = {}
            tracer.start_times = {}
            tracer.thread_local = threading.local()
            tracer.last_source_path = None
            tracer.max_variable_length = 100
            tracer.normalize = False
            tracer.relative_time = False
            tracer.thread_info = False
