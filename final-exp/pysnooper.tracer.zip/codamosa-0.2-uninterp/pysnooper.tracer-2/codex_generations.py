

# Generated at 2022-06-16 19:16:03.933722
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass

    def bar():
        pass

    def baz():
        pass

    def qux():
        pass

    def quux():
        pass

    def corge():
        pass

    def grault():
        pass

    def garply():
        pass

    def waldo():
        pass

    def fred():
        pass

    def plugh():
        pass

    def xyzzy():
        pass

    def thud():
        pass

    def test_function():
        foo()
        bar()
        baz()
        qux()
        quux()
        corge()
        grault()
        garply()
        waldo()
        fred()
        plugh()
        xyzzy()
        thud()

    output = io.StringIO()
    tracer

# Generated at 2022-06-16 19:16:12.279279
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'
    assert source[-1] == 'test_get_path_and_source_from_frame()'
    del frame
    del file_name
    del source



# Generated at 2022-06-16 19:16:22.518209
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile
    import textwrap
    import types
    import unittest
    import warnings

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.old_cwd = os.getcwd()
            os.chdir(self.tempdir)

        def tearDown(self):
            os.chdir(self.old_cwd)
            for filename in os.listdir(self.tempdir):
                os.remove(os.path.join(self.tempdir, filename))
            os.rmdir(self.tempdir)

        def test_get_path_and_source_from_frame(self):
            def foo():
                pass

# Generated at 2022-06-16 19:16:29.182754
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import os
    import itertools
    import traceback
    import opcode
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.DISABLED
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.utils
    import pysno

# Generated at 2022-06-16 19:16:38.936060
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
   

# Generated at 2022-06-16 19:16:41.498976
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Test for method __exit__ of class Tracer
    # This method is tested in test_snoop
    pass


# Generated at 2022-06-16 19:16:52.677831
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest
    import unittest.mock

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.write = get_write_function(self.output)
            self.write_patcher = unittest.mock.patch('pysnooper.utils.write',
                                                     self.write)
            self.write_patcher.start()

        def tearDown(self):
            self.write_patcher.stop()

        def test_watch(self):
            tracer = Tracer(output=self.output, watch=('foo', 'bar'))
            self.assertEqual(tracer.watch, [CommonVariable('foo'),
                                            CommonVariable('bar')])

       

# Generated at 2022-06-16 19:17:02.366293
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import pytest
    import pysnooper
    import datetime
    import threading
    import inspect
    import functools
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    from pysnooper.utils import DISABLED
    from pysnooper.utils import get_shortish_repr
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import timedelta_format

# Generated at 2022-06-16 19:17:15.627230
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pytest
    import sys
    import os
    import inspect
    import threading
    import itertools
    import opcode
    import functools
    import traceback
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.Tracer
    import pysnooper

# Generated at 2022-06-16 19:17:20.678121
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     UnavailableSource())



# Generated at 2022-06-16 19:17:46.933827
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() is f()  # Make sure it's cached



# Generated at 2022-06-16 19:17:54.419447
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    import shutil
    import os
    import sys
    import imp
    import types
    import textwrap
    import time
    import random
    import string
    import pickle
    import contextlib
    import io
    import re
    import traceback
    import inspect
    import linecache
    import tokenize
    import token
    import unittest
    import unittest.mock
    import importlib
    import importlib.util
    import importlib.machinery
    import importlib.abc
    import importlib.abc.Loader
    import importlib.abc.InspectLoader
    import importlib.abc.MetaPathFinder
    import importlib.abc.PathEntryFinder
    import importlib.abc.SourceLoader
    import importlib.abc.ExecutionLoader

# Generated at 2022-06-16 19:17:57.937786
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return 1
    assert get_path_and_source_from_frame(f.__code__.co_filename) == \
                                                            (__file__, None)



# Generated at 2022-06-16 19:18:04.270841
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snoop = Tracer(output=self.output)

        def test_default(self):
            self.assertEqual(self.snoop.watch, [])
            self.assertEqual(self.snoop.depth, 1)
            self.assertEqual(self.snoop.prefix, '')
            self.assertEqual(self.snoop.thread_info, False)
            self.assertEqual(self.snoop.custom_repr, ())
            self.assertEqual(self.snoop.max_variable_length, 100)

# Generated at 2022-06-16 19:18:15.963379
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat

# Generated at 2022-06-16 19:18:24.693280
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with default args
    tracer = Tracer()
    tracer.__enter__()
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local.__dict__ == {'original_trace_functions': []}
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False

# Generated at 2022-06-16 19:18:34.976956
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import inspect
    import functools
    import itertools

# Generated at 2022-06-16 19:18:45.936701
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import os
    import datetime_module


# Generated at 2022-06-16 19:18:46.758953
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-16 19:18:55.104810
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import io
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:19:29.914512
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test that Tracer() works
    Tracer()
    # Test that Tracer(watch=...) works
    Tracer(watch=['foo'])
    # Test that Tracer(watch_explode=...) works
    Tracer(watch_explode=['foo'])
    # Test that Tracer(watch=..., watch_explode=...) works
    Tracer(watch=['foo'], watch_explode=['bar'])
    # Test that Tracer(depth=...) works
    Tracer(depth=1)
    # Test that Tracer(prefix=...) works
    Tracer(prefix='foo')
    # Test that Tracer(overwrite=...) works
    Tracer(overwrite=True)
    # Test that Tracer(thread_info=...) works
    Tracer(thread_info=True)
    # Test that

# Generated at 2022-06-16 19:19:38.652637
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:19:47.189162
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
   

# Generated at 2022-06-16 19:19:52.098716
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:20:01.498923
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.DISABLED
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_write_function
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pys

# Generated at 2022-06-16 19:20:06.515030
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_filename,
                                          f.__code__.co_firstlineno) == \
                                          (f.__code__.co_filename,
                                           inspect.getsourcelines(f)[0])



# Generated at 2022-06-16 19:20:11.297679
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    class TestTracerTrace(unittest.TestCase):
        def test_Tracer_trace(self):
            # self.assertEqual(expected, Tracer.trace(frame, event, arg))
            assert False # TODO: implement your test here
    unittest.main()


# Generated at 2022-06-16 19:20:17.058583
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path
    import os
    import sys
    import pytest
    import os.path

# Generated at 2022-06-16 19:20:27.226089
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import CommonVariable
    import BaseVariable
    import Exploding
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import CommonVariable
    import BaseVariable
    import Exploding
    import get_path_and_source_from_frame
    import get

# Generated at 2022-06-16 19:20:34.511024
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')
    assert f()[1][-1].startswith('assert f()[1][0].startswith(')


# Generated at 2022-06-16 19:21:16.220852
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import os
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:21:28.335817
# Unit test for constructor of class Tracer

# Generated at 2022-06-16 19:21:39.824461
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with default args
    tracer = Tracer()
    tracer.__enter__()
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local.__dict__ == {'original_trace_functions': [None]}
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100

# Generated at 2022-06-16 19:21:52.211363
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import types

    # Test for method __exit__ of class Tracer
    class TestTracer___exit__:
        def test_Tracer___exit__(self):
            def test_function():
                with pysnooper.snoop():
                    pass
            test_function()

    # Test for method __exit__ of class Tracer
    class TestTracer___exit__:
        def test_Tracer___exit__(self):
            def test_function():
                with pysnooper.snoop():
                    pass
            test_function()

    # Test for method __exit__ of class Tracer

# Generated at 2022-06-16 19:22:04.164908
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.DISABLED
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper

# Generated at 2022-06-16 19:22:07.608956
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        pass
    frame = test_function.__code__.co_filename, test_function.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__, open(__file__).read().splitlines())



# Generated at 2022-06-16 19:22:19.754027
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import datetime
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:22:31.726838
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import datetime
    import threading
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:22:35.158159
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')



# Generated at 2022-06-16 19:22:43.569100
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import get_write_function
    from pysnooper.utils import get_shortish_repr
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import time_isoformat
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding

# Generated at 2022-06-16 19:23:50.753277
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper
    import sys
    import threading
    import types
    import unittest
    import unittest.mock
    import warnings
    import weakref
    from pysnooper.utils import get_write_function
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.variable import BaseVariable
    from pysnooper.variable import get_local_reprs
    from pysnooper.variable import get_path_and_source_from_frame
    from pysnooper.variable import get_shortish_repr
    from pysnooper.variable import truncate

# Generated at 2022-06-16 19:24:01.822712
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = sys._getframe(0)
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__, 'rb').read().splitlines())
    frame = sys._getframe(1)
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__, 'rb').read().splitlines())
    frame = sys._getframe(2)
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__, 'rb').read().splitlines())
    frame = sys._getframe(3)

# Generated at 2022-06-16 19:24:09.187788
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import os
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:24:13.183761
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test for method trace of class Tracer
    # Input arguments:
    #   frame :
    #   event :
    #   arg :
    # Return value:
    #   return value of method trace

    # Pass
    return None


# Generated at 2022-06-16 19:24:23.662897
# Unit test for constructor of class Tracer

# Generated at 2022-06-16 19:24:32.426800
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import datetime
    import threading
    import inspect
    import functools
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat