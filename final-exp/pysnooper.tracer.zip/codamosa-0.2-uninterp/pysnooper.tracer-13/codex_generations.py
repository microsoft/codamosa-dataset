

# Generated at 2022-06-16 19:15:17.740282
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:15:29.546744
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import io
    import sys
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.watch
    import pysnooper.watch.common
    import pysnooper.watch.explode
    import pysnooper.watch.variable
    import pysnooper.watch.variable.base
    import pysnooper.watch.variable.common
    import pysnooper.watch.variable.explode
    import pysnooper.watch.variable.variable
    import pysnooper.watch.variable.variable.base
    import pysnooper.watch.variable.variable.common
    import pysnooper.watch.variable.variable.explode

# Generated at 2022-06-16 19:15:37.906539
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import datetime
    import os
    import pycompat
    import inspect
    import functools
    import traceback
    import opcode
    import itertools
    import collections
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.inspect
    import pysnooper.datetime_module
    import pysnooper.thread_global
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_write_function
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.BaseVariable
    import pysnooper.utils
    import pysnooper.pycompat
    import p

# Generated at 2022-06-16 19:15:47.219599
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import os
    import datetime
    import threading
    import inspect
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import os
    import datetime
    import threading
    import inspect
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import os
    import datetime
    import threading
    import inspect
    import functools
    import itertools
    import opcode
    import traceback
    import pycomp

# Generated at 2022-06-16 19:15:59.716705
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:16:03.122008
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename
    assert get_path_and_source_from_frame(frame) == (frame, UnavailableSource())



# Generated at 2022-06-16 19:16:09.502933
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][1].startswith('def f():')



# Generated at 2022-06-16 19:16:17.664034
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y):
        z = x + y
        return z
    frame = inspect.currentframe()
    frame = frame.f_back
    assert get_local_reprs(frame) == {'x': '0', 'y': '1', 'z': '1'}
    assert get_local_reprs(frame, watch=[CommonVariable('x')]) == {'x': '0'}
    assert get_local_reprs(frame, watch=[CommonVariable('x'),
                                         CommonVariable('y')]) == {'x': '0',
                                                                   'y': '1'}

# Generated at 2022-06-16 19:16:24.768376
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_output(self):
            self.snooper.write('foo')
            self.assertEqual(self.output.getvalue(), 'foo\n')

        def test_watch(self):
            self.snooper.watch = ['foo', 'bar']
            self.assertEqual(self.snooper.watch, [CommonVariable('foo'),
                                                  CommonVariable('bar')])

        def test_watch_explode(self):
            self.snooper.watch_explode = ['foo', 'bar']
            self.assertEqual

# Generated at 2022-06-16 19:16:32.030391
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:00.495991
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with default args
    tracer = Tracer()
    tracer.__enter__()
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local.__dict__ == {'original_trace_functions': []}
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False

# Generated at 2022-06-16 19:17:07.330199
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:17.746794
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import traceback
    import threading
    import datetime
    import functools
    import inspect
    import os
    import pycompat
    import utils
    import opcode
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:29.066987
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import threading
    import time
    import unittest
    import unittest.mock

    class Tracer___call__Test(unittest.TestCase):
        def test_it(self):
            @pysnooper.snoop()
            def foo():
                pass
            self.assertEqual(foo.__name__, 'foo')
            self.assertEqual(foo.__doc__, None)
            self.assertEqual(foo.__module__, '__main__')

            @pysnooper.snoop()
            def foo_with_docstring():
                '''docstring'''
                pass
            self.assertEqual(foo_with_docstring.__name__, 'foo_with_docstring')
            self.assertEqual

# Generated at 2022-06-16 19:17:41.202561
# Unit test for constructor of class Tracer
def test_Tracer():
    import sys
    import io
    import unittest
    import unittest.mock

    class TracerTest(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.write = unittest.mock.Mock()
            self.write.side_effect = self.output.write
            self.snooper = Tracer(output=self.write)

        def test_output_to_file(self):
            with open('test_output.txt', 'w') as f:
                snooper = Tracer(output=f)
                with snooper:
                    pass


# Generated at 2022-06-16 19:17:45.792766
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return 1
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert source[0] == 'def f():'



# Generated at 2022-06-16 19:17:48.917302
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename
    assert get_path_and_source_from_frame(frame) == (__file__, UnavailableSource())



# Generated at 2022-06-16 19:18:01.294484
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import time
    import threading
    import contextlib
    import six
    import pytest

    def test_get_write_function_with_output(output):
        write = get_write_function(output, False)
        write('hello world')
        if isinstance(output, io.IOBase):
            output.seek(0)
            assert output.read() == 'hello world'
        elif isinstance(output, six.string_types):
            with open(output, 'r') as f:
                assert f.read() == 'hello world'
        else:
            assert output.getvalue() == 'hello world'

    def test_get_write_function_with_output_and_overwrite(output):
        write = get

# Generated at 2022-06-16 19:18:08.667187
# Unit test for constructor of class Tracer

# Generated at 2022-06-16 19:18:19.614468
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass

    def bar():
        pass

    def baz():
        pass

    def qux():
        pass

    def quux():
        pass

    def corge():
        pass

    def grault():
        pass

    def garply():
        pass

    def waldo():
        pass

    def fred():
        pass

    def plugh():
        pass

    def xyzzy():
        pass

    def thud():
        pass

    def foo_bar():
        pass

    def foo_baz():
        pass

    def foo_qux():
        pass

    def foo_quux():
        pass

    def foo_corge():
        pass

    def foo_grault():
        pass

    def foo_garply():
        pass


# Generated at 2022-06-16 19:18:57.869862
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import os
    import sys
    import threading
    import functools
    import inspect
    import pycompat
    import datetime
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame


# Generated at 2022-06-16 19:19:05.916257
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:19:09.029321
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     UnavailableSource())



# Generated at 2022-06-16 19:19:21.921924
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    import sys
    import io
    import os
    import datetime
    import threading
    import traceback
    import inspect
    import functools
    import itertools
    import pycompat
    import utils
    import opcode
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:19:30.092562
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import pytest
    from . import utils
    from .utils import temp_folder
    from .utils import temp_file
    from .utils import temp_file_with_content
    from .utils import temp_folder_with_files
    from .utils import temp_folder_with_folders_and_files
    from .utils import temp_folder_with_files_and_folders
    from .utils import temp_folder_with_content
    from .utils import temp_folder_with_content_in_subfolders
    from .utils import temp_folder_with_content_in_subfolders_and_files
    from .utils import temp_folder_with_content_in_subfolders_and_files_and_folders
    from .utils import temp_folder_with

# Generated at 2022-06-16 19:19:30.805260
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-16 19:19:41.419063
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper import snoop
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import os
    import pycompat
    import threading
    import inspect
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import os
    import pycompat
    import threading
    import inspect
    import functools
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import os
    import pycompat
    import threading
    import inspect

# Generated at 2022-06-16 19:19:46.681814
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test for method trace of class Tracer
    # Input arguments:
    #   frame :
    #   event :
    #   arg :
    # Output:
    #   return value :
    #   exception :
    pass


# Generated at 2022-06-16 19:19:58.271727
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import os
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import os
    import itertools
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import dat

# Generated at 2022-06-16 19:20:10.190228
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import BaseVariable
    import CommonVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:20:52.691759
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat

# Generated at 2022-06-16 19:20:59.104944
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__, source_lines)
source_lines = get_path_and_source_from_frame(inspect.currentframe())[1]



# Generated at 2022-06-16 19:21:10.727212
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:21:19.408547
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import contextlib
    import sys

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def test_write_function(write_function, s):
        with captured_output() as (out, err):
            write_function(s)
        return out.get

# Generated at 2022-06-16 19:21:29.202554
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import sys
    import io
    import threading
    import time
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:21:40.720093
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:21:53.189297
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import pysnooper.utils as utils
    import pysnooper.pycompat as pycompat
    import pysnooper.opcode as opcode
    import pysnooper.variable as variable
    import pysnooper.thread_global as thread_global
    import pysnooper.DISABLED as DISABLED
    import pysnooper.get_write_function as get_write_function
    import pysnooper.get_path_and_source_from_frame as get_path_and_source_from_frame
    import pysnooper.CommonVariable as CommonVariable
    import pysnooper.Exploding as Exploding
    import pysnooper.BaseVariable as BaseVariable


# Generated at 2022-06-16 19:22:05.055164
# Unit test for constructor of class Tracer

# Generated at 2022-06-16 19:22:09.829403
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert foo() == (__file__, UnavailableSource())
    assert foo() == (__file__, UnavailableSource())



# Generated at 2022-06-16 19:22:21.289124
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:23:35.567922
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     inspect.getsourcelines(
                                                         test_get_path_and_source_from_frame)[0])



# Generated at 2022-06-16 19:23:47.716361
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.Tracer
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper

# Generated at 2022-06-16 19:23:55.293941
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        pass

    def bar():
        pass

    def baz():
        pass

    def qux():
        pass

    def quux():
        pass

    def corge():
        pass

    def grault():
        pass

    def garply():
        pass

    def waldo():
        pass

    def fred():
        pass

    def plugh():
        pass

    def xyzzy():
        pass

    def thud():
        pass

    def test_watch():
        @Tracer(watch=('foo', 'bar'))
        def foo():
            bar = 1
            baz = 2
            qux = 3
            quux = 4

        foo()


# Generated at 2022-06-16 19:23:58.374865
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:24:07.245001
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import pycompat
    import os
    import itertools
    import opcode
    import traceback
    import threading
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat

# Generated at 2022-06-16 19:24:11.979557
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:24:22.460637
# Unit test for constructor of class Tracer
def test_Tracer():
    import pysnooper
    import sys
    import io
    import os
    import tempfile
    import contextlib
    import datetime
    import time
    import threading
    import traceback
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.write = get_write_function(self.output, False)

        def test_output_to_file(self):
            with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
                filename = f.name
            with pysnooper.snoop(filename):
                pass
            with open(filename) as f:
                output = f.read()
            os.unlink(filename)

# Generated at 2022-06-16 19:24:24.042539
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     UnavailableSource())



# Generated at 2022-06-16 19:24:28.491626
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')



# Generated at 2022-06-16 19:24:35.809462
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import io
    import contextlib
    import unittest
    import unittest.mock
    import pysnooper

    class TestTracerTrace(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.tracer = pysnooper.Snooper(self.output, watch=('foo', 'bar'))
            self.tracer.thread_info = False
            self.tracer.thread_info_padding = 0
            self.tracer.start_times = {}
            self.tracer.frame_to_local_reprs = {}
            self.tracer.target_codes = set()
            self.tracer.target_frames = set()
            self.tracer.last_source_path = None
            self.tr