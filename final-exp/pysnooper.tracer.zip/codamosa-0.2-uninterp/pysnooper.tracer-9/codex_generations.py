

# Generated at 2022-06-16 19:15:39.061483
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import sys
    import io
    import pytest
    import shutil
    import pathlib
    import contextlib

    @contextlib.contextmanager
    def temp_file(content=None):
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as f:
            if content:
                f.write(content)
        try:
            yield f.name
        finally:
            os.remove(f.name)

    def test_write_function(write_function, content, expected_content):
        with temp_file() as temp_file_name:
            write_function(temp_file_name, content)
            with open(temp_file_name) as f:
                assert f.read() == expected_content


# Generated at 2022-06-16 19:15:42.516998
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() is f()



# Generated at 2022-06-16 19:15:50.357716
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with default args
    tracer = Tracer()
    tracer.__enter__()
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local.__dict__ == {'original_trace_functions': []}
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False

# Generated at 2022-06-16 19:16:02.399592
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile
    import types
    import unittest

    class TestCase(unittest.TestCase):
        def test_1(self):
            def f():
                return 1
            frame = inspect.currentframe()
            path, source = get_path_and_source_from_frame(frame)
            self.assertEqual(path, __file__)
            self.assertEqual(source[frame.f_lineno - 1], '            return 1')

        def test_2(self):
            def f():
                return 1
            frame = inspect.currentframe()
            path, source = get_path_and_source_from_frame(frame)
            self.assertEqual(path, __file__)

# Generated at 2022-06-16 19:16:14.400897
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_output(self):
            self.snooper.write('test')
            self.assertEqual(self.output.getvalue(), 'test\n')

        def test_watch(self):
            self.snooper.watch = ('foo', 'bar')
            self.assertEqual(self.snooper.watch, [CommonVariable('foo'),
                                                  CommonVariable('bar')])

        def test_watch_explode(self):
            self.snooper.watch_explode = ('foo', 'bar')
            self.assertEqual

# Generated at 2022-06-16 19:16:19.611415
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import pysnooper
    import threading
    import time
    import datetime
    import traceback
    import functools
    import inspect
    import pycompat
    import utils
    import opcode
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:27.007374
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import os
    import datetime
    import threading
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:34.547448
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:16:42.066504
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest
    import unittest.mock

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(output=self.output)

        def test_default_values(self):
            self.assertEqual(self.snooper.watch, [])
            self.assertEqual(self.snooper.depth, 1)
            self.assertEqual(self.snooper.prefix, '')
            self.assertEqual(self.snooper.thread_info, False)
            self.assertEqual(self.snooper.custom_repr, ())
            self.assertEqual(self.snooper.max_variable_length, 100)

# Generated at 2022-06-16 19:16:53.360965
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import tempfile
    import contextlib
    import io
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.tracer
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pys

# Generated at 2022-06-16 19:17:19.310111
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper

# Generated at 2022-06-16 19:17:29.662537
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import get_write_function
    import pycompat
    import os
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISAB

# Generated at 2022-06-16 19:17:38.550978
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import sys
    import io
    import contextlib
    import pathlib
    import shutil
    import subprocess
    import time
    import threading
    import queue
    import random
    import string
    import pytest

    def get_random_string(length=10):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def get_random_file_path():
        return os.path.join(tempfile.gettempdir(), get_random_string())

    def get_random_file_path_with_extension(extension):
        return os.path.join(tempfile.gettempdir(), get_random_string() + '.' + extension)


# Generated at 2022-06-16 19:17:49.655514
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import opcode
    import traceback
    import functools
    import threading
    import itertools
    import os
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:17:56.528956
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0].startswith('def test_get_path_and_source_from_frame():')



# Generated at 2022-06-16 19:18:00.799618
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][1] == 'def f():'



# Generated at 2022-06-16 19:18:08.076876
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:19.059547
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper import snoop
    from pysnooper.utils import get_write_function
    from pysnooper.tracer import Tracer
    from pysnooper.variable import CommonVariable
    from pysnooper.variable import Exploding
    from pysnooper.variable import BaseVariable
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.utils import inspect
    from pysnooper.utils import DISABLED
    from pysnooper.utils import thread_global
    from pysnooper.utils import datetime_module
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import opcode
    from pysnooper.utils import funct

# Generated at 2022-06-16 19:18:30.265819
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:18:37.993055
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import io
    import sys
    import shutil
    import contextlib
    import pathlib
    import pytest
    import six
    import six.moves
    import six.moves.builtins
    import six.moves.cStringIO
    import six.moves.StringIO
    import six.moves.tkinter_simpledialog
    import six.moves.tkinter_filedialog
    import six.moves.tkinter_messagebox
    import six.moves.tkinter_scrolledtext
    import six.moves.tkinter_tix
    import six.moves.tkinter_ttk
    import six.moves.tkinter_constants
    import six.moves.tkinter_dnd
    import six.moves.tkinter_color

# Generated at 2022-06-16 19:19:01.297652
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import unittest
    import sys
    import inspect
    import threading
    import functools
    import pysnooper
    import datetime
    import pycompat
    import os
    import utils
    import opcode
    import traceback
    import thread_global
    import get_path_and_source_from_frame
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:19:12.092758
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import traceback
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def test_exception_is_raised(self):
            def f():
                with pysnooper.snoop():
                    raise Exception('foo')
            with self.assertRaises(Exception) as cm:
                f()
            self.assertEqual(cm.exception.args, ('foo',))

        def test_exception_is_raised_in_generator(self):
            def f():
                def g():
                    with pysnooper.snoop():
                        yield
                    raise Exception('foo')
                for _ in g():
                    pass

# Generated at 2022-06-16 19:19:17.622353
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:19:26.611179
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:19:38.175112
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    import os
    import sys
    import shutil
    import importlib
    import time
    import random
    import string
    import types
    import textwrap
    import inspect
    import tokenize
    import io
    import token
    import traceback
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file_path = os.path.join(self.temp_dir, 'test.py')
            self.temp_file = open(self.temp_file_path, 'w')
            self.temp_file.write('def foo():\n    pass\n')
            self.temp_file.close()

# Generated at 2022-06-16 19:19:50.887755
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import os
    import get_write_function
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import DIS

# Generated at 2022-06-16 19:20:02.999809
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import pycompat


# Generated at 2022-06-16 19:20:12.824569
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return g()
    def g():
        return h()
    def h():
        return i()
    def i():
        return j()
    def j():
        return k()
    def k():
        return l()
    def l():
        return m()
    def m():
        return n()
    def n():
        return o()
    def o():
        return p()
    def p():
        return q()
    def q():
        return r()
    def r():
        return s()
    def s():
        return t()
    def t():
        return u()
    def u():
        return v()
    def v():
        return w()
    def w():
        return x()
    def x():
        return y()
    def y():
        return z()

# Generated at 2022-06-16 19:20:24.246639
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import sys
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:20:36.234964
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
   

# Generated at 2022-06-16 19:21:09.978594
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import io
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils

# Generated at 2022-06-16 19:21:14.151279
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() is f()



# Generated at 2022-06-16 19:21:22.437819
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = x + 1
        z = x + 2
        return y, z
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    result = get_local_reprs(frame)
    assert result == {'x': '0', 'y': '1', 'z': '2'}



# Generated at 2022-06-16 19:21:30.630179
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isasyncgenfunction
    from pysnooper.utils import isgeneratorfunction
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import time_isoformat
    from pysnooper.utils import get_shortish_repr
    from pysnooper.utils import BaseVariable

# Generated at 2022-06-16 19:21:41.974632
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper import snoop
    from pysnooper.utils import get_write_function
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import iscoroutinefunction
    from pysnooper.utils import isasyncgenfunction
    from pysnooper.utils import isgeneratorfunction
    from pysnooper.utils import timedelta_format
    from pysnooper.utils import time_isoformat
    from pysnooper.utils import get_shortish_repr
    from pysnooper.utils import BaseVariable

# Generated at 2022-06-16 19:21:54.445029
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import datetime
    import threading
    import functools
    import inspect
    import traceback
    import pycompat
    import opcode
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.DISABLED
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.Tracer
    import pysno

# Generated at 2022-06-16 19:22:05.725176
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import unittest
    import warnings
    import weakref
    import os
    import datetime
    import pycompat
    import inspect
    import functools
    import itertools
    import opcode
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:22:19.092472
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import sys
    import types
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import os
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import pycompat
    import DISABLED
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:22:20.764338
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(watch='foo'):
        foo = 1
        foo = 2
        foo = 3


# Generated at 2022-06-16 19:22:32.924131
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    from .utils import WritableStream
    import io
    import sys
    import os
    import tempfile
    import pytest
    import os.path
    import shutil
    import contextlib
    import os
    import sys
    import io
    import tempfile
    import pytest
    import os.path
    import shutil
    import contextlib
    import os
    import sys
    import io
    import tempfile
    import pytest
    import os.path
    import shutil
    import contextlib
    import os
    import sys
    import io
    import tempfile
    import pytest
    import os.path
    import shutil
    import contextlib
    import os
    import sys
    import io
    import tempfile
    import pytest
    import os.path
    import shut

# Generated at 2022-06-16 19:23:10.583659
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.trace(None, None, None)


# Generated at 2022-06-16 19:23:20.219897
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        bb = 28
        cc = 29
        dd = 30
        ee = 31
        ff = 32
        gg = 33
        hh = 34
        ii = 35
        jj = 36
        kk = 37
        ll

# Generated at 2022-06-16 19:23:30.860648
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import six
    import pytest
    import pathlib
    import contextlib

    @contextlib.contextmanager
    def temp_dir():
        temp_dir = tempfile.mkdtemp()
        try:
            yield temp_dir
        finally:
            shutil.rmtree(temp_dir)

    def test_write_function(output, expected_output, overwrite=False):
        write = get_write_function(output, overwrite)
        write('hello')
        write('world')
        assert expected_output.getvalue() == 'helloworld'

    with temp_dir() as temp_dir:
        with io.StringIO() as output:
            test_write_function(output, output)


# Generated at 2022-06-16 19:23:34.540874
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:23:41.304238
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import sys
    import threading
    import traceback
    import unittest

    class TestTracer___exit__(unittest.TestCase):
        def test_it(self):
            def test_function():
                with pysnooper.snoop():
                    pass
            with self.assertRaises(Exception):
                test_function()

    unittest.main()


# Generated at 2022-06-16 19:23:51.703628
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import datetime
    import os
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import get_path_and_source_from_frame
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:23:57.253055
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     inspect.getsourcelines(test_get_path_and_source_from_frame)[0])
test_get_path_and_source_from_frame()



# Generated at 2022-06-16 19:24:02.492626
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('test_get_path_and_source_from_frame.py')
    assert f()[1][1].startswith('def f():')
test_get_path_and_source_from_frame()



# Generated at 2022-06-16 19:24:05.917647
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def f():'



# Generated at 2022-06-16 19:24:16.355287
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import tempfile
    import shutil
    import sys
    import types

    def get_path_and_source_from_frame(frame):
        return inspect.getsourcelines(frame)

    def test_file():
        def test_function():
            return get_path_and_source_from_frame(inspect.currentframe())

        return test_function()

    assert test_file()[0][0].startswith('def test_file():')

    def test_ipython():
        try:
            import IPython
        except ImportError:
            return
        ipython_shell = IPython.get_ipython()
        ipython_shell.run_cell('def test_function():\n    return get_path_and_source_from_frame(inspect.currentframe())')
       