

# Generated at 2022-06-16 19:15:23.838362
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import unittest

    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.snooper = Tracer(self.output)

        def test_default_values(self):
            self.assertEqual(self.snooper.watch, [])
            self.assertEqual(self.snooper.depth, 1)
            self.assertEqual(self.snooper.prefix, '')
            self.assertEqual(self.snooper.thread_info, False)
            self.assertEqual(self.snooper.custom_repr, ())
            self.assertEqual(self.snooper.max_variable_length, 100)

# Generated at 2022-06-16 19:15:35.313993
# Unit test for constructor of class Tracer

# Generated at 2022-06-16 19:15:46.171537
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import functools
    import inspect
    import datetime
    import pycompat
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.Tracer
    import pysnooper.test_utils
    import pysnooper.test_utils.test

# Generated at 2022-06-16 19:15:49.936454
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:16:02.012467
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test that Tracer constructor raises TypeError if watch is not a tuple
    with pytest.raises(TypeError):
        Tracer(watch='foo')

    # Test that Tracer constructor raises TypeError if watch_explode is not a tuple
    with pytest.raises(TypeError):
        Tracer(watch_explode='foo')

    # Test that Tracer constructor raises TypeError if depth is not an integer
    with pytest.raises(TypeError):
        Tracer(depth='foo')

    # Test that Tracer constructor raises TypeError if prefix is not a string
    with pytest.raises(TypeError):
        Tracer(prefix=1)

    # Test that Tracer constructor raises TypeError if overwrite is not a boolean
    with pytest.raises(TypeError):
        Tracer(overwrite='foo')

    #

# Generated at 2022-06-16 19:16:03.172988
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-16 19:16:14.893178
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import opcode
    import traceback
    import datetime
    import os
    import pycompat
    import utils
    from utils import get_path_and_source_from_frame
    from utils import get_local_reprs
    from utils import get_write_function
    from utils import CommonVariable
    from utils import Exploding
    from utils import BaseVariable
    from utils import DISABLED
    from utils import pycompat
    from utils import thread_global
    from utils import opcode
    from utils import utils
    from utils import get_path_and_source_from_frame
    from utils import get_local_reprs
    from utils import get

# Generated at 2022-06-16 19:16:20.292387
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import datetime
    import os
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_path_and_source_from_frame
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:16:27.690417
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import datetime
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:16:35.293163
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import os
    import pycompat
    import datetime
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:02.706143
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.get_write_function

# Generated at 2022-06-16 19:17:15.623727
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat

# Generated at 2022-06-16 19:17:27.587613
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:17:37.871927
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y):
        z = x + y
        return z
    frame = inspect.currentframe()
    frame = frame.f_back
    assert get_local_reprs(frame, max_length=10) == {'x': '1', 'y': '2', 'z': '3'}
    assert get_local_reprs(frame, max_length=10, normalize=True) == {'x': '1', 'y': '2', 'z': '3'}
    assert get_local_reprs(frame, max_length=10, normalize=True,
                           watch=[CommonVariable('z')]) == {'x': '1', 'y': '2', 'z': '3'}

# Generated at 2022-06-16 19:17:42.191779
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())
    assert f() is f()  # Caching works



# Generated at 2022-06-16 19:17:51.540990
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import opcode
    import traceback
    import itertools
    import datetime
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:57.939972
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        c = 3
        return locals()
    frame = f.__code__.co_consts[0].co_consts[0].co_consts[0].co_consts[0]
    assert get_local_reprs(frame) == {'a': '1', 'b': '2', 'c': '3'}



# Generated at 2022-06-16 19:18:06.192103
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs
    from pysnooper.utils import truncate
    from pysnooper.utils import ensure_tuple
    from pysnooper.utils import get_write_function
    from pysnooper.utils import BaseVariable
    from pysnooper.utils import CommonVariable
    from pysnooper.utils import Exploding
    from pysnooper.utils import pycompat
    from pysnooper.utils import DISABLED
    from pysnooper.utils import thread_global
    from pysnooper.utils import dat

# Generated at 2022-06-16 19:18:17.185890
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test that Tracer is callable
    Tracer()

    # Test that Tracer can be called with no arguments
    Tracer()()

    # Test that Tracer can be called with a function
    def foo():
        pass
    Tracer()(foo)

    # Test that Tracer can be called with a class
    class Foo:
        pass
    Tracer()(Foo)

    # Test that Tracer can be called with a class with a method
    class Foo:
        def bar(self):
            pass
    Tracer()(Foo)

    # Test that Tracer can be called with a class with a static method
    class Foo:
        @staticmethod
        def bar():
            pass
    Tracer()(Foo)

    # Test that Tracer can be called with a class with a class method

# Generated at 2022-06-16 19:18:19.355475
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert foo() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:18:42.595875
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0].endswith('/test_get_path_and_source_from_frame.py')
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')


# Generated at 2022-06-16 19:18:46.946271
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import sys
    import inspect
    import threading
    import functools
    import datetime
    import os
    import pycompat
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
    import pysnooper.pycompat
   

# Generated at 2022-06-16 19:18:55.473197
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import datetime
    import threading
    import functools
    import inspect
    import traceback
    import pycompat
    import opcode
    import pysnooper
    import utils
    import pycompat
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycomp

# Generated at 2022-06-16 19:19:02.373189
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.variable
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write

# Generated at 2022-06-16 19:19:14.224042
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.snoopapi
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.tracer
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.datetime_module
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_local_reprs
    import pysnooper.BaseVariable
    import pysnooper

# Generated at 2022-06-16 19:19:18.714753
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__, __file__)



# Generated at 2022-06-16 19:19:27.229942
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import pytest
    import pysnooper
    import inspect
    import threading
    import datetime
    import os
    import opcode
    import itertools
    import traceback
    import functools
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:19:36.237311
# Unit test for constructor of class Tracer
def test_Tracer():
    import pysnooper
    import sys
    import io
    import os
    import datetime
    import time
    import threading
    import random
    import unittest
    import unittest.mock
    import tempfile
    import contextlib
    import functools
    import inspect
    import traceback
    import pycompat
    import utils
    import opcode
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:19:38.123882
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test Tracer.__init__
    with Tracer():
        pass


# Generated at 2022-06-16 19:19:46.968529
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:15.067737
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:25.364219
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import itertools
    import opcode
    import traceback
    import datetime
    import os
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_path_and_source_from_frame
    import get_local_reprs
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:20:37.749542
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import datetime
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:49.726937
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    from . import utils
    from .utils import FileWriter
    from .utils import shitcode

    def test_write_function(output, expected_output):
        write_function = get_write_function(output, overwrite=False)
        write_function('hello')
        assert output.getvalue() == expected_output

    def test_write_function_overwrite(output, expected_output):
        write_function = get_write_function(output, overwrite=True)
        write_function('hello')
        assert output.getvalue() == expected_output

    def test_write_function_overwrite_error(output):
        with pytest.raises(Exception):
            get_write_function(output, overwrite=True)

# Generated at 2022-06-16 19:21:01.718352
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:21:05.284047
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_filename,
                                          f.__code__.co_firstlineno)



# Generated at 2022-06-16 19:21:16.542280
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import sys
    import os
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import datetime
    import datetime_module
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:21:23.662622
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     UnavailableSource())
test_get_path_and_source_from_frame()



# Generated at 2022-06-16 19:21:30.987638
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.tracer
    import pysnooper.pycompat
    import pysnooper.datetime_module
    import pysnooper.opcode
    import pysnooper.inspect
    import pysnooper.functools
    import pysnooper.threading
    import pysnooper.pycompat
    import pysnooper.pycompat.collections_abc
    import pysnooper.pycompat.collections_abc
    import pysnooper.pycompat.collections_abc
    import pysnooper.pycompat.collections_abc
   

# Generated at 2022-06-16 19:21:32.089491
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert foo() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:22:19.660830
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper
    import sys
    import threading
    import time
    import traceback
    import types

    # Test with default args
    tracer = pysnooper.Tracer()
    tracer._write = lambda s: None
    tracer.write = lambda s: None
    tracer.depth = 1
    tracer.prefix = ''
    tracer.thread_info = False
    tracer.thread_info_padding = 0
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.thread_local = threading.local()
    tracer.custom_repr = ()
    tracer.last_source_path = None
    tracer.max_variable_length = 100
    tracer.normalize = False
    tracer.relative

# Generated at 2022-06-16 19:22:23.347390
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:22:34.306142
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import pycompat
    import os


# Generated at 2022-06-16 19:22:46.283108
# Unit test for function get_write_function
def test_get_write_function():
    def write_to_stderr(s):
        stderr = sys.stderr
        try:
            stderr.write(s)
        except UnicodeEncodeError:
            # God damn Python 2
            stderr.write(utils.shitcode(s))
    assert get_write_function(None, False) == write_to_stderr
    assert get_write_function(sys.stderr, False) == write_to_stderr
    assert get_write_function(sys.stderr, True) == write_to_stderr
    assert get_write_function(write_to_stderr, False) == write_to_stderr
    assert get_write_function(write_to_stderr, True) == write_to_stderr
    assert get_write_

# Generated at 2022-06-16 19:22:55.748137
# Unit test for method __exit__ of class Tracer

# Generated at 2022-06-16 19:23:07.117734
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with default args
    tracer = Tracer()
    tracer.__enter__()
    assert tracer.write == sys.stdout.write
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local == threading.local()
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100

# Generated at 2022-06-16 19:23:16.430289
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (
        f.__code__.co_filename,
        UnavailableSource()
    )
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (
        f.__code__.co_filename,
        UnavailableSource()
    )
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame)

# Generated at 2022-06-16 19:23:23.961614
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat

    # 1. Assign parameters passed in
    output = None
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    exc_type = None
    exc

# Generated at 2022-06-16 19:23:32.687625
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    import datetime
    import threading
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:23:44.656589
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import functools
    import inspect
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import inspect
    import functools
    import sys
    import os
    import datetime
    import threading
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import pycompat
    import utils
    import thread_global
    import inspect
    import functools
    import sys
    import os
    import datetime
    import threading
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
