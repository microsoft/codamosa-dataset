

# Generated at 2022-06-16 19:15:28.368112
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(watch=('foo', 'bar'))
    def foo(a, b, c):
        return a + b + c

    @pysnooper.snoop(watch=('foo', 'bar'))
    def bar(a, b, c):
        return a + b + c

    foo(1, 2, 3)
    bar(1, 2, 3)


# Generated at 2022-06-16 19:15:37.250365
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import DISABLED
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:15:38.578949
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-16 19:15:47.675680
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', delete=False) as f:
        f.write('hello')
    file_writer = FileWriter(f.name, overwrite=False)
    file_writer.write('world')
    with open(f.name, 'r', encoding='utf-8') as f:
        assert f.read() == 'helloworld'
    os.remove(f.name)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', delete=False) as f:
        f.write('hello')
    file_writer = FileWriter(f.name, overwrite=True)
    file_writer.write('world')

# Generated at 2022-06-16 19:15:51.336296
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:16:03.452226
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    from pysnooper.tracer import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.utils import pycompat
    from pysnooper.utils import utils
    from pysnooper.utils import threading
    from pysnooper.utils import datetime_module
    from pysnooper.utils import inspect
    from pysnooper.utils import functools
    from pysnooper.utils import os
    from pysnooper.utils import DISABLED
    from pysnooper.utils import thread_global
    from pysnooper.utils import opcode
    from pysnooper.utils import traceback
    from pysnooper.utils import get_path_and_source_from_frame

# Generated at 2022-06-16 19:16:15.111826
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper
    import sys
    import threading
    import types
    import unittest
    import unittest.mock
    import warnings
    import weakref
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper.utils
    import pysnooper

# Generated at 2022-06-16 19:16:16.363037
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    test_Tracer_trace()

# Generated at 2022-06-16 19:16:23.070646
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import datetime_module
    import os
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import get_write_function
    import pycompat

    DISABLED = False
    thread_global.__dict__.setdefault('depth', -1)
    calling_frame = inspect.currentframe().f_back
    if not self._is_internal_frame(calling_frame):
        calling_frame.f_trace = self.trace
        self.target_frames.add(calling_frame)


# Generated at 2022-06-16 19:16:27.649452
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())



# Generated at 2022-06-16 19:16:57.079220
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:04.314582
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return g()
    def g():
        return h()
    def h():
        return i()
    def i():
        return j()
    def j():
        return k()
    def k():
        return l()
    def l():
        return m()
    def m():
        return n()
    def n():
        return o()
    def o():
        return p()
    def p():
        return q()
    def q():
        return r()
    def r():
        return s()
    def s():
        return t()
    def t():
        return u()
    def u():
        return v()
    def v():
        return w()
    def w():
        return x()
    def x():
        return y()
    def y():
        return z()

# Generated at 2022-06-16 19:17:16.235879
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import datetime
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import DISABLED
    import get_write_function
    import get_path_and_source_from_frame
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:27.954221
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest
    import os
    import os.path
    import sys
    import pytest

# Generated at 2022-06-16 19:17:38.269566
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import datetime
    import pytest
    import sys
    import os
    import re
    import time
    import datetime
    import pytest
    import sys
    import os
    import re
    import time
    import datetime
    import pytest
    import sys
    import os
    import re
    import time
    import datetime
    import pytest
    import sys
    import os
    import re
    import time
    import datetime
    import pytest
    import sys
    import os
    import re
    import time
    import datetime
    import pytest
    import sys
    import os
    import re
    import time
    import datetime
    import pytest
    import sys
    import os
    import re
    import time

# Generated at 2022-06-16 19:17:49.472137
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
   

# Generated at 2022-06-16 19:18:01.666433
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import os
    import pycompat
    import utils
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:18:14.665605
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:18:24.336797
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import time
    import datetime
    import pycompat
    import sys
    import os
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import functools
    import inspect
    import opcode
    import os
    import sys
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback
    import functools
    import inspect
    import opcode
    import os
    import sys
    import re
    import collections
    import datetime as datetime_module
    import itertools
    import threading
    import traceback

# Generated at 2022-06-16 19:18:25.788988
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-16 19:18:55.813419
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f() == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-16 19:19:07.375662
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        c = 3
        return locals()
    frame = f.__code__.co_firstlineno + 1
    locals_ = f()
    assert get_local_reprs(locals_, frame) == {'a': '1', 'b': '2', 'c': '3'}
    assert get_local_reprs(locals_, frame, watch=[CommonVariable('a')]) == {'a': '1'}
    assert get_local_reprs(locals_, frame, watch=[CommonVariable('a'), CommonVariable('b')]) == {'a': '1', 'b': '2'}

# Generated at 2022-06-16 19:19:20.698140
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import os
    import pycompat
    import opcode
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:19:28.387508
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:19:32.947713
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame) == (__file__,
                                                     open(__file__).read().splitlines())



# Generated at 2022-06-16 19:19:43.806560
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import re
    import threading
    import time
    import functools
    import inspect
    import pycompat
    import datetime
    import traceback
    import opcode
    import itertools
    import functools
    import threading
    import inspect
    import pycompat
    import datetime
    import traceback
    import opcode
    import itertools
    import functools
    import threading
    import inspect
    import pycompat
    import datetime
    import traceback
    import opcode
    import itertools
    import functools
    import threading
    import inspect
    import pycompat
    import datetime
    import traceback
    import opcode
    import itertools
    import functools

# Generated at 2022-06-16 19:19:55.933498
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import pycompat
    import opcode
    import os
    import itertools
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_write_function
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.get_local_reprs
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global

# Generated at 2022-06-16 19:20:07.906363
# Unit test for constructor of class Tracer

# Generated at 2022-06-16 19:20:13.234780
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b'hello')
        f.close()
        file_writer = FileWriter(f.name, overwrite=False)
        file_writer.write('world')
        with open(f.name, 'r') as f:
            assert f.read() == 'helloworld'
        os.remove(f.name)


# Generated at 2022-06-16 19:20:24.430865
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import pycompat
    import os
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:21:48.267925
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:22:01.288708
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = x + 1
        return y
    frame = f.__code__.co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts[0].co_consts

# Generated at 2022-06-16 19:22:09.669407
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading

    def test_Tracer___call___1():
        def foo():
            pass
        tracer = pysnooper.Tracer()
        assert tracer.__call__(foo) is foo
        assert tracer.__call__(foo) is not foo
        assert inspect.isfunction(tracer.__call__(foo))
        assert inspect.isfunction(tracer.__call__(foo))
        assert inspect.isfunction(tracer.__call__(foo))
        assert inspect.isfunction(tracer.__call__(foo))
        assert inspect.isfunction(tracer.__call__(foo))
        assert inspect.isfunction(tracer.__call__(foo))

# Generated at 2022-06-16 19:22:21.177351
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    from pysnooper import utils
    from pysnooper.utils import pycompat
    from pysnooper.utils import opcode
    from pysnooper.utils import inspect
    from pysnooper.utils import functools
    from pysnooper.utils import threading
    from pysnooper.utils import sys
   

# Generated at 2022-06-16 19:22:33.380582
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import BaseVariable
    import CommonVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:22:45.868686
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import sys
    import shutil
    import pytest
    from . import utils
    from . import pycompat
    from . import test_utils
    from . import test_utils_2
    from . import test_utils_3
    from . import test_utils_4
    from . import test_utils_5
    from . import test_utils_6
    from . import test_utils_7
    from . import test_utils_8
    from . import test_utils_9
    from . import test_utils_10
    from . import test_utils_11
    from . import test_utils_12
    from . import test_utils_13
    from . import test_utils_14
    from . import test_utils_15
    from . import test_utils_16

# Generated at 2022-06-16 19:22:50.797656
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert foo()[0].endswith('test_get_path_and_source_from_frame.py')
    assert foo()[1][0].startswith('def foo():')



# Generated at 2022-06-16 19:22:58.011180
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    import os
    import sys
    import shutil
    import contextlib
    import six
    import pytest
    import pathlib
    import subprocess

    @contextlib.contextmanager
    def temp_file(content):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            f.write(content)
        try:
            yield f.name
        finally:
            os.remove(f.name)

    def test_write_function(output, content, expected_content):
        write = get_write_function(output, overwrite=False)
        write(content)
        if isinstance(output, six.string_types):
            with open(output, 'r') as f:
                assert f.read() == expected_content

# Generated at 2022-06-16 19:23:02.060706
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')


# Generated at 2022-06-16 19:23:12.420192
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import shutil
    import unittest
    import unittest.mock
    import pysnooper
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.tracer
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.inspect
    import pysnooper.datetime_module
    import pysnooper.get_write_function
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.tracer
    import pysnooper.thread_global
    import pysnooper.opcode
    import pysnooper.inspect
    import pysnooper.datetime_module
