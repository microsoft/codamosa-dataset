

# Generated at 2022-06-16 19:15:13.639891
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Testing method __exit__ of class Tracer
    # No input
    # No output
    return None


# Generated at 2022-06-16 19:15:19.202302
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import datetime_module
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import datetime_module
    import pycompat
    import os
    import inspect
    import functools
    import threading
    import itertools
    import traceback
    import opcode
    import pycompat


# Generated at 2022-06-16 19:15:32.273088
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:15:39.263725
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_path_and_source_from_frame
    import pysnooper.get_write_function
    import pysnooper.BaseVariable
    import pysnooper.CommonVariable
    import pysnooper.Exploding
    import pysnooper.DISABLED
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.thread_global
    import pysnooper.get_path_and_source

# Generated at 2022-06-16 19:15:48.136004
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y):
        z = x + y
        return z

    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back

# Generated at 2022-06-16 19:16:00.461936
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import os
    import tempfile
    import contextlib
    import functools
    import inspect
    import threading
    import datetime
    import traceback
    import itertools
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:16:13.019588
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import inspect
    import threading
    import itertools
    import traceback
    import functools
    import pycompat
    import opcode
    import datetime
    import pysnooper
    import utils
    import thread_global
    import pycompat
    import inspect
    import datetime_module
    import threading
    import functools
    import traceback
    import itertools
    import opcode
    import sys
    import os
    import utils
    import pycompat
    import inspect
    import threading
    import functools
    import traceback
    import itertools
    import opcode
    import sys
    import os
    import utils
    import pycompat
    import inspect
    import threading
    import functools
    import trace

# Generated at 2022-06-16 19:16:19.823957
# Unit test for constructor of class Tracer
def test_Tracer():
    # test for watch
    tracer = Tracer(watch=('foo', 'bar'))
    assert tracer.watch == [CommonVariable('foo'), CommonVariable('bar')]
    tracer = Tracer(watch=('foo', 'bar', 'baz'))
    assert tracer.watch == [CommonVariable('foo'), CommonVariable('bar'),
                            CommonVariable('baz')]
    tracer = Tracer(watch=('foo', 'bar', 'baz', 'qux'))
    assert tracer.watch == [CommonVariable('foo'), CommonVariable('bar'),
                            CommonVariable('baz'), CommonVariable('qux')]
    tracer = Tracer(watch=('foo', 'bar', 'baz', 'qux', 'quux'))

# Generated at 2022-06-16 19:16:27.237582
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper
    import sys
    import threading
    import traceback
    import types
    import unittest
    import unittest.mock
    import warnings

    from pysnooper.utils import get_path_and_source_from_frame

    def test_enter_exit():
        with unittest.mock.patch('pysnooper.snoop.Tracer.write') as mock_write:
            with pysnooper.snoop():
                pass
        assert mock_write.call_count == 0


# Generated at 2022-06-16 19:16:34.700229
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:17:28.287477
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test for method trace of class Tracer
    # Input arguments:
    #   frame :
    #   event :
    #   arg :
    # Output:
    #   return value :
    #   frame :
    #   event :
    #   arg :
    #   indent :
    #   timestamp :
    #   thread_info :
    #   line_no :
    #   source_line :
    #   newish_string :
    #   name :
    #   value_repr :
    #   candidate_line_no :
    #   candidate_source_line :
    #   code_byte :
    #   ended_by_exception :
    #   return_value_repr :
    #   exception :
    pass


# Generated at 2022-06-16 19:17:32.502691
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_filename,
                                          f.__code__.co_firstlineno)



# Generated at 2022-06-16 19:17:45.272000
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import pysnooper
    import pycompat
    import os
    import utils
    import opcode
    import traceback
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:17:53.738002
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile
    import textwrap
    import tokenize
    import traceback
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file_path = os.path.join(self.temp_dir, 'temp.py')
            self.source = textwrap.dedent('''
                def foo():
                    pass
            ''').strip()
            with open(self.temp_file_path, 'w') as temp_file:
                temp_file.write(self.source)
            self.frame = inspect.currentframe()
            while self.frame.f_code.co_filename != self.temp_file_path:
                self

# Generated at 2022-06-16 19:18:03.693429
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with default args
    tracer = Tracer()
    tracer.__enter__()
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local.__dict__ == {'original_trace_functions': []}
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False

# Generated at 2022-06-16 19:18:15.734434
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import time
    import datetime
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
    import io
    import sys
    import time
    import os
   

# Generated at 2022-06-16 19:18:18.828360
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    assert get_path_and_source_from_frame(frame)



# Generated at 2022-06-16 19:18:26.796498
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0] == 'def test_get_path_and_source_from_frame():'
    assert f()[1][1] == '    def f():'
    assert f()[1][2] == '        return get_path_and_source_from_frame(inspect.currentframe())'
    assert f()[1][3] == '    assert f()[0] == __file__'
    assert f()[1][4] == '    assert f()[1][0] == \'def test_get_path_and_source_from_frame():\''

# Generated at 2022-06-16 19:18:36.209052
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import time
    import sys
    import io
    import contextlib
    import six
    import pytest
    import os.path
    import re
    import sys
    import six
    import pycompat
    import os
    import os.path
    import re
    import sys
    import six
    import pycompat
    import os
    import os.path
    import re
    import sys
    import six
    import pycompat
    import os
    import os.path
    import re
    import sys
    import six
    import pycompat
    import os
    import os.path
    import re
    import sys
    import six
    import pycompat
    import os
    import os.path
    import re
    import sys
    import six
   

# Generated at 2022-06-16 19:18:46.972129
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import pysnooper
    import inspect
    import functools
    import threading
    import sys
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:19:11.332071
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False) is not None
    assert get_write_function(sys.stdout, False) is not None
    assert get_write_function(sys.stderr, False) is not None
    assert get_write_function(sys.stdout.buffer, False) is not None
    assert get_write_function(sys.stderr.buffer, False) is not None
    assert get_write_function(utils.WritableStream(), False) is not None
    assert get_write_function(utils.WritableStream().buffer, False) is not None
    assert get_write_function(utils.WritableStream().buffer, False) is not None
    assert get_write_function(utils.WritableStream().buffer, False) is not None

# Generated at 2022-06-16 19:19:17.707103
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:19:18.464953
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-16 19:19:27.027403
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')
    assert f()[1][1].startswith('    def f():')
    assert f()[1][2].startswith('        return get_path_and_source_from_frame(')
    assert f()[1][3].startswith('    assert f()[0] == __file__')
    assert f()[1][4].startswith('    assert f()[1][0].startswith(')
    assert f()[1][5].startswith('    assert f()[1][1].startswith(')
   

# Generated at 2022-06-16 19:19:38.715450
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import sys
    import threading
    import datetime
    import os
    import inspect
    import functools
    import pycompat
    import opcode
    import traceback
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import BaseVariable
    import Exploding
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:19:47.206672
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo(x):
        return x + 1

    with Tracer(watch=('x',)):
        foo(1)

    with Tracer(watch=('x',), depth=2):
        foo(1)

    with Tracer(watch=('x',), depth=2, prefix='ZZZ '):
        foo(1)

    with Tracer(watch=('x',), depth=2, prefix='ZZZ ', overwrite=True):
        foo(1)

    with Tracer(watch=('x',), depth=2, prefix='ZZZ ', overwrite=True,
                thread_info=True):
        foo(1)


# Generated at 2022-06-16 19:19:58.546728
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import functools
    import inspect
    import traceback
    import itertools
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import BaseVariable
    import CommonVariable
    import Exploding
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:20:10.404737
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import io
    import threading
    import inspect
    import functools
    import datetime
    import pysnooper
    import pycompat
    import utils
    import opcode
    import traceback
    import thread_global
    import os
    import itertools
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
   

# Generated at 2022-06-16 19:20:22.329675
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys
    import types
    import tempfile
    import os
    import shutil
    import time
    import random
    import string
    import importlib
    import importlib.util
    import importlib.machinery

    def get_random_string(length):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def get_random_source(length):
        return '\n'.join(get_random_string(random.randint(1, 100))
                         for _ in range(length))

    def get_random_module_name():
        return get_random_string(random.randint(1, 10))

    def get_random_file_name():
        return get_random_string(random.randint(1, 10)) + '.py'

   

# Generated at 2022-06-16 19:20:25.684628
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return get_path_and_source_from_frame(inspect.currentframe())
    assert f()[0] == __file__
    assert f()[1][0].startswith('def test_get_path_and_source_from_frame():')


# Generated at 2022-06-16 19:21:11.889596
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-16 19:21:20.242723
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_

# Generated at 2022-06-16 19:21:23.027556
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(watch=('foo', 'bar')):
        foo = 'foo'
        bar = 'bar'


# Generated at 2022-06-16 19:21:30.806250
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(watch=('foo', 'bar'))
    def foo(foo, bar):
        pass
    assert foo.__wrapped__.__code__ == foo.__code__
    assert foo.__wrapped__.__name__ == foo.__name__
    assert foo.__wrapped__.__doc__ == foo.__doc__
    assert foo.__wrapped__.__dict__ == foo.__dict__
    assert foo.__wrapped__.__defaults__ == foo.__defaults__
    assert foo.__wrapped__.__kwdefaults__ == foo.__kwdefaults__
    assert foo.__wrapped__.__annotations__ == foo.__annotations__
    assert foo.__wrapped__.__globals__ == foo.__globals__

# Generated at 2022-06-16 19:21:42.009103
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    import sys
    import io
    import pysnooper
    import threading
    import time
    import datetime
    import inspect
    import traceback
    import opcode
    import functools
    import os
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:21:48.118433
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from pysnooper.utils import get_write_function
    from pysnooper.tracer import Tracer
    from pysnooper.variable import CommonVariable

    output = get_write_function(None, False)
    watch = [CommonVariable('foo')]
    watch_explode = [CommonVariable('self')]
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False

    tracer = Tracer(output, watch, watch_explode, depth, prefix, overwrite,
                    thread_info, custom_repr, max_variable_length, normalize,
                    relative_time)
    tracer.__enter__()

# Generated at 2022-06-16 19:22:01.098771
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import inspect
    import functools
    import threading
    import datetime
    import os
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:22:09.586783
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import sys
    import os
    import datetime
    import threading
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import pycompat
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import DISABLED
    import CommonVariable
    import Exploding
    import BaseVariable
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat


# Generated at 2022-06-16 19:22:21.104342
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import functools
    import inspect
    import threading
    import datetime
    import os
    import pycompat
    import opcode
    import traceback
    import itertools
    import utils
    import thread_global
    import get_path_and_source_from_frame
    import get_write_function
    import CommonVariable
    import Exploding
    import BaseVariable
    import DISABLED
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:22:27.124629
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-16 19:23:33.053099
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import utils
    import pycompat
    import datetime_module
    import os
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:23:45.085105
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import functools
    import threading
    import itertools
    import opcode
    import traceback
    import pycompat
    import utils
    import datetime_module
    import thread_global
    import get_path_and_source_from_frame
    import CommonVariable
    import BaseVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import py

# Generated at 2022-06-16 19:23:53.205308
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    import datetime
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode
    import os
    import pycompat
    import utils
    import thread_global
    import pycompat
    import inspect
    import functools
    import itertools
    import traceback
    import opcode


# Generated at 2022-06-16 19:24:04.405604
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import pytest
    import pysnooper
    import inspect
    import threading
    import functools
    import datetime
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.opcode
    import pysnooper.thread_global
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.pycompat
    import pysnooper.utils

# Generated at 2022-06-16 19:24:10.547560
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import shutil
    import sys
    import pytest
    import os.path
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
    import datetime
    import pycompat
    import time
   

# Generated at 2022-06-16 19:24:21.208537
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    import threading
    import itertools
    import opcode
    import traceback
    import functools
    import datetime
    import pycompat
    import utils
    import os
    import thread_global
    import get_path_and_source_from_frame
    import BaseVariable
    import CommonVariable
    import Exploding
    import DISABLED
    import get_write_function
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat

# Generated at 2022-06-16 19:24:30.073263
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        bar()
    def bar():
        baz()
    def baz():
        pass
    assert get_path_and_source_from_frame(inspect.currentframe()) == \
           (__file__, UnavailableSource())
    assert get_path_and_source_from_frame(inspect.currentframe().f_back) == \
           (__file__, UnavailableSource())
    assert get_path_and_source_from_frame(inspect.currentframe().f_back.f_back) == \
           (__file__, UnavailableSource())
    assert get_path_and_source_from_frame(inspect.currentframe().f_back.f_back.f_back) == \
           (__file__, UnavailableSource())

