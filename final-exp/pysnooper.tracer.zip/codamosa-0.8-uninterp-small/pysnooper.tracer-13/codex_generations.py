

# Generated at 2022-06-24 17:09:13.243025
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-24 17:09:20.615269
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    bytes_0 = b'X'
    bool_0 = False
    file_writer_0 = FileWriter(bytes_0, bool_0)
    tracer_0 = Tracer(file_writer_0)
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:09:27.727100
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys
    def trace(string_io, object_0, str_0, object_1):
        string_io.write(str_0)
        object_1
    @contextmanager
    def context():
        string_io = StringIO()
        object_0 = None
        str_0 = ''
        object_1 = None
        try:
            yield trace(string_io, object_0, str_0, object_1)
        finally:
            sys.stdout = string_io
            print('test')
            with string_io as object_2:
                pass

if __name__ == "__main__":
    pycompat_test.run_tests()

# Generated at 2022-06-24 17:09:38.087552
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import tempfile
    bytes_0 = b''
    bool_0 = False
    file_writer_0 = FileWriter(bytes_0, bool_0)

    class _TS:
        f = None
        o = None
    _ts = _TS()

    _ts.f = tempfile.mktemp(prefix=__name__, suffix='.snoop')
    _ts.o = open(_ts.f, 'w')
    byte_0 = 0
    byte_1 = 1
    byte_2 = 2

    with file_writer_0:
        _ts.o.write(bytes([byte_0]))
    with file_writer_0:
        _ts.o.write(bytes([byte_1]))

# Generated at 2022-06-24 17:09:46.026339
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    bytes_0 = b''
    bool_0 = False
    file_writer_0 = FileWriter(bytes_0, bool_0)
    tracer_0 = Tracer(file_writer_0, bytes_0)
    inspect_0 = Inspect()
    inspect_1 = Inspect()
    inspect_2 = Inspect()
    inspect_3 = Inspect()
    inspect_4 = Inspect()
    inspect_5 = Inspect()
    inspect_6 = Inspect()
    inspect_7 = Inspect()
    inspect_8 = Inspect()
    inspect_9 = Inspect()
    inspect_10 = Inspect()
    inspect_11 = Inspect()
    inspect_12 = Inspect()
    inspect_13 = Inspect()
    inspect_14 = Inspect()
    inspect_15 = Inspect()
    inspect_16 = Inspect()
    inspect_17 = Inspect()
   

# Generated at 2022-06-24 17:09:50.849283
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    output = None
    overwrite = False
    watch = ()
    depth = 1
    prefix = ''
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    sut = Tracer(output, watch, watch_explode=(), depth=depth,
                 prefix=prefix, overwrite=overwrite, thread_info=thread_info,
                 custom_repr=custom_repr,
                 max_variable_length=max_variable_length, normalize=normalize, relative_time=relative_time)
    assert sut


# Generated at 2022-06-24 17:09:54.783523
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    for i in range(5):
        frame_0, filename_0, line_0, arg_0, dict_0 = inspect.stack()[i]
        function_name_0, module_name_0, filename_name_0 = arg_0
        path_0, source_0 = get_path_and_source_from_frame(frame_0)
        assert path_0 == filename_name_0


# Generated at 2022-06-24 17:10:04.204864
# Unit test for function get_write_function
def test_get_write_function():
    str_0 = 'stderr'
    stream_0 = sys.stderr
    path_0 = os.path.expanduser('~')
    list_0 = [str_0, stream_0, path_0]
    bytes_0 = b''
    bool_0 = False
    tuple_0 = (str_0, stream_0, path_0)

# Generated at 2022-06-24 17:10:12.593528
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    _bytes_0 = b''
    _bool_0 = False
    _file_writer_0 = FileWriter(_bytes_0, _bool_0)
    _bytes_1 = b''
    _bool_1 = False
    _file_writer_1 = FileWriter(_bytes_1, _bool_1)
    _frame_0 = sys._getframe()
    _frame_1 = sys._getframe()
    _frame_2 = sys._getframe()
    _frame_3 = sys._getframe()
    _frame_4 = sys._getframe()
    _frame_5 = sys._getframe()
    _frame_6 = sys._getframe()
    _frame_7 = sys._getframe()
    _frame_8 = sys._getframe()
    _frame_9 = sys._getframe()
    _frame

# Generated at 2022-06-24 17:10:19.404934
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # We'll use a function that does nothing to test with:
    def foo():
        pass

    # Test a function in the program we are running:
    path, source = get_path_and_source_from_frame(inspect.currentframe())
    assert path == __file__
    assert inspect.getframeinfo(foo).function in source[0]

    # Test a function in a different module:
    import re
    path, source = get_path_and_source_from_frame(inspect.currentframe(0))
    assert re.match(r'^[^\n]+\bsub\b', source[0])



# Generated at 2022-06-24 17:11:34.531747
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    assert tracer_0.watch == []
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ''
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.custom_repr == ()
    assert tracer_0.last_source_path is None
    assert tracer_0.max_variable_length == 100
    assert tracer_0.normalize == False
    assert tracer_0.relative_time == False


tracer_1 = Tracer(watch=('foo', 'bar'))

# Generated at 2022-06-24 17:11:44.938141
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    assert hasattr(tracer_0, "_write")
    assert hasattr(tracer_0, "watch")
    assert hasattr(tracer_0, "frame_to_local_reprs")
    assert hasattr(tracer_0, "start_times")
    assert hasattr(tracer_0, "depth")
    assert hasattr(tracer_0, "prefix")
    assert hasattr(tracer_0, "thread_info")
    assert hasattr(tracer_0, "target_codes")
    assert hasattr(tracer_0, "target_frames")
    assert hasattr(tracer_0, "thread_local")
    assert hasattr(tracer_0, "custom_repr")

# Generated at 2022-06-24 17:11:47.007352
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = test_case_0()


# Generated at 2022-06-24 17:11:52.578223
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame = None # TODO: replace this line with an actual frame object once we're able to create it
    event = None # TODO: replace this line with an actual event object once we're able to create it
    arg = None # TODO: replace this line with an actual arg object once we're able to create it
    res = tracer_0.trace(frame, event, arg)
    assert res == tracer_0.trace


# Generated at 2022-06-24 17:11:55.535933
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()


# Generated at 2022-06-24 17:11:59.190304
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()

if __name__ == '__main__':
    test_Tracer___call__()

# Generated at 2022-06-24 17:12:04.115060
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Set up mock objects
    frame_0 = mock.Mock()
    frame_0.f_code = mock.Mock()
    frame_0.f_code.co_filename = mock.Mock()
    frame_0.f_back = mock.Mock()
    frame_0.f_lineno = mock.Mock()
    event_0 = mock.Mock()
    arg_0 = mock.Mock()
    # Invoke method
    obj = Tracer()
    result_0 = obj.trace(frame_0, event_0, arg_0)
    assert isinstance(result_0, types.FunctionType)


# Generated at 2022-06-24 17:12:10.943157
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func_0():
        test_case_0()

    test_frame = inspect.currentframe()
    while True:
        if test_frame.f_code.co_name == 'test_case_0':
            break
        test_frame = test_frame.f_back
    test_file_name, test_source = get_path_and_source_from_frame(test_frame)
    assert test_file_name.endswith('tracer.py')
    assert test_source[test_frame.f_lineno-2].find('test_case_0') != -1



# Generated at 2022-06-24 17:12:13.964387
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()

    # You can't compare Traceback objects
    # assert tracer_0.__enter__() == None
    assert True


# Generated at 2022-06-24 17:12:18.443079
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def wrapped_function():
        pass
    tracer = Tracer()
    wrapped_function = tracer.__call__(wrapped_function)
    wrapped_function()
    assert wrapped_function.__name__ == 'wrapped_function'


# Generated at 2022-06-24 17:12:36.583425
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.__exit__(None, None, None)


# Generated at 2022-06-24 17:12:41.155178
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert sys.version_info > (2, 7)
    assert 'test_get_path_and_source_from_frame' in sys._getframe().f_code.co_name
    get_path_and_source_from_frame(sys._getframe())



# Generated at 2022-06-24 17:12:52.607521
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    assert isinstance(tracer_0.trace, types.MethodType), \
        "Failed: tracer_0.trace should be MethodType"
    tracer_0.watch.append('foo')
    tracer_0.watch_explode.append('foo')
    tracer_0._write('bar')
    tracer_0.depth = 1
    tracer_0.prefix = 'foo'
    tracer_0.thread_info = False
    tracer_0.thread_info_padding = 0
    tracer_0.target_codes = set()
    tracer_0.target_frames = set()
    tracer_0.last_source_path = None
    tracer_0.max_variable_length = 100
    tracer_0.normalize = False


# Generated at 2022-06-24 17:13:01.872893
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    assert tracer._write == sys.stderr.write
    assert tracer.watch == ()
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local == threading.local()
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False
    assert tracer.relative_time == False

# Generated at 2022-06-24 17:13:07.581953
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    tracer_0 = Tracer()
    output_0 = pycompat.PathLike('file_name.txt')
    overwrite_0 = True
    write_function_0 = get_write_function(output_0, overwrite_0)
    write_function_0("This is a line.\n")


# Generated at 2022-06-24 17:13:20.053842
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_string = '''
    test_case_0()
    '''

# Generated at 2022-06-24 17:13:26.926574
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    def function_0():
        assert exc_type == ('hi',)
        assert exc_value == 'hi'
        assert exc_traceback == 'hi'
        raise Exception
    with tracer_0, pytest.raises(Exception):
        function_0()


# Generated at 2022-06-24 17:13:28.739540
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    try:
        test_case_0()
    except Exception:
        print(traceback.format_exc())
        assert False


# Generated at 2022-06-24 17:13:40.684884
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    tracer_1 = Tracer()
    tracer_2 = Tracer()
    tracer_3 = Tracer()
    tracer_4 = Tracer()
    tracer_5 = Tracer()
    tracer_6 = Tracer()
    tracer_7 = Tracer()
    tracer_8 = Tracer()
    tracer_9 = Tracer()
    tracer_10 = Tracer()
    tracer_11 = Tracer()
    tracer_12 = Tracer()
    tracer_13 = Tracer()
    tracer_14 = Tracer()
    tracer_15 = Tracer()
    tracer_16 = Tracer()
    tracer_17 = Tracer()
    tracer_18 = Tracer()
    tracer_19 = Tracer()

# Generated at 2022-06-24 17:13:48.188987
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_test_case():
        return test_case_0

    tracer = Tracer()
    get_test_case()

    frame = inspect.stack()[-1][0]
    expected_file_name = __file__
    expected_source = [u'def test_case_0():',
                       u'    tracer_0 = Tracer()',
                       u'',
                       u'',
                       u'# Unit test for function get_path_and_source_from_frame',
                       u'def test_get_path_and_source_from_frame():']
    actual_file_name, actual_source = get_path_and_source_from_frame(frame)

    assert actual_file_name == expected_file_name
    assert actual_source == expected_source


TraceResult = collections.namedt

# Generated at 2022-06-24 17:14:13.814477
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    ###################################################################
    # Test case 1:
    #   test_case_0() is located in line 3 - line 6
    #   tracer_0 is assigned in line 3
    ###################################################################
    __tracebackhide__ = True
    frame = inspect.currentframe()
    while frame:
        if 'test_get_path_and_source_from_frame' in frame.f_code.co_name:
            while frame:
                if frame.f_code.co_name == 'test_case_0':
                    break
                frame = frame.f_back
            break
        frame = frame.f_back
    assert frame is not None

# Generated at 2022-06-24 17:14:23.466357
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test constructor
    tracer_0 = Tracer()
    assert tracer_0._write == sys.stdout.write
    assert tracer_0.watch == []
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ''
    assert tracer_0.overwrite == False
    assert tracer_0.thread_info == False
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.custom_repr == ()
    assert tracer_0.last_source_path == None
    assert tracer_0.max_variable_length == 100
    assert tracer_0

# Generated at 2022-06-24 17:14:34.370320
# Unit test for constructor of class Tracer
def test_Tracer():
    outfile = open(os.path.join(os.path.expanduser('~'), "out_test.log"), "w")
    tracer_1 = Tracer(output=outfile)
    tracer_2 = Tracer(output=outfile, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    tracer_3 = Tracer(output=outfile, watch=('name',), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=True, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    tracer_4 = Tracer

# Generated at 2022-06-24 17:14:38.169395
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    global filename
    global source
    filename, source = get_path_and_source_from_frame(sys._getframe())
    assert filename.endswith('tracer.py')



# Generated at 2022-06-24 17:14:43.420545
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with pytest.raises(NameError):
        tracer_0 = Tracer()
        frame_0 = inspect.currentframe()
        event_0 = 'call'
        arg_0 = None
        output_0 = tracer_0.trace(frame_0, event_0, arg_0)



# Generated at 2022-06-24 17:14:47.119453
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Initialize tracer_0, an instance of Tracer
    tracer_0 = Tracer()

    # Initialize frame, event and arg
    frame = inspect.currentframe()
    event = 'call'
    arg = None

    # Call method trace of tracer_0
    tracer_0.trace(frame, event, arg)


# Generated at 2022-06-24 17:14:58.761695
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()

    tracer_0.__enter__()
    tracer_0.__exit__(None, None, None)

    assert tracer_0._write.__name__ in ('open', 'write_file')
    assert pycompat.isstring(tracer_0.prefix)
    assert pycompat.isiterable(tracer_0.watch)
    assert pycompat.isiterable(tracer_0.watch_explode)
    assert isinstance(tracer_0.depth, int)
    assert isinstance(tracer_0.prefix, str)
    assert isinstance(tracer_0.overwrite, bool)
    assert isinstance(tracer_0.thread_info, bool)
    assert pycompat.isiterable(tracer_0.custom_repr)

# Generated at 2022-06-24 17:15:02.238682
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    file_name, source = get_path_and_source_from_frame(f.__code__.co_filename)
    assert file_name != f.__code__.co_filename



# Generated at 2022-06-24 17:15:06.424937
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    exception_0 = None
    try:
        tracer_0.__exit__(exception_0, exception_0, exception_0)
    except Exception as caught_exception_0:
        exception_0 = caught_exception_0
    if (exception_0):
        raise exception_0


# Generated at 2022-06-24 17:15:20.038018
# Unit test for function get_write_function
def test_get_write_function():
    assert(get_write_function(output=None, overwrite=False) ==
           test_case_0.__globals__['write'])
    assert(get_write_function(output=sys.stdout, overwrite=False) ==
           test_case_0.__globals__['write'])
    output = open('tracer_test_get_write_function_0.txt', 'w')
    assert(get_write_function(output=output, overwrite=False) ==
           test_case_0.__globals__['write'])
    output.close()
    output = open('tracer_test_get_write_function_1.txt', 'w')

# Generated at 2022-06-24 17:15:54.943357
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__(
        None,
        None,
        None
    )


# Generated at 2022-06-24 17:15:55.864710
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()


# Generated at 2022-06-24 17:16:07.404789
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import pysnooper
    import time
    import os
    import logging
    import threading
    import inspect
    import base64
    import functools
    import os
    import sys
    import itertools
    import json
    import pycompat
    import datetime
    import itertools
    import threading
    import traceback
    import json
    import base64
    import inspect
    import logging
    import functools
    import threading
    import datetime
    import traceback
    import json
    import sys
    import os
    import inspect
    import functools
    import logging
    import traceback
    import json
    import base64
    import inspect
    import functools
    import logging
    import threading
    import os
    import json
    import sys

# Generated at 2022-06-24 17:16:13.479862
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    print('\nRunning unit test for __exit__ of class Tracer ...')
    tracer_0 = Tracer()
    exc_type_0 = None
    exc_value_0 = None
    exc_traceback_0 = None
    tracer_0.__exit__(exc_type_0, exc_value_0, exc_traceback_0)
    assert True, 'unit test succeeded'


# Generated at 2022-06-24 17:16:14.351017
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()

# Generated at 2022-06-24 17:16:17.437075
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back
    event_0 = 'call'
    arg_0 = None
    tracer_0.trace(frame_0=frame_0, event=event_0, arg=arg_0)


# Generated at 2022-06-24 17:16:26.005075
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    (f_name, f_source) = get_path_and_source_from_frame(inspect.currentframe())
    print('f_name = ', f_name)
    print('f_source = ', f_source)
    assert f_name == os.path.abspath(__file__)
    assert f_source[0] == 'def test_case_0():'
    assert f_source[2] == 'f_source = ' + repr(f_source)
    assert f_source[3][0:8] == 'f_name = '


# Generated at 2022-06-24 17:16:36.244186
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    t = Tracer()
    t.__exit__("exc_type", "exc_value", "exc_tb")
    t.__exit__("exc_type", "exc_value", "exc_tb")
    t.__exit__("exc_type", "exc_value", "exc_tb")
    t.__exit__("exc_type", "exc_value", "exc_tb")
    assert t.target_codes == set()
    assert t.target_frames == set()
    assert t.thread_local.__dict__['original_trace_functions'] == []


# Generated at 2022-06-24 17:16:47.959706
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()

    # test default parameters
    assert tracer._write is None
    assert tracer.watch == []
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.overwrite is False
    assert tracer.thread_info is False
    assert tracer.custom_repr == ()
    assert tracer.max_variable_length == 100
    assert tracer.normalize is False
    assert tracer.relative_time is False

    # test overwrite parameter
    try:
        tracer = Tracer(output='/dev/null', overwrite=True)
    except OSError:
        tracer = Tracer(output=None, overwrite=True)
    assert tracer.output == '/dev/null'
    assert tracer.overwrite is True



# Generated at 2022-06-24 17:16:49.097414
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    test_case_0()

# Generated at 2022-06-24 17:18:08.403280
# Unit test for method trace of class Tracer
def test_Tracer_trace():

    tracer_1 = Tracer()
    def foo(): pass
    def bar(): foo()
    def baz(): bar()

    baz()
    assert tracer_1.target_codes == {foo.__code__, bar.__code__, baz.__code__}


# Generated at 2022-06-24 17:18:12.537918
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    class Test:
        def test_method(self):
            return 'foobar'

    t = Test()
    f = t.test_method
    f()
    frame = sys._getframe()
    test_path, test_source = get_path_and_source_from_frame(frame)
    assert test_path == __file__, (test_path, __file__)
    assert test_source == source, (test_source, get_source())


source_cache = {}



# Generated at 2022-06-24 17:18:15.607332
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    assert tracer_0.trace() is None


# Generated at 2022-06-24 17:18:25.789237
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import inspect
    import re
    assertTrue = True
    assertFalse = False
    assertException = False
    # Constructor test
    obj = Tracer()
    # State test
    assert obj._write == sys.stdout.write
    assert obj.watch == []
    assert obj.frame_to_local_reprs == {}
    assert obj.start_times == {}
    assert obj.depth == 1
    assert obj.prefix == ''
    assert obj.overwrite == False
    assert obj.thread_info == False
    assert obj.custom_repr == ()
    assert obj.max_variable_length == 100
    assert obj.normalize == False
    assert obj.relative_time == False
    # State test
    assert obj._write == sys.stdout.write
    assert obj.watch == []
    assert obj.frame

# Generated at 2022-06-24 17:18:28.713454
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    assert tracer_0.__enter__() == None


# Generated at 2022-06-24 17:18:36.566032
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # pylint: disable=undefined-variable
    tracer_0 = Tracer()

    # Call method trace
    tracer_0.trace(frame=frame_0_0,
                   event='call',
                   arg=arg_0_0)

    # Call method trace
    tracer_0.trace(frame=frame_0_1,
                   event=event_0_1,
                   arg=arg_0_1)

    # Call method trace
    tracer_0.trace(frame=frame_0_2,
                   event='return',
                   arg=arg_0_2)
    # pylint: enable=undefined-variable


# Generated at 2022-06-24 17:18:39.560977
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from pysnooper.snoop_common import snoop_common
    test_case_0()
    print(snoop_common.DISABLED)
