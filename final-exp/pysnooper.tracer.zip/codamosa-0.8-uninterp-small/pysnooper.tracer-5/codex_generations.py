

# Generated at 2022-06-24 17:09:42.960638
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types, sys

    def function_0():
        source = None
        if source is None:
            # We used to check `if source is None` but I found a rare bug where
            # it was empty, but not `None`, so now we check `if not source`.
            source = ['SOURCE IS UNAVAILABLE']


# Generated at 2022-06-24 17:09:44.864801
# Unit test for constructor of class Tracer
def test_Tracer():
    # Constructor of class Tracer
    tracer = Tracer()


# Generated at 2022-06-24 17:09:52.172577
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    case_0 = {'watch': 'watch', 'output': None, 'duration': 4.40739,
              'overwrite': False, 'relative_time': False, 'watch_explode':
              'watch_explode', 'custom_repr': (), 'normalize': False,
              'max_variable_length': 100, 'thread_info': False, 'depth': 1,
              'prefix': ''}
    s_0 = Tracer(**case_0)
    try:
        s_0(test_case_0())
    except NotImplementedError:
        pass


# Generated at 2022-06-24 17:10:02.719724
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame_0 = {'__name__': '__name__', '__loader__': '__loader__', 'f_code': 'f_code', 'f_globals': 'f_globals'}
    match_0 = None
    match_1 = None
    match_2 = None
    match_3 = None
    match_4 = None
    ipython_shell_0 = None
    match_5 = None
    match_6 = None
    match_7 = None
    match_8 = None
    match_9 = None
    match_10 = None
    match_11 = None
    match_12 = None
    match_13 = None
    fp_0 = None
    match_14 = None
    match_15 = None
    match_16 = None
    match_17 = None
    match_

# Generated at 2022-06-24 17:10:05.777097
# Unit test for function get_local_reprs
def test_get_local_reprs():
    None


# Generated at 2022-06-24 17:10:07.346609
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer():
        test_case_0()


# Generated at 2022-06-24 17:10:17.734737
# Unit test for constructor of class Tracer
def test_Tracer():
    dict_0 = None
    dict_1 = None
    dict_2 = None
    dict_3 = None
    dict_4 = None
    dict_5 = None
    dict_6 = None
    dict_7 = None
    dict_8 = None
    dict_9 = None
    dict_10 = None
    dict_11 = None
    dict_12 = None
    dict_13 = None
    dict_14 = None
    dict_15 = None
    dict_16 = None

    return Tracer(**dict_0)


# Generated at 2022-06-24 17:10:32.184292
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    function_or_class_0 = test_Tracer___call__.__code__
    output_1, watch_2, watch_explode_3, depth_4, prefix_5, overwrite_6, thread_info_7, custom_repr_8, max_variable_length_9, normalize_10, relative_time_11 = None, None, None, None, None, None, None, None, None, None, None
    tracer_0 = Tracer(output_1, watch_2, watch_explode_3, depth_4, prefix_5, overwrite_6, thread_info_7, custom_repr_8, max_variable_length_9, normalize_10, relative_time_11)
    if (function_or_class_0 == test_Tracer___call__.__code__):
        assert True

# Generated at 2022-06-24 17:10:43.449099
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    dict_0 = None
    unavailable_source_0 = UnavailableSource(**dict_0)

    dict_1 = dict()
    dict_1['depth'] = unavailable_source_0
    dict_1['prefix'] = unavailable_source_0
    dict_1['overwrite'] = unavailable_source_0
    dict_1['thread_info'] = True
    dict_1['custom_repr'] = unavailable_source_0
    dict_1['max_variable_length'] = unavailable_source_0
    dict_1['normalize'] = True
    dict_1['relative_time'] = True
    tracer_0 = Tracer(**dict_1)
    # Test exception handling
    with pytest.raises(Exception):
        tracer_0.trace(None, None, None)



# Generated at 2022-06-24 17:10:53.366660
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    dict_0 = None
    frame_0 = utils.Frame(**dict_0)
    result = get_path_and_source_from_frame(frame_0)
    assert isinstance(result, tuple)
    assert len(result) == 2
    file_name_0, source_0 = result
    assert isinstance(file_name_0, str)
    assert isinstance(source_0, UnavailableSource)


# Generated at 2022-06-24 17:11:23.221486
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global tracer_0

    # Test whether the instance attribute is created when __exit__ is called.
    assert hasattr(tracer_0, '_Tracer__original_trace_functions')
    # Test whether the instance attribute's value is correct when
    # __exit__ is called.
    assert tracer_0._Tracer__original_trace_functions == [None]


# Generated at 2022-06-24 17:11:25.381427
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    tracer_0.__enter__()


# Generated at 2022-06-24 17:11:29.217934
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    exc_type = Exception('')
    exc_value = Exception('')
    exc_traceback = Exception('')
    tracer_0.__exit__(exc_type, exc_value, exc_traceback, )


# Generated at 2022-06-24 17:11:30.583388
# Unit test for constructor of class Tracer
def test_Tracer():
    test_case_0()
    

DISABLED = False


# Generated at 2022-06-24 17:11:32.273002
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with tracer0:
        a = 1


# Generated at 2022-06-24 17:11:43.547431
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    this_file_path = os.path.dirname(__file__)
    path, source = get_path_and_source_from_frame(inspect.currentframe())
    assert path.endswith('tracer.py')
    assert source[0] == '# Copyright 2018 Ram Rachum and collaborators.'
    release_this_script_file_path = (
        this_file_path + '/testing/release/test_get_path_and_source_from_frame.py'
    )

# Generated at 2022-06-24 17:11:50.247258
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    test_frame_0 = inspect.currentframe()
    test_event_0 = 'call'
    test_arg_0 = ''
    assert callable(tracer_0.trace)
    try:
        tracer_0.trace(test_frame_0, test_event_0, test_arg_0)
    except:
        assert False


# Generated at 2022-06-24 17:11:51.676585
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    assert True


# Generated at 2022-06-24 17:11:59.858165
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    def function_or_class_0():
        pass
    tracer_0(function_or_class_0)
    tracer_0._wrap_class(None)
    tracer_0._wrap_function(None)
    tracer_0(None)


# Generated at 2022-06-24 17:12:06.628304
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back.f_back
    frame_1 = frame_0.f_back
    frame_0.f_locals = {}
    frame_1.f_locals = {}
    event_0 = 'call'
    arg_0 = None
    output_0 = tracer_0.trace(frame_0, event_0, arg_0)
    return output_0


# Generated at 2022-06-24 17:12:37.504670
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = Frame(MagicMock(), 'test_Tracer_trace$fun_0') # Mock
    frame_0.f_code = Code('test_Tracer_trace', 1, 5, [], [], [], [], '', '', 0, b'')
    frame_0.f_lineno = 1
    frame_0.f_lasti = 0
    tracer_0.thread_local.original_trace_functions.append(None)
    tracer_0.start_times = {frame_0:datetime_module.datetime.now()}
    tracer_0.frame_to_local_reprs = {frame_0:{'a': '123'}}
    tracer_0.target_codes = {frame_0.f_code}
   

# Generated at 2022-06-24 17:12:48.824205
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    print("\nTesting get_path_and_source_from_frame")
    tracer_0 = Tracer()
    tracer_0.start()
    tracer_0.stop()
    result = 'test_case_0 ()'
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    stack_1 = tracer_0.trace.stack
    print("The stack of the Tracer is: " + str(stack_1))
    stack_case_0 = stack_1[0]
    file_name_0 = stack_case_0.frame.f_code.co_filename
    source_name_0 = stack_case_0.source
    index_start_function_0 = file_name_0.find("(");
    function

# Generated at 2022-06-24 17:12:59.200983
# Unit test for function get_write_function
def test_get_write_function():
    output_1 = None
    output_2 = 'test_file'
    output_3 = open('test_file_2', 'w')
    tracer_1 = Tracer()
    tracer_2 = Tracer(output = output_1)
    tracer_3 = Tracer(output = output_2)
    tracer_4 = Tracer(output = output_3)
    tracer_5 = Tracer(output = output_2, overwrite = True)

    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 17:13:09.974179
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import test
    from .test import test_case_0
    from .test import test_get_path_and_source_from_frame
    import inspect
    import os
    import pycompat
    import sys

    def get_file_name(frame):
        file_name = frame.f_code.co_filename
        # While inspecting imported modules, this function may be run
        # with a non-existent filename ('<string>' on Python 2,
        # '<ipython-input-1-...>' on Python 3). If so, there is no
        # point in trying to get the source of the file through this
        # function.

# Generated at 2022-06-24 17:13:14.955723
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # tracer_0 is of type Tracer.
    tracer_0 = Tracer()
    # test_function_1 is of type function.
    def test_function_1():
        pass

    # test_function_1 is of type function.
    # test_function_1 = tracer_0.trace(test_function_1)


# Generated at 2022-06-24 17:13:20.865845
# Unit test for constructor of class Tracer
def test_Tracer():
    """Test the constructor of class Tracer."""
    # Fixture set-up
    with pytest.raises(ValueError, match='"depth" should be a positive integer'):
        tracer_2 = Tracer(depth=0)
    with pytest.raises(ValueError, match='"depth" should be a positive integer'):
        tracer_3 = Tracer(depth=-1)
    with pytest.raises(ValueError, match='"relative_time" and "normalize" '
                                         'cannot both be True'):
        tracer_4 = Tracer(relative_time=True, normalize=True)
    # Test case
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
   

# Generated at 2022-06-24 17:13:29.915005
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    file_name = 'test'
    locals_ = {'test': True}
    frame = get_frame(test_case_0, locals_)
    result_file_name, result_source = get_path_and_source_from_frame(frame)
    assert result_file_name == file_name
    assert result_source[0] == 'def test_case_0():'
    assert result_source[-1] == 'tracer_0 = Tracer()'
    assert result_source[1] == '    tracer_0 = Tracer()'



# Generated at 2022-06-24 17:13:32.418752
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    print('____________________________________________________')
    print(get_path_and_source_from_frame(inspect.currentframe()))
    print('____________________________________________________')



# Generated at 2022-06-24 17:13:34.778710
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with snoop(prefix='', depth=1, max_variable_length=100):
        def test_case_0():
            tracer_0 = Tracer()


# Generated at 2022-06-24 17:13:45.645141
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    calling_frame = inspect.currentframe().f_back
    if not tracer_0._is_internal_frame(calling_frame):
        calling_frame.f_trace = tracer_0.trace
        tracer_0.target_frames.add(calling_frame)
    assert isinstance(tracer_0.frame_to_local_reprs, dict)
    assert len(tracer_0.frame_to_local_reprs) == 0
    assert isinstance(tracer_0.start_times, dict)
    assert len(tracer_0.start_times) == 0
    assert isinstance(tracer_0.watch, list)
    assert len(tracer_0.watch) == 0

# Generated at 2022-06-24 17:14:15.135456
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back
    frame_1 = inspect.currentframe().f_back
    frame_2 = inspect.currentframe().f_back
    frame_3 = inspect.currentframe().f_back
    frame_4 = inspect.currentframe().f_back
    frame_5 = inspect.currentframe().f_back
    frame_6 = inspect.currentframe().f_back
    frame_7 = inspect.currentframe().f_back
    frame_8 = inspect.currentframe().f_back
    frame_9 = inspect.currentframe().f_back
    event_0 = 'call'
    event_1 = 'call'
    event_2 = 'call'
    event_3 = 'call'
    event_4 = 'call'
    event_5

# Generated at 2022-06-24 17:14:18.562155
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """Test case for method __exit__ of class Tracer."""
    tracer_0 = Tracer()
    tracer_0.__exit__(arg_0, arg_1, arg_2)


# Generated at 2022-06-24 17:14:20.829134
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    tracer_0 = Tracer()
    assert tracer_0 is not None



# Generated at 2022-06-24 17:14:24.083440
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__enter__()
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:14:33.590967
# Unit test for function get_write_function
def test_get_write_function():
    # test all possible state of output
    assert get_write_function(sys.stdout, False) is sys.stdout.write
    # test that write function is returned when overwrite=True
    assert callable(get_write_function('stdout.txt', True))
    # test that callable object is returned if true
    assert callable(get_write_function(print, True))
    tracer = Tracer()
    assert tracer.write_function(sys.stdout, False) == sys.stdout.write
    assert tracer.write_function(None, False) is None
    # test that callable object is returned if true
    assert callable(tracer.write_function(print, True))


# Generated at 2022-06-24 17:14:37.855781
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe(0)
    file_path, source = get_path_and_source_from_frame(frame)
    assert os.path.basename(file_path) == 'tracer.py'



# Generated at 2022-06-24 17:14:45.058818
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import StringIO as StringIO_module
    import os

    function_returning_frame = lambda: inspect.currentframe()
    frame_0 = function_returning_frame()
    file_on_disk, source = get_path_and_source_from_frame(frame_0)
    assert file_on_disk.endswith('tracer.py')
    assert source == []
    assert os.path.isfile(file_on_disk)

    def function_0():
        # This should be the line of the `function_0` definition
        pass

    frame_0 = function_returning_frame()
    file_on_disk, source = get_path_and_source_from_frame(frame_0)
    assert file_on_disk.endswith('tracer.py')
    assert source

# Generated at 2022-06-24 17:14:50.068141
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def assert_path_and_source(expected_path, expected_source):
        result_path, result_source = \
            get_path_and_source_from_frame(inspect.currentframe())
        assert result_path == expected_path
        assert list(result_source) == expected_source

    assert_path_and_source(
        os.path.join(os.path.dirname(__file__), 'test_traceback.py'),
        [
            'def test_case_0():',
            '    tracer_0 = Tracer()'
        ]
    )



# Generated at 2022-06-24 17:14:53.618087
# Unit test for function get_write_function
def test_get_write_function():

    assert test_case_0() == "None"
    assert test_case_1() == "None"
    assert test_case_2() == "None"
    assert test_case_3() == "None"


# Generated at 2022-06-24 17:14:59.186836
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_func(a, b):
        a = a.format(b)
        return a
    test_frame = inspect.currentframe().f_back
    file_name, source = get_path_and_source_from_frame(test_frame)
    expected_source = [
        'def test_func(a, b):',
        '    a = a.format(b)',
        '    return a',
    ]
    assert source == expected_source
    assert file_name == __file__



# Generated at 2022-06-24 17:16:05.319297
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    def function_or_class_0():
        pass
    test_Tracer___call___var_0 = tracer_0(function_or_class_0)
    assert callable(test_Tracer___call___var_0)
    test_Tracer___call___var_1 = tracer_0(Tracer)


# Generated at 2022-06-24 17:16:12.896393
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()

    assert tracer_0._write == sys.stdout.write
    assert tracer_0.watch == ()
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ''
    assert tracer_0.overwrite == False
    assert tracer_0.thread_info == False
    assert tracer_0.custom_repr == ()
    assert tracer_0.max_variable_length == 100
    assert tracer_0.normalize == False
    assert tracer_0.relative_time == False

# Generated at 2022-06-24 17:16:20.033549
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    s_0 = '<lambda>'
    # s_0 -> '<lambda>'
    b_0 = True
    # b_0 -> True
    test_case_0()
    # test_case_0() -> None
    l_0 = [0, 1, 2]
    # l_0 -> [0, 1, 2]
    def function_0():
        try:
            None
            # None -> None
        finally:
            None

    @tracer_0
    def function_1():
        try:
            None
            # None -> None
        finally:
            None
    # function_1() -> None
    i_0 = None
    # i_0 -> None
    tracer_0.write(s_0)
    # s_0 -> '

# Generated at 2022-06-24 17:16:25.598033
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    assert hasattr(Tracer, "__exit__")
    tracer_0 = Tracer()
    assert callable(getattr(tracer_0, "__exit__"))
    assert isinstance(Tracer.__exit__, abc.abstractmethod)
    assert not hasattr(tracer_0, "__exit__")


# Generated at 2022-06-24 17:16:28.708186
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pytest.raises(NotImplementedError, message="Coroutine snooping is not yet supported"):
        test_case_0()


# Generated at 2022-06-24 17:16:39.363553
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    a = 1
    b = 2
    c = 3
    f = [1, 2, 3, 4, 5]
    e = sum(f)
    a = 2
    def ss(s):
        c = 1
        d = 2
        s = c + d
        return s + c

# Generated at 2022-06-24 17:16:49.404177
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.thread_local = threading.local()
    tracer_0.frame_to_local_reprs = {}
    tracer_0.start_times = {}
    tracer_0.target_codes = set()
    tracer_0.target_frames = set()
    tracer_0.depth = 2
    tracer_0.thread_info = False
    tracer_0.thread_info_padding = 0
    tracer_0.last_source_path = None
    tracer_0.max_variable_length = 100
    tracer_0.normalize = False
    tracer_0.relative_time = False

# Generated at 2022-06-24 17:16:54.016715
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    tracer_0.__enter__()


# Generated at 2022-06-24 17:16:56.492526
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(sys._getframe())[0] == __file__


# Generated at 2022-06-24 17:16:57.425986
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    return


# Generated at 2022-06-24 17:18:27.980392
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    '''
    Test that the `get_path_and_source_from_frame` function returns the correct result.
    '''
    import inspect
    import os
    import traceback
    import unittest

    # Create a local function
    def function():
        pass

    # Retrieve the function frame
    function_frame = inspect.currentframe().f_back
    while function_frame.f_code.co_name != 'function':
        function_frame = function_frame.f_back

    # Retrieve the filename and source from the local function frame
    file_name, source = get_path_and_source_from_frame(function_frame)

    # Check for correct result

# Generated at 2022-06-24 17:18:33.566651
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def _test_case_func():
        test_case_0()
    with tracer.TraceContext(_test_case_func, watch=()):
        for frame in _test_case_func.frames:
            print(get_path_and_source_from_frame(frame))


# Generated at 2022-06-24 17:18:43.687204
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer(custom_repr=((int, lambda x: x+1),))
    def f_0():
        a_0 = 5
        b_0 = 7
        c_0 = 9
        d_0 = 11
        return (a_0, b_0, c_0, d_0)
    tracer_0.trace(f_0.__code__, 'call', 1) == None
    tracer_0.frame_to_local_reprs == {f_0.__code__: {'a_0': '5', 'b_0': '7', 'c_0': '9', 'd_0': '11'}}