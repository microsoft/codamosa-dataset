

# Generated at 2022-06-24 17:09:26.709679
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from io import StringIO
    from contextlib import contextmanager
    from time import time
    from time import sleep
    from time import strftime
    from time import strptime
    from concurrent.futures import ThreadPoolExecutor
    from concurrent.futures import ProcessPoolExecutor
    from pysnooper import snoop
    from datetime import datetime

    # Test case 0
    write_function = StringIO()
    bool_0 = False
    var_1 = Tracer(write_function, watch=(), watch_explode=(), depth=1, prefix='', overwrite=bool_0, thread_info=bool_0, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)

# Generated at 2022-06-24 17:09:32.316521
# Unit test for function get_write_function
def test_get_write_function():
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    values_copy = dict((i, values[i]) for i in args)
    try:
        test_case_0()
        passed = True
    except Exception:
        passed = False
    return passed, values_copy



# Generated at 2022-06-24 17:09:45.512355
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    if sys.version_info >= (3, 2) and sys.implementation.name == 'cpython':
        assert get_path_and_source_from_frame(
            test_get_path_and_source_from_frame.__code__.co_consts[0])[1][0].strip() == "def test_get_path_and_source_from_frame():"
        assert get_path_and_source_from_frame(
            test_case_0.__code__.co_consts[1])[1][0].strip() == "var_0 = get_write_function(bool_0, bool_0)"
    else:
        assert get_path_and_source_from_frame(
            test_get_path_and_source_from_frame.__code__.co_consts[0])

# Generated at 2022-06-24 17:09:49.870656
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Testing for watch
    with pysnooper.snoop(watch=('var_0', ), overwrite=bool_0, relative_time=bool_0,
                         normalize=bool_0, thread_info=bool_0):
        test_case_0()
    # Testing for watch_explode
    with pysnooper.snoop(watch_explode=('var_0', ), overwrite=bool_0, relative_time=bool_0,
                         normalize=bool_0, thread_info=bool_0):
        test_case_0()


# Generated at 2022-06-24 17:10:01.745443
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer0 = Tracer()
    sys0 = sys
    tracer0.thread_local.original_trace_functions = (sys0.gettrace())
    try:
        # Throwing IOError here
        with tracer0:
            __class__.file0 = open('/tmp/snippets/file0')
    except IOError:
        # Catching the exception when thrown in the decorated function
        traceback.print_exc()


# Generated at 2022-06-24 17:10:08.171816
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Unit test for method trace of class Tracer
    # input
    frame = None
    event = None
    arg = None
    # End test
    # End test
    # End test
    # End test
    # End test


# Generated at 2022-06-24 17:10:20.477976
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    filename_0 = test_get_path_and_source_from_frame.__code__.co_filename
    co_names_0 = test_get_path_and_source_from_frame.__code__.co_names
    assert filename_0 == "test_get_path_and_source_from_frame.py"
    assert len(co_names_0) == 0
    test_bool_0 = True
    assert test_bool_0
    assert callable(test_case_0)
    path_0, source_0 = get_path_and_source_from_frame(test_case_0.__code__.co_filename)
    assert path_0 == "test_get_path_and_source_from_frame.py"


# Generated at 2022-06-24 17:10:33.099837
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Output for a function decorated with @var_1:
    with utils.captured_output() as (out, err):
        def test_1():
            var_0 = 2
            var_1 = pysnooper.snoop()(var_0)
            print('var_0 =', var_0)

        test_1()

    result_out = out.getvalue().strip()

# Generated at 2022-06-24 17:10:44.011928
# Unit test for constructor of class Tracer
def test_Tracer():
    bool_0 = False
    to_check = Tracer()
    bool_0 = bool_0
    assert to_check._write is not None
    bool_0 = bool_0
    assert to_check.watch is not None
    bool_0 = bool_0
    assert to_check.frame_to_local_reprs is not None
    bool_0 = bool_0
    assert to_check.start_times is not None
    bool_0 = bool_0
    bool_0 = bool_0
    assert to_check.depth == 1
    bool_0 = bool_0
    bool_0 = bool_0
    assert to_check.prefix == ''
    bool_0 = bool_0
    bool_0 = bool_0
    assert not to_check.thread_info
    bool_0 = bool_0

# Generated at 2022-06-24 17:10:54.415330
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    bool_0 = False
    Tracer_0 = Tracer(bool_0)
    int_0 = 0
    bool_1 = False
    str_0 = 'str_0'
    str_1 = 'str_1'
    Tracer_0.trace(int_0, bool_1, str_0, str_1)

if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__.replace('.pyc', '.py')])

# Generated at 2022-06-24 17:11:17.868078
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global DISABLED
    DISABLED = False
    global thread_global
    thread_global = threading.local()

    @pysnooper.snoop()
    def test_case_0():
        bool_0 = True

    # Test default values
    return True


# Generated at 2022-06-24 17:11:26.285024
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    line_no = 0
    func_name = ''
    for t in inspect.getouterframes(frame):
        if (t[3] == 'test_case_0'):
            frame = t[0]
            line_no = t[2]
            func_name = t[3]
            break

    file_name, source = get_path_and_source_from_frame(frame)

    assert line_no == source.index(utils.TRACER_START_MARKER) + 1
    assert func_name == 'test_case_0'
    assert os.path.isfile(file_name)
    assert os.path.abspath(file_name) == os.path.abspath(__file__)



# Generated at 2022-06-24 17:11:29.346720
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe(0)
    source = get_path_and_source_from_frame(frame)
    assert (source == (__file__, UnavailableSource()))


# Generated at 2022-06-24 17:11:32.741979
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    trace_0 = Tracer()
    var_0 = trace_0.trace()
    if not (var_0 == None):
        print ('Test failed')
        return
    else:
        print ('Test passed')


# Generated at 2022-06-24 17:11:35.413545
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()
    return

if __name__ == '__main__':
    test_Tracer___call__()
    sys.exit(0)

# Generated at 2022-06-24 17:11:38.114501
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    test_case_0()
if __name__ == "__main__":
    test_Tracer___call__()

# Generated at 2022-06-24 17:11:41.485066
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer(None, None, None, None, None, None, None, None, None, None)
    tracer.__call__(test_case_0())


# Generated at 2022-06-24 17:11:51.436526
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # Context manager used here to clean up the file system
    with FileWriter(utils.get_temp_path(), overwrite=True) as file_writer:
        file_writer.write('Test')
        assert os.path.exists(file_writer.path)
        assert os.path.isfile(file_writer.path)
        with open(file_writer.path, 'r') as file:
            assert file.read() == 'Test'
        file_writer.write('More text')
        with open(file_writer.path, 'r') as file:
            assert file.read() == 'More text'
    assert not os.path.exists(file_writer.path)


# Generated at 2022-06-24 17:11:59.696981
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print()
    print("Testing Tracer.trace(...) ...")

    @pysnooper.snoop()
    def test_case_0():
        bool_0 = True
    test_case_0()

    print("Done testing Tracer.trace(...)!")
    print()

# Generated at 2022-06-24 17:12:03.463747
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global bool_0
    bool_1 = bool_0
    bool_0 = False
    bool_1 = bool_0
    bool_0 = True


# Generated at 2022-06-24 17:12:24.086486
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pysnooper.snoop(
        prefix='',
        output=None,
        overwrite=None,
        write_function=None,
        custom_repr=(),
        thread_info=False,
        max_variable_length=100,
        relative_time=False,
        depth=1,
        normalize=False,
        watch=(),
        ):
        bool_0 = True


# Generated at 2022-06-24 17:12:31.360464
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (__file__, [])
    assert get_path_and_source_from_frame(test_case_0.__code__.co_firstlineno - 1) == (__file__, [
        ' ',
        'def test_case_0():',
        '    bool_0 = True',
        '',
        '# Unit test for function get_path_and_source_from_frame',
        'def test_get_path_and_source_from_frame():',
        '    frame = inspect.currentframe()',
        '    assert get_path_and_source_from_frame(frame) == (__file__, [])',
        ])

# Generated at 2022-06-24 17:12:40.957448
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import pycompat
    import sys
    import builtins
    import collections
    import functools
    import inspect
    import opcode
    import os
    import re
    import traceback
    import datetime as datetime_module
    import itertools
    import threading
    if pycompat.PY2:
        import __future__
    import _ast
    import ast
    import types
    import typing
    import typing_extensions
    from . import pycompat
    from .variables import CommonVariable, Exploding, BaseVariable
    from . import utils
    bool_0 = True
    output_0 = None
    overwrite_0 = True

# Generated at 2022-06-24 17:12:52.496427
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    thread_global_0 = thread_global.__dict__
    tracer_0.thread_local.__dict__
    calling_frame_0 = inspect.currentframe().f_back
    tracer_0.start_times
    tracer_0.frame_to_local_reprs
    tracer_0.target_frames
    thread_local.__dict__
    tracer_0.target_codes
    tracer_0.start_times
    tracer_0._write
    tracer_0.custom_repr
    tracer_0.last_source_path
    tracer_0.watch
    tracer_0.frame_to_local_reprs
    tracer_0.prefix
    tracer_0.thread_info_padding
    tracer_

# Generated at 2022-06-24 17:13:04.419911
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    from unittest.mock import MagicMock, patch
    arg_0 = MagicMock()
    arg_1 = MagicMock()
    arg_2 = MagicMock()

# Generated at 2022-06-24 17:13:09.700278
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  # Setup
  bool_0 = True

  # Print out values
  # print("bool_0 is {bool_0}".format(**locals()))

  # Perform unit test
  assert True == bool_0


# Generated at 2022-06-24 17:13:12.499399
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    obj = Tracer()
    state_0 = obj.__exit__(None, None, None)
    assert state_0 == None


# Generated at 2022-06-24 17:13:13.751907
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()

# Generated at 2022-06-24 17:13:23.695729
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    snooper_obj = pysnooper.Snooper(watch=[], watch_explode=[], depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=[], max_variable_length=100, normalize=False, relative_time=False)
    frame_obj = inspect.currentframe().f_back
    snooper_obj.exit(None, None, None)
    snooper_obj.exit(None, None, None)
    snooper_obj.exit(None, None, None)
    snooper_obj.exit(None, None, None)
    snooper_obj.exit(None, None, None)
    snooper_obj.exit(None, None, None)
    snooper_obj.exit(None, None, None)
    snooper_

# Generated at 2022-06-24 17:13:28.780848
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    snooper = pysnooper.snoop(max_variable_length=20)
    snooper(test_case_0)
    snooper = pysnooper.Snooper(max_variable_length=20)
    snooper(test_case_0)


# Generated at 2022-06-24 17:13:52.630080
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global bool_0
    int_0 = 0
    print('Snooping at the following lines:')
    print('> 5: int_0 = 0')
    print('> 6: print(\'Snooping at the following lines:\')')
    print('> 7: print(\'> 5: int_0 = 0\')')
    print('> 8: print(\'> 6: print(\\\'Snooping at the following lines:\\\')\')')
    print('> 9: print(\'> 7: print(\\\'> 5: int_0 = 0\\\')\')')
    print('> 10: print(\'> 8: print(\\\'> 6: print(\\\\\\\'Snooping at the following lines:\\\\\\\')\\\')\')')

# Generated at 2022-06-24 17:14:06.105496
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    bool_0 = bool_1 = bool_2 = bool_3 = None
    str_0 = str_1 = str_2 = ""

    # Initialize Tracer class
    tracer = extras.pysnooper.Tracer()
    # Initialize mock for tracer._write
    mock_tracer__write = MagicMock()
    # Set attribute _write of tracer to mock
    tracer._write = mock_tracer__write
    # Initialize list of mock for tracer.watch
    mock_tracer_watch_list = []
    # Set attribute watch of tracer to list of mock
    tracer.watch = mock_tracer_watch_list
    # Initialize dict of mock for tracer.frame_to_local_reprs
    mock_tracer_frame_to_local_reprs = {}
   

# Generated at 2022-06-24 17:14:09.391069
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global bool_0
    obj_0 = Tracer()
    obj_1 = Tracer()
    obj_1.__enter__()
    bool_0 = True
    assert(bool_0 == True)


# Generated at 2022-06-24 17:14:16.554102
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Init
    tracer_0 = Tracer()

    try:
        # Call test_case_0
        test_case_0()

        # Call tracer_0.trace
        tracer_0.trace()

        # Call tracer_0.trace
        self.trace(frame=frame_0, event=str_0, arg=arg_0)
    except Exception as exception_0:
        # Report error
        logger.exception(exception_0)
###############################################################################


# Generated at 2022-06-24 17:14:26.044633
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global bool_0
    bool_0 = True
    snoop_1 = pysnooper.snoop(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    snoop_1.__enter__()
    snoop_1.__exit__(None, None, None)



# Generated at 2022-06-24 17:14:34.842443
# Unit test for function get_write_function
def test_get_write_function():
    bool_0 = True
    s = 'test_get_write_function'
    bool_1 = True
    bool_2 = True
    output = 'Test\n'
    actual = get_write_function(s, bool_0)
    expected = bool_1
    assert expected == actual
    actual = get_write_function(Test, bool_0)
    expected = bool_2
    assert expected == actual
    actual = get_write_function(output, bool_0)
    expected = True
    assert expected == actual


# Generated at 2022-06-24 17:14:38.937144
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Summarize test
    print("          Testing __call__...")
    # Execute function under test
    tracer_0 = Tracer()
    test_case_0()
    # Display output
    tracer_0.display_output()


# Generated at 2022-06-24 17:14:43.218067
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print("test_Tracer_trace()")
    # Constructor for class Tracer
    w_Tracer = Tracer()
    s_0 = 'Tracer'
    frame_9 = inspect.currentframe().f_back
    event_10 = 'call'
    arg_11 = None
    # Method of class Tracer for method trace
    # return_value_12 = w_Tracer.trace(frame_9, event_10, arg_11)


# Generated at 2022-06-24 17:14:46.048077
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer();
    bool_0 = True
    assert isinstance(tracer.__call__(tracer), bool)
    assert isinstance(tracer.__call__(bool_0), bool)


# Generated at 2022-06-24 17:14:51.781874
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    s = None
    frame = None
    event = None
    arg = None
    instance = Tracer(s)
    exception = instance.trace(frame, event, arg)


# Generated at 2022-06-24 17:15:12.177550
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    # AssertionError is raised
    try:
        tracer_0.__exit__(TypeError, None, None)
    except AssertionError:
        pass

# Generated at 2022-06-24 17:15:19.341147
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer(None, [], [], 1, '', False, False, [], 100, False, False)
    function_0 = test_Tracer___call__
    class_0 = tracer_0._wrap_class(function_0)
    class_1 = tracer_0._wrap_class(function_0)
    if class_0 == class_1:
        pass
    else:
        assert False



# Generated at 2022-06-24 17:15:21.863046
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    try:
        tester = doctest.DocTestSuite(Tracer)
        suite = unittest.TestSuite()
        suite.addTest(tester)
        unittest.TextTestRunner().run(suite)
    except:
        pass


# Generated at 2022-06-24 17:15:27.438377
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    code = inspect.currentframe().f_code
    assert get_path_and_source_from_frame(inspect.currentframe()) == (code.co_filename, [x.strip() for x in inspect.getsource(test_case_0).split('\n')])


# Generated at 2022-06-24 17:15:29.723561
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe(0)
    try:
        result = get_path_and_source_from_frame(frame)
    except Exception as ex:
        assert not "*** # fails!" in ex.args[0], ex.args[0]
    assert '*** # fails!' not in str(result), str(result)


# Generated at 2022-06-24 17:15:35.142267
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    obj_0 = Tracer()
    func_0 = obj_0.__call__(test_case_0)
    assert isinstance(func_0, function_type)


# Generated at 2022-06-24 17:15:44.377861
# Unit test for constructor of class Tracer
def test_Tracer():
    frame = inspect.currentframe()
    current_frame = frame.f_back
    while current_frame is not None:
        print("current frame: ", current_frame)
        current_frame = current_frame.f_back
    test_case_0()
    # print("current frame after calling test_case_0: ", inspect.currentframe().f_back)
    print("f_code: ", frame.f_code)
    print("f_back: ", frame.f_back)
    print("f_code_name: ", frame.f_code.co_name)
    print("f_code_filename: ", frame.f_code.co_filename)
    print("f_code_filename: ", frame.f_code.co_filename)

# Generated at 2022-06-24 17:15:53.845105
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    caller_frame = inspect.currentframe().f_back
    file_name, source = get_path_and_source_from_frame(caller_frame)
    assert file_name == __file__
    assert source[22:25] == ['def test_case_0():', '    bool_0 = True', '']
    caller_frame = caller_frame.f_back
    file_name, source = get_path_and_source_from_frame(caller_frame)
    assert file_name == __file__

# Generated at 2022-06-24 17:16:01.499720
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    snoop = pysnooper.Snooper('test_file.log')
    snoop.watch = []
    snoop.frame_to_local_reprs = {}
    snoop.start_times = {}
    snoop.depth = 1
    snoop.prefix = ''
    snoop.thread_info = False
    snoop.thread_info_padding = 0
    snoop.target_codes = set()
    snoop.target_frames = set()
    snoop.thread_local = threading.local()
    snoop.custom_repr = ()
    snoop.last_source_path = None
    snoop.max_variable_length = 100
    snoop.normalize = False
    snoop.relative_time = False
    exc_value = None
    exc_traceback = None
    sn

# Generated at 2022-06-24 17:16:04.634721
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    f = 0
    while f:
        f = frame.f_back
        # no fails
        get_path_and_source_from_frame(frame)



# Generated at 2022-06-24 17:16:28.432873
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():

    # Note, this assertion at the top of this function is to capture the
    # decorator. We know that this function code object is not modified by the
    # decorator, but it makes sense to capture it anyway.
    assert sys._getframe().f_code == test_Tracer___call__.__code__

    # Call wrapped function test_case_0
    # Capture the output
    with pysnooper.capture_output() as output:
        test_case_0()

        # Test the output

# Generated at 2022-06-24 17:16:32.413064
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    print("begin testing Tracer")
    Tracer_0 = Tracer()
    Tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:16:39.455721
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    output = None
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False

    Tracer_instance_0 = Tracer(output, watch, watch_explode, depth, prefix,
                               overwrite, thread_info, custom_repr, max_variable_length,
                               normalize, relative_time)
    Tracer_instance_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:16:49.433460
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Unit test for method trace of class Tracer
    plt.plot([1, 2, 3, 4])
    plt.ylabel('some numbers')
    plt.show()
    plt.savefig('test.png')
    # A simple test of Tracer.trace.
    import io
    import os
    import sys
    import unittest
    output = io.StringIO()
    tracer = Tracer(output, watch=('foo',))
    frame = utils.Frame({'foo': 42}, None)

    def trace_function(frame, event, arg):
        tracer.trace(frame, event, arg)
        frame.f_lineno += 1
        return trace_function

    frame.f_lineno = 2

# Generated at 2022-06-24 17:17:00.475806
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    bool_0 = True
    bool_1 = False
    string_0 = "c%#+$`9K'^>;*CQJy$@60,W8E-L/("
    string_1 = "c%#+$`9K'^>;*CQJy$@60,W8E-L/("
    int_0 = __randint(-1000, 1000)
    int_1 = __randint(-1000, 1000)
    int_2 = __randint(-1000, 1000)

# Generated at 2022-06-24 17:17:11.321435
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys
    import types

    depth = 0
    while True:
        current_frame = sys._getframe(depth)
        depth += 1
        if current_frame.f_code.co_name == 'test_get_path_and_source_from_frame':
            break

    result_path, result_source = get_path_and_source_from_frame(current_frame)

    assert result_path == __file__
    assert type(result_source) == type(tuple())
    assert len(result_source) == 2
    assert type(result_source[0]) == type('')
    assert result_source[0] == '# Unit test for function get_path_and_source_from_frame'
    assert type(result_source[1]) == type('')
    assert result_source[1]

# Generated at 2022-06-24 17:17:16.523197
# Unit test for function get_local_reprs
def test_get_local_reprs(): 
    assert get_local_reprs(get_local_reprs.__code__.co_firstlineno + inspect.currentframe().f_lineno - 1, 
                           watch=(), custom_repr=(), max_length=None, normalize=False) == {'bool_0': 'True'}


# Generated at 2022-06-24 17:17:21.828827
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Parameters
    frame = None
    event = None
    arg = None

    # Locals
    indent = None
    timestamp = None
    thread_info = None
    source_path = None
    source = None
    source_line = None
    line_no = None
    old_local_reprs = None
    local_reprs = None
    newish_string = None
    name = None
    value_repr = None
    ended_by_exception = None
    return_value_repr = None
    exception = None

    assert True

if __name__ == '__main__':
    test_case_0()
    test_Tracer_trace()

# Generated at 2022-06-24 17:17:25.386338
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = inspect.stack()[1].frame
    locals = get_local_reprs(frame, normalize=True, custom_repr={datetime_module.datetime: '<datetime(0)>'})
    assert locals == {'frame': '<frame (test_get_local_reprs)>', 'bool_0': 'True'}


# Generated at 2022-06-24 17:17:30.632510
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    trace_0 = Tracer(None)
    s = StringIO()
    with pysnooper.snoop(depth=5, watch_explode=(), output=s):
        test_case_0()
    print(s.getvalue())

# Generated at 2022-06-24 17:18:16.821491
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Assign values to variables of the class snoop_session
    # Assign values to variables of the class Tracer
    # Assign values to variables of the class BaseVariable
    # Assign values to variables of the class CommonVariable
    from pysnooper.utils import get_shortish_repr
    from pysnooper.base_variable import BaseVariable

    path = 'test_Tracer___exit__'
    variable_name = 'index'

    # Assign values to variables of the class Exploding
    # Assign values to variables of the class Exploding
    variable_name = 'var_0'

    # Assign values to variables of the class Tracer
    # Assign values to variables of the class Tracer
    # Assign values to variables of the class Tracer
    # Assign values to variables of the class Tracer
    # Ass

# Generated at 2022-06-24 17:18:27.709624
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import mock
    import sys
    import threading
    import inspect
    mock_self = mock.MagicMock(spec=Tracer, depth=2,
                               target_codes=set(), target_frames=set(),
                               start_times={}, thread_local=threading.local(),
                               thread_info_padding=0)
    mock_get_write_function = mock.MagicMock(side_effect=mock_self.write,
                                             spec=get_write_function)
    mock_writing_frame = mock.MagicMock(spec=FrameType,
                                        f_code=mock.MagicMock(spec=CodeType),
                                        f_trace=Tracer.trace,
                                        f_back=inspect.currentframe())

# Generated at 2022-06-24 17:18:36.053019
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    __test__ = {}
    test_case_0.__annotations__['return'] = BaseVariable
    frame = inspect.currentframe()
    while frame.f_code.co_filename == __file__:
        frame = frame.f_back
    result = get_path_and_source_from_frame(frame)
    test_result = (__file__, [u'def test_case_0():\n', u'    bool_0 = True\n'])
    assert result == test_result, (result, test_result)
    return result

result = test_get_path_and_source_from_frame()


# Generated at 2022-06-24 17:18:40.851466
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    snooper.load_store()
    with snooper.snoop(output='file.txt') as result:
        test_case_0()
        pass
    assert result.exception is None
    assert result.start_time is not None
    assert result.end_time is not None
