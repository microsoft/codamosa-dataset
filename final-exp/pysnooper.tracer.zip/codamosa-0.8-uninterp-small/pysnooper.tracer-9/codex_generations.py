

# Generated at 2022-06-24 17:09:19.801215
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()


# Generated at 2022-06-24 17:09:25.194165
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False

if __name__ == '__main__':
    test_get_path_and_source_from_frame()

# Generated at 2022-06-24 17:09:28.517535
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # State method to test
    tracer = Tracer()
    tracer.__exit__(None, None, None)



# Generated at 2022-06-24 17:09:35.147110
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    decorator_0 = tracer_0

    @decorator_0
    def function_0():
        complex_0 = None
        var_0 = get_path_and_source_from_frame(complex_0)

    var_0 = function_0

    var_1 = Tracer.__call__(tracer_0, function_0)


# Generated at 2022-06-24 17:09:40.111152
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    with tracer_0:
        test_case_0()


# Generated at 2022-06-24 17:09:51.112782
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def method_0(arg_0):
        return arg_0
    method_0.__dict__['var_0'] = arg_0
    method_0.__dict__['var_1'] = arg_1
    method_0.__dict__['var_2'] = arg_2
    method_0.__dict__['var_3'] = arg_3
    method_0.__dict__['var_4'] = arg_4
    method_0.__dict__['var_5'] = arg_5
    method_0.__dict__['var_6'] = arg_6
    method_0.__dict__['var_7'] = arg_7
    method_0.__dict__['var_8'] = arg_8
    method_0.__dict__['var_9'] = arg_9
    method

# Generated at 2022-06-24 17:09:53.155300
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Create an instance of Tracer
    tracer_obj = Tracer()

    # Call method trace of Tracer with arguments frame, event, arg


# Generated at 2022-06-24 17:10:06.239875
# Unit test for function get_path_and_source_from_frame

# Generated at 2022-06-24 17:10:13.494723
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    complex_0 = None
    obj_0 = Tracer()
    obj_0.target_codes = set()
    var_0 = obj_0.trace(complex_0, 'complex_1', complex_0)
    with pytest.raises(NotImplementedError):
        obj_0.trace(complex_0, 'complex_1', complex_0)


# Generated at 2022-06-24 17:10:16.997999
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_name = ''
    overwrite = False
    file_writer = FileWriter(file_name, overwrite)
    s = ''
    file_writer.write(s)



# Generated at 2022-06-24 17:10:35.817425
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    assert result[0] == __file__, result[0]
    assert result[1][0] == 'def test_case_0():', result[1][0]
    del frame


_sentinel = object()


# Generated at 2022-06-24 17:10:39.999600
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    with tracer_0:
        pass


# Generated at 2022-06-24 17:10:49.335066
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.write('\n')
    tracer_0.thread_local.original_trace_functions = list()
    tracer_0.frame_to_local_reprs = dict()
    tracer_0.start_times = dict()
    tracer_0.target_codes = set()
    tracer_0.target_frames = set()
    tracer_0.last_source_path = None
    frame_0 = inspect.currentframe()
    tracer_0.__exit__(None,None,None)


# Generated at 2022-06-24 17:10:54.409240
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from_where = 'test_Tracer_trace'
    tracer_0 = Tracer()
    frame_0 = inspect.getouterframes(inspect.currentframe())[0][0]
    event_0 = 'call'
    arg_0 = None
    tracer_0.trace(frame_0, event_0, arg_0)
    return


# Generated at 2022-06-24 17:10:56.850496
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """Test of the method trace of class Tracer"""
    with Tracer() as tracer_0:
        pass


# Generated at 2022-06-24 17:10:58.214257
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    with tracer_0:
        pass


# Generated at 2022-06-24 17:11:06.055515
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    assert tracer_0._is_internal_frame(None) == False
    assert tracer_0._is_internal_frame(None) == False
    assert tracer_0._is_internal_frame(None) == False
    assert tracer_0._is_internal_frame(None) == False
    assert tracer_0._is_internal_frame(None) == False
    assert tracer_0._is_internal_frame(None) == False
    assert tracer_0._is_internal_frame(None) == False
    assert tracer_0._is_internal_frame(None) == False
    # TODO: implement these tests


# Generated at 2022-06-24 17:11:09.617521
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = test_case_0.__code__.co_filename
    path, source = get_path_and_source_from_frame(frame)
    assert path == test_case_0.__code__.co_filename
    assert source == inspect.getsourcelines(test_case_0)[0]



# Generated at 2022-06-24 17:11:14.089328
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    ts = datetime_module.datetime.now()

    assert tracer_0.__exit__(None, None, None) == None
    assert tracer_0.__exit__(None, None, None) == None
    assert tracer_0.__exit__(None, None, None) == None
    assert tracer_0.__exit__(None, None, None) == None
    assert tracer_0.__exit__(None, None, None) == None
    assert tracer_0.__exit__(None, None, None) == None


# Generated at 2022-06-24 17:11:23.978119
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    this_script_filename = os.path.abspath(inspect.getfile(test_get_path_and_source_from_frame))
    def test_tracer(frame, event, arg):
        test_case_0.__dict__['path_and_source'] = get_path_and_source_from_frame(frame)
    tracer_0.append(test_tracer)
    tracer_1 = Tracer()
    tracer_0.runfunc(test_case_0)
    tracer_1.append(test_tracer)
    tracer_2 = Tracer()
    def test_case_1():
        tracer_1.runfunc(test_case_0)
    tracer_1.runfunc(test_case_1)
    def test_case_2():
        tr

# Generated at 2022-06-24 17:11:47.067527
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import os.path
    import traceback
    import pysnooper
    # This class will be used to test the method __call__ of class Tracer
    class TestTracer__call__():
        def __init__(self):
            pass
        def __enter__(self):
            pass
        def __exit__(self, exc_type, exc_value, exc_traceback):
            pass
        def write(self, s):
            pass
        def set_thread_info_padding(self, thread_info):
            pass
        def trace(self, frame, event, arg):
            pass
        def test_case_0(self):
            pass
    # Get the function we need to test
    _Tracer = pysnooper.Tracer()
    testTracer___call__ = Tracer.__call__.__get

# Generated at 2022-06-24 17:11:52.905706
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function_0():
        function_1()

    def function_1():
        tracer_0 = Tracer() # breakpoint
        print(1)

    function_0()


tracer_lock = threading.RLock()



# Generated at 2022-06-24 17:12:04.709572
# Unit test for function get_local_reprs
def test_get_local_reprs():
    tracer = Tracer()

    def test_func():
        e = 123
        f = 'abc'
        g = set()
        g.add(e)
        h = 456
        
    watch = (Exploding(e),)
    result = tracer.get_local_reprs(test_func, watch, max_length=10)
    assert result['e'] == '123'
    assert result['f'] == 'abc'
    assert result['g'] == '{e}'
    assert result['h'] == '456'
    
    


# Generated at 2022-06-24 17:12:08.476562
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = "C:\\Users\\Mai Thanh\\PycharmProjects\\python_debugger\\tracer\\tests\\test_FileWriter_write"
    obj = FileWriter(path, overwrite=True)
    obj.write("test_file")


# Generated at 2022-06-24 17:12:17.763119
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys
    import tempfile

    def test_func():
        # The following line is at line 3
        pass

    frame = inspect.currentframe()
    (path, source) = get_path_and_source_from_frame(frame)
    source_line = source[0]
    assert 'def test_get_path_and_source_from_frame():' == source_line,\
        'Actual: %s' % source_line

    # Unit test if the file name is not the same as the __file__ attribute
    temp_file = tempfile.mkstemp()[1]
    temp_dir = tempfile.mkdtemp()
    temp_file = os.path.join(temp_dir, 'temp.py')

# Generated at 2022-06-24 17:12:20.633362
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_1 = Tracer()
    tracer_1.__exit__(exc_type, exc_value, exc_traceback)


# Generated at 2022-06-24 17:12:25.216985
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    file_name, source = get_path_and_source_from_frame(test_case_0.__code__.co_firstlineno)
    assert file_name == __file__
    assert source == [
        'def test_case_0():',
        '    tracer_0 = Tracer()',
    ]


# Generated at 2022-06-24 17:12:34.809425
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    stack_0 = []
    frame_0 = None
    event_0 = None
    arg_0 = None
    thread_global.depth = -1
    assert inspect.currentframe().f_back is frame_0
    assert opcode.opname[ord(frame_0.f_code.co_code[arg_0.f_lasti])] not in ('RETURN_VALUE', 'YIELD_VALUE')
    assert event_0 == 'return'
    assert arg_0 is None
    assert tracer_0.trace(frame_0, event_0, arg_0) is tracer_0.trace


# Generated at 2022-06-24 17:12:44.752932
# Unit test for function get_write_function
def test_get_write_function():
    # test case 0: output is None
    # expected result: write function should output to default stdout
    write = get_write_function(None, False)
    write('test case 0')
    # test case 1: overwrite is True, output is str
    # expected result: write function should output to file and overwrite
    write = get_write_function('tmp', True)
    write('test case 1')
    # test case 2: overwrite is False, output is callable
    # expected result: write function should output to file and append
    write = get_write_function(print, False)
    write('test case 2')
    # test case 3: overwrite is True, output is utils.WritableStream
    # expected result: write function should output to stream
    write = get_write_function(sys.stdout, True)

# Generated at 2022-06-24 17:12:51.066794
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # tracer_0 = Tracer()
    # __exit__(tracer_0, exc_type, exc_value, exc_traceback)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 17:13:11.166822
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_writer = FileWriter("output.txt", overwrite=True)
    file_writer.write("hello")
    file_writer.write("world")
    with open("output.txt", mode="r") as file:
        output = file.read()
        assert output == "hello"



# Generated at 2022-06-24 17:13:14.594145
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    with tracer_0:
        pass
    tracer_1 = Tracer()
    with tracer_1:
        pass
    pass


# Generated at 2022-06-24 17:13:15.598864
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    test_case_0()


# Generated at 2022-06-24 17:13:25.272004
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .python_magic import PythonMagic
    from .frames import Frame
    from .utilities import unittest
    from .environment import Environment

    class TracerTestCase(unittest.TestCase):
        def setUp(self):
            self.environment = Environment(sys.executable, ())
            self.python_magic = PythonMagic(self.environment)
            frame_filter = lambda frame: inspect.isfunction(frame.f_code)
            self.frame_info_maker = FrameInfoMaker(
                self.python_magic, frame_filter, False)
            tracer_test_env = {'test_case_0': test_case_0,
                               'Tracer': Tracer}

# Generated at 2022-06-24 17:13:30.162298
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__(None, None, None)
    assert True

    def test_case_inner_0():
        tracer_0 = Tracer()
        for x in range(6):
            if x == 2:
                tracer_0.depth -= 1
            if x == 5:
                tracer_0.depth += 1
            tracer_0.__exit__(None, None, None)
        assert True

    test_case_inner_0()


# Generated at 2022-06-24 17:13:32.016145
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    def test_target():
        pass
    tracer(test_target)


# Generated at 2022-06-24 17:13:39.929839
# Unit test for constructor of class Tracer
def test_Tracer():
    # test for default values
    assert tracer_0.watch == []
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ''
    assert tracer_0.thread_info_padding == 0
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.thread_local == threading.local
    assert tracer_0.custom_repr == ()
    assert tracer_0.max_variable_length == 100
    assert tracer_0.relative_time == False
    assert tracer_0.start_times == {}
    assert tracer_0.frame_to_local_reprs == {}


# Generated at 2022-06-24 17:13:44.788634
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    assert_equal(tracer_0.__enter__(), None)


# Generated at 2022-06-24 17:13:50.833940
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        file_path = os.path.join(temp_dir, 'test')
        FileWriter(file_path, True).write('hello, world\n')
        FileWriter(file_path, False).write('goodbye, world\n')

        with open(file_path) as f:
            lines = f.readlines()
            assert lines == ['hello, world\n', 'goodbye, world\n']



# Generated at 2022-06-24 17:13:54.235325
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_1 = Tracer()
    tracer_1.__exit__(exc_type=None, exc_value=None, exc_traceback=None)


# Generated at 2022-06-24 17:14:13.089799
# Unit test for function get_write_function
def test_get_write_function():
    sys.stdout = io.StringIO()
    test_case_0()
    sys.stdout = sys.__stdout__


# Generated at 2022-06-24 17:14:18.195506
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func_to_trace():
        x = 5
        y = x

    _, tracer_0 = trace_function(func_to_trace, return_tracer=True)

    assert tracer_0.start_time
    assert tracer_0.end_time
    assert tracer_0.execution_time == 0



# Generated at 2022-06-24 17:14:25.698269
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    t = Tracer()
    code = test_case_0.__code__
    f = inspect.currentframe().f_back
    t.trace(f, 'call', None)


test_Tracer_trace()

if __name__ == '__main__':
    # Run the tests!
    def test_case_1():
        pass

    def test_case_2():
        return 'hello'

    def test_case_3():
        return 1 + 1

    def test_case_4():
        i = 0
        i += 1
        return i

    def test_case_5():
        return test_case_2()

    def test_case_6():
        return test_case_3()

    def test_case_7():
        return test_case_4()


# Generated at 2022-06-24 17:14:36.595615
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.depth = 1
    tracer_0.target_frames = set()
    tracer_0.frame_to_local_reprs = {}
    tracer_0.start_times = {}
    tracer_0.max_variable_length = 100
    tracer_0.prefix = ''
    tracer_0.thread_info_padding = 0
    tracer_0.watch = [
            v if isinstance(v, BaseVariable) else CommonVariable(v)
            for v in utils.ensure_tuple(watch)
         ] + [
             v if isinstance(v, BaseVariable) else Exploding(v)
             for v in utils.ensure_tuple(watch_explode)
        ]


# Generated at 2022-06-24 17:14:40.727116
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Rough way of getting the calling frame
    outer_frame = inspect.currentframe().f_back
    assert get_path_and_source_from_frame(outer_frame)[0] == __file__


# Generated at 2022-06-24 17:14:44.880995
# Unit test for function get_write_function
def test_get_write_function():
    normal_stepline_output = open("normal_stepline_output.txt", "w")
    assert get_write_function(normal_stepline_output, False) == normal_stepline_output.write
    normal_stepline_output.close()



# Generated at 2022-06-24 17:14:48.921276
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    exc_type_0 = exc_type_0
    exc_value_0 = exc_value_0
    exc_traceback_0 = exc_traceback_0
    return_value_0 = tracer_0.__exit__(exc_type_0, exc_value_0, exc_traceback_0)
    return return_value_0


# Generated at 2022-06-24 17:14:57.570099
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with tracer_0 as mock_self:
        __trace_function_0 = mock_self.trace
        trace_function_0 = get_trace_function(mock_self)
        assert (__trace_function_0, mock_self.trace) == (trace_function_0, None)
        __trace_function_0 = mock_self.trace
        mock_self.trace = mock.Mock()
        trace_function_0 = get_trace_function(mock_self)
        mock_self.trace = __trace_function_0
        assert trace_function_0 == mock.Mock()


# Generated at 2022-06-24 17:15:02.426888
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_1 = Tracer()
    tracer_1.frame_to_local_reprs = {}
    tracer_1.start_times = {}

    # Begin unit test code
    tracer_1.frame_to_local_reprs = {}
    tracer_1.start_times = {}

    # Begin unit test code


# Generated at 2022-06-24 17:15:04.458970
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    result_0 = test_case_0()
    assert result_0 == None

test_module()


# Generated at 2022-06-24 17:15:25.060129
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:15:28.631097
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    tracer_0.__enter__()
    assert tracer_0._write is sys.stdout.write



# Generated at 2022-06-24 17:15:31.731584
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    return
    def test_case_1():
        def inside_function():
            path, source = get_path_and_source_from_frame(inspect.currentframe())
            print('path: %s' % path)
            print('source: %s' % source)
        inside_function()






# Generated at 2022-06-24 17:15:43.206324
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    assert tracer_0.__call__((lambda function_or_class:
        (lambda function_or_class: function_or_class)(function_or_class))) == (lambda function_or_class:
        (lambda function_or_class: function_or_class)(function_or_class))
    assert tracer_0.__call__((lambda self: (lambda self: self)(self))) == (lambda self: (lambda self: self)(self))


# Generated at 2022-06-24 17:15:45.077718
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer():
        pass
    return True



# Generated at 2022-06-24 17:15:54.346233
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper import tracer, utils
    import linecache
    # import inspect

    def dummy_function(a, b, c):
        x = a + b
        y = x * c
        return y

    def another_function():
        dummy_function(2, 3, 5)

    def yet_another_function():
        another_function()

    def test_x_function(x):
        return x

    # create a Tracer object
    tracer_object = tracer.Tracer()
    # create a function object
    function = yet_another_function

    # now, we construct the test data
    code_object = function.__code__
    event = "call"
    frame = utils.create_frame(function, [1, 2, 3], {}, "dummy_function")
    frame_

# Generated at 2022-06-24 17:15:55.865449
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    print(get_path_and_source_from_frame(frame))



# Generated at 2022-06-24 17:15:57.489314
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global DISABLED
    DISABLED = True


# Generated at 2022-06-24 17:16:00.657756
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()

    with tracer_0:
        pass


# Generated at 2022-06-24 17:16:04.955233
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():

    test_case_0()

# Initialize module level global variables
DISABLED = False

try:
    module_level_global_0 = raw_input
except NameError:
    # Python 3
    module_level_global_0 = input


# Generated at 2022-06-24 17:16:27.696554
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    trace_0 = Tracer.trace(Tracer(), None, None, None)
    assert trace_0 is None


# Generated at 2022-06-24 17:16:34.517400
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    test_frame_0 = inspect.currentframe().f_back
    test_event_0 = 'call'
    test_arg_0 = None
    # Call the method
    tracer_0.trace(test_frame_0, test_event_0, test_arg_0)


# Generated at 2022-06-24 17:16:43.918138
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Create an instance of Tracer
    tracer_0 = Tracer()
    
    # Create a (mock) frame
    frame_0 = Mock()
    
    # Set frame_0.f_code.co_filename to a (mock) value
    frame_0.f_code.co_filename = Mock()

    # Set frame_0.f_back.f_code to a (mock) value
    frame_0.f_back.f_code = Mock()
    
    # Set frame_0.f_lineno to a (mock) value
    frame_0.f_lineno = Mock()

    # Set frame_0.f_code to a (mock) value
    frame_0.f_code = Mock()
    
    # Set frame_0.f_code.co_code to a

# Generated at 2022-06-24 17:16:49.498400
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    print("Testing method __exit__ of class Tracer")
    tracer_0 = Tracer()
    try:
        tracer_0.__exit__(1)
    except:
        pass
    else:
        pass


# Generated at 2022-06-24 17:17:00.297644
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import mypy_extensions
    try:
        import pickle
    except ModuleNotFoundError as e:
        # Issue #1
        if e.name == '_pickle':
            return
        else:
            raise
    FileWriter.__module__ = 'sugaroid.sugaroid'
    FileWriter.__qualname__ = 'FileWriter'
    tracer_1 = Tracer()
    tracer_1.output = './test_FileWriter_write_output'
    tracer_1.start()
    test_case_0()
    tracer_1.stop()
    (output_text, expected_text) = tracer_1.diff()
    if output_text != expected_text:
        raise Exception('test_FileWriter_write failed')



# Generated at 2022-06-24 17:17:08.086733
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED # make DISABLED global to get its value (because of nested functions)
    DISABLED = True
    tracer_0 = Tracer()
    DISABLED = False
    frame_0 = inspect.currentframe()
    event_0 = 'call'
    arg_0 = None
    result_0 = tracer_0.trace(frame_0, event_0, arg_0)

# Execution of test case 0
test_case_0()

# Execution of test Tracer.trace
test_Tracer_trace()

# Generated at 2022-06-24 17:17:10.183469
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  # noinspection PyUnusedLocal
  @Tracer()
  def foo():
      pass
  foo()


# Generated at 2022-06-24 17:17:15.408498
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper.variable import CommonVariable

    test_case_0()

    tracer_1 = Tracer(output=sys.stdout, watch='foo', watch_explode='self')
    assert tracer_1.watch == [CommonVariable('foo'), Exploding('self')]


# Generated at 2022-06-24 17:17:19.111107
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    tracer_0.trace()

if __name__ == '__main__':
    test_case_0()
    test_Tracer_trace()

# Generated at 2022-06-24 17:17:24.815061
# Unit test for constructor of class Tracer
def test_Tracer():
    import inspect

    test_case_0()
    test_case_0.__defaults__ = (None, (), (), 1, '', False, False, (), 100, False, False)
    assert test_case_0.__defaults__ == Tracer.__init__.__defaults__
    args, varargs, varkw, defaults = inspect.getargspec(Tracer.__init__)
    assert args == ['self', 'output', 'watch', 'watch_explode', 'depth', 'prefix', 'overwrite', 'thread_info',
                    'custom_repr', 'max_variable_length', 'normalize', 'relative_time']

import unittest
