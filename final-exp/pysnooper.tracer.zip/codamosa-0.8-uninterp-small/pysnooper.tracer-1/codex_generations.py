

# Generated at 2022-06-24 17:09:25.744665
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop()
    def test():
        list_0 = [1,2,3]
        a = 1
        list_0.append(a)
        test_case_0()

    test()

if __name__ == "__main__":
    test_Tracer()

# Generated at 2022-06-24 17:09:37.212333
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Default arguments are tested
    test_snooper = Tracer()
    test_snooper.__enter__()
    assert test_snooper.watch == [], \
    "Expected {0}, Actual {1}".format([], test_snooper.watch)
    assert test_snooper.frame_to_local_reprs == {}, \
    "Expected {0}, Actual {1}".format({}, test_snooper.frame_to_local_reprs)
    assert test_snooper.start_times == {}, \
    "Expected {0}, Actual {1}".format({}, test_snooper.start_times)

# Generated at 2022-06-24 17:09:38.928353
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    test_case_0()


# Generated at 2022-06-24 17:09:46.117709
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    start_time = datetime_module.datetime.now()
    start_time_ = start_time + datetime_module.timedelta(0, 0, 1)
    # Initialise the object to test
    tracer = Tracer(watch=("foo", "bar", "baz"), watch_explode=("foo", "bar", "baz"), depth=1,
                    prefix='', overwrite=False, thread_info=False, custom_repr=(),
                    max_variable_length=100, normalize=False, relative_time=False)

    # Call method __exit__
    indent = ' ' * 4 * (thread_global.depth + 1)
    stack = tracer.thread_local.original_trace_functions
    sys.settrace(stack.pop())
    calling_frame = inspect.currentframe().f_back

# Generated at 2022-06-24 17:09:51.903004
# Unit test for method trace of class Tracer
def test_Tracer_trace():

    testTrace = Tracer.trace
    # Test case 0
    global frame
    frame = 0
    global event
    event = 'call'
    global arg
    arg = 0
    result = testTrace(frame, event, arg)
    # Test case 1
    global frame
    frame = 1
    global event
    event = 'call'
    global arg
    arg = 1
    result = testTrace(frame, event, arg)
    # Test case 2
    global frame
    frame = 1
    global event
    event = 'call'
    global arg
    arg = 1
    result = testTrace(frame, event, arg)
    # Test case 3
    global frame
    frame = 1
    global event
    event = 'call'
    global arg
    arg = 1

# Generated at 2022-06-24 17:09:56.662612
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():

    tracer_0 = Tracer()
    try:
        tracer_0.__enter__()
    except Exception as e:
        print("Exception in 'test_Tracer___enter__':", e)


# Generated at 2022-06-24 17:09:57.457476
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert None



# Generated at 2022-06-24 17:10:07.732058
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import os, sys, pycompat
    pycompat
    # Save current directory
    cwd = os.getcwd()
    # Test that function get_path_and_source_from_frame returns correct result
    # on a test python file
    test_path = f'{os.path.abspath(__file__)}'
    os.chdir(os.path.dirname(test_path))
    with open(test_path, 'rb') as fp:
        source = fp.read().splitlines()
    frame = sys._getframe()
    path, src = get_path_and_source_from_frame(frame)
    assert src == source
    os.chdir(cwd)



# Generated at 2022-06-24 17:10:20.656239
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    start_time = datetime_module.datetime.now()
    thread_info = str(threading.current_thread())
    start_time_isoformat = pycompat.time_isoformat(start_time.time(), timespec='microseconds')
    timestamp = ""
    indent = ""
    source_path = "/mnt/d/Program Files/JetBrains/PyCharm Community Edition 2019.3.3/helpers/pydev/pydevd_vars.py"
    line_no = 11
    source_line = "                                                     # We should trace this line either if it's in the decorated function,"
    newish_string = ("Starting var:.. " if event == 'call' else 'New var:....... ')
    name = "indent"
    value_repr = ""
    self = Tracer()

# Generated at 2022-06-24 17:10:22.757810
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import inspect
    import itertools
    import opcode
    import threading
    import traceback
    test_case_0()

# Generated at 2022-06-24 17:10:48.922933
# Unit test for function get_write_function
def test_get_write_function():
    # test_get_write_function
    #test_0
    output = None
    overwrite = None
    expected_result = sys.stderr
    result = get_write_function(output, overwrite)
    assert result == expected_result


# Generated at 2022-06-24 17:10:53.276478
# Unit test for constructor of class Tracer
def test_Tracer():

    print("test_Tracer:")
    test_case_0()
    print("test_Tracer: OK")
    print("")
    return




# Generated at 2022-06-24 17:10:57.495577
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # For exceptions
    global tracer_0
    with pytest.raises(Exception):
        tracer_0.__exit__()


# Generated at 2022-06-24 17:11:06.520600
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_1 = Tracer()
    assert tracer_0.start_times == {}
    tracer_0.start_times[1] = 1
    assert tracer_0.start_times == {1: 1}
    tracer_1.start_times[1] = 1
    assert tracer_1.start_times == {1: 1}
    exc_type_0 = None
    exc_value_0 = None
    exc_traceback_0 = None
    assert tracer_0.start_times == {1: 1}
    assert tracer_1.start_times == {1: 1}
    tracer_0.__exit__(exc_type_0, exc_value_0, exc_traceback_0)
    assert tracer_0.start_times

# Generated at 2022-06-24 17:11:08.179974
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_1 = Tracer()
    with tracer_1:
        pass


# Generated at 2022-06-24 17:11:11.275040
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    try:
        test_case_0()
    except Exception as e:
        if "module" not in str(e):
            raise Exception("test_case_0() raised an exception: " + str(e))
        else:
            print("test_case_0() raised an exception: " + str(e))
# Test the creation of valid tracers

# Generated at 2022-06-24 17:11:17.958196
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame_0 = sys._getframe()
    path, source = get_path_and_source_from_frame(frame_0)
    print(source)
    line_number = int(input("Select Line Number:"))
    print("Original source code:")
    print("".join(source[line_number-2:line_number]))
    print("Post-normalized source code:")
    print("".join(utils.normalize_source_code(source, line_number-1)))


# Generated at 2022-06-24 17:11:20.526783
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    obj = Tracer()
    obj.__enter__()
# test_Tracer___enter__


# Generated at 2022-06-24 17:11:24.325758
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    print(test_case_0.__doc__)
    try:
        tracer_0 = Tracer()
        tracer_0.__exit__()
    except:
        utils.print_traceback()
        return 1
    else:
        return 0


# Generated at 2022-06-24 17:11:26.077347
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    test_case_0()


# Generated at 2022-06-24 17:12:01.594506
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    test_func_0 = test_case_0
    expected_result_0 = None
    result_0 = tracer_0.__call__(test_func_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-24 17:12:04.465061
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    tracer_1 = tracer_0.__call__(test_case_0)


# Generated at 2022-06-24 17:12:07.687425
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    def function_or_class_0():
        pass

    tracer_0.__call__(function_or_class_0)


# Generated at 2022-06-24 17:12:17.002537
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    argc = 0
    argv = sys.argv
    for arg in argv:
        if arg == '-t' and argc == 1:
            # expected output:
            # ('/home/test_get_path_and_source_from_frame.py', ['def test_case_0():', '    tracer_0 = Tracer()'])
            print(get_path_and_source_from_frame(inspect.currentframe().f_back.f_back))
        elif arg == '-t' and argc == 0:
            argc += 1
            continue
        else:
            print('Usage: python test_get_path_and_source_from_frame.py -t')
            raise
    return


# Generated at 2022-06-24 17:12:27.609923
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    tracer_0.watch = ['foo', 'self']
    tracer_0.frame_to_local_reprs = {}
    tracer_0.start_times = {}
    tracer_0.depth = 1
    tracer_0.prefix = ''
    tracer_0.thread_info = False
    tracer_0.thread_info_padding = 0
    assert tracer_0.depth >= 1
    tracer_0.target_codes = set()
    tracer_0.target_frames = set()
    tracer_0.thread_local = threading.local()
    tracer_0.custom_repr = (('hello', 'world'),)
    tracer_0.last_source_path = None
    tracer_0.max_variable_length

# Generated at 2022-06-24 17:12:29.315485
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.__exit__(None, None, None)


# Generated at 2022-06-24 17:12:30.594955
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    test_case_0()


# Generated at 2022-06-24 17:12:32.658929
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-24 17:12:41.514385
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        pass

    def make_frame():
        frame = inspect.currentframe().f_back.f_back
        frame.f_globals = {'test_function': test_function}
        frame.f_lineno = 5
        frame.f_code = frame.f_code = test_function.__code__
        return frame

    frame = make_frame()

    path_and_source = get_path_and_source_from_frame(frame)
    assert path_and_source == (repr(path_and_source), [])

    path_and_source = get_path_and_source_from_frame(frame)

    path, source = path_and_source

    source = source[1:]

    source_str = '\n'.join(source).strip()

    assert path

# Generated at 2022-06-24 17:12:45.525697
# Unit test for function get_write_function
def test_get_write_function():
    output = ""
    overwrite = True
    func = get_write_function(output, overwrite)
    assert callable(func)
    assert func.__name__ == 'write'
    assert func.__self__ == output



# Generated at 2022-06-24 17:13:09.296100
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = None
    event_0 = 'call'
    arg_0 = None
    tracer_0.trace(frame_0, event_0, arg_0)



# Generated at 2022-06-24 17:13:17.648657
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Prepare
    tracer_0 = Tracer()
    tracer_1 = Tracer()
    function_or_class = test_case_0
    tracer_call_result = tracer_0.__call__(function_or_class)
    tracer_call_result = tracer_1.__call__(function_or_class)
    # Execute
    function_or_class = test_Tracer___call__
    tracer_call_result = tracer_0.__call__(function_or_class)
    # Assert
    assert (not False)


# Generated at 2022-06-24 17:13:26.205321
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_cases = [test_case_0]
    test_number = 0
    number_of_failed_tests = 0
    
    for test_case in test_cases:
        test_number += 1
        try:
            test_case()
        except Exception as exception:
            exception_type = type(exception).__name__
            exception_text = str(exception)
            print('Test number %s failed due to %s: %s' % (test_number, exception_type, exception_text))
            number_of_failed_tests += 1
            
    if number_of_failed_tests == 0:
        print('No test failed')
    else:
        print('%s test(s) failed' % number_of_failed_tests)





# Generated at 2022-06-24 17:13:37.797893
# Unit test for function get_write_function
def test_get_write_function():
    import io

    assert callable(get_write_function(None, False))
    assert callable(get_write_function(io.StringIO(), False))
    assert callable(get_write_function(sys.stderr, False))
    assert callable(get_write_function('path.txt', False))

    # Exception should be thrown when overwrite is True and output is not a path
    raised = False
    try:
        get_write_function(io.StringIO(), True)
    except Exception:
        raised = True
    assert raised


# Generated at 2022-06-24 17:13:45.738733
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from pathlib import Path
    import os

    current_dir = os.getcwd()
    test_path = Path(current_dir + '/test_FileWriter_write.txt')
    test_string = 'Test of FileWriter.write() - test line 1 '

    if not os.path.isfile(test_path):
        FileWriter(test_path, True).write(test_string)
    else:
        FileWriter(test_path, False).write(test_string)

    with open(test_path, 'r', encoding='utf-8') as file:
        lines = file.read()
        assert test_string in lines


# Generated at 2022-06-24 17:13:48.404927
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()

    # Call method trace of class Tracer
    tracer_0.trace(None, None, None)


# Generated at 2022-06-24 17:13:49.737651
# Unit test for constructor of class Tracer
def test_Tracer():
    test_case_0()


# Generated at 2022-06-24 17:14:03.192511
# Unit test for constructor of class Tracer
def test_Tracer():
    output = None
    watch = ('a', 'b')
    watch_explode = ('c', 'd')
    depth = 3
    prefix = 'PY'
    overwrite = True
    thread_info = True
    custom_repr = (('b', 'c'),)
    max_variable_length = 20
    normalize = False
    relative_time = True

    tracer = Tracer(output, watch, watch_explode, depth, prefix, overwrite, thread_info,
                    custom_repr, max_variable_length, normalize, relative_time)


    assert(tracer._write == None)
    assert(tracer.watch == [CommonVariable('a'), CommonVariable('b'),
                            Exploding('c'), Exploding('d')])

# Generated at 2022-06-24 17:14:13.324475
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_1 = Tracer(prefix="traced output")

    # Function test_case_1's source code
    source_1 = \
        """def test_case_1(a):\n""" + \
        """    b = a * a\n""" + \
        """    c = b * b\n""" + \
        """    return c\n""" + \
        """\n""" + \
        """def test_case_2(a):\n""" + \
        """    return test_case_1(a)"""

    # Function test_case_3's source code
    source_3 = \
        """def test_case_3():\n""" + \
        """    test_case_1(1)\n"""

    # Function test_case_4's source code

# Generated at 2022-06-24 17:14:18.614516
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    """
    Test function for method Tracer___call__
    """
    try:
        function_or_class = tracer_0
        expected_value = None
        actual_value = tracer_0.__call__(function_or_class)
        assert actual_value == expected_value
    except:
        raise AssertionError


# Generated at 2022-06-24 17:15:03.003720
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    this_code = utils.get_code(test_case_0)
    this_frame = utils.get_frame(test_case_0)
    assert get_path_and_source_from_frame(this_frame)[0] == this_code.co_filename




# Generated at 2022-06-24 17:15:07.540817
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test Case 0:
    tracer_0 = Tracer()
    assert tracer_0.trace(frame, event, arg) == tracer_0.trace, \
        "get_source_path_and_source returned {}, expected {}".\
        format(tracer_0.trace(frame, event, arg), tracer_0.trace)


# Generated at 2022-06-24 17:15:14.648982
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .utils import Frame
    from . import variables as variables_module
    from . import room as room_module
    from . import utils as utils_module
    from . import pycompat as pycompat_module
    from . import line_runner as line_runner_module
    from . import tracer as tracer_module
    from . import recorder as recorder_module
    from . import logger as logger_module

    frame = Frame(test_case_0)
    file_name, source = get_path_and_source_from_frame(frame)
    path = os.path.abspath(inspect.getfile(test_case_0))
    assert path == file_name
    assert source[2] == 'tracer_0 = Tracer()'



# Generated at 2022-06-24 17:15:20.068840
# Unit test for constructor of class Tracer
def test_Tracer():
    print("\nFunction test_case_0: Unit test for constructor of class Tracer\n")
    tracer_0 = Tracer()
    # print("\nTracer: tracer_0 = Tracer()")
    # print("Function test_case_0: Pass\n")
    # print("****************************************************************"
    #       "********************\n")



# Generated at 2022-06-24 17:15:25.507935
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    assert result[0] == os.path.realpath(__file__)
    assert result[1][0] == '# Unit test for function get_path_and_source_from_frame'



# Generated at 2022-06-24 17:15:33.121165
# Unit test for function get_write_function
def test_get_write_function():
    # Test for output as sys.stderr
    test_case_0()
    # Test for output as file
    file_name = "test_output.txt"
    try:
        if os.path.exists(file_name):
            os.remove(file_name)
        output = open(file_name, "w")
        write = get_write_function(output, False)
        write(b"test")
        output.close()
    finally:
        if os.path.exists(file_name):
            os.remove(file_name)
    # Test for output as function
    write = get_write_function(test_case_0, False)
    write('test')


# Generated at 2022-06-24 17:15:46.153311
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global tracer_0

    # Test attribute target_codes
    assert tracer_0.target_codes == test_case_0.__code__

    # Test attribute target_frames
    assert tracer_0.target_frames == inspect.currentframe().f_back

    # Test attribute thread_local
    assert isinstance(tracer_0.thread_local, threading.local)

    # Test attribute max_variable_length
    assert tracer_0.max_variable_length == 100

    # Test attribute normalize
    assert tracer_0.normalize == False

    # Test attribute relative_time
    assert tracer_0.relative_time == False


# Generated at 2022-06-24 17:15:55.065783
# Unit test for constructor of class Tracer
def test_Tracer():
    assert tracer_0.watch == []
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ''
    assert tracer_0.thread_info == False
    assert tracer_0.thread_info_padding == 0
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.thread_local == threading.local()
    assert tracer_0.custom_repr == ()
    assert tracer_0.last_source_path == None
    assert tracer_0.max_variable_length == 100
    assert tracer_0.normalize == False
    assert tracer_

# Generated at 2022-06-24 17:16:02.466977
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    assert tracer_0._write == sys.stdout.write
    assert type(tracer_0.watch) == list
    assert type(tracer_0.frame_to_local_reprs) == dict
    assert type(tracer_0.start_times) == dict
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ''
    assert tracer_0.thread_info == False
    assert tracer_0.thread_info_padding == 0
    assert type(tracer_0.target_codes) == set
    assert type(tracer_0.target_frames) == set
    assert type(tracer_0.thread_local) == threading._local
    assert type(tracer_0.custom_repr) == tuple
    assert tr

# Generated at 2022-06-24 17:16:05.360965
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    my_object = Tracer()
    frame = inspect.currentframe()
    event = 'call'
    arg = None
    assert my_object.trace(frame, event, arg) is not None


# Generated at 2022-06-24 17:16:56.197093
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """
        Test case for method __exit__ of class Tracer
    """
    global DISABLED
    DISABLED = False
    tracer_0 = Tracer()
    tracer_0.prefix = 'snoop'
    tracer_0.watch = set()
    tracer_0.depth = 1
    tracer_0.target_codes = set()
    tracer_0.target_frames = set()
    tracer_0.thread_info_padding = 0
    tracer_0.start_times = {}
    tracer_0.last_source_path = None
    tracer_0.max_variable_length = 100
    tracer_0.normalize = False
    sys.tracebacklimit = 1
    tracer_0.write('### test_Tracer___exit__ ###')
    DISAB

# Generated at 2022-06-24 17:16:58.301770
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pytest.raises(RuntimeError):
        test_case_0()


# Generated at 2022-06-24 17:16:59.965881
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with Tracer() as tracer_0:
        # pass # placeholder until real test code is inserted
        pass

    return

# Generated at 2022-06-24 17:17:06.180249
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    traceback.print_stack()
    file_name, source = get_path_and_source_from_frame(frame.f_back)
    print('file name: %r, source: %r' % (file_name, source))

# Unit test the function get_local_reprs

# Generated at 2022-06-24 17:17:10.861647
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0._write = get_write_function()
    tracer_0.frame_to_local_reprs = {}
    tracer_0.target_frames = set()
    tracer_0.start_times = {}
    tracer_0.thread_local = threading.local()
    tracer_0.last_source_path = None
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:17:14.207392
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    try:
        foo = "string"
        tracer_0.trace(foo, "string", "string")
    except:
        raise AssertionError()


# Generated at 2022-06-24 17:17:18.990137
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    tracer_0 = Tracer()
    frame = sys._getframe()
    file_name, source = get_path_and_source_from_frame(frame)
    assert 'test_get_path_and_source_from_frame' in ''.join(source)


# Generated at 2022-06-24 17:17:25.142724
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # from tests.samples.method_trace import method_trace_sample_0
    tracer_0 = Tracer()
    sample_0 = inspect.currentframe().f_code
    sample_1 = None
    sample_2 = 'call'
    sample_3 = (None, None, None)
    sample_4 = {'trace_limit': 0, 'trace_frame': None, 'trace_lineno': 0}
    try:
        # tracer_0.trace(sample_0, sample_1, sample_2, sample_3, sample_4)
        tracer_0.trace(sample_0, sample_2, sample_3)
    except:
        raise
    # assert_raises()


# Generated at 2022-06-24 17:17:30.877921
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    arg_0 = None
    frame_0 = None
    event_0 = 'call'
    ret_0 = tracer_0.trace(frame_0, event_0, arg_0)
    # assert_equal(ret_0, None)


# Generated at 2022-06-24 17:17:40.337822
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    test_frame_0 = inspect.currentframe().f_back
    test_frame_1 = inspect.currentframe().f_back
    test_event_0 = 'call'
    test_arg_0 = None
    # Call method trace of class Tracer on test_frame_0, test_event_0, test_arg_0, the default values are return
    assert tracer_0.trace(test_frame_0, test_event_0, test_arg_0) == None
    test_frame_1 = None
    # Call method trace of class Tracer on test_frame_0, test_event_0, test_arg_0, the default values are return
    assert tracer_0.trace(test_frame_1, test_event_0, test_arg_0) == None
