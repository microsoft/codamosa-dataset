

# Generated at 2022-06-24 17:09:38.147467
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    unavailable_source_0 = UnavailableSource()
    unavailable_source_1 = UnavailableSource()
    unavailable_source_2 = UnavailableSource()
    tracer_0 = Tracer()

# Generated at 2022-06-24 17:09:44.646822
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer, _, _ = initialize_snooper(None, (), (), 1, '', False, False, (), 100, False, False)
    find_source_test_cases = [
        [test_case_0, 'common.py', 'unavailable_source_0'],
    ]
    for find_source_test_case in find_source_test_cases:
        tracer.last_source_path = None
        find_source_test_case[0]()
        assert tracer.last_source_path == find_source_test_case[1]


# Generated at 2022-06-24 17:09:45.767131
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert Tracer().__call__(unavailable_source_0) == unavailable_source_0


# Generated at 2022-06-24 17:09:48.986020
# Unit test for function get_local_reprs
def test_get_local_reprs():
    code_0, frame_0 = get_code_and_frame(test_case_0)
    frame_0.f_locals['unavailable_source_0'] = unavailable_source_0
    result_0 = get_local_reprs(frame_0, custom_repr = (UnavailableSource,))
    assert result_0['unavailable_source_0'] == 'UnavailableSource()'


# Generated at 2022-06-24 17:09:51.151438
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = test_case_0.__code__.co_firstlineno
    source_path, source_lines = get_path_and_source_from_frame(frame)



# Generated at 2022-06-24 17:09:56.784646
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    unavailable_source_0 = UnavailableSource()
    unavailable_source_1 = UnavailableSource()
    unavailable_source_2 = UnavailableSource()
    test_frame_0 = inspect.currentframe().f_back
    test_frame_1 = inspect.currentframe().f_back
    test_frame_2 = inspect.currentframe().f_back
    test_frame_3 = inspect.currentframe().f_back
    test_frame_4 = inspect.currentframe().f_back
    test_frame_5 = inspect.currentframe().f_back
    test_frame_6 = inspect.currentframe().f_back
    test_frame_7 = inspect.currentframe().f_back
    test_frame_8 = inspect.currentframe().f_back
    test_frame_9 = inspect.currentframe().f_back
    test_

# Generated at 2022-06-24 17:10:07.913243
# Unit test for function get_write_function
def test_get_write_function():
    def write(s):
        stderr = sys.stderr
        try:
            stderr.write(s)
        except UnicodeEncodeError:
            # God damn Python 2
            stderr.write(utils.shitcode(s))
        
    write_1 = get_write_function(None, False)
    assert write_1 == write
    
    write_2 = get_write_function(sys.stderr, False)
    assert write_2 == write
    
    write_3 = get_write_function(write, False)
    assert write_3 == write

    #sys_path = sys.path.copy()
    #sys.path.append("C:\\Users\\stuart\\Desktop\\Misc\\Current\\debugpy\\debugpy")

# Generated at 2022-06-24 17:10:11.402245
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    path, source = get_path_and_source_from_frame(frame)
    assert (source[1] ==
            '    unavailable_source_0 = UnavailableSource()')
    assert (path == os.path.realpath(os.path.abspath(__file__)))



# Generated at 2022-06-24 17:10:19.757226
# Unit test for function get_write_function
def test_get_write_function():
    def test_function_0(output, message):
        write_function = get_write_function(output, False)
        write_function(message)
    
    output_string = ''
    
    def fake_write(s):
        nonlocal output_string
        output_string += s
    
    output_string = ''
    test_function_0(fake_write, 'my message')
    assert output_string == 'my message'
    
    class FakeOutputStream(object):
        def __init__(self):
            self.contents = ''
            
        def write(self, s):
            self.contents += s
            
    fake_output_stream = FakeOutputStream()
    test_function_0(fake_output_stream, 'my message')

# Generated at 2022-06-24 17:10:32.492337
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()

    # Test availability of source code
    assert 'unavailable_source_0' not in tracer.target_codes
    assert 'unavailable_source_1' in tracer.target_codes

    # Test availability of local variables
    assert tracer.frame_to_local_reprs is not None
    assert 'unavailable_source_1' in tracer.frame_to_local_reprs

    # Test depth
    depth = 1
    assert depth == tracer.depth
    assert depth == len(tracer.target_codes)
    assert depth == len(tracer.target_frames)
    assert depth == thread_global.depth
    assert depth == tracer.thread_local.depth

    # Test prefix
    assert tracer.prefix == ''

    # Test custom_repr

# Generated at 2022-06-24 17:11:01.152571
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-24 17:11:05.803343
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    unavailable_source_0 = UnavailableSource()
    unavailable_source_1 = UnavailableSource()
    unavailable_source_2 = UnavailableSource()
    unavailable_source_3 = UnavailableSource()
    unavailable_source_4 = UnavailableSource()
    unavailable_source_5 = UnavailableSource()
    unavailable_source_6 = UnavailableSource()
    unavailable_source_7 = UnavailableSource()


# Generated at 2022-06-24 17:11:09.226653
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(
        inspect.currentframe()
    ) == (
        __file__,
        test_get_path_and_source_from_frame.__code__.co_code.splitlines(True)
    )



# Generated at 2022-06-24 17:11:18.703225
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert ('<string>', ['print(1)']) == \
           get_path_and_source_from_frame(
               sys._getframe(0).f_back.f_back.f_back)
    assert ('__main__', ['print(2)']) == \
           get_path_and_source_from_frame(
               sys._getframe(0).f_back.f_back.f_back.f_back)
    assert ('/usr/lib/python2.7/abc.py', [u'xxx']) == \
           get_path_and_source_from_frame(
               sys._getframe(0).f_back.f_back.f_back.f_back.f_back)

# Generated at 2022-06-24 17:11:26.779066
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with unittest.mock.patch.object(Tracer, "write") as mock_write:
        import doctest
        doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)
        sys.stderr.write('\n')
        sys.stderr.write('Comparing assert count ...')
        sys.stderr.write('\n')
        diff = doctest.DocTestParser().get_examples(doctest.__doc__)
        sys.stderr.write('{} asserts in doctest\n'.format(len(diff)))
        sys.stderr.write('{} asserts in test code\n'.format(mock_write.call_count))

# Generated at 2022-06-24 17:11:33.371739
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():

    # Case 0
    # |- unavailable_source_0
    # |- unavailable_source_1
    # |- unavailable_source_2
    # |- unavailable_source_3
    # |- unavailable_source_4
    # |- unavailable_source_5
    # |- unavailable_source_6
    # |- unavailable_source_7
    # |- unavailable_source_8
    # |- unavailable_source_9
    with Tracer(output=sys.stdout):
        test_case_0()


# Generated at 2022-06-24 17:11:39.215762
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global DISABLED
    DISABLED = False
    captured_output = io.StringIO()
    tracer = Tracer(output=captured_output)
    function = test_case_0
    tracer(function)
    captured_output = captured_output.getvalue()
    # assert captured_output
    expected_captured_output = ''
    assert captured_output == expected_captured_output



# Generated at 2022-06-24 17:11:47.093774
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.custom_repr = tuple()
    tracer.max_variable_length = 100
    tracer.normalize = False
    tracer.relative_time = False
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.thread_info_padding = 0
    tracer.write = None
    tracer._write = None
    tracer.depth = 1
    tracer.frame_to_local_reprs = {}
    frame = None
    exc_type = None
    exc_value = None
    exc_traceback = None
    assert tracer.__exit__(exc_type, exc_value, exc_traceback) is None


# Generated at 2022-06-24 17:11:51.755626
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = test_case_0.__code__.co_consts[1].co_consts[0].co_firstlineno
    stack = inspect.stack()[1]
    assert stack.code_context is not None
    while stack.code_context is None or stack.code_context[0].strip() != 'test_case_0':
        stack = stack.tb_next.tb_frame
    assert stack.f_lineno == frame
    assert stack.f_locals == {'unavailable_source_0': UnavailableSource()}
    assert stack.f_code == test_case_0.__code__

    watch = {'module': BaseVariable(lambda frame: frame.f_globals['__name__'])}

# Generated at 2022-06-24 17:12:03.360693
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    unavailable_source_0 = UnavailableSource()
    tracer = Tracer()
    frame_0 = Frame(FrameType.Function, FunctionType.Method, unavailable_source_0,
                    0)
    frame_0.f_lasti = 0
    frame_0.f_code = None
    frame_0.f_trace = None
    frame_0.f_lineno = 0
    frame_0.f_back = None
    tracer._write = None
    tracer.watch = [CommonVariable()]
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.depth = 1
    tracer.prefix = ""
    tracer.thread_info = False
    tracer.thread_info_padding = 0
    tracer.target_codes = set()

# Generated at 2022-06-24 17:12:23.015049
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()



DISABLED = False


# Generated at 2022-06-24 17:12:33.234849
# Unit test for function get_local_reprs
def test_get_local_reprs():
    local = dict(a = 1, b = 2)

    # Should not throw an exception
    get_local_reprs(local)

    # Should not throw an exception
    get_local_reprs(local, watch=(CommonVariable('a'),))

    if pycompat.PY2:
        # Should not throw an exception
        get_local_reprs(local, custom_repr=(r'^<io\.BufferedReader.*>$', 'foo'))
    else:
        # Should not throw an exception
        get_local_reprs(local, custom_repr=(r'^<_io\.BufferedReader.*>$', 'foo'))



# Generated at 2022-06-24 17:12:39.340883
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Argument types
    arg0 = Tracer()
    arg1 = inspect.Traceback()
    arg2 = object()
    arg3 = inspect.Traceback()

    # Return type
    ret0 = None

    # Call the method
    ret0 = Tracer().__exit__(arg0, arg1, arg2, arg3)

    # Return type check
    assert isinstance(ret0, None)


# Generated at 2022-06-24 17:12:52.188674
# Unit test for constructor of class Tracer
def test_Tracer():
    assert Tracer()._write == pprint.pprint
    assert Tracer(output=sys.stdout)._write == sys.stdout.write
    try:
        sys.stdout.write = None
        assert Tracer(output=sys.stdout)._write == sys.stdout.write
    finally:
        sys.stdout.write = sys.__stdout__.write
    assert Tracer(watch='s').watch[0].path == 's'
    assert Tracer(watch='self').watch[0].path == 'self'
    assert Tracer(watch_explode='s').watch[0].path == 's'
    assert Tracer(watch_explode='self').watch[0].path == 'self'
    assert tracer_0.watch == []

# Generated at 2022-06-24 17:13:04.325989
# Unit test for function get_write_function
def test_get_write_function():
    # Test 1
    output_function = get_write_function(None, False)
    assert callable(output_function)

    # Test 2
    output_function = get_write_function(None, True)
    assert callable(output_function)

    # Test 3
    output_function = get_write_function('test_file', False)
    assert callable(output_function)

    # Test 4
    output_function = get_write_function('test_file', True)
    assert callable(output_function)

    # Test 5
    output_function = get_write_function(print, False)
    assert callable(output_function)

    # Test 6
    output_function = get_write_function(print, True)
    assert callable(output_function)

    # Test 7
    output_function

# Generated at 2022-06-24 17:13:16.530673
# Unit test for constructor of class Tracer
def test_Tracer():

    # Get the function name
    function_name = test_case_0.__name__
    print('Test for %s: ' % (function_name))

    tracer_0 = Tracer()
    assert tracer_0._write == sys.stdout.write
    assert tracer_0.watch == []
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ""
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.custom_repr == ()
    assert tracer_0.last_source_path == None

# Generated at 2022-06-24 17:13:20.011583
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        test_case_0()

    tracer_0 = Tracer()
    tracer_0.set_trace()
    f()
    tracer_0.set_trace()



# Generated at 2022-06-24 17:13:32.272915
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.watch = 'self'
    tracer.target_codes = {
        'print': print,
        'write': tracer.write,
        'test': test_Tracer_trace,
    }
    tracer.thread_info = True
    tracer.custom_repr = ((BaseException, utils.get_shortish_repr),)
    tracer.max_variable_length = 100
    tracer.normalize = False
    tracer.relative_time = False
    tracer.thread_info_padding = 0
    tracer.prefix = ''
    tracer.depth = 1
    print('Start')
    tracer.trace(None, 'call', None)
    print('End')
    tracer.trace(None, 'return', None)
    # Result:

# Generated at 2022-06-24 17:13:40.049852
# Unit test for function get_write_function
def test_get_write_function():
    # output: str | path
    output = "test_output"
    overwrite = True
    function = get_write_function(output, overwrite)
    assert isinstance(function, FileWriter.write.__class__)
    assert function.__self__.overwrite == overwrite
    
    # output: list
    output = []
    overwrite = False
    function = get_write_function(output, overwrite)
    assert callable(function)
    
    # output: tracer_0
    output = tracer_0
    overwrite = False
    function = get_write_function(output, overwrite)
    assert callable(function)
    
    # output: function
    output = test_case_0
    overwrite = False
    function = get_write_function(output, overwrite)
    assert callable(function)
    
   

# Generated at 2022-06-24 17:13:45.932960
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = test_case_0()
    frame_0 = {}
    event_0 = "event"
    arg_0 = "arg"
    test_case_0_Tracer_trace = tracer_0.trace(frame_0, event_0, arg_0)


# Generated at 2022-06-24 17:14:07.072706
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    assert isinstance(tracer_0, Tracer)

    tracer_0.__exit__(None, None, None)
    assert(True)


if __name__ == '__main__':
    tracer_0 = None

# Generated at 2022-06-24 17:14:10.616476
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper import Tracer

    def f(x):
      y = x + 1
      return y
    # tracer = Tracer()
    tracer = Tracer()
    ret = tracer.trace(f(5))
    assert ret == None


# Generated at 2022-06-24 17:14:18.812692
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    # Test invalid value of variable 'event'
    with pytest.raises(ValueError, match=r".* Invalid value for variable 'event' \('None'\)"):
        tracer_0.trace(frame=None, event=None, arg=None)
    # Test invalid value of variable 'event'
    with pytest.raises(ValueError, match=r".* Invalid value for variable 'event' \('None'\)"):
        tracer_0.trace(frame=None, event=None, arg=None)



# Generated at 2022-06-24 17:14:20.286462
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer.__enter__()


# Generated at 2022-06-24 17:14:24.471211
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    str_0 = 'Hello, World!'
    @tracer_0
    def func_0():
        print(str_0)
    func_0()
    # Test passed
    return


# Generated at 2022-06-24 17:14:30.290997
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    '''Unit test for get_path_and_source_from_frame()'''
    #__sphinx__
    file_name = 'test_tracer.py'
    module_name = 'test_tracer'
    frame = sys._getframe()
    globs = frame.f_globals
    loader = globs.get('__loader__')
    func_name = frame.f_code.co_name
    func_code = frame.f_code
    cache_key = (module_name, file_name)
    source_and_path_cache[cache_key] = None # In case this was run before and
                                            # the cache was filled
    #__sphinx__

    # __sphinx__
    globs = frame.f_globals or {}
    module_name = gl

# Generated at 2022-06-24 17:14:33.035581
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.__exit__(None, None, None)
    assert True


# Generated at 2022-06-24 17:14:45.341230
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    tracer_0 = Tracer()
    def test_case_0():
        fw = FileWriter('/tmp/test_FileWriter_write.log', True)
        fw.write(utils.shitcode('abc') + '\n')
        fw.write(utils.shitcode('def') + '\n')
        fw.write(utils.shitcode('ghi') + '\n')
    tracer_0.runfunc(test_case_0, ())
    expected_0 = utils.shitcode('abc\ndef\nghi\n')
    actual_0 = utils.read_contents('/tmp/test_FileWriter_write.log')
    assert actual_0 == expected_0
    os.remove('/tmp/test_FileWriter_write.log') 


# Generated at 2022-06-24 17:14:51.070681
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    code = utils.get_code(test_case_0.__code__)
    frame = utils.Frame(test_case_0, code, None, 'test_case_0', [], {})
    print(get_path_and_source_from_frame(frame))
    assert get_path_and_source_from_frame(frame)[0] == frame.f_code.co_filename
    #assert get_path_and_source_from_frame(frame)[1] == frame.f_code.co_filename


event_names = ('call', 'exception', 'line', 'return', 'c_call', 'c_exception',
               'c_return', 'opcode')


# Generated at 2022-06-24 17:15:00.453386
# Unit test for function get_local_reprs
def test_get_local_reprs():
    a = 5
    b = 7
    c = 10
    x = str(a)
    y = {
        'a': a,
        'b': b,
        'c': c,
        'x': x,
        'asdf': [1, 2, 3],
    }
    z = y
    z = 'asdf'
    z = 1
    result = get_local_reprs(inspect.currentframe())
    assert result['a'] == "'5'"
    assert result['b'] == "'7'"
    assert result['c'] == "'10'"
    assert result['x'] == "'5'"
    assert result['y'] == "'{'a': 5, 'b': 7, 'c': 10, 'x': '5', 'asdf': [1, 2, 3]}'"

# Generated at 2022-06-24 17:15:42.278905
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    f_args_0 = inspect.currentframe().f_back
    f_args_1 = None
    f_args_2 = None
    tracer_0.__exit__(f_args_0, f_args_1, f_args_2)


# Generated at 2022-06-24 17:15:50.441138
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # create a local variables for the test
    test_source = ['ATestSource', 'the second line', 'the third line']
    test_file = os.path.abspath(__file__)

    # create a frame
    def a_function():
        return traceback.extract_stack(limit=1)[0]
    frame = a_function()

    # check the result
    path, source = get_path_and_source_from_frame(frame)
    assert path == test_file
    assert source == test_source



# Generated at 2022-06-24 17:15:55.737667
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # test_case_0:
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe()
    event_0 = 'exception'
    arg_0 = {'hello': 0}
    func_ret_0 = tracer_0.trace(frame_0, event_0, arg_0)
    assert func_ret_0 is None


# Generated at 2022-06-24 17:16:02.946062
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Ipynb
    test_frame = sys._getframe()
    path, source = get_path_and_source_from_frame(test_frame)
    path_pattern = re.compile('^.*/(.*\.ipynb)$', re.MULTILINE)
    source_pattern = re.compile('test_get_path_and_source_from_frame', re.MULTILINE)
    assert path_pattern.search(path) and source_pattern.search(source[0])

    # py
    frame_globs = test_frame.f_globals
    frame_globs['__file__'] = 'cute_python_file.py'
    path, source = get_path_and_source_from_frame(test_frame)

# Generated at 2022-06-24 17:16:04.804511
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    with tracer_0:
        pass


# Generated at 2022-06-24 17:16:14.661113
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    def function_or_class_0():
        pass
    tracer_0.__call__(function_or_class_0)
    class function_or_class_1():
        def __init__(self):
            self.__0 = None
        def __call__(self, arg0, arg1):
            self.__0 = arg1
    tracer_0.__call__(function_or_class_1)
    class function_or_class_2():
        def __init__(self):
            self.__0 = None
        def __call__(self, arg0, arg1):
            self.__0 = arg1
    tracer_0.__call__(function_or_class_2)

# Generated at 2022-06-24 17:16:17.985417
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe()
    event_0 = 'return'
    arg_0 = None

    result_0 = tracer_0.trace(frame_0, event_0, arg_0)

    assert result_0 is None, "Testcase 0 failed."


# Generated at 2022-06-24 17:16:22.845621
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    path_and_source = get_path_and_source_from_frame(inspect.currentframe())
    assert isinstance(path_and_source, tuple)
    assert isinstance(path_and_source[0], str)
    assert isinstance(path_and_source[1][0], text_type)



# Generated at 2022-06-24 17:16:29.340957
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        a = 23
        b = 'hello'
        c = [1, 2, 3]
        d = c
        e = f
        test_case_0()
        path, source = get_path_and_source_from_frame(sys._getframe(1))
        return path, source
    file_name, source = f()
    assert (file_name, source[0]) == ('test_traceback.py',
        "def f():")
    assert (file_name, source[9]) == ('test_traceback.py',
        "test_case_0()")




# Generated at 2022-06-24 17:16:35.367622
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    exc_type_0 = None
    exc_value_0 = None
    exc_traceback_0 = None
    tracer_0.__exit__(exc_type_0, exc_value_0, exc_traceback_0)


# Generated at 2022-06-24 17:17:23.058501
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_1 = Tracer(watch='my_list', depth=3, overwrite=True, thread_info=True,
                      custom_repr=(('my_list', repr_list),), max_variable_length=200)
    tracer_2 = Tracer(watch=['my_list'], depth=3, overwrite=True,
                      custom_repr=((('my_list',), repr_list),),
                      max_variable_length=200, normalize=True, relative_time=True)
    tracer_3 = Tracer(watch_explode=['my_list'], depth=3, overwrite=True,
                      custom_repr=(('my_list', repr_list),),
                      max_variable_length=200)

# Generated at 2022-06-24 17:17:35.193114
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    DISABLED = True

    global _trace
    _trace = tracer_0.trace

    global _watch
    _watch = tracer_0.watch

    global _watch_explode
    _watch_explode = tracer_0.watch_explode

    global _frame_to_local_reprs
    _frame_to_local_reprs = tracer_0.frame_to_local_reprs

    global _target_codes
    _target_codes = tracer_0.target_codes

    global _target_frames
    _target_frames = tracer_0.target_frames

    global _thread_local
    _thread_local = tracer_0.thread_local

    global _last_source_path
    _last_source_path = tracer_0.last

# Generated at 2022-06-24 17:17:43.145992
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper import snoop
    from pysnooper.tests.test_snooper_utils import FunctionThatRaises
    from pysnooper.tests.test_snooper_utils import FunctionThatSumsTwoNumbers
    from pysnooper.tests.test_snooper_utils import FunctionThatSumsThreeNumbers
    from pysnooper.tests.test_snooper_utils import FunctionThatYieldsNumbers
    from pysnooper.tests.test_snooper_utils import FunctionThatYieldsNumbersTwice
    from pysnooper.tests.test_snooper_utils import FunctionThatHandlesGenerators
    from pysnooper.tests.test_snooper_utils import FunctionThatReturnsTwoValues

    # Test case 0
    # Create the implementation object.
    tracer_0 = Tracer

# Generated at 2022-06-24 17:17:54.047912
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with contextlib.suppress(AttributeError):
        # Calling method test_case_0 of class Tracer
        test_case_0()

    # Calling method __call__ of class Tracer
    snooper = Tracer()

    @snooper
    def foo(a, b=None):
        x = 3
        y = 4
        if b == None:
            b = x + y
        return a + b

    # Calling method foo of class function
    foo(1, 2)

    # Calling method foo of class function
    foo(1)

if __name__ == '__main__':
    if '--pdb' in sys.argv:
        try:
            import ipdb as pdb
        except ImportError:
            import pdb
        pdb.set_trace()
    import sys

# Generated at 2022-06-24 17:18:00.361412
# Unit test for function get_write_function
def test_get_write_function():
    tracer = Tracer()
    tracer.write = get_write_function(None, False)
    assert tracer.write is not None
    tracer.write = get_write_function('test.txt', False)
    assert tracer.write is not None
    assert tracer.write.overwrite is False
    tracer.write = get_write_function(utils.WritableStream(str), False)
    assert tracer.write is not None


# Generated at 2022-06-24 17:18:02.571206
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()
    print('test_get_path_and_source_from_frame passed')



# Generated at 2022-06-24 17:18:05.170319
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.depth = 2
    tracer_0.thread_local.original_trace_functions = [sys.gettrace()]
    tracer_0.start_times[inspect.currentframe().f_back] = datetime_module.datetime.now()


# Generated at 2022-06-24 17:18:09.602798
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    tracer_0.__enter__() # dummy call to __enter__, just to check if it runs without errors



# Generated at 2022-06-24 17:18:15.040440
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper import snoop
    # Test normal case
    test_case_0()
    # Test exception case:
    try:
        test_case_0()
    except AssertionError as e:
        assert True


# Generated at 2022-06-24 17:18:19.371203
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe().f_back
    assert get_path_and_source_from_frame(frame)

