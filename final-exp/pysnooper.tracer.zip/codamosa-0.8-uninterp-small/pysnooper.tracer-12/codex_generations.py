

# Generated at 2022-06-24 17:09:20.347685
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(NameError):
        unavailable_source_0 = UnavailableSource()


# Generated at 2022-06-24 17:09:29.364937
# Unit test for function get_write_function
def test_get_write_function():
    from . import pycompat
    import io
    test_string = "abcdef"
    assert get_write_function(None, False)(test_string) == None
    assert get_write_function(io.StringIO, False)(test_string).getvalue() == test_string
    assert get_write_function(io.BytesIO, False)(test_string).getvalue() == test_string.encode('utf-8')
    import sys
    assert sys.stderr.write(get_write_function(None, False)(test_string)) == len(test_string)
    assert get_write_function({'abc': 'def'}, False)(test_string) == None
    
    file_name = "pdbpp_test_file_get_write_function.txt"

# Generated at 2022-06-24 17:09:46.272130
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test creating a Tracer object
    test_Tracer = Tracer()

    # Test attribute start_times of class Tracer
    test_start_times_0 = test_Tracer.start_times
    if test_start_times_0 != {}:
        raise test_Tracer_trace.TestFailure(
            "Expected: {}\nGot: {}\nAttribute start_times of "
            "class Tracer is set incorrectly".format(
                {}, test_start_times_0))

    # Test attribute target_codes of class Tracer
    test_target_codes_0 = test_Tracer.target_codes

# Generated at 2022-06-24 17:09:48.471537
# Unit test for constructor of class Tracer
def test_Tracer():
    global unavailable_source_0
    unavailable_source_0.__file__ = None
    unavailable_source_0.__code__.co_filename = None
    assert unavailable_source_0.__file__ is None
    assert unavailable_source_0.__code__.co_filename is None


# Generated at 2022-06-24 17:09:55.479037
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        import IPython
        print(IPython.__version__)
    except ImportError:
        pass
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert os.path.basename(__file__) == os.path.basename(path)
    assert source[0].endswith("test_case_0()")
    frame = frame.f_back
    path, source = get_path_and_source_from_frame(frame)
    assert os.path.basename(__file__) == os.path.basename(path)
    assert source[0].endswith("test_case_0()")
    assert source[1].endswith("test_get_path_and_source_from_frame()")

# Generated at 2022-06-24 17:10:07.292214
# Unit test for constructor of class Tracer
def test_Tracer():
    global unavailable_source_0
    try:
        unavailable_source_0
    except NameError:
        unavailable_source_0 = UnavailableSource()

    output_0 = StringIO()
    global watch_0
    watch_0 = ('x', unavailable_source_0)
    global watch_explode_0
    watch_explode_0 = (unavailable_source_0,)
    global custom_repr_0
    custom_repr_0 = (unavailable_source_0, unavailable_source_0)
    global prefix_0
    prefix_0 = 'Hello'
    # depth=1
    global depth_0
    depth_0 = 1

    global result_0

# Generated at 2022-06-24 17:10:20.539367
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert pycompat.PY2  # This test case is only supported on Python 2.7
    import cStringIO as StringIO

    output = StringIO.StringIO()
    snoop = Tracer(output, watch=('a',))

    def func():
        a = 1
        b = 2
        return a + b

    assert not snoop.watch
    snooped = snoop(func)

    output.truncate(0)
    assert snooped() == 3
    assert output.getvalue() == """    Source path:... {0}
        Starting var:.. a = 1
        17    a = 1
        18    b = 2
        19    return a + b
    Elapsed time: 0:00:00.000001
""".format(func.__code__.co_filename)

    output.tr

# Generated at 2022-06-24 17:10:33.148335
# Unit test for method __call__ of class Tracer

# Generated at 2022-06-24 17:10:40.457595
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    try:
        _temp_sys_trace_func_bk = sys.gettrace()
    except:
        pass
    try:
        sys_trace_func = Tracer().trace
        sys.settrace(sys_trace_func)
        test_case_0()
    finally:
        try:
            sys.settrace(_temp_sys_trace_func_bk)
        except:
            pass
        pass

# Generated at 2022-06-24 17:10:42.727622
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Should succeed
    with Tracer():
        unavailable_source_0 = UnavailableSource()


# Generated at 2022-06-24 17:11:13.704705
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    filename_0, source_0 = get_path_and_source_from_frame(
        sys._getframe(1))
    assert filename_0 == __file__
    assert source_0[0].strip() == 'def test_case_0():'
    assert source_0[1].strip() == '    unavailable_source_0 = UnavailableSource()'
    assert source_0[2].strip() == ''
    assert source_0[3].strip() == ''
    assert source_0[4].strip() == ''
    assert source_0[5].strip() == ''
    assert source_0[6].strip() == '# Unit test for function get_path_and_source_from_frame'
    assert source_0[7].strip() == 'def test_get_path_and_source_from_frame():'
   

# Generated at 2022-06-24 17:11:21.142788
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    unavailable_source_0 = UnavailableSource()
    line_no = 'x'
    test_class_0 = Tracer()
    assert type(test_class_0) == Tracer
    assert test_class_0._write == sys.stdout.write
    assert test_class_0.watch == ()
    assert test_class_0.frame_to_local_reprs == {}
    assert test_class_0.start_times == {}
    assert test_class_0.depth == 1
    assert test_class_0.prefix == ''
    assert test_class_0.thread_info == False
    assert test_class_0.thread_info_padding == 0
    assert test_class_0.target_codes == {test_case_0.__code__}

# Generated at 2022-06-24 17:11:25.570645
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(sys._getframe())[1] == ['def test_case_0():']
    assert get_path_and_source_from_frame(sys._getframe())[0].endswith('debugger.py')



# Generated at 2022-06-24 17:11:30.455159
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    unavailable_source_0 = UnavailableSource()
    unknown_type_0 = UnknownType()
    not_implemented_0 = NotImplemented()

    # Call test_case_0
    test_case_0()

    # Call test_case_0
    test_case_0()

    # Call test_case_0
    test_case_0()



# Generated at 2022-06-24 17:11:42.421276
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    s = Tracer()
    frame = inspect.currentframe()
    arg = None
    frame.f_lineno = 8
    frame.f_code.co_code[frame.f_lasti] = dis.opmap['RETURN_VALUE']
    frame.f_code.co_filename = 'test_case_0'
    frame.f_code.co_code = unavailable_source_0
    frame.f_code.co_code = dis.Bytecode(frame.f_code)
    frame.f_code.co_names = tuple(frame.f_code.co_code.co_names)
    frame.f_code.co_consts = tuple(frame.f_code.co_code.co_consts)

# Generated at 2022-06-24 17:11:49.208654
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    try:
        frame = frame.f_back.f_back
        result = get_path_and_source_from_frame(frame)
        assert result[1] is unavailable_source_0
        assert result[0] == inspect.getfile(test_case_0)
    finally:
        del frame


# Generated at 2022-06-24 17:11:59.655077
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Unit test should raise an AssertionError if method trace of class
    # Tracer makes an invalid call to get_path_and_source_from_frame
    # AssertionError raised to indicate unit test failure
    with pytest.raises(AssertionError) as excinfo:
        unavailable_source_0 = UnavailableSource()
        test_case_0()

# Generated at 2022-06-24 17:12:04.709407
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()

    if (inspect.currentframe().f_code == test_case_0.__code__
            and not tracer.frame_to_local_reprs):
        return True
    else:
        return False


# Generated at 2022-06-24 17:12:13.307753
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Testing the case of pycompat.timedelta_format returning the string :
    tracing_instance_0 = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=True)
    # Calling __exit__
    exc_type_0 = None
    exc_value_0 = None
    exc_traceback_0 = None
    tracing_instance_0.__exit__(exc_type_0, exc_value_0, exc_traceback_0)

    # Testing the case of pycompat.timedelta_format returning the string :

# Generated at 2022-06-24 17:12:18.556366
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = None
    try:
        raise Exception()
    except Exception:
        frame = sys.exc_info()[2].tb_frame.f_back

    path, source = get_path_and_source_from_frame(frame)
    assert source.__class__ is unavailable_source_0.__class__



# Generated at 2022-06-24 17:12:51.916426
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        source_and_path = get_path_and_source_from_frame(
            inspect.currentframe())
        assert source_and_path == (os.path.normpath(__file__),
                                   inspect.getsourcelines(test_case_0)[0])
    finally:
        # remove the cached data so we can re-test later
        key = (__name__, __file__)
        if key in source_and_path_cache:
            del source_and_path_cache[key]


# Generated at 2022-06-24 17:13:01.566734
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Now we test the function.
    frame = test_case_0.__code__.co_firstlineno - 1
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == __file__
    assert isinstance(source, list)
    assert source.index('def test_case_0():') == 0
    assert source[0:2] == ['def test_case_0():', '    unavailable_source_0 = UnavailableSource()']



# Generated at 2022-06-24 17:13:04.877214
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Uncomment to run.
    # tracer = Tracer()
    # tracer.__exit__(None, None, None)
    raise NotImplementedError


# Generated at 2022-06-24 17:13:12.410404
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    path, source = get_path_and_source_from_frame(sys._getframe(0))
    assert path == __file__
    if 'test_case_0' in source:
        test_line = 'test_case_0()'
        assert source[source.index(test_line) + 1] == unavailable_source_0
    else:
        assert True



# Generated at 2022-06-24 17:13:19.656713
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():

    import time

    with Tracer():
        time.sleep(0.01)
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_

# Generated at 2022-06-24 17:13:27.382587
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()
    assert tracer.watch ==[]
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local == threading.local()
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False
    assert tracer.relative_time == False


# Generated at 2022-06-24 17:13:30.208991
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # 1. default argument values
    # 2. invoking __exit__
    # 3. normal flow
    # 4. error flow
    # 5. argument types
    # 6. argument ranges
    pass


# Generated at 2022-06-24 17:13:40.686388
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local == threading.local()
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False
    assert tracer.relative_time == False


# Generated at 2022-06-24 17:13:52.544960
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    unavailable_source_0 = UnavailableSource()
    tracer = Tracer()
    assert not tracer.target_codes
    assert not tracer.target_frames
    assert tracer._write(unavailable_source_0) == None
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert not tracer.thread_info
    assert tracer.thread_info_padding == 0
    assert tracer.custom_repr == ()
    assert tracer.last_source_path == None
    assert tracer.max_variable_length == 100
    assert not tracer.normalize
    assert not tracer.relative_time

# Generated at 2022-06-24 17:14:05.990343
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    if DISABLED:
        return

# Generated at 2022-06-24 17:14:45.203583
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """
    Unit test for method trace of class Tracer

    """

    # tests that when an exception is returned from a function, 'exception'
    # event is triggered
    def foo():
        pass
    # tests that when a function returns a return value, 'return' event
    # is triggered
    def foo_with_return():
        return 0
    # tests that when the function is just a single line, 'line' event
    # is triggered
    def foo_single_line():
        pass
    def foo_with_args(x, y):
        return x - y
    def foo_with_default_args(x, y=1):
        return x - y
    def foo_with_unpacking_args(*args):
        return sum(args)

# Generated at 2022-06-24 17:14:46.691898
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    with tracer_0:
        pass


# Generated at 2022-06-24 17:14:58.704580
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    rt = pycompat.Runtime()
    tracer = Tracer()
    tracer_0 = Tracer()
    rt.add_tracer_call(tracer_0)
    tracer_1 = Tracer()
    rt.add_tracer_call(tracer_1)
    tracer_2 = Tracer()
    rt.add_tracer_call(tracer_2)
    tracer_3 = Tracer()
    rt.add_tracer_call(tracer_3)
    tracer_4 = Tracer()
    rt.add_tracer_call(tracer_4)
    tracer_5 = Tracer()
    rt.add_tracer_call(tracer_5)
    tracer_6 = Tracer()
    rt.add_tracer

# Generated at 2022-06-24 17:14:59.699249
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    test_case_0()


# Generated at 2022-06-24 17:15:02.963507
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Instantiate an object of class Tracer
    tracer_0 = Tracer()

    # Call method __enter__ of the object
    result___enter___0 = tracer_0.__enter__()


# Generated at 2022-06-24 17:15:11.883235
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    s = 'def outer_function(a):\n'
    s += '    @pysnooper.snoop()\n'
    s += '    def inner_function(b, c=None):\n'
    s += '        return a + b + (c if c else 0)\n'
    s += '    return inner_function(2)\n'
    s += 'r = outer_function(1)'
    with utils.capture_stdout() as _stdout:
        exec(s)

# Generated at 2022-06-24 17:15:19.493039
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global tracer_0
    global tracer_second_0

    tracer_0 = Tracer()

    @tracer_0
    def foo_0():
        pass

    @tracer_0
    def foo_second_0():
        pass

    tracer_second_0 = Tracer()

    @tracer_second_0
    def foo_second_1():
        pass

    @tracer_second_0
    def foo_second_2():
        pass


# Generated at 2022-06-24 17:15:23.296518
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pysnooper
    tracer_0 = pysnooper.Tracer()
    with tracer_0:
        a = 0
    # FIXME: Add more tests
    pass


# Generated at 2022-06-24 17:15:26.273445
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writeFunction = FileWriter('../test_FileWriter_write',True)
    writeFunction.write('Hello World!')


# Generated at 2022-06-24 17:15:29.043978
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    assert not tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:15:50.484261
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def my_function():
        tracer_0.trace_local()
        test_case_0()

    path_and_source_from_frame = tracer_0.get_path_and_source_from_frame__internal
    my_function()



# Generated at 2022-06-24 17:15:53.960823
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back
    event_0 = 'call'
    arg_0 = None
    return tracer_0.trace(frame_0, event_0, arg_0)


# Generated at 2022-06-24 17:15:56.208476
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    with pytest.raises(NotImplementedError):
        tracer_0.__exit__(True, True, True)


# Generated at 2022-06-24 17:16:07.589363
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from unittest.mock import patch

    frame = inspect.currentframe().f_back

    with patch('pysnooper.tracer.CommonVariable.__init__',
               return_value=None) as _mock_CommonVariable___init__:
        with patch('pysnooper.tracer.Exploding.__init__',
                   return_value=None) as _mock_Exploding___init__:
            with patch('pysnooper.tracer.get_local_reprs',
                       return_value={}):
                with patch('pysnooper.tracer.get_path_and_source_from_frame',
                           return_value=None):
                    with Tracer():
                        pass


# Generated at 2022-06-24 17:16:10.280020
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_1 = Tracer()
    with tracer_1 as tracer_0:
        print(tracer_0)


# Generated at 2022-06-24 17:16:11.990365
# Unit test for constructor of class Tracer
def test_Tracer():
    assert hasattr(Tracer(), 'write'), 'Test failed!'


# Generated at 2022-06-24 17:16:19.288495
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    source = pycompat.get_source_from_frame(inspect.currentframe())
    source = ''.join(source)
    source = source.encode('utf-8')
    function_0 = inspect.currentframe()
    function_0 = function_0.f_back
    function_0 = function_0.f_globals['test_Tracer_trace']
    frame_0 = inspect.currentframe()
    event_0 = 'line'
    arg_0 = None
    frame_1 = tracer_0.trace(frame_0, event_0, arg_0)
    line_no_0 = frame_1.f_lineno
    assert line_no_0 == frame_0.f_lineno + 1
    frame_1 = frame_1.f

# Generated at 2022-06-24 17:16:21.585113
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_1 = Tracer()
    tracer_1.trace(frame, 'call', arg)
    tracer_1.trace(frame, 'line', arg)
    tracer_1.trace(frame, 'return', arg)


# Generated at 2022-06-24 17:16:31.039954
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer0 = Tracer()
    try:
        tracer0.__enter__()
        tracer0.trace(None, None, None)
    except:
        pass
    finally:
        tracer0.__exit__(None, None, None)
    tracer1 = Tracer()
    try:
        tracer1.__enter__()
        tracer1.trace(None, None, None)
    except:
        pass
    finally:
        tracer1.__exit__(None, None, None)
    tracer2 = Tracer()
    try:
        tracer2.__enter__()
        tracer2.trace(None, None, None)
    except:
        pass
    finally:
        tracer2.__exit__(None, None, None)


# Generated at 2022-06-24 17:16:40.270443
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    print(u'Testing method Tracer.__exit__')

# Generated at 2022-06-24 17:17:25.842409
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    with pytest.raises(NotImplementedError) as excinfo:
        tracer_0.trace(frame=None, event=None, arg=None)
    assert str(excinfo.value) == 'Trace function can only be used inside with statement'
    with tracer_0:
        frame_0 = inspect.currentframe().f_back
        tracer_0.set_thread_info_padding(None)
        event_0 = 'call'
        with pytest.raises(ValueError) as excinfo:
            tracer_0.trace(frame=frame_0, event=event_0, arg=None)
        assert str(excinfo.value) == 'Not possible to trace this event'
        tracer_0.depth = 1
        frame_0.f_code

# Generated at 2022-06-24 17:17:37.258465
# Unit test for function get_write_function
def test_get_write_function():
    if os.path.exists("tracer_test.txt"):
        os.remove("tracer_test.txt")
    with open("tracer_test.txt", "w") as f:
        get_write_function(f, False)("test_0")
        assert os.path.getsize("tracer_test.txt") == len("test_0")

    with open("tracer_test.txt", "w") as f:
        get_write_function(f, True)("test_1")
        assert os.path.getsize("tracer_test.txt") == len("test_1")

    get_write_function("tracer_test.txt", False)("test_2")
    assert os.path.getsize("tracer_test.txt") == len("test_2")

    get_write

# Generated at 2022-06-24 17:17:44.354452
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import re

    import pytest
    from pytest import raises
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_local_reprs

    from pysnooper import snoop


    # Arguments
    frame = test_case_0.__code__
    event = 'call'
    arg = None

    # Return type annotation
    return_type = None

    # raising exceptions
    if frame is None or event is None:
        with raises(ValueError):
            Tracer.trace(frame, event, arg)

    if isinstance(frame, int) or isinstance(event, int) or isinstance(arg, int):
        with raises(TypeError):
            Tracer.trace(frame, event, arg)

    # Establish a known state

# Generated at 2022-06-24 17:17:45.130065
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_1 = Tracer()


# Generated at 2022-06-24 17:17:47.194837
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writer = FileWriter('test_FileWriter', True)
    writer.write('foo\n')



# Generated at 2022-06-24 17:17:50.090461
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:17:52.173847
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as tracer_0:
        pass

# Generated at 2022-06-24 17:18:01.993446
# Unit test for method trace of class Tracer

# Generated at 2022-06-24 17:18:12.420245
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe()
    frame_0 = frame_0.f_back
    event_0 = 'call'
    arg_0 = None
    tracer_0.trace(frame_0, event_0, arg_0)
    frame_0 = frame_0.f_back
    event_0 = 'return'
    arg_0 = None
    tracer_0.trace(frame_0, event_0, arg_0)
    frame_0 = frame_0.f_back
    event_0 = 'exception'
    arg_0 = (None, None, None)
    tracer_0.trace(frame_0, event_0, arg_0)

# Generated at 2022-06-24 17:18:16.439610
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = utils.find_parent_frame(1)
    path, source = get_path_and_source_from_frame(frame)
    print(path, source)

