

# Generated at 2022-06-24 17:09:19.969320
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert DISABLED == False
    test_case_0()


# Generated at 2022-06-24 17:09:23.460081
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Instantiating a Tracer object
    t0 = Tracer()
    # Calling method __exit__ of t0 with correct parameter
    t0.__exit__(None, None, None)


# Generated at 2022-06-24 17:09:25.340916
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Expects unavailable_source_0 to be collected
    assert test_case_0.__code__.co_filename != unavailable_source_0.__file__


# Generated at 2022-06-24 17:09:36.918890
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Assignment statements
    program = '''
i = 3
s = 'Hello'
l = [1, 2, 3]
d = {4: 5, 6: 7}
'''
    expected_output = '''
Source path:... {filepath}
 000001 000 i = 3 = 3
 000002 000 s = 'Hello' = 'Hello'
 000003 000 l = [1, 2, 3] = [1, 2, 3]
 000004 000 d = {4: 5, 6: 7} = {4: 5, 6: 7}
'''.format(
        filepath=utils.make_temp_file(program),
    )
    output = utils.run_pysnooper(program)
    assert output.strip() == expected_output.strip()


# Generated at 2022-06-24 17:09:46.094447
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    '''
    This function is not intended to be human readable. It is parsed by
    test_Tracer_trace_source.py
    '''
    frame_0 = frame(
        event='call',
        line=5,
        source_line='unavailable_source_0 = UnavailableSource()',
        depth=0,
        scope={
            'unavailable_source_0': 'UnavailableSource()',
        },
    )
    frame_1 = frame(
        event='return',
        line=5,
        source_line='unavailable_source_0 = UnavailableSource()',
        depth=0,
        scope={
            'unavailable_source_0': '<pysnooper.tests.unreachables.UnavailableSource object at 0x000001F91571A160>',
        },
    )


# Generated at 2022-06-24 17:09:47.577153
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    '''
    >>> test_case_0()
    Exception:..... 'UnavailableSource' object has no attribute '__name__'
    '''


# Generated at 2022-06-24 17:09:55.042377
# Unit test for constructor of class Tracer
def test_Tracer():
    # test init function
    snoop = Tracer()
    assert snoop.watch == []
    assert snoop.frame_to_local_reprs == {}
    assert snoop.start_times == {}
    assert snoop.depth == 1
    assert snoop.prefix == ''
    assert snoop.thread_info == False
    assert snoop.thread_info_padding == 0
    assert snoop.target_codes == set()
    assert snoop.target_frames == set()
    assert snoop.thread_local == threading.local()
    assert snoop.custom_repr == ()
    assert snoop.last_source_path == None
    assert snoop.max_variable_length == 100
    assert snoop.normalize == False
    assert snoop.relative_time == False

    # test init function
    sn

# Generated at 2022-06-24 17:09:59.788576
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Test case Tracer___exit___TC_0
    unavailable_source_0 = UnavailableSource()
    with Tracer():
        with pytest.raises(ZeroDivisionError):
            unavailable_source_0()
    assert True


# Generated at 2022-06-24 17:10:02.588438
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(RuntimeError):
        with Tracer(watch='unavailable_source_0'):
            test_case_0()

# Generated at 2022-06-24 17:10:11.481944
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    unavailable_source_0 = UnavailableSource()
    unavailable_source_1 = UnavailableSource()
    unavailable_source_2 = UnavailableSource()
    unavailable_source_3 = UnavailableSource()
    unavailable_source_4 = UnavailableSource()
    unavailable_source_5 = UnavailableSource()
    unavailable_source_6 = UnavailableSource()
    unavailable_source_7 = UnavailableSource()
    unavailable_source_8 = UnavailableSource()
    unavailable_source_9 = UnavailableSource()
    unavailable_source_10 = UnavailableSource()
    unavailable_source_11 = UnavailableSource()
    unavailable_source_12 = UnavailableSource()
    unavailable_source_13 = UnavailableSource()
    unavailable_source_14 = UnavailableSource()
    unavailable_source_15 = UnavailableSource()

# Generated at 2022-06-24 17:10:39.245705
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print('Test #0')
    print('Executing test case 0')
    tracer_0 = Tracer()
    list_0 = []
    int_0 = 0
    list_0.append(int_0)
    print('Test #0')
    print('tracer_0 = ', tracer_0)
    print('list_0 = ', list_0)
    print('int_0 = ', int_0)
    print('# verify {} #', tracer_0.trace())


# Generated at 2022-06-24 17:10:49.351977
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Create a tracer for pysnooper to use
    tracer_0 = Tracer()
    # Create a frame for the tracer to use
    frame_0 = inspect.currentframe().f_back.f_back.f_back
    # Create an event for the tracer to use
    event_0 = 'call'
    # Create an argument for the tracer to use
    arg_0 = None
    # Invoke the method we're testing
    tracer_0.trace(frame_0, event_0, arg_0)
    # Check that the trace function was actually invoked
    # We don't have a way to check this at the moment
    # assert(False)


# Generated at 2022-06-24 17:10:53.697837
# Unit test for constructor of class Tracer
def test_Tracer():
    test_case_0()
    test_Tracer.counter += 1

test_Tracer.counter = 0


# Function to generate test report

# Generated at 2022-06-24 17:11:02.559254
# Unit test for function get_write_function
def test_get_write_function():
    # Check the type returned with None input
    assert callable(get_write_function(None, True))
    assert callable(get_write_function(None, False))

    # Check the type returned with a path input
    assert callable(get_write_function('test_filename.log', True))
    assert callable(get_write_function('test_filename.log', False))

    # Check the type returned with a callable input
    assert callable(get_write_function(test_case_0, True))
    assert callable(get_write_function(test_case_0, False))



# Generated at 2022-06-24 17:11:13.370728
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global tracer_0
    global list_0
    global int_0
    try:
        assert tracer_0 == None
    except AssertionError:
        raise AssertionError()
    try:
        assert list_0 == []
    except AssertionError:
        raise AssertionError()
    try:
        assert int_0 == 0
    except AssertionError:
        raise AssertionError()
    tracer_0 = Tracer()
    list_0 = []
    int_0 = 0
    try:
        assert tracer_0 is not None
    except AssertionError:
        raise AssertionError()
    try:
        assert list_0 == []
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-24 17:11:20.848355
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    b_0 = True if test_case_0.list_0 == [] else False
    list_0 = [test_case_0.list_0.append(element_var_0) for element_var_0 in range(10)]
    list_1 = [test_case_0.list_0.append(element_var_1) for element_var_1 in range(len(test_case_0.list_0))]
    exception_0 = None
    try:
        for element_var_0 in test_case_0.tracer_0.target_codes:
            print(element_var_0)
    except Exception as exception_1:
        exception_0 = exception_1

    exception_0 = None

# Generated at 2022-06-24 17:11:24.720518
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """
    __exit__(a0, a1, a2)
    """
    global tracer_0
    test_case_0()
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:11:32.321707
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writer = FileWriter('tracer_temp_output.txt', True)
    writer.write('this is first line\n')
    writer.write('this is second line')
    writer.close()
    file = open('tracer_temp_output.txt', 'r')
    s = file.readline()
    assert(s == 'this is first line\n')
    s = file.readline()
    assert(s == 'this is second line')
    file.close()
    os.remove('tracer_temp_output.txt')


# Generated at 2022-06-24 17:11:34.554152
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    list_0 = []
    int_0 = 0


# Generated at 2022-06-24 17:11:36.334260
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Create Tracer instance tracer_0.
    tracer_0 = Tracer()


# Generated at 2022-06-24 17:12:04.548394
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        tracer_0.start()
        tracer_0.stop()
    f()
    frame = sys._getframe(2)
    file_name, source = get_path_and_source_from_frame(frame)
    assert re.search(r'retrace.tests.test_tracer.test_case_0', file_name)
    assert re.search(r'tracer_0', source[0])
    assert re.search(r'Tracer', source[1])
    assert re.search(r'trace', source[2])



# Generated at 2022-06-24 17:12:13.230101
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back
    threading_local_1 = threading.local()
    threading_local_1.__dict__['original_trace_functions'] = []
    threading_local_1.original_trace_functions.append(sys.gettrace())
    tracer_0.start_times[frame_0] = datetime_module.datetime.now()
    sys.settrace(tracer_0.trace)
    # Invoke method trace of class Tracer
    tracer_0.trace(frame_0, 'call', None)
    # Invoke method trace of class Tracer
    tracer_0.trace(frame_0, 'call', None)
    # Invoke method trace of class Tracer
    tracer_0.trace

# Generated at 2022-06-24 17:12:23.150812
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    with open('traceback_test_file.py', 'w') as f:
        f.write('def test_case_0():\n'
                '    tracer_0 = Tracer()\n')

    import traceback_test_file

    try:
        traceback_test_file.test_case_0()
    except Exception:
        exc_type, exc_value, exc_tb = sys.exc_info()
        frame = exc_tb.tb_frame
        #print(frame.f_code.co_filename)
        file_name, source = get_path_and_source_from_frame(frame)
        while source is UnavailableSource:
            frame = frame.f_back
            file_name, source = get_path_and_source_from_frame(frame)
        #print(

# Generated at 2022-06-24 17:12:30.541946
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # test_0
    tracer_0 = Tracer()
    output_0 = sys.stdout
    overwrite_0 = True
    watch_0 = ()
    watch_explode_0 = ()
    depth_0 = 1
    prefix_0 = ''
    thread_info_0 = False
    custom_repr_0 = ()
    max_variable_length_0 = 100
    normalize_0 = False
    relative_time_0 = False
    write_0 = get_write_function(output_0, overwrite_0)
    target_codes_0 = set()
    target_frames_0 = set()
    start_times_0 = {}
    thread_local_0 = threading.local()
    last_source_path_0 = None
    frame_0 = inspect.currentframe().f_back
   

# Generated at 2022-06-24 17:12:33.155707
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    func_0 = lambda : None
    tracer_0.__call__(func_0)


# Generated at 2022-06-24 17:12:36.071339
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(AssertionError):
        test_case_0()


# Generated at 2022-06-24 17:12:49.060867
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    assert tracer_0.watch == []
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ''
    assert tracer_0.thread_info == False
    assert tracer_0.thread_info_padding == 0
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.custom_repr == ()
    assert tracer_0.last_source_path == None
    assert tracer_0.max_variable_length == 100
    assert tracer_0.normalize == False
    assert tracer_0.relative_time == False

# Generated at 2022-06-24 17:12:53.691699
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # If a stack of original trace functions is not empty, the first trace
    # function in it is assigned to sys.settrace
    with tracer_0:
        assert sys.gettrace() == tracer_0.trace

    # If the stack of original trace functions is empty, sys.settrace is set to
    # None
    with tracer_0:
        sys.settrace(None)
    assert sys.gettrace() == None


# Generated at 2022-06-24 17:13:04.421346
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = CustomRepr()
        b = CustomRepr()
        c = 3
        d = {1: 2, 3: 4, 5: 6}
        tracer_0 = Tracer()
        return locals()

    L = f()

    assert get_local_reprs(f.__code__.co_firstlineno,
                           watch=(CommonVariable('a'),),
                           custom_repr={CustomRepr: lambda x: 'Custom'}) \
                           == {'a': 'Custom', 'b': '<__main__.CustomRepr instance at 0x...>', 'c': '3', 'd': '{...}'}

# Generated at 2022-06-24 17:13:16.626102
# Unit test for function get_write_function
def test_get_write_function():
    result_0 = get_write_function(None, False)
    assert result_0(None) == sys.stderr.write(None)
    result_1 = get_write_function('test_file1.txt', True)
    assert result_1(None) in sys.stdout.write(None)
    result_2 = get_write_function(sys.stdout, False)
    assert result_2(None) == sys.stdout.write(None)
    result_3 = get_write_function(test_case_0, False)
    assert result_3(None) in sys.stdout.write(None)

# Generated at 2022-06-24 17:13:39.794189
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with tracer_0:
        assert True # TODO: implement your test here


# Generated at 2022-06-24 17:13:45.932962
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_1 = Tracer()

    function_or_class_2 = lambda x:x
    return_3 = tracer_1.__call__(function_or_class_2)

    assert return_3.__name__ == function_or_class_2.__name__



# Generated at 2022-06-24 17:13:50.233103
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_1 = Tracer()
    try:
        1 / 0
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        frame = inspect.trace()[0]
        tracer_1.trace(frame, 'exception', (exc_type, exc_value, exc_traceback))


# Generated at 2022-06-24 17:14:03.741736
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    tracer_0 = Tracer()
    tracer_0.source_context.output = pycompat.PathLike(
        r'D:\Ram\python_work\dirty_inspector\dirty-inspector\dirty_inspector/test_case_0.log')
    tracer_0.source_context.overwrite = False

# Generated at 2022-06-24 17:14:06.344563
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    function_or_class = lambda : None
    value = tracer_0.__enter__(function_or_class)


# Generated at 2022-06-24 17:14:13.374306
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import shutil
    import tempfile
    import sys

    def test_func():
        a = 3
        return a
    frame = inspect.currentframe().f_back
    filename = tempfile.mkstemp()[1]
    sys.path.append(tempfile.gettempdir())
    with open(filename, 'w') as f:
        f.write('def test_func(): \n')
        f.write('    a = 3\n')
        f.write('    return a\n')
    source_code = get_path_and_source_from_frame(frame)[1]
    assert source_code[2] == 'return a'
    assert source_code[1] == '    a = 3'
    assert source_code[0] == 'def test_func(): '

# Generated at 2022-06-24 17:14:15.628566
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_1 = Tracer(depth=1)
    tracer_2 = Tracer(depth=2)


# Generated at 2022-06-24 17:14:24.396935
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .utils import get_shortish_repr
    expected = {
        'a': '1',
        'b': '2',
    }
    locals_dict = {
        'a': 1,
        'b': 2,
    }
    assert get_local_reprs(locals_dict) == expected
    locals_dict.update({
        'c': 3,
        'd': 4,
    })
    assert get_local_reprs(locals_dict) == expected
    assert get_local_reprs(locals_dict, watch=[('c', 3)]) == {
        'a': 1,
        'b': 2,
        'c': '3',
    }

# Generated at 2022-06-24 17:14:36.074561
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def example_function():
        # Line 1
        # Line 2
        return

    example_function()


# Generated at 2022-06-24 17:14:39.453642
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """
    Test __exit__ of class Tracer
    """
    args = []
    arg_types = [object, object, object]
    tracer_0 = Tracer()
    with pytest.raises(TypeError):
        tracer_0.__exit__(*args)


# Generated at 2022-06-24 17:15:04.227175
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    test_case_0()


# Generated at 2022-06-24 17:15:05.481027
# Unit test for function get_local_reprs
def test_get_local_reprs():
    tracer_0 = Tracer()


# Generated at 2022-06-24 17:15:08.812651
# Unit test for constructor of class Tracer
def test_Tracer():
    test_case_0()
    return True

# end of unit test


# Generated at 2022-06-24 17:15:18.968450
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Calling __exit__ without prior __enter__ should be a no-op:
    tracer = Tracer()
    tracer.__exit__(None, None, None)

    # Likewise on a Tracer that has been disabled:
    global DISABLED
    DISABLED = True
    tracer.__exit__(None, None, None)
    DISABLED = False

    # The trace function should still return None even after exiting:
    with tracer:
        assert tracer.trace(None, None, None) is None
    assert tracer.trace(None, None, None) is None


# Generated at 2022-06-24 17:15:21.033958
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    try:
        tracer_0.__exit__()
    except Exception as e:
        print("Exception thrown: " + str(e))
        raise e


# Generated at 2022-06-24 17:15:31.999239
# Unit test for method trace of class Tracer

# Generated at 2022-06-24 17:15:34.223807
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    case_Tracer___call__(test_case_0)


# Generated at 2022-06-24 17:15:41.100818
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    def function_0(): pass

    # Call method __call__
    tracer_0(function_0)



# Generated at 2022-06-24 17:15:48.756482
# Unit test for constructor of class Tracer
def test_Tracer():
    # common
    test_case_0()
    # 
    # tracer = Tracer(custom_repr=((type1, custom_repr_func1),(condition2, custom_repr_func2), ...), \
    #     max_variable_length=100, normalize=False, relative_time=False):
    # if normalize and thread_info:
    #     raise NotImplementedError("normalize is not supported with " "thread_info")



# Generated at 2022-06-24 17:15:56.095184
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    # expected_local_reprs_0 = tracer_0.frame_to_local_reprs
    # expected_local_reprs_0 = {}
    test_frame_0 = inspect.currentframe()
    test_frame_0.f_trace = tracer_0.trace
    test_frame_0.f_lineno = 1
    test_frame_0.f_locals = {}
    test_exc_type_0 = None
    test_exc_value_0 = None
    test_exc_traceback_0 = None
    tracer_0.__exit__(test_exc_type_0, test_exc_value_0, test_exc_traceback_0)
    assert tracer_0.frame_to_local_reprs == {}


# Generated at 2022-06-24 17:16:49.465089
# Unit test for function get_local_reprs
def test_get_local_reprs():
    if PY2:
        from .variables import CuteVariable
    else:
        from .variables import CuteVariable3
    def function():
        x = 3
        y = 'abc'
        z = set()
        local_variable_0 = CuteVariable(max_length=5)
        tracer_0 = Tracer(watch=(local_variable_0,))
        tracer_0.start()
        a = 1
        tracer_0.stop()
    local_variable_0 = CuteVariable(max_length=5)
    tracer_0 = Tracer(watch=(local_variable_0,))
    tracer_0.start()
    function()
    tracer_0.stop()

# Generated at 2022-06-24 17:17:00.475322
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    # frame = frame of the caller method
    frame = inspect.currentframe().f_back
    # event = name of the event
    event = 'foo'
    # arg = argument passed by the event
    arg = 'bar'
    rel_time = datetime_module.datetime.now()
    # set the current trace function
    sys.settrace(tracer.trace)
    assert tracer.trace(frame, event, arg) == tracer.trace
    # reset the current trace function to None
    sys.settrace(None)
    # test for negative max_variable_length
    tracer = Tracer(max_variable_length=-10)
    assert tracer.trace(frame, event, arg) == tracer.trace
    # test for non-negative max_variable_length
    tracer

# Generated at 2022-06-24 17:17:08.738774
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Case 1:
    # This is an example of basic usage on a function
    # with one watch expression and one watch expression that explodes.
    def f01(x):
        a = x + 1
        return a
    # We are not using pysnooper here because of the test itself.
    tracer_0 = Tracer()
    tracer_1 = Tracer(watch=('x', 'a'), watch_explode=('self'))
    tracer_0.__enter__()
    tracer_1.__enter__()
    tracer_1.target_codes.add(f01.__code__)
    tracer_1.target_frames.add(f01.__code__.co_firstlineno)

# Generated at 2022-06-24 17:17:13.874274
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    tracer_0 = Tracer()
    test_case_0.test_FileWriter_write = tracer_0.test_FileWriter_write
    # Call function test_FileWriter_write
    try:
        test_case_0.test_FileWriter_write()
    except:
        pass



# Generated at 2022-06-24 17:17:24.384764
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def test_case_0():
        tracer_0 = Tracer()
        # Verify that the return value of __call__() is the function that was
        # passed to it.
        assert tracer_0(lambda x: x + 1) == (lambda x: x + 1)

    def test_case_1():
        # Verify that pysnooper works with a class
        tracer_0 = Tracer()
        wrapped_class = tracer_0(MyClass)
        wrapped_class.foo = 123
        assert wrapped_class.foo == 123
        wrapped_class.bar()
        wrapped_class.baz()

    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:17:36.523114
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    log = logging.getLogger('pysnooper')
    log.info('test_Tracer___call__')

    def test_func_1():
        return
    test_func_1 = Tracer(output=None)(test_func_1)

    assert(type(test_func_1) == types.FunctionType)
    assert(test_func_1.__code__.co_filename == inspect.getsourcefile(test_func_1))
    assert(test_func_1.__code__.co_name == 'test_func_1')
    assert(test_func_1.__code__.co_argcount == 0)
    assert(Tracer.__enter__.__code__.co_filename in test_func_1.__code__.co_code)

# Generated at 2022-06-24 17:17:43.918741
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test default values
    tracer = Tracer()
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.normalize == False
    assert tracer.relative_time == False

    # Test with non-default values
    tracer = Tracer(depth=4, prefix='$$ ')
    assert tracer.depth == 4
    assert tracer.prefix == '$$ '

    from .utils import TracerTest


# Generated at 2022-06-24 17:17:45.374521
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    global tracer_0
    print(tracer_0.get_path_and_source_from_frame(inspect.currentframe()))


# Generated at 2022-06-24 17:17:47.542776
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    assert tracer_0.trace == None


# Generated at 2022-06-24 17:17:48.888739
# Unit test for constructor of class Tracer
def test_Tracer():
    test_case_0()