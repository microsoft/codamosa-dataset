

# Generated at 2022-06-24 17:09:23.029466
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    __sugar__ = {'assertEqual': {'args': ['expected', 'actual']},
                 'addTest': {'kwargs': {'0': {'kwargs': {'0': {'name': 'name'}}}}}
                }
    from unittest import TestCase
    class TestGetPathSource(TestCase):
        def test_get_source_from_frame(self):
            source_and_path_0 = get_path_and_source_from_frame(inspect.currentframe())
            self.assertEqual(source_and_path_0[0], "python_snippets/thinker.py")

# Generated at 2022-06-24 17:09:26.089988
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    string_0 = 'snoop'
    list_0 = [string_0, string_0]
    Tracer_instance_0 = Tracer(list_0, list_0, list_0)
    Tracer_instance_0.__enter__()


# Generated at 2022-06-24 17:09:32.686947
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    float_0 = -358.0
    int_0 = -547
    file_writer_0 = FileWriter(float_0, int_0)
    trace_0 = Tracer(file_writer_0, None, (), (), 2, '', False, False, (), 100, False, False)
    trace_0.__enter__()
    trace_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:09:44.145215
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    float_0 = 0.813704956
    int_0 = 4
    string_0 = 'Pysnooper Unit Test'
    tracer_0 = Tracer(float_0, int_0, string_0)
    float_1 = 0.598976937
    int_1 = 4
    string_1 = 'Pysnooper Unit Test'
    tracer_1 = Tracer(float_1, int_1, string_1)
    tracer_1.__exit__(None, None, None)


# Generated at 2022-06-24 17:09:49.594582
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .variables import SimpleVariable
    frame = sys._getframe()
    assert frame
    assert frame.f_code.co_name == 'test_case_0'

    local_reprs = get_local_reprs(frame, watch=(SimpleVariable(float_0=float),),
                                  normalize=True)
    assert local_reprs['float_0'] == '-358.0'
    assert local_reprs['file_writer_0'][:64] == 'FileWriter(float_0=-358.0, int_0=-547)'


# Generated at 2022-06-24 17:09:55.823257
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with Tracer(None) as tracer_0:
        tracer_0.trace()


# Generated at 2022-06-24 17:10:07.487320
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    int_0 = -471
    int_1 = -221
    call_arg_0 = -149
    int_2 = -376
    int_3 = -305
    int_4 = -472
    int_5 = 4
    common_variable_0 = CommonVariable(int_0)
    common_variable_1 = CommonVariable(int_1)
    custom_repr_0 = (call_arg_0, int_2)
    custom_repr_1 = (int_3, int_4, int_5)
    int_6 = -380
    int_7 = -21
    int_8 = -216
    int_9 = -295
    int_10 = -507
    float_0 = -356.0
    float_1 = -163.0
    float_2 = -24.0


# Generated at 2022-06-24 17:10:17.304991
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()

    # It's not really a great idea to test for specific lines in the code
    # because this will change as the code changes. Instead, we should test
    # that the function returns a tuple with:
    #   * The path
    #   * A list of lines
    path, source = get_path_and_source_from_frame(frame)
    assert path is not None
    assert isinstance(source, list)
    assert len(source) > 0


# Generated at 2022-06-24 17:10:22.863983
# Unit test for constructor of class Tracer
def test_Tracer():
    @snoop(prefix='ZZZ ')
    def test_case_1():
        a = 5
        b = '6'
        c = a + int(b)
        print(c)
    test_case_1()


# Generated at 2022-06-24 17:10:31.773342
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    line_no = -180
    int_0 = -547
    float_0 = -358.0
    file_writer_0 = FileWriter(float_0, int_0)
    s = "../tests/test_data/test_Tracer___enter__.txt"
    file_writer_0.output = open(s, 'w')
    file_writer_0.overwrite = True

    size_0 = 0
    file_writer_0 = FileWriter(float_0, int_0)
    file_writer_0.output = open(s, 'w')
    file_writer_0.overwrite = True
    tracer_0 = Tracer(file_writer_0)
    tracer_0.__enter__()
    tracer_0.write("abc")
    assert tracer_0.__dict

# Generated at 2022-06-24 17:10:57.018791
# Unit test for method trace of class Tracer

# Generated at 2022-06-24 17:11:03.353413
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    # Test 1
    var_0 = get_path_and_source_from_frame(test_case_0())

    assert(var_0[0] == '$sandbox/scratch_1.py')
    assert(var_0[1] == ['import inspect as module_0', '                                                                                                                                                                                                                                                                                                                                                                                   ', 'def test_case_0():', '    var_0 = module_0.currentframe()', '              '])


# Generated at 2022-06-24 17:11:10.481357
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class Class_0():
        def method_0(self):
            var_0 = self
            var_1 = 'Hi'
            var_2 = list(range(10))
            return var_1[1:1]*.5 + var_0
        @pysnooper.snoop()
        def method_1(self):
            var_0 = self.method_0()
            return var_0
    var_0 = Class_0()
    var_0.method_1()


# Generated at 2022-06-24 17:11:12.543818
# Unit test for constructor of class Tracer
def test_Tracer():
    Tracer(watch=('foo', 'self'))
    Tracer(watch=('foo', 'self'))
    Tracer(watch=('foo', 'self'))


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:11:22.681945
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame_local_reprs_0 = get_local_reprs(
        var_0,
        watch=(),
        custom_repr=(),
        max_length=None,
        normalize=False
    )
    assert frame_local_reprs_0 == {}
    frame_local_reprs_1 = get_local_reprs(
        var_0,
        watch=(),
        custom_repr=(),
        max_length=None,
        normalize=True
    )
    assert frame_local_reprs_1 == {}

# Generated at 2022-06-24 17:11:31.472751
# Unit test for function get_path_and_source_from_frame

# Generated at 2022-06-24 17:11:34.684703
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    snooper = pysnooper.snoop()
    var_1 = snooper.__exit__(None, None, None)
    return var_1


# Generated at 2022-06-24 17:11:44.998450
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    this_dir = os.path.dirname(__file__)
    carcass = os.path.join(this_dir, 'carcass')
    with open(carcass, 'r') as f:
        carcass_source = f.read()

    frame_info = inspect.getframeinfo(test_case_0.__code__)
    sourcepath, source = get_path_and_source_from_frame(test_case_0.__globals__)
    source_lines, source_lines_start = inspect.getsourcelines(test_case_0)
    frame_info_lines, frame_info_lines_start = inspect.getframeinfo(test_case_0.__code__)
    assert source_lines == source_lines_start == frame_info_lines == frame_info_lines_start == source

# Generated at 2022-06-24 17:11:47.002875
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    test_case_0()

import traceback as module_1


# Generated at 2022-06-24 17:11:51.940554
# Unit test for constructor of class Tracer
def test_Tracer():
    with pysnooper.snoop(output=None):
        test_case_0()


# Generated at 2022-06-24 17:12:17.292196
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with Tracer(output=None):
        test_case_0()

from pdb import set_trace as module_0
import builtins as module_1


# Generated at 2022-06-24 17:12:27.720299
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import sys
    if 'garlicsim_lib' in sys.modules:
        del sys.modules['garlicsim_lib']
    test_case_0()
    sample_0 = pycompat.path_types[0]('./test_temp/test_FileWriter_write/sample_0.json')
    output_0 = pycompat.path_types[0]('./test_temp/test_FileWriter_write/output_0.json')
    overwrite_0 = True
    write_0 = FileWriter(output_0, overwrite_0)
    import json
    with open(sample_0, 'r') as file_0:
        state_0 = json.load(file_0)

# Generated at 2022-06-24 17:12:28.701079
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()



# Generated at 2022-06-24 17:12:40.135957
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import mock
    import tempfile
    test_case_0()
    mock_file_name = tempfile.mktemp()
    with open(mock_file_name, 'w') as f:
        f.write('some random content')
    mock_file_name = mock_file_name
    var_1 = list(get_path_and_source_from_frame.func_code.co_consts)
    var_2 = var_1[1]
    var_3 = var_1[2]
    var_4 = mock.MagicMock()
    var_4.get_source = mock.MagicMock(return_value=None)
    var_4.__name__ = '__loader__'
    var_5 = {}
    var_5['__loader__'] = var_4
    var_5

# Generated at 2022-06-24 17:12:49.690344
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import os
    import inspect
    import sys
    import contextlib
    current_dir = os.getcwd()
    temp_dir_path = os.path.join(current_dir, 'temp_test_dir')
    os.mkdir(temp_dir_path)
    os.chdir(temp_dir_path)
    tmp_file_path = os.path.join(temp_dir_path, 'temp_file.py')

# Generated at 2022-06-24 17:12:53.098862
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    var_0 = Tracer()
    var_1 = module_0.currentframe()
    var_2 = var_0.__call__(var_1)


# Generated at 2022-06-24 17:13:04.388810
# Unit test for function get_path_and_source_from_frame

# Generated at 2022-06-24 17:13:16.846627
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    assert callable(snooper_instance.trace)
    snooper_instance.watch = list()
    snooper_instance.frame_to_local_reprs = dict()
    snooper_instance.start_times = dict()
    snooper_instance.depth = int()
    snooper_instance.prefix = str()
    snooper_instance.thread_info = False
    snooper_instance.thread_info_padding = int()
    snooper_instance.target_codes = set()
    snooper_instance.target_frames = set()
    snooper_instance.thread_local = threading.local()
    snooper_instance.custom_repr = tuple()
    snooper_instance.last_source_path = None
    snooper_instance.max_variable_

# Generated at 2022-06-24 17:13:23.444830
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test with all args
    snoop_obj = pysnooper.snoop(module_0.stdout)
    snoop_obj.__call__(test_case_0)

    # Test with default args
    snoop_obj = pysnooper.snoop()
    snoop_obj.__call__(test_case_0)

    # Test failure with too few args
    with pytest.raises(TypeError):
        snoop_obj.__call__()


# Generated at 2022-06-24 17:13:25.793884
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert test_case_0.__code__ == module_0.currentframe().f_code
    path_0, source_0 = get_path_and_source_from_frame(test_case_0.__code__)
    assert "test_get_path_and_source_from_frame" in path_0


# Generated at 2022-06-24 17:14:16.064635
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(TypeError):
        Tracer()
    with pytest.raises(TypeError):
        Tracer(overwrite=None)
    with pytest.raises(TypeError):
        Tracer(thread_info=None)
    with pytest.raises(TypeError):
        Tracer(max_variable_length=None)
    with pytest.raises(TypeError):
        Tracer(normalize=None)
    with pytest.raises(TypeError):
        Tracer(relative_time=None)

# Generated at 2022-06-24 17:14:28.848723
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import inspect as module_0
    import inspect as module_1
    import inspect as module_2
    import os as module_3
    import pprint as module_4
    import inspect as module_5
    import inspect as module_6
    import inspect as module_7
    import os as module_8
    import pprint as module_9
    import inspect as module_10
    import inspect as module_11
    import inspect as module_12
    import os as module_13
    import pprint as module_14
    import pysnooper as module_15
    import inspect as module_16
    import inspect as module_17
    import inspect as module_18
    import os as module_19
    import pprint as module_20
    import pysnooper as module_21
    import inspect as module_22
    import inspect as module

# Generated at 2022-06-24 17:14:37.533501
# Unit test for function get_write_function

# Generated at 2022-06-24 17:14:40.726460
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    trace_0 = pysnooper.snoop(watch=[])(test_case_0)
    trace_0()


# Generated at 2022-06-24 17:14:45.608636
# Unit test for method trace of class Tracer
def test_Tracer_trace():

    def main():
        test_case_0()

    main()

if __name__ == '__main__':
    test_Tracer_trace()

################################################################################
#                                END OF FILE                                   #
################################################################################



# Snippet Title:
# Snippet Description:
# Snippet Author:

# Generated at 2022-06-24 17:14:50.504491
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Testing method __enter__ of class Tracer
    assert var_0.locals["self_object"].__enter__ == None

# Generated at 2022-06-24 17:14:59.991776
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    pysnooper.snoop()(test_case_0)()

if __name__ == '__main__':
    # Run unit tests without nose or py.test
    import os
    import sys
    import inspect
    import pysnooper
    # Make sure we use the same python version in the tests as in the library
    # to avoid possible confusion
    assert (sys.version_info.major, sys.version_info.minor) == \
           (pysnooper.version_info.major, pysnooper.version_info.minor)

    # Make sure that the test is run directly from the project folder
    # Do not run the tests if 'pysnooper' is a library installed via pip
    os_path_dirname = os.path.dirname
    os_path_

# Generated at 2022-06-24 17:15:01.929280
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    var_2 = test_case_0()
    var_1 = module_0.currentframe()

# Generated at 2022-06-24 17:15:05.887111
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect as module_0
    var_0 = test_case_0.__code__.co_filename
    var_1 = inspect.currentframe()
    var_2 = get_path_and_source_from_frame(var_1)
    assert var_0 == var_2[0]


# Generated at 2022-06-24 17:15:10.166803
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    var_0 = FileWriter(module_0.currentframe(), None)



import threading as module_1


# Generated at 2022-06-24 17:15:45.652496
# Unit test for function get_write_function
def test_get_write_function():
    """
    Test for function get_write_function, includes all cases.
    """
    try:
        # Test case 0
        test_case_0()
    except Exception:
        print("Test case 0: incorrect")
        raise
    print("Test case 0: correct")
    output = "test.txt"
    overwrite = False
    tracer_1 = Tracer(output=output, overwrite=overwrite)
    try:
        del tracer_1
    except Exception:
        print("Test case 1: incorrect")
        raise
    print("Test case 1: correct")

    output = "test.txt"
    overwrite = True
    tracer_2 = Tracer(output=output, overwrite=overwrite)
    try:
        del tracer_2
    except Exception:
        print("Test case 2: incorrect")
       

# Generated at 2022-06-24 17:15:47.211269
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()


# Generated at 2022-06-24 17:15:51.648419
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    s = 'test_string'
    test_case_0()
    tracer_0 = tracer_0.start_tracing()
    path = 'test_FileWriter_write_output_file.txt'
    overwrite = False
    tracer_0.write()
    tracer_0.stop_tracing()



# Generated at 2022-06-24 17:15:54.575385
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    with tracer_0:
        print("Unit test for Tracer.__call__")
        assert inspect.isgeneratorfunction(test_case_0) == False


# Generated at 2022-06-24 17:15:58.678773
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.write = mock.MagicMock(name='write')
    tracer_0.__exit__(None, None, None)
    assert tracer_0.write.call_args_list[0][0][0] == '    Elapsed time: 0:00:00.000000\n'


# Generated at 2022-06-24 17:16:00.657257
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with Tracer():
        pass


# Generated at 2022-06-24 17:16:02.463664
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass


# Generated at 2022-06-24 17:16:12.250014
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe()
    frame_1 = inspect.getouterframes(frame_0)[1].frame
    frame_2 = inspect.getouterframes(frame_1)[1].frame
    path_and_source_0 = get_path_and_source_from_frame(frame_0)
    path_and_source_1 = get_path_and_source_from_frame(frame_1)
    path_and_source_2 = get_path_and_source_from_frame(frame_2)
    assert path_and_source_0.filename == os.path.join(os.path.dirname(__file__),
                                                      'tracer.py')

# Generated at 2022-06-24 17:16:19.431070
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()


    # No arguments
    # No return value
    value = tracer.trace(
        None,
        None,
        None
    )

    # Return value type test
    if not isinstance(value, types.FunctionType):
        print("Return value type test failed")
        return


    # No arguments
    # No return value
    value = tracer.trace(
        None,
        None,
        None
    )

    # Return value type test
    if not isinstance(value, types.FunctionType):
        print("Return value type test failed")
        return


    # No arguments
    # No return value
    value = tracer.trace(
        None,
        None,
        None
    )

    # Return value type test

# Generated at 2022-06-24 17:16:25.517559
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    output_0 = None
    watch_0 = ()
    watch_explode_0 = ()
    depth_0 = 1
    prefix_0 = ''
    overwrite_0 = False
    thread_info_0 = False
    custom_repr_0 = ()
    max_variable_length_0 = 100
    normalize_0 = False
    relative_time_0 = False
    tracer_0 = Tracer(output_0, watch_0, watch_explode_0, depth_0,
                      prefix_0, overwrite_0, thread_info_0, custom_repr_0,
                      max_variable_length_0, normalize_0, relative_time_0)
    function_or_class_0 = test_case_0
    tracer_0._wrap_function(function_or_class_0)


# Generated at 2022-06-24 17:16:57.063983
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        test_case_0()
    finally:
        tracer = tracer_0
    import tempfile
    temp_folder = tempfile.TemporaryDirectory(prefix='sweet_debug_')
    test_file_path = os.path.join(temp_folder.name, 'test.py')
    test_file = open(test_file_path, 'w')
    test_file.write('''
x = 2
y = 3
z = 2 * x + y
''')
    test_file.close()
    frame_0 = tracer.frames[0]
    file_0, source_0 = get_path_and_source_from_frame(frame_0)
    assert file_0 == test_file_path

# Generated at 2022-06-24 17:17:00.133059
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    frame.f_locals['path'] = path
    frame.f_locals['source'] = source



# Generated at 2022-06-24 17:17:04.029912
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writer = FileWriter('test.txt', False)
    writer.write('test')
    f = open('test.txt', 'r')
    assert f.read() == 'test'



# Generated at 2022-06-24 17:17:05.967809
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    test_write = FileWriter('./test_output.txt', True)
    test_write("test_string")
    test_write("test_string")


# Generated at 2022-06-24 17:17:08.211318
# Unit test for function get_write_function
def test_get_write_function():
    output = "hello"
    overwrite = True
    print(get_write_function(output, overwrite))
    assert isinstance(get_write_function(output, overwrite), FileWriter)



# Generated at 2022-06-24 17:17:10.089240
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()
    frame = inspect.currentframe()
    print(get_path_and_source_from_frame(frame))



# Generated at 2022-06-24 17:17:12.571541
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    with tracer_0:
        pass


# Generated at 2022-06-24 17:17:13.870178
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    FileWriter(path = 'test_unit.log', overwrite = True).write \
     (s = 'test_unit.log')



# Generated at 2022-06-24 17:17:24.570294
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == __file__
    assert source[30:40] == ['# Unit test for function get_path_and_source_from_frame',
                             'def test_get_path_and_source_from_frame():',
                             '    frame = inspect.currentframe()',
                             '    file_name, source = get_path_and_source_from_frame(frame)',
                             '    assert file_name == __file__',
                             '    assert source[30:40] == [',
                             'test_get_path_and_source_from_frame()']



# Generated at 2022-06-24 17:17:32.332402
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_1 = Tracer(
        watch=("something",),
        watch_explode=("some_list", "some_dict",),
        depth=2,
        prefix="",
        overwrite=False,
        thread_info=True,
        custom_repr=((object, lambda x: "Object is: " + repr(x)),),
        max_variable_length=100,
        normalize=False,
        relative_time=False,
    )


# Generated at 2022-06-24 17:18:19.095969
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    assert result[0] == inspect.getframeinfo(frame).filename
    assert result[1][inspect.getframeinfo(frame).lineno - 1] \
        == inspect.getsourcelines(test_case_0)[0][0].strip()

# This dictionary holds the most recently used traceback for each thread.
# The traceback is only cleared if the thread itself is cleared.
_cached_tracebacks = {}



# Generated at 2022-06-24 17:18:21.808721
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    assert tracer is not None
    assert tracer.depth == 1
    print('{}'.format(tracer))
    # TODO: add test code
    pass


# Generated at 2022-06-24 17:18:30.554076
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()
    test_case_0.func_globals['__name__'] = 'tracemalloc_tests'
    frame = sys._getframe(1)
    source, path = get_path_and_source_from_frame(frame)
    assert path == 'tracer.py'
    assert source[0] == 'def test_case_0():'
    


# Generated at 2022-06-24 17:18:34.433022
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    try:
        tracer_0 = Tracer()
        tracer_0.__enter__()
        tracer_0.__exit__(None, None, None)
    except Exception as e:
        print('Caught exception:')
        print(e)

if __name__ == '__main__':
    test_case_0()
    #test_Tracer___exit__()