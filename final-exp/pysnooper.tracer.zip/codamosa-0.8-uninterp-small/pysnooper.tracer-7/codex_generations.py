

# Generated at 2022-06-24 17:09:57.022463
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    code_1 = test_case_0.__code__
    frame_1 = None
    result_1 = get_path_and_source_from_frame(frame_1)
    assert result_1[1] == unavailable_source_0


# Generated at 2022-06-24 17:10:08.522940
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame_0 = inspect.currentframe()
    frame_1 = sys._getframe(1)

    # Example 1: the current frame has source available
    expected_file_name_0, expected_source_0 = get_path_and_source_from_frame(frame_0)
    actual_file_name_0, actual_source_0 = get_path_and_source_from_frame(frame_0)

# Generated at 2022-06-24 17:10:16.054013
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    if DISABLED:
        return
    root_frame = inspect.currentframe().f_back
    root_frame.f_trace = None
    tracer = Tracer()
    tracer.target_codes.add(test_case_0.__code__)
    tracer.target_frames.add(root_frame)
    tracer.trace(root_frame, 'call', None)


# Generated at 2022-06-24 17:10:22.020467
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Case 0: unavailable source
    tracer = Tracer()
    frame = Frame(None, None, None, 1, unavailable_source_0, None)
    event = 'call'
    arg = None
    actual_0 = tracer.trace(frame, event, arg)
    expected_0 = None
    message_0 = ('"Case 0: unavailable source" failed\n'
                 'Expected:\n'
                 '{expected}\n'
                 'but got\n'
                 '{actual}').format(expected=expected_0, actual=actual_0)
    assert actual_0 == expected_0, message_0



# Generated at 2022-06-24 17:10:29.157275
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    if DISABLED:
        raise unittest.SkipTest("Snoop disabled, can't run test")
    snooper = Snooper(watch='watch')
    stack = snooper.thread_local.__dict__.setdefault('original_trace_functions',[])
    stack.append("hi")
    frame = unittest.mock.Mock()
    snooper.start_times[frame] = datetime_module.datetime.now()
    snooper.frame_to_local_reprs[frame] = frame
    snooper.target_frames.add(frame)
    with unittest.mock.patch.object(utils.datetime, 'datetime', autospec=True) as mock_datetime:
        mock_datetime.now.return_value = datetime_module.dat

# Generated at 2022-06-24 17:10:30.596730
# Unit test for constructor of class Tracer
def test_Tracer():
    from pysnooper import snoop
    test_obj = Tracer()
    assert isinstance(snoop(), Tracer) == True


# Generated at 2022-06-24 17:10:32.530848
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(
        sys._getframe()
    )[0].endswith(os.path.normpath('tests/test_debug_base.py'))



# Generated at 2022-06-24 17:10:43.345763
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    get_path_and_source_from_frame(frame)


_CO_OPTIMIZED = 0x0001
_CO_NEWLOCALS = 0x0002
_CO_VARARGS = 0x0004
_CO_VARKEYWORDS = 0x0008
_CO_NESTED = 0x0010
_CO_GENERATOR = 0x0020
_CO_NOFREE = 0x0040
_CO_COROUTINE = 0x0080
_CO_ITERABLE_COROUTINE = 0x0100
_CO_ASYNC_GENERATOR = 0x0200

coroutine_flags = _CO_COROUTINE | _CO_ITERABLE_COROUTINE | _CO_ASYNC_GENERATOR



# Generated at 2022-06-24 17:10:56.468588
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test with the following condition: unavailable_source_0 = UnavailableSource()

    # Case 0: unavailable_source_0 = UnavailableSource()
    frame = inspect.currentframe()
    frame_candidate = frame
    for i in range(1, 2):
        frame_candidate = frame_candidate.f_back
        if frame_candidate is None:
            return None
        elif frame_candidate.f_code in set():
             break
    else:
        return None
    calling_frame = inspect.currentframe().f_back
    # Expected output: None

    # Case 1: unavailable_source_0 = UnavailableSource()

# Generated at 2022-06-24 17:10:58.757933
# Unit test for constructor of class Tracer
def test_Tracer():
    _tracer = Tracer(output=_stdout, watch=('self', 'foo'), watch_explode=('foo', 'self'))


# Following fucntions is for case 0:

# Generated at 2022-06-24 17:11:52.645116
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from ..snooper import tracer
    tr = Tracer()
    tr.watch = [CommonVariable('a')]
    tr.frame_to_local_reprs = {}
    tr.start_times = {}
    tr.depth = 1
    tr.prefix = ''
    tr.overwrite = False
    tr.thread_info = False
    tr.custom_repr = ()
    tr.max_variable_length = 100
    tr.normalize = False
    tr.relative_time = False
    _frame_candidate = unavailable_source_0
    event = 'call'
    source_path = 'test_tracer.py'
    source_line = 'def test_case_0():\n'
    thread_info = ''
    thread_global.depth = -1
    frame = unavailable_source_0

# Generated at 2022-06-24 17:12:06.737408
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def function_with_missing_source():
        unavailable_source_0 = UnavailableSource()

    def function_with_existing_source():
        available_source_0 = AvailableSource()

    tracer = Tracer()
    tracer.depth = 2

    # Test event 'call'

# Generated at 2022-06-24 17:12:17.152773
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import inspect

    source_path = inspect.getsourcefile(test_case_0)
    source_lines = inspect.getsourcelines(test_case_0)[0]
    source_line = source_lines[1-1]
    line_no = 1
    indent = ' ' * 4 * 0
    timestamp = pycompat.time_isoformat(
        datetime_module.datetime.now().time(),
        timespec='microseconds'
    )
    event = 'call'
    arg = None
    # arg = 'exception:...\ntraceback (most recent call last):\n  File "x", line 1, in <module>\nNameError: name \'UnavailableSource\' is not defined\n'
    trace_frame = inspect.currentframe().f_back.f_back

    original_

# Generated at 2022-06-24 17:12:27.683897
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    from io import StringIO
    from tempfile import TemporaryFile
    from shutil import rmtree
    from pathlib import Path
    from os.path import isdir, join, curdir
    from .utils import get_write_function

    curdir_path = Path(curdir)
    file_nam = 'file.name'
    file_path = curdir_path.joinpath(file_nam)

    def assert_raise(obj, message, overwrite=False):
        with utils.testing_expectation(AssertionError(message)):
            get_write_function(obj, overwrite)

    assert_raise(None, '`overwrite` must be `False`.', overwrite=True)

# Generated at 2022-06-24 17:12:33.165352
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    obj = snoop(output=None, watch=(), watch_explode=(), depth=1,
                prefix='', overwrite=False, thread_info=False, custom_repr=(),
                max_variable_length=100, normalize=False, relative_time=False)
    exc_type = Exception()
    exc_value = Exception()
    exc_traceback = Exception()
    assert isinstance(obj.__exit__(exc_type, exc_value, exc_traceback), NoneType)


# Generated at 2022-06-24 17:12:41.213297
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe()
    (file_name,
     source) = get_path_and_source_from_frame(frame)
    assert file_name.endswith('debugging_tools/tests/test_traceback_parser.py')
    assert source[0] == 'def test_case_0():'
    assert source[-1] == 'test_case_0()'
    assert isinstance(source, UnavailableSource)



# Generated at 2022-06-24 17:12:52.607240
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import types
    import unittest
    class TestTracer(unittest.TestCase):
        def test_Tracer___call__(self):
            """Test if __call__ behaves properly"""
            # Function TestTracer._test_Tracer___call___
            def _test_Tracer___call___(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False):
                # TestTracer._test_Tracer___call___ generated from pysnooper/snoop.py
                # Code generated and tested on python 2.7, but it should work
                # for Python 3.5+
                import functools
                import inspect
               

# Generated at 2022-06-24 17:12:55.536271
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    unavailable_source_0 = UnavailableSource()

    with pytest.raises(UnavailableSourceError):
        unavailable_source_0.bar()

    unavailable_source_0.foo()

    # Make sure the following lines aren't snooped:
    tracer_0 = Tracer()
    tracer_1 = Tracer()


# Generated at 2022-06-24 17:13:02.150922
# Unit test for function get_write_function
def test_get_write_function():
    buff = pycompat.StringIO()
    write = get_write_function(buff, overwrite=True)
    write(u'1')

    assert buff.getvalue() == u'1'

    write = get_write_function(buff, overwrite=False)
    assert write == buff.write

    path = utils.rand_file_name()

# Generated at 2022-06-24 17:13:07.524305
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Call function Tracer.__call__ anonymously here.
    # Any exception that it rises will be caught.
    try:
        Tracer().__call__(unavailable_source_0)
    except:
        print(sys.exc_info()[1])


# Generated at 2022-06-24 17:13:43.278908
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(sys._getframe())[0] == __file__
    assert get_path_and_source_from_frame(sys._getframe())[1] == test_case_0.__code__.co_consts[0].splitlines()
    assert get_path_and_source_from_frame(sys._getframe())[1] == unavailable_source_0


# Generated at 2022-06-24 17:13:54.917905
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    cur_path = os.path.dirname(__file__)
    test_path = os.path.join(cur_path, 'test_case_0.py')
    source_path, source = get_path_and_source_from_frame(test_case_0.__globals__)
    assert source_path == test_path
    assert source == unavailable_source_0


if '__loader__' not in __import__('functools').__globals__:
    # When `__loader__` isn't present, add it manually so we can use it to
    # extract the source nice and easy.
    def loader_decorator(loader):
        def decorator(module):
            module.__loader__ = loader
            return module
        return decorator

# Generated at 2022-06-24 17:14:08.645045
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame_0 = inspect.currentframe()
    frame_1 = frame_0.f_back
    frame_2 = frame_1.f_back

    file_name_0, source_0 = get_path_and_source_from_frame(frame_0)
    file_name_1, source_1 = get_path_and_source_from_frame(frame_1)
    file_name_2, source_2 = get_path_and_source_from_frame(frame_2)

    assert file_name_0 == 'debugged_function.py'
    assert file_name_1 == 'debugged_function.py'
    assert file_name_2 == 'debugged_function.py'

    assert len(source_0) > 200
    assert len(source_1) > 200

# Generated at 2022-06-24 17:14:19.625338
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    unavailable_source_0 = UnavailableSource()
    try:
        raise Exception
    except:
        unavailable_source_0.tb = sys.exc_info()[2]
    try:
        unavailable_source_0.lineno = unavailable_source_0.tb.tb_lineno
    except AttributeError:
        unavailable_source_0.lineno = None

    def test_case_0():
        unavailable_source_1 = UnavailableSource()
        class test_case_0_class_0(object):
            def __call__(self):
                unavailable_source_1.__enter__()
                unavailable_source_1.__exit__()
        unavailable_source_1.test_case_0_class_0_instance = test_case_0_class_0()
        unavailable_source_1.test

# Generated at 2022-06-24 17:14:23.924033
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    snooper = Tracer(output=None)
    trace = snooper.trace
    frame = None  # dummy frame
    event = None  # dummy event
    arg = None  # dummy arg
    return trace(frame, event, arg)


# Generated at 2022-06-24 17:14:34.679958
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    assert get_line_from_frame(test_case_0.__code__.co_filename,
                               test_case_0.__code__.co_firstlineno) == 'def test_case_0():\n'
    assert get_full_path_from_frame(test_case_0.__code__.co_filename) == \
           os.path.abspath(__file__)
    assert get_path_and_source_from_frame(
        test_case_0.__code__.co_filename,
        test_case_0.__code__.co_firstlineno
    ) == (
        os.path.abspath(__file__),
        'def test_case_0():\n'
    )

# Generated at 2022-06-24 17:14:43.007357
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global total_lines, snoop_line, unwrapped_start
    # Initial setup
    tracer = Tracer(output=sys.stdout, watch="", watch_explode="()", depth=1, prefix="", overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    total_lines = 0
    snoop_line = 0
    # Saving the start time of the original function
    unwrapped_start = datetime.datetime.now()
    test_case_0()
    # Getting the end time of the original function
    unwrapped_end = datetime.datetime.now()
    # Calculating the elapsed time of the original function
    unwrapped_elapsed = unwrapped_end - unwrapped_start
   

# Generated at 2022-06-24 17:14:46.162136
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    unavailable_source_0 = UnavailableSource()
    tc = Tracer()
    tc(unavailable_source_0)

if __name__ == "__main__":
    #import doctest
    #doctest.testmod()
    test_Tracer___call__()

# Generated at 2022-06-24 17:14:52.834024
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    expected_start_times = {
        test_case_0.__code__.co_consts[0].co_consts[0]: datetime_module.datetime.now()
    }
    expected_frame_to_local_reprs = {}
    expected_last_source_path = None
    expected_thread_info_padding = 0

    # Calling Tracer.__enter__(...)
    tracer = Tracer()
    tracer.__enter__()

    # Check the current state of the Tracer instance
    actual_start_times = tracer.start_times
    actual_frame_to_local_reprs = tracer.frame_to_local_reprs
    actual_last_source_path = tracer.last_source_path
    actual_thread_info_padding = tracer.thread_info

# Generated at 2022-06-24 17:14:55.185695
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe(test_case_0)
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == os.path.abspath(inspect.getfile(test_case_0))
    assert source == unavailable_source_0



# Generated at 2022-06-24 17:15:33.972792
# Unit test for function get_write_function
def test_get_write_function():
    kwargs = {'overwrite': True}

    # Testing when output is None
    output = None
    write = get_write_function(output, **kwargs)
    assert write('hello\n')

    # Testing when output is a string
    output = 'test_file.log'
    write = get_write_function(output, **kwargs)
    assert write('hello\n')

    # Testing when output is a file
    output = open(output)
    write = get_write_function(output, **kwargs)
    assert write('hello\n')

    # Testing when output is a callable
    output = functools.partial(open, 'test_file.log')
    write = get_write_function(output, **kwargs)
    assert write('hello\n')

    # Testing when output is a

# Generated at 2022-06-24 17:15:44.043795
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # param: frame: frame object
    frame = Frame(Stack(), pycompat.ExecutionCode(source=u'print("hello")'),
                  {}, 0)
    # param: event: string
    event = 'call'
    # param: arg: depends on event
    arg = None
    # Test
    tracer = Tracer()
    tracer.trace(frame=frame, event=event, arg=arg)


# Generated at 2022-06-24 17:15:48.874237
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    unavailable_source_0 = UnavailableSource()
    unavailable_source_1 = UnavailableSource()

    def function_0():
        unavailable_source_0.test_case_1()

    function_0()

    def function_1():
        unavailable_source_1.test_case_1()

    function_1()

# Generated at 2022-06-24 17:15:55.123076
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame_0 = inspect.currentframe()
    path_and_source_0 = get_path_and_source_from_frame(frame_0)
    assert path_and_source_0 == ('test.py', ['def test_case_0():'])

test_case_0()



# Generated at 2022-06-24 17:15:57.574801
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame)[0] == \
                                               inspect.getabsfile(test_case_0)



# Generated at 2022-06-24 17:16:00.725318
# Unit test for constructor of class Tracer
def test_Tracer():
    unavailable_source_0 = UnavailableSource()
    Tracer(depth=1)


# Generated at 2022-06-24 17:16:09.028564
# Unit test for constructor of class Tracer
def test_Tracer():
    assert not inspect.isclass(Tracer)
    assert inspect.isfunction(Tracer)
    assert hasattr(Tracer, '__call__')
    assert inspect.ismethod(Tracer.__call__)
    #assert inspect.isfunction(Tracer.__enter__)
    #assert inspect.isfunction(Tracer.__exit__)
    #assert inspect.isfunction(Tracer.trace)
    #assert inspect.isfunction(Tracer.write)
    #assert inspect.isfunction(Tracer._is_internal_frame)
    #assert inspect.isfunction(Tracer._wrap_class)
    #assert inspect.isfunction(Tracer._wrap_function)


# Generated at 2022-06-24 17:16:17.930722
# Unit test for constructor of class Tracer
def test_Tracer():
    # Constructor:
    # 1. watch list
    # 2. watch_explode list
    # 3. depth
    # 4. prefix
    # 5. overwrite
    # 6. thread_info
    # 7. custom_repr list
    # 8. max_variable_length
    # 9. normalize
    # 10. relative_time

    # 1. watch list
    # input [str]
    s = Tracer(watch=['a', 'b', 'c'])
    # output [list]
    assert s.watch == [CommonVariable('a'), CommonVariable('b'), CommonVariable('c')]
    # input [list]
    s = Tracer(watch=['a'])
    # output [list]
    assert s.watch == [CommonVariable('a')]
    # input [str,]
    s

# Generated at 2022-06-24 17:16:28.312376
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    assert tracer_0.depth == 1
    assert tracer_0.watch == []
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.custom_repr == ()
    assert tracer_0.last_source_path == None
    assert tracer_0.max_variable_length == 100
    assert tracer_0.normalize == False
    assert tracer_0.relative_time == False
    assert tracer_0._write == sys.stdout.write

# Generated at 2022-06-24 17:16:29.745092
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-24 17:17:02.180981
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    tracer_1 = Tracer()
    try:
        test_case_0()
    except Exception as e:
        frame = traceback.extract_tb(e.__traceback__)[-1].frame
        file_name, source = get_path_and_source_from_frame(frame)
        assert file_name == os.path.normcase(os.path.abspath(__file__))
        assert source[20] == '    tracer_0 = Tracer()'



# Generated at 2022-06-24 17:17:06.855408
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(inspect.currentframe())
    result = foo()
    assert result[0].endswith(__file__)
    assert result[1][0].strip() == 'def test_case_0():'


# Generated at 2022-06-24 17:17:08.529781
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    return None


# Generated at 2022-06-24 17:17:13.301780
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    if 'case_0' in globals():
        tracer_0 = case_0
        tracer_0.__exit__(exc_type=None, exc_value=None, exc_traceback=None)
    else:
        tracer_0 = Tracer()



# Generated at 2022-06-24 17:17:14.540881
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    test_case_0()

#

# Generated at 2022-06-24 17:17:18.026395
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    t0 = Tracer()
    assert t0._Tracer__exit__('exc_type', 'exc_value', 'exc_traceback') is None


# Generated at 2022-06-24 17:17:21.174517
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    assert tracer_0.__dict__ == {}
    frame_0 = test_Tracer_trace.__code__
    event_0 = 'return'
    assert frame_0 == test_Tracer_trace.__code__
    arg_0 = None
    assert arg_0 is None
    

# Test case to test Tracer class

# Generated at 2022-06-24 17:17:33.079905
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Create a temp file with a single line of code, which is the function
    # call "test_case_0()".
    with open('temp_file.py', 'w') as f:
        f.write('test_case_0()')


# Generated at 2022-06-24 17:17:35.450298
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.__exit__(None, None, None)


# Generated at 2022-06-24 17:17:39.415953
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back
    event_0 = 'call'
    arg_0 = None
    output_0 = tracer_0.trace(frame_0, event_0, arg_0)
    assert output_0 == tracer_0.trace


# Generated at 2022-06-24 17:18:19.129281
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_func(a, b, c):
        return a + b + c

    frame = inspect.currentframe()
    while frame.f_code.co_name != 'test_func':
        frame = frame.f_back
    file_name, source = get_path_and_source_from_frame(frame)
    assert len(source) > 0
    assert isinstance(source[0], str)
    assert file_name == inspect.getfile(test_func)



# Generated at 2022-06-24 17:18:23.762740
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    with tracer_0:
        print('\nDELIMITER 0')
        tracer_0.__call__(tracer_0)
    with tracer_0:
        print('\nDELIMITER 1')
        tracer_0.__call__(Tracer())
    with tracer_0:
        print('\nDELIMITER 2')
        tracer_0.__call__(int)


# Generated at 2022-06-24 17:18:36.030619
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_1 = Tracer(prefix='PREFIX ', depth=10, overwrite=True,
        thread_info=False, custom_repr=((str, lambda s: '"string"'),),
        max_variable_length=None, normalize=False, relative_time=True)
    assert tracer_1._write == sys.stdout.write
    assert tracer_1.watch == []
    assert tracer_1.frame_to_local_reprs == {}
    assert tracer_1.start_times == {}
    assert tracer_1.depth == 10
    assert tracer_1.prefix == 'PREFIX '
    assert tracer_1.thread_info == False
    assert tracer_1.thread_info_padding == 0
    assert tracer_1.target_codes == set()