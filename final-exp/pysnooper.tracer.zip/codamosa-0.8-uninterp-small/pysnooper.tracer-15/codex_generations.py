

# Generated at 2022-06-24 17:09:42.116500
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pysnooper.snoop(watch=('dict_0',))
    

##############################################################################


# Generated at 2022-06-24 17:09:46.879143
# Unit test for function get_write_function
def test_get_write_function():
    try:
        get_write_function(dict_0, False)
        assert False
    except Exception:
        assert True
    try:
        get_write_function(unavailable_source_0, True)
        assert False
    except Exception:
        assert True



# Generated at 2022-06-24 17:09:50.901558
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = utils.get_frame_by_name('test_case_0')
    path, source = get_path_and_source_from_frame(frame)
    if os.path.isfile(path):
        assert source[0] == 'dict_0 = None'
    else:
        assert source == unavailable_source_0



# Generated at 2022-06-24 17:09:52.437816
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    filewriter_0 = FileWriter('test.txt', True)
    filewriter_0.write('...')



# Generated at 2022-06-24 17:09:59.074384
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        test_case_0()
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        path, source = get_path_and_source_from_frame(exc_traceback.tb_frame)
        assert exc_value is dict_0
        assert source is unavailable_source_0
        assert path == os.path.abspath(__file__)
        assert __file__ in path
    else:
        assert False




# Generated at 2022-06-24 17:10:07.242404
# Unit test for constructor of class Tracer
def test_Tracer():
    output_0 = StringIO()
    watch_0 = (1,)
    watch_explode_0 = (1,)
    depth_0 = 1
    prefix_0 = ''
    overwrite_0 = False
    thread_info_0 = False
    custom_repr_0 = (
        (1, str),
    )
    max_variable_length_0 = 100

    t_0 = Tracer(output_0, watch_0, watch_explode_0, depth_0, prefix_0,
                 overwrite_0, thread_info_0, custom_repr_0,
                 max_variable_length_0)
    # Initializing var 'output'
    output_0 = None
    # Initializing var 'watch'
    watch_0 = ()
    # Initializing var 'watch_explode'
    watch_

# Generated at 2022-06-24 17:10:19.056396
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print("Testing test_Tracer___call__...")

    source_0 = test_case_0.__code__.co_code
    function_0 = test_case_0.__code__

    tracer = Tracer(
        output=None,
        watch=(),
        watch_explode=(),
        depth=1,
        thread_info=False,
        custom_repr=(),
        max_variable_length=100,
        normalize=False,
        relative_time=False,
    )
    tracer.thread_local.original_trace_functions = []

    test_case_0()


# Generated at 2022-06-24 17:10:32.290245
# Unit test for method __exit__ of class Tracer

# Generated at 2022-06-24 17:10:43.512603
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Unit test for method __exit__ of class Tracer
    def test_case_0():
        snoop_0 = Tracer()
        frame_0 = inspect.currentframe().f_back
        snoop_0.write = noop_function
        snoop_0.__exit__(None, None, None)

    def test_case_1():
        snoop_0 = Tracer()
        frame_0 = inspect.currentframe().f_back
        snoop_0.write = noop_function
        snoop_0.__exit__(None, None, None)

    def test_case_2():
        snoop_0 = Tracer()
        frame_0 = inspect.currentframe().f_back
        snoop_0.write = noop_function

# Generated at 2022-06-24 17:10:48.401937
# Unit test for function get_write_function
def test_get_write_function():
    dict_0 = None
    unavailable_source_0 = UnavailableSource()
    f = None
    write = get_write_function(f, False)



# Generated at 2022-06-24 17:11:09.692206
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys
    a = 1
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (__file__, sys.modules[__package__.split('.')[0]].__dict__['test_get_path_and_source_from_frame'].__code__.co_filename)


# Generated at 2022-06-24 17:11:11.806175
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pytest.raises(NotImplementedError):
        Tracer()._wrap_class(test_case_0)
    Tracer()._wrap_function(test_case_0)
    

# Generated at 2022-06-24 17:11:16.814824
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    this_path, this_source = get_path_and_source_from_frame(frame)
    assert os.path.normcase(this_path) == os.path.normcase(__file__)
    assert this_source[0:13] == '# Unit test fo'
    return True


# Generated at 2022-06-24 17:11:27.186183
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Create frame
    test_case_0()
    frame_obj = sys._getframe()

    # Create expected result
    current_dir = os.path.dirname(os.path.abspath(__file__))
    path_str = current_dir + '/tests.py'

# Generated at 2022-06-24 17:11:38.966678
# Unit test for method trace of class Tracer
def test_Tracer_trace():

    # Initializations
    tracer_0 = pysnooper.snoop(watch=(), watch_explode=(), depth=1, prefix='',
                               overwrite=False, thread_info=False, custom_repr=(),
                               max_variable_length=100, normalize=False,
                               relative_time=False)
    frame_0 = inspect.currentframe().f_back
    event_0 = 'call'
    arg_0 = None

    # Call method trace of class Tracer
    tracer_0.trace(frame_0, event_0, arg_0)


# Generated at 2022-06-24 17:11:43.827339
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()
    assert get_path_and_source_from_frame(inspect.currentframe())[0] == __file__
    assert pycompat.text_type(type(get_path_and_source_from_frame(inspect.currentframe())[1])) == "<class 'list'>"


# Generated at 2022-06-24 17:11:52.740334
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    output = None
    watch = ()
    watch_explode = ('self',)
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    tracerObj = Tracer(output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr, max_variable_length, normalize, relative_time)
    tracerObj.__exit__(TypeError, TypeError(), TypeError)
    tracerObj.__exit__(ValueError, None, ValueError)

# Generated at 2022-06-24 17:12:02.778986
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    global str_0
    str_0 = 'test_case_0'
    temp_file = 'test_FileWriter_write.txt'
    f_w = FileWriter(temp_file, True)
    f_w.write(str_0)
    with open(temp_file, 'r') as f:
        assert (f.readline() == str_0)
    os.remove(temp_file)


# Generated at 2022-06-24 17:12:09.953349
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    print('Test get_path_and_source_from_frame starts...')
    frame_0 = inspect.currentframe()
    frame_1 = inspect.currentframe()
    del frame_0
    function_name_0 = 'test_case_0'
    get_all_globals = frame_1.f_globals
    print(get_all_globals)
    loader_0 = get_all_globals.get('__loader__')
    module_name_0 = get_all_globals.get('__name__')
    filename_0 = frame_1.f_code.co_filename
    cache_key = (module_name_0, filename_0)

# Generated at 2022-06-24 17:12:12.122461
# Unit test for function get_write_function
def test_get_write_function():
    assert callable(get_write_function(str_0, False))


# Generated at 2022-06-24 17:12:33.705024
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global str_0
    str_0 = 'test_Tracer___call__'
    return test_case_0()

# Generated at 2022-06-24 17:12:36.302895
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame, source_path_name = inspect.stack()[0]
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == source_path_name



# Generated at 2022-06-24 17:12:43.133456
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from _io import StringIO
    from _pysnooper import CommonVariable, BaseVariable, Exploding
    from pysnooper import FakeFile, Snooper
    from unittest.mock import Mock
    import inspect, threading
    import _pysnooper, functools
    import pysnooper
    import pycompat
    import utils, traceback
    import _pysnooper, json
    import re
    import collections.abc, itertools
    import _pysnooper, opcode, sys, inspect
    import _pysnooper
    import pycompat
    import thread_global
    import datetime_module
    import pycompat
    import os
    import pysnooper
    import utils, traceback
    import _pysnooper
    import pycompat
    import os
   

# Generated at 2022-06-24 17:12:52.085041
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = pysnooper.snoop()
    # Case 1
    assert(isinstance(tracer_0, pysnooper.pysnooper.Tracer))

    # Case 2
    class_0 = object
    assert(isinstance(tracer_0(class_0), object))

    # Case 3
    class_1 = object
    assert(isinstance(tracer_0(class_1), object))

    # Case 4
    function_0 = test_case_0
    assert(isinstance(tracer_0(function_0), types.FunctionType))


# Generated at 2022-06-24 17:12:56.434138
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print('Unit test for method __call__ of class Tracer')
    
# Test case 1 of method __call__ of class Tracer

# Generated at 2022-06-24 17:13:05.454519
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def my_method(arg1, arg2):
        str_0 = str_1 = str_2 = str_3 = str_4 = str_5 = str_6 = str_7 = None
        str_0 = 'test_Tracer_trace'
        str_1 = 'test_Tracer_trace'
        str_2 = 'test_Tracer_trace'
        str_3 = 'test_Tracer_trace'
        str_4 = 'test_Tracer_trace'
        str_5 = 'test_Tracer_trace'
        str_6 = 'test_Tracer_trace'
        str_7 = 'test_Tracer_trace'
    def f(arg_0):
        str_0 = str_1 = str_2 = str_3 = str_4 = str_5 = str_6 = str

# Generated at 2022-06-24 17:13:11.393681
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pyunit.skip_test_if_no_neo4j()

    tracer = Tracer(output="", watch=(), watch_explode=(), depth=1, prefix="", overwrite=False, thread_info=False,
                    custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)

    # Check default values
    test_0 = tracer.__call__(test_case_0)
    # Check whether a wrong type raises exception
    test_1 = tracer.__call__(1)

# Test for class Tracer

# Generated at 2022-06-24 17:13:21.441404
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(inspect.currentframe())[0].endswith('get_path_and_source_from_frame.py')
    assert get_path_and_source_from_frame(inspect.currentframe())[1][0].startswith('def test_get_path_and_source_from_frame():')
    test_case_0()
    assert get_path_and_source_from_frame(inspect.currentframe())[0].endswith('test_get_path_and_source_from_frame.py')
    assert get_path_and_source_from_frame(inspect.currentframe())[1][0].startswith('def test_get_path_and_source_from_frame():')



# Generated at 2022-06-24 17:13:23.724021
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pysnooper.snoop():
        test_case_0()



# Generated at 2022-06-24 17:13:26.391187
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_writer_0 = FileWriter(str_0, bool_0)
    file_writer_0.write(str_0)


# Generated at 2022-06-24 17:14:04.846847
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    iterable = ([1,2,3],[4,5,6],[7,8,9])
    for values in iterable:
        for value in values:
            assert value > 0



_file_cache = {}
_file_cache_lock = threading.Lock()



# Generated at 2022-06-24 17:14:07.989878
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global DISABLED
    DISABLED = False
    tracer_0 = Tracer() # TODO: Pass the correct parameters
    tracer_0.__enter__()
    DISABLED = True


# Generated at 2022-06-24 17:14:09.072430
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()


# Generated at 2022-06-24 17:14:20.079861
# Unit test for constructor of class Tracer
def test_Tracer():
    global DISABLED
    DISABLED = False

    test_case_0()
    
    tracer_1 = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=True, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    
    tracer_2 = Tracer(output=None, watch=('param_0',), watch_explode=('watch_param_1',), depth=1,
                 prefix='', overwrite=False, thread_info=True, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)


# Generated at 2022-06-24 17:14:24.336986
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = Frame()
    event_0 = 'call'
    arg_0 = None
    tracer_0.trace(frame_0, event_0, arg_0)


# Generated at 2022-06-24 17:14:27.086784
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    tracer_0.__enter__()


# Generated at 2022-06-24 17:14:34.215562
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    expected_path = os.path.dirname(os.path.dirname(__file__))
    expected_path = os.path.join(expected_path, 'tests', 'test_tracer.py')
    _, source = get_path_and_source_from_frame(test_case_0.__code__.co_firstlineno)
    assert expected_path == source.co_filename


# Generated at 2022-06-24 17:14:41.837941
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global exc_info
    exc_info = None
    def assertion(expected, actual):
        assert expected == actual
    # Call the __exit__ method of class Tracer
    tracer_0 = Tracer()
    try:
        raise Exception
    except:
        exc_info = sys.exc_info()
    tracer_0.__exit__(*exc_info)
    assertion(None, tracer_0)


# Generated at 2022-06-24 17:14:49.281126
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from io import StringIO
    from unittest import mock
    from datetime import datetime
    from time import time
    from time import sleep
    from time import time
    import random
    import sys
    import pycompat
    import threading
    import inspect
    import functools
    import opcode
    import traceback
    import sys
    import os
    import itertools
    import types
    import inspect
    import contextlib
    import threading
    import textwrap
    import unittest

    ###########################################################################
    ### Begin classes and functions used in test_case_0: ######################
    #                                                                         #

    class T0:
        def __init__(self, name, is_running=True, value=20):
            self.name = name

# Generated at 2022-06-24 17:14:50.563515
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-24 17:15:21.036979
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        test_case_0()
    except Exception:
        frame = sys.exc_info()[2].tb_frame.f_back
    finally:
        assert get_path_and_source_from_frame(frame) == ('test.py', ['def test_case_0():', '    tracer_0 = Tracer()'])

try:
    import linecache
    def check_function(frame, event, arg):
        frame.f_lineno = 0
        frame.f_trace = None
        try:
            linecache.checkcache(frame.f_code.co_filename)
        except Exception:
            return
finally:
    pass


# Generated at 2022-06-24 17:15:24.540103
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_1 = Tracer()
    tracer_1.__enter__()
    tracer_2 = Tracer()
    tracer_2.__enter__()


# Generated at 2022-06-24 17:15:28.684159
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = pysnooper.snoop()
    def function_0():
        pass
    function_0()
# def test_Tracer___call__():


# Generated at 2022-06-24 17:15:31.054586
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_1 = Tracer()
    assert tracer_1.__exit__(None, None, None) == None
    assert tracer_1.write is not None # does not raise error



# Generated at 2022-06-24 17:15:32.714670
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    test_case_0()


# Generated at 2022-06-24 17:15:43.970683
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    @tracer_0
    def func():
        pass
    tracer_0.__call__(func)
    tracer_0.__call__(func)
    @tracer_0
    def func():
        pass
    tracer_0.__call__(func)
    @tracer_0
    def func():
        pass
    tracer_0.__call__(func)
    tracer_0.__call__(func)


# Generated at 2022-06-24 17:15:49.379674
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    def function_in_this_file(arg):
        locals()
    caller_frame = inspect.stack()[2].frame
    path, source = get_path_and_source_from_frame(caller_frame)
    assert path == __file__
    assert 'test_case_0()' in source[caller_frame.f_lineno - 1]



# Generated at 2022-06-24 17:15:55.673997
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import sys

    def test_func_0():
        frame = inspect.currentframe()
        file_name, source =\
         get_path_and_source_from_frame(frame)
        assert file_name == __file__
        assert source[0] == u'def test_func_0():'
    test_func_0()



# Generated at 2022-06-24 17:15:57.232365
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.__exit__(1, 2, '3')


# Generated at 2022-06-24 17:16:07.081119
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(AssertionError):
        Tracer(depth=0)
    with pytest.raises(NotImplementedError):
        Tracer(normalize=True, thread_info=True)
    tracer_0 = Tracer()
    assert tracer_0._write is sys.stdout.write
    assert tracer_0.watch == []
    assert tracer_0.target_codes == set()
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.thread_info == False
    assert tracer_0.max_variable_length == 100
    assert tracer_0.normalize == False


# Generated at 2022-06-24 17:16:27.710780
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    exc_type_0 = None
    exc_value_0 = None
    exc_traceback_0 = None
    tracer_0.__exit__(exc_type_0, exc_value_0, exc_traceback_0)


# Generated at 2022-06-24 17:16:34.517083
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Call the method here
    tracer_0 = Tracer()
    assert tracer_0.trace(frame, event='call', arg=arg)==None
    assert tracer_0.trace(frame, event='return', arg=None)
    assert tracer_0.trace(frame, event='return', arg=arg)


# Generated at 2022-06-24 17:16:43.948287
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    if not hasattr(get_path_and_source_from_frame, 'count'):
        setattr(get_path_and_source_from_frame, 'count', 0)
    get_path_and_source_from_frame.count += 1
    if get_path_and_source_from_frame.count > 1:
        return
    tracer_0 = Tracer()

# Generated at 2022-06-24 17:16:48.449304
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:16:54.192343
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        test_case_0()
    except Exception as e:
        frame = sys.exc_info()[2].tb_frame
        assert get_path_and_source_from_frame(frame) == (__file__,
                                                         test_case_0.__code__.co_code.splitlines())



# Generated at 2022-06-24 17:17:05.866787
# Unit test for function get_write_function
def test_get_write_function():
    output = None
    overwrite = False
    write = get_write_function(output, overwrite)
    assert callable(write)
    output = '/Users/RamRachum/XXXX.txt'
    write = get_write_function(output, overwrite)
    assert callable(write)
    output = '/Users/RamRachum/XXXX.txt'
    overwrite = True
    write = get_write_function(output, overwrite)
    assert callable(write)
    output = '/Users/RamRachum/XXXX.txt'
    overwrite = False
    write = get_write_function(output, overwrite)
    assert callable(write)
    output = '/Users/RamRachum/XXXX'
    overwrite = False
    write = get_write_function(output, overwrite)
    assert callable(write)
    output

# Generated at 2022-06-24 17:17:06.874892
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()



# Generated at 2022-06-24 17:17:08.000329
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with tracer_0:
        time.sleep(1)


# Generated at 2022-06-24 17:17:11.179172
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        test_case_0()
    except Exception:
        _, _, traceback_ = sys.exc_info()
        args = None
        kwargs = None
    finally:
        frame = traceback_.tb_frame
        print(get_path_and_source_from_frame(frame))


# Generated at 2022-06-24 17:17:17.681703
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    tracer_0 = Tracer()
    # tracer_0.debug_here()
    filename = inspect.getsourcefile(Tracer)
    frame = inspect.currentframe()
    while frame.f_code.co_filename != filename:
        frame = frame.f_back
    # get_path_and_source_from_frame(frame)
    # get_path_and_source_from_frame(frame.f_back)
    # assert False
    path, source = get_path_and_source_from_frame(frame)
    assert path == filename
    assert source[0].startswith('class Tracer(')
    assert source[-1] == '    return (file_name, source)'
    path, source = get_path_and_source_from_frame(frame.f_back)
    assert path

# Generated at 2022-06-24 17:18:02.993312
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    #
    # This is a system test.
    #
    # The tests, when executed, prints all the traces of
    # the code block after the call to the Tracer()
    # object. The assertions checks for the expected
    # outputs and tries to parse it.
    #

    #
    # Test for case 0
    #
    tracer_0 = Tracer()
    # expected outputs from test case 0.

# Generated at 2022-06-24 17:18:04.251318
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-24 17:18:08.821489
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test execution of instructions trace and return
    with pysnooper.snoop(depth=1):
        pass


# Generated at 2022-06-24 17:18:11.890916
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    tracer_0.trace(frame, event='line', arg={})


# Generated at 2022-06-24 17:18:16.920844
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe()
    event_0 = 'call'
    arg_0 = None
    tracer_0.trace(frame_0, event_0, arg_0)


# Generated at 2022-06-24 17:18:23.041163
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame_0 = sys._getframe()
    path, source = get_path_and_source_from_frame(frame_0)
    line_0 = source[frame_0.f_lineno - 1]
    line_1 = '# Unit test for function get_path_and_source_from_frame'
    assert line_0 == line_1


try:
    import linecache
except ImportError:
    _have_linecache = False
else:
    _have_linecache = True


# Generated at 2022-06-24 17:18:29.018278
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.start_times = {inspect.currentframe().f_back: datetime_module.datetime.now()}
    tracer.__exit__(None, None, None)


# Generated at 2022-06-24 17:18:32.495231
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        pass
    frame = test_function.__code__.co_filename
    result = get_path_and_source_from_frame(frame)


# Generated at 2022-06-24 17:18:42.064451
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    if sys.platform == 'win32':
        path = 'C:\\..\\..\\..\\..\\Python\\Python35\\Lib\\functools.py'