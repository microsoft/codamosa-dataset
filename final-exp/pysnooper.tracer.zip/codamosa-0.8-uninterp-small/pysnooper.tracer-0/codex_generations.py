

# Generated at 2022-06-24 17:09:36.344196
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # This method is called from inside a `with` statement, so we don't
    # get to see it in the output. This is normal.
    # We're testing here that we can handle a situation where the source
    # code is "unavailable" (e.g. pyc files).
    assert test_case_0() == 'hello'


# Generated at 2022-06-24 17:09:39.202692
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    assert True == True



# Generated at 2022-06-24 17:09:48.175961
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = sys._getframe()
    retrieved_locals =  get_local_reprs(frame)
    for key, value in retrieved_locals.items():
        retrieved_locals.pop(key)
        assert key in frame.f_locals
        assert value == utils.get_shortish_repr(frame.f_locals[key])
    assert len(retrieved_locals) == 0


# Generated at 2022-06-24 17:09:54.620982
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    if pycompat.PY3:
        import unittest.mock as mock
    else:
        import mock

    # Current implementation is broken because of multithreading
    #tracer = Tracer(watch=('unavailable_source_0',))
    #mock_trace = mock.Mock()
    #with mock.patch('sys.settrace', new=mock_trace):
    #    mocked_wrapped_func = tracer(test_case_0)
    #    result = mocked_wrapped_func()
    #assert result == None
    #assert mock_trace.called

if __name__ == '__main__':
    test_Tracer___call__()

# Generated at 2022-06-24 17:09:57.816739
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # test cases
    try:
        test_case_0()
    except:
        pass
    finally:
        pysnooper.stop()


# Generated at 2022-06-24 17:10:00.027697
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    my_frame = test_case_0.__code__.co_filename



# Generated at 2022-06-24 17:10:10.034871
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, overwrite=False) == write
    with pycompat.temp_path() as temp_file:
        write_function = get_write_function(temp_file, overwrite=False)
        write_function('bla')
        assert write_function == FileWriter(temp_file, overwrite=False).write
        with open(temp_file, 'r') as f:
            assert f.read() == 'bla'
        write_function = get_write_function(temp_file, overwrite=True)
        assert write_function == FileWriter(temp_file, overwrite=True).write
        write_function('bla')
        with open(temp_file, 'r') as f:
            assert f.read() == 'bla'

# Generated at 2022-06-24 17:10:12.524921
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    try:
        with Tracer(output='stderr'):
            raise Exception()
    except Exception:
        pass


# Generated at 2022-06-24 17:10:17.605235
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    filename_pattern = re.compile('^.*x1.py$')
    assert filename_pattern.match(get_path_and_source_from_frame(
        sys._getframe(0))[0])

    filename_pattern = re.compile('^.*x2.py$')
    assert filename_pattern.match(get_path_and_source_from_frame(
        sys._getframe(0))[0])


# Generated at 2022-06-24 17:10:24.799239
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.trace(None, "call", None)
    tracer.trace(None, "line", None)
    tracer.trace(None, "return", None)
    tracer.trace(None, "exception", None)
    tracer.trace(None, "some other event", None)
    with pytest.raises(AssertionError):
        tracer.trace(None, None, None)


# Generated at 2022-06-24 17:11:01.010365
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with pytest.raises(TypeError):
        test_case_0()


# Generated at 2022-06-24 17:11:05.416853
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    _tm = Tracer()
    _res = _tm.trace(list_0, 'call', 'arg')
    print ("trace", _res)
    if _res is None:
        raise Exception('computation failed!')
    _tm.trace(list_0, 'return', None)
    _tm.trace(list_0, 'exception', None)


# Generated at 2022-06-24 17:11:09.088808
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    DISABLED = False
    list_0 = Tracer()
    var_0 = list_0.trace(None, None, None)

if __name__ == "__main__":
    test_case_0()
    test_Tracer_trace

# Generated at 2022-06-24 17:11:14.849998
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(ZeroDivisionError):
        snoop()(test_case_0)()
    snoop_func = snoop(watch_explode=('var_0', 'list_0'))
    snoop_func(test_case_0)()


test_case_1 = lambda: True
test_case_2 = lambda: True
test_case_3 = lambda: True
test_case_4 = lambda: True
test_case_5 = lambda: True
test_case_6 = lambda: True
test_case_7 = lambda: True
test_case_8 = lambda: True
test_case_9 = lambda: True
test_case_10 = lambda: True
test_case_11 = lambda: True
test_case_12 = lambda: True
test_case_13 = lambda: True
test

# Generated at 2022-06-24 17:11:20.067797
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test 1
    a = lambda x:x
    b = a(3)
    Tracer()(a)


# Generated at 2022-06-24 17:11:22.967926
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pysnooper.snoop(Tracer.trace)
    test_case_0()

# Generated at 2022-06-24 17:11:26.290985
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    obj_0 = Tracer()
    list_0 = None
    var_0 = obj_0.trace(list_0, 'call')
    assert var_0 == None


# Generated at 2022-06-24 17:11:28.691174
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(ValueError):
        with Tracer():
            raise ValueError


# Generated at 2022-06-24 17:11:37.633480
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer() #
    # Attribute(s) of object: Tracer
    print('tracer.depth =', tracer.depth)
    print('tracer.prefix =', tracer.prefix)
    print('tracer.watch =', tracer.watch)
    print('tracer.frame_to_local_reprs =', tracer.frame_to_local_reprs)
    print('tracer.start_times =', tracer.start_times)
    print('tracer.thread_info =', tracer.thread_info)
    print('tracer.thread_info_padding =', tracer.thread_info_padding)
    print('tracer.target_codes =', tracer.target_codes)
    print('tracer.target_frames =', tracer.target_frames)
    print

# Generated at 2022-06-24 17:11:40.858097
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    list_0 = None
    var_0 = Tracer()
    var_0.__exit__(list_0, list_0, list_0)



# Generated at 2022-06-24 17:11:59.787419
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Test whether __exit__ method in snoop.py works.
    __exit__ = True
    assert __exit__


# Generated at 2022-06-24 17:12:02.508954
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()
    assert DISABLED is False
    assert tracer is not None



# Generated at 2022-06-24 17:12:09.858078
# Unit test for function get_local_reprs
def test_get_local_reprs():
    if pycompat.PY2:
        import clr # noqa
        from System import Array # noqa
        from System.Array import CreateInstance # noqa
        from System import Type # noqa
        from System.Collections import IEnumerator, IEnumerable # noqa
    else:
        import System # noqa
        import clr # noqa
        from System import Array # noqa
        from System.Array import CreateInstance # noqa
        from System import Type # noqa
        from System.Collections import IEnumerator, IEnumerable # noqa
    try:
        import System.Collections.Generic # noqa
    except ImportError:
        pass


# Generated at 2022-06-24 17:12:12.846864
# Unit test for constructor of class Tracer
def test_Tracer():
    list_0 = Tracer()
    assert_equals(list_0.__class__, Tracer)


# Generated at 2022-06-24 17:12:18.874025
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # 1
    list_0 = Tracer()
    var_0 = get_path_and_source_from_frame(list_0)
    var_0 = list_0.__exit__(None, None, None)
    var_0 = get_path_and_source_from_frame(list_0)
    assert not var_0


# Generated at 2022-06-24 17:12:21.224704
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    obj = Tracer()
    obj.__exit__(None, None, None)
    # pass


# Generated at 2022-06-24 17:12:29.707453
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    list_0 = [0, 1, 2]
    var_0 = get_path_and_source_from_frame(list_0)
    assert var_0[0] == 'list_0'
    assert var_0[1][1] == '    list_0 = [0, 1, 2]'



# Generated at 2022-06-24 17:12:39.484510
# Unit test for constructor of class Tracer
def test_Tracer():
    print('test_Tracer')
    tracer = Tracer(output='test_Tracer.log',
                    watch=('foo', 'self'),
                    watch_explode=('foo', 'self'),
                    depth=1,
                    prefix='',
                    overwrite=False,
                    thread_info=False,
                    custom_repr=((type1, custom_repr_func1),
                                 (condition2, custom_repr_func2),
                                 (condition3, custom_repr_func3), ...),
                    max_variable_length=100,
                    normalize=False,
                    relative_time=False)
    pass


# Generated at 2022-06-24 17:12:49.284210
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import os
    import sys
    import tempfile
    import pycompat
    import twb_utils
    frame_0 = twb_utils.make_frame()
    f_0 = tempfile.NamedTemporaryFile(prefix='python-utils-',
            suffix='-get_path_and_source_from_frame', delete=False)
    filename_0 = os.path.basename(f_0.name)
    if pycompat.PY2:
        f_0.write(bytes(
            'def test_case_0():\n    list_0 = None\n    var_0 = get_path_and_source_from_frame(list_0)\n'
            ))

# Generated at 2022-06-24 17:12:51.600719
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 17:13:14.146288
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    with open('test_get_path_and_source_from_frame.py', 'w') as f:
        f.write(textwrap.dedent('''
        def hello():
            pass

        test_case_0()
        '''))
    filename, source = get_path_and_source_from_frame(
            sys._getframe().f_back)

    assert (filename, source) == (
        'test_get_path_and_source_from_frame.py',
        ['def hello():',
         '    pass',
         '',
         'test_case_0()']
    )
    os.unlink('test_get_path_and_source_from_frame.py')




# Generated at 2022-06-24 17:13:19.526030
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frameinfo = inspect.getframeinfo(test_case_0)
    path, source = get_path_and_source_from_frame(frameinfo)

    assert os.path.abspath(path) == os.path.abspath(inspect.getfile(test_case_0))
    assert source[7] == "    tracer_0 = Tracer()"


# Generated at 2022-06-24 17:13:27.569942
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """
    Tests the following Tracer class method:
        - trace
    """
    # Testing that trace prints the correct output for a standard function call
    with Tracer(output=test_output_dir.joinpath('test_Tracer_trace_0.log')) as tracer:
        def test_function_0(input_var_0):
            output_var_0 = input_var_0 + 1
            return output_var_0
        output_var_0 = test_function_0(0)


# Generated at 2022-06-24 17:13:30.760418
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe(1)
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def test_case_0():'
    assert source[1] == '    tracer_0 = Tracer()\n'


# Generated at 2022-06-24 17:13:33.094107
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def _test_func():
        pass
    f_code = _test_func.func_code
    print(get_path_and_source_from_frame(_test_func.func_globals))


# Generated at 2022-06-24 17:13:44.732358
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    globs = globals()
    module_name = globs.get('__name__')
    file_name = inspect.getfile(get_path_and_source_from_frame)
    cache_key = (module_name, file_name)

    loader = globs.get('__loader__')
    source = None
    if hasattr(loader, 'get_source'):
        try:
            source = loader.get_source(module_name)
        except ImportError:
            pass
        if source is not None:
            source = source.splitlines()
    if source is None:
        ipython_filename_match = ipython_filename_pattern.match(file_name)
        if ipython_filename_match:
            entry_number = int(ipython_filename_match.group(1))

# Generated at 2022-06-24 17:13:52.912509
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # Initialization
    tracer_0 = Tracer()
    fw = FileWriter('test_file.py', True)
    fw.write('this is test_write_0')
    path = pycompat.text_type('test_file.py')
    # Read data
    fp = open(path, 'r', encoding='utf-8')
    s = fp.read()
    fp.close()
    assert s == u'this is test_write_0'
    # Open in non-overwrite mode and write
    fw = FileWriter('test_file.py', False)
    fw.write('this is test_write_1')
    # Read data
    fp = open(path, 'r', encoding='utf-8')
    s = fp.read()
    fp.close()

# Generated at 2022-06-24 17:13:57.254965
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    tracer_1 = Tracer()
    #print('\n'.join(map(repr, tracer_1.get_source_lines(-10))))


_tracer_marker = object()
_ignoring_tracer_marker = object()



# Generated at 2022-06-24 17:14:10.008159
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False) as tracer_0:
        assert tracer_0 is not None
        #print("tracer_0 = ", tracer_0)
        assert callable(tracer_0)
        #print("callable(tracer_0) = ", callable(tracer_0))
        assert type(tracer_0) == Tracer
        assert hasattr(tracer_0, "__enter__")
        assert hasattr(tracer_0, "__exit__")
        assert inspect.isroutine(tracer_0)


# Generated at 2022-06-24 17:14:21.043302
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    local_time = datetime_module.datetime(2019, 1, 1, 0, 0, 0)
    with mock.patch('datetime.datetime') as mock_datetime:
        mock_datetime.now.return_value = local_time
        tracer_0 = Tracer()
        tracer_0.write = mock.Mock(return_value=None)
        tracer_0.start_times = {'frame_0': local_time}
        tracer_0.relative_time = False
        tracer_0.normalize = False
        with mock.patch('builtins.settrace') as mock_sys_settrace:
            tracer_0.__enter__()
            tracer_0.__exit__(None, None, None)

# Generated at 2022-06-24 17:14:58.778561
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Tracer_0
    tracer_0 = Tracer()

    # Call method __exit__
    tracer_0.__exit__(exc_type=None, exc_value=None, exc_traceback=None)



# Generated at 2022-06-24 17:15:02.817998
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe()
    event_0 = 'call'
    arg_0 = None

    assert tracer_0.trace(frame_0, event_0, arg_0) is None


# Generated at 2022-06-24 17:15:05.335442
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    with tracer_0 as __enter__:
        assert isinstance(__enter__, Tracer)


# Generated at 2022-06-24 17:15:19.563339
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    globs = {'__name__': 'test_get_path_and_source_from_frame',
             '__loader__': 'test_loader'}
    code = test_get_path_and_source_from_frame.__code__
    frame = {'f_globals': globs, 'f_code': code}
    (path, source) = get_path_and_source_from_frame(frame)
    assert source[0] == 'def test_get_path_and_source_from_frame():'
    assert os.path.basename(path) == 'tracer.py'
    assert source[-1] == 'test_case_0()'



# def get_path_and_source_from_frame(frame):
#     globs = frame.f_globals or {}


# Generated at 2022-06-24 17:15:21.950103
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    a = Tracer()
    a.trace(None, None, None)


# Generated at 2022-06-24 17:15:29.244997
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo_bar():
        tracer_0 = Tracer()

    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert (list(source)[:4] == [
        u'def foo_bar():',
        u'    tracer_0 = Tracer()',
        u'',
        u''
    ])


# Generated at 2022-06-24 17:15:45.699036
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test case Tracer_trace_TC_0
    tracer_0 = Tracer()

    # Test case Tracer_trace_TC_1
    tracer_1 = Tracer(custom_repr=((MyCustomClass, my_custom_repr_func),))

    # Test case Tracer_trace_TC_2
    tracer_2 = Tracer(watch=(my_var,))

    # Test case Tracer_trace_TC_3
    tracer_3 = Tracer(watch=('self.foo',))

    # Test case Tracer_trace_TC_4
    tracer_4 = Tracer(watch_explode=(my_list,))

    # Test case Tracer_trace_TC_5
    tracer_5 = Tracer(depth=1)

    # Test case Tracer_trace_TC_6

# Generated at 2022-06-24 17:15:48.416241
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    assert tracer_0._write is sys.stdout.write
    


# Generated at 2022-06-24 17:15:49.176518
# Unit test for method __call__ of class Tracer

# Generated at 2022-06-24 17:15:56.844879
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False) == write
    assert get_write_function(sys.stderr, False) == write
    assert get_write_function(sys.stderr, False).__code__ == write.__code__
    assert get_write_function(utils.WritableStream(sys.stderr), False).__code__ == write.__code__
    try:
        get_write_function(utils.WritableStream(sys.stderr), True)
    except Exception:
        return
    assert False, 'Should not be here'



# Generated at 2022-06-24 17:17:12.217207
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()
    for attr in ['_write', 'watch', 'frame_to_local_reprs', 'start_times',
                'depth', 'prefix', 'thread_info', 'thread_info_padding',
                'target_codes', 'target_frames', 'thread_local',
                'custom_repr', 'last_source_path', 'max_variable_length']:
        assert hasattr(tracer, attr), \
                "The class Tracer has no attribute named {}".format(attr)
    # test Tracer.__init__(self, output=None, watch=(), watch_explode=(), depth=1,
    # prefix='', overwrite=False, thread_info=False, custom_repr=(),
    # max_variable_length=100, normalize=False):
    tracer_

# Generated at 2022-06-24 17:17:13.999515
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    try:
        get_path_and_source_from_frame(f.__globals__)
    except Exception:
        pass


# Generated at 2022-06-24 17:17:20.100566
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    print('Running test method test_Tracer___exit__...')
    global DISABLED
    DISABLED = False
    try:
        test_Tracer___exit___0()
        test_Tracer___exit___1()
        test_Tracer___exit___2()
        DISABLED = True
    finally:
        DISABLED = True
    print('Done.')


# Generated at 2022-06-24 17:17:27.786019
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    assert isinstance(tracer, Tracer)

    @tracer
    def func(x, y):
        return x + y

    assert isinstance(func, types.FunctionType)
    assert func(1, 2) == 3

    @tracer
    def func_gen(x, y):
        yield x
        yield y

    assert isinstance(func_gen, types.FunctionType)
    assert isinstance(func_gen(1, 2), types.GeneratorType)
    assert list(func_gen(1, 2)) == [1, 2]

    @tracer
    def func_exception():
        1/0

    with pytest.raises(ZeroDivisionError) as excinfo:
        func_exception()


# Generated at 2022-06-24 17:17:35.495976
# Unit test for function get_write_function
def test_get_write_function():
    function_0 = get_write_function(None, None)
    assert function_0(u'fuck!') == None
    function_1 = get_write_function(u'./log.txt', True)
    assert isinstance(function_1, FileWriter)
    function_2 = get_write_function(u'fuck you!', None)
    assert isinstance(function_2, FileWriter)
    function_3 = get_write_function(test_case_0, None)
    assert function_3(u'fuck!') == None


# Generated at 2022-06-24 17:17:40.195891
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import site, tempfile
    test_file_name = tempfile.mkstemp()[1]
    test_frame = inspect.currentframe()
    test_args = (test_frame,)
    test_kwargs = {}
    test_result = get_path_and_source_from_frame(*test_args, **test_kwargs)
    assert test_result[0] == site.__file__


# Generated at 2022-06-24 17:17:42.874218
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    with tracer_0:
        pass


# Generated at 2022-06-24 17:17:48.410286
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    output_0 = io.StringIO()
    try:
        tracer_0._write = get_write_function(output_0, False)
    except Exception as e:
        raise e
    frame_0 = inspect.currentframe()
    while frame_0.f_code.co_filename.endswith('snooper.py'):
        frame_0 = frame_0.f_back
    assert frame_0.f_code.co_filename in ('snooper.py', 'test_snooper.py',
                                          'snooper/snooper.py')
    assert frame_0.f_lineno == 81
    event_0 = 'line'
    assert arg_0 is None
    #--------------------------------------------------------------------------
    # First iteration of loop:
    assert frame

# Generated at 2022-06-24 17:17:52.043984
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    def func_0():
        pass
    pysnooper.snoop()(func_0)


# Generated at 2022-06-24 17:18:01.906138
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        tracer_0 = Tracer()

    def bar():
        import test_tracer
        test_tracer.test_case_0()

    frame_0 = inspect.currentframe().f_back
    frame_1 = frame_0.f_back
    path_0, source_0 = get_path_and_source_from_frame(frame_0)
    path_1, source_1 = get_path_and_source_from_frame(frame_1)
    assert path_0 == frame_0.f_code.co_filename
    assert path_1 == frame_1.f_code.co_filename
    assert source_0[frame_0.f_lineno - 1].strip() == \
           "tracer_0 = Tracer()"