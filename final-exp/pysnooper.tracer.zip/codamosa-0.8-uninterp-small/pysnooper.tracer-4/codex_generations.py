

# Generated at 2022-06-24 17:09:53.006424
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert inspect.getsource(test_case_0) == u'    unavailable_source_0 = UnavailableSource()\n'
    _, source = get_path_and_source_from_frame(inspect.currentframe())
    assert len(source) == 2
    assert source[0].endswith('inspect.py')
    assert source[1] == u'    unavailable_source_0 = UnavailableSource()'



# Generated at 2022-06-24 17:09:57.211162
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    current_frame = inspect.currentframe()
    temp_module_name = 'temp_module'
    temp_file_name = 'temp_module.py'
    open(temp_file_name, 'ab').close()
    file_name, source = get_path_and_source_from_frame(current_frame)
    assert file_name == __file__
    assert source != unavailable_source_0

    try:
        os.unlink(temp_file_name)
    finally:
        del current_frame


# Variable for the unit test:
unavailable_source_0 = UnavailableSource()
del test_case_0



# Generated at 2022-06-24 17:10:08.667188
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with raises(AssertionError):
        t = Tracer(max_variable_length=-1)
    t = Tracer()
    assert 'depth' not in thread_global.__dict__
    assert 'original_trace_functions' not in t.thread_local.__dict__

    # Test that a function with no arguments and no return value works
    def function_0():
        pass
    function_0 = t(function_0)
    function_0()

    assert 'depth' in thread_global.__dict__
    assert 'original_trace_functions' in t.thread_local.__dict__

    # Test that a function with arguments and no return value works
    def function_1(a):
        pass
    function_1 = t(function_1)
    function_1(1)

    # Test that a function

# Generated at 2022-06-24 17:10:11.479056
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        test_case_0()
    except Exception:
        frame = sys.exc_info()[2].tb_frame.f_back
        assert get_path_and_source_from_frame(frame)[1] is unavailable_source_0


# Generated at 2022-06-24 17:10:19.888499
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global unavailable_source_0
    unavailable_source_0 = UnavailableSource()
    curframe = inspect.currentframe()
    calframe = inspect.getouterframes(curframe, 2)
    framedata = calframe[1][0]
    if hasattr(framedata, 'f_locals'):
        framelocals = framedata.f_locals
        frame_args = [framelocals[x] for x in ['exc_type', 'exc_value', 'exc_traceback']]
        if len(frame_args)==3:
            exc_type, exc_value, exc_traceback = frame_args
        else:
            exc_type = None
            exc_value = None
            exc_traceback = None
    else:
        exc_type = None
        exc_value = None
        exc

# Generated at 2022-06-24 17:10:23.675286
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    test_case_0()


# Generated at 2022-06-24 17:10:30.607349
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():

    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='',
                    overwrite=False, thread_info=False, custom_repr=(),
                    max_variable_length=100, normalize=False,
                    relative_time=False)
    # case 0
    function_or_class = test_case_0
    try:
        # call the method
        tracer.__call__(function_or_class)
    except:
        pass
    else:
        assert False



# Generated at 2022-06-24 17:10:33.338759
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert pycompat.iscoroutinefunction(Tracer().__call__(test_case_0)) == False


# Generated at 2022-06-24 17:10:39.437914
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path_0 = os.getcwd() + '/.fc/temp/test_FileWriter_write/existing_file'
    overwrite_0 = True
    file_writer_0 = FileWriter(path=path_0, overwrite=overwrite_0)
    text_0 = 'Hello world!'
    file_writer_0.write(s=text_0)
    with open(path_0, 'r') as file_0:
        content_0 = file_0.read()
    assert content_0 == text_0

test_case_0.test_case_id = 'e6e16c6a-a6ba-4e10-a6eb-b9af1898dbbc'
test_case_0.test_case_description = 'Test case for method write of class FileWriter: overwrite existing file'
test_

# Generated at 2022-06-24 17:10:52.263110
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import imp
    import linecache
    import tempfile
    import sys
    
    filename = tempfile.mktemp()
    with open(filename, 'w') as f:
        f.write('\n'.join(['line %d' % i for i in range(1, 101)]))
    
    module = imp.new_module('source_loader_test')
    module.__file__ = filename
    module.__loader__ = None
    assert get_path_and_source_from_frame(sys._getframe())[0] == __file__
    assert get_path_and_source_from_frame(sys._getframe())[1] == \
           linecache.getlines(__file__)
    sys.modules['source_loader_test'] = module


# Generated at 2022-06-24 17:11:26.339561
# Unit test for constructor of class Tracer
def test_Tracer():
    # test empty watch
    try:
        tracer_0 = Tracer(watch=())
        assert True
    except Exception as e:
        print(e)
        assert False
    # test empty watch_explode
    try:
        tracer_1 = Tracer(watch_explode=())
        assert True
    except Exception as e:
        print(e)
        assert False
    # test valid watch_explode
    try:
        tracer_2 = Tracer(watch_explode=('self',))
        assert True
    except Exception as e:
        print(e)
        assert False
    # test valid prefix
    try:
        tracer_3 = Tracer(prefix='ZZZ ')
        assert True
    except Exception as e:
        print(e)
        assert False
    # test invalid custom

# Generated at 2022-06-24 17:11:35.743226
# Unit test for function get_local_reprs

# Generated at 2022-06-24 17:11:40.923473
# Unit test for function get_local_reprs
def test_get_local_reprs():
    result = get_local_reprs(sys._getframe(0))
    assert result == {'test_case_0': '<function test_case_0 at 0x',
                      'unavailable_source_0': '<__main__.UnavailableSource instance at 0x'}


# Generated at 2022-06-24 17:11:45.380389
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    test_case_0()
    # Does `@pysnooper.snoop(watch=('foo', 'self'))` work?
    pysnooper.snoop(watch=('unavailable_source_0', 'self'), depth=2,
                    max_variable_length=None, normalize=True)(test_case_0)()


# Generated at 2022-06-24 17:11:54.141005
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # 1
    unavailable_source_0 = UnavailableSource()
    def unavailable_source_0_func_0(unavailable_source_0_arg_0):
        # 1
        unavailable_source_0_func_0_var_0 = unavailable_source_0_arg_0
        # 2
        unavailable_source_0_func_0_var_1 = unavailable_source_0_func_0_var_0 * unavailable_source_0_func_0_var_0

        # 3
        unavailable_source_0_func_0_var_2 = unavailable_source_0_func_0_var_1 + unavailable_source_0_func_0_var_1
        # 4
        unavailable_source_0_func_0_var_3 = unavailable_source_0_func_0_var_2 - unavailable_source

# Generated at 2022-06-24 17:11:59.220720
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pytest.raises(Exception, match="No source code is available"):
        tracer = Tracer()
        tracer.__call__(test_case_0)()


# Generated at 2022-06-24 17:12:02.372453
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    try:
        tracer = Tracer()
        tracer.__enter__()
        assert True
    except:
        assert False


# Generated at 2022-06-24 17:12:09.815233
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def source_function():
        return get_path_and_source_from_frame(sys._getframe())

# Generated at 2022-06-24 17:12:15.362197
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Test that function works correctly when source is unavailable
    try:
        test_case_0()
    except Exception:
        frame_0 = utils.get_last_frame()
        assert get_path_and_source_from_frame(frame_0) == \
               (__file__, unavailable_source_0)


# Unit tests for function `get_local_reprs`.

# Generated at 2022-06-24 17:12:20.050080
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    s = io.StringIO()
    tracer = Tracer(output=s)
    tracer.__call__(unavailable_source_0)
    s.reset()
    tracer.write('hi')
    assert s.getvalue().endswith('hi\n')



# Generated at 2022-06-24 17:12:49.249342
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os.path
    path = os.path.join(os.path.dirname(__file__), 'test_FileWriter.txt')
    writer = FileWriter(path, overwrite=True)
    # Write empty string
    writer.write('')
    # Write a non-empty string
    writer.write('abc')
    # Another non-empty one
    writer.write('xyz')
    # Read the content of the file
    with open(path) as f:
        content = f.read()
    assert content == 'abcxyz'



# Generated at 2022-06-24 17:12:59.482572
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Test a script in the same folder as this module
    def _test_0():
        tracer_0 = Tracer()
    test_case_0_frame = sys._getframe(0)
    assert get_path_and_source_from_frame(test_case_0_frame) == \
           (test_case_0_frame.f_code.co_filename, test_case_0.__code__.co_code.splitlines())

    # Test an IPython session
    import IPython
    ipython_shell = IPython.InteractiveShell.instance()
    try:
        ipython_shell.magic('run tracer_tests.py')
    except:
        pass # Consider this a failure of this test

# Generated at 2022-06-24 17:13:06.581133
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():

    tracer = Tracer()

    def function():
        print('in function')

    def function_generator():
        yield 1
        yield 2

    def function_generator_with_loop():
        for i in range(10):
            yield i
        for i in range(10):
            yield i

    def function_with_exception():
        print('in function')
        raise Exception('this is an exception')

    def function_with_exception_after_returning():
        print('in function')
        return 1
        raise Exception('this is an exception')

    def function_with_exception_in_generator():
        yield 1
        yield 2
        raise Exception('this is an exception')

    function_instance = function()

    function_generator_instance = function_generator()
    function_generator_instance

# Generated at 2022-06-24 17:13:20.055470
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    code = \
    r"""def test_case_1():
        a = 1
        b = 2
        c = a + b

        def sub_function(c):
            d = c + 1
            return d

        e = sub_function(c)"""

    test_case_1_code = compile(code, '<string>', 'exec')
    tracer_1 = Tracer()

    frame_1 = FrameType(None, -1, False, {}, test_case_1_code)

    frame_1.f_lineno = 0

    event_0 = 'call'
    arg_0 = None

    # Call the method
    output_1 = tracer_1.trace(frame_1, event_0, arg_0)

    assert output_1 == tracer_1.trace


# Generated at 2022-06-24 17:13:29.326981
# Unit test for function get_write_function
def test_get_write_function():
    assert callable(get_write_function(None, False)) is True
    assert callable(get_write_function('test.txt', False)) is True
    assert callable(get_write_function(None, True)) is False
    assert callable(get_write_function('test.txt', True)) is True
    assert callable(get_write_function(sys.stdout.write, False)) is True
    assert callable(get_write_function(sys.stdout, True)) is False
# End unit test for function get_write_function


# Generated at 2022-06-24 17:13:39.430730
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = test_case_0()
    result = get_path_and_source_from_frame(frame)
    file_name = result[0]
    source = result[1]
    assert file_name == os.path.abspath(os.path.join(os.path.dirname(__file__), 'tracer_tests.py'))
    assert (source[90] == 'def test_case_0():' and
            source[91] == '    tracer_0 = Tracer()' and
            source[92] == '    return inspect.currentframe()' and
            source[93] == '    # test_case_0')



# Generated at 2022-06-24 17:13:47.000681
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def inner():
        def innermost():
            test_case_0()
        innermost()
    inner()
    this_module_filename = __file__
    if this_module_filename.endswith(('.pyc', '.pyo')):
        this_module_filename = this_module_filename[:-1]
    assert (get_path_and_source_from_frame(sys._getframe(0)) == (
                                                     this_module_filename,
                                                     inspect.getsourcelines(
                                                           test_case_0)[0]))



# Generated at 2022-06-24 17:14:00.514904
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import functools
    import inspect
    import pysnooper
    import pytest
    from pysnooper.tracing import Tracer
    from pysnooper.utils import get_write_function, get_path_and_source_from_frame, utils
    from io import StringIO
    from pysnooper import BaseVariable, CommonVariable
    from types import FrameType
    from enum import Enum
    from pycompat import pycompat, six
    pycompat.set_function_flags(sys.gettrace, write=True)
    tracer_0 = Tracer()
    function_or_class = None
    class_0 = tracer_0._wrap_class(function_or_class)
    function_or_class = None

# Generated at 2022-06-24 17:14:10.651877
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back
    event_0 = 'call'
    arg_0 = None
    local_reprs_0 = {'var': 'None', 'var_0': 'None', 'var_1': 'None', 'var_2': 'None', 'var_3': 'None', 'var_4': 'None', 'var_5': 'None', 'var_6': 'None', 'var_7': 'None', 'var_8': 'None', 'var_9': 'None'}
    old_local_reprs_0 = {'var_10': 'None', 'var_11': 'None'}

# Generated at 2022-06-24 17:14:21.527079
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import inspect
    import functools
    import os
    import sys
    import datetime
    import threading
    import traceback
    import os
    import sys
    import pycompat
    import traceback
    import threading
    import functools
    import datetime
    import inspect
    import inspect
    import functools
    import os
    import sys
    import datetime
    import threading
    import traceback
    import os
    import sys
    import pycompat
    import traceback
    import threading
    import functools
    import datetime
    import inspect
    import inspect
    import functools
    import os
    import sys
    import datetime
    import threading
    import traceback
    import os
    import sys
    import pycompat
   

# Generated at 2022-06-24 17:15:05.373456
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    with pytest.raises(TypeError):
        tracer_0.trace()


# Generated at 2022-06-24 17:15:13.012469
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_func():
        def inner():
            test_case_0()  # noqa
        inner()
    frame = utils.get_frame(test_func)
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name.endswith('test_tracer.py')




# Generated at 2022-06-24 17:15:22.082242
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    assert tracer_0._write is sys.stdout.write
    assert tracer_0.watch == []
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ''
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.thread_local.__class__.__name__ == 'threading._local'
    assert tracer_0.custom_repr == ()
    assert tracer_0.last_source_path is None
    assert tracer_0.max_variable_length == 100

# Generated at 2022-06-24 17:15:24.315540
# Unit test for constructor of class Tracer
def test_Tracer():
    # test_case_0()
    print(test_case_0.__doc__)


# Generated at 2022-06-24 17:15:31.254387
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        test_case_0()
        print('Function name is',
              get_path_and_source_from_frame(sys._getframe(0))[0])
        print('Line 1 is',
              get_path_and_source_from_frame(sys._getframe(0))[1][0])
    except:
        traceback.print_exc()
        print('\n\n')
        traceback.format_exc()
        print('\n\n')


# Generated at 2022-06-24 17:15:45.653754
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    assert(result[0].endswith('/inspect_utils.py'))
    assert(result[1][0].startswith('def test_get_path_and_source_from_frame():'))
    frame = frame.f_back
    result = get_path_and_source_from_frame(frame)
    assert(result[0].endswith('/tracer.py'))
    assert(result[1][0].startswith('class Tracer(object):'))
    assert(result[1][1].startswith('    def __init__(self'))


# Generated at 2022-06-24 17:15:48.751950
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()

    # Call method trace
    # prepare variables
    tracer_0.trace(None, None, None)



# Generated at 2022-06-24 17:15:53.353825
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__()

if __name__ == '__main__':
    import sys
    import doctest

    print(doctest.testmod(
        sys.modules[__name__],
        optionflags=doctest.NORMALIZE_WHITESPACE
    ))

# Generated at 2022-06-24 17:16:00.981387
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__enter__ = MagicMock(name = '__enter__')
    tracer_0_enter = tracer_0.__enter__

    __exit__ = tracer_0.__exit__
    tracer_0.__exit__ = MagicMock(name = '__exit__', wraps = __exit__)
    tracer_0_exit = tracer_0.__exit__

    tracer_0.__enter__ = tracer_0_enter
    tracer_0.__enter__.__enter__ = MagicMock(name = '__enter__.__enter__')
    tracer_0_enter_enter = tracer_0.__enter__.__enter__


# Generated at 2022-06-24 17:16:08.885939
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_func():
        tracer_0 = Tracer()
        x = 10
        print(x)

    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    for _ in range(4):
        frame = frame.f_back
    assert frame.f_code.co_name == 'test_func'
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name.endswith('snoopum.py')
    assert source[2] == '    tracer_0 = Tracer()'


# Generated at 2022-06-24 17:17:25.457210
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer(False)
    assert (tracer_0.__call__(tracer_0) != tracer_0)
    assert (tracer_0.__call__(tracer_0) != tracer_0)


# Generated at 2022-06-24 17:17:35.806181
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    print('Starting unit test for FileWriter.write')
    path = os.path.join(os.path.dirname(__file__),'FileWriter_test.txt')
    fileWriter = FileWriter(path, True)

    print('fileWriter = ', fileWriter)
    print('fileWriter.write(''Hello World\n'')')
    fileWriter.write('Hello World\n')

    print('fileWriter.write(''Hello World2\n'')')
    fileWriter.write('Hello World2\n')

    print('fileWriter.write(''Hello World3\n'')')
    fileWriter.write('Hello World3\n')

    print('Ending unit test for FileWriter.write')
    


# Generated at 2022-06-24 17:17:38.222899
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    function_or_class_0 = '_'
    tracer_0.__call__(function_or_class_0)


# Generated at 2022-06-24 17:17:44.967770
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    class TestVar(CommonVariable):
        def __init__(self, name):
            self.name = name
        def items(self, frame, normalize):
            if normalize:
                return [(self.name, 'value1'), (self.name, 'value2')]
            else:
                return [(self.name, 'value1'), (self.name, 'value2')]
        def to_string(self, normalize):
            return self.name

    def test_function_0():
        """This is a function in which we get locals, it has no args."""
        var_0 = 0
        var_1 = 1

    def test_function_1(arg_0, arg_1):
        """This is a function in which we get locals, it has args."""
        var_0 = 0
        var_1

# Generated at 2022-06-24 17:17:49.575456
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    start_time = datetime_module.datetime.now()
    test_case_0()
    elapsed_time = datetime_module.datetime.now() - start_time
    assert elapsed_time < datetime_module.timedelta(seconds=1)



# Generated at 2022-06-24 17:17:52.235309
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    assert type(tracer_0.trace) == types.FunctionType



# Generated at 2022-06-24 17:17:54.171452
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as snooper:
        pass
    return True


# Generated at 2022-06-24 17:17:58.687470
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    #assert isinstance(tracer_0, Tracer), "tracer_0 is not instance of Tracer"
    test_case_0()
    print("Test Tracer completed")


# Generated at 2022-06-24 17:18:02.572492
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    'Unit test for method __exit__ of class Tracer'
    sut = tracer_0
    assert not sut.__exit__(None, None, None)
# test_case_0()



# Generated at 2022-06-24 17:18:03.837923
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()
