

# Generated at 2022-06-24 17:09:37.884399
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    tracer_0.target_codes.add("some_code")
    tracer_0.target_frames.add("some_frame")
    with tracer_0:
        assert tracer_0._is_internal_frame("some_frame") == None
        assert tracer_0._is_internal_frame("some_other_frame") == None
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.thread_local.original_trace_functions == []
    assert tracer_0.start_times == {}
    assert tracer_0.normalize == False
    assert tracer_0.max_variable_length == 100

    tracer_1 = Tracer()
    tracer_1.target

# Generated at 2022-06-24 17:09:45.762642
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_path_and_source_from_frame_in_test():
        def func():
            pass
        frame = sys._getframe()
        cur_locals = frame.f_locals
        cur_globals = frame.f_globals
        get_path_and_source_from_frame()
    get_path_and_source_from_frame_in_test()


# Generated at 2022-06-24 17:09:47.964115
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    exc_type_1 = None
    exc_value_1 = None
    exc_traceback_1 = None
    tracer_0.__exit__(exc_type_1, exc_value_1, exc_traceback_1)


# Generated at 2022-06-24 17:09:52.548612
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    foo = 1
    tracer_0 = Tracer()
    tracer_1 = Tracer()
    function_or_class = foo
    test_case_0()
    tracer_0._wrap_class(function_or_class)
    tracer_1._wrap_function(function_or_class)
    assert function_or_class == foo
    assert tracer_0 == tracer_1


# Generated at 2022-06-24 17:10:06.204303
# Unit test for constructor of class Tracer
def test_Tracer():
    assert not DISABLED
    tracer_1 = Tracer()
    assert tracer_1.watch == ()
    assert tracer_1.depth == 1
    assert tracer_1.prefix == ''
    assert tracer_1.thread_info is False
    assert tracer_1.custom_repr == ()
    assert tracer_1.target_codes == set()
    assert tracer_1.target_frames == set()
    assert tracer_1.thread_info_padding == 0
    assert tracer_1.start_times == {}
    assert tracer_1.frame_to_local_reprs == {}
    assert tracer_1.last_source_path == None
    assert tracer_1.max_variable_length == 100
    assert tracer_1.normalize is False
    assert tracer_

# Generated at 2022-06-24 17:10:08.860411
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back
    event_0 = 'call'
    arg_0 = None
    tracer_0.trace(frame_0, event_0, arg_0)


# Generated at 2022-06-24 17:10:12.343326
# Unit test for function get_write_function
def test_get_write_function():
    output = 'test.txt'
    overwrite = True
    # Get writer function
    write = get_write_function(output, overwrite)

    # Write output to file
    write(to_unicode('Test output'))
    # Should see the content in test.txt

    # Remove the file
    os.remove(output)



# Generated at 2022-06-24 17:10:15.074469
# Unit test for function get_write_function
def test_get_write_function():
    tracer_0 = test_case_0()
    tracer_0.stop()
    tracer_0.start()
    tracer_0.stop()
    assert tracer_0._get_write_function() != None


# Generated at 2022-06-24 17:10:19.211023
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    FileWriter(pycompat.PathLike('/'), False).write('')
    FileWriter(pycompat.PathLike('/'), True).write('')
    FileWriter(pycompat.PathLike('/'), True).write('')



# Generated at 2022-06-24 17:10:22.088552
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    try:
        tracer_0.__enter__()
    except:
        assert False


# Generated at 2022-06-24 17:10:51.021010
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    file_name, source = get_path_and_source_from_frame(frame)

# Generated at 2022-06-24 17:10:56.540677
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    assert tracer._write()
    assert tracer.watch
    assert tracer.frame_to_local_reprs
    assert tracer.start_times
    assert tracer.depth > 0
    assert tracer.prefix
    assert tracer.thread_info
    assert tracer.thread_info_padding >= 0
    assert tracer.target_codes
    assert tracer.target_frames
    assert tracer.thread_local
    assert tracer.custom_repr
    assert tracer.last_source_path
    assert tracer.max_variable_length > 0
    assert tracer.normalize
    assert tracer.relative_time

# Generated at 2022-06-24 17:11:01.500059
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import tempfile
    with tempfile.NamedTemporaryFile('w', suffix='.py') as py_file:
        py_file.write('\n')
        py_file.flush()
        file_name, source = get_path_and_source_from_frame(
            inspect.currentframe())
        assert file_name == py_file.name
        assert source == ['\n']


# Generated at 2022-06-24 17:11:04.974860
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    assert isinstance(tracer_0, Tracer)
    tracer_0.__enter__()
    # assert_equal(expected, Tracer.__enter__(self))
    raise NotImplementedError()


# Generated at 2022-06-24 17:11:07.085465
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_1 = Tracer()
    tracer_2 = Tracer(depth=5)
    tracer_3 = Tracer(depth=5, relative_time=True)
    assert tracer_1.trace(None, None, None) == None


# Generated at 2022-06-24 17:11:12.463610
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    currentdir = os.path.dirname(os.path.realpath(__file__))
    frame1 = inspect.currentframe()
    fullpath = currentdir + "/tracer.py"
    line_number = test_case_0.__code__.co_firstlineno
    source = file_name, source = get_path_and_source_from_frame(frame1)
    expected_filepath = fullpath
    expected_lines = open(fullpath, 'rb').read().splitlines()
    #epxected_lines = [x.decode('utf-8') for x in expected_lines]
    expected_lines = [pycompat.text_type(x, 'utf-8', 'replace') for x in
                      expected_lines]

# Generated at 2022-06-24 17:11:24.555210
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()

    def tracer_0_trace_0(frame_0, event_0, arg_0):
        return tracer_0.trace(frame_0, event_0, arg_0)

    def tracer_0_trace_1(frame_0, event_0, arg_0):
        return tracer_0.trace(frame_0, event_0, arg_0)

    with open(os.path.join(os.path.dirname(__file__), '../tests/trace.py'), 'r') as trace_0_pysnooper_py:
        exec(compile(trace_0_pysnooper_py.read(), 'trace.py', 'exec'), {'__file__': 'trace.py'})



# Generated at 2022-06-24 17:11:28.078434
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    try:
        tracer_0.trace(frame=None, event=None, arg=None)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 17:11:29.431677
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_case_0()


# Generated at 2022-06-24 17:11:34.024920
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import random
    tracer_0 = Tracer()
    with utils.redirect_stdout() as tmp_stdout:
        try:
            exit_value_0 = tracer_0.__exit__(None, Exception(), None)
            exception_raised_0 = False
        except:
            exception_raised_0 = True
    assert not exception_raised_0


# Generated at 2022-06-24 17:12:22.013465
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    globals_dict1 = {'__name__': '__main__'}
    globals_dict2 = {
        '__name__': '__main__',
        '__loader__': None
    }
    globals_dict3 = {
        '__name__': '__main__',
        '__loader__': __loader__
    }
    co_filename = '<ipython-input-1-e1a25a2e5145>'
    class Frame():
        f_globals = {}
        code = type('Code', (), {'co_filename': co_filename})
    frame = Frame()
    frame.f_globals = None
    path, source = get_path_and_source_from_frame(frame)
    assert path == co_filename
    assert source == UnavailableSource()


# Generated at 2022-06-24 17:12:27.620362
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    with tracer_0:
        pass


# Generated at 2022-06-24 17:12:30.292355
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__('exc_type_arg_0', 'exc_value_arg_1', 'exc_traceback_arg_2')


# Generated at 2022-06-24 17:12:36.440915
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    fw = FileWriter(os.path.join(os.getcwd(), 'test.txt'), True)
    test_str = '''test write'''
    fw.write(test_str)
    with open(fw.path, 'r') as f:
        assert f.readline() == test_str, 'test FileWriter.write() failed'
    os.remove(fw.path)



# Generated at 2022-06-24 17:12:45.983172
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test keyword overload for argument function_or_class in method Tracer.__call__
    # test_Tracer___call___1
    # Test a function
    def foo():
        pass
    foo = Tracer()(foo)
    # test_Tracer___call___2
    # Test a class
    class Foo:
        pass
    Foo = Tracer()(Foo)
    # test_Tracer___call___3
    # Test a subclass
    class Bar(Foo):
        pass
    Bar = Tracer()(Bar)
    # test_Tracer___call___4
    # Test a decorated class
    @Tracer()
    class Bar:
        pass


# Generated at 2022-06-24 17:12:52.587023
# Unit test for function get_write_function
def test_get_write_function():
    import io
    from contextlib import redirect_stdout, redirect_stderr
    from StringIO import StringIO

    # Redirect stdout and stderr
    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout = StringIO()
    sys.stderr = StringIO()
    print("Hello, world")
    print("This should be the new stdout", file=sys.stdout)
    print("This should be the new stderr", file=sys.stderr)
    new_stdout, new_stderr = sys.stdout, sys.stderr
    sys.stdout = old_stdout
    sys.stderr = old_stderr

    # Test for None
    write = get_write_function(None, False)
   

# Generated at 2022-06-24 17:12:57.996289
# Unit test for constructor of class Tracer
def test_Tracer():
    #Case 0, invalid argument
    try:
        test_case_0()
    except TypeError:
        print('Test case 0 passed')

# Test for if write works in constructor

# Generated at 2022-06-24 17:13:00.122757
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__(ValueError, AssertionError, None)


# Generated at 2022-06-24 17:13:10.001500
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import io
    import unittest
    class TestCase(unittest.TestCase):
        def test_0(self):
            calling_frame = inspect.currentframe().f_back
            file_name, source = get_path_and_source_from_frame(calling_frame)
            self.assertEqual(file_name, __file__)
            self.assertEqual(source,
                             inspect.getsourcelines(test_case_0)[0])

    suite = unittest.TestLoader().loadTestsFromTestCase(TestCase)
    unittest.TextTestRunner(stream=io.StringIO(), verbosity=2).run(suite)
    print('')



# Generated at 2022-06-24 17:13:12.321711
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writer = FileWriter('Dummy path', True)
    writer.write("This is a test")


# Generated at 2022-06-24 17:13:43.498642
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    try:
        test_cases = [test_case_0, ]
    except:
        logging.error("Import error. Below is the traceback.")
        traceback.print_exc()
        return

    for case in test_cases:
        try:
            logging.info("\nRunning test case: %s", case.__name__)
            case()
        except KeyboardInterrupt:
            logging.info("\nInterrupted by KeyboardInterrupt")


# Generated at 2022-06-24 17:13:45.837172
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    tracer_1 = Tracer()
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    print(path)
    print(source)


# Generated at 2022-06-24 17:13:50.163392
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func():
        a = 1

    tracer = Tracer()
    tracer.trace_function(func)

    def func_custom_repr():
        a = 1
        b = lambda: 'hello'
        c = [a, b]

    tracer = Tracer()
    tracer.trace_function(func_custom_repr)


# Generated at 2022-06-24 17:14:00.037912
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_1 = Tracer()
    try:
        tracer_1.__exit__(None, None, None)
    except:
        pass
    try:
        tracer_1.__exit__(object, None, None)
        raise AssertionError
    except:
        pass
    try:
        tracer_1.__exit__(None, object, None)
        raise AssertionError
    except:
        pass
    try:
        tracer_1.__exit__(None, None, object)
        raise AssertionError
    except:
        pass


# Generated at 2022-06-24 17:14:10.229981
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    assert tracer_0._write != None
    assert tracer_0.write != None
    assert tracer_0.watch != []
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.depth == 1
    assert tracer_0.prefix == ""
    assert tracer_0.thread_info == False
    assert tracer_0.thread_info_padding == 0
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert tracer_0.custom_repr == ()
    assert tracer_0.last_source_path == None
    assert tracer_0.max_variable_length == 100

# Generated at 2022-06-24 17:14:13.168477
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    tracer_0.__call__(test_case_0)
    tracer_0.__call__(test_case_0)


# Generated at 2022-06-24 17:14:15.778040
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    function_or_class = tracer_0
    assert tracer_0.__call__(function_or_class) is None


# Generated at 2022-06-24 17:14:19.978309
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # TEST 0
    ## Test with using not enough parameters of method trace.
    try:
        tracer_0 = Tracer()
        tracer_0.trace()
    except TypeError:
        pass
    else:
        print('Test failed!')


# Generated at 2022-06-24 17:14:29.239969
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    obj_0 = Tracer()
    # operand_1 is a random python object
    operand_1 = object.__new__(Tracer)
    operand_1.__init__()
    # operand_2 is a random python object
    operand_2 = object.__new__(Tracer)
    operand_2.__init__()
    # operand_3 is a random python object
    operand_3 = object.__new__(Tracer)
    operand_3.__init__()
    try:
        ret_0 = obj_0.trace(operand_1,operand_2,operand_3)
    except:
        print('Exception raised')
    else:
        print()

if __name__ == '__main__':
    # test_case_0()
    test

# Generated at 2022-06-24 17:14:31.140238
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.__exit__(None, None, None)

# Generated at 2022-06-24 17:14:58.779411
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writer = FileWriter('test_FileWriter_write.txt', False)
    writer.write('test string 1')
    writer.write('test string 2')
    writer.write('test string 3')
    writer('test string 4')
    writer('test string 5')
    writer('test string 6')
    os.remove('test_FileWriter_write.txt')



# Generated at 2022-06-24 17:15:08.533471
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .tracer import Tracer

    globals_dict = globals()
    fake_frame = inspect.currentframe()

# Generated at 2022-06-24 17:15:19.378917
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    test_0 = FileWriter('test_0.check', overwrite=True)
    test_0.write('hello world')
    with open('test_0.check', 'r') as check_file:
        check_content_0 = check_file.read()
        assert 'hello world' == check_content_0

    test_1 = FileWriter('test_0.check', overwrite=False)
    test_1.write('hi')
    with open('test_0.check', 'r') as check_file:
        check_content_1 = check_file.read()
        assert check_content_0 + 'hi' == check_content_1[-12:]



# Generated at 2022-06-24 17:15:24.923193
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def inner_function(a):
        (file_name, source) = get_path_and_source_from_frame(inspect.currentframe())
        print('The source of this function is', source)
        print('The file name of this function is', file_name)

        # manually read the source of inner_function
        with open(os.path.join(os.path.dirname(__file__), 'async_tools.py'),
                  'r',
                  encoding='utf-8') as f:
            text = f.read()
        # manually split the source
        lines = text.split('\n')
        indent = None
        for i in range(len(lines) - 1, -1, -1):
            line = lines[i]
            if 'def inner_function(a):' in line:
                indent

# Generated at 2022-06-24 17:15:28.688283
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import doctest
    doctest.run_docstring_examples(get_path_and_source_from_frame,
                                   globs=globals())


# Generated at 2022-06-24 17:15:32.493206
# Unit test for function get_write_function
def test_get_write_function():
    function_0 = get_write_function(None, False)
    assert function_0 == sys.stderr.write
    function_1 = get_write_function(sys.stderr, False)
    assert function_1 == sys.stderr.write
    function_2 = get_write_function(test_case_0, False)
    assert function_2 == test_case_0


# Generated at 2022-06-24 17:15:37.622282
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with patch('sys.stdout') as mocked_obj:
        test_case_0()
        assert mocked_obj.write.call_count == 1


# Generated at 2022-06-24 17:15:41.737979
# Unit test for function get_write_function
def test_get_write_function():
    f = open('test.txt','w')
    write = get_write_function(f, False)
    write('test')
    f.close()


# Generated at 2022-06-24 17:15:52.560824
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    frame_0 = inspect.currentframe().f_back
    frame_1 = frame_0.f_back
    frame_2 = frame_1.f_back
    frame_3 = frame_2.f_back
    event_0 = 'call'
    arg_0 = None # Unknown
    tracer_0.depth = 1
    expected_0 = None
    result_0 = tracer_0.trace(frame_0, event_0, arg_0)
    assert(expected_0 == result_0)

    tracer_0.depth = 2

    expected_0 = tracer_0.trace
    result_0 = tracer_0.trace(frame_1, event_0, arg_0)
    assert(expected_0 == result_0)

    tracer_0

# Generated at 2022-06-24 17:15:56.246117
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame_0 = inspect.currentframe()
    globs = frame_0.f_globals
    module_name = globs.get('__name__')
    file_name = frame_0.f_code.co_filename
    cache_key = (module_name, file_name)
    
    assert cache_key in source_and_path_cache


# Generated at 2022-06-24 17:16:25.449763
# Unit test for function get_write_function
def test_get_write_function():
    output_0 = None
    overwrite_0 = False
    test_case_write_func_0 = get_write_function(output_0, overwrite_0)
    assert callable(test_case_write_func_0)
    output_1 = 'test'
    overwrite_1 = False
    test_case_write_func_1 = get_write_function(output_1, overwrite_1)
    assert callable(test_case_write_func_1)


# Generated at 2022-06-24 17:16:27.756475
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer_0 = Tracer()
    assert type(tracer_0) is Tracer



# Generated at 2022-06-24 17:16:35.452596
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    x=5
    frame = inspect.getouterframes(inspect.currentframe(),2)[1][0]
    file_name, source = get_path_and_source_from_frame(frame)
    source = source[0]
    assert source == 'x=5'
    pass

test_case_0()

test_get_path_and_source_from_frame()


# Generated at 2022-06-24 17:16:37.111340
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    test_case_0()

if __name__ == '__main__':
    test_Tracer___enter__()

# Generated at 2022-06-24 17:16:46.864731
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function_0():
        tracer_0 = Tracer()
        tracer_0.start()
        frame_0 = inspect.currentframe()
        path_and_source = get_path_and_source_from_frame(frame_0)
        assert path_and_source[0] == __file__
        lines = '\n'.join(path_and_source[1])
        assert 'test_case_0()' in lines
        assert 'tracer_0 = Tracer()' in lines
        tracer_0.stop()

    test_case_0()
    function_0()



# Generated at 2022-06-24 17:16:56.341596
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    f_locals = locals()
    frame = inspect.currentframe()
    print(get_path_and_source_from_frame(frame))
    tracer_0 = Tracer()
    tracer_0.watch('a', 'b')
    def f():
        tracer_0.start()
        a = 1
        b = 2
        a + b
        tracer_0.stop()

    f()
    print(tracer_0.events)
    print(tracer_0.variables)


# Generated at 2022-06-24 17:17:07.509982
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import this
    frame_0 = inspect.currentframe()
    result = get_path_and_source_from_frame(frame_0)
    assert result == (__file__, inspect.getsourcelines(test_case_0)[0])
    assert result[0] == __file__
    assert os.path.getsize(result[0]) == os.path.getsize(__file__)
    assert 'test_get_path_and_source_from_frame' in '\n'.join(result[1])
    assert 'Tracer' in '\n'.join(result[1])
    assert 'frame_0' in '\n'.join(result[1])
    assert 'test_case_0' in '\n'.join(result[1])

# Generated at 2022-06-24 17:17:11.862961
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    def test_case_0():
        tracer_1 = Tracer()
        @tracer_0
        def foo():
            foo.bar = 'baz'
            print(foo.bar)
        return foo
    @tracer_0
    def bar():
        bar.baz = 'bazz'
        print(bar.baz)
    return [test_case_0, bar]


# Generated at 2022-06-24 17:17:14.977730
# Unit test for constructor of class Tracer
def test_Tracer():
    print("Testing: constructor of class Tracer")
    try:
        tracer_0 = Tracer()
        assert isinstance(tracer_0, Tracer)
    except Exception as e:
        print("Test failed: constructor of class Tracer")
    else:
        print("Test passed: constructor of class Tracer")
        


# Generated at 2022-06-24 17:17:25.555818
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    line_nos = []
    # Start recording line numbers
    sys.settrace(lambda *args: line_nos.append(args[2]))
    @tracer_0
    def dummy_1():
        1
    result_0 = tracer_0.__call__(dummy_1)
    assert dummy_1 == pycompat.identityfunc(result_0)
    # Stop recording line numbers
    sys.settrace(None)
    # Check that dummy_1 gets wrapped