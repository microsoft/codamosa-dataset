

# Generated at 2022-06-24 17:09:20.312725
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame_0, frame_0_locals = utils.run(test_case_0)
    frame_1, frame_1_locals = utils.run(get_path_and_source_from_frame, frame_0, frame_0_locals)
    assert frame_1_locals['result'] == ('<string>', unavailable_source_0)
    assert frame_1_locals['cache_key'] == (None, '<string>')


# Generated at 2022-06-24 17:09:29.415506
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    list_0 = []
    unavailable_source_0 = UnavailableSource(*list_0)
    int_0 = 1262
    dict_0 = {}
    unavailable_source_1 = UnavailableSource(*dict_0)
    str_0 = str(int_0)
    unavailable_source_2 = UnavailableSource(str_0)
    str_1 = str(int_0)
    # None
    str_2 = str(int_0)
    str_3 = str(int_0)
    str_4 = str_3
    str_5 = str_4
    str_6 = str_5
    # str_6 = "01234"
    str_7 = str_6[1:4]
    str_8 = str_7[0:3]
    str_9 = str_8[0]

# Generated at 2022-06-24 17:09:46.334214
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    list_0 = []
    unavailable_source_0 = UnavailableSource(*list_0)
    int_0 = 1262
    dict_0 = {}
    dict_0[unavailable_source_0] = int_0
    snooper_0 = pysnooper.snooper(*dict_0)
    snooper_0.write(*list_0)
    tuple_0 = ('__call__', snooper_0)
    dict_1 = {}
    dict_1[unavailable_source_0] = int_0
    tuple_1 = (snooper_0, *tuple_0, *dict_1)
    tuple_2 = (snooper_0, *tuple_1)
    snooper_0.write(*tuple_2)


# Generated at 2022-06-24 17:09:58.970157
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    list_0 = []
    Tracer(list_0)
    with Tracer(list_0) as obj_0:
        int_0 = 1288
        assert int_0 == 1288
        obj_0.watch
        str_0 = 'Watch'
        assert str_0 == 'Watch'
        obj_0.watch_explode
        str_1 = 'Watch explode'
        assert str_1 == 'Watch explode'
        int_1 = obj_0.depth
        assert int_1 == 1
        str_2 = obj_0.prefix
        assert str_2 == ''
        obj_0.overwrite
        obj_0.thread_info
        obj_0.custom_repr
        int_2 = obj_0.max_variable_length
        assert int_2 == 100
        str_3 = obj

# Generated at 2022-06-24 17:10:07.167690
# Unit test for constructor of class Tracer
def test_Tracer():
    output = None
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    test_Tracer_0 = Tracer(output, watch, watch_explode, depth, prefix,
                           overwrite, thread_info, custom_repr, max_variable_length, normalize,
                           relative_time)
    output = sys.stdout
    watch = unavailable_source_0
    test_Tracer_1 = Tracer(output, watch)
    output = None
    watch = unknown_variable_24
    watch_explode = unknown_variable_23

# Generated at 2022-06-24 17:10:19.606487
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Line coverage: 100.0%
    # Mutation coverage: 100.0%
    # Covered commands: 2

    # Call test_case_0
    try:
        test_case_0()
    except UnavailableSource as error:
        exception_type_0 = type(error)
        exception_value_0 = error
        exception_traceback_0 = sys.exc_info()[2]
        print(exception_type_0)
        print(exception_value_0)
        print(exception_traceback_0)

    exception_line_no_0 = 44
    str_0 = str(exception_line_no_0)
    print(str_0)


# Generated at 2022-06-24 17:10:30.809566
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # In Python 2, frame_creation_function is a function that may create an
    # inspectable frame
    frame_creation_function = lambda: None
    frame_0 = frame_creation_function.__code__.__closure__
    frame_1 = inspect.stack()[0][0]

    # Call function get_path_and_source_from_frame with arguments frame_1 and
    # None and assign to path_and_source_0
    path_and_source_0 = get_path_and_source_from_frame(frame_1)

    # Construct path_0 and source_0 from path_and_source_0
    path_0, source_0 = path_and_source_0


# Generated at 2022-06-24 17:10:35.781122
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(UnexpectedExit):
        with pysnooper.snoop():
            assert False
    try:
        with pysnooper.snoop(raise_unexpected=False):
            assert False
    except AssertionError:
        pass
    else:
        assert False, 'pysnooper did not catch AssertionError'


# Generated at 2022-06-24 17:10:42.352317
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe()
    filename_0, source_0 = get_path_and_source_from_frame(frame)
    assert source_0 == test_case_0.__doc__.split('\n')
    assert filename_0.endswith('spyder_profiler/frame.py')



# Generated at 2022-06-24 17:10:56.039612
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    int_0 = 107
    float_0 = float('nan')
    float_1 = float('inf')
    float_2 = float('+inf')
    float_3 = float('-inf')
    float_4 = float('+nan')
    float_5 = float('-nan')
    float_6 = float('nan')
    float_6 = float('inf')
    float_7 = float('+inf')
    float_8 = float('-inf')
    float_9 = float('+nan')
    float_10 = float('-nan')
    fn_0 = 'abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijk'

# Generated at 2022-06-24 17:11:41.298150
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    list_1 = None
    dict_1 = {list_1: list_1, list_1: list_1, list_1: list_1, list_1: list_1}
    file_writer_1 = FileWriter(list_1, dict_1)
    assert file_writer_1.write(list_1) == None


# Generated at 2022-06-24 17:11:46.754320
# Unit test for constructor of class Tracer
def test_Tracer():
    with Snooper(watch=("list_0", "dict_0"),
                 watch_explode=("file_writer_0",)) as snooper_0:
        test_case_0()

reload(sys)
sys.setdefaultencoding("utf-8")


# Generated at 2022-06-24 17:11:54.714908
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Create a Tracer instance
    tracer_0 = Tracer()
    # First entry of thread_local
    stack_0 = [None]
    frame_0 = None
    start_time_0 = datetime_module.datetime.now()

    # Test handling exception
    try:
        raise Exception('Test Exeception')
    except:
        exc_type_0 = sys.exc_info()[0]
        exc_value_0 = sys.exc_info()[1]
        exc_traceback_0 = sys.exc_info()[2]
        traceback.print_exception(exc_type_0, exc_value_0, exc_traceback_0)
        pass

    tracer_0.thread_local.original_trace_functions = stack_0
    tracer_0.target_frames

# Generated at 2022-06-24 17:12:07.015828
# Unit test for constructor of class Tracer
def test_Tracer():
    # Create a new Tracer object with default arguments
    tracer_0 = Tracer()
    # Assert that the arguments are initialized
    assert tracer_0._write == test_case_0.__globals__[u'file_writer_0'].write
    assert tracer_0.watch == tuple()
    assert tracer_0.frame_to_local_reprs == {}
    assert tracer_0.start_times == {}
    assert tracer_0.depth == 1
    assert tracer_0.prefix == u''
    assert tracer_0.target_codes == set()
    assert tracer_0.target_frames == set()
    assert type(tracer_0.thread_local) == test_case_0.__globals__[u'threading'].local
    assert tracer_0

# Generated at 2022-06-24 17:12:14.895077
# Unit test for constructor of class Tracer
def test_Tracer():
    output = None
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    with Tracer(output, watch, watch_explode, depth,
                 prefix, overwrite, thread_info, custom_repr,
                 max_variable_length, normalize, relative_time):
        pass


# Generated at 2022-06-24 17:12:25.556881
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pysnooper.snoop():

        # __call__(self, function_or_class) -> <function wrapper at ...>
        #
        # Decorate a function:

        @pysnooper.snoop()
        def foo(x, y):
            return x + y
        foo(1, 2)

        # __call__(self, function_or_class) -> <function wrapper at ...>
        #
        # Decorate an async function:
        async def async_foo(x, y):
            return x + y
        with pysnooper.snoop():
            await async_foo(1, 2)


# Generated at 2022-06-24 17:12:31.879311
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    output = None
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    tracer_0 = Tracer(output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr, max_variable_length, normalize, relative_time)


# Generated at 2022-06-24 17:12:39.274690
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    sys.settrace(None)
    frame = sys._getframe()
    filename, source = get_path_and_source_from_frame(frame)
    expected_filename = 'test_code_browser.py'
    _assert(filename == expected_filename, 'test_get_path_and_source_from_frame failed')
    expected_source = sys.modules[__name__].__file__.splitlines()
    _assert(source == expected_source, 'test_get_path_and_source_from_frame failed')



# Generated at 2022-06-24 17:12:42.648860
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Call method __call__ of class Tracer with arguments
    # Result: instance of Tracer

    return


# Generated at 2022-06-24 17:12:43.857416
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()


# Generated at 2022-06-24 17:13:03.280877
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    class_0 = FileWriter
    stack = inspect.stack()
    frame = stack[0][0]
    assert get_path_and_source_from_frame(
        frame) == (class_0.__module__ + class_0.__qualname__)
    return


# Generated at 2022-06-24 17:13:09.726509
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame.__code__.co_filename == '<stdin>'
    assert get_path_and_source_from_frame.__code__.co_name == 'test_case_0'
    assert get_path_and_source_from_frame.__globals__ == globals()
    assert get_path_and_source_from_frame(sys._getframe()) is not None



# Generated at 2022-06-24 17:13:20.603575
# Unit test for constructor of class Tracer
def test_Tracer():
    with open('test_Tracer_result.txt', 'w') as output_file:
        function_0 = test_case_0
        print(output_file, 'foo', 1, 1.0, (), [], {}, True, range(0, 5), test_case_0)
        tracer_0 = Tracer(output_file, [1, 1.0, (), [], {}, True, range(0, 5), test_case_0], ['self'], 2, 'ZZZ ', True, True, [], 100, False, True)
        test_case_0()
        tracer_0.set_thread_info_padding('foo')
        depth_0 = -1
        thread_global.__dict__.setdefault('depth', depth_0)
        frame_0 = inspect.currentframe()

# Generated at 2022-06-24 17:13:23.842351
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    with tracer_0:
        pass
    return


# Generated at 2022-06-24 17:13:24.656679
# Unit test for function get_write_function
def test_get_write_function():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 17:13:28.249239
# Unit test for function get_local_reprs
def test_get_local_reprs():
    local_reprs = get_local_reprs(inspect.currentframe())
    assert local_reprs == {'file_writer_0': '<FileWriter object at 0x...>',
                           'list_0': 'None',
                           'dict_0': '{None: None, None: None, None: None, None: None}'}


# Generated at 2022-06-24 17:13:34.212303
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pairs = [(('output', 'watch', 'watch_explode', 'depth', 'prefix', 'overwrite',
       'thread_info', 'custom_repr', 'max_variable_length', 'normalize',
       'relative_time'),
      (None, (), (), 1, '', False, False, (), 100, False, False)),
     ]

# Generated at 2022-06-24 17:13:45.359514
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print("test_Tracer_trace")
    # Test for method trace of class Tracer
    function_0 = None
    source_path_0 = 0
    frame_0 = None
    line_no_0 = 0
    custom_repr_0 = None
    line_no_1 = 0
    source_path_1 = 0
    arg_0 = None
    source_path_2 = 0
    frame_1 = None
    source_path_3 = 0
    frame_2 = None
    line_no_2 = 0
    line_no_3 = 0
    line_no_4 = 0
    return_value_repr_0 = None
    frame_3 = None
    source_path_4 = 0
    frame_4 = None
    source_path_5 = 0
    frame_5 = None


# Generated at 2022-06-24 17:13:48.864462
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    try:
        function_or_class = test_case_0()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_Tracer___call__()

# Generated at 2022-06-24 17:13:58.499007
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    """
    This function is a unit test for function get_path_and_source_from_frame
    """
    # Set up parameters
    frame = None
    function_name = 'test_case_0'
    module_name = None
    frame = utils.get_frame_by_function_name(function_name, module_name)
    # Run test
    path, source = get_path_and_source_from_frame(frame)
    # Check for success/failure
    assert path is not None
    assert source is not None
    assert len(source) > 0 
    return True


# Generated at 2022-06-24 17:14:21.720942
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass    # Disable this test case for now
    print("=========================================")
    print("Testing method trace of class Tracer...")
    tracer_1 = Tracer()
    frame_1 = inspect.currentframe()
    event_1 = 'call'
    arg_1 = None
    print("Calling Tracer.trace(frame_1, event_1, arg_1)...")
    ret_1 = tracer_1.trace(frame_1, event_1, arg_1)
    assert ret_1 is None
    print("returned:", ret_1)
    print("Done!")
    print("=========================================")



# Generated at 2022-06-24 17:14:22.777734
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()



# Generated at 2022-06-24 17:14:33.798106
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    tracer_0 = Tracer()
    import inspect
    import os
    import sys
    call_frame = inspect.currentframe()
    file_name, source = get_path_and_source_from_frame(call_frame)
    assert os.path.basename(file_name) == 'tracer.py'
    assert 'get_path_and_source_from_frame' in source[0]
    for line in source:
        assert isinstance(line, str)

    test_frame = inspect.currentframe().f_back
    file_name, source_lines = get_path_and_source_from_frame(test_frame)
    assert os.path.basename(file_name) == 'tracer.py'

# Generated at 2022-06-24 17:14:45.871359
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_1 = Tracer()

    ### Checking whether we should trace this line: #######################
    #                                                                     #
    # We should trace this line either if it's in the decorated function,
    # or the user asked to go a few levels deeper and we're within that
    # number of levels deeper.

    if not (frame.f_code in self.target_codes or frame in self.target_frames):
        if self.depth == 1:
            # We did the most common and quickest check above, because the
            # trace function runs so incredibly often, therefore it's
            # crucial to hyper-optimize it for the common case.
            return None
        elif self._is_internal_frame(frame):
            return None
        else:
            _frame_candidate = frame

# Generated at 2022-06-24 17:14:53.116130
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Testing that the correct calling of __enter__ method
    # returns a value
    # This test should pass
    tracer_0 = Tracer()
    with tracer_0 as s:
      assert isinstance(s, Tracer), (
          "s is not instance of Tracer")


# Generated at 2022-06-24 17:14:57.957028
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect

    caller_frame = inspect.currentframe()
    called_frame = inspect.getouterframes(caller_frame)[1][0]
    path = os.path.realpath(inspect.getfile(inspect.currentframe()))
    source = inspect.getsource(inspect.currentframe())

    assert get_path_and_source_from_frame(called_frame)[0] == path
    assert get_path_and_source_from_frame(called_frame)[1][0] == source.splitlines()[0]



# Generated at 2022-06-24 17:15:07.695888
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer(exc_traceback=None, exc_type=None, exc_value=None,
                  output=None, overwrite=False, prefix='', thread_info=False,
                  watch=(), watch_explode=(), depth=1, custom_repr=(),
                  max_variable_length=100, normalize=False, relative_time=False)

# Generated at 2022-06-24 17:15:20.161506
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()

    import datetime
    def test_function():
        return 'a'

    def test_function_with_frame_arg(frame):
        return frame.f_lineno

    def test_function_with_frame_event_arg(frame, event):
        return (frame.f_lineno, event)

    def test_function_with_frame_event_arg_none(frame, event):
        return None

    def test_function_with_frame_event_arg_exception(frame, event):
        raise Exception("Sample exception")

    def test_function_with_frame_event_arg_exception_none(frame, event):
        raise Exception("Sample exception")

    def test_function_with_frame_event_arg_exception_no_return(frame, event):
        raise

# Generated at 2022-06-24 17:15:29.483612
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    #  >= type(0, builtin_function_or_method)
    call_exit_0 = None
    call_method_0 = None
    with tracer_0 as call_exit_0:
        call_method_0 = tracer_0.__enter__()

    assert (isinstance(call_exit_0, type(tracer_0)))
    assert (cmp(call_method_0, tracer_0) == 0)
    assert (cmp(call_exit_0, tracer_0) == 0)


# Generated at 2022-06-24 17:15:40.175172
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    test_object = Tracer()
    class_1 = test_object.__call__(MyClass)
    random_1 = test_object.__call__(MyClass.random)
    tracer_0 = test_object.__call__(test_case_0)
    assert type(class_1) == type is MyClass
    assert type(random_1) == type is MyClass.random
    assert type(tracer_0) == type is tracer_0


# Generated at 2022-06-24 17:15:56.960393
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def a():
        test_case_0()
        test_case_1()

    def b():
        a()

    def test_case_1():
        b()

    test_case_1()


# Generated at 2022-06-24 17:16:05.315755
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()
    assert isinstance(tracer, Tracer)
    assert isinstance(tracer.watch, list)
    assert isinstance(tracer.frame_to_local_reprs, dict)
    assert isinstance(tracer.start_times, dict)
    assert isinstance(tracer.target_codes, set)
    assert isinstance(tracer.target_frames, set)
    assert isinstance(tracer.thread_local, threading.local)


# Generated at 2022-06-24 17:16:07.888507
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    # Verify we can create an instance of Tracer
    assert tracer_0 is not None


# Generated at 2022-06-24 17:16:15.442569
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import pdb; pdb.set_trace()
    test_case_0()
    test_frame = sys._getframe(0)
    test_result = get_path_and_source_from_frame(test_frame)
    test_path = test_result[0]
    test_source = test_result[1]
    expected_source_line = '    tracer_0 = Tracer()'
    found_source_line = test_source[test_frame.f_lineno - 1]
    assert(expected_source_line == found_source_line)
    print(test_path)
    print(found_source_line)


# Generated at 2022-06-24 17:16:25.548935
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def _test_get_path_and_source_from_frame():
        _file_name = inspect.getfile(test_case_0)
        _source = inspect.getsource(test_case_0)
        _line = inspect.getsourcelines(test_case_0)[1]
        _source_lines = _source.splitlines()
        frame = test_case_0.__code__.co_filename
        file_name, source = get_path_and_source_from_frame(frame)
        assert file_name == _file_name
        assert source == _source_lines
    _test_get_path_and_source_from_frame()



# Generated at 2022-06-24 17:16:28.434196
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print("\n------ test_Tracer___call__ ------")
    tracer_0 = Tracer()
    test_case_0()


# Generated at 2022-06-24 17:16:31.877075
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print("test_Tracer___call__")
    tracer = Tracer()
    assert isinstance(tracer, Tracer)


# Generated at 2022-06-24 17:16:40.653304
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test case Tracer.trace()
    # This is a passing test case.
    # No output was displayed.
    foo = 10
    tracer_0 = Tracer()
    tracer_0.trace(None, "call", 10)
    foo
    tracer_0.trace(None, "call", 10)
    foo
    tracer_0.trace(None, "call", 10)
    foo
    tracer_0.trace(None, "call", 10)
    foo
    tracer_0.trace(None, "call", 10)
    foo
    tracer_0.trace(None, "call", 10)
    foo
    tracer_0.trace(None, "call", 10)
    foo
    tracer_0.trace(None, "call", 10)
    foo
    tracer_

# Generated at 2022-06-24 17:16:49.940322
# Unit test for constructor of class Tracer
def test_Tracer():
    def _test_Tracer():
        tracer_0 = Tracer()

        assert(tracer_0.watch == [])
        assert(tracer_0.frame_to_local_reprs == {})
        assert(tracer_0.start_times == {})
        assert(tracer_0.depth == 1)
        assert(tracer_0.prefix == '')
        assert(tracer_0.target_codes == set())
        assert(tracer_0.target_frames == set())
        assert(tracer_0.thread_local == threading.local())
        assert(tracer_0.last_source_path == None)
        assert(tracer_0.max_variable_length == 100)
        assert(tracer_0.normalize == False)

# Generated at 2022-06-24 17:16:50.691564
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    test_case_0()


# Generated at 2022-06-24 17:17:26.170247
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def inner_function(outer_variable):
        inner_variable = outer_variable * 2
        return inner_variable
    class InnerClass(object):
        def __repr__(self):
            return 'inner_class'
        def method(self, number):
            return 'inner_method(%s)' % number
    frame_0 = inspect.currentframe()
    outer_variable = 0
    inner_class = InnerClass()
    get_path_and_source_from_frame(frame_0)
    get_path_and_source_from_frame(frame_0)
    get_path_and_source_from_frame(frame_0)
    variable_0 = inner_function(outer_variable)
    variable_1 = inner_class.method(variable_0)



# Generated at 2022-06-24 17:17:32.210552
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer(depth=1, max_variable_length=100, normalize=False,
                      output=None, overwrite=False, prefix='',
                      relative_time=False, thread_info=False,
                      watch=(('a', 'b'),), watch_explode=(), custom_repr=())
    tracer_0.__call__(test_case_0)

# Generated at 2022-06-24 17:17:33.149114
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    assert True


# Generated at 2022-06-24 17:17:42.206759
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    debug_program.print_header('Unit test trace()')
    expected_output = '''Starting var:.. local_variable = 1
Modified var:.. local_variable = 3
Modified var:.. local_variable = 5
Modified var:.. local_variable = 6
Return value:.. sequence (refcount = 1)
  0: 1
Exception:..... IndexError
'''
    output = io.StringIO()
    tracer = Tracer(output)
    frame = frames.make_mock_frame({'local_variable':1}, test_Tracer_trace)
    with tracer:
        frame.f_lineno = 1
        frame.f_lineno = 2
        frame.f_lineno = 3
        frame.f_lineno = 4
        frame.f_lineno = 5
        frame.f_lin

# Generated at 2022-06-24 17:17:45.687291
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
  args0 = None
  args1 = 2
  args2 = "abcd"
  tracer_0 = Tracer()
  tracer_0.__exit__(args0, args1, args2)
  assert tracer_0.__exit__.__doc__ == '''__exit__(self, exc_type, exc_value, exc_traceback)

       '''
  del args0, args1, args2, tracer_0


# Generated at 2022-06-24 17:17:56.842152
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()

    # Test with normal values:
    tracer_0.write = MagicMock()
    tracer_0.__exit__('Test exc_type', 'Test exc_value', 'Test exc_traceback')
    tracer_0.write.assert_called_once()
    assert tracer_0.thread_local == threading.local()
    assert tracer_0.thread_local.original_trace_functions == []

    # Test with exception:
    tracer_1 = Tracer()
    with pytest.raises(TypeError):
        tracer_1.__exit__()



# Generated at 2022-06-24 17:17:58.004457
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()


# Generated at 2022-06-24 17:18:02.390895
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    tracer.__call__(globals)
    tracer.__call__(test_case_0())
    tracer.__call__(isinstance)
    tracer.__call__(Tracer)



# Generated at 2022-06-24 17:18:10.419783
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_file_name = os.path.join(os.path.dirname(__file__),
                                  os.path.basename(__file__))
    with open(test_file_name, 'rb') as fp:
        source_lines = fp.read().splitlines()
    assert get_path_and_source_from_frame(test_case_0.__code__.co_firstlineno) == (test_file_name, source_lines)



# Generated at 2022-06-24 17:18:12.011664
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
