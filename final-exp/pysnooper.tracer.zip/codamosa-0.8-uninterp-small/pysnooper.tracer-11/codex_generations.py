

# Generated at 2022-06-24 17:09:26.396404
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = sys._getframe()
    watch = [CommonVariable('unavailable_source_0', unavailable_source_0)]

# Generated at 2022-06-24 17:09:37.452963
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Trace (1)
    unavailable_source_1 = UnavailableSource(co_filename='unavailable',
                                             co_firstlineno=1)
    unavailable_source_1.f_back = unavailable_source_0
    unavailable_source_1.f_lineno = 1
    unavailable_source_1.f_trace = None
    unavailable_source_1.f_lasti = 0
    unavailable_source_1.f_code = unavailable_source_1
    with MockTracer(1, [], [], 0, '', True, False, [], 100, False, False) as mock_tracer_1:
        mock_tracer_1.trace(unavailable_source_1, 'call', None)
    # Trace (2)

# Generated at 2022-06-24 17:09:45.983234
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    assert tracer.trace(frame=None, event=None, arg=None) == tracer.trace
    assert tracer.trace(frame=None, event=None, arg=None) == tracer.trace
    assert tracer.trace(frame=None, event=None, arg=None) == tracer.trace
    assert tracer.trace(frame=None, event=None, arg=None) == tracer.trace
    assert tracer.trace(frame=None, event=None, arg=None) == tracer.trace

# Generated at 2022-06-24 17:09:48.412626
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    assert inspect.currentframe().f_back.f_trace != tracer.trace
    with tracer:
        test_case_0()
        assert inspect.currentframe().f_back.f_trace == tracer.trace


# Generated at 2022-06-24 17:09:50.433674
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    test1 = Tracer()
    test_case_0()
    test1.trace(None, None, None)



# Generated at 2022-06-24 17:09:54.125110
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    FileWriter(name, overwrite_value).write(s)


# Generated at 2022-06-24 17:09:56.668074
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    t = Tracer()
    assert t.trace(None, None, None) == t.trace


# Generated at 2022-06-24 17:09:59.966753
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    first_trace = Tracer()
    test_case_0()
    first_trace.trace(0)


# Generated at 2022-06-24 17:10:01.684454
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    get_path_and_source_from_frame(inspect.currentframe())



# Generated at 2022-06-24 17:10:10.976941
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    locs = locals()

    # 1. Unit test with a file that exists and is readable

    # Capture values `path` and `source`
    p, s = get_path_and_source_from_frame(locs)

    # Check that `path` is the path of this file (i.e. the unit test file)
    assert p == __file__

    # Check that `source` is this file, split into lines
    with open(__file__, 'r') as f:
        assert s == f.read().splitlines()

    # 2. Unit test with a file that exists, but is not readable

    # Save current file permissions
    file_permissions = os.stat(__file__).st_mode

    # Set permissions to be unreadable
    os.chmod(__file__, 0)

    # Capture values `path

# Generated at 2022-06-24 17:10:56.014133
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global unavailable_source_0
    unavailable_source_0 = UnavailableSource()
    test_case_0()


# Generated at 2022-06-24 17:11:04.831576
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    unavailable_source_0 = UnavailableSource()
    unavailable_source_1 = UnavailableSource()
    unavailable_source_2 = UnavailableSource()
    unavailable_source_3 = UnavailableSource()
    unavailable_source_4 = UnavailableSource()
    unavailable_source_5 = UnavailableSource()
    unavailable_source_6 = UnavailableSource()
    unavailable_source_7 = UnavailableSource()
    unavailable_source_8 = UnavailableSource()
    unavailable_source_9 = UnavailableSource()
    unavailable_source_10 = UnavailableSource()
    unavailable_source_11 = UnavailableSource()
    unavailable_source_12 = UnavailableSource()
    unavailable_source_13 = UnavailableSource()
    unavailable_source_14 = UnavailableSource()
    unavailable_source_15 = UnavailableSource()

# Generated at 2022-06-24 17:11:13.637295
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    try:
        import IPython
        IPython.get_ipython()
    except TypeError:
        raise AssertionError('IPython is required for this test.')

    # Test that when we're in an IPython shell and we run a function,
    # its source will be taken from the shell.
    def fibonacci(n):
        assert n > 0
        a, b = 0, 1
        while n > 0:
            a, b = b, a + b
            n -= 1
        return a
    fibonacci._test_get_path_and_source_from_frame = True

    try:
        fibonacci(10)
    finally:
        del fibonacci._test_get_path_and_source_from_frame


# Generated at 2022-06-24 17:11:20.899921
# Unit test for method trace of class Tracer
def test_Tracer_trace():

    ### Setup: ###############################################################
    #                                                                        #
    frame = frame_from_test_case(test_case_0)
    watch = ('unavailable_source_0',)
    #                                                                        #
    ### Finished setup. ######################################################



    ### Testing: #############################################################
    #                                                                        #
    tracer = Tracer(watch=watch, depth=1)
    #                                                                        #
    ### Finished testing. ####################################################



    ### Asserting: ###########################################################
    #                                                                        #
    assert tracer.trace(frame, event='call', arg=None) is tracer.trace
    #                                                                        #
    ### Finished asserting. ##################################################

# Generated at 2022-06-24 17:11:31.654301
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function_0():
        test_case_0()

    def test_function_1():
        test_case_1()
    test_path_0 = __file__
    if test_path_0.endswith('.pyc'):
        test_path_0 = test_path_0[:-1]
    with open(test_path_0, 'rb') as fp:
        test_source_0 = fp.read().decode('utf-8').splitlines()

    test_path_1 = __file__
    if test_path_1.endswith('.pyc'):
        test_path_1 = test_path_1[:-1] + 'w'

# Generated at 2022-06-24 17:11:43.130712
# Unit test for function get_local_reprs
def test_get_local_reprs():
    test_case_0()
    for frame in inspect.getouterframes(inspect.currentframe()):
        if frame[3] == 'test_case_0':
            frame = frame[0]
            break
    else:
        raise AssertionError()

    ##
    ## Test basic
    ##
    local_reprs = get_local_reprs(frame)
    assert local_reprs['frame'] == '<frame>'
    assert local_reprs['unavailable_source_0'] == '<UnavailableSource>'

    ##
    ## Test watch
    ##
    x = 123
    y = 456
    watch = (BaseVariable('x'), BaseVariable('y'))
    local_reprs = get_local_reprs(frame, watch=watch)
    assert local_re

# Generated at 2022-06-24 17:11:53.265205
# Unit test for function get_local_reprs
def test_get_local_reprs():

    def _get_local_reprs(globals=globals(), locals=locals(), max_length=None,
                         normalize=False):
        return get_local_reprs(inspect.currentframe().f_back, (), custom_repr=(),
                               max_length=max_length, normalize=normalize)

    assert _get_local_reprs() == {}

    a = 5
    assert _get_local_reprs() == {'a': '5'}

    b = [1, 2, 3]
    assert _get_local_reprs() == {'a': '5', 'b': '[1, 2, 3]'}

    c = unavailable_source_0

# Generated at 2022-06-24 17:12:06.880460
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    this_file_directory = os.path.dirname(__file__)
    this_file_path = os.path.join(this_file_directory, __file__)
    frame = sys._getframe(0)
    this_file_path_1, this_file_source_1 = \
                                        get_path_and_source_from_frame(frame)
    assert this_file_path_1 == this_file_path
    assert this_file_source_1 == UnavailableSource()

    frame = sys._getframe(1)
    frame.f_globals = frame.f_globals.copy()
    frame.f_globals['__name__'] = __name__
    this_file_path_0, this_file_source_0 = \
                                        get_path_and_source_

# Generated at 2022-06-24 17:12:13.454984
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert 'unavailable_source' not in globals()
    test_case_0()
    assert 'unavailable_source' in globals()
    frame = inspect.currentframe()
    (file_name, source) = get_path_and_source_from_frame(frame)
    assert file_name == __file__
    assert source is unavailable_source_0


# Generated at 2022-06-24 17:12:15.436422
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()
    assert source_and_path_cache == {}


# Generated at 2022-06-24 17:12:43.803210
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    unavailable_source_0 = UnavailableSource()
    assert unavailable_source_0 == UnavailableSource.__init__.__closure__[0].cell_contents


# Generated at 2022-06-24 17:12:46.168423
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer():
        test_case_0()

if __name__ == '__main__':
    test_Tracer___exit__()

# Generated at 2022-06-24 17:12:52.139213
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import context

    frame = inspect.currentframe()
    frame = frame.f_back.f_back

    def display_tracer():
        with context.Tracer(frame).call_chain_context. \
             variable_watch_context.watch('x'):
            pass

    frame = inspect.currentframe()
    frame = frame.f_back.f_back.f_back.f_back.f_back
    path, source = get_path_and_source_from_frame(frame)
    assert source is unavailable_source_0



# Generated at 2022-06-24 17:12:55.042543
# Unit test for constructor of class Tracer
def test_Tracer():
    '''
    >>> test_case_0()
    Starting var:.. unavailable_source_0 = <TracerTest.UnavailableSource ()>
    2020-08-31 11:58:04,095,166 call      3     unavailable_source_0 =
        <TracerTest.UnavailableSource ()>
    Call ended by exception
    '''



# Generated at 2022-06-24 17:13:04.843015
# Unit test for function get_local_reprs
def test_get_local_reprs():
    unavailable_source_0 = UnavailableSource()
    available_source_0 = AvailableSource()
    available_source_1 = AvailableSource()
    available_source_2 = AvailableSource()


    def outer_function(n, common_variable):
        def inner_function(n, d):
            c = n * n
            e = d
            f = n * n * n
            return n * n * n * n * n * n * n * n * n * n * 10 * n * n
        a = n
        b = n * n
        return inner_function(n, n)

    common_variable = CommonVariable('c')
    frame = outer_function(1, common_variable)
    frame_locals = frame.f_locals.copy()
    frame_locals.pop('__builtins__', None)


# Generated at 2022-06-24 17:13:11.888031
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe()
    path, src = get_path_and_source_from_frame(frame)
    assert isinstance(path, str)
    assert isinstance(src, list)
    assert src[0].strip().startswith('def test_get_path_and_source_from_frame(frame):')



# Generated at 2022-06-24 17:13:16.270779
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    pysnooper_snoop = pysnooper.snoop
    def test_case_0():
        unavailable_source_0 = UnavailableSource()
        pysnooper.snoop
        return pysnooper_snoop
    with tracer:
        test_case_0()


# Generated at 2022-06-24 17:13:25.486487
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Test 1: Test the behavior of thread_global.depth += 1 in __enter__
    # when the first value of thread_global.depth is -1.
    # thread_global.depth should be 0 after calling __enter__
    with Tracer(output=None) as t0:
        assert(thread_global.depth == 0)
    # Test 2: Test the behavior of thread_global.depth += 1 in __enter__
    # when the first value of thread_global.depth is not -1.
    # thread_global.depth should be 1 after calling __enter__
    with Tracer(output=None) as t1:
        with Tracer(output=None):
            with Tracer(output=None):
                assert(thread_global.depth == 3)


# Generated at 2022-06-24 17:13:26.657652
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pytest.raises(StopIteration):
        test_case_0()


# Generated at 2022-06-24 17:13:36.830232
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe()
    _, test_case_0_source = get_path_and_source_from_frame(frame)
    test_case_0 = '\n'.join(test_case_0_source)
    for i, line in enumerate(test_case_0.splitlines()):
        if line.strip().startswith('unavailable_source_0 ='):
            assert test_case_0_source[i] == unavailable_source_0
            break


# Generated at 2022-06-24 17:14:05.431624
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    assert result[0] == __file__
    assert result[1] == open(__file__, 'r', encoding='utf-8').read().splitlines()



# Generated at 2022-06-24 17:14:09.550718
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    assert isinstance(tracer, Tracer)
    local_frame = inspect.currentframe()
    assert local_frame.f_code == tracer.__exit__.__code__
    assert tracer.__exit__(None, None, None) == None


# Generated at 2022-06-24 17:14:16.242199
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    assert result[0].endswith('test_get_path_and_source_from_frame')
    assert result[1][0] == 'def test_get_path_and_source_from_frame():'
    if pycompat.PY2:
        assert result[1][1] == '    frame = inspect.currentframe()'
        assert result[1][2] == '    result = get_path_and_source_from_frame(frame)'
        assert result[1][3] == '    assert result[0].endswith(\'test_get_path_and_source_from_frame\')'
    else:
        assert result[1][1] == '    frame = inspect.currentframe()'

# Generated at 2022-06-24 17:14:22.729484
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    assert test_case_0.__code__.co_filename == tracer_0.trace(test_case_0).__code__.co_filename


# Generated at 2022-06-24 17:14:23.976445
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()



# Generated at 2022-06-24 17:14:29.682810
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def inner_function(arg_0):
        return arg_0 + 1
    path, source = get_path_and_source_from_frame(inspect.currentframe())
    assert path == __file__
    assert source[0] == '    path, source = get_path_and_source_from_frame(inspect.currentframe())'
    assert source[1] == r'    assert path == __file__'
    assert source[2] == r'    assert source[0] == \'    path, source = get_path_and_source_from_frame(inspect.currentframe())\''



# Generated at 2022-06-24 17:14:37.821573
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(Exception):
        Tracer(depth=0)
    with pytest.raises(Exception):
        Tracer(depth=-1)
    with pytest.raises(Exception):
        Tracer(depth=1.0)
    with pytest.raises(Exception):
        Tracer(depth='1')
    with pytest.raises(Exception):
        Tracer(depth=[1, 2])
    with pytest.raises(Exception):
        Tracer(depth=(1, 2))
    with pytest.raises(Exception):
        Tracer(depth={"k": 1})
    with pytest.raises(Exception):
        Tracer(depth={"k": 1})
    with pytest.raises(Exception):
        Tracer(prefix=1)

# Generated at 2022-06-24 17:14:40.091661
# Unit test for constructor of class Tracer
def test_Tracer():
    # Call constructor, check the inner state with debugger, call destructor
    test_case_0()

if __name__ == "__main__":
    import pysnooper
    test_Tracer()

# Generated at 2022-06-24 17:14:41.446059
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()
    fra

# Generated at 2022-06-24 17:14:44.730294
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    passed = True
    try:
        tracer_0(None)
    except (Exception) as e:
        passed = False
    finally:
        assert passed


# Generated at 2022-06-24 17:15:21.813225
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """Test method trace"""
    frame_0 = inspect.currentframe().f_back.f_back
    event = None
    arg = None
    tracer_0 = Tracer()
    tracer_0.start_times = {}
    basedir = os.path.dirname(__file__)
    fpath = os.path.abspath(os.path.join(basedir, 'snoop.py'))
    code = open(fpath, "r")
    lines = code.readlines()
    line = lines[0]
    lineno = random.randint(1, 100)
    source_string = line

    with patch('builtins.print') as mock_0:
        mock_0.__name__ = "print"
        mock_0.return_value = None
        tracer_0.trace

# Generated at 2022-06-24 17:15:24.135408
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    test_case_0()

# -----------------------------------------------------------------------------
# Tests.
# -----------------------------------------------------------------------------


# Generated at 2022-06-24 17:15:28.792910
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_0 = Tracer()

    frame_0 = inspect.currentframe()
    event_0 = 'call'
    arg_0 = None

    tracer_0.trace(frame_0, event_0, arg_0)



# Generated at 2022-06-24 17:15:36.961629
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global tracer_0
    global cls_0
    global function_or_class_0
    global function_or_class_takes_0
    global result_0

    # [Call       1] __call__(function_or_class_0)
    function_or_class_takes_0 = function_or_class_0
    # [Call       2] __init__()
    # [Assignment 3] output=None
    # [Assignment 4] watch=()
    # [Assignment 5] watch_explode=()
    # [Assignment 6] depth=1
    # [Assignment 7] prefix=''
    # [Assignment 8] overwrite=False
    # [Assignment 9] thread_info=False
    # [Assignment 10] custom_repr=()
    # [Assignment 11] max

# Generated at 2022-06-24 17:15:50.400619
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    assert tracer_0._write is not None
    assert tracer_0.write != get_write_function(output=stdout, overwrite=False)
    tracer_0.__enter__()
    assert not hasattr(tracer_0, 'target_codes')
    assert not hasattr(tracer_0, 'target_frames')
    assert not hasattr(tracer_0, 'thread_local')
    assert not hasattr(tracer_0, 'frame_to_local_reprs')
    assert not hasattr(tracer_0, 'start_times')
    assert not hasattr(tracer_0, 'thread_info_padding')
    assert not sys.gettrace()
    assert not thread_global.depth

# Generated at 2022-06-24 17:15:58.190492
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    """Test the function get_path_and_source_from_frame."""
    # case 0:
    tracer_0 = Tracer(module='sly._tracer', line_start=1048)
    path_0, source_0 = get_path_and_source_from_frame(tracer_0.frame)

    line_list_0 = source_0[tracer_0.line-1].strip().split()
    assert line_list_0[0] == 'def'
    assert line_list_0[1] == 'test_case_0():'

    # case 1:
    tracer_1 = Tracer(module='sly._tracer', line_start=1405)
    path_1, source_1 = get_path_and_source_from_frame(tracer_1.frame)


# Generated at 2022-06-24 17:16:09.521476
# Unit test for method __call__ of class Tracer

# Generated at 2022-06-24 17:16:11.962330
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:16:16.408606
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe().f_back.f_back
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == __file__[:-1]
    line_number = frame.f_lineno
    line = source[line_number - 1]
    assert line.strip() == 'file_name, source = get_path_and_source_from_frame(frame)'


# Generated at 2022-06-24 17:16:20.145162
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer_0 = Tracer()
    try:
        with tracer_0 as dummy_with_var_0:
            pass
    except:
        pass
    assert False


# Generated at 2022-06-24 17:16:53.962055
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer_trace_0 = Tracer().trace(
        frame=frame_0,
        event='call',
        arg=None,
    )
    assert tracer_trace_0 is None
    tracer_trace_1 = Tracer(
        depth=1,
        thread_info=True,
    ).trace(
        frame=frame_0,
        event='return',
        arg=None,
    )
    assert tracer_trace_1 is None


# Generated at 2022-06-24 17:17:05.869466
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Calling __call__ of Tracer
    tracer_0 = Tracer()
    method_test(tracer_0, None,
                [
                    {
                        'test_args': (),
                        'expected_result': None
                    }
                ]
    )
    # Calling __call__ of Tracer
    tracer_1 = Tracer()
    method_test(tracer_1,
                [

                ],
                [
                    {
                        'test_args': (None,),
                        'expected_result': None
                    }
                ]
    )
    # Calling __call__ of Tracer
    tracer_2 = Tracer()

# Generated at 2022-06-24 17:17:19.530173
# Unit test for function get_write_function
def test_get_write_function():
    test_outputs = [None, sys.stderr, sys.stdout, lambda s: s]
    test_values = ["test_value"]
    test_overwrite = False
    test_output = sys.stdout

    assert get_write_function(test_output, test_overwrite)(test_values) == test_values, "get_write_function() is broken!"

    test_output = open(os.path.join(os.path.dirname(__file__), '..', '..', 'test.txt'), 'w')
    os.remove(os.path.join(os.path.dirname(__file__), '..', '..', 'test.txt'))


# Generated at 2022-06-24 17:17:25.220933
# Unit test for function get_local_reprs
def test_get_local_reprs():
    # Unit test
    # normalize
    assert get_local_reprs({'a': 2, 'b': 3}, ([('b', 'b*2')],), normalize=False) == \
        (collections.OrderedDict([('a', '2'), ('b', '3'), ('b', '6')]))
    assert get_local_reprs({'a': 2, 'b': 3}, ([('b', 'b*2')],), normalize=True) == \
        (collections.OrderedDict([('a', '2'), ('b', '6')]))

# Generated at 2022-06-24 17:17:29.982733
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer_0 = Tracer()
    try:
        tracer_0.__enter__()
    except:
        utils.print_exc()
    tracer_0.__exit__(None, None, None)


# Generated at 2022-06-24 17:17:32.882803
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer_0 = Tracer()
    try:
        tracer_0.__call__(1)
    except NotImplementedError:
        assert True
    except:
        assert False


# Generated at 2022-06-24 17:17:36.522735
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_case_0()
    path, source = get_path_and_source_from_frame(sys._getframe())
    assert path == __file__
    assert len(source) > 1000



# Generated at 2022-06-24 17:17:40.998789
# Unit test for constructor of class Tracer
def test_Tracer():
    test_case_0()



# Generated at 2022-06-24 17:17:43.607144
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    test_case_0()

if __name__ == '__main__':
    test_Tracer_trace()
    test_code_to_source()

# Generated at 2022-06-24 17:17:52.557100
# Unit test for function get_write_function
def test_get_write_function():
    # test output is None
    tracer_0 = Tracer()
    write_function = get_write_function(None, False)
    assert hasattr(write_function, '__call__')

    # test output is string
    output_path = r'output.txt'
    if os.path.exists(output_path):
        os.remove(output_path)

    write_function = get_write_function(output_path, True)
    s = 'Hello World'
    write_function(s)
    with open(output_path, 'r') as output:
        assert output.read() == s


# Generated at 2022-06-24 17:18:26.402125
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    assert test_case_0.__code__ == test_case_0.__code__

# Generated at 2022-06-24 17:18:32.796043
# Unit test for function get_write_function
def test_get_write_function():
    assert isinstance(get_write_function(None, False), type(lambda: None)), True   # True
    assert isinstance(get_write_function('out.txt', False), type(lambda: None)), True   # True
    assert isinstance(get_write_function(sys.stdout, True), type(lambda: None)), True   # True



# Generated at 2022-06-24 17:18:33.556888
# Unit test for constructor of class Tracer
def test_Tracer():
    test_case_0()



# Generated at 2022-06-24 17:18:42.173679
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    with open('/tmp/t.txt', 'w') as f:
        fw = FileWriter('/tmp/t.txt', False)
        fw.write('hello world1\n')
    with open('/tmp/t.txt', 'r') as f:
        assert f.read() == 'hello world1\n'
    with open('/tmp/t.txt', 'w') as f:
        fw = FileWriter('/tmp/t.txt', True)
        fw.write('hello world2\n')
    with open('/tmp/t.txt', 'r') as f:
        assert f.read() == 'hello world2\n'

