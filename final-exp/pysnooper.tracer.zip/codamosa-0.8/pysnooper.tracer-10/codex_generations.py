

# Generated at 2022-06-10 21:33:17.482541
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = False

# Generated at 2022-06-10 21:33:28.568103
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import inspect
    import functools
    from py.error import Traceback
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    import threading
    import os
    import uuid
    import pycompat
    import itertools
    import collections

    import pysnooper
    import pysnooper.pycompat
    import pysnooper.utils
    import pysnooper.stringutils
    import pysnooper.compat_inspect
    import pysnooper.pycompat

    def test_Tracer_side_effect():
        def foo():
            pass

        class Foo(object):
            def __init__(self):
                pass

            @pysnooper.snoop()
            def bar(self):
                pass

# Generated at 2022-06-10 21:33:32.422384
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    def f(a, b):
        return a + b
    s = Tracer()
    new_f = s(f)
    new_f(2, 3)


# Generated at 2022-06-10 21:33:37.185664
# Unit test for function get_write_function
def test_get_write_function():
    """
    x = 1
    def write(s):
        global x
        x += s
    get_write_function(write)(1)
    assert x == 2
    """




# Generated at 2022-06-10 21:33:38.700354
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass


# Generated at 2022-06-10 21:33:39.444227
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass

# Generated at 2022-06-10 21:33:48.103566
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    code = compile('def _():\n    pass', '', 'exec')
    frame = _create_frame(code)
    trace_function = MagicMock()
    tracer = Tracer(watch=['foo'], depth=1)
    tracer.frame_to_local_reprs[frame] = {'foo': 'bar'}
    tracer.start_times[frame] = '123'
    tracer.target_codes.add(code)
    tracer.target_frames.add(frame)
    tracer.thread_local.original_trace_functions = [trace_function]
    sys.settrace(trace_function)
    tracer.__exit__(None, None, None)
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}

# Generated at 2022-06-10 21:33:52.194704
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # pytest.skip('skip Tracer_trace tests')
    pysnooper.snoop(depth=2)
    @pysnooper.snoop()
    def f1():
        print(1)
    def f2():
        print(2)
    def f3():
        print(3)
        f1()
    def f4():
        print(4)
        f3()
    f4()



# Generated at 2022-06-10 21:33:52.926613
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass

# Generated at 2022-06-10 21:33:56.843928
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper.tracer
    def test_func():
        ...
    tracer = pysnooper.tracer.Tracer()
    tracer.__call__(test_func)
    ...


# Generated at 2022-06-10 21:34:20.743776
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import linecache
    def foo():
        pass
    assert (get_path_and_source_from_frame(sys._getframe(0)) ==
            (get_path_and_source_from_frame.__code__.co_filename,
             linecache.getlines(getattr(foo, '__code__', None).co_filename)))
test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:34:27.104071
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = False
    output = StringIO()

# Generated at 2022-06-10 21:34:29.152713
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return 1
    assert get_path_and_source_from_frame(f.__code__.co_offset)



# Generated at 2022-06-10 21:34:40.986569
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    ##
    from io import StringIO
    from contextlib import contextmanager

    io = StringIO()

    @contextmanager
    def captured_output(stream=None):
        old = sys.stdout
        if stream is None:
            stream = StringIO()
        sys.stdout = stream
        try:
            yield stream
        finally:
            sys.stdout = old

    @pysnooper.snoop(output=io, truncate=3)
    def test_simple_function():
        print("Hello")

    with captured_output() as out:
        test_simple_function()

    assert out.getvalue() == io.getvalue() + "\n"
    
if __name__ == "__main__":
    test_Tracer___exit__()

    # To make the above code work, method __enter__

# Generated at 2022-06-10 21:34:51.699992
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # test_Tracer___enter__()

    # This function tests method __enter__ of class Tracer.

    from pysnooper.tracer import _frame_candidate  # noqa
    from pysnooper.tracer import _source_path  # noqa
    from pysnooper.tracer import _source_line  # noqa

    # Needed by test_Tracer.__init__
    output = None
    thread_info = False
    max_variable_length = 100
    watch = ('foo', 'bar')
    watch_explode = ('foo', 'self')
    depth = 1
    prefix = ''
    overwrite = False
    custom_repr = \
        ((type,
          eval),)

    # Needed by class Tracer.__init__

# Generated at 2022-06-10 21:35:06.727425
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # This test uses nose as a unit test.

    # This is just a dummy class that has a `get_source` method, to
    # mimic a loader.
    class FakeLoader(object):
        def get_source(self, module_name):
            return '\n'.join(['a = 2', 'b = 3'])

    # This is just a dummy class that has a `read` method, to mimic
    # an open file.
    class FakeFile(object):
        def __init__(self, content):
            self.content = content

        def read(self, *args, **kwargs):
            return self.content

    # This is a dummy object that has a linecache attribute.
    class FakeLineCache(object):
        linecache = None


# Generated at 2022-06-10 21:35:17.342855
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .patch import patch
    from . import utils
    with patch.object(utils, 'get_shortish_repr', lambda x: str(x)):
        with patch.object(sys, 'frozen', False):
            with patch.object(sys.modules['__main__'], '__file__',
                              '<stdin>'):
                with patch.object(sys.modules['__main__'], '__loader__',
                                  None):
                    with patch.object(sys.modules['__main__'], '__name__',
                                      '__main__'):
                        with open(os.devnull, 'rb') as f:
                            with patch.object(sys, 'stdin', f):
                                frame = sys._getframe()

# Generated at 2022-06-10 21:35:24.683499
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        local_var = "I'm a local!"
        import os
        os.path
        return local_var

    frame = f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert source == ['import os',
                      '',
                      'os.path',
                      'return local_var'], source
    assert path == __file__, path



# Generated at 2022-06-10 21:35:34.747861
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    fromStringIO = io.StringIO
    import traceback
    class stub_threading(object):
        class Thread(object):
            def __init__(self, **kwargs): pass
            def getName(self): return 'MainThread'
    stub_threading_obj = stub_threading()
    stub_datetime_obj = stub_datetime(datetime_=datetime.datetime)
    stub_datetime_obj.timedelta = datetime.timedelta
    stub_datetime_obj.datetime = datetime.datetime
    stub_datetime_obj.datetime.now = datetime.datetime.now
    stub_datetime_obj.datetime.time = datetime.datetime.time
    stub_datetime_obj.time = time

# Generated at 2022-06-10 21:35:48.044977
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    def test_exit(self, exc_type, exc_value, exc_traceback):
        self.assertEqual(exc_type, None)
        self.assertEqual(exc_value, None)
        self.assertEqual(exc_traceback, None)
        stack = self.thread_local.original_trace_functions
        sys.settrace(stack.pop())
        calling_frame = inspect.currentframe().f_back
        self.target_frames.discard(calling_frame)
        self.frame_to_local_reprs.pop(calling_frame, None)

        ### Writing elapsed time: #############################################
        #                                                                     #
        start_time = self.start_times.pop(calling_frame)
        duration = datetime_module.datetime.now() - start_time
       

# Generated at 2022-06-10 21:37:06.109137
# Unit test for function get_write_function
def test_get_write_function():
    import pytest
    import io
    import StringIO
    import tempfile
    import os
    
    write_to_stderr_output = get_write_function(None, None)
    assert callable(write_to_stderr_output)
    write_to_file_output = tempfile.NamedTemporaryFile()
    write = get_write_function(write_to_file_output, None)
    assert callable(write)

    write(u'אבג')
    write_to_file_output.file.seek(0)
    assert write_to_file_output.file.read() == u'אבג'.encode('utf8')
    write_to_file_output.file.close()

    write_to_file_path = tempfile.mkdtemp()
    write

# Generated at 2022-06-10 21:37:12.016492
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.watch == []
    assert tracer.custom_repr == []
    tracer = Tracer(watch='a', prefix='foo', depth=2)
    assert tracer.watch == ['a']
    assert tracer.prefix == 'foo'
    assert tracer.depth == 2


# Generated at 2022-06-10 21:37:14.535990
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """
    This is to test the method trace of class Tracer
    """
    pass


# Generated at 2022-06-10 21:37:24.443490
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    the_globals = {}
    the_locals = {}
    def the_function(x):
        "The function docstring"
        if x:
            print("Hello world!")
            print("Goodbye world!")
        y = 7
        return y * 2
    the_frame = inspect.currentframe()
    the_code = the_function.__code__
    result = get_path_and_source_from_frame(the_frame)
    assert result == (the_code.co_filename, the_code.co_lnotab[:the_code.co_firstlineno])

# Generated at 2022-06-10 21:37:37.737114
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    snooper = Tracer()
    import os, sys
    all_local_variables = {'snooper': snooper, 'frame': None, 'os': os, 'sys': sys, 'function_or_class': None}

# Generated at 2022-06-10 21:37:40.177615
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    try:
        foo = Tracer()
        foo.__exit__()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-10 21:37:50.033245
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect

    def fake_file(source_lines, file_name='<fake_file>',
                  module_name='fake_module'):
        def fake_loader(module_name):
            return FakeLoader(module_name)

        class FakeLoader(object):
            '''A fake module Loader for testing purposes.'''
            def __init__(self, module_name):
                self.module_name = module_name
            def get_source(self, module_name):
                if self.module_name != module_name:
                    raise ImportError("Module name mismatch")
                return '\n'.join(source_lines)

        r_file_name, r_source = get_path_and_source_from_frame(
            inspect.currentframe())


# Generated at 2022-06-10 21:37:55.567057
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe()
    filename, source_lines = get_path_and_source_from_frame(frame)
    assert source_lines[frame.f_lineno - 1].strip() == 'line 1'
    assert filename == __file__
    if pycompat.IS_WINDOWS:
        # Make sure we can read the source even if the path has \ in it
        _, filename = get_path_and_source_from_frame(get_path_and_source_from_frame.__code__.co_firstlineno + 1)
        with open(filename) as f:
            assert f.read().split('\n')[1].strip() == 'line 2'

# Generated at 2022-06-10 21:38:00.506147
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import sys

    @pysnooper.snoop()
    def foo():
        pass

    pysnooper.snoop(output=sys.stderr, depth=2)(foo)


# Generated at 2022-06-10 21:38:11.514877
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    DISABLED = False
    def tester_function(num):
        return num ** 2
    tester_function.__code__ = tester_function.__code__.replace(
        co_name='tester_function'
    )
    m = mock.Mock()
    with Tracer(output=m):
        assert 8 == tester_function(2)
    assert m.call_args[0][0].strip() == 'Call started:   tester_function({num!r})'.format(
        num=2
    )
    assert m.call_args_list[1][0][0].strip() == 'Return value:.. {num!r}'.format(
        num=4
    )
    DISABLED = True



# Generated at 2022-06-10 21:38:46.030670
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    if False:
        # TODO: Write code here to test Tracer.__call__
        pass

# Generated at 2022-06-10 21:38:51.344072
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import tests
    assert get_path_and_source_from_frame(
        tests.get_frame_by_name(__name__))[0] == os.path.abspath(__file__)
    assert get_path_and_source_from_frame(sys._getframe())[0] == \
        os.path.abspath(__file__)



# Generated at 2022-06-10 21:38:59.661426
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  with pytest.raises(NotImplementedError):
        @pysnooper.snoop(output=FileIO(__file__ + '.output', 'wb'))
        async def coro(x):
            yield 1
        await coro(1)

  with pytest.raises(NotImplementedError):
        @pysnooper.snoop(output=FileIO(__file__ + '.output', 'wb'))
        async def coro(x):
            yield 1
        await coro(1)

# Generated at 2022-06-10 21:39:04.543298
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import threading_zombies
    import linecache
    frame = sys._getframe()
    assert get_path_and_source_from_frame(frame) == \
        (threading_zombies.__file__,
         linecache.getlines(threading_zombies.__file__))



# Generated at 2022-06-10 21:39:13.019639
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def decorator():
        def decorate(func):
            return func
        return decorate
    def dummy():
        decorator()
        pass
    dummy_source_path = inspect.getsourcefile(dummy)
    with open(dummy_source_path, 'r', encoding='utf-8') as f:
        dummy_source = f.readlines()
    dummy_code = dummy.__code__
    dummy_frame = dummy.__code__.co_firstlineno
    dummy_call_code = dummy.__code__.co_varnames[2]
    dummy_decorator_code = dummy.__code__.co_varnames[1]
    dummy_watch_common_variable = 'dummy_call_code'
    dummy_watch_exploding = 'dummy_decorator_code'


# Generated at 2022-06-10 21:39:18.324952
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    this_file_contents = pycompat.open(__file__, 'rU').readlines()
    def f():
        pass
    file_name, source = get_path_and_source_from_frame(f.__code__.co_firstlineno)
    assert source == this_file_contents



# Generated at 2022-06-10 21:39:27.317401
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    ''' Unit test for method __exit__ of class Tracer
    '''
    from random import randint
    
    
    
    
    
    
    
    
    
    
    
    
    test_POSTFIX_LEN = 50
    test_FILE_NAME = "test-{0:d}.txt".format(randint(10000, 99999))
    test_OUTPUT_FILENAME = test_FILE_NAME + ".txt"

    def log_output(s):
        '''
        Helper function for unit test
        '''
        with open(test_OUTPUT_FILENAME, 'a', encoding='utf8') as out:
            out.write(s)
            out.flush()


# Generated at 2022-06-10 21:39:37.278556
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test_tracer_trace():
        def method_with_call():
            x = 1
            call_other_method()
            x = 2

        def call_other_method():
            return

        def method_with_call_and_return():
            x = 1
            call_other_method()
            return()

        def method_with_call_and_exception():
            x = 1
            call_other_method()
            raise Exception('')

        def method_with_call_and_oneline_decorator():
            @spam
            def decorated_method():
                pass

            decorated_method()

        def method_with_call_and_multiline_decorator():
            @spam
            @eggs
            def decorated_method():
                pass

            decorated_method()


# Generated at 2022-06-10 21:39:39.813843
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print("Start to test Tracer.trace()")
    with Tracer():
        pass

# Adjustment of method trace of class Tracer

# Generated at 2022-06-10 21:39:51.243957
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class DummyClass(object):
        def func1(self):
            pass
        def func2(self):
            pass
    @snoop(watch=['i', 'j'])
    def my_function(a, b):
        i = 1
        j = 2
        k = 3
        k += b
        return a + k
    class MyClass(DummyClass):
        @snoop(watch=['i', 'j'])
        def func1(self):
            i = 1
            j = 2
            k = 3
            k += 1
            return i + j + k
        @snoop(watch=['i', 'j'])
        def func2(self):
            i = 1
            j = 2
            k = 3
            k += 2
            return i + j + k
   

# Generated at 2022-06-10 21:42:27.817365
# Unit test for constructor of class Tracer
def test_Tracer():
    def ret1():
        return 1
    def ret2():
        return 2
        return 3
    def ret4():
        return 4
        return 5
        return 6

    def inner():
        return ret1() + ret2()
    def outer():
        return ret4() + inner()
    with Tracer() as tr:
        outer()

    assert len(tr.target_codes) == 5
    assert len(tr.target_frames) == 2
    # We use the function name and lineno to identify the code, since
    # SourcePaths may be different on different machines.
    assert len([c for c in tr.target_codes if c.co_name=='ret1' and c.co_firstlineno==9]) == 1

# Generated at 2022-06-10 21:42:35.700015
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_path_and_source_from_frame_for_this_file():
        return get_path_and_source_from_frame(
            inspect.currentframe().f_back
        )
    path, source = get_path_and_source_from_frame_for_this_file()
    assert path == __file__
    assert isinstance(source, list)
    assert source[0] == 'def get_path_and_source_from_frame():'

