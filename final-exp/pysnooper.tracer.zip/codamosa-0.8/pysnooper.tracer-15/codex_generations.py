

# Generated at 2022-06-10 21:33:15.525788
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer=Tracer()
    # Test for exc_type, exc_value, exc_traceback are not None
    exception = AssertionError('This is an exception')
    tracer.__exit__(type(exception), exception, None)

test_Tracer___exit__()



# Generated at 2022-06-10 21:33:17.954347
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    @pysnooper.snoop()
    def foo(a, b):
        return a + b
    assert foo(a=1, b=2) == 3


# Generated at 2022-06-10 21:33:28.851876
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import textwrap
    import imp
    import tempfile
    import os
    import sys
    import ctypes
    import platform
    import pycompat
    temp_file = pycompat.temp_named_file()
    with open(temp_file, 'w') as f:
        f.write(textwrap.dedent('''
        def foo():
            pass

        with pysnooper.snoop():
            foo()
        '''))
    m = imp.load_source('temp_mod', temp_file)
    output = io.StringIO()
    tracer = Tracer(output=output)
    tracer(m.foo)()
    output.seek(0)
    output_text = output.read()

# Generated at 2022-06-10 21:33:43.940655
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import mock
    from pysnooper import utils
    from pysnooper.tracing import BaseVariable, CommonVariable, Exploding
    mock_output = mock.MagicMock()
    mock_watch = mock.MagicMock()
    mock_watch_explode = mock.MagicMock()
    mock_depth = mock.MagicMock()
    mock_prefix = mock.MagicMock()
    mock_overwrite = mock.MagicMock()
    mock_thread_info = mock.MagicMock()
    mock_custom_repr = mock.MagicMock()
    mock_max_variable_length = mock.MagicMock()
    mock_normalize = mock.MagicMock()
    mock_relative_time = mock.MagicMock()
    mock_get_write_function = mock.MagicMock()
    mock

# Generated at 2022-06-10 21:33:54.599121
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .tracing import Tracer
    import inspect
    import pycompat
    from .tracing import thread_global
    from .tracing import utils
    from .tracing import os
  
    tracer = Tracer()
  
    frame = inspect.currentframe()
    event = 'call'
    arg = None
    # event = 'call', logic block number: 1
    if not (frame.f_code in tracer.target_codes or frame in tracer.target_frames):
        if tracer.depth == 1:
            # We did the most common and quickest check above, because the
            # trace function runs so incredibly often, therefore it's
            # crucial to hyper-optimize it for the common case.
            return None
        elif tracer._is_internal_frame(frame):
            return None

# Generated at 2022-06-10 21:34:01.933331
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    
    tracer = Tracer()
    tracer._write = mock.Mock()
    # Make any exception raised in __exit__ do nothing
    def raise_exception_for_no_reason(*args, **kwargs):
        raise Exception('This exception should not be raised under any '
                        'circumstance')
    tracer.write = raise_exception_for_no_reason

    with tracer:
        pass

    tracer._write.assert_called_once_with(u'')

# Generated at 2022-06-10 21:34:03.024213
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    #TODO
    pass


# Generated at 2022-06-10 21:34:06.280801
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_source_and_path(func):
        def f(x):
            return x + 1
        return get_path_and_source_from_frame(frame=f.__code__.co_firstlineno)



# Generated at 2022-06-10 21:34:13.586802
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import sys
    import pytest
    from .variables import Variable
    from .utils import WritableStream

    class TestFileWriter(FileWriter):
        def write_to_file(self, file_obj):
            file_obj.write('test')

    class AnyFile(io.RawIOBase):
        def __init__(self):
            self.closed = False

        def close(self):
            pass

        def __enter__(self):
            return self

        def __exit__(self, type, val, tb):
            pass

    def write_to_string_io(s):
        bytes_io = getattr(output, 'bytes_io', None)
        if bytes_io is None:
            output.bytes_io = io.BytesIO()
            bytes_io = output.bytes_io


# Generated at 2022-06-10 21:34:19.859259
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def gen_test():
        print('start')
        yield 1
        yield 2
        yield 3
        print('stop')
    def test():
        print('start')
        yield 1
        yield 2
        yield 3
        print('stop')
    with Tracer(output=None):
        list(gen_test())
        for i in test():
            pass


# Generated at 2022-06-10 21:35:22.521433
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        g()
    def g():
        return get_local_reprs(frame=sys._getframe(1))

    f()



# Generated at 2022-06-10 21:35:27.997553
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    class TestTracer(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_show_source_path(self):
            pass
        def test_max_variable_length(self):
            pass
    unittest.main()


# Generated at 2022-06-10 21:35:29.418663
# Unit test for constructor of class Tracer
def test_Tracer():
    @Tracer()
    def foo():
        print(1)
        return 2

    assert hasattr(foo, '__wrapped__')
    foo()

# Generated at 2022-06-10 21:35:31.014330
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as tracer:
        1/0


# Generated at 2022-06-10 21:35:38.820650
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import threading
    class Spy(object):
        def action_call(self,action='',frame=None,event='',arg=None,indent='',timestamp=''):
            self.action = action
            self.frame=frame
            self.event=event
            self.arg=arg
            self.indent=indent
            self.timestamp=timestamp
    class SpecialString(str): 
        def __new__(cls, source_line='', *args, **kwargs):
            return str.__new__(cls, *args, **kwargs)
        def lstrip(self):
            return 'def'
        def startswith(self,pattern):
            if pattern == '@':
                return False
            return None

# Generated at 2022-06-10 21:35:55.088966
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    import types
    import warnings
    from contextlib import contextmanager

    # Python 2.7 doesn't have WarningMessage in the standard library.
    # Python 3.4 doesn't have it either until Python 3.4.3.
    # So we're going to fake it.
    class WarningMessage(object):
        _category_name = None

        def __init__(self, message, category, filename, lineno, file=None,
                     line=None):
            self.message = message
            self.category = category
            self.filename = filename
            self.lineno = lineno
            self.file = file
            self.line = line
            self._category_name = None

        def __str__(self):
            line = self.line
            if line is not None:
                line = line.strip

# Generated at 2022-06-10 21:36:07.451906
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import warnings
    warnings.simplefilter('ignore', ResourceWarning)

    from io import BytesIO
    from io import StringIO
    from contextlib import contextmanager

    import datetime_module

    class MockFile(BytesIO):
        def __init__(self, *args, **kwargs):
            super(MockFile, self).__init__(*args, **kwargs)
            self.lines = []

        def write(self, data):
            self.lines.append(data)

        def getvalue(self):
            return b''.join(self.lines)

        def __enter__(self, *args):
            return self

        def __exit__(self, *args):
            pass


# Generated at 2022-06-10 21:36:10.056994
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func(a):
        return a

    assert get_path_and_source_from_frame(func.__code__.co_filename,
                                                            func.__code__)



# Generated at 2022-06-10 21:36:16.336855
# Unit test for constructor of class Tracer
def test_Tracer():
    @snoop(watch=('foo', 'bar.baz', 'a[].b'))
    def f(foo, bar):
        x = foo
        x, y = bar
        yield x, y

    with f.__wrapped__.__wrapped__ as g:
        g()



# Generated at 2022-06-10 21:36:22.047486
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    """Test for Tracer.__call__(self, function_or_class)"""

    for _ in utils.repeat(num_iterations=10, max_length=10):
        DISABLE_SNOOP()
        tracer = Tracer()
        assert tracer.__call__(_.function_or_class) == _.expected
        assert DISABLED



# Generated at 2022-06-10 21:36:55.424815
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    import linecache
    import contextlib
    import tempfile

    def inner_test(file_name, source, expected_path, expected_source):
        frame = inspect.currentframe().f_back # Hack to get a frame
        frame = types.FunctionType(frame.f_code, frame.f_globals,
                                   "abcde-frame", None, None)
        frame.f_code.co_filename = file_name
        path, source_lines = get_path_and_source_from_frame(frame)
        assert path == expected_path
        assert source_lines == expected_source.splitlines()

        linecache.cache[file_name] = None

        # Make sure that we are not reading the file from cache
        path, source = get_path_and_source_from_frame(frame)

# Generated at 2022-06-10 21:36:59.093095
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(Exception):
        _ = Tracer('stdout', watch_explode=(3,), depth='1')


snoop = Tracer()



# Generated at 2022-06-10 21:37:10.425029
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import contextlib
    @contextlib.contextmanager
    def test_file(name, path, contents):
        try:
            with open(path, 'wb') as file:
                file.write(contents.encode('utf-8'))
            if name:
                sys.modules[name] = lambda: None
                sys.modules[name].__file__ = path
            yield
        finally:
            if name:
                del sys.modules[name]
            os.remove(path)
    test_file('my_module', 'my_module.py', '''
            # -*- coding: iso-8859-15 -*-

            a = 1
            ''')
    import my_module # defined above

# Generated at 2022-06-10 21:37:17.632237
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = C('y')
        z = C('z')
        w = C('w')
        del y
        return locals()
    n = C('n')
    n.set(4)
    assert get_local_reprs(f(5).f_back, watch=[n]) == {'z': 'z', 'x': '5',
                                                      'n': 'C(4)'}
del test_get_local_reprs



# Generated at 2022-06-10 21:37:18.633929
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass # TODO

# Generated at 2022-06-10 21:37:27.860438
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__(): 
    from pysnooper.snoop import Tracer
    tracer = Tracer()
    for x in range(6):
        print(x)
        if x == 1:
            # TODO: Find out why there is a key error for line 541
            # with self.assertRaises(KeyError):
            tracer.set_thread_info_padding(True)
        elif x == 2:
            with self.assertRaises(KeyError):
                tracer.set_thread_info_padding(True)
        elif x == 3:
            tracer.set_thread_info_padding(True)
        elif x == 4:
            with self.assertRaises(KeyError):
                tracer.set_thread_info_padding(True)
        elif x == 5:
            tracer.set_thread

# Generated at 2022-06-10 21:37:39.696873
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class TestTracer___call__(unittest.TestCase):
        def test(self):
            def function_or_class():
                pass
            def get_write_function(output, overwrite):
                return write_function
            def write_function(s):
                pass
            class ClassMethod(object):
                pass
            class Class(object):
                pass
            @pysnooper.snoop(output=None, watch=(), watch_explode=(), depth=1,
                             prefix='', overwrite=False, thread_info=False, custom_repr=(),
                             max_variable_length=100, normalize=False, relative_time=False)
            def test_function_or_class():
                pass

# Generated at 2022-06-10 21:37:41.006871
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass
# Code for testing the Tracer class

# Generated at 2022-06-10 21:37:44.048731
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(frame_from_this_function()) == (
        __file__, _get_path_and_source_from_frame_source
    )




# Generated at 2022-06-10 21:37:52.755295
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import inspect
    import functools
    import threading
    from datetime import datetime
    import sys
    import pycompat
    import os
    import traceback
    from unittest.mock import MagicMock
    from pysnooper import utils
    from pysnooper import pycompat
    from pysnooper.pycompat import test_bytecode_spec
    from pysnooper import opcode

    ### Checking whether we should trace this line: ##########################
    #                                                                        #

# Generated at 2022-06-10 21:38:27.118071
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import uuid
    import os
    import io
    import traceback
    import tempfile
    import shutil
    import time
    def pytest_generate_tests(metafunc):
        idlist = []
        argvalues = []
        for scenario in metafunc.cls.scenarios:
            idlist.append(scenario[0])
            items = scenario[1].items()
            argnames = [x[0] for x in items]
            argvalues.append(([x[1] for x in items]))
        metafunc.parametrize(argnames, argvalues, ids=idlist, scope="class")
    
    output_dir = tempfile.mkdtemp()

# Generated at 2022-06-10 21:38:30.665391
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Create class Tracer and method trace
    tracer = Tracer()
    tracer.trace(1, 2, 3)
# Test Tracer

# Generated at 2022-06-10 21:38:45.044540
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    DISABLED = False
    global thread_global
    thread_global = threading.local()
    thread_global.depth = -1
    code_object = types.CodeType(0,0,0,0,0,b'\x64\x00\x00d\x01\x00d\x02\x00\x17S',
                                 (),(),('num',),'','','',0,'','',())
    frame_object = types.FrameType(None,
                                   os.path.abspath(__file__),
                                   False,
                                   None,
                                   None)
    frame_object.f_code = code_object
    frame_object.f_lineno = 1
    frame_object.f_lasti = 0

# Generated at 2022-06-10 21:38:48.374209
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        source = inspect.getsource(foo)
        assert source == get_path_and_source_from_frame(inspect.currentframe())[1]
    
    foo()
    
assert test_get_path_and_source_from_frame() == None


# Generated at 2022-06-10 21:39:00.263143
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    class TestTracer(unittest.TestCase):
        def setUp(self):
            self.tracer = Tracer()

        # Test for method trace of class Tracer
        def test_trace(self):
            import __main__
            ### Checking whether we should trace this line: #######################
            #                                                                     #
            # We should trace this line either if it's in the decorated function,
            # or the user asked to go a few levels deeper and we're within that
            # number of levels deeper.


# Generated at 2022-06-10 21:39:10.388016
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.max_variable_length = 100

    @tracer
    def foo():
        pass

    foo()
# unit test for method write of class Tracer
tracer = Tracer()
try:
    tracer.write('test')
except TypeError:
    assert True
else:
    assert False

# unit test for method _wrap_function of class Tracer
try:
    tracer._wrap_function(foo)
except NotImplementedError:
    assert True
else:
    assert False

# unit test for method _wrap_class of class Tracer
try:
    tracer._wrap_class(foo)
except NotImplementedError:
    assert True
else:
    assert False

# unit test for method _is_internal_frame of class Tracer
tracer._

# Generated at 2022-06-10 21:39:21.346377
# Unit test for constructor of class Tracer
def test_Tracer():
    # This is the body of the module-level `snoop` decorator:
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = True
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False

    tracer = Tracer(
        output=None, watch=watch, watch_explode=watch_explode, depth=depth,
        prefix=prefix, overwrite=overwrite, thread_info=thread_info,
        custom_repr=custom_repr, max_variable_length=max_variable_length,
        normalize=normalize, relative_time=relative_time
    )
    return tracer



# Generated at 2022-06-10 21:39:24.468266
# Unit test for function get_write_function
def test_get_write_function():
    from .test import Variable
    def f(s): print('Write', s)
    write = get_write_function(f, False)
    write('test')
    write = get_write_function(f, True)
    write('test')



# Generated at 2022-06-10 21:39:29.134361
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    source = ['# coding: utf-8',
              'def f():',
              "    print('hello')"]
    file_name = 'bla.py'
    result = get_path_and_source_from_frame(inspect.currentframe())
    assert result == ('bla.py', source)



# Generated at 2022-06-10 21:39:39.362945
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class Foo(object):
        def __init__(self, value):
            self.value = value
    def fn():
        for _ in range(0):
            pass
    @snoop()
    def fn2():
        for _ in range(0):
            pass
    @snoop()
    def fn3():
        raise Exception
    @snoop(watch=('self.value',))
    def fn4(self):
        for _ in range(0):
            pass
    @snoop()
    def fn5():
        fn()
        fn2()
        fn3()
    @snoop()
    def fn6():
        return
    obj = Foo('yolo')
    fn2()
    fn5()
    fn4(obj)
    fn6()

# Generated at 2022-06-10 21:40:02.215050
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass

# Generated at 2022-06-10 21:40:04.529521
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with raises(Exception):
        with Tracer():
            pass
test_Tracer___exit__()


# Generated at 2022-06-10 21:40:16.676830
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tests
    import types
    def x(): return inspect.currentframe()
    frame = x()
    path, source = get_path_and_source_from_frame(frame)
    assert path == tests.__file__
    assert source == open(tests.__file__, 'r').read().splitlines()

    class A(object): pass
    a = A()
    a.__file__ = 'foo'
    frame = a.__getattribute__('__code__').co_filename
    path, source = get_path_and_source_from_frame(frame)
    assert path == path
    assert source == UnavailableSource()

    class Loader(object): pass
    loader = Loader()
    loader.get_source = lambda mn: ['x']
    frame = types.ModuleType('foo').a = 5


# Generated at 2022-06-10 21:40:25.234437
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_path = os.path.join(os.path.dirname(__file__),
                             '_test_get_path_and_source_from_frame.py')
    with open(test_path, 'w', encoding='utf-8') as f:
        f.write('# -*- coding: utf-8 -*-\n')

# Generated at 2022-06-10 21:40:38.424727
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print("Testing Tracer.trace ...")

    from pysnooper import snoop
    global_variable = 'global_string'

    # 0. Function
    @snoop(prefix='function_')
    def function(argument, keyword=2, argument_3=None):
        """This is a docstring."""
        local_variable = 'local_string'
        if 'tr' in local_variable:
            local_variable = 'local_string_2'
        else:
            local_variable = 'local_string_3'
        print('This is a print statement.')
        return local_variable

    # 1. Trace call
    assert 'function_trace' in globals()
    test_frame_1, test_event_1, test_arg_1 = frame, event, arg

    # 2. Trace event call
   

# Generated at 2022-06-10 21:40:42.949058
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename
    path, source = get_path_and_source_from_frame(frame)
    assert path == frame
    assert len(source) == 1
    assert source[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-10 21:40:51.189645
# Unit test for function get_local_reprs
def test_get_local_reprs():
    class Foo: pass
    foo = Foo()
    bar = Foo()
    foo.x = bar
    bar.y = foo
    z = 5
    watch = (CommonVariable('x'), CommonVariable('y'), CommonVariable('z'))
    result = get_local_reprs({'foo': foo, 'bar': bar, 'z': z}, watch)
    assert result == collections.OrderedDict({
        'foo': 'Foo(x=...)',
        'x': 'Foo(y=...)',
        'y': 'Foo(x=...)',
        'bar': 'Foo(y=...)',
        'z': '5',
    })
    assert result['foo'] is not foo
    assert result['x'] is not bar
    assert result['y'] is not foo

# Generated at 2022-06-10 21:41:01.728149
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return sys._getframe()
    frame = foo()
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__

# Generated at 2022-06-10 21:41:08.755295
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global xy
    global xyz
    xy = 1
    xyz = 1
    def global_increment(number):
        global xy
        global xyz
        xy += 1
        xyz += 1
        return number
    temp_Tracer = Tracer(max_variable_length=None)
    code_wrapper = temp_Tracer._wrap_function(global_increment)
    with temp_Tracer:
        code_wrapper(1)
    assert xyz == 2
    assert xy == 2


# Generated at 2022-06-10 21:41:18.149731
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from tests.test_utils import assert_equal
    from .with_statement import Context
    def fn():
        pass
    assert_equal(get_path_and_source_from_frame(fn.__code__.co_consts[0]),
                 (fn.__code__.co_filename, UnavailableSource()))
    with Context():
        assert_equal(get_path_and_source_from_frame(fn.__code__.co_consts[0]),
                     (fn.__code__.co_filename, UnavailableSource()))
        def fn():
            pass
    assert_equal(get_path_and_source_from_frame(fn.__code__.co_consts[0]),
                 (fn.__code__.co_filename, UnavailableSource()))

# Generated at 2022-06-10 21:41:39.318652
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    snoop = pysnooper.snoop()

# Generated at 2022-06-10 21:41:45.895060
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import datetime
    import inspect
    import functools
    import threading
    import traceback
    import itertools
    import opcode
    import utils
    import pycompat
    from .utils import BaseVariable, ThreadGlobal
    from .utils import get_path_and_source_from_frame
    from .utils import CommonVariable, Exploding
    from .utils import get_write_function
    from .utils import get_local_reprs
    from .utils import DISABLED
    from .utils import pycompat

    global thread_global
    thread_global = ThreadGlobal()
    global datetime_module
    datetime_module = datetime
    global traceback_module
    traceback_module = traceback
    global itertools_module
    itertools_module = itertools
   

# Generated at 2022-06-10 21:41:47.419991
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass # TODO


# Generated at 2022-06-10 21:41:48.770196
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    assert True==False

# Generated at 2022-06-10 21:41:52.517889
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    with open('temp.txt', 'w') as file_object:
        file_object.write('Spam, spam, spam...\n')
        file_object.write('And spam!\n')



# Generated at 2022-06-10 21:42:00.515205
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Test for a case when exception was thrown
    # Creation of mock object
    mock_self = Mock()
    mock_exc_type = Mock()
    mock_exc_value = Mock()
    mock_exc_traceback = Mock()
    # Mocking of methods
    mock_self.__exit__.return_value = None
    mock_exc_type.__name__ = "Exception"
    mock_exc_value.__repr__.return_value = "Hello world!"
    mock_exc_traceback.tb_frame.f_code.co_filename = __file__
    mock_exc_traceback.tb_lineno = 180
    mock_exc_traceback.tb_frame.f_lasti = 56
    # Call of the method

# Generated at 2022-06-10 21:42:11.566219
# Unit test for function get_write_function
def test_get_write_function():
    def get_write_function():
        return get_write_function(None, overwrite=False)
    clean = test_get_write_function.clean
    assert clean(get_write_function())

    def get_write_function_stderr():
        return get_write_function(sys.stderr, overwrite=False)
    assert clean(get_write_function_stderr())

    def get_write_function_stringio():
        from io import StringIO
        return get_write_function(StringIO(), overwrite=False)
    assert clean(get_write_function_stringio())

    def get_write_function_function():
        def write(s):
            print(s)
        return get_write_function(write, overwrite=False)
    assert clean(get_write_function_function())


# Generated at 2022-06-10 21:42:20.789266
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def foo(x, y=3):
        name = 'hi'
        return name

    with pysnooper.snoop():
        foo(1)

    expected_log = """
    Begin tracing...

    Starting var:.. name = ''
    Return value:.. 'hi'
    Elapsed time: 0:00:00.000"""

    assert utils.normalize_log(actual_log) == utils.normalize_log(expected_log)

    actual_log = ""
    with pysnooper.snoop():
        foo(1, 2)

    expected_log = """
    Begin tracing...

    Starting var:.. y = 2
    Starting var:.. name = ''
    Return value:.. 'hi'
    Elapsed time: 0:00:00.000"""

    assert utils.normalize

# Generated at 2022-06-10 21:42:28.185322
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def new_script_executor(args):

        def callback(frame, event, arg):
            if event == "call":
                path, source = get_path_and_source_from_frame(frame)
                # noinspection PyUnboundLocalVariable
                lines = inspect.getframeinfo(frame)[1]
                if path:
                    assert os.path.exists(path), \
                        "Path exists, but `{}` doesn't.".format(path)
                else:
                    assert not os.path.exists(path), \
                        "Path doesn't exists, but `{}` does.".format(path)
                assert lines[0] in (source[lines[0] - 1],
                                    "SOURCE IS UNAVAILABLE")

# Generated at 2022-06-10 21:42:41.244321
# Unit test for constructor of class Tracer
def test_Tracer():
    global DISABLED
    with pytest.raises(NotImplementedError):
        Tracer(thread_info=True, normalize=True)
    with pytest.raises(NotImplementedError):
        Tracer(depth=5)
    with pytest.raises(ValueError):
        Tracer(depth=0)
    with pytest.raises(ValueError):
        Tracer(depth=-1)
    Tracer()
    Tracer(depth=1)
    Tracer(depth=2)
    Tracer(watch=('foo', 'bar', 'baz'))
    Tracer(watch_explode=('foo', 'bar', 'baz'))
    Tracer(watch=('foo', 'bar', 'baz'), watch_explode=('foo', 'bar', 'baz'))
   