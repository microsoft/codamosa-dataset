

# Generated at 2022-06-10 21:33:08.015878
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        x = 4
    result = get_path_and_source_from_frame(sys._getframe())
    assert result == ('python_path', ['x = 4'])




# Generated at 2022-06-10 21:33:11.773475
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    def f():
        pass
    frame = inspect.stack()[1][0]
    path, source = get_path_and_source_from_frame(frame)
    assert source[0] == 'def f():'
    assert source[1] == '    pass'



# Generated at 2022-06-10 21:33:16.360094
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Pass a class.
    def test_case_0(cls):
        cls = Tracer().__call__(cls)
        cls()
    # Pass a function.
    def test_case_1(function):
        function = Tracer().__call__(function)
        function()
    # Pass a coroutine.
    def test_case_2(coroutine):
        coroutine = Tracer().__call__(coroutine)
        coroutine()

# Generated at 2022-06-10 21:33:27.604859
# Unit test for constructor of class Tracer
def test_Tracer():
    '''
    An example of unit test for constructor
    '''
    global DISABLED


# Generated at 2022-06-10 21:33:42.884950
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    def test_one_thread_no_watch(mocker):
        mocker.patch('pysnooper.snooper.get_write_function')
        mocker.patch('pysnooper.snooper.datetime.datetime')
        mocker.patch('pysnooper.snooper.threading.current_thread')
        mocker.patch('pysnooper.snooper.threading.Thread.getName')
        mocker.patch('pysnooper.snooper.inspect.currentframe')
        mocker.patch('pysnooper.snooper.sys.gettrace')
        mocker.patch('pysnooper.snooper.sys.settrace')
        
        # Setup mocks
        sys.gettrace.return_value = None
        datetime.datetime.now

# Generated at 2022-06-10 21:33:53.693377
# Unit test for constructor of class Tracer

# Generated at 2022-06-10 21:34:04.828088
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    import threading
    import traceback
    import inspect

    def get_path_and_source_from_frame(frame):
        # Get frame source file path and line
        if frame.f_code.co_filename.endswith('.pyc'):
            f_filename = frame.f_code.co_filename[:-1]
        else:
            f_filename = frame.f_code.co_filename
        source = inspect.getsourcelines(frame)[0]
        return f_filename, source

    def get_local_reprs(frame,
                        watch=(), custom_repr=(),
                        max_length=100, normalize=False):
        '''Get local reprs of a frame'''
        # Get local reprs of a frame

# Generated at 2022-06-10 21:34:12.986397
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def myfunc(x):
        y = x
        return x + y
    frame = sys._getframe(1)
    var1, var2 = myfunc(x=1)
    frame.f_locals['z'] = 'a' * 100
    result = get_local_reprs(frame, max_length=50, normalize=True)
    assert result == {'x': '1',
                      'y': '1',
                      'z': 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa...'}
    result = get_local_reprs(frame, max_length=50, normalize=False)
    assert result == {'x': '1',
                      'y': '1',
                      'z': "'" + 'a' * 50 + "...'"}

# Generated at 2022-06-10 21:34:25.261060
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import unittest
    import os
    import sys
    import functools
    import traceback
    from test import support
    import threading
    import inspect
    import _thread
    import contextlib
    import pycompat
    import utils

    class DisabledException(Exception):
        pass

    Tracer.__init__(
        watch=(),
        watch_explode=(),
        depth=1,
        prefix='',
        overwrite=False,
        thread_info=False,
        custom_repr=(),
        max_variable_length=100,
        normalize=False,
        relative_time=False,
        )


# Generated at 2022-06-10 21:34:34.545221
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import shutil
    path = 'test.txt'
    try:
        s = 'hello world'
        file_writer = FileWriter(path, True)
        file_writer.write(s)
        assert open(path, 'r', encoding='utf-8').read() == s

        s = 'hello world'
        file_writer = FileWriter(path, False)
        file_writer.write(s)
        assert open(path, 'r', encoding='utf-8').read() == 'hello world\nhello world'
    finally:
        try:
            os.remove(path)
        except FileNotFoundError:
            pass



# Generated at 2022-06-10 21:35:05.130454
# Unit test for function get_local_reprs
def test_get_local_reprs():
    a = 1
    b = 2
    c = 'whatever'
    class A: pass
    custom_repr = {}
    def foo():
        class B: pass
        custom_repr['B'] = 'B'
        #d = lambda: 'lambda'
        #custom_repr['<lambda>'] = 'lambda'
        d = 3
        e = A()
        #e.__class__.__module__ += '.spam'
        f = B()
        g = 2
        h = 3
        i = 3
        return sys._getframe()
    frame = foo()
    class B: pass
    watch = [CommonVariable('d', 1, lambda x: '{}'.format(x+1))]

# Generated at 2022-06-10 21:35:15.506973
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def add(x, y):
        zzz = 'x' * (1 << 10)
        return x + y

    with pysnooper.snoop(watch=('x', 'y'), watch_explode=('zzz',), max_variable_length=10):
        add(1, 2)

    with pysnooper.snoop(watch=('x', 'y'), watch_explode=('zzz',), max_variable_length=10):
        add('a', 'b')

    with pysnooper.snoop(watch=('x', 'y'), watch_explode=('zzz',), max_variable_length=None):
        with pytest.raises(Exception):
            add(1, 'b')


# Generated at 2022-06-10 21:35:27.488547
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    get_path_and_source_from_frame = utils.get_path_and_source_from_frame
    frame = (inspect.currentframe())
    source_path, source = get_path_and_source_from_frame(frame)
    print("source_path", source_path)
    print("source", source)
    #print(frame.f_code)
    #print(frame.f_code.co_filename)
    #print(Tracer.__enter__.__code__.co_filename)
    #print(Tracer.__exit__.__code__.co_filename)
    #print(Tracer.__call__.__code__.co_filename)

# Generated at 2022-06-10 21:35:30.611130
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    f = FileWriter('/tmp/abc', overwrite=True)
    f.write('abc\n')
    with open('/tmp/abc') as f:
        assert f.read() == 'abc\n'
    f.write('def\n')
    with open('/tmp/abc') as f:
        assert f.read() == 'def\n'
# Unit tests for get_write_function

# Generated at 2022-06-10 21:35:34.124755
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    t = Tracer()
    for i in range(100):
        for j in range(100):
            for k in range(100):
                for l in range(100):
                    for m in range(100):
                        t.trace(i,j,k)

# Generated at 2022-06-10 21:35:47.359675
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    x = lambda: None

# Generated at 2022-06-10 21:35:55.098140
# Unit test for function get_write_function
def test_get_write_function():
    assert callable(get_write_function(None, False))
    assert callable(get_write_function(sys.stderr, False))
    assert callable(get_write_function('abc', False))
    assert callable(get_write_function(utils.WritableStream(), False))
    assert callable(get_write_function(utils.WritableStream(), False))

    def custom_write(s):
        pass

    assert get_write_function(custom_write, False) is custom_write

    assert isinstance(get_write_function('abc', True), FileWriter)



# Generated at 2022-06-10 21:35:57.048638
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(watch=('spam', 'egg')):
        pass

# Generated at 2022-06-10 21:36:12.608336
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # test_FileWriter_write.py
    import tempfile
    path = tempfile.mktemp()

    # We are going to write to this file, and then confirm the contents.
    file_writer = FileWriter(path, False)
    file_writer.write(u'א ב ג ד ה ו ז')
    with open(path, 'rb') as output_file:
        assert output_file.read() == utils.shitcode(u'א ב ג ד ה ו ז')

    # Now we're going to write to it again, and confirm that the contents were
    # added and didn't get wiped.
    file_writer.write(u'ח ט י כ ל מ נ')

# Generated at 2022-06-10 21:36:19.479607
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import pdb
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    path, source = result
    search_string = 'def test_get_path_and_source_from_frame():'
    found_it = False
    for line in source:
        if search_string in line:
            found_it = True
            break
    assert found_it
    assert os.path.abspath(path) == os.path.abspath(__file__)
    assert result == get_path_and_source_from_frame(frame)



# Generated at 2022-06-10 21:36:42.709563
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest

    @pytest.fixture
    def test_target():
        @pysnooper.snoop()
        def func():
            pass

        return func

    @pytest.fixture
    def test_function(test_target, monkeypatch):

        def func(*args, **kwargs):
            return test_target.pytest_func.__call__(*args, **kwargs)

        return func

    def test_target_must_be_function(test_target):
        assert inspect.isfunction(test_target)

    def test_target_must_be_wrapped_by_snoop(test_target):
        assert inspect.isfunction(test_target)


# Generated at 2022-06-10 21:36:48.174310
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function(x):
        return x + 1
    frame = inspect.currentframe().f_back
    assert get_path_and_source_from_frame(frame) == (
        __file__,
        open(__file__, 'rb').read().splitlines()
    )



# Generated at 2022-06-10 21:36:59.232995
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def program():
        width = 20
        def fib(n):
            if n <= 1:
                return 1
            return fib(n - 1) + fib(n - 2)
        for n in range(1, width + 1):
            print('{n:2}: {fib_result:3}'.format(n=n,
                                                 fib_result=fib(n)))
    result = trim(capture(lambda: Tracer()(program)()))

# Generated at 2022-06-10 21:37:00.555376
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
	pass


# Generated at 2022-06-10 21:37:08.041036
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function(a):
        """\
        Hello world!
        """
        b = 2
    frame = test_function.__code__.co_filename, 0, None, test_function.__code__, test_function.__globals__
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0].strip().startswith('def test_function(a):')
    assert source[1].strip() == '"""Hello world!"""'
    assert source[2].strip() == 'b = 2'



# Generated at 2022-06-10 21:37:18.869657
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import _pysnooper as module
    # from _pysnooper import Tracer
    # assert module.Tracer is Tracer


    class Foo:
        x = 10
        def __init__(*args, **kwargs):
            pass

        def bar(*args, **kwargs):
            pass

    # Tracer.__init__ = lambda *args, **kwargs: None
    import sys
    old_modules = sys.modules.copy()
    old_snoop_disabled = module.DISABLED
    import io
    with io.StringIO() as f:
        module.DISABLED = False
        module.get_write_function = lambda output, overwrite: lambda s: None
        module.start_line = lambda frame: frame.f_lineno


# Generated at 2022-06-10 21:37:27.960728
# Unit test for function get_write_function
def test_get_write_function():
    class StubWritableStream:
        def write(self, s):
            raise Exception("I'm the function you're looking for")
    stub_writable_stream = StubWritableStream()
    with utils.assignment_guard(sys.stderr, utils.NonWritableStream(4096)):
        assert get_write_function(stub_writable_stream, False) is stub_writable_stream.write
    with utils.assignment_guard(sys.stderr, utils.NonWritableStream(4096)):
        assert get_write_function(utils.NonWritableStream(4096), False) is sys.stderr.write
    assert get_write_function(utils.NonWritableStream(4096), True) is sys.stderr.write

# Generated at 2022-06-10 21:37:39.697459
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    os.environ["PYTHONPATH"] = os.getcwd() + ':../'+ os.getcwd()
    path = "test/test_FileWriter.txt"
    with open(path, 'w') as output_file:
        output_file.write("This is a test file")
    file_writer = FileWriter(path, False)
    file_writer.write("This is a test file")
    with open(path, 'w') as output_file:
        output_file.write("This is a test file")
    file_writer.write("This is a test file")
    with open(path, 'w') as output_file:
        output_file.write("This is a test file")
    file_writer.write("This is a test file")

# Generated at 2022-06-10 21:37:45.307694
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    @pysnooper.snoop()
    def fibo(n):
        if n == 0 or n == 1:
            return n
        return fibo(n - 1) + fibo(n - 2)
    fibo(5)

# Method trace of class Tracer
# Time: 596 milliseconds, Memory: 0 bytes

dispatch_table = {}
from functools import partial

# Generated at 2022-06-10 21:37:46.744232
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as sut:
        pass

# Generated at 2022-06-10 21:38:25.291709
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        get_path_and_source_from_frame(inspect.currentframe())
    assert get_path_and_source_from_frame(inspect.currentframe()) == \
                                   (__file__, open(__file__, 'r').readlines())
    assert get_path_and_source_from_frame(foo.__code__) == \
                                   (__file__, open(__file__, 'r').readlines())



# Generated at 2022-06-10 21:38:40.803093
# Unit test for constructor of class Tracer
def test_Tracer():
    @snoop
    def foo(a):
        b = a * 2
        return b

    assert foo.__wrapped__ is foo.__original_function__

    foo_module = foo.__module__
    foo_name = foo.__name__
    foo_filename = foo.__code__.co_filename
    foo_docstring = foo.__doc__
    foo_annotations = foo.__annotations__

    @snoop
    def bar():
        print('hi', end='')
        yield

    assert bar.__wrapped__ is bar.__original_function__

    bar_module = bar.__module__
    bar_name = bar.__name__
    bar_filename = bar.__code__.co_filename
    bar_docstring = bar.__doc__

# Generated at 2022-06-10 21:38:52.299943
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import time
    import unittest

    from . import utils

    class Tracer___exit__Test(unittest.TestCase):

        def test_it(self):
            x = [0]
            def foo():
                x[0] += 1
                time.sleep(0.01)

            with utils.captured_output() as (stdout, stderr):
                with Tracer() as tracer:
                    foo()

            # The output should look like this (note the last four lines):
            #
            #     Starting var:.. x = [0]
            #     New var:....... tracer = <pysnooper.tracer.Tracer object at 0x...>
            #          Call ended by exception
            #     Return value:.. 1
            #     Elapsed time: 0:00:00.0101

# Generated at 2022-06-10 21:39:04.009684
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    module_name='Tracer'
    method_name='trace'
    m = sys.modules[__name__]
    f = getattr(m, method_name)
    if f.__doc__ is None: f.__doc__ = ''
    
    ### Set up test inputs:
    frame = inspect.currentframe()
    event = 'call'
    arg = None
    ###########################################################################

    # Call the function:
    actual = f(frame, event, arg)
    
    ### Print results:
    msg = '{}.{}.__doc__:\n{}'.format(module_name, method_name, f.__doc__)
    print_test_message(msg)
    if actual is None:
        msg = '{}.{}() returned None'.format(module_name, method_name)
   

# Generated at 2022-06-10 21:39:06.246400
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    def test_trace():
        with tracer:
            pass
    test_trace()

# Generated at 2022-06-10 21:39:06.939531
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-10 21:39:15.056813
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print('#' * 80)
    print(Tracer.trace.__doc__)
    print('#' * 80)
    

# Generated at 2022-06-10 21:39:25.955682
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """
    Test whether the method trace of class Tracer does the right thing.
    See the comment at the beginning of this file for more details.
    """
    # First, make sure that the trace function itself works
    def foo():
        return 1
    t = Tracer(watch=('foo()',))
    t.trace(foo.__code__, 'call', 10)

    # Next, check the conditions where the trace function simply returns None
    # There are 3:
    # - The code object is not of the target code object
    # - The code object is of the target code object, but the depth is 1 (and
    #   consequently, no tracing call is made)
    # - The code object is of the target code object, but the depth is above 1
    #   (and consequently, no tracing call is made)

# Generated at 2022-06-10 21:39:31.202084
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(None) == \
           (__file__, UnavailableSource())
    assert get_path_and_source_from_frame(sys._getframe(0)) == \
           (__file__, UnavailableSource())
test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:39:41.278675
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    assert inspect.isfunction(Tracer.trace)
    from contextlib import contextmanager

    @contextmanager
    def c(call_depth=0, print_depth=0):
        print('========================================================')
        print('call_depth', call_depth)
        print('print_depth', print_depth)
        print('expected_depth', 1 + 2 * call_depth + max(0, print_depth - 1))
        print('----------')

        stack = []

        @pysnooper.snoop(depth=print_depth)
        def f(x):
            stack.append(x)

        def g(x):
            f(x)
        def h(x):
            g(x)

        def i():
            h(call_depth)

        i()

        expected_calls = []

# Generated at 2022-06-10 21:40:25.920597
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    if True:
        # This branch is only used when running the unit tests.
        # In regular usage, datetime_module.datetime.now() is patched to return
        # a "now" at a fixed time. That's to make the log output predictable and
        # testable.
        global datetime_module
        import datetime
        datetime_module = datetime

    log_output = []
    # TODO: Make this more elegant
    old_print = print
    def mock_print(s):
        log_output.append(s)

    def dummy_function():
        x = 2
        something_else()
        y = 4
        return x + y

    def something_else():
        return 'called something_else'

    global mock_datetime_datetime_now

# Generated at 2022-06-10 21:40:38.820313
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    '''
    Test case for method __exit__
    '''
    tracer = Tracer()
    tracer.target_codes = set(['code3', 'code1', 'code2'])
    tracer.target_frames = set(['frame3', 'frame2', 'frame1'])
    tracer.frame_to_local_reprs = {'frame1': {'name1': 'value1'},
                                   'frame3': {'name1': 'value1'},
                                   'frame2': {'name1': 'value1'}
                                  }
    tracer.start_times = {'frame1': datetime.datetime.now(),
                          'frame3': datetime.datetime.now(),
                          'frame2': datetime.datetime.now()
                         }
    calling_

# Generated at 2022-06-10 21:40:52.148647
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    test = Tracer(custom_repr = ())
    module = __import__('pysnooper')
    import inspect
    import sys
    import threading
    import timeit
    class module_t:
        pass
    module_t.__file__ = 'pysnooper.py'
    module_t.__name__ = 'pysnooper'
    module_t.__package__ = 'pysnooper'
    module_t.__cached__ = 'pysnooper'
    import inspect
    import sys
    import threading
    import timeit
    class code_t:
        pass
    code_t.co_filename = '<unknown>'
    code_t.co_firstlineno = 1
    code_t.co_flags = 0

# Generated at 2022-06-10 21:41:02.444652
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import types, random
    class TestClass:
        def __init__(self, bar):
            self.bar = bar
    def custom_repr(x):
        return 'custom for {}'.format(repr(x))
    def test_function(a=5, b='hello'):
        c = 6
        d = [1,2,3]
        e = TestClass(10)
        f = TestClass(11)
        g = f.bar
        f.bar = 12
        if random.random() > 0.5:
            while True:
                if random.random() > 0.5:
                    break
                else:
                    eval('1') #@UndefinedVariable
        return locals()
    frame = test_function.__code__. \
                   _fake_frame #@UndefinedVariable
    frame.f

# Generated at 2022-06-10 21:41:10.743685
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import pprint

    @pysnooper.snoop(watch_explode=('a', 'b'))
    def foo(a):
        b = {'a': 1, 'b': 2}
        c = 'something'

    output = io.StringIO()
    foo({'x': [1, 2, 3], 'y': [4, 5, 6]}, output=output)

    output = output.getvalue().strip()
    output = output.split('\n')
    output = [line.strip() for line in output]
    assert output[0] == 'Starting var:.. a = {\'x\': [1, 2, 3], \'y\': [4, 5, 6]}'
    pprint.pprint(output[1:])

# Generated at 2022-06-10 21:41:12.106890
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == "__main__":
    test_Tracer_trace()

# Generated at 2022-06-10 21:41:14.524609
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    tracer.__enter__()


# Generated at 2022-06-10 21:41:19.921005
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    import sys

    output_io = io.StringIO()
    sys.stderr = output_io

    @pysnooper.snoop(watch=['x', 'y'])
    def add(x, y):
        return x + y

    add(1, y=2)

    output_io.seek(0)

# Generated at 2022-06-10 21:41:29.240538
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert (get_local_reprs(
        {'a': 'b', 'c': 'd', 'e': 'f'},
        lambda key, value: ((key, value), (key, '<' + value + '>')))
            == {'a': 'b', 'c': 'd', 'e': 'f', 'a': '<b>', 'c': '<d>', 'e': '<f>'}
        )
    assert (get_local_reprs({'a': 'b', 'c': 'd', 'e': 'f'}, watch=())
            == {'a': 'b', 'c': 'd', 'e': 'f'})

# Generated at 2022-06-10 21:41:29.935285
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass