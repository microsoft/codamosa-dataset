

# Generated at 2022-06-10 21:33:29.477535
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y, z=1, *args, **kwargs):
        if y > 10:
            a = x + 1
        else:
            a = x + 2
        a = a + y
        a += 1
        b = x + y + z
        c = a + b
        l = [a, b, c]
        d = {'a': a, 'b': b, 'c': c}
        e = l + [d]
        return l, d, e
    def g(x, y, *args, **kwargs):
        a = x
        a = a + y
        b = x + y
        c = a + b
        l = [a, b, c]
        d = {'a': a, 'b': b, 'c': c}

# Generated at 2022-06-10 21:33:42.989115
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pytest.raises(NotImplementedError):
        Tracer().__call__(coroutine=True)

    def regular_function():
        pass
    assert Tracer().__call__(regular_function) == regular_function

    def regular_function2(one, two, three=4, five=6):
        pass
    assert Tracer().__call__(regular_function2) == regular_function2

    def regular_function3(*, one, two, three=4, five=6):
        pass
    assert Tracer().__call__(regular_function3) == regular_function3

    def regular_function4(*args):
        pass
    assert Tracer().__call__(regular_function4) == regular_function4

    def regular_function5(**kwargs):
        pass
    assert Tracer().__call

# Generated at 2022-06-10 21:33:53.693326
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import mint
    assert (list(get_local_reprs(mint._test()).items()) ==
            [('a', '2'), ('b', '2'), ('c', '3'), ('d', '3'), ('g', 'h(1, 2)')])
    assert (list(get_local_reprs(mint._test(),
                                 watch=(CommonVariable('a', 0),
                                        CommonVariable('b', 0),
                                        CommonVariable('c', 1))).items()) ==
            [('a', '2'), ('b', '2'), ('c', '3'), ('d', '3'), ('g', 'h(1, 2)')])

# Generated at 2022-06-10 21:34:04.782090
# Unit test for function get_write_function
def test_get_write_function():
    # if output is None
    output = None
    write = get_write_function(output, False)
    assert callable(write)
    # if output is callable
    output = lambda s: None
    write = get_write_function(output, False)
    assert callable(write)

    # if output is utils.WritableStream
    class WritableStream(utils.WritableStream):
        def write(self, s):
            pass
    output = WritableStream()
    write = get_write_function(output, False)
    assert callable(write)

    # if output is a path
    output = 'c:/temp/output.log'
    write = get_write_function(output, False)
    assert callable(write)
    write = get_write_function(output, True)
    assert call

# Generated at 2022-06-10 21:34:12.981818
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    #
    # Basic test:
    #
    line = Line()
    sys.settrace   = line.settrace
    sys.gettrace   = line.gettrace
    inspect.currentframe  = line.currentframe
    thread_global.depth = 0
    depth = 1
    prefix = 'pysnooper:'
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    tracer = Tracer()
    tracer.write = line.write
    tracer.thread_info_padding = 0
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.thread_local = threading.local()
    tracer.last_source_path = None
    

# Generated at 2022-06-10 21:34:25.323737
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = False

    # Initialization
    depth = 1
    indent = ' ' * 4 * (depth + 1)
    start_time = datetime_module.datetime(2000, 1, 1, 0, 0, 0, 0)
    duration = datetime_module.timedelta(days=1, hours=1, minutes=1, seconds=1, microseconds=1)
    elapsed_time_string = pycompat.timedelta_format(duration)

    # Mocking
    function = MagicMock()
    function.__code__ = MagicMock()
    function.__name__ = MagicMock()
    function.__qualname__ = MagicMock()
    frame = MagicMock()
    frame.f_code = MagicMock()
    frame.f_code.co_filename

# Generated at 2022-06-10 21:34:36.691143
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print('test_Tracer_trace...')
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)

    try:
        with tracer:
            pass
    except Exception as e:
        print(u'exception raised: {0}'.format(e))

    try:
        from threading import Thread
        thread = Thread(target=tracer.trace, args=(None,))
        del thread
    except Exception as e:
        print(u'exception raised: {0}'.format(e))
if __name__ == '__main__':
    test_watch_explode()


# Generated at 2022-06-10 21:34:41.196848
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    class C(object):
        pass
    def f():
        pass
    def t1():
        pysnooper.snoop()(C)
    def t2():
        pysnooper.snoop()(f)

# Generated at 2022-06-10 21:34:51.779087
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # To make this test independent of the file this unit test resides in
    here = os.path.abspath(os.path.dirname(__file__))
    os.chdir(here)
    sys.path.append(here)
    # Test when calling function trace from function trace (which happens
    # when a function having a decorator of Snooper is called by another 
    # function having a decorator of Snooper)

    # Prepare for call to trace
    output = StringIO()
    watch = []
    watch_explode = []
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False

# Generated at 2022-06-10 21:35:02.621109
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    for name, value in locals().copy().items():
        globals().pop(name, None)

    import unittest
    import unittest.mock


    class TracerTest(unittest.TestCase):
        def setUp(self):
            self.sut = Tracer(watch=(), watch_explode=(), depth=1,
                              prefix='', overwrite=False, thread_info=False,
                              custom_repr=(),
                              max_variable_length=100, normalize=False,
                              relative_time=False)


# Generated at 2022-06-10 21:35:23.317072
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_recursive(x):
        if x > 0:
            return x * test_recursive(x-1)
        else:
            return 1
    test_recursive(2)
    import inspect
    frame = inspect.currentframe().f_back.f_back
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert 'test_recursive(x):' in source[0]



# Generated at 2022-06-10 21:35:27.255311
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # assume
    tracer = Tracer()
    function_or_class = None

    # action
    result = tracer(function_or_class)

    # expect
    assert result == None

# Generated at 2022-06-10 21:35:29.188673
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs(inspect.stack()[-1].frame)

# Generated at 2022-06-10 21:35:29.652442
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass

# Generated at 2022-06-10 21:35:35.959557
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from . import test_simple_tracer
    from .test_simple_tracer import whatever
    from .test_simple_tracer import whatever2
    from .test_simple_tracer import whatever3
    from .test_simple_tracer import Whatever
    from .test_simple_tracer import Whatever2
    from .test_simple_tracer import Whatever3
    assert Whatever.__dict__['whatever'] != whatever
    assert Whatever2.__dict__['whatever2'] != whatever2
    assert Whatever3.__init__ != whatever3


# Generated at 2022-06-10 21:35:41.517871
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():

    class Foo(object):

        def bar(x, y, z):  # pylint: disable=E0213
            pass
    foo = Foo()

    with Tracer():
        foo.bar(1, y=2, z=3)
        foo.bar(4, y=5, z=6)

# Generated at 2022-06-10 21:35:56.860012
# Unit test for function get_write_function
def test_get_write_function():
    # Test without output
    f = get_write_function(output=None, overwrite=False)
    f(u'\n')
    # Test writing to a file
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        p = tempdir + '/my_file.txt'
        f = get_write_function(p, overwrite=True)
        f(u'hello')
        if pycompat.PY2:
            with open(p, 'rb') as fp:
                assert fp.read() == 'hello'
        else:
            with open(p, 'r', encoding='utf-8') as fp:
                assert fp.read() == 'hello'
    # Test writing to a file without overwrite
    import tempfile

# Generated at 2022-06-10 21:36:08.636290
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = utils.make_dummy_frame(
        {'x': 7, 'y': 'hi', 'z': ['a', 'b'], 'w': (1, 2, 3, 4)},
        varnames=['x', 'y'],
        co_cellvars=['z'],
        co_freevars=['w'],
        f_code=utils.make_dummy_code(co_argcount=1)
    )

    assert get_local_reprs(frame, max_length=8) == {
        'x': '7',
        'y': 'hi',
        'z': '[\'a\', \'b\']',
        'w': '(1, 2, 3, 4)'
    }
    assert get_local_reprs(frame, max_length=4)

# Generated at 2022-06-10 21:36:15.449094
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = False
    output = io.StringIO()
    write = get_write_function(output, overwrite = False)
    watch = [
        v if isinstance(v,BaseVariable) else CommonVariable(v) for v in utils.ensure_tuple(())
      ] + [
        v if isinstance(v,BaseVariable) else Exploding(v) for v in utils.ensure_tuple(())
      ]
    frame_to_local_reprs = {}
    start_times = {}
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = []
    max_variable_length = 100
    normalize = False
    relative_time = False
    calling_frame = inspect.currentframe().f_back


# Generated at 2022-06-10 21:36:26.854657
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer(output=BytesIO(),
                    watch=('foo', 'self.foo'),
                    watch_explode=('foo', 'self'),
                    depth=3,
                    prefix='abc',
                    overwrite=False,
                    thread_info=False,
                    custom_repr=(),
                    max_variable_length=100,
                    normalize=False,
                    relative_time=False,
                    )
    assert tracer.watch == [
        CommonVariable('foo'),
        CommonVariable('self.foo'),
        Exploding('foo'),
        Exploding('self'),
    ]
    assert tracer.depth == 3
    assert tracer.prefix == 'abc'
    assert tracer.thread_info == False
    assert tracer.custom_repr == ()
    assert tracer.normalize == False
    assert tracer

# Generated at 2022-06-10 21:36:51.677018
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    global_namespace = {'__name__': __name__}
    local_namespace = {}
    exec('def _f():\n    pass\n', global_namespace, local_namespace)
    f = local_namespace['_f']
    result = get_path_and_source_from_frame(f.__code__.co_filename)
    assert result == (__file__, [u'def _f():'])
test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:36:54.797085
# Unit test for function get_write_function
def test_get_write_function():
    import io
    assert get_write_function(None, False)('foo') is None
    assert get_write_function(io.StringIO(), False)('foo') == 'foo'



# Generated at 2022-06-10 21:37:06.475272
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys, os
    open('temp_source_file.txt', 'w').write('Hello, world!')
    module = type(sys)('temp_module')
    module.__file__ = 'temp_source_file.txt'
    module.__loader__ = SourceLoader()
    frame = type('Frame', (), {'f_globals': module.__dict__,
                               'f_code': type('CodeType', (object,),
                                              {'co_filename': 'temp_source_file.txt',
                                               'co_freevars': (),
                                               'co_cellvars': (),
                                               'co_varnames': ()})})
    path, source = get_path_and_source_from_frame(frame)
    assert path == 'temp_source_file.txt'

# Generated at 2022-06-10 21:37:17.753018
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    line_no = random.randint(0, 1000)
    tracer = Tracer.__new__(Tracer)
    tracer.watch = random.choice(([], ["a"], {1, 2, 3}))
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.depth = random.randint(0, 1000)
    tracer.prefix = random.choice((None, "", "a"))
    tracer.overwrite = random.choice((True, False))
    tracer.thread_info = random.choice((True, False))
    tracer.custom_repr = [("a", "b"), (1, 2)]
    tracer.max_variable_length = random.randint(0, 1000)
    tracer.normalize = random.choice

# Generated at 2022-06-10 21:37:27.109208
# Unit test for constructor of class Tracer
def test_Tracer():
    class MockWriter():
        def __init__(self):
            self.written_strings = []
        def write(self, s):
            self.written_strings.append(s)

    mock_writer = MockWriter()
    tracer = Tracer(output=mock_writer,
                    watch=('a', 'b'),
                    watch_explode=('c', 'd'),
                    depth=2,
                    prefix='XX ',
                    overwrite=False,
                    thread_info=False,
                    custom_repr=(),
                    max_variable_length=100,
                    normalize=False,
                    relative_time=False,)
    assert isinstance(tracer._write, Callable)
    assert isinstance(tracer.write, Callable)
    assert isinstance(tracer.watch, list)

# Generated at 2022-06-10 21:37:32.032546
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Tracer.trace([frame, event, arg]) -> deepcopy(frame)
    assert isinstance(Tracer().trace(inspect.currentframe(), 'call', None),
                      type(inspect.currentframe()))

# Generated at 2022-06-10 21:37:42.557376
# Unit test for constructor of class Tracer
def test_Tracer():
    for depth in (-1, 0, 2, 10):
        with Tracer(depth=depth):
            pass

    with Tracer(watch='foo'):
        pass

    with Tracer(watch=('foo', 'bar')):
        pass

    with Tracer(watch_explode='foo'):
        pass

    with Tracer(watch_explode=('foo', 'bar')):
        pass

    with Tracer(prefix='@'):
        pass

    with Tracer(output=StringIO(), overwrite=True):
        pass

    with Tracer(relative_time=True):
        pass

    with Tracer(normalize=True):
        pass

    with Tracer(max_variable_length=300):
        pass

    with Tracer(max_variable_length=None):
        pass


# Generated at 2022-06-10 21:37:44.006297
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    assert Tracer().trace == Tracer.trace

# Generated at 2022-06-10 21:37:50.393328
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import shutil
    file_path = 'tests/output.txt'
    try:
        os.remove(file_path)
    except OSError:
        pass
    FileWriter(file_path, False).write('a')
    FileWriter(file_path, False).write('b')
    with open(file_path, 'r') as input_file:
        content = input_file.read().splitlines()
    shutil.rmtree('tests')
    assert content == ['a', 'b']

# Generated at 2022-06-10 21:37:51.322422
# Unit test for constructor of class Tracer
def test_Tracer():
    Tracer()

snoop = Tracer()

# Generated at 2022-06-10 21:38:15.052718
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest

    from .snoop import Tracer

    class MockDatetime:

        def __init__(self, timestamp=123456789):
            self.timestamp = timestamp

        def now(self):
            return self

        def __sub__(self, other):
            return 123

    mock_datetime = MockDatetime()
    datetime_module = type(datetime_module)("datetime", (datetime_module,),
                                           {"datetime": mock_datetime})
    pysnooper.load_module(datetime_module)
    original_trace = sys.gettrace()
    thread_global.depth = 1
    tracer = Tracer()
    tracer.__enter__()
    assert thread_global.depth == 2
    assert tracer.thread_local.original_trace_functions

# Generated at 2022-06-10 21:38:17.991885
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print('testing function Tracer___call__', end='')
    # TODO: write unit test
    raise NotImplementedError

# Generated at 2022-06-10 21:38:28.725595
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import time
    import unittest

    class _Tester(unittest.TestCase):
        def setUp(self):
            self.tracer = Tracer(self.output, watch=('self',), depth=1)

        def output(self, s):
            self.last_s = s

    # Enable self.assertAlmostEqual(...)
    # to compare floats.
    _Tester.maxDiff = None

    class Test_Tracer_trace1(_Tester):
        '''
        In this test, we ensure that Tracer.trace(...)
        writes lines when:
        - We start a function call
        - We end a function call but not due to an exception
        - We end a function call due to an exception
        '''


# Generated at 2022-06-10 21:38:35.576668
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    s = utils.StringIO()
    with pysnooper.snoop(s, watch=('e',), prefix='SNOOP:'):
        for i in range(1, 5):
            try:
                e = [i, i+1]
                a = e[2]
            except:
                pass



# Generated at 2022-06-10 21:38:48.015131
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest

    # Setup test cases.
    class Foo:
        pass
    function = Foo()
    decorator = pysnooper.snoop()

# Generated at 2022-06-10 21:38:59.880803
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test_one(code_byte, expected):
        opname = opcode.opname[code_byte]
        arg = opcode.opmap.get(opname)
        mangled_name = '_' + opname
        # it's ugly to add properties to a class dynamically, but
        # it's easier than fiddling with the mro, and it works
        with Tracer() as tracer:
            setattr(tracer, mangled_name, mock.Mock(return_value=None))
            tracer.trace(None, opname, arg)
            getattr(tracer, mangled_name).assert_called_once_with(
                opname, arg)
    # Test that Tracer.trace calls the correct event handler functions
    # for all the events we care about. We test the 'return' event
    #

# Generated at 2022-06-10 21:39:10.115585
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def foo(a):
        b = []
        c = 12
        return a, b, c
    called = []
    def write_to_called(s):
        called.append(s)
    tracer = Tracer(write=write_to_called, thread_info=True)
    foo = tracer(foo)
    foo(2)
    assert called[0].startswith('Source path:... ')
    assert called[0].endswith(__file__)
    assert called[1].startswith('    MainThread')
    assert called[1].endswith('call        3 foo(a=2)')
    assert called[2].startswith('        New var:....... a = 2')
    assert called[3].startswith('        Starting var:.. b = []')

# Generated at 2022-06-10 21:39:12.542972
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        g()

    def g():
        frame = f.__code__.co_filename = __file__
        return get_path_and_source_from_frame(frame)

    f()



# Generated at 2022-06-10 21:39:24.205891
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    outlist = []
    def output(s):
        outlist.append(s)

    @Tracer(output)
    def simple_function():
        return 'result'

    @Tracer(output, depth=2)
    def depth_function():
        return 'result'

    @Tracer(output, watch=('a', 'b', 'c'))
    def watch_function():
        a = 1
        b = a + 1
        c = a + b
        return c

    @Tracer(output, watch=('a',))
    def watch_explode_function():
        a = [1, 2, 3]
        return a

    @Tracer(output, watch=('a',))
    def watch_normalize_function():
        a = [1, 2, 3]
        return a

    # Test

# Generated at 2022-06-10 21:39:26.848693
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    assert tracer.__call__(0) == 0, "Return the number itself"

# Generated at 2022-06-10 21:39:48.560852
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def myfunc(a,b):
        pass
    f = Tracer(watch='a', max_variable_length=100).trace
    fr = inspect.currentframe().f_back
    f(fr, 'exception', ValueError)
    f(fr, 'call', None)
    fr.f_locals['a'] = 'bla'
    f(fr, 'return', None)
    assert fr is None


# Generated at 2022-06-10 21:39:51.911180
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  tracer = Tracer()
  pytest.raises(AttributeError, "tracer.__enter__()")



# Generated at 2022-06-10 21:40:05.547520
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test that Tracer decorator works on simple functions
    @Tracer()
    def foo(x):
        return x

    assert foo(1) == 1

    # Test that Tracer decorator works on nested functions
    @Tracer()
    def foo(x):

        @Tracer()
        def bar(y):
            return y

        return bar(x)

    assert foo(1) == 1

    # Test that Tracer decorator works on nested (but not necessary decorated)
    # functions
    @Tracer()
    def foo(x):

        def bar(y):
            return y

        return bar(x)

    assert foo(1) == 1

    # Test that Tracer decorator works on nested functions
    @Tracer()
    def foo(x):
        yield x


# Generated at 2022-06-10 21:40:17.540976
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from pysnooper.snoop import Tracer
    from pysnooper import snoop
    from pysnooper.snoop import get_path_and_source_from_frame
    from pysnooper.snoop import _get_variable_repr
    from pysnooper.snoop import get_local_reprs
    from pysnooper.snoop import _get_shortish_repr
    from pysnooper.snoop import get_write_function
    from pysnooper.snoop import BaseVariable
    from pysnooper.snoop import CommonVariable
    from pysnooper.snoop import Exploding
    from pysnooper.utils import pycompat

    import functools
    import inspect
    import threading
    import threading

# Generated at 2022-06-10 21:40:25.770050
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import math
    def my_repr(obj):
        if obj is math.pi: return "pi"
        if obj is math.e: return "e"
    def foo(x, y, z, long_var_name, m=None):
        return x + y + z + long_var_name + repr(m)
    frame = inspect.currentframe()
    assert get_local_reprs(frame) == {'m': None}
    assert get_local_reprs(frame, normalize=True) == \
        {'m': None, '<exc_info>': 'None'}
    assert get_local_reprs(frame, watch=(CommonVariable('exc_info'),)) == \
        {'m': None, '<exc_info>': 'None'}
    assert get_local_re

# Generated at 2022-06-10 21:40:38.688901
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from pysnooper import snoop
    # Call the __exit__ method of the class Tracer.
    # __exit__ has no return
    # object in the class Tracer:
    # 1. output
    # 2. 
    # 3. 
    # 4. 
    # 5. 
    # 6. 
    # 7. 
    # 8. 
    # 9. 
    # 10. 
    # 11. 
    # 12. 
    # 13. 
    # 14. 
    # 15. 
    # 16. 
    # 17. 
    # 18. 
    # 19. 
    # 20. 
    # 21. 
    # 22. 
    # 23. 
    # 24. 
    # 25. 
    # 26. 

# Generated at 2022-06-10 21:40:51.858343
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    instance = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    # TODO: unit tests fail without these variables
    watch = None
    watch_explode = None
    depth = None
    prefix = None
    overwrite = None
    thread_info = None
    custom_repr = None
    max_variable_length = None
    normalize = None
    relative_time = None
    frame = inspect.currentframe()
    event = 'call'
    arg = None
    output = None
    return instance.trace(frame, event, arg)


# Generated at 2022-06-10 21:40:56.395765
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    #global DISABLED, thread_global
    DISABLED = False
    #DISABLED = False
    with Tracer():
        sum(range(5))
    #assert True == False

if __name__ == '__main__':
    test_Tracer_trace()

# Generated at 2022-06-10 21:41:02.727254
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    t = Tracer()
    frame = inspect.currentframe()
    # test normal case
    assert t.trace(frame, 'call', None)==t.trace
    assert t.trace(frame, 'exception', (int, 1, None))==t.trace
    assert t.trace(frame, 'return', None)==t.trace
    # test abnormal case
    assert t.trace(None, 'call', None)==None
    assert t.trace(None, 'exception', None)==None

# Trigger method __exit__ of class Tracer
# test normal case

# Generated at 2022-06-10 21:41:10.083863
# Unit test for function get_local_reprs
def test_get_local_reprs():
    x = 1
    y = 2
    z = 3
    _x = x
    _y = y
    _z = z
    custom_repr = {x: '<x>', y: '<y>', z: '<z>'}
    result = get_local_reprs(frame=inspect.currentframe(),
                             watch=(CommonVariable('_x'),
                                    CommonVariable('_y'),
                                    CommonVariable('_z')),
                             custom_repr=custom_repr)
    assert result == {'_x': '<x>', '_y': '<y>', '_z': '<z>'}


# Generated at 2022-06-10 21:41:51.099590
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return g()
    def g():
        return h()
    def h():
        return pycompat.get_frame()

    frame = f()

    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source == __file__

    # How can we make sure it gets `__file__` even if we use the `import`
    # trick?
    source_and_path_cache.clear()



# Generated at 2022-06-10 21:41:52.861771
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(watch='x'):
        x = 'hi'


# Generated at 2022-06-10 21:42:00.582967
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import os
    from . import utils
    from . import pycompat
    from . import inspect_
    from . import datetime_module
    from . import opcode
    from . import threading
    from . import threading as threading_module
    from . import inspect
    from . import functools
    from . import DISABLED
    from . import thread_global
    from . import get_write_function
    from . import CommonVariable
    from . import BaseVariable
    from . import Exploding
    import traceback

    def get_path_and_source_from_frame(frame):
        source_path = inspect_.getfile(frame)
        with open(source_path, encoding='utf-8') as f:
            source = f.readlines()
        return source_path, source


# Generated at 2022-06-10 21:42:04.667376
# Unit test for constructor of class Tracer
def test_Tracer():
    t = Tracer()
    assert t.depth == 1
    t = Tracer(depth=3)
    assert t.depth == 3
    t = Tracer(depth=7)
    assert t.depth == 7


# Generated at 2022-06-10 21:42:06.629036
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types

# Generated at 2022-06-10 21:42:09.119714
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    module_name = 'mymodule'
    file_name = 'myfile.py'
    def f():
        pass
    loader = lambda: None

# Generated at 2022-06-10 21:42:12.198868
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function_for_testing():
        return inspect.currentframe()
    frame = function_for_testing()
    path, source = get_path_and_source_from_frame(frame)



# Generated at 2022-06-10 21:42:14.182887
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class Foo(object):
        @pysnooper.snoop()
        def __init__(self):
            pass
    foo = Foo()

# Generated at 2022-06-10 21:42:23.341791
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import logging
    import pysnooper
    class Decorated:
        def __init__(self, n):
            self.n = n
        def __add__(self, other):
            return self.n + other.n
        def __lt__(self, other):
            return self.n < other.n
        def __len__(self):
            return self.n
        def __repr__(self):
            return 'Decorated({self.n!r})'.format(**locals())
    class New:
        def __init__(self, n):
            self.n = n
        def __add__(self, other):
            return self.n + other.n
        def __lt__(self, other):
            return self.n < other.n

# Generated at 2022-06-10 21:42:26.820307
# Unit test for constructor of class Tracer
def test_Tracer():
    Tracer(
        output=None,
        watch=(),
        watch_explode=(),
        depth=1,
        prefix='',
        overwrite=False,
        custom_repr=(),
        max_variable_length=100,
        normalize=False,
        relative_time=False
    )
