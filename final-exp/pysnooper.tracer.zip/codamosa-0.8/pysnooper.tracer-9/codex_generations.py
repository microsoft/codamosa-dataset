

# Generated at 2022-06-10 21:33:13.365083
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  import tempfile
  import os
  import sys
  import re
  import pysnooper
  def the_function_to_wrap():
    pass
  tracer = pysnooper.Tracer(watch=('the_variable_to_watch',), depth=2, overwrite=False, thread_info=True, custom_repr=((True, True),), max_variable_length=100, normalize=False, relative_time=False)
  tracer._write = sys.stdout.write
  with tracer:
    the_function_to_wrap()
  def test_Tracer___enter___simple(x0_Tracer):
    assert type(x0_Tracer) == Tracer
    assert x0_Tracer.watch == [CommonVariable('the_variable_to_watch')]
    assert x0_Tracer

# Generated at 2022-06-10 21:33:16.829056
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from xdoctest import utils
    from xdoctest import doctest_module
    results = utils.run_doctests_module(doctest_module)
    return results



# Generated at 2022-06-10 21:33:27.959077
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.max_variable_length=100
    tracer.normalize=True
    tracer.relative_time=True
    tracer.write = mock_write
    tracer.watch=()
    tracer.watch_explode=()
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.depth = 1
    tracer.prefix = ''
    tracer.overwrite=False
    tracer.thread_info=True
    tracer.custom_repr=()
    tracer.last_source_path = None
    tracer.thread_info_padding = 0
    tracer.thread_local = threading.local()
    tracer.target_codes = set()
    tracer.target_frames = set()

# Generated at 2022-06-10 21:33:34.945902
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with pytest.raises(NotImplementedError):
        with Tracer(output=None, watch=(), watch_explode=(), depth=1,
                    prefix='', overwrite=False, thread_info=False, custom_repr=(),
                    max_variable_length=100, normalize=False, relative_time=False):
            pass

# Generated at 2022-06-10 21:33:38.698668
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile

# Generated at 2022-06-10 21:33:41.282726
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # TODO Implement for each method in class Snooper
    raise NotImplementedError()

# Generated at 2022-06-10 21:33:49.469984
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import flavors
    from .flavors import PythonFlavor

    flavor = PythonFlavor()
    namespace = {}

    file_name = __file__
    if file_name.endswith('.pyc'):
        file_name = file_name[:-1]

    with open(file_name, 'rb') as fp:
        source = fp.read().splitlines()
    source = [pycompat.text_type(sline, 'utf-8', 'replace') for sline in
                  source]

    globals_ = namespace

    frame = inspect.currentframe()
    globals_['__name__'] = 'cute_inspect.tests'
    globals_['__loader__'] = object()

    namespace['flavors'] = flavors
    namespace['PythonFlavor'] = PythonFlavor



# Generated at 2022-06-10 21:33:54.752489
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame(): # pragma: no cover
    def f():
        pass
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    result = get_path_and_source_from_frame(frame)
    assert result[0] == __file__, result
    assert 'def f():' in result[1], result[1]


# Generated at 2022-06-10 21:34:05.777908
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest

    def testcase(function):
        def wrapper(*args, **kwargs):
            function(*args, **kwargs)
            return None
        wrapper.__wrapped__ = function
        return wrapper

    class TestTracer___call__(unittest.TestCase):
        def test_SELF_is_instance_of_Tracer(self):
            @pysnooper.snoop()
            def func():
                pass
            self.assertIsInstance(func._snoop, Tracer)

        def test_wrapped_function_has_same_name_docstring_as_original_function(self):
            @pysnooper.snoop()
            def func():
                'doc'
                pass

# Generated at 2022-06-10 21:34:10.043886
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Make frame with some locals:
    def f():
        a = 5
        return locals()

    frame = f()['__frame']

    assert get_path_and_source_from_frame(frame) == (
                                            __file__,
                                            open(__file__, 'r').readlines()
                                            )



# Generated at 2022-06-10 21:34:36.921375
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    try:
        with Tracer(watch='k'):
            list()[0]
        assert False
    except IndexError:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        assert exc_type == IndexError

if __name__ == "__main__":
    test_Tracer___exit__()

# Generated at 2022-06-10 21:34:42.513315
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    #self = <pysnooper.tracer.Tracer object at 0x7f0a1a4b42b0>
    #exc_type = None
    #exc_value = None
    #exc_traceback = None
    from pysnooper.tracer import Tracer
    #to implement
    assert False



# Generated at 2022-06-10 21:34:52.210273
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(a, b):
        c = 44
        return a, b, c
    frame = sys._getframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    local_names = ('a', 'b', 'c')
    local_values = (1, 2, 44)
    for local_name, local_value in zip(local_names, local_values):
        assert frame.f_locals[local_name] == local_value
    result = get_local_reprs(frame, max_length=10)
    assert set(local_names) <= set(result)
    assert all(len(repr(local_value)) <= 10
               for local_value in local_values)



# Generated at 2022-06-10 21:35:04.810245
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # Test output when overwrite is set to True
    file_writer = FileWriter('~/file.txt', True)
    file_writer.write('Hello world!')
    with open('~/file.txt', 'r') as output_file:
        assert output_file.read() == 'Hello world!'

    # Test output when overwrite is set to False
    file_writer = FileWriter('~/file.txt', False)
    file_writer.write('Hello world!')
    with open('~/file.txt', 'r') as output_file:
        assert output_file.read() == 'Hello world!Hello world!'



# Generated at 2022-06-10 21:35:15.141814
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer(output=pathlib.Path('/tmp/snoop.log'),
                    watch=('foo',),
                    watch_explode=('self',),
                    depth=2,
                    prefix='ZZZ ',
                    overwrite=False,
                    thread_info=True,
                    custom_repr=((type1, custom_repr_func1),
                                 (condition2, custom_repr_func2), ),
                    max_variable_length=200,
                    normalize=False,
                    relative_time=True
                    )

    assert tracer.watch == [CommonVariable("foo"), Exploding("self")]
    assert tracer.depth == 2
    assert tracer.prefix == "ZZZ "
    assert tracer.overwrite == False
    assert tracer.thread_info == True

# Generated at 2022-06-10 21:35:26.971834
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    import tempfile

    # Test when module has a loader
    test_file_name = tempfile.mktemp(suffix='.py')
    with open(test_file_name, 'wb') as f:
        f.write('''if True:\n    print('one')\nprint('two')\n''')

    loader = tracer.SourceFileLoader(os.path.splitext(test_file_name)[0],
                                     test_file_name)

# Generated at 2022-06-10 21:35:27.980966
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # __exit__ is tested in other tests
    pass

# Generated at 2022-06-10 21:35:34.086088
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    class Foo(object):
        def __init__(self, language):
            self.language = language
        def get_language(self):
            return self.language
    foo = Foo("Python")
    a = 1
    b = 2
    c = 3
    d = foo.get_language()
    e = 5
    f = 6
    g = 7
    h = 8
    i = 9
    j = 10
    k = 11


# Generated at 2022-06-10 21:35:47.307375
# Unit test for constructor of class Tracer
def test_Tracer():
    from io import StringIO
    from .utils import get_shortish_repr

    def foo(a, b=None, *args, c=1, d=2, **kwargs):
        pass

    def bar(a):
        foo(a, c=3)

    def test_write():
        s = StringIO()
        tracer = Tracer(output=s, depth=2)
        tracer.write('AAA')
        tracer.write('BBB')
        assert s.getvalue() == 'AAA\nBBB\n'

    def test_watch():
        s = StringIO()
        tracer = Tracer(output=s, watch='a')
        tracer.__enter__()
        bar('a0')
        tracer.__exit__(None, None, None)
        expected = u''

# Generated at 2022-06-10 21:35:49.637992
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # __exit__ is untestable because all it does is call the @pysnooper decorator
    pass

# Generated at 2022-06-10 21:36:38.413593
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    import inspect
    import linecache
    import dis
    import opcode

    linecache.clearcache()
    import sys

    frame = inspect.currentframe()
    frame_locals = frame.f_locals
    frame_globals = frame.f_globals
    frame_code = frame.f_code
    frame_lasti = frame.f_lasti
    arg = arg = None
    timestamp = ' now'
    event = 'return'   
    tracer = pysnooper.Tracer()
    code_byte = frame.f_code.co_code[frame.f_lasti]
    if not isinstance(code_byte, int):
        code_byte = ord(code_byte)

# Generated at 2022-06-10 21:36:40.425345
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    with pytest.raises(NotImplementedError):
        Tracer().__enter__()

# Generated at 2022-06-10 21:36:53.023297
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    import sys
    import unittest
    from unittest import mock

    class TracerTraceTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            # Uncomment the following lines to run this test standalone,
            # and not as a part of the whole test suite.
            #
            # from sys import stdout
            # from pysnooper import snoop
            # @snoop()
            # def test_function(a, b):
            #     return a * b
            # cls.test_function = test_function
            pass

        @classmethod
        def tearDownClass(cls):
            pass

        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-10 21:37:02.909063
# Unit test for function get_local_reprs
def test_get_local_reprs():
    # (None, (), {}, {'my_repr':lambda x: 'my_repr(%s)' % x})
    class MyRepr(object):
        def __repr__(self):
            return 'my_repr()'
        def __str__(self):
            return 'my_str()'

    class MyVariable(BaseVariable):
        def items(self, frame, normalize=False):
            local_reprs = get_local_reprs(frame, normalize=normalize)
            return {'my_variable': local_reprs['a']}


    def f():
        a = 'a'
        my_repr = MyRepr()
        my_variable = MyVariable()
        return get_local_reprs(inspect.currentframe())


# Generated at 2022-06-10 21:37:14.585731
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Try with empty input
    # Expect error to be thrown
    with pytest.raises(TypeError):
        Tracer().__call__()
    # Try with args pysnooper.snoop.Tracer() and function simple_sum
    # Expect global variable DISABLED to be False
    # Expect variable function_or_class to be equal to simple_sum
    global DISABLED
    DISABLED = False
    def simple_sum(x, y):
        return x + y
    result = Tracer().__call__(simple_sum)
    assert result == simple_sum
    # Try with args pysnooper.snoop.Tracer() and class TestClass
    # Expect attribute TestClass.SimpleSum to be equal to simple_sum

# Generated at 2022-06-10 21:37:24.607079
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    code = """
    def foo(x):
        y = x + 1
        return y
    x=1
    foo(1)
    x=2
    foo(1)
    """
    output = StringIO()
    watch_explode = ["x*2", "y*3"]

# Generated at 2022-06-10 21:37:35.605683
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    class Foo:
        def __init__(self, n):
            self.n = n

        def get_n(self):
            return self.n

        def __getitem__(self, i):
            return i * i

    @pysnooper.snoop(watch=('f', 'f.n', 'f[1]'), watch_explode=('f',), custom_repr=('n',
        lambda n: 'n * 10: %s' % (n * 10)))
    def f(n):
        f = Foo(n)
        return f.get_n()

    f(10)

# class CommonVariable(thread_local):

# Generated at 2022-06-10 21:37:46.161423
# Unit test for function get_write_function
def test_get_write_function():
    get_write_function(None, False)
    get_write_function(None, True)
    get_write_function(sys.stdout, False)
    get_write_function(sys.stdout, True)
    get_write_function(utils.StringIOWrapper(), False)
    get_write_function(utils.StringIOWrapper(), True)
    get_write_function(os.devnull, False)
    get_write_function(os.devnull, True)
    get_write_function(lambda s: 0, False)
    get_write_function(lambda s: 0, True)
    get_write_function('', False)
    get_write_function('', True)
    with pycompat.open(os.devnull, 'w') as devnull:
        get_write_function

# Generated at 2022-06-10 21:37:51.252388
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_func():
        var = 1 + 1
        return var
    assert get_path_and_source_from_frame(inspect.currentframe())[0] \
                                           == test_func.__code__.co_filename
    assert get_path_and_source_from_frame(inspect.currentframe())[1] \
                                           == inspect.getsourcelines(test_func)[0]



# Generated at 2022-06-10 21:37:52.623769
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(inspect.currentframe())



# Generated at 2022-06-10 21:39:26.493379
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test that a snooper is created
    snooper = Tracer()
    # Test that a snooper is created, with a non-default value
    snooper2 = Tracer(output='test')
    # Test that the output can be passed a file
    snooper3 = Tracer(output=open('test', 'w'))
    # Test that the snooper can be used as a context manager
    with snooper:
        a = 1
    with snooper2:
        b = 2
    with snooper3:
        c = 3
    # Test that a snooper is created for a generator, and can be used
    # as a context manager
    @utils.generator
    def f():
        yield 1
        yield 2

# Generated at 2022-06-10 21:39:36.711418
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import inspect
    import re

    import pytest
    import six


    @pysnooper.snoop()
    def foo(g):
        a = 1
        b = a
        c = b
        g.send(c)


    class X(object):
        @pysnooper.snoop()
        def foo(self, g):
            a = 1
            b = a
            c = b
            g.send(c)


    @pysnooper.snoop()
    def empty():
        pass


    @pysnooper.snoop()
    def custom_repr(obj):
        return 'custom_repr={}'.format(obj)


# Generated at 2022-06-10 21:39:39.437347
# Unit test for function get_write_function
def test_get_write_function():
    assert isinstance(get_write_function(None, False), functools.partial)
    assert isinstance(get_write_function(None, True), functools.partial)


# Generated at 2022-06-10 21:39:50.983562
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    source_path = os.path.realpath(__file__)
    with open(source_path) as f:
        source = f.read()

    frame = types.FrameType(f_globals={}, f_locals={}, f_back=None, f_code=None, f_trace=None, f_lasti=32)

    watch = []
    watch_explode = []

    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False


# Generated at 2022-06-10 21:39:58.326062
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def test(function_or_class,):
        if DISABLED:
            return function_or_class
        if inspect.isclass(function_or_class):
            return self._wrap_class(function_or_class)
        else:
            return self._wrap_function(function_or_class)
    return locals()

# Generated at 2022-06-10 21:40:06.548023
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    class A:
        a = 1
        b = 2
        c = 3

        def __init__(self):
            self.d = 4
            self.e = 5
            self.f = 6

        def method(self):
            self.g = 7
            self.h = 8
            self.i = 9

            for j in range(10):
                self.j = j
                self.k = self.j + 10
                self.l = self.j + 20
                self.m = self.j + 30
            return self.j

    with pysnooper.snoop():
        A().method()

# Generated at 2022-06-10 21:40:16.557459
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    file_ = StringIO()
    tracer = Tracer(file_)
    frame = FrameType(None, inspect._empty)
    frame = frame._replace(f_code = FrameType.f_code.__class__(1, 2, 3, 4, 0, 5, 6, 7, 8, 9, 10))
    tracer.start_times = {frame: datetime_module.datetime(1998, 1, 1, 12, 12)}
    tracer.__exit__(None, None, None)
    assert(file_.getvalue() == '    Elapsed time: 0:00:00\n')


# Generated at 2022-06-10 21:40:25.151013
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    contents = []
    if not os.path.exists('test_FileWriter_write.tmp'):
        with open('test_FileWriter_write.tmp', 'w', encoding='utf-8'):
            pass
        path = pycompat.text_type('test_FileWriter_write.tmp')
    else:
        path = pycompat.text_type('test_FileWriter_write_b.tmp')
    output = FileWriter(path, True)
    # Test for write with `overwrite=True`
    s = 'write with overwrite=True\n'
    output.write(s)
    with open(path, 'r', encoding='utf-8') as output_file:
        contents.append(output_file.read())
    assert contents[-1] == s
    # Test for write with `overwrite=

# Generated at 2022-06-10 21:40:37.244134
# Unit test for constructor of class Tracer
def test_Tracer():
    '''
    o = Tracer(watch=('foo', 'bar'), watch_explode=('foo', 'bar'))
    assert o.watch == [BaseVariable('foo'), BaseVariable('bar'),
                       Exploding('foo'), Exploding('bar')]

    o = Tracer()
    assert o.watch == []
    assert o.watch_explode == []

    o = Tracer(watch=(('foo',1), ('bar',2)))
    assert o.watch == [BaseVariable('foo'), BaseVariable('bar')]

    o = Tracer(watch=(('foo',11), ('foo',2)))
    assert o.watch == [BaseVariable('foo')]

    o = Tracer(watch='foo')
    assert o.watch == [BaseVariable('foo')]
    '''


# Generated at 2022-06-10 21:40:47.519514
# Unit test for function get_write_function
def test_get_write_function():
    class FakeFile:
        def __init__(self):
            self.written = False
        def close(self):
            pass
        def write(self, s):
            self.written = s
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass
    assert callable(get_write_function(FakeFile(), False))
    f = FakeFile()
    get_write_function(f, False)('hello')
    assert f.written == 'hello'
    f = FakeFile()
    get_write_function(lambda s: f.write(s * 2), False)('hello')
    assert f.written == 'hellohello'
    f = FakeFile()
    with FakeFile() as f:
        get_write_function(f, False)('hello')
   