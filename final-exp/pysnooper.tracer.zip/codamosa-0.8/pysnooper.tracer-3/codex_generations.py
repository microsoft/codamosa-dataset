

# Generated at 2022-06-10 21:33:24.467969
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # CallableTestCase.__init__ of pytest-mock
    pytest_mock_1 = pytest_mock.mock.Mock()
    pytest_mock_1.return_value = '_formatret_'
    # CallableTestCase.__init__ of test_tracer
    _formatret_1 = pytest_mock_1(argspec=None,
                                 func_or_cls=_formatret_)
    assert _formatret_1 == '_formatret_'
    # CallableTestCase.__init__ of pytest-mock
    pytest_mock_2 = pytest_mock.mock.Mock()
    pytest_mock_2.return_value = '_formatret_'
    # CallableTestCase.__init__ of test_tr

# Generated at 2022-06-10 21:33:33.614174
# Unit test for function get_write_function
def test_get_write_function():
    class TestPath:
        def __fspath__(self):
            return 'test'

    class TestPath2:
        def __fspath__(self):
            raise AttributeError

    class TestStream:
        def write(self, s):
            pass

    import io
    import io as io_module

    assert io_module == io

    with io.StringIO() as io_stream:
        write_function = get_write_function(io_stream, False)
        assert write_function is io_stream.write

    fake_stderr = utils.WritableStream()
    write_function = get_write_function(fake_stderr, False)
    assert write_function is fake_stderr.write

    write_function = get_write_function(None, False)

# Generated at 2022-06-10 21:33:45.030945
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with Tracer(watch=('a',)) as tracer:
        a, b = "a", "b"
        a, b = "a", "b"   # code_byte = LOAD_CONST - 12
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a, b = "a", "b"
        a

# Generated at 2022-06-10 21:33:55.542586
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    '''
    The decorator @snoop() can be used only on functions, coroutines,
    generators and classes.
    '''
    def test_function():
        pass

    @asyncio.coroutine
    def test_coroutine():
        yield from asyncio.sleep(0)

    def test_generator():
        yield 42

    @snoop()
    def test_decorator_on_function():
        pass

    @snoop()
    @asyncio.coroutine
    def test_decorator_on_coroutine():
        yield from asyncio.sleep(0)

    @snoop()
    def test_decorator_on_generator():
        yield 42

    @snoop()
    class TestClass:
        pass



# Generated at 2022-06-10 21:33:58.792524
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as tracer:
        pass

    with pytest.raises(KeyError):
        tracer.start_times[inspect.currentframe().f_back]



# Generated at 2022-06-10 21:34:07.548568
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    file_name = os.path.join(tempfile.gettempdir(), 'test_file')
    try:
        with open(file_name, 'w') as f:
            f.write('def foo():\n    a = 5\n')
        def foo():
            frame = inspect.currentframe()
            assert get_path_and_source_from_frame(frame) == (
                file_name, ['def foo():', '    a = 5']
            )
            return 1
        assert foo() == 1
    finally:
        os.remove(file_name)
test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:34:11.764680
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_frame = inspect.currentframe()
    test_file_name, test_source = get_path_and_source_from_frame(
        test_frame)
    assert test_file_name == __file__
    assert test_frame.f_code.co_filename in test_file_name
    assert test_source[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-10 21:34:23.578679
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import tempfile
    import os
    import sys
    import subprocess
    import pysnooper
    import functools
    import threading
    import inspect
    from unittest import TestCase
    import pysnooper._tracer
    from _pytest.monkeypatch import MonkeyPatch
    class Classy:
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar
        def method(self):
            return self.foo + self.bar
    classy = Classy(1, 2)
    with tempfile.NamedTemporaryFile(mode='r', encoding='utf-8') as f:
        with MonkeyPatch() as m:
            m.setattr(pysnooper, 'DISABLED', False)

# Generated at 2022-06-10 21:34:31.340979
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import debugger
    def foo():
        frame = inspect.currentframe()
        return get_path_and_source_from_frame(frame)
    file_name, source = foo()
    assert (file_name, source[0]) == (__file__, 'def foo():')
    assert (file_name, source[-1]) == (__file__, '    return get_path_and_source_from_frame(frame)')
    del debugger.get_path_and_source_from_frame, debugger.foo



# Generated at 2022-06-10 21:34:36.322883
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_path_and_source_from_frame_call(x):
        return get_path_and_source_from_frame(
            inspect.currentframe().f_back.f_back.f_back
        )

    assert get_path_and_source_from_frame_call(1)



# Generated at 2022-06-10 21:34:58.172044
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import subprocess
    subprocess.call(['pytest', 'testing.py::test_Tracer_trace'])
    raise SystemExit



# Generated at 2022-06-10 21:35:07.809209
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    from pysnooper import snoop
    print_func = sys.stdout.write
    def test_case1():
        @snoop(watch=('i', 'j', 'm'), depth=2)
        def foo(n):
            i = 1
            j = 2
            for i in range(2, n):
                for j in range(3, n):
                    print(i, j)
        foo(5)

    def test_case2():
        @snoop(watch=('i', 'j', 'm'), depth=2)
        def foo(n):
            i = 1
            j = 2
            if j > 1:
                m = 9
            for i in range(2, n):
                for j in range(3, n):
                    print(i, j)
       

# Generated at 2022-06-10 21:35:12.746880
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    
    @pysnooper.snoop()
    def f(x):
        time.sleep(2)
        return x ** 2
    
    with pysnooper.snoop():
        f(3)
    
    with pysnooper.snoop():
        raise Exception('hi')

test_Tracer___exit__()

# Generated at 2022-06-10 21:35:15.813720
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.run_docstring_examples(Tracer.trace, globals(), verbose=True)

# Generated at 2022-06-10 21:35:27.770392
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper.snoop import _wraps_with_bound_arguments, _unbound_method

    class Foo(object):
        def bar(self):
            """Test function docstring."""
            pass

    # pylint: disable=assignment-from-no-return
    class_, function = Tracer()(Foo)

    returned_function = Foo.bar
    class_, returned_function = Tracer()(returned_function)

    assert class_ is None
    assert isinstance(function, functools.partial)
    assert 'bar' in dir(Foo)
    # pylint: enable=assignment-from-no-return

    assert getattr(Foo, 'bar') == returned_function
    assert getattr(Foo, 'bar') is not function

# Generated at 2022-06-10 21:35:32.519354
# Unit test for constructor of class Tracer
def test_Tracer():
    with (pysnooper.Snooper(watch=("foo",), watch_explode=("bar",))) as snooper:
        foo = 'abc'
        bar = ['abc', 'def']
        snooper.watch = ['c']
        snooper.watch_explode = ['d']
        c = 'abc'
        d = ['abc', 'def']
        snooper.watch.append('e')
        snooper.watch_explode.append('f')
        e = 'abc'
        f = ['abc', 'def']
# END Unit test for constructor of class Tracer


# Generated at 2022-06-10 21:35:39.617400
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys
    import tempfile
    test_source = '''def f():
    1/0'''

    def get_module():
        module_name = 'test_module'
        if module_name in sys.modules:
            del sys.modules[module_name]
        return type(sys)(module_name)

    def test_normal_module():
        module = get_module()
        file_path = module.__file__ = tempfile.mktemp('.py')
        with open(file_path, 'wb') as f:
            f.write(pycompat.bytes_(test_source))
        module.__loader__ = None
        frame = sys._getframe(1)
        frame.f_globals = module.__dict__
        file_path, source = get_path_and_source_from_

# Generated at 2022-06-10 21:35:46.381051
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # We need to use a real file (can't mock it), as it's hardcoded into the
    # decorator module.
    with tempfile.NamedTemporaryFile() as f:
        output = f.name
        ts = Tracer(output=output)
        assert ts.trace is not None



# Generated at 2022-06-10 21:35:54.070146
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import _tst_utils

    def f():
        import inspect
        frame = inspect.currentframe()
        return get_path_and_source_from_frame(frame)
    path, source = f()
    assert isinstance(source, list)
    assert source[0] == _tst_utils.get_current_line_as_string()



# Generated at 2022-06-10 21:36:01.959416
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import functools
    """Test cases for Tracer class."""
    def wrapper():
        """Wrapping up tracer in a function."""
        pass
    @functools.wraps(wrapper)
    def tracer(self, frame, event, arg):
        wrapper(self, frame, event, arg)
    return tracer
if __name__ == '__main__':
    print(test_Tracer_trace()())



# Generated at 2022-06-10 21:36:25.061766
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = inspect.currentframe()
    assert get_local_reprs(frame) == {'frame': '<frame at 0x10c34e7e8>',
                                      'utils': '<module utils>'}



# Generated at 2022-06-10 21:36:34.720516
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_frame():
        import inspect
        return inspect.currentframe().f_back
    def assert_get_source_and_path(frame, source, path):
        source_and_path = get_path_and_source_from_frame(frame)
        assert source_and_path[0] == path
        assert source_and_path[1] == source
    def assert_get_source_and_path_is_unavailable(frame):
        source_and_path = get_path_and_source_from_frame(frame)
        assert isinstance(source_and_path[1], UnavailableSource)
    def assert_source_is_unavailable():
        assert_get_source_and_path_is_unavailable(get_frame())

# Generated at 2022-06-10 21:36:42.592687
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    capture_logs = unittest.mock.patch.object(tracer, 'write', autospec=True)
    make_timestamp = unittest.mock.patch.object(tracer,
                          'make_timestamp', autospec=True)
    make_timestamp.return_value = '123'

    frame = inspect.currentframe().f_back
    event = 'call'
    arg = None

    captured = capture_logs.__enter__()
    func = tracer.trace(frame, event, arg)
    assert func is tracer.trace
    assert len(captured.mock_calls) == 1


# Generated at 2022-06-10 21:36:54.263148
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    self = Tracer(output=utils.DummyStdout(),
                  watch=(),
                  watch_explode=(),
                  depth=1,
                  prefix='',
                  overwrite=False,
                  thread_info=False,
                  custom_repr=(),
                  max_variable_length=100,
                  normalize=False,
                  relative_time=False)
    exc_type = Exception
    exc_value = Exception()
    exc_traceback = None
    try:
        raise exc_value
    except:
        exc_traceback = sys.exc_info()[2]
        self.__exit__(*sys.exc_info())
        ret_val = False
    else:
        ret_val = None
    return ret_val

# Generated at 2022-06-10 21:36:58.066095
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        frame = sys._getframe()
        return get_path_and_source_from_frame(frame)

    result = foo()
    assert result[0] == __file__
    assert result[1][1] == 'def foo():'



# Generated at 2022-06-10 21:37:04.109175
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False).__name__ == 'write'
    assert get_write_function('foo', True).__name__ == 'write'
    assert get_write_function(sys.stderr, False).__name__ == 'write'
    assert get_write_function(lambda s: s, False).__name__ == '<lambda>'



# Generated at 2022-06-10 21:37:04.805196
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass

# Generated at 2022-06-10 21:37:09.101680
# Unit test for constructor of class Tracer
def test_Tracer():
    assert Tracer().depth == 1
    assert Tracer(depth=2).depth == 2
    assert Tracer(depth='2').depth == 2
    assert Tracer(depth='3').depth == 3
    assert Tracer(depth='4').depth == 4


# Generated at 2022-06-10 21:37:16.094335
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def foo():
        for i in range(3):
            yield i

    g = foo()
    next(g)
    frame = g.gi_frame
    assert get_path_and_source_from_frame(frame) == (
        inspect.getsourcefile(test_get_path_and_source_from_frame),
        [
            'def foo():',
            '    for i in range(3):',
            '        yield i',
        ]
    )



# Generated at 2022-06-10 21:37:21.537016
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    m = inspect.getmodule(frame)
    file_name, source = get_path_and_source_from_frame(frame)
    assert isinstance(source[0], pycompat.text_type)
    assert file_name == os.path.abspath(m.__file__)



# Generated at 2022-06-10 21:37:50.247523
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def decorator_factory(prefix='', **kwargs):
        def decorator(func):
            return Tracer(prefix=prefix, **kwargs)(func)
        return decorator
    def simple_test(x):
        return x
    decorator_with_prefix = decorator_factory(prefix='PREFIX ')
    decorated_function_with_prefix = decorator_with_prefix(simple_test)
    assert isinstance(decorated_function_with_prefix, Tracer)
    assert decorated_function_with_prefix.prefix == 'PREFIX '
    assert decorated_function_with_prefix.target_codes == {simple_test.__code__}
    assert decorated_function_with_prefix.watch == []
    assert decorated_function_with_prefix.depth == 1
    assert decorated_function_with_prefix

# Generated at 2022-06-10 21:38:00.083201
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    class Loader(object):
        def get_source(name):
            if name == 'module':
                return 'a = 1'
            raise ImportError
    def func():
        x = 3
        source, source_path = get_path_and_source_from_frame(
            inspect.currentframe()
        )
        assert source == source_and_path_cache[('<string>', '<string>')][1]
        assert source == ['x = 3']
        assert source_path == ('<string>', ['x = 3'])
    frame = inspect.currentframe()
    func()
    del frame
    frame2 = inspect.currentframe()
    for i in range(3):
        frame2 = frame2.f_back

# Generated at 2022-06-10 21:38:11.644260
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    try:
        from io import BytesIO
    except ImportError:
        from io import BytesIO

    def _test_Tracer___exit__body(io, source_path, source, multi_line_func,
                                  depth):
        tracer = Tracer(output=io)
        tracer.depth = depth
        tracer.start_times[multi_line_func.__code__] = \
                                datetime_module.datetime.now()
        tracer.last_source_path = source_path
        tracer._write(u'Source path:... {source_path}\n'.format(**locals()))
        tracer._write(u'Call ended by exception\n')
        tracer.thread_info_padding = 20
        tracer.__exit__(None, None, None)
        assert tr

# Generated at 2022-06-10 21:38:22.031695
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    FileWriter('temp', overwrite=True).write(u'Lorem ipsum')
    with open('temp') as f:
        assert f.read() == 'Lorem ipsum'
    FileWriter('temp', overwrite=False).write(u' dolor sit amet')
    with open('temp') as f:
        assert f.read() == 'Lorem ipsum dolor sit amet'
    FileWriter('temp', overwrite=True).write(u'Lorem ipsum')
    with open('temp') as f:
        assert f.read() == 'Lorem ipsum'
    os.remove('temp')



# Generated at 2022-06-10 21:38:23.778051
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Write your code here to test Tracer.trace()
    pass


# Generated at 2022-06-10 21:38:24.911174
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    return True



# Generated at 2022-06-10 21:38:40.304682
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED=False
    output = StringIO()
    pysnooper.snoop(output=output,
                    watch=('a', 'b', 'c', 'd'),
                    watch_explode=('my_list', 'my_dict'),
                    depth=2,
                    prefix='ZZZ ',
                    overwrite=False,
                    thread_info=False,
                    custom_repr=((list, str),),
                    max_variable_length=100,
                    normalize=False,
                    relative_time=False)
    @pysnooper.snoop()
    def foo():
        a = 1
        b = 'hello world'
        c = []
        d = {}
        c.append(a)
        c.append(b)
        c.append(c)
        c

# Generated at 2022-06-10 21:38:52.003553
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    class Stub_Tracer :

        # Assign parameters as attributes
        def __init__(self, output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False, ) :
            self.output = output
            self.watch = watch
            self.watch_explode = watch_explode
            self.depth = depth
            self.prefix = prefix
            self.overwrite = overwrite
            self.thread_info = thread_info
            self.custom_repr = custom_repr
            self.max_variable_length = max_variable_length
            self.normalize = normalize
            self.relative_time = relative_time


# Generated at 2022-06-10 21:38:59.661419
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # No setup.

    # Exercise the SUT.
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False,
                    custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    frame = inspect.currentframe().f_back
    result = tracer.trace(frame, 'call', None)

    # Verify the result.
    assert None is result


# Generated at 2022-06-10 21:39:01.738179
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pprint.pprint(Tracer.trace.__dict__)

# Code for decorator watch of class Tracer

# Generated at 2022-06-10 21:39:25.998805
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    if utils.get_testing_mode():
        return
    import pysnooper
    pysnooper.Snooper.__exit__.__wrapped__(None,None,None)
    pysnooper.Snooper._is_internal_frame.__wrapped__(None,None,None)
    pysnooper.Snooper.set_thread_info_padding.__wrapped__(None,None,None)
    pysnooper.Snooper.trace.__wrapped__(None,None,None)

# Generated at 2022-06-10 21:39:32.080176
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    def foo():
        pass
    foo.__module__ = '__main__'
    foo_code = foo.__code__
    result = get_path_and_source_from_frame(types.FunctionType(foo_code, {}))
    (_, source), = result.items()
    assert source[0] == u''
    assert source[1].startswith(u'def')



# Generated at 2022-06-10 21:39:34.713692
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test():
        x = 14
        from . import utils
        utils.get_path_and_source_from_frame(sys._getframe())
    return test



# Generated at 2022-06-10 21:39:36.493465
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(sys._getframe())



# Generated at 2022-06-10 21:39:47.079126
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper.utils import get_write_function, get_path_and_source_from_frame, normalize_path, get_shortish_repr, truncate

    # unit test for method get_write_function of module utils
    def test_get_write_function():
        class FileLike:
            def write(self, s):
                pass

        assert get_write_function(None) == sys.stdout.write
        assert get_write_function(sys.stdout) == sys.stdout.write
        assert get_write_function(sys.stdout.write) == sys.stdout.write
        assert get_write_function(FileLike()) == FileLike().write

    # unit test for method get_path_and_source_from_frame of module utils

# Generated at 2022-06-10 21:39:48.666427
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-10 21:39:57.207243
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def tes_trace(event, frame, arg):
        return event

    t = Tracer(depth=None, normalize=False)
    assert t.trace(None, None, None) is None
    assert t.trace(None, None, None) == 'call'
    assert t.trace(None, None, None) == 'line'
    assert t.trace(None, None, None) == 'return'
    assert t.trace(None, None, None) == 'exception'


# Generated at 2022-06-10 21:40:07.105363
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import re
    import pysnooper
    from pysnooper.writer import get_write_function

    output = get_write_function(None, False)
    tracer = pysnooper.Tracer(output=output, watch=(), watch_explode=(), depth=1, prefix='',
                              overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100,
                              normalize=False, relative_time=False)
    frame = inspect.currentframe()
    event = 'call'
    arg = None
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.thread_local = threading.local()
    tr

# Generated at 2022-06-10 21:40:19.513984
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    start_time = datetime_module.datetime.now()
    end_time = start_time + datetime_module.timedelta(seconds=60.0)
    while datetime_module.datetime.now() < end_time:
        import os
        import random
        import sys
        # Here we test that we correctly ignore calls to the snooper __exit__ method
        # (and others)

        # We monkey patch the inspect module to always return the same values
        # for the current frame, current source path and current source lines
        # it does that by returning a fake frame, source path and source lines
        inspect_source_lines = ["def foo()\n", "	bar()\n", "	print(foo)\n"]
        previous_inspect_getsourcelines = inspect.getsourcelines
        import built

# Generated at 2022-06-10 21:40:26.857577
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():

    # pysnooper.Tracer.__exit__:10 (self, exc_type, exc_value, exc_traceback)
    # (type(exc_type), exc_type) = <class>, None
    exc_type = None
    # (type(exc_value), exc_value) = <class>, None
    exc_value = None
    # (type(exc_traceback), exc_traceback) = <class>, None
    exc_traceback = None

    # self.depth = -1
    thread_global.depth = -1
    # (type(self._write), self._write) = <class 'function'>, <function _write at 0x7fd9a9e0e048>
    self._write = _write
    # (type(self.watch), self.watch) = <class 'list'>, []

# Generated at 2022-06-10 21:41:09.515015
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .test import unittest_tools
    def foo():
        pass

    assert get_path_and_source_from_frame(foo.__code__.co_filename) == (
        foo.__code__.co_filename, UnavailableSource(),
    )


Approximate = type(repr(datetime_module.date.today()), (object,), {})



# Generated at 2022-06-10 21:41:12.410666
# Unit test for constructor of class Tracer
def test_Tracer():
    with StringIO() as f:

        @Tracer(output=f)
        def foo(x):
            return x + 1

        assert foo(12) == 13
        output = f.getvalue().splitlines()
        assert 'Source path:...' in output[0]
        assert 'foo = 12' in output[1]
        assert 'Return value:.. 13' in output[-1]


# Generated at 2022-06-10 21:41:13.974329
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pytest
    with pytest.raises(TypeError):
        pysnooper.snoop()(lambda: None).__code__


# Generated at 2022-06-10 21:41:18.880012
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe()
    path, source_lines = get_path_and_source_from_frame(frame)
    assert len(path) > 0
    assert isinstance(source_lines, list)
    assert source_lines[0] == 'def test_get_path_and_source_from_frame():'



# Generated at 2022-06-10 21:41:21.703512
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        get_path_and_source_from_frame(inspect.currentframe())
    foo()



# Generated at 2022-06-10 21:41:29.311523
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    obj = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    exc_type = exc_value = exc_traceback = None
    obj.__exit__(exc_type, exc_value, exc_traceback)
    return None

# Generated at 2022-06-10 21:41:40.504325
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function():
        "mydocstring"
        a = 1
        b = 2
        c = 3

    def function2():
        "mydocstring2"
        a = 4
        b = 5
        c = 6

    file_name, source = get_path_and_source_from_frame(
        inspect.currentframe().f_back
    )
    assert source[0] == "def function():"
    assert source[1] == '    "mydocstring"'
    assert source[2] == "    a = 1"
    assert source[3] == "    b = 2"
    assert source[4] == "    c = 3"

    file_name, source = get_path_and_source_from_frame(
        inspect.currentframe().f_back
    )

# Generated at 2022-06-10 21:41:41.759723
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass # Nothing to test



# Generated at 2022-06-10 21:41:51.436608
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect

    def dummy_function():
        pass

    real_path, source = get_path_and_source_from_frame(inspect.currentframe())
    assert real_path == os.path.realpath(__file__)
    assert source[0].startswith('def test_get_path_and_source_from_frame():')
    dummy_function_path, dummy_source = \
        get_path_and_source_from_frame(inspect.currentframe(1))
    assert dummy_function_path == real_path
    assert dummy_source[:5] == source[:5]

test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:42:00.185145
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from tracer.tests.fixtures import dummy
    from tracer.tests.fixtures import dummy_module
    from tracer.tests.fixtures.dummy import foo

    t = Tracer()
    t.watch = [
        dummy,
        dummy_module,
        foo,
        (lambda v: isinstance(v, dict)
                   and v == dict(a=1, b=2, c=3),
         lambda v: '{}...'.format(v[0])),
    ]
    t.frame_to_local_reprs = {}
    t.start_times = {}
    t.depth = 1
    t.prefix = ''
    t.thread_info = False
    t.thread_info_padding = 0
    t.target_codes = set()
    t.target_frames = set()
