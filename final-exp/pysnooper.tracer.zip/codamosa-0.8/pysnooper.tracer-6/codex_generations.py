

# Generated at 2022-06-10 21:33:33.509609
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  import sys, time
  import random, collections
  import functools
  from os.path import dirname
  from pysnooper.thirdparty import inspect
  from pysnooper.thirdparty import pycompat
  from pysnooper.thirdparty import datetime_module
  from pysnooper.thirdparty import threading
  from pysnooper.thirdparty import traceback
  from pysnooper.thirdparty import opcode
  from pysnooper.thirdparty.utils import get_path_and_source_from_frame
  from pysnooper import utils
  from pysnooper.variable import BaseVariable
  from pysnooper.variable import CommonVariable
  from pysnooper.variable import Exploding
  from pysnooper.utils import get_write_function

# Generated at 2022-06-10 21:33:37.508338
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import models.test_util.test_decorators
    import models.test_util.test_decorators
    test_decorators.test_decorators()

# Generated at 2022-06-10 21:33:46.725344
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  T = Tracer(max_variable_length=None)

  def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False):
    self._write = get_write_function(output, overwrite)

    self.watch = [
            v if isinstance(v, BaseVariable) else CommonVariable(v)
            for v in utils.ensure_tuple(watch)
         ] + [
             v if isinstance(v, BaseVariable) else Exploding(v)
             for v in utils.ensure_tuple(watch_explode)
        ]
    self.frame_to_local_reprs = {}

# Generated at 2022-06-10 21:33:52.997227
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def return_42():
        return 42

    frame = (inspect.currentframe() or (sys._getframe(1) if sys._getframe
                                        else None)).f_back
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name.endswith('test_debug_utils.py')
    assert source[frame.f_lineno - 1].strip() == 'def return_42():'



# Generated at 2022-06-10 21:34:04.176994
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  fn = "test_Tracer_trace"
  import io
  # Import other standard Python libraries
  import sys
  import inspect
  import datetime
  import os
  import pycompat
  import pysnooper
  import opcode
  import functools
  import threading
  import traceback
  import pycompat
  from pysnooper.utils import get_write_function, get_path_and_source_from_frame
  from pysnooper.utils import BaseVariable, CommonVariable, Exploding
  from pysnooper.utils import get_local_reprs, make_repr
  from pysnooper.utils import DISABLED, DefaultOrderedDict, utils
  from pysnooper.variables import Tracer
  from pysnooper.variables import thread_global

# Generated at 2022-06-10 21:34:12.640984
# Unit test for function get_write_function
def test_get_write_function():

    class StreamLike(object):
        def __init__(self):
            self.written_strings = []

        def write(self, s):
            self.written_strings.append(s)

    def my_write_function(s):
        if isinstance(s, bytearray):
            raise UnicodeEncodeError('bla')
        if isinstance(s, bytes):
            return 'Bytes %s' % utils.shitcode(s)
        return 'My write function: %s' % s

    stream = StreamLike()
    write_function = get_write_function(b'bla')
    write_function(u'bla')
    write_function(b'bla')
    write_function(bytearray(b'bla'))

# Generated at 2022-06-10 21:34:17.409480
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import utils
    def f(): pass
    frame = utils.get_frame(f)
    path, source = get_path_and_source_from_frame(frame)
    assert path
    assert source and 'f' in source[0]



# Generated at 2022-06-10 21:34:23.859240
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return inspect.currentframe()
    frame = f()
    expected_path, expected_source = __file__, inspect.getsource(f).splitlines()
    result_path, result_source = get_path_and_source_from_frame(frame)
    assert result_path == expected_path
    assert result_source == expected_source
assert test_get_path_and_source_from_frame() is None



# Generated at 2022-06-10 21:34:35.542682
# Unit test for function get_local_reprs
def test_get_local_reprs():  # pragma: no cover
    local_dict = {'a': 1, 'b': 2, 'c': 3}
    def function(x):
        def inner():
            return 4
        return inner()
    code = function.__code__
    code = types.CodeType(0, code.co_kwonlyargcount, code.co_nlocals,
                          code.co_stacksize, code.co_flags, code.co_code,
                          code.co_consts, code.co_names, code.co_varnames,
                          'test_get_local_reprs', code.co_name, 1,
                          code.co_lnotab, (), ())
    frame = types.FrameType(local_dict, {}, {}, 'test_get_local_reprs', code)


# Generated at 2022-06-10 21:34:39.411978
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    p = Tracer()
    frame = sys._getframe()
    event = 'return'
    arg = None
    expected = None
    actual = p.trace(frame, event, arg)
    assert expected == actual


# Generated at 2022-06-10 21:35:06.925918
# Unit test for function get_local_reprs
def test_get_local_reprs():
    class C(object):
        pass
    c = C()
    custom_repr = {C: lambda c: 'newrepr(c)'}
    frame = inspect.currentframe()
    assert get_local_reprs(frame, custom_repr=custom_repr) == \
           {'C': 'newrepr(c)',
            'frame': 'get_local_reprs(frame, custom_repr=custom_repr)'}



# Generated at 2022-06-10 21:35:17.694942
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    from pysnooper import snoop

    def foo(a):
        b = a + 1
        c = 2 * b
        return c

    def bar():
        import pysnooper
        pysnooper.snoop(watch=('c',))(foo)(1)

    output = io.StringIO()
    snoop(output=output, watch=('b',))(bar)()

    assert output.getvalue().splitlines() == [
        'Source path:... {__file__}',
        'Starting var:.. a = 1',
        'Starting var:.. b = 2',
        'Return value:.. 3',
        'Modified var:.. c = 3',
        'Return value:.. 3',
        'Elapsed time: 0:00:00.000'
    ]
# Unit

# Generated at 2022-06-10 21:35:29.719751
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    '''
    # setUpClass ()
    '''
    # mock ___enter__ of class Tracer
    # setUp
    global DISABLED
    DISABLED = False
    from .threading import thread_global
    thread_global.depth = -1
    global threading
    threading = make_mock()
    threading.local = make_mock()
    thread_local = threading.local()
    thread_local.__dict__.setdefault().__enter__()
    thread_local.__dict__.setdefault('original_trace_functions', []).append()
    global inspect
    inspect = make_mock()
    inspect.currentframe = make_mock()
    calling_frame = inspect.currentframe().__enter__().f_back
    calling_frame.f_trace = make_mock

# Generated at 2022-06-10 21:35:34.083278
# Unit test for function get_write_function
def test_get_write_function():
    test_output = 'file'
    test_write = get_write_function(test_output)
    assert callable(test_write)
    test_output = utils.WritableStream(test_output)
    test_write = get_write_function(test_output)
    assert callable(test_write)



# Generated at 2022-06-10 21:35:47.306678
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """ Unit test for method trace of class Tracer. """
    from base_test import MockOutput
    from new_custom_variable import NewCustomVariable
    with MockOutput() as output:
        # test "return" event
        # test "return" event after exception
        # test "return" event normal
        tracer = Tracer(depth=2, output=output, watch=("foo",),
                        watch_explode=("self",), prefix="!",
                        overwrite=True, thread_info=True,
                        custom_repr=((object, NewCustomVariable),),
                        max_variable_length=None, normalize=False,
                        relative_time=False,
                        )
        tracer()(test_trace_return)()

# Generated at 2022-06-10 21:35:58.838183
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def g():
        x = 1
        get_path_and_source_from_frame(inspect.currentframe())
        del x
        import pathlib
        file_name = pathlib.Path(os.path.abspath(__file__))
        assert file_name.suffix == '.py'
        with open(str(file_name), mode='rb') as f:
            source = f.read().splitlines()
        source = [pycompat.text_type(line, 'utf-8', 'replace') for line in source]
        return (str(file_name), source)
    assert g() == get_path_and_source_from_frame(inspect.currentframe().f_back)

# Generated at 2022-06-10 21:36:06.239576
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        print('hello!')
        return 2

    assert get_path_and_source_from_frame(foo.__code__.co_filename) == (
        foo.__code__.co_filename, UnavailableSource()
    )


CodeInfo = collections.namedtuple('CodeInfo', ['frame', 'code', 'is_python',
                                               'filename', 'source',
                                               'first_line', 'line_no'])



# Generated at 2022-06-10 21:36:07.793922
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    pysnooper


# Generated at 2022-06-10 21:36:14.996664
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  print()
  # test 1
  t = Tracer(output='example.log', watch=('y', 'f', 'o', 'x'), watch_explode=('foo', 'm'), depth=1,
             prefix='', overwrite=False, thread_info=False, custom_repr=(),
             max_variable_length=100, normalize=False, relative_time=False)
  def func(x):
    # f source line
    f = True
    return x**2
  
  @t
  def func(x):
    # f source line
    f = True
    return x**2
  print(func.f)
  
  # test 2

# Generated at 2022-06-10 21:36:15.647033
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass

# Generated at 2022-06-10 21:36:42.350360
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import re
    import tempfile
    import unittest


    class TestTracer___call__(unittest.TestCase):
        def setUp(self):
            self.output = pycompat.StringIO()
            self.tracer = Tracer(output=self.output)


        def tearDown(self):
            del self.tracer


        def test__depth_2_depth_1_and_0(self):
            @self.tracer
            def function_1():
                var_1 = 1
                function_2()
                var_2 = 2
                return var_1 + var_2


            @self.tracer
            def function_2():
                var_1 = 1
                return var_1


            function_1()
            output = self.output.getvalue()

# Generated at 2022-06-10 21:36:54.798546
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def outer_function(i, j):
        def inner_function(k, l):
            return k + l
        return inner_function(i, j)
    frame = inspect.currentframe()
    while frame.f_code.co_name != 'outer_function':
        frame = frame.f_back
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[0] == 'def outer_function(i, j):'
    assert source[1] == '    def inner_function(k, l):'
    assert source[2] == '        return k + l'
    assert source[3] == '    return inner_function(i, j)'
test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:37:00.820568
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import bizzarre
    source_and_path = get_path_and_source_from_frame(bizzarre.add_one.__code__)
    assert source_and_path == (bizzarre.add_one.__code__.co_filename, [
        "def add_one(x):",
        "    if x == 42:",
        "        return bang_the_universe()",
        "    else:",
        "        return x + 1"
    ])



# Generated at 2022-06-10 21:37:06.296815
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    def foo():
        pass
    wrapped_foo = tracer(foo)
    # We're just testing that the wrapping doesn't blow up. Everything else is
    # tested in test_decorator.
    wrapped_foo()

# Generated at 2022-06-10 21:37:17.579303
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import pysnooper
    # self.frame_to_local_reprs.pop(frame, None)
    # self.start_times.pop(frame, None)
    # thread_global.depth -= 1
    def test_method(self, exc_type, exc_value, exc_traceback):
        frame = inspect.currentframe().f_back

        frame_to_local_reprs = self.frame_to_local_reprs.pop(frame, None)
        if frame_to_local_reprs != None:
            return True
        start_times = self.start_times.pop(frame, None)
        if start_times != None:
            return True
        thread_global.depth -=1
        if thread_global.depth == -1:
            return True

    import io

# Generated at 2022-06-10 21:37:22.575907
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func():
        source_line = [1]
        print()
        return source_line
    source_line = [1]
    frame = sys._getframe(1)
    (path, source) = get_path_and_source_from_frame(frame)
    assert source[frame.f_lineno - 1] == '    source_line = [1]'



# Generated at 2022-06-10 21:37:29.709520
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    start_time = datetime_module.datetime.now()
    duration = datetime_module.datetime.now() - start_time
    elapsed_time_string = pycompat.timedelta_format(duration)
    indent = ' ' * 4 * (thread_global.depth + 1)
    assert f'{indent}Elapsed time: {elapsed_time_string}' == '        Elapsed time: 0.000s'
    with Tracer(watch=['hello'], depth=3) as t:
        indent = ' ' * 4 * (thread_global.depth + 1)
        assert f'{indent}Elapsed time: {elapsed_time_string}' == '        Elapsed time: 0.000s'

# Generated at 2022-06-10 21:37:34.737140
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def dummy_function(a): pass
    assert (
        get_path_and_source_from_frame(inspect.currentframe().f_back)[1][0].strip() ==
        inspect.getsource(test_get_path_and_source_from_frame).strip()
    )



# Generated at 2022-06-10 21:37:43.247739
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    snoop = Tracer(watch=())
    frame = frame_for_line(16)
    frame.f_lineno = 16
    frame.f_lasti = 0
    sys.settrace(snoop.trace)
    snoop.trace(frame, 'call', (1, 2))
    frame2 = frame_for_line(19)
    frame2.f_lineno = 19
    frame2.f_lasti = 0
    snoop.trace(frame2, 'call', (1, 2))
    pycompat.execfile('snooper_test.py')


# Generated at 2022-06-10 21:37:50.211123
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Test cases that are expected to fail
    from test_Tracer___exit___Failing import test_cases_failing
    for test_params, expected in test_cases_failing:
        actual = Tracer.__exit__(*test_params)
        assert actual == expected

    # Test cases that are expected to pass
    from test_Tracer___exit___Passing import test_cases_passing
    for test_params, expected in test_cases_passing:
        actual = Tracer.__exit__(*test_params)
        assert actual == expected


# Generated at 2022-06-10 21:38:20.049952
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import add
    def f():
        print('hi')
    frame = f.__code__.co_firstlineno
    path, source = get_path_and_source_from_frame(frame)
    assert path.endswith('sneakums.py')
    assert source is not None
    source = source[frame - 1].strip()
    assert source == 'print(\'hi\')'
    assert source == add.test_get_path_and_source_from_frame.__code__.co_firstlineno.strip()



# Generated at 2022-06-10 21:38:29.798457
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    m4 = MagicMock(return_value=MagicMock())
    # m4.__enter__.return_value = None

    m4.__enter__.return_value.trace.return_value = None
    sys.settrace.return_value = None

    m5 = MagicMock(side_effect=BaseException)
    m5.f_back = None
    m5.f_code = MagicMock()
    m5.f_code.co_filename = 'test.py'
    m5.f_lasti = 0
    m1 = MagicMock()
    m3 = MagicMock()
    m2 = MagicMock(return_value=m3)
    m3.__enter__.return_value = None
    m3.__exit__.return_value = None


# Generated at 2022-06-10 21:38:37.596726
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def a():
        b()

    def b():
        return sys._getframe(0)

    frame = a()

    path, source = get_path_and_source_from_frame(frame)

    assert path.endswith('test_get_path_and_source_from_frame.py')
    assert source[frame.f_lineno - 1] == '        return sys._getframe(0)'



# Generated at 2022-06-10 21:38:41.966465
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    '''__init__(self, output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)'''
    self = Tracer(None, (1,), (2,), 1, '', False, False, (), 100, False, False)
    calling_frame = inspect.currentframe().f_back
    calling_frame.f_trace = Tracer.trace
    self.target_frames.add(calling_frame)
    stack = self.thread_local.__dict__.setdefault('original_trace_functions', [])
    stack.append(sys.gettrace())
    self.start_times[calling_frame] = datetime_module.datetime.now

# Generated at 2022-06-10 21:38:48.206338
# Unit test for constructor of class Tracer
def test_Tracer():
    @Tracer()
    def foo():
        try:
            bar(3)
        except ValueError:
            pass
        return 4

    @Tracer()
    def bar(n):
        baz(n-1)
        return n + 1

    @Tracer(watch=('b', 'n'))
    def baz(n):
        if n >= 0:
            baz(n - 1)
        return n

    bar(6)
    foo()

# Generated at 2022-06-10 21:39:00.040155
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = 12
        def g(z):
            nonlocal y
            # The following line is to trick PyCharm's static analysis:
            assert isinstance(y, int)
            y = 42
            temp = x
            if temp:
                temp = z
            return temp
        return g(x)

    result = get_local_reprs(inspect.currentframe())
    assert result == {'f': repr(f), 'x': repr(1), 'y': repr(42), 'z': repr(1),
                      'temp': repr(1)}

    def make_variable(value):
        variable = BaseVariable('value')
        variable.getter = lambda frame: value
        return variable


# Generated at 2022-06-10 21:39:10.209741
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import sys
    import contextlib

    def FileWriter_fn(path, overwrite):
        s = "We are starving for a good meal\n"
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as output_file:
            output_file.write(s)
        os.remove(output_file.name)
        return {'s':s, 'path':output_file.name, 'overwrite': False}

    out = FileWriter_fn(None, None)
    s = out['s']
    path = out['path']
    overwrite = out['overwrite']

    with open(path, 'w' if overwrite else 'a', encoding='utf-8') as output_file:
        output_file.write(s)
    overwrite = False


# Generated at 2022-06-10 21:39:21.615996
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import unittest

    # Generated code for test_Tracer___enter__
    class TestTracer_0(unittest.TestCase):
        def test_Tracer___enter___0(self):
            # PySnooperInstantiator should work as object as well
            from pysnooper.tracing import PySnooperInstantiator
            import io
            import os
            # The code will write to sys.stdout, this will break the test if executed elsewhere
            import sys
            import threading
            
            # First, test with just a simple function call
            def test_0():
                with PySnooperInstantiator():
                    pass
            

# Generated at 2022-06-10 21:39:26.709045
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test_func(a, b, c=3):
        try:
            return (a, b, c)
        except Exception as e:
            return e

    with Tracer(watch='a', watch_explode=('c',)):
        print(test_func(1, 2, [1, 2, 3], 4, 5, 6))

    with Tracer(depth=2):
        test_func(1, 2, [1, 2, 3], 4, 5, 6)


# Generated at 2022-06-10 21:39:28.951839
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def a():
        def b():
            pass
    pass
    t = Tracer()
    t.trace(None, None, None)


# Generated at 2022-06-10 21:40:03.396512
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    '''__enter__ = __exit__ = None'''
    tracer = Tracer()
    f = lambda x: x / 0
    frame = inspect.currentframe().f_back
    frame.f_code.co_filename = 'test.py'
    frame.f_code.co_name = '<lambda>'
    frame.f_lineno = 1
    frame.f_locals = {'x': 1}
    tracer.target_codes.add(frame.f_code)
    frame.f_trace = tracer.trace
    tracer.target_frames.add(frame)
    tracer.frame_to_local_reprs[frame] = tracer.get_local_reprs(frame)

# Generated at 2022-06-10 21:40:16.044859
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .testing import run_with_locals
    from .testing import make_fake_function_object
    from .testing import make_fake_code_object
    from .testing import fake_function_object

    class FakeFrame(object):
        def __init__(self, f_globals, f_code):
            self.f_globals = f_globals
            self.f_code = f_code
        def __repr__(self):
            return '<FakeFrame %r %r>' % (self.f_globals, self.f_code)

    def get_path_and_source_from_frame(frame):
        return os.path.join(os.path.dirname(__file__), 'test_output.txt'), []


# Generated at 2022-06-10 21:40:24.721974
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    output = tempfile.TemporaryFile()
    write_function = get_write_function(output, False)
    write_function('dummy line')
    output.seek(0)
    assert output.read() == b'dummy line'
    output.close()
    output = tempfile.NamedTemporaryFile(delete=False)
    write_function = get_write_function(output.name, True)
    write_function('dummy line')
    output.close()
    assert open(output.name).read() == 'dummy line'
    os.unlink(output.name)
    output = tempfile.NamedTemporaryFile(delete=False)
    write_function = get_write_function(output, True)
    write_function('dummy line')
    output.close()

# Generated at 2022-06-10 21:40:27.716206
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pysnooper

    @pysnooper.snoop()
    def foo():
        pass

    foo()


# Generated at 2022-06-10 21:40:40.014133
# Unit test for function get_write_function
def test_get_write_function():
    with open(__file__, 'rt', encoding='utf-8') as f:
        file_content = f.read()
    buffer = utils.WritableStream()
    write = get_write_function(None, False)
    write(file_content)
    write = get_write_function(buffer, False)
    write(file_content)
    assert buffer.get_value() == file_content
    write = get_write_function('__test.txt', False)
    write(file_content)
    with open('__test.txt', 'rt', encoding='utf-8') as f:
        assert f.read() == file_content
    write = get_write_function('__test.txt', True)
    write(file_content * 5)

# Generated at 2022-06-10 21:40:48.914059
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    from pysnooper import utils
    from pysnooper import _thread_local as thread_global
    import inspect
    import opcode
    import traceback
    import sys
    import functools
    from pysnooper import get_path_and_source_from_frame
    from pysnooper import BaseVariable, CommonVariable, Exploding
    import types
    import pycompat
    from pysnooper import get_write_function
    import threading
    import datetime
    import os
    #
    # Check that the thread_local object is set correctly
    #

    DISABLED = False
    _datetime_module = datetime

    def wrapped_function(arg):
        return arg

    original_function = wrapped_function



# Generated at 2022-06-10 21:40:49.856890
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-10 21:40:52.207615
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print ("test_Tracer_trace: This method is tested in test_Tracer_snoop ")
    pass


# Generated at 2022-06-10 21:41:02.617820
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import threading
    from parameterized import parameterized

    ### Importing module (which runs its code): ##############################
    #                                                                        #
    import pysnooper

    ### Finished importing module. ###########################################


    #                                                                        #
    ### Testing function Tracer.__exit__: ####################################

    thread_global = threading.local()

    def test_it(output, watch, watch_explode, depth, prefix, overwrite,
                thread_info, custom_repr, max_variable_length, normalize,
                relative_time, exc_type, exc_value, exc_traceback,
                expected_calls):
        tracer_object = None

# Generated at 2022-06-10 21:41:08.484947
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import sys
    import os
    import time
    import re
    import shutil

    with utils.TempDirectory() as temp_dir:
        temp_dir = pycompat.Path(temp_dir)
        path = temp_dir / 'output.txt'
        write = FileWriter(path, overwrite=True).write
        write('abc')
        with path.open() as f:
            assert f.read() == 'abc'

# Generated at 2022-06-10 21:41:36.441513
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # yapf: disable
    # For the record, this function was generated by a script that used
    #   exec(repr(snooper_instance.__dict__))
    #   to inject the following code into the test function:
    def trace(self, frame, event, arg):
        if not (frame.f_code in self.target_codes or frame in self.target_frames):
            if self.depth == 1:
                return None
            elif self._is_internal_frame(frame):
                return None
            else:
                _frame_candidate = frame
                for i in range(1, self.depth):
                    _frame_candidate = _frame_candidate.f_back
                    if _frame_candidate is None:
                        return None

# Generated at 2022-06-10 21:41:44.452251
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def __test_case(initial_globals):
        def __func():
            pass
        frame = inspect.currentframe()
        frame.f_globals = initial_globals
        frame.f_code = __func.__code__
        return get_path_and_source_from_frame(frame)

    # Case 1: no globals should cause it to break
    try:
        __test_case({})
    except Exception:
        pass
    else:
        assert False, "Should've broken in this case."

    # Case 2: globals without `__name__` should cause it to break
    try:
        __test_case({'a': 0})
    except Exception:
        pass
    else:
        assert False, "Should've broken in this case."

    # Case 3: globals without `__

# Generated at 2022-06-10 21:41:57.004009
# Unit test for function get_write_function
def test_get_write_function():
    # Test cases with `output` being `None`
    write_function = get_write_function(None, False)
    assert write_function is not None
    assert callable(write_function)

    # Test cases with `output` being a file path
    write_function = get_write_function('test.txt', False)
    assert write_function is not None
    assert callable(write_function)

    write_function = get_write_function('test.txt', True)
    assert write_function is not None
    assert callable(write_function)

    # Test cases with `output` being a path-like object
    if pycompat.has_pathlib:
        from pathlib import Path
        write_function = get_write_function(Path('./test.txt'), False)
        assert write_function is not None

# Generated at 2022-06-10 21:42:04.760619
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def sample_function():
        return get_path_and_source_from_frame(inspect.currentframe())

    assert sample_function() == os.path.realpath(__file__), repr(sample_function())

    def test_function():
        return sample_function()

    assert test_function() == os.path.realpath(__file__), repr(test_function())

    def another_function():
        return test_function()

    assert another_function() == os.path.realpath(__file__), repr(another_function())



# Generated at 2022-06-10 21:42:14.604561
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def my_function(a_, b_, c_):
        a__ = 1
        bb_ = 2
        a_b = 3
        bb = 4
        c = 5
        return a_, b_, c_, a__, bb_, a_b, bb, c
    locals_dict = get_local_reprs(my_function.func_code.co_filename,
                                  my_function.func_code.co_firstlineno,
                                  locals())

# Generated at 2022-06-10 21:42:23.667758
# Unit test for function get_write_function
def test_get_write_function():
    write_function = get_write_function(None, False)
    assert callable(write_function)
    write_function = get_write_function('test_get_write_function.tmp', True)
    assert callable(write_function)
    write_function = get_write_function(sys.stdout.write, False)
    assert callable(write_function)
    write_function = get_write_function(sys.stdout, False)
    assert callable(write_function)
    try:
        get_write_function(None, True)
    except:
        pass
    else:
        assert False, 'should raise Exception'
    write_function('test')
    assert os.path.exists('test_get_write_function.tmp')

# Generated at 2022-06-10 21:42:27.061329
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import builtins as builtins_module, doctest
    if sys.version_info < (3, 0):
        import __builtin__ as builtins_module
    builtins = builtins_module.__dict__

    doctest.testmod()

# Generated at 2022-06-10 21:42:40.178147
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def test_function(a, b, c, d=True, e=False):
        f = 1
        g = 2
        h = 3
    test_frame = inspect.currentframe().f_back
    assert get_local_reprs(test_frame, custom_repr={int: lambda x: x+1}) == {
        'a': '1',
        'b': '2',
        'c': '3',
        'd': 'True',
        'e': 'False',
        'f': '2',
        'g': '3',
        'h': '4',
    }