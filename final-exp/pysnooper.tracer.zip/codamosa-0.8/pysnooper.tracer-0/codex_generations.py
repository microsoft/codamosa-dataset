

# Generated at 2022-06-10 21:33:24.951869
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    with tempfile.NamedTemporaryFile(mode='w+t') as f:
        file_writer = FileWriter(f.name, True)
        file_writer.write('first_line')
        file_writer.write('second_line')
        assert os.stat(f.name).st_size == len('first_linesecond_line')



# Generated at 2022-06-10 21:33:27.101026
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    with pysnooper.snoop():
        pass

# Generated at 2022-06-10 21:33:42.562472
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    from . import utils
    from .variables import CommonVariable
    from .state import CuteState

    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame)[0] == os.path.abspath(__file__)

    def f():
        frame = inspect.currentframe()
        return get_path_and_source_from_frame(frame)[0]

    assert f() == os.path.abspath(__file__)

    cu = CuteState()
    try:
        cu.set_as_global()
        assert f() == os.path.abspath(__file__)
    finally:
        cu.unset_as_global()


# Generated at 2022-06-10 21:33:53.408583
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Set up
    import pysnooper
    method_to_test = pysnooper.Tracer.__call__
    name = "pysnooper/test/test_example_1.py"
    def func_wrapper(frame, event, arg):
        # The mock of method func_wrapper
        pass

    # Set up the mock object
    monkeypatch = MonkeyPatch()
    monkeypatch.setattr(pysnooper, "DISABLED", False)
    monkeypatch.setattr(pysnooper, "get_path_and_source_from_frame", lambda
        frame: (name, "print(123)"))

    # Set up the param
    args = lambda : None
    args.watch = ()
    args.watch_explode = ()
    args.depth = 1
    args.prefix = ""
   

# Generated at 2022-06-10 21:33:58.055193
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # default input arguments
    default_args = []
    # default output
    default_ans = None
    if default_args != []:
        assert Tracer.trace(*default_args) == default_ans, 'test_Tracer_trace failed'
    # TODO: more tests


# Generated at 2022-06-10 21:34:00.737070
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    import pysnooper
    doctest.testmod(pysnooper)
test_Tracer_trace()

 

# Generated at 2022-06-10 21:34:10.539201
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = False

    # Test for get_frame_info
    try:
        raise Exception()
    except Exception:
        frame = sys.exc_info()[2].tb_frame

    # Test for get_path_and_source_from_frame
    frame_info = inspect.getframeinfo(frame)

    frame_info[0] = os.path.realpath(frame_info[0])

    with open(frame_info[0]) as file:
        source_lines = file.readlines()
        source_lines.reverse()
        source_line = inspect.cleandoc(source_lines[frame_info[1] - 1])

    _source_path, source = get_path_and_source_from_frame(frame)

    # Test for get_local_reprs


# Generated at 2022-06-10 21:34:17.615972
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer(output=None, watch=(), watch_explode=(),
                    prefix='', overwrite=False, thread_info=False, custom_repr=(),
                    max_variable_length=100, normalize=False, relative_time=False)
    exception, value, traceback = None, None, None
    tracer.__exit__(exception=exception, value=value, traceback=traceback)
    return


# Generated at 2022-06-10 21:34:29.018475
# Unit test for constructor of class Tracer
def test_Tracer():

    import os, tempfile
    from time import time

    @Tracer(watch=('foo',))
    def foo(a):
        return a + 1

    with tempfile.TemporaryDirectory() as tempdir:
        output_path = os.path.join(tempdir, 'test.log')
        with Tracer(output=output_path):
            foo(4)

        with open(output_path) as file:
            output = file.read()
    assert 'foo = 4' in output and 'Return value:.. 5' in output, output

    @Tracer(watch=('id(self)',))
    class A(object):
        def __init__(self):
            pass

        def foo(self, a):
            return a + 1

    a = A()
    a.foo(4)


# Generated at 2022-06-10 21:34:40.896789
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  tracer = Tracer(watch=["line_no", "source_line", "event", "timestamp", "thread_info"],depth=1,prefix='',overwrite=False,thread_info=False,custom_repr=(),max_variable_length=100,normalize=False,relative_time=False)
  # Assumed inputs

# Generated at 2022-06-10 21:35:03.928780
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Initializing input arguments:
    Tracer_instance = Tracer()
    calling_frame = inspect.currentframe()

    # Inspecting call of the decorated function:
    with Tracer_instance:
        pass

    assert calling_frame.f_trace is Tracer_instance.trace

# Generated at 2022-06-10 21:35:06.099785
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer() as tracer:
        pass

# Generated at 2022-06-10 21:35:10.552245
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    x = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    x.__exit__(exc_type=None, exc_value=None, exc_traceback=None)


# Generated at 2022-06-10 21:35:22.565021
# Unit test for constructor of class Tracer
def test_Tracer():
    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 100

        def __repr__(self):
            return 'abc'

        def __str__(self):
            return 'xyz'


    @pysnooper.snoop(watch='a')
    def foo(a, b, c):
        a = 100
        yield b
        yield a
        a = 200


    @pysnooper.snoop(watch='TestClass')
    def bar(a):
        a.a = 2
        a.b = 200
        raise Exception


    @pysnooper.snoop()
    def foo2():
        test_class = TestClass()
        bar(test_class)


# Generated at 2022-06-10 21:35:33.523847
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import time
    import traceback
    import functools
    import threading
    from _pysnooper import utils
    from _pysnooper import opcode
    from _pysnooper import pycompat
    from _pysnooper import thread_global
    from _pysnooper import inspect
    import datetime_module
    from _pysnooper import DISABLED
    from _pysnooper import BaseVariable
    from _pysnooper import Watch
    from _pysnooper import CommonVariable
    from _pysnooper import Exploding
    from _pysnooper import utils
    from _pysnooper import CommonVariable
    from _pysnooper import get_write_function
    from _pysnooper import get_path_and_source_from

# Generated at 2022-06-10 21:35:40.146988
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from types import FrameType
    from datetime import datetime

    class BackFrame(object):
        def __init__(self, f_code, f_lasti, f_lineno):
            self.f_code = f_code
            self.f_lasti = f_lasti
            self.f_lineno = f_lineno

    class SimpleTestFrame(object):
        def __init__(self, f_locals_dict, f_lineno=1, f_lasti=1,
                     f_code=None, f_back=None):
            self.f_locals = f_locals_dict
            self.f_lineno = f_lineno
            self.f_lasti = f_lasti
            self.f_back = f_back
            self.f_code = self.__code

# Generated at 2022-06-10 21:35:41.913658
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-10 21:35:43.804191
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pytest.fail('Not implemented')

# Generated at 2022-06-10 21:35:53.206356
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():

    # Tests for class Tracer

    import tempfile
    from pysnooper import snoop
    from .utils import strip_indent

    def assert_equal_with_tracing(a, b, variables=None):
        # For testability, only erase output if we're not running in a debugger.
        if not utils.is_in_debugger():
            print('Starting new test')
            sys.stdout.write('\x1b[2J\x1b[H')  # erase output

        with snoop():
            assert a == b

        if variables is not None:
            captured_vars = sys.stdout.getvalue().splitlines()
            stripped_vars = [line.split(' = ')[0] for line in captured_vars]
            assert stripped_vars == variables



# Generated at 2022-06-10 21:35:59.415424
# Unit test for function get_write_function
def test_get_write_function():
    import contextlib

    with contextlib.redirect_stdout(None):
        write = get_write_function(None, False)
        write('hello')
    with contextlib.redirect_stdout(None):
        write = get_write_function('hello.txt', False)
        write('hello')
    with contextlib.redirect_stdout(None):
        write = get_write_function('hello.txt', True)
        write('hello')
    with pycompat.open('hello.txt', 'rb') as f:
        assert f.read() == utils.shitcode('hello')



# Generated at 2022-06-10 21:36:21.007731
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS, verbose=False)


# Generated at 2022-06-10 21:36:31.207377
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import contextlib2

    @contextlib2.contextmanager
    def use_frame():
        def f():
            frame = sys._getframe(1)
            return get_path_and_source_from_frame(frame)
        yield f
        
    with use_frame() as f:
        a_tuple = f()
        assert a_tuple[0].endswith('debugger/local_repr.py')
        assert a_tuple[1]

    with use_frame() as f:
        import test_debugger

        a_tuple = f()
        assert a_tuple[0].endswith('debugger/test_debugger.py')
        assert a_tuple[1]

    try:
        raise Exception()
    except:
        with use_frame() as f:
            a

# Generated at 2022-06-10 21:36:41.341864
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  import pytest
  import __builtin__
  import pycompat
  import threading
  import sys
  
  import pysnooper
  from pysnooper.utils import BaseVariable, CommonVariable, Exploding
  import utils

  snoop = Tracer(
            output=None,
            watch=(),
            watch_explode=(),
            depth=1,
            prefix='',
            overwrite=False,
            thread_info=False,
            custom_repr=(),
            max_variable_length=100,
            normalize=False,
            relative_time=False
        )
  def f1():
    return 1
  
  def f2():
    return 1
  

# Generated at 2022-06-10 21:36:53.267298
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import pytest
    import itertools
    import os
    kwarg_combos = itertools.product([True, False],
                                     [True, False])
    for overwrite, should_exist in kwarg_combos:
        path = 'my_wat_file.txt'
        with open(path, 'w') as f:
            f.write('this is the start')
        file_writer = FileWriter(path, overwrite)
        file_writer.write('something')
        with open(path, 'r') as f:
            content = f.read()
        assert should_exist == os.path.exists(path)
        if should_exist:
            assert content == 'something'
        else:
            assert content == 'this is the start'



# Generated at 2022-06-10 21:37:03.015483
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    output = io.StringIO()

    def write(s):
        output.write(s + "\n")

    snooper = Tracer(output=write)

    @snooper
    def p():
        import time
        time.sleep(0.01)
        return 10

    p()

    value = output.getvalue()
    assert value.startswith("Source path:... ")
    assert value.endswith("Elapsed time: 0:00:00.010012",)

# Generated at 2022-06-10 21:37:09.551429
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    with pytest.raises(NotImplementedError):
        @pysnooper.snoop(watch=tuple())
        async def foo():
            pass
        foo(
        )
    with pytest.raises(NotImplementedError):
        @pysnooper.snoop(watch=tuple())
        async def foo():
            pass
        foo(
        )
        await foo()


# Generated at 2022-06-10 21:37:20.349426
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from unittest import mock
    from pysnooper import snoop
    from pysnooper import utils

    # Wrapper for a function
    func = mock.Mock()
    snooped_func = snoop(func)


# Generated at 2022-06-10 21:37:28.889103
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import pytest
    import os
    import importlib.util
    import example

    def get_frame(module_name, line_number):
        module_spec = importlib.util.find_spec(module_name)
        module = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(module)
        module_filename = module_spec.origin
        frame = sys._getframe()
        last_module_frame = None
        for i in range(line_number):
            frame = frame.f_back
            if frame.f_globals['__name__'] != module_name:
                last_module_frame = frame
        if last_module_frame is not None:
            frame = last_module_frame
        return frame


# Generated at 2022-06-10 21:37:32.349146
# Unit test for function get_write_function
def test_get_write_function():
    output = open('test.txt', 'w')
    get_write_function(output, False)
    os.remove('test.txt')


# Generated at 2022-06-10 21:37:33.568313
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import doctest
    return doctest.testmod(verbose=0)



# Generated at 2022-06-10 21:38:01.699596
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global write_log_func_to_test
    # This log function can be used to get printmsgs.
    write_log_func_to_test = []
    tracer = Tracer()
    tracer._write = write_log_func_to_test.append
    tracer.__enter__()
    expected = []
    assert write_log_func_to_test == expected
    tracer.__exit__(None, None, None)

# Generated at 2022-06-10 21:38:12.598339
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import __main__
    import types
    import dis
    import pickle
    import random
    import os
    import sys
    import itertools
    import inspect
    import re
    import io
    import tempfile
    import threading
    import logging
    import functools
    from io import StringIO
    from . import utils
    from . import thread_global
    from . import opcode
    from .utils import pycompat
    from . import sys_patch
    from . import datetime_module
    from . import DISABLED
    from .utils import get_write_function

    class CustomRegex(object):

        def __init__(self, regex_string):
            self.regex = re.compile(regex_string)

        def __eq__(self, other):
            return self.regex

# Generated at 2022-06-10 21:38:24.413929
# Unit test for function get_write_function
def test_get_write_function():
    output = None
    write = get_write_function(output, False)
    write('A')


    f = open('test','w')
    output = f
    write = get_write_function(output, False)
    write('B')
    f.close()
    with open('test','r') as f:
        assert f.read() == 'B'
    os.remove('test')

    output = 'test'
    write = get_write_function(output, True)
    write('C')
    with open('test','r') as f:
        assert f.read() == 'C'
    os.remove('test')

    import io
    output = io.StringIO()
    write = get_write_function(output, False)
    write('D')

# Generated at 2022-06-10 21:38:29.169037
# Unit test for function get_write_function
def test_get_write_function():
    f = open('testfile.txt', 'a')
    assert get_write_function(f, overwrite=False) == f.write
    assert get_write_function(f, overwrite=True) == f.write


# Generated at 2022-06-10 21:38:43.882919
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    
    # Python code
    code = \
    '''
    def foo():
        pass
    '''

    # Parse code into an AST
    top = ast.parse(code)

    # Compile AST
    codeobj = compile(top, '<stdin>', 'exec')

    # Extract code object from AST
    codeobj = top.body[0].body[0]

    # Create a snooper
    snooper = Tracer()

    # Extract globals from code object
    globals_ = codeobj.__code__.co_names

    # Create a frame object

# Generated at 2022-06-10 21:38:51.103632
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    snooper = pysnooper.Snooper(watch=['a'])
    snooper._write = mock_write
    snooper.__enter__()
    assert mock_write.write_buffer == ""
    snooper.__exit__(None, None, None)
    assert mock_write.write_buffer == ""
    assert "a" in snooper.watch
    assert snooper.depth == 1
    assert not snooper.thread_info
    assert not snooper.normalize


# Generated at 2022-06-10 21:38:55.054138
# Unit test for constructor of class Tracer
def test_Tracer():

    def f(a, b):
        return a+b

    Tracer()(f)
    Tracer(watch='deep', watch_explode='shallower')(f)
    Tracer()(f)


# Generated at 2022-06-10 21:38:56.867966
# Unit test for constructor of class Tracer
def test_Tracer():
    import doctest
    return doctest.testmod(optionflags=doctest.ELLIPSIS)



# Generated at 2022-06-10 21:39:07.611841
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import types
    import unittest


    class TracerTest(unittest.TestCase):
        def test_call_with_function_argument_should_wrap_it(self):
            traceable = lambda: None
            non_traceable = lambda: None
            class DummyTracer:
                def _wrap_function(self, function):
                    self.wrapped = function
                    return non_traceable
            dummy_tracer = DummyTracer()
            decorator = Tracer(dummy_tracer)
            wrapped_function = decorator(traceable)

            self.assertEqual(dummy_tracer.wrapped, traceable)
            self.assertNotEqual(wrapped_function, traceable)
            self.assertTrue(isinstance(wrapped_function, types.FunctionType))


# Generated at 2022-06-10 21:39:09.508175
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}



# Generated at 2022-06-10 21:39:31.867156
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    snooper = tracer.Tracer()
    # Fail
    with raises(NotImplementedError):
        snooper.__enter__()


# Generated at 2022-06-10 21:39:41.645551
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .types import TypedVariable
    def f(x):
        return x
    frame = f.__code__.create_execution_frame(
                                              f.__globals__,
                                              {'x': {'a': 'b'}},
                                              f.__code__, 4)
    frame.f_lineno = 4
    assert get_local_reprs(frame) == {
        'x': '{...}'
    }
    assert get_local_reprs(frame, watch=[TypedVariable('x', int)]) == {
        'x': '{...}',
        'x (int)': '{...}'
    }

# Generated at 2022-06-10 21:39:47.775678
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = sys._getframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == os.path.abspath(__file__). lower()
    assert source[frame.f_lineno - 1].strip() == 'test_get_path_and_source_from_frame()'
# Do unit test
test_get_path_and_source_from_frame()




# Generated at 2022-06-10 21:39:49.409269
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass # TODO: implement this test


# Generated at 2022-06-10 21:40:04.622139
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Return a new function that checks whether the function being decorated
    # is in a pysnooper trace, only then it executes the function. If not, it
    # returns None. Used only for tests.
    def create_tracer_test(function_under_test, test_function_name):
        def tracer_test(*args, **kwargs):
            if DISABLED:
                return
            tracer_test_frame = inspect.currentframe().f_back
            if tracer_test_frame in thread_global.tracer.target_frames:
                return function_under_test(*args, **kwargs)

        return tracer_test

    # Skip tests if we're not running in a pysnooper trace.

# Generated at 2022-06-10 21:40:16.754162
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        g()
    def g():
        h()
    def h():
        i()
    def i():
        j()
    def j():
        k()
    def k():
        l()
    def l():
        m()
    def m():
        n()
    def n():
        o()
    def o():
        p()
    def p():
        q()
    def q(x=123):
        r()
    def r(y=234):
        s()
    def s(z=345):
        t()
    def t(a=(1, 2, 3)):
        u()
    def u(b=[1, 2, 3]):
        v()
    def v(c=[1, 2, 3]):
        w()

# Generated at 2022-06-10 21:40:19.361954
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile

# Generated at 2022-06-10 21:40:21.510133
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        return locals()
    assert get_local_reprs(f()) == {'a': '1'}




# Generated at 2022-06-10 21:40:25.562364
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect

    def test_function():
        frame = inspect.currentframe()
        return get_path_and_source_from_frame(frame)

    test_script_file_name = utils. script_file_name
    assert test_function() == (
        test_script_file_name,
        open(test_script_file_name, 'rb').read().splitlines()
    )



# Generated at 2022-06-10 21:40:34.843095
# Unit test for function get_write_function
def test_get_write_function():
    shil=b'hell\xf8'
    write=get_write_function(None,False)
    write(shil)
    write=get_write_function(sys.stderr,False)
    write(shil)
    write=get_write_function(open('x','wb'),False)
    write(shil)
    write=get_write_function(lambda x: 2,False)
    write(shil)
    write=get_write_function(open('z','wb'),True)
    write(shil)


# Generated at 2022-06-10 21:41:18.549464
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__(): 
    # Instantiate mock objects
    # Instantiate mock objects
    mockTracer = Tracer(output=None, watch=(), watch_explode=(),
                        depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(),
                        max_variable_length=100, normalize=False, relative_time=False)

    # Call method __exit__
    mockTracer.__exit__(exc_type=None, exc_value=None,
                                    exc_traceback=None)

# Generated at 2022-06-10 21:41:26.164176
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import datetime; import threading; import inspect; import functools; import sys; import os
    from tests.utils import inject_additional_locals
    from pysnooper.utils import truncate
    def f(arg_1, arg_2, kwarg_1=None, *args, **kwargs):
        local_1 = 2
        local_2 = 3
        imported = datetime.datetime.now()
        return arg_1 + arg_2 + kwarg_1 + imported
    call_counter = 0
    class MockedWrite:
        @classmethod
        def mocked_write(cls, *args):
            nonlocal call_counter; call_counter += 1
        def __call__(self, *args, **kwargs):
            return self.mocked_write(*args, **kwargs)
       

# Generated at 2022-06-10 21:41:27.848419
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper.tests.tests import test_Tracer_snoop
    test_Tracer_snoop.Tracer.trace(test_Tracer_snoop.Tracer, None)


# Generated at 2022-06-10 21:41:28.351286
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass

# Generated at 2022-06-10 21:41:39.163030
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from hypothesis import given, assume
    import hypothesis.strategies as st
    import hypothesis.extra.pytz as pytz_st
    from hypothesis.extra.datetime import datetimes
    from hypothesis.extra.pytz import timezones
    from hypothesis.stateful import RuleBasedStateMachine, Bundle, rule
    from hypothesis.strategies import floats

    class SnoopStateMachine(RuleBasedStateMachine):
        depth_for_elapsed_time = Bundle('depth_for_elapsed_time')
        value = Bundle('value_truncating')
        value2 = Bundle('value_truncating')


# Generated at 2022-06-10 21:41:45.827889
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    source = '''
    def foo():
        a = 1
        b = 2
        c = a + b

    def bar():
        a = 10
        b = 20
        print(a, b)
    '''
    source_path = '/tmp/a.py'

    _snoop = snoop(output=None, watch=('a', 'b'))
    _snoop.target_codes.add(foo.__code__)
    frame = get_frame_from_source('foo', source, source_path)

    _snoop.trace(frame, 'call', None)
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    _snoop.trace(frame, 'line', None)

# Generated at 2022-06-10 21:41:57.886393
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    '''
    This function will test the Tracer.trace method.
    Args:
        None
    Return:
        None
    '''
    # create a tracer instance:
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    def func(a):
        a = a + 1
        return a

    # use inspect.trace to get the original trace function:
    original_trace = inspect.trace()[0].function
    # invoke the trace method of the tracer instance:
    tracer.trace(inspect.currentframe(), "call", None)
    # check whether the tracer.trace method

# Generated at 2022-06-10 21:42:08.883969
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # __exit__: Test if elapsed time is correctly calculated
    #   * Method used: __exit__()
    #   * Used when:  function call ends
    #   * Expected:   elapsed time is correctly printed
    #   * Input:      function call with start time given
    #   * Output:     elapsed time should be correctly printed
    #   * Test case:  Normal case with no exception
    start = datetime_module.datetime(2017, 9, 21, 15, 5, 0, 0)
    with Tracer() as tracer:
        tracer.start_times[None] = start
    assert tracer.start_times == {}
    assert mock_write.mock_calls == [
        mock.call("    Elapsed time: 00:00:00.000001\n"),
    ]


# Generated at 2022-06-10 21:42:18.628916
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import builtins
    from .utils import traceback_exception_asstring
    from .utils import variable_repr_for_tests, variable_repr_in_test_env
    with utils.mock_stdout() as mock:
        try:
            # Catch exception
            raise RuntimeError('Test Exception')
        except:
            self = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                          prefix='', overwrite=False, thread_info=False, custom_repr=(),
                          max_variable_length=100, normalize=False, relative_time=False)
            self.target_codes = set()
            self.target_frames = set()
            self.frame_to_local_reprs = {}
            self.start_times = {}
            self.thread_local

# Generated at 2022-06-10 21:42:26.822139
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global x
    x = 5
    global y
    y = 5
    with pysnooper.snoop(watch=('x', 'y',)), \
            pytest.raises(Exception):
        global x
        x = 7
        y = 7
        if x == y:
            raise Exception()
        else:
            pass
        y = 8
        if x == y:
            raise Exception()
        else:
            pass
    expected_result = '''\
Starting var:.. x = 5
Starting var:.. y = 5
    New var:....... x = 7
Call ended by exception
'''
    sys.stdout.seek(0)
    result = sys.stdout.read()
    assert result == expected_result
    sys.stdout.seek(0)
    sys.stdout.truncate