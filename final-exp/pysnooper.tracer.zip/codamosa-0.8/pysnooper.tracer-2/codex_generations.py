

# Generated at 2022-06-10 21:33:19.108043
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-10 21:33:29.554990
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # This is a method of class Tracer.
    # It is responsible for writing elapsed time when the program execution
    # is finished, and poping the call frame from frame_to_local_reprs,
    # start_times dict, and target_frames set.
    import datetime
    import time
    import io

    # Generate a mocked out datetime class.
    class MockDatetime(datetime.datetime):
        def __new__(cls, *args, **kwargs):
            return datetime.datetime.__new__(cls, *args, **kwargs)
        @classmethod
        def now(cls):
            return cls(2017, 2, 11, 2, 10, 59, 79634)
    # Override the original datetime module with the mocked out class.
    datetime_module.dat

# Generated at 2022-06-10 21:33:42.994998
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import imp
    import types
    import tempfile
    import sys

    def set_up_module_loader(module_name, module_source):
        # This is basically what imp.reload() does, but it doesn't work
        # in this case because the module to be reloaded doesn't exist in
        # the first place.

        module_dir = tempfile.mkdtemp()
        module_filename = os.path.join(module_dir, 'the_module.py')
        with open(module_filename, 'w') as module_file:
            module_file.write(module_source)

        sys.path.insert(0, module_dir)
        module = imp.load_source(module_name, module_filename)
        return types.ModuleType(module_name), module_filename


# Generated at 2022-06-10 21:33:53.740507
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # pylint: disable=unused-argument
    def exception_in_tracer_trace():
        with open('/path/to/nowhere') as f:
            pass
    def exception_in_tracer_trace_in_thread():
        thread = threading.Thread(target=exception_in_tracer_trace)
        thread.start()
        thread.join()
    def empty_function():
        pass
    def exception_in_empty_function():
        empty_function()
        raise Exception('foobar')
    def exception_in_exception_in_empty_function():
        exception_in_empty_function()
    def another_function():
        exception_in_exception_in_empty_function()
    def function_called_by_another_function():
        pass

# Generated at 2022-06-10 21:34:04.828394
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer._write = mock.Mock()
    calling_frame = mock.Mock(spec=inspect.FrameInfo)
    tracer.target_codes.add(calling_frame.f_code)
    tracer.target_frames.add(calling_frame)
    tracer.start_times[calling_frame] = datetime_module.datetime.now()
    tracer.thread_local.__dict__.setdefault('original_trace_functions', list())


# Generated at 2022-06-10 21:34:09.249154
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def my_function():
        pass

    assert get_path_and_source_from_frame(inspect.currentframe()) == \
                                        (__file__, [u"def test_get_path_and_source_from_frame():"])

test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:34:18.671673
# Unit test for constructor of class Tracer
def test_Tracer():
    print(Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False))
    try:
        print(Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=((1, 1),),
                 max_variable_length=100, normalize=False, relative_time=False))
    except:
        pass


# Generated at 2022-06-10 21:34:30.029660
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    a = Tracer()
    frame1 = inspect.currentframe()
    frame2 = inspect.currentframe()
    frame1.f_lineno=10
    frame2.f_lineno=20
    frame1.f_code.co_filename="file1"
    frame2.f_code.co_filename="file2"
    frame1.f_code.co_code="test"
    frame2.f_code.co_code="trace"

    a.target_frames.update([frame1,frame2])
    a.target_codes.update([frame1.f_code,frame2.f_code])
    assert a._is_internal_frame(frame1)==False
    assert a._is_internal_frame(frame2)==False
    assert a.trace(frame1, "call", None)==a

# Generated at 2022-06-10 21:34:42.242679
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    if True:
        class X(object):
            pass
        x = X()
        x.__call__ = Tracer()
    if True:
        class X(object):
            pass
        x = X()
        x.__call__ = Tracer()
    if True:
        class X(object):
            pass
        x = X()
        x.__call__ = Tracer()
    if True:
        class X(object):
            pass
        x = X()
        x.__call__ = Tracer()
    if True:
        class X(object):
            pass
        x = X()
        x.__call__ = Tracer()
    if True:
        class X(object):
            pass
        x = X()
        x.__call__ = Tracer()


# Generated at 2022-06-10 21:34:48.711577
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo(a):
        b = a * 2 + 3
        c = b - 4
        d = b + c
        return d
    frame = inspect.currentframe()
    while frame.f_code.co_name != 'foo':
        frame = frame.f_back
    assert get_local_reprs(frame) == {'a': '18', 'c': '47', 'b': '37', 'd': '84'}



# Generated at 2022-06-10 21:35:23.679042
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import os
    import pysnooper
    import sys
    import threading
    import traceback
    import unittest
    try:
        import unittest.mock as mock
    except ImportError:
        import mock


    class TestCase(unittest.TestCase):
        snooper = pysnooper.Snooper
        tracer_cls = pysnooper.tracer.tracer_instance.Tracer

        @mock.patch('pysnooper.tracer.tracer_instance.DISABLED', False)
        def test_can_be_called_on_functions(self):

            @self.snooper()
            def some_function():
                pass


# Generated at 2022-06-10 21:35:34.434292
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import pycompat
    import traceback
    import inspect
    import functools
    import threading
    from . import utils
    from .utils import get_shortish_repr
    from .utils import get_path_and_source_from_frame
    from .utils import BaseVariable
    from .utils import CommonVariable
    from .utils import Exploding
    from .utils import raise_if_invalid_regex
    from .utils import get_local_reprs
    # from .utils import ObjectProxy
    if pycompat.PY2:
        import __builtin__ as builtins
    else:
        import builtins
    reload(builtins)
    import dis
    reload(dis)
    dis.opmap  # pylint: disable=pointless-statement
    reload(dis)


# Generated at 2022-06-10 21:35:38.027573
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import io
    output = io.StringIO()
    with pysnooper.snoop(output=output):
        assert 1 == 1
    assert 'Return value:.. 1' in output.getvalue()

# Generated at 2022-06-10 21:35:54.054989
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    print('In unit test __exit__ of class Tracer')
    with open('./tracer.log', 'w') as log_file:
        with Tracer(output=log_file, watch=('x',)) as snoop:
            x = 1
            log_file.seek(0)
            log_lines = log_file.readlines()
            assert len(log_lines) == 4
            assert log_lines[0] == 'Source path:... ./tracer.py\n'
            assert log_lines[1] == '    Starting var:.. x = 1\n'
            assert log_lines[2] == '    Elapsed time: 0:00:00.000001\n'
            assert log_lines[3] == '    Return value:.. 1\n'

# Generated at 2022-06-10 21:36:00.900924
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    def foo():
        print("Hello")
    def bar():
        print("World")
    if __name__ == "__main__":
        with pysnooper.snoop():
            foo()
        with pysnooper.snoop():
            bar()
if __name__ == "__main__":
    test_Tracer___exit__()

# Generated at 2022-06-10 21:36:04.876327
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # print '-' * 40
    # tracer = Tracer()
    # tracer.set_depth(3)
    # tracer.set_target_code(set([target_code]))
    # tracer.set_target_frame(set([target_frame]))
    # tracer.set_frame_to_local_reprs(frame_to_local_reprs)
    # tracer.trace(target_frame, 'call', None)
    # tracer.trace(target_frame, 'return', None)
    # tracer.trace(target_frame, 'exception', ('TypeError', None, None))
    # print "method trace is correct!"
    pass

# Generated at 2022-06-10 21:36:18.050922
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import functools
    import inspect

    import pysnooper

    from . import utils

    from .utils import pycompat, threading

    from .utils.code_info import get_path_and_source_from_frame

    from .utils.frame_info import get_local_reprs

    from .utils.variable import CommonVariable, BaseVariable

    from .utils.magic_numbers import opcode

    from .utils.scope import Scope

    from .utils.wrappers import TracerWrapper

    from .utils.wrappers import tracer_wrapper

    from .utils.wrappers import DISABLED

    from .utils.wrappers import thread_global
    assert tracer_wrapper.Tracer.__qualname__ == 'Tracer'


# Generated at 2022-06-10 21:36:19.563066
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-10 21:36:27.205780
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def f1():
        return get_path_and_source_from_frame(inspect.currentframe())[1][0]

    def f2():
        return get_path_and_source_from_frame(inspect.currentframe())[1][0]

    assert f1() == '        return get_path_and_source_from_frame(inspect.currentframe())[1][0]'
    assert f2() == '        return get_path_and_source_from_frame(inspect.currentframe())[1][0]'



# Generated at 2022-06-10 21:36:31.207333
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def ff():
        return get_path_and_source_from_frame(
            inspect.currentframe()
        )
    assert ff() == (os.path.realpath(__file__),
                    UnavailableSource())
    assert ff() == (os.path.realpath(__file__),
                    UnavailableSource())



# Generated at 2022-06-10 21:37:01.056098
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper

    @pysnooper.snoop()
    def test1():
        # line 1
        # line 2
        pass

    # unit test for this method
    assert isinstance(test1, types.FunctionType)



# Generated at 2022-06-10 21:37:05.185056
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    def test():
        with Tracer():
            print('hello world')

    sys._getframe().f_code.co_filename = 'test_filename'
    test()
    assert sys._getframe().f_code.co_filename == 'test_filename'



# Generated at 2022-06-10 21:37:16.594133
# Unit test for constructor of class Tracer
def test_Tracer():
    global DISABLED
    DISABLED = True
    with pytest.raises(RuntimeError) as e:
        tracer = Tracer(watch=('a', 'b'))
    assert e.value.args[0] == "Cannot use multiple watch and watch_explode at the same time."
    with pytest.raises(RuntimeError) as e:
        tracer = Tracer(watch=('a',), watch_explode=('c', 'd'))
    assert e.value.args[0] == "Cannot use multiple watch and watch_explode at the same time."
    with pytest.raises(RuntimeError) as e:
        tracer = Tracer(watch_explode=('b', 'c'))

# Generated at 2022-06-10 21:37:23.817550
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import contextlib
    try:
        with open('test_get_path_and_source_from_frame.txt', 'wb') as f:
            f.write(b'this is a test')
        assert get_path_and_source_from_frame(
            inspect.currentframe()
        ) == (
            'test_get_path_and_source_from_frame.txt',
            [u'this is a test']
        )
    finally:
        os.remove('test_get_path_and_source_from_frame.txt')



# Generated at 2022-06-10 21:37:33.152474
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    snooper = Tracer(watch = ('bar', ), depth = 1)
    snooper.watch = [CommonVariable('bar')]
    foo = 23
    bar = 42

    def func(foo, bar, qux):
        return foo
    frame = inspect.currentframe()
    event = 'call'
    arg = [foo, bar]
    a = snooper.trace(frame, event, arg)
    assert a == snooper.trace


# Generated at 2022-06-10 21:37:38.665036
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    output = io.StringIO()
    # Normal flow, no exceptions
    tracer = Tracer(output=output,
                    watch=('x', 'y', ),
                    watch_explode=('z', ),
                    depth=3,
                    prefix='XXX',
                    overwrite=True,
                    thread_info=True,
                    custom_repr=((type(foo), utils.repr_bar), ),
                    max_variable_length=200,
                    normalize=False,
                    relative_time=False)
    x = 1
    tracer.trace(
        frame=inspect.currentframe(),
        event='call',
        arg=None
    )
    y = 2
    tracer.trace(
        frame=inspect.currentframe(),
        event='line',
        arg=None
    )
    z = 3

# Generated at 2022-06-10 21:37:40.375688
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(NotImplementedError):
        Tracer().__exit__()


# Generated at 2022-06-10 21:37:50.276063
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .utils import get_shortish_repr, truncate
    from .watch import CommonVariable, Exploding, BaseVariable
    from .utils import ensure_tuple
    import opcode
    import inspect
    import functools
    import datetime
    from .utils import get_path_and_source_from_frame
    import threading
    #from .watch import CommonVariable, Exploding, BaseVariable
    #from .utils import ensure_tuple

    def test_get_path_and_source_from_frame():
        def get_test_frame():
            def f():
                frame = inspect.currentframe().f_back
                frame = frame.f_back
                return frame
            return f()
        frame = get_test_frame()
        path, source = get_path_and_source_from_frame(frame)


# Generated at 2022-06-10 21:38:00.505450
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import time
    import datetime
    from cStringIO import StringIO, BytesIO
    from contextlib import contextmanager
    from pysnooper.utils import ensure_string, ensure_bytes

    def ensure_string_io(output):
        if isinstance(output, pycompat.string_types):
            return StringIO()
        else:
            return BytesIO()

    @contextmanager
    def assert_snoop(snooper_kwargs, expected_output, function, *args, **kwargs):
        output = ensure_string_io(expected_output)
        expected_output = ensure_string(expected_output)
        with pysnooper.snoop(output=output, **snooper_kwargs):
            function(*args, **kwargs)
        assert output.getvalue() == expected_output



# Generated at 2022-06-10 21:38:07.003685
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer._write = unittest.mock.Mock()
    frame = inspect.currentframe()
    from itertools import count
    tracer.trace(frame, 'call', count())
    tracer.trace(frame, 'return', count())
    tracer.trace(frame, 'exception', (Exception, Exception('hi'), None))
