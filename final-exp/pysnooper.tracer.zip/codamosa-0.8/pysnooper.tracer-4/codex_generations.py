

# Generated at 2022-06-10 21:33:29.932057
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from unittest.mock import MagicMock
    from pysnooper import snoop
    from datetime import datetime

    def get_path_and_source_from_frame(frame):
        source_path = 'foo.py'
        source = ['if a:', '    print(a)']
        return source_path, source

    def test_end_exception():
        # function call ends due to an exception
        #test_frame = MagicMock()
        test_frame = threading.local()
        test_frame.f_code = threading.local()
        test_frame.f_code.co_code = [2]
        test_frame.f_lasti = 0
        #test_frame.f_code.co_lines = [1, 2]

# Generated at 2022-06-10 21:33:43.385684
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    '''
    Test function to perform unit testing on method trace of Tracer class
    '''

# Generated at 2022-06-10 21:33:47.612145
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():

    tracer = Tracer()
    tracer.write = mock.MagicMock()
    tracer.__enter__()

    assert tracer.write.call_count == 1
    tracer.__exit__()

    assert tracer.write.call_count == 2

# Generated at 2022-06-10 21:33:50.069218
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .test_utils import get_python_file_path

# Generated at 2022-06-10 21:34:01.427069
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer=Tracer()
    tracer.watch=["var1", "var2"]
    tracer.depth=1
    tracer.write=print
    tracer.thread_info=False
    tracer.custom_repr=[]
    tracer.max_variable_length=100
    tracer.normalize=False
    tracer.relative_time=False
    tracer.thread_info_padding=0
    tracer.prefix=" "
    tracer.target_codes=set()
    tracer.target_frames=set()
    tracer.thread_local=threading.local()
    tracer.last_source_path="C:\\Users\\paulg\\Desktop\\pysnooper-master\\example.py"
    tracer.start_times={}
    frame0=inspect.currentframe

# Generated at 2022-06-10 21:34:10.972365
# Unit test for function get_write_function
def test_get_write_function():
    import inspect

    def test_none():
        write = get_write_function(output=None, overwrite=False)
        assert inspect.isfunction(write)
        write(u'Testing writing to stderr')

    def test_file_path():
        import tempfile
        import os
        full_path = tempfile.mktemp('.txt')
        write = get_write_function(output=full_path, overwrite=False)
        assert inspect.isfunction(write)
        write(u'Testing writing to path')
        with open(full_path, encoding='utf8') as f:
            assert f.read() == u'Testing writing to path'
        os.remove(full_path)

    def test_writable_object():
        class Writable(object):
            def write(self, s):
                self.s

# Generated at 2022-06-10 21:34:22.928649
# Unit test for function get_write_function
def test_get_write_function():
    import io

    f = io.StringIO()
    write = get_write_function(f, False)
    write('hello')
    assert f.getvalue() == 'hello'

    f = io.StringIO()
    write = get_write_function(f.write, False)
    write('hello')
    assert f.getvalue() == 'hello'

    def write(s):
        raise Exception('this is a test')
    write = get_write_function(write, False)
    with utils.assert_raises(Exception) as result:
        write('hello')
    assert result.exception.args[0] == 'this is a test'

    f = io.StringIO()
    with utils.assert_raises(Exception) as result:
        get_write_function(f, True)

# Generated at 2022-06-10 21:34:28.681108
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def test_function():
        return get_path_and_source_from_frame(inspect.currentframe())

    assert (re.escape(os.path.basename(__file__)) in test_function()[0]) and \
           ('get_path_and_source_from_frame' in
            ''.join(test_function()[1]))



# Generated at 2022-06-10 21:34:40.289929
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    dirpath = tempfile.mkdtemp()
    try:
        file_name = os.path.join(dirpath, 'temp.py')
        file_name_bytes = os.fsencode(file_name)
        with open(file_name_bytes, 'wb') as f:
            f.write(b'\xc3\xa9')
        with open(file_name_bytes, 'rb') as f:
            (result_file_name, result_source) = \
                get_path_and_source_from_frame(inspect.currentframe())
            assert result_file_name == file_name
            assert result_source == [u'é']
    finally:
        import shutil
        shutil.rmtree(dirpath)
test_get_path_and_source_from

# Generated at 2022-06-10 21:34:51.169133
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import sys
    import pycompat

    from . import utils

    if pycompat.OS_WINDOWS:
        output_name = '__temp.txt'
    else:
        output_name = '/tmp/__temp.txt'
    max_attempts = 4
    for attempt in range(max_attempts):
        if not os.path.exists(output_name):
            break
    else:
        raise Exception(
                "Tried %s times to create `%s` but couldn't because the file "
                "already exists. Please delete this file." % (max_attempts,
                                                               output_name))
    sys.stderr.write("Please delete `%s` when done.\n" % output_name)

# Generated at 2022-06-10 21:35:29.189247
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print('Test __call__...', end='')
    ### Implement your test here ###
    # raise NotImplementedError
    print('Done!')



# Generated at 2022-06-10 21:35:36.970081
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pprint
    import threading
    import time
    import pysnooper
    # case 1
    class Foo:
        @pysnooper.snoop()
        def method(self):
            return 1
        
        @classmethod
        @pysnooper.snoop()
        def class_method(cls):
            return 10
    
    print('case 1:')
    print('Foo.__dict__:')
    pprint.pprint(Foo.__dict__)
    tmp = Foo()
    tmp.method()
    print('')
    tmp.class_method()
    print('')
    
    # case 2

# Generated at 2022-06-10 21:35:53.230935
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from . import pysnooper
    from .pysnooper import snoop
    def function_or_class(a, b, c, d=4, e=5, *args, **kwargs):
        1 / 0
    class A:
        pass
    with captured_output(stderr) as (out, err):
        with snoop(watch=()):
            function_or_class(1, 2, 3, 6, 7, 8, foo='bar', spam='eggs')

# Generated at 2022-06-10 21:35:55.239215
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    simple_test_of_instance_method(Tracer(), Tracer.__enter__, "self")


# Generated at 2022-06-10 21:36:07.549244
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.target_codes = [
        {'co_filename': 'file1', 'co_name': 'method1'},
        {'co_filename': 'file2', 'co_name': 'method2'}
    ]
    tracer.depth = 1
    tracer.thread_local = threading.local()
    tracer.thread_local.original_trace_functions = []
    tracer.frame_to_local_reprs = {
        {'f_back': None, 'f_code': {'co_filename': 'file2', 'co_name': 'method2'}}: {},
        {'f_back': None, 'f_code': {'co_filename': 'file1', 'co_name': 'method1'}}: {}
    }
   

# Generated at 2022-06-10 21:36:11.927319
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    output = io.StringIO()
    with Tracer(output=output, watch=['a'], watch_explode=('b',)):
        a, b = 1, [1, 2]
        c = 1
        b.append(3)
    print(output.getvalue())

# if __name__ == '__main__':
#     test_Tracer()

# Generated at 2022-06-10 21:36:13.984084
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo():
        print(1)
        print(2)

foo = Tracer()(foo)
foo()

# Generated at 2022-06-10 21:36:16.952984
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def f():
        raise Exception("I am an exception!")

    with Tracer() as tracer:
        try:
            f()
        except Exception:
            pass
    assert len(tracer.buffer) == 3


# Generated at 2022-06-10 21:36:20.284489
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # pysnooper._snoop_pprint.__exit__ = test_Tracer___exit__
    __tracebackhide__ = True
    raise NotImplementedError

# Generated at 2022-06-10 21:36:30.692061
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def function1(a):
        return a
    def function2(a):
        b = a
        c = b
        d = c
        try:
            print(d)
        except:
            raise
        return d
    def test_is_internal_frame():
        tracer = Tracer()
        curr_frame = inspect.currentframe()
        if tracer._is_internal_frame(curr_frame):
            raise Exception("should not be an internal frame")
        curr_frame.f_code.co_filename = tracer.__enter__.__code__.co_filename
        if not tracer._is_internal_frame(curr_frame):
            raise Exception("should be an internal frame")
    def test_watch():
        tracer = Tracer(watch=("a", "b"))
        frame

# Generated at 2022-06-10 21:37:23.341769
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    s = StringIO()
    m = Tracer(s)
    m.write = lambda s: s
    m.write_error = lambda s: s
    m.start_times = {'frame':datetime_module.datetime.now()}
    m.thread_info = False
    m.__exit__('exc_typ', 'exc_val', 'exc_tb')
    assert m.thread_local.original_trace_functions == []
    assert m.frame_to_local_reprs == {}
    assert m.start_times == {}

# Generated at 2022-06-10 21:37:37.560991
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
  def test_case_0():
    tracer = Tracer(
      output=None,
      watch=(),
      watch_explode=(),
      depth=1,
      prefix='',
      overwrite=False,
      thread_info=False,
      custom_repr=(),
      max_variable_length=100,
      normalize=False,
      relative_time=False,
    )
    exc_type = Exception
    exc_value = None
    exc_traceback = None
    expected = None
    actual = tracer.__exit__(exc_type, exc_value, exc_traceback)
    try:
      pass
    except:
      assert False
    else:
      assert True

  for t in [test_case_0]:
    t()


# Generated at 2022-06-10 21:37:40.905652
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(
        get_path_and_source_from_frame.__code__
    ) == (__file__, open(__file__, 'rb').read().splitlines())



# Generated at 2022-06-10 21:37:50.596888
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    calling_frame = inspect.currentframe()
    src_path = tracer.last_source_path = "some/path/of/source.py"
    tracer.target_codes.add(calling_frame.f_code)
    tracer.target_frames.add(calling_frame)
    with ExitStack() as stack:
        stack.enter_context(tracer)
        stack.callback(tracer.__exit__)
        thread_global.__dict__.setdefault('depth', -1)
        thread_global.depth += 1
        indent = ' ' * 4 * thread_global.depth

# Generated at 2022-06-10 21:37:57.759462
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def myfunc(n):
        print(n)
        if n == 0:
            return
        myfunc(n - 1)

    with io.StringIO() as buf, redirect_stdout(buf):
        tracer = Tracer(output=buf)
        myfunc(5)
    output = buf.getvalue()
    assert output.count('Call event:') == 6
    assert output.count('Elapsed time:') == 6
    assert output.count('Return value:') == 6
    assert output.count('Return event:') == 5
    assert 'n = 5' in output


# Generated at 2022-06-10 21:38:06.949241
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Resetting static members to their initial values, since this test is not run in isolation
    Tracer.instance = None
    Tracer.instance_lock = threading.Lock()
    Tracer.instance_lock.locked = False
    global DISABLED
    DISABLED = False
    try:
        _test_Tracer___enter__()
    finally:
        Tracer.instance = None
        Tracer.instance_lock = threading.Lock()
        Tracer.instance_lock.locked = False
        DISABLED = False

# Generated at 2022-06-10 21:38:10.615567
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    func = _function_object
    expected = _function_object
    actual = _function_object.__enter__()
    assert expected == actual


# Generated at 2022-06-10 21:38:23.802125
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import sys
    import os
    from .utils import DEFAULT_ENCODING
    from .variables import CommonVariable
    from . import sys_tools
    import pycompat
    try:
        from contextlib import redirect_stdout
    except ImportError:
        from .utils import redirect_stdout
    from .utils import get_time_stamp

    #capture stdout, there are tests that use `print`.

# Generated at 2022-06-10 21:38:27.514609
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        import sys
        return sys._getframe(0)
    assert get_path_and_source_from_frame(foo()) == \
                                            (__file__,
                                             open(__file__, 'r',
                                                  encoding='utf-8').readlines())



# Generated at 2022-06-10 21:38:39.423457
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import nose
    import nose.tools
    import pysnooper
    import threading
    import traceback
    def foo():
        raise ValueError()

    with pysnooper.snoop():
        try:
            foo()
        except ValueError:
            lines = traceback.format_exc().splitlines()
        assert len(lines) == 4, lines
        assert lines[1].strip() == '    raise ValueError()', lines[1]
        assert lines[2].strip() == 'ValueError()', lines[2]

if __name__ == '__main__':
    test_Tracer_trace()