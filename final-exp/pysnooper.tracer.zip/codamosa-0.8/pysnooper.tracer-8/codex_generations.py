

# Generated at 2022-06-10 21:33:45.318813
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer("output=None", "watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False")

# Generated at 2022-06-10 21:33:49.362824
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def _test():
        x = 2
        y = 3
        assert _test_get_path_and_source_from_frame() == (
            'test_get_path_and_source_from_frame', ['x = 2', 'y = 3'])
    _test()


# Generated at 2022-06-10 21:33:51.183527
# Unit test for constructor of class Tracer
def test_Tracer():
    from pysnooper import Tracer
    tracer = Tracer(output=None, watch=[])

# Unit tests for constructor and decorator function of class Snooper

# Generated at 2022-06-10 21:34:02.412288
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test Tracer without arguments
    t = Tracer()
    assert t.write == sys.stderr.write, "Default `write` function is not sys.stderr.write"
    assert t.watch == (), "Default `watch` value is not empty."
    assert t.watch_explode == (), "Default `watch_explode` value is not empty."
    assert t.depth == 1, "Default `depth` is not 1."
    assert t.prefix == '', "Default `prefix` is not empty string."
    assert t.custom_repr == (), "Default `custom_repr` is not an empty tuple."
    assert t.max_variable_length == 100, "Default `max_variable_length` is not 100."
    assert t.normalize == False, "Default `normalize` is not False."
    assert t

# Generated at 2022-06-10 21:34:07.493902
# Unit test for constructor of class Tracer
def test_Tracer():
    from .utils import run_as_main

    @snoop()
    def foo():
        return bar(123)

    @snoop()
    def bar(x):
        return [x + i for i in range(10)]

    if __name__ == "__main__":
        run_as_main(foo)


snoop = Tracer

# Generated at 2022-06-10 21:34:09.844123
# Unit test for function get_write_function
def test_get_write_function():
    def my_write_function(s):
        print('my_write_function was called with', s)
    get_write_function(my_write_function, False)('hello')
    get_write_function(None, False)('world')
test_get_write_function()



# Generated at 2022-06-10 21:34:21.584853
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import io
    import sys
    import functools
    import datetime
    import threading
    import itertools
    import opcode
    import types
    import traceback
    import functools
    import inspect
    import contextlib
    import utils
    import pycompat
    import thread_global
    import get_path_and_source_from_frame
    import utils
    import sys
    import pysnooper.utils
    import collections

    import pytest
    import logging

    global DISABLED
    DISABLED = True

    @pysnooper.snoop()
    def foo():
        pass

    # Just check that it doesn't crash
    foo()


    DISABLED = False


    # FIXTURE: Output


    #     def test_output__not_specified():


# Generated at 2022-06-10 21:34:29.109939
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import __builtin__
    import sys
    import pysnooper
    import types
    tracer = pysnooper.snoop(watch=('foo', 'self'))
    def foo():
        foo = 7
        bar = 8
        bar = 'e'
        return 1
    decorated_function = tracer(foo)
    assert isinstance(decorated_function, types.FunctionType)
    assert decorated_function is not foo
    assert decorated_function() == 1


# Generated at 2022-06-10 21:34:35.067638
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    test_obj = Tracer(watch=[], watch_explode=[], depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    if hasattr(test_obj, "trace"):
        assert callable(getattr(test_obj, "trace"))



# Generated at 2022-06-10 21:34:46.889974
# Unit test for constructor of class Tracer
def test_Tracer():
    from pysnooper import snoop
    # default param
    snoop(prefix="")
    # prefix
    snoop(prefix="prefix")
    # output
    snoop(output="output")
    # watch
    snoop(watch=["list", "dict"])
    snoop(watch="string")
    # watch_explode
    snoop(watch_explode="string")
    # depth
    snoop(depth=1)
    # overwrite
    snoop(overwrite=False)
    snoop(overwrite=True)
    snoop(overwrite=None)
    # thread_info
    snoop(thread_info=False)
    snoop(thread_info=True)
    # custom_repr
    snoop(custom_repr=())

# Generated at 2022-06-10 21:35:23.228262
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    class MyLoader(object):
        def get_source(self, module_name):
            if module_name == 'module_name':
                return 'a = 1'
            else:
                raise ImportError()
    frame = sys._getframe()
    globs = frame.f_globals
    globs['__name__'] = 'module_name'
    globs['__loader__'] = MyLoader()
    assert get_path_and_source_from_frame(frame) == (
        frame.f_code.co_filename,
        ['a = 1']
    )
test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:35:26.361931
# Unit test for constructor of class Tracer
def test_Tracer():
    # Basic smoke test of Tracer.
    @pysnooper.snoop()
    def foo():
        pass

    foo()


# Generated at 2022-06-10 21:35:35.925195
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    start_time = datetime_module.datetime.now()
    line_no = 54
    source_path, source = get_path_and_source_from_frame(frame)
    source_line = source[line_no - 1]
    timestamp = pycompat.time_isoformat(datetime_module.datetime.now().time(),
                                        timespec='microseconds')
    thread_info = ""
    indent = ' ' * 4 * thread_global.depth
    newish_string = 'Starting var:.. '
    name = "foo"
    value_repr = "bar"
    source_path = source_path if not normalize else os.path.basename(source_path)
    thread_info = "1-MainThread "

# Generated at 2022-06-10 21:35:49.236552
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    test_globals = {'__name__': 'test', '__file__': 'test.py'}
    test_globals['__loader__'] = __loader__
    test_source = inspect.getsource(test_get_path_and_source_from_frame)
    test_code = test_globals['test_get_path_and_source_from_frame'].__code__
    test_frame = sys._getframe()
    test_frame.f_globals = test_globals
    test_frame.f_code = test_code
    source, path = get_path_and_source_from_frame(test_frame)
    assert source[0][:8] == 'def test_'
    assert path == 'test.py'
test_get_path_and_source_from

# Generated at 2022-06-10 21:36:00.480420
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class TestTracer(unittest.TestCase):
        # Test if snoop returns the same function when there are no assigned classes.
        def test_Tracer_without_Class(self):
            with pysnooper.snoop() as snoop:
                snoop.write('test')
            self.assertEqual(snoop.__enter__(), None)
            self.assertEqual(snoop.__exit__(None, None, None), None)

        # Test that the return value of __enter__ is None.
        def test_enter_is_not_None(self):
            with pysnooper.snoop():
                pass
            the_enter = pysnooper.snoop().__enter__()
            self.assertEqual(the_enter, None)

        # Test that the return value of

# Generated at 2022-06-10 21:36:15.686530
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import test_get_path_and_source_from_frame_cute_module
    import os
    path_to_test_file = os.path.dirname(__file__)
    path_to_test_file = os.path.join(path_to_test_file, 'test_utils.py')
    if not os.path.exists(path_to_test_file):
        path_to_test_file = os.path.join(path_to_test_file, 'test_utils.py')
    assert os.path.exists(path_to_test_file)

# Generated at 2022-06-10 21:36:17.486308
# Unit test for function get_write_function
def test_get_write_function():
    sys.stderr = None
    get_write_function(None, False)



# Generated at 2022-06-10 21:36:28.503715
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Setup
    output = None
    watch = ('a', )
    watch_explode = ('self',)
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ((),)
    max_variable_length = 100
    normalize = False
    relative_time = False
    tracer = Tracer(output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr, max_variable_length, normalize, relative_time)
    tracer._write = lambda *args, **kwargs: None
    function_or_class = lambda : 1
    # Exercise
    actual = tracer(function_or_class)
    # Verify
    assert callable(actual)
    callable_obj = actual
    # Exercise
    actual = call

# Generated at 2022-06-10 21:36:38.814645
# Unit test for function get_write_function
def test_get_write_function():
    def write_to_stderr(s):
        stderr = sys.stderr
        stderr.write(s)

    write = get_write_function(write_to_stderr, overwrite=None)
    write('hello!')
    assert write == write_to_stderr
    write = get_write_function('stderr', overwrite=None)
    assert isinstance(write, FileWriter)
    import io
    output_file = io.StringIO()
    write = get_write_function(output_file, overwrite=None)
    write('hello!')
    assert output_file.getvalue() == 'hello!'
    import time

    class StupidStream(utils.WritableStream):
        def write(self, s):
            time.sleep(.1)

    stupid_stream = StupidStream

# Generated at 2022-06-10 21:36:51.139793
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = True
    tracer = Tracer()
    assert tracer._is_internal_frame(inspect.currentframe().f_back) == True
    DISABLED = False
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local.__dict__ == {'original_trace_functions': []}
    assert tracer.custom_repr == ()
    assert tracer.last_

# Generated at 2022-06-10 21:37:23.255350
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        frame = inspect.currentframe()
        return get_path_and_source_from_frame(frame)
    assert f()[0].endswith('tests/test_data/weather_settings.py')
    assert f()[1] == [
        'from garlicsim.general_misc.nifty_collections import OrderedDict',
        'import datetime',
        '',
        'settings = OrderedDict(',
        '    seed=datetime.datetime(2010, 1, 1, 0, 0)',
        ')',
        ''
    ]
test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:37:32.350356
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Create instance of class Tracer
    tracer = Tracer()
    # Create mock object of class Tracer
    mockTracer = mock.Mock(spec=Tracer)
    # Invoke method __exit__ of class Tracer
    tracer.__exit__(mockTracer.exc_type, mockTracer.exc_value, mockTracer.exc_traceback )


# Generated at 2022-06-10 21:37:33.561031
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import doctest
    doctest.testmod(verbose=True)



# Generated at 2022-06-10 21:37:44.299618
# Unit test for method __enter__ of class Tracer

# Generated at 2022-06-10 21:37:47.980876
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer("test/test_output/test_Tracer___enter__.output")
    tracer.__enter__()
    tracer.set_thread_info_padding("test")
    assert tracer.thread_info_padding == 4

# Generated at 2022-06-10 21:37:53.971003
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    path, source = result
    assert path
    assert source
    assert result == get_path_and_source_from_frame(frame)
    assert result == source_and_path_cache[(__name__, path)]
    assert source[inspect.currentframe().f_lineno - 1].strip() == 'def test_get_path_and_source_from_frame():'

test_get_path_and_source_from_frame()
del test_get_path_and_source_from_frame



# Generated at 2022-06-10 21:37:57.545659
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import types
    with pytest.raises(NotImplementedError):
        Tracer().trace(types.FrameType(None, None, None, None, None, None), 'call', None)


# Generated at 2022-06-10 21:38:08.538049
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test the case when DISABLED is True
    assert Tracer()(None) is None
    # Test the case when DISABLED is False
    # Test the case when function_or_class is a function
    # Test the case when function_or_class is a class
    # Test the case when function_or_class is a generator function
    def gen_func():
        yield 1
    gen_func_wrapped = Tracer()(gen_func)
    assert gen_func_wrapped() is not None
    # Test the case when function_or_class is an async generator function
    # Test the case when function_or_class is a coroutine function


# Generated at 2022-06-10 21:38:15.553366
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    t = Tracer()
    calling_frame = inspect.currentframe()
    assert t._is_internal_frame(calling_frame) == True
    calling_frame = calling_frame.f_back.f_back
    assert t._is_internal_frame(calling_frame) == False
test_Tracer___exit__()

# Generated at 2022-06-10 21:38:27.198896
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(a, b, c=3, d=4):
        e = 5
        g = f

        def strange_repr(obj):
            if type(obj) is str:
                return str.lower(obj)

        class CustomRepr(object):
            def __repr__(self):
                return 'this is a custom repr'

        custom_repr = (
            (CustomRepr, lambda custom_repr: 'custom repr'),
            (strange_repr, lambda obj: str(obj).upper()),
        )

        class Variable(BaseVariable):
            name = 'e'

            def __getitem__(self, frame):
                return utils.get_shortish_repr(frame.f_locals['e'] * 2,
                                               custom_repr)


# Generated at 2022-06-10 21:39:02.922462
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from unittest.mock import MagicMock
    import datetime
    import random

    class MockCheckpoints(object):
        def __init__(self):
            self.checkpoints = []

        def write(self, to_write):
            self.checkpoints.append(to_write)

    mock_checkpoints = MockCheckpoints()

    def mock_get_write_function(output, overwrite):
        return mock_checkpoints.write

    module = sys.modules[__name__]
    saved_get_write_function = module.get_write_function
    module.get_write_function = mock_get_write_function
    saved_datetime_module = tracer.datetime_module
    tracer.datetime_module = datetime
    saved_random = tracer.random
    tracer.random = random



# Generated at 2022-06-10 21:39:11.961980
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    """

    """
    tracer = Tracer(watch=("x"))
    tracer.trace(frame,event, arg)
    x = 1
    # here the output should be
    ### Writing elapsed time:
    ### Finished writing elapsed time.
    ### Checking whether we should trace this line:
    ### Finished checking whether we should trace this line.
    ### Making timestamp:
    ### Finished making timestamp.
    ### Reporting newish and modified variables:
    ### Finished newish and modified variables.
    ### Dealing with misplaced function definition:
    ### Finished dealing with misplaced function definition.   

    ### Writing elapsed time:
    ### Finished writing elapsed time.
    ### Checking whether we should trace this line:
    ### Finished checking whether we should trace this line.
    ### Making timestamp:
    ### Finished making timestamp.
    ### Reporting newish and modified variables:
   

# Generated at 2022-06-10 21:39:23.634013
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename
    frame.f_globals.update({'__name__': 'mock_module',
                            '__loader__': mock_loader})
    assert get_path_and_source_from_frame(frame) == (
        'mock_module.py', ['mock source'])
    assert get_path_and_source_from_frame(frame) == (
        'mock_module.py', ['mock source'])
    del frame.f_globals['__loader__']
    assert get_path_and_source_from_frame(frame) == (
        'mock_module.py', ['mock source'])

# Generated at 2022-06-10 21:39:26.962542
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    assert get_path_and_source_from_frame(frame) == (__file__, inspect.getsourcelines(call_stack_module)[0])



# Generated at 2022-06-10 21:39:28.307212
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as tracer:
        assert tracer


# Generated at 2022-06-10 21:39:38.472385
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # Modify some globals to create a fake module for the `get_path_and_source_from_frame`
    # function to inspect.
    #
    # Note: This test is somewhat heuristic.

    def fake_func():
        global module_name
        module_name = 'my_module'

        global __file__
        __file__ = 'my_file.py'

        global __loader__
        __loader__ = type('my module loader', (object,), {})
        __loader__.get_source = lambda: 'bla'

        get_path_and_source_from_frame(inspect.currentframe())

    fake_func()

    expected_result = ('my_file.py', ['bla'])
    actual_result = source_and_path_cache[(module_name, __file__)]

# Generated at 2022-06-10 21:39:40.256264
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    x = Tracer()
    x.trace()
# class Tracer

# Generated at 2022-06-10 21:39:45.937932
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f(x, y):
        return x * y
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    assert frame.f_code.co_name == 'f'
    file_name, source = get_path_and_source_from_frame(frame)
    assert file_name == __file__
    assert 'def f(x, y):' in source



# Generated at 2022-06-10 21:40:01.792284
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .fake_frames import create_fake_frame
    from .utils import sleep
    from .watch import CommonVariable

    frame = create_fake_frame(
        frame_locals={'i': 3},
        code_obj=code_for_test_Tracer_trace,
    )

    s = StringIO()
    t = Tracer(output=s, watch=('i',), depth=2)
    assert t.trace(frame, 'call', None) is t.trace
    assert s.getvalue() == ''
    assert t.frame_to_local_reprs[frame] == {'i': '3'}

    s = StringIO()
    t = Tracer(output=s, watch=('i',), depth=2)
    assert t.trace(frame, 'line', None) is t.trace
   

# Generated at 2022-06-10 21:40:14.629423
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import builtins
    builtins.__dict__['DISABLED'] = False
    tracer = Tracer(output = None, watch = (), watch_explode = (), depth = 1, prefix = '', overwrite = False, thread_info = False, custom_repr = (), max_variable_length = 100, normalize = False, relative_time = False)
    try:
        raise RuntimeError('Cannot stop me')
    except RuntimeError as e:
        exception = e
        exc_type, exc_value, exc_traceback = sys.exc_info()
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        tracer.__exit__(exc_type, exc_value, exc_traceback)

# Generated at 2022-06-10 21:41:09.831951
# Unit test for function get_write_function
def test_get_write_function():
    import contextlib

    @contextlib.contextmanager
    def assert_raises(*exceptions):
        with pytest.raises(exceptions):
            yield

    def write_no_op(s): pass

    write = get_write_function(None, False)
    assert write('test') is None
    assert write(u'אבג') is None

    write = get_write_function(write_no_op, False)
    assert write('test') is None

    file_name = 'file.txt'
    if os.path.isfile(file_name):
        os.unlink(file_name)

    write = get_write_function(file_name, False)
    assert write('test') is None
    assert os.path.isfile(file_name)


# Generated at 2022-06-10 21:41:10.729420
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test is disabled due to its difficulty
    pass

# Generated at 2022-06-10 21:41:16.302731
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # set-up
    class Tracer(object):
        def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
                     prefix='', overwrite=False, thread_info=False, custom_repr=(),
                     max_variable_length=100, normalize=False, relative_time=False):
            pass
        def write(self, s):
            return
        def _is_internal_frame(self, frame):
            pass
    class Dummy_context(object):
        def __init__(self, exc_type, exc_value, exc_traceback):
            pass
        def __exit__(self, exc_type, exc_value, exc_traceback):
            pass
    class Dummy_functools(object):
        def wraps(self, function):
            return function


# Generated at 2022-06-10 21:41:18.023667
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper.tracer import Tracer

    @Tracer()
    def test_Tracer___call__(self):
        pass

    test_Tracer___call__(Tracer())


# Generated at 2022-06-10 21:41:27.930140
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import imp
    import types
    # Test 1:
    def test_function():
        pass
    func = test_function
    with pycompat.patch_object(func, 'f_globals', new={'__name__': 'test'}):
        source_path_1 = get_path_and_source_from_frame(func.__code__)
        assert source_path_1 == (__file__, source_and_path_cache[(__name__, __file__)][1])
    # Test 2:
    source_obj = imp.new_module(__name__)
    source_obj.__file__ = __file__
    with pycompat.patch_object(types, 'ModuleType', new=source_obj.__class__):
        source_path_2 = get_path_and_source

# Generated at 2022-06-10 21:41:32.986608
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return 5
    def bar():
        return foo()

    file_name, source = get_path_and_source_from_frame(
                                             inspect.currentframe().f_back)
    assert file_name == __file__
    assert 'bar()' in source[0]


# Unit tests for function get_local_reprs

# Generated at 2022-06-10 21:41:42.682132
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    '''Test method __call__ of class Tracer

    Testing with the following cases:
        - case 1: Check if decorator is as class
        - case 2: Check for coroutine function
        - case 3: Check for asyncgen function
        - case 4: Check for generator function
        - case 5: Check for normal function
    '''
    @pysnooper.snoop()
    class Foo:
        a = 0

    # case 1
    assert Foo.a == 0

    # case 2
    # Coroutines are functions, but snooping them is not supported at the moment
    @pysnooper.snoop()
    async def foo():
        return 0

    with pytest.raises(NotImplementedError):
        foo()

    # case 3
    # Coroutines are functions, but snooping them

# Generated at 2022-06-10 21:41:55.853360
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    print('Test for Tracer.__enter__')
    def test_10():
        f_name = sys._getframe().f_code.co_name

        with pysnooper.snoop():
            print('test_10')
            print(f_name)

    def test_10_1():
        f_name = sys._getframe().f_code.co_name

        with pysnooper.snoop(watch=('f_name')):
            print('test_10_1')
            print(f_name)

    def test_10_2():
        f_name = sys._getframe().f_code.co_name

        with pysnooper.snoop(watch=(), depth=0):
            print('test_10_2')
            print(f_name)


# Generated at 2022-06-10 21:42:03.810435
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest
    import time
    import inspect

    class TestTracerTrace(unittest.TestCase):
        def setUp(self):
            self.tracer = Tracer(watch=('bar', 'baz'))
            self.tracer.set_thread_info_padding = lambda x: ''
            self.thread_global = thread_global
            self.thread_global.__dict__["depth"] = -1

        def test_trace_before_or_after_the_decorated_function_should_return_None(self):
            frame = inspect.currentframe()
            frame.f_code = self.tracer._is_internal_frame.__code__
            result = self.tracer.trace(frame, None, None)
            self.assertIsNone(result)


# Generated at 2022-06-10 21:42:13.689008
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func():
        return 1

    import sys
    import types
    import builtins
    module = types.ModuleType('mod')
    module.func = func
    sys.modules['mod'] = module
    builtins.__dict__['mod'] = module
    source_info = get_path_and_source_from_frame(func.__code__.co_firstlineno)
    assert source_info == ('builtin', UnavailableSource())
    module.__file__ = __file__
    source_info = get_path_and_source_from_frame(func.__code__.co_firstlineno)
    assert source_info == (__file__, UnavailableSource())
    file_path = os.path.dirname(__file__)