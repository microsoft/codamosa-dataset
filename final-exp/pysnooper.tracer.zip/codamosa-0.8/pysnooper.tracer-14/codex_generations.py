

# Generated at 2022-06-10 21:33:26.081872
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer(watch=('foo', 'self.bar', 'baz'))
    tracer._write = MagicMock()
    tracer.start_times = {'frame0': datetime.datetime(2020, 11, 18, 0, 4, 42, 62282, tzinfo=datetime.timezone.utc), 'frame1': datetime.datetime(2020, 11, 18, 0, 4, 42, 63298, tzinfo=datetime.timezone.utc)}
    tracer._is_internal_frame = MagicMock(return_value=True)
    tracer.target_frames = set()

# Generated at 2022-06-10 21:33:34.485975
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func(x): return x
    def test(): pass

    # Test that get_path_and_source_from_frame works when module name is None
    assert get_path_and_source_from_frame(func.__code__.co_consts[0].co_frame) == (None, (func.__code__.co_consts[0].co_code,))

    # Test that get_path_and_source_from_frame works when module name is not None
    assert get_path_and_source_from_frame(test.__code__.co_consts[0].co_frame) == (__file__, [u'def test(): pass', u''])

    # Test that get_path_and_source_from_frame returns non-None source

# Generated at 2022-06-10 21:33:39.885673
# Unit test for function get_local_reprs
def test_get_local_reprs():
    class Foo:
        pass
    foo = Foo()
    foo.bar = 42
    bar = 43
    baz = "lorem ipsum"
    lorem = "Adam"
    ipsum = "Eve"
    def my_repr(x):
        if x == bar:
            return 'bar'
        return x
    class my_repr_wrapper:
        def __repr__(self):
            return 'my_repr_wrapper'
    my_repr_wrapper_instance = my_repr_wrapper()
    frame = inspect.currentframe()

# Generated at 2022-06-10 21:33:45.516636
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    _, _, get_path_and_source_from_frame_test_frame = inspect.stack()[0]
    result = get_path_and_source_from_frame(get_path_and_source_from_frame_test_frame)
    assert result[0] == os.path.basename(__file__)
    assert result[1][3].endswith('def test_get_path_and_source_from_frame():\n')



# Generated at 2022-06-10 21:33:51.249297
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .utils import Watch

    @pysnooper.snoop(watch='foo')
    def f():
        x = 123
        foo = 'foo'

    f()
    assert traceback.format_stack(inspect.currentframe())[-3] == \
'''  File "pysnooper/snoop.py", line 1696, in trace
    return self.trace
\n'''

# Generated at 2022-06-10 21:34:00.633875
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_name = 'file_writer_test_' + str(id(os.getpid())) # just to be sure that the name is unique
    assert not os.path.exists(file_name)
    file_writer = FileWriter(file_name, overwrite=True)
    file_writer.write('hello1')
    assert os.path.exists(file_name)
    file_writer.write('hello2')
    assert open(file_name, 'r').read() == 'hello1hello2'
    assert not file_writer.overwrite
    os.remove(file_name)
    assert not os.path.exists(file_name)



# Generated at 2022-06-10 21:34:07.412364
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import test
    def foo():
        bar()
    def bar():
        path_and_source = get_path_and_source_from_frame(inspect.currentframe().f_back)
    bar()
    source = path_and_source[1]
    assert source[0] == u'def foo():'
    assert source[1] == u'    bar()'
test_get_path_and_source_from_frame()
del test_get_path_and_source_from_frame



# Generated at 2022-06-10 21:34:09.729394
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global DISABLED
    DISABLED = False
    pysnooper.snoop(output=None)
    global DISABLED
    DISABLED = False

# Generated at 2022-06-10 21:34:21.306536
# Unit test for function get_write_function
def test_get_write_function():
    def write_to_file_test(output):
        import io
        import os

        write = get_write_function(output, True)
        write(u'123')
        write(u'456')

        assert os.path.isfile(os.path.join(u'.', output))
        with io.open(output) as fi:
            assert fi.read() == u'123456'
        os.remove(output)

    write_to_file_test(u'file.txt')
    write_to_file_test(u'./file.txt')
    write_to_file_test(u'path/file.txt')

    import io
    write = get_write_function(io.StringIO(), False)
    write(u'123')

# Generated at 2022-06-10 21:34:32.803284
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer._write = lambda x: None
    def _is_internal_frame(frame):
        return frame.f_code.co_filename == Tracer.__enter__.__code__.co_filename
    tracer._is_internal_frame = _is_internal_frame
    tracer.write = lambda x: None
    frame = MagicMock()
    frame.f_lineno, frame.f_code, frame.f_trace = 1, "code", None
    tracer.__enter__()
    assert frame.f_trace == tracer.trace
    assert frame in tracer.target_frames
    assert threading.current_thread().__dict__["depth"] == -1
    assert tracer.start_times[frame]
    assert sys.gettrace() == tracer.trace



# Generated at 2022-06-10 21:35:22.122347
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    total = 0
    def test_function(a, b):
        # source code line that get executed by method test_function
        global total
        total += a + b
        return total
        
    # go here if you want to see the source code of the decorated function
    decorated_function = snoop(test_function)
    test_input = [(1, 2), (3, 4), (5, 6)]
    for a, b in test_input:
        assert total == test_function(a, b)
        assert total == decorated_function(a, b)

if __name__ == '__main__':
    test_Tracer___call__()
 

# Generated at 2022-06-10 21:35:33.036146
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    frame = types.FrameType(None, -1, None, None, None, None)
    frame.f_code.co_filename = '<ipython-input-1-b006f00d23f3>'
    frame.f_globals = {'__loader__': None,
                       '__name__': '__main__',
                       'datetime': datetime_module}
    path, source = get_path_and_source_from_frame(frame)
    assert path == frame.f_code.co_filename
    assert source == source_and_path_cache[(frame.f_globals['__name__'],
                                            frame.f_code.co_filename)]

    frame = types.FrameType(None, -1, None, None, None, None)
    frame.f

# Generated at 2022-06-10 21:35:46.442723
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pickle
    import unittest.mock
    import functools
    import inspect
    # Test Tracer.__call__()
    # Argument output:
    # Example calls:
    #   output=None
    #   output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False
    #   output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False
    #   output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_

# Generated at 2022-06-10 21:35:47.272320
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass

# Generated at 2022-06-10 21:35:58.145043
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import time

    default_watch_list = ["foo"]
    default_watch_explode_list = ["self"]
    default_depth = 1
    default_prefix = ""
    default_overwrite = False
    default_thread_info = False
    default_custom_repr = ()
    default_max_variable_length = 100
    default_normalize = False
    default_relative_time = False
    default_output = None

    test_watch_list = ["bar"]
    test_watch_explode_list = ["args"]
    test_depth = 2
    test_prefix = "ZZZ "
    test_overwrite = True
    test_thread_info = True
    test_custom_repr = ( (str, lambda x: "str"), )
    test_max_variable_length = 200


# Generated at 2022-06-10 21:36:02.733624
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer('/tmp/snoop.log')
    tracer.__enter__()
    sys.gettrace()
    tracer.__exit__(None, None, None)



# Generated at 2022-06-10 21:36:04.490248
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import debugger

    def foo():
        return get_path_and_source_from_frame(sys._getframe(0))
    debugger.debug(foo, watch=())



# Generated at 2022-06-10 21:36:05.104382
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    assert False, "Test not implemented."


# Generated at 2022-06-10 21:36:18.133833
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = pysnooper.Tracer()
    thread_global.depth = -1
    calling_frame = inspect.currentframe().f_back
    if not tracer._is_internal_frame(calling_frame):
        calling_frame.f_trace = tracer.trace
        tracer.target_frames.add(calling_frame)

    stack = tracer.thread_local.__dict__.setdefault(
        'original_trace_functions', []
    )
    stack.append(sys.gettrace())
    tracer.start_times[calling_frame] = datetime_module.datetime.now()
    sys.settrace(tracer.trace)

    tracer.__exit__(None,None,None)
    assert not tracer.start_times

    assert not tracer.frame_to_local_

# Generated at 2022-06-10 21:36:21.613951
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer(output=None, overwrite=False)
    tracer._write = lambda s: s
    def foo():
        pass
    assert tracer(foo)() == None

# Generated at 2022-06-10 21:36:43.104031
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Tracer.__call__: 17
    def test_function():
        return
    with Tracer():
        test_function()

# Generated at 2022-06-10 21:36:55.573966
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def test_Tracer___call___1():
        import pysnooper

        def test_Tracer___call___1_1():
            def test_Tracer___call___1_1_1():
                def test_Tracer___call___1_1_1_1():
                    def test_Tracer___call___1_1_1_1_1():
                        def test_Tracer___call___1_1_1_1_1_1():
                            a = 1

                        @pysnooper.snoop()
                        def test_Tracer___call___1_1_1_1_1_2():
                            def test_Tracer___call___1_1_1_1_1_2_1():
                                a = 1

                            b = 1

                        test_Tracer

# Generated at 2022-06-10 21:37:04.262782
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import tempfile
    assert get_write_function(None, None) is not None
    assert get_write_function('path', None) is not None
    assert get_write_function(io.StringIO(), None) is not None
    assert get_write_function(tempfile.TemporaryFile(), None) is not None
    assert get_write_function(lambda s: None, None) is not None
    assert get_write_function('path', True) is not None
    assert get_write_function(None, True) is None



# Generated at 2022-06-10 21:37:07.098761
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    doctest.run_docstring_examples(Tracer.trace, globals(), verbose=True, name="Tracer.trace")


# Generated at 2022-06-10 21:37:08.769681
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    global_namespace = {}

# Generated at 2022-06-10 21:37:19.662960
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .utils import fake_source_code, fake_frame

    class FakeFrame(object):
        f_code = FakeFrameCode()
        f_globals = {}
        f_locals = {}
        f_trace = None

        def __repr__(self):
            return '<FakeFrame>'

    class FakeFrameCode(object):
        co_filename = '<FakeFilename>'
        co_name = '<FakeFuncName>'
        co_code = b''

    fake_frame = FakeFrame()
    fake_source_code = 'print("hello world")\n'

    def _test(event, fake_frame_event, trace_event,
              source_line_event, source_line_do_not_trace, source_line_trace,
              depth, depth_selector):
        fake_

# Generated at 2022-06-10 21:37:24.850288
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def sample_function():
        a_variable = 'some value'

    frame = inspect.currentframe().f_back
    path, source = get_path_and_source_from_frame(frame)
    assert path == __file__
    assert source[:3] == ['from __future__ import division',
                          'from __future__ import print_function',
                          "import re"]



# Generated at 2022-06-10 21:37:37.862801
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def check_source_and_path_from_frame(source, source_file_path):
        import tempfile
        with tempfile.NamedTemporaryFile('wb', delete=False) as f:
            f.write(source)
            f.close()
            check_source_and_path(source, source_file_path, f.name)
            os.unlink(f.name)
    def check_source_and_path(source, source_file_path, file_name):
        if (file_name.endswith(('.pyc', '.pyo')) and
                os.path.exists(file_name[:-1])):
            # The .py file might not have been generated yet
            file_name = file_name.rsplit('.', 1)[0]
        frame = sys._getframe()

# Generated at 2022-06-10 21:37:43.334265
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    """
    Write the two strings in a file and check if the file has those two strings
    """
    output = FileWriter('output.txt', True)
    output.write('String 1')
    output.write('String 2')
    with open('output.txt', 'r', encoding = 'utf-8') as output_file:
        assert output_file.read() == 'String 1String 2'


# Generated at 2022-06-10 21:37:44.915327
# Unit test for method __exit__ of class Tracer

# Generated at 2022-06-10 21:38:28.142182
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import os
    import sys
    import types
    import traceback
    import datetime
    import itertools
    import utils
    import opcode
    from decorator import BaseVariable
    from decorator import CommonVariable
    from decorator import Exploding
    import inspect
    import functools
    import pysnooper
    import pycompat
    DISABLED = os.environ.get('PYSNOOPER_DISABLE')
    thread_global = types.SimpleNamespace()
    # End of definitions for method trace of class Tracer
    from pysnooper.utils import get_path_and_source_from_frame
    from pysnooper.utils import get_write_function
    output=None
    watch=()
    watch_explode=()
    depth=1
    prefix=''

# Generated at 2022-06-10 21:38:43.238248
# Unit test for constructor of class Tracer
def test_Tracer():
    from .tracer import Tracer
    from .utils import BaseVariable
    from .common import CommonVariable
    from .explode import Exploding
    import inspect
    import threading
    import functools

    class Class(object):

        @Tracer()
        def internal_function(self, c, d):
            pass

        def function(self, a, b):
            return self.internal_function(a, b)

        def __call__(self, a, b):
            return self.function(a, b)


# Generated at 2022-06-10 21:38:46.314718
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    def foo(x):
        for i in range(x):
            pass

    tracer = Tracer(output='stdout')
    result = foo(5)
    assert result is None

# Generated at 2022-06-10 21:38:48.166200
# Unit test for function get_write_function
def test_get_write_function():
    import sys
    assert get_write_function(sys.stderr, False) == sys.stderr.write



# Generated at 2022-06-10 21:38:52.053010
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper import snoop
    @snoop()
    def test():
        x = 1
        y = 2
        z = x + y
    test()
    pass


# Generated at 2022-06-10 21:39:01.236399
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect

    def get_test_frame():
        def f():
            return inspect.currentframe()
        return f()

    test_frame = get_test_frame()
    file_name, source = get_path_and_source_from_frame(test_frame)
    assert source
    assert source[0].startswith('def get_test_frame():')

    def g():
        pass

    test_frame = g.__code__
    file_name, source = get_path_and_source_from_frame(test_frame)
    assert source
    assert source[0].startswith('def g():')




# Generated at 2022-06-10 21:39:04.820001
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    Tracer=Pysnooper._pysnooper.Tracer

    with pytest.raises(NotImplementedError):
        t = Tracer()
        t._Tracer_enter()


# Generated at 2022-06-10 21:39:07.344103
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    output = []
    obj = Output(output)
    with Tracer(output=obj, prefix='hi'):
        pass
    assert "Source path:... <unknown>" in output

# Generated at 2022-06-10 21:39:14.512281
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    with mock.patch('pysnooper.snoop.pysnooper.utils.ensure_tuple', return_value=('foo',)):
        with mock.patch('pysnooper.snoop.pysnooper.CommonVariable', return_value=mock.sentinel.comVar):
            with mock.patch('pysnooper.snoop.pysnooper.Exploding', return_value=mock.sentinel.exploding):
                res = tracer(mock.Mock())
    assert tracer.watch == [
        mock.sentinel.comVar,
        mock.sentinel.exploding,
    ]
    assert res == mock.sentinel.wrappedFunc



# Generated at 2022-06-10 21:39:25.662570
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    from pysnooper.tracing import Tracer, DISABLED
    from pysnooper.variables import CommonVariable, BaseVariable, Exploding
    DISABLED = False
    def foo():
        pass
    def function_is_decorated(function, decorator):
        return getattr(function, '__name__', None) == decorator
    def get_function_name(function):
        return getattr(function, '__name__', None)
    def function_wrapped_properly(function):
        return get_function_name(function) == 'simple_wrapper'
    def test_function_decorated_with_no_arguments():
        function = foo
        tracer = Tracer()
        decorator = tracer(function)

# Generated at 2022-06-10 21:40:48.874813
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()

    # Write to standard output
    tracer.write("foo")
    assert sys.stdout.getvalue() == "foo\n"

    # Store output in file
    with open("foo.txt", "w") as output:
        output_file = StringIO()
        output_file.write = output.write
        tracer._write = output_file.write
        tracer.write("foo")
        with open("foo.txt") as output:
            assert output.read() == "foo\n"
        os.remove("foo.txt")




# Generated at 2022-06-10 21:40:58.092007
# Unit test for constructor of class Tracer
def test_Tracer():
    with patch('pysnooper.utils.get_path_and_source_from_frame') as mock_path:
        mock_path.return_value = ('source_path', 'source')
        with patch('pysnooper.utils.get_local_reprs') as mock_local:
            mock_local.return_value = {}
            with Tracer(output='test_output', watch=('watch'),
                        watch_explode=('explode'), depth=2, prefix='prefix',
                        overwrite=False, thread_info=True,
                        custom_repr='repr'):
                pass
    assert mock_path.call_count == 1
    assert mock_local.call_count == 1



# Generated at 2022-06-10 21:41:05.412583
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import inspect
    a = '''
        def add(x, y):
            try:
                a = 3 + x + y
            except TypeError:
                raise TypeError
            except ValueError:
                raise ValueError
            return x + y
    '''
    b = '''
        def add(x, y):
            return x + y
    '''
    c = '''
        def add(x, y):
            for x in range(10):
                pass
            return x + y
    '''
    d = '''
        def add(x, y):
            f =  x + y
            g =  x + y
    '''
    e = '''
        def add(x, y):
            raise ValueError
    '''


# Generated at 2022-06-10 21:41:12.051123
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer(None)
    def f(x, y=3):
        return x + y
    def g(x):
        return x
    def h():
        return f
    def i(x):
        return g(x)
    def j():
        return h()
    def k():
        return i(2)
    assert f(1, y=4) == 5
    assert g(1) == 1
    assert h()(1, y=4) == 5
    assert i(2) == 2
    assert j()(1, y=4) == 5
    assert k() == 2
    assert f(1, y=4) == 5
    assert g(1) == 1
    assert h()(1, y=4) == 5
    assert i(2) == 2

# Generated at 2022-06-10 21:41:17.597587
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import io
    import builtins
    import contextlib
    import inspect
    import ast
    import io
    import types
    import dis
    import functools
    import textwrap
    import traceback
    import itertools
    import collections
    import datetime
    import threading
    from . import utils
    from . import pycompat
    from . import opcode
    from . import thread_global
    from . import print_function
    from . import DISABLED
    from . import BaseVariable
    from . import CommonVariable
    from . import Exploding
    from . import utils
    from . import get_write_function
    from . import get_path_and_source_from_frame
    from . import get_local_reprs
    from . import Tracer
    testargs_call_

# Generated at 2022-06-10 21:41:21.728879
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():

    log_list = []

    def dummy_write(s):
        log_list.append(s)

    tracer = pysnooper.Tracer(write=dummy_write)
    tracer.start_times[object()] = datetime_module.datetime(2019, 1, 1, 0, 0, 0)
    tracer.__enter__()

    tracer.__exit__(None, None, None)
    assert re.match(r'^    Elapsed time: 0:00:00\.[0-9]{3,3}$', log_list[-1])
    assert not tracer.start_times


# Generated at 2022-06-10 21:41:29.466155
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    # Create a dummy module's source code
    filename = 'temp_module.py'
    source = ['def f():\n',
              '    return 456\n']
    with open(filename, 'wb') as f:
        f.write(''.join(source).encode('utf-8'))

    def test_function():
        import temp_module
        return temp_module.f()

    try:
        result_path, result_source = get_path_and_source_from_frame(
                                                     test_function.__code__)
        assert result_path == filename
        assert result_source == source
    finally:
        os.remove(filename)

test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:41:37.551201
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writer = FileWriter('tmp.out', True)
    writer.write('one\ntwo\n')
    with open('tmp.out', 'r') as tmp_file:
        assert tmp_file.read() == 'one\ntwo\n'
    writer.write('three\nfour\n')
    with open('tmp.out', 'r') as tmp_file:
        assert tmp_file.read() == 'one\ntwo\nthree\nfour\n'
    os.remove('tmp.out')



# Generated at 2022-06-10 21:41:39.663984
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print('Testing Tracer.__call__()')
    # TODO
    print('Success')


# Generated at 2022-06-10 21:41:43.449540
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    frame = inspect.currentframe()
    try:
        assert frame is not None
        assert get_path_and_source_from_frame(frame)
    finally:
        del frame

