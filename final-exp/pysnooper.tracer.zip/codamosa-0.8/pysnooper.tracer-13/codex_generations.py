

# Generated at 2022-06-10 21:33:03.258249
# Unit test for function get_write_function
def test_get_write_function():
    import io
    assert isinstance(get_write_function(None, False),
                      collections.Callable)
    assert isinstance(get_write_function(io.StringIO(), False),
                      collections.Callable)
    assert isinstance(get_write_function(lambda x: x, False),
                      collections.Callable)
    assert isinstance(get_write_function('file', False),
                      FileWriter)
    def no_no(x):
        pass
    assert get_write_function(no_no, True) is no_no
    try:
        assert get_write_function(no_no, False) is no_no
    except Exception:
        pass
    else:
        raise Exception("Didn't raise expected exception")



# Generated at 2022-06-10 21:33:05.506980
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    doctest.testmod(verbose=True)

test_Tracer___call__()


# Generated at 2022-06-10 21:33:13.139777
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function():
        pass
    file_name, source = get_path_and_source_from_frame(function.__code__.co_filename, function.__code__)
    assert source[1].startswith('def test_get_path_and_source_from_frame():')
    file_name, source = get_path_and_source_from_frame(datetime_module.datetime.now)
    assert source[0].startswith('class datetime(')
    file_name, source = get_path_and_source_from_frame(map)
    assert source[0].startswith('def map(')



# Generated at 2022-06-10 21:33:24.564102
# Unit test for constructor of class Tracer
def test_Tracer():
    assert not os.path.exists(TEST_FILE)
    with open(TEST_FILE, 'w+') as f:
        tracer = Tracer(f)
        assert tracer.watch == []
        assert tracer.depth == 1
        assert tracer.prefix == ''
        assert tracer.thread_info_padding == 0
        assert tracer.target_codes == set()
        assert tracer.target_frames == set()
        assert tracer.thread_local == threading.local()
        assert tracer.custom_repr == ()
        assert tracer.last_source_path == None
        assert tracer.max_variable_length == 100
        assert tracer.normalize == False
        assert tracer.relative_time == False
        assert tracer._write == f.write
        # Tidy up
       

# Generated at 2022-06-10 21:33:27.199914
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """It should be possible to exit Tracer context manager"""
    with Tracer(output=StringIO()) as tracer:
        pass

# Generated at 2022-06-10 21:33:42.707501
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.write = Mock(side_effect=tracer.write)
    class ValidTracer(Tracer):
        def __init__(self):
            pass
    vt = ValidTracer()
    vt.write = Mock(side_effect=tracer.write)
    # Case 1
    # Test Case Number: 0
    # Test Case Values:
    # exc_type=None, exc_value=None, exc_traceback=None
    # Output:
    # (NOTHING)
    # Confidence: High
    tracer.__exit__(None, None, None)
    vt.__exit__(None, None, None)
    # Case 2
    # Test Case Number: 1
    # Test Case Values:
    # exc_type=None, exc_value=None

# Generated at 2022-06-10 21:33:46.396635
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper.tracer import Tracer

    def func():
        pass

    t = Tracer()
    f = t(func)
    assert f.__name__ == "func"


# Generated at 2022-06-10 21:33:57.003268
# Unit test for function get_write_function
def test_get_write_function():
    def write_to_file(path):
        write = get_write_function(path, overwrite=True)
        write('Hello')
    def write_to_stderr():
        write = get_write_function(output=None, overwrite=False)
        write('Hello')
    def write_to_func(f):
        write = get_write_function(output=f, overwrite=False)
        write('Hello')
    def write_to_wrong_overwrite_value():
        write = get_write_function(sys.stdout, overwrite='wrong_value')
        write('Hello')
    def write_to_wrong_output_type():
        write = get_write_function(['hello'], overwrite=False)
        write('Hello')

# Generated at 2022-06-10 21:34:07.729118
# Unit test for function get_write_function
def test_get_write_function():
    expected_unittest_output_result = 'unittest_output\n'
    expected_unittest_output_result_path = 'unittest_output\n'

    class UnittestOutput(utils.WritableStream):
        def write(self, data):
            assert data == expected_unittest_output_result
    unittest_output = UnittestOutput()

    unittest_output_path = utils.get_temp_file_path()
    write = get_write_function(unittest_output, False)
    write('unittest_output')
    write = get_write_function(unittest_output_path, True)
    write('unittest_output')
    assert os.path.isfile(unittest_output_path)

# Generated at 2022-06-10 21:34:11.111177
# Unit test for function get_local_reprs
def test_get_local_reprs():
    mydict = utils.mydict
    assert get_local_reprs(utils.get_frame('functools.get_local_reprs'),
                           watch=(CommonVariable('mydict'),),
                           custom_repr=(mydict,),
                           max_length=10) == mydict



# Generated at 2022-06-10 21:34:37.918001
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    utils.setup_logging(quiet=True)
    def test_f():
        print(0)
    def test_error():
        raise ValueError()
    def test_yield():
        for i in range(3):
            yield i
    def test_generator():
        yield from test_yield()
    def test_genexp():
        return (i for i in (0, 1))
    def test_module_variable():
        import random, os
        return random.random(), os.name
    def test_function_attr():
        def test_f():
            return 1
        test_f.attr = "value"
        return test_f.attr
    def test_global():
        def test_f():
            return 1
        def test_g():
            return test_f()
        return test_

# Generated at 2022-06-10 21:34:49.432034
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function(x):
        #### THIS IS A TEST FOR get_path_and_source_from_frame
        a = x + 1
        a = a * 2
        a = a * 3
        a = a * 4
        a = a * 5
        a = a * 6
        a = a * 7
        a = a * 8
        return a
    import inspect
    frame = inspect.currentframe()
    try:
        file_name = get_path_and_source_from_frame(frame)[0]
    finally:
        del frame

    line_number = function.__code__.co_firstlineno
    assert get_path_and_source_from_frame(inspect.currentframe())[0] == file_name

# Generated at 2022-06-10 21:35:00.522204
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest
    import types
    import functools
    def a(n):
        return n
    def test_function():
        pass

    @pysnooper.snoop(watch=('n', 'a(n)'), prefix='ZZZ ')
    def b(n):
        return a(n)

    with pytest.raises(NotImplementedError):
        @pysnooper.snoop()
        async def a():
            pass

    with pytest.raises(NotImplementedError):
        @pysnooper.snoop()
        async def a():
            await asyncio.sleep(0)

    # test Class decorator
    class A:
        @pysnooper.snoop()
        def a(self,n):
            return n

# Generated at 2022-06-10 21:35:03.456868
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def _():
        assert False, 'This should never be executed'
    with pytest.raises(Exception):
        _()
    with pytest.raises(TypeError):
        snoop(1)

# Generated at 2022-06-10 21:35:11.376361
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    ''' Test for method trace of class Tracer. '''
    global DISABLED
    DISABLED = True
    test_Tracer = Tracer(watch=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    assert not test_Tracer.frame_to_local_reprs
    test_Tracer.frame_to_local_reprs = {1:'a'}
    assert test_Tracer.frame_to_local_reprs
    test_Tracer.target_codes = set()
    test_Tracer.target_frames = set()
    test_Tracer.start_times = {1:'a'}
    test_Tracer.thread_local = threading.local()

# Generated at 2022-06-10 21:35:23.495517
# Unit test for constructor of class Tracer
def test_Tracer():
    import pysnooper.utils
    if pysnooper.utils.PY3:
        from venv.scripts.activate import pysnooper
        from venv.scripts.activate import pycompat
        from venv.scripts.activate import inspect
        from venv.scripts.activate import threading

# Generated at 2022-06-10 21:35:34.353568
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    tracer.write = utils.DictWriter(dict())
    # Test for a single function
    def foo(a):
        b = a + 1
        c = bar()
        return c + 1
    def bar():
        return 5
    foo_wrapped = tracer(foo)
    foo_wrapped(1)
    # Test for a class with multiple methods
    class Foo:
        def __init__(self, a):
            self.a = a
        def bar(self):
            return self.a + 1
        def baz(self):
            return Foo(self.a + 1)
    tracer.write = utils.DictWriter(dict())
    tracer(Foo).__init__(1)
    tracer(Foo).bar()

# Generated at 2022-06-10 21:35:47.591804
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from hypothesis import given, strategies as st
    from test_utils import REPR_MAX_LENGTH, TEST_SOURCE_PATH, mock
    import hypothesis.strategies as st

    @given(st.integers(min_value=1, max_value=sys.getrecursionlimit()))
    def test_depth(depth):
        # Makes sure the depth argument produces the expected number of
        # snoop lines.
        tracer = Tracer(depth=depth)

        @tracer
        def function():
            pass

        @tracer
        def other_function():
            function()

        num_lines = 0

        @tracer
        def third_function():
            nonlocal num_lines

            function()
            function()
            function()

            for x in range(4):
                num_lines += 1
                assert x == num

# Generated at 2022-06-10 21:35:58.487159
# Unit test for constructor of class Tracer
def test_Tracer():
    # Unit test for constructor of class Tracer
    tr1 = Tracer()
    assert 'prefix' in tr1.__dict__
    assert tr1.__dict__['prefix'] == ''
    tr2 = Tracer(prefix=None)
    assert 'prefix' in tr2.__dict__
    assert tr2.__dict__['prefix'] == ''
    tr3 = Tracer(prefix='')
    assert 'prefix' in tr3.__dict__
    assert tr3.__dict__['prefix'] == ''
    with pytest.raises(TypeError) as excinfo:
        Tracer(prefix=1)
    assert 'prefix must be a string' in str(excinfo.value)
    tr4 = Tracer(prefix='abc')
    assert 'prefix' in tr4.__dict__
    assert tr4.__dict

# Generated at 2022-06-10 21:36:09.994199
# Unit test for constructor of class Tracer
def test_Tracer():
    assert Tracer()
    assert Tracer(output='/tmp/pysnooper.log')
    assert Tracer(watch='a')
    assert Tracer(watch=(('a', 'b'), 'c', 'd.e'))
    assert Tracer(watch_explode=(('a', 'b'), 'c', 'd.e'))
    assert Tracer(depth=0)
    assert Tracer(depth=2)
    assert Tracer(prefix='')
    assert Tracer(prefix='Hello, ')
    assert Tracer(overwrite=False)
    assert Tracer(overwrite=True)
    assert Tracer(thread_info=False)
    assert Tracer(thread_info=True)
    assert Tracer(custom_repr=())

# Generated at 2022-06-10 21:36:44.445125
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__(): 
    tracer = Tracer(depth=1,prefix='',overwrite=False,thread_info=False,custom_repr=(),max_variable_length=100,normalize=False,relative_time=False)
    assert True



# Generated at 2022-06-10 21:36:56.604730
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys
    test_output = io.StringIO()
    test_write = get_write_function(test_output, overwrite=True)
    def dummy_write_function(s):
        print(s)
        test_write(s)
    def dummy_next(frame):
        frame.f_lineno += 1
        return frame.f_lineno
    tracer_test = Tracer(output='', depth=1, prefix='', overwrite=False,
                         thread_info=False, custom_repr=(),
                         max_variable_length=100, normalize=False,
                         relative_time=False)
    tracer_test._write = dummy_write_function

# Generated at 2022-06-10 21:37:01.251520
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    s = StringIO()
    def func():
        pass
    with Tracer(output=s):
        func()
    assert s.getvalue() == '    Elapsed time: 0:00:00\n'


# Generated at 2022-06-10 21:37:12.273107
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer(
        output=None,
        watch_explode=(),
        watch=(),
        depth=1,
        prefix='',
        overwrite=False,
        thread_info=False,
        custom_repr=(),
        max_variable_length=100,
        normalize=False,
        relative_time=False,
    )
    thread_global.depth = -1
    assert thread_global.depth == -1
 
    try:
        assert_raises(KeyError, tracer.start_times.pop, calling_frame)
    except Exception as e:
        exc_info = sys.exc_info()

# Generated at 2022-06-10 21:37:23.082814
# Unit test for constructor of class Tracer
def test_Tracer():
    # The constructor of class Tracer should accept watch, watch_explode, depth
    # and prefix as keyword arguments.
    pysnooper.snoop(watch_explode=('watch_explode'))
    pysnooper.snoop(prefix='prefix')
    pysnooper.snoop(depth=2)
    pysnooper.snoop(watch=('watch'))

    # They should be assigned as appropriate attritubes
    tracer = Tracer(watch_explode=('watch_explode'), prefix='prefix',
                    depth=2)
    assert tracer.depth == 2
    assert tracer.prefix == 'prefix'
    assert tracer.watch == [CommonVariable('watch_explode', should_explode=True),
                            CommonVariable('watch')]
    assert tracer.watch_

# Generated at 2022-06-10 21:37:26.268027
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    from pysnooper import snoop
    @snoop()
    def func1():
        try:
            return 1/0
        except:
            return 1
    with pytest.raises(ZeroDivisionError):
        func1()

# Generated at 2022-06-10 21:37:38.347210
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import mock
    import pysnooper
    import sys
    import threading
    threading_module = pysnooper.threading_module
    DISABLED = pysnooper.DISABLED
    Tracer = pysnooper.tracer.Tracer
    thread_global = pysnooper.tracer.thread_global
    traceback_module = pysnooper.traceback_module

    @pysnooper.snoop()
    def test_function():
        a = 2
        a = 3

    with mock.patch('pysnooper.tracer.Tracer.write') as mocked_write:
        test_function()

    # Test results:
    assert mocked_write.call_count == 3

# Generated at 2022-06-10 21:37:39.386209
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass #TODO: Not yet implemented

# Generated at 2022-06-10 21:37:49.326103
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    class MockTracer(Tracer):
        pass
    obj = MockTracer(output=None, watch=(), depth=2,
                     custom_repr=(), max_variable_length=100, normalize=False,
                     relative_time=False, prefix='', overwrite=False,
                     thread_info=False)
    obj.thread_local.__dict__['original_trace_functions'] = []
    MockTracer.__dict__['frame_to_local_reprs'] = {}
    MockTracer.__dict__['start_times'] = {}
    MockTracer.__dict__['target_codes'] = set()
    MockTracer.__dict__['target_frames'] = set()
    MockTracer.__dict__['thread_local'] = threading.local()

# Generated at 2022-06-10 21:37:50.627404
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    t = Tracer()
    assert t.trace


# Generated at 2022-06-10 21:39:06.423969
# Unit test for function get_write_function
def test_get_write_function():
    with open('helloworld.txt', 'w') as fh:
        assert callable(get_write_function(fh, False))
        assert callable(get_write_function(fh, True))
    assert callable(get_write_function(None, False))
    assert get_write_function(None, True) is None
    assert callable(get_write_function('helloworld.txt', False))
    assert callable(get_write_function('helloworld.txt', True))
    with open('helloworld.txt', 'w') as fh:
        assert callable(get_write_function(utils.WritableStream(fh), True))
    assert callable(get_write_function(utils.WritableStream(sys.stdout), True))



# Generated at 2022-06-10 21:39:14.164772
# Unit test for function get_write_function
def test_get_write_function():
    def test_output():
        os.remove('test_output_output.txt')

    def test_overwrite():
        os.remove('test_overwrite_output.txt')

    def test_callable():
        os.remove('test_callable_output.txt')

    def test_is_path():
        os.remove('test_is_path_output.txt')

    def test_write(output, overwrite=False):
        """
        Call the function get_write_function with the parameters 'output' and
        'overwrite'. Write some content and check if it is written in the file
        or in the console.
        """
        write_function = get_write_function(output, overwrite)

        write_function('Hello world!')
        if overwrite:
            assert os.path.isfile(output)

# Generated at 2022-06-10 21:39:22.953366
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    DISABLED=False
    obj=Tracer()
    obj.target_codes=set()
    obj.target_frames=set()
    obj.start_times={}
    obj.custom_repr=[]
    obj.depth=1
    obj.frame_to_local_reprs={}
    from inspect import currentframe
    frame=currentframe()
    event='call'
    arg={}
    ex=obj.trace(frame,event,arg)
    assert ex == obj.trace


# Generated at 2022-06-10 21:39:34.103665
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import __builtin__
    import ast
    get_path_and_source_from_frame(
        sys._getframe()
    )
    def foo(arg):
        get_path_and_source_from_frame(
            sys._getframe()
        )
        pass
    foo(1)
    exec(compile('get_path_and_source_from_frame(sys._getframe())',
                 '<string>', 'exec'))
    for source_line in (
        'import os',
        'get_path_and_source_from_frame(sys._getframe())',
    ):
        exec(compile(source_line, '<string>', 'exec'))
    import ast

# Generated at 2022-06-10 21:39:43.627550
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys, os
    if not hasattr(sys, 'getallocatedblocks'):
        pytest.skip('Test requires CPython')
    def do_test(file_name, source, module_name='__main__'):
        import ast
        code = compile(ast.parse(source), file_name, 'exec')
        loader = local_import(file_name)
        with open(file_name, 'w') as f:
            f.write(source)
        frame = sys._getframe()
        frame.f_globals['__name__'] = module_name
        frame.f_globals['__loader__'] = loader
        frame.f_code = code
        assert get_path_and_source_from_frame(frame) == (file_name, source.splitlines())

# Generated at 2022-06-10 21:39:45.828174
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    raise Exception("Test for method test_Tracer___exit__ not written yet.")


# Generated at 2022-06-10 21:39:49.179806
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop()
    def foo(): pass
    assert isinstance(foo, Tracer)


# Generated at 2022-06-10 21:40:04.526094
# Unit test for method trace of class Tracer
def test_Tracer_trace():

    #  start_times = {}
    #  frame_to_local_reprs = {}
    local_reprs = {'def': 'def', 'self': 'self'}
    #  frame = frame
    #  calling_frame = inspect.currentframe()
    #  thread_global.depth = -1
    #  line_no = frame.f_lineno
    #  timestamp = pycompat.time_isoformat(
    #  datetime_module.datetime.now().time(),
    #  timespec='microseconds'
    #  )
    #  indent = ' ' * 4 * (thread_global.depth + 1)
    #  last_source_path = None
    source_path, source = get_path_and_source_from_frame(frame)
    source_path = source_path

# Generated at 2022-06-10 21:40:07.619020
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = pysnooper.snoop()
    # Call method __enter__ of class Tracer
    return tracer.__enter__()

if __name__ == '__main__':
    test_Tracer___enter__()

# Generated at 2022-06-10 21:40:19.879824
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import variables
    __FILE__ = None
    __file__ = get_path_and_source_from_frame(sys._getframe())[0]
    assert __file__ == sys.modules[__name__].__file__
    assert type(__FILE__) is type(__file__)
    with variables.VariableConfiguration(variables.VariableConfiguration.quick,
                                         locals()):
        x = 1
        source = get_path_and_source_from_frame(sys._getframe())[1]
        assert source[0] == '__FILE__ = None'
        assert source[1] == '__file__ = get_path_and_source_from_frame(sys._getframe())[0]'
        assert source[2] == 'assert __file__ == sys.modules[__name__].__file__'
       