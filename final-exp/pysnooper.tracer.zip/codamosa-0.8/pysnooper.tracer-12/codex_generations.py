

# Generated at 2022-06-10 21:33:15.249054
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    global x_var
    x_var = 1
    def f():
        global x_var
        x_var = 2
        frames = sys._getframe().f_back.f_back.f_back
        for frame in (frames, frames.f_back):
            assert get_path_and_source_from_frame(frame)[1][0].endswith(
                'common_tricks.py')

test_get_path_and_source_from_frame()



# Generated at 2022-06-10 21:33:23.241061
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile

    with tempfile.NamedTemporaryFile(delete=False) as output_file:
        output_file.close()
        path = output_file.name

    fw = FileWriter(path, overwrite=True)
    fw.write('one')
    fw.write('two')
    fw.write('three')
    with open(path, 'r') as output_file:
        assert output_file.read() == 'three'
    fw = FileWriter(path, overwrite=True)
    os.remove(path)



# Generated at 2022-06-10 21:33:25.052802
# Unit test for function get_path_and_source_from_frame

# Generated at 2022-06-10 21:33:30.189578
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    def test_func(test_arg):
        return test_arg
    with Tracer() as tracer:
        with tracer:
            test_arg = 'test_val'
            res = test_func(test_arg)
        with tracer:
            res = test_func(test_arg)
        with tracer:
            res = test_func(test_arg)
# Test setUp

# Generated at 2022-06-10 21:33:43.266017
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test 1
    frame = object()
    event = object()
    arg = object()
    with Tracer(output=None) as tracer_obj:
        res = tracer_obj.trace(frame=frame, event=event, arg=arg)
        assert res == tracer_obj.trace

    assert tracer_obj.frame_to_local_reprs == {}

    # Test 2
    frame = object()
    event = object()
    arg = None
    with Tracer(output=None) as tracer_obj:
        res = tracer_obj.trace(frame=frame, event=event, arg=arg)
        assert res == tracer_obj.trace

    assert tracer_obj.frame_to_local_reprs == {}



# Generated at 2022-06-10 21:33:49.406968
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(watch='$a', watch_explode='$b')
    @pysnooper.snoop(watch='$c', watch_explode='$d', depth=2)
    def foo(a, b, c, d):
        return a + b + c + d
    assert foo(1, 2, 3, 4) == 10
# End of unit test for constructor of class Tracer

# Generated at 2022-06-10 21:33:50.073475
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass

# Generated at 2022-06-10 21:34:01.491207
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from contextlib import ExitStack
    from io import StringIO
    from pysnooper import Line

    import pysnooper.utils as utils

    from test.test_tracer import TracerTestBase
    from test.test_utils import NoOutput

    class MyTestCase(TracerTestBase):
        def test_normalize(self):
            with ExitStack() as stack:
                output = stack.enter_context(StringIO())
                stack.enter_context(NoOutput())
                stack.enter_context(
                    Tracer(output, normalize=True)
                )
                self.assertEqual(Line('Source path:... test/test_tracer.py'),
                                 Line(output.getvalue()))

        def test_relative_time(self):
            with ExitStack() as stack:
                output = stack.enter

# Generated at 2022-06-10 21:34:11.007402
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import my_module
    test_frame = sys._getframe()
    test_globals = test_frame.f_globals
    test_filename = test_frame.f_code.co_filename
    test_source = test_globals['__file__']
    if test_source.endswith('.pyc'):
        test_source = test_source[:-1]
    assert get_path_and_source_from_frame(test_frame) == (
        test_source,
        source_and_path_cache[('my_module', test_filename)][1]
    )

    assert my_module.my_function() == 'my_function called'

# Generated at 2022-06-10 21:34:23.085133
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import textwrap
    from collections import namedtuple

    @pysnooper.snoop()
    def f():
        print('hello')
        return 'world'

    captured_stdout = io.StringIO()
    with contextlib.redirect_stdout(captured_stdout):
        f()
    captured_stdout.seek(0)
    captured_stdout_lines = captured_stdout.readlines()
    captured_stdout_lines = [line.rstrip('\n') for line in captured_stdout_lines]


# Generated at 2022-06-10 21:34:49.644082
# Unit test for constructor of class Tracer
def test_Tracer():
    assert isinstance(Tracer(output='/tmp/test.txt'), Tracer)
    assert isinstance(Tracer(output='/tmp/test.txt', watch=('a',)), Tracer)
    assert isinstance(Tracer(output='/tmp/test.txt', watch=[('a', 'b', 'c')]), Tracer)
    assert isinstance(Tracer(output='/tmp/test.txt', watch='a'), Tracer)
    assert isinstance(Tracer(output='/tmp/test.txt', watch_explode='a'), Tracer)
    assert isinstance(Tracer(output='/tmp/test.txt', watch_explode=['a', 'b']), Tracer)
    assert isinstance(Tracer(output='/tmp/test.txt', watch_explode=[('a', 'b')]), Tracer)

# Generated at 2022-06-10 21:35:01.021953
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    s = 'foo'
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8') as output_file:
        output_file.write(s)
        output_file_path = output_file.name
        output_file.close()
        file_writer = FileWriter(output_file_path, overwrite=False)
        file_writer.write(s)
        with open(output_file_path, 'r', encoding='utf-8') as output_file:
            assert output_file.read() == 2*s



# Generated at 2022-06-10 21:35:02.060950
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys


# Generated at 2022-06-10 21:35:10.501618
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    get_source = get_path_and_source_from_frame

    def foo():
        pass
    assert get_source(inspect.currentframe())[0] == '<string>'
    assert get_source(foo.__code__.co_filename, foo.__code__.co_name)
      # A-OK
    assert get_source(foo.__code__.co_name, foo.__code__.co_name)
    assert get_source(1, 2) == ('1', UnavailableSource())
    assert get_source(1, 2) == ('1', UnavailableSource())  # Cached now

    def foo():
        pass

    assert get_source(inspect.currentframe())[0] == '<string>'

# Generated at 2022-06-10 21:35:15.726348
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from pysnooper import snoop

    @snoop
    def my_func():
        pass

    assert isinstance(my_func, Tracer)
    assert my_func.__closure__
    assert my_func.__closure__[0].cell_contents is my_func



# Generated at 2022-06-10 21:35:27.725600
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def func():
        pass
    func.__code__.co_filename = 'filename.py'
    tracer = Tracer()
    tracer.target_codes = set((func.__code__,))
    tracer.frame_to_local_reprs[123] = 456
    tracer.frame_to_local_reprs[7] = 8

    ### Testing DISABLED: #####################################################
    #                                                                         #
    assert tracer.trace(123, 'exception', (1, 2, 3)) == None
    #                                                                         #
    ### Finished testing DISABLED. ############################################

    ### Testing event call: ###################################################
    #                                                                         #
    frame = func.__code__
    thread_global.__dict__['depth'] = 6
    tracer

# Generated at 2022-06-10 21:35:29.621106
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, False)
    assert write is not None



# Generated at 2022-06-10 21:35:37.968106
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def my_function(x):
        a = 3
        return x + a

    _, source = get_path_and_source_from_frame(sys._getframe(0))
    start_line = source.index('def my_function(x):')
    end_line = source[start_line:].index('    return x + a') + start_line
    assert source[start_line:end_line] == [
        'def my_function(x):',
        '    a = 3',
        '    return x + a',
    ]
    (_, source) = get_path_and_source_from_frame(sys._getframe(0))
    start_line = source.index('    a = 3')
    end_line = source[start_line:].index('    return x + a') + start_line

# Generated at 2022-06-10 21:35:53.977103
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def sample_function():
        pass
    def sample_generator():
        yield
    function_output = []
    generator_output = []
    sample_function_with_snoop_enabled = Tracer(function_output.append)(
                                                          sample_function)
    sample_generator_with_snoop_enabled = Tracer(generator_output.append)(
                                                          sample_generator)
    sample_function_with_snoop_enabled()
    assert function_output == []
    assert generator_output == []
    with Tracer(function_output.append):
        sample_function_with_snoop_enabled()
    expected_output = ['New var:....... something = 1']
    assert function_output[-len(expected_output):] == expected_output

# Generated at 2022-06-10 21:36:06.549051
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """
    This is a unit test for method __exit__ of class Tracer
    """
    # get an instance of Tracer class
    tracer = Tracer('/tmp/snoop.log', watch=('foo', 'bar'))

    exception = None
    exc_type = None
    exc_traceback = None

    def get_timestamp():
        return datetime_module.datetime.now()

    def get_frame():
        return inspect.currentframe().f_back

    # get the calling frame
    calling_frame = get_frame()
    # set the 'start_times' and 'target_frames' attributes of tracer
    tracer.start_times[calling_frame] = get_timestamp()
    tracer.target_frames.add(calling_frame)

    # set the 'depth' attribute of thread_

# Generated at 2022-06-10 21:36:22.398760
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    with tracer:
        assert thread_global.depth == -1


# Generated at 2022-06-10 21:36:32.738989
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import my_module
    def test_function():
        return 1
    source_1 = get_path_and_source_from_frame(inspect.currentframe())
    source_2 = get_path_and_source_from_frame(
        my_module.__dict__['__file__'].__dict__['currentframe']()
    )
    source_3 = get_path_and_source_from_frame(
        test_function.__dict__['currentframe']()
    )

# Generated at 2022-06-10 21:36:42.262137
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with open("test_Tracer_trace.txt", "w") as f:
        f.write("")
    f = open("test_Tracer_trace.txt", "a")
    def show_argument(*args, **kwargs):
        for i in range(len(args)):
            print("Argment " + str(i) + ": " + str(args[i]))
        for key in kwargs.keys():
            print("Keyword " + str(key) + ": " + str(kwargs[key]))
    ##########################################################################
    # function test_1
    ##########################################################################
    print("\n\nTest 1\n")

# Generated at 2022-06-10 21:36:51.353693
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        return get_path_and_source_from_frame(inspect.currentframe())
    test_path = os.path.join(os.path.dirname(__file__), 'test_get_source.py')
    with open(test_path, 'rb') as f:
        expected_source = f.read().decode('utf-8').splitlines()
    actual_path, actual_source = test_function()
    assert actual_path == test_path
    assert actual_source == expected_source



# Generated at 2022-06-10 21:36:59.363357
# Unit test for function get_local_reprs
def test_get_local_reprs():
    a = 'foo'
    b = 42
    c = (1, 2, 3)
    watch = (BaseVariable('a'), CommonVariable('b'), CommonVariable('c'))
    assert get_local_reprs(inspect.currentframe()) == \
           {'a': repr(a), 'b': repr(b), 'c': repr(c), 'watch': repr(watch)}



# Generated at 2022-06-10 21:37:01.474693
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import os, sys

    # THIS IS A STUB
    raise NotImplementedError


# Generated at 2022-06-10 21:37:04.928034
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # test signal handler is set to the function 'snoop_signal_handler'
    assert signal.getsignal(signal.SIGTERM) == snoop_signal_handler



# Generated at 2022-06-10 21:37:16.406458
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    ''' Test for Tracer.trace.
    Test if the tracing of a Tracer instance can correctly record events of a
    test function.
    '''
    def f(arg):
        return arg

    t = Tracer(watch=['arg'])
    events = []
    frame = inspect.currentframe().f_back
    frame.f_trace = t.trace
    t.target_frames.add(frame)
    with t:
        events.append(f(1))
        events.append(f(5))

    assert events == [1, 5]
    # assert that the trace function correctly records call events
    assert t.frame_to_local_reprs.keys() == {frame}

# Generated at 2022-06-10 21:37:25.976844
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import os
    import sys
    import pytest
    import inspect
    import functools
    import itertools
    import pycompat
    import os
    import sys
    import pytest
    from . import pysnooper, thread_global
    from .utils import get_path_and_source_from_frame
    from . import utils
    from . import inspect
    from . import pycompat
    from . import BaseVariable, CommonVariable, Exploding
    from . import get_write_function
    import functools
    import itertools
    import pycompat
    import inspect
    import functools
    import itertools
    import pycompat
    import inspect
    import types
    import functools
    import itertools
    import pycompat
    import datetime
    import functools


# Generated at 2022-06-10 21:37:38.293691
# Unit test for constructor of class Tracer
def test_Tracer():
    # We need a function to watch, taken from the README.
    def test():
        bar = 'BAR'
        foo = [0, 1, 2, {'a': 'A'}]
        foo[3]['b'] = 'B'
        assert 1 == 2

    def unit_test_case(watch, depth, expected_output):
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                         prefix='pysnooper_',
                                         suffix='.log') as temp_output:
            with Tracer(temp_output.name, watch=watch, depth=depth):
                test()
            output_content = utils.get_file_content(temp_output.name)


# Generated at 2022-06-10 21:38:03.367190
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    m_get_local_reprs = MagicMock(return_value={'x': '1', 'y': '2'})
    m_get_path_and_source_from_frame = MagicMock(return_value=('x', 'xx'))
    # m_Tracer_write = MagicMock()
    m_Tracer_trace = MagicMock(side_effect = pysnooper.tracer.Tracer.trace)


# Generated at 2022-06-10 21:38:10.303990
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    frame = inspect.currentframe()
    frame.f_lineno = 5
    frame.f_code.co_filename = "/usr/lib/python3.6/site-packages/pysnooper/__init__.py"
    event = 'call'
    trace_object = Tracer()
    assert trace_object.trace(frame, event, None) == trace_object.trace
# Unit tests for method __call__ of class Tracer
import functools


# Generated at 2022-06-10 21:38:23.548557
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import io
    import unittest
    from function_wrappers import get_path_and_source_from_frame, get_local_reprs
    from function_wrappers import BaseVariable, CommonVariable, Exploding
    from function_wrappers import DISABLED
    from function_wrappers import thread_global

    class TestCases(unittest.TestCase):

        def call_test_function(self, *args, **kwargs):
            def test_function():
                pass

            with self.tracer:
                return test_function(*args, **kwargs)

        def call_test_generator(self, *args, **kwargs):
            def test_generator():
                yield 1

            with self.tracer:
                gen = test_generator()
                if next(gen):
                    return
                return gen

# Generated at 2022-06-10 21:38:25.393144
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    testTrace = Tracer()
    assert testTrace.thread_info == False


# Generated at 2022-06-10 21:38:28.608807
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    """This is an automatically generated unit test for method __call__ of class Tracer
    """


# Generated at 2022-06-10 21:38:41.186681
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer(overwrite=True)
    assert tracer.watch == []
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.custom_repr == ()

    tracer = Tracer(watch=[b'foo'])
    assert isinstance(tracer.watch[0], CommonVariable)
    assert tracer.watch[0].name == 'foo'

    tracer = Tracer(watch_explode=[b'foo'])
    assert isinstance(tracer.watch[0], Exploding)
    assert tracer.watch[0].name == 'foo'


# Generated at 2022-06-10 21:38:52.580893
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    source_path = 'foo.py'
    source_lines = 'line 1\nline 2\nline 3'.split('\n')
    # noinspection PyUnresolvedReferences
    frame = mock.Mock(spec=inspect.FrameInfo(
        filename=source_path,
        lineno=2,
        code_context=source_lines[1],
    ), f_code=mock.Mock(spec=inspect.CodeType, co_filename=source_path),
        f_lineno=2, f_lasti=3, f_trace=None)
    trace_frame = Tracer(watch=[])
    trace_frame.frame_to_local_reprs[frame] = {}
    trace_frame.start_times[frame] = datetime_module.datetime.now()
    trace_frame

# Generated at 2022-06-10 21:38:57.092884
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    assert get_path_and_source_from_frame(f.__code__.co_consts[0].co_frame) == \
                                                   (f.__code__.co_filename,
                                                    UnavailableSource())



# Generated at 2022-06-10 21:39:07.863692
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    conn = get_connection()
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute("""CREATE TABLE test_Tracer___exit__ (
        id serial PRIMARY KEY,
        num integer,
        data varchar
    )""")
    count = 0
    for i in range(100):
        if random.randint(0, 1):
            for j in range(random.randint(1, 10)):
                cur.execute("INSERT INTO test_Tracer___exit__ (num, data) VALUES (%(num)s, %(data)s)",
                            {'num': random.randint(1, 1000000), 'data': str(random.random())})
            count += 1

    conn.commit()


# Generated at 2022-06-10 21:39:14.937553
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from . import variables
    from .utils import shortish_repr
    from .dialog import sim
    from . import test_utils

    for use_ipython in (False, True):
        for use_custom_repr in (False, True):
            for use_max_length in (False, True):
                for normalize in (False, True):
                    frame = test_utils.execute_code(
                        '''def f(x):
                               y = 2
                               z = 3
                           f(1)
                        '''
                    )
                    frame = frame.f_back
                    assert frame.f_code.co_name == 'f'

                    expected_result = {'x': '1', 'y': '2', 'z': '3'}

# Generated at 2022-06-10 21:39:39.373399
# Unit test for function get_write_function
def test_get_write_function():
    from . import unicode

    assert '<function get_write_function.<locals>.write at ' in repr(
        get_write_function(None)).strip()
    write = get_write_function(unicode.StringIO(), False)
    assert '<function get_write_function.<locals>.write at ' in repr(
        write).strip()
    assert write(1) is None
    assert write(None) is None
    assert write(u'hi') is None
    #
    assert '<function get_write_function.<locals>.write at ' in repr(
        get_write_function('to.file', False)).strip()
    with utils.temp_folder() as temp_folder:
        path = utils.Path(temp_folder) / 'bla.txt'

# Generated at 2022-06-10 21:39:50.873449
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test with basic parameters.
    def assert_default_config(tracer):
        assert tracer.watch == ()
        assert tracer.watch_explode == ()
        assert tracer.depth == 1
        assert tracer.prefix == ''
        assert tracer.overwrite is False
        assert tracer.thread_info is False
        assert tracer.custom_repr == ()
        assert tracer.max_variable_length == 100
        assert tracer.normalize is False
        assert tracer.relative_time is False

    assert_default_config(Tracer('stdout'))
    assert_default_config(Tracer(output='stdout'))
    assert_default_config(Tracer(output=sys.stdout))
    assert_default_config(Tracer(output=sys.stdout, overwrite=True))

   

# Generated at 2022-06-10 21:39:53.761947
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # TODO: construct object for Tracer and call __call__
    raise NotImplementedError()


# Generated at 2022-06-10 21:39:57.450194
# Unit test for function get_write_function
def test_get_write_function():
    p = pycompat.Path(__file__) / 'test_get_write_function.txt'

    def write_to_stderr(s):
        stderr = sys.stderr
        try:
            stderr.write(s)
        except UnicodeEncodeError:
            # God damn Python 2
            stderr.write(utils.shitcode(s))

    write_1 = get_write_function(None, False)
    write_2 = get_write_function(write_to_stderr, False)
    write_3 = get_write_function(sys.stderr, False)
    write_4 = get_write_function(p, False)
    write_5 = get_write_function(p, True)


# Generated at 2022-06-10 21:40:04.252118
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import shutil
    import os


# Generated at 2022-06-10 21:40:05.653944
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .common import TracerTest
    TracerTest.test_Tracer_trace()

# Generated at 2022-06-10 21:40:13.280699
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer(watch=('self', 'self.bar'))
    assert tracer.watch[0] == CommonVariable('self')
    assert isinstance(tracer.watch[1], Exploding)
    assert tracer.watch[1].expression == 'self.bar'
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info is False
    assert tracer.custom_repr == ()


# Generated at 2022-06-10 21:40:23.086832
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    output = io.StringIO()
    import sys
    import time
    from pysnooper.utils import truncate
    l = []
    flag = True
    time.sleep(1)
    @pysnooper.snoop(output=output,
                     watch=('flag', 'l', 'sys.path'))
    def foo():
        print(1)
        l.append(1)
        print(2)
        l.append(2)
        return
        print(3)
        l.append(3)
    foo(l)
    got = output.getvalue()

# Generated at 2022-06-10 21:40:29.821948
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f(x):
        return x
    frame = f.__code__.co_filename, f.__code__.co_firstlineno
    result = get_path_and_source_from_frame(frame)
    file_name, source = result
    assert file_name.endswith('frames.py')
    assert source[0].strip() == 'def f(x):'



# Generated at 2022-06-10 21:40:42.086724
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # from pysnooper import snoop
    # from pysnooper.tracer import tracer
    # from pysnooper.utils import utils
    # from pysnooper.snoop import snoop
    def _snoop_wrap_function(function):
        return function

    def _function_wrapper():
        pass

    def _generator_wrapper():
        pass

    class _dummy_threading:
        #
        # Combine the getattr methods in one class
        #
        class local:
            #
            # Fake the getattr method in local
            #
            def __init__(self, **kwargs):
                pass


# Generated at 2022-06-10 21:41:06.177380
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    from traceback import format_exception_only
    import types
    import os
    import sys
    import pycompat
    import functools
    import inspect
    import six
    import dis
    import itertools
    import threading
    import time
    import datetime
    import datetime_module
    import opcode
    import sys
    import types
    import traceback
    import datetime
    from types import ModuleType
    from . import utils
    from .eval_repr import get_repr

    class Exception_Repr(object):
        def __init__(self, exception):
            self.exception = exception


# Generated at 2022-06-10 21:41:11.547520
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import re, os, sys
    from pysnooper import snoop
    from pysnooper import utils

    class FakeStream(object):
        def __init__(self):
            self.lines = []

        def write(self, s):
            self.lines.append(s)

        def flush(self):
            pass

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, tb):
            return False

    @snoop
    def function(x):
        pass

    with FakeStream() as fs:
        function(10)
    # Check case when we pass different argument to function
    assert fs.lines[0].startswith('    Starting var:.. x = ')

# Generated at 2022-06-10 21:41:15.226018
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import unittest

    class Tracer___enter__Test(unittest.TestCase):
        def test_1(self):
            s = StringIO()
            tracer = Tracer(output=s)
            tracer.__enter__()
            self.assertEqual(
                s.getvalue(),
                u'\n'
                u'\n'
                u'    Source path:... {path}\n'.format(path=__file__)
            )

    unittest.main()


# Generated at 2022-06-10 21:41:20.571163
# Unit test for method trace of class Tracer
def test_Tracer_trace():

    # Creating mock objects with the appropriate attributes
    mock_code = MagicMock(spec=types.CodeType)
    mock_frame = MagicMock()
    # Adding attributes and setting return values
    mock_frame.f_code = mock_code
    mock_frame.f_lineno = 0
    mock_code.co_filename = "test_Tracer_trace.py"
    mock_code.co_code = b'\x64\x00\x00\x00\x00\x00\x00\x00\x00'
    mock_code.co_firstlineno = 0
    mock_code.co_consts = None
    mock_code.co_names = None
    mock_code.co_varnames = None
    mock_code.co_freevars = None
    mock_code.co

# Generated at 2022-06-10 21:41:29.857578
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import unittest

    class TestTracer__exit__(unittest.TestCase):

        def setUp(self):
            pass


        def tearDown(self):
            pass


        def test__exit__(self):
            tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)


            with self.assertRaises(AttributeError):
                tracer.__exit__(None, None, None)


    unittest.main()


# Generated at 2022-06-10 21:41:40.946571
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import os.path
    import shutil
    with tempfile.TemporaryDirectory() as temp_dir:
        fw = FileWriter(os.path.join(temp_dir, 'foo.txt'), overwrite=True)
        fw.write(u'foo\n')
        fw.write(u'bar\n')
        fw.write(u'biz\n')
        with open(os.path.join(temp_dir, 'foo.txt'), 'r') as file:
            result = file.read()
        assert result == 'foo\nbar\nbiz\n'
        fw = FileWriter(os.path.join(temp_dir, 'foo.txt'), overwrite=False)
        fw.write(u'foo\n')

# Generated at 2022-06-10 21:41:54.445636
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from unittest import mock
    from pysnooper import utils

    output = mock.Mock()

    depth = 2
    prefix = 'ZZZ '
    overwrite = False
    thread_info = False
    custom_repr = (('a', 'b'), (1, 2))
    normalize = False
    relative_time = False

    def m_get_write_function(output, overwrite):
        return 'write function'

    def m_inspect_isclass(x):
        return x == 'class'

    def m_inspect_isfunction(x):
        return x == 'function'

    def m_inspect_isgeneratorfunction(x):
        return x == 'generator'

    def m_wrap(x):
        return 'wrapped %s' % x


# Generated at 2022-06-10 21:42:03.189396
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import collections
    import inspect
    import os
    import six
    import sys
    import time
    import traceback
    import unittest
    import types
    import uuid
    import warnings
    import zlib
    DISABLED = True
    def get_write_function(output, overwrite):
        if output == '-':
            return sys.stdout.write
        elif output is None and not overwrite:
            return lambda s: None
        else:
            file_object = (
              open(output, 'w' if overwrite else 'a')
            if output else sys.stdout)
            return file_object.write
    def humanize_timedelta(timedelta):
        if not isinstance(timedelta, pycompat.datetime_timedelta):
            timedelta = pycompat.datetime_

# Generated at 2022-06-10 21:42:04.470346
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test for method __call__ of class Tracer
    assert True

# Generated at 2022-06-10 21:42:09.946765
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    t = Tracer()
    f = t._wrap_function(unwrap(f1))
    assert f.__name__ == "f1"
    assert f.__doc__ == "f1 docstring"
    f = t(unwrap(f1))
    assert f.__name__ == "f1"
    assert f.__doc__ == "f1 docstring"

