

# Generated at 2022-06-10 21:33:13.365185
# Unit test for constructor of class Tracer
def test_Tracer():

    def foo():
        return 5 + 1

    tracer = Tracer()
    tracer.write = mock.Mock()

    with tracer:
        foo()


# Generated at 2022-06-10 21:33:22.376770
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def method_trace(self, frame, event, arg):
        calling_frame = inspect.currentframe().f_back
        if not self._is_internal_frame(calling_frame):
            calling_frame.f_trace = self.trace
            self.target_frames.add(calling_frame)

        stack = self.thread_local.__dict__.setdefault('original_trace_functions', [])
        stack.append(sys.gettrace())
        self.start_times[calling_frame] = datetime_module.datetime.now()
        sys.settrace(self.trace)


    return method_trace


# Generated at 2022-06-10 21:33:28.577120
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_path_and_source(frame):
        return get_path_and_source_from_frame(frame)[0], \
            get_path_and_source_from_frame(frame)[1]

    def test_function():
        pass
    _, source = get_path_and_source(inspect.currentframe())
    assert re.search('^ *def test_function\(\)', source[2])



# Generated at 2022-06-10 21:33:30.251385
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    _test_Tracer_trace_no_args()
    _test_Tracer_trace_with_args()

# Generated at 2022-06-10 21:33:38.919303
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo(x):
        return x + 5
    assert get_path_and_source_from_frame(foo.__code__.co_consts[0])[0] == \
                                                              foo.__code__.co_filename
    assert get_path_and_source_from_frame(foo.__code__.co_consts[0])[1][1].strip() == \
                                                              'return x + 5'


# Generated at 2022-06-10 21:33:47.128529
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with pytest.raises(NotImplementedError, match='normalize is not supported with '):
        assert len(Tracer(normalize=True).trace(frame=None, event='call', arg=None)) == 6
    with pytest.raises(NotImplementedError, match='normalize is not supported with '):
        assert len(Tracer(normalize=True, thread_info=True).trace(frame=None, event='call', arg=None)) == 6
    assert len(Tracer().trace(frame=None, event='call', arg=None)) == 6

# Generated at 2022-06-10 21:33:57.767812
# Unit test for function get_write_function
def test_get_write_function():
    # Test default write function
    write_func = get_write_function(None, overwrite=False)
    assert 'stderr.write' in write_func.__name__
    # Test overwrite
    write_func = get_write_function('test.txt', overwrite=True)
    assert isinstance(write_func, FileWriter)
    # Test file write function
    write_func = get_write_function('test.txt', overwrite=False)
    assert isinstance(write_func, FileWriter)
    # Test callable
    def test_func(s):
        pass
    write_func = get_write_function(test_func, overwrite=False)
    assert write_func.__name__ == 'test_func'
    # Test writable stream

# Generated at 2022-06-10 21:34:08.463179
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test():
        a = [1,2,3]
        b = 4
        try:
            'abc'.abc()
        except:
            pass

    # Test with default arguments
    tracer = Tracer(depth=2, overwrite=False, thread_info=False)
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.watch = []
    tracer.target_codes = set([test.__code__])
    tracer.target_frames = set()
    with tracer:
        test()
    assert len(tracer.frame_to_local_reprs) == 2
    assert len(tracer.start_times) == 2
    assert len(tracer.target_codes) == 1
    assert len(tracer.target_frames)

# Generated at 2022-06-10 21:34:11.096345
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Tracer___exit__()
    print("\n##### test_Tracer___exit__() #####")
 
    myobject = Tracer()
    myobject.__exit__()

# Generated at 2022-06-10 21:34:23.084700
# Unit test for constructor of class Tracer
def test_Tracer():
    # max_variable_length

    # output
    # watch
    # watch_explode
    # depth
    # prefix
    # overwrite
    # thread_info
    # custom_repr

    with Tracer(max_variable_length=10):
        pass
    with Tracer(output=sys.stdout):
        pass
    with Tracer(watch=('x', 'y')):
        pass
    with Tracer(watch_explode=('x', 'y')):
        pass
    with Tracer(depth=5):
        pass
    with Tracer(prefix='123'):
        pass
    with Tracer(overwrite=True):
        pass
    with Tracer(thread_info=True):
        pass

# Generated at 2022-06-10 21:34:49.428587
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper

    def __Tracer___call___inner(function_or_class):
        ####
        import pysnooper
        ####

        if DISABLED:
            return function_or_class

        if inspect.isclass(function_or_class):
            return self._wrap_class(function_or_class)
        else:
            return self._wrap_function(function_or_class)

    @pysnooper.snoop()
    def __Tracer___call___outer():
        ####
        import pysnooper
        ####

        if DISABLED:
            return function_or_class

        if inspect.isclass(function_or_class):
            return self._wrap_class(function_or_class)

# Generated at 2022-06-10 21:35:05.269915
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import random

    from unittest.mock import patch

    class TestTracer(unittest.TestCase):

        def test_Tracer___call___1(self):
            with patch('pysnooper.snoop.get_path_and_source_from_frame') as  m1, \
                 patch('pysnooper.snoop.get_local_reprs') as  m2, \
                 patch('pysnooper.snoop.utils.get_shortish_repr') as  m3, \
                 patch('pysnooper.snoop.utils.truncate') as  m4, \
                 patch('pysnooper.snoop.get_write_function') as  m5:
                get_write_function_args = []
                expected

# Generated at 2022-06-10 21:35:15.595786
# Unit test for constructor of class Tracer
def test_Tracer():
    where = sys._getframe(1).f_code.co_name
    assert where == inspect.currentframe().f_code.co_name
    where = sys._getframe(2).f_code.co_name
    assert where == inspect.currentframe().f_code.co_name
    where = sys._getframe(3).f_code.co_name
    assert where == inspect.currentframe().f_code.co_name
    where = sys._getframe(4).f_code.co_name
    assert where == inspect.currentframe().f_code.co_name
    where = sys._getframe(5).f_code.co_name
    assert where == inspect.currentframe().f_code.co_name
    where = sys._getframe(6).f_code.co_name

# Generated at 2022-06-10 21:35:27.587187
# Unit test for constructor of class Tracer
def test_Tracer():
    # when no argument is given
    tracker = Tracer()
    assert tracker.watch == []
    assert tracker.depth == 1
    assert tracker.prefix == ''
    assert tracker.target_codes == set()
    assert tracker.target_frames == set()
    assert tracker.thread_local.__dict__ == {}
    assert tracker.custom_repr == ()
    assert tracker.last_source_path is None
    assert tracker.max_variable_length == 100
    assert tracker.normalize == False
    assert tracker.relative_time == False
    # when arguments are given

# Generated at 2022-06-10 21:35:31.495597
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def function():
        pass
    function()
    frame_record = sys._getframe()
    while frame_record:
        frame_record = frame_record.f_back
    assert get_path_and_source_from_frame(frame_record) != (None, None)



# Generated at 2022-06-10 21:35:37.800176
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo():
        x = 23
        return x
    x = 3
    def bar():
        x = 23
        return x
    bar()
    test_frame = inspect.currentframe()
    assert get_local_reprs(test_frame) == {'x': '23'}
    assert get_local_reprs(test_frame.f_back) == {'x': '3', 'foo': '<function test_get_local_reprs.<locals>.foo>'}
    assert get_local_reprs(test_frame.f_back.f_back) == {}



# Generated at 2022-06-10 21:35:53.902353
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    _test_Tracer___call___ = Tracer()
    def _test_Tracer___call___test_func():
        pass
    def _test_Tracer___call___test_func_with_decorator():
        pass
    _test_Tracer___call___test_func_with_decorator = _test_Tracer___call__(_test_Tracer___call___test_func_with_decorator)

    assert _test_Tracer___call___test_func == _test_Tracer___call___test_func
    assert _test_Tracer___call___test_func_with_decorator != _test_Tracer___call___test_func_with_decorator
    assert _test_Tracer___call___test_func_with_decorator.func_name

# Generated at 2022-06-10 21:36:06.340066
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        pass  # This is the line we'll ask a frame for
        pass
    frame = inspect.currentframe()
    def bar():
        return foo()
    bar()  # Creates a frame.

# Generated at 2022-06-10 21:36:14.987331
# Unit test for function get_write_function
def test_get_write_function():
    from .pycompat import PathLike
    write_function = get_write_function(None, False)
    assert callable(write_function)
    write_function = get_write_function(None, True)
    assert callable(write_function)
    write_function = get_write_function(sys.stderr, False)
    assert callable(write_function)
    write_function = get_write_function(sys.stderr, True)
    assert callable(write_function)
    write_function = get_write_function(os.getcwd(), False)
    assert callable(write_function)
    write_function = get_write_function(os.getcwd(), True)
    assert callable(write_function)

# Generated at 2022-06-10 21:36:26.406867
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .utils import get_shortish_repr
    from .common import CommonVariable
    from .exploding import Exploding
    from .base import BaseVariable
    from . import DISABLED
    print('')
    # Test with a real function
    @snoop
    def foo(a, b):
        return a + b
    foo(1, b=2)
    # Test with our mocked Tracer
    tracer = Tracer()
    tracer.trace(frame=object(), event='exception', arg=(None, None, None))
    tracer.trace(frame=object(), event='return', arg=None)
    tracer.trace(frame=object(), event='call', arg=None)
    tracer.write('')
    # Test with snoop

# Generated at 2022-06-10 21:36:43.610179
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    doctest.testmod(verbose=False, optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-10 21:36:48.174067
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f(x, y):
        return x * y
    assert get_path_and_source_from_frame(f.__code__.co_filename,
                                          f.__code__.co_firstlineno)



# Generated at 2022-06-10 21:37:03.521805
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Traceback: __call__ -> _wrap_class
    # Importing pdb so that it doesn't mess with the current stack frame
    # (it can be imported multiple times)
    import pdb
    import sys

    def function_dummy(x):
        """Docstring of function_dummy"""
        return x

    class_dummy = type(
        'class_dummy', (object,), {
            '__doc__': 'Docstring of class_dummy',
            'function_dummy': function_dummy,
        }
    )

    functools.wraps(function_dummy)

    inspect.isgeneratorfunction(function_dummy)

    # Calling function: _wrap_function
    # Calling function: _wrap_function
    # Calling function: get_write_function

# Generated at 2022-06-10 21:37:11.027871
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    def the_function(x, y):
        a = 3
        for i in range(5):
            if i > 2:
                break
            a += x + y
        else:
            a = 5
        return a

    assert('test_get_path_and_source_from_frame' ==
           inspect.currentframe().f_code.co_name)
    assert(get_path_and_source_from_frame(inspect.currentframe())[0] ==
           inspect.getabsfile(the_function))



# Generated at 2022-06-10 21:37:21.879386
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test call
    # Test return without exception
    # Test exception
    # Test return at the end of a program

    def _reset_global_state():
        thread_global.depth = -1
        trace.frame_to_local_reprs = {}
        trace.start_times = {}
        trace.target_codes = set()
        trace.target_frames = set()
        trace.last_source_path = None
        trace.thread_info_padding = 0
        trace.thread_local = threading.local()

    def _return_value(x):
        return x

    def _exception_raising(x):
        raise ValueError('hello')

    def _test_single_event(event, func, line_no=None):
        _reset_global_state()

# Generated at 2022-06-10 21:37:25.286552
# Unit test for constructor of class Tracer
def test_Tracer():
    """test_Tracer"""
    @Tracer(depth=1)
    def f():
        return
    assert f() is None
    @Tracer(depth=1)
    def g():
        import logging
        logging.info('foo')
    assert g() is None


# Generated at 2022-06-10 21:37:29.884665
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo(): pass
    assert get_path_and_source_from_frame(inspect.currentframe()) == \
           (__file__, open(__file__, 'r', encoding='utf-8').read().splitlines())



# Generated at 2022-06-10 21:37:41.356276
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def function():
        pass
    self = Tracer()
    self.__init__ = Tracer.__init__
    self._is_internal_frame = Tracer._is_internal_frame
    frame = inspect.currentframe()
    self.target_codes = set()
    self.target_frames = set()
    self.watch = []
    self.start_times = {}
    self.depth = 1
    self.normalize = False
    self.relative_time = False
    self.prefix = ''
    self.frame_to_local_reprs = {}
    self.thread_info = False
    self.thread_info_padding = 0
    self.custom_repr = []
    self.max_variable_length = 100
    self.target_codes.add(function.__code__)

# Generated at 2022-06-10 21:37:42.953076
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer()
    tracer.__enter__()


# Generated at 2022-06-10 21:37:51.907696
# Unit test for function get_local_reprs
def test_get_local_reprs(): # pragma: no cover
    from . import jupytertools
    from .variables import CommonVariable

    my_name = 'Shahar Azulay'
    name_variable = CommonVariable(name='name', default=None, length=5)
    address_variable = CommonVariable(name='address', default=None, length=15)

    def f(x):
        my_address = 'some_address'
        name_variable.set(my_name)
        address_variable.set(my_address)
        return 2 * x

    d = {'name': 'Guy'}


    my_address = 'some_address'

    print('\nNames:\n')
    print(get_local_reprs(frame=f.__code__.__code__.__getattribute__('__frame__')))

# Generated at 2022-06-10 21:38:26.613919
# Unit test for constructor of class Tracer
def test_Tracer():
    test_tracer = Tracer()


# Generated at 2022-06-10 21:38:42.167409
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import functools
    import inspect
    import threading
    class Snooper:
        def __init__(self):
            self.t = Tracer(prefix='my_prefix')
        def __call__(self, function_or_class):
            t = self.t
            if DISABLED:
                return function_or_class
            if inspect.isclass(function_or_class):
                return self._wrap_class(function_or_class)
            else:
                return self._wrap_function(function_or_class)

# Generated at 2022-06-10 21:38:53.853652
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    from contextlib import contextmanager
    from test import support
    from test import test_snoop as test_snoop
    from test.support.script_helper import assert_python_ok
    from test.support import threading_helper
    from pysnooper import snoop
    from unittest import mock
    from types import ModuleType
    import threading
    import os
    import re
    import sys
    from test.support import captured_stdout
    from contextlib import contextmanager
    from pysnooper import snoop
    import pytest
    @snoop()
    def foo(a, b):
        foo.called_with = (a, b)
        return a + b
    assert_python_ok('-m', 'test.test_snoop')

# Generated at 2022-06-10 21:39:04.779001
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = False
    global thread_global
    thread_global = threading.local()
    global datetime_module
    datetime_module = mock.MagicMock()
    global get_write_function
    get_write_function = mock.MagicMock()
    global inspect
    inspect = mock.MagicMock()
    inspect.currentframe().f_back.f_trace = mock.MagicMock()
    inspect.currentframe().f_back.f_back = mock.MagicMock()
    inspect.isclass.return_value = True
    inspect.isfunction.return_value = True
    inspect.isgeneratorfunction.return_value = True
    inspect.iscoroutinefunction.return_value = True
    inspect.isgenerator.return_value = True

# Generated at 2022-06-10 21:39:13.136232
# Unit test for function get_local_reprs
def test_get_local_reprs():
    x = 3
    def f():
        x=5
        y=6
        z=7
        g()
    def g():
        x=9
        h()
        return 'g'
    def h():
        return 'h'

    frame = inspect.currentframe().f_back.f_back.f_back.f_back.f_back
    assert get_local_reprs(frame, max_length=5) == {'x': '5', 'y': '6', 'z': '7', 'g': '<function...>'}
    assert get_local_reprs(frame, max_length=8) == {'x': '5', 'y': '6', 'z': '7', 'g': '<function...>'}

# Generated at 2022-06-10 21:39:24.624255
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, overwrite=None) is sys.stderr.write
    assert get_write_function(sys.stderr, overwrite=None) is sys.stderr.write
    with open('test_output.txt', 'w') as test_output_file:
        assert get_write_function(test_output_file, overwrite=None) == test_output_file.write
    with open('test_output.txt', 'w') as test_output_file:
        write_func = get_write_function(test_output_file, overwrite=True)
        write_func('test')
    assert open('test_output.txt', 'r').read() == 'test'

# Generated at 2022-06-10 21:39:30.999784
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    try:
        with pysnooper.snoop() as snoop:
            raise RuntimeError('test_Tracer_trace')
    except RuntimeError:
        pass
    lines = [l for l in snoop.output_file if 'Exception:.....' in l]
    assert len(lines) == 1
    assert 'test_Tracer_trace' in lines[0]


# Generated at 2022-06-10 21:39:41.040526
# Unit test for constructor of class Tracer
def test_Tracer():
    t = Tracer(watch=())
    assert t.watch == ()

    t = Tracer(watch='foo')
    assert t.watch == ('foo',)

    t = Tracer(watch=['foo'])
    assert t.watch == ('foo',)

    t = Tracer(watch=('foo',))
    assert t.watch == ('foo',)

    t = Tracer(watch=('foo', 'bar'))
    assert t.watch == ('foo', 'bar')

    t = Tracer(watch=['foo', 'bar'])
    assert t.watch == ('foo', 'bar')

    t = Tracer(watch=['foo', 'bar'], watch_explode=('baz', 'quux'))
    assert t.watch == ('foo', 'bar', 'baz', 'quux')

    t

# Generated at 2022-06-10 21:39:47.508688
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import types
    tracer = Tracer()
    def f(x):
        return x + 1
    def f_with_decorator(x):
        return x + 1
    f_with_decorator = tracer(f_with_decorator)
    f_with_decorator(1)
    assert type(f_with_decorator) == types.FunctionType
    assert f_with_decorator(1) == 2


# Generated at 2022-06-10 21:40:03.173082
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import os
    import tempfile
    try:
        import IPython
    except ImportError:
        return

    def get_frame_and_file(file_name, contents):
        ipython_shell = IPython.get_ipython()
        ipython_shell.run_cell(contents, silent=True)
        frame = get_frame_and_file.fake_frame()
        frame.f_code.co_filename = file_name
        return frame, os.path.abspath(file_name)

    # Testing IPython
    with open(__file__, 'rb') as source_file:
        source_text = source_file.read().decode('utf-8')
    for i in range(2):
        file_name = tempfile.mkstemp()[1]

# Generated at 2022-06-10 21:41:40.906196
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import collections
    import threading

    def test(param, watch, expected_outputs):
        class Foo(object):
            @pysnooper.snoop(*watch)
            def foo(self):
                param = param
                bar()

        def bar():
            pass

        old_stdout = sys.stdout
        try:
            sys.stdout = out = StringIO()
            foo = Foo()
            foo.foo()
        finally:
            sys.stdout = old_stdout

        outputs = out.getvalue().splitlines()
        assert outputs == expected_outputs


# Generated at 2022-06-10 21:41:49.502435
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        path = f.name

    fw = FileWriter(path, overwrite=True)
    fw.write('hello')
    with open(path, 'r') as f:
        assert f.read() == 'hello'
    fw.write('world')
    with open(path, 'r') as f:
        assert f.read() == 'helloworld'



# Generated at 2022-06-10 21:42:00.175441
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import io
    import re
    import contextlib
    import unittest
    original_stdout = sys.stdout
    try:
        sys.stdout = io.StringIO()
        output_stream = sys.stdout
        @pysnooper.snoop(output_stream=output_stream)
        def func(): pass
    finally:
        sys.stdout = original_stdout
        output_stream = sys.stdout
    func()
    output = output_stream.getvalue()
    match = re.search(r'Source path:... (\S+)', output)
    assert match
    source_path = match.group(1)
    assert source_path.endswith(__file__)
    assert 'func()' in output
    assert 'Return value:.. None' in output

# Unit test

# Generated at 2022-06-10 21:42:11.095585
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys, argparse, threading
    from functools import reduce
    from pysnooper.utils import get_shortish_repr, pycompat

    def func(a, b):
        # I'll put the actual doctest in the next line
        '''       ===> test_tracer.py <===
        line no: 11
        Local var:.. (a, b) = (1, 2)
        Exception:.. TypeError("unsupported operand type(s) for +: 'int' and 'str'",)
        '''
        aa = a
        cc = a + b
        dd = b + a
        bb = b
        return a
    test_dict = {}
    parser = argparse.ArgumentParser()

# Generated at 2022-06-10 21:42:20.426737
# Unit test for function get_write_function
def test_get_write_function():

    # test with sys.stderr
    output = sys.stderr
    output.write = lambda s: None  # this is so tests won't write to stderr
    write_function = get_write_function(output, False)
    assert callable(write_function)

    # test with file object
    write_function = get_write_function(open(os.devnull), False)
    assert callable(write_function)

    # test with function
    def write_to_default(s):
        sys.stderr.write(s)
    write_function = get_write_function(write_to_default, False)
    assert callable(write_function)

    # test with an error

# Generated at 2022-06-10 21:42:22.233788
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(AttributeError):
        pysnooper.snoop(foo=1)



# Generated at 2022-06-10 21:42:23.267747
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass


# Generated at 2022-06-10 21:42:24.452232
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    assert False # TODO: implement your test here


# Generated at 2022-06-10 21:42:36.232930
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .utils import MockProcessor
    from .utils import assert_log_equal
    import pytest

    @pysnooper.snoop(watch=('self', 'self.foo'), depth=3)
    def outer(foo):
        def nested(bar, baz):
            return bar, baz
        return nested(foo, 4)

    class Foo:
        def __init__(self):
            self.foo = 'foo'

        def method(self):
            return self

    with assert_log_equal(__file__, 'test_Tracer_trace',
                          normalize=True):
        mock_processor = MockProcessor()
        mock_processor.write = mock_processor.mock_write
        mock_processor.write = mock_processor.mock_write
        mock_processor.thread_info = False