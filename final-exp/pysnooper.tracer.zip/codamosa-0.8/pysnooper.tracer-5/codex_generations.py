

# Generated at 2022-06-10 21:33:30.940973
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from os.path import basename
    from pysnooper.snoopdist import SnoopDist
    from pysnooper.utils import truncate
    from unittest import mock
    from unittest.mock import call
    import inspect
    import io
    import os
    mock_string_io = mock.Mock(spec=io.StringIO)
    mock_string_io().__exit__.return_value = None
    mock_string_io().__enter__.return_value = sentinel.string_io
    mock_output = mock.Mock(spec=SnoopDist)
    mock_output().__exit__.return_value = None
    mock_output().__enter__.return_value = sentinel.output
    mock_stdout = mock.Mock(spec=io.StringIO)
    mock

# Generated at 2022-06-10 21:33:38.155470
# Unit test for function get_write_function
def test_get_write_function():
    output = sys.stderr
    assert get_write_function(output, overwrite=False) == output.write
    from io import BytesIO
    output = BytesIO()
    assert get_write_function(output, overwrite=False)(b'bla') == None
    assert output.getvalue() == b'bla'



# Generated at 2022-06-10 21:33:47.083847
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Default arguments for Tracer.__init__
    tr = Tracer()
    def foo(x):
        return x
    def bar():
        return foo(test_Tracer_trace.x)
    tr.trace(bar.__code__, 'call', None)
    x = 1
    y = 2
    assert tr.frame_to_local_reprs == {inspect.currentframe(): {'x': '1',
                                                                'y': '2',
                                                                'tr': 'pysnooper.New(/home/simon/Code/pysnooper/pysnooper/pysnooper.py, Tracer)'}}
    tr.write = mock.Mock()
    tr.trace(bar.__code__, 'line', None)
    tr.write.assert_called_with

# Generated at 2022-06-10 21:33:57.756228
# Unit test for constructor of class Tracer
def test_Tracer():
    # Check that different cases of variable assignment are handled correctly
    @pysnooper.snoop()
    def test_one():
        function_local_var = 'local variable'
        a.b.c.d = 'd'

    @pysnooper.snoop()
    def test_two():
        a = b = c = d = 'd'
        b = 'b'

    @pysnooper.snoop()
    def test_three():
        l = []
        l.append('something')
        l.append('something else')

    # Check that variables in other function's scope aren't reported
    @pysnooper.snoop()
    def test_four():
        a = 'outer scope'
        def inner_function():
            a = 'inner scope'

        inner_function()



# Generated at 2022-06-10 21:34:08.462450
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper.utils import shortish_repr
    import traceback
    import threading
    import datetime
    import sys
    import os
    import inspect
    import functools
    import pycompat
    import pysnooper.utils as utils

    # Placeholder for assertion-free unit tests
    pass

    # Placeholder for TestCase subclasses
    class TestCase_Tracer_trace(unittest.TestCase):
        pass

    # Unit tests for Tracer.trace
    class Test_Tracer_trace(TestCase_Tracer_trace):

        # Thorough tests for method update_repr
        def test_update_repr(self):
            snooper = Tracer(watch=['test_a', 'test_b'])
            frame = MockFrame()
            # test_a was already

# Generated at 2022-06-10 21:34:11.731703
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # If a function definition is actually missing, but the function call is
    # there, we're screwed. The following test case helps ensure this doesn't
    # happen.
    def s():
        @pysnooper.snoop()
        def _():
            1
        _()

    s()

# Generated at 2022-06-10 21:34:23.576170
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    #Test vaild input
    frame = frame = inspect.currentframe()
    event = 'call'
    arg = None
    tracer = Tracer(watch=('a', 'b'))
    (sys.gettrace())()
    tracer.trace(frame, event, arg)
    frame = frame = inspect.currentframe()
    event = 'call'
    arg = None
    tracer = Tracer(watch=('a', 'b'), custom_repr=((type(int), lambda x : x * 2), (1, lambda x : x * 3)))
    (sys.gettrace())()
    tracer.trace(frame, event, arg)
    #Test invaild input
    frame = frame = inspect.currentframe()
    event = 'call'
    arg = None

# Generated at 2022-06-10 21:34:35.386576
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Tracer.__call__(self, function_or_class)
    from unittest import TestCase
    from io import StringIO
    from pysnooper.tracing import Tracer
    from pysnooper.utils import get_write_function
    from pysnooper.pycompat import PY2
    
    class TestTracer(TestCase):
        # test for method __call__ of class Pysnooper
        def test_call(self):
            # test for method __call__ of class Pysnooper
            def f1(x, y):
                pass
            def f2(z):
                pass
            def g1(x, y):
                return f1(x, y)
            def g2(x, y):
                return f2(x), f2(y)

# Generated at 2022-06-10 21:34:47.245206
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper import snoop
    trace_info = {}
    import inspect
    import sys
    
    def decorate_func():
        """
        This function is used to decorate trace_example
        """

        def trace_example(watch_args, watch_kwargs):
            """
            This function is used to demonstrate the behavior of method
            trace. We assume that trace_example is decorated by snoop.

            Note: Because of the limitation of our test framework, we cannot
            call snoop to decorate trace_example, so we also need to
            decorate it by decorate_func. 
            """
            def inner_func():
                """
                This function is used to demonstrate the behavior of method
                trace. We assume that inner_func is in the same frame as
                trace_example.
                """

# Generated at 2022-06-10 21:35:02.781656
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    class Main():
        def __init__(self, v):
            self.v = v

        def fun(self):
            return self.v

    t = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)

    # Test case 1
    @t
    def fun():
        return
    try:
        fun()
    except:
        pass

    # Test case 2

# Generated at 2022-06-10 21:35:20.050374
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-10 21:35:20.749503
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass


# Generated at 2022-06-10 21:35:22.213775
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Test original functionality for this method
    pass

# Generated at 2022-06-10 21:35:31.721052
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from inspect import currentframe
    frame = currentframe()
    this_file_name = __file__ if not __file__.endswith(('.pyc', '.pyo')) else \
        __file__[:-1]
    assert get_path_and_source_from_frame(frame)[0] == this_file_name
    assert get_path_and_source_from_frame(frame)[1][1] == \
           'def test_get_path_and_source_from_frame():'
test_get_path_and_source_from_frame()


_MAX_LINES_FULL_CALL_EXAMPLE_PRETTY_PRINT = 5



# Generated at 2022-06-10 21:35:39.248725
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import sys
    import types
    import inspect
    import os
    import threading
    import datetime
    import functools
    import pysnooper.utils
    import pysnooper.compat as pycompat
    import pysnooper.watch
    import io
    import pysnooper.threading_local
    import pysnooper.dis
    import pysnooper.unicode_literals
    from pysnooper import DISABLED
    output_stream = io.StringIO()
    depth = 1
    prefix = ""
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False


# Generated at 2022-06-10 21:35:46.069616
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Set up the test object.
    test_obj = Tracer()
    test_obj.watch = ['x']
    test_obj.depth = 2
    # Calling the method with the test object and example arguments
    # produces an AssertionError.
    # test_obj.trace(frame, event, arg)

# Generated at 2022-06-10 21:35:58.423339
# Unit test for function get_write_function
def test_get_write_function():
    from .utils import StringStream
    from .stack_dump import StackDump
    output = StringStream()
    string = '''hello'''
    write_function = get_write_function(output, False)
    write_function(string)
    if output.getvalue() != '''hello''':
        raise Exception("String wasn't the same.")
    else:
        print("String is the same")
    output = StringStream()
    string = '''olleh'''
    write_function = get_write_function(output, False)
    write_function(string)
    if output.getvalue() != '''olleh''':
        raise Exception("String wasn't the same.")
    else:
        print("String is the same")
    output = '''hello'''
    string = '''olleh'''


# Generated at 2022-06-10 21:36:13.817400
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    output = io.StringIO()
    t = Tracer(output)
    test_f_locals = {'a': 1, 'b': 2, 'c': 3}
    test_f_code = {'co_filename': 'hypothetical_test_file.py'}
    test_f_globals = {'argv': 'hypothetical_test_globals'}
    f = FrameType(test_f_locals, test_f_globals, 'failed_line', test_f_code)
    exc = (ArithmeticError, ArithmeticError('raised error during test'),
           traceback.extract_stack())
    # test_trace_return_no_error

# Generated at 2022-06-10 21:36:25.061822
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import inspect
    import functools
    import threading
    class Trace:
        def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
                     prefix='', overwrite=False, thread_info=False, custom_repr=(),
                     max_variable_length=100, normalize=False, relative_time=False):
            assert isinstance(watch, tuple)
            assert isinstance(watch_explode, tuple)
            assert isinstance(depth, int)
            assert isinstance(prefix, str)
            assert isinstance(overwrite, bool)
            assert isinstance(thread_info, bool)
            assert isinstance(custom_repr, tuple)
            assert isinstance(max_variable_length, int)
            assert isinstance(normalize, bool)

# Generated at 2022-06-10 21:36:34.809929
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # We'll test by calling foo() below. First, we'll get foo's source path and
    # source.
    foo_source_path, foo_source = get_path_and_source_from_frame(
        inspect.currentframe().f_back,
    )

    @pysnooper.snoop()
    def foo():
        return 3

    # We'll open a StringIO to pretend it's a log file.
    file_like_object = io.StringIO()
    tracer = Tracer(output=file_like_object)

    @pysnooper.snoop()
    def bar():
        with tracer:
            foo()

    # We'll call bar() to trigger Snooper.
    bar()

    # Now we'll read the "log" file.
    log_lines = file_like_object

# Generated at 2022-06-10 21:37:06.352682
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import sys
    import io
    import os
    import random
    import tempfile

    import pysnooper

    class TestTracer___call__(unittest.TestCase):
        def setUp(self):
            self.real_stdout_fd = sys.stdout.fileno()
            self.real_stdout = os.fdopen(os.dup(self.real_stdout_fd))
            self.fake_stdout = io.StringIO()
            os.dup2(self.fake_stdout.fileno(), sys.stdout.fileno())
            self.real_stderr_fd = sys.stderr.fileno()
            self.real_stderr = os.fdopen(os.dup(self.real_stderr_fd))
            self

# Generated at 2022-06-10 21:37:17.624340
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper
    from contextlib import contextmanager
    from mock import Mock
    import sys

    class MyClass(object):
        def __init__(self):
            self.write = Mock()

        def __enter__(self):
            pass

        @pysnooper.snoop(depth=2)
        def foo(self):
            with self.foo_routine(123) as dummy:
                yield dummy

        @pysnooper.snoop(depth=2)
        def foo_routine(self, x):
            y = 2 * x
            with contextmanager_function() as dummy:
                yield dummy

        @contextmanager
        def foo_routine_contextmanager(self, x):
            y = 2 * x

# Generated at 2022-06-10 21:37:27.041358
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.write = MagicMock()
    tracer.start_times = {inspect.currentframe().f_back: datetime_module.datetime.now()}
    tracer.depth = 5
    tracer.max_variable_length = 100
    tracer.thread_info = True
    tracer.thread_info_padding = 10
    tracer.target_codes = set()
    tracer.target_frames = set()
    tracer.last_source_path = None
    tracer.frame_to_local_reprs = {}
    tracer.thread_local = threading.local()
    tracer.custom_repr = None


# Generated at 2022-06-10 21:37:38.884903
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # IMPORTS
    from _ast import Raise
    import ast
    import sys
    import timeit
    import unittest


    # BODY
    def _is_internal_frame(frame):
        return frame.f_code.co_filename == Tracer.__enter__.__code__.co_filename
    def _is_internal_frame_orig(frame):
        return frame.f_code.co_filename == Tracer.__enter__.__code__.co_filename

    def test_is_internal_frame(benchmark):
        benchmark(_is_internal_frame)

    def test_is_internal_frame_orig(benchmark):
        benchmark(_is_internal_frame_orig)


# Generated at 2022-06-10 21:37:48.883843
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import os
    import random
    import re
    import tempfile
    import unittest
    import shutil

    from unittest.mock import Mock, patch

    from pysnooper import utils, pycompat

    def run_test(output='stdout', overwrite=False):
        def some_function():
            return 1
        # output is not None
        if output is 'stdout':
            stdout = open(os.devnull, 'w')
            with patch('sys.stdout', stdout), \
                 patch('sys.stderr', stdout):
                with Tracer(output=output, overwrite=overwrite):
                    some_function()
        elif output is None:
            with Tracer(output=output, overwrite=overwrite):
                some_function()

# Generated at 2022-06-10 21:37:53.747131
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper import snoop
    global DISABLED
    DISABLED = False
    def my_func():
        a = 1
    snoop_obj = snoop()
    calling_frame = my_func.__code__.co_firstlineno
    frame = inspect.currentframe()
    frame = frame.f_back
    event = 'call'
    global_thread_global = thread_global
    snoop_obj.trace(frame, event, None)
    DISABLED = True


# Generated at 2022-06-10 21:38:06.509811
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper
    pysnooper.snoop(prefix=None, overwrite=True, watch_explode=('foo', 'self'), depth=2,
                    output=None, thread_info=False,
                    custom_repr=(), max_variable_length=100, normalize=False,
                    relative_time=False)
    def main():
        class TestClass(object):
            def __init__(self):
                self._foo = 0
            def method(self):
                foo = self._foo
                foo += 10
                self._foo = foo
        tc = TestClass()
        tc.method()
    main()


#class SnoopMeta(type):
#    '''
#    SnoopMeta is a metaclass that makes the @pysnooper.snoop decorator
#    work on classes

# Generated at 2022-06-10 21:38:13.212064
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(NotImplementedError):
        Tracer(thread_info=True, normalize=True)
    Tracer(thread_info=True)
    Tracer(thread_info=False)
    Tracer(normalize=True)
    Tracer(normalize=False)


# Generated at 2022-06-10 21:38:25.774769
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def test_basic():
        from pysnooper import snoop
        @snoop(watch='x')
        def foo(y):
            x = 123
            y = 456
            return y
        global_variables = globals()
        foo(333)
        # test_basic uses a normal global variable named 'globals', which
        # isn't accessible in the snooped function, so this shouldn't appear
        # in output
    def test_depth():
        from pysnooper import snoop
        @snoop(watch='x', depth=2)
        def foo():
            x = 123
            bar()
        @snoop()
        def bar():
            pass
    def test_decorating_class():
        from pysnooper import snoop

# Generated at 2022-06-10 21:38:41.325588
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    import unittest.mock
    import time
    with unittest.mock.patch.object(sys, 'settrace') as settrace:
        with unittest.mock.patch('datetime.datetime') as datetime_mock:
            with unittest.mock.patch.object(time, 'time') as time:
                time.return_value = 0.0
                datetime_mock.now().__gt__.return_value = True
                tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                                prefix='', overwrite=False, thread_info=False, custom_repr=(),
                                max_variable_length=100, normalize=False, relative_time=False)

# Generated at 2022-06-10 21:39:25.282179
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    output=None
    watch=()
    watch_explode=()
    depth=1
    prefix=''
    overwrite=False
    thread_info=False
    custom_repr=()
    max_variable_length=100
    normalize=False
    relative_time=False
    snooper_obj = Tracer(output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr, max_variable_length, normalize, relative_time)
    frame = inspect.currentframe()
    event = 'call'
    arg = None
    snooper_obj.trace(frame, event, arg)


# Generated at 2022-06-10 21:39:35.865052
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def getting_the_source_from_frame():
        def this_is_the_source():
            pass
        return get_path_and_source_from_frame(inspect.currentframe())
    result = getting_the_source_from_frame()

# Generated at 2022-06-10 21:39:40.256244
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    a = 1
    # b = 2
    # c = 3
    # d = 4

    tracer = Tracer()
    tracer.trace(None, None, None)

#     self.assertEqual(expected, tracer.trace(None, None, None))
    raise NotImplementedError()


# Generated at 2022-06-10 21:39:43.345907
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def trace_test():
        pass

    f = Tracer()
    f.trace(frame, "call", None)
    f.trace(frame, "exception", None)
    f.trace(frame, "return", None)


# Generated at 2022-06-10 21:39:55.958900
# Unit test for constructor of class Tracer
def test_Tracer():
    import StringIO

    output = StringIO.StringIO()
    a = Tracer(output=output)
    assert a.watch == ()
    assert a.depth == 1
    assert a.prefix == ''
    assert a.thread_info == False
    assert a.custom_repr == ()
    assert a.normalize == False
    assert a.max_variable_length == 100
    assert a.relative_time == False

    b = Tracer(output=output, watch='a', watch_explode='b', depth=2, prefix='X',
               thread_info=True, custom_repr=((type, lambda x: 'y'),),
               max_variable_length=50, normalize=True, relative_time=True)
    assert b.watch == [CommonVariable('a')]

# Generated at 2022-06-10 21:40:04.930765
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import nose
    import nose.loader
    import tempfile

    with tempfile.NamedTemporaryFile('w', delete=False) as fp:
        fp.write('# coding: utf-16\nimport os\nprint(os.getcwd())')
    file_name, source = get_path_and_source_from_frame(
        inspect.currentframe()
    )
    assert source[1] == 'import os'
    os.remove(file_name)



# Generated at 2022-06-10 21:40:17.142335
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import _pytest.outcomes
    _pytest.outcomes.SKIPPED = "SKIPPED"
    pytest.SKIPPED = "SKIPPED"
    import builtins
    builtins.__dict__['DISABLED'] = True
    # Method call: __exit__
    self = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    exc_type = None
    exc_value = None
    exc_traceback = None
    self.depth = 0
    self.start_times[calling_frame] = start_time = datetime_module.datetime.now()
    duration = datetime_

# Generated at 2022-06-10 21:40:25.620535
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import sys
    def p(s):
        print(s)
    custom_write = FileWriter('path.txt', True)
    custom_write(u'Hello world!'.encode('utf-8'))
    custom_write(u'Hello world!2'.encode('utf-8'))
    with open(custom_write.path, 'r', encoding='utf-8') as f:
        print("Custom write:")
        print(f.read())
    print("End custom write")
    custom_write_2 = FileWriter(sys.stderr, True)
    custom_write_2(u'Hello world!'.encode('utf-8'))
    custom_write_2(u'Hello world!2'.encode('utf-8'))

# Generated at 2022-06-10 21:40:35.978637
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import pytest
    with pytest.raises(Exception) as excinfo:
        class _Temp:
            def __init__(self):
                pass

            @pysnooper.snoop(depth=2)
            def t4(self):
                return self.t3(1)

            def t3(self, a):
                return self.t2(self.t1(a))

            def t1(self, a):
                return a + a

            def t2(self, a):
                raise Exception()
    assert "Exception:..... " in str(excinfo.value)

# Generated at 2022-06-10 21:40:48.892053
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = pysnooper.Tracer()
    class Foo(object):
        def f1(self, x):
            a = x
            return a
        def f2(self, y):
            b = y
            return b
    test_obj = Foo()
    tracer.trace(test_obj.f1.__code__, 'call', None)
    tracer.trace(test_obj.f1.__code__, 'line', None)
    tracer.trace(test_obj.f2.__code__, 'call', None)
    tracer.trace(test_obj.f2.__code__, 'line', None)

if __name__ == '__main__':
    test_Tracer_trace()