

# Generated at 2022-06-20 12:25:41.894435
# Unit test for method write of class Tracer
def test_Tracer_write():
    def func(x): return x
    import sys
    tracer = Tracer(output=sys.stderr, watch=('x',))(func)
    with tracer:
        y = tracer.write("aa")
    return y


# Generated at 2022-06-20 12:25:53.517992
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    temprory_file = tempfile.NamedTemporaryFile(delete=False)
    temprory_file.close()
    temprory_file_name = temprory_file.name
    write_function = get_write_function(temprory_file_name, overwrite=True)
    write_function('test')
    with open(temprory_file_name) as f:
        assert f.read() == 'test'
    os.remove(temprory_file_name)
    write_function = get_write_function(sys.stderr, overwrite=False)
    write_function('test')
    write_function = get_write_function('/path/that/doesnt/exist/because/it/is/'
                                        'only/a/test', overwrite=True)


# Generated at 2022-06-20 12:26:02.432979
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1; b = 3; c = 4; a += b; d = a; local_var = 5
        return a
    frame = utils.get_caller_frame().f_back
    result = get_local_reprs(frame)
    assert result == {'a': '4', 'b': '3', 'c': '4', 'd': '4', 'local_var': '5'}
    result = get_local_reprs(frame, max_length=10)
    assert result == {'a': '4', 'b': '...', 'c': '...', 'd': '...',
                      'local_var': '...'}
    result = get_local_reprs(frame, max_length=10, normalize=True)

# Generated at 2022-06-20 12:26:10.734048
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    x = 3
    y = 4
    def function():
        return x + y
    function_frame = function.__code__.co_firstlineno + 1
    assert get_path_and_source_from_frame(function.__globals__['__builtins__']) == (
        os.path.join(sys.prefix, 'lib', 'python{}.{}'.format(*sys.version_info[:2]),
                     'functools.py'),
        UnavailableSource()
    )
    function_filename, function_source = (
        get_path_and_source_from_frame(inspect.getouterframes(inspect.currentframe(), 1)[0][0])
    )

# Generated at 2022-06-20 12:26:23.316409
# Unit test for method write of class Tracer
def test_Tracer_write():
    import pytest
    from io import StringIO
    from pysnooper import snoop, snoop_log, utils

    stream = StringIO()
    assert stream.read() == ''

    @snoop(stream=stream)
    def test_method():
        a = 1
        b = 2
        c = a + b
        return c
    test_method()
    assert stream.read() == ('    Starting var:.. b = 2\n'
                             '    Starting var:.. a = 1\n'
                             '    New var:....... c = 3\n'
                             '    Return value:.. 3\n'
                             '    Elapsed time: 0:00:00.000000\n')

if (__name__ == '__main__'):  # If used as a script
    import sys
   

# Generated at 2022-06-20 12:26:26.884358
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'test'
    path_type = type(path)
    overwrite = True
    fw = FileWriter(path, overwrite)
    
    assert fw.path is path
    assert isinstance(fw.path, path_type)
    assert fw.overwrite is overwrite
    assert callable(fw.write)



# Generated at 2022-06-20 12:26:32.958376
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo():
        a = int(8)
        b = 'x' * 8
        c = [8]
        d = (8,)
        e = {8: 9}
        f = {8, 9}
        g = {8}
        return locals()
    if sys.version_info[0] == 2:
        assert get_local_reprs(foo()) == {
            'a': 'int(8)',
            'b': "u'xxxxxxxx'",
            'c': '[8]',
            'd': '(8,)',
            'e': '{8: 9}',
            'f': 'set([8, 9])',
            'g': 'set([8])',
            }

# Generated at 2022-06-20 12:26:34.890767
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:37.856755
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:42.426801
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io.StringIO()
    tracer = Tracer(output=output, prefix='ZZZ')
    tracer.write(u'foo')
    assert output.getvalue() == 'ZZZfoo\n'


# Generated at 2022-06-20 12:27:04.241362
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = inspect.currentframe()
    locals_ = frame.f_locals.copy()
    locals_.update({'variable_that_isnt_in_frame': 'bla'})
    for key, value in locals_.items():
        locals_[key] = utils.get_shortish_repr(value)

    local_reprs = get_local_reprs(frame, max_length=50, normalize=True)

    assert locals_ == local_reprs



# Generated at 2022-06-20 12:27:13.479309
# Unit test for function get_write_function
def test_get_write_function():
    s = b''
    write = get_write_function(s, None)
    write(b'hello')
    write(b'world')
    assert s == b'helloworld'
    s = b''
    write = get_write_function(s, False)
    write(b'hello')
    write(b'world')
    assert s == b'helloworld'
    s = ''
    write = get_write_function(s, False)
    write('hello')
    write('world')
    assert s == 'helloworld'
    s = b''
    write = get_write_function(s, True) # FileMode
    write(b'hello')
    write(b'world')
    assert s == b'helloworld'
    s = b''
    write = get_write_function

# Generated at 2022-06-20 12:27:15.151926
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:27:22.064238
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    import os
    import shutil
    from . import utils
    test_dir = tempfile.mkdtemp()
    test_path = os.path.join(test_dir, 'test_FileWriter.txt')
    test_writer = FileWriter(test_path, False)
    test_str = u'Hello World!'
    test_writer.write(test_str)

    (test_path_f, test_path_s) = utils.split_path(test_path)
    assert test_path_s == 'test_FileWriter.txt'
    assert os.path.exists(os.path.join(test_path_f, test_path_s))

    with open(test_path, 'r') as f:
        file_line = f.readline()
        assert file_line

# Generated at 2022-06-20 12:27:27.278123
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    fd, path = tempfile.mkstemp(prefix='shitpile_')
    fp = pycompat.open_with_closefd(fd, 'w')
    fp.write('aaa')
    fp.close()
    fw = FileWriter(path, overwrite=False)
    fw.write('bbb')
    fw.write('ccc')
    with pycompat.open_with_encoding(path, encoding='utf-8') as fp:
        assert fp.read() == 'aaabbbccc'



# Generated at 2022-06-20 12:27:30.330938
# Unit test for function get_local_reprs
def test_get_local_reprs():
    x = 1
    y = 'spam'
    result = get_local_reprs(inspect.currentframe(), ['x', CommonVariable('y')])
    assert result == {'x': '1', 'y': "'spam'"}



# Generated at 2022-06-20 12:27:40.041045
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    maxDiff = None
    tracer = Tracer(None)
    import io

    class Foo(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __repr__(self):
            return '<Foo({!r}, {!r})>'.format(self.a, self.b)

    @pysnooper.snoop()
    def get_foo(a, b):
        return Foo(a, b)

    foo = get_foo('bar', b='baz')
    foo_repr = repr(foo)

    output = io.StringIO()
    tracer._write = output.write
    with tracer:
        pass


# Generated at 2022-06-20 12:27:46.011975
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    f = pycompat.temp_file_name('-cute-test.txt')
    w = FileWriter(f, True)
    try:
        w.write('hello')
        assert open(f).read() == 'hello'
        w.write('there')
        assert open(f).read() == 'hello'+'there'
    finally:
        pycompat.remove_file(f)



# Generated at 2022-06-20 12:27:49.979805
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a_list = _common_stuff()
        return a_list
    expected_result = eval(repr({'a_list': [1, 2, 3, 4]}))
    assert get_local_reprs(f.__code__.co_firstlineno) == expected_result

# Generated at 2022-06-20 12:27:55.649557
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding('A') == 'A'
    assert tracer.set_thread_info_padding('A') == 'A '
    tracer.set_thread_info_padding('ABC')
    assert tracer.set_thread_info_padding('A') == 'A' * 3

# Generated at 2022-06-20 12:28:20.057869
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def test_function(a, b, c, d, e, f=4, g=5, h=6, i=7, j=8, k=9, l=10,
                      m=11, n=12, o=13, p=14, q=15, r=16, s=17, t=18, u=19,
                      v=20, w=21, x=22, y=23, z=24):
        pass

    frame = inspect.currentframe()
    # noinspection PyUnusedLocal
    old_frame = frame
    frame = frame.f_back
    # noinspection PyUnusedLocal
    old_frame = frame
    frame = frame.f_back
    # noinspection PyUnusedLocal
    old_frame = frame

# Generated at 2022-06-20 12:28:28.354231
# Unit test for constructor of class FileWriter
def test_FileWriter():
    output = 'test.txt'
    FileWriter(output, overwrite=True)
    assert (os.path.exists('test.txt'))
    with open(output, 'r') as f:
        assert (f.read() == '')
    FileWriter(output, overwrite=False).write('test')
    with open(output, 'r') as f:
        assert (f.read() == 'test')
    FileWriter(output, overwrite=True).write('test')
    with open(output, 'r') as f:
        assert (f.read() == 'test')



# Generated at 2022-06-20 12:28:31.146113
# Unit test for method write of class FileWriter

# Generated at 2022-06-20 12:28:38.540545
# Unit test for constructor of class Tracer
def test_Tracer():
    f = io.StringIO()
    with Tracer(f, watch=('foo', 'bar', 'baz')):
        pass
    assert f.getvalue() in {
        "Source path:... <string>\n"
        "    Call ended by exception\n",
        "Source path:... <string>\n"
        "    Call ended by exception\n"
        "Source path:... <string>\n"
        "    Call ended by exception\n",
    }
    f.close()

test_Tracer()


# Generated at 2022-06-20 12:28:43.990469
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    assert hasattr(tracer, 'write')

# Generated at 2022-06-20 12:28:55.401158
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # test case 1
    #
    # declaration of function and class
    #
    @pysnooper.snoop(watch = ('item', 'self'))
    class Class1(object):
        def __init__(self, item):
            self.item = item

        def method1(self):
            a = 1
            b = 2
            c = 3
            return a+b+c

    #
    # call of function to test
    #

# Generated at 2022-06-20 12:29:05.080653
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    try:
        tracer = Tracer()
    except AssertionError as err:
        pass

    tracer = Tracer(watch=1)
    tracer = Tracer(watch=([], {}))
    tracer = Tracer(watch=(1, []))
    tracer = Tracer(watch_explode=1)
    tracer = Tracer(watch_explode=([], {}))
    tracer = Tracer(watch_explode=(1, []))

    ## Test with normal function:
    def foo():
        pass
    snooped_foo = tracer(foo)
    try:
        snooped_foo()
    except TypeError:
        pass # expected when executing this test without the snooped function

    ## Test with generator function:
    def bar():
        yield None
    snooped_bar

# Generated at 2022-06-20 12:29:06.043028
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    pass


# Generated at 2022-06-20 12:29:17.722270
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo():
        x = 1
        y = [1, 2]
        class Bar:
            x = 2

        return x, y, Bar
    x, y, Bar = foo()
    frame = inspect.currentframe()
    frame = frame.f_back
    assert get_local_reprs(frame, max_length=8, normalize=True) == {'Bar': 'Bar',
                                                                    'y': '[1, 2]',
                                                                    'x': '1'}

# Generated at 2022-06-20 12:29:25.026537
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from . import curry
    old_get_path_and_source_from_frame = \
            curry.get_path_and_source_from_frame
    curry.get_path_and_source_from_frame = get_path_and_source_from_frame
    from . import testutils, test_curry
    try:
        testutils.run_tests(test_curry)
    finally:
        curry.get_path_and_source_from_frame = \
                old_get_path_and_source_from_frame



# Generated at 2022-06-20 12:29:48.392097
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()
    path = shutil.os.path.join(temp_dir, 'test_de_mypy_de_FileWriter_write.txt')
    file_writer = FileWriter(path, overwrite=True)
    file_writer.write('Hello, world!')
    assert utils.read_file(path) == 'Hello, world!'



# Generated at 2022-06-20 12:29:49.937422
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import doctest
    frame = inspect.currentframe()
    frame = frame.f_back
    print(get_path_and_source_from_frame(frame))
    doctest.testmod()



# Generated at 2022-06-20 12:29:56.994904
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import unittest

    class TestTracerTrace(unittest.TestCase):
        def setUp(self):
            self.tracer = Tracer()

        def test_Tracer_trace_return_value(self):
            # This is a bit messy, since we need a valid frame to pass into trace().

            # The following commented block was used for testing an older version
            # of Tracer.trace(), which needed a target_code to be passed in.
            #
            # def _get_frame_for_Tracer_trace(self):
            #     def _function_to_call():
            #         return inspect.currentframe()
            #     frame = _function_to_call()
            #     return frame

            import io
            with io.StringIO() as stream:
                tracer = Tracer(overwrite=stream)

# Generated at 2022-06-20 12:30:03.056625
# Unit test for constructor of class FileWriter
def test_FileWriter():
    try:
        import_test_class('.utils', 'WritableStream')
        file_writer = FileWriter('output', True)
        file_writer.write('cool')
        assert os.path.exists('output')
        with open('output', 'r') as f:
            assert f.read() == 'cool'
    except:
        print('test_FileWriter FAILED')
        raise
    finally:
        os.remove('output')


# Generated at 2022-06-20 12:30:08.865632
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import io

    # Capture output
    output = io.StringIO()
    sys.stdout = output

    tracer = pysnooper.snoop()
    tracer.write('This is a test')
    assert output.getvalue() == 'This is a test\n'
    output.close()


# Generated at 2022-06-20 12:30:18.616574
# Unit test for constructor of class Tracer
def test_Tracer():
    _ = Tracer()

# Define all the supported commands
_disable = pysnooper_module.disable
_enable = pysnooper_module.enable
_snoop = pysnooper_module.snoop
_clear_trace_functions = clear_trace_functions
_setLogger = pysnooper_module.setLogger

if __name__ == '__main__':
    print(bool(Tracer()))
    print(bool(Tracer()))
    print(Tracer.__name__)
    print(Tracer.__dict__)
    print(Tracer.__doc__)
    print(Tracer.__module__)
    print(bool(Tracer.__call__))
    print(bool(Tracer.__call__))
    test_Tracer()

# Generated at 2022-06-20 12:30:29.483149
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(sys.stderr, False)() is None
    assert get_write_function(None, False)() is None
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        with open(os.path.join(temp_dir, 'file_1.txt'), 'w') as file_1:
            file_1.write('old content')
        with open(os.path.join(temp_dir, 'file_2.txt'), 'w') as file_2:
            file_2.write('old content')
        write = get_write_function(os.path.join(temp_dir, 'file_1.txt'), False)
        write('new content')

# Generated at 2022-06-20 12:30:40.652270
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer_instance = Tracer()
    test_thread_info = 'test'
    padding_longer = 'test2'
    padding_longer_result = 'test2 '
    assert tracer_instance.set_thread_info_padding(test_thread_info) == test_thread_info
    tracer_instance._thread_info_padding = len(padding_longer)
    assert tracer_instance.set_thread_info_padding(test_thread_info) == test_thread_info + ' '
    tracer_instance._thread_info_padding = len(test_thread_info)
    assert tracer_instance.set_thread_info_padding(padding_longer) == padding_longer_result
    tracer_instance._thread_info_padding = 0
    assert tracer_instance.set_thread_info

# Generated at 2022-06-20 12:30:45.888058
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source_string = u'a = 5'
    source_lines = source_string.splitlines()
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[10] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[-1] == u'SOURCE IS UNAVAILABLE'
test_UnavailableSource___getitem__()



# Generated at 2022-06-20 12:30:56.072087
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    output = {}
    watch = []
    watch_explode = []
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False
    tracer = Tracer(output, watch, watch_explode, depth, prefix, overwrite,
                    thread_info, custom_repr, max_variable_length,
                    normalize, relative_time)
    tracer.thread_local = threading.local()
    tracer.thread_local.original_trace_functions = []
    output = {}
    watch = ['x']
    watch_explode = []
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()

# Generated at 2022-06-20 12:31:12.470295
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:19.498118
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import threading
    snoop = Tracer(thread_info=True)
    identifier = threading.get_ident()
    for name in ("1", "11", "22"):
        threading.current_thread().setName(name)
        actual = snoop.set_thread_info_padding(
            "{ident}-{name} ".format(ident=identifier, name=name)
        )
        assert len(actual) == len("{}-22 ".format(identifier))


# Generated at 2022-06-20 12:31:22.588649
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import doctest
    doctest.run_docstring_examples(get_path_and_source_from_frame,
                                   globals(), True, name='get_path_and_source_from_frame')



# Generated at 2022-06-20 12:31:26.766309
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = utils.get_frame_by_filename_and_line(__file__,
                                                 test_utils.TEST_LINE)
    local_reprs = get_local_reprs(frame)
    assert local_reprs['local_reprs'] == collections.OrderedDict()



# Generated at 2022-06-20 12:31:28.971670
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = 'test.txt'
    try:
        writer = FileWriter(path, write)
    except:
        return False
    else:
        return True



# Generated at 2022-06-20 12:31:35.373186
# Unit test for constructor of class Tracer
def test_Tracer():
    import numpy as np
    @pysnooper.snoop(watch_explode=('foo', 'self'), prefix='ZZZ> ',
                     max_variable_length=6, relative_time=True, normalize=True)
    def func1(foo):
        bar = 'bar'
        # bar = np.ones(10)
        return bar

    assert callable(func1)
    func1(1)


# Generated at 2022-06-20 12:31:45.329890
# Unit test for constructor of class FileWriter
def test_FileWriter():
    class MockWith(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

    class MockOpen(object):
        def __init__(self, name, mode):
            self.name = name
            self.mode = mode

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def write(self, s):
            self.s = s

    mock_open = MockOpen
    mock_with = MockWith
    path = 'abc'
    a = FileWriter(path, True)
    a.write('def')
    assert mock_open.name == 'abc'
    assert mock

# Generated at 2022-06-20 12:31:48.468496
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    l = []
    def f():
        l.append(1)
        return tracer.trace(1,1,1)
    f()


# Generated at 2022-06-20 12:31:56.922628
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import io
    import pytest
    from pysnooper import utils, pycompat
    from pysnooper.utils import thread_global

    def test():
        def foo():
            a = 1
            return a
        foo()

    prev_frame = utils.get_frame_info()

    output = io.StringIO()
    with pytest.raises(AssertionError):
        with Tracer(output, depth=0):
            pass

    with Tracer(output, depth=1):
        test()


# Generated at 2022-06-20 12:32:01.528590
# Unit test for constructor of class FileWriter
def test_FileWriter():
    writer = FileWriter('test.txt', False)
    assert writer.path == 'test.txt'
    assert writer.overwrite == False
    writer.write('a')
    assert writer.overwrite == False
    writer = FileWriter('test.txt', True)
    assert writer.overwrite == True
    writer.write('a')
    assert writer.overwrite == False



# Generated at 2022-06-20 12:32:37.889469
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()
    assert True



# Generated at 2022-06-20 12:32:39.358473
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    import tempfile


# Generated at 2022-06-20 12:32:48.352499
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(watch=('immutable_var', 'mutable_var[0]'))
    def foo(arg):
        immutable_var = 2
        mutable_var = [3, 4]
        return arg

    # expected_prefix = 'pysnooper'
    # if sys.version_info > (3,):
    #     expected_prefix = 'pysnooper.tests.test_snooper'
    tracer = Tracer()
    assert tracer.watch == (
        CommonVariable('immutable_var'),
        CommonVariable('mutable_var[0]'),
    )
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.custom_repr == ()
    assert tracer.max_

# Generated at 2022-06-20 12:32:56.588361
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    def _test_FileWriter_write_inner(overwrite, input_string,
                                     expected_output_file_content):
        with utils.TemporaryFolder() as temporary_folder:
            path = temporary_folder.make_path('file.txt')
            file_writer = FileWriter(path, overwrite=overwrite)
            file_writer.write(input_string)
            assert path.read_text('utf-8') == expected_output_file_content
    _test_FileWriter_write_inner(overwrite=True, input_string='what',
                                 expected_output_file_content='what')
    _test_FileWriter_write_inner(overwrite=False, input_string='what',
                                 expected_output_file_content='what')

# Generated at 2022-06-20 12:32:59.919900
# Unit test for constructor of class FileWriter
def test_FileWriter():
    writer = FileWriter('path_to_file', False)
    assert isinstance(writer.path, str)
    assert isinstance(writer.overwrite, bool)
    assert not writer.overwrite



# Generated at 2022-06-20 12:33:01.748816
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()
    assert isinstance(tracer, Tracer)


# Generated at 2022-06-20 12:33:09.436794
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = '/tmp/test_FileWriter_write'
    FileWriter(path, True).write('Line 1')
    FileWriter(path, True).write('Line 2')
    FileWriter(path, True).write('Line 3')
    FileWriter(path, False).write('Line 4')
    FileWriter(path, False).write('Line 5')
    FileWriter(path, False).write('Line 6')
    with open(path, 'r') as f:
        for i, line in zip(range(1, 7), f):
            assert line == 'Line {}\n'.format(i)
    os.remove(path)



# Generated at 2022-06-20 12:33:15.867807
# Unit test for constructor of class Tracer
def test_Tracer():
    x = 1
    def f():
        return x

    with utils.capture_stdout() as stdout:
        with pysnooper.snoop():
            f()
        assert '> Starting var:.. x = 1' in stdout.getvalue()

    with utils.capture_stdout() as stdout:
        with pysnooper.snoop(x for x in [1]):
            f()
        assert '> New var:....... x = 1' in stdout.getvalue()


# Generated at 2022-06-20 12:33:24.545945
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.set_thread_info_padding("")
    assert tracer.thread_info_padding == 0

    tracer.set_thread_info_padding("ABC")
    assert tracer.thread_info_padding == 3

    tracer.set_thread_info_padding("AB")
    assert tracer.thread_info_padding == 3

    tracer.set_thread_info_padding("ABCD")
    assert tracer.thread_info_padding == 4

    tracer.set_thread_info_padding("ABCD")
    assert tracer.thread_info_padding == 4

    tracer.set_thread_info_padding("ABCDE")
    assert tracer.thread_info_padding == 5


# Generated at 2022-06-20 12:33:28.758422
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import tempfile
    import os.path
    filepath = os.path.join(tempfile.gettempdir(), 'test.py')

# Generated at 2022-06-20 12:34:58.216221
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  import pytest
  from pysnooper import cli
  from pysnooper import snoop
  from pysnooper.utils import Tracer
  from pysnooper.utils import get_write_function
  from pysnooper.utils import pycompat
  from pysnooper.utils import utils
  from pytest import mark
  from pytest import raises
  if cli.DISABLED:
    raise Exception('Should not be skipped')
  if cli.TRACER is None:
    raise Exception('Should not be skipped')
  if pycompat.PY3_VERSION_INFO < (3, 7, 0):
    return
  # Following lines is to suppress warnings:
  # No value for argument 'a' in method call
  # No value for argument 'b' in method call
  # No value for