

# Generated at 2022-06-20 12:25:40.862889
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    f = tempfile.TemporaryFile('w+')
    path = f.name
    g = FileWriter(path, overwrite=True)
    g.write('hello world')
    g.write('hello world')
    g = FileWriter(path, overwrite=False)
    g.write('hello world')
    f.seek(0)
    print(f.read())



# Generated at 2022-06-20 12:25:45.780382
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect

    def test():
        frame = inspect.currentframe()
        assert frame.f_code.co_filename == __file__
        assert frame.f_globals['__name__'] == '__main__'
        assert get_path_and_source_from_frame(frame) == (__file__,
                                                         inspect.getsource(test)
                                                         .split('\n'))
    test()



# Generated at 2022-06-20 12:25:47.689000
# Unit test for constructor of class Tracer
def test_Tracer():
    assert Tracer()._write is sys.stdout.write
    assert Tracer(output='pytest.log')._write is write_to_file
    assert Tracer(output='pytest.log', overwrite=True)._write is write_to_file


# Generated at 2022-06-20 12:25:59.349181
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    from . import utils
    from .pycompat import StringIO

    if os.name == 'nt':
        path = r'C:\Users\ram\Desktop\cute_unicode_snowman.txt'
    else:
        path = '/tmp/cute_unicode_snowman.txt'
    def make_file_writer():
        return FileWriter(path, False)
    file_writer = make_file_writer()
    assert os.path.isfile(path) == False
    file_writer.write('☃')
    assert os.path.isfile(path) == True
    text = utils.read_all_from_file(path)
    assert text == '☃'
    file_writer.write('☃')
    text = utils.read_all_from_

# Generated at 2022-06-20 12:26:08.839864
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile

    # Test #1: writing to stderr
    write_function = get_write_function(None, False)
    old_stderr = sys.stderr
    try:
        sys.stderr = tempfile.TemporaryFile()
        s = b'Hello world!'
        write_function(s)
        sys.stderr.seek(0)
        assert sys.stderr.read() == s
    finally:
        sys.stderr.close()
        sys.stderr = old_stderr

    # Test #2: writing to file
    file_path = str(tempfile.mktemp())
    write_function = get_write_function(file_path, True)
    s = b'Hello again!'
    write_function(s)

# Generated at 2022-06-20 12:26:21.378872
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 12:26:31.713536
# Unit test for constructor of class Tracer
def test_Tracer():
    '''Test output of constructor of class Tracer
    '''
    # pylint: disable=too-many-locals
    warn('snoop.snoop is deprecated; use snoop.snoop()', DeprecationWarning)
    def test(x):
        '''Function to test output of constructor of class Tracer
        '''
        y = x + 1
        return y

    def test_with_custom_repr():
        '''Function to test output of constructor of class Tracer
        '''
        y = x + 1
        return y

    pac = pysnooper.snoop
    pysnooper.snoop = Tracer(watch="x")
    out = StringIO()


# Generated at 2022-06-20 12:26:35.605967
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                    prefix='', overwrite=False, thread_info=False, custom_repr=(),
                    max_variable_length=100, normalize=False, relative_time=False)

    with patch('sys.stdout', new=StringIO()) as fake_out:
        tracer.write('test')
    assert fake_out.getvalue() == "test\n"






# Generated at 2022-06-20 12:26:47.582855
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    info = "t1"
    tracer0 = Tracer(thread_info=True)
    tracer0.set_thread_info_padding(info)

    tracer1 = Tracer(thread_info=True)
    tracer1.set_thread_info_padding(info)

    # Test padding not less than 1
    assert(tracer0.thread_info_padding == 1)
    assert(tracer1.thread_info_padding == 1)

    # Test padding not more than the length of thread_info
    assert(tracer0.thread_info_padding <= len(info))
    assert(tracer1.thread_info_padding <= len(info))

    # Test padding same for two different instances of Tracer
    assert(tracer0.thread_info_padding == tracer1.thread_info_padding)




# Generated at 2022-06-20 12:26:48.808681
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert isinstance(UnavailableSource()[0], unicode)

# Generated at 2022-06-20 12:27:12.321087
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    fd, path = tempfile.mkstemp()
    fileno = os.fdopen(fd, 'w')
    fileno.write('test')
    fileno.close()
    write = get_write_function(fileno, False)
    print(write)
    assert write == sys.stderr.write
    write = get_write_function(None, False)
    print(write)
    assert write == get_write_function(None, False)
    write = get_write_function(path, True)
    print(write)
    assert write == FileWriter(path, True).write
    write = get_write_function(fileno, True)
    print(write)
    print("Error, overwrite can only be used with writing to file!\n")


# Generated at 2022-06-20 12:27:16.027414
# Unit test for function get_local_reprs
def test_get_local_reprs():
    class CustomRepr(object):
        def get_repr(self):
            return 'custom repr'
    assert get_local_reprs(
        inspect.currentframe(),
        dict(a='b', c=CustomRepr())
    ) == {'a': "'b'", 'c': "'custom repr'"}



# Generated at 2022-06-20 12:27:27.417348
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_path_and_source_from_frame_and_get_lines(frame):
        file_name, source = get_path_and_source_from_frame(frame)
        with open(file_name, 'rb') as fp:
            file_lines = fp.read().splitlines()
        return file_name, source, file_lines

    def test_get_source_from_same_module():
        def function(x):
            return x

        file_name, source, file_lines = \
            get_path_and_source_from_frame_and_get_lines(function.__code__.co_firstlineno)
        assert source == file_lines

    def test_get_source_from_different_module():
        import_ = __import__
        def function(x):
            return x

# Generated at 2022-06-20 12:27:30.268157
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    buffer = io.StringIO()
    with Tracer(buffer):
        x = 4

    assert buffer.getvalue() == (
        '    New var:....... x = 4\n'
    )


# Generated at 2022-06-20 12:27:35.636605
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    """
    Make sure that FileWriter writes to a file and sets overwrite to False
    after the first write.
    """
    # Setup
    path = 'out.txt'
    fileWriter = FileWriter(path, True)
    assert fileWriter.overwrite == True

    # Execute
    fileWriter.write('test write 1')
    fileWriter.write('test write 2')

    # Verify
    expected_content = 'test write 1test write 2'
    with open(path,'r') as fp:
        assert fp.read() == expected_content
    assert fileWriter.overwrite == False

    # Teardown
    os.remove(path)


# Generated at 2022-06-20 12:27:43.948110
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    t = Tracer()
    t.__enter__()
    with pytest.raises(KeyError):
        t.start_times = {}
        t.__enter__()
    t._is_internal_frame(1)
    setattr(t, '_is_internal_frame', lambda x: True)
    with pytest.raises(AttributeError):
        t.__enter__()
    setattr(t, '_is_internal_frame', lambda x: False)
    t._is_internal_frame = lambda x: False
    t.__enter__()


# Generated at 2022-06-20 12:27:54.641027
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    def test_directly():
        tracer = Tracer()
        assert (tracer._write and tracer._write.__module__ == '__main__'), \
               "Error in definition of variable 'tracer' of class Tracer"
        assert (tracer.watch and tracer.watch.__module__ == '__main__'), \
               "Error in definition of variable 'tracer' of class Tracer"
        assert (tracer.frame_to_local_reprs and tracer.frame_to_local_reprs.__module__ == '__main__'), \
               "Error in definition of variable 'tracer' of class Tracer"

# Generated at 2022-06-20 12:28:02.690513
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import io
    import threading

    output = io.StringIO()

    def func():
        import threading

        x = 2
        y = 3
        x + y

    @pysnooper.snoop(output=output)
    def func_start():
        func()

    @pysnooper.snoop(output=output)
    def func_end():
        func()

    def test_function_internal_frames(func_entry_point, expected_output):
        func_entry_point()
        output_string = output.getvalue()
        assert output_string == expected_output

    @pysnooper.snoop(output=output)
    def func_internal_frames():
        func()


# Generated at 2022-06-20 12:28:03.790162
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0]



# Generated at 2022-06-20 12:28:11.653156
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test that __enter__ is working properly
    print('Test that __enter__ is working properly')

    with Tracer(watch=('a', 'b'), watch_explode=('c',)):
        a = 1
        b = 2
        c = {}
        c[1] = 'one'
        c[2] = 'two'
        d = 2
        for i in range(2):
            pass
        print('Test that __enter__ is working properly')

# Generated at 2022-06-20 12:28:41.817334
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                        'file_writer_test.txt'))
    file_writer = FileWriter(path, False)
    file_writer.write('hi')
    file_writer.write('hi again')
    with open(path, 'r') as f:
        assert f.read() == 'hi'

    path = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                        'file_writer_test2.txt'))
    file_writer = FileWriter(path, True)
    file_writer.write('hi')
    file_writer.write('hi again')

# Generated at 2022-06-20 12:28:46.875526
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with pytest.raises(NotImplementedError):
        tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                prefix='', overwrite=False, thread_info=False, custom_repr=(),
                max_variable_length=100, normalize=False, relative_time=False)
        tracer.__enter__()

# Generated at 2022-06-20 12:28:55.529740
# Unit test for constructor of class Tracer
def test_Tracer():
    # Intentionally putting extra space in front of `return`, because later on
    # we're testing for this.
    source = u'''
    def foo():
        return 'foo'
    '''
    write = _FakeWrite()
    tracer = Tracer(watch=('return ',), output=write)
    tracer.trace(None, 'call', None)
    assert (
        u'   New var:....... return = True'
        in [write.s for write in tracer._write.writes]
    )

# Generated at 2022-06-20 12:29:05.202563
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Setup
    output=None
    watch=()
    watch_explode=()
    depth=1
    prefix=''
    overwrite=False
    thread_info=False
    custom_repr=()
    max_variable_length=100
    normalize=False
    relative_time=False
    self = pysnooper.snoop(output=output, watch=watch, watch_explode=watch_explode, depth=depth, prefix=prefix, overwrite=overwrite, thread_info=thread_info, custom_repr=custom_repr, max_variable_length=max_variable_length, normalize=normalize, relative_time=relative_time)
    exc_type = ts.Parameter(0)
    exc_value = ts.Parameter(1)
    exc_traceback = ts.Parameter(2)


# Generated at 2022-06-20 12:29:16.576364
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo(x):
        y = 2
        a = x
        return a + y
    foo_frame = inspect.currentframe().f_back
    result = get_local_reprs(foo_frame)
    assert result == {'x': '1', 'y': '2', 'a': '1'}

    custom_repr_dict = {'x': 'X!'}
    result = get_local_reprs(foo_frame, custom_repr=custom_repr_dict)
    assert result == {'x': 'X!', 'y': '2', 'a': '1'}

    watch = (CommonVariable(lambda: x), CommonVariable(lambda: z))
    result = get_local_reprs(foo_frame, watch)

# Generated at 2022-06-20 12:29:27.742034
# Unit test for method write of class Tracer
def test_Tracer_write():
  class A:
    def f1(self):
      pass

    def f2(self):
      pass
  class B:
    def f1(self):
      pass
    def f2(self):
      pass

  with Tracer(prefix="My Prefix ") as t:
    t.write("This line is written to output")

  t = Tracer(prefix="My Prefix ")
  t.write("This line is written to output")
  assert t.prefix == "My Prefix "
  # test __call__
  assert isinstance(t,Tracer)
  #test _wrap_class
  assert isinstance(t._wrap_class(A),type)
  #test _wrap_function
  assert isinstance(t._wrap_function(A.f1),types.FunctionType)
  #test simple_

# Generated at 2022-06-20 12:29:35.298862
# Unit test for function get_write_function
def test_get_write_function():
    (file_name, source) = get_path_and_source_from_frame(inspect.stack()[0][0])
    frame = inspect.stack()[0][0]
    local_reprs = get_local_reprs(frame)

    content = u'Python version: {}\n{}'\
              .format(sys.version.replace('\n', '\n' + u' ' * 11),
                      get_repr_from_frame(frame, source, local_reprs, True))

    f = utils.WritableStringIO()
    f.write_function = get_write_function(f, False)
    f.write_function(content)
    assert f.getvalue() == content



# Generated at 2022-06-20 12:29:39.947185
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    class Foo(object):
        def __getitem__(self, i):
            return i
    assert (Foo()[0] == 0)
    assert (UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE')
test_UnavailableSource()



# Generated at 2022-06-20 12:29:44.795852
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pytest.skip("manual test")
    from . import _pysnooper
    def func():
        return 1
    _pysnooper._snooper.__enter__()
    func()
    _pysnooper._snooper.__exit__(None, None, None)


# Generated at 2022-06-20 12:29:52.444036
# Unit test for constructor of class Tracer
def test_Tracer():
    with utils.captured_stdout() as output:
        with Tracer(watch='a'):
            a = 1
    assert output.getvalue() == (
        "Starting var:.. a = 1\n"
        "Elapsed time: 0:00:00.000000\n"
    )

    with utils.captured_stdout() as output:
        with Tracer(watch='a'):
            a = 1
            a = 2
    assert output.getvalue() == (
        "Starting var:.. a = 1\n"
        "New var:....... a = 2\n"
        "Elapsed time: 0:00:00.000000\n"
    )

# Generated at 2022-06-20 12:30:19.848356
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def function(a, b, c=1, d=1, e=1, f=1, g=1, h=1, i=1, j=1, k=1, l=1,
                 m=1, n=1, o=1, p=1, q=1, r=1, s=1, t=1, u=1, v=1, w=1, x=1,
                 y=1, z=1, abcdefghijklmnopqrstuvwxyz=1):
        return 1
    frame = sys._getframe()
    upper_names = [name for name in dir(function) if name.upper() == name]
    lower_names = [name for name in dir(function) if name.lower() == name]
    result = get_local_reprs(frame)

# Generated at 2022-06-20 12:30:21.524320
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[10] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:30:29.525084
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import python_toolbox as pt
    frame = sys._getframe()
    result = get_local_reprs(frame)
    assert result == {'__file__': 'scratch.py',
                      '__name__': "'__main__'",
                      'frame': '<frame object at 0x...>',
                      'pt': '<module \'python_toolbox\' from ...>',
                      'result': 'OrderedDict([...])',
                      'test_get_local_reprs': '<function test_get_local_reprs at 0x...>'}



# Generated at 2022-06-20 12:30:30.607314
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass


# Generated at 2022-06-20 12:30:39.658194
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # setup
    path = os.path.join(os.path.dirname(__file__), 'FileWriter_write.txt')
    if os.path.isfile(path):
        os.remove(path)
    fw = FileWriter(path, overwrite=True)
    s = 'lalala'

    # run test
    fw.write(s)
    fw.write(s)

    # assert results
    with open(path, 'r', encoding='utf-8') as output_file:
        output = output_file.read()
    assert output == s*2
    os.remove(path)



# Generated at 2022-06-20 12:30:47.246815
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import os
    import inspect
    import datetime
    import sys
    import threading
    import itertools
    import functools
    import pycompat
    import opcode
    import inspect
    import traceback

    func_body = '''
    def foo():
        return bar()
    '''

    source_file = utils.make_temp_file(func_body)
    sys.meta_path.append(utils.FoundSource(source_file))

    @pysnooper.snoop()
    def bar():
        return 3

    try:
        bar()
    finally:
        sys.meta_path.pop()

    os.remove(source_file)

# Generated at 2022-06-20 12:30:57.407122
# Unit test for constructor of class Tracer
def test_Tracer():
    def write_function(string):
        pass
    
    def function():
        pass
    
    def generator():
        yield 1
        
    def coroutine():
        yield from []
        
    class A(object):
        def __init__(self):
            pass
        def method(self):
            pass
            
    def dummy():
        pass
        
    import StringIO
    output = StringIO.StringIO()
    
    # Being verbose

# Generated at 2022-06-20 12:31:07.099822
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import types
    import pprint
    frame = types.FrameType(globals(), {'foo': 42}, 'filename.py', 10,
                            'foo', ('x',), None)
    variables = (
        CommonVariable('foo', max_length=3),
        CommonVariable('foo', max_length=1),
        CommonVariable('bar', max_length=3),
        CommonVariable('baz', max_length=3),
    )
    for variable in variables:
        assert all(
            get_local_reprs(frame, watch=(variable,), normalize=True).items()
            == [(variable.name, '...')]
        )

# Generated at 2022-06-20 12:31:18.605650
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from .test_utils import Mock, MockWriteFunction
    from .utils import ensure_tuple, get_write_function, get_path_and_source_from_frame

    # Mocking all the things
    mock_object = Mock()
    mock_object.write = MockWriteFunction()

    mock_callable = Mock()

    mock_get_write_function = Mock(return_value=mock_object.write)
    mock_ensure_tuple = Mock(return_value=[1, 2, 3])
    mock_get_path_and_source_from_frame = Mock()

    # Stub all the things
    stub(utils.get_write_function).before(mock_get_write_function)
    stub(utils.ensure_tuple).before(mock_ensure_tuple)

# Generated at 2022-06-20 12:31:21.166264
# Unit test for constructor of class Tracer
def test_Tracer():
    if DISABLED:
        return

    tracer = Tracer(output=None)

    assert isinstance(tracer, Tracer)


# Generated at 2022-06-20 12:31:48.393204
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    import os
    import filecmp

    def write_to_file(output, content, overwrite=False):
        with open(output, 'w' if overwrite else 'a') as f:
            f.write(content)

    def write_content(content):
        return content

    def write_to_stdout(content):
        sys.stdout.write(content)

    def write_to_stderr(content):
        sys.stderr.write(content)

    def write_to_null(content):
        pass

    with tempfile.TemporaryDirectory() as tempdir:
        filename = os.path.join(tempdir, 'test_file')

        write1 = get_write_function(filename, overwrite=False)

# Generated at 2022-06-20 12:31:56.251401
# Unit test for function get_write_function
def test_get_write_function():
    import sys, io
    assert get_write_function(sys.stdout, False) == sys.stdout.write

    s = io.StringIO()
    assert get_write_function(s, False) == s.write

    class FakeWritableStream(object):
        def write(self, *args, **kwargs): pass
    s = FakeWritableStream()
    assert get_write_function(s, False) == s.write

    assert get_write_function(None, False) != s.write
    assert get_write_function(None, False) != sys.stdout.write

    assert get_write_function('test_file.txt', True) != sys.stdout.write
test_get_write_function()



# Generated at 2022-06-20 12:32:00.827970
# Unit test for method write of class Tracer
def test_Tracer_write():
  import sys
  if sys.version_info[0] > 2:
    from io import StringIO
  else:
    from StringIO import StringIO
  _write_1 = 'print("Hello, World")'
  _write_2 = 'print("Hello, World")\n'
  _write_3 = 'Hello, World'
  _write_4 = 'Hello, World\n'
  _write_5 = '\n'
  _write_6 = ''
  _write_7 = ' '
  _write_8 = '   '
  _write_9 = '\t'
  _write_10 = '\n\n'
  _write_11 = '\t\t'
  _write_12 = '\t \t'
  out = StringIO()
  tracer = Tracer(out)

# Generated at 2022-06-20 12:32:10.900203
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import threading
    current_thread = threading.current_thread()
    current_thread_name = current_thread.getName()
    current_thread_len = len(current_thread_name)
    tracer = Tracer(thread_info=True)
    assert tracer.thread_info_padding == 0
    assert tracer.set_thread_info_padding(current_thread_name) == current_thread_name.ljust(current_thread_len)
    assert tracer.thread_info_padding == current_thread_len
    assert tracer.set_thread_info_padding(current_thread_name) == current_thread_name.ljust(current_thread_len)
    assert tracer.thread_info_padding == current_thread_len

# Generated at 2022-06-20 12:32:14.060346
# Unit test for method write of class Tracer
def test_Tracer_write():
    """
    Tracer.write
    """
    output = io.StringIO()
    s = Tracer(output)
    s.write("Hello World")
    assert "Hello World" == output.getvalue().strip()



# Generated at 2022-06-20 12:32:22.588044
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Test with and without an exception
    def test_exception(self, exception_type, exception_value,
                       exception_traceback):
        with self.assertRaises(exception_type) as cm:
            with self:
                raise exception_type(exception_value)
        self.assertEqual(cm.exception, exception_value)
        self.assertEqual(sys.gettrace(), None)
        self.assertEqual(thread_global.depth, -1)
        self.assertFalse(snooper.target_codes)
        self.assertFalse(snooper.target_frames)
        self.assertNotIn(frame, snooper.frame_to_local_reprs)
        self.assertNotIn(frame, snooper.start_times)

# Generated at 2022-06-20 12:32:29.141376
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import threading
    pysnooper.snoop(thread_info=True, output='/dev/null')
    tracer = Tracer()
    tracer.set_thread_info_padding('shit')
    tracer.set_thread_info_padding('shit1')
    threading.current_thread().name = 'goddamnit'
    tracer.set_thread_info_padding('shit')
    assert tracer.thread_info_padding == 9
    threading.current_thread().name = 'goddamnit1'
    threading.current_thread().ident += 1
    tracer.set_thread_info_padding('shit1')
    assert tracer.thread_info_padding == 16


# Generated at 2022-06-20 12:32:32.532697
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    for i in range(10):
        assert unavailable_source[i] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:32:36.939749
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    with tempfile.TemporaryDirectory() as dir_name:
        file_writer = FileWriter(dir_name + '/' + 'text.txt', True)
        file_writer.write('blabla')
        with open(dir_name + '/' + 'text.txt', 'r') as myfile:
            assert myfile.read() == 'blabla'



# Generated at 2022-06-20 12:32:43.477893
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tmp_path = tempfile.NamedTemporaryFile()
    with open(tmp_path.name, 'w') as f:
        with Tracer(output=f, normalize=True):
            pass
    expected_output_filename = 'test_pysnooper_Tracer_enter_expected_output'
    with open('expected_output/' + expected_output_filename, 'r') as f:
        expected_output = f.read()
    with open(tmp_path.name, 'r') as f:
        actual_output = f.read()
    assert actual_output == expected_output



# Generated at 2022-06-20 12:33:26.793785
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:33:36.593657
# Unit test for method write of class Tracer
def test_Tracer_write():
    from io import StringIO
    from io import BytesIO
    from io import IOBase
    # Note: In Python 2.X, the type of "str" is "str",
    #       but in Python 3.X, the type of "str" is "unicode".
    #       In this function, we do not care about this,
    #       because we pass byte sequences as arguments to methods.

    write_bytes = b"(Pdb) "
    write_unicode_bytes = u"(Pdb) ".encode("utf-8")
    write_unicode = u"(Pdb)"
    self = Tracer()
    self.prefix = u"prefix: "

    # I/O object to write bytes
    output = StringIO()
    # Call method
    self.write(write_bytes)
    # Check output
    assert output

# Generated at 2022-06-20 12:33:39.864869
# Unit test for function get_write_function
def test_get_write_function():
    def my_output(s):
        print('got %s' % s)
    write_function = get_write_function(my_output, True)
    write_function('some string')
    write_function = get_write_function(my_output, False)
    write_function('some other string')



# Generated at 2022-06-20 12:33:42.270723
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    #Test for internal_frame
    #Test for depth
    #Test for target_codes
    #Test for target_frames
    #Test for newish_string
    #Test for ended_by_exception
    pass


# Generated at 2022-06-20 12:33:44.623880
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs(inspect.currentframe(), watch=(), custom_repr=(),
                           max_length=0, normalize=True) == collections.OrderedDict()



# Generated at 2022-06-20 12:33:46.829915
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert ((UnavailableSource()[:2] ==
             ['SOURCE IS UNAVAILABLE', 'SOURCE IS UNAVAILABLE']) ==
            True)



# Generated at 2022-06-20 12:33:48.992970
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source_unavailable = UnavailableSource()
    assert source_unavailable[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:33:54.801916
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def x():
        raise RuntimeError()
    try:
        x()
    except Exception as e:
        tb = e.__traceback__
        frame = utils.get_frame_and_lineno(tb)[0]
        result = get_path_and_source_from_frame(frame)
        assert result[0] == __file__
        source = inspect.getsourcelines(x)[0]
        assert result[1][0] == source[0]



# Generated at 2022-06-20 12:33:56.890446
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_writer = FileWriter('test_FileWriter.txt', overwrite=True)
    file_writer.write('test\n')
    file_writer.write('test\n')



# Generated at 2022-06-20 12:34:03.560485
# Unit test for method write of class Tracer
def test_Tracer_write():
    # Create tracer
    tracer = Tracer()

    # Add mock write function
    from unittest.mock import Mock
    mock_write = Mock()
    tracer._write = mock_write

    # Call write
    tracer.write("test")

    # Verify write was called
    mock_write.assert_called_with('test\n')

    # Add prefix
    tracer.prefix = "pre"

    # Call write
    tracer.write("test")

    # Verify write was called with prefix
    mock_write.assert_called_with('pretest\n')


# Generated at 2022-06-20 12:34:56.115184
# Unit test for constructor of class Tracer
def test_Tracer():
    output = io.StringIO()
    s = Tracer(output, watch=('foo', 'bar'), watch_explode=('self',),
               depth=3, prefix='>>> ', override=True, thread_info=True)
    assert (s.watch == [BaseVariable('foo'),
                        BaseVariable('bar'),
                        Exploding('self')])
    assert s.frame_to_local_reprs == {}
    assert s.start_times == {}
    assert s.depth == 3
    assert s.prefix == '>>> '
    assert s.thread_info == True
    assert s.target_codes == set()
    assert s.target_frames == set()
    assert output.getvalue() == ''
    assert s.thread_info_padding == 0

# Simple example of a function

# Generated at 2022-06-20 12:35:05.541636
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys, unittest
    from . import test_utils

    class GetPathAndSourceFromFrameTestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = test_utils.create_temp_dir(
                prefix='test_get_path_and_source_from_frame_'
            )
            self.python_file = os.path.join(self.test_dir, 'test.py')

            with open(self.python_file, 'w') as f:
                f.write('print(1)')

            self.python_file_with_comments = os.path.join(self.test_dir, 'test_comments.py')