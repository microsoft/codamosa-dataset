

# Generated at 2022-06-20 12:25:43.403687
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    doctest.testmod(verbose=False)

# Generated at 2022-06-20 12:25:54.094520
# Unit test for function get_local_reprs
def test_get_local_reprs():
    x = 5
    y = 6
    z = 7
    frame = utils.get_current_frame()
    assert get_local_reprs(frame) == {'x': '5', 'y': '6', 'z': '7'}
    assert get_local_reprs(frame, max_length=2) == {'x': '5', 'y': '…', 'z': '…'}
    assert get_local_reprs(frame, watch=(('x*y', x*y, False), ('x*z', x*z, False))) == {'x': '5', 'y': '6', 'z': '7', 'x*y': '30', 'x*z': '35'}



# Generated at 2022-06-20 12:26:02.720887
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # initialize a Tracer
    tracer = pysnooper.Tracer()

    # test case1: no thread info
    thread_info = ''
    thread_info_padding = 15
    assert tracer.set_thread_info_padding(thread_info) == thread_info.ljust(thread_info_padding)

    # test case2: thread info length is less than the thread_info_padding
    thread_info = '12345'
    assert tracer.set_thread_info_padding(thread_info) == thread_info.ljust(thread_info_padding)

    # test case3: thread info length is larger than the thread_info_padding
    thread_info = '123456'
    assert tracer.set_thread_info_padding(thread_info) == thread_info.ljust(len(thread_info))

# Generated at 2022-06-20 12:26:07.056673
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        frame = sys._getframe(0)
        return get_path_and_source_from_frame(frame)
    assert os.path.normpath(foo()[0]) == os.path.normpath(test_get_path_and_source_from_frame.__code__.co_filename)



# Generated at 2022-06-20 12:26:19.317261
# Unit test for constructor of class Tracer
def test_Tracer():
    str_output = io.StringIO()
    # set output in constructor of class Tracer
    tracer_object = Tracer(output=str_output)

    # check if 'tracer_object._write' has been created correctly
    assert tracer_object._write == str_output.write
    # check if 'tracer_object.watch' is created correctly
    assert tracer_object.watch == []
    # check if 'tracer_object.frame_to_local_reprs' is created correctly
    assert tracer_object.frame_to_local_reprs == {}
    # check if 'tracer_object.start_times' is created correctly
    assert tracer_object.start_times == {}
    # check if 'tracer_object.depth' is created correctly
    assert tracer_object.depth == 1
   

# Generated at 2022-06-20 12:26:27.516932
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # No exception
    with pytest.raises(KeyError):
        with Tracer():
            raise KeyError("You told me to")
    # Exception handled here
    with Tracer():
        try:
            raise KeyError("You told me to")
        except KeyError as e:
            pass
    # Exception not handled here
    with pytest.raises(KeyError):
        with Tracer():
            raise KeyError("You told me to")
    # Exception not handled here
    with pytest.raises(KeyError):
        with Tracer():
            raise KeyError("You told me to")

# Generated at 2022-06-20 12:26:33.259520
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import filecmp
    import tempfile
    import shutil

    temp_dir = tempfile.mkdtemp(prefix='mockdebug_test_')
    try:
        output_file = os.path.join(temp_dir, 'output')
        file_writer = FileWriter(output_file, True)
        file_writer.write('first line')
        file_writer.write('second line')
        with open(output_file) as f:
            assert f.read() == 'first linesecond line'
        import filecmp
        assert filecmp.cmp(output_file, os.path.join(os.path.dirname(__file__),
                                                     'test_data',
                                                     'output_file'))
    finally:
        shutil.rmtree(temp_dir)



# Generated at 2022-06-20 12:26:45.444208
# Unit test for constructor of class Tracer
def test_Tracer():
    output = io.StringIO()
    #test normal case
    @snoop(output=output, watch='foo')
    def f(x):
        foo = x
        return x + 1
    f(1)
    #test wrong watch values
    @snoop(output=output, watch=1)
    def f(x):
        foo = x
        return x + 1
    f(1)
    @snoop(output=output, watch=['foo', 1])
    def f(x):
        foo = x
        return x + 1
    f(1)
    #test wrong output
    with pycompat.redirect_stdout(output):
        @snoop(output='foo', watch='foo')
        def f(x):
            foo = x
            return x + 1

# Generated at 2022-06-20 12:26:54.455547
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import __main__
    __main__.__snooper_test_snoop = snoop
    import dummy
    dummy.a = 1
    dummy.b = 2
    dummy.c = 3
    dummy.d = 4

    # Test snooping a function
    @snoop
    def dummy_snoop():
        print('hello')

    dummy_snoop()
    assert dummy_snoop.__name__ == 'dummy_snoop'

    # Test snooping a class
    @snoop
    class DummySnoop():
        def func(self):
            pass

    DummySnoop().func()
    assert DummySnoop.func.__name__ == 'func'
    assert DummySnoop.__name__ == 'DummySnoop'

   

# Generated at 2022-06-20 12:27:00.386419
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import os
    import pysnooper.utils
    import pysnooper.snoop

    with pysnooper.snoop():
        pass

    @pysnooper.snoop(watch_explode=('self',))
    class Foo():
        def __init__(self):
            self.x = 5

        def __str__(self):
            return 'str'

        def __repr__(self):
            return 'repr'
        def snoop_class_method(self):
            pass
        @classmethod
        def snoop_class_method2(cls):
            pass
        @staticmethod
        def snoop_static_method():
            pass

    f = Foo()
    f.snoop_class_method()
    Foo.snoop_class_

# Generated at 2022-06-20 12:27:22.363575
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(None, False)
    assert write == get_write_function(None, True)
    assert write != get_write_function('some_path', False)
    assert write != get_write_function('some_path', True)

    write = get_write_function('some_path', False)
    assert write == get_write_function('some_path', True)
    assert write != get_write_function(None, False)
    assert write != get_write_function(None, True)

    def write(s):
        pass
    assert write == get_write_function(write, False)
    assert write == get_write_function(write, True)

    class WritableStream:
        def write(self, s):
            pass
    writable_stream = WritableStream()
    assert writ

# Generated at 2022-06-20 12:27:29.833941
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    def test_inner_call(code, method_name, args, kwargs, expected_out_buf,
                        expected_out_file, result=None):
        fd, out_path = tempfile.mkstemp()

# Generated at 2022-06-20 12:27:34.035140
# Unit test for function get_write_function
def test_get_write_function():
    get_write_function(None, False)
    get_write_function(utils.StringIO(), False)
    get_write_function(utils.WritableStream(), False)
    get_write_function(lambda s: sys.stderr.write(s), False)
    get_write_function(sys.stderr, False)
    get_write_function(utils.StringIO(), True)



# Generated at 2022-06-20 12:27:35.920084
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from . import utils
    
    
    
    
    
    

# Generated at 2022-06-20 12:27:47.108858
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import io
    handler = io.StringIO()
    def foo():
        pass
    def bar():
        foo()
    def baz():
        bar()
    def qux():
        baz()
    function = qux
    with pysnooper.snoop(handler, depth=2):
        qux()
    sstr = "Starting var:.. __file__ = 'snooper.py'\n"
    sstr += "Starting var:.. __name__ = 'snooper'\n"
    sstr += "Starting var:.. __package__ = 'snooper'\n"

# Generated at 2022-06-20 12:27:53.302039
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Create an instance of Tracer
    tracer_instance = Tracer(
        output=None,
        watch=(),
        watch_explode=(),
        depth=1,
        prefix='',
        overwrite=False,
        thread_info=False,
        custom_repr=(),
        max_variable_length=100,
        normalize=False,
        relative_time=False,
    )


# Generated at 2022-06-20 12:28:01.889807
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import contextlib
    import os
    with contextlib.ExitStack() as stack:
        file_writer = FileWriter(stack.enter_context(tempfile.NamedTemporaryFile()).name, True)
        file_writer.write('bla')
        with open(file_writer.path) as result_file:
            assert result_file.read() == 'bla'
        file_writer.write('blo')
        with open(file_writer.path) as result_file:
            assert result_file.read() == 'blobloblo'
        file_writer.write('ble')
        with open(file_writer.path) as result_file:
            assert result_file.read() == 'blobloblo\nble'
        file_writer.write('ble')

# Generated at 2022-06-20 12:28:09.857715
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    with tempfile.NamedTemporaryFile(prefix='peachpy-') as f:
        path = f.name
        open(path, 'w').write('Example text\n')
        FileWriter(path, False).write('more text\n')
        assert open(path).read() == 'Example text\nmore text\n'
        FileWriter(path, overwrite=True).write('more text 2\n')
        assert open(path).read() == 'more text 2\n'



# Generated at 2022-06-20 12:28:19.568673
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()

    current_thread = threading.current_thread()
    current_thread_len = len("{ident}-{name}".format(ident=current_thread.ident,
                                                     name=current_thread.getName()))
    thread_info_padding = max(tracer.thread_info_padding, current_thread_len)
    assert thread_info_padding == current_thread_len

    current_thread_len = len("{ident}-{name}".format(ident=current_thread.ident + 1,
                                                     name=current_thread.getName()))
    thread_info_padding = max(thread_info_padding, current_thread_len)
    thread_info_padding = max(tracer.thread_info_padding, current_thread_len)
    assert thread_info_

# Generated at 2022-06-20 12:28:28.775403
# Unit test for function get_write_function
def test_get_write_function():
    buff = pycompat.BytesIO()
    def write(s):
        buff.write(s.encode())
    text = 'Hi, this is a test'
    write = get_write_function(buff, False)
    write(text)
    assert buff.getvalue().decode() == text

    write = get_write_function(None, False)
    try:
        write(text)
    except UnicodeEncodeError:
        # God damn Python 2
        pass

    write = get_write_function(write, False)
    write(text)
    assert buff.getvalue().decode() == 2 * text



# Generated at 2022-06-20 12:28:53.921235
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()



# Generated at 2022-06-20 12:28:56.819074
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        pass

    assert get_path_and_source_from_frame(test_function.__code__.co_firstlineno)



# Generated at 2022-06-20 12:28:59.197668
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()['Hello'] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[10] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:29:05.284442
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    global DISABLED
    DISABLED = False
    tracer_instance = pysnooper.snoop()
    DISABLED = True

    # Test the behavior of __exit__ with no arguments.
    tracer_instance.__exit__()

    DISABLED = False
    # Test the behavior of __exit__ with all arguments.
    assert tracer_instance.__exit__(1, 1, 1) is None
    DISABLED = True

test_Tracer___exit__()

# Generated at 2022-06-20 12:29:11.230173
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'c:\\Users\\abc.txt'
    file1_content = 'aaabbbccc'
    file2_content = 'eeefffggg'
    file1_expected_content = 'aaabbbccceeef'
    file2_expected_content = 'eeefffggg'
    fw1 = FileWriter(path, False)
    fw1.write(file1_content)
    fw2 = FileWriter(path, False)
    fw2.write(file2_content)
    with open(path, 'r') as output_file:
        read_content = output_file.read()
    assert read_content == file1_expected_content, 'Write to file failed.'

    path = 'c:\\Users\\abc.txt'

# Generated at 2022-06-20 12:29:13.111032
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .test.test_tracer import test_Tracer_trace
    test_Tracer_trace()


# Generated at 2022-06-20 12:29:16.358271
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[20] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source['s'] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-20 12:29:27.292257
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # Create an instance to test method set_thread_info_padding
    test_tracer = Tracer()
    # Test case 1
    thread_info = "123-abc "
    current_thread_len = len(thread_info)
    test_tracer.thread_info_padding = 0
    assert test_tracer.thread_info_padding == current_thread_len, "test_tracer.thread_info_padding == current_thread_len"

# Generated at 2022-06-20 12:29:35.630926
# Unit test for constructor of class Tracer
def test_Tracer():
    # Check special treatment of single-string watch values
    assert len(Tracer(watch='x').watch) == 1
    assert len(Tracer(watch=('x',)).watch) == 1
    assert len(Tracer(watch='x').watch[0].var_name) == 'x'
    assert len(Tracer(watch=('x',)).watch[0].var_name) == 'x'
    # Check special treatment of single-string watch_explode values
    assert len(Tracer(watch_explode='x').watch) == 1
    assert len(Tracer(watch_explode=('x',)).watch) == 1
    assert len(Tracer(watch_explode='x').watch[0].var_name) == 'x'

# Generated at 2022-06-20 12:29:43.677148
# Unit test for function get_write_function
def test_get_write_function():
    def f(output):
        write = get_write_function(output, False)
        write('abc')
        assert write('abc') is None
    f(None)
    with utils.FileWriter('temp.txt', True) as output:
        f(output)
        assert os.path.getsize('temp.txt') == 6
        os.remove('temp.txt')
    f(lambda s: print(s))
    f(sys.stderr)
test_get_write_function()
del test_get_write_function



# Generated at 2022-06-20 12:30:06.007343
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import mock
    def assert_called(self, *args, **kwargs):
        if 'args' in kwargs:
            del kwargs['args']
        return self.called_args[0] == args and self.called_kwargs == kwargs
    with mock.patch('utils.get_path_and_source_from_frame',
                    side_effect=lambda x: (x, None)):
        with mock.patch('utils.get_local_reprs', return_value={}):
            with mock.patch('pysnooper.utils.get_shortish_repr', return_value='repr'):
                with mock.patch('datetime.datetime'):
                    from pysnooper import thread_global
                    thread_global.__dict__.setdefault('depth', -1)
                    thread_

# Generated at 2022-06-20 12:30:16.928016
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # No coverage # Issue #62
    # No coverage # Issue #72
    from pysnooper.snoop import get_path_and_source_from_frame
    # No coverage # Issue #72
    from pysnooper.snoop import get_local_reprs
    tracer = Tracer()
    tracer.watch = [
            CommonVariable(v) for v in utils.ensure_tuple(watch)
         ] + [
             Exploding(v) for v in utils.ensure_tuple(watch_explode)
        ]
    # Code taken from http://hg.python.org/cpython/file/3.5/Lib/test/test_trace.py
    # No coverage # Issue #72
    def foo(x, y):
        a = x + y

# Generated at 2022-06-20 12:30:27.041950
# Unit test for function get_write_function
def test_get_write_function():
    class MyStandardError(utils.WritableStream):
        my_stderr_value = ''
        def write(self, s):
            self.my_stderr_value += s

    def my_function(s):
        my_function.my_function_value += s

    my_function.my_function_value = ''

    my_file = utils.WritableStream()
    my_stderr = MyStandardError()

    write_function_1 = get_write_function(None, False)
    write_function_2 = get_write_function(my_function, False)
    write_function_3 = get_write_function(my_file, False)
    write_function_4 = get_write_function(my_stderr, False)

    write_function_1('foo bar')

# Generated at 2022-06-20 12:30:30.036722
# Unit test for method write of class Tracer
def test_Tracer_write():
    with TestOutput() as output:
        with Tracer(output) as tracer:
            tracer.write('hello world!')
    assert output.getvalue() == 'hello world!\n'


# Generated at 2022-06-20 12:30:32.814880
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.trace(None, None, None)
    return True

test_Tracer_trace()


# Generated at 2022-06-20 12:30:39.658387
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        y = 'y'
        x = (1, [1, 2, 3])
    result = get_local_reprs(f.__code__.co_firstlineno + 1,
                             f.func_globals, normalize=False)
    assert result == {'a': '1', 'b': '2', 'y': "'y'", 'x': '(1, [1, 2, 3])'}



# Generated at 2022-06-20 12:30:47.747730
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    class MockSocket():
        def __init__(self):
            self.last_send = None

        def send(self, data):
            self.last_send = data

    def unit_test(data, expected):
        mock_socket = MockSocket()
        t = Tracer(output=mock_socket, thread_info=True)
        t.thread_info_padding = 10
        assert t.set_thread_info_padding(data) == expected

    data = '185-main'
    expected = '185-main   '
    unit_test(data, expected)

    data = '501-Thread-1'
    expected = '501-Thread-1'
    unit_test(data, expected)

    data = '501-Thread-155'
    expected = '501-Thread-155'

# Generated at 2022-06-20 12:30:58.323168
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def function_or_class(): pass
    def function(): pass
    def generator_function(): yield
    if sys.version_info[0:2] >= (3, 3):
        async def async_function(): pass
        async def async_generator_function(): yield
    if sys.version_info[0:2] >= (3, 5):
        async def async_coroutine(): await asyncio.sleep(0)
        async def async_coroutine_generator(): yield

    def scenario(function_or_class):
        with Tracer() as tracer:
            function_or_class(get_write_function=tracer._write)
        output = tracer._write.output
        return utils.normalize(output)

    assert scenario(function_or_class) == ''

# Generated at 2022-06-20 12:31:05.597408
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(output=None, overwrite=False)
    assert write('a') == None

    def w(s):
        print(s)
    write = get_write_function(output=w, overwrite=False)
    assert write('a') == None

    output = open('temp')
    write = get_write_function(output=output, overwrite=False)
    assert write('a') == None

    output = open('temp', 'w')
    write = get_write_function(output=output, overwrite=True)
    assert write('a') == None



# Generated at 2022-06-20 12:31:15.941273
# Unit test for constructor of class FileWriter
def test_FileWriter():
    write = FileWriter("tmp.txt", True).write
    write("line 1")
    write("line 2")
    with open("tmp.txt", "r") as f:
        lines = f.readlines()
    assert len(lines) == 2
    assert lines[0] == "line 1"
    assert lines[1] == "line 2"
    f = open("tmp.txt", "a")
    write("line 3\n")
    f.close()
    with open("tmp.txt", "r") as f:
        lines = f.readlines()
    assert len(lines) == 3
    assert lines[0] == "line 1"
    assert lines[1] == "line 2"
    assert lines[2] == "line 3\n"



# Generated at 2022-06-20 12:31:34.957497
# Unit test for function get_write_function
def test_get_write_function():
    class WritableStream(object):
        def write(self, s):
            self.s = s
    import tempfile
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        write = get_write_function(f, False)
        write('hey')
    assert open(path).read() == 'hey'
    write = get_write_function(None, False)
    write('hey')
    assert sys.stderr.write('') == 3
    path = os.path.join(tempfile.gettempdir(), 'temp.txt')
    write = get_write_function(path, True)
    write('hey')
    assert open(path).read() == 'hey'
    write = get_write_function(path, False)
    write

# Generated at 2022-06-20 12:31:40.237250
# Unit test for constructor of class Tracer
def test_Tracer():
    def test_function():
        pass
    tracer = Tracer(watch=('x', 'y', 'z'))
    tracer.watch.append(x)
    assert test_function.__code__ in tracer.target_codes
    assert len(tracer.watch) == 4
    assert isinstance(tracer.watch[-1], CommonVariable)

# Generated at 2022-06-20 12:31:47.630634
# Unit test for method write of class Tracer
def test_Tracer_write():
    '''
    The method test_Tracer_write tests the method Tracer.write of class Tracer
    This method tests for different inputs for the class Tracer and their outputs.
    '''
    # Inputs
    file_name="test.txt"
    if os.path.exists(file_name):
        os.remove(file_name)
    t=Tracer(file_name)
    t.write("Test")
    # Expected outputs
    expected_output="Test"
    # Outputs
    output=open(file_name).read()
    # Assertion checks
    assert expected_output==output

# Generated at 2022-06-20 12:31:48.696034
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()



# Generated at 2022-06-20 12:31:53.934355
# Unit test for function get_write_function
def test_get_write_function():
    class my_stream:
        def write(self, s):
            self.s = s
    s = my_stream()
    assert get_write_function(None)('abc') is None
    assert get_write_function(s)('abc') is None
    assert s.s == 'abc'
    assert get_write_function(utils.WritableStream(None))('abc') is None
test_get_write_function()



# Generated at 2022-06-20 12:31:56.935828
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io

    output = io.StringIO()
    tracer = Tracer(output)
    test_msg = "test_msg"
    tracer.write(test_msg)
    output.seek(0)
    lines = output.readlines()
    assert len(lines) == 1
    assert lines[0] == test_msg + '\n'

assert test_Tracer_write() == None

# Generated at 2022-06-20 12:32:03.518996
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def sub_func(a):
        b = 5
        return a
    def func():
        a = 3
        return sub_func(a)
    x = inspect.currentframe().f_back.f_back
    local_reprs = get_local_reprs(x, max_length=100, normalize=True)
    assert local_reprs['a'] == '3'
    assert local_reprs['b'] == '5'
    assert local_reprs['__builtins__'].startswith('{')
# end of unit test



# Generated at 2022-06-20 12:32:09.406507
# Unit test for function get_write_function
def test_get_write_function():
    from .tests import output_stream
    from io import StringIO

    def write_to_stream(output):
        write = get_write_function(output, False)
        write('Hello')

    write_to_stream(None)
    write_to_stream(sys.stdout)
    write_to_stream(output_stream)
    write_to_stream(StringIO())



# Generated at 2022-06-20 12:32:16.721528
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from . import utils
    import tempfile

    path = tempfile.mktemp()
    fw = FileWriter(path, True)
    expected = 'hello, world'
    fw.write(expected)
    assert utils.get_file_contents(path) == expected
    fw.write(expected)
    assert utils.get_file_contents(path) == expected * 2

    fw = FileWriter(path, False)
    fw.write(expected)
    assert utils.get_file_contents(path) == expected * 3
    os.remove(path)



# Generated at 2022-06-20 12:32:24.852417
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    class FakeFrame(object):
        def __init__(self, code, lineno, trace, name):
            self.f_code = code
            self.f_lineno = lineno
            self.f_trace = trace
            self.f_name = name

    fake_target_code = FakeFrame(code=FakeFrame, lineno=1, trace=None, name='FakeFrame')
    fake_target_frame = FakeFrame(code=FakeFrame, lineno=1, trace=None, name='FakeFrame')

    class MockTracer(Tracer):
        def __init__(self, depth, target_codes, target_frames,
                     max_variable_length, custom_repr):
            self.depth = depth
            self.target_codes = target_codes
            self.target_frames = target_frames
            self.max

# Generated at 2022-06-20 12:32:49.985747
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():


    # Support for python 2.6:
    from io import BytesIO

    from unittest import TestCase as BaseTestCase
    import unittest
    import os

    class TestCase(BaseTestCase):
        def assertMultiLineEqual(self, first, second, msg=None):
            """
            Assert that two multi-line strings are equal.
            """
            self.assert_(isinstance(first, basestring),
                         'First argument is not a string')
            self.assert_(isinstance(second, basestring),
                         'Second argument is not a string')

            if first != second:
                message = ''.join(difflib.ndiff(first.splitlines(True),
                                                second.splitlines(True)))
                if msg:
                    message += " : " + msg

# Generated at 2022-06-20 12:32:59.080170
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .variables import Variable
    file_writer = FileWriter(None, False)
    file_writer.write('abc')
    assert file_writer.path is None
    assert file_writer.overwrite is False
    file_writer = FileWriter('path', True)
    file_writer.write('abc')
    assert file_writer.path == 'path'
    assert file_writer.overwrite is False
    file_writer.write('def')
    with open('path', 'r') as f:
        assert f.read() == 'abcdef'

# When debugging from a REPL, this will be the number of lines to show after
# the exception line, since one line will be a statement to keep the debugger
# open (probably `breakpoint()`.)
repl_post_exception_margin = 1



# Generated at 2022-06-20 12:33:08.959341
# Unit test for method __call__ of class Tracer

# Generated at 2022-06-20 12:33:17.706601
# Unit test for method write of class Tracer
def test_Tracer_write():
    import tempfile, shutil, os
    tmpdirname = tempfile.mkdtemp()
    output_file_name = os.path.join(tmpdirname, 'pysnooper_output.log')
    self = Tracer(watch=('var1', 'var2', 'var3'), output=output_file_name)
    indent = '    '
    source_path = 'Source path:...'
    timestamp = '00:00:00.000000'
    event = 'Event'
    line_no = '1234'
    source_line = 'source line'
    name = 'name'
    value_repr = 'value_repr'
    return_value_repr = 'Return value:..'
    exception = 'Exception:.....'
    thread_info = 'thread_info'
    newish_string

# Generated at 2022-06-20 12:33:22.653124
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    test_path = (pycompat.text_type(os.path.realpath('.')) + '/temp.tmp')
    file_writer = FileWriter(test_path, False)
    file_writer.write('test')
    with open(test_path, 'r') as f:
        assert f.read() == 'test'
    os.remove(test_path)

# Generated at 2022-06-20 12:33:33.036555
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def function():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6

        assert list(get_local_reprs(
            frame=inspect.currentframe(),
            normalize=False
        ).items()) == [
            ('a', '1'),
            ('b', '2'),
            ('c', '3'),
            ('d', '4'),
            ('e', '5'),
            ('f', '6'),
        ]


# Generated at 2022-06-20 12:33:41.490264
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = inspect.currentframe()
    def foo(x, y=3, z=4):
        x = 7; y = 8; z = 9
        a = b = c = d = e = f = g = h = i = j = k = l = m = n = o = p = q = r = s = t = u = v = w = x = y = z = 0
        b = 3; c = 2
        return locals()
    frame = foo.__code__.__getframe__(**{'locals': foo()})
    from .common_values import \
        instantiate_custom_reprs, instantiate_common_values
    watch = (instantiate_common_values(),
             instantiate_custom_reprs())

# Generated at 2022-06-20 12:33:47.521304
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import json
    required_output = '''{
  "a": 1,
  "b": {
    "b1": "b1",
    "b2": "b2"
  }
}'''
    a = 1
    b = dict(b1='b1', b2='b2')
    frame = inspect.currentframe()
    frame_locals = frame.f_locals
    assert json.dumps(get_local_reprs(frame), indent=2) == required_output


# Generated at 2022-06-20 12:33:56.378832
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import zipfile
    import io
    import types

    def get_path_and_source(frame):
        return get_path_and_source_from_frame(frame)

    def test_function(x):
        return x * x + 2 * x

    def test_function_main():
        test_function(1)

    test_function_main_filename = inspect.getsourcefile(test_function_main)
    test_function_main_source = inspect.getsource(test_function_main).splitlines()
    test_function_line_number = test_function_main_source.index('    test_function(1)')
    test_function_filename = inspect.getsourcefile(test_function)
    test_function_source = inspect.getsource(test_function).splitlines()
    test_function_line_number

# Generated at 2022-06-20 12:33:58.461854
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(sys._getframe()) == __file__, \
           'test_get_path_and_source_from_frame failed'



# Generated at 2022-06-20 12:34:32.785960
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = StringIO()
    watch = ('foo', 'self')
    prefix = 'ZZZ '
    overwrite = True
    thread_info = True
    custom_repr = 'val'
    max_variable_length = 0
    normalize = True
    relative_time = True
    sys.stdout = output
    x = Tracer()
    x.watch = watch
    x.prefix = prefix
    x.overwrite = overwrite
    x.thread_info = thread_info
    x.custom_repr = custom_repr
    x.max_variable_length = max_variable_length
    x.normalize = normalize
    x.relative_time = relative_time

    x.write('test')
    output.close()
    sys.stdout = sys.__stdout__
    assert output.getvalue()

# Generated at 2022-06-20 12:34:38.510078
# Unit test for method write of class Tracer
def test_Tracer_write():
    def test_snoop_Tracer_write():
        @pysnooper.snoop(watch=('line_no', 'source_line'))
        def func(a, b):
            for i in range(len(a)):
                b[i] = a[i] + 1
            return b
        func([1, 2], [0, 0])
        assert True
    test_snoop_Tracer_write()


# Generated at 2022-06-20 12:34:46.772962
# Unit test for function get_write_function
def test_get_write_function():
    from .testing import AssertRaises, assert_equal
    from .testing.value_equality import assert_different

    assert_equal(get_write_function(None, False), sys.stderr.write)
    assert_different(get_write_function(None, False), sys.stderr.write)
    assert_equal(get_write_function(None, True), sys.stderr.write)


# Generated at 2022-06-20 12:34:54.222441
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global DISABLED
    DISABLED = False

    global thread_global
    thread_global.depth = 42
    global frame_to_local_reprs
    frame_to_local_reprs = {('key_frame_to_local_reprs_0',): 'value_frame_to_local_reprs_0'}
    global start_times
    start_times = {('key_start_times_0',): 'value_start_times_0'}
    
    # Call method
    tracer = Tracer()
    tracer.__enter__()

    # Check attributes
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}

# Generated at 2022-06-20 12:34:59.180039
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = pysnooper._snoop.Tracer(prefix="")
    assert tracer.thread_info_padding == 0
    assert tracer.set_thread_info_padding("") == " "
    assert tracer.thread_info_padding == 1
    assert tracer.set_thread_info_padding("1") == "1 "
    assert tracer.thread_info_padding == 2
    assert tracer.set_thread_info_padding("11") == "11 "
    assert tracer.thread_info_padding == 2
    assert tracer.set_thread_info_padding("11") == "11 "
    assert tracer.thread_info_padding == 2
    assert tracer.set_thread_info_padding("111") == "111 "
    assert tracer.thread_info_padding == 3
    assert tr