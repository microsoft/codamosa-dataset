

# Generated at 2022-06-20 12:25:48.940323
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import time
    from pysnooper.tracing import (
        get_local_reprs,
        get_path_and_source_from_frame,
    )
    frame = inspect.stack()[0][0]
    def test_locals():
        a = 1
        b = 2
        c = 3
        return locals()
    def test_get_path_and_source_from_frame():
        return get_path_and_source_from_frame(frame)
    def test_get_local_reprs(local_reprs, max_length=None):
        return get_local_reprs(frame, watch=(), custom_repr=(), max_length=max_length, normalize=False)
    locals1 = test_locals()
    locals2 = locals()
    source_path

# Generated at 2022-06-20 12:26:00.071111
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # block with parameters
    pysnoop_class_1 = pysnooper.snoop(thread_info=True)
    # block with default parameters
    pysnoop_class_2 = pysnooper.snoop()

    # no thread_info
    pysnoop_class_3 = pysnooper.snoop()

    timestamp = pycompat.time_isoformat(
        datetime_module.datetime.now().time(),
        timespec='microseconds'
    )

    assert pysnoop_class_1.thread_info_padding == 0
    assert pysnoop_class_2.thread_info_padding == 0
    assert pysnoop_class_3.thread_info_padding == 0
    assert pysnoop_class_1.thread_info is True
   

# Generated at 2022-06-20 12:26:09.224552
# Unit test for function get_write_function
def test_get_write_function():
    from . import mock, test_case
    import sys
    import cStringIO

    def assert_called(stderr, times=1):

        def check(s):
            stderr.write.assert_called_with(s)
            stderr.write.assert_called_times(times)

        return check

    with test_case.TestCase() as test_case:
        stderr = mock.Mock()
        stderr.write = mock.Mock()
        with test_case.assertRaises(Exception):
            get_write_function(stderr, True)
        mock_output = mock.Mock()
        mock_output.write = mock.Mock()
        sys.stderr = stderr

# Generated at 2022-06-20 12:26:10.218182
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-20 12:26:13.172652
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = sys._getframe()
    assert isinstance(get_local_reprs(frame), collections.OrderedDict)


# Generated at 2022-06-20 12:26:15.012421
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:20.861097
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[3:6] == 'SOURCE IS UNAVAILABLE'
    assert unavailable_source[3:6:3] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:31.345858
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from .utils import elapsed_time_format
    from .utils import get_shortish_repr
    import inspect
    import sys
    import threading
    import unittest
    
    
    
    
    
    
    
    
    
    
    
    
    class TestCase(unittest.TestCase):
        def test(self):
            _buffer_ = []
            _write_ = lambda s: _buffer_.append(s)
            
            global DISABLED
            DISABLED = False
            
            class Foo:
                def __init__(self):
                    self._age = 0
                    
                @pysnooper.snoop()
                def process_things(self):
                    for thing in self.things:
                        thing.process()
                        

# Generated at 2022-06-20 12:26:32.762630
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with pytest.raises(ValueError):
        with Tracer():
            pass

# Generated at 2022-06-20 12:26:34.686075
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test new and modified variables

    # Test return value

    # Test exception
    pass

# Generated at 2022-06-20 12:26:59.181926
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global __builtins__
    from pysnooper import snoop

    def my_builtin_open(name):
        return name

    __builtins__['open'] = my_builtin_open

    with Tracer(watch=['self', 'user_input'], max_variable_length=100) as tracer:
        @snoop()
        def simple_wrapper(user_input=None, *args, **kwargs):
            p = user_input
            if not user_input:
                p = 'null'
            print(p)
            return user_input

        @snoop()
        def function_with_exception(user_input=None, *args, **kwargs):
            raise Exception('foo')


# Generated at 2022-06-20 12:27:09.462292
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # AssertionError: AttributeError not raised, instead of AssertionError
    with raises(AssertionError):
        with pysnooper.snoop(output=None):
            pass
    # AssertionError: AttributeError not raised, instead of AssertionError
    with raises(AssertionError):
        with pysnooper.snoop():
            pass
    # AssertionError: AttributeError not raised, instead of AssertionError
    with raises(AssertionError):
        with pysnooper.snoop(watch=('hey', 'you')):
            pass
    # AssertionError: IOError not raised, instead of None
    with raises(AssertionError):
        with pysnooper.snoop(output=six.BytesIO()):
            pass
    #

# Generated at 2022-06-20 12:27:15.152832
# Unit test for constructor of class FileWriter
def test_FileWriter():
    with pycompat.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, 'temp.txt')
        with open(path, 'w') as f:
            f.write('12345')
        file_writer = FileWriter(path, True)
        file_writer.write('abc')
        with open(path, 'r') as f:
            assert f.read() == 'abc'
        file_writer.write('def')
        with open(path, 'r') as f:
            assert f.read() == 'def'



# Generated at 2022-06-20 12:27:21.821016
# Unit test for constructor of class FileWriter
def test_FileWriter():
    try:
        FileWriter(123, True)
        assert False, 'Did not raise exception'
    except Exception:
        pass
    try:
        FileWriter('foo.txt', False).write(u'hello')
        content = open('foo.txt', 'r').read()
        assert content == 'hello'
    finally:
        os.remove('foo.txt')



# Generated at 2022-06-20 12:27:25.324297
# Unit test for function get_local_reprs
def test_get_local_reprs():
    a = 'a'
    b = 'b'
    watch = (CommonVariable(b),)
    result = get_local_reprs(sys._getframe(), watch=watch)
    assert result == {'a': "'a'", b: "'b'"}


# Generated at 2022-06-20 12:27:30.473531
# Unit test for constructor of class FileWriter
def test_FileWriter():
    with utils.TempFolder() as temp_folder:
        output_path = temp_folder / 'output.txt'
        writer = FileWriter(output_path, overwrite=False)
        writer.write('Hello world!\n')
        with open(output_path, encoding='utf-8') as output_file:
            assert output_file.read() == 'Hello world!\n'



# Generated at 2022-06-20 12:27:37.710180
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def mock_get_path_and_source_from_frame(frame):
        return ('/project/workdir/test_pysnooper.py',
                ['    foo = 1',
                 '    return foo',
                ])
    class MockFrame(object):
        f_code = MockFrame
        f_lineno = 2
        f_lasti = 1
    class MockThreading(object):
        current_thread = MockFrame
        class Thread(object):
            def getName(self):
                return 'mock_thread'
    mock_frame = MockFrame()
    mock_thread = MockThreading.Thread()
    mock_event = 'return'
    mock_arg = 1
    mock_tracer = Tracer()
    mock_tracer.thread_info = True

# Generated at 2022-06-20 12:27:48.457420
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo():
        a = 1
        b = 2
        c = [1, 2, 3]
        d = {6: 7, 8: 9}
        e = {10, 11, 12}
        f = 'a'
        g = b'a'
        h = bytearray(b'a')
    f = foo.__code__
    frame = sys._getframe(0)
    locals_ = get_local_reprs(frame)

# Generated at 2022-06-20 12:27:53.507769
# Unit test for function get_write_function
def test_get_write_function():
    for output in (None, sys.stdout, sys.stderr, open('/tmp/test', 'w')):
        for overwrite in (False, True):
            if output is None:
                continue
            write = get_write_function(output, overwrite)
            assert callable(write)
            write('foo')



# Generated at 2022-06-20 12:27:55.009636
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:28:22.697231
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import io
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    snooper = Tracer(output='stdout')
    snooper.write('aaa')
    snooper.write('bbb')
    assert sys.stdout.getvalue() == u'aaa\nbbb\n'
    snooper = Tracer(output='stderr')
    snooper.write('aaa')
    snooper.write('bbb')
    assert sys.stderr.getvalue() == u'aaa\nbbb\n'
    sys.stdout = old_stdout
    sys.stderr = old_stderr

#

# Generated at 2022-06-20 12:28:26.407950
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = "file"
    overwite = True
    fileWriter = FileWriter(path, overwrite)
    assert fileWriter.path == "file"
    assert fileWriter.overwrite == True



# Generated at 2022-06-20 12:28:34.856576
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    from special_functions import check_function
    import os, threading, sys
    from common_variables import CommonVariable
    from base_tracer import BaseVariable
    from exploding import Exploding
    from linecache_module_patcher import LinecacheModulePatcher
    from datetime_module_patcher import datetime
    from get_path_and_source_from_frame import get_path_and_source_from_frame
    from get_local_reprs import get_local_reprs
    from utils import get_shortish_repr
    from utils import truncate
    import pycompat
    import inspect
    from common_variables import _CommonVariable__common_variable_locations
    from common_variables import _CommonVariable__get_targets, _CommonVariable__get_target_

# Generated at 2022-06-20 12:28:44.217507
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.thread_info_padding == 0
    tracer.set_thread_info_padding('Thread-1')
    assert tracer.thread_info_padding == len('Thread-1')
    tracer.set_thread_info_padding('Thread-1')
    assert tracer.thread_info_padding == len('Thread-1')
    tracer.set_thread_info_padding('Thread-4')
    assert tracer.thread_info_padding == len('Thread-4')


# Generated at 2022-06-20 12:28:45.705703
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert (UnavailableSource()[0] ==
            u'SOURCE IS UNAVAILABLE')



# Generated at 2022-06-20 12:28:55.661221
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as dirname:
        path = os.path.join(dirname, 'testfile')
        FileWriter(path, True).write('hey')
        assert open(path).read() == 'hey'
        FileWriter(path, False).write('hey')
        assert open(path).read() == 'heyhey'
        FileWriter(path, False).write('hey')
        assert open(path).read() == 'heyheyhey'
        FileWriter(path, True).write('hey')
        assert open(path).read() == 'hey'


_frame_cache = {}


# Generated at 2022-06-20 12:29:00.411510
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    tracer.write(u'abc')


# Generated at 2022-06-20 12:29:06.545800
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer(output=None)
    stack = []
    good_stack = [False, False, False]
    def f():
        stack.append(good_stack.pop(0))
    def good_f():
        pass
    def bad_f():
        1/0
    tracer._write = lambda s: stack.append(True)
    with tracer:
        tracer.__exit__(None, None, None)
    if not all(stack):
        raise Exception('test_Tracer___exit__ failed')

# Generated at 2022-06-20 12:29:11.147988
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write("This is a test")
    tracer.write("This is another test")
    tracer.write("This is yet another test")
    tracer.write("This is the last test")



# Generated at 2022-06-20 12:29:17.330621
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        import random
        random.randint(0, 3)
        g()

    def g():
        frame = inspect.currentframe()
        path, source = get_path_and_source_from_frame(frame)
        assert path == __file__
        assert source[2].startswith('    def g():')

    f()
test_get_path_and_source_from_frame()



# Generated at 2022-06-20 12:29:40.951378
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(ValueError) as excinfo:
        Tracer(normalize=True, relative_time=True)
    assert "Neither normalize nor relative_time can be set to True" in str(excinfo.value)


# Generated at 2022-06-20 12:29:47.939078
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        file_writer = FileWriter(temp_dir + '/foo.txt', True)
        file_writer.write('foobar')
        with open(temp_dir + '/foo.txt') as file_:
            assert file_.read() == 'foobar'
        file_writer.write('barbaz')
        with open(temp_dir + '/foo.txt') as file_:
            assert file_.read() == 'foobarbarbaz'




# Generated at 2022-06-20 12:29:51.630221
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer=Tracer()
    tracer.start_times={}
    tracer.target_frames=set()
    tracer.frame_to_local_reprs={}
    tracer.write=lambda x:None
    tracer.__exit__(None,None,None)

# Generated at 2022-06-20 12:30:00.593089
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import inspect
    import threading
    import functools
    import sys
    # Python 2 can't capture annotations and defaults of functools.wraps decorator
    f = Tracer()
    # Base case
    # Call: function_or_class
    # Expect: <class 'functools.partial'>
    def dummy():
        pass
    assert type(f(dummy)) == functools.partial
    # decorator is a class
    class decorator(object):
        def __init__(self, function_or_class):
            pass
    # Call: decorator
    # Expect: <class 'functools.partial'>
    assert type(f(decorator)) == functools.partial
    # Coroutines are functions, but snooping them is not supported
    # at the moment
    # Call: function

# Generated at 2022-06-20 12:30:04.702010
# Unit test for function get_local_reprs
def test_get_local_reprs():
    a = 3
    b = 5
    reprs = get_local_reprs(inspect.currentframe())
    assert reprs == {'a': '3', 'b': '5'}
    assert reprs['a'] == '3'
    assert reprs['b'] == '5'



# Generated at 2022-06-20 12:30:15.967689
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from cute_mongo.collections import CuteMongoCollection
    from cute_mongo.utils import get_shortish_repr
    locals = {'col': CuteMongoCollection()}
    assert get_local_reprs(locals) == {'col': 'cute_mongo.collections.CuteMongoCollection'}

# Generated at 2022-06-20 12:30:25.367581
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import tempfile
    import os
    import sys

    def snoop(**kwargs):
        _kwargs = dict(overwrite=False, depth=1, watch=(), watch_explode=(),
                       prefix='', output=None, thread_info=False, custom_repr=(),
                       max_variable_length=100, normalize=False, relative_time=False)
        _kwargs.update(kwargs)
        _kwargs['output'] = string_io = io.StringIO()
        with Tracer(**_kwargs) as snooper:
            y = 5
            z = 6
            z = z + z
            z = z + z
            z = z + z
            z = z + z
            z = z + z
            z = z + z
            z = z + z


# Generated at 2022-06-20 12:30:36.389899
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .variables import Variable
    from .utils import normalize_repr
    from . import utils
    from . import case_insensitive_dict

    frame = get_frame()
    frame.f_locals['a'] = [1, 2, 3]
    assert get_local_reprs(frame) == \
           {'a': '[1, 2, 3]'}
    frame.f_locals['a'] += ['asdf', (1, 2, 3)]
    assert get_local_reprs(frame) == \
           {'a': "[1, 2, 3, 'asdf', (1, 2, 3)]"}
    assert get_local_reprs(frame, max_length=20) == \
           {'a': "[1, 2, 3, 'asd...']"}
    assert get

# Generated at 2022-06-20 12:30:44.702928
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
	# Initilize and equip values for the test
	testTracer = Tracer()
	elapsed_time_string = "5:20:00"
	indent = ' ' * 4 * (thread_global.depth + 1)
	testTracer.prefix = ''
	testTracer.start_times = {0:datetime_module.datetime.now()}
	# -------------------------------------
	testTracer.write = MagicMock()
	testTracer.__exit__(None, None, None)
	testTracer.write.assert_called_with('{indent}Elapsed time: {elapsed_time_string}'.format(**locals()))


# Generated at 2022-06-20 12:30:46.314541
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:17.108503
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def inner():
        frame = sys._getframe(0)
        return get_path_and_source_from_frame(frame)
    path, source = inner()
    if sys.version_info[:2] == (3, 2):
        assert path == '__main__.py'
        assert source[1] == '    path, source = inner()'
    else:
        assert path == '<string>'
        assert source[1] == '    path, source = inner()'


# Generated at 2022-06-20 12:31:19.796546
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile

    FileWriter(tempfile.gettempdir(), overwrite=False)
    FileWriter(tempfile.gettempdir(), overwrite=True)



# Generated at 2022-06-20 12:31:24.918207
# Unit test for constructor of class Tracer
def test_Tracer():
    Sn = Tracer
    assert Sn(output="tmp.txt")
    assert Sn(watch=("a",))
    assert Sn(watch_explode=("a",))
    assert Sn(depth=2, prefix="test", overwrite=True, thread_info=True, custom_repr=("test", "test"), max_variable_length=100, normalize=False, relative_time=True)


# Generated at 2022-06-20 12:31:30.149857
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class TestTracer___call__:
        @pysnooper.snoop(watch=('x', 'y', 'z', 'a'))
        def f(self, x, y, z):
            a = x + y
            time.sleep(0.01)
            return z
    test_Tracer___call__=TestTracer___call__()
    test_Tracer___call__.f(3, 4, 7)

# Generated at 2022-06-20 12:31:41.355129
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os.path
    from . import utils
    from .utils import Path
    from .test_toolbox.inspect import assert_
    from .test_toolbox import TempFolder

    path = utils.Path(__file__).parent / 'test_mock_dump.txt'
    content = 'dumped_content'
    if path.exists():
        path.unlink()
    with TempFolder():
        writer = FileWriter(path, overwrite=True)
        writer.write(content)
        assert_(path.read_text()) == content
        writer.write('new_content')
        assert_(path.read_text()) == content + 'new_content'

        writer = FileWriter(path, overwrite=False)
        writer.write(content)

# Generated at 2022-06-20 12:31:42.162795
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0]


# Generated at 2022-06-20 12:31:51.804175
# Unit test for function get_local_reprs
def test_get_local_reprs():
    a='a'
    b=2
    my_list=[3, 4]
    def my_function():
        pass
    def f():
        a in locals()
        b in locals()
        my_list in locals()
        my_function in locals()
    f()
    frame = sys._getframe(1)
    assert get_local_reprs(frame) == {'a': "'a'",
                                      'b': '2',
                                      'my_function': '<function f.<locals>.my_function at ',
                                      'my_list': '[3, 4]'}

# Generated at 2022-06-20 12:31:53.523675
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:54.817321
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with pytest.raises(TypeError):
        tracer = pysnooper.snoop()


# Generated at 2022-06-20 12:31:59.661302
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import pysnooper
    import os
    import pycompat
    import tempfile
    import pycompat
    import inspect
    import functools
    import pysnooper.pycompat
    import datetime as datetime_module
    import gc
    import threading
    call_log = []
    stack = []
    thread_local = threading.local()

    output = open(os.path.join(tempfile.gettempdir(), "test_Tracer___enter__.txt"), "w")

    def get_write_function(output, overwrite):
        def _write(s):
            if isinstance(s, bytes):
                s = s.decode('utf-8', 'replace')
            call_log.append({'_write': s})

        return _write


# Generated at 2022-06-20 12:33:15.183367
# Unit test for constructor of class FileWriter
def test_FileWriter():
    file_name = 'test_file'
    test_string = 'test_string'
    file_writer = FileWriter(file_name, True)
    file_writer.write(test_string)
    with open(file_name, 'r') as f:
        assert f.read() == test_string
    if os.path.exists(file_name):
        os.remove(file_name)



# Generated at 2022-06-20 12:33:21.105321
# Unit test for constructor of class Tracer
def test_Tracer():
    output = []
    write = lambda s: output.append(s)
    watch = ['a']
    watch_explode = ['b']
    depth = 1
    prefix = 'Prefix'
    overwrite = False
    thread_info = False
    max_variable_length = 100
    custom_repr = ((type, lambda x: x),)
    tracer = Tracer(output, watch, watch_explode, depth, prefix, overwrite,
                    thread_info, custom_repr,
                    max_variable_length)
    assert tracer._write is write
    assert tracer.watch == [CommonVariable('a'), Exploding('b')]
    assert tracer.depth == 1
    assert tracer.prefix == 'Prefix'
    assert tracer.custom_repr == custom_repr
    assert tracer.max_

# Generated at 2022-06-20 12:33:29.167150
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import filecmp
    file_path = tempfile.mkstemp()[1]
    file_writer = FileWriter(file_path, True)
    file_writer.write("a")
    file_writer.write("b")
    with open(file_path, encoding='utf-8') as file:
        assert file.readlines() == ["a", "b"]
    file_writer.write("c")
    with open(file_path, encoding='utf-8') as file:
        assert file.readlines() == ["ac"]


# Generated at 2022-06-20 12:33:33.904280
# Unit test for method write of class Tracer
def test_Tracer_write():
    with patch('builtins.print') as patched_print:
        tracer_instance = Tracer()
        tracer_instance.write("this is a test")
        assert patched_print.call_count == 2
        (output1, output2), _ = patched_print.call_args_list[1]
        assert output1 == 'this is a test'


# Generated at 2022-06-20 12:33:37.778477
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io, sys
    sio = io.StringIO()
    trace = Tracer(output=sio)
    trace.write('123')
    assert '123\n' == sio.getvalue()


# Generated at 2022-06-20 12:33:45.818949
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    global get_path_and_source_from_frame
    global source_and_path_cache
    original_get_path_and_source_from_frame = get_path_and_source_from_frame
    original_source_and_path_cache = source_and_path_cache

# Generated at 2022-06-20 12:33:47.594988
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:33:49.139093
# Unit test for constructor of class Tracer
def test_Tracer():
    def func():
        pass
    tracer = Tracer()
    tracer.__init__()


# Generated at 2022-06-20 12:33:55.350549
# Unit test for method write of class Tracer
def test_Tracer_write():
    test_object = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    test_args = (
        'x',
    )
    # Call the method
    try:
        test_object.write(*test_args)
    except Exception as e:
        print('Exception:', e)

# Generated at 2022-06-20 12:34:03.934586
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pysnooper
    import pytest
    from pysnooper import utils


    # Test for function __init__
    def __init__():
        with pytest.raises(NotImplementedError):
            pysnooper.Tracer(prefix='')


    # Test for function __call__
    def __call__():
        @pysnooper.snoop()
        def foo():
            pass
        assert foo.__name__ == 'foo'
        assert foo.__doc__ == 'Test for function __call__\n\n'
        assert foo.__module__ == 'test_Tracer'


    # Test for function _wrap_function
    def _wrap_function():
        def foo():
            pass