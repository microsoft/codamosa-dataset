

# Generated at 2022-06-20 12:26:02.493222
# Unit test for function get_write_function
def test_get_write_function():
    def check(output,
              file_path=None,
              overwrite_expected=False,
              write_function_expected=None):
        assert write_function_expected
        write_function = get_write_function(output, overwrite=True)
        assert write_function == write_function_expected
        if file_path is not None:
            assert isinstance(write_function, FileWriter)
            assert write_function.file_path == file_path
            assert write_function.overwrite == overwrite_expected
        else:
            assert not isinstance(write_function, FileWriter)

# Generated at 2022-06-20 12:26:10.765413
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    class MockLoader(object):
        @staticmethod
        def get_source(module_name):
            assert module_name == 'foo'
            return '# coding: utf-8\nfoo'

    frame = {
        'f_code': {'co_filename': '<ipython-input-1->'},
        'f_globals': {
            '__name__': 'foo',
            '__loader__': MockLoader(),
        },
    }

    filename, source = get_path_and_source_from_frame(
        type('', (), frame)()
    )
    assert filename == '<ipython-input-1->'
    assert source == ['# coding: utf-8', 'foo']


# Generated at 2022-06-20 12:26:13.172925
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    us = UnavailableSource()
    assert us[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:15.512468
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    
    
    # No assertion. See the explanation in Tracer.__enter__.
    pass
    
    

# Generated at 2022-06-20 12:26:23.789934
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = inspect.currentframe().f_back
    assert get_local_reprs(frame, (CommonVariable('a'),
                                   CommonVariable('b'))) == {
                                                              'a': '2',
                                                              'b': '15',
                                                              'frame': utils.shortish_repr(frame),
                                                              'test_get_local_reprs': utils.shortish_repr(test_get_local_reprs)
                                                              }



# Generated at 2022-06-20 12:26:30.563050
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    import os
    import pathlib
    from .test_utils import _filename

    frame = types.FrameType(0, False, False, locals())
    code = types.CodeType(0, 0, 0, 0, 0, '', (), (), (), '', '', 1, '')
    frame.f_locals = {'__name__': 'a.b'}
    frame.f_code = code

    assert get_path_and_source_from_frame(frame) == ('a.b', UnavailableSource())

    code = types.CodeType(0, 0, 0, 0, 0, '', (), (), (), '', '', 1, '')
    frame = types.FrameType(0, False, False, locals())
    frame.f_locals = {'__name__': 'a.b'}


# Generated at 2022-06-20 12:26:34.428358
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == inspect.getsourcefile(frame)
    assert source[frame.f_lineno - 1].endswith('test_get_path_and_source_from_frame()')
    del frame
    del path
    del source
    del inspect



# Generated at 2022-06-20 12:26:46.557271
# Unit test for constructor of class Tracer
def test_Tracer():
    output = io.StringIO()
    tracer = Tracer(watch=('foo',), prefix='ZZZ ', overwrite=True, output=output,
                    custom_repr=((lambda x: True, lambda x: '<SPAM>'),), thread_info=True)
    assert tracer.watch == [CommonVariable('foo')]
    assert tracer.depth == 1
    assert tracer.prefix == 'ZZZ '
    assert tracer.thread_info
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local
    assert tracer.custom_repr == ((lambda x: True, lambda x: '<SPAM>'),)
    assert tracer.write == output.write
    assert tracer.max_variable_length == 100

# Generated at 2022-06-20 12:26:56.639097
# Unit test for function get_write_function
def test_get_write_function():
    # Using get_write_function with output=None
    # Writes to original stderr
    old_stderr = sys.stderr
    sys.stderr = stderr = utils.StringStream()
    write_function = get_write_function(None, False)
    write_function(u"my name is")
    assert stderr.getvalue() == u"my name is"
    sys.stderr = old_stderr
    # Using get_write_function with output=StringIO
    # Writes to given stream (StringIO)
    stream = utils.StringStream()
    write_function = get_write_function(stream, False)
    write_function(u"my name is")
    assert stream.getvalue() == u"my name is"
    # Using get_write_function

# Generated at 2022-06-20 12:26:59.984506
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[1] == u'SOURCE IS UNAVAILABLE'
    assert source[3] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:27:17.889472
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    pass



# Generated at 2022-06-20 12:27:21.957986
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'
    lines = UnavailableSource()[0:2]
    assert lines == [u'SOURCE IS UNAVAILABLE', u'SOURCE IS UNAVAILABLE']



# Generated at 2022-06-20 12:27:22.634637
# Unit test for function get_write_function
def test_get_write_function():
    # TODO: Write the tests
    pass


# Generated at 2022-06-20 12:27:29.993726
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding("")=="   -MainThread "
    tracer.set_thread_info_padding("Thread-1")
    assert tracer.set_thread_info_padding("")=="   -MainThread "
    tracer.set_thread_info_padding("Thread-1")
    assert tracer.set_thread_info_padding("")=="   -MainThread "
    tracer.set_thread_info_padding("Thread-1")
    assert tracer.set_thread_info_padding("")=="   -MainThread "
    tracer.set_thread_info_padding("Thread-1")
    assert tracer.set_thread_info_padding("")=="   -MainThread "
    tracer.set_thread

# Generated at 2022-06-20 12:27:36.236749
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    if sys.version_info < (3, 5):
        # Since we're relying on inspect.getframeinfo, which was only added in
        # Python 3.5.
        return
    def decorator(func):
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper
    decorator = decorator(test_get_path_and_source_from_frame)
    frame = inspect.currentframe()
    frame = frame.f_back
    file_name, source = get_path_and_source_from_frame(frame)
    if file_name[-4:] in ('.pyc', '.pyo'):
        file_name = file_name[:-1]
    assert file_name.endswith(__file__)

# Generated at 2022-06-20 12:27:47.424223
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def empty_func():
        pass
    assert list(get_local_reprs(inspect.currentframe().f_back)) == []

    def test_func():
        pass
    assert list(get_local_reprs(inspect.currentframe().f_back)) == [
                                              ('test_func', '<Function>')]
    frame = inspect.currentframe().f_back
    d = {'my_dict': {'a': 1, 'b': 2}}
    def test_func():
        return d['my_dict']['b']
    assert list(get_local_reprs(frame,
                            max_length=8)) == [('d', '{...}'),
                                               ('test_func', '<Function>')]

# Generated at 2022-06-20 12:27:54.501640
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    temp_file_path = utils.get_temp_file_path('pdbpp_test_FileWriter_write')
    file_writer = FileWriter(temp_file_path, overwrite=True)
    file_writer.write(u'a\nb\nc')
    file_writer.write('d\n')
    file_writer.write('e\n')
    assert utils.read_file(temp_file_path) == u'a\nb\ncd\ne\n'


# Generated at 2022-06-20 12:27:56.515613
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource().__getitem__(0) == u'SOURCE IS UNAVAILABLE'

unavailable_source = UnavailableSource()



# Generated at 2022-06-20 12:27:59.143834
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import doctest
    import pysnooper
    import sys

    (fails, tests) = doctest.testmod(pysnooper, report=False)
    sys.exit(fails)


# Generated at 2022-06-20 12:28:05.431709
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    import pysnooper.thread_global
    import pysnooper.utils
    import sys
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    output = io.StringIO()
    pysnooper.snoop(output)(lambda x: x)
    assert 'Source path:...' in output.getvalue()
    output.close()

    output = io.StringIO()
    pysnooper.snoop(output)(lambda x: x)
    assert 'Starting var:.. x = <unknown>' in output.getvalue()
    output.close()

    output = io.StringIO()
    pysnooper.snoop(output, watch=('x',))(lambda x: x)

# Generated at 2022-06-20 12:28:56.465695
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        path = os.path.join(tempdir, 'output.txt')
        file_writer = FileWriter(path, overwrite=False)
        for i in range(2):
            file_writer.write(u'line %s\n' % (i + 1))
        with open(path, 'r', encoding='utf-8') as f:
            assert f.read() == u'line 1\nline 2\nline 1\nline 2\n'



# Generated at 2022-06-20 12:29:05.768382
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from pysnooper.pycompat import collections_abc
    from pysnooper.snoop import Tracer
    from pysnooper.pycompat import importlib
    from pysnooper.pycompat import mock
    from pysnooper.pycompat import module_type
    from pysnooper.pycompat import OrderedDict
    from pysnooper.pycompat import patch
    from pysnooper.pycompat import StringIO
    from pysnooper.pycompat import sys
    from pysnooper.pycompat import text_type
    from pysnooper.pycompat import unittest
    from pysnooper.pycompat import uuid
    import pysnooper.utils
    import pysnooper.variables


# Generated at 2022-06-20 12:29:17.508254
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    global DISABLED
    output = StringIO()
    snoop = Tracer(output=output)
    def foo():
        pass
    snooped = snoop(foo)
    with snoop:
        assert snooped() is None
    assert output.getvalue() == 'Starting var:.. __return__ = None\n'
    output = StringIO()
    snoop = Tracer(output=output, depth=2)
    def foo():
        def bar():
            pass
        return bar()
    snooped = snoop(foo)
    with snoop:
        assert snooped() is None
    assert 'Starting var:.. __return__ = None' in output.getvalue(), output.getvalue()
    output = StringIO()
    snoop = Tracer(output=output, depth=0)

# Generated at 2022-06-20 12:29:20.686924
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(prefix='AAA ')
    def foo():
        print('foo')
    foo()

if __name__ == "__main__":
    test_Tracer()


# Generated at 2022-06-20 12:29:31.331447
# Unit test for method write of class Tracer
def test_Tracer_write():
    # Tests whether method write of class Tracer works correctly
    if len(sys.argv) != 2:
        pass
    if sys.argv[1] != 'test':
        pass
    # Creating a dummy file to test if overwriting works correctly
    with open('test.txt', 'w') as file:
        file.write('test' + '\n')
        file.close()
    # Creating instance of Tracer
    tracer = Tracer(output='test.txt', overwrite=True, prefix='-- ')
    # Writing to file
    tracer.write('test_write')
    # Testing whether file was overwritten and prefix was added correctly
    with open('test.txt', 'r') as file:
        content = file.read()
    assert content == '-- test_write\n'
test_Tracer_write

# Generated at 2022-06-20 12:29:37.710676
# Unit test for constructor of class Tracer
def test_Tracer():
    class Foo:
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def add(self, a):
            return a + self.x + self.y

    return_values = []
    with open(os.devnull, 'w') as null_file:
        @Tracer(output=null_file, watch=(('a','a'),'self'))
        def add_two_numbers(a, b):
            z = Foo(a, b)
            return_values.append(z.add(a))
            return_values.append(z.add(b))

    add_two_numbers(1, 2)

    assert return_values.pop() == 6
    assert return_values.pop() == 5

# Generated at 2022-06-20 12:29:48.310691
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import types
    import __future__

    class A(object):
        def __getattribute__(self, arg):
            pass
    a = A()
    code = a.__getattribute__.__code__
    code = types.CodeType(code.co_argcount, code.co_kwonlyargcount,
                          code.co_nlocals, code.co_stacksize, code.co_flags,
                          code.co_code, code.co_consts, code.co_names,
                          code.co_varnames, __file__, '__getattribute__',
                          code.co_firstlineno,
                          code.co_lnotab, (), ())
    frame = types.FrameType(globals(), locals(), code, None, None)
    result = get_path_and_

# Generated at 2022-06-20 12:29:55.406452
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t = Tracer(thread_info=True)
    assert t.thread_info_padding == 0
    result = t.set_thread_info_padding("")
    assert result == ""
    assert t.thread_info_padding == 0
    result = t.set_thread_info_padding("a")
    assert result == "a "
    assert t.thread_info_padding == 2
    result = t.set_thread_info_padding("bcd")
    assert result == "bcd "
    assert t.thread_info_padding == 4
    result = t.set_thread_info_padding("")
    assert result == "    "
    assert t.thread_info_padding == 4


# Generated at 2022-06-20 12:30:05.812971
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os
    import sys

    def function():
        return inspect.currentframe()

    frame = function()
    assert get_path_and_source_from_frame(frame) == \
                                          (__file__, open(__file__, 'rb').read().splitlines())

    frame = function()
    frame.f_globals['__name__'] = 'abc'
    assert get_path_and_source_from_frame(frame) == (__file__, UnavailableSource())

    frame = function()
    frame.f_globals['__loader__'] = 'abc'
    assert get_path_and_source_from_frame(frame) == (__file__, UnavailableSource())

    frame = function()
    def import_file(path):
        assert path == os.path.join

# Generated at 2022-06-20 12:30:14.079618
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[1] == 'SOURCE IS UNAVAILABLE'
    assert uas[2] == 'SOURCE IS UNAVAILABLE'
    assert uas[3] == 'SOURCE IS UNAVAILABLE'
    assert uas[-1] == 'SOURCE IS UNAVAILABLE'
    assert uas[-2] == 'SOURCE IS UNAVAILABLE'
    assert uas[-3] == 'SOURCE IS UNAVAILABLE'
    assert uas['junk'] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:50.987106
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    # test 1
    thread_info = "1-thread "
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == len(thread_info)
    # test 2
    thread_info = "22-thread "
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == len(thread_info)
    # test 3
    thread_info = "333-thread "
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == len(thread_info)
    thread_info = "333-thread "
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding

# Generated at 2022-06-20 12:31:52.359855
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print(Tracer().trace)
    None

# Generated at 2022-06-20 12:32:01.101453
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from . import pysnooper
    from .test_utils import get_test_cases_for_main
    from .test_utils import MainTestCase

    cases = get_test_cases_for_main(pysnooper)


# Generated at 2022-06-20 12:32:11.271271
# Unit test for method set_thread_info_padding of class Tracer

# Generated at 2022-06-20 12:32:14.175856
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import opcode
    frame = inspect.currentframe()
    for _ in range(2):
        frame = frame.f_back
    assert get_path_and_source_from_frame(frame)[0] == __file__



# Generated at 2022-06-20 12:32:17.580043
# Unit test for function get_write_function
def test_get_write_function():
    get_write_function(None, False)
    get_write_function(sys.stdout, False)
    with open('test_file.txt', 'w') as f:
        get_write_function(f, False)
        get_write_function(f, True)
    os.remove('test_file.txt')
    with open('test_file.txt', 'w') as f:
        get_write_function(f, False)
        get_write_function(f, False)



# Generated at 2022-06-20 12:32:20.435941
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from unittest import mock

    path = 'pysnooper.snoop'
    with mock.patch(path) as mock_snoop:
        with mock_snoop as mock_snooper:
            with mock_snooper as mock_tracer:
                with mock_tracer as mock_enter:
                    mock_enter.return_value = None
                    with snoop(output=None):
                        pass
                    assert mock_enter.call_count == 1



# Generated at 2022-06-20 12:32:28.092087
# Unit test for method write of class Tracer
def test_Tracer_write():
	# Parameter test
	# str -> str
	# return a str
    check_pysnooper.check("@pysnooper.snoop()\ndef test_Tracer_write():\n\ts = 'output'\n\ttracer = pysnooper.snooper.Tracer(output=s)\n\ts_result = tracer.write('s')\n\tprint(s_result)")
    # Expore result
    # str -> str
    # return a str

# Generated at 2022-06-20 12:32:34.523875
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer_instance = Tracer(thread_info=True)

    def test_thread_info_padding():
        for i in range(1, 20):
            thread_name = "Thread-" + str(i)
            current_thread = threading.Thread(target=do_nothing,
                                              name=thread_name)
            current_thread.start()
            current_thread.join()

    def do_nothing():
        pass

    test_thread_info_padding()

# Generated at 2022-06-20 12:32:42.915793
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from .utils import get_source

    def test_function():
        pass

    def test_generator():
        yield None

    def test_coroutine():
        yield None
        raise NotImplementedError

    def test_asyncgen():
        yield None
        yield None
        raise NotImplementedError

    test_function_with_docstring = """
    def test_function_with_docstring():
        """
    test_function_with_docstring += "line 1 docstring\nline 2 docstring"
    test_function_with_docstring += "line 3 docstring\nline 4 docstring"
    test_function_with_docstring += "line 5 docstring\nline 6 docstring"
    test_function_with_docstring += """"""
