

# Generated at 2022-06-20 12:26:05.642808
# Unit test for constructor of class Tracer
def test_Tracer():
    output = io.StringIO()
    # No watch:
    tracer = Tracer(output, watch=[], watch_explode=[], depth=1,
                    prefix='', overwrite=False, thread_info=False,
                    custom_repr=(), max_variable_length=100, normalize=False,
                    relative_time=False)
    assert tracer.watch == []
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.thread_info == False
    assert tracer.custom_repr == ()
    assert tracer.max_variable_length == 100
    assert tracer.normalize == False
    assert tracer.relative_time == False
    assert tracer._write == output.writelines
    assert tracer.thread_info_padding == 0
    assert tracer.target_codes

# Generated at 2022-06-20 12:26:09.650504
# Unit test for constructor of class Tracer
def test_Tracer():
    class TestClass():
        def __init__(self):
            pass
        def a(self, x, y):
            return x
        def b(self, a):
            return a
    tracer = Tracer()
    tracer._write = utils.FakeFile()
    tracer.__call__(TestClass)


# Generated at 2022-06-20 12:26:14.464603
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo(x, y, z):
        pass
    result = get_local_reprs(inspect.currentframe(), max_length=1)
    assert result == {'foo': 'f...', 'y': '...', 'z': '...', 'result': '{...}'}



# Generated at 2022-06-20 12:26:18.018672
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    UnavailableSource()[0]
    UnavailableSource()[100000]
    UnavailableSource()[-1000]


# Generated at 2022-06-20 12:26:28.582095
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import tempfile
    expected_result = u'(Tracer) depth: 0\n(Tracer) watch: []\n(Tracer) target_codes: set([])\n(Tracer) target_frames: set([])\n(Tracer) frame_to_local_reprs: {}\n(Tracer) start_times: {}\n(Tracer) thread_local.original_trace_functions: []\n'
    tracer = Tracer()

# Generated at 2022-06-20 12:26:32.320644
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    empty = UnavailableSource()
    assert empty[0] == u'SOURCE IS UNAVAILABLE'
    assert empty[5] == u'SOURCE IS UNAVAILABLE'
    assert empty[-1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:33.561375
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Call the method
    # No type checking
    pass


# Generated at 2022-06-20 12:26:38.199010
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func(x):
        y = 3
        return x + y
    frame = func.__code__.co_filename, func.__code__.co_firstlineno
    assert frame == get_path_and_source_from_frame(frame)



# Generated at 2022-06-20 12:26:49.110874
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # The function to be tested
    from .debug import get_path_and_source_from_frame
    # The objects needed to be faked
    import types
    import os.path
    # 1. Normal case:
    # The fake objects
    file_name = os.path.join(os.getcwd(), 'test.py')
    # The fake module
    module = types.ModuleType('test')
    module.__file__ = file_name
    module.__loader__ = None
    fp = open(file_name, 'w')
    fp.write('def f():\n    return 1\n')
    fp.close()
    # The fake frame

# Generated at 2022-06-20 12:26:56.979039
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    # First, let's make sure our functions work on plain files.
    with open('temp.py', 'wb') as f:
        f.write(b'print("hi")')
    sys.path.insert(0, '')
    import temp
    frame = inspect.currentframe()
    path, source = get_path_and_source_from_frame(frame)
    assert path == 'temp.py'
    assert source == ['print("hi")']
    del sys.modules['temp']
    sys.path.pop(0)
    os.remove('temp.py')

    # Now, let's make sure they work on IPython `%%` cells:

# Generated at 2022-06-20 12:27:27.753821
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    tracer.set_thread_info_padding("0")
    assert tracer.thread_info_padding == 1

    tracer.set_thread_info_padding("000")
    assert tracer.thread_info_padding == 3

    tracer.set_thread_info_padding("")
    assert tracer.thread_info_padding == 3


# Generated at 2022-06-20 12:27:30.579867
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = pysnooper.snoop()
    tracer.write("line1")
    tracer.write("line2")
    tracer.write("line3")
    tracer.write("line4")

# Generated at 2022-06-20 12:27:33.997437
# Unit test for method write of class Tracer
def test_Tracer_write():
    prefix = 'prefix'
    s = 'test'
    @pysnooper.snoop(prefix=prefix)
    def check(expected, actual):
        assert(expected == actual)
    check('{prefix}{s}\n'.format(**locals()), Tracer(prefix=prefix).write(s))


# Generated at 2022-06-20 12:27:36.918389
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == 'SOURCE IS UNAVAILABLE'
    
    

# Generated at 2022-06-20 12:27:47.880694
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    """
    Unit test for method __exit__
    """
    # raises error when calling __exit__
    # __exit__ returns None and does nothing
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises error when calling __exit__
    # raises

# Generated at 2022-06-20 12:27:51.928550
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    # It should return a unicode string
    assert isinstance(UnavailableSource()['a'], unicode)
    # It should behave as a read-only dictionary
    with pytest.raises(TypeError): UnavailableSource()['a'] = 4



# Generated at 2022-06-20 12:27:57.627802
# Unit test for method write of class Tracer
def test_Tracer_write():
    from io import TextIOWrapper
    from io import StringIO
    sio = StringIO()
    tio = TextIOWrapper(sio)
    self = Tracer(tio)
    s = '...'
    self.write(s)
    expectedResult = "..." + "\n"
    actualResult = sio.getvalue()
    assert actualResult == expectedResult

# Generated at 2022-06-20 12:27:59.500979
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:28:01.784289
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    frame = inspect.currentframe()
    event = 'call'
    arg = 'arg'
    tracer.trace(frame, event, arg)

# Generated at 2022-06-20 12:28:13.942863
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pysnooper.utils as utils
    import types
    from io import StringIO
    import os
    import sys
    import inspect
    import traceback
    import opcode
    import functools

    class CommonVariable:
        def __init__(self, name):
            self.name = name

        def __repr__(self):
            return 'CommonVariable({self.name!r})'.format(**locals())

        def __eq__(self, other):
            if isinstance(other, self.__class__):
                return self.name == other.name
            return NotImplemented

        def __ne__(self, other):
            if isinstance(other, self.__class__):
                return self.name != other.name
            return NotImplemented


# Generated at 2022-06-20 12:28:46.952866
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from types import FrameType

    # basic setup
    src_path = 'test_file.py'
    src = [
        "@pysnooper.snoop()",
        "def hello(name):",
        "    print(f'hello {name}!')",
        "",
        "@pysnooper.snoop()",
        "def goodbye(name):",
        "    print(f'goodbye {name}!')",
        "",
        "def main():",
        "    print('Calling hello()')",
        "    hello('Alice')",
        "    print('Calling goodbye()')",
        "    goodbye('Bob')",
        "    print('goodbye world')",
    ]
    frame = {}
    thread_global.depth = 0
    event = None
    arg = None
   

# Generated at 2022-06-20 12:28:58.753639
# Unit test for constructor of class FileWriter
def test_FileWriter():
    def test():
        f = FileWriter(r'C:\Python Projects\project\internals\test.py',
                       overwrite=True)
        f.write('This is a string')
        del f
        f = FileWriter(r'C:\Python Projects\project\internals\test.py',
                       overwrite=False)
        f.write('This is a string')
        del f
        f = FileWriter(r'C:\Python Projects\project\internals\test.py',
                       overwrite=True)
        f.write('This is a string')
        del f
        f = FileWriter(r'C:\Python Projects\project\internals\test.py',
                       overwrite=False)
        f.write('This is a string')

    test()


# Generated at 2022-06-20 12:29:04.194761
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # Test: call method __call__ of class Tracer with function as argument and
    # test to see if it is an instance of Tracer.
    assert isinstance(snoop()(foo), Tracer)
    # Test: call method __call__ of class Tracer with class as argument and test
    # to see if it is an instance of Tracer.
    assert isinstance(snoop()(Bar), Tracer)


# Generated at 2022-06-20 12:29:15.744441
# Unit test for constructor of class Tracer
def test_Tracer():
    from pysnooper.utils import LocalVariable, Exploding
    global_var = "a"
    watch=('foo', 'self', 'cls')
    watch_explode=(Exploding(global_var), LocalVariable('cls'))
    depth=3
    prefix='#####'
    overwrite=True
    thread_info=False
    custom_repr=((type, str),)
    max_variable_length=200
    normalize=True
    relative_time=True

# Generated at 2022-06-20 12:29:26.444442
# Unit test for constructor of class Tracer
def test_Tracer():
    def do_nothing():
        x = 3
        y = x
    tracer = Tracer(output=StringIO())
    trace = tracer.trace
    assert trace(None, None, None) == tracer.trace

    @pysnooper.snoop()
    def simple_function():
        x = 3
        y = x

    tracer = Tracer(depth=2, watch=['x', 'y'], watch_explode=['self'])
    @tracer
    def decorated_function(self):
        x = 3
        y = x
        self.a = 1
        self.b = 2
        return x

    decorated_function(decorated_function)

    target_codes = [do_nothing.__code__, simple_function.__code__, decorated_function.__code__]
   

# Generated at 2022-06-20 12:29:35.207094
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import nose

    import pysnooper
    import io

    def do_test_case(
            exc_type=None, exc_value=None, exc_traceback=None,
            watch=(),
            output='',
            prefix='',
            overwrite=False,
            thread_info=False,
            custom_repr=(),
            max_variable_length=100,
            normalize=False):
        pysnooper_io = io.StringIO()
        with Tracer(output=pysnooper_io, watch=watch,
                    prefix=prefix, overwrite=overwrite,
                    thread_info=thread_info,
                    custom_repr=custom_repr,
                    max_variable_length=max_variable_length,
                    normalize=normalize):
            raise exc_type(exc_value)
       

# Generated at 2022-06-20 12:29:36.291241
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
	pass # Doesn't have meaningful tests


# Generated at 2022-06-20 12:29:39.817170
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    assert source[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:29:49.963457
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Tracer/__enter__
    # Test that Tracer().__enter__() works in normal cases
    def dummy():
        pass

    with Tracer():
        dummy()
    assert True # used to verify we get to this point

    # Tracer/__enter__
    # Test that Tracer().__enter__() works if function call raises exception
    def dummy():
        raise Exception
    try:
        with Tracer():
            dummy()
    except Exception:
        pass
    else:
        assert False # should raise exception

    # Tracer/__enter__
    # Test that Tracer().__enter__() works with coroutine
    @asyncio.coroutine
    def dummy():
        pass

    with Tracer():
        dummy()
    assert True # used to verify we get to this point

    # Tracer/__enter__

# Generated at 2022-06-20 12:29:56.974819
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func():
        x = 1
        y = 2
        z = 3
        watched_variable_1 = 4
        watched_variable_2 = 5

    frame = utils.get_frame(func)

    assert get_local_reprs(frame) == collections.OrderedDict([
        ('watched_variable_1', '4'),
        ('watched_variable_2', '5'),
        ('x', '1'),
        ('y', '2'),
        ('z', '3'),
    ])

# Generated at 2022-06-20 12:30:44.446941
# Unit test for method write of class Tracer
def test_Tracer_write():
    with Tracer(output=sys.stdout, watch=(), watch_explode=(), depth=1,
             prefix='', overwrite=False, thread_info=False, custom_repr=(),
             max_variable_length=100, normalize=False, relative_time=False):
            tracer = Tracer()
            tracer.write(s='A string')

# Generated at 2022-06-20 12:30:47.467029
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding("1-1 ") == "1-1 ".ljust(7)



# Generated at 2022-06-20 12:30:57.578598
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import sys; sys.path.append('.')
    import test_smart_function
    # Take a frame that's in the middle of the program, and not at the start
    frame = sys._getframe(0)
    while frame.f_code.co_filename == __file__:
        frame = frame.f_back
    assert frame.f_code.co_filename.endswith('smart_function.py')

    path, source = get_path_and_source_from_frame(frame)
    assert path.endswith('smart_function.py')
    assert source[frame.f_lineno - 1].strip() == (
        'def test_get_path_and_source_from_frame():'
    )

test_get_path_and_source_from_frame()



# Generated at 2022-06-20 12:31:03.523702
# Unit test for method write of class Tracer

# Generated at 2022-06-20 12:31:10.513157
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    from io import StringIO
    from pysnooper import get_write_function
    import sys
    import threading
    from test_utils import TestCase, pycompat

    class Dummy:
        @staticmethod
        def sm():
            return 1

        @classmethod
        def cm(cls):
            return 2

        def instance(self):
            return 3

        def raise_exc(self):
            raise Exception('test')

    def func():
        return 4

    def gen():
        yield 5
        yield 6

    def raise_exc():
        raise Exception('test')

    if sys.version_info >= (3, 5):
        async def coro():
            return 7

        async def gencoro():
            yield 8
            yield 9


# Generated at 2022-06-20 12:31:16.117699
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import io
    from contextlib import contextmanager
    from pysnooper import snoop

    @snoop()
    def example():
        pass

    with redirect_stdout(io.StringIO()) as stdout:
        example()
    assert stdout.getvalue().strip().endswith('Elapsed time: 0:00:00.000002')

# Generated at 2022-06-20 12:31:19.329692
# Unit test for constructor of class FileWriter
def test_FileWriter():
    temp_path = 'some_path'
    overwrite = True
    s = 'some_string'
    file_writer = FileWriter(temp_path, overwrite)
    file_writer.write(s)



# Generated at 2022-06-20 12:31:25.480435
# Unit test for constructor of class Tracer
def test_Tracer():
    @snoop(watch=('foo', 'self'))
    def test_function(foo):
        pass

    assert len(test_function.__wrapped__.__snoop__.watch) == 2
    foo_exp, self_exp = test_function.__wrapped__.__snoop__.watch

    assert foo_exp.name == 'foo'
    assert not foo_exp.explode

    assert self_exp.name == 'self'
    assert self_exp.explode


# Generated at 2022-06-20 12:31:33.435531
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import os
    import tempfile
    import ast
    def make_file(contents, encoding='utf-8'):
        file_descriptor, path = tempfile.mkstemp(suffix='.py')
        os.close(file_descriptor)
        with open(path, 'wb') as f:
            f.write(contents.encode(encoding))
        return path
    def make_compiled_file():
        path = make_file('def f(x): return x + 1')
        return compile(open(path, 'rb').read(), path, 'exec')
    assert get_path_and_source_from_frame(
        ast.parse('1 + 2').body[0].lineno - 1
    ) == (__file__, UnavailableSource())

# Generated at 2022-06-20 12:31:38.206999
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(NotImplementedError):
        Tracer(output=None, watch=(), watch_explode=(), depth=1,
               prefix='', overwrite=False, thread_info=False, custom_repr=(),
               max_variable_length=100, normalize=False, relative_time=False)


# Generated at 2022-06-20 12:33:15.727074
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import doctest
    from pysnooper import snoop
    doctest.testmod(snoop, raise_on_error=True)


# Generated at 2022-06-20 12:33:21.407888
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer(depth=1, thread_info=True, max_variable_length=0)
    
    def test_frame():
        return 1
    tracer.__enter__()
    test_frame.__code__.co_name = 'a'
    # fake source code format
    test_frame.f_code.co_filename = 'test.py'
    test_frame.f_lineno = 0
    test_frame.f_locals = {'b': 1}
    test_frame.f_lasti = 1
    frame_code = bytes([1])
    try:
        test_frame.f_code.co_code = frame_code
    except TypeError:
        test_frame.f_code.co_code = frame_code.decode('utf-8')
    arg = None


# Generated at 2022-06-20 12:33:23.020189
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:33:28.712606
# Unit test for constructor of class Tracer
def test_Tracer():
    called = False

    def foo():
        pass

    def foo_called(*args, **kwargs):
        nonlocal called
        called = True

    tracer = Tracer(output=foo)
    with tracer:
        foo()

    assert called


if __name__ == '__main__':
    test_Tracer()

# Generated at 2022-06-20 12:33:34.969087
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    import os
    import pytest

    output_path = tempfile.mktemp()
    output_file = FileWriter(output_path, True)
    assert output_file.path == output_path
    assert output_file.overwrite == True
    output_file.write('This is written to the file')
    assert os.path.exists(output_path)
    with pytest.raises(Exception):
        output_file.write('This should not be written')
    assert os.path.exists(output_path)


# Generated at 2022-06-20 12:33:42.015704
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Setup
    tracer = Tracer(watch=('foo', 'self'))
    # Exercise
    delete_cover_files('tests/', 'test_Tracer___enter__')
    with open('tests/test_Tracer___enter__.cover', 'w') as f:
        with pysnooper.snoop(f, watch=('foo', 'self')):
            foo = 0
            foo = 1
    with open('tests/test_Tracer___enter__.cover', 'r') as f:
        output = f.read()
    # Verify
    assert_in('Starting var:.. foo = 0', output)
    assert_in('New var:....... foo = 1', output)

# Generated at 2022-06-20 12:33:49.852891
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.thread_info_padding == 0
    tracer.set_thread_info_padding("thread_info") == "thread_info"
    assert tracer.thread_info_padding == 12
    tracer.set_thread_info_padding("thread_info") == "thread_info   "
    assert tracer.thread_info_padding == 12
    tracer.set_thread_info_padding("thread_info_thread_info") == "thread_info_thread_info"
    assert tracer.thread_info_padding == 23
    tracer.set_thread_info_padding("thread") == "thread"
    assert tracer.thread_info_padding == 12


# Generated at 2022-06-20 12:33:59.074040
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print('Testing function "Tracer___call__"', file=sys.stderr)

    import datetime
    import inspect
    import functools
    import time
    import threading
    import os
    import itertools
    import traceback
    import sys
    import opcode
    import types
    import dis

    import pycompat
    import thread_global

    import utils

    t_Tracer = Tracer()
    t_function_or_class = None

    expected_output = None
    actual_output = t_Tracer(t_function_or_class)
    assert actual_output == expected_output, "'{actual_output}' should be '{expected_output}'".format(**locals())

    output_file = 'snoop.log'


# Generated at 2022-06-20 12:34:07.666778
# Unit test for function get_write_function
def test_get_write_function():
    from . import utils
    import io
    import tempfile
    import random

    output = io.StringIO()
    write = get_write_function(output, None)
    str1 = utils.random_string()
    write(str1)
    assert str1 == output.getvalue()

    output = io.StringIO()
    write = get_write_function(lambda s: output.write(s.upper()), None)
    str2 = utils.random_string()
    write(str2)
    assert str2.upper() == output.getvalue()

    with tempfile.NamedTemporaryFile(delete=False) as f:
        output1 = f.name
        str3 = utils.random_string()
        f.write(str3.encode())

# Generated at 2022-06-20 12:34:10.845560
# Unit test for constructor of class FileWriter
def test_FileWriter():
    fw = FileWriter(path='path', overwrite=True)
    assert fw.path == 'path'
    assert fw.overwrite == True
    assert type(fw.write) == types.MethodType
