

# Generated at 2022-06-20 12:25:53.517838
# Unit test for constructor of class FileWriter
def test_FileWriter():
    utils.assert_equal(FileWriter('C:/A/B/C.txt', True).path, 'C:/A/B/C.txt')
    utils.assert_equal(FileWriter('C:/A/B/C.txt', True).overwrite, True)



# Generated at 2022-06-20 12:26:02.461928
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tester = Tracer()
    tester.write = lambda s: print(s)

    def test():
        # Something to trace.
        pass

    test_frame = inspect.currentframe().f_back
    test_frame.f_code = test.__code__
    tester.target_codes.add(test.__code__)

    tester.trace(test_frame, 'line', None)
    tester.trace(test_frame, 'call', None)
    tester.trace(test_frame, 'line', None)
    tester.trace(test_frame, 'exception', (ZeroDivisionError(), '', None))
    tester.trace(test_frame, 'line', None)
    tester.trace(test_frame, 'call', None)

# Generated at 2022-06-20 12:26:07.119293
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer0 = Tracer(output=sys.stdout,watch=())  # Default init
    tracer1 = Tracer(output=sys.stdout,watch=('self',),watch_explode=('self',))
    tracer1.write('hello world')
    tracer1.write('hello world')
    assert tracer0 is not None
    assert tracer1 is not None
test_Tracer_write()


# Generated at 2022-06-20 12:26:13.558775
# Unit test for function get_write_function
def test_get_write_function():
    from . import sandbox
    from .tests.sandbox_test_cases.test_utils.test_print_tools \
         import FileWriter as TestFileWriter
    
    class MyStream(utils.WritableStream):
        def write(self, s):
            pass
    
    stderr = sys.stderr
    output = sandbox.SandboxedOutput()
    output.push_to_stderr()

# Generated at 2022-06-20 12:26:17.969575
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'
    assert uas[-1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:22.549056
# Unit test for function get_local_reprs
def test_get_local_reprs():
    square = lambda x: x ** 2
    expected_items = [('x', '2'), ('y', '4'), ('z', '3'), ('square', square)]
    if pycompat.PY2:
        expected_items.append(('unicode_', u'hello'))
    # note that square is also in locals, we get the repr from custom_repr
    locals_ = {'x': 2, 'y': square(x=2), 'z': 3, square: square}
    if pycompat.PY2:
        locals_['unicode_'] = 'hello'
    locals_['y'] = square(x=locals_['x'])
    frame = inspect.currentframe()

# Generated at 2022-06-20 12:26:32.571826
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from io import StringIO
    from pysnooper import snoop
    from .utils import utils

    def test(*args):
        global res
        res = StringIO()
        snoop(res, *args)(foo)(1, bar=2, baz=3)

    def foo(a, bar, baz):
        global res2
        res2 = StringIO()
        snoop(res2)(bar)

    def bar():
        global res3
        res3 = StringIO()
        snoop(res3)(baz)

    def baz():
        with snoop():
            pass

    # 1. test
    with pytest.raises(NotImplementedError):
        test(normalize=True)

# Generated at 2022-06-20 12:26:35.106902
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os.path
    assert FileWriter('test.txt', True).write('hello') == None # noqa
    with open('test.txt', 'r', encoding='utf-8') as file:
        assert file.read() == 'hello'
    os.remove('test.txt')



# Generated at 2022-06-20 12:26:47.246777
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop(output=None)
    def foo():
        pass
    foo()

# Generated at 2022-06-20 12:26:55.698145
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import re
    import sys
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import datetime
    import re
    import sys
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import datetime
    import re
    import sys
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import datetime
    import re
    import sys
    import os
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import pycompat
    import datetime
    import re
    import sys
    import os

# Generated at 2022-06-20 12:27:26.256686
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer(output=sys.stdout, watch=(), watch_explode=(), depth=1,
                    prefix='', overwrite=False, thread_info=False, custom_repr=(),
                    max_variable_length=100, normalize=False, relative_time=False)

# Generated at 2022-06-20 12:27:34.003365
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest.mock
    import unittest

    class MockFrame:
        pass

    @pysnooper.snoop()
    def foo():
        pass

    def bar():
        pass

    foo.__code__ = object()
    foo.__code__.co_filename = object()
    target_code = object()

    with unittest.TestCase() as case:
        case.assertEqual(
            pysnooper.snoop(watch='a')(foo),
            foo
        )
        mock_write = unittest.mock.Mock()
        mock_function = unittest.mock.Mock()
        mock_function.__code__ = target_code
        mock_function.__code__.co_filename = foo.__code__.co_filename
        sn

# Generated at 2022-06-20 12:27:35.603145
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass # TODO


# Generated at 2022-06-20 12:27:39.093028
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[1] == unavailable_source[2] == \
                                  unavailable_source[3] == \
                                  u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-20 12:27:45.743436
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from pysnooper import snoop
    with snoop(normalize=True, depth=1):
        class C:
            def __init__(self, i: int):
                self.i = i

            def f(self) -> int:
                j = 3
                return self.i + j

        c = C(4)
        # print(c.f())

    # assert c.f() == 7


# Generated at 2022-06-20 12:27:47.649985
# Unit test for method write of class Tracer
def test_Tracer_write():
    e = Tracer()
    e.write()


# Generated at 2022-06-20 12:27:55.408773
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # This test will fail if not allowed to create a file
    import tempfile
    with tempfile.TemporaryDirectory() as temp_directory:
        file_name = os.path.join(temp_directory, 'test.txt')
        file_writer = FileWriter(file_name, True)
        file_writer.write('Hello,\n')
        assert open(file_name, 'r').read() == 'Hello,\n'
        file_writer.write('world\n')
        assert open(file_name, 'r').read() == 'Hello,\nworld\n'


# Generated at 2022-06-20 12:27:57.056497
# Unit test for function get_write_function
def test_get_write_function():
    from .tests.test_utils import StringIO
    msg = 'Stop me before I kill again!'
    assert FileWriter(StringIO(), overwrite=False).write(msg) == msg



# Generated at 2022-06-20 12:28:06.757203
# Unit test for constructor of class Tracer
def test_Tracer():
    import sys
    import os
    import io

    # Create a file-like class
    test_IO = io.StringIO()
    # Create a writer function
    test_write = test_IO.write

    # Check whether the constructor of the Tracer class works properly
    # Create a instance of Tracer
    tracer_test = Tracer()
    # Add the Tracer instance to the namespace
    sys.modules['__main__'].tracer_test = tracer_test
    # Execute the test
    exec('''
from __main__ import tracer_test
with tracer_test:
    x = 1
''', {}, {})

    # Check the output
    assert 'Tracer.__init__' in test_IO.getvalue()


# Generated at 2022-06-20 12:28:16.376935
# Unit test for constructor of class FileWriter
def test_FileWriter():
    a_string = 'a string'
    path = 'file.txt'
    file_writer = FileWriter(path, overwrite=False)
    file_writer.write(a_string)
    result = open(path).read()
    assert result == a_string
    file_writer.write('another string')
    result = open(path).read()
    assert result == a_string + 'another string'
    os.remove(path)
    file_writer = FileWriter(path, overwrite=True)
    file_writer.write(a_string)
    result = open(path).read()
    assert result == a_string
    os.remove(path)



# Generated at 2022-06-20 12:28:39.137107
# Unit test for function get_write_function
def test_get_write_function():
    assert isinstance(get_write_function(None, False), collections.Callable)
    assert isinstance(get_write_function(pathlib.Path('.'), False), collections.Callable)
    assert isinstance(get_write_function(lambda x:x, False), collections.Callable)
    assert isinstance(get_write_function(sys.stdout, False), collections.Callable)



# Generated at 2022-06-20 12:28:40.383700
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-20 12:28:49.389848
# Unit test for constructor of class FileWriter

# Generated at 2022-06-20 12:28:55.356900
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
  import pytest
  with pytest.raises(Exception):
    tracer = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False)
    tracer.write = lambda s: None
    with tracer:
      raise Exception("")

# Generated at 2022-06-20 12:28:57.747137
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[0] == source[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:28:59.051535
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write("test")


# Generated at 2022-06-20 12:29:01.547589
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[10] == u'SOURCE IS UNAVAILABLE'
    assert u'SOURCE' in UnavailableSource()[10:20]
# Test is over



# Generated at 2022-06-20 12:29:09.524268
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from unittest import TestCase
    from unittest.mock import patch, MagicMock

    class Test(TestCase):
        def test(self):
            mock_exc_type = MagicMock()
            mock_exc_value = MagicMock()
            mock_exc_traceback = MagicMock()
            mock_self = MagicMock(spec=Tracer)
            mock_self.target_frames = {MagicMock()}
            mock_self.target_codes = {MagicMock()}

            # include actual function call
            with patch.object(snooper.utils, 'get_thread_depth',
                              return_value=1) as patched_get_thread_depth:

                with patch.object(snooper.Tracer, 'write') as patched_write:
                    snooper.Tracer.__

# Generated at 2022-06-20 12:29:18.070005
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = sys.stdout
    watch = ()
    watch_explode = ()
    depth = 1
    prefix = ''
    overwrite = False
    thread_info = False
    custom_repr = ()
    max_variable_length = 100
    normalize = False
    relative_time = False

    my_snooper = Tracer(
        output, watch, watch_explode, depth, prefix, overwrite, thread_info,
        custom_repr, max_variable_length, normalize, relative_time
    )
    my_snooper.write("hello world")


# Generated at 2022-06-20 12:29:21.961319
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    output = io.StringIO()
    t = Tracer(output)
    output.getvalue() == ''
    t.write("testing write...")
    assert output.getvalue() == 'testing write...\n'
    output.close()

# Generated at 2022-06-20 12:30:12.697010
# Unit test for constructor of class Tracer
def test_Tracer():
    # test output
    output = StringIO()
    # test watch with tuple
    watch = ('a', 'b')
    watch_explode = ('c', 'd')
    # test custom_repr
    custom_repr = ((object,
                    lambda x: 'Object'),)
    my_repr = CustomRepr(custom_repr=custom_repr)
    # test max_variable_length
    max_variable_length = 2
    # test normalize
    normalize = True
    # test relative_time
    relative_time = True
    # test Tracer constructor

# Generated at 2022-06-20 12:30:14.421161
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:30:16.258731
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    obj = UnavailableSource()
    assert obj[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:30:25.973074
# Unit test for function get_local_reprs
def test_get_local_reprs():
    from .variables import IntegerVariable, StringVariable
    from .tests.variables import assert_values
    from .tests.utils import Case
    Case(lambda: get_local_reprs(dict(a=1, z=2, c=3)),
         assert_values,
         dict(a=1, z=2, c=3))
    Case(lambda: get_local_reprs(
        dict(b=IntegerVariable('b'), c=StringVariable('c')),
        watch=(StringVariable('c'),)
    ),
         assert_values,
         dict(b='b', c='c'))

# Generated at 2022-06-20 12:30:29.939796
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer(output=None)

    def test(s):
        assert isinstance(s, pycompat.text_type)
        return len(s)

    tracer._write = test

    tracer.write('string')


# Generated at 2022-06-20 12:30:40.996908
# Unit test for constructor of class Tracer
def test_Tracer():
    # Tracer class has no unit tests for now.
    #
    # The following code was written for an earlier version, but it's not
    # guaranteed to be bug free, and it's not updated to the current version
    # either:

    # class Foo:
    #     def bar(self):
    #         return self.baz

    #     def baz(self):
    #         pass

    # output = StringIO()
    # foo = Foo()
    # with Tracer(output):
    #     foo.bar()
    # assert not output.getvalue()
    # foo = Foo()
    # with Tracer(output, ('self.baz',)):
    #     foo.bar()
    # assert 'Return value....' in output.getvalue()
    pass



# Generated at 2022-06-20 12:30:47.584496
# Unit test for function get_write_function
def test_get_write_function():
    from .test_utils import assert_calls_equiv

    with assert_calls_equiv([[lambda s: sys.stderr.write(utils.shitcode(s))]],
                            get_write_function, [None]):
        print()

    with open('testfile', 'w') as file:
        with assert_calls_equiv([[file.write]], get_write_function,
                                [file]):
            print()

    class CollectWrites(object):
        def __init__(self):
            self.lines = []

        def write(self, s):
            self.lines.append(s)

    collect_writes = CollectWrites()

# Generated at 2022-06-20 12:30:54.276381
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = '__test_file.txt'
    f = FileWriter(path, True)
    f.write('blah')
    with open(path) as f:
        result = f.read()
    assert result == 'blah'
    f.write('blih')
    with open(path) as f:
        result = f.read()
    assert result == 'blih'
    os.remove(path)
test_FileWriter_write()



# Generated at 2022-06-20 12:30:55.634843
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()  # We only check that it works



# Generated at 2022-06-20 12:30:57.280607
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    @pysnooper.snoop()
    def hello():
        print("hello")
    hello()

# Generated at 2022-06-20 12:34:21.504401
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        x = 1
        if x:
            y = 2
        z = 'abc'
        return (x, y, z)
    frame = sys._getframe()
    frame = frame.f_back.f_back.f_back
    dict = get_local_reprs(frame)
    assert dict['y'] == '2'
    assert dict['__return__'] == '(1, 2, abc)'



# Generated at 2022-06-20 12:34:25.524706
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from . import pysnooper

    def foo():
        pass

    decorator = pysnooper.snoop(watch_explode=['foo', 'self'])
    foo = decorator(foo)

    assert isinstance(foo, functools.wraps(foo))
    assert foo.snoopers[0] == decorator

# Generated at 2022-06-20 12:34:28.849473
# Unit test for method write of class Tracer
def test_Tracer_write():
    snooper_output = StringIO()
    s = Tracer(output=snooper_output)
    s.write('hello world')
    assert snooper_output.getvalue() == 'hello world\n'
    snooper_output.close()


# Generated at 2022-06-20 12:34:31.832327
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    import sys
    import shutil
    import sweet_inspect as plugin

# Generated at 2022-06-20 12:34:40.803785
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from .utils import reset_redefined_builtins

    with reset_redefined_builtins():
        import inspect
        import threading
        from .utils import get_write_function

        class Tracer(object):
            def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
                         prefix='', overwrite=False, thread_info=False, custom_repr=(),
                         max_variable_length=100, normalize=False, relative_time=False):
                self._write = get_write_function(output, overwrite)


# Generated at 2022-06-20 12:34:43.525411
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import builtins
    with replace(builtins, 'open', mock_open()):
        with Tracer(overwrite=True):
            def dummy_func():
                pass
            dummy_func()
        dummy_func()


# Generated at 2022-06-20 12:34:45.374862
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    for i in (-100, -1, 0, 1, 100):
        assert isinstance(UnavailableSource()[i], str)



# Generated at 2022-06-20 12:34:53.330257
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    depth = -1
    def set_depth(x):
        global depth
        depth = x
    thread_global.depth = depth
    snooper = pysnooper.Snooper(Snooper)
    def function_or_class():
        return
    with snooper:
        function_or_class()
    import datetime
    from pycompat import time_isoformat
    print("n:", len(snooper.start_times))
    print("start_time:", snooper.start_times.get(function_or_class.__code__))
    print("duration:", datetime.datetime.now() - snooper.start_times.get(function_or_class.__code__))

# Generated at 2022-06-20 12:35:03.946136
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func(a, b, c, d=4, e=5, f=6, *g, **h):
        def inner_func():
            return f
        inner_func()
        return a, b, c, d, e, f, g, h
    frame = utils.Frame(func, (1,2,3), {'d':7, 'e':8, 'f':9}, (10,11,12), h=13)
    assert get_local_reprs(frame) == collections.OrderedDict(
        a=1, b=2, c=3, d=7, e=8, f=9, g=(10, 11, 12), h=13
    )