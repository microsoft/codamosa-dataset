

# Generated at 2022-06-20 12:25:58.569687
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        i = 0
        j = Exploding()
        return i, j

    frame = inspect.currentframe()
    expected = {'frame': '<frame object at 0x...>', 'i': '0', 'j': '...'}
    assert get_local_reprs(frame.f_back) == expected
    expected = {'frame': '...', 'i': '0', 'j': '...'}
    assert get_local_reprs(frame.f_back, max_length=3) == expected




# Generated at 2022-06-20 12:26:01.328612
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    from .utils import assert_equal
    assert_equal(UnavailableSource()[1], u'SOURCE IS UNAVAILABLE')



# Generated at 2022-06-20 12:26:09.611162
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from unittest import mock
    import pysnooper

    x = pysnooper.Tracer()
    x.prefix = mock.Mock(return_value='prefix')
    x.write = mock.Mock()
    x.start_times = {mock.Mock(): mock.Mock()}
    x.frame_to_local_reprs = {mock.Mock(): mock.Mock()}
    x.target_frames = {mock.Mock()}

    source_code = []
    with mock.patch.object(pysnooper, 'DISABLED', False):
        with mock.patch.object(threading, 'current_thread') as current_thread:
            current_thread.getName.return_value = 'thread_name'

# Generated at 2022-06-20 12:26:15.209563
# Unit test for function get_write_function
def test_get_write_function():
    def _func():
        import threading
        local = threading.local()
        local.result_list = []
        def func(s):
            local.result_list.append(s)
        return func
    write = get_write_function(None, False)
    write('abc')
    class Output(object):
        def __init__(self):
            self.s = ''

        def write(self, s):
            self.s += s
    output = Output()
    write = get_write_function(output, False)
    write('abc')
    assert output.s == 'abc'
    func = _func()
    write = get_write_function(func, False)
    write('abc')
    assert len(func.__self__.result_list) == 1

# Generated at 2022-06-20 12:26:23.505374
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import six
    import pickle
    with six.moves.cStringIO() as fp:
        # test for first write
        f = FileWriter(fp, True)
        f.write('hello')
        f.write(pickle.dumps(b'hello'))
        out = fp.getvalue()
        assert out == "hellohello"
        # test for overwrite
        f.write('world')
        out = fp.getvalue()
        assert out == "helloworld"



# Generated at 2022-06-20 12:26:26.772911
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(AssertionError):
        assert Tracer(depth=0)

    with pytest.raises(AssertionError):
        assert Tracer(depth=1.2)


# Generated at 2022-06-20 12:26:28.172224
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:34.085855
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer()
    assert tracer.watch == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local.__dict__ == {}
    assert tracer.normalize == False
    assert tracer.relative_time == False

test_Tracer()

# Generated at 2022-06-20 12:26:35.851596
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:38.755805
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    for i in range(-4, 5):
        unavailable_source[i]


# Generated at 2022-06-20 12:27:18.394264
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    output_file = StringIO()
    tracer = Tracer(output_file)
    tracer(test_fixture_for_test_Tracer___call__)
    assert output_file.getvalue() == """Source path:... test_pysnooper.py
Starting var:.. k = 2
Starting var:.. i = 1
New var:....... j = 2
Modified var:.. j = 3
Call ended by exception
Return value:.. None
Source path:... test_pysnooper.py
Starting var:.. k = 2
Starting var:.. i = 1
New var:....... j = 2
Modified var:.. j = 3
Return value:.. 4
Elapsed time: 0:00:00.000003
Elapsed time: 0:00:00.000003
"""


# Generated at 2022-06-20 12:27:25.467955
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from test_utils.test_cases.BaseTestCase import BaseTestCase
    from datetime import datetime
    from io import StringIO
    from unittest.mock import patch
    import tempfile
    import os
    import contextlib
    import inspect

    class TracerTest(BaseTestCase):
        def setUp(self):
            BaseTestCase.setUp(self)
            self.snooper = Tracer(output=None, watch=None, watch_explode=None, depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)


# Generated at 2022-06-20 12:27:33.127071
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    __tracebackhide__ = True
    def test():
        a = 1
        b = 2
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1
        a = a + 1


# Generated at 2022-06-20 12:27:41.101277
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    writer = FileWriter('file.txt', overwrite=True)
    writer.write('Line1')
    writer.write('Line2')
    writer.write('Line3')
    with open('file.txt', encoding='utf-8') as f:
        assert f.read() == 'Line1Line2Line3'
    writer = FileWriter('file.txt', overwrite=True)
    writer.write('Line4')
    with open('file.txt', encoding='utf-8') as f:
        assert f.read() == 'Line4'
    os.remove('file.txt')



# Generated at 2022-06-20 12:27:44.581867
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import datetime
    t = Tracer()
    try:
        with t:
            pass
    except:
        assert False, 'Unreachable'
    return



# Generated at 2022-06-20 12:27:51.801922
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from pysnooper import snoop
    @snoop()
    def foo():
        pass
    # call foo() first, to get the snoop target frame
    foo()
    # to make sure depth = -1
    tracer = Tracer()
    stack = tracer.thread_local.__dict__.setdefault('original_trace_functions', [])
    tracer.__enter__()
    assert thread_global.__dict__.setdefault('depth', -1) == -1
    assert stack == [sys.gettrace()]



# Generated at 2022-06-20 12:27:57.105068
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x):
        y = [1, 2, 3]
        del y[0]
        return x * 44
    local_reprs = get_local_reprs(get_frame(f, [4]), ('y',))
    assert local_reprs['y'] == '[2, 3]'
    assert 'x' not in local_reprs


# Generated at 2022-06-20 12:27:59.889931
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    my_UnavailableSource = UnavailableSource()
    assert my_UnavailableSource[0, 0] == u'SOURCE IS UNAVAILABLE'
    assert my_UnavailableSource == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:28:03.545446
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    current_thread = threading.current_thread()
    thread_info = "{ident}-{name} ".format(ident=current_thread.ident, name=current_thread.getName())
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == len(thread_info)



# Generated at 2022-06-20 12:28:08.886337
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.set_thread_info_padding("A-a ")
    assert tracer.thread_info_padding == 4
    tracer.set_thread_info_padding("A-a-a ")
    assert tracer.thread_info_padding == 6



# Generated at 2022-06-20 12:28:47.353698
# Unit test for method write of class Tracer
def test_Tracer_write():
    global tracer
    tracer = Tracer(output='pysnooper.log', watch='*', watch_explode='*')
    def add(a, b): 
        c = a + b
        return c
    with tracer:
        add(1, 2)

# Generated at 2022-06-20 12:28:59.427584
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():

    obj = Tracer()
    info = 'main thread'
    obj.thread_info_padding = -1
    assert obj.set_thread_info_padding(info) == 'main thread '
    obj.thread_info_padding = 0
    assert obj.set_thread_info_padding(info) == 'main thread '
    obj.thread_info_padding = 1
    assert obj.set_thread_info_padding(info) == 'main thread '
    obj.thread_info_padding = 5
    assert obj.set_thread_info_padding(info) == 'main thread '
    obj.thread_info_padding = 8
    assert obj.set_thread_info_padding(info) == 'main thread '
    obj.thread_info_padding = 9

# Generated at 2022-06-20 12:29:08.138201
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def _gen_code(depth):
        if pycompat.PY2:
            code_template = '''
                def foo():
                    return {}
            '''
        else:
            # On Python 3, the dis function treats the function name as a
            # local variable.
            code_template = '''
                def foo():
                    _name_0_ = 'foo'
                    return {}
            '''
        return compile(code_template.format(
            '\n'.join('foo()' for _ in range(depth))
        ), '<string>', 'exec')

    for depth in (1, 2):
        code = _gen_code(depth)
        target = Tracer(depth=depth)
        globals_ = {}
        locals_ = {}
        retval = target.__call__(code)
       

# Generated at 2022-06-20 12:29:15.533637
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    path = tempfile.mktemp()
    try:
        FileWriter(path, True).write('abc')
        with open(path, 'r', encoding='utf-8') as f:
            assert f.read() == 'abc'
        FileWriter(path, False).write('def')
        with open(path, 'r', encoding='utf-8') as f:
            assert f.read() == 'abcdef'
    finally:
        os.unlink(path)



# Generated at 2022-06-20 12:29:26.217839
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Test cases that should fail
    assert TestFailure(
        TypeError,
        Tracer,
        "output",
        output = ('a',)
    ).fail()

    assert TestFailure(
        TypeError,
        Tracer,
        "watch",
        watch = ('a',)
    ).fail()

    assert TestFailure(
        TypeError,
        Tracer,
        "watch_explode",
        watch_explode = ('a',)
    ).fail()

    assert TestFailure(
        TypeError,
        Tracer,
        "depth",
        depth = ('a',)
    ).fail()

    assert TestFailure(
        TypeError,
        Tracer,
        "prefix",
        prefix = ('a',)
    ).fail()


# Generated at 2022-06-20 12:29:35.033357
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        import datetime as module
        module.datetime.now()
        sys.exit()
    assert get_path_and_source_from_frame(inspect.currentframe().f_back) == (
        os.path.abspath(__file__),
        UnavailableSource()
    )

# Generated at 2022-06-20 12:29:45.459340
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    if threading.current_thread().getName() == "MainThread":
        thread_info = "99999-MainThread"
    else:
        thread_info = "99999-Thread-1"
    assert tracer.set_thread_info_padding(thread_info) == "99999-MainThread "
    thread_info = "99-Thread-1"
    assert tracer.set_thread_info_padding(thread_info) == "99-Thread-1       "
    thread_info = "9999-Thread-1"
    assert tracer.set_thread_info_padding(thread_info) == "9999-Thread-1     "


# Generated at 2022-06-20 12:29:46.470114
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pytest.skip()

# Generated at 2022-06-20 12:29:54.245455
# Unit test for function get_write_function
def test_get_write_function():
    def my_write_function(s):
        assert isinstance(s, str)
    null_write_function = get_write_function(None, False)
    my_write_function = get_write_function(my_write_function, False)
    import io
    my_writable_stream = io.StringIO()
    my_writable_stream_write_function = get_write_function(
                                                        my_writable_stream,
                                                        False)
    null_write_function('hi')
    my_write_function('hello')
    my_writable_stream_write_function('goodbye')
    assert my_writable_stream.getvalue() == 'goodbye'
test_get_write_function()



# Generated at 2022-06-20 12:30:02.912909
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    thread_global.padding = tracer.set_thread_info_padding
    thread_global.pad = 0
    threading.Thread(target=thread_f0, args=(tracer,)).start()
    time.sleep(0.25)
    threading.Thread(target=thread_f1, args=(tracer,)).start()
    time.sleep(0.25)
    threading.Thread(target=thread_f2, args=(tracer,)).start()
    time.sleep(0.25)
    assert thread_global.pad == 9
    print("tracer.thread_info_padding:", tracer.thread_info_padding)


# Generated at 2022-06-20 12:30:44.172641
# Unit test for function get_write_function
def test_get_write_function():
    from .utils import FakeStdout, FakeStream

    write = get_write_function(None, False)
    write('hello')

    write = get_write_function('foo', False)
    write('hello')
    with open('foo') as f:
        assert f.read() == 'hello'

    write = get_write_function(FakeStdout(), False)
    assert write('hello') == 'hello'

    write = get_write_function(FakeStream(), False)
    assert write('hello') == 'hello'

    def write(x):
        return x

    write = get_write_function(write, False)
    assert write('hello') == 'hello'



# Generated at 2022-06-20 12:30:49.221363
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def wrapped_function(self):
        pass
    function = wrapped_function.__wrapped__
    assert function != wrapped_function
    assert inspect.isroutine(function)
    assert not inspect.isroutine(wrapped_function)
    assert inspect.isgeneratorfunction(function) == inspect.isgeneratorfunction(wrapped_function)
test_Tracer___call__()

# Generated at 2022-06-20 12:30:51.338749
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source_lines = UnavailableSource()
    source_lines[0]



# Generated at 2022-06-20 12:31:01.441981
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Dummy classes to avoid errors with settrace
    import threading
    import time
    class _DummyFrame:
        pass
    class _DummyCode:
        pass
    frame_1 = _DummyFrame()
    frame_1.f_code = _DummyCode()
    frame_1.f_code.co_filename = Tracer.__enter__.__code__.co_filename
    frame_1.f_lineno = 1
    frame_1.f_lasti = 0
    frame_1.f_code.co_code = b''
    frame_2 = _DummyFrame()
    frame_2.f_code = _DummyCode()
    frame_2.f_code.co_filename = 'test_Tracer_trace.py'
    frame_2.f_lineno = 2


# Generated at 2022-06-20 12:31:09.487102
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():

    tracer = Tracer()

    thread_info = 'Thread-1-'
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == len(thread_info)

    thread_info = 'Thread-25-'
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == len(thread_info)

    thread_info = 'Thread-100-'
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == len(thread_info)

    thread_info = 'Thread-1-MainThread'
    expected = len(thread_info)
    tracer.set_thread_info_padding(thread_info)
    assert tracer.thread_info_padding == expected

# Generated at 2022-06-20 12:31:13.277327
# Unit test for constructor of class Tracer
def test_Tracer():
    with pytest.raises(AssertionError):
        Tracer(depth=0)

    with pytest.raises(AssertionError):
        Tracer(depth=-2)


# Generated at 2022-06-20 12:31:22.919235
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Assert that Tracer.__exit__()'s first argument is 'exc_type'
    # Assert that Tracer.__exit__()'s second argument is 'exc_value'
    # Assert that Tracer.__exit__()'s third argument is 'exc_traceback'
    # Assert that Tracer.__exit__()'s fourth argument is 'exc_type=None'
    # Assert that Tracer.__exit__()'s fifth argument is 'exc_value=None'
    # Assert that Tracer.__exit__()'s sixth argument is 'exc_traceback=None'
    # Assert that Tracer.__exit__()'s return value is None
    assert True # TODO: implement your test here


# Generated at 2022-06-20 12:31:26.518134
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import os
    from ._version import __version__
    from .utils import get_shortish_repr
    from .config import s
    import sys
    a = Tracer()
    b = Tracer.__call__(a, func2)
    b(1)

# Generated at 2022-06-20 12:31:27.525853
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass



# Generated at 2022-06-20 12:31:34.648804
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    def callable_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function(): pass
    class Foo: pass
    function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_function_

# Generated at 2022-06-20 12:33:06.288180
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    from .watch import _TraceEvent
    from .watch import _Tracer
    tracing_obj = Tracer(output=None, watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    stack_frame = "stack_frame"
    event = "event"
    arg = "arg"
    testing_obj = _Tracer()
    testing_obj.watch = [
        v if isinstance(v, BaseVariable) else CommonVariable(v)
        for v in utils.ensure_tuple(())
    ]

# Generated at 2022-06-20 12:33:08.778896
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    x = 1
    @pysnooper.snoop()
    def foo():
        nonlocal x
        x += 2
        return x
    foo()


# Generated at 2022-06-20 12:33:10.438737
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[3] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:33:14.662671
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    print('Testing Tracer.__call__')
    def test_func():
        pass
    watch = ('test_func', 'self')
    t = Tracer(watch=watch, max_variable_length=None)
    f = t.__call__(test_func)
    assert f is not None


# Generated at 2022-06-20 12:33:15.276927
# Unit test for constructor of class Tracer
def test_Tracer():
    raise NotImplementedError


# Generated at 2022-06-20 12:33:19.457372
# Unit test for method write of class Tracer
def test_Tracer_write():
    dump_file = tempfile.mktemp()
    with open(dump_file, 'w') as f:
        def write(s):
            f.write(s)
        p = Tracer(write)
        p.write('hello')
        p.write("world")
    with open(dump_file, 'r') as f:
        assert f.read() == 'helloworld\n'
    os.remove(dump_file)

# Generated at 2022-06-20 12:33:26.397308
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer(output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr, max_variable_length, normalize)
    def func():
        pass
    if inspect.isclass(function_or_class):
        return self._wrap_class(function_or_class)
    else:
        return self._wrap_function(function_or_class)
    tracer.__call__(func)


# Generated at 2022-06-20 12:33:29.003592
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding("")=="      "

# Generated at 2022-06-20 12:33:33.639995
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        x = 1
        def g():
            y = 2
            return locals()
        return g()
    local_reprs = get_local_reprs(f().f_back)
    assert local_reprs == collections.OrderedDict([('x', '1'),
                                                   ('y', '2')])


# Generated at 2022-06-20 12:33:41.771799
# Unit test for method write of class Tracer
def test_Tracer_write():
	def get_write_function(output, overwrite):
		if output is None:
			return sys.stdout.write
		elif isinstance(output, str):
			if overwrite:
				return lambda s: open(output, 'w', encoding='utf-8').write(s)
			else:
				return lambda s: open(output, 'a', encoding='utf-8').write(s)
		else:
			return output.write