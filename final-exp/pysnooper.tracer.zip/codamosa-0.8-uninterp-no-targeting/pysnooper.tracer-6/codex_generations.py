

# Generated at 2022-06-20 12:26:13.683872
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = inspect.stack()[1][0]
    locals_before = frame.f_locals.copy()
    x = 2
    locals_after = frame.f_locals.copy()
    assert locals_before == get_local_reprs(frame)
    assert locals_after == get_local_reprs(frame)
    assert {'x': '2'} == get_local_reprs(frame, custom_repr={int: lambda x: 'custom'})



# Generated at 2022-06-20 12:26:18.069586
# Unit test for constructor of class FileWriter
def test_FileWriter():
    output_file=FileWriter("/tmp/output", True)
    assert pycompat.text_type(output_file) == "FileWriter('/tmp/output', True)"

test_FileWriter()



# Generated at 2022-06-20 12:26:22.347162
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import StringIO

    import six
    import pytest

    from pysnooper import snoop, thread_global, utils

    tmpdir = six.moves.tempfile.mkdtemp()

    class Class:
        def __init__(self):
            self.a = 1

        def method(self):
            return 6

    @snoop(watch=('foo', 'self.a'))
    @snoop(watch=('self.b',))
    @snoop()
    def function(foo, bar):
        return 5


    @snoop(watch=('self.a', ))
    class ClassWithSnoop(Class):
        def method(self):
            return 7


# Generated at 2022-06-20 12:26:30.308050
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile(mode='w')
    file_writer = FileWriter(tmp_file.name, True)
    file_writer.write('This is a test\n')
    tmp_file.seek(0)
    assert tmp_file.read() == 'This is a test\n'
    file_writer.write('This is a test2\n')
    tmp_file.seek(0)
    assert tmp_file.readlines() == ['This is a test\n', 'This is a test2\n']
    tmp_file.close()



# Generated at 2022-06-20 12:26:33.690770
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y):
        '''hi'''
        a = 5
        b = 6
        return locals()
    l = f('spam', 'eggs')
    expected = {
        'y': repr('eggs'),
        'x': repr('spam'),
        'a': repr(5),
        'b': repr(6),
    }
    result = dict(get_local_reprs(l['__frame__']))
    assert result == expected, (result, expected)




# Generated at 2022-06-20 12:26:39.085035
# Unit test for constructor of class FileWriter
def test_FileWriter():
    fw = FileWriter(r'abc', True)
    assert fw.path is r'abc'
    assert fw.overwrite is True

    # test write()
    fw.write('hello world')
    with open('abc', 'r', encoding='utf-8') as f:
        assert f.read() == 'hello world'



# Generated at 2022-06-20 12:26:48.528932
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[3:3] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[3:333] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[3:333:3] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[:333:3] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[::3] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[3:] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-20 12:26:57.961757
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import_module = utils.import_module
    write_to_file = utils.write_to_file

    def get_path_and_source(frame):
        if isinstance(frame, str):
            # For testing purposes
            return frame

        return get_path_and_source_from_frame(frame)

    assert get_path_and_source('traceback.py') == \
           get_path_and_source('traceback.py')

    file_name, source = get_path_and_source(sys._getframe())
    file_name2, source2 = get_path_and_source(sys._getframe())
    assert file_name == file_name2
    assert source == source2


# Generated at 2022-06-20 12:27:06.922835
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    def do(path, s):
        try:
            os.remove(path)
        except Exception:
            pass
        fw = FileWriter(path, True)
        fw.write(s)
        with open(path, 'r') as f:
            assert f.read() == s
        fw.write(u's')
        with open(path, 'r') as f:
            assert f.read() == s + u's'

    do('test.txt', u'abc')
    do(u'test.txt', u'abc')
    do(b'test.txt', b'abc')
    do(b'test.txt', u'abc')
    do(u'test.txt', b'abc')



# Generated at 2022-06-20 12:27:10.859282
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from pathlib import Path
    from . import temp_file_tools

    with temp_file_tools.create_temp_file() as temp_file:
        fw = FileWriter(temp_file, overwrite=True)
        s = 'abc'
        fw.write(s)
        Path(temp_file).read_text() == s
        with open(temp_file, encoding='utf-8') as output_file:
            output_file.read() == s



# Generated at 2022-06-20 12:27:53.405736
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = sys._getframe(1)
    result = get_local_reprs(frame)
    assert 'frame' in result
    assert '__name__' in result
    assert result['frame'] == repr(frame)
    assert result['__name__'] == repr(__name__)
test_get_local_reprs()



# Generated at 2022-06-20 12:28:01.934888
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from . import testing

    my_file = testing.TempFile(extension='.txt')
    with my_file.open('w') as f:
        f.write(u'test 00')
    writer = FileWriter(my_file.path, False)
    writer.write(u'test 01')
    with my_file.open('r') as f:
        content = f.read()
    assert content == u'test 00test 01'
    writer.write(u'test 02')
    with my_file.open('r') as f:
        content = f.read()
    assert content == u'test 00test 01\ntest 02'
    writer = FileWriter(my_file.path, True)
    writer.write(u'test 03')
    with my_file.open('r') as f:
        content

# Generated at 2022-06-20 12:28:14.023414
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    # Test writing with overwrite=True
    content = utils.gen_random_string(20)
    path = 'temp_FileWriter_write_overwrite_true.txt'
    FileWriter(path, overwrite=True).write(content)
    with open(path, 'r') as f:
        result = f.read()
    assert result == content

    # Test writing without overwrite
    content = utils.gen_random_string(20)
    path = 'temp_FileWriter_write_overwrite_false.txt'
    FileWriter(path, overwrite=False).write(content)
    with open(path, 'r') as f:
        result = f.read()
    assert result == initial_content + content
    os.remove(path)

    # Test writing with overwrite=False
    content = utils.gen_random_

# Generated at 2022-06-20 12:28:18.002895
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    output_file_path = pycompat.Path(__file__).parent / 'test.log'
    f = FileWriter(output_file_path, True)
    f.write('a')
    f.write('b')
    assert pycompat.text(output_file_path.open().read()) == 'ab'



# Generated at 2022-06-20 12:28:20.403746
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:28:31.635182
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pysnooper._snoop
    # Test with exception
    tracer = pysnooper._snoop.Tracer(watch=('a', 'b'), watch_explode=('c', 'd'))
    tracer._write = Mock(return_value=None)
    try:
        with tracer:
            a = 1
            b = 2
            c = {'c':'3'}
            d = [4,5]
            raise ValueError('o my')
    except ValueError:
        args = tracer._write.call_args_list
        assert args[0][0][0].startswith('    New var:....... ')
        assert args[1][0][0].startswith('    New var:....... ')

# Generated at 2022-06-20 12:28:34.300248
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert isinstance(UnavailableSource()[1], pycompat.text_type)
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'

UnavailableSource = UnavailableSource()



# Generated at 2022-06-20 12:28:37.160435
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert u'SOURCE IS UNAVAILABLE' == unavailable_source[0]



# Generated at 2022-06-20 12:28:45.505948
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = pysnooper.tracing.Tracer(thread_info=True)
    assert tracer.set_thread_info_padding('12345678-') == '12345678-'
    assert tracer.set_thread_info_padding('9-') == '    9-'
    tracer.set_thread_info_padding('12345678-')
    assert tracer.set_thread_info_padding('12345678-') == '12345678-'
    assert tracer.set_thread_info_padding('9-') == '12345678-'



# Generated at 2022-06-20 12:28:46.867026
# Unit test for function get_write_function
def test_get_write_function():
    def output():
        pass
    assert get_write_function(output, overwrite=0) is output



# Generated at 2022-06-20 12:29:16.533878
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    try:
        source_lines = inspect.getsourcelines(__file__)[0]
    except IOError:
        source_lines = [
            'SOURCE IS UNAVAILABLE BECAUSE THIS MODULE IS A C EXTENSION.'
        ]

    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == source_lines[0]



# Generated at 2022-06-20 12:29:22.712844
# Unit test for function get_local_reprs
def test_get_local_reprs():
    test = {}
    class Thing:
        pass
    var = Thing()
    var.x = 1
    var.y = 2
    var.z = '3'
    test['var'] = var
    test['value'] = 5

    assert get_local_reprs(test), {'test': '{...}',
                                   'var': 'Thing(x=1, y=2, z="3")',
                                   'value': '5'}



# Generated at 2022-06-20 12:29:30.513545
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.thread_info_padding == 0
    tracer.set_thread_info_padding('mainThread')
    assert tracer.thread_info_padding == len('mainThread')
    tracer.set_thread_info_padding('Thread-2')
    assert tracer.thread_info_padding == len('mainThread')
    tracer.set_thread_info_padding('Thread-22')
    assert tracer.thread_info_padding == len('Thread-22')

# Generated at 2022-06-20 12:29:33.479828
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    def test():
        with pysnooper.Snooper(watch=('arg')) as snooper:
            snooper.watch_add(('local_repr'))
            snooper.watch_remove(('local_repr'))
            return True
    assert test()

# Generated at 2022-06-20 12:29:35.204248
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    object = Tracer()
    assert object.__enter__() is None
test_Tracer___enter__()


# Generated at 2022-06-20 12:29:46.599350
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    import sys

    with io.StringIO() as output, \
         redirect_stdout(output):
        tracer = Tracer(
                     output=output,
                     watch=['foo', 'bar'],
                     watch_explode=['baz', 'qox'],
                     depth=2,
                     prefix="XXX ",
                     overwrite=True,
                     thread_info=True,
                     custom_repr=[('a', lambda x: 'AAA'),
                                  ('b', lambda x: 'BBB'),
                                 ],
                     max_variable_length=None,
                     normalize=False,
                     relative_time=False,
                )

    assert tracer.watch == [CommonVariable('foo'), CommonVariable('bar'),
                            Exploding('baz'), Exploding('qox')]

# Generated at 2022-06-20 12:29:54.895959
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    # method definition
    def Tracer_trace(self, frame, event, arg):
        if not (frame.f_code in self.target_codes or frame in self.target_frames):
            if self.depth == 1:
                return None
            elif self._is_internal_frame(frame):
                return None
            else:
                _frame_candidate = frame
                for i in range(1, self.depth):
                    _frame_candidate = _frame_candidate.f_back
                    if _frame_candidate is None:
                        return None
                    elif _frame_candidate.f_code in self.target_codes or _frame_candidate in self.target_frames:
                        break
                else:
                    return None

# Generated at 2022-06-20 12:29:58.643862
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs(frame=None) == {}
    assert get_local_reprs(frame=None, watch=[]) == {}
    assert get_local_reprs(frame=None, watch=[], custom_repr=()) == {}



# Generated at 2022-06-20 12:30:09.778778
# Unit test for function get_write_function
def test_get_write_function():
    """test whether the returned function would be activated as expected."""

    class DummyStream(utils.WritableStream):
        def __init__(self):
            self.contents = ''
        def write(self, text):
            self.contents += text

    def fake_write(s):
        assert s == 'fake?'

    output = DummyStream()
    write_function = get_write_function(output, False)
    print(write_function)
    assert write_function is not None
    assert write_function('fake?') is None
    assert output.contents == 'fake?'

    output = DummyStream()
    write_function = get_write_function(output, True)
    assert write_function('fake?') is None
    assert output.contents == 'fake?'

    output = '/dev/null'


# Generated at 2022-06-20 12:30:19.232711
# Unit test for function get_write_function
def test_get_write_function():
    import contextlib
    class StdoutRedirector(object):
        def __enter__(self):
            self._stdout = sys.stdout # Save a reference to the original stdout
            sys.stdout = open(r'C:\Temp\test_get_write_function_stdout.txt', 'w')
        def __exit__(self, type, value, traceback):
            sys.stdout = self._stdout # Restore the original stdout
            return False # Don't suppress exceptions


    with StdoutRedirector():
        get_write_function(None, False)('a')
        try:
            get_write_function(None, True)('b')
        except Exception:
            pass

# Generated at 2022-06-20 12:30:44.941011
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    tracer = Tracer()
    def f():
        return 1
    f_wrapper = tracer(f)
    assert tracer.target_codes == {f.__code__}
    assert inspect.getsourcelines(f_wrapper) == inspect.getsourcelines(f)
    assert f_wrapper() == 1


# Generated at 2022-06-20 12:30:55.320770
# Unit test for constructor of class Tracer
def test_Tracer():
    # Default initialization of class Tracer
    s = Tracer()
    assert s.watch == []
    assert s.depth == 1
    assert s.prefix == ''
    assert s._write == sys.stdout.write
    assert s.thread_info == False
    assert s.thread_info_padding == 0
    assert s.target_codes == set()
    assert s.target_frames == set()
    assert s.thread_local.__dict__ == {}
    assert s.custom_repr == ()
    assert s.last_source_path == None
    assert s.max_variable_length == 100
    assert s.normalize == False
    assert s.relative_time == False
    # Non-default initialization of class Tracer

# Generated at 2022-06-20 12:31:04.500793
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():

    tracer = Tracer()
    tracer.set_thread_info_padding("test_thread")
    assert tracer.thread_info_padding == 10

    tracer.set_thread_info_padding("test_longer_thread")
    assert tracer.thread_info_padding == 14

    tracer.set_thread_info_padding("test_longest_thread")
    assert tracer.thread_info_padding == 16

    tracer.set_thread_info_padding("test_thread")
    assert tracer.thread_info_padding == 16

    tracer.set_thread_info_padding("test_long")
    assert tracer.thread_info_padding == 16

# Generated at 2022-06-20 12:31:05.686531
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-20 12:31:07.478480
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:19.103200
# Unit test for constructor of class Tracer

# Generated at 2022-06-20 12:31:21.165951
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    uas = UnavailableSource()
    assert uas[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:29.995209
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    global get_path_and_source_from_frame
    global ipython_pattern
    global source_and_path_cache
    global ipython_pattern
    source_and_path_cache = {}
    source = [b'# coding: shift_jis', b'', b'hello = "\\xe3\\x81\\x82"', b'']
    whatever = lambda: None
    whatever.__code__ = type(sys)().__code__ # dynamic class
    whatever.__code__.co_filename = '<ipython-input-1-e5f88c5a7b28>'

# Generated at 2022-06-20 12:31:35.176396
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'
    assert uas[1] == u'SOURCE IS UNAVAILABLE'
    assert uas[2] == u'SOURCE IS UNAVAILABLE'
test_UnavailableSource___getitem__()



# Generated at 2022-06-20 12:31:41.980674
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t = Tracer()
    assert t.set_thread_info_padding("a") == "a".ljust(1)
    assert t.thread_info_padding == 1
    assert t.set_thread_info_padding("a") == "a".ljust(1)
    assert t.thread_info_padding == 1
    assert t.set_thread_info_padding("ab") == "ab".ljust(2)
    assert t.thread_info_padding == 2



# Generated at 2022-06-20 12:32:16.684392
# Unit test for method write of class Tracer
def test_Tracer_write():
    @pysnooper.snoop()
    def f():
        pass
    try:
        f()
    except:
        pass
    f.tracer.write('test_Tracer_write: msg')

# Generated at 2022-06-20 12:32:24.744941
# Unit test for function get_write_function
def test_get_write_function():
    L = []
    class TestStream(utils.WritableStream):
        def write(self, s):
            L.append(s)
    import tempfile
    with tempfile.NamedTemporaryFile() as file:
        test_file = file.name
        file_writer = get_write_function(test_file, True)
        stream_writer = get_write_function(TestStream(), False)
        func_writer = get_write_function(lambda s: L.append(s), False)
        stderr_writer = get_write_function(None, False)
        for writer in (file_writer, stream_writer, func_writer, stderr_writer):
            writer('x')
    assert L == ['x', 'x', 'x', 'x']
    assert open(test_file, 'rb').read()

# Generated at 2022-06-20 12:32:31.026690
# Unit test for constructor of class Tracer
def test_Tracer():
    """
    Unit test for constructor of class Tracer:

    >>> pysnooper.snoop(resources.get_test_filename('simple.py'))
    Source path:... /so/simple.py
    0000    def square(x):
    0001        """

# Generated at 2022-06-20 12:32:39.191189
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    # no threads are running, so the new padding should be 0
    assert tracer.set_thread_info_padding("") == ""
    # another call to set_thread_info_padding with a new thread name should
    # increase the padding to 16
    assert tracer.set_thread_info_padding("MainThread") == "MainThread "
    # yet another call to set_thread_info_padding with thread name MainThread
    # should not change the padding
    assert tracer.set_thread_info_padding("MainThread") == "MainThread "
    # another call to set_thread_info_padding with thread name with name
    # Thread-2 should not change the padding
    assert tracer.set_thread_info_padding("Thread-2") == "Thread-2      "
   

# Generated at 2022-06-20 12:32:40.324036
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    pass


# Generated at 2022-06-20 12:32:41.970267
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[5] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:32:49.026661
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    root = os.path.dirname(__file__)
    source_file_path = os.path.join(root, 'source_example.py')
    with utils.open_with_encoding(source_file_path, encoding='utf-8') as f:
        source = f.read()

    local = {}
    exec(source, {}, local)
    frame = local['frame']
    path, source_lines = get_path_and_source_from_frame(frame)
    assert path == source_file_path
    assert source_lines == source.splitlines()



# Generated at 2022-06-20 12:32:57.273759
# Unit test for function get_write_function
def test_get_write_function():
    try:
        get_write_function('some_string', True)
    except Exception as e:
        assert isinstance(e, Exception)
    try:
        get_write_function('some_string', False)
    except Exception as e:
        assert isinstance(e, Exception)
    try:
        get_write_function(None, True)
    except Exception as e:
        assert isinstance(e, Exception)
    try:
        get_write_function(None, False)
    except Exception as e:
        assert isinstance(e, Exception)
    try:
        get_write_function('some_string', True)
    except Exception as e:
        assert isinstance(e, Exception)

# Generated at 2022-06-20 12:33:03.051815
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    import sys
    s = io.StringIO()
    ori_write = sys.stdout.write
    sys.stdout.write = s.write
    with Tracer(output=None) as tracer:
        pass
    sys.stdout.write = ori_write
    # There is no expected output for unit test for method write of class Tracer
    pass

# Generated at 2022-06-20 12:33:07.696591
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper
    import random
    @pysnooper.snoop()
    def foo(n):
        return n + random.random()
    try:
        foo(1)
    except Exception as e:
        print(e)

test_Tracer___call__()

from pysnooper import snoop
import time



# Generated at 2022-06-20 12:34:21.360066
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[3] == 'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-20 12:34:22.644784
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print("test_Tracer_trace")
test_Tracer_trace()


# Generated at 2022-06-20 12:34:24.491616
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source_unavailable = UnavailableSource()
    assert source_unavailable[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:34:32.891517
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(None, False)
    assert get_write_function(sys.stdout, False)
    assert get_write_function(sys.stderr, False)
    assert get_write_function(sys.stdout.buffer, False)
    assert get_write_function(open('foo.txt', 'w'), False)
    assert get_write_function(open('foo.txt', 'wb'), False)
    assert get_write_function(open('foo.txt', 'w').write, False)
    assert get_write_function(open('foo.txt', 'wb').write, False)
    assert get_write_function(open('foo.txt', 'wb'), False)
    assert get_write_function(open('foo.txt', 'w').write, True)

# Generated at 2022-06-20 12:34:42.151921
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    s = StringIO()
    tracer = Tracer(output=s, depth=3)
    tracer.custom_repr = (
        (type(5), lambda x: ('<%d>' % x).rjust(12)),
        (lambda x: x > 3, lambda x: ('<%d>' % x).rjust(12))
    )
    def foo():
        with tracer:
            x = 5

    foo()
    output = s.getvalue().splitlines()
    assert output[:2] == [
        '    Starting var:..             5 =        <5>',
        '    Source path:... python_script.py'
    ]
    assert output[-2:] == [
        '    Return value:..',
        'Elapsed time: 0:00:00.000000'
    ]

# Generated at 2022-06-20 12:34:45.194429
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t=Tracer()
    t.set_thread_info_padding("my_thread")
    assert t.thread_info_padding == 9

# Unit test: comparing the method set_thread_info_padding of class Tracer with the output of method getName in class Thread

# Generated at 2022-06-20 12:34:53.191528
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer()
    tracer.write = unittest.TestCase().assertFalse
    tracer.write_elapsed_time = unittest.TestCase().assertFalse
    tracer.thread_local = threading.local()
    tracer.start_times = {}
    tracer.target_frames = set()
    tracer.target_codes = set()
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}

    calling_frame = unittest.mock.Mock()
    calling_frame.f_back = unittest.mock.Mock()
    calling_frame.f_code = unittest.mock.Mock()

    tracer.target_codes.add(calling_frame.f_code)
    tracer.target_frames

# Generated at 2022-06-20 12:34:58.591838
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from . import utils
    f = FileWriter('Test_FileWriter_write.txt', True)
    for i in range(5):
        f.write("Write in %s times\n" %i)
    utils.readable_diff('Test_FileWriter_write.txt',
        'Test_FileWriter_write.txt')
    os.remove('Test_FileWriter_write.txt')
