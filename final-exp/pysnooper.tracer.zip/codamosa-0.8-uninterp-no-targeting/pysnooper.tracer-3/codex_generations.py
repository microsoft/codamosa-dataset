

# Generated at 2022-06-20 12:25:57.351718
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io.StringIO()
    snooper = pysnooper.Snooper(output)
    snooper.prefix = '123 '
    snooper.write('456')
    assert output.getvalue() == '123 456\n'


# Generated at 2022-06-20 12:26:05.314486
# Unit test for constructor of class Tracer
def test_Tracer():
    import pysnooper.thread_global

    d = {'foo': 1, 'bar': 2, 'baz': 3}
    l = [1, 2, 3, 4, 5]
    d2 = {'qux': 1, 'quxx': 2, 'quxxx': 3}
    l2 = [1, 2, 3, 4, 5]
    s = 'hello'

    def f(a, b, c):
        d['foo'] = 2
        l[1] = 2
        for i in range(10):
            d2['qux'] = i
            l2[0] = i
            if i == 5:
                raise ValueError('hi')

    with Tracer(watch=('a', 'b', 'c')) as tracer:
        f(d, l, s)

    ### Checking

# Generated at 2022-06-20 12:26:15.462800
# Unit test for method write of class Tracer
def test_Tracer_write():
    import os
    import sys
    import tempfile
    import unittest
    from unittest.mock import patch

    # sys.stderr.isatty returns False in the test suite but True in IDLE.
    # To make the unit tests more consistent between IDLE and the test suite,
    # we patch isatty() to return True.
    with patch('sys.stderr.isatty', return_value=True):
        class TestClass(unittest.TestCase):
            def setUp(self):
                # Create a Tracer instance and overwrite its _write() method
                # with a mock.
                self.output_file = tempfile.NamedTemporaryFile(mode='r+',
                                                               encoding='utf-8')

# Generated at 2022-06-20 12:26:27.517201
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer(watch_explode=('foo', 'self'),
                    )
    def f(foo):
        pass
    tracer.target_codes.add(f.__code__)
    fake_frame = FakeFrame(
        f_code=f.__code__,
        f_globals={'__name__': '__main__'},
        f_lineno=2,
        f_back=FakeFrame(
            f_code=Tracer.__enter__.__code__,
            f_lineno=10,
        ),
        f_locals={'foo': 'bar'},
    )
    tracer.target_frames.add(fake_frame)
    tracer.frame_to_local_reprs[fake_frame] = {'self': 'baz'}
    tr

# Generated at 2022-06-20 12:26:31.747958
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    import sys
    buf = io.StringIO()
    sys.stdout = buf
    self = pysnooper.snoop()
    s = 'test'
    self.write(s)
    assert buf.getvalue() == 'test\n'



# Generated at 2022-06-20 12:26:33.472891
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()[:]
    assert source == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:45.640837
# Unit test for function get_local_reprs
def test_get_local_reprs():
    a_variable = BaseVariable('my_variable')
    my_dict = {'a': 1, 'b': 2, 'c': 3}
    locals_dict = {}

    def my_function(a, b, c):
        locals_dict.update(globals())

    my_function(1, 2, 3)


# Generated at 2022-06-20 12:26:56.189040
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from os.path import exists
    from garlicsim.general_misc.file_writing_tools import overwrite, append
    from garlicsim.general_misc import temp_file_tools
    from garlicsim.general_misc.temp_value import TempValue

    expected = str(datetime_module.datetime.now())
    output_file = TempValue(
        temp_file_tools.create_temporary_file()
    )

    def write(s):
        return FileWriter(output_file.value, overwrite).write(s)

    assert not exists(output_file.value)
    with output_file:
        write(expected)
        assert exists(output_file.value)
        assert open(output_file.value).read() == expected

    expected += expected

    with output_file:
        write(expected)

# Generated at 2022-06-20 12:26:58.067191
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding('thread_info') == 'thread_info'.ljust(len('thread_info'))



# Generated at 2022-06-20 12:27:07.650436
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    from . import utils
    from .utils import (
         _is_tracing_on, _reset_tracing,
         _is_tracing_locally_on, _reset_local_tracing,
    )
    _reset_tracing()

    _reset_local_tracing()
    global_output_string = []
    local_output_string = []

    @pysnooper.snoop(global_output_string, depth=100)
    def do_stuff_1(x, y):
        with pysnooper.snoop(local_output_string):
            return x + y

    assert not _is_tracing_locally_on()
    assert not _is_tracing_on()
    assert len(global_output_string) == 0

# Generated at 2022-06-20 12:27:33.348388
# Unit test for method write of class Tracer
def test_Tracer_write():
    from io import StringIO
    import sys
    out = StringIO()
    sys.stdout = out
    output = Tracer()
    output.write('test')
    assert out.getvalue() == 'test\n'


# Generated at 2022-06-20 12:27:37.531758
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    test_FileWriter_write_writer = FileWriter('test_FileWriter_write', True)
    test_FileWriter_write_writer.write('test_file_writer_write')
    del test_FileWriter_write_writer



# Generated at 2022-06-20 12:27:39.315111
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():

	T = Tracer()

	assert T.__exit__(None, None, None) == None

# Generated at 2022-06-20 12:27:47.834717
# Unit test for constructor of class Tracer
def test_Tracer():
    print("")
    functions = []
    @snoop()
    def f():
        print("hello world")

    functions.append(f)
    f()

    @snoop()
    def g():
        def h(a, b):
            print("in function H")
            print("a = ", a)
            print("b = ", b)
            return a + b
        return h(2, 3)

    functions.append(g)
    g()
    assert len(functions) == 2

if __name__ == '__main__':
    test_Tracer()

# Generated at 2022-06-20 12:27:53.160925
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def get_arg():
        return '\a'
    f = inspect.currentframe()
    path, source = get_path_and_source_from_frame(f)
    assert path == f.f_code.co_filename
    assert source == [u'def get_arg():', u'    return \'\\a\'']
    del get_arg



# Generated at 2022-06-20 12:28:01.823425
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import io
    import os
    import re
    import subprocess
    import tarfile
    import tempfile
    import unittest
    import shutil
    import pysnooper
    from pysnooper.utils import get_path_and_source_from_frame
    # test for simple code
    def simple_code():
        with pysnooper.snoop() as s:
            global function_call
            function_call = "bar"
            return "foo"
    function_output = io.StringIO()
    old_stdout = sys.stdout
    try:
        sys.stdout = function_output
        simple_code()
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-20 12:28:13.983047
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    class TestTracer(object):
        """
        A TestTracer object for testing method set_thread_info_padding of class Tracer.
        """
        def __init__(self, pysnooper):
            self.pysnooper = pysnooper

        def test_tracer_set_thread_info_padding(self):
            tracer = self.pysnooper.tracer
            example_thread_info = '1-Thread-1'
            max_thread_info_len = len(example_thread_info)
            assert tracer.set_thread_info_padding(example_thread_info) == example_thread_info
            assert tracer.thread_info_padding == max_thread_info_len
            example_thread_info = '1-Thread-12'
            max_thread_info_len = len

# Generated at 2022-06-20 12:28:22.697006
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import io
    import StringIO
    import os
    import tempfile
    import shutil
    class StringIOStream:
        '''
        A class to convert StringIO objects to a utils.WritableStream
        '''
        def __init__(self, string_io):
            self.string_io = string_io
        def write(self, text):
            self.string_io.write(text)

    def _test(path):
        output_file = open(path, 'r', encoding='utf-8')
        temp_path = tempfile.mkdtemp()
        test_file_name = os.path.join(temp_path, 'test.txt')
        output_file.close()


# Generated at 2022-06-20 12:28:28.565117
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  import pytest

  expected_global_depth = 0
  expected_filename = 'hello.py'
  expected_line_no = 5
  expected_source_path = '/Users/zzg/hello.py'
  expected_source_line = '  print(1)\n'

  expected_timestamp = '10:01:09.067117'
  expected_thread_info = '1-MainThread '
  expected_thread_info_padding = 14
  expected_event = 'line'
  expected_indent = '    '

  expected_newish_string = 'New var:....... '
  expected_name = '1'
  expected_value_repr = '1'

  expected_source_path = 'hello.py'

  expected_return_value_repr = 'None'


# Generated at 2022-06-20 12:28:36.106928
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():

    def test_string(test_string):
        assert test_string == "test", \
            "test_string is not equal to test"

    def test_string2(test_string):
        assert test_string == "test", \
            "test_string is not equal to test"

    def test_string3(test_string):
        assert test_string == "test", \
            "test_string is not equal to test"

    def test_string4(test_string):
        assert test_string == "test", \
            "test_string is not equal to test"

    def test_string5(test_string):
        assert test_string == "test", \
            "test_string is not equal to test"


# Generated at 2022-06-20 12:29:12.428773
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import tempfile
    import threading
    import traceback
    import types

    import pysnooper

    # begin_filter
    # Line with comments
    # Line with comments
    # Line with comments
    # Line with comments
    def test_function(arg1, arg2, arg3):
        # Line with comments
        local_variable1 = 1
        local_variable2 = 2
        local_variable3 = 3
        # Line with comments
        # Line with comments
        local_variable1 *= 10
        # Line with comments
        # Line with comments
        # Line with comments
        # Line with comments
        local_variable2 *= 100
        # Line with comments
        # Line with comments
        # Line with comments
        local_variable3 *= 1000
        # Line with comments
        # Line with comments


# Generated at 2022-06-20 12:29:14.445956
# Unit test for method write of class Tracer
def test_Tracer_write():
    x = Tracer()
    assert(x.write("Sample String") == "Sample String\n")


# Generated at 2022-06-20 12:29:16.663274
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[:] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:29:23.264725
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    mocker.patch('pysnooper.utils.get_write_function',
        lambda output, overwrite: 'get_write_function_result'
    )
    assert 'get_write_function_result' == Tracer(output=None,
        watch=(), watch_explode=(), depth=1, prefix='', overwrite=False,
        thread_info=False, custom_repr=(), max_variable_length=100,
        normalize=False, relative_time=False).__enter__()

# Generated at 2022-06-20 12:29:30.475223
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    t = Tracer(thread_info=True)
    base = "test"
    l = []
    for i in range(1, 1000):
        l.append(base + str(i))
    for i in l:
        t.set_thread_info_padding(i)
        assert len(i) == len(t.set_thread_info_padding(i))
    t.set_thread_info_padding(base)
    assert len(base) == len(t.set_thread_info_padding(base))

# Generated at 2022-06-20 12:29:35.660184
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def outer_function():
        def inner_function():
            return get_path_and_source_from_frame(
                inspect.currentframe().f_back.f_back
            )
        return inner_function()
    result = outer_function()
    assert result[0] == inspect.getfile(test_get_path_and_source_from_frame), \
           "The file path is wrong."
    assert result[1][0].endswith('test_get_path_and_source_from_frame()')



# Generated at 2022-06-20 12:29:41.325943
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    with tempfile.NamedTemporaryFile() as temp_file:
        writer = FileWriter(temp_file.name, overwrite=True)
        writer.write('foo')
        writer.write('bar')
        assert(open(temp_file.name, 'r').read() == 'foobar')



# Generated at 2022-06-20 12:29:51.470808
# Unit test for constructor of class Tracer
def test_Tracer():
    output = StringIO()
    watch = ('a', 'b')
    watch_explode = ('c', 'd')
    t = Tracer(output, watch=watch, watch_explode=watch_explode)
    assert t.watch == [CommonVariable('a'), CommonVariable('b'),
                                   Exploding('c'), Exploding('d')]
    assert t.frame_to_local_reprs == {}
    assert t.depth == 1
    assert t.prefix == ''
    assert t.target_codes == set()
    assert t.target_frames == set()
    assert t.thread_info == False
    assert t.custom_repr == ()
    assert t.last_source_path is None
    assert t.max_variable_length == 100
    assert t.normalize == False
    assert t.relative_

# Generated at 2022-06-20 12:30:00.176553
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import string

    watch = (CommonVariable(lambda frame, normalize: {'hello': 'world'}),
             BaseVariable('test', lambda frame, normalize:
                          frame.f_locals['test'], '3'))
    def func(a, b, test=None):
        c = 3
        d = (1, 2, 3)
        e = set(string.ascii_letters)
        return get_local_reprs(locals(), max_length=10,
                               watch=watch, custom_repr=True)

# Generated at 2022-06-20 12:30:11.335661
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    import sys
    import pytest
    from contextlib import contextmanager
    import pysnooper
    @contextmanager
    def redirect_stdout(stream):
        old_stdout = sys.stdout
        sys.stdout = stream
        try:
            yield
        finally:
            sys.stdout = old_stdout

    @pysnooper.snoop()
    def f():
        pass

    with redirect_stdout(io.StringIO()) as fake_stdout:
        f()

    output = fake_stdout.getvalue()
    output = output.splitlines()

# Generated at 2022-06-20 12:31:05.012141
# Unit test for constructor of class FileWriter
def test_FileWriter():
    """Test whether attributes of class FileWriter were correctly assigned"""
    overwrite = True
    path = './path'
    s = 's'
    fw = FileWriter(path, overwrite)
    assert fw.path == path
    assert fw.overwrite == overwrite
    assert fw.write(s) is None
    assert fw.overwrite == False



# Generated at 2022-06-20 12:31:15.006644
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # This is the same code being instrumented by this test. It's important
    # that it doesn't actually run, or else it would output to stdout or
    # whatever file descriptor was passed in the parameter self.output.
    DISABLED = True

    import math  # import dependency
    import os  # import dependency

    from pysnooper import utils  # import dependency

    def foo():
        x = 9
        y = [1, 2, 3]
        z = {"a": 1, "b": 2}
        return x

    function = foo
    function = function
    function = function
    function = function
    function = function
    function = function
    function = function
    function = function

    assert function() == 9



# Generated at 2022-06-20 12:31:17.814959
# Unit test for method write of class Tracer
def test_Tracer_write():
    writer = StringIO()
    s = Snoop(writer)
    s.write("this and that")
    assert writer.getvalue() == 'this and that\n'


# Generated at 2022-06-20 12:31:21.166175
# Unit test for method write of class Tracer
def test_Tracer_write():
    @pysnooper.snoop()
    def test_Tracer_write_func():
        return 3
    # test_Tracer_write_func()
    test_Tracer_write_func()

# Generated at 2022-06-20 12:31:30.074378
# Unit test for constructor of class Tracer
def test_Tracer():
    with Tracer(output=None, watch=[], watch_explode=[], depth=1,
                prefix='', overwrite=False, thread_info=False,
                custom_repr=(), max_variable_length=100, normalize=False,
                relative_time=False) as tracer:
        assert (tracer.watch == [])
        assert (tracer.frame_to_local_reprs == {})
        assert (tracer.start_times == {})
        assert (tracer.depth == 1)
        assert (tracer.prefix == '')
        assert (tracer.target_codes == set())
        assert (tracer.target_frames == set())
        assert (hasattr(tracer.thread_local, 'original_trace_functions'))
        assert (tracer.custom_repr == ())
       

# Generated at 2022-06-20 12:31:32.591222
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with pytest.raises(AttributeError):
        with Tracer():
            assert False
        assert False


# Generated at 2022-06-20 12:31:35.025711
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
  # It's very hard to test this in a pythonic way, as it depends on
  # the execution time of the code.
  pass


# Generated at 2022-06-20 12:31:45.173624
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import sys
    import pytest
    import pycompat
    import contextlib
    import functools
    import inspect
    import pycompat
    import threading
    import datetime as datetime_module

    from . import pysnooper
    from . import utils
    from .utils import BaseVariable, CommonVariable, Exploding
    from .utils import DISABLED
    from .utils import get_write_function, get_path_and_source_from_frame
    from .utils import get_local_reprs
    from .utils import opcode

    call_id_counter = itertools.count()
    def get_unique_call_id():
        return next(call_id_counter)

    class thread_global:
        depth = -1
    class threading:
        class local:
            pass

# Generated at 2022-06-20 12:31:54.592345
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    import sys
    import io
    import time
    import datetime
    from pysnooper import thread_global
    from pysnooper import utils
    from pysnooper import Tracer
    from pysnooper import get_write_function

    @functools.lru_cache(maxsize=None)
    def get_output_like_linux_string():
        output_like_linux_string = io.StringIO()
        def _write(s):
            output_like_linux_string.write(s)
        return _write, output_like_linux_string

    open_file, filename = _get_filename() # This function is from here: https://github.com/cool-RR/pysnooper/blob/master/test/test_utils.py

# Generated at 2022-06-20 12:32:03.224869
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import io
    import inspect
    import pycompat
    import filecmp
    import subprocess
    import os
    output = io.StringIO()
    # Write to a temporary file so that I can compare the output with
    # the reference file.
    #with io.open('/tmp/output.txt', 'w', encoding='utf-8') as output:
    with io.open('/tmp/output.txt', 'w') as output:
        test_file = inspect.getfile(Tracer)
        # Python 3 needs to pass a unicode string
        if pycompat.PY3:
            test_file = pycompat.unicode(test_file)
        with Tracer(output=output):
            exec(open(test_file).read(), globals())
