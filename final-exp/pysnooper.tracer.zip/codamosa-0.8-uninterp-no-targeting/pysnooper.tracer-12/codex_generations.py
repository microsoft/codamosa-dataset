

# Generated at 2022-06-20 12:25:58.987623
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write('test message')
    assert tracer.thread_local.original_trace_functions == []
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.last_source_path == None

# Generated at 2022-06-20 12:26:08.560515
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def func():
        b = 3
        return 'spam', 34
    frame = inspect.currentframe()
    frame = frame.f_back


    assert get_local_reprs(frame, watch=(), custom_repr=(),
                           normalize=False, max_length=None) == {}

    assert get_local_reprs(frame, watch=(), custom_repr=(),
                           normalize=True, max_length=None) == {}

    assert get_local_reprs(frame, watch=(), custom_repr=(),
                           normalize=False, max_length=10) == {}

    assert get_local_reprs(frame, watch=(), custom_repr=(),
                           normalize=True, max_length=10) == {}


    assert get_local_reprs

# Generated at 2022-06-20 12:26:21.138628
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    assert tracer.set_thread_info_padding("") == " "*20
    assert tracer.set_thread_info_padding("1") == "1" + " "*19
    assert tracer.set_thread_info_padding("12") == "12" + " "*18
    assert tracer.set_thread_info_padding("123") == "123" + " "*17
    assert tracer.set_thread_info_padding("1234") == "1234" + " "*16
    assert tracer.set_thread_info_padding("12345") == "12345" + " "*15
    assert tracer.set_thread_info_padding("123456") == "123456" + " "*14

# Generated at 2022-06-20 12:26:31.605133
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    test_Tracer_trace_depth_2_overwrite_False_normalize_False_relative_time_False()
    test_Tracer_trace_depth_2_overwrite_False_normalize_False_relative_time_True()
    test_Tracer_trace_depth_2_overwrite_False_normalize_True_relative_time_False()
    test_Tracer_trace_depth_2_overwrite_False_normalize_True_relative_time_True()
    test_Tracer_trace_depth_2_overwrite_True_normalize_False_relative_time_False()
    test_Tracer_trace_depth_2_overwrite_True_normalize_False_relative_time_True()
    test_Tracer_trace_depth_2_overwrite_True_normalize_True_relative_time

# Generated at 2022-06-20 12:26:32.795301
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as snoop:
        pass



# Generated at 2022-06-20 12:26:44.726955
# Unit test for function get_local_reprs
def test_get_local_reprs():
    code = compile('x = 1; y = 2; z = 3; xxx = 4', '<string>', 'single')
    frame = pycompat.get_frame(code, {'x': 77})

    assert get_local_reprs(frame, max_length=1) == {
        'x': '77', 'y': '2', 'z': '3', 'xxx': '4'
    }
    assert get_local_reprs(frame, watch=[CommonVariable('x')], max_length=1) == {
        'x': '77', 'y': '2', 'z': '3', 'xxx': '4'
    }

# Generated at 2022-06-20 12:26:52.758590
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def foo():
        return get_path_and_source_from_frame(sys._getframe()), 'boo'
    if pycompat.PY2:
        assert foo() == ('test_get_path_and_source_from_frame', ['    return foo()',
                         "foo()"]), foo()
    else:
        assert foo() == ('test_get_path_and_source_from_frame', ['    return foo()',
                                                                  "foo()"]), foo()



# Generated at 2022-06-20 12:26:53.836465
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def foo(x):
        pass
    foo_ = Tracer() (foo)
    assert foo_ (1) == None


# Generated at 2022-06-20 12:27:04.119584
# Unit test for function get_write_function
def test_get_write_function():
    import io
    import os

    # output=None
    write = get_write_function(None, False)
    # write() should print to console.
    if pycompat.PY2:
        assert write(u'\u263a') == None
    # write(output=None) should return None
    assert write(None) == None
    # write() should not return anything.
    assert write('hi') == None
    # write() should be able to handle any types of input.
    assert write(u'\u263a'.encode()) == None

    # output=str
    file_path = os.path.join('shit.txt')
    write = get_write_function(file_path, False)
    assert write(u'\u263a') == None
    assert write(None) == None
    assert write

# Generated at 2022-06-20 12:27:06.762279
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[3] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:27:24.364253
# Unit test for method write of class Tracer
def test_Tracer_write():
    print("Unit Test: method write of Class Tracer()")
    Tracer.write(1)


# Generated at 2022-06-20 12:27:25.178552
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Pass
    return


# Generated at 2022-06-20 12:27:32.336071
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os

    path = 'testing_FileWriter_write'
    try:
        os.remove(path)
    except OSError:
        pass
    file_writer = FileWriter(path, overwrite=True)
    file_writer.write('hello')
    file_writer.write('world')
    file_writer = FileWriter(path, overwrite=False)
    file_writer.write('hello')
    file_writer.write('world')
    with open(path, encoding='utf-8') as output_file:
        x = output_file.read()
    assert x == 'helloworldhelloworld'
    os.remove(path)



# Generated at 2022-06-20 12:27:36.681453
# Unit test for function get_local_reprs
def test_get_local_reprs():
    a = 1
    frame = inspect.currentframe()
    result = get_local_reprs(frame, watch=(CommonVariable('a'),))
    assert result == collections.OrderedDict([('a', '1')])
    a = 5
    result = get_local_reprs(frame, watch=(CommonVariable('a'),))
    assert result == collections.OrderedDict([('a', '5')])
del test_get_local_reprs


# Generated at 2022-06-20 12:27:44.440611
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    # Set up fake `frame` object as if from traceback, without needing
    # to actually get into a traceback situation.
    class FakeCode(object):
        co_filename = 'xyz'
        co_name = 'abc'
    frame = FakeFrame()
    frame.f_code = FakeCode()
    frame.f_globals = {'__loader__': MockLoader()}

    got = get_path_and_source_from_frame(frame)
    assert got == ('xyz', ['def abc():', '    pass'])

# Generated at 2022-06-20 12:27:49.925120
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import StringIO
    output = StringIO.StringIO()
    def dummy_function():
        pass
    tracer = Tracer(output)
    wrapped_function = tracer(dummy_function)
    assert dummy_function.__name__ == wrapped_function.__name__
    assert dummy_function.__doc__ == wrapped_function.__doc__
    assert dummy_function.__module__ == wrapped_function.__module__



# Generated at 2022-06-20 12:27:59.817967
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from mypy_extensions import TypedDict
    from contextlib import contextmanager
    from . import testing_tools
    class Data(TypedDict):
        path: pycompat.PathLike
        overwrite: bool
        repr: str
        expected_overwrite: bool
        result: typing.Optional[None]

# Generated at 2022-06-20 12:28:05.734378
# Unit test for function get_write_function
def test_get_write_function():
    import io

    output_stream = io.StringIO()
    write = get_write_function(output_stream, False)
    write('hi\n')
    assert output_stream.getvalue() == 'hi\n'

    output_stream = io.StringIO()
    write = get_write_function(output_stream, True)
    write('hi\n')
    assert output_stream.getvalue() == 'hi\n'

    write = get_write_function(None, False)
    import sys
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    write('hi\n')
    assert sys.stderr.getvalue() == 'hi\n'
    sys.stderr = old_stderr


# Generated at 2022-06-20 12:28:06.505358
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass

# Generated at 2022-06-20 12:28:17.554420
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    '''
    Test the method trace of class Tracer.
    '''
    pysnooper.configure(max_variable_length = 100)
    print('Normalize: False')
    @pysnooper.snoop()
    def test_func_1():
        a = 1
        b = [1, 2, 3]
        c = {'d': 1, 'e': [1, 2]}
        return c

    test_func_1()
    print('========')
    print('Normalize: True')
    @pysnooper.snoop(normalize = True)
    def test_func_2():
        a = 1
        b = [1, 2, 3]
        c = {'d': 1, 'e': [1, 2]}
        return c

    test_func_2()

# Generated at 2022-06-20 12:28:42.211533
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_code():
        return get_path_and_source_from_frame(inspect.currentframe())
    def test_lambda():
        return get_path_and_source_from_frame(inspect.currentframe())
    utils.assert_equal(test_code(), (_this_file, source))
    utils.assert_equal(test_lambda(), (_this_file, source))
test_get_path_and_source_from_frame()


# Generated at 2022-06-20 12:28:44.366542
# Unit test for method write of class Tracer
def test_Tracer_write():
    t = Tracer()
    t.write("test_Tracer_write")

# Generated at 2022-06-20 12:28:46.607410
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'
    assert source[-5] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-20 12:28:57.570916
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    @pysnooper.snoop()
    def f(x):
        return x

    _snooper = Tracer()
    f.__code__
    _snooper.trace(f.__code__, 'call', None)
    def g(x):
        x = x + 2
        y = x * 3
        return y
    g.__code__
    _snooper.trace(g.__code__, 'call', None)
    def h(x):
        x = x + 2
        y = x * 3
        return y
    h.__code__
    _snooper.trace(h.__code__, 'call', None)



# Generated at 2022-06-20 12:28:59.198079
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = sys._getframe(0)
    assert get_local_reprs(frame)



# Generated at 2022-06-20 12:29:03.890165
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  with Tracer(
      output=None,
      watch=(),
      watch_explode=(),
      depth=1,
      prefix='',
      overwrite=False,
      thread_info=False,
      custom_repr=(),
      max_variable_length=100,
      normalize=False,
      relative_time=False) as tracer:
    pass


# Generated at 2022-06-20 12:29:09.141717
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os

    def test_single_write():
        path = utils.get_random_string()
        try:
            fw = FileWriter(path, overwrite=True)
            content = utils.get_random_string()

            fw.write(content)

            with open(path, 'rb') as f:
                assert f.read() == utils.shitcode(content)
        finally:
            os.remove(path) # so it won't cause trouble for other tests

    test_single_write()



# Generated at 2022-06-20 12:29:13.498563
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource()[2] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:29:18.711261
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from contextlib import contextmanager
    from unittest.mock import patch

    tracer = Tracer()
    tracer._write = patch.object(tracer, '_write').start()
    context_manager = tracer.__enter__()
    assert context_manager is tracer
    tracer._write.assert_called_once()
    return

# Generated at 2022-06-20 12:29:19.749157
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    pass


# Generated at 2022-06-20 12:29:49.431543
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # unit test for method set_thread_info_padding of class Tracer
    tracer = Tracer(thread_info=True)
    # test for case: thread_info_padding = 0
    assert tracer.set_thread_info_padding("1-1") == "1-1 "
    assert tracer.set_thread_info_padding("1-1") == "1-1 "
    # test for case: thread_info_padding > 0
    assert tracer.set_thread_info_padding("1-1") == "1-1 "
    assert tracer.set_thread_info_padding("101-101") == "101-101 "
    # test for case: thread_info_padding < len(thread_info)
    assert tracer.set_thread_info_padding("101-101") == "101-101 "


# Generated at 2022-06-20 12:29:56.612398
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def assert_equal(a, b):
        assert a == b, '%s != %s' % (repr(a), repr(b))

    frame = Frame({'a': 1, 'b': 'abc', 'c': 2}, None)
    assert_equal(get_local_reprs(frame),
                 collections.OrderedDict([('a', '1'), ('b', "'abc'"), ('c', '2')]))

    frame = Frame({'b': 'abc', 'c': 2, 'a': 1}, None)
    assert_equal(get_local_reprs(frame),
                 collections.OrderedDict([('a', '1'), ('b', "'abc'"), ('c', '2')]))

    frame.f_locals['b'] = 2
    frame.f_locals['d']

# Generated at 2022-06-20 12:30:07.238948
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import dis
    file_name, source = get_path_and_source_from_frame(
        dis.StackSummary.extract(dis.StackSummary.extract(
            inspect.currentframe()
        ).frames[0]
    ).frames[1])
    if '_test_get_path_and_source_from_frame' in globals():
        assert file_name.endswith('debuggy/stepping.py')
        assert file_name == __file__
        assert source[0] == 'def test_get_path_and_source_from_frame():'
    else:
        assert file_name.endswith('tests/test_stepping.py')
        assert source[0] == '    # Unit test for function get_path_and_source_from_frame'

# Generated at 2022-06-20 12:30:15.699430
# Unit test for constructor of class FileWriter
def test_FileWriter():
    if pycompat.WINDOWS:
        file_name = 'C:/path/to/file.txt'
    else:
        file_name = '/path/to/file.txt'
    file_writer = FileWriter(file_name, overwrite=True)
    file_writer.write('line 1\n')
    file_writer = FileWriter(file_name, overwrite=False)
    file_writer.write('line 2\n')
    with open(file_name, 'r') as file:
        assert file.read() == 'line 1\nline 2\n'
    os.remove(file_name)



# Generated at 2022-06-20 12:30:22.018643
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    from .utils import get_caller_frame  # Avoid circular import
    # We try to write a file with non-ASCII characters, but if we're on an OS
    # that doesn't support it, we just skip the test.
    try:
        with open('tmp.py', 'wt') as f:
            f.write('# -*- coding: utf-8 -*-\n\n')
            f.write('def foo(x):\n')
            f.write('    print(x)\n')
            f.write('foo(u"שלום")\n')
    except utils.file_writing_errors:
        return
    sys.path.insert(0, '.')
    __import__('tmp')
    frame = get_caller_frame(2)
    assert get_path_

# Generated at 2022-06-20 12:30:33.112758
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import threading
    import inspect

    import pysnooper
    import pysnooper.thread_global

    pysnooper.thread_global.depth = pysnooper.thread_global.depth = -1

    class CustomException(Exception):
        pass

    class MyTest(unittest.TestCase):
        def test_call(self):
            def foo():
                1 + 1
                raise CustomException()

            @pysnooper.snoop(watch=('frame',))
            def bar(frame):
                pass

            bar(inspect.currentframe())

            try:
                foo()
            except CustomException:
                pass

            def foo():
                yield 1
                yield 2

            generator = foo()
            next(generator)
            next(generator)


# Generated at 2022-06-20 12:30:35.534142
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Tracer.__enter__()
    # We can't test this method without making a lot of monkey-patching
    pass

# Generated at 2022-06-20 12:30:45.141864
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test():
        def some():
            def other():
                return get_path_and_source_from_frame(
                    sys._getframe().f_back.f_back.f_back
                )
            return other()
        return some()
    this_file_name = inspect.getsourcefile(test) or inspect.getfile(test)
    path, source = test()
    assert path == this_file_name
    for substring in ['get_path_and_source_from_frame',
                      'test_get_path_and_source_from_frame',
                      'this_file_name',
                      ]:
        assert substring in source
    # Test again, now making sure we get it from the cache:
    assert test() is test()
    assert test() is test()
    assert test() is test()



# Generated at 2022-06-20 12:30:55.509497
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import io
    import sys
    import traceback
    import pytest

    # Exception that is thrown by something called in this test
    class SomethingWentWrong(Exception):
        pass

    # Unit test that needs the mocked functionality in this module
    def test_tracer___exit__(mocker):
        # Set up the global variable of this module
        pysnooper.utils.DISABLED = False

        # mock the attribute of an instantiated class (the variable is stored in the class)
        mocker.patch.object(pysnooper.utils.Tracer, "DISABLED", True)

        # Mock the return value of a function (here a function inside a class)
        mocker.patch.object(pysnooper.utils.Tracer, "_write").return_value = True

        # Mocking with a function to access the

# Generated at 2022-06-20 12:31:00.694439
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding('1-abc') == '1-abc '
    assert tracer.set_thread_info_padding('222-abc') == '222-abc'


SNOOP_ENVIRON_KEY = 'PYSNOOPER_ENABLED'



# Generated at 2022-06-20 12:31:42.456984
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    a = UnavailableSource()
    assert a[1] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:49.399638
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(watch=[], prefix='', overwrite=False, thread_info=True, thread_info_padding=20)
    tracer1 = Tracer(watch=[], prefix='', overwrite=False, thread_info=True, thread_info_padding=20)
    assert tracer.set_thread_info_padding(str(False)) == '                   '
    assert tracer.set_thread_info_padding('1234567') == '1234567            '
    assert tracer1.thread_info_padding == 0

# Generated at 2022-06-20 12:31:55.672137
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    try:
        t = tempfile.NamedTemporaryFile('w', encoding='utf-8')
        file_writer = FileWriter(t.name, overwrite=True)
        file_writer.write('foo\n')
        file_writer.write('bar\n')
        file_writer = FileWriter(t.name, overwrite=True)
        file_writer.write('baz\n')

        t.seek(0)
        assert t.read() == 'baz\n'
    finally:
        t.close()



# Generated at 2022-06-20 12:31:57.126200
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    result = Tracer().__exit__(None, None, None)
    assert result is None


# Generated at 2022-06-20 12:31:59.505497
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE'

# Unit tests for `get_local_reprs`.


# Generated at 2022-06-20 12:32:06.210021
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
  from io import StringIO
  from pysnooper.tracer import Tracer
  import inspect

  s = StringIO()
  tracer = Tracer(output=s,watch=(),watch_explode=(),depth=1,prefix='',overwrite=False,thread_info=False,custom_repr=(),max_variable_length=100,normalize=False,relative_time=False)
  frame = inspect.currentframe()
  tracer.write = lambda s: None
  tracer.__exit__(None, None, None)



# Generated at 2022-06-20 12:32:11.960566
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = "test.txt"
    f = FileWriter(path, True)
    
    f.write("Hello!\n")
    with open(path, "r") as f2:
        assert f2.read() == "Hello!\n"

    f.write("Hi!\n")
    with open(path, "r") as f2:
        assert f2.read() == "Hi!\n"

    

# Generated at 2022-06-20 12:32:14.397076
# Unit test for function get_write_function
def test_get_write_function():
    sys.stderr.write('New test_get_write_function\n')
    write = get_write_function(None, False)
    write(1)
    assert 1 == 0


# Generated at 2022-06-20 12:32:19.861829
# Unit test for method write of class Tracer
def test_Tracer_write():
    # instance of class Tracer
    tracer = Tracer()
    # metadata
    tracer.prefix = "ZZZ"
    tracer.thread_info_padding = 0
    # parameter
    arg_s = "test"
    # expected
    expected_output = "ZZZtest\n"
    # output
    output = tracer.write(s=arg_s)
    # compare output with expected
    assert expected_output == output
test_Tracer_write()

# Generated at 2022-06-20 12:32:27.299467
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import atexit
    path = tempfile.mktemp()
    atexit.register(os.unlink, path)
    with open(path, 'w') as my_file:
        my_file.write('abc')

    x = FileWriter(path, overwrite=True)
    x.write('def')
    x.write('ghi')
    with open(path, 'r') as my_file:
        assert my_file.read() == 'defghi'

    x = FileWriter(path, overwrite=False)
    x.write('jkl')
    x.write('mno')
    with open(path, 'r') as my_file:
        assert my_file.read() == 'defghijklmno'



# Generated at 2022-06-20 12:33:31.123531
# Unit test for function get_write_function
def test_get_write_function():
    from .tests.utils import DummyStream
    import io
    import tempfile
    import codecs
    with tempfile.NamedTemporaryFile() as f:
        write = get_write_function(f.name, False)
        write(u"hello world")
        f.seek(0)
        contents = f.read()
    assert contents == b"hello world"
    with tempfile.NamedTemporaryFile() as f:
        write = get_write_function(f.name, True)
        write(u"hello world")
        f.seek(0)
        contents = f.read()
    assert contents == b"hello world"
    with tempfile.NamedTemporaryFile() as f:
        write = get_write_function(io.open(f.name, "wb"), False)

# Generated at 2022-06-20 12:33:40.046976
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # Initialize
    # remove some key from the global environment
    pysnooper.logger.removeHandler(pysnooper.logger.handlers[0])

    tracer = Tracer(
        output=StringIO(),
        watch=[],
        watch_explode=[],
        depth=1,
        prefix='',
        overwrite=False,
        max_variable_length=100,
    )
    # Exercise
    tracer.__enter__()
    # Verify
    assert thread_local.original_trace_functions == [sys.gettrace()]
    assert sys.gettrace() == tracer.trace
    assert pysnooper.logger.level == logging.DEBUG
    assert len(pysnooper.logger.handlers) == 1

# Generated at 2022-06-20 12:33:45.967191
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    thread_info = "thread_info"
    tracer = Tracer()
    tracer.thread_info_padding = 10
    result = tracer.set_thread_info_padding(thread_info)
    assert result == "thread_info"
    
    thread_info = "thread"
    tracer = Tracer()
    tracer.thread_info_padding = 10
    result = tracer.set_thread_info_padding(thread_info)
    assert result == "thread     "
    



# Generated at 2022-06-20 12:33:55.234097
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    reporter = Tracer(thread_info=True)
    assert reporter.set_thread_info_padding("123-main ") == "123-main "
    assert reporter.set_thread_info_padding("12-main ") == "12-main "
    assert reporter.set_thread_info_padding("1-main ") == "1-main "
    assert reporter.thread_info_padding == 8
    assert reporter.set_thread_info_padding("1-mai ") == "1-mai "
    assert reporter.thread_info_padding == 8
    assert reporter.set_thread_info_padding("1-main ") == "1-main "
    assert reporter.thread_info_padding == 8
    assert reporter.set_thread_info_padding("1-x ") == "1-x "

# Generated at 2022-06-20 12:33:57.001719
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[:5] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:33:59.846077
# Unit test for method write of class Tracer
def test_Tracer_write():
  f = StringIO()
  s = Tracer(output=f)
  s.write('Testing Tracer.write')
  assert f.getvalue() == 'Testing Tracer.write\n'


# Core test.

# Generated at 2022-06-20 12:34:08.394831
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer_obj = Tracer(thread_info=True)
    current_thread = threading.current_thread()
    current_thread_len = len("{ident}-{name} ".format(ident=current_thread.ident,
                                                      name=current_thread.getName()))
    assert tracer_obj.thread_info_padding == 0
    assert tracer_obj.set_thread_info_padding("") == " " * current_thread_len
    assert tracer_obj.thread_info_padding == current_thread_len
    assert tracer_obj.set_thread_info_padding("") == " " * current_thread_len
    assert tracer_obj.thread_info_padding == current_thread_len

# Generated at 2022-06-20 12:34:09.962695
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:34:13.729363
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    t = Tracer()
    t.set_thread_info_padding('')
    t.start_times[None] = True
    sys.settrace(t.trace)
    t.__exit__(None, None, None)

if __name__ == '__main__':
    test_Tracer___exit__()

# Generated at 2022-06-20 12:34:22.432717
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(x, y):
        z = 'z'
        a = object()
        return a

    frame = utils.get_frame_by_frame(utils.get_frame(f))

    assert get_local_reprs(frame) == {'x': 'x', 'y': 'y', 'z': '"z"', 'a': '<object>'}
    assert get_local_reprs(frame, watch=(BaseVariable('z'), BaseVariable('a'))) == {'x': 'x', 'y': 'y', 'z': '"z"', 'a': '<object>'}