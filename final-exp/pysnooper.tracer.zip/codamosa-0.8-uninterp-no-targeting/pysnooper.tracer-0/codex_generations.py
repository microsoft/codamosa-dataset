

# Generated at 2022-06-20 12:25:44.309606
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    import os

    fd, path = tempfile.mkstemp()
    os.close(fd)
    try:
        fw = FileWriter(path, overwrite=False)
        fw.write('Something')
        with open(path, encoding='utf-8') as file:
            assert file.read() == 'Something'

        fw = FileWriter(path, overwrite=True)
        fw.write('Something')
        with open(path, encoding='utf-8') as file:
            assert file.read() == 'Something'
    finally:
        os.remove(path)



# Generated at 2022-06-20 12:25:56.238693
# Unit test for function get_local_reprs
def test_get_local_reprs():
    result = get_local_reprs(caller_frame)
    assert result['x'] == '4', "x is not '4'"
    assert result['y'] == '8', "y is not '8'"
    assert result['a'] == "['x', 'y']", "a is not '[\'x\', \'y\']'"
    assert not result.get('b'), "`b` shouldn't be here"
    assert result['c'] == "('a', 'b')", "c is not '(\'a\', \'b\')'"
    assert not result.get('d'), "`d` shouldn't be here"
    assert not result.get('e'), "`e` shouldn't be here"
    assert not result.get('f'), "`f` shouldn't be here"

# Generated at 2022-06-20 12:26:04.092057
# Unit test for function get_write_function
def test_get_write_function():
    class MyClass(object):
        def __init__(self):
            self.written_text = ''

        def write(self, text):
            self.written_text += text

    test_cases = (
        (None, 'foo'),
        (sys.stdout, 'foo'),
        (MyClass(), 'foo'),
        ('c:/output/file.txt', 'foo'),
    )

    for output, text in test_cases:
        if isinstance(output, MyClass):
            my_class = output
            output.written_text = ''
        write = get_write_function(output, False)
        write(text)
        if isinstance(output, MyClass):
            assert my_class.written_text == text
        else:
            from . import testing

# Generated at 2022-06-20 12:26:07.890279
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    # Setup
    tracer = Tracer(thread_info=True)
    expected_result = '123-abc '
    # Exercise
    result = tracer.set_thread_info_padding('123-abc')
    # Verify
    assert result == expected_result
    # Cleanup - none necessary



# Generated at 2022-06-20 12:26:10.669002
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    a = Tracer()
    a1 = a.trace('frame')
    if a1 != a.trace:
        return False

    return True

# This works - pylint: disable=unused-argument

# Generated at 2022-06-20 12:26:20.007741
# Unit test for function get_local_reprs
def test_get_local_reprs():
    assert get_local_reprs.__code__.co_argcount == 1
    assert get_local_reprs.__code__.co_varnames[:4] == \
                                                   ('frame', 'watch',
                                                    'custom_repr', 'max_length')
    from . import variables
    x = 4
    with variables.ExplodingVariable('x'):
        frame = inspect.currentframe()
        assert get_local_reprs(frame) == {'x': variables.x.explosion_value}



# Generated at 2022-06-20 12:26:30.489093
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import numpy as np
    from pysnooper import snoop

    def my_function(n):
        foo = np.zeros(n)
        bar = np.ones(n)
        return np.array([foo, bar])

    @snoop(normalize=True)
    def test_function(n):
        return my_function(n)

    test_function(n=12)
    # Output: Source path:... tmp.py
    #         Starting var:.. redef
    #         Starting var:.. fun
    #         Starting var:.. fun_or_class
    #         Starting var:.. function
    #         Starting var:.. snooper
    #         Starting var:.. name
    #         Starting var:.. obj
    #         Starting var:.. snooped_obj
    #         Starting var:..

# Generated at 2022-06-20 12:26:38.668444
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer(watch=('foo', 'bar', 'baz'))
    frame = inspect.currentframe()
    frame.f_locals['foo'] = 'foo'
    frame.f_locals['bar'] = 'bar'
    labeled_dict = {}
    labeled_dict['foo'] = 'foo2'
    labeled_dict['bar'] = 'bar2'
    frame.f_locals['baz'] = labeled_dict
    tracer.trace(frame, 'call', None)
    tracer.trace(frame, 'return', 'baz')


# Generated at 2022-06-20 12:26:46.512184
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return g()
    def g():
        1/0
    try:
        f()
    except ZeroDivisionError:
        exc_type, exc_value, exc_tb = sys.exc_info()
        file_name, source = get_path_and_source_from_frame(exc_tb.tb_frame)
    assert file_name == __file__
    source = source[1]
    assert source.strip().endswith('f()')


# Generated at 2022-06-20 12:26:50.574650
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def dummy_func():
        pass

    file_name, source = get_path_and_source_from_frame(dummy_func.__code__.co_filename, dummy_func.__globals__)
    assert file_name == dummy_func.__code__.co_filename
    assert source is not None



# Generated at 2022-06-20 12:27:10.790974
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import unittest
    from .tests import test_utils

    class GetPathAndSourceFromFrameTests(unittest.TestCase):
        def test_regular_file(self):
            frame = test_utils.make_frame('def f(): pass')
            result = get_path_and_source_from_frame(frame)
            self.assertEqual(len(result), 2)
            self.assertEqual(result[0], os.path.realpath(__file__))
            self.assertTrue(isinstance(result[1], list))
            self.assertTrue(result[1][0].startswith('"""Unit test for'))

        def test_regular_reprs(self):
            frame = test_utils.make_frame('a = 12')
            result = get_local_reprs(frame)


# Generated at 2022-06-20 12:27:18.440620
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    try:
        import __main__
    except ImportError:
        __main__ = None
    __main__.test_snoop_test_Tracer___call__ = None
    import StringIO
    try:
        import __main__
    except ImportError:
        __main__ = None
    __main__.test_snoop_test_Tracer___call__ = None


    def method1():
        test_snoop_test_Tracer___call__.append('method1')

    # only module and class defined in main module
    m = Tracer(output=StringIO.StringIO())
    m1 = m(method1)
    try:
        import __main__
    except ImportError:
        __main__ = None

# Generated at 2022-06-20 12:27:19.271918
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    print("Method Tracer.trace() passed!")


# Generated at 2022-06-20 12:27:21.119359
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert '__name__' in get_path_and_source_from_frame(sys._getframe())



# Generated at 2022-06-20 12:27:29.728473
# Unit test for function get_local_reprs
def test_get_local_reprs():
    import pytest
    from .variables import MagicVariable, Item

    global x, y, z
    with pytest.raises(MagicVariable):
        get_local_reprs(globals(),
                        watch=(MagicVariable('x', Item(MagicVariable('y'), 10)),
                               MagicVariable('z', Item(MagicVariable('z'), 12))))
    frame = inspect.currentframe()
    x, y, z = [1, 'a', (4, 5)]
    local_reprs = get_local_reprs(frame, max_length=4)
    assert local_reprs == collections.OrderedDict([('x', '1'), ('y', "'a'"), ('z', '4, 5')])



# Generated at 2022-06-20 12:27:37.118969
# Unit test for function get_write_function
def test_get_write_function():
    from .testing.silly_outputs import SillyOutput

    silly_output = SillyOutput()
    write_functions = (
        get_write_function(None, False),
        get_write_function(silly_output, False),
        get_write_function(utils.WritableStream(silly_output), False),
    )
    assert all(write_function('hello') is None for write_function in
               write_functions)
    assert silly_output.content == 'hello'*len(write_functions)
    
    write_function = get_write_function('test_file.txt', True)
    write_function('test')
    assert os.path.exists('test_file.txt')

# Generated at 2022-06-20 12:27:47.969400
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  print("********************************************")
  print("* TEST METHOD TRACE OF CLASS TRACER         *")
  print("* For test purpose, it only test the 2nd    *")
  print("* block of trace method.                    *")
  print("********************************************")
  # make a test class (I'm too lazy to write or)
  class A(object):
    def func(self):
      pass
  a = A()
  # call the function to get the frame and line number
  _, line_number = inspect.getsourcelines(a.func)
  # construct a test frame for mocking
  frame = utils.FrameMock(a.func.__code__, line_number - 1)
  # mock the global variables
  thread_global.depth = random.randint(0, 10)
  # get the trace function
 

# Generated at 2022-06-20 12:27:49.586922
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[5] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:27:59.597561
# Unit test for function get_local_reprs
def test_get_local_reprs():

    from . import variables

    assert get_local_reprs(
        inspect.currentframe(),
        custom_repr={ColoredString: lambda x: '<ColoredString>'},
        max_length=17
    ) == {'key': '"value"'}

    assert get_local_reprs(inspect.currentframe()) == {'key': '"value"'}

    def local_function(x):
        y = x + 1

    frame = inspect.currentframe().f_back

# Generated at 2022-06-20 12:28:01.994777
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()['some_key'] == u'SOURCE IS UNAVAILABLE'
    assert UnavailableSource().__getitem__('some_key') == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:28:16.766355
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert isinstance(source[0], str)
    assert isinstance(source[10], str)
test_UnavailableSource___getitem__()



# Generated at 2022-06-20 12:28:24.182815
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    assert tracer.set_thread_info_padding("1-2") == "1-2      "
    assert tracer.set_thread_info_padding("1-23") == "1-23     "
    assert tracer.set_thread_info_padding("1-234") == "1-234    "
    assert tracer.set_thread_info_padding("11-234") == "11-234   "
    assert tracer.set_thread_info_padding("234-234") == "234-234  "
    assert tracer.set_thread_info_padding("2345-234") == "2345-234 "
    assert tracer.set_thread_info_padding("23456-234") == "23456-234"

# Generated at 2022-06-20 12:28:31.594576
# Unit test for function get_write_function
def test_get_write_function():
    def dummy():
        return 1
    def write_to_stderr(s):
        sys.stderr.write(s)
    assert get_write_function(None, False) == write_to_stderr
    assert get_write_function(dummy, False) == dummy
    assert get_write_function(utils.WritableStream(), False) == utils.WritableStream().write
    assert get_write_function('test_get_write_function.txt', True) == FileWriter('test_get_write_function.txt', True).write




# Generated at 2022-06-20 12:28:42.834703
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = inspect.currentframe().f_back.f_back
    frame.f_locals['unicode_'] = 'עברית'
    frame.f_locals['utf8'] = 'שלום!'
    frame.f_locals['utf8_bytes'] = 'שלום'.encode('utf8')
    frame.f_locals['utf16_bytes'] = 'שלום'.encode('utf16')
    frame.f_locals['ascii'] = 'hello'
    frame.f_locals['windows_1255'] = 'שלום'.encode('windows-1255').decode('cp1255')
    frame.f_locals['cp850'] = 'שלום'.encode('cp850').decode('cp850')

# Generated at 2022-06-20 12:28:44.504995
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    a = Tracer(output=None)
    pass


# Generated at 2022-06-20 12:28:51.266442
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import pytest
    import trace, types
    # <trace.Tracer instance at 0x000002A0750B2F80>
    t = trace.Tracer()
    assert str(t.__class__) == "<class 'trace.Tracer'>"
    # <built-in method __getattribute__ of trace.Tracer object at 0x000002A0750B2F80>
    assert str(t.__getattribute__) == "<method-wrapper '__getattribute__' of trace.Tracer object at 0x000002A0750B2F80>"
    # <built-in method __setattr__ of trace.Tracer object at 0x000002A0750B2F80>

# Generated at 2022-06-20 12:29:01.455077
# Unit test for constructor of class Tracer
def test_Tracer():
    write_function = StringIO()

    @Tracer(output=write_function, watch=('a', 'b'),
                          watch_explode=('c', 'd'),
                          depth=2,
                          prefix='ZZZ ',
                          overwrite=True,
                          thread_info=False,
                          custom_repr=(),
                          max_variable_length=200,
                          normalize=True,
                          relative_time=True)
    def foo():
        a = 1
        b = 2
        c = [1, 2, 3]
        d = {'a': 1, 'b': 2}
        for i in range(3):
            a += 1
            b += 2
            c.append(i)
            d[str(i)] = i

    foo()
    output = write_function

# Generated at 2022-06-20 12:29:06.199527
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with captured_stdout() as output:
        with pysnooper.snoop(output=None, depth=1, prefix='', overwrite=False, thread_info=False, custom_repr=(), max_variable_length=100, normalize=False, relative_time=False):
            sys.settrace(None)
    output = output.getvalue()
    return output


# Generated at 2022-06-20 12:29:14.791775
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    """Test method `__enter__` of Tracer."""
    from pysnooper.utils import init
    from pysnooper.variables import BaseVariable, Exploding, CommonVariable

    init()
    obj = Tracer(watch=1, watch_explode=2, depth=3,
                 prefix='4', overwrite=True, thread_info=False,
                 custom_repr=(), max_variable_length=100,
                 normalize=False)
    # todo: no asserts
test_Tracer___enter__()


# Generated at 2022-06-20 12:29:18.363516
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    def foo():
        pass
    def decorated_tracer():
        with Tracer():
            foo()
    def not_decorated_tracer():
        with Tracer():
            foo()
    decorated_tracer()

# Generated at 2022-06-20 12:29:31.597051
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def foo(a=3, b=4, c=5):
        pass
    foo()
    frame = sys._getframe(0)
    frame.f_locals['d'] = 6
    result = get_local_reprs(frame)
    assert result['a'] == '3'
    assert result['b'] == '4'
    assert result['c'] == '5'
    assert result['d'] == '6'
    assert result['self'] == '<None>'



# Generated at 2022-06-20 12:29:36.456860
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import sys
    # Clean the new entry which was added by the last execution of test
    current_thread = threading.current_thread()
    thread_global.__dict__.pop(current_thread.ident, None)
    original_trace_function = sys.gettrace()
    def test_function():
        with Tracer():
            pass
    test_function()
    assert thread_global.__dict__.pop(current_thread.ident) == 0
    assert sys.gettrace() == original_trace_function



# Generated at 2022-06-20 12:29:47.651510
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = pysnooper.Snooper(watch=('foo', 'self'))
    tracer.depth = 1
    tracer.thread_info_padding = 1

    orig_now = datetime_module.datetime.now
    datetime_now = orig_now()
    def mock_now(*args, **kwargs):
        return datetime_now

    with mock.patch('pysnooper.snoop.datetime', datetime_module.datetime):
        datetime_module.datetime.now = mock_now

        # ============== Event: call ============= #
        tracer.max_variable_length = None
        tracer.custom_repr = ()
        tracer.normalize = False

        mock_event = 'call'
        mock_arg = None
        mock_frame = mock.Magic

# Generated at 2022-06-20 12:29:55.577828
# Unit test for constructor of class FileWriter
def test_FileWriter():
    my_path = "my_path"
    my_string = u"my_string"

    def test_function(writer = FileWriter(my_path, overwrite=True), 
                      string = my_string):
        with open(my_path, 'r') as fp:
            assert fp.read() == ""
        writer.write(string)
        with open(my_path, 'r') as fp:
            assert fp.read() == string
        writer.write(string)
        with open(my_path, 'r') as fp:
            assert fp.read() == string + string

    test_function()


# Generated at 2022-06-20 12:30:01.436226
# Unit test for function get_write_function
def test_get_write_function():
    import sys
    import io

    assert '\n' in FileWriter('doesnt matter', False).write('hello\n')

    with io.BytesIO() as f:
        assert get_write_function(f, False)(b'a') == None
        assert f.getvalue() == b'a'

    def writer(s):
        print(s, end='')

    assert get_write_function(writer, False)('hi') == None



# Generated at 2022-06-20 12:30:13.009236
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    def write_test(path):
        utils.FileWriter(path, False)
        utils.FileWriter(path, True)
    def write_test_exc(path):
        utils.FileWriter(path, False)
        with pytest.raises(Exception):
            utils.FileWriter(path, True)

    with tempfile.TemporaryDirectory() as tmp_dir:
        write_test(tmp_dir)
        write_test(os.path.join(tmp_dir, 'a'))
        write_test(os.path.join(tmp_dir, 'a', 'b'))
        write_test(os.path.join(tmp_dir, 'a', 'b', 'c'))

# Generated at 2022-06-20 12:30:21.011967
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer()
    tracer.write = lambda x: x
    tracer.thread_local.original_trace_functions = []
    tracer.frame_to_local_reprs = {}
    tracer.start_times = {}
    tracer.set_thread_info_padding = lambda x: x
    thread_global.depth = -1
    tracer.target_codes = set()
    tracer.target_frames = set()
    if tracer.trace(None, None, None) is not None:
        raise AssertionError("Expected None to be returned")
    if thread_global.depth != -1:
        raise AssertionError("Expected thread_global.depth == -1")

    frame = MagicMock(name='frame')

# Generated at 2022-06-20 12:30:26.084836
# Unit test for function get_write_function
def test_get_write_function():
    write = get_write_function(sys.stderr, overwrite=False)
    assert callable(write)
    write('abc')
    write = get_write_function('abc.txt', overwrite=False)
    assert callable(write)
    write('abc')  # will actually write to file
    import shutil
    shutil.rmtree('abc.txt')



# Generated at 2022-06-20 12:30:30.341112
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[None] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[object()] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:30:41.447701
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import threading
    from pysnooper import utils
    import datetime as datetime_module
    import os
    import inspect
    import pycompat
    import itertools
    import traceback
    import opcode
    import functools

    DISABLED = False
    assert (DISABLED)

    def get_path_and_source_from_frame(frame):
        path, _ = inspect.getsourcefile(frame)
        with open(path) as f:
            source = f.readlines()
        return path, source

    class thread_global(object):
        pass
    thread_global.__dict__.setdefault('depth', -1)
    inspect.currentframe().f_back
    class BaseVariable(object):
        def __init__(self, variable_name):
            self

# Generated at 2022-06-20 12:30:58.323136
# Unit test for function get_local_reprs
def test_get_local_reprs():
    code = compile('a = 3\nb = 4\n', 'test_get_local_reprs', 'exec')
    frame = sys._getframe().f_back
    frame.f_code = code
    frame.f_locals.update({'a': 3, 'b': 4})
    assert get_local_reprs(frame) == {'a': '3', 'b': '4'}
    assert get_local_reprs(frame, watch=(Exploding('a'),)) == {'a': '...'}
    assert get_local_reprs(frame, max_length=3) == {'a': '3', 'b': '4'}
    assert get_local_reprs(frame, max_length=2) == {'a': '3', 'b': '...'}
   

# Generated at 2022-06-20 12:31:02.150167
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def method(x, *args, **kwargs):
        """Docstring for method."""
        return x

    assert isinstance(Tracer()(method), type(method))
    assert Tracer()(method).__doc__ == "Docstring for method."

# Generated at 2022-06-20 12:31:06.190804
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    assert get_path_and_source_from_frame(
        inspect.currentframe()
    )[0].endswith(os.path.join('debug_tools', '__init__.py'))
test_get_path_and_source_from_frame.unittest = ['.source_tools']



# Generated at 2022-06-20 12:31:07.559292
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    source = UnavailableSource()
    assert source[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:09.107543
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    # pytest.skip('not yet implemented')
    pass


# Generated at 2022-06-20 12:31:11.463090
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:18.261314
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = 'dummy.txt'
    s = 'This is a test'
    try:
        file_writer = FileWriter(path, True)
        file_writer.write(s)
        file_writer.write(s)
        file_writer.write(s)
        file_writer.write(s)
        file_writer.write(s)
    except Exception as error:
        assert False, 'FileWriter threw an Exception: {}'.format(repr(error))



# Generated at 2022-06-20 12:31:27.909209
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    with mock.patch.object(Tracer, 'write') as mock_write:
        with mock.patch('pysnooper.utils') as mock_utils:
            with mock.patch('pysnooper.pycompat'):
                with mock.patch('pysnooper.inspect'):
                    with mock.patch('pysnooper.datetime_module.datetime'):
                        with mock.patch('pysnooper.threading.current_thread'):
                            pass


# Generated at 2022-06-20 12:31:38.006690
# Unit test for function get_write_function
def test_get_write_function():

    # Set up a mock file
    class MockFile:
        def __init__(self):
            self.content = []
        def write(self, s):
            self.content.append(s)
        def flush(self):
            pass
        def __repr__(self):
            return f'<MockFile {self.content}>'

    # Test 1) output=None
    write = get_write_function(None, True)
    # no errors... write to stderr
    write('Foo')

    # Test 2) output=callable
    f = MockFile()
    def my_write(s):
        f.write(s)
    write = get_write_function(my_write, True)
    write('Foo')
    assert f.content == ['Foo']

    # Test 3)

# Generated at 2022-06-20 12:31:48.016634
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                                                          delete=False) as f:
        fwriter = FileWriter(f.name, overwrite=False)

        assert fwriter.path == f.name
        assert fwriter.overwrite == False
        with pytest.raises(AssertionError):
            FileWriter(None, overwrite=False)

        fwriter.write('hello')
        f.close()
        with open(f.name, 'r', encoding='utf-8') as f_check:
            assert f_check.read() == 'hello'

        fwriter.write('hello again')

# Generated at 2022-06-20 12:31:59.944516
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    assert True, "Test if the method __enter__ of class Tracer work."

# Generated at 2022-06-20 12:32:02.273049
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:32:05.974477
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    class Test():
        def __init__(self):
            pass
    logger = logging.getLogger(__name__)
    logger.debug(__name__)
    test = Test()

# Generated at 2022-06-20 12:32:10.138784
# Unit test for method write of class Tracer
def test_Tracer_write():
    import sys
    import io
    output = io.StringIO()
    tracer = Tracer(output)
    tracer.write("Ceci est un test.")
    assert output.getvalue() == "Ceci est un test.\n"
    output.close()



# Generated at 2022-06-20 12:32:19.223911
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    __file__ = os.path.join(os.path.dirname(__file__), 'frame.py')
    with open(__file__) as f:
        expected_source = f.read()
    def dummy_get_source(module_name):
        return expected_source
    def f():
        pass
    frame = f.__code__.co_filename = __file__
    frame = sys._getframe()
    frame = sys._getframe()
    frame = sys._getframe()
    frame = sys._getframe()
    frame = sys._getframe()
    try:
        path, source = get_path_and_source_from_frame(frame)
    except UnavailableSource:
        pass
    else:
        assert path == __file__
        assert source == expected_source.splitlines()

# Generated at 2022-06-20 12:32:27.034227
# Unit test for method write of class Tracer
def test_Tracer_write():
    """
    Test for method write of class Tracer
    """
    tracer = Tracer(overwrite = True, prefix = "GLOBAL ",
                    thread_info = True, custom_repr = (("%r", lambda x: x),))
    output_filepath = "tester_output_write.txt"

    def real_function():
        print("I am a real function.")

    def real_function_2():
        print("I am function number 2.")

    def real_function_3():
        print("I am function number 3.")

    def real_function_4():
        print("I am function number 4.")

    tracer.write("I am not a real function.")
    for i in range(4):
        tracer(real_function)


# Generated at 2022-06-20 12:32:36.730679
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    from pysnooper.utils import _SnooperDebugger, _SnooperDebugger__inner_trace
    where_call_stack = sys._current_frames()
    snooper_instance = Tracer(output = None)
    snooper_instance.__exit__ = lambda *args, **kwargs: None
    snooper_instance.__enter__ = lambda *args, **kwargs: None
    # def __init__(self, output=None, watch=(), watch_explode=(), depth=1,
    #              prefix='', overwrite=False, thread_info=False, custom_repr=(),
    #              max_variable_length=100, normalize=False, relative_time=False)
    snooper_instance.watch = []
    snooper_instance.depth = 1
    sn

# Generated at 2022-06-20 12:32:45.237326
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from cStringIO import StringIO
    from os.path import join as join_path
    from time import time
    from shutil import rmtree
    from tempfile import mkdtemp

    tmp_dir = mkdtemp()

# Generated at 2022-06-20 12:32:47.103281
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:32:50.331687
# Unit test for method write of class Tracer
def test_Tracer_write():
    output = io.StringIO()
    s = Tracer(output)
    try:
        s.write('foo')
        s.write('bar')
    except:
        pass
    s.write('baz')
    assert output.getvalue() == 'foo\nbar\nbaz\n'


# Generated at 2022-06-20 12:33:18.693204
# Unit test for method write of class Tracer
def test_Tracer_write():
    from os.path import abspath
    from io import StringIO
    from pycompat import pysnooper_source_path

    # Configuring a StringIO object to write to
    output = StringIO()
    prefix = 'ZZZ '
    overwrite = False
    thread_info_padding = 0
    thread_info = True
    trace_obj = Tracer(
        output=output, prefix=prefix, overwrite=overwrite,
        thread_info_padding=thread_info_padding,
        thread_info=thread_info
    )
    s = 'test_string'
    indent = ' ' * 4 * (thread_global.depth + 1)
    thread_info = '{ident}-{name} '.format(
        ident=threading.current_thread().ident,
        name=threading.current_thread().getName())

# Generated at 2022-06-20 12:33:29.805220
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from unittest.mock import call

    # Tests for exception handling
    function = Mock()
    function.__code__ = Mock(co_filename='/some/path.py')

    tracer = Tracer()
    tracer.target_codes.add(function.__code__)
    tracer.target_frames.add(Mock(f_back=Mock(f_code=function.__code__)))

    frame = Mock(f_code=function.__code__)
    frame.f_lineno = 3
    tracer.frame_to_local_reprs[frame] = {}

    # Tests for missing frame
    tracer.__enter__()
    tracer.__exit__(None, None, None)


# Generated at 2022-06-20 12:33:38.919351
# Unit test for constructor of class Tracer
def test_Tracer():
    import unittest
    class TracerTestCase(unittest.TestCase):
        def test_default(self):
            tracer = Tracer()
            self.assertEqual(tracer.watch, [])
            self.assertEqual(tracer.watch_explode, [])
            self.assertEqual(tracer.depth, 1)
            self.assertEqual(tracer.prefix, '')
            self.assertEqual(tracer.overwrite, False)
            self.assertEqual(tracer.thread_info, False)
            self.assertEqual(tracer.custom_repr, ())
            self.assertEqual(tracer.max_variable_length, 100)
            self.assertEqual(tracer.normalize, False)

# Generated at 2022-06-20 12:33:39.438684
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
  pass

# Generated at 2022-06-20 12:33:41.566007
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    my_frame = inspect.currentframe()
    result = get_path_and_source_from_frame(my_frame)
    assert result == (__file__, open(__file__).read().splitlines())



# Generated at 2022-06-20 12:33:50.286572
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    if pycompat.PY2:
        import six
        six.exec_("class utils.WritableStream:\n  def write(*args): pass\n", globals())

    import os
    import sys
    import os.path
    import tempfile
    import shutil
    my_dir = os.path.dirname(__file__)
    tmp_dir_name = os.path.join(my_dir, 'tmp')
    if os.path.isdir(tmp_dir_name):
        shutil.rmtree(tmp_dir_name)
    os.makedirs(tmp_dir_name)
    file_name = os.path.join(tmp_dir_name, 'sample.txt')
    os.unlink(file_name)
    # append mode

# Generated at 2022-06-20 12:33:59.343160
# Unit test for constructor of class FileWriter
def test_FileWriter():
    test_path = 'test.txt'

    # Test constructor of FileWriter
    fw = FileWriter(test_path, True)
    fw.write('hello world\n')

    with open(test_path, 'r') as f:
        assert f.read() == 'hello world\n'

    fw = FileWriter(test_path, False)
    fw.write('hello world again\n')
    with open(test_path, 'r') as f:
        assert f.read() == 'hello world\nhello world again\n'

    fw = FileWriter(test_path, False)
    fw.write('hello world again\n')

# Generated at 2022-06-20 12:34:03.410477
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  import sys
  import pysnooper
  # Assemble
  tracer = pysnooper.Tracer()
  frame = sys._getframe()
  event = 'call'
  arg = 'arg'
  # Act
  tracer.trace(frame, event, arg)
  # Assert
  # Note: we do not assert

# Generated at 2022-06-20 12:34:10.643541
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    from sys import settrace

    import datetime
    from pysnooper import snoop
    from pysnooper.utils import get_repr
    import pycompat
    import threading

    class A:
        def foo(self):
            pass
    class B(A):
        def bar(self):
            pass

    _BASE_MODULE_DIR = os.path.dirname(os.path.dirname(__file__))

    @snoop()
    def f():
        pass
    f()

    @snoop(watch=('b',))
    def g(b):
        pass
    g(b=None)
    g(b="foo")


# Generated at 2022-06-20 12:34:19.198550
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import sys
    import pycompat
    import os
    import pysnooper.tracer
    DISABLED = os.getenv('PYSNOOPER_DISABLE')
    from pysnooper.utils import get_shortish_repr, get_path_and_source_from_frame
    from pysnooper.base_variable import Variable, CommonVariable, Exploding
    from pysnooper.variables import var_to_shortish_repr

    from pysnooper.tracer import Tracer

    tracer = Tracer()
    tracer.normalize = True
    tracer.relative_time = False
    tracer.max_variable_length = None
    tracer.target_codes = {'function body code': 'function global code'}
    tracer.target_frames = {'function frame'}