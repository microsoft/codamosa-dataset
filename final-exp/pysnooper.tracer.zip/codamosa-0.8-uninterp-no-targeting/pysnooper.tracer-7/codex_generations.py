

# Generated at 2022-06-20 12:25:55.614285
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import tempfile
    import os
    output = tempfile.mktemp()
    try:
        with Tracer(output=output):
            os.remove(output)
            os.remove(output)
        assert os.path.exists(output)
    except:
        pass
    try:
        os.remove(output)
    except:
        pass

# Generated at 2022-06-20 12:25:57.746343
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    uas = UnavailableSource()
    assert list(uas) == [u'SOURCE IS UNAVAILABLE']


# Generated at 2022-06-20 12:25:58.696599
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pytest


# Generated at 2022-06-20 12:26:06.647677
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    path = tempfile.mktemp()
    file_writer = FileWriter(path, False)
    file_writer.write('abc')
    with open(path, 'r') as file:
        assert file.read() == 'abc'
    file_writer.write('de')
    with open(path, 'r') as file:
        assert file.read() == 'abcde'
    file_writer = FileWriter(path, True)
    file_writer.write('fgh')
    with open(path, 'r') as file:
        assert file.read() == 'fgh'



# Generated at 2022-06-20 12:26:18.704503
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    file_name = tempfile.NamedTemporaryFile().name
    assert not os.path.isfile(file_name)
    FileWriter(file_name, True).write('a')
    assert os.path.isfile(file_name)
    FileWriter(file_name, False).write('b')
    with open(file_name, 'r', encoding='utf-8') as f:
        assert f.read() == 'ab'
    FileWriter(file_name, False).write('c')
    with open(file_name, 'r', encoding='utf-8') as f:
        assert f.read() == 'abc'
    FileWriter(file_name, True).write('d')

# Generated at 2022-06-20 12:26:23.933583
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    (file_name, source) = get_path_and_source_from_frame(
                                            inspect.currentframe().f_back
                                            )
    assert os.path.basename(file_name) == os.path.basename(__file__)
    assert 'test_get_path_and_source_from_frame()' in source



# Generated at 2022-06-20 12:26:32.635516
# Unit test for constructor of class Tracer
def test_Tracer():
    import io
    output = io.StringIO()

    depth = 1
    prefix = 'ZZZ '
    overwrite = False
    @Tracer(output=output, depth=depth, prefix=prefix, overwrite=overwrite)
    def foo():
        def bar():
            return 4
        return bar()

    foo()
    assert output.getvalue() == """\
ZZZ Call started
ZZZ Starting var:.. foo = <function foo at 0x7f5d5b5d7c80>
ZZZ Starting var:.. bar = <function bar at 0x7f5d5b5d7d08>
ZZZ Return value:.. 4
ZZZ Call ended by exception
"""


# Generated at 2022-06-20 12:26:43.895115
# Unit test for method write of class Tracer
def test_Tracer_write():
    # Arrange
    class MockOutputWriter:
        def __init__(self):
            self.written_output = []
    
        def write(self, s):
            self.written_output.append(s)

    mock_output_writer = MockOutputWriter()
    tracer = Tracer(output=mock_output_writer)
    expected_output = 'foo\nbar\nbaz\n'

    # Act
    tracer.write('foo\n')
    tracer.write('bar\n')
    tracer.write('baz\n')

    # Assert
    written_output = ''.join(mock_output_writer.written_output)
    assert written_output == expected_output


# Generated at 2022-06-20 12:26:53.343199
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    thread1 = threading.current_thread()
    thread2 = threading.Thread(target=lambda: None)
    thread1_ident = thread1.ident
    thread2_ident = thread2.ident
    def ident_str(thread_ident):
        return "-"+str(thread_ident)
    thread2.start()
    thread2.join()

    tracer = Tracer(thread_info=True)

    # Test empty thread_info
    thread_info = ""
    thread_info = tracer.set_thread_info_padding(thread_info)
    assert thread_info == "            ", thread_info

    # Test no padding of a thread_info with the same length as padding
    thread_info = ident_str(thread1_ident)+" "+thread1.getName()
    thread_info = tracer.set

# Generated at 2022-06-20 12:26:56.542749
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from io import StringIO
    with StringIO() as f:
        _output = Tracer(f, max_variable_length=2)
        def test_func(a):
            return a
        _output(_test_func)
        assert f.getvalue() == '        test_func = func\n'


# Generated at 2022-06-20 12:31:00.772420
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    foo = 10
    msg = ''
    class ThisException(Exception):
        pass
    # Unit test for case when exception is raised
    try:
        with pysnooper.snoop():
            foo = foo/0
            print(foo)
    except Exception:
        msg = traceback.format_exc()
    finally:
        assert(msg != '')

    # Unit test for case when exception is raised in a subfunc
    try:
        def subfunc():
            foo = foo/0
            print(foo)
        with pysnooper.snoop():
            subfunc()
    except Exception:
        msg = traceback.format_exc()
    finally:
        assert(msg != '')

    # Unit test for case when a exception is raised in a subclass

# Generated at 2022-06-20 12:31:03.826778
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0]

_source_code_cache_lock = threading.RLock()
_source_code_cache = {}


# Generated at 2022-06-20 12:31:07.332833
# Unit test for method write of class Tracer
def test_Tracer_write():
    # assert False, "TDD: write method must be implemented"
    pass


# Generated at 2022-06-20 12:31:13.258256
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    def f():
        pass
    frame = sys._getframe()
    frame.f_code = f.__code__
    assert UnavailableSource()[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:24.878713
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import __main__
    import inspect
    import pytest
    import sys

    # Check if every call to Tracer.__enter__ yields a Tracer.trace instance.
    tracer = Tracer(None, watch=(), watch_explode=(), depth=1,
                    prefix=u'', overwrite=False, thread_info=False,
                    custom_repr=(), max_variable_length=100,
                    normalize=False, relative_time=False)
    old_getframe = inspect.currentframe
    inspect.currentframe = lambda *args, **kwargs: \
                            old_getframe(*args, **kwargs).f_back
    thread_global = __main__.thread_global
    thread_global.__dict__.setdefault('depth', -1)
    assert tracer.__enter__() == tracer.trace

# Generated at 2022-06-20 12:31:32.304491
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    import contextlib
    import os

    with tempfile.NamedTemporaryFile() as tf:
        fp = tf.name
    def test(overwrite):
        with contextlib.closing(FileWriter(fp, overwrite)) as f:
            f.write("something")
        with open(fp, 'r') as tf:
            generated = tf.read()
        expected = "something"
        if not overwrite:
            expected += "\nsomething"
        assert generated == expected

    test(True)
    test(False)
    os.remove(fp)



# Generated at 2022-06-20 12:31:40.793924
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    line_prefix = "    "
    @pysnooper.snoop(prefix=line_prefix)
    def call_snoopped_function():
        return "return value"
    output_stream = io.StringIO()
    pysnooper.get_write_function(output_stream)()
    call_snoopped_function()
    assert re.search(r'{}Elapsed time: \d+ ms'.\
        format(re.escape(line_prefix)), output_stream.getvalue())

# Generated at 2022-06-20 12:31:51.805487
# Unit test for method write of class Tracer
def test_Tracer_write():
    # Normal
    expected = "TEST\n"
    actual = Tracer(overwrite=True, output=StringIO())
    actual.prefix = ""
    actual.write("TEST")
    output_buffer = actual._write.original_buffer
    actual = output_buffer.getvalue()
    nose.tools.assert_equal(actual, expected)

    # Normal
    expected = "PREFIXTEST\n"
    actual = Tracer(overwrite=True, output=StringIO())
    actual.prefix = "PREFIX"
    actual.write("TEST")
    output_buffer = actual._write.original_buffer
    actual = output_buffer.getvalue()
    nose.tools.assert_equal(actual, expected)


# Generated at 2022-06-20 12:31:54.707684
# Unit test for method write of class Tracer
def test_Tracer_write():
    tracer = Tracer()
    tracer.write('Hello World')


# Generated at 2022-06-20 12:32:07.222386
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    tracer = Tracer(watch=('b',))
    with tracer:
        a = 1
        b = 2
        c = 3
        d = 4
    assert tracer.watch == [CommonVariable('b')]
    assert tracer.frame_to_local_reprs == {}
    assert tracer.start_times == {}
    assert tracer.depth == 1
    assert tracer.prefix == ''
    assert tracer.target_codes == set()
    assert tracer.target_frames == set()
    assert tracer.thread_local == threading.local()
    assert tracer.custom_repr == ()
    assert tracer.last_source_path is None
    assert tracer.max_variable_length == 100
    assert tracer.normalize is False
    assert tracer.relative_time is False
