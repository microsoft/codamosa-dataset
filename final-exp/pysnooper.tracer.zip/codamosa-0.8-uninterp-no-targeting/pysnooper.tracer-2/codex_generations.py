

# Generated at 2022-06-20 12:25:46.495884
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert (UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE')



# Generated at 2022-06-20 12:25:52.898580
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    _test_get_path_and_source_from_frame.__code__ # For pytest to be happy
    assert get_path_and_source_from_frame(_test_get_path_and_source_from_frame) == \
                                                                    (__file__, _test_get_path_and_source_from_frame_source)





# Generated at 2022-06-20 12:26:02.117967
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    global DISABLED
    class TestTracer(unittest.TestCase):
        def setUp(self):
            DISABLED = False
            self._write = get_write_function(None,False)
            self.depth = 1
            self.prefix = ''
            self.thread_info = False
            self.thread_info_padding = 0
            self.target_codes = set()
            self.target_frames = set()
            self.start_times = {}
            self.thread_local = threading.local()
            self.frame_to_local_reprs = {}
            self.watch = [SimpleVariable('a'),Exploding('b')]
            self.custom_repr = ()
            self.last_source_path = None
            self.max_variable_length = 100
            self.normalize = False

# Generated at 2022-06-20 12:26:03.918875
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:26:13.222551
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import unittest
    class Test_Tracer___exit__(unittest.TestCase):
        def test_it(self):
            import mock
            s = Tracer(watch='bar')
            _write = mock.Mock()
            s._write = _write
            s.start_times[mock.Mock()] = datetime_module.datetime(2019, 8, 25, 15, 0)
            s.frame_to_local_reprs[mock.Mock()] = {}
            s.__exit__(None, None, None)
            _write.assert_called_once_with('    Elapsed time: 0:00:00.000000\n')
    unittest.main()

# Generated at 2022-06-20 12:26:17.256264
# Unit test for constructor of class Tracer
def test_Tracer():
    @pysnooper.snoop()
    def foo(x):
        return x + 1

    assert foo(1) == 2, "test_Tracer failed"


# Generated at 2022-06-20 12:26:19.786146
# Unit test for method write of class Tracer
def test_Tracer_write():
    s = Tracer()
    s.write('This is a test')

Tracer.write = test_Tracer_write


# Generated at 2022-06-20 12:26:30.307496
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=True, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    tracer.thread_info_padding = None
    
    # create thread 1
    def test_thread_1():
        tracer.set_thread_info_padding(thread_info='-1-test_thread_1 ')
    
    t1 = Thread(target=test_thread_1)
    
    # create thread 2
    def test_thread_2():
        tracer.set_thread_info_padding(thread_info='-2-test_thread_2')
    
    t2 = Thread(target=test_thread_2)
    
   

# Generated at 2022-06-20 12:26:36.696071
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    thread_info = tracer.set_thread_info_padding("")
    expected_thread_info = "MainThread-MainThread "
    assert thread_info == expected_thread_info, \
        "Unexpected value of variable `thread_info`: {}. Expected: {}"\
            .format(thread_info, expected_thread_info)

    tracer = Tracer(thread_info=True)
    thread_info = tracer.set_thread_info_padding("1234-Test ")
    expected_thread_info = "1234-Test      "

# Generated at 2022-06-20 12:26:48.402537
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    try:
        assert DISABLED, "couldn't complete test: 'DISABLED' is True (run tests with PYSNOOPER_DISABLE=0)"
    except AssertionError as e:
        print("\n\nERROR: {}\n\n".format(e))

    #### Tests start here #####################################################

    import sys
    import threading
    import unittest

    import pytest

    @pytest.mark.skipif(DISABLED, reason="couldn't complete test: 'DISABLED' is True (run tests with PYSNOOPER_DISABLE=0)")
    class TestThreadLocal(threading.local):
        def __init__(self):
            self.original_trace_functions = []


# Generated at 2022-06-20 12:27:13.053437
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    file_path = tempfile.mktemp('.txt')
    if pycompat.PY2:
        file_path = file_path.encode()
    file_writer = FileWriter(file_path, True)
    file_writer.write('hello\n')
    with open(file_path, 'r') as input_file:
        file_content = input_file.read()
    assert file_content == 'hello\n'
    file_writer.write('bar\n')
    with open(file_path, 'r') as input_file:
        file_content = input_file.read()
    assert file_content == 'bar\n'
    os.remove(file_path)
test_FileWriter_write()



# Generated at 2022-06-20 12:27:15.787970
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from . import testing
    with testing.todo_async_test_file('a.txt') as path:
        fw = FileWriter(path, True)
        assert fw.path == path
        assert fw.overwrite == True


# Generated at 2022-06-20 12:27:17.909906
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    def f():
        pass
    t = Tracer()
    t.write = MagicMock()
    t.__exit__(1, 2, 3)
    t.write.assert_called()



# Generated at 2022-06-20 12:27:28.298851
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f():
        a = 1
        b = 2
        return a, b
    frame = sys._getframe().f_back
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    assert get_local_reprs(frame) == {'a': '1', 'b': '2'}
    with utils.max_length(3):
        assert get_local_reprs(frame) == {'a': '1', 'b': '2'}
    variable = CommonVariable('b')
    with utils.max_length(3):
        assert (get_local_reprs(frame, watch=(variable,))
                == {'a': '1', 'b': '2', '<watch> b': '2'})
    variable.set_label

# Generated at 2022-06-20 12:27:29.913578
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from . import runtime
    foo = runtime.Tracer()
    foo.__enter__()

# Generated at 2022-06-20 12:27:36.485707
# Unit test for function get_write_function
def test_get_write_function():
    import io
    write = get_write_function(None, False)
    assert write(u'hello') is None
    stream = io.StringIO()
    write = get_write_function(stream, False)
    write(u'hello')
    assert stream.getvalue() == u'hello'
    assert pycompat.is_string(stream.getvalue())
    write = get_write_function(u'pep.txt', True)
    write(u'hello')
    with open(u'pep.txt', 'r') as f:
        assert f.read() == u'hello'
    os.remove(u'pep.txt')
test_get_write_function()



# Generated at 2022-06-20 12:27:47.470669
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  # initializing Tracer class
  tracer = pysnooper.snoop()
  frame = DummyFrame()
  frame.f_lineno = 1
  source = {1: 'print("hello world")'}
  def mock_get_path_and_source_from_frame(*args):
    return source

  # override the original get_path_and_source_from_frame to check calls using
  # mock_get_path_and_source_from_frame
  pysnooper.pysnooper.get_path_and_source_from_frame = mock_get_path_and_source_from_frame
  # runs the method trace
  tracer.trace(frame, 'call', None)

  # check whether get_path_and_source_from_frame is called once

# Generated at 2022-06-20 12:27:49.470389
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0] == UnavailableSource()[1] == \
           u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:27:59.561395
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from .utils import StateTransitionMachine

    with StateTransitionMachine() as sm:
        @sm.on_enter(['START'])
        def start():
            assert thread_local.depth == 0
            return 'START->INITIALIZING'

        @sm.on_enter(['INITIALIZING'])
        def begin_init():
            return 'INITIALIZING->INITIALIZED'

        @sm.on_enter(['INITIALIZED'])
        def check_init():
            assert thread_local.depth == -1
            return 'INITIALIZED->ENTERING'

        @sm.on_enter(['ENTERING'])
        def begin_enter():
            assert thread_local.depth == -1
            return 'ENTERING->ENTERED'


# Generated at 2022-06-20 12:28:10.700863
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # Default parameters
    # These are basically just for coverage testing, maybe not useful
    tracer = Tracer()
    tracer.depth = 1
    tracer.write("test_Tracer_trace")

    # This test is used to verify the correctness of depth feature
    # depth = 1
    # Setting depth to 1 only tracer the first frame, thus the second frame
    # should not be realesed
    # And this part is just for the sake of coverage
    def foo1():
        pass
    tracer.__enter__()
    foo1()
    tracer.__exit__(None, None, None)

    # depth = 1
    # Setting depth to 2 should trace the 2 frames
    def foo2():
        def foo2_1():
            pass
        foo2_1()
    tracer.__enter__()
   

# Generated at 2022-06-20 12:28:42.117346
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():

    # Initializing object...
    t = Tracer(watch=())
    t.thread_info_padding = 0

    # Testing 'current_thread_len > thread_info_padding'
    assert ' ' * 7 == t.set_thread_info_padding(thread_info=' ' * 4)
    assert 4 == t.thread_info_padding

    # Testing 'current_thread_len = thread_info_padding'
    assert ' ' * 7 == t.set_thread_info_padding(thread_info=' ' * 7)
    assert 7 == t.thread_info_padding


# Generated at 2022-06-20 12:28:47.353786
# Unit test for constructor of class Tracer
def test_Tracer():
    def f(a, b):
        c = 1
        return a + b + c

    with Tracer(watch='a', watch_explode='b'):
        f(1, 2)


if __name__ == '__main__':
    sys.stderr.write("Error: pysnooper has to be used as a decorator.\n")
    sys.exit(1)

# Generated at 2022-06-20 12:28:51.748491
# Unit test for function get_write_function
def test_get_write_function():
    for output in ((), [], {}, 1):
        with pytest.raises(Exception):
            get_write_function(output, overwrite=True)



# Generated at 2022-06-20 12:28:57.747258
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func():
        """This is the function we'll test on."""
        source_line_number = inspect.currentframe(). \
                             f_back.f_lineno + 1
        assert source_line_number == get_path_and_source_from_frame(
            inspect.currentframe().f_back
        )[1][source_line_number - 1].strip() == 'source_line = 1'
        return func

    func()



# Generated at 2022-06-20 12:29:04.534255
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[:] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[:5:2] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[5:2:2] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[3] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-3] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:29:08.426245
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    """Test case for method Tracer.__enter__ of class Tracer"""
    def test_method__case_1():
        """Test case for method Tracer.__enter__ of class Tracer"""
        snooper_instance = Tracer()
        snooper_instance.snoop()
        return None
    test_method__case_1()
    return None

# Generated at 2022-06-20 12:29:09.837710
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    """Snooping functions works"""
    pass


# Generated at 2022-06-20 12:29:18.313015
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import os
    import tempfile
    import shutil

    path = pycompat.Path(tempfile.mkdtemp())
    try:
        file_writer = FileWriter(path / 'myfile', overwrite=True)
        file_writer.write('this is a test\n')
        for _ in range(3):
            file_writer.write('this is another test\n')
        assert open(path / 'myfile', 'r').read() == \
               'this is a test\n' + 'this is another test\n'*3
    finally:
        shutil.rmtree(path)



# Generated at 2022-06-20 12:29:19.882973
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    UnavailableSource()[0] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:29:25.618253
# Unit test for constructor of class FileWriter
def test_FileWriter():
    unittest = pycompat.unittest_module
    with unittest.mock.patch('__main__.open',
                             new=unittest.mock.MagicMock()) as mock_open:
        file = FileWriter('file_name', 'overwrite')
        assert file.path == 'file_name'
        assert file.overwrite == 'overwrite'



# Generated at 2022-06-20 12:30:30.079155
# Unit test for function get_write_function
def test_get_write_function():
    with open('test.txt', 'w') as f:
        write = get_write_function(f, True)
        write('Hello')
        with open('test.txt') as f2:
            assert f2.read() == 'Hello'
        write = get_write_function(None, True)
        import io

        stream = io.StringIO()
        sys.stderr = stream
        write('Hi')
        assert stream.getvalue() == 'Hi'
        stream.truncate(0)
        write = get_write_function(stream.write, True)
        write('Hello')
        assert stream.getvalue() == 'Hello'
    os.remove('test.txt')




# Generated at 2022-06-20 12:30:41.166597
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import tempfile, time
    def foo():
        pass
    def bar(x):
        print(x)
    def baz():
        raise ValueError('foo')
    def qux():
        raise StopIteration()
    def quux(x, z):
        yield x
        try:
            yield z
        finally:
            x = 3
    def coro():
        yield
    def gen():
        yield 1
        return

# Generated at 2022-06-20 12:30:48.503401
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import sys
    import inspect
    import threading
    import datetime
    import utils
    import thread_global
    import pycompat
    try:
        import opcode
    except ImportError:
        opcode = None
    with Tracer() as tracer:
        tracer.watch = [
            'v' if isinstance(v, BaseVariable) else CommonVariable(v)
            for v in utils.ensure_tuple(watch)
         ] + [
             v if isinstance(v, BaseVariable) else Exploding(v)
             for v in utils.ensure_tuple(watch_explode)
        ]
        thread_global.__dict__.setdefault('depth', -1)
        calling_frame = inspect.currentframe().f_back
        # calling_frame = t.f_back


# Generated at 2022-06-20 12:30:59.061962
# Unit test for function get_local_reprs
def test_get_local_reprs():
    x = 3
    y = 'hello'
    z = None
    def egg():
        '''Docstring for egg.'''
        b = 7
        def spam():
            return 4
        def cheese():
            a = 6
            c = {'spam': 5}
            return c
        return spam, cheese
    spam, cheese = egg()

    frame = inspect.currentframe()
    watch = [
        CommonVariable('x', 'X'),
        CommonVariable('y', 'Y'),
        CommonVariable('z', 'Z'),
        CommonVariable('egg', 'Egg'),
        CommonVariable('spam', 'Spam'),
        CommonVariable('cheese', 'Cheese'),
    ]
    result = get_local_reprs(frame, watch=watch, max_length=200)

# Generated at 2022-06-20 12:31:03.604006
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = f.__code__.co_filename, 0, 'changeme', f.__code__.co_lasti, None
    assert get_path_and_source_from_frame(frame) == (f.__code__.co_filename,
                                                     UnavailableSource())



# Generated at 2022-06-20 12:31:09.111845
# Unit test for constructor of class Tracer
def test_Tracer():
    @snoop(watch=('Foo.bar', 'Foo.baz.qux'))
    def foo():
        return Foo()

    class Foo(object):
        def __init__(self):
            self.bar = 0
            self.baz = Bar()

        def __repr__(self):
            return 'Foo()'

    class Bar(object):
        def __init__(self):
            self.qux = 1

        def __repr__(self):
            return 'Bar()'

    foo()


# Generated at 2022-06-20 12:31:20.650668
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    file_path = os.path.join(os.path.expanduser('~'), 'snoop.log')
    with open(file_path, 'w') as file:
        file.truncate(0)
    class Class:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    def function_with_exploding_watch():
        pass
    class CustomVariable(Variable):
        def get_repr(frame):
            pass

    function_with_exploding_watch = Tracer(watch_explode=('self', 'a'),
                    watch=(CustomVariable(),), prefix='>> ')(
                    function_with_exploding_watch
                    )
    function_with_exploding_watch()

# Generated at 2022-06-20 12:31:23.397370
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'
    assert uas[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:27.355497
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    tracer.set_thread_info_padding("thread_01")
    tracer.set_thread_info_padding("thread")
    tracer.set_thread_info_padding("thread_01")
    assert tracer.thread_info_padding == 9

# Generated at 2022-06-20 12:31:28.650276
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    # No explicit test for method __call__ of class Tracer
    pass