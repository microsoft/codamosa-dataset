

# Generated at 2022-06-20 12:25:48.456779
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    # No parameters
    tracer = Tracer()
    # with parameters
    frame = inspect.currentframe()
    event = 'call'
    arg = 'arg'
    tracer.trace(frame, event, arg)
    # Test each possible event
    tracer.trace(frame, 'call', arg)
    tracer.trace(frame, 'exception', (Exception, Exception("just an Exception"), None))
    tracer.trace(frame, 'c_call', arg)
    tracer.trace(frame, 'c_exception', arg)
    tracer.trace(frame, 'c_return', arg)
    tracer.trace(frame, 'line', arg)
    tracer.trace(frame, 'return', arg)
    tracer.trace(frame, 'opcode', arg)
    # Test __enter__ and __

# Generated at 2022-06-20 12:25:59.999025
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    first = tracer.set_thread_info_padding("  ")
    second = tracer.set_thread_info_padding("   ")
    third = tracer.set_thread_info_padding("         ")
    assert first == "  ", "actual: {}".format(first)
    assert second == "   ", "actual: {}".format(second)
    assert third == "         ", "actual: {}".format(third)

    # Unit test for method write of class Tracer
    def test_Tracer_write():
        import io
        import sys
        import builtins
        # Redirect stdout to temp file

        stdout = sys.stdout
        sys.stdout = io.StringIO()
        tracer = Tracer()

# Generated at 2022-06-20 12:26:05.895503
# Unit test for function get_local_reprs
def test_get_local_reprs():
    x = 7
    def f():
        if 3 == 5:
            x = 9
            y = x
            return x, y
        else:
            return 4, 4
    f()
    local_reprs = get_local_reprs(sys._getframe())
    assert local_reprs == {'__doc__': 'None', 'x': '7', 'f': '<function f at ...>'}



# Generated at 2022-06-20 12:26:07.134562
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    assert UnavailableSource()[0]

source_cache = {}


# Generated at 2022-06-20 12:26:13.875561
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pysnooper
    import io
    # We'll check that the @snooper decorator works without needing a filename
    # (so let's use StringIO instead of a regular file)

    # pysnooper.snoop()
    #
    output = io.StringIO()
    tracer = pysnooper.Tracer(output=output)
    #
    tracer.__enter__()
    #
    assert False # TODO: implement your test here


# Generated at 2022-06-20 12:26:23.409194
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    import os.path
    import sys

    import python_toolbox.sys_tools

    def foo(): pass
    frame = inspect.currentframe()
    for _ in range(2):
        frame = frame.f_back
    __file__ = python_toolbox.sys_tools.__file__
    path, source = get_path_and_source_from_frame(frame)
    assert path == os.path.normcase(__file__)
    assert source == open(__file__, 'rb').read().splitlines()
test_get_path_and_source_from_frame()



# Generated at 2022-06-20 12:26:24.968495
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    uas = UnavailableSource()
    assert uas[10] == u'SOURCE IS UNAVAILABLE'


# Generated at 2022-06-20 12:26:29.440207
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        path = os.path.join(tempdir, 'test.txt') #create a test file
    writer = FileWriter(path, True)
    writer.write('First_line\n')
    writer = FileWriter(path, False)
    writer.write('Second_line\n')
    with open (path) as f:
        assert f.read() == 'First_line\nSecond_line\n'



# Generated at 2022-06-20 12:26:36.882668
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import io
    output = io.StringIO()
    watch = ['foo']
    prefix = 'ZZZ '
    max_variable_length = 100
    # Test whether Tracer decorated function correctly
    def function():
        pass
    assert Tracer(output, watch, prefix, max_variable_length)(function) == function
    # Test whether Tracer decorated class correctly
    class A(object):
        def method(self):
            pass
    a = A()
    for attr in ('method',):
        assert getattr(a, attr) == getattr(Tracer(output, watch, prefix, max_variable_length)(a), attr)

# Generated at 2022-06-20 12:26:43.450152
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        pass
    frame = get_frame_by_name('test_get_path_and_source_from_frame',
                              context=1)
    source = get_path_and_source_from_frame(frame)[1][0].strip()
    assert source == 'def f():'
test_get_path_and_source_from_frame()



# Generated at 2022-06-20 12:27:06.348659
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pysnooper
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_output():
        output = StringIO()
        with pysnooper.snoop(output=output):
            yield output

    @pysnooper.snoop()
    def test_function():
        pass

    with capture_output() as output:
        test_function()

    assert 'Starting' in output.getvalue()
    assert 'Elapsed' in output.getvalue()
    assert 'Return value' in output.getvalue()


# Generated at 2022-06-20 12:27:07.856378
# Unit test for function get_write_function
def test_get_write_function():
    class FakeWritableStream(object):
        def write(self, s):
            print('Wrote %s' % s)
    assert get_write_function(FakeWritableStream(), None)



# Generated at 2022-06-20 12:27:09.655460
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    assert UnavailableSource()[0] == u'SOURCE IS UNAVAILABLE'

# Generated at 2022-06-20 12:27:13.054196
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    def foo():
        pass
    tracer = Tracer()
    assert pycompat.iscoroutinefunction(tracer(foo)) == True
    assert pycompat.isasyncgenfunction(tracer(foo)) == False
    assert inspect.isgeneratorfunction(tracer(foo)) == False



# Generated at 2022-06-20 12:27:20.789814
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = os.path.join(os.path.dirname(__file__), "test_filewriter.txt")
    filewriter = FileWriter(path, True)
    filewriter.write('test 1')
    # After first write, overwrite is false, so next write should append
    filewriter.write('test 2')
    with open(path) as f:
        file_content = f.read()
    assert file_content == 'test 1test 2'
    os.remove(path)



# Generated at 2022-06-20 12:27:24.773651
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def test_function():
        pass
    frame_data = get_path_and_source_from_frame(
        inspect.currentframe().f_back)
    file_name, source = frame_data
    assert file_name.endswith('tests/test_getsource.py')
    assert source is not None
    assert 'test_get_path_and_source_from_frame' in source



# Generated at 2022-06-20 12:27:30.735762
# Unit test for constructor of class Tracer
def test_Tracer():
    input_string = "je ne pas understand francais"
    output = StringIO()
    tracer = Tracer(output=output, watch=('input_string', 'output'))
    assert tracer.watch[0].name == 'input_string'
    assert tracer.write == output.write
    assert output.getvalue() == ""
    input_string = "I don't understand french"
    tracer.write('Just testing')
    assert output.getvalue() == "Just testing\n"
    # Constructor tests done
    # Cleaning up
    output.close()

# Unit tests for the Tracer.__call__ method

# Generated at 2022-06-20 12:27:36.871137
# Unit test for function get_write_function
def test_get_write_function():
    class WritableStream(object):
        def write(self, s):
            print(s)

    writable_stream = WritableStream()
    assert get_write_function(writable_stream, overwrite=False) is \
           writable_stream.write

    file_writer = get_write_function('foo', overwrite=True)
    def function(s):
        print(s)
    assert get_write_function(function, overwrite=False) is function
    old_stderr = sys.stderr
    sys.stderr = utils.WritableStream()
    assert get_write_function(None, overwrite=False) is sys.stderr.write



# Generated at 2022-06-20 12:27:38.737427
# Unit test for constructor of class Tracer
def test_Tracer():
    tracer = Tracer(1)
    assert tracer.depth == 1


# Generated at 2022-06-20 12:27:49.459163
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    from unittest import TestCase
    from unittest.mock import Mock
    from unittest.mock import patch
    
    import threading
    import time
    import traceback

    def main():
        pass
        
    class TracerTest(TestCase):
        # Test use case when current thread length greater than thread_info_padding
        def test_Tracer_set_thread_info_padding_case_1(self):
            t = Tracer()
            t.thread_info = True
            thread_info_padding = 50
            t.thread_info_padding = thread_info_padding
            current_thread = threading.current_thread()
            thread_info = "{ident}-{name} ".format(
                ident=current_thread.ident, name=current_thread.getName())

# Generated at 2022-06-20 12:28:11.501521
# Unit test for method write of class Tracer
def test_Tracer_write():
    with mock.patch('sys.stdout', new=io.StringIO()) as stdout:
        Tracer().write('str')
        assert stdout.getvalue() == 'str\n'

# Generated at 2022-06-20 12:28:14.146285
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    try:
        a = UnavailableSource()
        print(a[7])
    except Exception:
        assert 0, 'Exception in UnavailableSource'


# Generated at 2022-06-20 12:28:22.214449
# Unit test for function get_write_function
def test_get_write_function():
    assert get_write_function(write_function, False)('a') == write_function('a')
    assert get_write_function(write_function, True)('a') == write_function('a')
    assert get_write_function(os.path.devnull, True)('a') == None
    assert get_write_function(os.path.devnull, False)('a') == None
    assert get_write_function(sys.stdout, True)('a') == sys.stdout.write('a')
    assert get_write_function(sys.stdout, False)('a') == sys.stdout.write('a')
    assert get_write_function(None, False)('a') == sys.stderr.write('a')
test_get_write_function()
del test_get_write_function



# Generated at 2022-06-20 12:28:32.534795
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import contextlib
    import types
    import unittest
    import pkgutil
    import textwrap

    def my_fn():
        return get_path_and_source_from_frame(inspect.currentframe())

    class MyClass(object):
        def my_method(self):
            return get_path_and_source_from_frame(inspect.currentframe())

    class GetSourceTester(unittest.TestCase):
        def test(self):
            self.assertEqual(my_fn(), ('__main__', [u'def my_fn():']))
            self.assertEqual(MyClass().my_method(),
                             ('__main__', [u'    def my_method(self):']))


# Generated at 2022-06-20 12:28:34.425775
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import pytest
    # no exception raised
    assert Tracer().__exit__(None, None, None) == None


# Generated at 2022-06-20 12:28:42.986147
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    write = FileWriter(__file__[:-3] + 'test_FileWriter_write.output', True).write
    write(u'Test 1\n')
    write(u'Test 2')
    write(u'Test 3\n')
    write(u'Test 4\n')
    with open(__file__[:-3] + 'test_FileWriter_write.output', encoding='utf-8') as output_file:
        assert output_file.read() == 'Test 1\nTest 2Test 3\nTest 4\n'



# Generated at 2022-06-20 12:28:44.930226
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    try:
        raise Exception
    except Exception:
        assert isinstance(UnavailableSource()[0], str)



# Generated at 2022-06-20 12:28:47.463074
# Unit test for constructor of class FileWriter
def test_FileWriter():
    FileWriter('file.txt', overwrite=True)
    FileWriter(pycompat.Path('file.txt'), overwrite=True)


_stop_iteration_str = str(StopIteration)



# Generated at 2022-06-20 12:28:59.428106
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():

    # Test normal module
    def f(x, y):
        return x + y

    dummy_source = inspect.getsource(f)
    with open('test_get_path_and_source_from_frame.py', 'w') as f:
        f.write(dummy_source)

    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    assert result[0] == 'test_get_path_and_source_from_frame.py'

    # Test ipython
    import IPython
    ipython_shell = IPython.get_ipython()

    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)

# Generated at 2022-06-20 12:29:08.780204
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    function_or_class = _test_function_or_class
    output = 'output'
    watch = 'watch'
    watch_explode = 'watch_explode'
    depth = object()
    prefix = object()
    overwrite = object()
    thread_info = object()
    custom_repr = object()
    max_variable_length = object()
    normalize = object()
    relative_time = object()
    assert Tracer(output, watch, watch_explode, depth, prefix, overwrite, thread_info, custom_repr, max_variable_length, normalize, relative_time)(function_or_class) == function_or_class

# Generated at 2022-06-20 12:30:10.106105
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    uas = UnavailableSource()
    assert uas[0] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:30:19.499504
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import inspect
    import functools
    import threading
    import datetime
    import sys
    import threading
    import itertools
    import traceback
    import opcode
    import types
    import re
    import warnings
    import os
    import pycompat
    import pysnooper.utils as utils
    import pysnooper.variable as variable
    import pysnooper.tracer.threading_local as threading_local
    # For module test
    import multiprocessing

    # user defined type
    if PY2:
        class CustomStr(str):
            pass

        class CustomUnicode(unicode):
            pass
    else:
        class CustomStr(str):
            pass
    class CustomInt(int):
        pass
    class CustomFloat(float):
        pass
   

# Generated at 2022-06-20 12:30:24.342853
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    tracer = Tracer(output='test.log',watch=(), watch_explode=(), depth=1,
                 prefix='', overwrite=False, thread_info=False, custom_repr=(),
                 max_variable_length=100, normalize=False, relative_time=False)
    #TODO: Implement test
    return


# Generated at 2022-06-20 12:30:35.836504
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    from . import mock_module
    from . import utils
    pass_over_whitelisted = utils.get_var_repr = lambda x, y, z, q, w, e: 'mocked_repr'
    mocked_snooper = mock_module.snooper
    mocked_snooper.watch = []
    mocked_snooper.watch_explode = []
    mocked_snooper.depth = 1
    mocked_snooper.prefix = ''
    mocked_snooper.overwrite = False
    mocked_snooper.thread_info = False
    mocked_snooper.custom_repr = ()
    mocked_snooper.max_variable_length = 100
    mocked_snooper.normalize = False
    mocked_snooper.relative_time = False
    mocked

# Generated at 2022-06-20 12:30:45.411470
# Unit test for function get_write_function
def test_get_write_function():
    with open('test', 'w') as f:
        write = get_write_function(f, True)
        write('Test')
    with open('test', 'r') as f:
        assert f.read() == 'Test'
    test = utils.WritableStream()
    write = get_write_function(test, False)
    write('Test')
    assert test.getvalue() == 'Test'
    import sys
    write = get_write_function(sys.stderr, False)
    write('Test')
    write = get_write_function(None, False)
    write('Test')
    write = get_write_function(None, True)
    try:
        write('Test')
    except Exception as exception:
        assert isinstance(exception, Exception)
    else:
        raise Exception()



# Generated at 2022-06-20 12:30:49.054275
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    '''
    >>> def f():
    ...     return 3
    >>> import inspect
    >>> frame = inspect.currentframe()
    >>> get_path_and_source_from_frame(frame)
    """
    >>> def f():
    ...     return 3
    """
    '''



# Generated at 2022-06-20 12:30:59.796187
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    with utils.temp_folder() as temp_folder:
        path = temp_folder / 'foo'

        # The following test is important for catching bugs in Python 2
        # (issues #5 and #19)
        file_writer = FileWriter(path, True)
        file_writer.write(u'אבג')
        with open(path, 'r', encoding='utf-8') as f:
            assert f.read() == u'אבג'
        file_writer.write(u'דהו')
        with open(path, 'r', encoding='utf-8') as f:
            assert f.read() == u'אבגדהו'
        file_writer.write(u'זחטי')

# Generated at 2022-06-20 12:31:02.181632
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:09.457420
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer_obj = Tracer()
    tracer_obj.thread_info_padding = 4
    assert tracer_obj.set_thread_info_padding('1-2') == '1-2  '

    tracer_obj.thread_info_padding = 6
    assert tracer_obj.set_thread_info_padding('1-2') == '1-2   '

    tracer_obj.thread_info_padding = 6
    assert tracer_obj.set_thread_info_padding('1-2  ') == '1-2     '

    tracer_obj.thread_info_padding = 6
    assert tracer_obj.set_thread_info_padding('1-2   ') == '1-2      '


# Generated at 2022-06-20 12:31:16.243653
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer()
    thread_info = tracer.set_thread_info_padding("1-my_thread ")
    assert thread_info == "1-my_thread".ljust(tracer.thread_info_padding)
    thread_info = tracer.set_thread_info_padding("120-my_thread ")
    assert thread_info == "120-my_thread".ljust(tracer.thread_info_padding)

# Generated at 2022-06-20 12:32:25.539372
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    try:
        import pytest
    except ImportError:
        return
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as directory:
        output_file_path = os.path.join(directory, 'doggie.txt')
        write = FileWriter(output_file_path, overwrite=True).write
        write('kitty')
        with open(output_file_path) as f:
            assert f.read() == 'kitty'
        write('doggie')
        with open(output_file_path) as f:
            # Make sure we are appending instead of overwriting
            assert f.read() == 'kittydoggie'



# Generated at 2022-06-20 12:32:32.166969
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import os
    import sys
    import inspect

    def test_function():
        pass
    test_function_filename = inspect.getsourcefile(test_function)
    try:
        original_sys_path = sys.path[:]
        sys.path.insert(0, os.path.dirname(test_function_filename))
        assert get_path_and_source_from_frame(inspect.currentframe()) == \
                                                            (test_function_filename,
                                                             inspect.getsource(test_function).splitlines())
    finally:
        sys.path = original_sys_path



# Generated at 2022-06-20 12:32:40.441875
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .pycompat import PathLike
    from .utils import FakeWritableStream as FWS
    from .utils import test_write_stream
    
    fw = FileWriter('hi', True)
    fw.write('')
    assert fw.overwrite == False
    fw.write('')
    
    fw = FileWriter(FWS(), True)
    fw.write('')
    assert fw.overwrite == False
    fw.write('')
    
    # test_write_stream.py is in the same directory as FileWriter
    t = PathLike('.')
    # PathLike must be str or bytes
    t = 'test/test_write_stream/test_FileWriter_write.txt'
    if isinstance(t, (bytes, str)):
        fw = File

# Generated at 2022-06-20 12:32:44.060781
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import unittest
    import doctest
    from . import pysnooper
    class TestTracer___call__(unittest.TestCase):
        def test_it(self):
            doctest.testmod(pysnooper)
    unittest.main()




# Generated at 2022-06-20 12:32:49.366391
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    out = FileWriter('a.txt',True)
    with open('a.txt','w',encoding='utf-8') as output_file:
        output_file.write('first\nsecond\n')
    out.write('third\n')
    with open('a.txt','r',encoding='utf-8') as output_file:
        content = output_file.read()
    assert(content == 'first\nsecond\nthird\n')

# Generated at 2022-06-20 12:32:58.348697
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    import io
    import sys

    # Original code
    if True:
        a = 1
        b = 2
        c = 3
    else:
        print('\nERR 1: current code is not original')
        assert False
    d = c + b
    e = a + d
    f = a + b + c + d + e

    # Replacement code
    if True:
        a = 3
        b = 2
        c = 3
    else:
        print('\nERR 2: current code is not replacement')
        assert False
    d = 3 + b
    e = 3 + d
    f = 3 + b + 3 + d + e

    test_Tracer_trace.current_line_number = 0
    test_Tracer_trace.current_source_line = None


# Generated at 2022-06-20 12:33:03.893101
# Unit test for constructor of class FileWriter
def test_FileWriter():
    path = '/tmp/test.txt'
    overwrite = True
    fw = FileWriter(path, overwrite)
    write_function = fw.write
    write_function('hello world')
    try:
        with open(path, 'r') as f:
            content = f.read()
        assert content == 'hello world'
    finally:
        os.remove(path)



# Generated at 2022-06-20 12:33:05.627222
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    global DISABLED, thread_global
    DISABLED = False
    thread_global.depth = -1

# Generated at 2022-06-20 12:33:12.002983
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Create an instance of class Tracer
    tracer = Tracer()

    # Set variable `exc_type`
    exc_type = None

    # Set variable `exc_value`
    exc_value = None

    # Set variable `exc_traceback`
    exc_traceback = None

    # Call method __exit__ of class Tracer instance
    return_value = tracer.__exit__(exc_type, exc_value, exc_traceback)

    return return_value


# Generated at 2022-06-20 12:33:19.190456
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    import pysnooper.log_threading as log_threading
    global DISABLED
    DISABLED = False
    global REALTIME_WRITE_TO_CONSOLE
    REALTIME_WRITE_TO_CONSOLE = False
    def raise_error(x):
        return 1/0
    def bar_func(x):
        return 1/0
    def foo_func(x):
        return bar_func(x)
    def decorated_func():
        foo_func('')
    try:
        s = Tracer()
        decorated_func = s(decorated_func)
        with s:
            try:
                decorated_func()
            except Exception:
                pass
    except:
        pass


# Generated at 2022-06-20 12:34:42.771962
# Unit test for constructor of class Tracer
def test_Tracer():

    snooper = pysnooper.Snooper()
    assert snooper.depth == 1, snooper.depth
    assert snooper.prefix == '', snooper.prefix
    assert snooper.watch == [], snooper.watch

    snooper = pysnooper.Snooper(depth=3, prefix='xx-', watch='foo')
    assert snooper.depth == 3, snooper.depth
    assert snooper.prefix == 'xx-', snooper.prefix
    assert snooper.watch == [CommonVariable('foo')], snooper.watch

    snooper = pysnooper.Snooper(watch=('foo', 'bar'))
    assert snooper.depth == 1, snooper.depth
    assert snooper.prefix == '', snooper

# Generated at 2022-06-20 12:34:50.358367
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    self = Tracer()

    self.watch = [CommonVariable('foo')]
    self.depth = 1
    self.prefix = ''
    self.thread_info = False
    self.thread_info_padding = 0
    self.target_codes = set()
    self.target_frames = set()
    self.thread_local = threading.local()
    self.custom_repr = ()
    self.last_source_path = None

    def function_or_class():
        pass

    assert self._wrap_class(function_or_class) == function_or_class
    assert self._wrap_function(function_or_class) is not function_or_class


# Generated at 2022-06-20 12:34:56.291983
# Unit test for constructor of class FileWriter
def test_FileWriter():
    import tempfile
    temp_dir = tempfile.gettempdir()
    filename = os.path.join(temp_dir, "test.log")
    filewriter = FileWriter(filename, True)
    filewriter.write("this is a test")
    filewriter = FileWriter(filename, False)
    filewriter.write("this is a test")


# Generated at 2022-06-20 12:34:59.377274
# Unit test for constructor of class FileWriter
def test_FileWriter():
    writer = FileWriter("test.txt", True)
    s = "test"
    writer.write(s)
    with open("test.txt", "r", encoding="utf-8") as file:
        assert s == file.read()

