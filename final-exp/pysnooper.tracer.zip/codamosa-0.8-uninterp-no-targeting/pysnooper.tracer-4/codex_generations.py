

# Generated at 2022-06-20 12:25:56.764452
# Unit test for function get_write_function
def test_get_write_function():
    import tempfile
    from . import dotdot

    with tempfile.TemporaryDirectory() as temp_directory:
        with open(os.path.join(temp_directory, 'out.txt'), 'w') as f:
            write_function = get_write_function(f, False)
            write_function(u'hello, world!\n')

        with open(os.path.join(temp_directory, 'out.txt')) as f:
            assert f.read() == 'hello, world!\n'

        write_function = get_write_function(None, False)
        write_function(u'hello, world!\n')
        write_function('ç\n')

        with open(os.path.join(temp_directory, 'out.txt'), 'a') as f:
            write_function = get_write

# Generated at 2022-06-20 12:26:06.936560
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    from .file_writer import FileWriter
    from . import utils
    from .temp import TempFolder
    from .path import Path

    temp_folder = TempFolder()
    path1 = temp_folder.make_file_with_content(u'hello')
    path2 = temp_folder.make_file_with_content(u'hello')

    with utils.open(path1) as f:
        assert f.read() == 'hello'

    with utils.open(path2) as f:
        assert f.read() == 'hello'

    content = 'hello'
    writer = FileWriter(path1, True)
    writer.write(content)
    writer.write(content)

    with utils.open(path1) as f:
        assert f.read() == content + content + 'hello'

    writer

# Generated at 2022-06-20 12:26:14.802833
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    path = 'test_FileWriter_write.txt'
    file_writer = FileWriter(path, overwrite=True)
    file_writer.write('test')
    assert os.path.isfile(path)
    with open(path, encoding='utf-8') as output_file:
        assert output_file.read() == 'test'
    file_writer.write('2')
    with open(path, encoding='utf-8') as output_file:
        assert output_file.read() == 'test2'
    os.remove(path)
test_FileWriter_write()



# Generated at 2022-06-20 12:26:23.217449
# Unit test for constructor of class Tracer
def test_Tracer():
    # Empty list of local variables
    frame = inspect.currentframe()
    local_reprs = get_local_reprs(frame)
    assert local_reprs == {}

    # Non-empty list of local variables
    local_variables = {}
    local_variables['a'] = 42
    frame = inspect.currentframe()
    local_reprs = get_local_reprs(frame)
    assert local_reprs['a'] == '42'


# Generated at 2022-06-20 12:26:30.772013
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
  tracer = Tracer()
  _frame = mock.Mock()
  _frame.f_code = mock.Mock()
  _frame.f_code.co_filename = mock.Mock()
  _frame.f_back = _frame
  _frame.f_trace = mock.Mock()
  with tracer:
    if _frame.f_code.co_filename == Tracer.__enter__.__code__.co_filename:
      pass
    else:
      pass
    tracer.target_frames.add(_frame)
  pass


# Generated at 2022-06-20 12:26:34.174677
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    # Import here to prevent a circular import
    from pysnooper import snoop
    @snoop(watch=['a'])
    def test1(a):
        return a

    with pytest.raises(Exception):
        test1()


# Generated at 2022-06-20 12:26:35.103697
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()



# Generated at 2022-06-20 12:26:40.453443
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    for func in [
        # '__exit__',
        '__init__',
        '__enter__',
    ]:
        eval(func + '\n' + inspect.getsource(eval('Tracer.' + func)))
test_Tracer_trace()

# Generated at 2022-06-20 12:26:48.770288
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    import os
    # test writing to new file
    temp_path = tempfile.mktemp()
    file_writer = FileWriter(temp_path, overwrite=True)
    file_writer.write('hello')
    assert os.path.isfile(temp_path), "file not created"
    assert os.path.exists(temp_path), 'file not written'
    assert open(temp_path).read() == 'hello'
    # test appending
    file_writer.write(' again')
    assert open(temp_path).read() == 'hello again'
    os.remove(temp_path)



# Generated at 2022-06-20 12:26:58.058762
# Unit test for constructor of class FileWriter
def test_FileWriter():
    from pytest import raises
    from itertools import groupby
    class FakePath(object):
        def __init__(self, path):
            self.path = path
        def __unicode__(self):
            return u"Unicode('%s')" % self.path
    class FakeWritableStream(object):
        def __init__(self, *args):
            self.args = args
        def write(self, content):
            pass

    with raises(Exception):
        FileWriter(FakePath(u"some/file/path"), overwrite=True)
    w1 = FileWriter(FakePath(u"some/file/path"), overwrite=False)
    w2 = FileWriter(FakePath(u"some/file/path"), overwrite=False)

# Generated at 2022-06-20 12:27:34.624780
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    # Note: this is a good unit test, since it exercises all statements in the
    # function.
    source_lines = UnavailableSource()
    source_lines[1]



# Generated at 2022-06-20 12:27:45.743858
# Unit test for function get_write_function
def test_get_write_function():
    import os
    import tempfile
    import io

    with tempfile.NamedTemporaryFile(delete=False) as f:
        write_func = get_write_function(f, overwrite=False)
        write_func(u'abc')
    with open(f.name, 'rb') as f:
        assert f.read() == b'abc'
    os.unlink(f.name)

    f = io.BytesIO()
    write_func = get_write_function(f, overwrite=False)
    write_func(u'abc')
    assert f.getvalue() == b'abc'

    with pytest.raises(Exception):
        f = io.BytesIO()
        write_func = get_write_function(f, overwrite=True)


# Generated at 2022-06-20 12:27:55.890315
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    import tempfile
    with tempfile.NamedTemporaryFile('w', delete=False) as temp_file:
        temp_file_name = temp_file.name
    fw = FileWriter(temp_file_name, overwrite=True)
    file_content = '''\
This is the file content.
This is the second line.
'''
    fw(file_content)
    with open(temp_file_name, 'r') as temp_file:
        content = temp_file.read()
    assert content == file_content
    fw(file_content)
    with open(temp_file_name, 'r') as temp_file:
        content = temp_file.read()
    assert content == file_content + file_content




# Generated at 2022-06-20 12:28:03.429706
# Unit test for constructor of class Tracer
def test_Tracer():
    # Test watch and watch_explode
    tracer = Tracer(watch=('foo', 'self'))
    assert tracer.watch == [CommonVariable('foo'), CommonVariable('self')]
    tracer = Tracer(watch_explode=('foo', 'self'))
    assert tracer.watch == [Exploding('foo'), Exploding('self')]
    # Test watch += watch_explode
    tracer = Tracer(watch=(), watch_explode=('foo', 'self'))
    assert tracer.watch == [Exploding('foo'), Exploding('self')]
    tracer = Tracer(watch=('foo', 'self'), watch_explode=())
    assert tracer.watch == [CommonVariable('foo'), CommonVariable('self')]

# Generated at 2022-06-20 12:28:04.956524
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    with Tracer():
        pass


# Generated at 2022-06-20 12:28:16.208967
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    import time
    import sys
    import time
    import unittest
    import unittest.mock

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    except:
        print("no StringIO found")

    log = StringIO()
    tracer = Tracer(watch=True)

    with unittest.mock.patch.object(tracer, 'write') as mock_write:
        with tracer:
            pass
            #print('hi')

            try:
                1 / 0
            except:
                pass


# Generated at 2022-06-20 12:28:19.058145
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def f():
        return None
    assert get_path_and_source_from_frame(f.__code__.co_filename)
    assert get_path_and_source_from_frame(f.__code__.co_filename)



# Generated at 2022-06-20 12:28:30.349723
# Unit test for constructor of class FileWriter
def test_FileWriter():
    # test when output is None
    fw = FileWriter(None, True)
    assert fw.path == None
    assert fw.overwrite == True

    # test when output is writable object
    class MyWritable(io.TextIOBase):
        def write(self, s):
            pass
    fw = FileWriter(MyWritable(), True)
    assert fw.path == MyWritable()
    assert fw.overwrite == True

    # test when output is path-like object
    fw = FileWriter('/path/to/f', True)
    assert fw.path == '/path/to/f'
    assert fw.overwrite == True

    # test when output is path-like object and it is not overwritable
    fw = FileWriter('/path/to/f', False)
   

# Generated at 2022-06-20 12:28:33.168768
# Unit test for method write of class Tracer
def test_Tracer_write():
    """
    1. test_Tracer_write_null
    2. test_Tracer_write_not_null
    """
    pass





# Generated at 2022-06-20 12:28:43.745374
# Unit test for function get_local_reprs
def test_get_local_reprs():
    def f(a, b, c):
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8

        class H:
            def __init__(self, foo): pass

        h = H(h)
        return h

    frame = inspect.currentframe()
    local_reprs = get_local_reprs(frame,
                                  custom_repr=(collections.OrderedDict,))
    assert local_reprs == {'f': 'f', 'e': '5', 'd': '4', 'b': '2',
                           'a': '1', 'g': '7', 'c': '3', 'h': 'H(8)'}



# Generated at 2022-06-20 12:29:16.490009
# Unit test for method trace of class Tracer
def test_Tracer_trace():
    tracer = Tracer(output=StringIO())
    frame = MagicMock()
    frame.f_code = Mock()
    frame.f_code.co_filename = 'test_Tracer_trace'
    frame.f_lineno = 11
    frame.f_code.co_code = 'test_Tracer_trace'
    frame.f_lasti = 11
    tracer.trace(frame, 'call', 'test_Tracer_trace')

# Generated at 2022-06-20 12:29:21.376129
# Unit test for method write of class Tracer
def test_Tracer_write():
    import io
    output = io.StringIO()
    write = get_write_function(output, False)
    message = "Hello world"
    prefix = "pysnooper"
    write(f"{prefix}{message}")
    assert output.getvalue() == "pysnooperHello world\n"


# Generated at 2022-06-20 12:29:25.516284
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect
    frame = inspect.currentframe()
    result = get_path_and_source_from_frame(frame)
    assert result[0] == __file__
    for line in result[1]:
        assert isinstance(line, pycompat.string_type)



# Generated at 2022-06-20 12:29:34.562409
# Unit test for constructor of class Tracer
def test_Tracer():
    with open(os.devnull, 'w') as null:
        s = Tracer(output=null)
    assert s.watch == []
    assert s.frame_to_local_reprs == {}
    assert s.start_times == {}
    assert s.depth == 1
    assert s.prefix == ''
    assert s.target_codes == set()
    assert s.target_frames == set()
    assert s.thread_local.__dict__ == {}

    with open(os.devnull, 'w') as null:
        s = Tracer(output=null, watch='a')
    assert s.watch == [CommonVariable('a')]
    assert s.frame_to_local_reprs == {}
    assert s.start_times == {}
    assert s.depth == 1
    assert s.prefix == ''

# Generated at 2022-06-20 12:29:38.050219
# Unit test for method trace of class Tracer
def test_Tracer_trace():
  snooper = Tracer()
  l = locals()
  s = snooper.trace(None, None, None)
  s = snooper.trace(None, None, None)


# Generated at 2022-06-20 12:29:48.882737
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    tracer = Tracer(thread_info=True)
    
    # test case 1:
    current_thread_info_1 = "t-MainThread "
    tracer.set_thread_info_padding(current_thread_info_1)
    expected_padding = current_thread_info_1
    actual_padding = tracer.thread_info_padding
    test_case_1 = "test case 1: checking that padding is set to current_thread_info  : "
    test_case_1_result = actual_padding==expected_padding
    print(test_case_1 + str(test_case_1_result))
    
    # test case 2:
    current_thread_info_2 = "t-Thread 13 "
    tracer.set_thread_info_padding(current_thread_info_2)
    expected

# Generated at 2022-06-20 12:29:53.071213
# Unit test for constructor of class Tracer
def test_Tracer():
    import pytest
    with pytest.raises(AssertionError):
        Tracer(depth=0)

    with pytest.raises(AssertionError):
        Tracer(thread_info=True, normalize=True)


# Generated at 2022-06-20 12:29:54.274076
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    file_writer=FileWriter('test.txt',True)
    file_writer.write('hello world')


# Generated at 2022-06-20 12:29:55.531296
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    UnavailableSource()[0]

unavailable_source = UnavailableSource()


# Generated at 2022-06-20 12:29:57.366110
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    source = UnavailableSource()
    assert source[1] == 'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:30:35.188776
# Unit test for function get_local_reprs
def test_get_local_reprs():
    watch = [BaseVariable(name, lambda value: (name, value))
             for name in ('abc', 'def', 'ghi')]
    watch = sorted(watch, key=lambda variable: variable.name)
    test_frame = sys._getframe()
    local_reprs_dict = get_local_reprs(test_frame, watch=watch)
    assert sorted(local_reprs_dict.keys()) == sorted(['__builtins__', 'watch'])
    assert local_reprs_dict == {
        'watch':
            '[abc: <variable> abc=abc, def: <variable> def=def, '
            'ghi: <variable> ghi=ghi]'
    }



# Generated at 2022-06-20 12:30:42.577490
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    from unittest.mock import MagicMock
    tracer = Tracer()
    tracer.thread_info_padding = 5
    thread_info_padding = tracer.thread_info_padding
    current_thread = MagicMock()
    current_thread.ident = 1
    current_thread.getName.return_value = "test"
    thread_info = tracer.set_thread_info_padding(current_thread)
    assert thread_info_padding == tracer.thread_info_padding
    assert thread_info == "1-test "

# Generated at 2022-06-20 12:30:50.844490
# Unit test for method write of class Tracer
def test_Tracer_write():
    from io import StringIO
    from contextlib import redirect_stdout
    from pysnooper.snoop import Tracer
    data = "abcdefghijklmnopqrstuvwxyz"
    tr = Tracer(prefix="")
    with redirect_stdout(StringIO()) as buf:
        tr.write (data)
        assert buf.getvalue() == data+"\n"
        tr.write (data)
        assert buf.getvalue() == data+"\n"+data+"\n"
        tr.write (data)
        assert buf.getvalue() == data+"\n"+data+"\n"+data+"\n"

# Generated at 2022-06-20 12:30:56.240361
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    class _TestClass(object):
        def test(self):
            test = Tracer()
            test.set_thread_info_padding('Thread 1')
            test.set_thread_info_padding('Thread')
            test.set_thread_info_padding('Thread 10')
            test.set_thread_info_padding('Thread 2')
    test = _TestClass()
    test.test()

# Generated at 2022-06-20 12:31:06.228873
# Unit test for constructor of class Tracer
def test_Tracer():
    from io import StringIO
    import sys

    # Test class variable watch:
    s = StringIO()
    sys.stdout = s
    sys.stderr = s
    result_output = [
        "Starting var:.. inner_dict = {'b': 2, 'a': 1}",
        "Starting var:.. inner_list = [1, 2, 3]",
        "Starting var:.. inner_dict = {'b': 2, 'a': 1}",
        "Starting var:.. inner_list = [1, 2, 3]",
        'Call ended by exception',
        'Call ended by exception',
        'Call ended by exception',
        'Call ended by exception'
    ]


# Generated at 2022-06-20 12:31:17.109528
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    assert 1 == 1

    global COLON
    COLON = 'colon'

    global ARGS
    ARGS = 'args'

    global FUNC_NAME
    FUNC_NAME = 'func_name'

    global CALLS
    CALLS = 'calls'

    global CALLERS
    CALLERS = 'callers'

    global INDENT
    INDENT = 'indent'

    class AttributeMock(object):
        def __init__(self, name):
            self.name = name

        def __get__(self, obj, cls=None):
            if obj is None:
                return self
            return obj._attrs[self.name]

        def __set__(self, obj, value):
            obj._attrs[self.name] = value


# Generated at 2022-06-20 12:31:19.150748
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
  t = Tracer()
  assert t.__exit__(None, None, None) == None

# Generated at 2022-06-20 12:31:26.896164
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    import inspect, tempfile
    tf = tempfile.NamedTemporaryFile(mode='wb', delete=False)
    tf.write(b'# coding: latin-1\nspam\n')
    tf.close()
    try:
        source_lines, path = get_path_and_source_from_frame(
            inspect.currentframe()
        )
        assert path == tf.name
        assert source_lines == [u'# coding: latin-1', u'spam']
    finally:
        os.unlink(tf.name)
test_get_path_and_source_from_frame()



# Generated at 2022-06-20 12:31:30.337449
# Unit test for method __getitem__ of class UnavailableSource
def test_UnavailableSource___getitem__():
    unavailable_source = UnavailableSource()
    assert unavailable_source[5] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-5] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[slice(5, 10)] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:31:41.648145
# Unit test for constructor of class Tracer
def test_Tracer():
    def foo(bar):
        baz = 10
        return bar + baz

    with Tracer(output=get_write_function(),
                watch=['plus_args', 'bar', 'baz'],
                watch_explode=['plus_args'],
                depth=1,
                prefix='!!',
                overwrite=False,
                thread_info=False,
                custom_repr=(),
                max_variable_length=100,
                normalize=False,
                relative_time=False):
        foo(10)

# This code runs with python -m pysnooper, which is
# convenient for development
if __name__ == '__main__':
    output = sys.stdout

    # See if a commandline option for where to write snoop output exists:

# Generated at 2022-06-20 12:32:45.198628
# Unit test for constructor of class UnavailableSource
def test_UnavailableSource():
    unavailable_source = UnavailableSource()
    assert unavailable_source[0] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[1] == u'SOURCE IS UNAVAILABLE'
    assert unavailable_source[-1] == u'SOURCE IS UNAVAILABLE'



# Generated at 2022-06-20 12:32:49.332145
# Unit test for method __call__ of class Tracer
def test_Tracer___call__():
    from types import FunctionType

    # Case 1:
    def func1():
        pass

    assert type(Tracer()(func1)) is FunctionType

    # Case 2:
    class cls1:
        @classmethod
        def func2(cls):
            pass

    assert type(Tracer()(cls1)) is type



# Generated at 2022-06-20 12:32:52.775835
# Unit test for function get_local_reprs
def test_get_local_reprs():
    frame = get_test_frame(test_get_local_reprs)
    frame.f_locals['a'] = 2
    frame.f_locals['b'] = 2
    assert get_local_reprs(frame) == {'a': '2', 'b': '2'}



# Generated at 2022-06-20 12:32:54.498859
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    with Tracer() as tracer:
        assert not tracer.start_times
    assert not tracer.start_times


# Generated at 2022-06-20 12:33:04.955040
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    TEST_MSG = "The padding for thread info is expected to be {} but it is {}"
    self = Tracer(output=None, watch=(), watch_explode=(), depth=1, prefix='',
                  overwrite=False, thread_info=False, custom_repr=(),
                  max_variable_length=100, normalize=False, relative_time=False)
    # Add padding for a thread info that is of length 4
    thread_info_padding = self.set_thread_info_padding("1234")
    assert self.thread_info_padding == 4, TEST_MSG.format(4,self.thread_info_padding)
    # Add padding for a thread info that is of length 3
    thread_info_padding = self.set_thread_info_padding("123")
    assert self.thread_info_padding == 4

# Generated at 2022-06-20 12:33:14.481772
# Unit test for method write of class FileWriter
def test_FileWriter_write():
    with utils.temp_folder() as temp_folder:
        file_writer = FileWriter(os.path.join(temp_folder, '.watch.txt'),
                                 overwrite=False)
        file_writer.write('Hello, world!')
        file_writer.write('Hello, world!')  # Shouldn't duplicate.
    with open(os.path.join(temp_folder, '.watch.txt')) as f:
        assert f.read() == 'Hello, world!'
    with utils.temp_folder() as temp_folder:
        file_writer = FileWriter(os.path.join(temp_folder, '.watch.txt'),
                                 overwrite=False)
        file_writer.write('Hello, world!')
        file_writer.write('Hello, world!')  # Should duplicate.

# Generated at 2022-06-20 12:33:17.009448
# Unit test for function get_path_and_source_from_frame
def test_get_path_and_source_from_frame():
    def func(): pass
    _, source = get_path_and_source_from_frame(func.__code__.co_firstlineno)
    source = source[0]
    assert 'func()' in source



# Generated at 2022-06-20 12:33:23.913977
# Unit test for method __enter__ of class Tracer
def test_Tracer___enter__():
    import pytest
    import pysnooper

    with pytest.raises(NotImplementedError, match='normalize is not supported with thread_info'):
        pysnooper.snoop(normalize=True, thread_info=True)

if __name__ == '__main__':
    import sys
    from . import _test
    [test_name] = sys.argv[1:]
    module = sys.modules[__name__]
    func = getattr(module, 'test_' + test_name)
    func()

# Generated at 2022-06-20 12:33:34.354600
# Unit test for constructor of class Tracer
def test_Tracer():
    assert 'watch' in inspect.getargspec(Tracer.__init__).args
    assert 'watch_explode' in inspect.getargspec(Tracer.__init__).args
    assert 'custom_repr' in inspect.getargspec(Tracer.__init__).args
    assert 'max_variable_length' in inspect.getargspec(Tracer.__init__).args
    assert inspect.isclass(Tracer)
    s = Tracer(output=sys.stdout)
    assert inspect.ismethod(s.__enter__)
    assert inspect.ismethod(s.__exit__)
    assert inspect.ismethod(s.trace)
    assert inspect.ismethod(s._wrap_function)
    assert inspect.ismethod(s._wrap_class)
    assert inspect.ismethod

# Generated at 2022-06-20 12:33:36.825744
# Unit test for constructor of class Tracer
def test_Tracer():
    output = io.StringIO()
    with pycompat.suppress(AttributeError):
        output.buffer = output
    assert Tracer(output)._write(b'x')

# Generated at 2022-06-20 12:34:44.179679
# Unit test for method trace of class Tracer

# Generated at 2022-06-20 12:34:52.552621
# Unit test for method __exit__ of class Tracer
def test_Tracer___exit__():
    class MockTracer:
        def __init__(self):
            self.exc_type = None
            self.exc_value = None
            self.exc_traceback = None
            self.call_args_list = []

        def __enter__(self):
            pass

        def __exit__(self, exc_type, exc_value, exc_traceback):
            self.exc_type = exc_type
            self.exc_value = exc_value
            self.exc_traceback = exc_traceback
            self.call_args_list.append((exc_type, exc_value, exc_traceback))
    # An exception gets raised in the `with` context
    tracer = MockTracer()
    def test_code():
        with tracer:
            raise RuntimeError('Boom!')
    test_code()

# Generated at 2022-06-20 12:34:57.928512
# Unit test for method set_thread_info_padding of class Tracer
def test_Tracer_set_thread_info_padding():
    import unittest
    # Case 1
    tracer = Tracer(thread_info=True)
    thread_info = "123"
    thread_info_padding = 0
    thread_info = tracer.set_thread_info_padding(thread_info)
    assert thread_info == "123     "
    return thread_info_padding == tracer.thread_info_padding

    # Case 2
    tracer = Tracer(thread_info=True)
    thread_info = "123"
    thread_info_padding = 5
    thread_info = tracer.set_thread_info_padding(thread_info)
    assert thread_info == "123"
    return thread_info_padding == tracer.thread_info_padding
test_Tracer_set_thread_info_padding()
