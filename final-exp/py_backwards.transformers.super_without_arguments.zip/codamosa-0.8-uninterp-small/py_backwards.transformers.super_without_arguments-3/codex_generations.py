

# Generated at 2022-06-25 22:42:03.680483
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    ast_0 = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(ast_0)
    module_0.Call()
    super_without_arguments_transformer.visit_Call()


# Generated at 2022-06-25 22:42:09.483427
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    s_t_r_0 = module_0.Str()
    try:
        super_without_arguments_transformer_0.visit_Call(s_t_r_0)
    except Exception:
        pass



# Generated at 2022-06-25 22:42:11.604529
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(tree)
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-25 22:42:13.907775
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    assert(isinstance(super_without_arguments_transformer_0, module_0.AST))


# Generated at 2022-06-25 22:42:17.409454
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:42:21.396875
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = module_0.Name()
    super_without_arguments_transformer_0.visit_Call(a_s_t_1)

# Generated at 2022-06-25 22:42:23.150824
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:42:25.734563
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("Testing constructor of class SuperWithoutArgumentsTransformer")
    test_case_0()
    print(" Done!")

# Unit testing the class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:42:28.362169
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(SuperWithoutArgumentsTransformer(a_s_t_0), SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:42:31.057637
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:36.239820
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_SuperWithoutArgumentsTransformer_0 = SuperWithoutArgumentsTransformer("0", "1", "2", "3")
    assert a_SuperWithoutArgumentsTransformer_0.target == (2, 7)


# Generated at 2022-06-25 22:42:37.496387
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_SuperWithoutArgumentsTransformer_0 = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-25 22:42:41.001013
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = """super()"""
    tree = typed_ast.ast3.parse(source, mode='exec')
    tree_changed, node_paths = SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_changed == True
    assert node_paths == set()

# Generated at 2022-06-25 22:42:42.290870
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()


# Generated at 2022-06-25 22:42:52.050584
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.Call(func=module_0.Name(id='super', ctx=module_0.Load()), args=[], keywords=[], starargs=None, kwargs=None)
    a_s_t_1 = module_0.AST()
    # FunctionDef(name='main', args=arguments(args=[arg(arg='arg', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))], decorator_list=[])

# Generated at 2022-06-25 22:42:54.265717
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  a_s_t_0 = module_0.AST()
  transformer = SuperWithoutArgumentsTransformer(a_s_t_0)
  return transformer


# Generated at 2022-06-25 22:42:55.942495
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    SuperWithoutArgumentsTransformer().visit_Call(module_0.Call())

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:42:58.031914
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# eof

# Generated at 2022-06-25 22:43:07.597049
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.AST()
    a_s_t_2 = module_0.AST()
    a_s_t_3 = module_0.AST()
    a_s_t_4 = module_0.AST()
    a_s_t_5 = module_0.AST()
    a_s_t_6 = module_0.AST()
    a_s_t_7 = module_0.AST()
    a_s_t_8 = module_0.AST()
    a_s_t_9 = module_0.AST()
    a_s_t_10 = module_0.AST()
    a_s_t_11 = module_0.AST()
    a_s_t_

# Generated at 2022-06-25 22:43:09.955073
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except Exception:
        assert False


if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:43:18.519540
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    # Instantiate enclosing class
    a_s_t_2 = SuperWithoutArgumentsTransformer()

    # Prepare node to test
    node = module_0.Call()

    # Execute test function
    result = a_s_t_2.visit_Call(node)


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 22:43:28.368559
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    a_s_t_0 = module_0.AST()
    module_0.fix_missing_locations(a_s_t_0)
    a_s_t_2 = module_0.Module([], None)
    module_0.fix_missing_locations(a_s_t_2)
    a_s_t_2.body.append(a_s_t_0)
    a_s_t_0.body.append(module_0.FunctionDef('meth', module_0.arguments([module_0.arg('self', None)], None, [], [], None, []), [module_0.Expr(module_0.Call(module_0.Name('super', module_0.Load()), [], []))], [], None))


    # Test for class constructor
    t

# Generated at 2022-06-25 22:43:29.499837
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    i_s_t_0 = module_0.AST()


# Generated at 2022-06-25 22:43:32.717819
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    _cls_0 = SuperWithoutArgumentsTransformer()

    # Check for instance attributes
    assert hasattr(_cls_0, '_tree')
    assert hasattr(_cls_0, '_tree_changed')
    assert hasattr(_cls_0, 'target')




# Generated at 2022-06-25 22:43:41.763283
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    source_0 = "super()"
    tree_0 = ast.parse(source_0)
    transformer_0 = SuperWithoutArgumentsTransformer()
    try:
        for _ in range(100):
            new_tree_0 = transformer_0.visit(tree_0)
    except Exception as e:
        out_0 = None
        assert None == out_0
    else:
        out_0 = new_tree_0.body[0].value.args[0].id
        assert "Cls" == out_0

# Generated at 2022-06-25 22:43:44.212588
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()

#unittest.main()
from testing.test import test
test(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-25 22:43:47.480162
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Assert AssertionError if constructor raises AssertionError for parameter target
    try:
        test_case_0()
    except AssertionError:
        pass
    else:
        raise AssertionError('AssertionError not raised')
    

# Generated at 2022-06-25 22:43:49.013246
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test = SuperWithoutArgumentsTransformer()
    test_case_0()


# Generated at 2022-06-25 22:43:49.505548
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:43:51.693703
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = module_0.AST()
    T = SuperWithoutArgumentsTransformer(node)
    assert T


# Generated at 2022-06-25 22:43:58.163246
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert(isinstance(call_1, module_0.Call))

# Generated at 2022-06-25 22:44:04.954205
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    
    assert super_without_arguments_transformer_0.visit_Call(call_0) == call_0
    assert super_without_arguments_transformer_0._tree is a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed is False

# Generated at 2022-06-25 22:44:13.157223
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # 1st use case: If node.func is not of type ast.Name and node.func.id != 'super' and len(node.args) != 0:
    # Expected outcome: call_1 == call_0
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 == call_0
    # 2nd use case: If node.func is of type ast.Name and node.func.id != 'super' and len(node.args) == 0:
    # Expected outcome: call_1 == call_0


# Generated at 2022-06-25 22:44:20.422118
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None
    assert super_without_arguments_transformer_0.target is not None
    assert super_without_arguments_transformer_0._tree is not None
    assert super_without_arguments_transformer_0._tree_changed is not None, '_tree_changed'
    assert super_without_arguments_transformer_0.visit_Call(call_0) is not None


# Generated at 2022-06-25 22:44:21.338093
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:44:25.262891
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:44:32.937943
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Create an instance of Call
    call_18 = module_0.Call()

    # Create an instance of AST
    a_s_t_0 = module_0.AST()

    # Create an instance of SuperWithoutArgumentsTransformer
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    # Call method visit_Call of SuperWithoutArgumentsTransformer
    call_24 = super_without_arguments_transformer_0.visit_Call(call_18)

    # Assert that the type of call_24 is Call
    assert(type(call_24) == module_0.Call)

# Generated at 2022-06-25 22:44:35.006788
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:44:38.947229
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 22:44:42.651400
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:48.451759
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # TODO: Check if this is a test
    assert False


# Generated at 2022-06-25 22:44:52.312605
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:55.883261
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:59.570846
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:00.384808
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:45:04.704413
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:45:10.956572
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Creating a new ast
    _ast = module_0.AST()

    # Testing if the ast created is valid
    assert(_ast is not None), "Invalid ast"

    # Creating a new SuperWithoutArgumentsTransformer passing the previous ast as a parameter
    _SuperWithoutArgumentsTransformer = SuperWithoutArgumentsTransformer(_ast)

    # Testing if the SuperWithoutArgumentsTransformer created is valid
    assert(_SuperWithoutArgumentsTransformer is not None), "Invalid SuperWithoutArgumentsTransformer"



# Generated at 2022-06-25 22:45:13.897481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None

# Generated at 2022-06-25 22:45:16.279525
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:17.710947
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = SuperWithoutArgumentsTransformer(ast.AST())

test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:45:29.798156
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:31.335039
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # test all combinations of actual parameters
    test_case_0()
    print('done test_SuperWithoutArgumentsTransformer_visit_Call')


# Generated at 2022-06-25 22:45:35.671763
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:38.879853
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    

# Generated at 2022-06-25 22:45:42.591719
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:45:51.012721
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    super_without_arguments_transformer_0.generic_visit(call_0)
    super_without_arguments_transformer_1.generic_visit(call_0)


# Generated at 2022-06-25 22:45:55.299290
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:01.555821
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:05.568210
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    the_tree_0 = module_0.AST()
    super_without_arguments_transformer_12 = SuperWithoutArgumentsTransformer(the_tree_0)
    module_0.dump(super_without_arguments_transformer_12._tree)
    module_0.dump(super_without_arguments_transformer_12._changed)

# Generated at 2022-06-25 22:46:07.038466
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:46:33.343061
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        assert callable(SuperWithoutArgumentsTransformer.visit_Call)
    except:
        print('Method visit_Call of class SuperWithoutArgumentsTransformer is not callable')
    try:
        call_0 = Call()
        a_s_t_0 = AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
        call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    except:
        print('Method visit_Call of class SuperWithoutArgumentsTransformer is not callable via an instance')


# Generated at 2022-06-25 22:46:41.219364
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:46:47.266495
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer.__name__ == 'SuperWithoutArgumentsTransformer'
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

if __name__ == '__main__':
    import sys
    sys.exit(pytest.main(["-v", "-s", __file__]))

# Generated at 2022-06-25 22:46:51.151412
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:54.853019
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = module_0.Call()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(module_0.AST())
    super_without_arguments_transformer.visit_Call(node)
    assert module_0.Call() == node

# Generated at 2022-06-25 22:46:59.351691
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 == call_0

# Generated at 2022-06-25 22:47:02.815241
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0


# Generated at 2022-06-25 22:47:03.375748
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-25 22:47:06.779791
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:47:11.042703
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert type(call_1) is module_0.Call

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:48:00.178532
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class_ = SuperWithoutArgumentsTransformer
    method = SuperWithoutArgumentsTransformer.visit_Call
    assert class_ is not None
    assert method is not None
    assert callable(method)

# Generated at 2022-06-25 22:48:01.019759
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:48:04.991319
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_2 = module_0.Call()
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)
    assert call_3 is None

# Generated at 2022-06-25 22:48:08.943688
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_0.tree_changed

# Generated at 2022-06-25 22:48:12.481433
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree is a_s_t_0
    


# Generated at 2022-06-25 22:48:18.513861
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test for SuperWithoutArgumentsTransformer"""

    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as _ast
    from .super_without_arguments import SuperWithoutArgumentsTransformer

    from .base import BaseNodeTransformer

    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer

    a_s_t_0 = _ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:22.069665
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:48:23.987499
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:25.738523
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # TODO: Fix this unit test
    assert False, 'Test not yet implemented'

# Generated at 2022-06-25 22:48:30.381134
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert isinstance(super_without_arguments_transformer_1, SuperWithoutArgumentsTransformer)
    assert isinstance(super_without_arguments_transformer_1, module_0.NodeTransformer)
    assert isinstance(super_without_arguments_transformer_1, module_0.NodeVisitor)


# Generated at 2022-06-25 22:50:14.472442
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0(call_0, super_without_arguments_transformer_0)

test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:50:16.398534
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print('test_SuperWithoutArgumentsTransformer')
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:19.116723
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:50:23.868234
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    call_0 = ast.Call()
    a_s_t_0 = ast.Module()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    # Test condition where `super_without_arguments_transformer_0._tree_changed` is False
    if not super_without_arguments_transformer_0._tree_changed:
        pass

# Generated at 2022-06-25 22:50:27.006837
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:50:28.295448
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    s_w_a_t_0 = SuperWithoutArgumentsTransformer(tree_0)

# Generated at 2022-06-25 22:50:38.672246
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 is not call_0
    assert isinstance(call_1, module_0.Call)
    assert call_1.args == []
    assert call_1.func is None
    assert call_1.keywords == []
    assert call_1.starargs is None
    assert call_1.kwargs is None
    assert not call_1.col_offset
    assert not call_1.lineno


# Generated at 2022-06-25 22:50:42.532564
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Create an instance of class SuperWithoutArgumentsTransformer
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Compare result of method super_without_arguments_transformer_0.visit_Call to computed value
    assert call_1 == super_without_arguments_transformer_0.visit_Call(call_0), "Computed value does not match expected value"

# Generated at 2022-06-25 22:50:45.585764
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0 # type: ignore
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:50:46.437814
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print(SuperWithoutArgumentsTransformer)