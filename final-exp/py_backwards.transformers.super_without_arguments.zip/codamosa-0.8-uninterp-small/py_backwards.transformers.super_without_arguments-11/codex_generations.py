

# Generated at 2022-06-25 22:42:11.959379
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = ast.parse("")
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    super_without_arguments_transformer_1.visit(a_s_t_1)
    a_s_t_2 = ast.parse("super(Cls, self)")
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)
    super_without_arguments_transformer_2.visit(a_s_t_2)
    a_s_t_3 = ast.parse("super(Cls, cls)")
    super_without_arguments_transformer_3 = SuperWithoutArgumentsTransformer(a_s_t_3)
    super

# Generated at 2022-06-25 22:42:20.505250
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_0 = ast.Call()
    super_without_arguments_transformer_0.visit_Call(a_s_t_0)
    assert(super_without_arguments_transformer_0._tree_changed == True)
    super_without_arguments_transformer_0._tree_changed = False
    a_s_t_0 = ast.Subscript()
    super_without_arguments_transformer_0.visit_Call(a_s_t_0)
    assert(super_without_arguments_transformer_0._tree_changed == False)

test_case_0()
test_SuperWithoutArg

# Generated at 2022-06-25 22:42:30.523204
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    cls_0 = None
    func_1 = None
    call_2 = None
    super_without_arguments_transformer_0._replace_super_args(call_2)
    a_s_t_3 = None
    super_without_arguments_transformer_0.generic_visit(a_s_t_3)
    call_3 = None
    name_3 = None
    name_3_id_3 = None
    name_3 = ast.Name(id=name_3_id_3)

    name_2 = None
    name_2_id_2 = None

# Generated at 2022-06-25 22:42:34.119432
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)



# Generated at 2022-06-25 22:42:39.105469
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = None

    # Testing constructor
    try:
        assert SuperWithoutArgumentsTransformer(a_s_t_1)
        super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    except BaseException as throws:
        assert False

    # Testing visit_Call method
    try:
        super_without_arguments_transformer_1.visit_Call("test_string")
    except BaseException as throws:
        assert type(throws) == TypeError
    else:
        assert False

# Generated at 2022-06-25 22:42:41.539275
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    asser

# Generated at 2022-06-25 22:42:43.929727
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a = None
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(a)
    assert super_without_arguments_transformer


# Generated at 2022-06-25 22:42:45.962503
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    assert SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:48.426370
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(None)
    super_without_arguments_transformer_1._replace_super_args(None)


# Generated at 2022-06-25 22:42:57.590455
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = ast.Call(args=None, args=(), func=ast.Name(ctx=None, id='super'), func=ast.Name(ctx=None, id='super'), keywords=[], keywords=[], starargs=None, starargs=None)
    a_s_t_1 = super_without_arguments_transformer_0.visit_Call(a_s_t_1)
    assert a_s_t_1.__class__.__name__ == "Call"
    assert len(a_s_t_1.args) == 2
    assert a_s_t_1.args[0].__class__.__name

# Generated at 2022-06-25 22:43:07.892901
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = ast.parse('class MyClass:\n'
                        '    def method(self):\n'
                        '        super()')
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    super_without_arguments_transformer_1.visit(a_s_t_1)
    assert ast.dump(a_s_t_1) == ast.dump(ast.parse('class MyClass:\n'
                                        '    def method(self):\n'
                                        '        super(MyClass, self)'))

# Generated at 2022-06-25 22:43:14.520751
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    f_l_1 = ast.parse('class Foo(object):\n    def __init__(self):\n        self.a = 5\n\n    def bar(self):\n        super()')

    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(f_l_1)

    super_without_arguments_transformer_2.visit(f_l_1)

    assert str(f_l_1) == 'class Foo(object):\n    def __init__(self):\n        self.a = 5\n\n    def bar(self):\n        super(Foo, self)'

# Generated at 2022-06-25 22:43:19.041588
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)



# Generated at 2022-06-25 22:43:20.236863
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:43:22.151879
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 22:43:25.528904
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_r_0 = None
    super_without_arguments_transformer_r_0 = SuperWithoutArgumentsTransformer(a_s_t_r_0)

    assert super_without_arguments_transformer_r_0 is not None


# Generated at 2022-06-25 22:43:28.020040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:43:31.955000
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Call method visit_Call
    a_s_t_0 = None
    super_without_arguments_transformer_0.visit_Call(a_s_t_0)



# Generated at 2022-06-25 22:43:38.262440
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Create class
    # Instance created before __init__ is run
    # __init__ called after __new__
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # __init__ called after __new__


# Generated at 2022-06-25 22:43:40.565975
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:52.424527
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    # assert super_without_arguments_transformer_0.visit_Call(a_s_t_0.Call)
# Unit tests for instance method of SuperWithoutArgumentsTransformer -- visit_Call


# Unit tests for instance method of SuperWithoutArgumentsTransformer -- visit_Call

if __name__ == '__main__':
    test_case_0()
    test_SuperWithoutArgumentsTransformer()
    test_visit_Call()

# Generated at 2022-06-25 22:43:54.490402
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:57.472768
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)



# Generated at 2022-06-25 22:43:59.538467
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:02.910137
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:03.449603
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass # TODO

# Generated at 2022-06-25 22:44:05.748967
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Unit test 3 for test_case_0

# Generated at 2022-06-25 22:44:07.792202
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:10.075938
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:12.214105
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:16.633479
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(ast.parse('pass'))
    assert repr(super_without_arguments_transformer) == '<SuperWithoutArgumentsTransformer>'


# Generated at 2022-06-25 22:44:17.453577
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# unit tests for __init__

# Generated at 2022-06-25 22:44:17.799175
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:44:20.098497
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    assert isinstance(super_without_arguments_transformer_0._tree, module_0.Module)


# Generated at 2022-06-25 22:44:20.918629
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:44:21.806372
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True


# Generated at 2022-06-25 22:44:24.134447
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()
    print('Unit test for constructor of class SuperWithoutArgumentsTransformer passed')

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:44:25.225355
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:44:28.758315
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Check if the super constructor returns a SuperWithoutArgumentsTransformer object
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:44:31.885345
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0.parse('class MyClass:\n    def method(self):\n        super()'))


# Generated at 2022-06-25 22:44:39.194817
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0.parse('class MyClass:\n    def method(self):\n        super()'))
    assert(isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer))
    test_case_0()


if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:44:40.680174
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)


# Generated at 2022-06-25 22:44:43.631066
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:44:51.524344
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_0 = module_0.ClassDef(name='MyClass', bases=[], keywords=[], body=[module_0.FunctionDef(name='method', args=module_0.arguments(args=[module_0.arg('self', None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Call(func=module_0.Name(id='super', ctx=module_0.Load()), args=[], keywords=[], starargs=None, kwargs=None))], decorator_list=[], returns=None)], decorator_list=[], keywords=[])
    module_0.fix_missing_locations(class_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTrans

# Generated at 2022-06-25 22:44:54.542721
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:44:56.800336
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0.parse('class MyClass:\n    def method(self):\n        super()'))


# Generated at 2022-06-25 22:45:00.843006
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    var_1 = super_without_arguments_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:45:05.120756
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:45:09.167111
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:45:11.262893
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    

# Generated at 2022-06-25 22:45:19.083461
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(None)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:45:21.294012
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = SuperWithoutArgumentsTransformer(module_0.If(test=module_0.Name(id='True'), body=[], orelse=[]))
    assert var_0 != None


# Generated at 2022-06-25 22:45:23.729494
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(None)
    except Exception as e:
        var_0 = True
    assert var_0


# Generated at 2022-06-25 22:45:29.149694
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    str_1 = 'class MyClass:\n    def method(self):\n        super(MyClass, self)'
    var_1 = module_0.parse(str_1)
    assert super_without_arguments_transformer_0.visit(var_0) == var_1
    pass

# Generated at 2022-06-25 22:45:31.586315
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)

# Generated at 2022-06-25 22:45:33.076558
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True == True, 'test_SuperWithoutArgumentsTransformer'


# Generated at 2022-06-25 22:45:34.012891
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()



# Generated at 2022-06-25 22:45:36.643862
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test constructor of class SuperWithoutArgumentsTransformer."""
    class_0 = SuperWithoutArgumentsTransformer
    node_0 = None
    var_0 = class_0(node_0)

# Generated at 2022-06-25 22:45:37.933030
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 22:45:42.176575
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('class MyClass:\n    def method(self):\n        super()')
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(tree)
    assert(isinstance(super_without_arguments_transformer_1, SuperWithoutArgumentsTransformer))

# Unittest for visit_Call

# Generated at 2022-06-25 22:45:48.892540
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except Exception:
        assert False


# Generated at 2022-06-25 22:45:52.693124
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:45:59.656412
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.parse('None')
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:46:01.661748
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0.Module([], []))


# Generated at 2022-06-25 22:46:05.165713
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_1 = 'class MyClass:\n    def method(self):\n        super()'
    py_0 = module_0.parse(str_1)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(py_0)

# Generated at 2022-06-25 22:46:13.451596
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.parse('class MyClass:\n    def method(self):\n        super()')
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    var_1 = super_without_arguments_transformer_0.visit(var_0)

if __name__ == '__main__':
    import pprint
    import typed_ast.ast3 as module_0
    var_0 = module_0.parse('class MyClass:\n    def method(self):\n        super()')
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    var_1 = super_without_arguments_transformer_0.visit(var_0)
    pprint.pprint(var_1)

# Generated at 2022-06-25 22:46:14.218649
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:46:17.405447
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:46:21.425101
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)

# Generated at 2022-06-25 22:46:22.202788
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:46:36.343634
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_2 = 'class MyClass:\n    def method(self):\n        super()'
    var_2 = module_0.parse(str_2)
    var_3 = SuperWithoutArgumentsTransformer(var_2)
    print(var_3.visit(var_2))


# Generated at 2022-06-25 22:46:40.286634
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    var_1 = super_without_arguments_transformer_0.visit(var_0)

# Generated at 2022-06-25 22:46:44.620418
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    test_case_0()
    test_SuperWithoutArgumentsTransformer0()


# Generated at 2022-06-25 22:46:45.409441
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert isinstance(SuperWithoutArgumentsTransformer, type)

# Generated at 2022-06-25 22:46:48.589490
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(var_0)
    assert True

# Generated at 2022-06-25 22:46:51.970849
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_1 = module_0.parse('class MyClass:\n    def method(self):\n        super()')
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(
        var_1)
    super_without_arguments_transformer_0.visit(var_1)


# Generated at 2022-06-25 22:46:55.698502
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(str)
    assert super_without_arguments_transformer_1 != None

    # Unit test for SuperWithoutArgumentsTransformer.visit_Call
    test_case_0()

# Generated at 2022-06-25 22:46:56.622419
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True # TODO: implement your test here

# Generated at 2022-06-25 22:47:01.153327
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    var_1 = super_without_arguments_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:47:02.702620
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print('test constructor')
    #test_case_0()
    print('test case 0')

# Generated at 2022-06-25 22:47:28.257678
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:47:32.784329
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    assert super_without_arguments_transformer_0._tree == var_0
    super_without_arguments_transformer_0.visit(var_0)
    assert super_without_arguments_transformer_0._tree_changed == True

# Generated at 2022-06-25 22:47:34.719243
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test exception case
    try:
        sup = SuperWithoutArgumentsTransformer(None)
    except:
        # Exception raised, test case passed
        pass


# Generated at 2022-06-25 22:47:39.775836
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_0 = SuperWithoutArgumentsTransformer(module_0.parse(''))
    assert isinstance(class_0.name, str)
    str_0 = 'print(1)'
    str_1 = 'print(1)'
    assert class_0.visit(module_0.parse(str_0)) == module_0.parse(str_1)
    assert class_0.visit(module_0.parse(str_1)) == module_0.parse(str_1)


# Generated at 2022-06-25 22:47:43.193976
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_4 = module_0.parse('class MyClass:\n    def method(self):\n        super()')
    var_5 = SuperWithoutArgumentsTransformer(var_4)
    var_5.visit(var_4)


# Generated at 2022-06-25 22:47:43.851806
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:47:47.163639
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert super_without_arguments_transformer_0._tree_changed is False

# Generated at 2022-06-25 22:47:50.670957
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:47:51.310965
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:47:55.844283
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert callable(SuperWithoutArgumentsTransformer), "['__init__', 'visit_Attribute', 'visit_Assign', 'visit_Dict', 'visit_For', 'visit_FunctionDef', 'visit_If', 'visit_List', 'visit_Module', 'visit_Name', 'visit_Return', 'visit_Tuple', 'visit_While']"



# Generated at 2022-06-25 22:48:51.949274
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    var_1 = super_without_arguments_transformer_0.visit(var_0)


# Generated at 2022-06-25 22:48:52.637689
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:48:53.562004
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = SuperWithoutArgumentsTransformer(None)


# Generated at 2022-06-25 22:48:54.023372
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:48:55.480647
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_2 = 'class MyClass:\n    def method(self):\n        super()'
    test_case_0()


# Generated at 2022-06-25 22:48:57.123547
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer(ast.parse(''))
    assert isinstance(t, BaseNodeTransformer)


# Generated at 2022-06-25 22:49:00.823728
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 22:49:02.020522
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:49:03.008176
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:49:04.644157
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0.parse)


# Generated at 2022-06-25 22:51:26.986012
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(None)


# Generated at 2022-06-25 22:51:28.473229
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.parse('super()')
    var_1 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:51:29.116553
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:51:29.756243
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:51:30.616681
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = SuperWithoutArgumentsTransformer(None)


# Generated at 2022-06-25 22:51:34.803337
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:51:39.265658
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 =  module_0.parse('class MyClass:\n    def method(self):\n        super()')

    # unit test for method visit_Call
    def test_method_visit_Call():
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
        var_1 = super_without_arguments_transformer_0.visit_Call(var_0)

# Generated at 2022-06-25 22:51:40.814619
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(None)
    print(super_without_arguments_transformer_0)


# Generated at 2022-06-25 22:51:42.929778
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    with pytest.raises(TypeError):
        var_0 = module_0.parse('')
        var_1 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:51:50.163928
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = 'class MyClass:\n    def method(self):\n        super()'
    var_0 = module_0.parse(str_0)
    var_1 = ast.parse(str_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_1)
    try:
        super_without_arguments_transformer_0.visit(var_0)
    except Exception as var_2:
        var_3 = super_without_arguments_transformer_0._tree_changed
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(var_0)
    super_without_arguments_transformer_1.visit(var_0)