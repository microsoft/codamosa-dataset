

# Generated at 2022-06-25 22:42:04.011881
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    node_0 = module_0.Call('super', [])
    node_1 = super_without_arguments_transformer_0.visit_Call(node_0)
    assert(node_1 == node_0)


# Generated at 2022-06-25 22:42:10.076971
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()
    a_s_t_0 = module_0.AST()
    name_0 = module_0.Name()
    call_0 = module_0.Call(func=name_0, args=[])
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

    assert call_1 is call_0


# Generated at 2022-06-25 22:42:13.633047
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = module_0.Call()
    super_without_arguments_transformer_0.visit_Call(a_s_t_1)

# Generated at 2022-06-25 22:42:20.946700
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not super_without_arguments_transformer_1
    assert super_without_arguments_transformer_0.__class__ is super_without_arguments_transformer_1.__class__
    assert super_without_arguments_transformer_0.tree is super_without_arguments_transformer_1.tree


# Generated at 2022-06-25 22:42:28.811234
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call(
        func=module_0.Name(id='super'),
        args=[],
        keywords=[],
        starargs=None,
        kwarargs=None,
    )
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_0.func.id == 'super', 'Should be {}'.format('super')

# Generated at 2022-06-25 22:42:36.334340
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Construct instance of class SuperWithoutArgumentsTransformer
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Check constructor, attributes and types of nodes
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert isinstance(super_without_arguments_transformer_0.target, tuple)
    assert super_without_arguments_transformer_0.tree == a_s_t_0
    assert isinstance(super_without_arguments_transformer_0.tree, module_0.AST)


# Generated at 2022-06-25 22:42:45.303487
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    try:
        super_without_arguments_transformer_0.visit_Name(a_s_t_0.Name(id='A'))
    except Exception as e:
        raise e
    try:
        super_without_arguments_transformer_0.visit(a_s_t_0.Name(id='A'))
    except Exception as e:
        raise e
    try:
        super_without_arguments_transformer_0.generic_visit(a_s_t_0.Name(id='A'))
    except Exception as e:
        raise e

# Generated at 2022-06-25 22:42:48.359934
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()

test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:42:57.563358
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.generic_visit(module_0.AST())
    super_without_arguments_transformer_0.visit(module_0.AST())
    super_without_arguments_transformer_0.visit_alias(module_0.alias())
    super_without_arguments_transformer_0.visit_arg(module_0.arg())
    super_without_arguments_transformer_0.visit_arguments(module_0.arguments())
    super_without_arguments_transformer_0.visit_Assert(module_0.Assert())
    super

# Generated at 2022-06-25 22:42:58.693514
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    """
    Test for class SuperWithoutArgumentsTransformer
    """
    
    pass

# Generated at 2022-06-25 22:43:04.568174
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = '\n    Test for class SuperWithoutArgumentsTransformer\n    '


# Generated at 2022-06-25 22:43:09.237624
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = '\n    Test for class SuperWithoutArgumentsTransformer\n    '
    str_1 = '\n    Test for class SuperWithoutArgumentsTransformer\n    '
    str_2 = '\n    Test for class SuperWithoutArgumentsTransformer\n    '


# Generated at 2022-06-25 22:43:20.136164
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import os
    import sys
    import ast
    import astunparse
    import inspect
    import unittest
    from ast import parse
    from textwrap import dedent
    from typed_ast import ast3 as typed_ast
    from typed_ast import ast27 as typed_ast
    from typed_ast import ast35 as typed_ast

    from typed_ast.transforms.bases.node_transformer import BaseNodeTransformer

    from typed_ast.transforms.super_without_arguments import SuperWithoutArgumentsTransformer

    def test_case_0():
        str_0 = '\n    Test for class SuperWithoutArgumentsTransformer\n    '

    class UnitTestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def setUp(self):
            self.transformer = SuperWithoutArgumentsTransformer

       

# Generated at 2022-06-25 22:43:22.415816
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer._ID_GEN is 0
    assert SuperWithoutArgumentsTransformer.target == (2, 7)


# Generated at 2022-06-25 22:43:24.113935
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = '\n    Test for class SuperWithoutArgumentsTransformer\n    '


# Generated at 2022-06-25 22:43:26.684302
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_code = 'class A:\n    def __init__(self):\n        super()\n        '
    SuperWithoutArgumentsTransformer(test_code).result()


# Generated at 2022-06-25 22:43:27.862669
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert True


# Generated at 2022-06-25 22:43:30.890351
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        assert test_case_0() == None , 'expect none'
        assert True
    except AssertionError as e:
        print('Fail', e)

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:43:43.051565
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_0 = '\n    Test for class SuperWithoutArgumentsTransformer\n    '
    str_1 = 'super()'
    str_2 = 'super(Cls, self.attr)'
    str_3 = 'TestCls'
    str_4 = 'test_meth'
    node_0 = ast.parse(str_1)
    node_1 = node_0.body[0]
    assert isinstance(node_1, ast.Expr)
    node_2 = node_1.value
    assert isinstance(node_2, ast.Call)
    node_3 = node_2.func
    assert isinstance(node_3, ast.Name)
    node_4 = node_3.id
    assert isinstance(node_4, str)
    assert node_4 == 'super'
   

# Generated at 2022-06-25 22:43:44.953069
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    str_1 = '\n    Test for class SuperWithoutArgumentsTransformer\n    '


# Generated at 2022-06-25 22:43:52.700508
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:57.241398
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # assert call_1 == super_without_arguments_transformer_0.visit_Call(call_0)
    # assert False # TODO: create a test case for the above two lines

# Generated at 2022-06-25 22:43:59.311445
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = SuperWithoutArgumentsTransformer(module_0.AST())
    assert isinstance(module_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:44:03.319446
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-25 22:44:06.950866
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    func_0 = module_0.FunctionDef()
    super_without_arguments_transformer_0._transform_super_args(func_0)

# Generated at 2022-06-25 22:44:09.336976
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:13.341109
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:44:17.269305
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:18.767009
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


test_cases = [
    test_case_0,
]


# Generated at 2022-06-25 22:44:22.283275
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert type(super_without_arguments_transformer_0) == SuperWithoutArgumentsTransformer


# Generated at 2022-06-25 22:44:28.632075
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0

# Generated at 2022-06-25 22:44:29.444587
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()



# Generated at 2022-06-25 22:44:33.849411
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:37.435038
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:44.135523
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # call_0 = module_0.Call()

    tree = ast.parse(
    '''
    class A:
        def __init__(self):
            super()
    ''')

    SuperWithoutArgumentsTransformer(tree).run()
    print(ast.dump(tree))


    # a_s_t_0 = module_0.AST()
    # super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


    # assert call_1 == call_0

# Generated at 2022-06-25 22:44:47.302883
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert type(super_without_arguments_transformer_0) == SuperWithoutArgumentsTransformer
    pass


# Generated at 2022-06-25 22:44:52.568008
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    print("Type of output:", type(call_1))
    print("Output:", call_1)
    assert call_1 is call_0


# Generated at 2022-06-25 22:44:53.453229
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True == True

# Generated at 2022-06-25 22:44:54.836679
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    o = SuperWithoutArgumentsTransformer(None)
    assert o.target == (2, 7)

# Generated at 2022-06-25 22:44:58.404688
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:10.125731
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_1 = module_0.Call()
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert not a_s_t_1.walk_tree(call_1, super_without_arguments_transformer_1)


# Generated at 2022-06-25 22:45:14.270573
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # parameters
    a_s_t_0 = module_0.AST()

    # test constructor
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:16.629666
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:17.480378
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:45:20.197196
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:45:23.466649
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    expected_0 = None
    expected_1 = None
    expected_2 = True
    
    assert SuperWithoutArgumentsTransformer() == expected_0
    assert SuperWithoutArgumentsTransformer().target == expected_1
    assert SuperWithoutArgumentsTransformer()._tree_changed == expected_2


# Generated at 2022-06-25 22:45:27.827046
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = __import__('typed_ast._ast3', fromlist=['AST', 'Call'])
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(hasattr(super_without_arguments_transformer_0, "_root"))


# Generated at 2022-06-25 22:45:29.638778
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0.AST()
    a_s_t_0 = SuperWithoutArgumentsTransformer(module_0)
    test_case_0()


# Generated at 2022-06-25 22:45:33.431374
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ast_0 = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(ast_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer.visit_Call(call_0)
    assert call_1.__class__ == module_0.Call

# Generated at 2022-06-25 22:45:34.377704
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:45:51.450500
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert(isinstance(SuperWithoutArgumentsTransformer(module_0.AST()), SuperWithoutArgumentsTransformer))
    try:
        assert(isinstance(SuperWithoutArgumentsTransformer(1), SuperWithoutArgumentsTransformer))
    except AssertionError as e:
        assert True


# Generated at 2022-06-25 22:45:56.772799
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:58.031046
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:46:04.545759
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    expect_1 = call_0
    assert call_1 == expect_1
    assert super_without_arguments_transformer_0.tree_changed == 0

# Generated at 2022-06-25 22:46:09.492336
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Method call doesn't return, so we keep the same type
    assert isinstance(super_without_arguments_transformer_0.visit_Call(call_0), module_0.Call)


# Generated at 2022-06-25 22:46:13.308462
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:46:19.120432
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

if __name__ == '__main__':
    import sys
    if len(sys.argv) == 1:
        import doctest
        doctest.testmod()
    elif len(sys.argv) == 2:
        test_case_0()
    elif len(sys.argv) == 3:
        test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:46:23.620088
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:46:26.159569
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:46:30.012114
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:57.792895
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:47:02.884997
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    """
    pass
    # No unit test required


# Generated at 2022-06-25 22:47:04.323608
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    arg0 = module_0.AST()
    obj0 = SuperWithoutArgumentsTransformer(arg0)


# Generated at 2022-06-25 22:47:07.917998
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    typed_ast.ast3.Call = Call
    typed_ast.ast3.FunctionDef = FunctionDef
    typed_ast.ast3.ClassDef = ClassDef
    
    a_s_t_0 = typed_ast.ast3.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:47:10.053167
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("begin testing SuperWithoutArgumentsTransformer()")
    test_case_0()
    print("finish testing SuperWithoutArgumentsTransformer()")

test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:47:11.303070
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer(module_0.AST()).tree == module_0.AST(), ""


# Generated at 2022-06-25 22:47:15.837905
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert_equals(call_0, call_1)

# Generated at 2022-06-25 22:47:21.408611
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast._ast3 import Call
    from typed_ast import ast3 as ast

    test_source = '''        super()
    '''
    test_tree = ast.parse(test_source)
    test_node = test_tree.body[0].value
    
    assert type(test_node) is Call
    
    SuperWithoutArgumentsTransformer(test_tree).visit(test_tree)
    actual_source = compile(test_tree, '', 'exec')
    

# Generated at 2022-06-25 22:47:24.899548
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:25.600937
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:48:31.499368
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:37.904820
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:48:39.153102
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module_0 = module_0

# Generated at 2022-06-25 22:48:43.446076
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:48:45.120458
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Test cases
    test_case_0()


# Unit tests for class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:48:46.111301
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass 

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:48:51.490896
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)
    assert super_without_arguments_transformer_0 is not None
    assert super_without_arguments_transformer_0._tree == module_0
    assert super_without_arguments_transformer_0._tree_changed == False

if __name__ == '__main__':
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:48:53.253743
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(tree)
    assert super_without_arguments_transformer is not None

# Generated at 2022-06-25 22:48:55.770769
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert super_without_arguments_transformer_0

test_SuperWithoutArgumentsTransformer()
test_case_0()

# Generated at 2022-06-25 22:49:02.441111
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:50:13.430754
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:50:15.641699
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:50:18.317577
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_3 = module_0.Call()
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_4 = super_without_arguments_transformer_1.visit_Call(call_3)

# Generated at 2022-06-25 22:50:22.314550
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer()
    super_without_arguments_transformer_1.visit_Call(call_0)

# Generated at 2022-06-25 22:50:25.197205
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:50:34.778500
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    call_1 = module_0.Call()
    call_1.func = module_0.Name()
    call_1.func.id = str()
    call_1.args = []
    a_s_t_0.body = [call_1]
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_2 = super_without_arguments_transformer_0.visit_Call(call_0)

if __name__ == '__main__':
    test_case_0()
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:50:42.018706
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Sanity check
    if not id(SuperWithoutArgumentsTransformer):
        raise Exception('Could not find SuperWithoutArgumentsTransformer constructor')
    # Test the 2.7-specific assertions
    if SuperWithoutArgumentsTransformer.target:
        # Test the 2.7-specific overrides
        if SuperWithoutArgumentsTransformer.target != (2, 7):
            raise Exception('SuperWithoutArgumentsTransformer.target is not set correctly')
        # Test the 2.7-specific constructor
        if not SuperWithoutArgumentsTransformer(None):
            raise Exception('SuperWithoutArgumentsTransformer missing __init__')
    return True

if __name__ == '__main__':
    # Sanity check
    if not id(ast):
        raise Exception('Could not find ast module')
    # Test the 2.7-specific assertions

# Generated at 2022-06-25 22:50:47.454157
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    module_0.ClassDef()
    module_0.arguments()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(classdef_0)
    assert super_without_arguments_transformer_0.generic_visit(classdef_0) == classdef_0
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:50:51.494479
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert hasattr(call_1, "args") == False
    assert hasattr(call_1, "starargs") == False
    assert hasattr(call_1, "kwargs") == False
    assert hasattr(call_1, "func") == False


# Generated at 2022-06-25 22:50:52.772823
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    name_0 = module_0.Name()
    # Constructor SuperWithoutArgumentsTransformer
    module_0.AST()
