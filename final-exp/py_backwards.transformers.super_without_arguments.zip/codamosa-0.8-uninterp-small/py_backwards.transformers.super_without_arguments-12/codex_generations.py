

# Generated at 2022-06-25 22:42:04.036164
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:12.752808
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef()
    functiondef_0 = module_0.FunctionDef()
    functiondef_0.args.args.append(module_0.arg(arg_0="self"))
    functiondef_0.name = "method"
    classdef_0.name = "Cls"
    call_0 = module_0.Call()
    call_0.func = module_0.Name(id="super")
    try:
        super_without_arguments_transformer_0._replace_super_args(call_0)
    except NodeNotFound:
        pass

# Generated at 2022-06-25 22:42:13.333125
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-25 22:42:17.739350
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.Str()
    a_s_t_0.value = a_s_t_1.s
    if a_s_t_0.value == 'super(Cls, self)':
        raise Exception("Test case failed!")


# Generated at 2022-06-25 22:42:26.739703
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_0 = module_0.AST()
    x_0 = module_0.Name(id='super', ctx=module_0.Load())
    y_0 = module_0.Call(func=x_0)
    super_without_arguments_transformer_1 = super(SuperWithoutArgumentsTransformer, super_without_arguments_transformer_0).visit_Call(y_0)
    assert super_without_arguments_transformer_0 == super_without_arguments_transformer_1


# Generated at 2022-06-25 22:42:29.302789
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:35.609273
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_0 = module_0.Name()
    module_0.Name.id = super_0
    call_1 = module_0.Call()
    module_0.Call.func = call_1
    module_0.Call.args = call_1
    result_0 = super_without_arguments_transformer_0.visit_Call(call_1)


# Generated at 2022-06-25 22:42:36.363507
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:42:37.617538
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 22:42:40.404890
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:47.968803
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    str_0 = ''
    dict_0 = {str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:42:52.879573
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    str_0 = ''
    dict_0 = {str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:59.881329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    str_0 = ''
    dict_0 = {str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # attribute str of class str has type str
    # attribute lineno of class AST has type int
    # attribute col_offset of class AST has type int
    # attribute end_line of class AST has type int
    # attribute end_col_offset of class AST has type int
    # attribute end_lineno of class AST has type int
    # attribute ast_type of class AST has type str
    # attribute _attributes of class AST has type list
    # attribute _fields of class AST has type list
    # attribute body

# Generated at 2022-06-25 22:43:08.993303
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_2 = None
    str_1 = ''
    dict_1 = {str_1: str_1}
    a_s_t_1 = module_0.AST(**dict_1)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert super_without_arguments_transformer_2._tree_changed == False
    call_3 = super_without_arguments_transformer_2.visit_Call(call_2)
    assert super_without_arguments_transformer_2._tree_changed == False

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:43:13.608742
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    str_0 = ''
    dict_0 = {str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert type(super_without_arguments_transformer_0) == SuperWithoutArgumentsTransformer


# Generated at 2022-06-25 22:43:14.404924
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:43:21.577997
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:43:27.160788
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    str_0 = ''
    dict_0 = {str_0: str_0}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    ret_0 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert ret_0 == call_0

# Generated at 2022-06-25 22:43:30.050368
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST(**{'': ''})
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:43:30.890684
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:43:45.855303
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_0 = super_without_arguments_transformer_0.ast
    assert a_s_t_0 == None
    a_s_t_0 = super_without_arguments_transformer_0.ast = module_0.AST()
    version = super_without_arguments_transformer_0.version
    assert version == (3, 8)
    del version
    target = super_without_arguments_transformer_0.target
    assert target == (2, 7)
    del target
    tree = super_without_arguments_transformer_0.tree
    assert tree == None
    del tree


# Generated at 2022-06-25 22:43:46.700625
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:43:53.009834
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:43:55.082873
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:43:55.893716
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:43:59.197430
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.target == (2, 7)


# Generated at 2022-06-25 22:43:59.985504
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    #return SuperWithoutArgumentsTransformer()
    pass

# Generated at 2022-06-25 22:44:04.012642
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = ast.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(call_0)
    super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:44:10.314513
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        a_s_t_0 = module_0.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
        list_0 = [super_without_arguments_transformer_0]
        call_0 = module_0.Call(*list_0)
        call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    except Exception as exception_1:
        print('Exception caught in test_SuperWithoutArgumentsTransformer_visit_Call')


# Generated at 2022-06-25 22:44:12.137064
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:44:19.423101
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:22.883704
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    str_0 = str(call_1)
    str_1 = str("Call()")
    assert str_0 == str_1

# Generated at 2022-06-25 22:44:30.024104
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Constructor call without argument
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()
    # Creating a class
    class_0 = super_without_arguments_transformer_0.visit_ClassDef()
    # Creating a method
    function_0 = super_without_arguments_transformer_0.visit_FunctionDef(class_0)
    # Calling the method
    call_0 = super_without_arguments_transformer_0.visit_Call(function_0)
    assert (call_0 is not None)
    # The method should return the object it was called on
    assert (call_0 == function_0)


# Generated at 2022-06-25 22:44:34.112348
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(module_0.Call())
    return


# Generated at 2022-06-25 22:44:40.250528
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as __ast
    from ast import Call as _Call

    a_s_t_0 = __ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = _Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1.__class__.__name__ == 'Call'

# Generated at 2022-06-25 22:44:42.344419
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(a_s_t)


# Generated at 2022-06-25 22:44:43.122901
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:44:47.714921
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:44:49.143614
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-25 22:44:49.942710
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:44:55.769185
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:45:01.620819
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # get a AST object
    a_s_t_0 = module_0.AST()
    # get a SuperWithoutArgumentsTransformer object
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # get a Call object
    call_0 = module_0.Call(super_without_arguments_transformer_0)
    # test
    try:
        super_without_arguments_transformer_0.visit_Call(call_0)
    except:
        return 0
    

# Generated at 2022-06-25 22:45:06.672150
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    name_0 = module_0.Name("Call", module_0.Load())
    call_0 = module_0.Call(name_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:08.403040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:45:11.747086
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_2)
    assert super_without_arguments_transformer_1.target == (2, 7)


# Generated at 2022-06-25 22:45:13.364708
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # TODO: Add more tests
    # test_case_0()

    pass


# Generated at 2022-06-25 22:45:15.776235
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s_w_a_t_0 = SuperWithoutArgumentsTransformer()

if __name__ == '__main__':
	super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:45:18.234312
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:25.130514
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import sys
    sys.modules.pop('typed_ast._ast3')
    try:
        from typed_ast.ast3 import AST
        from typed_ast.ast3 import Call

        class Test_SuperWithoutArgumentsTransformer_visit_Call(unittest.TestCase):
            def setUp(self):
                self.test_obj = SuperWithoutArgumentsTransformer(AST())

            def test_visit_Call_type_error(self):
                with self.assertRaises(TypeError):
                    self.test_obj.visit_Call(Call())
    finally:
        sys.modules['typed_ast._ast3'] = module_0
    unittest.main()

# Generated at 2022-06-25 22:45:29.830300
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:45:47.165236
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:45:49.218044
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:57.156482
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    print(str(super_without_arguments_transformer_0))
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)



# Generated at 2022-06-25 22:46:03.517790
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:11.592150
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn

    class TestFunction(ast.FunctionDef):
        pass

    class TestClass(ast.ClassDef):
        pass

    class Module(ast.Module):

        def __init__(self, body):
            self.body = body

        @property
        def node(self):
            return self.body

    call = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[])

    test_func = TestFunction(name='a')
    test_class = TestClass(name='Test')


# Generated at 2022-06-25 22:46:13.697115
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)

# Generated at 2022-06-25 22:46:16.833252
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tmp_0 = module_0.AST()
    tmp_1 = SuperWithoutArgumentsTransformer(tmp_0)
    tmp_2 = module_0.Call()
    tmp_3 = tmp_1.visit_Call(tmp_2)
    return tmp_3

# Generated at 2022-06-25 22:46:20.826024
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:46:23.897810
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # prepare
    module_0 = ast.parse('super()')
    # execute
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)
    # verify
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:46:28.833650
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:46:40.977224
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # SuperWithoutArgumentsTransformer_0 = SuperWithoutArgumentsTransformer()
    test_case_0()

# test for function isinstance

# Generated at 2022-06-25 22:46:45.125316
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Expected AST:
    # AST()
    # Test creation of a new instance of class SuperWithoutArgumentsTransformer with attribute a_s_t of type AST
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:49.175873
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    assert isinstance(super_without_arguments_transformer_0._tree, ast.AST)

# Generated at 2022-06-25 22:46:50.873829
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    assert not SuperWithoutArgumentsTransformer(a_s_t_0).target


# Generated at 2022-06-25 22:46:56.221887
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:59.690260
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:47:00.777531
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-25 22:47:03.974400
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:47:05.704761
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    assert transformer._tree == tree


# Generated at 2022-06-25 22:47:09.779090
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:47:35.691562
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:47:38.170607
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:39.561095
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()
    return


# Generated at 2022-06-25 22:47:40.989054
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.AST()
    transformer = SuperWithoutArgumentsTransformer(tree)


# Generated at 2022-06-25 22:47:43.911319
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:44.606054
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:47:48.564861
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # check a simple function
    func_def_0 = module_0.FunctionDef()
    func_def_0.name = "super_with_args"
    func_def_1 = module_0.FunctionDef()
    func_def_1.name = "super_without_args"
    func_def_2 = module_0.FunctionDef()
    func_def_2.name = "super_with_args"
    class_def_0 = module_0.ClassDef()
    class_def_0.name = "super_with_args"
    pass



# Generated at 2022-06-25 22:47:50.771000
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:47:51.421387
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:47:56.462395
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call(*[super_without_arguments_transformer_0])
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1.__class__ == module_0.Call


# Generated at 2022-06-25 22:48:43.305831
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert callable(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:48:46.856435
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)



# Generated at 2022-06-25 22:48:48.824728
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)

# Generated at 2022-06-25 22:48:55.608503
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    str_0 = 'super'
    name_0 = module_0.Name(str_0, module_0.Load())
    call_0 = module_0.Call(name_0, [], [], None, None)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 == 'super(Cls, self)'

# Generated at 2022-06-25 22:49:01.725614
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert type(super_without_arguments_transformer_0) == SuperWithoutArgumentsTransformer


# Generated at 2022-06-25 22:49:09.604784
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
	# Test case with line coverage of 0.0%
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Test case with line coverage of 25.0%
    function_def_0 = module_0.FunctionDef()
    call_0 = module_0.Call()
    class_def_0 = module_0.ClassDef()
    call_1 = super_without_arguments_transformer_0._replace_super_args(call_0)
    # Test case with line coverage of 25.0%
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:49:12.827355
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:18.804062
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # SuperWithoutArgumentsTransfomer(2.7, AST)
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    # Call()
    list_1 = [super_without_arguments_transformer_1]
    call_2 = module_0.Call(*list_1)
    # SuperWithoutArgumentsTransformer.visit_Call(Call)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)
    assert call_3 is call_2

# Generated at 2022-06-25 22:49:20.435704
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:22.318752
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:51:07.360997
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = Supe

# Generated at 2022-06-25 22:51:09.635484
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == module_0.AST()


# Generated at 2022-06-25 22:51:10.425794
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Nothing to test for constructor
    pass


# Generated at 2022-06-25 22:51:14.170453
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:51:15.245322
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  try:
      ast.parse('super()')
  except NodeNotFound:
      pass

# Generated at 2022-06-25 22:51:19.459466
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    # AssertionError: None != <typed_ast._ast3.Call object at 0xb9b1d7ec>
    # assert call_1 == None


# Generated at 2022-06-25 22:51:20.071464
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:51:21.683054
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_2)


# Generated at 2022-06-25 22:51:24.415740
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 22:51:25.303287
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()