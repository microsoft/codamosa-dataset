

# Generated at 2022-06-25 22:41:56.391504
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:09.655204
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:14.568464
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_0 = module_0.Call(func=module_0.Name(id='super', ctx=module_0.Load()), args=[], keywords=[], starargs=None, kwargs=None)
    call_0 = super_without_arguments_transformer_1.visit_Call(call_0)
    assert call_0 is not None


# Generated at 2022-06-25 22:42:19.077728
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1.target = (0, 0)
    super_without_arguments_transformer_1.__class__



# Generated at 2022-06-25 22:42:21.514982
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)



# Generated at 2022-06-25 22:42:28.403549
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = super_without_arguments_transformer_0._tree.body[0].value.value
    super_without_arguments_transformer_0._tree.body[0].value.value = None
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:42:35.399746
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Test 0
    a_s_t_2 = module_0.Call()
    a_s_t_3 = module_0.Name()
    a_s_t_3.id = 'super'
    a_s_t_2.func = a_s_t_3
    a_s_t_2.args = []
    super_without_arguments_transformer_0.visit(a_s_t_2)

# Generated at 2022-06-25 22:42:36.550472
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_witho

# Generated at 2022-06-25 22:42:38.966068
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:40.316170
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    global test_case_0
    test_case_0()

# Generated at 2022-06-25 22:42:45.379482
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module_name = 'astroid'

# Generated at 2022-06-25 22:42:48.121945
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Input parameters of method visit_Call
    node = module_0.Call()
    # Result of method visit_Call
    
    
    # Call method visit_Call of class SuperWithoutArgumentsTransformer
    test_case_0()

# Generated at 2022-06-25 22:42:49.274233
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    trans = SuperWithoutArgumentsTransformer('')


# Generated at 2022-06-25 22:42:58.311590
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    class_declaration_0 = a_s_t_0.ClassDef(name='Test')
    class_declaration_0.bases = []
    class_declaration_0.keywords = []
    class_declaration_0.decorator_list = []
    function_declaration_0 = a_s_t_0.FunctionDef(name='foo')
    function_declaration_0.args = type(function_declaration_0.args)()
    function_declaration_0.args.args = []
    function_declaration_0.args.vararg = None
    function_declaration_0.args.kwarg = None
    function_declaration_0.args.defaults = []
    function_declaration_0.decorator

# Generated at 2022-06-25 22:42:59.120616
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test has not been implemented yet
    assert False

# Generated at 2022-06-25 22:43:08.486619
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Raise exception because no tree was provided
    with pytest.raises(Exception):
        test_case_0()

    # Test default args
    a_s_t_0 = module_0.AST()
    transformer_0 = SuperWithoutArgumentsTransformer(tree=a_s_t_0)
    result_0 = transformer_0.visit_Call(module_0)

    # Test no return value
    a_s_t_1 = module_0.AST()
    transformer_1 = SuperWithoutArgumentsTransformer(tree=a_s_t_1)
    result_1 = transformer_1.visit_Call()

    # Test invalid return type
    a_s_t_2 = module_0.AST()
    transformer_2 = SuperWithoutArgumentsTransformer(tree=a_s_t_2)

# Generated at 2022-06-25 22:43:10.294295
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_SuperWithoutArgumentsTransformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:13.644741
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_1 = module_0.Lambda()
    a_0 = module_0.Call(a_1)
    a_2 = SuperWithoutArgumentsTransformer()
    a_3 = module_0.Call()

    a_2.visit_Call(a_0)


# Generated at 2022-06-25 22:43:25.409241
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    node_0 = module_0.Call
    func = a_s_t_0.Name
    func.id = 'super'
    
    backtrack_0 = BacktrackImplementation(node_0=node_0, func=func)
    node_0 = module_0.Call()
    func = a_s_t_0.Name()
    func.id = 'super'
    
    backtrack_0.node_0 = node_0
    backtrack_0.func = func
    
    node_0.func = func
    node_0.args = []
    
    class Test_SuperWithoutArgumentsTransformer_visit_Call:
        def __init__(self, node_0, func):
            self.node_0 = node_

# Generated at 2022-06-25 22:43:27.045678
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # FIXME: test incorrect parameters
    # FIXME: test more cases
    assert True


# Generated at 2022-06-25 22:43:31.207015
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TODO: Implement testcase for constructor of class SuperWithoutArgumentsTransformer
    assert True


# Generated at 2022-06-25 22:43:32.484009
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-25 22:43:39.235432
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:42.773546
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0


# Generated at 2022-06-25 22:43:47.222691
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

    assert call_1 is call_0

# Generated at 2022-06-25 22:43:51.035632
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:53.360998
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)


# Generated at 2022-06-25 22:43:55.429103
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # First make sure the test is configured properly
    # SuperWithoutArgumentsTransformer.target = (2, 7)
    # # Then run the test
    test_case_0()

# Generated at 2022-06-25 22:43:58.389648
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:43:59.541769
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    return None


# Generated at 2022-06-25 22:44:08.705543
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert(call_1 is call_0)


# Generated at 2022-06-25 22:44:12.251332
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 != None


# Generated at 2022-06-25 22:44:12.759078
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-25 22:44:15.997443
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:44:22.614269
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == False
    assert super_without_arguments_transformer_0._in_func_def is None
    assert super_without_arguments_transformer_0._modified_modules == set()
    assert super_without_arguments_transformer_0._version == (2, 7)


# Generated at 2022-06-25 22:44:24.897548
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TODO: import typed_ast.ast3 and instantiate object
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0.AST())


# Generated at 2022-06-25 22:44:27.750723
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(None)

# test_case_0

# Generated at 2022-06-25 22:44:31.508711
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:44:33.603301
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        test_case_0()
    except Exception:
        assert False
    else:
        assert True

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:44:38.430629
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    return super_without_arguments_transformer_0.visit_Call(call_1)

# Generated at 2022-06-25 22:44:53.010098
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:44:55.370959
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:56.172573
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True # TODO: implement your test here

# Generated at 2022-06-25 22:44:56.949698
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:45:00.019212
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:45:03.709498
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:45:12.704572
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0 = typed_ast._ast3
    module_0 = module_0
    class_0 = module_0.ClassDef(name='Str')
    module_0 = module_0
    class_1 = module_0.ClassDef(name='List')
    module_0 = module_0
    function_0 = module_0.FunctionDef(name='join')
    module_0 = module_0
    function_1 = module_0.FunctionDef(name='append')
    module_0 = module_0
    function_2 = module_0.FunctionDef(name='pop')
    module_0 = module_0
    function_3 = module_0.FunctionDef(name='change_value_at')
    module_0 = module_0

# Generated at 2022-06-25 22:45:16.552391
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:20.804301
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    name_0 = super_without_arguments_transformer_0.visit_Name((call_0.func.id))

# Generated at 2022-06-25 22:45:23.492864
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    arg_0 = module_0.Call()
    arg_1 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(arg_1)
    super_without_arguments_transformer_0.visit_Call(arg_0)

## Unit tests
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:45:42.483774
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = {}
    t.update({'a': 1})
    t.update({'b': 2})
    t.update({'c': 3})
    t.update({'d': 4})
    assert t.get('a') == 1
    assert t.get('b') == 2
    assert t.get('c') == 3
    assert t.get('d') == 4
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    call_2 = module_0.Call()
    a_s_t_1 = module

# Generated at 2022-06-25 22:45:44.681715
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:45:47.280487
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:45:48.120176
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:45:52.600361
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:00.660327
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # 
    assert super_without_arguments_transformer_0 != None


# Generated at 2022-06-25 22:46:04.729199
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    # Test constructor
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:46:09.394634
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)
    out = super_without_arguments_transformer_0._tree_changed
    assert out

# Generated at 2022-06-25 22:46:10.117274
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:46:13.696448
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:37.175128
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:40.867332
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:49.211687
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)

from ..utils.tree import get_closest_parent_of
from ..utils.helpers import warn
from ..exceptions import NodeNotFound
from .base import BaseNodeTransformer
from .. import utils
from .. import exceptions
from .. import ast_manipulation
from .. import tree
from .remove_from_import_aliases import RemoveFromImportAliasesTransformer
from .replace_name import ReplaceNameTransformer
from .replace_module_global_references import ReplaceModuleGlobalReferencesTransformer

# Generated at 2022-06-25 22:46:49.783215
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert 1 == 1

# Generated at 2022-06-25 22:46:52.381909
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        a_s_t_0 = module_0.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    except Exception:
        assert False


# Generated at 2022-06-25 22:46:56.136847
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-25 22:46:59.613065
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_5 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_5)
    assert isinstance(super_without_arguments_transformer_1, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-25 22:47:03.695372
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 == call_0

# Generated at 2022-06-25 22:47:10.882904
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    module_0_body = []

    module_0_body.append(module_0.Expr(
        value=module_0.Call(
            func=module_0.Name(
                id='super',
                ctx=module_0.Load(),
            ),
            args=[],
            keywords=[],
        )
    ))


# Generated at 2022-06-25 22:47:14.989216
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.parse("a = super()")
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(tree)
    assert type(super_without_arguments_transformer_1) == SuperWithoutArgumentsTransformer

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()
    test_case_0()

# Generated at 2022-06-25 22:48:13.704497
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    call_2 = super_without_arguments_transformer_0.visit_Call(call_0)

if __name__ == '__main__':
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:48:17.227855
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:23.135022
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    expected_0 = module_0.Call()
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    return call_1 == expected_0

if __name__ == '__main__':
    import sys
    import nose2
    sys.argv.append('--verbose')
    sys.argv.append('--nocapture')
    nose2.main()

# Generated at 2022-06-25 22:48:25.629986
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:48:29.212330
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:48:30.446349
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        test_case_0()
    except:
        assert False

    assert True

# Generated at 2022-06-25 22:48:31.586891
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer()



# Generated at 2022-06-25 22:48:39.475224
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    target_0: int = 2
    target_1: int = 7
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert super_without_arguments_transformer_0.target == (target_0, target_1)
    assert super_without_arguments_transformer_0.tree is tree_0


# Generated at 2022-06-25 22:48:43.100385
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:48:46.926889
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:50:41.493923
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert super_without_arguments_transformer_0 != None


# Generated at 2022-06-25 22:50:44.317602
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_2 = module_0.Call()
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)

# Generated at 2022-06-25 22:50:48.891151
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(tree)
    assert super_without_arguments_transformer._tree == tree
    assert super_without_arguments_transformer._tree_changed == False
    assert super_without_arguments_transformer.visit(None) == None
    assert super_without_arguments_transformer.visit_alias(None) == None
    assert super_without_arguments_transformer.visit_arguments(None) == None
    assert super_without_arguments_transformer.visit_arg(None) == None
    assert super_without_arguments_transformer.visit_comprehension(None) == None

# Generated at 2022-06-25 22:50:51.508314
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        test_case = test_case_0
        test_case()
    except Exception as e:
        print('Exception: ' + str(e))
        assert False

# Generated at 2022-06-25 22:50:53.878312
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Set up
    i_v_a_s_t_0 = module_0.Interactive()
    a_s_t_0 = module_0.AST()
    # Test
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:50:57.922306
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 is call_0


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:51:04.595547
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert isinstance(SuperWithoutArgumentsTransformer(module_0.AST()), SuperWithoutArgumentsTransformer), "Expected type(SuperWithoutArgumentsTransformer(module_0.AST())) to be <class '__main__.SuperWithoutArgumentsTransformer'>"
    assert isinstance(SuperWithoutArgumentsTransformer(module_0.AST()) if True else module_0.AST(), SuperWithoutArgumentsTransformer), "Expected type(SuperWithoutArgumentsTransformer(module_0.AST()) if True else module_0.AST()) to be <class '__main__.SuperWithoutArgumentsTransformer'>"
    assert SuperWithoutArgumentsTransformer(module_0.AST()) if True else module_0.AST() == SuperWithoutArgumentsTransformer(module_0.AST())
    assert id(SuperWithoutArgumentsTransformer(module_0.AST()))

# Generated at 2022-06-25 22:51:07.876385
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:51:09.878186
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:51:12.933194
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)