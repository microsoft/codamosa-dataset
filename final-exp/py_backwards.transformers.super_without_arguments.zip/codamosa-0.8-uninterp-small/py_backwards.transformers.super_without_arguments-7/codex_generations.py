

# Generated at 2022-06-25 22:42:03.328095
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    node_1 = module_0.Call()
    super_without_arguments_transformer_1.visit_Call(node_1)


# Generated at 2022-06-25 22:42:07.565038
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_2 = module_0.Call()
    super_without_arguments_transformer_1.visit_Call(call_2)


# Generated at 2022-06-25 22:42:10.816890
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:13.897634
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Call constructor
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_2)

    # Test instance variables:
    assert super_without_arguments_transformer_0.target == (2, 7)


# Generated at 2022-06-25 22:42:18.707475
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast._ast3 as module_0

    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    try:
        assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    except AssertionError:
        raise AssertionError


# Generated at 2022-06-25 22:42:28.457103
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    class_0 = module_0.ClassDef('Class0', [], [], [], [], 0)
    functiondef_1 = module_0.FunctionDef('FunctionDef1', module_0.arguments([], None, None, []), [], [], 0, None)
    call_2 = module_0.Call(module_0.Name('super', 0), [], [], None, None)
    call_2.args = []
    call_2.keywords = []
    call_2.starargs = None
    call_2.kwargs = None

# Generated at 2022-06-25 22:42:30.807685
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:42:35.609234
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module_1 = ast.parse('class A:\n    def f(self):\n        super()')

    assert SuperWithoutArgumentsTransformer(module_1).visit(module_1).body[0].body[0].value.args[0].id == 'A'
    assert SuperWithoutArgumentsTransformer(module_1).visit(module_1).body[0].body[0].value.args[1].id == 'self'


# Generated at 2022-06-25 22:42:38.064783
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Test for constructor: SuperWithoutArgumentsTransformer(tree: AST)

# Generated at 2022-06-25 22:42:39.010927
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:42:42.114481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:42:45.030664
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("Test: SuperWithoutArgumentsTransformer(self, node: ast.AST):")
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-25 22:42:46.497860
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a = ast.AST()
    t = SuperWithoutArgumentsTransformer(a)



# Generated at 2022-06-25 22:42:48.926693
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:58.029533
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit(module_0.Name(id="node"))
    try:
        super_without_arguments_transformer_0.visit(module_0.Call(func=module_0.Name(id="super"), args=[]))
    except NodeNotFound as raised_exception:
        assert str(raised_exception) == "super() outside of function"
    else:
        raise RuntimeError("NodeNotFound was not raised")

# Generated at 2022-06-25 22:43:00.423347
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:01.282916
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:43:08.405237
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = ast.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    try:
        super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_1)
    except Exception as e_2:
        print(e_2)


# Generated at 2022-06-25 22:43:11.222042
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:43:18.811071
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    # test_SuperWithoutArgumentsTransformer_0

    assert super_without_arguments_transformer_1._tree_changed == False
# ------------------------------------------------------------------------------

# test_SuperWithoutArgumentsTransformer_0_1_1
test_case_0()

# ------------------------------------------------------------------------------


# Generated at 2022-06-25 22:43:25.572054
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Test for call to visit_Call (line 24)
    call_0 = None
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:29.346121
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:43:30.170612
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True



# Generated at 2022-06-25 22:43:31.918522
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)

# Generated at 2022-06-25 22:43:43.332582
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(input_0)

    # def test_case_0():
    call_0 = None
    call_1 = super_without_arguments_transformer_1.visit_Call(call_0)
    # def test_SuperWithoutArgumentsTransformer():
    input_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:43:52.658071
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
	aST0 = LinP2TAST()
	superWithoutArgumentsTransformer0 = SuperWithoutArgumentsTransformer(aST0)
	superWithoutArgumentsTransformer0._tree.body.insert(0, None)
	superWithoutArgumentsTransformer0._tree.body[0] = ast.ImportFrom(module='typed_ast._ast3', names=[ast.alias(name='AST', asname=None)], level=0)
	superWithoutArgumentsTransformer0._tree.body.insert(1, None)
	superWithoutArgumentsTransformer0._tree.body[1] = ast.ImportFrom(module='typed_ast._ast3', names=[ast.alias(name='Module', asname=None)], level=0)
	superWithoutArgumentsTransformer0._tree.body.insert(2, None)
	super

# Generated at 2022-06-25 22:43:54.413271
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_0 = SuperWithoutArgumentsTransformer()
    assert isinstance(class_0, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-25 22:43:58.608363
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0


# Generated at 2022-06-25 22:44:02.202328
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree)
    assert(super_without_arguments_transformer_0._tree_changed == False)


# Generated at 2022-06-25 22:44:02.788704
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert None


# Generated at 2022-06-25 22:44:08.546118
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Unit test for visit_Call
    test_case_0()

# Generated at 2022-06-25 22:44:11.189611
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()

test_case_0()


if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:44:14.978737
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0



# Generated at 2022-06-25 22:44:15.819036
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass



# Generated at 2022-06-25 22:44:18.234909
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:20.572924
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:23.129522
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:25.407301
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:29.173092
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:44:32.309724
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:38.239933
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:44:42.871331
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert (super_without_arguments_transformer_0.tree == a_s_t_0)

import typed_ast.ast3 # type: ignore


# Generated at 2022-06-25 22:44:43.631024
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:44:46.186295
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)

test_case_0()
# test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:44:52.642964
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Assuming tree node is not None
    tree = ast.AST()
    assert tree is not None
    # Assuming that the tree node has a valid type
    assert isinstance(tree, ast.AST)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree)
    # Assuming super_without_arguments_transformer_0 is not None
    assert super_without_arguments_transformer_0 is not None
    # Assuming that super_without_arguments_transformer_0 has a valid type
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    

# Generated at 2022-06-25 22:44:55.299034
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

test_case_0()
test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:44:58.287019
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    super_without_arguments_transformer_0.visit_Call(module_0.Call())


# Generated at 2022-06-25 22:44:59.796913
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TODO: implement tests for class SuperWithoutArgumentsTransformer
    assert True == True



# Generated at 2022-06-25 22:45:01.545818
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree)


# Generated at 2022-06-25 22:45:04.932784
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transforme

# Generated at 2022-06-25 22:45:22.463455
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0._replace_super_args(call_0)
    assert super_without_arguments_transformer_0._tree is a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed is False
    try:
        super_without_arguments_transformer_0.visit_Call(call_0)
    except Exception as e_0:
        assert type(e_0) is NodeNotFound


# Generated at 2022-06-25 22:45:24.716291
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)
    return None


# Generated at 2022-06-25 22:45:26.731107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = None
    SuperWithoutArgumentsTransformer_0 = SuperWithoutArgumentsTransformer(tree)
    assert SuperWithoutArgumentsTransformer_0


# Generated at 2022-06-25 22:45:29.378882
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None
    test_case_0()

# Generated at 2022-06-25 22:45:31.764974
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        SuperWithoutArgumentsTransformer(None)
    except TypeError:
        pass

if __name__ == '__main__':
    import pytest
    import sys
    sys.exit(pytest.main(['-s', __file__]))

# Generated at 2022-06-25 22:45:33.600065
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:45:35.469658
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)


# Generated at 2022-06-25 22:45:38.402819
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = ast.AST()

    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert super_without_arguments_transformer_0.target == (2, 7)


# Generated at 2022-06-25 22:45:39.690410
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:45:44.858739
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dunder_main_0 = module_0.Module(body=[])
    arg_0 = dunder_main_0
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(arg_0)


# Generated at 2022-06-25 22:46:09.812674
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None

# Generated at 2022-06-25 22:46:12.031096
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)

test_case_0()
test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:46:17.100425
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert not super_without_arguments_transformer_0._tree_changed
    assert not super_without_arguments_transformer_0._targets


# Generated at 2022-06-25 22:46:20.464790
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:46:22.168463
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:28.257298
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_3 = module_0.AST()
    super_without_arguments_transformer_3 = SuperWithoutArgumentsTransformer(a_s_t_3)
    assert issubclass(type(super_without_arguments_transformer_3), BaseNodeTransformer)
    assert type(super_without_arguments_transformer_3._tree) is module_0.AST
    assert type(super_without_arguments_transformer_3._changed) is bool
    assert super_without_arguments_transformer_3.target == (2, 7)


# Generated at 2022-06-25 22:46:30.781783
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)
    module_1 = super_without_arguments_transformer_0.visit(module_0)


# Generated at 2022-06-25 22:46:31.584572
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True == True


# Generated at 2022-06-25 22:46:36.276262
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    classdef_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    classdef_1 = super_without_arguments_transformer_0.visit_ClassDef(classdef_0)
    assert classdef_1 is classdef_0

# Generated at 2022-06-25 22:46:39.083989
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None

# Generated at 2022-06-25 22:47:31.616317
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    classdef_0 = module_0.ClassDef(
        name = 'foo',
        bases = [],
        keywords = [],
        starargs = None,
        kwargs = None,
        body = [],
        decorator_list = []
    )
    module_0.fix_missing_locations(classdef_0)
    super_without_arguments_transformer_0.visit_ClassDef(classdef_0)


# Generated at 2022-06-25 22:47:35.963247
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module = module_0

    a_s_t_0 = module.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    assert not super_without_arguments_transformer_0._tree_changed
    assert isinstance(super_without_arguments_transformer_0._tree, module.AST)



# Generated at 2022-06-25 22:47:38.517520
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:47:45.507395
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(super_without_arguments_transformer_0.tree == a_s_t_0)
    assert(super_without_arguments_transformer_0._tree_changed == False)
    assert(super_without_arguments_transformer_0.target[0] == 2)
    assert(super_without_arguments_transformer_0.target[1] == 7)
    assert(super_without_arguments_transformer_0.visit_Call(call_0) == call_0)


# Generated at 2022-06-25 22:47:49.681718
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0
    assert super_without_arguments_transformer_0._tree is a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed is False
    assert super_without_arguments_transformer_0._version is (2, 7)


# Generated at 2022-06-25 22:47:51.817470
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree)

if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 22:47:55.832317
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree is a_s_t_0

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:48:01.414920
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    str_0 = repr(call_1)
    str_1 = str(call_1)
    print(str_1)

if __name__ == '__main__':
    import sys
    import typing
    test_SuperWithoutArgumentsTransformer()
    test_case_0()
    pass

# Generated at 2022-06-25 22:48:07.875436
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Create object and test for type
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)

    # Test name of function visit_Call
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)



# Generated at 2022-06-25 22:48:10.908667
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:18.065084
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Constructor for class SuperWithoutArgumentsTransformer
    tree_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)

# Generated at 2022-06-25 22:50:20.447138
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_50 = module_0.AST()
    super_without_arguments_transformer_50 = SuperWithoutArgumentsTransformer(a_s_t_50)
    assert(isinstance(super_without_arguments_transformer_50, SuperWithoutArgumentsTransformer))


# Generated at 2022-06-25 22:50:25.255569
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    try:
        super_without_arguments_transformer_0.visit_Call(call_1)
        assert False
    except Exception as exc:
        assert isinstance(exc, SystemExit)
    except:
        assert False



# Generated at 2022-06-25 22:50:27.923022
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:50:33.801883
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:50:34.384948
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True

# Generated at 2022-06-25 22:50:41.693003
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test with valid arguments.
    tree_arg_0 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(tree_arg_0)
    assert(super_without_arguments_transformer_1._tree == tree_arg_0)
    assert(super_without_arguments_transformer_1._tree_changed == False)
    
    # Test with valid arguments (default values).
    tree_arg_1 = module_0.AST()
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(tree_arg_1)
    assert(super_without_arguments_transformer_2._tree == tree_arg_1)
    assert(super_without_arguments_transformer_2._tree_changed == False)
    
    #

# Generated at 2022-06-25 22:50:43.744501
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:46.502045
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_def_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0, class_def_0)


# Generated at 2022-06-25 22:50:50.531322
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    function_def_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = None
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    call_2 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(call_2)
