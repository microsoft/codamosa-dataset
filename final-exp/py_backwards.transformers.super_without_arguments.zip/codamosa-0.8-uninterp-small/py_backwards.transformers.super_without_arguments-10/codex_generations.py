

# Generated at 2022-06-25 22:42:04.273707
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    call_0 = module_0.Call()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert super_without_arguments_transformer_1.visit_Call(call_0) == call_0


# Generated at 2022-06-25 22:42:13.211993
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    func_0 = module_0.FunctionDef()
    func_0.args = module_0.arguments()
    module_0.arguments.args = [module_0.arg()]
    module_0.arguments.args[0].arg = 'arg_0'
    func_0.name = 'func_0'
    cls_0 = module_0.ClassDef()
    cls_0.name = 'cls_0'
    node_0 = module_0.Call()
    node_0.func = module_0.Name()
    node_0.func.id = 'super'
    node_0.args

# Generated at 2022-06-25 22:42:14.301148
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass


# Generated at 2022-06-25 22:42:14.805464
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:42:24.030960
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    try:
        super_without_arguments_transformer_0.visit(module_0.Expr(value=module_0.Name(id='super'))).value.args[0].id
    except NameError:
        pass
    else:
        assert False
    try:
        super_without_arguments_transformer_0.visit(module_0.Assign(targets=[module_0.Name(id='super', ctx=module_0.Load())], value=module_0.Name(id='super'))).value.args[0].id
    except NameError:
        pass

# Generated at 2022-06-25 22:42:32.038512
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Instantiate AST object
    a_s_t_0 = module_0.AST()
    # Instantiate visitor object
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    # Instantiate Call node
    node_0 = module_0.Call()

    # Instantiate Name node
    node_1 = module_0.Name()

    node_1.id = 'super'

    node_0.func = node_1

    node_0.args = ()

    # Call method visit_Call
    super_without_arguments_transformer_0.visit_Call(node_0)


# Generated at 2022-06-25 22:42:33.847405
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Run tests
if __name__  == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:42:36.714160
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Compiling AST
    a_s_t_0 = module_0.AST()

    # Constructing an object of SuperWithoutArgumentsTransformer with arguments
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:42:40.316729
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Set up the test
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:42:45.030392
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    call_0 = module_0.Call()
    call_0.func = Name()

    assert super_without_arguments_transformer_0.visit_Call(call_0) == call_0

# Generated at 2022-06-25 22:42:52.755113
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:42:54.266817
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree)
    assert True

# Generated at 2022-06-25 22:42:56.132776
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:59.224650
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:00.746680
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-25 22:43:06.127911
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.tree == a_s_t_0
    assert not super_without_arguments_transformer_0.tree_changed

# Generated at 2022-06-25 22:43:10.836720
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    call_0 = None
    # __init__ of class SuperWithoutArgumentsTransformer
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    
    super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:43:15.128741
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    try:
        assert super_without_arguments_transformer_0
    except AssertionError:
        raise AssertionError('expected super_without_arguments_transformer_0 to be defined but it is not')


# Generated at 2022-06-25 22:43:21.721364
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:23.812886
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-25 22:43:33.461730
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:43:34.786539
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:43:39.893248
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:44.334846
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert(call_1 == None)

# Generated at 2022-06-25 22:43:53.282079
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = ast.Call(
        func=ast.Name(
            id='super',
            ctx=ast.Load()),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None)
    a_s_t_0 = ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    expr_0 = ast.Expression(
        body=call_1)

# Generated at 2022-06-25 22:43:57.509924
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    # assert call_1 is None
    pass


# Generated at 2022-06-25 22:44:06.223494
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_1.target == (2, 7)
    assert super_without_arguments_transformer_1.tree == a_s_t_0
    assert super_without_arguments_transformer_1._tree_changed == False
    assert super_without_arguments_transformer_1.generic_visit(call_0) == call_0


# Generated at 2022-06-25 22:44:11.341423
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    if call_0 is call_1:
        print("Passed: Call")
    else:
        print("Failure: Call")


# Generated at 2022-06-25 22:44:13.602085
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:14.456974
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:44:30.189466
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:34.889995
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1


# Generated at 2022-06-25 22:44:43.198338
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)
    module_1 = super_without_arguments_transformer_0._tree
    module_2 = super_without_arguments_transformer_0._tree_changed
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(module_0)
    module_3 = super_without_arguments_transformer_1._tree
    module_4 = super_without_arguments_transformer_1._tree_changed
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(module_0)
    module_5 = super_without_arguments_transformer_2._tree
    module_6 = super_without_arguments_transformer_2._tree

# Generated at 2022-06-25 22:44:44.244889
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:44:47.440427
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:44:49.758362
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:51.413549
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    arg0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(arg0)

# Generated at 2022-06-25 22:44:57.984996
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert_equal(super_without_arguments_transformer_0.target, (2, 7))
    assert_equal(super_without_arguments_transformer_0.tree, a_s_t_0)
    assert_equal(super_without_arguments_transformer_0._tree_changed, False)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:44:58.523566
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-25 22:45:02.169945
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:45:27.481634
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert True

# Generated at 2022-06-25 22:45:31.309471
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not super_without_arguments_transformer_1


# Generated at 2022-06-25 22:45:35.986845
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:45:36.835725
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:45:42.447904
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)

    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

    return


# Generated at 2022-06-25 22:45:47.295940
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import _ast as ast
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer


    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-25 22:45:49.074676
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree)
    pass


# Generated at 2022-06-25 22:45:51.733089
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)


# Generated at 2022-06-25 22:45:56.455591
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = None
    ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)
    assert (super_without_arguments_transformer_0._tree == ast_0)


# Generated at 2022-06-25 22:46:01.592621
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:46:54.259403
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:56.347414
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:46:57.906822
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 22:47:02.048063
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert (super_without_arguments_transformer_0.visit_Call(call_0) == None)


# Generated at 2022-06-25 22:47:05.565527
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert not super_without_arguments_transformer_0._tree_changed

import typed_ast.ast3 as module_0


# Generated at 2022-06-25 22:47:08.499838
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree is a_s_t_0


# Generated at 2022-06-25 22:47:09.245294
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass
    


# Generated at 2022-06-25 22:47:17.427668
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Set 1:
    typed_ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(typed_ast_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    assert isinstance(super_without_arguments_transformer_0, module_0.NodeTransformer)
    # Set 2:
    typed_ast_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(typed_ast_1)
    assert isinstance(super_without_arguments_transformer_1, SuperWithoutArgumentsTransformer)
    assert isinstance(super_without_arguments_transformer_1, module_0.NodeTransformer)



# Generated at 2022-06-25 22:47:19.215556
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(call_0)


# Generated at 2022-06-25 22:47:22.406390
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Pass a_s_t_0_0 as the parameter to test constructor of SuperWithoutArgumentsTransformer
    call_2 = None
    a_s_t_0_0 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0_0)


# Generated at 2022-06-25 22:49:16.815282
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:49:18.399316
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    module_name = 'typed_ast.ast3'
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)



# Generated at 2022-06-25 22:49:23.523531
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    print("SUCCESS: SuperWithoutArgumentsTransformer.visit_Call")

if __name__ == '__main__':
    module_0 = __import__('typed_ast._ast3', fromlist=('AST',))
    test_case_0()
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:49:26.133313
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:49:27.691818
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:30.000931
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:49:31.575547
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(tree)
    assert super_without_arguments_transformer.target == (2, 7)


# Generated at 2022-06-25 22:49:33.659938
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = None
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:49:34.748338
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = None
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-25 22:49:35.525187
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()