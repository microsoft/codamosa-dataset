

# Generated at 2022-06-25 22:42:03.546230
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:42:06.352300
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Because SuperWithoutArgumentsTransformer is an abstract class, you must use one of its inherited classes to test its constructor
    #TODO: Add your test code here
    raise NotImplementedError()


# Generated at 2022-06-25 22:42:12.950033
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    
    # Declarations
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Init
    call_0 = ast.Call(func=ast.Name(id='super'), keywords=[], starargs=None, kwargs=None)
    # Call
    super_without_arguments_transformer_0.visit_Call(call_0)
    # Validate
    # assertEqual(call_0.args, [])

# Generated at 2022-06-25 22:42:21.597385
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    m = ast3.Module()
    class ClassName():
        pass
    m.body = []
    m.body.append(ast3.Assign())
    m.body[0].targets = []
    m.body[0].targets.append(ast3.Name())
    m.body[0].targets[0].id = 'foo'
    m.body[0].targets[0].ctx = ast3.Store()
    m.body[0].value = ast3.Call()
    m.body[0].value.func = ast3.Name()
    m.body[0].value.func.id = 'super'
    m.body[0].value.func.ctx = ast3.Load()

# Generated at 2022-06-25 22:42:27.009356
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    try:
        super_without_arguments_transformer_0.visit_Call(call_0)
    except AttributeError:
        pass

# Generated at 2022-06-25 22:42:29.589771
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    return

# Generated at 2022-06-25 22:42:37.815330
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit(True)
    super_without_arguments_transformer_0.visit(module_0.mod)
    super_without_arguments_transformer_0.visit(module_0.Interactive)
    super_without_arguments_transformer_0.visit(module_0.Expression)
    super_without_arguments_transformer_0.visit(module_0.Suite)
    super_without_arguments_transformer_0.visit(module_0.FunctionDef)

# Generated at 2022-06-25 22:42:47.010177
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)
    a_s_t_3 = module_0.AST()
    super_without_arguments_transformer_3 = SuperWithoutArgumentsTransformer(a_s_t_3)
    a_s_t_1_1 = module_0.Call()
    super_without_arguments_transformer_1_1 = SuperWithoutArgumentsTransformer(a_s_t_1_1)
    a_s_t_1 = module_0.Call()
    a_s_t_1.args = ()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:42:56.308767
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # a_s_t_0 is an instance of typed_ast._ast3.AST
    # call_0 is an instance of typed_ast._ast3.Call
    # super_without_arguments_transformer_0 is an instance of SuperWithoutArgumentsTransformer
    # The call to method visit_Call of class SuperWithoutArgumentsTransformer performed here
    # has type violations.
    # (1) super_without_arguments_transformer_0 has type SuperWithoutArgumentsTransformer,
    # expected type SuperWithoutArgumentsTransformer
    # (2) call_0 has type Call, expected type

# Generated at 2022-06-25 22:42:59.189713
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:05.882256
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    assert isinstance(transformer, BaseNodeTransformer)
    assert isinstance(transformer, ast.NodeTransformer)
    assert hasattr(transformer.generic_visit, '__call__')

# Generated at 2022-06-25 22:43:07.117597
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:43:07.768650
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    int_0 = 0

# Generated at 2022-06-25 22:43:16.184913
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None
    )
    tree = ast.parse(inspect.getsource(test_case_0))
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected = (
        ast.Call(
            func=ast.Name(id='super', ctx=ast.Load()),
            args=[ast.Name(id='TestCase0'),ast.Name(id='int_0')],
            keywords=[],
            starargs=None,
            kwargs=None
        )
    )
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-25 22:43:21.498372
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Input
    int_0 = 0
    # Expect Output
    expected_0 = 0
    # Actual Output
    actual_0 = int_0
    # Compare
    assert actual_0 == expected_0


# Generated at 2022-06-25 22:43:26.007468
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    check_function = SuperWithoutArgumentsTransformer().visit_Call
    func_def = ast.parse('super()', mode='eval').body
    check_function(func_def)
    assert str(func_def.func.args[0].id) == 'cls'
    assert str(func_def.func.args[1].id) == 'self'


# Generated at 2022-06-25 22:43:26.565964
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    int_0 = 0

# Generated at 2022-06-25 22:43:28.680498
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.stmt('pass()')
    o = SuperWithoutArgumentsTransformer()
    o.visit(node)



# Generated at 2022-06-25 22:43:31.129140
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = "super()"
    tree = ast.parse(s)
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-25 22:43:33.787394
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 22:43:37.939508
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    SuperWithoutArgumentsTransformer()


# Generated at 2022-06-25 22:43:40.962960
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse(test_case_0.__code__.co_consts[1])
    x = SuperWithoutArgumentsTransformer()
    y = x.visit(tree)
    assert isinstance(y, ast.Module)

# Generated at 2022-06-25 22:43:42.817771
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_method_call = SuperWithoutArgumentsTransformer()
    print("SuperWithoutArgumentsTransformer constructor test: successful")



# Generated at 2022-06-25 22:43:52.112303
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # NOTE: The following samples are taken from 
    # https://docs.python.org/3/library/typed_ast.html
    # and were modified so that they compile

    # Test case 1:
    # super()
    # super(cls, self)
    expected_tree = ast.parse(textwrap.dedent("""
        class A:
            def __init__(self):
                super(A, self)
        """))

    tree = ast.parse(textwrap.dedent("""
        class A:
            def __init__(self):
                super()
        """))

    SuperWithoutArgumentsTransformer(tree).run()

    compare_ast(tree, expected_tree, True)

    # Test case 2:
    # super()
    # super(cls, cls)
    expected_tree

# Generated at 2022-06-25 22:43:53.552258
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    check_node = ast.parse('super()')
    node = SuperWithoutArgumentsTransformer().visit(check_node)

# Generated at 2022-06-25 22:43:54.372921
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:43:58.942026
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = """class A:
    def test(self):
        super()
"""
    expected = """class A:
    def test(self):
        super(A, self)
"""
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert expected == astor.to_source(tree)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 22:44:08.271134
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("test_SuperWithoutArgumentsTransformer")

    print("Case 0: super()")
    source_code = """
        class A:
            def __init__(self):
                super()
    """
    expected_code = """
        class A:
            def __init__(self):
                super(A, self)
    """
    print("Source code:")
    print(source_code)

    print("Expected code:")
    print(expected_code)
    

# Generated at 2022-06-25 22:44:09.542716
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-25 22:44:17.814827
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    # Test case 0:
    # This test case is from file: ../tests/cases/compile_ast/test_super_arg.py, line 5
    test_case_0_instance = ast.parse("""\
        try:
            int_0
        except BaseException:
            super(Cls0, self).method_0()
    """)

    try:
        assert (SuperWithoutArgumentsTransformer(test_case_0_instance).visit(test_case_0_instance)) == test_case_0_instance
    except AssertionError:
        print('AssertionError, test case: ', 'test_case_0')
        print(SuperWithoutArgumentsTransformer(test_case_0_instance).visit(test_case_0_instance))



# Generated at 2022-06-25 22:44:25.151695
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astunparse
    from typing import List
    string_0 = 'def test_case_0():\n    int_0 = 0'
    tree_0 = ast.parse(string_0)
    SuperWithoutArgumentsTransformer(tree_0).run()
    string_1 = astunparse.unparse(tree_0)
    assert string_1 == 'def test_case_0():\n    int_0 = 0'


# Generated at 2022-06-25 22:44:27.664688
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ast_tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast_tree)
    assert transformer != None

# Generated at 2022-06-25 22:44:28.178771
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:44:34.203847
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(test_case_0)
    print("Before transformation: ")
    print(astor.to_source(ast.parse(inspect.getsource(test_case_0))))
    transformer.visit(ast.parse(inspect.getsource(test_case_0)))
    print("After transformation: ")
    print(astor.to_source(ast.parse(inspect.getsource(test_case_0))))



# Test for method _replace_super_args

# Generated at 2022-06-25 22:44:38.394019
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = ast.parse(test_case_0.__code__.co_code)
    n = SuperWithoutArgumentsTransformer()
    n.visit(t)
    int_0

if __name__ == '__main__':
    t = ast.parse(test_case_0.__code__.co_code)
    n = SuperWithoutArgumentsTransformer()
    n.visit(t)

# Generated at 2022-06-25 22:44:42.073592
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    obj = SuperWithoutArgumentsTransformer()
    source = """super()"""
    root = ast.parse(source)
    obj.visit(root)
    expected = ast.parse("""super(Cls, self)""")
    assert ast.dump(root) == ast.dump(expected)

# Generated at 2022-06-25 22:44:47.892776
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_utils import assert_equal_ignore_ws
    from .. import ast_manipulation

    code = """
        class Foo:
            def __init__(self):
                super()
    """
    expected = """
        class Foo:
            def __init__(self):
                super(Foo, self)
    """
    tree = ast_manipulation.parse_module(code)
    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.run()
    assert_equal_ignore_ws(ast_manipulation.dump_module(tree), expected)

# Generated at 2022-06-25 22:44:52.605012
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Setup
    node = ast.Call(
        func=ast.Name(id='super')
    )
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(ast.parse(inspect.getsource(test_case_0)))

    # Test and verify
    assert transformer.visit_Call(node)._fields == ("func", "args", "keywords", "starargs", "kwargs")
    # Tear down

# Generated at 2022-06-25 22:45:00.614376
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Testing catch the situation that the super has arguments
    class Cls0:
        def __init__(self):
            super(Cls0, 0)
            # int_0 = 0

    class Cls1:
        def __init__(self):
            super(0)
            # int_0 = 0

    # Testing catch the situation that the super does not has arguments
    class Cls2:
        def __init__(self):
            super()
            # int_0 = 0

    class Cls3:
        def __init__(self):
            super()
            # int_0 = 0

    class Cls4:
        def __init__(self):
            super()
            # int_0 = 0

    class Cls5:
        def __init__(self):
            super()
            # int_0

# Generated at 2022-06-25 22:45:01.764680
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  SuperWithoutArgumentsTransformer(ast.parse('int_0 = 0'))

# Generated at 2022-06-25 22:45:13.734308
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Asserts the return type of method "visit_Call"
    assert (isinstance(super_without_arguments_transformer_0.visit_Call(None), module_0.Call))
    # Asserts the return type of method "visit_Call"
    assert (isinstance(super_without_arguments_transformer_1.visit_Call(None), module_0.Call))
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_

# Generated at 2022-06-25 22:45:17.362269
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:45:19.490319
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:22.820395
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    

# Generated at 2022-06-25 22:45:26.622166
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:45:29.540817
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:32.316945
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # a_s_t_0 = None
    # super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:35.709692
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        a_s_t_0 = None
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    except NameError as inst:
        assert type(inst) == NameError



# Generated at 2022-06-25 22:45:40.940771
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    try:
        assert super_without_arguments_transformer_0.visit_Call(call_0) is call_0
    except AssertionError as e:
        errors.append(e)


# Generated at 2022-06-25 22:45:51.522853
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    a_s_t_2 = None
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)
    a_s_t_3 = None
    super_without_arguments_transformer_3 = SuperWithoutArgumentsTransformer(a_s_t_3)
    a_s_t_4 = None
    super_without_arguments_transformer_4 = SuperWithoutArgumentsTransformer(a_s_t_4)

# Generated at 2022-06-25 22:46:07.609283
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert call_1 is call_0
    call_0 = module_0.Call()
    call_0_0 = module_0.Name()
    call_0.args = []
    call_0.keywords = []
    call_0.func = call_0_0
    call_0_0.ctx = module_0.Load()

# Generated at 2022-06-25 22:46:09.979872
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

test_case_0()
test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:46:14.659600
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def test_object(self, self_1, self_2):
        from macropy.core.quotes import macros, q, name, ast, u

        with q as body:
            f = 0

            def f():
                super()

        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(body)
        super_without_arguments_transformer_0._replace_super_args((body.body[1].body[0]).func)

# Generated at 2022-06-25 22:46:18.030368
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:21.160134
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(tree=a_s_t_0)


# Generated at 2022-06-25 22:46:24.585463
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:46:28.072152
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:31.157452
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:35.591513
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:46:37.574600
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:46:50.672737
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:58.353542
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert len(call_1.args) == 2
    name_0 = call_1.args[0]
    assert name_0.id == "Name"
    assert call_0.keywords == call_1.keywords
    name_1 = call_1.args[1]
    assert name_1.id == "Name"

# Generated at 2022-06-25 22:47:00.635851
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:01.715708
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:47:05.217128
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:12.649301
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(super_without_arguments_transformer_0.module_level_globals_to_remove == list())
    assert(super_without_arguments_transformer_0.module_level_globals_to_add == dict())
    assert(super_without_arguments_transformer_0.module_level_globals_addition_position == {})
    assert(super_without_arguments_transformer_0.module_level_global_removal_position == {})
    assert(super_without_arguments_transformer_0.local_level_globals_to_remove == {})

# Generated at 2022-06-25 22:47:14.761890
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:18.785847
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:21.768822
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:47:25.056207
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:43.568690
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:45.834721
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:47:47.724373
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0


# Generated at 2022-06-25 22:47:53.428169
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Assert condition for parameter a_s_t_0
    assert a_s_t_0 == None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    # Assert condition for parameter node
    assert call_0 == None
    super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_1.visit_Call(call_0)


# Generated at 2022-06-25 22:48:01.099469
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.Module()
    func_def_0 = module_0.FunctionDef()
    func_def_0.args = module_0.arguments()
    func_def_0.args.args = [module_0.arg()]
    func_def_0.name = '<module>'
    func_def_0.args.args[0].arg = 'func_def'
    a_s_t_0.body = [func_def_0]
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.args = []
    call_0.func.id = 'super'
    func_def_0.body = [call_0]

# Generated at 2022-06-25 22:48:03.936402
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:48:06.586944
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_2 = None
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)

if __name__ == "__main__":
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:48:11.536148
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:48:15.641151
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = None
    call_2 = module_0.Call()
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_3 = super_without_arguments_transformer_2.visit_Call(call_2)
    super_without_arguments_transformer_3 = SuperWithoutArgumentsTransformer(a_s_t_1)



# Generated at 2022-06-25 22:48:17.457805
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)



# Generated at 2022-06-25 22:48:43.945440
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:48:48.253692
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    
    call_0 = module_0.Call()
    
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_1.visit_Call(call_0)

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:48:53.556725
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:56.324749
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:56.830442
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True

# Generated at 2022-06-25 22:49:03.658862
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:49:05.409002
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:49:07.895846
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.parse("2 + 3")
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    


# Generated at 2022-06-25 22:49:13.175966
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_2 = None
    call_2 = module_0.Call()
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)
    call_3 = super_without_arguments_transformer_2.visit_Call(call_2)

# Generated at 2022-06-25 22:49:13.650820
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:50:10.778545
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:50:12.888259
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:14.580713
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:50:17.180779
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_0 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:19.246753
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:50:20.364440
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer(tree)



# Generated at 2022-06-25 22:50:23.266728
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:24.161373
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_argumen

# Generated at 2022-06-25 22:50:25.744115
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:35.713824
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    call_0 = module_0.Call()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_2 = module_0.Call()
    functiondef_0 = module_0.FunctionDef()
    functiondef_0.args = module_0.arguments()
    functiondef_0.args.args = [module_0.arg()]
    functiondef_0.name = 'functiondef_0'
    clsdef_0 = module_0.ClassDef()
