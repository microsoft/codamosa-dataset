

# Generated at 2022-06-25 22:42:01.662989
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:42:04.316432
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    call_0 = module_0.Call()
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:42:06.267881
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except:
        import traceback
        traceback.print_exc()


# Generated at 2022-06-25 22:42:07.177053
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:42:14.874203
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    node_0 = module_0.Name()
    super_without_arguments_transformer_0.visit_Name(node_0)
    node_1 = module_0.FunctionDef()
    super_without_arguments_transformer_0.visit_FunctionDef(node_1)
    node_2 = module_0.ClassDef()
    super_without_arguments_transformer_0.visit_ClassDef(node_2)
    node_3 = module_0.Module()
    super_without_arguments_transformer_0.visit_Module(node_3)
    node_4 = module_0.Ex

# Generated at 2022-06-25 22:42:17.450446
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0) # TYPE: SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:42:23.683791
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    assert isinstance(super_without_arguments_transformer_0, module_0.NodeTransformer)
    assert super_without_arguments_transformer_0.target == (2, 7)


# Generated at 2022-06-25 22:42:31.508246
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    call_0 = module_0.Call()
    func_0 = module_0.Name()
    func_0.id = 'super'
    call_0.func = func_0
    call_0.keywords = list()
    call_0.starargs = None
    call_0.kwargs = None
    call_0.args = list()

    super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:42:38.893121
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_0.parse("""def foo():\n    super()""")
    a_s_t_0.body[0].body.append(module_0.Expr(value=module_0.Call(func=module_0.Name(id='super', ctx=module_0.Load()), args=[], keywords=[])))
    super_without_arguments_transformer_0.generic_visit(a_s_t_0)
    assert str(a_s_t_0) == """def foo():\n    super(C, self)\n    super()"""


# Generated at 2022-06-25 22:42:43.139657
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)

    call_0 = module_0.Call()

    super_without_arguments_transformer_1.visit_Call(call_0)

# Generated at 2022-06-25 22:42:56.666492
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    c_a_l_l_0 = module_0.Call()
    n_a_m_e_0 = SuperWithoutArgumentsTransformer._replace_super_args(super_without_arguments_transformer_0, c_a_l_l_0)
    n_a_m_e_0 = super_without_arguments_transformer_0.visit_Call(c_a_l_l_0)
    assert n_a_m_e_0.args == c_a_l_l_0.args
    return None

# Generated at 2022-06-25 22:43:06.589243
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    target_0_0 = module_0.Call()
    target_0_0.args = list()
    target_0_0.keywords = list()
    target_0_0.func = module_0.Name()
    target_0_0.func.id = 'super'
    target_0_0.func.ctx = module_0.Load()
    super_without_arguments_transformer_0.visit_Call(target_0_0)
    assert(super_without_arguments_transformer_0._tree_changed == True)


# Generated at 2022-06-25 22:43:08.512119
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    unit_test_SuperWithoutArgumentsTransformer_0 = test_case_0()


# Generated at 2022-06-25 22:43:10.973507
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:18.461110
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    func_2 = module_0.Call(func=module_0.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None)
    call_3 = super_without_arguments_transformer_1.visit_Call(func_2)
    assert call_3


# Generated at 2022-06-25 22:43:25.000427
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None

# Generated at 2022-06-25 22:43:29.150061
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # The next line fails, because the base class method doesn't actually exist
    # super_without_arguments_transformer_0.get_tree()


# Generated at 2022-06-25 22:43:32.411146
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:43:40.566042
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()

    # Call to SuperWithoutArgumentsTransformer()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == False

# Generated at 2022-06-25 22:43:48.768495
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Init
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    node_0 = module_0.Call()
    kwargs_0 = {'func': module_0.Name(id='super'), 'args': []}
    node_0 = module_0.Call(**kwargs_0)
    node_0.args = []

    # Call
    node_0 = super_without_arguments_transformer_0.visit_Call(node_0)

    # Asserts
    assert node_0.func.id == 'super'
    assert node_0.args



# Generated at 2022-06-25 22:43:56.741752
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-25 22:44:00.607146
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(type(super_without_arguments_transformer_0) == type(SuperWithoutArgumentsTransformer(None)))


# Generated at 2022-06-25 22:44:04.047130
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:12.286559
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    module_0.FunctionDef()
    module_0.arguments()
    module_0.arguments()
    module_0.Name()
    super_without_arguments_transformer_0.generic_visit()
    module_0.Name()
    super_without_arguments_transformer_0.generic_visit()
    super_without_arguments_transformer_0.visit_Call()
    module_0.Call()
    module_0.Name()
    module_0.arguments()
    super_without_arguments_transformer_0.generic_visit()
    module_0.Name()
    super

# Generated at 2022-06-25 22:44:20.422631
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # should be able to detect the following syntax
    assert SuperWithoutArgumentsTransformer.has_target_syntax((2,)) == False
    assert SuperWithoutArgumentsTransformer.has_target_syntax((2, 1)) == False
    assert SuperWithoutArgumentsTransformer.has_target_syntax((2, 2)) == False
    assert SuperWithoutArgumentsTransformer.has_target_syntax((2, 3)) == False
    assert SuperWithoutArgumentsTransformer.has_target_syntax((2, 4)) == False
    assert SuperWithoutArgumentsTransformer.has_target_syntax((2, 5)) == False
    assert SuperWithoutArgumentsTransformer.has_target_syntax((2, 6)) == False
    assert SuperWithoutArgumentsTransformer.has_target_syntax((2, 7)) == True
    assert SuperWithoutArg

# Generated at 2022-06-25 22:44:24.171848
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Setup
    
    # Test
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(module_0.AST())


# Generated at 2022-06-25 22:44:24.655349
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:44:29.056824
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = super_without_arguments_transformer_0.visit_Call(module_0.Call())
    assert(call_0 == module_0.Call())

# Generated at 2022-06-25 22:44:29.870094
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()



# Generated at 2022-06-25 22:44:33.955767
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  a_s_t_0 = module_0.AST()
  super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
  assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:44:41.173891
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:46.221748
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_2)
    list_1 = [a_s_t_2, a_s_t_2]
    call_2 = module_0.Call(*list_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)
    assert call_3 == call_2

# Generated at 2022-06-25 22:44:50.562532
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:55.336370
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:59.944785
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:04.894256
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_78 = module_0.AST()
    super_without_arguments_transformer_78 = SuperWithoutArgumentsTransformer(a_s_t_78)
    list_78 = [a_s_t_78, a_s_t_78]
    call_78 = module_0.Call(*list_78)
    call_79 = super_without_arguments_transformer_78.visit_Call(call_78)

# Generated at 2022-06-25 22:45:05.679180
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:45:06.632769
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:45:10.607615
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    
test_case_0()
test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:45:16.590675
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Set up
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)

    # Invoke method
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

    # Check results
    assert call_1==call_0

# Generated at 2022-06-25 22:45:22.072661
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:45:26.404019
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert super_without_arguments_transformer_0.tree == a_s_t_0


# Generated at 2022-06-25 22:45:27.162651
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:45:27.952372
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:45:30.093459
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)

    assert super_without_arguments_transformer_1 is not None


# Generated at 2022-06-25 22:45:33.485619
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:35.393672
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumen

# Generated at 2022-06-25 22:45:40.579935
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:44.613018
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:51.839063
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Create an instance of class SuperWithoutArgumentsTransformer
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer()

    assert(isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer))

    # Test property target
    assert(super_without_arguments_transformer_0.target == (2, 7))

    # Test property name
    assert(super_without_arguments_transformer_0.name == 'super-without-arguments')

    # Test method visit_Call
    test_case_0()

    # TODO: test the rest of class

# Generated at 2022-06-25 22:46:03.823705
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 == call_0

# Generated at 2022-06-25 22:46:09.883085
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [module_0.Attribute()]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

if (__name__ == '__main__'):
    test_case_0()
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:46:12.365180
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(object)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(object)
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:46:15.912972
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)  # type: ignore
    assert isinstance(super_without_arguments_transformer_1, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-25 22:46:17.667244
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-25 22:46:23.094085
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
  here = os.path.abspath(os.path.dirname(__file__)) # type: ignore

  t0 = threading.Thread(target=test_case_0)
  t1 = threading.Thread(target=test_case_0)
  t0.start()
  t1.start()
  t0.join()
  t1.join()
  assert None

import typing as tp


# Generated at 2022-06-25 22:46:28.072451
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:46:33.653997
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:46:36.685239
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        a_s_t_0 = module_0.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 22:46:45.020774
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    # assert type(super_without_arguments_transformer_0) == SuperWithoutArgumentsTransformer, 'super_without_arguments_transformer_0 should be of type SuperWithoutArgumentsTransformer'
    # assert super_without_arguments_transformer_0.target == (2, 7), 'super_without_arguments_transformer_0.target should be equal

# Generated at 2022-06-25 22:46:58.548202
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert a_s_t_0 == call_1
    
    
    
    
    
    
    
    
    
    
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   


# Generated at 2022-06-25 22:47:01.294296
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:03.694826
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:05.991072
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:08.803329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_1 = module_0.Call()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(module_0.AST())
    try:
        super_without_arguments_transformer_1.visit_Call(call_1)
        assert False
    except AttributeError:
        pass

# Generated at 2022-06-25 22:47:11.687586
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:47:15.609780
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()') 
    transformer = SuperWithoutArgumentsTransformer(tree)
    assert transformer._cls

    # there is redefinition of _cls in visit_Call, so
    # after first call of _visit_Call, _cls == None
    #assert transformer._cls


# Generated at 2022-06-25 22:47:22.532396
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    print(call_1)
    print(call_0)
    print(call_1)
    print(call_1)

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:47:23.413758
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:47:27.046375
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert hasattr(super_without_arguments_transformer_0, '_tree')
    assert hasattr(super_without_arguments_transformer_0, '_tree_changed')


# Generated at 2022-06-25 22:47:46.956765
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    list_1 = [a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = module_0.Call(*list_1)
    assert_0 = str(call_1.func)
    assert_1 = 'super'

    try:
        assert assert_0 == assert_1
    except AssertionError:
        raise AssertionError(('Expected {0} but got {1}'.format(assert_1, assert_0)))


# Generated at 2022-06-25 22:47:54.505015
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from cStringIO import StringIO
    from typed_ast import ast27
    from typed_astunparse import astunparse
    from .helpers import compile_source, assert_equal

    source = 'super()'
    expected = 'super(Cls, self)'

    tree = compile_source(source, 'exec', 'sub', 'ast27',
                          flags=ast.PyCF_ONLY_AST)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    typed_ast27 = ast27.AST()
    typed_ast27.copy_location(tree)
    typed_ast27.body = tree.body
    typed_ast27.filename = tree.filename

    out = StringIO()
    astunparse.Unparser(typed_ast27, out)
    result = out.getvalue

# Generated at 2022-06-25 22:47:57.305976
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:48:01.753944
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    test_case_0()

# Generated at 2022-06-25 22:48:04.143237
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:06.274273
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:11.712722
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert (call_1 == call_0)

# Generated at 2022-06-25 22:48:13.822006
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        test_case_0()
    except:
        print('test fail')
    else:
        print('test success')

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:48:16.583120
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 != None


# Generated at 2022-06-25 22:48:19.246846
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(super_without_arguments_transformer_0 is not None)
    

# Generated at 2022-06-25 22:48:47.572467
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    _ast = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(_ast)
    _ast_0 = super_without_arguments_transformer._ast
    assert _ast == _ast_0
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(_ast)
    assert super_without_arguments_transformer == super_without_arguments_transformer_0


# Generated at 2022-06-25 22:48:50.215507
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:52.929427
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:54.900629
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:48:57.049027
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:02.538892
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:06.718026
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:49:09.317642
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:10.218739
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:49:15.862648
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:50:19.674881
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:50:22.450990
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer))


# Generated at 2022-06-25 22:50:24.338260
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:24.996331
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:50:29.625345
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Pass AST object that matches type specification for a_s_t
    a_s_t_0 = module_0.AST()
    # Pass AST object that matches type specification for a_s_t
    a_s_t_1 = module_0.AST()

    # Tests instantiation of class SuperWithoutArgumentsTransformer
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)

    # Tests instantiation of class SuperWithoutArgumentsTransformer
    assert isinstance(super_without_arguments_transformer_1, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:50:39.711446
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [a_s_t_0, a_s_t_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert a_s_t_0 == call_1
    assert a_s_t_0 == call_0
    assert super_without_arguments_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:50:43.657703
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def test_case_0():
        a_s_t_0 = module_0.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
        list_0 = [a_s_t_0, a_s_t_0]
        call_0 = module_0.Call(*list_0)
        call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:50:45.509493
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:50:52.630759
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    list_1 = [a_s_t_1, a_s_t_1]
    call_2 = module_0.Call(*list_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)
# megalock

# Generated at 2022-06-25 22:50:55.928921
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_2)
    assert super_without_arguments_transformer_1 is not None
    assert super_without_arguments_transformer_1._tree is a_s_t_2
