

# Generated at 2022-06-25 22:42:01.895871
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = module_0.Call()
    assert super_without_arguments_transformer_0.visit_Call(a_s_t_1) is None

import chardet


# Generated at 2022-06-25 22:42:08.024619
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_1 = module_0.Call(func=module_0.Name(id='super', ctx=module_0.Load()), args=[], keywords=[], starargs=None, kwargs=None)
    super_without_arguments_transformer_0.visit_Call(a_s_t_1)

# Generated at 2022-06-25 22:42:13.844996
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1: module_0.AST = module_0.parse("x", "single", "exec")
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert super_without_arguments_transformer_1._tree_changed == False
    assert super_without_arguments_transformer_1.generic_visit(a_s_t_1) == None
    assert super_without_arguments_transformer_1._tree_changed == False

# Generated at 2022-06-25 22:42:16.241356
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:19.785821
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)

# Unit test
# Tests that the transformer visits all nodes in list order and replaces whitespace-only tokens with underscores

# Generated at 2022-06-25 22:42:23.101995
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:42:23.952811
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True == True


# Generated at 2022-06-25 22:42:27.925891
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert_equal(super_without_arguments_transformer_0._tree, a_s_t_0)


# Generated at 2022-06-25 22:42:33.457452
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(a_s_t)
    module_0.Call()
    typed_ast.mod
    super_without_arguments_transformer.visit_Call(class_0)
    return

if (__name__ == '__main__'):
    test_case_0()
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:42:37.211379
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    ast_0_0 = module_0.Call()
    super_without_arguments_transformer_0.visit_Call(ast_0_0)

# Generated at 2022-06-25 22:42:48.888793
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(None)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    call_0.args = [None]
    call_2 = super_without_arguments_transformer_0.visit_Call(call_0)
    call_0.args = [None]
    call_3 = super_without_arguments_transformer_0.visit_Call(call_0)
    call_1.func = call_0
    call_4 = super_without_arguments_transformer_0.visit_Call(call_1)
    call_1.func = call_0
    call_5 = super_without_arguments_

# Generated at 2022-06-25 22:42:57.985683
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import astor
    import sys
    a_s_t_2 = ast.AST()
    a_s_t_0 = ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = ast.Call()
    call_0 = call_1
    assert isinstance(call_0, ast.Call)
    call_0.keywords = []
    assert call_0.keywords == []
    call_0.starargs = None
    assert call_0.starargs is None
    call_0.kwargs = None
    assert call_0.kwargs is None
    call_0.func = None
    assert call_0.func is None
    call_0.args = []
    assert call_0

# Generated at 2022-06-25 22:43:01.359079
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert type(super_without_arguments_transformer_0) == SuperWithoutArgumentsTransformer


# Generated at 2022-06-25 22:43:05.683517
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:43:09.318060
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None

# Generated at 2022-06-25 22:43:13.608525
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Test
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    
    # Test
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    


# Generated at 2022-06-25 22:43:20.484701
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        a_s_t_0 = module_0.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
        assert super_without_arguments_transformer_0.tree == a_s_t_0
    except:
        __tracebackhide__ = True
        raise



# Generated at 2022-06-25 22:43:25.119136
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:43:30.171563
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.args = []
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:31.620894
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True

# Unit tests for function _replace_super_args of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:43:41.559899
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:43:46.017572
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:43:51.189886
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .transformer import SuperWithoutArgumentsTransformer
    tree = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(tree)
    test_case = [
        (Transformer(tree), transformer)
    ]
    for transformer_1, transformer_2 in test_case:
        transformer_2.visit_Call()
        if not transformer_1 == transformer_2:
            return False
    return True

# Generated at 2022-06-25 22:43:55.626278
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    try:
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    except:
        print("Test failed: Exception thrown")

if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()
    test_case_0()

# Generated at 2022-06-25 22:43:58.014646
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:04.802607
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        a_s_t_0 = module_0.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    except NotImplementedError as e:
        raise Exception("Cannot execute super_without_arguments.super_without_arguments_transformer.TestCase_0.test_SuperWithoutArgumentsTransformer") from e  # type: ignore
    else:
        print("test_SuperWithoutArgumentsTransformer is executed.")


# Generated at 2022-06-25 22:44:08.151790
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # See setup call above.
    assert call_1 == call_0
    # See setup call above.
    assert call_1 == call_0
    # See setup call above.
    assert call_1 == call_0
    # See setup call above.
    assert call_1 == call_0

# Generated at 2022-06-25 22:44:13.483224
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    i_0 = 2
    i_1 = 7
    super_without_arguments_transformer_1_0 = SuperWithoutArgumentsTransformer()
    assert super_without_arguments_transformer_1_0.target == (i_0, i_1), "super_without_arguments_transformer_1_0.target: {} is not equal to: {}".format(super_without_arguments_transformer_1_0.target, (i_0, i_1))


# Generated at 2022-06-25 22:44:21.844884
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    module_0.Call.args = (call_0, ())
    module_0.Call.keywords = (call_0, ())
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    if (not call_1):
        raise ValueError('Not equal')


if (__name__ == '__main__'):
    import os
    import sys
    import logging
    logging.basicConfig(level=logging.INFO)
    # logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    script

# Generated at 2022-06-25 22:44:23.835812
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:44:38.941669
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    # Assign values to the following fields of class SuperWithoutArgumentsTransformer
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:44:44.707085
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    class_def_0 = module_0.ClassDef()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.args = []
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert(isinstance(call_0.func, module_0.Name))

# Generated at 2022-06-25 22:44:47.541242
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test with default arguments
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    
    
    
    


# Generated at 2022-06-25 22:44:49.275127
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

import typed_ast._ast3 as module_0
import _ast as module_1


# Generated at 2022-06-25 22:44:54.616297
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Asserts that the two objects are equal
# Parameter 'actual' is the object produced
# Parameter 'expected' is the object that 'actual' is expected to equal

# Generated at 2022-06-25 22:44:57.217504
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()


# Generated at 2022-06-25 22:45:00.961593
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:04.591033
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        a_s_t_0 = module_0.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
        assert super_without_arguments_transformer_0 is not None
    except:
        assert False


# Generated at 2022-06-25 22:45:08.618146
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    print(super_without_arguments_transformer_0)



# Generated at 2022-06-25 22:45:14.969807
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert isinstance(super_without_arguments_transformer_0.target, tuple) == True
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert isinstance(super_without_arguments_transformer_0.target, tuple) == True


# Generated at 2022-06-25 22:45:41.041992
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Arrange
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()

    # Act
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

    # Assert
    assert call_1 == call_0

# Generated at 2022-06-25 22:45:45.316198
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = modeule
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    pass



# Generated at 2022-06-25 22:45:46.545807
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer(module_0.AST()) != None

# Generated at 2022-06-25 22:45:48.929795
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Constructor test
    a_s_t_0 = module_0.AST()
    assert isinstance(SuperWithoutArgumentsTransformer(a_s_t_0), SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:45:55.396661
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:46:03.441934
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.args = []
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 is None, "visit_Call returns incorrect value"


# Generated at 2022-06-25 22:46:04.164975
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:46:09.688589
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert super_without_arguments_transformer_0._tree_changed == False

# Unit tests for visit_Call

# Generated at 2022-06-25 22:46:14.358637
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

if __name__ == '__main__':
    import pytest
    pytest.main(['-q', __file__])

# Generated at 2022-06-25 22:46:17.850076
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    if sys.version_info[0] != 2 or sys.version_info[1] < 7:
        import pytest
        pytest.skip("super() outside of class")
    try:
        test_case_0()
    except:
        print("Exception in test case 0")
        raise

# Generated at 2022-06-25 22:47:05.042046
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:09.434494
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

if __name__ == "__main__":
    import sys
    import nose2
    sys.exit(nose2.main())

# Generated at 2022-06-25 22:47:13.039606
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Instantiate an instance of class SuperWithoutArgumentsTransformer
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)

    assert super_without_arguments_transformer_1 is not None, \
        'Failed to instantiate SuperWithoutArgumentsTransformer'


# Generated at 2022-06-25 22:47:15.355958
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:19.832917
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.python_source import PythonSource
    from .transformers import SuperWithoutArgumentsTransformer
    from ..utils.helpers import assert_source_equal
    from ..exceptions import InvalidSource

    source_0 = '''
a = b
c = d
        
'''
    expected_0 = '''
a = b
c = d
        
'''

# Generated at 2022-06-25 22:47:25.776803
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = importlib.import_module('typed_ast._ast3')
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.t == module_0.AST
    assert super_without_arguments_transformer_0.target == (2, 7)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:26.417040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:47:33.912334
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef()
    function_def_0.args = module_0.arguments()
    function_def_0.args.args = []
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.func.id = '0'
    call_0.args = []
    super_without_arguments_transformer_0._tree.body = [function_def_0]
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:47:36.927948
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:47:40.494123
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:48:33.992243
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert isinstance(SuperWithoutArgumentsTransformer(), SuperWithoutArgumentsTransformer),\
        "Constructor not functioning for 'SuperWithoutArgumentsTransformer'"

# Generated at 2022-06-25 22:48:43.991014
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.tree_changed == False
    assert super_without_arguments_transformer_0.tree == module_0.AST()
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert super_without_arguments_transformer_0.VERSION == (2, 7)


# Generated at 2022-06-25 22:48:47.743291
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)

test_case_0()
test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:48:51.814802
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:48:53.761771
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:57.542046
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.target == (2, 7), "Expected (%d, %d), but got %r" % (2, 7, super_without_arguments_transformer_0.target)

# Generated at 2022-06-25 22:49:08.370273
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

a_s_t_0 = module_0.AST()
assert isinstance(a_s_t_0, module_0.AST)
call_0 = module_0.Call()
assert isinstance(call_0, module_0.Call)
super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
assert isinstance(call_1, module_0.Call)

# Generated at 2022-06-25 22:49:14.345664
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    #
    # Call target code
    #
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    #
    # Tested code
    #


# Generated at 2022-06-25 22:49:16.694919
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:18.056108
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


if __name__ == '__main__':
    import pytest
    import sys
    pytest.main(sys.argv)

# Generated at 2022-06-25 22:51:25.390029
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert not hasattr(super_without_arguments_transformer_0, '_replace_super_args') # verify private attribute does not exist
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


if __name__ == '__main__':
    test_case_0()
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:51:28.816840
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert_equal(call_0, call_1)



# Generated at 2022-06-25 22:51:32.441200
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:51:34.918291
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:51:39.808184
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.func.id = "super"
    call_0.args = []
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:51:46.855892
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


if __name__ == '__main__':
    import typing
    import typed_ast.ast3 as ast
    from typed_ast.transforms.type_comment import TypeCommentTransformer
    import sys
    import astor
    sys.setrecursionlimit(10000)

# Generated at 2022-06-25 22:51:48.874491
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)


# Generated at 2022-06-25 22:51:51.517075
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_2)
