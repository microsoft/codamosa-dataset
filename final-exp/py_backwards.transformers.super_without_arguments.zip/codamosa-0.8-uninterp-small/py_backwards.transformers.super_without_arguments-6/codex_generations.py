

# Generated at 2022-06-25 22:42:03.616659
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:42:06.396573
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:13.240720
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    args_0 = (ast.Call(func=(ast.Name(id='super', ctx=(ast.Load(lineno=1, col_offset=8)))), args=(), keywords=(), starargs=None, kwargs=None),)
    kwargs_0 = {}
    function_1 = SuperWithoutArgumentsTransformer.visit_Call(*args_0, **kwargs_0)
    # assert function_1.__doc__ == 'Compiles:\n        super()\n    To:\n        super(Cls, self)\n        super(Cls, cls)\n            \n    '


# Generated at 2022-06-25 22:42:16.241150
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    module_0.Call()
    pass


# Generated at 2022-06-25 22:42:19.786362
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    return (a_s_t_0, super_without_arguments_transformer_0)


# Generated at 2022-06-25 22:42:27.174296
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    source_code_0 = 'super()'
    source_code_tree_0 = parser.parse(source_code_0)
    a_s_t_0._reset_fields()
    a_s_t_0.body = source_code_tree_0.body
    super_without_arguments_transformer_0.visit(a_s_t_0)

# Generated at 2022-06-25 22:42:29.757728
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:42:34.812424
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Assertions:
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    assert super_without_arguments_transformer_0._tree is a_s_t_0



# Generated at 2022-06-25 22:42:38.510340
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    assert isinstance(super_without_arguments_transformer_0, module_0.NodeTransformer)

# Generated at 2022-06-25 22:42:42.666304
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:42:54.645000
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)

    # Test with raising node not found
    def visit_FunctionDef():
        def visit_Call(node):
            node_id = "node-id-0"
            try:
                raise NodeNotFound(node_id)
            except NodeNotFound as node_not_found_0:
                assert node_not_found_0.node_id == node_id
                try:
                    raise node_not_found_0
                except NodeNotFound as node_not_found_1:
                    assert node_not_found_1.node_id == node_id


# Generated at 2022-06-25 22:42:57.752290
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:43:00.464091
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:43:03.018193
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# test_case_1

# Generated at 2022-06-25 22:43:07.972950
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    module_0.Call(func=module_0.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None)

# Generated at 2022-06-25 22:43:11.822798
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:21.071412
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    if callable(super_without_arguments_transformer_0.generic_visit):
        super_without_arguments_transformer_0.generic_visit(module_0.AST())
    if callable(super_without_arguments_transformer_0.visit_Call):
        super_without_arguments_transformer_0.visit_Call(module_0.AST())


# Generated at 2022-06-25 22:43:25.650079
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    assert isinstance(a_s_t_0, module_0.AST)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:43:30.971180
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    name_0 = module_0.Name()
    name_0.id = "super"
    call_0.func = name_0
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:39.047397
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    node_0: module_0.Call = module_0.Call()
    node_1: module_0.Call = super_without_arguments_transformer_0.visit_Call(node_0)

# Generated at 2022-06-25 22:43:46.661581
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        a_s_t_0 = module_0.AST()
    except:
        a_s_t_0 = None
    try:
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    except:
        super_without_arguments_transformer_0 = None

    assert(super_without_arguments_transformer_0 is not None)

# Generated at 2022-06-25 22:43:49.232966
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:52.543530
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:43:58.014417
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


if __name__ == '__main__':
    import __main__
    test_names = [
        'test_SuperWithoutArgumentsTransformer',
        'test_case_0'
    ]

    for test_name in test_names:
        test_case = getattr(__main__, test_name)
        test_case()

# Generated at 2022-06-25 22:44:00.636868
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:05.040807
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:44:09.025088
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    try:
        super_without_arguments_transformer_0.visit(a_s_t_0)
    except AttributeError:
        pass


# Generated at 2022-06-25 22:44:17.418169
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    functiondef_0 = module_0.FunctionDef()
    super_without_arguments_transformer_0._set_tree(functiondef_0)
    super_without_arguments_transformer_0.generic_visit(call_0)
    name_0 = module_0.Name()
    super_without_arguments_transformer_0._stack.append(name_0)
    super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:21.426095
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    visit_Call_0 = module_0.Call()
    super_without_arguments_transformer_0.visit_Call(visit_Call_0)

# Generated at 2022-06-25 22:44:22.047805
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:44:29.921243
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_1 = {}
    a_s_t_1 = module_0.AST(**dict_1)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert_equal("<SuperWithoutArgumentsTransformer for '2.7'>", super_without_arguments_transformer_1.__repr__())
    return "SuperWithoutArgumentsTransformer is OK"


# Generated at 2022-06-25 22:44:33.368242
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:36.053974
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {'print': None}
    a_s_t_0 = module_0.AST(dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:44:42.839669
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)
    dict_1 = {}
    dict_1['_tree_changed'] = None
    dict_1['_tree'] = module_0.AST()
    assert (super_without_arguments_transformer_0.__dict__ == dict_1)


# Generated at 2022-06-25 22:44:46.257972
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:44:50.637572
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {'func': 'super', 'args': []}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:55.120173
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)



# Generated at 2022-06-25 22:44:59.429960
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:00.235408
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TODO: please implement it
    pass

# Generated at 2022-06-25 22:45:09.634737
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == None
    assert not super_without_arguments_transformer_0._futurize_cont and super_without_arguments_transformer_0._futurize_source == None
    assert not super_without_arguments_transformer_0._source_has_future_import and super_without_arguments_transformer_0._target == (2, 7)

# Generated at 2022-06-25 22:45:17.558619
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)



# Generated at 2022-06-25 22:45:20.558159
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    return


# Generated at 2022-06-25 22:45:21.052831
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass




# Generated at 2022-06-25 22:45:27.120167
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Verify condition #1
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree is a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == False
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:33.280836
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    

if __name__ == '__main__':
    import sys
    import __main__
    
    if sys.version_info < (3, 0, 0):
        # Python 2 does not support type annotations
        test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:45:34.241318
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:45:35.120387
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:45:39.745241
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:45:46.625905
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:45:55.666648
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {
        'args': [],
        'keywords': [],
        'func': module_0.Name(**{'id': 'super', 'ctx': module_0.Load()}),
        'starargs': None,
        'kwargs': None
    }
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:12.470598
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.visit_Call(call_0) == call_0
    assert super_without_arguments_transformer_0.visit_Call(call_0) == call_0
    dict_1 = {}
    call_1 = module_0.Call(**dict_1)
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert super_without

# Generated at 2022-06-25 22:46:20.785852
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {'col_offset': 0, 'keywords': [], 'starargs': None, 'args': [], 'kwargs': None, 'func': module_0.Name(**{'id': 'super', 'ctx': module_0.Load()}), 'lineno': 0}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 is not None

# Generated at 2022-06-25 22:46:25.648561
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {'args': [], 'keywords': [], 'func': module_0.Name(id='super')}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:28.291093
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:36.728622
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {'body': [], 'decorator_list': [], 'name': 'Foo',
              'lineno': 1, 'col_offset': 0}
    classdef_0 = module_0.ClassDef(**dict_0)
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    dict_0 = {'name': 'x', 'col_offset': 8, 'lineno': 2}
    name_0 = module_0.Name(**dict_0)
    dict_0 = {'func': call_0, 'args': [name_0], 'col_offset': 4, 'lineno': 2}
    expr_0 = module_0.Expr(**dict_0)

# Generated at 2022-06-25 22:46:40.793624
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:46:43.855089
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:46:47.132335
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    module_ast_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_ast_0)
    assert (super_without_arguments_transformer_0 is not None)

# Generated at 2022-06-25 22:46:49.248108
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:46:50.388569
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # FIXME: how to use test_case_0 ?
    test_case_0()

# Generated at 2022-06-25 22:47:18.056908
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

if __name__=="__main__":
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:47:25.428859
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_t_1 = {}
    a_s_t_t_1 = module_0.AST(**dict_t_1)
    super_without_arguments_transformer_t_1 = SuperWithoutArgumentsTransformer(a_s_t_t_1)
    assert super_without_arguments_transformer_t_1._tree is a_s_t_t_1
    dict_t_2 = {}
    classdef_t_2 = module_0.ClassDef(**dict_t_2)
    classdef_t_2.name = 'A'
    dict_t_3 = {}
    arguments_t_3 = module_0.arguments(**dict_t_3)
    dict_t_4 = {}

# Generated at 2022-06-25 22:47:26.556585
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:47:30.960354
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:47:31.417320
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True

# Generated at 2022-06-25 22:47:34.513513
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Test constructor for 1 attribute
    try:
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    except:
        super_without_arguments_transformer_0 = None
    assert super_without_arguments_transformer_0 != None


# Generated at 2022-06-25 22:47:35.691723
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(**{})


# Generated at 2022-06-25 22:47:36.362626
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:47:37.552779
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:47:45.228896
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {'keywords': [], 'args': [], 'func': module_0.Name(**{'id': 'super', 'ctx': module_0.Load()}), 'starargs': None, 'kwargs': None}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    dict_1 = {}
    call_2 = module_0.Call(**dict_1)
    if call_1 == call_2:
        raise AssertionError
    else:
        pass


# Generated at 2022-06-25 22:48:42.960329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:48:44.095606
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:48:48.450863
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 == call_0

# Generated at 2022-06-25 22:48:52.470422
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:48:55.968138
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:49:01.441587
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:09.428058
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    dict_1 = {}
    call_2 = module_0.Call(**dict_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)

# Generated at 2022-06-25 22:49:14.962913
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.target == (2, 7)



# Generated at 2022-06-25 22:49:16.696816
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # None input
    test_case_0()

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:49:17.617624
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

import unittest


# Generated at 2022-06-25 22:51:21.067664
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:51:24.212393
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:51:26.518172
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWit

# Generated at 2022-06-25 22:51:29.643792
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.tree == a_s_t_0

# Generated at 2022-06-25 22:51:30.280232
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:51:30.927090
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:51:35.709996
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:51:37.795674
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

if __name__ == "__main__":
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:51:39.806122
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    dict_0 = {}
    a_s_t_0 = module_0.AST(**dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:51:43.281366
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    dict_0 = {}
    call_0 = module_0.Call(**dict_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
