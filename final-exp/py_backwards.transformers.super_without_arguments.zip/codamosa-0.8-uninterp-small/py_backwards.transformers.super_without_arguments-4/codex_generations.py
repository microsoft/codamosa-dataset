

# Generated at 2022-06-25 22:42:06.869366
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert isinstance(super_without_arguments_transformer_1, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:42:11.415241
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 =  module_0.Call()
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:42:12.552372
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert callable(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:42:17.940441
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert not super_without_arguments_transformer_0._tree_changed
    

# Generated at 2022-06-25 22:42:27.585291
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    global a_s_t_0

    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert isinstance(super_without_arguments_transformer_0, BaseNodeTransformer)
    
    # Test for method generic_visit
    ast_1 = module_0.FunctionDef(name='a', args=None, body=None, decorator_list=[], returns=None)
    super_without_arguments_transformer_0.generic_visit(ast_1)

    # Test for method visit_Call
    a_s_t_0 = module_0.AST()
    super_without

# Generated at 2022-06-25 22:42:30.309364
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:42:38.166831
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    class_def_0 = module_0.ClassDef()
    function_def_0 = module_0.FunctionDef()
    call_0 = module_0.Call()
    arguments_0 = module_0.arguments()
    arg_0 = module_0.arg()
    name_0 = module_0.Name()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0.func = function_def_0
    call_0.args = arguments_0
    arguments_0.args = [arg_0]
    arg_0.arg = class_def_0
    class_def_0.name = super_without_arguments_transformer_0._replace_super_

# Generated at 2022-06-25 22:42:40.564327
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    global super_without_arguments_transformer_0
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:49.392271
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:42:58.369296
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(a_s_t_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(a_s_t_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer

# Generated at 2022-06-25 22:43:09.561840
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    attribute_0 = module_0.Name("super", module_0.Load())
    attribute_1 = module_0.Attribute("__class__", module_0.Load(), module_0.Load())
    attribute_2 = module_0.Attribute("__name__", module_0.Load(), module_0.Load())
    attribute_3 = module_0.Attribute("__name__", module_0.Load(), module_0.Load())
    attribute_4 = module_0.Attribute("__class__", module_0.Load(), module_0.Load())

# Generated at 2022-06-25 22:43:14.123843
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0_1 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0_1)
    call_0_0 = module_0.Call(module_0.Name('super', module_0.Load()), [])
    super_without_arguments_transformer_0.visit_Call(call_0_0)


# Generated at 2022-06-25 22:43:18.983007
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)



# Generated at 2022-06-25 22:43:24.407634
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.func = module_0.Name()
    call_0.args = []
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:32.813402
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    #
    # Create an AST of the following form
    #
    #  class A:
    #    def f(self):
    #      super()
    #
    a_s_t_0 = module_0.AST()
    classdef_0 = module_0.ClassDef(name='A', bases=[], keywords=[], body=[], decorator_list=[])
    functiondef_0 = module_0.FunctionDef(name='f', body=[], decorator_list=[], args=None, returns=None, type_comment=None)
    call_0 = module_0.Call(func=None, args=[], keywords=[], starargs=None, kwargs=None, type_comment=None)
    functiondef_0.body = [call_0]
    classdef_0.body = [functiondef_0]


# Generated at 2022-06-25 22:43:37.595298
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:43:41.321879
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(a_s_t_0)

# Generated at 2022-06-25 22:43:44.826814
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert not hasattr(SuperWithoutArgumentsTransformer, '__wrapped__')
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0.AST())
    assert hasattr(SuperWithoutArgumentsTransformer, '__wrapped__')


# Generated at 2022-06-25 22:43:48.382843
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:43:49.504382
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TODO: Put your test here:
    ...


# Generated at 2022-06-25 22:43:56.856857
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_2 = module_0.Call()
    try:
        super_without_arguments_transformer_0.visit_Call(a_s_t_2)
    except:
        pass



# Generated at 2022-06-25 22:44:04.574717
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    classDef = None
    functionDef = None
    call = None
    name = None
    name_0 = None
    call_0 = None
    super_without_arguments_transformer_0._replace_super_args(call)
    super_without_arguments_transformer_0.generic_visit(call_0)
    super_without_arguments_transformer_0.visit_Call(call)


# Generated at 2022-06-25 22:44:08.228790
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)

    call_2 = module_0.Call()
    super_without_arguments_transformer_2.visit(call_2)



# Generated at 2022-06-25 22:44:12.975948
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    a_s_t_1 = module_0.parse('\nfoo = super()\n')
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit(a_s_t_1)

test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:44:15.581533
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:19.791512
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    assert(super_without_arguments_transformer_0.tree == a_s_t_0)
    super_without_arguments_transformer_0._visit_Name(a_s_t_0)


# Generated at 2022-06-25 22:44:28.375495
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    name_0 = module_0.Name()
    name_0.id = "super"
    call_0 = module_0.Call()
    call_0.func = name_0
    call_0.args = []
    call_0.keywords = []
    try:
        assert_equal(super_without_arguments_transformer_0.visit_Call(call_0), call_0)
    except AssertionError as e:
        print(e)


if __name__ == '__main__':
    from typing import List


# Generated at 2022-06-25 22:44:31.508358
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:44:37.626842
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Test from line 110 of file test_super_without_arguments.py
    a_s_t_1 = module_0.parse("super")
    a_s_t_2 = module_0.parse("super()")
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    # method visit_Call of class SuperWithoutArgumentsTransformer
    assert super_without_arguments_transformer_1.visit_Call(a_s_t_2.body[0]) == a_s_t_1.body[0]


# Generated at 2022-06-25 22:44:45.819398
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .simple_name_replacer import SimpleNameReplacer
    from .super_without_arguments_transformer import SuperWithoutArgumentsTransformer
    from .static_method_to_class_method_transformer import StaticMethodToClassMethodTransformer


# Generated at 2022-06-25 22:44:49.796501
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-25 22:44:56.017790
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_0 == call_1

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:44:58.371627
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:59.571749
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass  # TODO: implement your test here


# Generated at 2022-06-25 22:45:05.121005
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 == module_0.Call()


# Generated at 2022-06-25 22:45:12.264046
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Test attributes
    assert isinstance(super_without_arguments_transformer_0._tree, ast.AST)
    assert super_without_arguments_transformer_0._tree_changed == False
    assert isinstance(super_without_arguments_transformer_0.target, tuple)
    assert super_without_arguments_transformer_0.target == (2, 7)
    # Test methods
    test_case_0()

# Generated at 2022-06-25 22:45:13.287036
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:45:15.698034
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        from typed_ast.transforms._test_case_0 import test_case_0
        test_case_0()
    except Exception:
        print("Test case 0 fails")


# Generated at 2022-06-25 22:45:18.158284
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:22.993354
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        SuperWithoutArgumentsTransformer(ast)
    except NameError as e:
        assert(str(e) == "name 'ast' is not defined")
    except UnboundLocalError as e:
        assert(str(e) == "local variable 'ast' referenced before assignment")
    except AttributeError as e:
        assert(str(e) == "'module' object has no attribute 'AST'")
    else:
        raise Exception('super() did not raise an exception')


# Generated at 2022-06-25 22:45:30.279389
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:31.876555
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    SuperWithoutArgumentsTransformer_0 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:45:32.539265
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:45:35.236876
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:45:38.475515
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, BaseNodeTransformer)


# Generated at 2022-06-25 22:45:38.955900
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-25 22:45:44.139295
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:46.701740
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(a_s_t)


# Generated at 2022-06-25 22:45:49.074488
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:51.413735
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-25 22:46:00.267025
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Call the constructor of class SuperWithoutArgumentsTransformer
    test_case_0()



# Generated at 2022-06-25 22:46:04.299773
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:46:09.267990
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:11.998451
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-25 22:46:14.392547
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:16.987822
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:20.668754
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

test_SuperWithoutArgumentsTransformer()
test_case_0()

# Generated at 2022-06-25 22:46:22.638937
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
  test_case_0()

if __name__ == '__main__':
  for t_case in [test_case_0]:
    t_case()

# Generated at 2022-06-25 22:46:24.904728
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:27.108164
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:46:42.196660
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:46:46.670421
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_2)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:46:51.399694
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:52.851297
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert issubclass(SuperWithoutArgumentsTransformer, BaseNodeTransformer)


# Generated at 2022-06-25 22:46:55.274930
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test if constructor will creates the required attributes
    assert SuperWithoutArgumentsTransformer.target == (2, 7)


# Generated at 2022-06-25 22:46:58.908578
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:47:01.755698
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:03.482621
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-25 22:47:06.339674
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    if __name__ == "__main__":
        test_case_0()


# Generated at 2022-06-25 22:47:07.117909
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer


# Generated at 2022-06-25 22:47:44.166100
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 =  SuperWithoutArgumentsTransformer(a_s_t_0)

    assert super_without_arguments_transformer_0 is not None

# Generated at 2022-06-25 22:47:45.753922
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:47:49.229110
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == False

test_case_0()
test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:47:53.188280
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    a_s_t_0 = ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = ast.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:57.897205
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:47:59.895681
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:02.581672
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except SystemExit:
        pass
    except:
        print("Test case 0 failed")
        print(traceback.print_exc())


# Generated at 2022-06-25 22:48:03.359368
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:48:07.350505
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    list_0 = [super_without_arguments_transformer_0]
    call_0 = Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:48:15.148194
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # constructor
    a_s_t_0 = module_0.AST(module_0.Module())
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # methods
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    module_0.FunctionDef()
    list_0 = [super_without_arguments_transformer_0]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    list_0 = [super_without_arguments_transformer_0]

# Generated at 2022-06-25 22:49:33.002148
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:49:33.569443
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:49:37.430881
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    attr_0 = super_without_arguments_transformer_1._tree
    assert (attr_0 == a_s_t_1)
    attr_1 = super_without_arguments_transformer_1.target
    assert (attr_1 == (2, 7))


# Generated at 2022-06-25 22:49:40.737167
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    print('Unit test for class SuperWithoutArgumentsTransformer')
    try:
        test_case_0()
        print('Pass!')
    except Exception:
        print('Fail!')

# Generated at 2022-06-25 22:49:44.896777
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert super_without_arguments_transformer_1.a_s_t == a_s_t_1


# Generated at 2022-06-25 22:49:46.775362
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:49.259956
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:50.936880
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:49:51.865851
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(a)

# Generated at 2022-06-25 22:49:53.765079
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
