

# Generated at 2022-06-25 22:42:04.930135
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    a_s_t_0_0 = module_0.AST()
    super_without_arguments_transformer_0_0 = SuperWithoutArgumentsTransformer(a_s_t_0_0)
    assert(super_without_arguments_transformer_0.tree == a_s_t_0)
    assert(super_without_arguments_transformer_0_0.tree == a_s_t_0_0)


# Generated at 2022-06-25 22:42:07.523222
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:42:11.079929
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

import typed_ast._ast27 as module_1


# Generated at 2022-06-25 22:42:16.273914
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.Str('foo')
    assert(a_s_t_1.s == 'foo')
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    super_without_arguments_transformer_1.visit_Call(a_s_t_1)
    assert(a_s_t_1.s == 'foo')
    a_s_t_2 = module_0.Str('foo')
    assert(a_s_t_2.s == 'foo')
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)
    super_without_arguments_transformer_2.visit_Call(a_s_t_2)


# Generated at 2022-06-25 22:42:18.870122
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:24.108731
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_2)
    call_0 = module_0.Call()
    # When
    result = super_without_arguments_transformer_0.visit_Call(call_0)
    # Then
    assert result is call_0

# Generated at 2022-06-25 22:42:33.416923
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)

# Generated at 2022-06-25 22:42:42.072853
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    a_s_t_3 = module_0.Name()
    a_s_t_3.id = "super"
    a_s_t_5 = module_0.arguments()
    a_s_t_6 = module_0.Name()
    a_s_t_6.id = "Cls"
    a_s_t_5.args = [a_s_t_6]
    a_s_t_7 = module_0.Name()
    a_s_t_7.id = "self"
    a_s_t_5.vararg = None
    a_s_t_5

# Generated at 2022-06-25 22:42:42.930502
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:42:48.581222
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_0.func = module_0.Name(id='super')
    call_0.args.append(module_0.Name(id='Cls'))
    super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:42:55.648525
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_object = SuperWithoutArgumentsTransformer(ast.parse('super()'))
    super_object._replace_super_args(ast.Call(func = ast.Name(id = 'super', ctx = ast.Load()), args = [], keywords = []))
    assert super_object == SuperWithoutArgumentsTransformer(ast.parse('super(Cls, self)'))

# Generated at 2022-06-25 22:42:56.463786
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:42:57.516583
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer.target == (2, 7)

# Generated at 2022-06-25 22:43:07.137786
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    input = ast.parse('foo(super())')
    transformer = SuperWithoutArgumentsTransformer()
    transformed_node = transformer.visit(input)

    assert isinstance(transformed_node, ast.Module)
    assert len(transformed_node.body) == 1

    assert isinstance(transformed_node.body[0], ast.Expr)
    assert isinstance(transformed_node.body[0].value, ast.Call)
    assert isinstance(transformed_node.body[0].value.func, ast.Name)
    assert transformed_node.body[0].value.func.id == 'foo'
    assert len(transformed_node.body[0].value.args) == 1
    assert isinstance(transformed_node.body[0].value.args[0], ast.Call)
    assert isinstance

# Generated at 2022-06-25 22:43:08.546082
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    obj = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-25 22:43:19.157334
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree_0 = parse(
        """
        class Foo:
            def bar(self):
                super()
        """
    )

    tree_1 = parse(
        """
        class Foo:
            def bar(self):
                super(Foo, self)
        """
    )

    tree_2 = parse(
        """
        class Foo:
            @staticmethod
            def bar():
                super()
        """
    )

    tree_3 = parse(
        """
        class Foo:
            @staticmethod
            def bar():
                super(Foo, cls)
        """
    )

    tree_4 = parse(
        """
        class Foo:
            @classmethod
            def bar(cls):
                super()
        """
    )


# Generated at 2022-06-25 22:43:25.888633
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Compile from source
    tree = ast.parse("super()")
    
    # Run the 'visit_Call' method of the transformer
    SuperWithoutArgumentsTransformer.visit_Call(ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))
    
    # Verify the expected output
    assert ast.dump(tree) == ast.dump(ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))


# Generated at 2022-06-25 22:43:27.246250
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()
    #test_case_1()

# Generated at 2022-06-25 22:43:30.383486
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree_0 = ast.parse(test_case_0.__doc__)
    tree_1 = ast.parse(test_case_0.__doc__)
    assert SuperWithoutArgumentsTransformer().visit(tree_0) == tree_1

# Generated at 2022-06-25 22:43:35.742632
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast_helpers import check_source

    # Test when node is not None but invalid class
    invalid_node = ast.Name()
    try:
        SuperWithoutArgumentsTransformer(invalid_node)
    except TypeError:
        pass

    # Test when node is not None but invalid class (2)
    invalid_node = ast.Module()
    try:
        SuperWithoutArgumentsTransformer(invalid_node)
    except TypeError:
        pass


# Unit test of methods of class SuperWithoutArgumentsTransformer
# Unit test of _replace_super_args defined in class SuperWithoutArgumentsTransformer
# Unit test of visit_Call defined in class SuperWithoutArgumentsTransformer

# Unit test of visit_Call defined in class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:43:41.763904
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:42.611874
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass


# Generated at 2022-06-25 22:43:51.737990
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None

    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    # assert call_1 == call_0, "Expected: call_1 == call_0, but got: " + str(call_1)

    print('Assertion passed.')

import sys
import pydevd
sys.path.append('.')
    
if __name__ == "__main__":
    pydevd.settrace('192.168.1.13', port = 5678, stdoutToServer = True, stderrToServer = True)
    # test_Super

# Generated at 2022-06-25 22:43:54.570104
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)
    assert super_without_arguments_transformer_0._tree == ast_0


# Generated at 2022-06-25 22:43:55.702573
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("test_SuperWithoutArgumentsTransformer")



# Generated at 2022-06-25 22:44:04.954106
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module_0 = typed_ast.ast3
    call_0 = module_0.Call()
    super_0 = None
    setattr(call_0, 'func', super_0)
    arg_0 = module_0.Name()
    arg_1 = module_0.Name()
    list_0 = [arg_0, arg_1]
    arguments_0 = module_0.arguments()
    setattr(arguments_0, 'args', list_0)
    setattr(call_0, 'args', arguments_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:44:08.943600
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = None
    super_without_arguments_transformer_0.visit_Call(call_0)
    return super_without_arguments_transformer_0


# Generated at 2022-06-25 22:44:11.266792
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    b_s_t_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:12.358725
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TODO: add test for constructor of class SuperWithoutArgumentsTransformer
    pass

# Generated at 2022-06-25 22:44:13.194390
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:44:19.346848
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 != None


# Generated at 2022-06-25 22:44:20.422353
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.AST()
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-25 22:44:22.980148
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print(type(SuperWithoutArgumentsTransformer(module_0.AST())))
    #assert(type(SuperWithoutArgumentsTransformer(module_0.AST())) == SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:44:24.651389
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)


# Generated at 2022-06-25 22:44:26.840245
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
	assert isinstance(SuperWithoutArgumentsTransformer(module_0.AST()), SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:44:29.561709
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:30.409353
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:44:34.392322
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:37.358509
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0) # type: ignore
    test_case_0()

# Generated at 2022-06-25 22:44:41.315139
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = None
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:44:54.835083
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_2 = None
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)
    assert call_3 is None


# Generated at 2022-06-25 22:44:58.820445
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        call_0 = None
        a_s_t_0 = module_0.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
        call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    except Exception as e:
        raise e

# Generated at 2022-06-25 22:45:03.406010
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # No exception
    super_without_arguments_transformer_0.visit_Call(call_0)


import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:45:08.016461
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:45:08.897096
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:45:11.302013
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:14.506547
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    v_0 = None
    c_0 = None
    module_0 = module_0
    v_1 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(v_0, v_1)

# Generated at 2022-06-25 22:45:18.501924
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:45:21.606502
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:28.210284
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert super_without_arguments_transformer_0._tree == a_s_t_1
    assert super_without_arguments_transformer_0._tree_changed == False
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert super_without_arguments_transformer_0._call_stack == []
    assert super_without_arguments_transformer_0.generic_visit(None) == None


# Generated at 2022-06-25 22:45:50.598781
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    call_1 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(None)
    call_2 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_0 == call_1 and call_1 == call_2


# Generated at 2022-06-25 22:45:55.708884
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:46:00.427083
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:46:03.328852
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)


# Generated at 2022-06-25 22:46:05.199679
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    assert SuperWithoutArgumentsTransformer(a_s_t_0) != None


# Generated at 2022-06-25 22:46:09.074999
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Initialize instance of class
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert hasattr(super_without_arguments_transformer_0, "_tree")


# Generated at 2022-06-25 22:46:11.795238
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)

    assert (super_without_arguments_transformer_0._tree is ast_0)


# Generated at 2022-06-25 22:46:15.190823
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = None
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:24.126097
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    classdef_0 = None
    call_0 = module_0.Call(
        ast.Name(id="extra", ctx=ast.Load()),
        []
    )
    class_0 = module_0.ClassDef(
        "DemoClass",
        [],
        None,
        [],
        [],
        []
    )
    functiondef_0 = module_0.FunctionDef(
        "demo",
        module_0.arguments(
            [],
            None,
            None,
            []
        ),
        [
            module_0.Expr(call_0)
        ],
        []
    )
    arguments_0 = module_0.arguments(
        [],
        None,
        None,
        []
    )

# Generated at 2022-06-25 22:46:28.181902
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Case: super(Cls, self)
    # Expected: super(Cls, self)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None



# Generated at 2022-06-25 22:47:10.256951
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:47:13.664835
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import io

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        test_case_0()
        assert out.getvalue() == ''
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-25 22:47:16.380390
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:20.873914
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert isinstance(super_without_arguments_transformer_0._tree, module_0.AST)


# Generated at 2022-06-25 22:47:27.665210
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 is not None
    assert call_1 is call_0
    call_0 = module_0.Call()
    call_0.starargs = []
    call_0.args = []
    call_0.kwargs = []
    call_0.func = module_0.Name()
    call_0.func.ctx = module_0.Load()
    call_0.func.id = str()
    a_s_t_0 = module_0.AST()
    super

# Generated at 2022-06-25 22:47:30.958014
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    return None


# Generated at 2022-06-25 22:47:32.148579
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:33.295292
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:35.660060
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    
    # Set the tree without the constructor parameter
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)



# Generated at 2022-06-25 22:47:36.910546
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer(None)
    assert t is not None


# Generated at 2022-06-25 22:49:16.190025
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TODO: Stubs were not generated for class 'Call' in module '_ast3'
    # TODO: Stubs were not generated for class 'AST' in module '_ast3'
    call_2 = None
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)


# Generated at 2022-06-25 22:49:18.057960
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:49:24.102957
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    call_0 = ast.Call()
    a_s_t_0 = ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert type(call_1) == ast.Call
    # assert call_1.  == 
    # assert call_1.  == 
    # assert call_1.  == 
    # assert call_1.  == 
    assert call_1.keywords == []
    # assert call_1.  == 
    assert call_1.starargs is None and call_1.kwargs is None


# Generated at 2022-06-25 22:49:28.919592
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class ClassDef_0(module_0.ClassDef):
        def __init__(self, name, x: int) -> None:
            self.name = name
            self.foo = x
        def __hash__(self) -> int:
            return hash((type(self), self.name, self.foo))
        def __eq__(self, other:'ClassDef_0') -> bool:
            return (type(self) == type(other) and
                    self.name == other.name and
                    self.foo == other.foo)
        def __repr__(self) -> str:
            return '%s(%s, %d)' % (type(self).__name__, self.name, self.foo)

# Generated at 2022-06-25 22:49:31.437339
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  ast0 = None
  super_without_arguments_transformer0 = SuperWithoutArgumentsTransformer(ast0)
  return super_without_arguments_transformer0

from ..exceptions import TransformerNotSuitable
if __name__ == '__main__':
    a = test_SuperWithoutArgumentsTransformer()
    print(a)

# Generated at 2022-06-25 22:49:32.406051
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


from ..utils.decorators import version_range_decorator


# Generated at 2022-06-25 22:49:35.636171
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

    return (call_0, a_s_t_0, super_without_arguments_transformer_0, call_1)

# Generated at 2022-06-25 22:49:39.161484
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)
    super_without_arguments_transformer_0 = None


# Generated at 2022-06-25 22:49:42.678849
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    name_0 = module_0.Name()
    super_without_arguments_transformer_0.visit_Name(name_0)


# Generated at 2022-06-25 22:49:46.294350
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_2 = None
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)