

# Generated at 2022-06-25 22:41:54.775177
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:42:06.449678
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import io
    from contextlib import redirect_stdout
    from io import StringIO
    from typed_ast import ast3 as ast

    f = StringIO()
    with redirect_stdout(f):
        a_s_t_0 = ast.AST()
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
        functiondef_0 = ast.FunctionDef(name='foo',args=ast.arguments(args=[ast.arg(arg='bar',annotation=None)],vararg=None,kwonlyargs=[],kw_defaults=[],kwarg=None,defaults=[]),body=[ast.Call(func=ast.Name(id='super'),args=[],keywords=[])],decorator_list=[],returns=None)
        super_without_arg

# Generated at 2022-06-25 22:42:14.500507
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    # Call typed_ast.ast3.Call to create an instance of Call
    call_0 = module_0.Call(
        func=module_0.Name(id='super'),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None
    )

    # Call class SuperWithoutArgumentsTransformer method visit_Call

# Generated at 2022-06-25 22:42:15.610354
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Unit test of visit_Call method of SuperWithoutArgumentsTransformer class

# Generated at 2022-06-25 22:42:18.867864
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    print(super_without_arguments_transformer_1)


# Generated at 2022-06-25 22:42:20.948334
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # TODO: implement unit test
    # assert super_without_arguments_transformer.visit_Call() == expected_value
    assert True # TODO: implement test


# Generated at 2022-06-25 22:42:31.015963
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    function_def_0 = module_0.FunctionDef(name='foo', args=module_0.arguments(args=[module_0.Name(id='p_0', ctx=module_0.Param())], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[module_0.Expr(value=module_0.Call(func=module_0.Name(id='super', ctx=module_0.Load()), args=[], keywords=[]))], decorator_list=[], returns=None)
    super_without_arguments_transformer_0._replace_super_

# Generated at 2022-06-25 22:42:34.889497
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    node_0 = None
    
    assert super_without_arguments_transformer_0.visit_Call(node_0) is None

# Generated at 2022-06-25 22:42:37.519393
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:42:46.734189
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # Test if fields of class SuperWithoutArgumentsTransformer "hasattr"
    if (not hasattr(super_without_arguments_transformer_0, "generic_visit")):
        raise AssertionError()
    # Test if fields of class SuperWithoutArgumentsTransformer "hasattr"
    if (not hasattr(super_without_arguments_transformer_0, "_tree")):
        raise AssertionError()
    # Test if fields of class SuperWithoutArgumentsTransformer "hasattr"
    if (not hasattr(super_without_arguments_transformer_0, "_tree_changed")):
        raise AssertionError()

# Generated at 2022-06-25 22:42:58.251556
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert(isinstance(SuperWithoutArgumentsTransformer, type))
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer))
    assert(super_without_arguments_transformer_0.target == (2, 7))
    call_1 = module_0.Call()
    list_1 = []
    a_s_t_1 = module_0.AST(*list_1)

# Generated at 2022-06-25 22:43:03.377467
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

test_case_0()
test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:43:09.601081
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:43:13.568818
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_2 = module_0.Call()
    list_1 = []
    a_s_t_1 = module_0.AST(*list_1)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    super_without_arguments_transformer_1.visit_Call(call_2)

# Generated at 2022-06-25 22:43:19.040810
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:43:20.236434
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:43:21.303791
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:43:25.118772
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()

# Generated at 2022-06-25 22:43:29.233734
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Calling function 'visit_Name' of class 'SuperWithoutArgumentsTransformer' to check if it works
    try:
        test_case_0()
    except Exception as e:
        assert False, "Function 'visit_Name' of class 'SuperWithoutArgumentsTransformer' raised error: " + str(e)



# Generated at 2022-06-25 22:43:33.888870
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert call_1 == call_0

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:43:37.893561
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()


# Generated at 2022-06-25 22:43:39.894710
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Unit tests for method SuperWithoutArgumentsTransformer.visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:43:42.088107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)

# Generated at 2022-06-25 22:43:44.543411
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = module_0
    a_s_t_0 = module_0.AST()
    SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:43:48.003145
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_2 = module_0.Call()
    list_1 = []
    a_s_t_1 = module_0.AST(*list_1)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)


# Generated at 2022-06-25 22:43:55.481265
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module_0 = None
    s_t_0 = module_0
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    s_t_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert s_t_1 == (module_0.Call(args=[module_0.Name(id='Cls'), module_0.Name(id='self')]))


# Generated at 2022-06-25 22:44:00.607475
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert isinstance(call_1, module_0.Call)  # Value


# Generated at 2022-06-25 22:44:04.347623
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.AST()
    a_s_t_0 = module_0.AST(tree)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:44:05.144173
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:44:10.222149
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    str_0 = super_without_arguments_transformer_0.__repr__()
    assert str_0 == 'SuperWithoutArgumentsTransformer(AST())'


# Generated at 2022-06-25 22:44:19.034035
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:23.078232
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module_0 = module_str
    module_str_0 = module_str
    len_0 = len(module_str_0)
    str_0 = 'module_str'
    int_0 = len_0 + 0
    ast_0 = ast(module_0)
    list_0 = []
    a_s_t_0 = ast(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)
    call_0 = Call()
    list_1 = []
    a_s_t_1 = ast(*list_1)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(ast_0)
    call_1 = super_without_arguments_transformer_1.visit_Call(call_0)


# Generated at 2022-06-25 22:44:32.233042
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("test_SuperWithoutArgumentsTransformer: ", end='', flush=True)

    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer), "assert #0 failed"

    call_1 = module_0.Call()
    str_0 = "super"
    name_0 = module_0.Name(id=str_0)
    call_1.func = name_0
    argument_0 = module_0.arguments()
    call_1.args = [argument_0]
    list_

# Generated at 2022-06-25 22:44:40.564565
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test params of type ast3.AST
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    stmt_0 = module_0.Expr(value=module_0.UnaryOp(op=module_0.USub(), operand=module_0.Name(id='a', ctx=module_0.Load())))
    stmt_1 = module_0.Expr(value=module_0.Name(id='a', ctx=module_0.Load()))
    module_0.AST(body=list_0)
    expr_0 = module_0.Name(id='a', ctx=module_0.Load())
   

# Generated at 2022-06-25 22:44:41.251282
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

import nuitka.nodes.NodeMakingHelpers


# Generated at 2022-06-25 22:44:43.270012
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    arg_0 = module_0.AST(*[])
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(arg_0)


# Generated at 2022-06-25 22:44:45.225598
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)


# Generated at 2022-06-25 22:44:46.000429
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:44:48.487327
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.parse("print('2')")
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree)
    assert super_without_arguments_transformer_0.tree is tree


# Generated at 2022-06-25 22:44:50.562321
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    test_case_0()

# Generated at 2022-06-25 22:45:02.649313
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = ast.parse('super()')
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)


# Generated at 2022-06-25 22:45:11.945541
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert super_without_arguments_transformer_0._tree is a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed is False
    assert super_without_arguments_transformer_0._directives == {'default_context'}
    assert super_without_arguments_transformer_0._functional_imports == {}
    assert super_without_arguments_transformer_0._indirect_imports == set()


# Generated at 2022-06-25 22:45:18.696331
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0.visit_Call(module_0.Call(args=[])) is None
    assert super_without_arguments_transformer_0.visit_Call(module_0.Call(args=[])) is None


if __name__ == '__main__':
    test_case_0()
    test_SuperWithoutArgumentsTransformer()
    print('Tests passed')

# Generated at 2022-06-25 22:45:22.357290
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(super_without_arguments_transformer_0.target == (2, 7))


# Generated at 2022-06-25 22:45:23.103045
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:45:26.176844
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = ast.Module()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(module_0, 2)


# Generated at 2022-06-25 22:45:30.991124
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:45:36.876212
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree == a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed == False


# Generated at 2022-06-25 22:45:38.116360
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()
test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:45:45.451575
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_trans

# Generated at 2022-06-25 22:46:10.619344
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert hasattr(super_without_arguments_transformer_0, "generic_visit")


# Generated at 2022-06-25 22:46:18.972361
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    abs_tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(abs_tree_0)
    list_1 = []
    a_s_t_1 = module_0.AST(*list_1)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    list_2 = []
    a_s_t_2 = module_0.AST(*list_2)
    super_without_arguments_transformer_2 = SuperWithoutArgumentsTransformer(a_s_t_2)
    list_3 = []
    a_s_t_3 = module_0.AST(*list_3)
    super_without_arguments_transformer_3 = SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:46:22.353091
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:46:23.689050
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        test_case_0()
    except TypeError:
        pass
    else:
        raise RuntimeError

# Generated at 2022-06-25 22:46:27.815235
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_2 = module_0.Call()
    list_1 = []
    a_s_t_1 = module_0.AST(*list_1)
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    super_without_arguments_transformer_1.visit(call_2)

# Generated at 2022-06-25 22:46:31.764109
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert isinstance(super_without_arguments_transformer_0._tree, module_0.AST)

# Generated at 2022-06-25 22:46:36.478440
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("Start test of function SuperWithoutArgumentsTransformer")
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    print(super_without_arguments_transformer_0)
    print("End test of function SuperWithoutArgumentsTransformer")


# Generated at 2022-06-25 22:46:37.360831
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:46:41.829588
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:46:42.346173
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    return 0


# Generated at 2022-06-25 22:47:30.140029
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        list_0 = []
        a_s_t_0 = module_0.AST(*list_0)
        super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    except:
        assert False


# Generated at 2022-06-25 22:47:33.722866
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:36.182603
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:47:41.219553
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = ast.Module()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(module_0)
    super_without_arguments_transformer_1._ignore_func_args
    super_without_arguments_transformer_1._tree_changed
    super_without_arguments_transformer_1._tree


if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 22:47:45.053778
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(module_0)
    call_0 = module_0.Call()

    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert isinstance(call_1, module_0.Call)

# Generated at 2022-06-25 22:47:49.039006
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  call_0 = ast.Call()
  list_0 = []
  a_s_t_0 = ast.AST(*list_0)
  super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
  assert super_without_arguments_transformer_0 is not None
  # assert super_without_arguments_transformer_0._tree is a_s_t_0
  call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:56.680875
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # constructor_0 = SuperWithoutArgumentsTransformer()

    # Constructor might be None
    ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)
    assert type(super_without_arguments_transformer_0) == SuperWithoutArgumentsTransformer
    assert type(super_without_arguments_transformer_0.target) == tuple
    assert super_without_arguments_transformer_0.target == (2, 7)
    assert type(super_without_arguments_transformer_0._tree) == module_0.AST
    assert super_without_arguments_transformer_0._tree == ast_0

    # Constructor might be None
    ast_1 = module_0.AST()
    super_without_arguments_

# Generated at 2022-06-25 22:47:58.986328
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    tree = ast.parse('def func(self):\n    super()')
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree)
    return

# Generated at 2022-06-25 22:48:03.286435
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = module_0.Call()
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    pass


# Generated at 2022-06-25 22:48:10.908188
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert_equal(call_0, call_1)
    assert_is_instance(call_1, module_0.Call)
    assert_equal(call_0, None)
    assert_is_instance(call_0, module_0.Call)
    assert_equal(call_1, None)
    assert_true(call_0 is call_1)


# Generated at 2022-06-25 22:50:01.914809
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.AST()
    transformer = SuperWithoutArgumentsTransformer(tree)
    assert transformer.tree == tree
    assert transformer._tree_changed == False
    assert transformer._changed_nodes == []
    assert transformer.target == (2, 7)

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-v', '-s'])

# Generated at 2022-06-25 22:50:02.888319
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-25 22:50:05.846299
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0._tree is a_s_t_0
    assert super_without_arguments_transformer_0._tree_changed is False


# Generated at 2022-06-25 22:50:08.767116
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert super_without_arguments_transformer_0.tree is not None

if __name__ == '__main__':
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:50:11.702753
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    call_0 = module_0.Call()
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:50:13.809548
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_0 = []
    a_s_t_0 = module_0.AST(*list_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:50:14.709459
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert issubclass(SuperWithoutArgumentsTransformer, BaseNodeTransformer)


# Generated at 2022-06-25 22:50:17.128057
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_2 = []
    a_s_t_5 = module_0.AST(*list_2)
    super_without_arguments_transformer_14 = SuperWithoutArgumentsTransformer(a_s_t_5)

    test_case_0()

test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:50:18.117487
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:50:18.931675
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer.__name__ is "SuperWithoutArgumentsTransformer"