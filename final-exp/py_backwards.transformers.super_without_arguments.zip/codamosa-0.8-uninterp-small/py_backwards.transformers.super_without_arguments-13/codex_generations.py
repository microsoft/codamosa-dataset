

# Generated at 2022-06-25 22:42:03.628858
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_1 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert super_without_arguments_transformer_1 is not None


# Generated at 2022-06-25 22:42:08.104436
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_0 = ast.Call()
    a_s_t_1 = call_0
    super_without_arguments_transformer_0.visit_Call(a_s_t_1)

# Generated at 2022-06-25 22:42:10.356285
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer.__bases__ == (BaseNodeTransformer,)


# Generated at 2022-06-25 22:42:13.147177
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert (super_without_arguments_transformer_0.target == (2, 7))


# Generated at 2022-06-25 22:42:16.161731
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Unit Test for the generic_visit method of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-25 22:42:17.000309
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:42:20.106841
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_1 = None
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_1 = None
    super_without_arguments_transformer_1.visit_Call(call_1)

# Generated at 2022-06-25 22:42:20.908382
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:42:26.739409
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    # calls private _replace_super_args
    super_without_arguments_transformer_0.visit(None)

if __name__ == "__main__":
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-25 22:42:27.584040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()

# Generated at 2022-06-25 22:42:37.556336
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    str_0 = '\x0clt6eCs< 4tR~6cC=Uaj'
    dict_0 = {str_0: str_0, str_0: tree_0, str_0: tree_0}
    list_0 = [tree_0, tree_0, tree_0]
    call_0 = module_0.Call(*list_0, **dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:42:40.003693
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()
    

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:42:42.377456
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:42:52.134951
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    list_0 = [a_s_t_0, a_s_t_0, a_s_t_0]
    str_0 = '\x1ehJ\x1bU6w5U\x0e\x1bZl"\x05z\x1d\x03\x1b|\x1f\x07\x0f\x1b\x0bJ\x13\x08"\x05z\x1d\x03\x1b|\x1f\x07\x0f\x1b\x0bJ\x13\x08'
    dict_0 = {str_0: str_0, str_0: a_s_t_0, str_0: a_s_t_0}


# Generated at 2022-06-25 22:42:53.705202
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:43:00.125987
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    list_0 = [a_s_t_0, a_s_t_0, a_s_t_0]
    str_0 = '\x0clt6eCs< 4tR~6cC=Uaj'
    dict_0 = {str_0: str_0, str_0: a_s_t_0, str_0: a_s_t_0}
    call_0 = module_0.Call(*list_0, **dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:43:03.066422
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        assert(True)
    except AssertionError:
        print('Test failed')
        raise
    else:
        print('Test completed')

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:43:04.871224
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_case_0()


# Generated at 2022-06-25 22:43:06.138951
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:43:14.941019
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a_s_t_0 = None
    list_0 = [a_s_t_0, a_s_t_0, a_s_t_0]
    str_0 = '\x0clt6eCs< 4tR~6cC=Uaj'
    dict_0 = {str_0: str_0, str_0: a_s_t_0, str_0: a_s_t_0}
    call_0 = module_0.Call(*list_0, **dict_0)
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

if __name__ == '__main__':
    test

# Generated at 2022-06-25 22:43:24.168746
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_1 = None
    list_1 = [var_1]
    call_2 = module_0.Call(*list_1)
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    assert call_2 == super_without_arguments_transformer_1.visit_Call(call_2)


# Generated at 2022-06-25 22:43:26.048209
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    # Test Case #0
    try:
        test_case_0()
    except RuntimeError as e:
        pass

# Generated at 2022-06-25 22:43:33.901037
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert not hasattr(super_without_arguments_transformer_0, '_a_s_t')
    assert not hasattr(super_without_arguments_transformer_0, '_tree')
    assert not hasattr(super_without_arguments_transformer_0, '_tree_changed')
    var_1 = None
    list_0 = [var_1]
    call_0 = module_0.Call(*list_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

test_case_0()

# Generated at 2022-06-25 22:43:41.640808
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    list_0 = [None]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)
    super_without_arguments_transformer_0.visit_Call(call_0)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:43:45.150771
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0


# Generated at 2022-06-25 22:43:54.033088
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)

    list_1 = [var_0]
    call_2 = module_0.Call(*list_1)
    super_without_arguments_transformer_0.visit_Call(call_2)

    list_2 = [var_0,var_0]
    call_3 = module_0.Call(*list_2)
    super_without_arguments_transformer_0.visit_

# Generated at 2022-06-25 22:43:58.572383
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert isinstance(super_without_arguments_transformer_0, SuperWithoutArgumentsTransformer)


# Generated at 2022-06-25 22:44:03.196982
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast._ast3 as module_0
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None

# Generated at 2022-06-25 22:44:11.504234
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    func_0 = module_0.FunctionDef()
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    classdef_0 = module_0.ClassDef()
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0._replace_super_args(call_0)
    super_without_arguments_transformer_0._replace_super_args(call_0)
    super_without_arguments_transformer_0._replace_super_args(call_0)

# Generated at 2022-06-25 22:44:12.325405
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass


# Generated at 2022-06-25 22:44:21.729449
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    if call_1.func.id == 'super' and call_1.args[0].id == 'Cls' and call_1.args[1].id == 'func':
        pass
    else:
        sys.exit(1)


# Generated at 2022-06-25 22:44:30.179893
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    str_0 = str(var_0)
    var_1 = None
    list_0 = [var_1]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    var_2 = None
    var_3 = None
    str_1 = str(var_3)
    var_4 = None
    list_1 = [var_4]
    call_1 = module_0.Call(*list_1)
    assert call_1.starargs is var_2
    assert super_without_arguments_transformer_0.tree is a_s_t_0
    assert call_

# Generated at 2022-06-25 22:44:33.955557
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:44:41.704769
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """
    Test visit_Call
    """
    # Initialization
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

    # Invocation
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    
    # Result assertion
    try:
        assert call_1 is not None
    except AssertionError:
        raise AssertionError()
        
    # Teardown


# Generated at 2022-06-25 22:44:46.074595
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:44:54.115386
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    var_1 = None
    list_1 = [var_1]
    call_1 = module_0.Call(*list_1)
    functiondef_0 = module_0.FunctionDef('func', a_s_t_0, list_1)
    list_2 = [functiondef_0]
    classdef_0 = module_0.ClassDef('cls', list_2)
    list_3 = [call_1, classdef_0]

# Generated at 2022-06-25 22:44:56.987769
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(super_without_arguments_transformer_0 != None)


# Generated at 2022-06-25 22:44:59.461493
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:00.962173
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        test_case_0()
    except Exception as inst:
        print(inst)
    assert True

# Generated at 2022-06-25 22:45:03.670106
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:10.410021
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)

# Generated at 2022-06-25 22:45:17.012624
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = ast.Call(*list_0)
    a_s_t_1 = ast.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert hasattr(call_1, '_attributes')
    assert hasattr(call_1, '_fields')
    assert not hasattr(call_1, '_annotations')
    assert call_1.args == []

# Generated at 2022-06-25 22:45:24.941140
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_0 = [module_0.AST()]
    list_1 = [module_0.ClassDef('unit_test', [], [], [], None)]
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)
    module_0.Module(list_0, list_1)

# Generated at 2022-06-25 22:45:31.878591
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    s = """
    super()
    """

# Generated at 2022-06-25 22:45:34.769077
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    ast_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(ast_0)
    return None


# Generated at 2022-06-25 22:45:38.916182
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    test_case_0()


# Generated at 2022-06-25 22:45:46.867258
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:45:51.415237
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:45:59.010856
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    assert(super_without_arguments_transformer_0._tree == a_s_t_0)
    assert(super_without_arguments_transformer_0._tree_changed == False)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    assert(super_without_arguments_transformer_0._tree_changed == True)


# Generated at 2022-06-25 22:45:59.705137
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    return None


# Generated at 2022-06-25 22:46:12.734672
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(tree_0)
    assert(super_without_arguments_transformer_0 is not None)


# Generated at 2022-06-25 22:46:18.429005
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

test_case_0()

test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:46:20.826252
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        test_case_0()
    except:
        assert False == True


# Generated at 2022-06-25 22:46:25.117393
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:27.326318
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_2 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_2)

# Generated at 2022-06-25 22:46:31.691100
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:46:33.575886
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:46:35.240067
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    try:
        test_case_0()
    except:
        raise

import typed_ast._ast3 as module_0


# Generated at 2022-06-25 22:46:37.503614
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    assert super_without_arguments_transformer_0 is not None


# Generated at 2022-06-25 22:46:45.757651
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    # Check if function throws when given Invalid arguments
    try:
        SuperWithoutArgumentsTransformer.visit_Call(1)
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        SuperWithoutArgumentsTransformer.visit_Call(**{'node': 1})
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        SuperWithoutArgumentsTransformer.visit_Call(**{'node': 'string'})
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        SuperWithoutArgumentsTransformer.visit_Call(**{'node': [1]})
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 22:47:09.434505
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    var_1 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_1)


# Generated at 2022-06-25 22:47:11.237558
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

# Generated at 2022-06-25 22:47:16.092227
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:47:18.781384
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:47:21.529566
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module_0 = ast
    var_0 = module_0.Module()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)
    assert(super_without_arguments_transformer_0 != None)


# Generated at 2022-06-25 22:47:22.198010
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:47:26.359710
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:47:30.989280
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:47:32.285825
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(var_1)
    assert super_without_arguments_transformer_1 is not None


# Generated at 2022-06-25 22:47:36.120216
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)



# Generated at 2022-06-25 22:48:31.847605
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)


# Generated at 2022-06-25 22:48:40.558451
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_1 = None
    list_1 = [var_1]
    call_2 = module_0.Call(*list_1)
    a_s_t_1 = module_0.AST()
    super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer(a_s_t_1)
    call_3 = super_without_arguments_transformer_1.visit_Call(call_2)

import typed_ast._ast3 as module_1


# Generated at 2022-06-25 22:48:45.262548
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:48:50.654661
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    # TODO: Add more tests for this class


# Generated at 2022-06-25 22:48:53.486855
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:48:57.457091
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:49:05.061348
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:49:06.880299
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:49:09.427945
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try: 
        super_without_arguments_transformer_1 = SuperWithoutArgumentsTransformer()
    except TypeError: 
        pass

# Test with assert_true and assert_false

# Generated at 2022-06-25 22:49:12.457672
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:50:21.607592
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# End of file

# Generated at 2022-06-25 22:50:27.337896
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)
    if call_1 is call_0:
        print("OK")
        return
    else:
        print("FAIL")

if __name__ == '__main__':
    test_case_0()
    test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-25 22:50:33.031531
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)

if __name__ == "__main__":
    test_case_0()
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-25 22:50:34.169425
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    test_case_0()

# Generated at 2022-06-25 22:50:36.109573
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(var_0)


# Generated at 2022-06-25 22:50:43.109133
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    super_without_arguments_transformer_0.generic_visit(call_0)
    super_without_arguments_transformer_0.tree_changed
    var_1 = module_0.keyword
    tuple_0 = (var_1, )
    list_1 = [tuple_0]
    call_1 = module_0.Call(*list_1)
    super_without_arguments_transformer_0.visit_Call(call_1)


# Generated at 2022-06-25 22:50:46.236184
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.tree import create_and_return_tree
    test_tree = create_and_return_tree("""
    class Cls:
        def func(self):
            super()  # <-- Should be replaced
    """)

    swat = SuperWithoutArgumentsTransformer(test_tree)
    swat.visit(test_tree)

    assert test_tree is not None


# Generated at 2022-06-25 22:50:52.445039
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    var_0 = None
    list_0 = [var_0]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)

# Generated at 2022-06-25 22:50:55.946299
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    list_0 = [None]
    call_0 = module_0.Call(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    call_1 = super_without_arguments_transformer_0.visit_Call(call_0)


# Generated at 2022-06-25 22:51:02.802566
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    list_0 = []
    class_0 = module_0.ClassDef(*list_0)
    call_0 = module_0.Call(*list_0)
    function_def_0 = module_0.FunctionDef(*list_0)
    a_s_t_0 = module_0.AST()
    super_without_arguments_transformer_0 = SuperWithoutArgumentsTransformer(a_s_t_0)
    attribute_0 = super_without_arguments_transformer_0.visit(class_0)
    list_1 = []
    call_1 = module_0.Call(*list_1)
    func_0 = super_without_arguments_transformer_0.visit(call_1)