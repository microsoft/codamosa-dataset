

# Generated at 2022-06-12 04:14:20.950000
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[]
    )
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit_Call(node)
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert isinstance(node.args[0], ast.Name)
    assert isinstance(node.args[1], ast.Name)

# Generated at 2022-06-12 04:14:24.767897
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .globals import GlobalsTransformer
    from .function import FunctionTransformer
    from .class_ import ClassTransformer
    from ..utils import cst_to_ast
    # Test transformation of super()


# Generated at 2022-06-12 04:14:31.722357
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_str
    code = """class A:
        pass
    class B(A):
        def __init__(self):
            super()
    """
    expected = """
    class A:
        pass


    class B(A):
        def __init__(self):
            super(A, self)


    """
    assert compile_str(code, 2, 7).strip('\n\t ') == expected.strip('\n\t ')

# Generated at 2022-06-12 04:14:36.964765
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test method visit_Call of class SuperWithoutArgumentsTransformer"""
    from ..utils.testing import get_node_of, to_source
    node = get_node_of("""
    class Foo:
        def m(self):
            super()
    """)
    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(tree.body[0].body[0].body[0], ast.Expr)
    assert 'super(Foo, m)' in to_source(tree)

# Generated at 2022-06-12 04:14:45.813518
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import test_utils
    test_utils.assert_transformation(
        SuperWithoutArgumentsTransformer,
        """
        class Foo:
            def bar(self):
                super()
        """,
        """
        class Foo:
            def bar(self):
                super(Foo, self)
        """,
        target=(2, 7),
    )

    # Verify that it will not transform if super() is outside of a method
    test_utils.assert_transformation(
        SuperWithoutArgumentsTransformer,
        """
        class Foo:
            super()
        """,
        """
        class Foo:
            super()
        """,
        target=(2, 7),
    )

# Generated at 2022-06-12 04:14:55.358600
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import parse

    node1 = parse("super()").body[0].value
    node2 = parse("super().foo()").body[0].value
    node3 = parse("class x:super()").body[0].body[0]
    node4 = parse("class x(object):super().foo()").body[0].body[0]

    t = SuperWithoutArgumentsTransformer(parse("pass"))

    t.visit(node1)
    assert(node1.args[0].id == "x")
    assert(node1.args[1].id == "self")

    t.visit(node2)
    assert(node2.args[1].id == "self")

    t.visit(node3)
    assert(node3.args[0].id == "x")

# Generated at 2022-06-12 04:15:02.292346
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3

    code_snippet = """
    class B:
        def __init__(self):
            super().__init__()
    """

    tree = ast.parse(code_snippet)
    SuperWithoutArgumentsTransformer(tree).run()

# Generated at 2022-06-12 04:15:02.983508
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:03.566385
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:05.361157
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:14.849530
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(tree=None,
                                                   file=None,
                                                   module=None,
                                                   type_ignores=None)

    call_node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[], starargs=None, kwargs=None)
    try:
        result = transformer.visit_Call(node=call_node)
    except AttributeError:
        pass
    else:
        assert False, 'Expected exception'


# Unit tests for class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:20.552108
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def a(self):
                super()
    """
    expected = """
        class A:
            def a(self):
                super(A, self)
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    result = tree.body[0].body[0].body[0]
    assert result.args[0].id == "A"
    assert result.args[1].id == "self"

# Generated at 2022-06-12 04:15:24.521068
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert SuperWithoutArgumentsTransformer.visit_Call(SuperWithoutArgumentsTransformer, ast.Call(
        func=ast.Name(id='super'), args=[], keywords=[])) == ast.Call(
        func=ast.Name(id='super'), args=[], keywords=[])


# Generated at 2022-06-12 04:15:25.459525
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:34.702456
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import test_case

    class Test(test_case.TestCase):
        def setUp(self):
            self.transformer_class = SuperWithoutArgumentsTransformer
            self.tree = ast.parse('super()')
            self.expected_tree = ast.parse('super(Cls, self)')
            self.tree.body[0].body = [ast.ClassDef(name='Cls', body=[ast.FunctionDef(name='func', args=ast.arguments(args=[ast.arg(arg='self')]), body=[ast.Expr(value=ast.Call(func=ast.Name(id='super'), args=[], keywords=[]))])])]

    Test().run()

# Generated at 2022-06-12 04:15:44.033773
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse('''
    class A:
        def f(self):
            super()
    ''')
    assert transformer.visit(tree) == ast.parse('''
    class A:
        def f(self):
            super(A, self)
    ''')

    tree = ast.parse('''
    class A:
        def f(self):
            super(B, self)
    ''')
    assert transformer.visit(tree) == ast.parse('''
    class A:
        def f(self):
            super(B, self)
    ''')

# Generated at 2022-06-12 04:15:54.237069
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.unparse import Unparser
    import textwrap
    source = textwrap.dedent('''\
    class A:
        def __init__(self):
            super().__init__()

    class B(A):
        def __init__(self):
            super().__init__()
    ''')
    tree = Unparser(source, 2)
    assert SuperWithoutArgumentsTransformer(tree).visit(tree.body[0]) is None
    assert tree.body[0].body[0].value.args[0].id == 'B'
    assert tree.body[0].body[0].value.args[1].id == 'self'
    assert SuperWithoutArgumentsTransformer(tree).visit(tree.body[1]) is None

# Generated at 2022-06-12 04:15:55.248690
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:56.183201
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:03.210198
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..builders import ClassDef, FunctionDef, Call, Name, Var

    super_ = Name('super')
    cls_ = Name('Cls')

    # Test 1
    node = Call(super_)
    assert get_ast(node).body[0].value.args[0].id == 'Cls'

    # Test 2
    node = Call(super_)
    tree = get_ast(ClassDef(name='Cls', body=[node], decorator_list=[]))
    assert tree.body[0].body[0].value.args[0].id == 'Cls'

    # Test 3
    node = Call(super_)
    tree = get_ast(ClassDef(name=cls_, body=[node], decorator_list=[]))
    assert tree.body[0].body[0].value.args

# Generated at 2022-06-12 04:16:12.335031
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = dedent("""
    class A:
        def __init__(self):
            super()
    """)
    expected = dedent("""
    class A:
        def __init__(self):
            super(A, self)
    """)
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astunparse(tree) == expected

# Generated at 2022-06-12 04:16:17.921626
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing.utils import build_and_run

    source = '''        
    class Parent:
        pass

    class Child(Parent):
        def __init__(self):
            super().__init__()
    '''
    module, output = build_and_run(source, SuperWithoutArgumentsTransformer)

    assert 'super(Child, self).__init__' in output
    assert 'super(Parent, self).__init__' in output

# Generated at 2022-06-12 04:16:18.850934
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:29.080772
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """It should replace super() by super(Cls, self) when there is no argument"""
    transformer = SuperWithoutArgumentsTransformer(None, None)  # type: ignore
    TREE = ast.parse("""
        class A:
            def b(self):
                super()
        """)
    transformer.visit(TREE)

# Generated at 2022-06-12 04:16:35.597479
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_from = '''class Foo:
  def __init__(self):
    super()'''
    code_to = '''class Foo:
  def __init__(self):
    super(Foo, self)'''
    tree_from = ast.parse(code_from)
    tree_to = ast.parse(code_to)
    t = SuperWithoutArgumentsTransformer(tree_from)
    t.visit(tree_from)
    assert (ast.dump(tree_from) == ast.dump(tree_to))



# Generated at 2022-06-12 04:16:46.402437
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class Tree:
        body: list = []

    class Class:
        name: str = 'Foo'
        body: list = []


    class Function:
        name: str = 'spam'

    class Call:
        func: ast.Name = ast.Name(id='super')

    class Name:
        id: str = 'arg'

    class Arguments:
        args: list = []

    def test_generator(func: str) -> ast.Call:
        return ast.Call(func=ast.Name(id=func))


# Generated at 2022-06-12 04:16:52.668176
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    import ast as pyast
    tree = pyast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert compile(tree, "<test>", 'exec') == code_expected


# Generated at 2022-06-12 04:16:58.276649
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tree = ast.parse(textwrap.dedent(code))
    SuperWithoutArgumentsTransformer().visit(tree)
    expected_code = 'super(Class, self)'
    assert astor.to_source(tree).strip() == textwrap.dedent(expected_code).strip()

    code = 'super()'
    tree = ast.parse(textwrap.dedent(code))
    SuperWithoutArgumentsTransformer().visit(tree)
    expected_code = 'super(Class, self)'
    assert astor.to_source(tree).strip() == textwrap.dedent(expected_code).strip()

# Generated at 2022-06-12 04:17:00.347713
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astor.code_gen import to_source
    from .. import transform, untransform


# Generated at 2022-06-12 04:17:01.264713
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:15.839218
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str

    program = """
        class A:
            def f(self):
                super()
        """
    expected = """
        class A:
            def f(self):
                super(A, self)
        """
    tree = ast.parse(program)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == expected

    # Raise exception: super() outside of function
    program = """
        class A:
            super()
        """
    tree = ast.parse(program)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == program

    # Raise exception: super() outside of class

# Generated at 2022-06-12 04:17:16.700249
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:20.626867
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()', '<test>', 'exec')
    expected = ast.parse('super(__class__, self)', '<test>', 'exec')

    transformer = SuperWithoutArgumentsTransformer()
    node = transformer.visit(node)  # type: ignore
    assert transformer.tree_changed

    assert ast.dump(node) == ast.dump(expected)


# Generated at 2022-06-12 04:17:25.975813
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree: ast.Module = ast.parse('super()')
    tree.body[0].value.args = []

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    # if you see this message, the test is failed
    assert transformer._tree_changed is True, 'super() without arguments was not detected'

# Generated at 2022-06-12 04:17:32.402596
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_ = ast.Super()
    node = ast.Call(
        func=super_,
        args=[],
        keywords=[]
    )

    BaseNodeTransformer._tree_changed = False
    class Tree:
        def __init__(self):
            self.body = [
                ast.FunctionDef(
                    name='abc',
                    args=ast.arguments(
                        args=[
                            ast.arg(arg='self', annotation=None)
                        ],
                        vararg=None,
                        kwonlyargs=[],
                        kw_defaults=[],
                        kwarg=None,
                        defaults=[]
                    ),
                    body=[
                        node
                    ]
                )
            ]

    tree = Tree()
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert BaseNodeTransformer._

# Generated at 2022-06-12 04:17:40.950992
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from python_transformer.visitors.super_without_arguments import SuperWithoutArgumentsTransformer
    from . import sample_code
    from . import expected_output
    from . import tree_compare
    from numpy import testing

    code = sample_code.SUPER_WITHOUT_ARGUMENTS_CODE
    expected_tree = ast.parse(expected_output.SUPER_WITHOUT_ARGUMENTS_CODE)
    tree = ast.parse(code)

    tree = SuperWithoutArgumentsTransformer().visit(tree)
    testing.assert_equal(astor.to_source(tree), astor.to_source(expected_tree))
    assert tree_compare.compare_ast(tree, expected_tree), 'Expected tree to be similar to result.'

# Generated at 2022-06-12 04:17:43.287701
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .syntax_helpers import get_node
    from ..utils.source import source_to_unicode



# Generated at 2022-06-12 04:17:49.254290
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class C(object):
            def method(self):
                return super()
    """
    tree = ast.parse(code)
    expected = """
        class C(object):
            def method(self):
                return super(C, self)
    """

    SuperWithoutArgumentsTransformer().visit(tree)
    result = compile(tree, filename='', mode='exec')

    assert expected == str(result)

# Generated at 2022-06-12 04:17:56.099280
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import is_valid_transformation
    from . import transforms_to

    assert is_valid_transformation(
        SuperWithoutArgumentsTransformer,
        """
            class MyClass(SuperClass):
                def my_method(self):
                    super()
            """,
        """
            class MyClass(SuperClass):
                def my_method(self):
                    super(MyClass, self)
            """,
        check_ast=True,
    )



# Generated at 2022-06-12 04:18:02.733691
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test SuperWithoutArgumentsTransformer"""
    from ..utils.source import source_to_unicode
    
    code = source_to_unicode("""
        class Parent(object):
            def __init__(self, x, y=1):
                super()
        
        class Child(Parent):
            def __init__(self, x, y=2):
                super()
    """)
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-12 04:18:18.258045
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # The following code:
    # ## super()
    #
    # Should be converted to:
    # assert super(C, self) is None
    # assert super(C, cls) is None

    input_code = """\
## super()
"""

    expected_output = """\
assert super(C, self) is None
assert super(C, cls) is None
"""

    tree = ast.parse(input_code)

    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)

    assert transformer.tree_changed is True
    assert ast.dump(new_tree) == expected_output

# Generated at 2022-06-12 04:18:22.045102
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import Parser
    from ..utils.source import Source

    source = Source("""
        super()
    """)
    tree = Parser().parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == "super(Cls, self)"

# Generated at 2022-06-12 04:18:23.165679
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:27.233060
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == '''Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]))])'''



# Generated at 2022-06-12 04:18:28.449790
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:18:36.530225
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from astor.code_gen import to_source

    class SuperWithoutArgumentsTransformerTest(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return super().visit_Call(node)  # type: ignore

        def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
            return self.generic_visit(node)  # type: ignore

        def visit_ClassDef(self, node: ast.ClassDef) -> ast.AST:
            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-12 04:18:37.472416
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:18:45.146952
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
	from typed_ast import ast3 as ast
	# Test super() inside a func
	tree = ast.parse("""
	class B:
		def __init__(self):
			super()
	""")

	transformer = SuperWithoutArgumentsTransformer()
	transformer.visit(tree)
	assert transformer.tree_changed() == True

	# Test super() inside a cls
	tree = ast.parse("""
	def func():
		super()
	""")

	transformer = SuperWithoutArgumentsTransformer()
	transformer.visit(tree)
	assert transformer.tree_changed() == False

# Generated at 2022-06-12 04:18:55.226783
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import utils
    node = utils.run_visitor('funcdef', SuperWithoutArgumentsTransformer, '''
    class C:
        def __init__(self):
            super()
    ''')

# Generated at 2022-06-12 04:18:55.908909
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:20.919900
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..unparser import Unparser
    from ..parser import parse
    import textwrap

    code = textwrap.dedent(
        """\
        class Cls:
            def __init__(self):
                a = super()
        """
    )
    mod = parse(code, mode='exec')
    SuperWithoutArgumentsTransformer().visit(mod)
    assert Unparser(mod, singleton=False).unparse() == textwrap.dedent(
        """\
        class Cls:
            def __init__(self):
                a = super(Cls, self)
        """
    )

    code = textwrap.dedent(
        """\
        class Cls:
            def __init__(self):
                a = super()
        """
    )
    mod = parse(code, mode='exec')

# Generated at 2022-06-12 04:19:31.256801
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest

    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def test_it_works(self):
            transformer = SuperWithoutArgumentsTransformer()
            tree = ast.parse("""
            class Test:
                def test(self):
                    super()
                @staticmethod
                def test2(cls):
                    super()
            """)
            tree = transformer.visit(tree)
            # TODO: deal w/ static method
            self.assertEqual(tree._fields, ('body',))
            self.assertEqual(tree.body[0].body[0]._fields, ('name', 'args', 'body'))
            self.assertEqual(tree.body[0].body[0].args.args[0].arg, 'self')

# Generated at 2022-06-12 04:19:31.779816
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:33.853405
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .transform import ModuleTransformer

    # Code before transformation

# Generated at 2022-06-12 04:19:44.184934
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # super() case 1:
    code_snippet_before_transformation = """
            class C(A):
                def __init__(self, c):
                    super()
    """
    code_snippet_after_transformation = """
            class C(A):
                def __init__(self, c):
                    super(C,self)
    """
    ast1 = ast.parse(code_snippet_before_transformation)
    ast2 = ast.parse(code_snippet_after_transformation)
    actual_result = SuperWithoutArgumentsTransformer(None)
    actual_result.visit(ast1)
    assert ast.dump(ast2) == ast.dump(ast1)

    # super() case 2:

# Generated at 2022-06-12 04:19:48.633636
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class MySuperClass:
        def method():
            super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    expected_code = '''
    class MySuperClass:
        def method():
            super(MySuperClass, self)
    '''
    assert astunparse.unparse(tree) == expected_code

# Generated at 2022-06-12 04:19:58.335139
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(None, None)

    class_node = ast.ClassDef(name='Spam', body=[], lineno=1, col_offset=0)
    node = ast.Call(func=ast.Name(id='super', ctx=ast.Load()),
                    args=[],
                    keywords=[],
                    lineno=1,
                    col_offset=0)

# Generated at 2022-06-12 04:19:59.131202
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:08.926594
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import compile_source
    from .base import BaseNodeTransformer
    from typed_ast import ast3 as ast
    from ..exceptions import NodeNotFound
    from ..utils.tree import get_closest_parent_of
    module = compile_source("class D(object):\n"
"    def foo(self):\n"
"        super()\n"
"        return 5")
    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.visit(module)
    assert module.body[0].body[0].body[0].value.func.id =='super'
    assert module.body[0].body[0].body[0].value.args[0].id == 'D'

# Generated at 2022-06-12 04:20:12.269705
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_without_arguments_transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super().__init__()')
    super_without_arguments_transformer.visit(tree)
    assert 'super(Test, self).__init__()' in astor.to_source(tree)

# Generated at 2022-06-12 04:20:47.464531
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert tree_to_code(tree).strip() == 'super(Cls, self)'

# Generated at 2022-06-12 04:20:53.035801
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing SuperWithoutArgumentsTransformer"""
    module_ast = ast.parse("""super()""")
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(module_ast)
    assert_equal(ast.dump(module_ast), """Module(body=[Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None)])""")



# Generated at 2022-06-12 04:20:55.939994
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import load_ast

    # This piece of code is compiled by astor (https://github.com/berkerpeksag/astor)

# Generated at 2022-06-12 04:21:04.190715
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from typed_ast.ast3 import FunctionDef, ClassDef, Name
    from .test_BaseNodeTransformer import BaseNodeTransformerTest
    class Test(BaseNodeTransformerTest):
        def create_transformer(self) -> BaseNodeTransformer:
            return SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:21:08.019060
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest
    import astor

# Generated at 2022-06-12 04:21:10.734454
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    result = transformer.visit(ast.parse('''
        class Cls:
            def __init__(self):
                super()
    '''))
    # todo: how to test?

# Generated at 2022-06-12 04:21:15.688712
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'class C(object): def __init__(self): super()'
    tree = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)

    assert tree.body[0].body[0].value.args[0].id == 'C'
    assert tree.body[0].body[0].value.args[1].id == 'self'

# Generated at 2022-06-12 04:21:16.628257
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    from .. import ast_utils

# Generated at 2022-06-12 04:21:21.507384
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..binder import Binder
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_fixtures_path

    path = get_fixtures_path('super_without_arguments.py')
    source = source_to_unicode(path)
    tree = Binder().parse(source, path)

    transformer = SuperWithoutArgumentsTransformer(tree=tree, filename=path)
    transformer.run()

# Generated at 2022-06-12 04:21:29.169009
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    from ..utils.tree import compile_ast, extract_python_source
    from ..utils.helpers import list_of_nodes
    s = "super()"
    result_target_tree = compile_ast(s)
    module_node = result_target_tree.body[0]
    module_node._fields = ('body', 'type_ignores') # type: ignore
    module_node.body[0] = list_of_nodes(module_node.body[0]) # type: ignore
    module_node.body[0][0] = list_of_nodes(module_node.body[0][0]) # type: ignore
    module_node.body[0][0][0] = list_of_nodes(module_node.body[0][0][0]) # type: ignore
    module_node.body

# Generated at 2022-06-12 04:22:14.777176
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:15.261926
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert True

# Generated at 2022-06-12 04:22:17.492351
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.code_gen import cst_to_ast
    from ..utils.helpers import dump_ast
    from ..utils.tree import find_all_nodes_of_type

# Generated at 2022-06-12 04:22:21.808260
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..registry import Registry
    import astor

    tree = ast.parse("assert super().__class__ == cls")
    registry = Registry()
    registry.register_transformer(SuperWithoutArgumentsTransformer)
    new_tree = registry.transform(tree)
    assert (astor.to_source(new_tree) == "assert super(cls, cls).__class__ == cls")


# Generated at 2022-06-12 04:22:23.224751
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    assert t is not None

# Generated at 2022-06-12 04:22:31.029904
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing:
        class Cls:
            def __init__(self):
                super()
    To:
        class Cls:
            def __init__(self):
                super(Cls, self)
            
    """
    code_str = 'class Cls:\n    def __init__(self):\n        super()'
    expected_str = 'class Cls:\n    def __init__(self):\n        super(Cls, self)'
    code_ast = ast.parse(code_str)
    expected_ast = ast.parse(expected_str)
    transformer = SuperWithoutArgumentsTransformer(code_ast)
    transformer.visit(code_ast)
    assert ast.dump(code_ast) == ast.dump(expected_ast)

# Generated at 2022-06-12 04:22:31.790749
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:37.974021
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_

    # Test for super()
    tree = compile_("""\
    class A(object):
        def bar(self):
            super()
    """)
    assert len(tree.body) == 1
    A = tree.body[0]
    assert isinstance(A, ast.ClassDef)
    assert len(A.body) == 1
    bar = A.body[0]
    assert isinstance(bar, ast.FunctionDef)
    assert isinstance(bar.body[0].value, ast.Call)
    assert not len(bar.body[0].value.args)
    SuperWithoutArgumentsTransformer(ast_tree=tree).visit(tree)
    assert isinstance(bar.body[0].value, ast.Call)
    assert len(bar.body[0].value.args)

# Generated at 2022-06-12 04:22:42.667629
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ..utils.helpers import get_code
    node = ast3.parse(get_code(__file__, 'SuperWithoutArgumentsTransformer.py'))
    node = SuperWithoutArgumentsTransformer().visit(node)
    exec(compile(node, filename="", mode="exec"))  # make sure code runs
    return node

# Generated at 2022-06-12 04:22:43.537792
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:24:15.562997
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test the constructor of the class SuperWithoutArgumentsTransformer."""

    # Test without any argument given
    node_transformer = SuperWithoutArgumentsTransformer()
    assert node_transformer._tree is None

    # Test with a tree given as argument
    tree = ast.parse('print(1)')
    node_transformer = SuperWithoutArgumentsTransformer(tree=tree)
    assert node_transformer._tree is not None