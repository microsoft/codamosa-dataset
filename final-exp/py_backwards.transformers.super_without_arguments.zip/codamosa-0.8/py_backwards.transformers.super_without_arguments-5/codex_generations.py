

# Generated at 2022-06-12 04:14:16.548340
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:17.008958
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-12 04:14:25.553061
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Test case 1:
    tree1 = ast.parse('super()')
    tree_changed = False
    SuperWithoutArgumentsTransformer(tree1, tree_changed).visit(tree1)
    assert str(tree1) == 'super(Cls, self)'
    assert tree_changed == True

    # Test case 2:
    tree2 = ast.parse('super(super())')
    tree_changed = False
    SuperWithoutArgumentsTransformer(tree2, tree_changed).visit(tree2)
    assert str(tree2) == 'super(super(Cls, self))'
    assert tree_changed == True

    # Test case 3:
    tree3 = ast.parse('parent.super()')
    tree_changed = False

# Generated at 2022-06-12 04:14:35.619863
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...testing import assert_code_equal
    from .super_without_arguments_transformer import SuperWithoutArgumentsTransformer

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node):
            super().visit_Call(node)
            if hasattr(self, 'changed'):
                return self.changed
            else:
                return node


# Generated at 2022-06-12 04:14:39.931355
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test the SuperWithoutArgumentsTransformer for super with no arguments"""
    tree = ast.parse('class A: def f(self): super()')
    SuperWithoutArgumentsTransformer(tree).run()
    assert str(tree) == 'class A: def f(self): super(A, self)'



# Generated at 2022-06-12 04:14:42.435042
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    tree = parse('super()')
    trans = SuperWithoutArgumentsTransformer()
    trans.visit(tree)
    assert trans._tree_changed

# Generated at 2022-06-12 04:14:52.115340
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import setup_module_for_tests
    setup_module_for_tests()

    # type: Optional[SuperWithoutArgumentsTransformer]
    transformer = None

    # type: ast.Call
    top_node = ast.parse('super()').body[0]

    expected = ast.parse('super(Cls, self)').body[0]

    def _check(top_node, expected) -> None:
        _check.counter += 1
        nonlocal transformer
        transformer = SuperWithoutArgumentsTransformer(2.7)
        transformer.visit(top_node)
        assert top_node == expected, f'{_check.counter}: {ast.dump(top_node)}\n{ast.dump(expected)}'

    _check.counter = 0
    _check(top_node, expected)
    top_

# Generated at 2022-06-12 04:14:58.304932
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..byteplay3 import Code, LOAD_CONST, MAKE_FUNCTION, CALL_FUNCTION, BUILD_CLASS, BUILD_TUPLE, EXTENDED_ARG
    from ..byteplay3 import LOAD_GLOBAL, LOAD_FAST, LOAD_METHOD, LOAD_ATTR, STORE_ATTR, RETURN_VALUE, MAKE_CLOSURE
    from ..utils.helpers import get_func_code, get_code_object

# Generated at 2022-06-12 04:15:03.802883
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass


try:
    # pylint: disable=unused-wildcard-import
    from typing import *  # pylint: disable=wildcard-import
    from .. import utils  # pylint: disable=unused-import
    from . import base  # pylint: disable=unused-import
except ImportError:
    pass

# Generated at 2022-06-12 04:15:05.678518
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:08.574542
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:18.495219
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import cst
    from .parser import parse

    mod = parse('''
        class Foo:
            def fn(self):
                super()
            @classmethod
            def fn2(cls):
                super()
                ''')
    mod = SuperWithoutArgumentsTransformer(mod).visit(mod)
    assert cst.dump_tree(mod) == \
    'Module(\n' \
    '  stmt=[\n' \
    '    ClassDef(\n' \
    '      name="Foo",\n' \
    '      bases=[],\n' \
    '      keywords=[],\n' \
    '      body=[\n' \
    '        FunctionDef(\n' \
    '          name="fn",\n' \
    '          args=arguments(\n'

# Generated at 2022-06-12 04:15:28.593133
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_from = 'super()'
    code_to = 'super(Cls, self)'
    
    unit_test_name = 'TestSuperWithoutArgumentsTransformer'
    class_name = 'Cls'
    function_name = 'func'
    node_test = ast.parse(code_from)

# Generated at 2022-06-12 04:15:35.916207
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import parse

    pointcut = '''
        class Point:
            x = 10
            y = 20
            def __init__(self, x, y):
                super().__init__(x, y)
                    
    '''
    tree = parse(pointcut)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert len(tree.body[0].body[0].initializer.value.args) == 2
    print(ast.dump(tree))

# Generated at 2022-06-12 04:15:45.123172
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node1 = ast.Call()
    node1.func = ast.Name(id='super')
    node1.args = []

    node2 = ast.Call()
    node2.func = ast.Name(id='super')
    node2.args = [ast.arg(arg='arg', annotation=None)]

    node3 = ast.Call()
    node3.func = ast.Name(id='other')
    node3.args = []

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node1)
    transformer.visit(node2)
    transformer.visit(node3)

    assert type(node1.args[0]) is ast.Name
    assert node1.args[0].id == 'Cls'
    assert type(node1.args[1]) is ast.Name

# Generated at 2022-06-12 04:15:55.613419
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .sample_ast import function_def, class_def
    from ..utils.source import put_in_module

    class ExampleClass(object):
        def example_function(self):
            super()

    source = put_in_module(ExampleClass, function_def, class_def)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert transformer.tree_changed is True

# Generated at 2022-06-12 04:16:00.536478
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from .unpacking import UnpackTupleAssignmentTransformer

    transformer = SuperWithoutArgumentsTransformer(None)
    transformer.visit(ast.parse('super'))
    assert transformer._tree_changed is True

    transformer = UnpackTupleAssignmentTransformer(None)
    transformer._tree_changed = False
    transformer.visit(ast.parse('super()'))
    assert transformer._tree_changed is False



# Generated at 2022-06-12 04:16:08.500041
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    patcher = patch('py2js.transpilers.function.SuperWithoutArgumentsTransformer._replace_super_args')
    mock_replace_super_args = patcher.start()

    transformer = SuperWithoutArgumentsTransformer()

    source = textwrap.dedent('''
    class A(object):
        def __init__(self):
            super()
    
    def foo():
        def bar():
            pass
    ''')
    tree = ast.parse(source)
    transformer.visit(tree)
    assert not mock_replace_super_args.called

    source = textwrap.dedent('''
    class A(object):
        def __init__(self):
            self.super()
    
    def foo():
        def bar():
            pass
    ''')

# Generated at 2022-06-12 04:16:11.777230
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import testing

    with testing.File('super()') as t:
        n = t.parse()
        n = SuperWithoutArgumentsTransformer().visit(n)
        assert str(n) == "class Test:\n\n    def __init__(self):\n        super(Test, self)"

# Generated at 2022-06-12 04:16:17.610153
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class Foo():
        def __init__(self):
            super()
    '''
    expected_code = '''
    class Foo():
        def __init__(self):
            super(Foo, self)
    '''

    tr = SuperWithoutArgumentsTransformer()
    tr.visit(ast3.parse(code))
    actual_code = astor.to_source(tr.root).strip()
    assert expected_code == actual_code

# Generated at 2022-06-12 04:16:32.775922
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class D:
        def __init__(self, x, y):
            super()
            self._x = x
            self._y = y
    
        def __str__(self):
            return str(self.x) + ' ' + str(self.y)
    """
    expected_output = """
    class D:
        def __init__(self, x, y):
            super(D, self)
            self._x = x
            self._y = y
    
        def __str__(self):
            return str(self.x) + ' ' + str(self.y)
    """
    tree = ast.parse(input)
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert astunparse.unparse(tree) == expected_output

# Generated at 2022-06-12 04:16:43.748448
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("""
        class A:
            def __init__(self):
                pass

            def foo(self):
                super()
    """)

    trans = SuperWithoutArgumentsTransformer(tree)
    trans.visit(tree)

    # The AST as a string is different between 2.7 and 3.x, so there are 2
    # different expected AST strings.
    expected_ast_27 = ast.parse("""
        class A:
            def __init__(self):
                pass

            def foo(self):
                super(A, self)
    """)
    expected_ast_32 = ast.parse("""
        class A:
            def __init__(self):
                pass

            def foo(self):
                super(A, self)
    """)


# Generated at 2022-06-12 04:16:45.355631
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from .unparse import UnparseTransformer


# Generated at 2022-06-12 04:16:49.335256
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import set_parent_nodes
    from ..utils.helpers import assert_source_equal
    from ..utils.helpers import assert_source_not_equal
    from ..utils.tree import NodeNotFound


# Generated at 2022-06-12 04:16:55.557098
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    tree = ast.parse("def func(self): super()")
    tree_before_transformation = astor.to_source(tree)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    tree_after_transformation = astor.to_source(tree)

    # This test does not make sense as the test would depend on the scope of the test file.
    assert tree_before_transformation != tree_after_transformation



# Generated at 2022-06-12 04:16:58.088291
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("Unit test for method: SuperWithoutArgumentsTransformer")
    assert True
    # TODO: Create unit test for constructor of class SuperWithoutArgumentsTransformer


# Generated at 2022-06-12 04:17:04.677420
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .base import BaseNodeTransformer
    from pathlib import Path
    from typed_ast import ast3

    source = Path(__file__).parent.parent.parent / 'examples' / 'super_without_arguments.py'
    tree = ast3.parse(source_to_unicode(source))
    transformer = BaseNodeTransformer.make_transformer()

    transformer.visit(tree)

    assert transformer._tree_changed is True

# Generated at 2022-06-12 04:17:12.476399
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from random import randint
    from ..tokenizer.tokenizer import Tokenizer
    from ..exceptions import PythonToRubyTranslationError

    t = Tokenizer('./fixtures/class_definitions.py')
    t.tokenize()
    code = t.source_code
    s = SuperWithoutArgumentsTransformer(code, code, 2, 7)
    s.visit(ast.parse(code))
    assert_equals(s._tree_changed, True)

    s = SuperWithoutArgumentsTransformer(code, code, 3, 8)
    assert_raises(PythonToRubyTranslationError, s.visit, ast.parse(code))

# Generated at 2022-06-12 04:17:14.778897
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import test_utils
    from .base import BaseNodeTransformer


# Generated at 2022-06-12 04:17:15.879136
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    import astunparse


# Generated at 2022-06-12 04:17:31.510025
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    tree = ast3.parse('super()')

    node = tree.body[0]
    assert isinstance(node, ast3.Expr)

    node = node.value
    assert isinstance(node, ast3.Call)

    node = node.func
    assert isinstance(node, ast3.Name)

    node = node.id
    assert node == 'super'

    node = tree.body[0].value.args
    assert not len(node)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    transformer.leave(tree)

    node = tree.body[0].value.args
    assert len(node)
    assert isinstance(node[0], ast3.Name)
    assert isinstance(node[1], ast3.Name)

# Generated at 2022-06-12 04:17:40.817364
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    import typed_ast.ast3
    from ..translators.helpers import get_tree

    tree = get_tree(dedent('''
        class Foo(object):
            def __init__(self, x):
                super().__init__()
            def one_arg(self, x):
                super().one_arg(x)
            def two_args(self, x, y):
                super().two_args(x, y)
        '''))
    assert isinstance(tree, typed_ast.ast3.Module)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert isinstance(tree, typed_ast.ast3.Module)
    assert isinstance(tree.body[0], typed_ast.ast3.ClassDef)

# Generated at 2022-06-12 04:17:46.120705
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class C(object):
            def __init__(self):
                super()
    """
    tree = ast.parse(code)
    expected_code = """
        class C(object):
            def __init__(self):
                super(C, self)
    """
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-12 04:17:51.530975
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that arguments of super() calls are automatically replaced.

    """
    class Cls(object):
        def meth(self):
            super()

    c = compile(Cls.__module__, Cls.__module__ + '.py', 'exec')
    SuperWithoutArgumentsTransformer(c).visit(c)
    assert isinstance(c.body[0].body[0].value, ast.Call)

# Generated at 2022-06-12 04:18:00.895864
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_node = ast.ClassDef(name='TestClass',
                              body=[ast.FunctionDef(name='__init__',
                                                    args=ast.arguments(
                                                        args=[ast.arg(arg='self', annotation=None)],
                                                        vararg=None, kwonlyargs=[], kw_defaults=[],
                                                        kwarg=None, defaults=[]),
                                                    body=[], decorator_list=[], returns=None)])


# Generated at 2022-06-12 04:18:02.775017
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from .. import compile_to_untyped_ast


# Generated at 2022-06-12 04:18:10.351404
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
  # Arguments: code_str, expected_tree
  test_params = [
    ('super()', 'super(Cls, self)'), 
    ('super(a,b)', 'super(a,b)'), 
    ('super', 'super')
  ]

  for code_str, expected_tree in test_params:
      tree = ast.parse(code_str)
      tree = SuperWithoutArgumentsTransformer().visit(tree)
      assert astor.to_source(tree) == expected_tree

# Generated at 2022-06-12 04:18:15.579495
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ..context import Context
    from ..rewriter import Rewriter
    import re

    code = 'super()\n'
    tree = ast.parse(code)
    ctx = Context()
    rwt = Rewriter(ctx, tree)
    rwt.rewrite()

    assert rwt.compile() == "super(C, c)\n"


# Generated at 2022-06-12 04:18:22.548230
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse("super()")
    transformer.visit(tree)
    func = tree.body[0].value
    assert isinstance(func, ast.Call)
    assert isinstance(func.func, ast.Name)
    assert len(func.args) == 2
    assert isinstance(func.args[0], ast.Name)
    assert func.args[0].id == "Cls"
    assert isinstance(func.args[1], ast.Name)
    assert func.args[1].id == "self"

# Generated at 2022-06-12 04:18:23.357378
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:18:44.535568
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    node = compile('super()', '<stdin>', 'single', ast.PyCF_ONLY_AST)
    transformer.visit(ast.fix_missing_locations(node))

    print(ast.dump(node))

# Generated at 2022-06-12 04:18:45.103975
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:52.547730
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import examples

    # Given
    visitor = SuperWithoutArgumentsTransformer()
    tree = ast.parse(examples.SUPER_WITHOUT_ARGS)

    # When
    visitor.visit(tree)

    # Then
    assert isinstance(tree.body[0].body[0].value, ast.Call)
    assert tree.body[0].body[0].value.args[0].id == 'Cls'
    assert tree.body[0].body[0].value.args[1].id == 'cls'

# Generated at 2022-06-12 04:18:59.982135
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast, source_to_python_ast, source_to_tree

    tree = source_to_tree('''
        class Cls(object):
            def method(self):
                super()
    ''')

    # Make sure that SuperWithoutArgumentsTransformer is present among the tree's transformers
    assert SuperWithoutArgumentsTransformer in [type(t) for t in tree.transformers]

    # Try compiling the tree
    for version in ('2', '3'):
        tree.compile(target_version=version)

    # Check that the compiled tree is equal to the expected result
    assert tree == source_to_tree('''
        class Cls(object):
            def method(self):
                super(Cls, self)
        ''')

# Generated at 2022-06-12 04:19:09.322417
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:13.214102
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast
    import typed_astunparse

    source = ast.parse("""
        class A:
            def __init__(self):
                super()

        class B(A):
            def __init__(self):
                super()
    """)

    transformer = SuperWithoutArgumentsTransformer()
    source = transformer.visit(source)

    result = typed_astunparse.unparse(source)

    expected = """
        class A:
            def __init__(self):
                super(A, self)

        class B(A):
            def __init__(self):
                super(B, self)
    """

    assert result == expected

# Generated at 2022-06-12 04:19:19.302518
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from ..utils.helpers import bytecode_compare
    from .test_tree_transformer import TREE_TESTS

    for node, (src, result) in TREE_TESTS:
        tree = compile(src, '<test>', 'exec')
        c = SuperWithoutArgumentsTransformer(tree)
        c.visit(tree)
        assert bytecode_compare(compile(src, '<test>', 'exec'), tree) == result



# Generated at 2022-06-12 04:19:29.744253
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u

    # Simple
    tree = ast.parse(u('''
    class Foo(object):
        def t(self):
            super()
            super()
        def t2(self):
            super().bar()
            super().bar2()
    '''))
    SuperWithoutArgumentsTransformer(tree).run()

    assert u('''
    class Foo(object):
        def t(self):
            super(Foo, self)
            super(Foo, self)
        def t2(self):
            super(Foo, self).bar()
            super(Foo, self).bar2()
    ''') == u(tree)

    # TODO: classmethod/staticmethod

# Generated at 2022-06-12 04:19:39.665959
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    class Test(SuperWithoutArgumentsTransformer): pass

    tests = [
        ("""super()""", """super(Cls, self)"""),

        ("""super().method()""", """super(Cls, self).method()"""),

        ("""super(a,b,c)""", """super(a,b,c)"""),

        ("""super.method()""", """super.method()"""),

        ("""super(lambda x:x)""", """super(lambda x:x)"""),
    ]

    for test, expected in tests:
        tree = ast.parse(
            """class Test(object):
                def __init__(self, arg):
                    %s
            """ % test,
            mode='exec'
        )
        Test().visit(tree)


# Generated at 2022-06-12 04:19:41.762616
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing that super() calls are transformed to appropriate syntax"""

# Generated at 2022-06-12 04:20:21.776676
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:27.392818
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    code: str = 'super()'
    tree: ast.Module = ast.parse(code)
    func = tree.body[0].value

    assert isinstance(func, ast.Call)
    assert isinstance(func.func, ast.Name)
    assert func.func.id == 'super'
    assert not func.args


# Generated at 2022-06-12 04:20:29.636699
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_code = '''
    class A:
        def __init__(self):
            super()
    '''
    expected_output = '''
    class A:
        def __init__(self):
            super(A, self)
    '''
    utils.assert_converted(input_code, expected_output, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-12 04:20:32.829964
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""
        class A:
            def __init__(self):
                super()
    """)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert "super(A, self)" in to_source(tree)


# Generated at 2022-06-12 04:20:41.317650
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # type: () -> None
    """Unit tests for compiler.compile_ast._super.SuperWithoutArgumentsTransformer"""
    from ..compiler import compile_ast
    from ..utils.helpers import bytecode_to_str
    code = """
        class C(object):
            def __init__(self):
                super()
                self.x = 1

        class D(C):
            def __init__(self):
                super()
                self.y = 2
    """
    tree = compile_ast(code, target_version=(2, 7))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

# Generated at 2022-06-12 04:20:49.431266
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert transformer._tree.body[0].value.args[1].id == 'self'
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    assert transformer._tree.body[0].value.args[1].id == 'self'
    tree = ast.parse('super(a, b)')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert not transformer._tree_changed
    tree = ast.parse('a.super()')

# Generated at 2022-06-12 04:20:57.382442
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None,
        )
    node = SuperWithoutArgumentsTransformer(ast.parse('class X(): def test(): super()')).visit(node)
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'X'
    assert isinstance(node.args[1], ast.Name)

# Generated at 2022-06-12 04:21:05.132707
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # The AST of the source code to be tested
    node = ast.parse("""class Foo:
                            def method(self):
                                super()
                                super()
                        """, mode='exec')

    # The expected AST
    expected_node = ast.parse("""class Foo:
                            def method(self):
                                super(Foo, self)
                                super(Foo, self)
                        """, mode='exec')

    # Instantiate SuperWithoutArgumentsTransformer
    transformer = SuperWithoutArgumentsTransformer()
    # Transform the ast
    transformed_ast = transformer.visit(node)
    # Compare the transformed ast with the expected result
    assert ast.dump(transformed_ast) == ast.dump(expected_node)

# Generated at 2022-06-12 04:21:09.972043
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''def test():\n    super()'''
    ast_module = ast.parse(code)
    node_transformer = SuperWithoutArgumentsTransformer(ast_module)
    node_transformer.visit(ast_module)
    exec_module = node_transformer.compile()
    assert eval(exec_module) == 0

# Generated at 2022-06-12 04:21:17.474456
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import print_ast

    src = '''
        class Foo:
            def __init__(self):
                super()

        class Foo:
            @classmethod
            def bar(cls):
                super()
    '''

    expected_result = '''
        class Foo:
            def __init__(self):
                super(Foo, self)

        class Foo:
            @classmethod
            def bar(cls):
                super(Foo, cls)
    '''

    tree = source_to_ast(src)
    SuperWithoutArgumentsTransformer.run(tree)
    assert print_ast(tree) == expected_result
    print('*' * 80 + '\n')



# Generated at 2022-06-12 04:21:55.258333
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:01.591114
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    node = ast.Call(
        func=ast.Name(id='super'),
        args=[]
    )

    source = ast.parse("""
    def __init__(self, x, y):
        super()""")

    expected = ast.parse("""
    def __init__(self, x, y):
        super(Foo, self)""")

    t = SuperWithoutArgumentsTransformer()
    t.visit(source)

    assert ast.dump(expected) == ast.dump(source)

# Generated at 2022-06-12 04:22:02.701535
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:22:04.004093
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:22:05.120748
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:22:07.641992
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..tests.utils import transform

    code = 'super()'
    expected = 'super(Cls, self)'

    result = transform(SuperWithoutArgumentsTransformer, code)

    assert result == expected

# Generated at 2022-06-12 04:22:10.010646
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super()')
    transformer.visit(tree)
    source = astor.to_source(tree)
    assert source == 'super(Cls, self)'

# Generated at 2022-06-12 04:22:16.081843
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        assert(super().__class__ == super(C, cls).__class__ == super(C, self).__class__ == C)
    """
    expected_code = """
        assert(super(C, cls).__class__ == super(C, self).__class__ == C)
    """

    tree = ast.parse(code)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-12 04:22:16.526441
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:24.801762
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import transform
    from ..utils import ast_dump
    from ..utils.helpers import get_ast_node

    dumped_ast = ast_dump(transform(compile('super()', '<string>', 'exec', flags=8), 2, 7))
    assert dumped_ast == "Module(body=[FunctionDef(name='', args=arguments(args=[arg(arg='self', annotation=None)], vararg=None, kwonlyargs=[], kwarg=None, defaults=[], kw_defaults=[]), body=[Expr(value=Call(func=Super(args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[]), args=[], keywords=[]))], decorator_list=[], returns=None)])"

# Generated at 2022-06-12 04:23:49.159450
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import as_decorator, transform_tree
    from .sample_parses import super_samples
    for sample in super_samples:
        transform_tree(sample, [as_decorator(SuperWithoutArgumentsTransformer)])
        # We need to use eval here because ast.literal_eval can't handle None
        eval(compile(sample.body[0], filename="<ast>", mode="exec"))

# Generated at 2022-06-12 04:23:51.542239
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import inspect
    # Change these lines to test with different version of Python.
    version = (3, 7)
    ast_ = __import__("typed_ast.ast3")

# Generated at 2022-06-12 04:23:57.095420
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    t = SuperWithoutArgumentsTransformer()
    node = ast.Call()
    node.func = ast.Name()
    node.func.id = 'super'
    node.args = []
    node = t.visit_Call(node)
    assert len(node.args) == 2
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'

# Generated at 2022-06-12 04:24:05.146262
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..testing_utils import assert_code_equal
    from typed_ast import ast3 as ast

    for tree in [ast.parse('''
        class Test:
            def __init__(self, *args, **kwargs):
                super()
                super().__init__(*args, **kwargs)
            @classmethod
            def method(cls, *args, **kwargs):
                super()
                super().method(*args, **kwargs)
    ''')]:
        transformer = SuperWithoutArgumentsTransformer()
        tree = transformer.visit(tree)
        assert transformer._tree_changed

# Generated at 2022-06-12 04:24:14.109601
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('''
        class Test(object):
            def test(self):
                self.val = super()
    ''')

    transformer = SuperWithoutArgumentsTransformer(node)
    transformer.visit(node)

    assert transformer._tree_changed
    result = ast.dump(node)