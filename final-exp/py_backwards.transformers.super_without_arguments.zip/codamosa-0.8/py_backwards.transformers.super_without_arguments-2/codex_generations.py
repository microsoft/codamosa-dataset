

# Generated at 2022-06-12 04:14:22.269079
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astunparse
    import io
    import ast


# Generated at 2022-06-12 04:14:23.551617
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:14:33.090741
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_transformer

    def test_module(mod):
        # type: (ast.Module) -> ast.Module
        t = SuperWithoutArgumentsTransformer()
        new_tree = t.visit(mod)
        return new_tree

    mod = run_transformer(SuperWithoutArgumentsTransformer,
                          "class A(object):\n    def f(self): super()\n    def g(self, *args): super()\n")
    # TODO super() should be transformed
    # assert len(mod.body) == 1
    # cls = mod.body[0]
    # assert len(cls.body) == 2

    # print(ast.dump(mod))

# Generated at 2022-06-12 04:14:38.137609
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Test:
            def __init__(self, x):
                super()
                
            def test(self):
                super(Test, self)
        """
    expected_code = """
        class Test:
            def __init__(self, x):
                super(Test, self)
                
            def test(self):
                super(Test, self)
        """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert expected_code == astor.to_source(tree)

# Generated at 2022-06-12 04:14:48.127972
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from typed_ast import ast3
    from typed_ast.ast3 import FunctionDef, Name, ClassDef, Call

    tree = ast3.parse('super()')
    node = tree.body[0]
    assert isinstance(node, ast3.Expr)
    assert isinstance(node.value, Call)
    assert isinstance(node.value.func, Name)
    assert node.value.func.id == 'super'
    tree.body.insert(0, FunctionDef(name='func', args=ast3.arguments(args=[ast3.arg(arg='self')]), body=[], type_comment=None))
    tree.body.insert(0, ClassDef(name='Cls', bases=[], keywords=[], body=[], decorator_list=[]))

    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:14:48.713296
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:58.256632
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as py_ast

    py_ast.SuperWithoutArgumentsTransformer = SuperWithoutArgumentsTransformer  # type: ignore

    node = py_ast.parse("super()", mode='eval')
    py_ast.fix_missing_locations(node)

    trans = py_ast.SuperWithoutArgumentsTransformer()
    trans.visit(node)

    expected = py_ast.parse("super(cls, self)", mode='eval')
    py_ast.fix_missing_locations(expected)

    assert ast.dump(node) == ast.dump(expected)

    node = py_ast.parse("super('hello')", mode='eval')
    py_ast.fix_missing_locations(node)

    trans = py_ast.SuperWithoutArgumentsTransformer()
    trans.visit(node)

   

# Generated at 2022-06-12 04:15:07.587356
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast as std_ast
    from typed_ast import ast3 as typed_ast
    from typed_ast import convert, walk
    import StringIO

    tree = std_ast.parse("super()")
    typed_ast.ast3.fix_missing_locations(tree)
    walker = walk.Walker(SuperWithoutArgumentsTransformer)
    walker.walk(tree)
    output = StringIO.StringIO()
    convert(tree, output)
    # Check if the code to be compiled is as expected
    assert(output.getvalue().strip() == 'super(Cls, self)')

# Generated at 2022-06-12 04:15:17.451321
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Implicit super() call in __init__
    code = '''
    class cls1:
        def __init__(self):
            super().__init__()
    '''
    expected_code = '''
    class cls1:
        def __init__(self):
            super(cls1, self).__init__()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == expected_code, astor.to_source(tree)

    # Super() call inside another method
    code = '''
    class cls1:
        def method1(self):
            super().method1()
    '''

# Generated at 2022-06-12 04:15:18.319258
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")

# Generated at 2022-06-12 04:15:29.986774
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..common import parse
    from ..common import tokenize
    import io
    src = '''
        class Cls:
            def meth(self):
                super()
    '''
    nodes = parse(tokenize(io.StringIO(src).readline))
    node = nodes[0].body[0].body[0]

    transformer = SuperWithoutArgumentsTransformer(nodes)
    root = transformer.visit(nodes)

    print(''.join(node.s() for node in root))
    assert str(root[0]) == '<Module[<ClassDef.Cls[<FunctionDef.meth[<FunctionDef.meth[<Call.super[super(Cls, self)]]]]]]>'

# Generated at 2022-06-12 04:15:34.789543
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")
    SuperWithoutArgumentsTransformer().visit(node)
    assert ast.dump(node) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None)"

# Generated at 2022-06-12 04:15:37.733841
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..codegen import to_source
    from ..utils.helpers import assert_source


# Generated at 2022-06-12 04:15:45.793066
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import Compiler
    from .test_transformer import compile_to_function

    test = """
    class A:
        def __init__(self, x):
            super()
    """

    expected = """
    class A:
        def __init__(self, x):
            super(A, self)
    """

    def check(tree):
        assert isinstance(tree, ast.Module)
        cls = tree.body[0]
        assert isinstance(cls, ast.ClassDef)
        assert len(cls.body) == 1
        func = cls.body[0]
        assert isinstance(func, ast.FunctionDef)
        assert len(func.body) == 1
        call1 = func.body[0]
        assert isinstance(call1, ast.Expr)

# Generated at 2022-06-12 04:15:50.691471
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("super()")
    SuperWithoutArgumentsTransformer(node).compile()
    assert ast.dump(node) == "Call(Name(id='super', ctx=Load()), [Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], [], None, None)\n"

# Generated at 2022-06-12 04:15:52.151556
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:15:53.901336
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .utils import round_trip
    from .. import parse

# Generated at 2022-06-12 04:16:00.972234
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    import typed_astunparse
    from .test_setup import setup_test_module
    
    
    class TestSuperWithoutArgumentsTransformer_visit_Call(unittest.TestCase):
        """Tests method visit_Call of class SuperWithoutArgumentsTransformer"""
        def test_Call_super(self):
            code = '''
super()
'''
            node = ast.parse(code)
            tree = SuperWithoutArgumentsTransformer().visit(node)
            self.assertEqual(code, typed_astunparse.unparse(node))
            

# Generated at 2022-06-12 04:16:06.770776
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    super_call = tree.body[0].value.value
    assert len(super_call.args) == 2
    assert isinstance(super_call.args[0], ast.Name)
    assert isinstance(super_call.args[1], ast.Name)
    assert super_call.args[0].id == 'Cls'
    assert super_call.args[1].id == 'self'

# Generated at 2022-06-12 04:16:10.878541
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import generate_code
    from .. import compile_

    code = """
    class A(object):
        def __init__(self):
            super()
    """
    expected = """
    class A(object):
        def __init__(self, *args, **kwargs):
            super(A, self)
    """

    tree = compile_(code, '<test>', 'exec')
    assert generate_code(tree)[0] == expected

# Generated at 2022-06-12 04:16:18.544704
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from .base import BaseNodeTransformerTest
    import astor
    from .base import compile_func
    class Test(BaseNodeTransformerTest):
        def create_transformer(self) -> BaseNodeTransformer:
            return SuperWithoutArgumentsTransformer()


# Generated at 2022-06-12 04:16:27.446721
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A(object):
        def __init__(self):
            super()
    """
    node = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(node.body[0].body[0].value.args[0], ast.Name)
    assert node.body[0].body[0].value.args[0].id == 'A'
    assert isinstance(node.body[0].body[0].value.args[1], ast.Name)
    assert node.body[0].body[0].value.args[1].id == 'self'
    assert node.body[0].body[0].value.func.id == 'super'


# Generated at 2022-06-12 04:16:36.419418
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Visit block of code containing super() for a class
    def visit_block_code():
        code = """
            class Test(object):

                def __init__(self):
                    super()

        """
        node = ast.parse(code) # Create ast
        transformer = SuperWithoutArgumentsTransformer(node) # Create an instance of SuperWithoutArgumentsTransformer
        new_tree = transformer.visit(node) # Create a new tree by visiting the old one

        # Check that the new tree is the same as the expected one
        expected_code = """
            class Test(object):

                def __init__(self):
                    super(Test, self)

        """
        expected_tree = ast.parse(expected_code) # Create the ast to be compared to

        _assert_trees_equals(new_tree, expected_tree)

# Generated at 2022-06-12 04:16:38.549557
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:16:40.029870
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import parse


# Generated at 2022-06-12 04:16:49.029512
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import inspect
    import ast
    import textwrap

    # Check if class exists
    assert inspect.isclass(SuperWithoutArgumentsTransformer)

    # Check if class inheritance
    assert issubclass(SuperWithoutArgumentsTransformer, BaseNodeTransformer)

    source_code = textwrap.dedent('''
    class A:
        def __init__(self, x):
            super().__init__()
    ''')
    tree = ast.parse(source_code)
    transformer = SuperWithoutArgumentsTransformer(target_version=(3, 2), text=source_code, tree=tree)
    transformer.visit(tree)



# Generated at 2022-06-12 04:16:57.574742
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    if sys.version_info < (3, 8):
        cls_ast = compile(textwrap.dedent('''
            def f(self):
                super()
        '''), '<string>', 'exec', flags=compile.PYCF_ONLY_AST)

        func_ast = compile(textwrap.dedent('''
            class Cls:
                def f(self):
                    super()
        '''), '<string>', 'exec', flags=compile.PYCF_ONLY_AST)
    else:
        cls_ast = compile(textwrap.dedent('''
            def f(self):
                super()
        '''), '<string>', 'exec', flags=ast.PyCF_ONLY_AST)

        func

# Generated at 2022-06-12 04:17:03.778755
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse

    module = ast.parse(
        '''
        class Foo:
            def __init__(self):
                super()
        '''
    )

    transformer = SuperWithoutArgumentsTransformer(module)
    transformer.visit(module)

    expected = '''
        class Foo:
            def __init__(self):
                super(Foo, self)
        '''

    assert astunparse.unparse(module) == expected

# Generated at 2022-06-12 04:17:13.246050
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_string
    from .base import BaseTreeTransformer

    transformer = SuperWithoutArgumentsTransformer()

    @transformer.transform
    def func():
        """Docstring"""
        super()
        super()

    assert source_to_string(func) == (
        "def func():\n"
        "    'Docstring'\n"
        "    super(Cls, self)\n"
        "    super(Cls, cls)\n"
    )

    # Trying to call super() from outside a clas and/or function
    # Should raise a warning

    transformer = BaseTreeTransformer()

    @transformer.transform
    def func():
        super()

    assert func.__doc__ == 'super() outside of class'


# Generated at 2022-06-12 04:17:14.626353
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse

# Generated at 2022-06-12 04:17:21.237445
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:28.711040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTest
    import textwrap
    test_code = textwrap.dedent(u"""
        class Foo(Parent):
            def __init__(self):
                super().__init__()
        """)
    expected_code = textwrap.dedent(u"""
        class Foo(Parent):
            def __init__(self):
                super(Foo, self).__init__()
        """)
    BaseNodeTransformerTest(SuperWithoutArgumentsTransformer, test_code, expected_code).test()



# Generated at 2022-06-12 04:17:29.421778
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:29.883549
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:39.788411
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """super()"""
    output = """super(Cls, self)"""
    module = ast.parse(input)
    transformer = SuperWithoutArgumentsTransformer(input, tree = module, filename = 'test')

    with open("test.py", "w") as f:
        f.write("class Cls:\n\tdef __init__(self):\n\t\t" + input)

    with open("test.py", "r") as f:
        assert f.read() == "class Cls:\n\tdef __init__(self):\n\t\t" + input

    codeobj = compile(module, 'test', 'exec')
    exec(codeobj)

    transformer.visit(module)
    output_module = module
    codeobj = compile(output_module, 'test', 'exec')

# Generated at 2022-06-12 04:17:40.570350
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:49.486477
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = parse('super()')
    visitor = SuperWithoutArgumentsTransformer.run_on(tree)
    assert isinstance(visitor, SuperWithoutArgumentsTransformer)
    assert visitor._tree_changed is True

    tree = parse('def func(): super()')
    visitor = SuperWithoutArgumentsTransformer.run_on(tree)
    assert isinstance(visitor, SuperWithoutArgumentsTransformer)
    assert visitor._tree_changed is True

    tree = parse('class Cls: def func(): super()')
    visitor = SuperWithoutArgumentsTransformer.run_on(tree)
    assert isinstance(visitor, SuperWithoutArgumentsTransformer)
    assert visitor._tree_changed is True

# Generated at 2022-06-12 04:17:52.192607
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from ..utils.helpers import set_parent_nodes_if_not_exists
    from ..transpile import TypedTranspiler


# Generated at 2022-06-12 04:17:55.101108
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    unittest_input = """
        class SuperS:
            def method(self):
                super()
    """

    unittest_output = """
        class SuperS:
            def method(self):
                super(SuperS, self)
    """
    node = ast.parse(unittest_input)
    SuperWithoutArgumentsTransformer().visit(node)
    assert(astor.to_source(node) == unittest_output)

# Generated at 2022-06-12 04:17:57.118350
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse
    from ..utils.tree import print_tree

# Generated at 2022-06-12 04:18:07.461180
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert SuperWithoutArgumentsTransformer(None).visit_Call(ast.Call()) == ast.Call()

# Generated at 2022-06-12 04:18:13.201857
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
        # Test for simple example with super()
        code ="""
        class A:
            def __init__(self):
                super()
        """
        node = ast.parse(code)
        SuperWithoutArgumentsTransformer().visit(node) # type: ignore
        exec(compile(node, filename="<ast>", mode="exec"))


# Generated at 2022-06-12 04:18:18.089002
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    class A:
        super()
    """
    tree = ast.parse(dedent(test_SuperWithoutArgumentsTransformer.__doc__))
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == dedent(
        """\
        class A:
            super(A, self)
        """
    )


# Generated at 2022-06-12 04:18:18.686503
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:22.390548
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"), globals())   # pylint: disable=exec-used
    assert True


# Generated at 2022-06-12 04:18:27.621133
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    # Before
    before = ast.parse("""
        class Foo:
            def f(self):
                super()
                """)

    # After
    after = ast.parse("""
        class Foo:
            def f(self):
                super(Foo, self)
                """)

    node_transformer = SuperWithoutArgumentsTransformer(before)
    node_transformer.visit(before)
    assert ast.dump(node_transformer.tree) == ast.dump(after)

# Generated at 2022-06-12 04:18:28.929960
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:34.674105
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    tree = ast3.parse("""class Cls(object):
        def __init__(self, arg):
            super().__init__()

    obj = Cls('arg')""", mode='exec')
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    obj = tree.body[0].body[0].body[0].args
    assert obj[0].id == 'Cls'
    assert obj[1].id == 'self'

# Generated at 2022-06-12 04:18:36.755278
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:46.235918
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """class Cls(object):
    def __init__(self):
        super()
    def method(self, cls):
        super()"""

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.visit(tree)
    assert len(tree.body[0].body[0].body[0].args) == 2
    assert isinstance(tree.body[0].body[0].body[0].args[0], ast.Name)
    assert tree.body[0].body[0].body[0].args[0].id == 'Cls'
    assert isinstance(tree.body[0].body[0].body[0].args[1], ast.Name)

# Generated at 2022-06-12 04:18:55.909082
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that the super class's constructor works."""

# Generated at 2022-06-12 04:18:56.755964
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:06.258097
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class MockNode(ast.AST):
        def __init__(self) -> None:
            self.args = MockNode()
            self.arg = MockNode()
            self.id = 'args'
        def __iter__(self) -> Iterator[MockNode]:
            return iter([self.args])
    tree = MockNode()
    tree.body = [MockNode()]
    tree.body[0].body = [MockNode()]
    tree.body[0].body[0].func = MockNode()
    tree.body[0].body[0].func.id = 'super'
    tree.body[0].body[0].args = []
    tree.body[0].args = MockNode()
    tree.body[0].args.args = [MockNode()]

# Generated at 2022-06-12 04:19:07.961627
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import Parser
    from .test_helpers import transform


# Generated at 2022-06-12 04:19:15.212676
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    
    # Input
    input = '''
    class Test:
        def z(self):
            super()
    '''
    # Expectation
    expected_output = '''
    class Test:
        def z(self):
            super(Test, self)
    '''

    # Run test
    t = SuperWithoutArgumentsTransformer()
    new_tree = t.visit(ast.parse(input))

    # Verify output
    assert astor.to_source(new_tree).strip() == expected_output.strip()

# Generated at 2022-06-12 04:19:15.830352
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:19.613353
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    root = ast.parse('x = super()')

    SuperWithoutArgumentsTransformer(target = (2, 7)).visit(root)

    expected_ast = ast.parse('x = super(Cls, self)')

    assert ast.dump(root) == ast.dump(expected_ast)

# Generated at 2022-06-12 04:19:20.673760
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:23.947344
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from test.utils import round_trip_load, round_trip_dump

# Generated at 2022-06-12 04:19:33.088595
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class B:
        def __init__(self, c):
            super()
    
    class C:
        def __init__(self, c):
            super()
            
        def __init__(self):
            super()
    """
    expected_output = """
    class B:
        def __init__(self, c):
            super(B, self)
    
    class C:
        def __init__(self, c):
            super(C, self)
            
        def __init__(self):
            super(C, self)
    """

    tree = ast.parse(input)
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    assert ast.dump(tree) == expected_output



# Generated at 2022-06-12 04:19:55.392101
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    func_def = ast.parse('def test(self): super()')
    tree = func_def.body[0]
    transformer.visit(tree)
    assert tree.body[0].args == [ast.Name(id='Cls', ctx=ast.Load()), ast.Name(id='self', ctx=ast.Load())]

# Generated at 2022-06-12 04:19:59.732186
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = ast.parse('return super()')
    s.body[0].value.args = []
    t = SuperWithoutArgumentsTransformer(s)
    new_ast = t.visit(s)
    assert new_ast.body[0].value.args == [
        ast.Name(id='cls', ctx=ast.Load()),
        ast.Name(id='self', ctx=ast.Load())]



# Generated at 2022-06-12 04:20:00.808835
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:10.279118
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    code = 'super().foo()'
    tree = ast.parse(code)
    assert t.visit(tree) is None
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Call)
    assert isinstance(tree.body[0].value.func.func, ast.Name)
    assert tree.body[0].value.func.func.id == 'super'
    assert isinstance(tree.body[0].value.func.args[0], ast.Name)
    assert isinstance(tree.body[0].value.func.args[1], ast.Name)

# Generated at 2022-06-12 04:20:16.487952
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast
    import _ast
    from typed_ast import ast3 as typed_ast
    from textwrap import dedent
    frm = "from __future__ import print_function"
    assert isinstance(ast.parse(dedent(frm)), ast.Module)
    assert isinstance(typed_ast.ast3.parse(dedent(frm)), typed_ast.Module)
    source = "super()"
    tree = typed_ast.ast3.parse(dedent(source))
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    result = typed_ast.ast3.parse(dedent(
        """\
        super(Cls, self)
        """))
    assert ast.dump(tree) == ast.dump(result)
    assert tree == result


# Generated at 2022-06-12 04:20:26.543599
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys

    class SuperWithoutArgumentsTransformerTest(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self._tree_changed = False
            self._tree = ast.parse('cls().func(super())')
            self.generic_visit(self._tree)
            self._tree_changed = False
            self._tree = ast.parse('''
            class Cls:
                def __init__(self):
                    self.attr = super()
            ''')
            self.generic_visit(self._tree)
            self._tree_changed = False
            self._tree = ast.parse('func(super())')
            self.generic_visit(self._tree)

    sys.modules[__name__] = SuperWithoutArgumentsTransformerTest()

# Generated at 2022-06-12 04:20:27.947209
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..codegen.python_codegen import PythonCodeGenerator
    from ..parser.python_parser import PythonParser

# Generated at 2022-06-12 04:20:29.709537
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    node = ast.parse("super()")
    transformer.visit(node)
    assert transformer._tree_changed

# Generated at 2022-06-12 04:20:38.378508
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast

    from typed_ast import ast3 as typed_ast

    # Given
    class ASTNodeFactory():
        def Call(self, func, args):
            return typed_ast.Call(func, args, [], None, None)

        def Name(self, id):
            return typed_ast.Name(id, typed_ast.Load())

        def FunctionDef(self, name, args, body):
            return typed_ast.FunctionDef(name, typed_ast.arguments(args, [], None, None), body, [], None, None)

        def ClassDef(self, name, body):
            return typed_ast.ClassDef(name, [], body, [])

    class ASTTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self, tree):
            super().__init__(tree)
           

# Generated at 2022-06-12 04:20:46.257374
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """test_SuperWithoutArgumentsTransformer
    Tests if the SuperWithoutArgumentsTransformer works by 
    running the transformer on the following sample code:
    
    class A:
        def __init__(self, x=1):
            super()
            super()

    class B:
        def __init__(self, x=2):
            pass

    x = super()
    """
    # The sample code
    code = """class A:
        def __init__(self, x=1):
            super()
            super()
    class B:
        def __init__(self, x=2):
            pass
    x = super()"""

    # The expected output

# Generated at 2022-06-12 04:21:33.815019
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
    class Toto:
        def __init__(self):
            super()
            
    class Titi(Toto):
        def __init__(self):
            super().__init__()
            
    def nothing():
        super()
    """
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected_ast = ast.parse("""
    class Toto:
        def __init__(self):
            super(Toto, self)


    class Titi(Toto):
        def __init__(self):
            super().__init__()


    def nothing():
        super()
    """)
    assert ast.dump(tree) == ast.dump(expected_ast)

# Generated at 2022-06-12 04:21:37.737701
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    tree = astor.parse_file('examples/super_without_arguments.py', 2)
    SuperWithoutArgumentsTransformer(tree).run()

    with open('examples/super_without_arguments.out', 'r') as fd:
        assert fd.read() == astor.to_source(tree)

# Generated at 2022-06-12 04:21:42.560893
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import get_test_nodes

    nodes = get_test_nodes('''
    class MyClass(SuperClass):
        def __init__(self):
            super()
    ''')

    for node in nodes:
        SuperWithoutArgumentsTransformer().visit(node)

    assert str(nodes[2].value.args[1]) == "self"
    assert str(nodes[2].value.args[0]) == "MyClass"

# Generated at 2022-06-12 04:21:44.422677
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..util_ast import ast_to_source


# Generated at 2022-06-12 04:21:46.329576
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:47.623469
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    from ..utils.testing import check_transformer


# Generated at 2022-06-12 04:21:49.967633
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arrange
    from ..utils.source import Source


# Generated at 2022-06-12 04:21:55.188167
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # SuperWithoutArgumentsTransformer inherits from BaseNodeTransformer
    from ..utils.testing import assert_transformed
    from ..utils.testing import assert_unchanged

    assert_transformed(
        SuperWithoutArgumentsTransformer,
        "super()",
        """
        super(__class__, self)"""
    )

    assert_transformed(
        SuperWithoutArgumentsTransformer,
        """
        class Cls:
            def __init__(self):
                super()""",
        """
        class Cls:
            def __init__(self):
                super(Cls, self)"""
    )

    assert_unchanged(SuperWithoutArgumentsTransformer, "super(Cls, self)")

# Generated at 2022-06-12 04:21:56.038955
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:02.037017
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("""
super()
    """)
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert "".join(ast.dump(node)) == textwrap.dedent("""
    Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])
    """)

# Generated at 2022-06-12 04:23:35.288819
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .base import BaseNodeTransformerTestCase

    class TestTransformer(BaseNodeTransformer):
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            node.args = [ast.Name(id='Cls'), ast.Name(id='self')]

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                self._replace_super_args(node)
                self._tree_changed = True

            return self.generic_visit(node)


# Generated at 2022-06-12 04:23:37.497371
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:23:41.715466
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_before = '''class A:
    def __init__(self):
        super()
'''
    code_after = '''class A:
    def __init__(self):
        super(A, self)
'''
    result = SuperWithoutArgumentsTransformer().visit(ast.parse(code_before))
    assert ast.dump(ast.fix_missing_locations(result)) == ast.dump(ast.parse(code_after))

# Generated at 2022-06-12 04:23:44.635162
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""class New(object):
        def __init__(self):
            super()

        def test(self):
            super()""")
    SuperWithoutArgumentsTransformer().visit(tree)
    expected = ast.parse("""class New(object):
        def __init__(self):
            super(New, self)

        def test(self):
            super(New, self)""")
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 04:23:49.960071
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer, NodeTransformer
    class Dummy(BaseNodeTransformer):
        def visit_Name(self, node: ast.Name) -> ast.Name:
            raise NodeTransformer.StopTransformation()
    class Dummy2(BaseNodeTransformer):
        pass
    transformer = Dummy2()
    transformer.visit(ast.parse("""
super().meth().meth()
"""))

# Generated at 2022-06-12 04:23:59.298419
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode, source_to_ast
    cls = ast.ClassDef(
        name='Cls',
        body=[
            ast.FunctionDef(
                name="method",
                args=ast.arguments(
                    args=[ast.Name(id="self", ctx=ast.Param())],
                    vararg=None,
                    kwonlyargs=[],
                    kw_defaults=[],
                    kwarg=None,
                    defaults=[]
                ),
                body=[ast.Pass()],
                decorator_list=[],
                returns=None
            )
        ],
        decorator_list=[],
        keywords=[]
    )

    class_str = source_to_unicode(cls)

# Generated at 2022-06-12 04:24:00.330664
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test super() without arguments"""

# Generated at 2022-06-12 04:24:08.523675
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..ast_manipulation import SourceWrapper
    from .local_variable_duplicator import LocalVariableDuplicator

    code = """class Test:
    def test(self):
        super()
"""
    tree = ast.parse(code)

    sw = SourceWrapper(tree)
    lvd = LocalVariableDuplicator(sw)
    lvd.visit(tree)

    sw = SourceWrapper(tree)
    Transformer = SuperWithoutArgumentsTransformer(sw)
    new_tree = Transformer.visit(tree)

    assert new_tree.body[0].body[0].body[0].value.args[0].id == 'Test'

# Generated at 2022-06-12 04:24:13.308188
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == 'super(Cls, self)'
    tree = ast.parse('super()', mode='exec')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == 'super(Cls, self)'

# Generated at 2022-06-12 04:24:14.019432
# Unit test for constructor of class SuperWithoutArgumentsTransformer