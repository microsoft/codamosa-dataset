

# Generated at 2022-06-12 04:14:28.186593
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    import textwrap

    code = textwrap.dedent(
        """
        class A:
            def __init__(self):
                super()
        """
    )
    expected_code = textwrap.dedent(
        """
        class A:
            def __init__(self):
                super(A, self)
        """
    )
    tree = ast.parse(code)
    expected_tree = ast.parse(expected_code)

    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astunparse.unparse(tree) == astunparse.unparse(expected_tree)

# Generated at 2022-06-12 04:14:37.501841
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import Source
    from ..utils.helpers import ast_from_str
    from ..utils.tree import findall_nodes

    source = Source("""
        class V:
            def __init__(self):
                super().__init__()
    """)

    tree = SuperWithoutArgumentsTransformer().visit(ast_from_str(source.code))
    result = findall_nodes(tree, ast.Call)

    assert len(result) == 1

    assert isinstance(result[0], ast.Call)
    assert isinstance(result[0].func, ast.Name)
    assert result[0].func.id == 'super'
    assert len(result[0].args) == 2
    assert isinstance(result[0].args[0], ast.Name)

# Generated at 2022-06-12 04:14:38.071834
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:40.763136
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    assert 'super' not in astunparse.unparse(node)

# Generated at 2022-06-12 04:14:41.730484
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:44.480736
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..utils.helpers import print_result, compare_ast

    # Tests

# Generated at 2022-06-12 04:14:47.591557
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    expected_tree = ast.parse('super(Cls, self)')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:14:57.195183
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('class X: def f(self): x = super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)

# Generated at 2022-06-12 04:14:58.110100
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:59.489429
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:07.008663
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    cls = SuperWithoutArgumentsTransformer()
    result = cls.visit(node)
    assert(str(result) == 'super(Cls, self)')

# Generated at 2022-06-12 04:15:10.179866
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .support import get_node
    transformer = SuperWithoutArgumentsTransformer()

    assert get_node('super()', transformer) == \
        ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    assert transformer._tree_changed

# Generated at 2022-06-12 04:15:19.674230
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Cls(object):
        def method(self):
            super()
    """
    tree = ast.parse(code)
    visitor = SuperWithoutArgumentsTransformer(tree)
    visitor.visit(tree)
    assert(len(visitor.log)) == 1
    #assert(len(visitor.errors)) == 1
    assert(visitor.tree_changed) == True

    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 2

# Generated at 2022-06-12 04:15:30.076857
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
            class A():
                def f():
                    super()
                def g():
                    super(arg)
                def h():
                    super(A, self, arg)
            """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-12 04:15:36.638497
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..upgrader import upgrader
    src = """
    class A():
        def __init__(self):
            super()
    """

    expected = """
    class A():
        def __init__(self):
            super(A, self)
    """

    module, _ = upgrader.upgrade(src)
    assert_equals(ast.dump(module), expected)

# Generated at 2022-06-12 04:15:38.224746
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:15:40.411630
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code_object, code_object_to_ast


# Generated at 2022-06-12 04:15:46.609820
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    module = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(module)
    assert tree.body[0].value.args == [ast.Name(id='Cls'), ast.Name(id='self')]

    code = '''class Foo:
        def bar(self):
            super()
    '''
    module = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(module)
    assert tree.body[0].body[0].body[0].value.args == [ast.Name(id='Foo'), ast.Name(id='self')]

    code = 'super(Bar)'
    module = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(module)

# Generated at 2022-06-12 04:15:55.839449
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    from typed_astunparse import unparse

    from ..utils.ast_factory import factory
    from ..compiler import Compiler
    from ..python_2_to_3_types_ast import Python2To3TypesAST
    from ..python_2_to_3_types_transformer import Python2To3TypesTransformer

    compiler = Compiler()
    p2to3_transformer = Python2To3TypesTransformer()
    p2to3_ast = Python2To3TypesAST()
    transformer = SuperWithoutArgumentsTransformer()

    class Cls:
        def method(self):
            super(Cls, self)


# Generated at 2022-06-12 04:16:03.062378
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # super()
    x = ast.parse("super()")
    y = ast.parse("super(Cls, self)")
    transformer = SuperWithoutArgumentsTransformer(x)
    transformer.visit(x)
    assert transformer._tree == y

    # super()
    x = ast.parse("\nclass Cls:\n def func(self):\n  super()")
    y = ast.parse("\nclass Cls:\n def func(self):\n  super(Cls, self)")
    transformer = SuperWithoutArgumentsTransformer(x)
    transformer.visit(x)
    assert transformer._tree == y

    # super()
    x = ast.parse("\nclass Cls:\n @staticmethod\n def func():\n  super()")

# Generated at 2022-06-12 04:16:10.155099
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .mixins.transformers_for_tests import ModuleTransformersForTestsMixin
    from .mixins.source_code_for_tests import SuperSourceCodeForTestsMixin
    class ModuleTransformers(ModuleTransformersForTestsMixin):
        super_without_arguments = SuperWithoutArgumentsTransformer
    class SourceCode(SuperSourceCodeForTestsMixin, ModuleTransformers): pass
    check_source_code(SourceCode())

# Generated at 2022-06-12 04:16:15.307616
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_super = '''
          class Foo(object):
              def __init__(self):
                  super()
          class Bar(Foo):
              def __init__(self, n):
                  super(Bar, self)
          '''

    from typed_ast import parse

    # before
    tree = parse(code_super)
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            if node.id == 'super':
                assert node.lineno == 4
                assert node.col_offset == 22
                assert len(node.args) == 0

    SuperWithoutArgumentsTransformer.run_on_tree(tree)

    # after

# Generated at 2022-06-12 04:16:19.348869
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """\
a = super()
"""
    expect_output = """\
a = super(__class__, self)
"""
    tree = ast.parse(input)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert expect_output == ast.unparse(tree)

# Generated at 2022-06-12 04:16:20.439826
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast
    from .. import compile


# Generated at 2022-06-12 04:16:21.600626
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TODO: Implement.
    pass

# Generated at 2022-06-12 04:16:27.041886
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """class A():
        def f(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    fixed_code = astor.to_source(tree).strip()
    assert fixed_code == """class A():
    def f(self):
        super(A, self)"""
    print(fixed_code)

# Generated at 2022-06-12 04:16:29.311158
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import tree
    from ..utils import helpers
    import sys

# Generated at 2022-06-12 04:16:33.648877
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = textwrap.dedent("""
    class Spam:
        def __init__(self):
            super()
    """)

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(tree, filename="<ast>", mode="exec"))

# Generated at 2022-06-12 04:16:44.763744
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    from ..utils import setup_ast_node, setup_module_and_class
    from ..utils.submodule import rename_module, rename_module_import
    from ..utils.tree import search_tree_from_node
    from .base import BaseNodeTransformerTest

    class TestNodeTransformer(BaseNodeTransformerTest):
        node_transformer_class = SuperWithoutArgumentsTransformer
        target_node = 'Call'

        def test_with_method(self):
            code = '''
                class Cls:
                    def method(self):
                        super()
                '''
            node = setup_ast_node(code, self.target_node)
            node = rename_module_import(node, 'typed_ast.ast3', ast)

# Generated at 2022-06-12 04:16:50.406080
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer."""
    code = '''
        class A():
            def b(self):
                super()
        '''
    tree = ast.parse(code, '', 'exec')

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    expected_code = '''
        class A():
            def b(self):
                super(A, self)
        '''
    expected_tree = ast.parse(expected_code, '', 'exec')
    assert_equals(ast.dump(tree), ast.dump(expected_tree))


# Generated at 2022-06-12 04:17:02.969191
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    ast_tree = ast.parse(
        '''
        class MyClass(object):
            def __init__(self):
                super()
                pass
        '''
    )
    transformer = SuperWithoutArgumentsTransformer(ast_tree)
    transformer.visit(ast_tree)

# Generated at 2022-06-12 04:17:03.871565
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:10.519662
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast
    from ..utils.tree import print_tree
    module = get_ast('super().foo')
    SuperWithoutArgumentsTransformer(2, 7).visit(module)
    expected = "Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[])"
    actual = print_tree(module).strip()
    assert actual == expected.strip()

# Generated at 2022-06-12 04:17:12.588895
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    sut = SuperWithoutArgumentsTransformer()
    assert sut.transform(ast.parse('super()')) == ast.parse('super(cls, self)')


# Generated at 2022-06-12 04:17:15.195433
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "super()"
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(tree, '<test>', 'exec'))

# Generated at 2022-06-12 04:17:15.686791
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:20.096429
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert (SuperWithoutArgumentsTransformer(None)(ast.parse("super()"))) == (ast.parse("super(Cls, self)"))
    assert (SuperWithoutArgumentsTransformer(None)(ast.parse("super(a,b,c)"))) == (ast.parse("super(a,b,c)"))
    assert (SuperWithoutArgumentsTransformer(None)(ast.parse("foo()"))) == (ast.parse("foo()"))

# Generated at 2022-06-12 04:17:24.947208
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test constructor of SuperWithoutArgumentsTransformer works
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    transformer = SuperWithoutArgumentsTransformer()
    assert isinstance(transformer, BaseNodeTransformer)


# Generated at 2022-06-12 04:17:32.042744
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """class Cls(object):
    def func(self):
        s = super()
    def func2(cls):
        s = super()
    @classmethod
    def func3(cls):
        s = super()
    @staticmethod
    def func4():
        s = super()
"""
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-12 04:17:40.843387
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Test(object):
            def __init__(self, a):
                super().__init__(a)
    """

    node = ast.parse(code)
    transformed = SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-12 04:17:57.644307
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from libcst.codemod._codemod import CodemodContext, CodemodTest
    from libcst.metadata import ModuleMetadataWrapper
    from libcst.matchers import Name, Call, Arguments, FunctionDef, ClassDef

    class MyModuleTransformer(SuperWithoutArgumentsTransformer):
        METADATA_DEPENDENCIES = (ModuleMetadataWrapper,)

    source = """
        class Foo():
            def __init__(self):
                super()
    """

    context = CodemodContext(source, None, None, None, None, None)
    module = MyModuleTransformer(context).visit(context.module)
    wrapped = CodemodTest(module)


# Generated at 2022-06-12 04:18:02.254195
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse("""
        class A:
            def __init__(self):
                super()
    """)
    transformer.visit(tree)
    with open('target_super.py', 'w') as target:
        target.write(astor.to_source(tree))

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:18:04.762820
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:12.092133
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest

    class Test(unittest.TestCase):
        def test_simple(self):
            source = dedent('''
            class Foo:
                def __init__(self):
                    super()
            ''')
            expect = dedent('''
            class Foo:
                def __init__(self):
                    super(Foo, self)
            ''')
            self.assertEqual(SuperWithoutArgumentsTransformer(source).output, expect)

    unittest.main()

# Generated at 2022-06-12 04:18:15.304077
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    se = SuperWithoutArgumentsTransformer()

    # Test 1: super()
    class TestClassTransformer1:
        def __init__(self):
            self.tree_changed = False

# Generated at 2022-06-12 04:18:24.119780
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import get_all_names
    from ..utils.ast_helpers import get_child_of_type

    cls = source_to_ast("""
    class C(object):
        def __init__(self):
            super()
    """)

    assert len(get_all_names(cls)) == 0

    cls = source_to_ast("""
    class C(object):
        def __init__(self):
            super(1)
    """)

    assert len(get_all_names(cls)) == 0

    cls = source_to_ast("""
    class C(object):
        def f(self):
            super()
    """)


# Generated at 2022-06-12 04:18:24.543435
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:32.963683
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        def f(self):
            super()
    """
    tree = ast.parse(code)
    node = tree.body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'

    cls = ast.ClassDef(name='C', body=[ast.FunctionDef(name='f', args=ast.arguments(args=[ast.arg(arg='self')]))])
    tree.body.append(cls)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert isinstance(node.value.args[0], ast.Name)
    assert node.value

# Generated at 2022-06-12 04:18:42.302467
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass
#     root = ast.parse(
# '''
# class Cls:
#     def __init__(self):
#         super()
# '''
#     )
#     tree = parse_tree(root)
#     t = SuperWithoutArgumentsTransformer()
#     t.visit(tree)
#     assert t._tree_changed
#     assert str(tree) == '''
# class Cls:
#     def __init__(self):
#         super(Cls, self)
# '''

#     root = ast.parse(
# '''
# class Cls:
#     def __init__(self, arg):
#         super(arg)
# '''
#     )
#     tree = parse_tree(root)
#     t = SuperWithoutArgumentsTransformer()
#

# Generated at 2022-06-12 04:18:43.514547
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:03.408316
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    src = """
        class MyInt(int):
            def __init__(self, value):
                super().__init__(value)
    """
    expected_result = """
        class MyInt(int):
            def __init__(self, value):
                super(MyInt, self).__init__(value)
    """
    tree = ast.parse(src)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = ast.dump(tree)  # type: ignore
    assert result == expected_result

# Generated at 2022-06-12 04:19:08.002379
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    compiler = SuperWithoutArgumentsTransformer()
    compiler.visit(tree)
    codeobj = compile(tree, '', 'exec')
    ns = {}
    eval(codeobj, ns)
    super_call = ns['foo'].__super_call__
    assert super_call == 'super(Cls, self)'

# Generated at 2022-06-12 04:19:18.221180
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:18.723634
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:22.862335
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_code_to_ast import source_code_to_ast

    class TestTranspiler(BaseNodeTransformer):
        def visit_Call(self, node):
            return SuperWithoutArgumentsTransformer(self.tree).visit(node)


# Generated at 2022-06-12 04:19:24.097967
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:25.220603
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:31.452261
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    @add_to_class('__init__', """
    def __init__(self, n):
        super().__init__()
        
    """)
    class Foo:
        def __init__(self):
            super().__init__()
        
    assert Foo.__init__.__source__ == """
    def __init__(self, n):
        super(Foo, self).__init__()
        
    """
    assert Foo.__init__.__name__ == '__init__'

# Generated at 2022-06-12 04:19:33.282625
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_module
    from ..visitor import Visitor


# Generated at 2022-06-12 04:19:34.680122
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:04.895223
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:06.309122
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    import astor


# Generated at 2022-06-12 04:20:14.942856
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_compiled, compile_

    assert_compiled(
        textwrap.dedent('''\
            class Class:
                def __init__(self):
                    super()
        '''),
        textwrap.dedent('''\
            class Class:
                def __init__(self):
                    super(Class, self)
        ''')
    )


# Generated at 2022-06-12 04:20:19.033921
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import load_example_co

    co = load_example_co('super_without_args_ex1.py')

    SuperWithoutArgumentsTransformer(co).run()

    assert co == load_example_co('super_without_args_ex1_expected.py')

# Generated at 2022-06-12 04:20:28.451907
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest
    import random
    import string

    from typed_ast import ast3 as ast
    from ..exceptions import WrongTransformerTargetVersion
    from ..utils.helpers import target_version_str

    # Create a random class name
    cls_name = ''.join(random.choice(string.ascii_uppercase) for _ in range(10))
    # Create a random function name
    func_name = ''.join(random.choice(string.ascii_uppercase) for _ in range(10))

    # Test for Python 2

# Generated at 2022-06-12 04:20:34.594022
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():  # noqa
    # 2.7: super(cls, self)
    code = '''
    class C:
        def __init__(self):
            super()
    '''
    expected = '''
    class C:
        def __init__(self):
            super(C, self)
    '''
    # Act
    res = SuperWithoutArgumentsTransformer()(ast.parse(code))
    # Assert
    aft = ast.parse(expected)
    # TODO: do we want to compare str(res) with str(aft)?
    assert ast.dump(res) == ast.dump(aft)


# Generated at 2022-06-12 04:20:43.498664
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import parse
    from ..utils.helpers import get_ast_node_type

    source = '''
            class a:
                def __init__(self, a, b=1, c=2):
                    self.a = a
                    super()
                    super()
                    super()
                    super()
                def d(self, a, b=1, c=2):
                    self.a = a
                    super()
                    super()
                    super()
                    super()
            '''
    tree = parse(source)
    result = SuperWithoutArgumentsTransformer().visit(tree)
    assert get_ast_node_type(result.body[0].body[0].body[0].value) == 'Call'

# Generated at 2022-06-12 04:20:44.258473
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:20:46.119422
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Test for making sure that super() becomes super(Cls, self)
    """


# Generated at 2022-06-12 04:20:47.188118
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

# Generated at 2022-06-12 04:22:08.447741
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    cls = ast.parse('class C(object): def f(self): super()').body[0]
    transformer = SuperWithoutArgumentsTransformer(ast.Module([cls]), target_version=(2, 7))
    transformer.visit(cls)
    assert transformer._tree_changed

# Generated at 2022-06-12 04:22:16.837143
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Spam:
        def spam(self):
            super()
    """
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-12 04:22:22.286590
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import Source

    source = Source("""
    class A:
        def __init__(self):
            super().__init__()
    """)
    tree = get_ast(source)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert tree.body[0].body[0].value.args[0].id == "A"
    assert tree.body[0].body[0].value.args[1].id == "self"

# Generated at 2022-06-12 04:22:23.742497
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:26.706720
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def b(self):
            super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(tree, '', 'exec'))

# Generated at 2022-06-12 04:22:27.793872
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse


# Generated at 2022-06-12 04:22:34.775619
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest

    class TestCase(unittest.TestCase):
        def test_super(self):
            from typed_ast import parse

            source = """
            class X:
                def __init__(self):
                    super()
            """
            expected = """
            class X:
                def __init__(self):
                    super(X, self)
            """
            module_node = parse(source)
            transformer = SuperWithoutArgumentsTransformer()
            transformer.visit(module_node)
            module_expected = parse(expected)
            self.assertEqual(
                ast.dump(module_node),
                ast.dump(module_expected)
            )

    unittest.main()



# Generated at 2022-06-12 04:22:35.440316
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse


# Generated at 2022-06-12 04:22:36.546369
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_for_version
    from ..python_code import PythonCode


# Generated at 2022-06-12 04:22:38.333868
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass
