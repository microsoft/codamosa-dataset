

# Generated at 2022-06-12 04:14:16.975582
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from .test_helpers import _transform_test


# Generated at 2022-06-12 04:14:21.259190
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from . import get_ast

    code = get_ast("""
    class Cls(object):
        def meth(self):
            super()
    """)

    typ_code = get_ast("""
    class Cls(object):
        def meth(self):
            super(__class__, self)
    """)

    tr = SuperWithoutArgumentsTransformer(code)
    tr.visit(code)

    assert code == typ_code

# Generated at 2022-06-12 04:14:31.857117
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import os
    import astor
    from .. import get_ast, parse_python_source, get_python_source
    from ..utils.ast_helpers import iter_ast_node_of_type, get_first_ast_node_of_type

    path = os.path.dirname(__file__) + '/data/super_without_arguments.py'
    with open(path, 'r') as f:
        data = f.read()

    # Parse to AST
    tree = get_ast(parse_python_source(data))
    func = list(iter_ast_node_of_type(tree, ast.FunctionDef))[-1]
    node = get_first_ast_node_of_type(func, ast.Call)

    # Test constructor

# Generated at 2022-06-12 04:14:33.528426
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astor import to_source
    from ..utils.helpers import get_ast


# Generated at 2022-06-12 04:14:43.120940
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    test_SuperWithoutArgumentsTransformer check
    """
    class_string = "class sample: def __init__(self): super()"
    class_ast = ast.parse(class_string)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(class_ast)

# Generated at 2022-06-12 04:14:51.579546
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from .helpers import get_node
    from .super_without_arguments import SUPER_WITHOUT_ARGUMENTS_TEST_CASES

    for test_case in SUPER_WITHOUT_ARGUMENTS_TEST_CASES:
        tree = ast.parse(test_case)
        old_tree = copy.deepcopy(tree)
        SuperWithoutArgumentsTransformer().visit(tree)
        assert astor.to_source(old_tree) != astor.to_source(tree)
        assert get_node(tree, test_case) is not None


# pop()
# test_SuperWithoutArgumentsTransformer_visit_Call()

# Generated at 2022-06-12 04:14:56.801615
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import c, parse
    from .. import tree
    t = parse('''
        class A:
            def m(self):
                return super()
    ''')
    assert tree.dump_c(SuperWithoutArgumentsTransformer().visit(t)) == c('''
        class A:
            def m(self):
                return super(A, self)
    ''')


# Generated at 2022-06-12 04:14:58.089106
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.codegen import to_source


# Generated at 2022-06-12 04:15:00.680875
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:01.664665
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:09.840072
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = """
    class A:
        def __init__(self):
            super().__init__()
    """
    expected_code = """
    class A:
        def __init__(self):
            super(A, self).__init__()
    """
    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(code))
    assert ast.dump(ast.parse(expected_code)) == ast.dump(t.tree)

# Generated at 2022-06-12 04:15:10.757154
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:15:17.528338
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    src = '''
        class A(object):
            def __init__(self):
                super()
                pass
        pass
    '''
    expected = '''
        class A(object):
            def __init__(a0):
                super(A, a0)
                pass
        pass
    '''
    tree = ast.parse(src)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert ast.dump(tree) == expected

# Generated at 2022-06-12 04:15:26.921935
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # pylint: disable=C0111
    # this is a unit test, not a function
    cls_str = '''
    class A:
        def __init__(self):
            super()
    '''

    expected_cls_str = '''
    class A:
        def __init__(self):
            super(A, self)
    '''

    from . import default_transforms
    from ..utils import get_ast
    from ..transformer import Transformer
    cls_ast = get_ast(cls_str)
    t = Transformer(cls_ast)
    for transform in default_transforms:
        t.register(transform)
    t.run()
    assert ast.unparse(cls_ast) == expected_cls_str

# Generated at 2022-06-12 04:15:27.645714
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:30.301609
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    assert str(node) == 'super(C, self)'

# Generated at 2022-06-12 04:15:34.745989
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import assert_transformation, get_ast

    tree = get_ast("super()")
    assert_transformation(
        SuperWithoutArgumentsTransformer,
        tree,
        """
        class Cls(object):
            def f(self):
                super(Cls, self)
        """
    )

# Generated at 2022-06-12 04:15:36.178144
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:37.886118
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:15:45.850114
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # assert that the module compiles and can be imported
    import unittest.mock as mock
    import sys

    tree = mock.Mock(type_ignores=[], spec_set=ast.AST)

    transformer = SuperWithoutArgumentsTransformer(tree, mock.Mock(spec=sys.stderr))

    # assert that the _replace_super_args method works
    node = ast.Call()
    func = ast.FunctionDef()
    func.args.args = [ast.arg()]
    func.args.args[0].arg = 'testName'
    cls = ast.ClassDef()
    cls.name = 'testClassName'

    transformer._tree.body = [cls, func]

    transformer._replace_super_args(node)


# Generated at 2022-06-12 04:15:52.961879
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .. import tree
    from .. import utils
    from ..utils.source import source_to_unicode

    source = source_to_unicode("""class A:
    def __init__(self):
        super()""")
    tree = tree.build_ast_tree(source, ('2.7', '3.6'))
    SuperWithoutArgumentsTransformer(tree).run()
    # print(tree.show())
    expected_source = source_to_unicode("""class A:\n    def __init__(self):
        super(A, self)""")
    assert utils.tree.convert_and_compare(tree, expected_source)

# Generated at 2022-06-12 04:15:55.110621
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import run_transformer
    from ..exceptions import InvalidPython

    # Valid: super()

# Generated at 2022-06-12 04:16:02.730261
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest
    from typed_ast import ast3 as ast
    from ..utils.tree_builder import build_ast_tree
    from ..utils.helpers import make_call_expression

    class Test(unittest.TestCase):
        def test(self):
            module = ast.Module()
            class_def = ast.ClassDef(name='Cls', body=[], decorator_list=[])
            function_def = ast.FunctionDef(name='foo', args=ast.arguments(args=[ast.arg(arg='self')]), body=[ast.Expr(value=make_call_expression(func='super', args=[]))])
            module.body = [class_def, function_def]
            tree = build_ast_tree(root=module)

            transformer = SuperWithoutArgumentsTransformer()
            transformer.vis

# Generated at 2022-06-12 04:16:10.176921
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    #super() to super(Cls, self)
    @add_transformer(SuperWithoutArgumentsTransformer)
    def test1():
        class Foo:
            def bar(self):
                super()

                # verify that super() is not replaced in other places
                return super
    assert test1() == '\n\nclass Foo:\n    def bar(self):\n        super(Foo, self)\n\n        # verify that super() is not replaced in other places\n        return super\n'

    #super() to super(Cls, cls)
    @add_transformer(SuperWithoutArgumentsTransformer)
    def test2():
        class Foo:
            @classmethod
            def bar(cls):
                super()

                # verify that super() is not replaced in other places
                return super
    assert test

# Generated at 2022-06-12 04:16:18.808561
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that expression 'super()' is compiled to 'super(Cls, self)'"""
    # Given
    class_node = ast.ClassDef(name='FooClass', body=[
        ast.FunctionDef(name='foo_method', args=ast.arguments(args=[ast.Name(id='self', ctx=ast.Param())],
                                                               vararg=None,
                                                               kwarg=None,
                                                               defaults=[]),
                        body=[
                            ast.Call(func=ast.Name(id='super'), args=[],
                                     keywords=[], starargs=None, kwargs=None)
                        ], decorator_list=[], returns=None)
    ])
    tree = ast.Module(body=[class_node])
    # When
    SuperWithoutArgumentsTransformer(tree).run

# Generated at 2022-06-12 04:16:26.217847
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    source = inspect.cleandoc(
        """
        class Cls:
            def method(self):
                super()
        """
    )

    expected_result = inspect.cleandoc(
        """
        class Cls:
            def method(self):
                super(Cls, self)
        """
    )

    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)

    assert ast.dump(new_tree) == ast.dump(ast.parse(expected_result))

# Generated at 2022-06-12 04:16:35.793581
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...unitutil import initializer_mock

    node = initializer_mock(ast.Call, args=[])
    arg = initializer_mock(ast.Name, id='super')
    node.func = arg
    tree = initializer_mock(ast.Module, body=[node])
    transformer = initializer_mock(SuperWithoutArgumentsTransformer)
    transformer._tree = tree
    transformer._replace_super_args = initializer_mock(SuperWithoutArgumentsTransformer._replace_super_args)
    transformer.generic_visit = initializer_mock(BaseNodeTransformer.generic_visit)
    node_1 = transformer.visit_Call(node)
    transformer._replace_super_args.assert_called_once_with(node)
    assert transformer._tree_changed

# Generated at 2022-06-12 04:16:45.558770
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_source
    from ..utils.helpers import get_ast_node

    source = """
        class Person:
            def __init__(self):
                super()
    """

    tree = compile_source(source, __file__, attr_transformer=SuperWithoutArgumentsTransformer)
    node = get_ast_node(tree, ast.Call)
    assert isinstance(node, ast.Call)
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'Person'
    assert isinstance(node.args[1], ast.Name)
    assert node.args[1].id == 'self'

# Generated at 2022-06-12 04:16:55.348544
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def visit_Call(self, node: ast.Call) -> ast.AST:
        if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
            self._replace_super_args(node)
            self._tree_changed = True

        return self.generic_visit(node)  # type: ignore
    visit_Call = SuperWithoutArgumentsTransformer.visit_Call.__func__
    tree, target, flags = ast.parse(textwrap.dedent('''\
    class A:
        def __init__(self):
            super()
    ''')), None, None
    node = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer(tree, target, flags)
    transformer.generic_visit=lambda x:x
   

# Generated at 2022-06-12 04:17:05.197281
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:21.122094
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    f = lambda: super()
    tree = ast.parse(inspect.getsource(f))
    func = tree.body[0].value
    node = func.body[0]
    transformed = SuperWithoutArgumentsTransformer().visit(node)
    assert isinstance(transformed, ast.Expr)
    assert isinstance(transformed.value, ast.Call)
    assert isinstance(transformed.value.func, ast.Name)
    assert transformed.value.func.id == 'super'
    assert len(transformed.value.args) == 2
    assert isinstance(transformed.value.args[0], ast.Name)
    assert isinstance(transformed.value.args[1], ast.Name)
    assert isinstance(transformed.value.keywords, list)

# Generated at 2022-06-12 04:17:30.696996
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = 'super()'
    root_node = ast.parse(code)
    node = list(ast.walk(root_node))[-1]
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert not len(root_node.body[0].body)

    node = SuperWithoutArgumentsTransformer().visit(node)

    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert isinstance(node.args[0].ctx, ast.Load)

# Generated at 2022-06-12 04:17:31.186477
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:33.848578
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode

# Generated at 2022-06-12 04:17:39.672661
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast
    source = '''
    class Test:
        def method(self):
            super()
    '''
    module = compile_to_ast(source, 2, 6)
    module = SuperWithoutArgumentsTransformer().visit(module)
    assert get_method_call(module, 'super()').args[0].id == 'Test'
    assert get_method_call(module, 'super()').args[1].id == 'self'
    

# Generated at 2022-06-12 04:17:48.887630
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
    class Foo:
        def __init__(self):
            super().__init__()

    class Bar(Foo):
        def __init__(self):
            super().__init__()
    """
    target = """
    class Foo:
        def __init__(self):
            super(Foo, self).__init__()

    class Bar(Foo):
        def __init__(self):
            super(Bar, self).__init__()
   """
    node = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(node)
    result = compile(node, '', mode='exec')
    assert(target == str(result))


# Generated at 2022-06-12 04:17:55.819304
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = 'super()'
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    assert ast.dump(new_tree, include_attributes=True) == """Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"""

# Generated at 2022-06-12 04:18:02.665423
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from codebase import compile_ast
    from io import StringIO
    from contextlib import redirect_stdout

    f = StringIO()

# Generated at 2022-06-12 04:18:13.892110
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast

    code = '''
        class Cls:
            def method(self):
                super().__init__()
    
        class Cls2(Cls):
            def __init__(self):
                super().__init__()
        '''

    expected = '''
        class Cls:
            def method(self):
                super(Cls, self).__init__()
    
        class Cls2(Cls):
            def __init__(self):
                super(Cls2, self).__init__()
        '''

    tree = source_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    actual = ast.to_source(tree)

    assert actual == expected

# Generated at 2022-06-12 04:18:14.564230
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:33.088561
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import assert_conversion, generate_python_ast, parse_to_ast
    # Test super() works correctly inside of class and function

# Generated at 2022-06-12 04:18:42.434190
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Test with a tree of a single super()
    # class A:
    #     def __init__(self):
    #         super()
    tree = ast.parse("""
        class A:
            def __init__(self):
                super()
    """)  # type: ast.Module

    # Before compilation

# Generated at 2022-06-12 04:18:48.390282
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Foo(object):
            def bar(self):
                return super()
    """
    tree = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    expected = ast.parse(
        """
        class Foo(object):
            def bar(self):
                return super(Foo, self)
    """
    )
    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-12 04:18:58.039673
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Call, Name, FunctionDef, Load, ClassDef

    source1 = """
    class A:
        def b(self):
            super()
    """
    expected1 = """
    class A:
        def b(self):
            super(A, self)
    """

    tree1 = ast.parse(source1)
    SuperWithoutArgumentsTransformer().visit(tree1)
    assert ast.dump(tree1) == ast.dump(ast.parse(expected1))

    source2 = """
    class A:
        class B:
            def c(self):
                super()
    """
    expected2 = """
    class A:
        class B:
            def c(self):
                super(A, self)
    """



# Generated at 2022-06-12 04:19:08.043250
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Method 1: Super without arguments
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree, ast.Module)
    assert isinstance(tree.body[0], ast.Expr)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert tree.body[0].value.func.id == 'super'
    assert len(tree.body[0].value.args) == 2
    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].value.args[1], ast.Name)

# Generated at 2022-06-12 04:19:18.221637
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test for super()
    node = ast.parse("""super()""")
    SuperWithoutArgumentsTransformer().visit(node)
    assert ast.dump(node) == "Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))"

    # test for super(b)
    node = ast.parse("""super(b)""")
    SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-12 04:19:19.747226
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import get_ast


# Generated at 2022-06-12 04:19:20.765414
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:21.272237
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:28.784658
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3

    node = ast3.parse("super()")
    try:
        SuperWithoutArgumentsTransformer().visit(node)
    except NodeNotFound:
        pass
    else:
        assert False
    assert node == ast3.parse("super()")

    node = ast3.parse("super(1, 2, 3)")
    SuperWithoutArgumentsTransformer().visit(node)
    assert node == ast3.parse("super(1, 2, 3)")
    

# Generated at 2022-06-12 04:20:09.275852
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from ..utils.python2to3 import convert
    from ast_tools.transforms import SuperWithoutArgumentsTransformer

    code = """
    class A:
        def foo(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree)
    assert convert(tree) == """
        class A:
            def foo(self):
                super(A, self)
        """



# Generated at 2022-06-12 04:20:15.691468
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_helper import ast_to_str

    class ExampleUnittest(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return super().visit_Call(node)

    example = '''
        class A(object):
            def __init__(self):
                super()
    '''

    expected = '''
        class A(object):
            def __init__(self):
                super(A, self)
    '''
    tree = ast.parse(example)
    ExampleUnittest(2, 7).visit(tree)
    assert ast_to_str(tree) == expected

# Generated at 2022-06-12 04:20:25.992663
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Simple usage
    tree = ast.parse(
        textwrap.dedent(
            """
            class Foo(object):
                def __init__(self):
                    super()
                def __call__(self):
                    super()
            """
        ), "exec"
    )

    expected_tree = ast.parse(
        textwrap.dedent(
            """
            class Foo(object):
                def __init__(self):
                    super(Foo, self)

                def __call__(self):
                    super(Foo, self)
            """
        ), "exec"
    )
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert ast.dump(tree) == ast.dump(expected_tree)


    # Multiple super()'s in a function.
    tree = ast

# Generated at 2022-06-12 04:20:29.626847
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""super(type(self), self)""")
    tree_transformed = SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert isinstance(tree_transformed, ast.Module) and tree_transformed.body[0].value.func.args[0].func.value.id == 'super'


# Generated at 2022-06-12 04:20:38.306429
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_transform

    assert_transform(
        SuperWithoutArgumentsTransformer,
        '''
        class A:
            def f(self):
                super()
        ''',
        '''
        class A:
            def f(self):
                super(A, self)
        ''',
        2,
    )
    assert_transform(
        SuperWithoutArgumentsTransformer,
        '''
        class A:
            @classmethod
            def f(cls):
                super()
        ''',
        '''
        class A:
            @classmethod
            def f(cls):
                super(A, cls)
        ''',
        2,
    )

# Generated at 2022-06-12 04:20:39.594325
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests the constructor of class SuperWithoutArgumentsTransformer"""
    assert SuperWithoutArgumentsTransformer() is not None

# Generated at 2022-06-12 04:20:44.469790
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # input
    tester = SuperWithoutArgumentsTransformer()
    tree = ast.parse('class A:\n def foo(self):\n  super()')

    # expected
    expected = ast.parse('class A:\n def foo(self):\n  super(A, self)')

    # make test
    tester.visit(tree)

    # compare to expected
    assert ast.dump(expected) == ast.dump(tree)



# Generated at 2022-06-12 04:20:51.173979
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """ Unit testing for SuperWithoutArgumentsTransformer """
    # super()
    node = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(node)
    # import astunparse
    # print(astunparse.unparse(tree))
    assert(str(tree) == "Module(body=[Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])")

# Generated at 2022-06-12 04:20:51.665920
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-12 04:20:52.785353
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:47.357154
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse("""
        class A:
            def __init__(self):
                super()
            def func(self):
                def internal():
                    super()
    """)
    SuperWithoutArgumentsTransformer(tree).transform()

    expected = """
        class A:
            def __init__(self):
                super(A, self)
            def func(self):
                def internal():
                    super(A, self)
    """
    assert ast.dump(tree, include_attributes=True) == ast.dump(ast.parse(expected), include_attributes=True)

# Generated at 2022-06-12 04:21:54.695521
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import get_ast

    code = '''class Class(object):
        def __init__(self, x):
            super()
            
    '''
    tree = get_ast(code, (2, 7))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name) and node.func.id == 'super'
    assert isinstance(node.args[0], ast.Name) and node.args[0].id == "Class"
    assert isinstance(node.args[1], ast.Name) and node.args[1].id == "self"

# Generated at 2022-06-12 04:22:03.618670
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import List
    from typed_ast.ast3 import Module, FunctionDef, ClassDef, Expr, Str, Call

    # Input

# Generated at 2022-06-12 04:22:04.433627
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor


# Generated at 2022-06-12 04:22:12.996128
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class MyClass(object):
        def my_function(self):
            super()

        def my_classmethod(cls):
            super()

        def my_other_function(self, other):
            super()
    """
    tree = ast.parse(code)
    super_method_transformer = SuperWithoutArgumentsTransformer(tree)
    super_method_transformer.run()

    calls = [call for call in ast.walk(tree) if isinstance(call, ast.Call)]
    all_super_args: List[str] = ['MyClass', 'self']
    all_super_args_classmethod: List[str] = ['MyClass', 'cls']


# Generated at 2022-06-12 04:22:16.307968
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import textwrap
    from ..utils.helpers import cst_to_ast
    node = cst_to_ast(textwrap.dedent("""
    class A:
        def __init__(self):
            super()
    """))
    tree = SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-12 04:22:18.306518
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import compile_source
    from . import to_source
    assert_equal = __import__('typed_astunparse').assert_equal


# Generated at 2022-06-12 04:22:18.766545
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:27.521811
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    module_ast = astor.code_to_ast.parse_file('./examples/super.py')

    transformer = SuperWithoutArgumentsTransformer()
    with warnings.catch_warnings(record=True) as w:
        transformer.visit(module_ast)
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)

    # Test that this example still compiles
    compiled_module = compile(module_ast, 'super.py', 'exec')

    context = {}
    exec(compiled_module, context)
    assert context['x'].__str__() == 'Cls.meth: A'
    assert context['y'].__str__() == 'B.meth: B'

# Generated at 2022-06-12 04:22:35.026802
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast.ast3 import Pass, FunctionDef, Name, Load, ClassDef, Call, Store, Expr

    tree = ast.parse('super()')
    cls = ClassDef(name='Test', bases=[], keywords=[], body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))], decorator_list=[])

# Generated at 2022-06-12 04:24:11.357777
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:24:12.284331
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:24:19.548963
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast as pyast
    from typed_ast import ast3 as typed_pyast
    from ..utils.tree import print_tree, tree_to_str
    from .test_helpers import assert_source_equal, parse_to_ast

    test_source = """
    class Class:
        def __init__(self):
            super()
    """
    expected_source = """
    class Class:
        def __init__(self):
            super(Class, self)
    """
    tree = parse_to_ast(test_source, 2, 7)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert_source_equal(tree_to_str(tree), expected_source)
