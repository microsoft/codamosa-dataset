

# Generated at 2022-06-12 04:14:30.762194
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import get_node_as_string
    from . import TRANSFORMERS
    from ..utils.ast_converter import AstConverter
    from ..tools import remove_transformer_from_copy

    ast_converter = AstConverter(remove_transformer_from_copy(TRANSFORMERS, SuperWithoutArgumentsTransformer))
    node = ast_converter.get_ast_from_str("super()")
    SuperWithoutArgumentsTransformer(ast_converter.tree).visit(node)
    assert get_node_as_string(node) == "super(B, this)"

# Generated at 2022-06-12 04:14:37.300771
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    from ..utils.node_test_mixin import NodeTestMixin

    class Test(NodeTestMixin):
        target = (2, 7)
        transformer = SuperWithoutArgumentsTransformer
        expect_code = '''
        class A:
            def method(self, a, b):
                super(A, self)
                def inner_method(self, n):
                    super(A, self)
        '''

    tree = source_to_nodes(Test.expect_code, Test.target)
    Test.transformer(False, tree).run()
    Test.check(tree)

# Generated at 2022-06-12 04:14:38.157806
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:40.481159
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import PythonParser
    from ..transpile import Transpiler
    from ..tokenize import generate_tokens


# Generated at 2022-06-12 04:14:50.130988
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_isolated
    from textwrap import dedent

    # Transform super() to super(Cls, self)
    with pytest.warns(UserWarning):
        compile_isolated(dedent('''
        class A:
            def __init__(self):
                super()
        '''), '<test>', 'exec')
    compile_isolated(dedent('''
        class A:
            def __init__(self):
                super(A, self)
        '''), '<test>', 'exec')

    # Transform super() to super(Cls, cls)

# Generated at 2022-06-12 04:14:51.223207
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:51.751336
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:00.480149
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    # Test for simple class with super() and function inside it
    tree = ast.parse(
        """
        class A:
            def func(self):
                super()
        """
    )
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    expected_code = (
        """
        class A:
            def func(self):
                super(A, self)
        """
    )
    assert astor.to_source(tree).strip() == expected_code.strip()

    # Test for function outside of class
    tree = ast.parse(
        """
        super()
        """
    )
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    # Check that tree didn't changed

# Generated at 2022-06-12 04:15:02.935939
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import string_to_module, module_to_string

# Generated at 2022-06-12 04:15:08.337911
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()

    code = """
    super()
    """
    tree = ast.parse(code)

    tree = transformer.visit(tree)

    code_2 = """
    super(cls, self)
    """
    tree_2 = ast.parse(code_2)

    assert ast.dump(tree) == ast.dump(tree_2)

# Generated at 2022-06-12 04:15:20.379199
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import textwrap
    from ..testing import assert_source

    source = textwrap.dedent("""\
        class A(object):
            def __init__(self):
                super()
        
        class B(object):
            def __init__(self, attr):
                super().__init__()
        """)
    expected = textwrap.dedent("""\
        class A(object):
            def __init__(self):
                super(A, self)

        class B(object):
            def __init__(self, attr):
                super(B, self).__init__()
        """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert_source(tree, expected)

# Generated at 2022-06-12 04:15:21.090358
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:22.742747
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode


# Generated at 2022-06-12 04:15:32.866524
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast

    # Test case: compile super() to super(Cls, self)
    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                self._replace_super_args(node)
                self._tree_changed = True

            return self.generic_visit(node)  # type: ignore

    # Test all possible return cases
    transformer = TestSuperWithoutArgumentsTransformer()
    class Test(object):
        def foo(self):
            super()
    assert transformer.visit(ast.parse('super()')) == ast.parse('super(Test, self)')


# Generated at 2022-06-12 04:15:38.270861
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast as python_ast
    import typed_ast.ast3 as typed_ast


    class Test(SuperWithoutArgumentsTransformer):
        def visit_Name(self, node: typed_ast.Name) -> typed_ast.Name:
            return node



# Generated at 2022-06-12 04:15:43.528616
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils import get_code
    code_str = """
    class Cls:
        def method(self):
            super()
    """
    tree = ast.parse(code_str)  # type: ignore
    transpiler = SuperWithoutArgumentsTransformer(tree=tree)
    transpiler.visit()
    code = get_code(tree)

# Generated at 2022-06-12 04:15:44.985627
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile


# Generated at 2022-06-12 04:15:55.431899
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Tested with Python 2.7 and 3.7
    import sys

    if sys.version_info >= (3, 0):
        from typed_ast import ast3 as ast
    else:
        from typed_ast import ast27 as ast

    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])

    class DummyNode(object):
        def __init__(self, name):
            self.name = name

    class DummyTree(object):
        def __getitem__(self, item):
            if item == 0:
                return DummyNode('Bar')
            else:
                raise IndexError('Out of bound')

    transformer = SuperWithoutArgumentsTransformer(DummyTree())

# Generated at 2022-06-12 04:16:02.056305
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    from ..utils.templates import build_ast
    from .helpers import transform

    source = """
    class Test(object):
        def test(self):
            super()
    """
    nodes = source_to_nodes(source)
    template = """
    class Test(object):
        def test(self):
            super(Test, self)
    """
    expected_nodes = source_to_nodes(template)
    result_nodes = transform(nodes, SuperWithoutArgumentsTransformer)

    assert build_ast(result_nodes) == build_ast(expected_nodes)

# Generated at 2022-06-12 04:16:09.788920
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import List
    import astor
    code = '''
        class MyParentClass:

            def __init__(self):
                super()
    '''
    tree = ast.parse(code)
    my_class = tree.body[0]

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert len(my_class.body[0].body) == 2
    assert isinstance(my_class.body[0].body[0], ast.Expr)
    assert isinstance(my_class.body[0].body[0].value, ast.Call)
    assert len(my_class.body[0].body[0].value.args) == 2

# Generated at 2022-06-12 04:16:23.518800
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_parser import parse_ast
    from .base import BaseNodeTransformer, BaseNodeTransformerTest

    class T(BaseNodeTransformer):
        pass

    class TT(BaseNodeTransformerTest):
        transformer = T

    with TT as t:
        t.check(parse_ast("super()"),
                parse_ast("super(Cls, self)"))
        t.check(parse_ast("''"),
                parse_ast("''"))
        t.check(parse_ast("super([1, 2, 3])"),
                parse_ast("super([1, 2, 3])"))



# Generated at 2022-06-12 04:16:34.100028
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
        Cases:
        1. Super outside class / method
        2. Super within a method, but outside class
        3. Super within a class, but outside method
        4. Super without arguments within a class and a method
        5. Super with arguments within a class and a method
    """
    expected_code = """
        class B(object):
            def __init__(self):
                super(B, self).__init__()
        """
    tree = ast.parse("""
        class B(object):
            def __init__(self):
                super().__init__()
        """)
    node = tree.body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert astunparse.unparse(tree) == expected_code
    assert transformer

# Generated at 2022-06-12 04:16:38.582633
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = 'class Cl: super()'
    expected_code = '''class Cl: super(Cl, self)'''
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == expected_code

# Generated at 2022-06-12 04:16:46.401942
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from ..utils import cpython_34
    code = dedent('''
    class A(object):
      def f(self):
        super()
    ''')

    tree = cpython_34.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    expected_result = dedent('''
    class A(object):
      def f(self):
        super(A, self)
    ''').lstrip()

    assert ast.dump(tree) == expected_result

# Generated at 2022-06-12 04:16:56.148597
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import io
    import unittest

    from typed_ast import ast3
    from typed_ast import typing3
    from typed_ast import pyc_ast
    from typed_ast import pyc_parser
    from ..utils.lowerer import _lowered_fields

    class Var:
        pass

    parser = pyc_parser.CParser()
    module = pyc_ast.PyCFastParse('super()', '', parser, None, False, 
            _lowered_fields, typing3.TYPE_CHECKING)
    pyc_ast.fix_missing_locations(module)
    tree = ast3.fix_missing_locations(ast3.Module(body=[module]))
    b = SuperWithoutArgumentsTransformer(tree)
    b.visit(tree)

    var = Var()


# Generated at 2022-06-12 04:17:03.061127
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    tree = ast.parse("""
    class Foo(object):
        def __init__(self):
            super()
        """)
    t = SuperWithoutArgumentsTransformer.from_tree(tree)
    t.visit(tree)
    expected_tree = ast.parse("""
    class Foo(object):
        def __init__(self):
            super(Foo, self)
        """)
    assert astor.dump_tree(tree) == astor.dump_tree(expected_tree)

# Generated at 2022-06-12 04:17:12.663443
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree_builder import TreeBuilder

    tree_builder = TreeBuilder()

    tree_builder.add_function_def(
        name='foo',
        args=[tree_builder.add_arg(arg='self')],
        body=[
            tree_builder.add_call(
                tree_builder.add_name(id='super'),
            ),
        ],
    )

# Generated at 2022-06-12 04:17:18.986999
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from textwrap import dedent

    code = dedent("""
    class A:
        def __init__(self, a):
            self.a = a

    class B(A):
        def __init__(self, a, b):
            super()
            self.b = b
    """)

    tree = ast3.parse(code)

    transformer = SuperWithoutArgumentsTransformer(tree)

    transformer.visit(tree)

    exec(compile(tree, "<test>", "exec"))


__all__ = ['SuperWithoutArgumentsTransformer']

# Generated at 2022-06-12 04:17:29.056344
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    text = "super()"
    tree = ast.parse(text)
    SuperWithoutArgumentsTransformer.run_testing_on_single_file(text, tree)

    text = "super(Cls)"
    tree = ast.parse(text)
    SuperWithoutArgumentsTransformer.run_testing_on_single_file(text, tree)

    text = "def func(self):\n    super()"
    tree = ast.parse(text)
    SuperWithoutArgumentsTransformer.run_testing_on_single_file(text, tree)

    text = "def func(self):\n    super(Cls)"
    tree = ast.parse(text)
    SuperWithoutArgumentsTransformer.run_testing_on_single_file(text, tree)


# Generated at 2022-06-12 04:17:29.777889
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:45.475146
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing.utils import build_ast, extract_node

    tree = build_ast("super()")

    node = extract_node(tree, ast.Call)
    visitor = SuperWithoutArgumentsTransformer(tree)
    new_node = visitor.visit_Call(node)

    assert str(new_node.args[0]) == "Cls"
    assert str(new_node.args[1]) == "self"

# Generated at 2022-06-12 04:17:51.566347
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""
    class C(object):
        def __init__(self):
            super()
    """)
    node = tree.body[0].body[0].body[0].value
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert isinstance(transformer, SuperWithoutArgumentsTransformer)
    assert node.args == [ast.Name(id='C'), ast.Name(id='self')]



# Generated at 2022-06-12 04:17:57.842597
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    node = ast.parse("""
    class A:
        def _init(self):
            super()
    """)
    SuperWithoutArgumentsTransformer().visit(node)
    expected_return = ast.parse("""
    class A:
        def _init(self):
            super(A, self)
    """)
    assert astor.to_source(node) == astor.to_source(expected_return)

# Generated at 2022-06-12 04:17:59.507492
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""
    # pylint: disable=unused-variable


# Generated at 2022-06-12 04:18:02.774306
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer."""
    from typed_ast import ast3 as ast
    from ..utils.tree import compile_ast_and_get_tree

# Generated at 2022-06-12 04:18:03.357779
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:13.674200
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    class SuperWithoutArgumentsTransformer_test1(ast.NodeVisitor):
        string = """
            class A:
                super()
        """
        expected_string = """
            class A:
                super(A, self)
        """

        def __init__(self):
            self.tree = ast.parse(self.string)

        def test_SuperWithoutArgumentsTransformer_correctly_called(self):
            transformer = SuperWithoutArgumentsTransformer()
            transformer.visit(self.tree)
            self.string = ''.join(astor.to_source(self.tree).split())
            self.expected_string = ''.join(self.expected_string.split())
            assert self.string == self.expected_string

# Generated at 2022-06-12 04:18:14.993222
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:19.478865
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ast_helper import ast_from, ast_to_source
    source = 'super()'
    tree = ast_from(source)
    transformer = SuperWithoutArgumentsTransformer()

    transformer.visit(tree)
    expected_tree_source = 'super(Cls, self)'
    assert ast_to_source(tree) == expected_tree_source

# Generated at 2022-06-12 04:18:27.529030
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast

    tree = ast.parse(
        '''
        class MyClass:
            def my_method(self, arg):
                super()
        '''
    )
    cls = tree.body[0]
    func = cls.body[0]
    node = func.body[0]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)  # Type of 1st argument
    assert node.args[0].id == 'MyClass'  # 1st argument itself

# Generated at 2022-06-12 04:18:57.764377
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test super() is converted to super(cls, self)"""

    # Setup
    code = '''
    super()
    '''
    expected_code = '''
    super(Cls, self)
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)

    class Super(ast.NodeVisitor):
        def visit_Call(self, node):
            return [node]

    super_call_node = Super().visit(tree.body[0])[0]

    # Exercise
    transformer.visit(tree)

    # Verify
    assert len(super_call_node.args) == 2
    assert isinstance(super_call_node.args[0], ast.Name)
    assert super_call_node.args[0].id == 'Cls'

# Generated at 2022-06-12 04:18:58.195719
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:58.656966
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:59.287264
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-12 04:19:09.228122
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-12 04:19:18.220515
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class B:
            def __init__(self):
                self.x = get_x()
         
        class A(B):
            def __init__(self):
                super()
                self.y = get_y()
    """
    tree = ast.parse(dedent(code))
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree).strip() == dedent("""
       class B:
           def __init__(self):
               self.x = get_x()
        
        class A(B):
            def __init__(self):
                super(A, self)
                self.y = get_y()
    """).strip()

# Generated at 2022-06-12 04:19:24.373244
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.test_utils import run_test_node, parse_node
    test_node = '''
    class A:
        def __init__(self):
            super()
    '''
    expected_tree = 'class A: def __init__(self): super(A, self)'
    tree = parse_node(test_node)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    run_test_node(tree, expected_tree)



# Generated at 2022-06-12 04:19:27.196545
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == "super(Cls, self)"

# Generated at 2022-06-12 04:19:36.560852
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import assert_source

    tree = ast.parse('super()')
    node = tree.body[0].value
    SuperWithoutArgumentsTransformer().visit(tree)

    assert_source(tree, 'super(Cls, self)')

    func = ast.FunctionDef(name='foo', args=ast.arguments(args=[ast.arg(arg='self')]), body=[tree])
    cls = ast.ClassDef(name='Cls', bases=[], body=[func])

    SuperWithoutArgumentsTransformer().visit(func)
    assert_source(func, 'def foo(self):\n    super(Cls, self)\n')

    SuperWithoutArgumentsTransformer().visit(cls)

# Generated at 2022-06-12 04:19:40.203403
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast
    import sys
    print(SuperWithoutArgumentsTransformer(ast.parse("super()")).visit(ast.parse("super()")))
    # Will print <_ast.Module object at 0x7f1fa82efb00>

# Generated at 2022-06-12 04:20:10.462881
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer.run_test(tree)
    assert(tree.body[0].value.args[0].id == 'Cls')
    assert(tree.body[0].value.args[1].id == 'self')

# Generated at 2022-06-12 04:20:11.332759
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import transformer

# Generated at 2022-06-12 04:20:17.025511
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .packages.typed_ast.ast3 import parse

    tree = parse('super()\nsuper()')

    SuperWithoutArgumentsTransformer.run(tree)

    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].value.args[1], ast.Name)



# Generated at 2022-06-12 04:20:21.692427
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def a():
            super()
    """

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert_code(code, tree)



# Generated at 2022-06-12 04:20:27.392875
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    super_node1 = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    node = ast.Call(func=super_node1, args=[], keywords=[])
    funcnode = ast.FunctionDef(name='func', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[node], decorator_list=[], returns=None)
    classnode = ast.ClassDef(name='Cls', bases=[ast.Name(id='object')], keywords=[], body=[funcnode], decorator_list=[])

    tree = ast.Module(body=[classnode])

    result = SuperWithoutArgumentsTransformer().visit(tree)
    print(ast.dump(result))

# Generated at 2022-06-12 04:20:28.264898
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import parse


# Generated at 2022-06-12 04:20:35.959808
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    from ..tests.utils import generate_python_script_from_ast_nodes
    from ..tests.compiler_unit_test_case import CompilerUnitTestCase, run_test

    class TestCase(CompilerUnitTestCase):
        def test_super_without_arguments(self):
            code = '''
                class A(object):
                    def __init__(self):
                        super().__init__()
                '''
            tree = compile(code, '<test>', 'exec', ast.PyCF_ONLY_AST)
            node = tree.body[0]
            self.assertIsInstance(node, ast.ClassDef)
            node = node.body[0]
            self.assertIsInstance(node, ast.FunctionDef)


# Generated at 2022-06-12 04:20:42.756978
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from ..utils.helpers import debug_ast_diff
    ast1 = parse(
    '''
    class A:
        def __init__(self):
            super().__init__()
    ''')
    ast2 = parse(
    '''
    class A:
        def __init__(self):
            super(A, self).__init__()
    ''')
    tt = SuperWithoutArgumentsTransformer()
    new_tree = tt.visit(ast1)
    debug_ast_diff(ast2, new_tree)

# Generated at 2022-06-12 04:20:44.223897
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer(None)
    assert transformer._replace_super_args(None) is None

# Generated at 2022-06-12 04:20:50.318360
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    from .. import transform

    class_name = 'Foo'
    func_name = 'bar'
    src = "class {0}:\n    def {1}(self):\n        super()".format(class_name, func_name)
    expected = "class {0}:\n    def {1}(self):\n        super({0}, self)".format(class_name, func_name)

    tree = get_ast(src)
    transform(tree, [SuperWithoutArgumentsTransformer])
    assert astunparse.unparse(tree) == expected


# Generated at 2022-06-12 04:21:35.196653
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from textwrap import dedent
    from ..utils.helpers import run_transformer

    module = dedent('''\
        class MyClass():
            def __init__(self):
                super()
    ''')
    tree = run_transformer(SuperWithoutArgumentsTransformer, module)
    assert astor.to_source(tree).strip() == dedent('''\
        class MyClass():
            def __init__(self):
                super(MyClass, self)
    ''').strip()


# Unit tests for class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:37.416791
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..transformations import InitializeParseTree
    from ..transformations import FinalizeParseTree
    from ..transformations import SuperWithoutArgumentsTransformer


# Generated at 2022-06-12 04:21:40.922697
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_compare import are_asts_equivalent

    code = 'super()'
    expected = 'super(Cls, self)'
    node = ast.parse(code, mode='eval')
    SuperWithoutArgumentsTransformer().visit(node)

    assert are_asts_equivalent(ast.parse(expected, mode='eval'), node)


# Generated at 2022-06-12 04:21:48.080073
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..main import compile
    from ..utils import parse

    # class A(super):
    #     def __init__(self):
    #         super().__init__()
    #         super().method()
    #     def method(self):
    #         super().__init__()
    #         super().method()
    src = """
    class A(super):
        def __init__(self):
            super().__init__()
            super().method()
        def method(self):
            super().__init__()
            super().method()
    """
    tree = parse(src)
    SuperWithoutArgumentsTransformer().visit(tree)
    code = compile(tree)

# Generated at 2022-06-12 04:21:49.893195
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""

# Generated at 2022-06-12 04:21:53.565782
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for SuperWithoutArgumentsTransformer"""

    code_ast = ast.parse('foo(super())')
    tree = SuperWithoutArgumentsTransformer().visit(code_ast)
    expected_code_ast = ast.parse('foo(super(cls, self))')
    assert ast.dump(tree) == ast.dump(expected_code_ast)

# Generated at 2022-06-12 04:21:54.033000
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:01.159791
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent

    source = dedent("""
    class Test:
        def __init__(self):
            super()
    """)
    node = ast.parse(source)
    x = SuperWithoutArgumentsTransformer()
    x.visit(node)
    expected = dedent("""
    class Test:
        def __init__(self):
            super(Test, self)
    """)
    source2 = dedent("""
    class Test:
        def __init__(self):
            super()
    """)
    assert ast.dump(ast.parse(source2)) == ast.dump(node)

# Generated at 2022-06-12 04:22:01.613397
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:07.677781
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor 
    node = ast.parse('class Base(object):\n\tdef __init__(self):\n\t\tsuper()')
    expected_output = ast.parse('class Base(object):\n\tdef __init__(self):\n\t\tsuper(Base, self)')
    SuperWithoutArgumentsTransformer().visit(node)
    assert astor.to_source(node).strip() == astor.to_source(expected_output).strip()
    assert SuperWithoutArgumentsTransformer().target == (2, 7)

# Generated at 2022-06-12 04:23:33.466711
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..transforms import ClassDefinitionsToTopLevel
    from ..transforms import FunctionDefinitionsToTopLevel
    from ..transforms import ImportStatementToGlobal
    from ..transforms import RemoveDocStrings


# Generated at 2022-06-12 04:23:39.062014
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test_super_without_args_no_change
    assert(str(SuperWithoutArgumentsTransformer().visit(ast.parse('super(A, self)'))) == 'super(A, self)')
    
    # test_super_without_args
    assert(str(SuperWithoutArgumentsTransformer().visit(ast.parse('super()'))) == 'super(Cls, self)')

# Generated at 2022-06-12 04:23:43.790888
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class A:
            def __init__(self, a):
                super()
                super().__init__()
        '''
    expected_code = '''
        class A:
            def __init__(self, a):
                super(A, self)
                super(A, self).__init__()
        '''
    transformer = SuperWithoutArgumentsTransformer()
    result_code = transformer.transform_source(code)
    assert result_code == expected_code

# Generated at 2022-06-12 04:23:52.641208
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .. import compile
    source = source_to_unicode('''
        class Test(object):
            def __init__(self, x):
                super()
    ''')
    tree = compile(source, __name__, 'exec')
    assert isinstance(tree, ast.Module)

    node = tree.body[0]
    assert isinstance(node, ast.ClassDef)

    node = node.body[0]
    assert isinstance(node, ast.FunctionDef)

    node = node.body[0]
    assert isinstance(node, ast.Expr)
    node = node.value
    assert isinstance(node, ast.Call)
    node = node.func
    assert isinstance(node, ast.Name)
    assert node.id

# Generated at 2022-06-12 04:23:54.306572
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:24:02.619329
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def foo(self):
                super(A, self)
        """
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-12 04:24:08.559306
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..utils.source import source
    from ..utils.helpers import get_names
    from .. import compile_to_ast

    source_code = source('''
        class Base(object):
            def __init__(self):
                super().__init__()
        ''')
    nodes = source_to_nodes(source_code)
    node, = compile_to_ast(nodes, SuperWithoutArgumentsTransformer)
    assert get_names(node) == 'Base super Base self'

# Generated at 2022-06-12 04:24:16.876405
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import tests
    from ..tests.utils import transform

    code = """
    super()
    """
    # ast before
    before = tests.parse_to_ast(code)
    # ast after
    after = tests.parse_to_ast("""
    super(Cls, self)
    """)

    # class
    class_name = 'Cls'
    # function
    func_name = 'func'
    # node that will replace super in the test case
    replace_node = ast.Attribute(
        value = ast.Name(id = 'self', ctx = ast.Load()), 
        attr = func_name,
        ctx = ast.Load()
    )
    # there is only one Call in the test case
    call: ast.Call = before.body[0].value

    # compile

# Generated at 2022-06-12 04:24:17.285220
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:24:21.563443
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    test_code = '''
    class Cls:
        def __init__(self):
            super()
    '''
    expected = '''
    class Cls:
        def __init__(self):
            super(Cls, self)
    '''
    node = ast.parse(test_code)
    SuperWithoutArgumentsTransformer().visit(node)
    assert astor.to_source(node).strip() == expected.strip()