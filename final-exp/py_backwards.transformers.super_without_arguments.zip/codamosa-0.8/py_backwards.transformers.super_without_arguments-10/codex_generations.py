

# Generated at 2022-06-12 04:14:27.883727
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test to check super() with positional arguments
    tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree.body[0], ast.Expr)
    new_super = cast(ast.Call, tree.body[0].value)
    assert new_super.args[0].id == 'Cls'
    assert new_super.args[1].id == 'self'

    # Test to check super() with stararg
    tree = ast.parse('super(*args)')
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert isinstance(tree.body[0], ast.Expr)
    new_super = cast(ast.Call, tree.body[0].value)

# Generated at 2022-06-12 04:14:33.885639
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    import ast as ast3
    node = ast3.parse("super()").body[0]
    transformer = SuperWithoutArgumentsTransformer(ast3.parse("class A: def __init__(self): super()"))
    new_node = transformer.visit(node)
    assert transformer._tree_changed == True
    assert compile(new_node, '<test>', 'exec')

# Generated at 2022-06-12 04:14:40.024107
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()
    node = ast.parse(
        'class Foo:\n'
        '    def method(self):\n'
        '        super()'
    )
    transformer.visit(node)
    assert transformer._tree_changed is True
    assert astor.to_source(node).strip() == (
        'class Foo: \n'
        '    def method(self): \n'
        '        super(Foo, self)\n'
    )

# Generated at 2022-06-12 04:14:47.184150
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..crystax import CrystaxPythonCompatibility

    source_text = '''
    class A:
        def f(self):
            super()
    '''
    expected_text = '''
    class A:
        def f(self):
            super(A, self)
    '''
    tree = CrystaxPythonCompatibility().run_pipeline(source_text, (2, 7))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert ast.dump(tree) == expected_text

# Generated at 2022-06-12 04:14:52.216965
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import ast_manipulation

    code = """
x = super()
"""
    expected_code = """
x = super(Cls, self)
"""
    
    class Cls:
        def __init__(self):
            x = super()

    classmethod = ast.ClassDef(name='Cls', body=[ast.FunctionDef(name='__init__', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)]), body=[ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))])], decorator_list=[])
    tree = ast.parse(code)

# Generated at 2022-06-12 04:14:57.369495
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    stt = SuperWithoutArgumentsTransformer(tree)
    assert tree == ast.parse("super(Cls, self)")
    assert tree != ast.parse("super()")
    assert tree != ast.parse("super(Cls, self, self)")

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:15:02.348008
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import astor
    from astor.code_gen import to_source
    code = """
    class A:
        def __init__(self, x):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert to_source(tree).strip() == '''
    class A:
        def __init__(self, x):
            super(A, self)
    '''

    code = ''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert to_source(tree).strip() == ''

# Generated at 2022-06-12 04:15:03.342340
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:15:04.404727
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:05.726898
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:18.567176
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """

    def foo(self):
        super()

    def foo2(cls):
        super()

    class Foo(object):
        def foo(self):
            super()

    class Foo2(object):
        def foo2(cls):
            super()

    """
    from ..parser import parse
    from ..utils.helpers import dump_tree
    from .base import BaseNodeTransformer
    from ..utils.tree import flatten

    # Build AST
    tree = parse(test_SuperWithoutArgumentsTransformer_visit_Call.__doc__)
    flatten(tree)

    # Apply transformer
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    # Compare result
    result = dump_tree(tree)


# Generated at 2022-06-12 04:15:24.920784
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.Call(
        func=ast.Name(id='super'),
        args=[],
        keywords=[]
    )
    transformer = SuperWithoutArgumentsTransformer()
    actual = transformer.visit(node)
    expected = ast.Call(
        func=ast.Name(id='super'),
        args=[
            ast.Name(id='Cls'),
            ast.Name(id='self')
        ],
        keywords=[]
    )
    assert ast_equal(actual, expected)

# Generated at 2022-06-12 04:15:28.593347
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(ast.parse("super()"))
    assert str(tree) == "super(__name__, cls)"
    # assert str(tree) == "__name__"

# Generated at 2022-06-12 04:15:40.279672
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import as_tuple
    from unittest import mock
    from ..utils.tree import node_factory

    node = node_factory('Call', [
        node_factory('Name', [], [], [], [], [], id='super'),
        [],
    ])

    tree: ast.AST = node

    parent_func = node_factory('FunctionDef', [], [], [], [], [], name='func', args=node_factory('arguments', [], [], [], [], [], args=[node_factory('arg', [], [], [], [], [], arg='self')]))
    parent_cls = node_factory('ClassDef', [], [], [], [], [], name='Cls')

    instance = SuperWithoutArgumentsTransformer([])


# Generated at 2022-06-12 04:15:42.751126
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.codegen import to_source
    from ..utils.ast_helpers import parse_to_ast


# Generated at 2022-06-12 04:15:51.926055
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import Parser

    code = '''
    class Foo:
        def __init__(self):
            super()
    
    class Bar:
        def __init__(self, a, b):
            super(Bar, self)
    '''
    expected_code = '''
    class Foo:
        def __init__(self):
            super(Foo, self)
    
    class Bar:
        def __init__(self, a, b):
            super(Bar, self)
    '''
    t = SuperWithoutArgumentsTransformer()
    p = Parser()
    p.add_transformer(t)
    new_code = p.parse(code)
    assert new_code == expected_code

# Generated at 2022-06-12 04:15:58.978448
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as typed_ast

    module = typed_ast.parse("""
    class A:
        def __init__(self, x):
            super().__init__(x)
            return

        def f(self, x):
            super().f(x)
            return
    """)

    module = SuperWithoutArgumentsTransformer().visit(module)

    module = typed_ast.ast3.fix_missing_locations(module)

    print(typed_ast.dump(module))
    exec(compile(module, filename="", mode="exec"))

# Generated at 2022-06-12 04:16:07.833689
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import generate_source
    from ..transformer.constructor import ConstructorTransformer
    from ..transformer.class_ import ClassTransformer
    from ..transformer.super_without_arguments import SuperWithoutArgumentsTransformer
    
    # Complete test
    clas = ast.FunctionDef(name='B', args=ast.arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))], decorator_list=[], returns=None)

# Generated at 2022-06-12 04:16:13.484289
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast27
    node = ast27.parse("super()", mode='eval')
    SuperWithoutArgumentsTransformer().visit(node)
    assert ast27.dump(node) == (
        "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), "
        "args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], "
        "keywords=[], starargs=None, kwargs=None))]\n)"
    )


# Generated at 2022-06-12 04:16:23.266602
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = source_1 = '''
    class A:
        def f(self):
            super()
            '''
    expected = expected_1 = '''
    class A:
        def f(self):
            super(A, self)
            '''
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == expected
    
    source = source_2 = '''
    class A:
        def f(self):
            super(X)
            '''
    expected = expected_2 = '''
    class A:
        def f(self):
            super(X)
            '''
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_

# Generated at 2022-06-12 04:16:33.932204
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from copy import deepcopy
    node = ast.parse('super()', mode='eval')
    node = deepcopy(node)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    expected = ast.parse('super(__name__, self)', mode='eval')
    assert ast.dump(node) == ast.dump(expected)

# Generated at 2022-06-12 04:16:39.383002
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    input_code = "super()"
    expected_code = "super(Cls, self)"

    tree = ast.parse(input_code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    generated_code = astor.to_source(tree)

    assert generated_code == expected_code


# Generated at 2022-06-12 04:16:42.308040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import ClassDef, FunctionDef, Name
    import ast
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:16:47.778096
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = """
        class A(object):
            def foo(self):
                super().foo()
    """

    t = compile(s, '<string>', 'exec',ast.PyCF_ONLY_AST)
    tree = ast.parse(s, 'exec')
    SuperWithoutArgumentsTransformer(tree=tree).run()
    assert ast.dump(tree) == ast.dump(t)

if __name__ == '__main__':
    test_SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:16:55.010143
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # The string representation of the AST node
    node_code = 'super()'
    # The AST node
    node = ast.parse(node_code).body[0].value
    # Transformer settings
    settings = {'filename': '<inline code>'}

    # Run the transformer
    transformer = SuperWithoutArgumentsTransformer(node, settings)
    transformer.visit(node)

    # Check the new node
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'

# Generated at 2022-06-12 04:17:02.611680
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    
    from typed_ast import ast3 as ast
    from ..typeshed import visitor
    from ..utils import code_to_ast
    from .base import BaseNodeTransformer
    from ..exceptions import NodeNotFound
    
    source = 'super()'
    tree = code_to_ast.parse(source)
        
    nodeTransformer = SuperWithoutArgumentsTransformer()
    visitor.visit(tree, nodeTransformer)
    
    source_expected = 'super(Cls, self)'
    tree_expected = code_to_ast.parse(source_expected)
    assert tree == tree_expected

# Generated at 2022-06-12 04:17:11.676505
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseUnparserTestCase
    import unittest
    from typed_ast import ast3
    
    class Test(unittest.TestCase, BaseUnparserTestCase):
        def test_SuperWithoutArgumentsTransformer(self):
            tree = ast3.parse(
                '''
                    class A:
                        def __init__(self):
                            super()
                '''
            )

            SuperWithoutArgumentsTransformer().visit(tree)
            code = self.unparse(tree)
            exec(code, globals())

            c = A()
            self.assertTrue(isinstance(c, A))
            self.assertTrue(isinstance(c, object))
    
    unittest.main()

# Generated at 2022-06-12 04:17:16.438354
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    super_call = ast.parse("super()")
    tree = ast.parse("""
    class MyClass:
        def __init__(self):
            super()
    """)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse("""
    class MyClass:
        def __init__(self):
            super(MyClass, self)
    """))



# Generated at 2022-06-12 04:17:24.192966
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test replace_super_args
    class TestSuperWithoutArgumentsTransformer:
        def setup_method(self, method):
            self.tree = ast.parse('super()')
            self.transformer = SuperWithoutArgumentsTransformer(self.tree)

        def test_replace_super_args(self):
            self.tree = ast.parse('''
                class A:
                    def __init__(self):
                        super()
            ''')
            self.transformer = SuperWithoutArgumentsTransformer(self.tree)
            self.transformer.visit(self.tree)
            assert 'super(A, self)' == astor.to_source(self.transformer._tree)


# Generated at 2022-06-12 04:17:31.557319
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode_str

    example_code = source_to_unicode_str("""
    class Foo:
        def __init__(self):
            super()
    """)

    expected_code = source_to_unicode_str("""
    class Foo:
        def __init__(self):
            super(Foo, self)
    """)

    tree = compile(example_code, '<string>', 'exec', ast.PyCF_ONLY_AST)  # type: ignore
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    print(expected_code)
    print(ast.dump(tree))

    assert ast.dump(tree) == expected_code



# Generated at 2022-06-12 04:17:53.036641
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..semanal import resolve_call
    from ..semanal.helpers import get_builtin_function

    transformer = SuperWithoutArgumentsTransformer()
    node = ast.parse('super()')
    cls = ast.ClassDef(name='foo', bases=[], body=[])
    func = ast.FunctionDef(name='bar', args=ast.arguments(args=[ast.Name(id='baz')]), body=[node])
    cls.body.append(func)
    module = ast.Module(body=[cls])
    transformer.visit(module)
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert node.args[0].id == 'foo'
    assert isinstance(node.args[1], ast.Name)
    assert node

# Generated at 2022-06-12 04:18:01.380514
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    node_orig = ast.Call()
    node_orig.func = ast.Name()
    node_orig.func.id = 'super'
    node_orig.args = []
    node_orig.starargs = None
    node_orig.kwargs = None
    node_orig.keywords = []

    tree_orig = ast.Module()
    tree_orig.body = [
        ast.FunctionDef(),
        ast.ClassDef(),
        ast.str()
    ]
    tree_orig.body[0].args = ast.arguments()
    tree_orig.body[0].args.args = [ast.arg()]
    tree_orig.body[0].args.args[0].arg = 'self'
    tree_orig.body[1].name = 'A'

# Generated at 2022-06-12 04:18:10.244953
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from tools.general.general import run_transformer
    from typing import List

    from typed_ast import ast3 as ast

    source = """\
    class A(object):
        def a(self):
            super().m()
        
        def b(self):
            super(B, self).m()
    """

    expected = """\
    class A(object):
        def a(self):
            super(A, self).m()
        
        def b(self):
            super(B, self).m()
    """

    tree = run_transformer(SuperWithoutArgumentsTransformer, source)
    assert tree == expected

# Generated at 2022-06-12 04:18:19.806087
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    Unit test for constructor of class SuperWithoutArgumentsTransformer
    """
    code: str = '''class A(object):\n    def b(self):\n        super()'''
    tree: ast.Module = ast.parse(code)
    transformer: SuperWithoutArgumentsTransformer = SuperWithoutArgumentsTransformer(tree)
    new_tree: ast.Module = transformer.visit(tree)

# Generated at 2022-06-12 04:18:27.770509
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast.ast3 import parse, dump
    from ..utils import assert_equal_source
    source = '''super()'''
    expected = '''super("Cls", self)'''
    tree = parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree, '2.7', {})
    transformer.visit_Call(tree.body[0])
    assert_equal_source(dump(tree), expected)
    source = '''super('''
    expected = '''super("Cls", self)'''
    tree = parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree, '2.7', {})
    transformer.visit_Call(tree.body[0])
    assert_equal_source(dump(tree), expected)
    source = '''dsuper()'''


# Generated at 2022-06-12 04:18:28.723785
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:18:30.384037
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_string
    from ..utils.tree import dump_ast


# Generated at 2022-06-12 04:18:35.529895
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
        class A:
            def __init__(self):
                super()
    """
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert_code_equal(astunparse.unparse(tree), """
        class A():
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-12 04:18:45.012624
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .helpers import roundtrip, assert_equal_source
    from .base import BaseNodeTransformer

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-12 04:18:45.973161
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    

# Generated at 2022-06-12 04:18:53.933401
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass

# Generated at 2022-06-12 04:19:00.748357
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    class TestTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self.attributes = []

        def _transform(self, node):
            self.attributes.append(node)

    tree = ast.parse("""class A(object):
        def __init__(self):
            super()
        def __new__(cls):
            super()
    """)
    tt = TestTransformer()
    tt.visit(tree)
    assert len(tt.attributes) == 2
    assert tt.attributes[0].func.id == 'super'
    assert tt.attributes[0].args[0].id == 'A'
    assert tt.attributes[0].args[1].id == 'self'
    assert tt.attributes[1].func.id

# Generated at 2022-06-12 04:19:01.316508
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:04.299913
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "super()"
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    res = compile(tree, '', 'exec')
    exec(res)

# Generated at 2022-06-12 04:19:10.756231
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    t = SuperWithoutArgumentsTransformer()
    tree = ast3.parse("super()")
    t.visit(tree)
    assert ast3.dump(tree) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])", ast3.dump(tree)

    t = SuperWithoutArgumentsTransformer()
    tree = ast.parse("super()")
    t.visit(tree)

# Generated at 2022-06-12 04:19:20.285534
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from tests.utils import transform, make_suite
    from typed_ast import ast3 as ast

    cls = ast.ClassDef(name='B', bases=[ast.Name(id='A')], body=[
        ast.ClassDef(name='B', bases=[ast.Name(id='object')])
    ], decorator_list=[])

    @transform(SuperWithoutArgumentsTransformer)
    def foo():
        super()
    
    @transform(SuperWithoutArgumentsTransformer)
    def bar(self):
        super()

    @transform(SuperWithoutArgumentsTransformer)
    def baz(cls):
        super()

    @transform(SuperWithoutArgumentsTransformer)
    class A:
        def baz(cls):
            super()
        

# Generated at 2022-06-12 04:19:22.909484
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .syntax_support import setup_module_for_syntax_only
    setup_module_for_syntax_only()


# Generated at 2022-06-12 04:19:26.474920
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    try:
        from typed_ast import ast3
    except ImportError:
        return
    from .test_visitor import transform_source


# Generated at 2022-06-12 04:19:31.968319
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_node_equal
    node = parse('''
    class B:
        def __init__(self):
            super()
    ''')
    expected = parse('''
    class B:
        def __init__(self):
            super(B, self)
    ''')
    actual = SuperWithoutArgumentsTransformer().visit(node)
    assert_node_equal(expected, actual)



# Generated at 2022-06-12 04:19:37.345186
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""super()""")
    SuperWithoutArgumentsTransformer(tree).run()
    actual = ast.dump(tree)
    desired = 'Module(body=[Expr(value=Call(func=Super(args=[Name(id="Cls", ctx=Load())]), args=[Name(id="self", ctx=Load())], keywords=[]))])'
    assert actual == desired

# Generated at 2022-06-12 04:19:57.797919
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arrange
    code = "super()"
    tree = ast.parse(code)
    expected = "super(__class__, self)"
    super_transformer = SuperWithoutArgumentsTransformer()

    # Act
    super_transformer.visit(tree)
    actual = to_source(tree)

    # Assert
    assert actual == expected

# Generated at 2022-06-12 04:19:59.062694
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:05.511670
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        super.f()
        super
        super()
        super(x)
        super(x, y)

        class A():
            def f(self):
                super()
    """
    expected = """
        super.f()
        super
        super(A, self)
        super(x)
        super(x, y)

        class A():
            def f(self):
                super(A, self)
    """
    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(code))
    assert str(t) == expected

# Generated at 2022-06-12 04:20:14.287288
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as ast
    from ..utils import parse_string
    def run_test(src):
        module = parse_string(src)
        class SuperWithoutArgumentsTransformer2(SuperWithoutArgumentsTransformer):
            def _get_tree(self) -> ast.AST:
                return module
        SuperWithoutArgumentsTransformer2().run()
        return module

    assert isinstance(run_test(
        """class A:
            def f(self):
                super()"""), ast.Module)
    assert isinstance(run_test(
        """class A:
            def f(self):
                super().f()"""), ast.Module)
    assert isinstance(run_test(
        """class B:
            def f(self):
                super().x(y)"""), ast.Module)

# Generated at 2022-06-12 04:20:20.208997
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == 'Expr(value=Call(func=Attribute(value=Name(id=\'super\', ctx=Load()), attr=\'__init__\', ctx=Load()), args=[Name(id=\'Cls\', ctx=Load()), Name(id=\'self\', ctx=Load())], keywords=[]))'

# Generated at 2022-06-12 04:20:26.847040
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Compile source code to AST
    source = """
    class Test:
        def __init__(self):
            super().__init__()
    """
    tree = parse(source)

    # Apply transformer
    SuperWithoutArgumentsTransformer().visit(tree)
    
    # Transpile AST to source code
    code = compile(tree, '<ast>', 'exec')
    namespace = {}
    exec(code, namespace)

    # Assert result
    assert namespace['Test'].__name__ == 'Test'

# Generated at 2022-06-12 04:20:30.236348
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    s = 'class D(B, C):\n\tdef __init__(self, x):\n\t\tself.x = x\n\t\tsuper().__init__()'
    tree = ast.parse(s)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == 'class D(B, C):\n\tdef __init__(self, x):\n\t\tself.x = x\n\t\tsuper(D, self).__init__()\n'


# Generated at 2022-06-12 04:20:37.624707
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .test_transformer import run_local_tests
    class TestTrans(SuperWithoutArgumentsTransformer):
        def visit_FunctionDef(self, cls: ast.FunctionDef) -> ast.FunctionDef:
            self.generic_visit(cls)
            cls.body += [ast.Expr(ast.Call(func=ast.Name('super', ast.Load()), args=[], keywords=[]))]
            cls.body += [ast.Expr(ast.Call(func=ast.Name('super', ast.Load()), args=[], keywords=[]))]
            return cls


# Generated at 2022-06-12 04:20:45.444626
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    import sys
    sys.path.insert(0, ".")
    from ..utils.tree import get_tree
    import unittest
    import re

    class UnitTest(unittest.TestCase):
        def setUp(self):
            self.tree = get_tree('super.py')
            self.transformer = SuperWithoutArgumentsTransformer()

        def test_result(self):
            result = re.sub('\\s+', ' ', self.transformer.visit(self.tree))
            result = result.replace('( ', '(').replace(' )', ')')

            self.assertEqual(result, """
            class Foo():
                def bar(cls):
                    super(Foo, cls)
            """)


# Generated at 2022-06-12 04:20:47.646806
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_source

    source = get_source(SuperWithoutArgumentsTransformer)
    assert "Compiles:" in source
    assert "target" in source

# Generated at 2022-06-12 04:21:32.076259
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    string = """
    class Foo(Bar):
        def baz(self):
            super()
    """
    expected_tree = """
    class Foo(Bar):
        def baz(self):
            super(Foo, self)
    """
    tree = ast.parse(string)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == expected_tree

# Generated at 2022-06-12 04:21:39.925647
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.test_utils import can_transform, do_transformation_test

    class DummyTransformer(BaseNodeTransformer):
        def _add_super_arg(self, node: ast.Call) -> None:
            node.args.append(ast.Constant(42))

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super':
                self._add_super_arg(node)
                self._tree_changed = True

            return self.generic_visit(node)  # type: ignore


# Generated at 2022-06-12 04:21:40.888901
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .unparse import unparse

# Generated at 2022-06-12 04:21:42.449562
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:46.981897
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    source = """
    class A(B):
        def foo(self):
            a = super()
    """
    expected = """
    class A(B):
        def foo(self):
            a = super(A, self)
    """
    tree = sta(source)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == ast.dump(sta(expected))


# Generated at 2022-06-12 04:21:54.655701
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that SuperWithoutArgumentsTransformer correctly updates 
    class.super() to super(Cls, cls)
    """
    code = """
        class A:
            def __init__(self):
                super()
    """

    # Parse code into ast
    tree = ast.parse(code)

    # Apply SuperWithoutArgumentsTransformer
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    # Run tests
    ClassDef = tree.body[0]
    super_call = ClassDef.body[0].body[0]

    assert isinstance(super_call, ast.Expr)
    assert isinstance(super_call.value, ast.Call)

    assert isinstance(super_call.value.func, ast.Name)
    assert super_call.value.func.id == 'super'

# Generated at 2022-06-12 04:21:56.511122
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import put_ast_and_get_source
    from ..utils.helpers import generate_source


# Generated at 2022-06-12 04:21:56.980620
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:59.669247
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..tests.utils.transform_test_utils import check_transform
    from .transform import OneLineTransformer
    from ..utils.context import PassContext


# Generated at 2022-06-12 04:22:05.122193
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super()')
    t.visit(tree)
    assert ast.dump(tree) == 'Module(body=[Expr(value=Call(func=Name(id=\'super\', ctx=Load()), args=[Name(id=\'Cls\', ctx=Load()), Name(id=\'self\', ctx=Load())], keywords=[], starargs=None, kwargs=None))])'


# Generated at 2022-06-12 04:23:15.233524
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree=node)
    transformer.visit(node)
    print(astunparse.unparse(node))
    #assert astunparse.unparse(node) == 'super(Cls, self)'

# Generated at 2022-06-12 04:23:20.961748
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test 1: super()
    code = "super()\ns"
    transformed, _ = SuperWithoutArgumentsTransformer().transform(code)
    assert transformed == 'super(Cls, s)\ns'
    # Test 2: super()
    code = "super()"
    transformed, _ = SuperWithoutArgumentsTransformer().transform(code)
    assert transformed == 'super(Cls, cls)'
    # Test 3: super()
    code = "super()\ns"
    transformed, _ = SuperWithoutArgumentsTransformer().transform(code)
    assert transformed == 'super(Cls, s)\ns'

# Generated at 2022-06-12 04:23:26.132620
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = """
        class Foo(object):
            def bar(self):
                super()
        """
    t = """
        class Foo(object):
            def bar(self):
                super(Foo, self)
        """
    tt = ast.parse(t)
    st = ast.parse(s)
    t2 = SuperWithoutArgumentsTransformer().visit(st)
    assert ast.dump(tt) == ast.dump(t2)



# Generated at 2022-06-12 04:23:31.003226
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    code = 'class Foo(object): def __init__(self): super().__init__()'
    tree = ast.parse(code)

    transformer.visit(tree)

    expected = 'class Foo(object): def __init__(self): super(Foo, self).__init__()'
    actual = astunparse.unparse(tree)

    assert expected == actual

# Generated at 2022-06-12 04:23:34.530789
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    module = ast.parse('super()')
    node = module.body[0]
    expected = ast.parse('super(Cls, self)')
    expected = expected.body[0]
    node = SuperWithoutArgumentsTransformer().visit(node)  # type: ignore
    assert astor.to_source(node) == astor.to_source(expected)

# Generated at 2022-06-12 04:23:39.943897
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arrange
    input_code = 'super()'
    expected_code = 'super(Cls, self)'
    tree = ast.parse(input_code)

    # Act
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    actual_code = to_source(tree)

    # Assert
    assert actual_code == expected_code

# Generated at 2022-06-12 04:23:46.169451
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class MyClass:
            def __init__(self):
                super()
            def func(self, a):
                super()
        """

    expected_code = """
        class MyClass:
            def __init__(self):
                super(MyClass, self)
            def func(self, a):
                super(MyClass, a)
        """

    tree = ast.parse(code)
    tt = SuperWithoutArgumentsTransformer(tree)
    tt.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))

# Generated at 2022-06-12 04:23:49.690168
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Test(object):
            def test(self):
                super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == code.replace('super()', 'super(Test, self)')


# Generated at 2022-06-12 04:23:50.171860
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:23:51.080209
# Unit test for constructor of class SuperWithoutArgumentsTransformer