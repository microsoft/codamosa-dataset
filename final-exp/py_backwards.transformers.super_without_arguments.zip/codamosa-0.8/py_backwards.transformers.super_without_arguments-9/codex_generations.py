

# Generated at 2022-06-12 04:14:26.464192
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class Test:
        def __init__(self):
            super()
    '''
    expected_code = '''
    class Test:
        def __init__(self):
            super(Test, self)
    '''
    ast_tree = ast.parse(code)
    new_ast = SuperWithoutArgumentsTransformer().visit(ast_tree)
    assert astor.to_source(new_ast) == expected_code

# Generated at 2022-06-12 04:14:34.248283
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Test:
        def __init__(self):
            super()
            
    class Test2:
        def __init__(self):
            super(Test, self)
    """

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    expected = """
    class Test:
        def __init__(self):
            super(Test, self)
            
    class Test2:
        def __init__(self):
            super(Test, self)
    """

    assert_code_equal(expected, tree)

# Generated at 2022-06-12 04:14:43.803362
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest
    import typed_astunparse

    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def test_super_without_arguments(self):
            from ..binder import Binder  # Import here to avoid circular import

            code = '''
                class Foo:
                    def bar(self):
                        super()
                '''

            module = Binder(code, [SuperWithoutArgumentsTransformer]).bind_module()

            expected_code = '''
                class Foo:
                    def bar(self):
                        super(Foo, self)
                '''

            self.assertEqual(module.as_string(), typed_astunparse.unparse(ast.parse(expected_code)))

    unittest.main(argv=[''], exit=False)

# Generated at 2022-06-12 04:14:52.954024
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseCompileTest
    
    class Test(BaseCompileTest):
        target = (2, 7)
        transformer = SuperWithoutArgumentsTransformer
        code = """
            class A:
                def __init__(self):
                    super()
                    super()
            class B:
                def __init__(self, *args):
                    super()
            def func():
                super()
        """
        expected_code = """
            class A:
                def __init__(self):
                    super(A, self)
                    super(A, self)
            class B:
                def __init__(self, *args):
                    super(B, args[0])
            def func():
                super()
        """
    
    Test.test_module()

# Generated at 2022-06-12 04:14:58.068262
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    tree = ast.parse('super()')
    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    assert not len(node.args)

    tr = SuperWithoutArgumentsTransformer(tree)
    tr.visit(tree)
    source = astor.to_source(tree)
    assert 'super(Cls, cls)' in source

# Generated at 2022-06-12 04:15:09.344640
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.helpers import compare_ast

    code = '''
super()
    '''

    expected_code = '''
super(Cls, self)
    '''

    source = ast.parse(code)

    def _change_name(tree):
        for cls in tree.body:
            if isinstance(cls, ast.ClassDef):
                cls.name = 'Cls'
            for func in cls.body:
                if isinstance(func, ast.FunctionDef):
                    func.args.args[0].arg = 'self'

    source = _change_name(source)

    sut = SuperWithoutArgumentsTransformer()
    sut.visit(source)
    actual_code = astor.to_source(source)

# Generated at 2022-06-12 04:15:10.138689
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse

# Generated at 2022-06-12 04:15:14.678472
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    t = SuperWithoutArgumentsTransformer()
    ref = 'class Test(object):\n    def method(self):\n        super(object, self)'
    t.visit(ast.parse(ref))
    assert astor.to_source(t.root) == ref

# Generated at 2022-06-12 04:15:15.468575
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:16.732770
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    pass
    # FIXME: implement


# Generated at 2022-06-12 04:15:19.722413
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:30.120432
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code1 = """
        def __init__(self):
            super()
    """
    tree1 = ast.parse(code1)
    SuperWithoutArgumentsTransformer().visit(tree1)

    assert ast.dump(tree1) == "Module([FunctionDef('__init__', arguments(args=[arg('self', None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), [Expr(Call(Name('super'), [Name('Cls'), Name('self')], []))], [], None))])"
    code2 = """
        class Cls:
            def __init__(self):
                super()
    """
    tree2 = ast.parse(code2)
    SuperWithoutArgumentsTransformer().visit(tree2)

    assert ast.dump

# Generated at 2022-06-12 04:15:34.219712
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    code = "super()"
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    code = astor.to_source(tree).strip()
    assert code == "super(Cls, cls)"


# Generated at 2022-06-12 04:15:36.502496
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:15:43.026612
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = textwrap.dedent("""
    class A:
        def __init__(self, x):
            super()
    """)
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == textwrap.dedent("""
    class A:
        def __init__(self, x):
            super(A, self)
    """)


# Generated at 2022-06-12 04:15:45.866861
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..converter import CodeToAst
    code = CodeToAst.parse('super()')
    SuperWithoutArgumentsTransformer(code).visit(code)
    print(astor.to_source(code))

# Generated at 2022-06-12 04:15:46.810862
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:54.554788
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse

    code = '''class A:
        def f(self):
            super()
        def f(self):
            super().f()
    '''
    expected_code = '''class A:
        def f(self):
            super(A, self)
        def f(self):
            super(A, self).f()
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)
    assert astunparse.unparse(tree) == expected_code

# Generated at 2022-06-12 04:15:55.884973
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    T = SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:02.913838
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('class MyClass(object): def __init__(self): super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    transformer.assert_different()
    assert transformer._tree_changed == True

    # Compare the code to the expected result
    tree = ast.parse('class MyClass(object): def __init__(self): super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    transformer.assert_different()
    tree_code = transformer.compile_code()
    assert tree_code == 'class MyClass(object): def __init__(self, *args, **kwargs): super(MyClass, self).__init__(*args, **kwargs)'


# Generated at 2022-06-12 04:16:08.989497
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "class A: def __init__(self): super().__init__()"
    expected_code = "class A: def __init__(self): super(A, self).__init__()"
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    new_tree = transformer.visit(tree)
    assert ast.dump(new_tree) == expected_code

# Generated at 2022-06-12 04:16:12.665669
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class A:
        def __init__(self):
            super()
            """

    output = """
    class A:
        def __init__(self):
            super(A, self)
            """

    tree = ast.parse(input)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == output



# Generated at 2022-06-12 04:16:19.004374
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Cls(object):
        def __init__(self):
            super()

        def meth(self):
            super()
    """
    expected_code = """
    class Cls(object):
        def __init__(self):
            super(Cls, self)

        def meth(self):
            super(Cls, self)
    """
    tt = TranspileTest(SuperWithoutArgumentsTransformer)
    tt.test(code, expected_code)

# Generated at 2022-06-12 04:16:19.835707
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:25.684951
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Cls(object):
            def __init__(self):
                super() 
    """
    expected = """
        class Cls(object):
            def __init__(self):
                super(Cls, self) 
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree).strip() == expected.strip()



# Generated at 2022-06-12 04:16:26.622625
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:35.997971
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
        transformer = SuperWithoutArgumentsTransformer()
        tree = ast.parse(
            '''
            class D():
                def __init__(self):
                    super()
            '''
        )
        transformer.visit(tree)

# Generated at 2022-06-12 04:16:41.340969
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_limited
    source_code = '''
x = 1
super(A)
'''
    tree = compile_limited(source_code, 2, 7)
    SuperWithoutArgumentsTransformer(tree).run()
    assert tree.body[1].value.args[0].id == 'A'

# Generated at 2022-06-12 04:16:41.937136
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:48.351528
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def _test_SuperWithoutArgumentsTransformer_helper(src_code, expected_src_code):
        ast_tree = ast.parse(src_code)
        SuperWithoutArgumentsTransformer().visit(ast_tree)
        actual_src_code = compile(ast_tree, '<string>', 'exec')
        expected_ast_tree = ast.parse(expected_src_code)
        expected_src_code = compile(expected_ast_tree, '<string>', 'exec')
        assert expected_src_code == actual_src_code

    # test 1

# Generated at 2022-06-12 04:16:58.065573
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    transformer = SuperWithoutArgumentsTransformer()

    # super() in class without args
    src = '''
    class MyClass:
        def __init__(self):
            super()
    '''
    expected_result = '''
    class MyClass:
        def __init__(self):
            super(MyClass, self)
    '''
    tree = ast.parse(src)
    transformer.visit(tree)
    actual_result = compile(tree, '', 'exec')
    actual_result = str(actual_result)[:-1].strip()
    expected_result = expected_result.strip()
    assert actual_result == expected_result


# Generated at 2022-06-12 04:17:03.874260
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .test_helpers import assert_equal_source
    from .. import transform

    ast_tree = ast.parse(
        """
        class Test:
            def __init__(self):
                super()
        """)

    c = transform(ast_tree, SuperWithoutArgumentsTransformer)
    assert_equal_source(c, """
        class Test:
            def __init__(self):
                super(Test, self)
        """)

# Generated at 2022-06-12 04:17:11.208172
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class A():
                def __init__(self):
                    super()
    '''
    tree = ast.parse(code)
    node = list(ast.walk(tree))[3].value
    assert(isinstance(node, ast.Call))
    SuperWithoutArgumentsTransformer().visit(node)
    node = list(ast.walk(tree))[3].value
    assert(isinstance(node, ast.Call))
    assert(isinstance(node.args[0], ast.Name))
    assert(node.args[0].id == 'A')

# Generated at 2022-06-12 04:17:19.360722
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # test super() outside of class
    test_tree = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer(test_tree)
    transformer.visit(test_tree)
    assert transformer._tree_changed == False
    assert transformer.result() == "super()"

    # test super() outside of function
    test_tree = ast.parse("class Cls:\n \tdef fn():\n\t\tsuper()")
    transformer = SuperWithoutArgumentsTransformer(test_tree)
    transformer.visit(test_tree)
    assert transformer._tree_changed == False
    assert transformer.result() == "class Cls:\n \tdef fn():\n\t\tsuper()"

    # test super() in method

# Generated at 2022-06-12 04:17:21.422277
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:23.253660
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:24.664949
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from astor import to_source


# Generated at 2022-06-12 04:17:31.908215
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('class a(): def foo(): super()')
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(tree)
    assert visitor._tree_changed == True
    assert ast.dump(tree) == '''Module(body=[ClassDef(name='a', bases=[], keywords=[],
    body=[FunctionDef(name='foo', args=arguments(args=[], vararg=None, kwarg=None, defaults=[]),
    body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='a', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))], decorator_list=[])], decorator_list=[])])'''

# Generated at 2022-06-12 04:17:36.571747
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..compiler import resolve_class_name
    from ..utils.helpers import get_identifier_from_node

    filename = 'example.py'
    scope    = {}


# Generated at 2022-06-12 04:17:42.354684
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class UnitTestTreeTransformer(ast.NodeTransformer):
        def visit_Node(self, node: ast.AST) -> ast.AST:
            if not isinstance(node, ast.AST):
                return node
            for field, old_value in ast.iter_fields(node):
                if isinstance(old_value, list):
                    new_values = []
                    for value in old_value:
                        if isinstance(value, ast.AST):
                            value = self.visit(value)
                            if value is None:
                                continue
                            elif not isinstance(value, ast.AST):
                                new_values.extend(value)
                                continue
                        new_values.append(value)
                    old_value[:] = new_values

# Generated at 2022-06-12 04:17:49.831235
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass
#     from ..utils.testing import generate_code
#     from ..utils.testing import assert_tree_is
    # TODO create tests

# Generated at 2022-06-12 04:17:55.316870
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    sample = """
    class Foo:
        def __init__(self):
            super().__init__()
            super().foo()
    """
    tree = ast.parse(sample)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == "class Foo: def __init__(self): super(Foo, self).__init__(); super(Foo, self).foo()"

# Generated at 2022-06-12 04:17:58.318237
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = ast.parse(
        "super()",
        mode='exec'
    )
    SuperWithoutArgumentsTransformer(t).visit(t)
    exec(compile(t, filename="", mode="exec"))

# Generated at 2022-06-12 04:18:07.858955
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from .unpacking import UnpackingTransformer

    code = """
    class A(object):
        def __init__(self):
            super()
            pass
            
    class B(A):
        def __init__(self, a):
            super()
            pass
            
    class C:
        def __call__(self):
            super()
            pass
    """
    tree = compile(code, '<test>', 'exec', ast.PyCF_ONLY_AST)
    tree = UnpackingTransformer().visit(tree)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    code = astor.to_source(tree)

# Generated at 2022-06-12 04:18:11.689418
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..replacement_transformer import ReplacementTransformer
    transformer = ReplacementTransformer()

    transformer.register_transformer(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-12 04:18:20.814695
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_helpers import source_to_ast as sta
    source = """
    class Cls:
        def __init__(self):
            super().__init__()

    class Cls2:
        def do(self):
            super()
    """
    expected = """
    class Cls:
        def __init__(self):
            super(Cls, self).__init__()

    class Cls2:
        def do(self):
            super(Cls2, self)
    """
    ast_tree = sta(source)
    SuperWithoutArgumentsTransformer(source, ast_tree).visit(ast_tree)
    assert ast.dump(ast_tree) == ast.dump(sta(expected))


# Generated at 2022-06-12 04:18:21.890716
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:22.699157
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:28.060101
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3  as ast
    node = ast.Call(
        func=ast.Name(id='super', ctx=ast.Load()),
        args=[],
        keywords=[],
        starargs=None,
        kwargs=None
    )
    ast.fix_missing_locations(node)
    tr = SuperWithoutArgumentsTransformer('<string>')
    x = tr.visit(node)
    assert x.args[0].id == 'Cls'
    assert x.args[1].id == 'self'
    assert tr._tree_changed

# Generated at 2022-06-12 04:18:34.165436
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from ..utils.source import source_to_ast as a
    from .helpers import assert_transformation

    source = """
        class T(object):
            def __init__(self):
                super()
    """

    expected = """
        class T(object):
            def __init__(self):
                super(T, self)
    """

    assert_transformation(SuperWithoutArgumentsTransformer, source, expected, a, u)

# Generated at 2022-06-12 04:18:46.585750
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:55.531352
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .setup_test import setup_test
    from .localization import LocalizationTransformer
    from .. import transformers

    code = '''
    class A:
        def __init__(self):
            super()
            super('XXX')
    '''

    tree = ast.parse(code)
    tree = transformers.transform(tree, LocalizationTransformer)
    tree = transformers.transform(tree, SuperWithoutArgumentsTransformer)

    assert 'A' == setup_test(tree)[1].body[0].body[0].value.func.args[0].id
    assert 'XXX' == setup_test(tree)[1].body[0].body[1].value.func.args[0].s

# Generated at 2022-06-12 04:19:00.649029
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.testing import assert_transformed_code

    assert_transformed_code(
        SuperWithoutArgumentsTransformer,
        """class Test(object):
            def __init__(self):
                super()""",
        """class Test(object):
            def __init__(self):
                super(Test, self)"""
    )

    assert_transformed_code(
        SuperWithoutArgumentsTransformer,
        """class Test(object):
            def __init__(self, name):
                super()""",
        """class Test(object):
            def __init__(self, name):
                super(Test, self)"""
    )

# Generated at 2022-06-12 04:19:05.458104
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        def __init__(self):
            super()  # noqa
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert code_gen.to_source(tree) == '''
        def __init__(self):
            super(Cls, self)  # noqa
    '''

# Generated at 2022-06-12 04:19:11.500505
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    import os
    import sys
    from ..utils.context import Context
    from ..transforms import SuperWithoutArgumentsTransformer
    from ..utils.source import source_to_unicode
    from .test_helpers import assert_startswith

    context = Context(
        os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'tests', 'data', 'python-scripts')),
        sys.path, True, {})


# Generated at 2022-06-12 04:19:21.114572
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_code_object
    from ..utils.source import source_to_function
    from ..utils.source import source_to_ast
    from ..utils.helpers import loc

    def test_function(tree: ast.AST) -> ast.FunctionDef:
        transformer = SuperWithoutArgumentsTransformer(tree)
        new_tree = transformer.visit(tree)
        code = compile(new_tree, '<ast>', 'exec')

        globals_ = {}
        exec(code, globals_)
        function = globals_['test_function']

        return source_to_function(function)

    def test_code_object(code: str) -> ast.FunctionDef:
        tree = source_to_ast(code)
        transformer = SuperWithoutArgumentsTransformer(tree)
       

# Generated at 2022-06-12 04:19:31.411980
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class NodeVisitor(ast.NodeVisitor):
        def __init__(self):
            self._tree = ast.parse(
                """
                class Foo():
                    def __init__(self):
                        super()
                
                """
            )

        def visit_Call(self, node: ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                node.args = [ast.Name(id='Foo'), ast.Name(id='self')]
            self.generic_visit(node)  # type: ignore

    visitor = NodeVisitor()
    visitor.visit(visitor._tree)

    my_super_without_args_transformer = SuperWithoutArgumentsTransformer(visitor._tree)
    my_super_

# Generated at 2022-06-12 04:19:41.955963
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest

    from .base import BaseTestTransformer

    class TestSuperWithoutArgumentsTransformer(BaseTestTransformer, unittest.TestCase):
        transformer = SuperWithoutArgumentsTransformer

        def test_super_without_arguments(self):
            code = """
            class D(object):
                def __init__(self):
                    super()
            """
            result = """
            class D(object):
                def __init__(self):
                    super(D, self)
            """
            self.assertCodeEqual(code, result)

        def test_super_no_function(self):
            code = """
            super()
            """
            result = """
            super(D, self)
            """
            self.assertCodeEqual(code, result)


# Generated at 2022-06-12 04:19:51.308938
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import setup_fixtures
    from .base import BaseNodeTransformer
    from .super_without_arguments import SuperWithoutArgumentsTransformer

    source = """
        class MyCls(object):
            def __init__(self):
                super() #super()
        
        class MyCls1(object):
            def __init__(self):
                super(MyCls1, self) #super()
        
        class MyCls2(object):
            def __init__(self):
                super(MyCls2, cls) #super()
        
        class MyCls2(object):
            def __init__(self):
                super(MyCls2, cls)
        
    """

# Generated at 2022-06-12 04:19:52.761515
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_code_object

# Generated at 2022-06-12 04:20:26.324723
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .codegen import to_source
    from .typing import TypingTransformer
    from .tree import ASTNodeTransformer
    from .unpacking import UnpackingTransformer
    from .parentheses import ParenthesesTransformer
    from .my_ast import parse

    source = '''
    class A:
        def __init__(self):
            super().__init__()
    '''

    tree = parse(source)
    tree = ASTNodeTransformer(tree).visit(tree)
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    tree = TypingTransformer(tree).visit(tree)
    tree = UnpackingTransformer(tree).visit(tree)
    tree = ParenthesesTransformer(tree).visit(tree)


# Generated at 2022-06-12 04:20:31.489683
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = '''
        class Foo:
            def __init__(self):
                super()
    '''

    tree = ast.parse(source)
    fixed_tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    expected_tree = ast.parse('''
        class Foo:
            def __init__(self):
                super(Foo, self)
    ''')

    assert tree != expected_tree
    assert ast.dump(tree) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:20:39.972282
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .wrappers import FunctionDefWrapper
    from ..utils import module_to_str
    from .. import __version__
    
    def get_module(body) -> ast.Module:
        """Returns an ast.Module with body as the body of the module."""
        module: ast.Module = ast.parse('')
        module.body = body
        return module
    
    def get_transformed_module(body) -> ast.Module:
        """Returns an ast.Module with the body transformed using SuperWithoutArgumentsTransformer."""
        return SuperWithoutArgumentsTransformer().visit(get_module(body))
    

# Generated at 2022-06-12 04:20:48.093479
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class C(object):
        def __init__(self):
            super().__init__()
        def f(self, cls):
            super().f(cls)
    '''

    expected_code = '''
    class C(object):
        def __init__(self):
            super(C, self).__init__()
        def f(self, cls):
            super(C, cls).f(cls)
    '''

    class Tree(object):
        def __init__(self, tree):
            self.tree = tree

        def __getitem__(self, item: Union[int, slice, ast.AST]) -> Union[ast.AST, List[ast.AST]]:
            return self.tree

    tree = ast.parse(code)
    t = SuperWithout

# Generated at 2022-06-12 04:20:48.576268
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:54.980053
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test constructor of class SuperWithoutArgumentsTransformer"""

    input_code = '''
super()
'''
    expected_code = '''
super(Cls, self)
'''

    # The input code is transformed
    tree = ast.parse(input_code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == expected_code

    # The input code is not transformed
    tree = ast.parse(input_code)
    SuperWithoutArgumentsTransformer(transform_level=0).visit(tree)
    assert ast.dump(tree) == input_code



# Generated at 2022-06-12 04:21:03.256027
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestTransformer(SuperWithoutArgumentsTransformer):
        def _get_tree(self, node: ast.AST) -> Optional[ast.AST]:
            return node


    class DummyNode(ast.AST):
        _fields = ()

    module = DummyNode()
    module.body = [
        ast.ClassDef(
            'Test', [], [], [],
            ast.FunctionDef(
                'test', ast.arguments([], None, None, []), [],
                ast.Expr(
                    ast.Call(
                        ast.Name('super', None), [], []
                    )
                )
            )
        )
    ]

    TestTransformer(module).visit(module)
    node = module.body[0]

# Generated at 2022-06-12 04:21:09.663928
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = dedent('''
        class A:
            def f(self):
                super()
        ''')

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()

    new_code = dedent('''
        class A:
            def f(self):
                super(A, self)
        ''')

    expected = ast.parse(new_code)
    assert compare_ast(tree, expected)

# Generated at 2022-06-12 04:21:10.377529
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:11.598570
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast


# Generated at 2022-06-12 04:22:17.854206
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import ast_converter
    from .. import tree_utils


# Generated at 2022-06-12 04:22:21.221660
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    code = 'super()'
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    result = astor.to_source(tree)
    assert result == 'super(__name__, __name__)\n'

# Generated at 2022-06-12 04:22:24.802214
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class Cls:
        def func(self):
            super()
    '''

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(Cls, self)' in str(tree)

# Generated at 2022-06-12 04:22:25.241804
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:22:25.733317
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-12 04:22:30.225180
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import compile_source, run_generated_code
    code = """
    class Foo:
        def __init__(self):
            super().__init__()
    """
    module = compile_source(SuperWithoutArgumentsTransformer, code)
    assert module.Foo.__init__.__defaults__ == (Foo,)
    assert run_generated_code(module, 'Foo().__init__()') == 'Foo'

# Generated at 2022-06-12 04:22:30.701988
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:34.842078
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import literal_eval
    from typed_ast.ast3 import parse

    s = "super()"
    t = parse(s)
    SuperWithoutArgumentsTransformer().visit(t)
    output = literal_eval(s)

    expected = "super(Cls, self)"
    t2 = parse(expected)
    SuperWithoutArgumentsTransformer().visit(t2)
    
    assert output == literal_eval(expected)

# Generated at 2022-06-12 04:22:35.836731
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

# Generated at 2022-06-12 04:22:45.051969
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Test for a simple class
    code_tree = ast.parse('class Test:\n    def method(self):\n        super()')
    SuperWithoutArgumentsTransformer(code_tree).run()