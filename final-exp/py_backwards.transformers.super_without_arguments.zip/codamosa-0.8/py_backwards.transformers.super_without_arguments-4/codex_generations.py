

# Generated at 2022-06-12 04:14:21.382363
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""

# Generated at 2022-06-12 04:14:22.362128
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:25.088331
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = "super()"
    tree = ast.parse(s)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert "super(Cls, self)" in ast.dump(tree)

# Generated at 2022-06-12 04:14:29.526174
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    p = SuperWithoutArgumentsTransformer()
    source = """
        class A:
            def __init__(self):
                super()
    """
    tree = ast.parse(source)

    p.visit(tree)
    code = compile(tree, '', 'exec')
    eval(code)

# Generated at 2022-06-12 04:14:34.368466
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('class A:\n    def a(self):\n        super()')    
    node2 = ast.parse('class A:\n    def a(self):\n        super(A, self)')
    assert SuperWithoutArgumentsTransformer().visit(node) == node2.body[0].body[0]  # type: ignore

# Generated at 2022-06-12 04:14:35.803211
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:45.813868
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .. import compile_to_ast as c2a
    from .. import compile_to_python as c2p
    source_code = '''
        class Foo():
            def __init__(self):
                super()
        class Bar():
            def __init__(self):
                super().__init__()
        class Baz(Bar):
            def __init__(self):
                super()
    '''
    tree = c2a(source_code, target_versions={(2, 7)})
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    result = c2p(tree, '2.7')

# Generated at 2022-06-12 04:14:50.007861
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'class C: def m(self): super()'
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert_code_equal(
        code='class C: def m(self): super(C, self)',
        tree=tree
    )



# Generated at 2022-06-12 04:14:53.938656
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tree = ast.parse(code)
    node = tree.body[0]
    inferred = SuperWithoutArgumentsTransformer().visit(node).args[0]
    assert isinstance(inferred, ast.Name) and inferred.id == 'Cls'

# Generated at 2022-06-12 04:14:56.978757
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    transpiler = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-12 04:15:07.461781
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""class Cls(object):
                            def __new__(cls):
                                super()
                    """)
    tree_ = ast.parse("""class Cls(object):
                            def __new__(cls):
                                super(Cls, cls)
                    """)
    trans = SuperWithoutArgumentsTransformer(tree)
    trans.run()
    assert ast.dump(tree) == ast.dump(tree_)

# Generated at 2022-06-12 04:15:17.334416
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def check(src: str, expected: str) -> None:
        t = SuperWithoutArgumentsTransformer([], 2, 7)
        tree = ast.parse(src)
        with warnings.catch_warnings(record=True) as w:
            t.visit(tree)
            t.visit(tree)  # run twice to check idempotency
        assert len(w) == 0, 'warnings during transform'
        t.finalize()
        assert ast.dump(tree) == expected

# Generated at 2022-06-12 04:15:22.797227
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    ast2 = SuperWithoutArgumentsTransformer().visit(ast.Call(func=ast.Name(id='super'), args=[], keywords=[]))
    assert ast2.func.id == 'super'
    assert ast2.args[0].id == 'Cls'
    assert ast2.args[1].id == 'self'

# Generated at 2022-06-12 04:15:32.968797
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.testing import (
        assert_compiled_ast_matches,
        assert_source_code_transformation,
    )
    assert_compiled_ast_matches(
        SuperWithoutArgumentsTransformer,
        example_code='''
        class A:
            def B(self):
                super()
        ''',
        expected_code='''
        class A:
            def B(self):
                super(A, self)
        ''',
    )

# Generated at 2022-06-12 04:15:43.973242
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..tokenize import tokenize
    from ..parse import parse
    from .. import fix_missing_locations
    from . import ClassNodeTransformer, ArgumentListTransformer, FunctionDefTransformer

    source = """
        class Cls(super):
            def method(self):
                super()

        def func():
            return super()
    """
    tree = parse(tokenize(source))
    fix_missing_locations(tree)

    tree = FunctionDefTransformer().visit(tree)
    tree = ClassNodeTransformer().visit(tree)
    tree = ArgumentListTransformer().visit(tree)
    tree = SuperWithoutArgumentsTransformer().visit(tree)


# Generated at 2022-06-12 04:15:54.130669
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse

    src = """
    class A:
        def __init__(self, arg1):
            super()

    class B:
        def __init__(self):
            super()
    """
    expected_result = """
    class A:
        def __init__(self, arg1):
            super(A, self)

    class B:
        def __init__(self):
            super(B, self)
    """
    tree = parse(src)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = compile(tree, filename="<ast>", mode="exec").co_consts[0]
    assert result == expected_result.strip()


# Generated at 2022-06-12 04:15:59.757543
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(None)
    arg_list = []
    ast_call = ast.Call(
        func = None,
        args = arg_list,
        keywords = [],
    )
    old_args = ast_call.args
    transformer.visit_Call(ast_call)
    assert ast_call.args is not old_args
    assert ast_call.args == [ast.Name(id=None), ast.Name(id=None)]

# Generated at 2022-06-12 04:16:01.278716
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:09.273354
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Set up a test tree
    tree = ast.fix_missing_locations(ast.parse(
        'class ExampleClass(object):\n'
        '    def example_func(self):\n'
        '        self.example_attr = super()',
        mode='exec'
    ))

    # Run function
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    # Check if it updated the tree correctly
    correct_tree = ast.fix_missing_locations(ast.parse(
        'class ExampleClass(object):\n'
        '    def example_func(self):\n'
        '        self.example_attr = super(ExampleClass, self)',
        mode='exec'
    ))
    assert ast.dump(tree) == ast.dump(correct_tree)

# Generated at 2022-06-12 04:16:10.148591
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:16:13.956755
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:15.683603
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:22.182455
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = u"""class Foo(object):
    def __init__(self):
        super()
        """.encode('utf-8')

    expected_source = u"""class Foo(object):
    def __init__(self):
        super(Foo, self)
        """.encode('utf-8')

    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    result_source = _get_source(tree)
    assert result_source == expected_source


# Generated at 2022-06-12 04:16:25.844162
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from ..parser import parse
    from .stub_node import BuiltinFunctionStub, FunctionStub, NameStub, ClassDefStub, ArgumentsStub, AttributeStub


# Generated at 2022-06-12 04:16:35.540548
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_restricted

    # Success when the visitor encounters a call to super() with no arguments
    source = """
        class Cls:
            def func(self):
                super()
    """
    three_ast = compile_restricted(source, '<test>', 'exec', ast3)
    SuperWithoutArgumentsTransformer(three_ast).visit(three_ast)
    assert isinstance(three_ast.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(three_ast.body[0].body[0].body[0].value.args[0], ast.Name)
    assert three_ast.body[0].body[0].body[0].value.args[0].id == 'Cls'

# Generated at 2022-06-12 04:16:46.364547
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import sys
    import astor
    if sys.version_info < (2, 7):
        return
    code_before = """
        class Sample:
            def func(self):
                super()

        class Sample:
            def func(self):
                super(Sample, self).func()

        class Sample:
            def func(self):
                print(super().func)

        class Sample:
            def func(self):
                print(super(Sample, self).func)

        class Sample:
            def func(self):
                print(super(Sample, self).func())

        class Sample:
            def func(self):
                a = super().func
    """

# Generated at 2022-06-12 04:16:55.855943
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class Test(SuperWithoutArgumentsTransformer):
        def __init__(self):
            super().__init__()
            self._tree = None
        def visit_Call(self, node):
            self.generic_visit(node)  # type: ignore
    tree = ast.parse("super()")
    Test().visit(tree)
    assert ast.dump(tree, include_attributes=True) == \
            ast.dump(ast.parse("super(__class__, self)"))
    tree = ast.parse("def foo():\n    super()")
    Test().visit(tree)
    assert ast.dump(tree, include_attributes=True) == \
            ast.dump(ast.parse("def foo():\n    super(__class__, self)"))

# Generated at 2022-06-12 04:17:06.675554
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_block_1 = '''\
    class Cls(object):
        def method(self):
            return super()
    '''

# Generated at 2022-06-12 04:17:07.616032
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:08.418086
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:17.626020
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Cls(object):
        def __init__(self):
            super()
    """
    expected_code = """
    class Cls(object):
        def __init__(self):
            super(Cls, self)
    """
    assert(SuperWithoutArgumentsTransformer(code, None).result == expected_code)

# Generated at 2022-06-12 04:17:22.310154
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .unparser import Unparser
    from .parser import parse

    tree = parse("""
    class A:
        def m():
            assert super() == super(A, A)
    """)

    SuperWithoutArgumentsTransformer(tree, None).visit(tree)
    Unparser(tree, None)

    tree = parse("""
    class A:
        def m():
            assert super() == super(A, A)
    """)

    SuperWithoutArgumentsTransformer(tree, None).visit(tree)
    Unparser(tree, None)



# Generated at 2022-06-12 04:17:30.541477
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTest
    import textwrap
    
    class_source = textwrap.dedent('''
    # Some comment
    class Sub(Parent):
        def log(self):
          super()
    ''')

    exp_result = textwrap.dedent('''
    # Some comment
    class Sub(Parent):
        def log(self):
          super(Sub, self)
    ''')

    exp_tree = BaseNodeTransformerTest.compile_to_ast(exp_result)
    tree = BaseNodeTransformerTest.compile_to_ast(class_source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert exp_tree == tree

# Generated at 2022-06-12 04:17:31.379954
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:33.706979
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-12 04:17:34.464718
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:38.966373
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from typed_ast import ast27 as ast27

    class NodeTransformerTester(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            assert node.args[0].id == 'cls'
            assert node.args[1].id == 'self'


# Generated at 2022-06-12 04:17:49.105566
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..parsers.python import PythonParser

    code = """
    class TestClass(object):
        def __init__(self):
            super()
    """
    lines = []
    parser = PythonParser('2.7')
    node = parser.parse(code)
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(node)

    for line in code.splitlines():
        lines.append(line)
    result = parser.module_to_str(node)
    expected = """
    class TestClass(object):
        def __init__(self):
            super(TestClass, self)
    """
    lines2 = []
    for line in expected.splitlines():
        lines2.append(line)
    differences = []
    zipped_pairs = zip(lines, lines2)
   

# Generated at 2022-06-12 04:17:58.587863
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    code = '''
    class C(object):
        def __init__(self):
            super().__init__()

        @classmethod
        def cm(cls):
            super().cm()

        @staticmethod
        def sm():
            super().sm()
    '''

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert to_code(tree) == '''
    class C(object):
        def __init__(self):
            super(C, self).__init__()

        @classmethod
        def cm(cls):
            super(C, cls).cm()

        @staticmethod
        def sm():
            super(C, cls).sm()
    '''

# Generated at 2022-06-12 04:17:59.670082
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:18:16.970131
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    orig_module = ast.parse("""class C(object):
            def f(self):
                super()""")

    expected_module = ast.parse("""class C(object):
            def f(self):
                super(C, self)""")

    SuperWithoutArgumentsTransformer().visit(orig_module)

    orig_module_code = compile(orig_module, '', 'exec')
    expected_module_code = compile(expected_module, '', 'exec')
    assert orig_module_code == expected_module_code

# Generated at 2022-06-12 04:18:17.943541
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:18.910979
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:25.625191
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ..utils.test import transforms_to

    @transforms_to(
        # Note that this is different from the CPython 2.x implementation which
        # has no args.
        """
        class Test(object):
            def meth(self):
                super(Test, self)

            @classmethod
            def clsmeth(cls):
                super(Test, cls)
        """
    )
    def test():
        class Test(object):
            def meth(self):
                super()

            @classmethod
            def clsmeth(cls):
                super()
    test()

# Generated at 2022-06-12 04:18:34.635188
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node1 = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    node2 = ast.FunctionDef(
        name='foo',
        args=ast.arguments(
            args=[ast.arg(arg='bar', annotation=None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            node1
        ]
    )
    node3 = ast.ClassDef(name='Cls', bases=[], keywords=[], body=[node2])
    tree = ast.Module(body=[node3])

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)


# Generated at 2022-06-12 04:18:44.141511
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:45.102494
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:55.180816
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    class_definition_fixture = ast.ClassDef(name="Foo", bases=[], keywords=[],
                                            body=[ast.FunctionDef(name="bar", args=ast.arguments(args=[], vararg=None,
                                                                                               kwonlyargs=[],
                                                                                               kw_defaults=[],
                                                                                               kwarg=None,
                                                                                               defaults=[]),
                                                                  body=[ast.Expr(value=ast.Call(func=ast.Name(id="super", ctx=ast.Load()),
                                                                                                args=[], keywords=[]))])],
                                            decorator_list=[])
    # When
    nodes_mapping = {ast.ClassDef: class_definition_fixture}
    SuperWithout

# Generated at 2022-06-12 04:18:55.751863
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:00.202152
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    node = ast.parse(source_to_unicode('''
        class A:
            def __init__(self):
                super()
    '''))
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert tree_to_str(node) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-12 04:19:30.269354
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..fixer_utils import parse_text_to_ast_or_error

    class Dummy:
        pass

    class DummySuper:
        pass

    src = "super()"
    expected = "super(Dummy, a)"

    ast_tree = parse_text_to_ast_or_error(src, 2, 7)
    tree = parse_text_to_ast_or_error(expected, 2, 7)
    tree = SuperWithoutArgumentsTransformer(ast_tree).visit(tree)

    assert ast_tree.body[0] == tree.body[0]

# Generated at 2022-06-12 04:19:40.292907
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_code_equal, generate_code_for_module_dict, assert_tree_equal

    from .. import fixers

    fixers = [fixers.SuperWithoutArgumentsTransformer]


# Generated at 2022-06-12 04:19:49.437813
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse
    from .context import Context
    from .base import BaseNodeTransformer
    from ..pythontypes import ClassType

    import astor

    context = Context()
    context.update('super',  ClassType('super', (ClassType('object'),)))

    transformer = SuperWithoutArgumentsTransformer(context, parse('super()').body[0], parse('def test(): pass').body[0])
    result = transformer.visit(parse('super()'))
    assert astor.to_source(result) == "super(object, self)"

    context.update('super', None)
    transformer = SuperWithoutArgumentsTransformer(context, parse('super()').body[0], parse('def test(): pass').body[0])
    result = transformer.visit(parse('super()'))

# Generated at 2022-06-12 04:19:58.801057
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .base import BaseNodeTransformerTest
    from ..testing import ExceptionRaised
    from ..testing.tools import create_fake_parent, wrap_nodes_to_tree, wrap_nodes_to_tree
    import unittest
    import typed_ast.ast3 as ast

    class TestSuperWithoutArgumentsTransformer(unittest.TestCase, BaseNodeTransformerTest):
        transformer = SuperWithoutArgumentsTransformer
        method = 'visit_Call'


# Generated at 2022-06-12 04:19:59.782765
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:06.071609
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent

    INPUT_CODE = dedent('''
        class MyClass():
            def func():
                super()
                pass
        ''')

    expected_output_code = dedent('''
        class MyClass():
            def func():
                super(MyClass, cls)
                pass
        ''')

    node = ast.parse(INPUT_CODE)
    node = SuperWithoutArgumentsTransformer().visit(node)

    assert ast.dump(node) == ast.dump(ast.parse(expected_output_code))

# Generated at 2022-06-12 04:20:14.689929
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).run()
    assert ast.dump(tree) == 'Module(body=[FunctionDef(name=\'\', args=arguments(args=[arg(arg=\'self\', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Super(args=[Name(id=\'Cls\', ctx=Load()), Name(id=\'self\', ctx=Load())], keywords=[])], decorator_list=[], returns=None)])'

    tree = ast.parse('class Cls:\n  def m(self):\n    super()')
    SuperWithoutArgumentsTransformer(tree).run()

# Generated at 2022-06-12 04:20:19.969682
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()', mode='eval')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None)"

# Generated at 2022-06-12 04:20:29.124981
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import all_versions

    # py27: no super()
    @all_versions
    def test_no_super(self):
        tree = ast.parse("""
            class a:
                def a():
                    pass
        """)
        Suite(tree).visit(SuperWithoutArgumentsTransformer)
        self.assertEqual(to_source(tree), """\
            class a:
                def a():
                    pass
        """)

    # py27: no super() in class
    @all_versions
    def test_class_no_super(self):
        tree = ast.parse("""
            class a:
                class b:
                    pass
        """)
        Suite(tree).visit(SuperWithoutArgumentsTransformer)

# Generated at 2022-06-12 04:20:33.528660
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse(
        "class Foo:\n"
        "    def bar(self):\n"
        "        super()"
    )

    SuperWithoutArgumentsTransformer(node).visit(node)

    assert ast.dump(node) == ast.dump(
        ast.parse(
            "class Foo:\n"
            "    def bar(self):\n"
            "        super(Foo, self)"
        )
    )

# Generated at 2022-06-12 04:20:58.286605
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:59.364170
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..testing_utils import assert_tree


# Generated at 2022-06-12 04:21:04.689203
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .helpers import get_results
    source = """
        class A(object):
            def __init__(self):
                super().__init__()"""

    expected_source = """
        class A(object):
            def __init__(self):
                super(A, self).__init__()"""

    result = get_results(SuperWithoutArgumentsTransformer, source)
    assert result == expected_source

# Generated at 2022-06-12 04:21:12.711135
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    xform = SuperWithoutArgumentsTransformer()
    assert xform.target == (2, 7)

    """
    Class A:
        def __init__(self):
            super().__init__()
    """
    tree = ast.parse('class A:\n def __init__(self): super().__init__()')
    xform.visit(tree)

    """
    class B:
        def __init__(self):
            super(B, self).__init__()
    """
    expected = ast.parse('class B:\n def __init__(self): super(B, self).__init__()')
    assert ast.dump(tree, False, False) == ast.dump(expected, False, False)


# Generated at 2022-06-12 04:21:15.605750
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..test_utils import make_test_tree
    from .helpers_2to3 import print_tree


# Generated at 2022-06-12 04:21:16.112472
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:23.007014
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..base import do_transformation
    import typed_ast.ast3 as ast

    code = '''
    class A:
        def __init__(self):
            super()

    class B:
        def __init__(self, a):
            super()

    class C:
        def __init__(self, a, b, c):
            super()

    class D(A):
        def __init__(self, a):
            super()

    class E(A):
        def __init__(self, a, b, c, d):
            super()
    '''

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer.run(tree)


# Generated at 2022-06-12 04:21:23.840693
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import test_utils

# Generated at 2022-06-12 04:21:29.349913
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ...utils.testing import assert_transformed_code

    assert_transformed_code(
        SuperWithoutArgumentsTransformer,
        """
        class Point:
            def __init__(self, x, y):
                super().__init__(x, y)
        """,
        """
        class Point:
            def __init__(self, x, y):
                super(Point, self).__init__(x, y)
        """
    )

# Generated at 2022-06-12 04:21:32.995316
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    code = 'super()'
    module = ast.parse(code)
    new_module = SuperWithoutArgumentsTransformer().visit(module)
    new_code = compile(new_module, '<string>', 'exec')
    globs = {'super': super}
    eval(new_code, globs)

# Generated at 2022-06-12 04:22:26.640618
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .ast_builder import AstBuilder, FunctionBuilder, ClassBuilder, ReturnBuilder, AssignBuilder, NameBuilder, CallBuilder, ExprBuilder

    result = AstBuilder('''
           class A:
              def __init__(self, name):
                self.name = name
              def get_name(self):
                  return super().name
    ''').with_transformed(SuperWithoutArgumentsTransformer)

    expected = AstBuilder('''
           class A:
              def __init__(self, name):
                self.name = name
              def get_name(self):
                  return super(A, self).name
    ''')

    assert expected == result

# Generated at 2022-06-12 04:22:31.514454
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def __init__(self):
            super()
            a = super()
        def less_args(self):
            super()
            
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert(compile(tree, '', 'exec').co_code ==
           compile(code.replace('super()', 'super(A, self)'), '', 'exec').co_code)

# Generated at 2022-06-12 04:22:36.985221
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
    This function is used to unit test constructor of class SuperWithoutArgumentsTransformer.
    """
    code = """
    a = super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "Module(body=[Assign(targets=[Name(id='a', ctx=Store())], value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='BaseClass', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"


# Generated at 2022-06-12 04:22:39.356915
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from ..utils.helpers import strip_lines


# Generated at 2022-06-12 04:22:42.110310
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:22:48.474225
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes

    code = "class C: pass"
    assert code == str(ast.parse(code))

    code = "class C: \n    def m(self): super()"
    node = source_to_nodes(code)
    assert '[Call(Name(super), [Name(C), Name(self)], [], None, None)]' == str(
        node.body[0].body[0].body)

    code = "class C: \n    def m(self): super(X)"
    node = source_to_nodes(code)
    assert '[Call(Name(super), [Name(C), Name(self)], [], None, None)]' == str(
        node.body[0].body[0].body)


# Generated at 2022-06-12 04:22:49.719281
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:51.442278
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast27
    from ..visitor import VisitorsDispatcher

# Generated at 2022-06-12 04:22:51.972005
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-12 04:22:52.763290
# Unit test for constructor of class SuperWithoutArgumentsTransformer