

# Generated at 2022-06-12 04:14:27.441418
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:36.997047
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    il=ast.parse('''class A:
    def __init__(self):
        super()''')
    obj=SuperWithoutArgumentsTransformer(il)
    obj.run()
    assert(str(il)=='''class A:
    def __init__(self):
        super(A, self)''')
    il=ast.parse('''class A:
    def __init__(self,a):
        def d(self):
            super()''')
    obj=SuperWithoutArgumentsTransformer(il)
    obj.run()
    assert(str(il)=='''class A:
    def __init__(self,a):
        def d(self):
            super(A, self)''')

# Generated at 2022-06-12 04:14:41.041671
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .context import Context
    from .exceptions import TransformationError
    from .unsupported_features import UnsupportedFeaturesTransformer
    from .unsupported_syntax import UnsupportedSyntaxTransformer

# Generated at 2022-06-12 04:14:48.535380
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Simple example for the test
    code = '''
        super()
    '''

    # Following is needed to simulate how the source code is parsed from Python 2.7
    from ..utils.ast_parser import ASTParser
    root = ASTParser(code, 2.7).parse()

    # Create the transformer
    transformer = SuperWithoutArgumentsTransformer()

    # Transform the code
    transformer.visit(root)

    # Check the result (compare the code after transformation with the expected code)
    assert code_gen.to_source(root) == '''\
        super(Cls, self)
    '''

# Generated at 2022-06-12 04:14:51.062865
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # arrange
    from ..transpiler import Transpiler
    from .test_helpers import assert_program
    from ..parser import parse

# Generated at 2022-06-12 04:14:51.924867
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:56.005922
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import settings
    from .. import tree

    class TestTransformer(SuperWithoutArgumentsTransformer):
        """Transformer for testing purposes"""
        def visit_Name(self, node):
            node.id = 'transformed'
            self._tree_changed = True
            return node


# Generated at 2022-06-12 04:15:00.227328
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    _ = ast.parse(
        """
        class MyClass(object):
            def mymethod(self):
                super()
        """)

    t = SuperWithoutArgumentsTransformer()
    t.visit(_)

    assert _ == ast.parse(
        """
        class MyClass(object):
            def mymethod(self):
                super(MyClass, self)
        """)



# Generated at 2022-06-12 04:15:09.605661
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import run_transformers
    from .. import utils
    from . import base
    from . import super_without_arguments

    code = '''class Foo(object):
    def __init__(self):
        super().__init__()
'''
    root = utils.parse_code(code)
    transformer = super_without_arguments.SuperWithoutArgumentsTransformer(root)
    run_transformers(root, [transformer])
    assert transformer.tree_changed()
    assert utils.dump_code(root) == '''class Foo(object):
    def __init__(self):
        super(Foo, self).__init__()
'''


# Generated at 2022-06-12 04:15:13.678380
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    # Expected node
    node_expected: ast.Call

    # Actual node
    node_actual: ast.Call

    # Expected ast

# Generated at 2022-06-12 04:15:22.061520
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
        
    code = dedent('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).run()
    assert ast.dump(tree) == dedent('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-12 04:15:23.416937
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer(tree=None).generic_visit(None) is None

# Generated at 2022-06-12 04:15:24.027525
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert True

# Generated at 2022-06-12 04:15:28.770915
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = SuperWithoutArgumentsTransformer()

    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    t.visit_Call(node)
    assert node.args[0].id == 'Cls'
    assert node.args[1].id == 'self'


# Generated at 2022-06-12 04:15:31.785993
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'

    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert str(tree) == "super(__main__, cls)"

# Generated at 2022-06-12 04:15:42.316249
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    from ..utils.ast_helpers import ast_transformer_test_helper

    class Base(ast.AST):
        _fields = ('name', 'args', 'keywords')

    class SuperNode(ast.AST):
        _fields = ('func', 'args', 'keywords', 'starargs', 'kwargs')

    source = ast.parse("""
        class c(object):
            def f(self):
                super()
    """)
    expected = ast.parse("""
        class c(object):
            def f(self):
                super(c, self)
    """)

    ast_transformer_test_helper(source, expected, SuperWithoutArgumentsTransformer)



# Generated at 2022-06-12 04:15:48.105241
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Create a simple target tree
    t = ast.parse('''
    class A:
        def f(self):
            super()
    ''')

    # Set up and run the transformer
    tt = SuperWithoutArgumentsTransformer(t, (2, 7))
    tt.run()
    #print(t)

    # Verify the transformed tree
    assert t == ast.parse('''
    class A:
        def f(self):
            super(A, self)
    ''')

# Generated at 2022-06-12 04:15:56.605413
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..parser import parse

    # Create an instance of a subclass
    transformer = SuperWithoutArgumentsTransformer()

    # Create a parse tree
    tree = parse('super()')

    # Transform the tree
    new_tree = transformer.visit(tree)

    # default dicts
    assert_equal(repr(ast.dump(new_tree)), 'Module(body=[Expr(value=Call(func=Name(id=super, ctx=Load()), args=[Name(id=C, ctx=Load()), Name(id=self, ctx=Load())], keywords=[], starargs=None, kwargs=None))])')

# Generated at 2022-06-12 04:16:06.092102
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import _ast
    from typed_ast import ast3 as ast
    from ..python_transformer import PythonTransformer
    from ..utils.tree import build_tree

    node = ast.parse('super()')
    tree = build_tree(node)

    cls_node_name = ast.Name(id='Cls')
    func_node_name = ast.Name(id='func')
    func_node_arg = ast.arg(arg='self', annotation=None)
    func_node_arguments = ast.arguments(args=[func_node_arg], vararg=None,
                                        kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[])

# Generated at 2022-06-12 04:16:07.678608
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer(None, None)._replace_super_args is not None

# Generated at 2022-06-12 04:16:23.467601
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse
    from ..minifier import minify
    import textwrap
    source = textwrap.dedent(r"""
    class A:
        def __init__(self):
            super().__init__()
        def f(self):
            x = super()
            y = super()
            super()
        def f2(self):
            def g():
                super()
    class B(A):
        def __init__(self):
            super().__init__()
    class C(A):
        def __init__(self, x):
            super().__init__()
    class D(A):
        def __init__(self, x):
            super(D, self).__init__()
    """)
    module = parse(source)

# Generated at 2022-06-12 04:16:34.067490
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

    tree = ast.parse("""
    class Test:
        def __init__(self):
            super()
    """)

    transformer.visit(tree)

    assert transformer._tree_changed is True

# Generated at 2022-06-12 04:16:35.548881
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import refactor

# Generated at 2022-06-12 04:16:46.364004
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    test_tree = ast.parse("""class Cls(object):
                                 def method(self):
                                     super()""")
    SuperWithoutArgumentsTransformer().visit(test_tree)

# Generated at 2022-06-12 04:16:47.187242
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:55.523770
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class_name = 'TestClass'
    super_call = "super()"
    module = ast.parse(f'class {class_name}:\n    def __init__(self, a):\n        {super_call}\n        self.a = a')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(module)
    module_out = transformer.transpile_visit(module)
    assert module_out == f"""class {class_name}:\n    def __init__(self, a):\n        super({class_name}, self).__init__()\n        self.a = a\n"""

# Generated at 2022-06-12 04:17:06.184048
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer."""
    from ..utils.source import source_to_ast

    # Arrange
    node = source_to_ast('''
        class Cls:
            def method(self):
                super()
    ''')
    sut = SuperWithoutArgumentsTransformer()

    # Act
    result = sut.visit(node)

    # Assert
    assert isinstance(result.body[0].body[0].body[0].args[0], ast.Name)
    assert result.body[0].body[0].body[0].args[0].id == 'Cls'
    assert isinstance(result.body[0].body[0].body[0].args[1], ast.Name)

# Generated at 2022-06-12 04:17:07.238823
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:12.398850
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.tree import assert_tree
    code = '''\
    class Klass(object):
        def method(self):
            super()
            return super()
    '''
    expected_code = '''\
    class Klass(object):
        def method(self):
            super(Klass, self)
            return super(Klass, self)
    '''
    assert_tree(SuperWithoutArgumentsTransformer,code,expected_code)

# Generated at 2022-06-12 04:17:20.379395
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from astunparse import unparse
    from ..utils.helpers import is_same_src

    node = source_to_nodes("""
    class Cls:
        def method(self):
            super()
    """)[1].body[0]

    assert isinstance(node, ast.ClassDef)
    assert len(node.body) == 1
    assert isinstance(node.body[0], ast.FunctionDef)
    assert isinstance(node.body[0].body[0], ast.Expr)
    assert isinstance(node.body[0].body[0].value, ast.Call)
    assert isinstance(node.body[0].body[0].value.func, ast.Name)

# Generated at 2022-06-12 04:17:40.842869
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # super()
    t = ast.parse('super()', mode='exec')
    t = SuperWithoutArgumentsTransformer(t).visit(t)

    assert(t)
    assert(isinstance(t, ast.Module))
    assert(len(t.body) == 1)
    assert(isinstance(t.body[0], ast.Expr))
    assert(isinstance(t.body[0].value, ast.Call))

    call = t.body[0].value
    assert(isinstance(call.func, ast.Name))
    assert(call.func.id == 'super')
    assert(len(call.args) == 2)
    assert(isinstance(call.args[0], ast.Name))
    assert(call.args[0].id == 'NoneType')

# Generated at 2022-06-12 04:17:51.033386
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Input
    node_name = ast.Name(id='super', ctx=ast.Load())
    node_call = ast.Call(func=node_name, args=[], keywords=[], starargs=None, kwargs=None)
    node_assign = ast.Assign(targets=[ast.Name(id='x', ctx=ast.Store())], value=node_call)
    node_assign.lineno = 1
    node_assign.col_offset = 7

    # Expected output
    expected_node_name_0 = ast.Name(id='super', ctx=ast.Load())
    expected_node_name_1 = ast.Name(id='Cls', ctx=ast.Load())

# Generated at 2022-06-12 04:17:52.064303
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:53.901461
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from astmonkey import transformers


# Generated at 2022-06-12 04:18:01.695874
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    print('\n=== test_SuperWithoutArgumentsTransformer_visit_Call() ===')

    import astor

    code = """
    class Cls:
        def method(self):
            super()
    """
    expected_code = """
    class Cls:
        def method(self):
            super(Cls, self)
    """
    tree = ast.parse(code)  # type: ast.Module

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    print('ORIGINAL:\n%s' % astor.to_source(tree))
    print('EXPECTED:\n%s' % astor.to_source(ast.parse(expected_code)))

    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-12 04:18:12.896153
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('''
        class MySuper:
            def __init__(self):
                super()
    ''')
    
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == '''
        class MySuper:
            def __init__(self):
                super(MySuper, self)
    '''

    tree = ast.parse('''
        class MySuper:
            @staticmethod
            def my_method():
                super()
    ''')
    
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == '''
        class MySuper:
            @staticmethod
            def my_method():
                super(MySuper, cls)
    '''

# Generated at 2022-06-12 04:18:18.501893
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    module = ast.parse('super()')
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(module)
    result = ast.dump(module)
    assert result == 'Module(body=[Expr(value=Call(func=Name(id="super", ctx=Load()), args=[Name(id="Cls", ctx=Load()), Name(id="self", ctx=Load())], keywords=[], starargs=None, kwargs=None))])'

# Generated at 2022-06-12 04:18:23.745737
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class Test:
        def __init__(self):
            super()
    """
    expected_output = """
    class Test:
        def __init__(self):
            super(Test, self)
    """
    tree = ast.parse(input)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    actual_output = astor.to_source(tree).strip()
    assert actual_output == expected_output

# Generated at 2022-06-12 04:18:29.021469
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')

    class ImInAClass():
        def im_in_a_class(self):
            return super()

    transpiled = ast.dump(SuperWithoutArgumentsTransformer(node, ImInAClass).visit(node))
    assert transpiled == "Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), args=[Name(id='ImInAClass', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-12 04:18:29.573589
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:40.310093
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:45.658265
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    import os.path as path
    sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))

    from utils.helpers import generate_python_ast
    from utils.source_code_inserter import SourceCodeInserter
    from transformers.super_without_arguments_transformer import SuperWithoutArgumentsTransformer


# Generated at 2022-06-12 04:18:52.338014
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    node = ast.parse("super()").body[0]

    class TestSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):

        def _replace_super_args(self, node: ast.Call) -> None:
            assert node.args == []

        def ____visit_Call(self, node: ast.Call) -> ast.Call:
            assert node.func.id == 'super'

    TestSuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-12 04:18:53.446188
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..builder import build_module_ast


# Generated at 2022-06-12 04:18:58.741758
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    from .util import should_transform, run_transform_test
    input = """
            class Foo(object):
                def __init__(self):
                    super()
                    super(Foo)
                    """
    want = """
            class Foo(object):
                def __init__(self):
                    super(Foo, self)
                    super(Foo)
                    """
    run_transform_test(SuperWithoutArgumentsTransformer, dedent(input), dedent(want))



# Generated at 2022-06-12 04:19:08.804542
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast
    import textwrap
    test_code = textwrap.dedent("""
    class A:
        def f(self):
            super()
    """)
    expected_code = textwrap.dedent("""
    class A:
        def f(self):
            super(A, self)
    """)
    node = get_ast(test_code)
    SuperWithoutArgumentsTransformer().visit(node)
    assert ast.dump(node) == ast.dump(get_ast(expected_code))
    test_code = textwrap.dedent("""
    def f(self):
        super()
    """)
    expected_code = textwrap.dedent("""
    def f(self):
        super(Cls, self)
    """)
    node = get_ast

# Generated at 2022-06-12 04:19:12.123725
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    expected = """super(Cls, self)"""
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert expected == astor.to_source(tree)

# Generated at 2022-06-12 04:19:21.580326
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .utils import should_transform_equal

    should_transform_equal(SuperWithoutArgumentsTransformer, """
    class Cls:
        def fn(self):
            super()
    """, """
    class Cls:
        def fn(self):
            super(Cls, self)
    """)

    should_transform_equal(SuperWithoutArgumentsTransformer, """
    class Cls:
        def fn(self, *args, **kwargs):
            super()
    """, """
    class Cls:
        def fn(self, *args, **kwargs):
            super(Cls, self)
    """)


# Generated at 2022-06-12 04:19:25.219938
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing the constructors of SuperWithoutArgumentsTransformer class"""
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree=tree)
    assert tree._changed is False



# Generated at 2022-06-12 04:19:28.030001
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    assert 'super(Cls, self)' in ast.dump(node)

# Generated at 2022-06-12 04:19:51.087872
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from typed_ast import ast3
    from ..utils.source import source_to_node

    code = """
a1 = super()
"""
    target = """
a1 = super(__dunder__Cls, self)
"""

    tree = source_to_node(code)
    visitor = SuperWithoutArgumentsTransformer(tree)
    visitor.visit(tree)
    assert astor.to_source(tree) == target

    code = """
a1 = super()
"""
    target = """
a1 = super(__dunder__Cls, cls)
"""

    tree = source_to_node(code)
    visitor = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-12 04:19:52.558278
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_node


# Generated at 2022-06-12 04:19:59.300739
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import inspect

    code = inspect.cleandoc('''
    class Foo():
        def __init__(self):
            super()
    ''')

    expected_code = inspect.cleandoc('''
    class Foo():
        def __init__(self):
            super(Foo, self)
    ''')

    expected_ast = ast.parse(expected_code)
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)  # type: ignore
    ast.fix_missing_locations(tree)

    assert ast.dump(tree) == ast.dump(expected_ast)

# Generated at 2022-06-12 04:19:59.813911
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-12 04:20:02.655184
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "super()"
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    exec(compile(tree, "<test>", "exec"))

# Generated at 2022-06-12 04:20:08.393855
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''class A:
    def __init__(self):
        super().__init__()'''
    root = ast.parse(code)  # type: ignore
    target = root.body[0].body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer(root)
    transformer.visit(root)
    assert target.args[0].id == 'A'
    assert target.args[1].id == 'self'

# Generated at 2022-06-12 04:20:09.855614
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(node)
    return node

# Generated at 2022-06-12 04:20:11.186008
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse


# Generated at 2022-06-12 04:20:21.235231
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:24.141251
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..transpile import TranspileVisitor

    tree = ast.parse('super()')
    visitor = TranspileVisitor()
    visitor.visit(tree)
    assert str(tree) == "super(__module__.__qualname__, self)"

# Generated at 2022-06-12 04:20:38.799530
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer


# Generated at 2022-06-12 04:20:39.562764
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:40.903354
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    

# Generated at 2022-06-12 04:20:41.566624
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:49.324662
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    if len(super()):
        j = super()
    """

    tree = ast.parse(code)
    assert len(ast.walk(tree)) == 9
    assert len(list(ast.iter_child_nodes(tree))) == 8

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert len(ast.walk(tree)) == 9
    assert len(list(ast.iter_child_nodes(tree))) == 9

    calls = list(ast.walk(tree))[-2:]
    assert isinstance(calls[0], ast.Call)
    assert isinstance(calls[1], ast.Call)

    assert len(calls[0].args) == 2
    assert len(calls[1].args) == 2

# Generated at 2022-06-12 04:20:57.250943
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    from ..utils.testing import assert_transform
    assert_transform(
        SuperWithoutArgumentsTransformer,
        'super()',
        """
        class C:
            def f(self):
                super(C, self)
            @classmethod
            def g(cls):
                super(C, cls)
        """
    )
    assert_transform(
        SuperWithoutArgumentsTransformer,
        """
        class C:
            def f(self):
                super()
            @classmethod
            def g(cls):
                super()
        """,
        """
        class C:
            def f(self):
                super(C, self)
            @classmethod
            def g(cls):
                super(C, cls)
        """
    )

    assert_transform

# Generated at 2022-06-12 04:20:58.021145
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast


# Generated at 2022-06-12 04:21:02.041356
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def f():
            super()
    '''

    # Run the transformer
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree=tree)
    transformer.run()
    tr_code = transformer.to_source()

    # Check the results
    assert 'super(A, f)' in tr_code

# Generated at 2022-06-12 04:21:09.274337
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    source = "class Test():\n    def test(self):\n        super()"
    tree = ast.parse(source)
    tree = transformer.visit(tree)
    print(astor.to_source(tree))
    expr = tree.body[0].body[0].body[0]
    assert isinstance(expr, ast.Expr)
    assert isinstance(expr.value, ast.Call)
    names = [arg.id for arg in expr.value.args]
    assert names == ['Test', 'self']

# Generated at 2022-06-12 04:21:10.567019
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Print function
    expected_output = {}

# Generated at 2022-06-12 04:21:52.067975
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    """
    expected = """
    class A:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert astor.to_source(tree) == expected



# Generated at 2022-06-12 04:21:54.642481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""class A:
    def __init__(self):
        c = super() 
   
    def x(self):
        c = super()""")

    cls = SuperWithoutArgumentsTransformer()
    tree = cls.visit(tree)

# Generated at 2022-06-12 04:22:03.549696
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as ast
    from ..utils.node_utils import dump_ast

    transformer = SuperWithoutArgumentsTransformer('example.py')
    # func(super())

# Generated at 2022-06-12 04:22:05.014120
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that the setup_class decorator is created successfully with a decorator
    """

# Generated at 2022-06-12 04:22:08.883327
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import tests
    from .. import ast_transforms
    from ..utils.tree import parse_tree

    t = tests.get_test_data()[7][0]
    tree = parse_tree(t)
    ast_transforms.SuperWithoutArgumentsTransformer(tree).run()
    assert str(tree) == tests.get_test_data()[7][1]

# Generated at 2022-06-12 04:22:11.623457
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    node = ast.parse(
        '''class Foo(object):
    def bar(self):
        super()
    '''
    )
    SuperWithoutArgumentsTransformer().visit(node)
    exec(compile(node, "<ast>", "exec"))

# Generated at 2022-06-12 04:22:16.938339
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_before = """class test(object):    
        def test_2(self):
            super()
            super()
    """
    expected_result = """class test(object):    
        def test_2(self):
            super(test, self)
            super(test, self)
    """
    tr = SuperWithoutArgumentsTransformer()
    code = tr.transform(code_before)
    assert code == expected_result

# Generated at 2022-06-12 04:22:18.244115
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer.__name__ == "SuperWithoutArgumentsTransformer"

# Generated at 2022-06-12 04:22:22.572665
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes

    tree = source_to_nodes('''
    super()
    ''')
    node = tree.body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert source_to_nodes('''
    super(__name__, __name__)
    ''') == tree

# Generated at 2022-06-12 04:22:24.145100
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:23:45.570940
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source_code import SourceCode
    from ..utils.helpers import assert_code_equal

# Generated at 2022-06-12 04:23:54.811022
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    from ..utils.source import Source
    from ..utils.helpers import get_ast

    source = Source(dedent("""
    class Entity:
        def __init__(self, name, xy):
            super().__init__(name)
            self.x, self.y = xy
    """))
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    # new_source = Source.from_node(tree)
    # assert new_source.code == dedent("""
    # class Entity:
    #     def __init__(self, name, xy):
    #         super(Entity, self).__init__(name)
    #         self.x, self.y = xy
    # """)

# Generated at 2022-06-12 04:24:03.024763
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    from typed_ast import ast3
    from ..utils.helpers import normalize

    class TestTransformerSuperWithoutArgumentsTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast3.Call):
            return node

    # Should compile super() (no args) to super(cls, cls_or_self)
    node = ast3.parse('super()')
    node = compile(node, __name__, TestTransformerSuperWithoutArgumentsTransformer)
    node = TestTransformerSuperWithoutArgumentsTransformer(target=3.8).visit(node)
    assert normalize(node) == normalize(ast3.parse('super(Cls, self)'))

    # Should compile super() (no args) to super(cls, cls_or_self)

# Generated at 2022-06-12 04:24:03.750945
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:24:05.145525
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from ..utils.helpers import run_transformer

# Generated at 2022-06-12 04:24:05.871293
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:24:14.816937
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test that super() is turned into super(Cls, self)
    code = """
    class Test(object):
        def Test(self):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = compile(tree, '', 'exec')
    exec(result)
    Test.Test(Test())

    # Test that super() is turned into super(Cls, cls)
    code = """
    class Test(object):
        def __init__(cls):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = compile(tree, '', 'exec')
    exec(result)
    Test.__init__(Test())

    # Test that super

# Generated at 2022-06-12 04:24:19.815552
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_utils import print_ast, get_ast

    source = source_to_unicode("""class Foo(object):
    def __init__(self):
        super()""")

    expected = source_to_unicode("""class Foo(object):
    def __init__(self):
        super(Foo, self)""")

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert expected == print_ast(tree)