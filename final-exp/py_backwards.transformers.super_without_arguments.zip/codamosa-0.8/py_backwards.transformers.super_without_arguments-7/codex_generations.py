

# Generated at 2022-06-12 04:14:20.153780
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    from .unpacking import UnpackingTransformer
    tree = compile('class A(object):\n def __init__(self):\n   super()',
        UnpackingTransformer,
        SuperWithoutArgumentsTransformer)
    assert str(tree) == 'class A(object):\n def __init__(self):\n   super(A, self)'



# Generated at 2022-06-12 04:14:29.345724
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_name
    from .__test_helpers__ import TreeChecker

    tr = TreeChecker()
    tr.register_transformer(SuperWithoutArgumentsTransformer)
    result = tr.run('super()')

    assert isinstance(result, ast.Call)
    assert result.args[0].id == 'Cls'
    assert result.args[1].id == 'self'

    result = tr.run('super(Cls, self)')

    assert isinstance(result, ast.Call)
    assert result.args[0].id == 'Cls'
    assert result.args[1].id == 'self'

# Generated at 2022-06-12 04:14:37.915600
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    class MyVisitor(ast.NodeVisitor):
        def __init__(self):
            self.code = inspect.cleandoc(
                """
                class A:
                    def a(self):
                        super()
                """)
            self.module = ast.parse(self.code)
            self.expected_code = inspect.cleandoc(
                """
                class A:
                    def a(self):
                        super(A, self)
                """)
            self.expected_module = ast.parse(self.expected_code)

        def run(self):
            self.tree_changed = False
            self.transformer = SuperWithoutArgumentsTransformer(self.module)
            self.new_module = self.transformer.visit(self.module)
            return self.new_module


# Generated at 2022-06-12 04:14:47.901748
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import setup_transformers, restore_transformers
    from typed_ast.ast3 import parse
    from .. import utils

    cls = '''
        class Foo:
            def bar(self):
                super()
    '''

    cls = parse(cls)
    setup_transformers()
    utils.apply_transformer(cls, SuperWithoutArgumentsTransformer)
    restore_transformers()
    assert isinstance(cls.body[0].body[0].body[0], ast.Expr)
    assert isinstance(cls.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(cls.body[0].body[0].body[0].value.func, ast.Name)
    assert cls.body[0].body[0].body

# Generated at 2022-06-12 04:14:57.497404
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert(do_test_for_class(SuperWithoutArgumentsTransformer, 
            """
            class Example:
                def __init__(self):
                    super(Example, self)
            """
            , """
            class Example:
                def __init__(self):
                    super()
            """).failed)

    assert(do_test_for_class(SuperWithoutArgumentsTransformer, 
            """
            class Example:
                def __init__():
                    super(Example, self)
            """
            , """
            class Example:
                def __init__():
                    super()
            """).failed)


# Generated at 2022-06-12 04:15:00.510570
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)
    assert str(tree) == 'super(inner, self)' or str(tree) == 'super(inner, cls)'
    assert transformer.changed == True

# Generated at 2022-06-12 04:15:10.297845
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..target import Target
    from ..utils.helpers import get_code
    from ..utils.ast_compare import node_equals, ast_equals

    # No super() calls in tree
    t = """
        if True:
            print("hi")
    """
    y = """
        if True:
            print("hi")
    """
    t = ast.parse(t, mode='exec')
    y = ast.parse(y, mode='exec')
    SuperWithoutArgumentsTransformer(t, Target('2.7')).visit(t)
    assert ast_equals(t, y)

    # super() called in class outside of any method
    t = """
        class Foo:
            super()
    """

# Generated at 2022-06-12 04:15:17.176502
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Given
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    instance = SuperWithoutArgumentsTransformer()

    # When
    instance.visit_Call(node)

    # Then
    assert instance._tree_changed
    assert len(node.args) == 2
    assert isinstance(node.args[0], ast.Name)
    assert isinstance(node.args[1], ast.Name)


# Generated at 2022-06-12 04:15:24.477950
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import textwrap, ast

    code = textwrap.dedent('''
    class C():
        def __init__(self):
            super()
    ''')

    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit()

    fixed_code = textwrap.dedent('''
    class C():
        def __init__(self):
            super(C, self)
    ''')

    fixed_tree = ast.parse(fixed_code)
    assert ast.dump(fixed_tree) == ast.dump(tree)


# Generated at 2022-06-12 04:15:26.916400
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import test_utils
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:15:30.302312
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:33.093770
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # pylint: disable=import-error
    from typed_ast import ast3 as ast
    from .. import Path
    import astor

    # pylint: disable=no-member

# Generated at 2022-06-12 04:15:33.677778
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:40.617540
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(t)
    assert ast.dump(t) == "Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-12 04:15:46.670431
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast_to_str

    t = """
    class C(object):
        def f(self):
            return super()
    """

    tree = ast.parse(t)
    tr = SuperWithoutArgumentsTransformer(tree)
    tr.visit(tree)

# Generated at 2022-06-12 04:15:49.050671
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_astunparse
    from .base import BaseNodeTransformerTest
    from ..utils.helpers import build_ast


# Generated at 2022-06-12 04:15:51.508794
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Arrange
    from ..utils.source import Source
    from ..transpiler.transpile import Transpiler

# Generated at 2022-06-12 04:16:00.668619
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    res = compile(tree, '', 'exec')
    cls = res.co_names.index("A")
    func = res.co_names.index("__init__")

# Generated at 2022-06-12 04:16:05.497025
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    c = """class Foo(object):
    def __init__(self):
        super()
"""
    c = ast.parse(c)
    m = SuperWithoutArgumentsTransformer(c, [])
    m.visit(c)
    assert str(c) == """class Foo(object):
    def __init__(self):
        super(Foo, self)"""

# Generated at 2022-06-12 04:16:09.027851
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    code = "super()"
    expected_code = "super(Cls, self)"
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert expected_code == astor.to_source(tree).strip()

# Generated at 2022-06-12 04:16:20.519551
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_node as stn

    source = """
        class A:
            def __init__(self):
                super()
                
        class B:
            def __init__(self):
                super(B, self)
                
        class C:
            def __init__(self):
                super(B, B)
                
        class D:
            def __init__(self):
                super(B, self).__init__()
                
        class E:
            def __init__(self):
                super().__init__()
    """

    tree = stn(source, __name__)
    node = tree.body[0].body[0]
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)

# Generated at 2022-06-12 04:16:24.636484
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = SuperWithoutArgumentsTransformer()
    node = ast.parse('super()').body[0]
    node = s.visit(node)
    assert_equal(node.args[0].id, 'Cls')
    assert_true(isinstance(node.args[1], ast.Name))


# Generated at 2022-06-12 04:16:33.360153
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test for available for Python 2.7
    assert SuperWithoutArgumentsTransformer.verify(2, 7)
    assert not SuperWithoutArgumentsTransformer.verify(3, 7)

    # Test the transformation on Python 3.0 up, which should not do any transformation
    tree = ast.parse('super()')
    node = get_node(tree, ast.Call)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)

    assert not transformer.tree_changed()

    # Transform super() in method of class Foo

# Generated at 2022-06-12 04:16:34.365652
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:45.603685
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_source
    from .inject_self import InjectSelfTransformer
    from .. import settings

    source = (
        'class Test:\n'
        '    def __init__(self):\n'
        '        super()\n'
        '        super()\n'
        '    def func(self):\n'
        '        super()\n'
        '        super()\n'
        '        super()\n'
        '        return\n'
    )

    tree = ast_from_source(source)
    tree = InjectSelfTransformer().visit(tree)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    result = source_to_unicode(tree)



# Generated at 2022-06-12 04:16:51.391143
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_tst_data_abspath
    from ..utils.tree import compile_and_get_root_node
    from ..utils.visitor import TreeNodeVisitor

    tree = compile_and_get_root_node(get_tst_data_abspath('super_no_arguments.py'))
    visitor = TreeNodeVisitor(tree)

# Generated at 2022-06-12 04:16:58.603576
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    class Foo():
        pass

    class Bar(Foo):
        def a(self):
            super().a()
            super.a()

        def b(self):
            super().b()
            super.b()

        @classmethod
        def c(cls):
            super().c()
            super.c()

        @staticmethod
        def d():
            super().d()
            super.d()

    class Baz(Bar):
        def d(self):
            super().d()
            super.d()


# Generated at 2022-06-12 04:17:01.402104
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import ast_transformer

    tr = ast_transformer.transformer_from_cls(SuperWithoutArgumentsTransformer)


# Generated at 2022-06-12 04:17:02.111389
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-12 04:17:11.868950
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    tree = ast.parse('''
    class TestClass:
        def test_func(self):
            super()
        ''')

    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)
    assert tree != transformer.tree

    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)
    assert tree == transformer.tree

    foo_func_name = tree.body[0].body[0].body[0].args[0].id
    assert foo_func_name == 'foo_func'

    tree = ast.parse('''
    class TestClass:
        def foo_func(self):
            super()
        ''')

    transformer = SuperWithoutArgumentsTransformer(tree)
    tree

# Generated at 2022-06-12 04:17:21.852053
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

    module: ast.Module = source_to_ast.parse(
        """
        class A:
            def __init__(self):
                super()

        class B(A):
            def __init__(self, x):
                super().__init__()

        def f():
            class A:
                def __init__(self):
                    super()

            class B(A):
                def __init__(self, x):
                    super().__init__()
        """
    )

    module = SuperWithoutArgumentsTransformer().visit(module)
    module = ast.fix_missing_locations(module)


# Generated at 2022-06-12 04:17:28.710897
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_source
    import textwrap
    source = textwrap.dedent("""
        class A:
            def __init__(self):
                super()
        """)
    tree = compile_source(source, 2, 7)
    SuperWithoutArgumentsTransformer(tree).run()
    fixed_source = textwrap.dedent("""
        class A:
            def __init__(self):
                super(A, self)
        """)
    assert str(tree) == fixed_source

# Generated at 2022-06-12 04:17:33.372589
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
        tree = ast.parse("""class A():
                                def func(self):
                                    super()
                            """)
        transformer = SuperWithoutArgumentsTransformer(tree)
        transformer.visit(tree)
        source = tree.body[0].body[0].body[0].args[1].id
        assert("self" in source)

# Generated at 2022-06-12 04:17:38.824308
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import ast_helpers
    source = """class A:
    def __init__(self):
        super()"""
    expected = """class A:
    def __init__(self):
        super(A, self)"""
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast_helpers.compile_source(tree) == expected

# Generated at 2022-06-12 04:17:39.633895
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile

# Generated at 2022-06-12 04:17:48.844214
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "super()"
    expected_code = "super(Foo, self)"

    ast_tree = compile(code, '<test>', 'exec', ast.PyCF_ONLY_AST)
    compiler = SuperWithoutArgumentsTransformer(ast_tree)
    transformer = compiler.visit(ast_tree)
    new_ast = type(ast_tree)(transformer)
    new_code = compile(new_ast, '<test>', 'exec', ast.PyCF_ONLY_AST)

    assert ast.dump(new_ast) == ast.dump(ast.parse(expected_code))
    assert ast.dump(ast.parse(code)) == ast.dump(ast.parse(code))

# Generated at 2022-06-12 04:17:49.371688
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:51.220820
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.mangling import encode, decode

# Generated at 2022-06-12 04:17:55.354371
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree=ast.parse('class A: def f(self): super()'))
    transformer.visit(node)
    assert node == ast.parse('super(A, self)')



# Generated at 2022-06-12 04:17:59.222242
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SuperWithoutArgumentsTransformerTest(SuperWithoutArgumentsTransformer):
        def _replace_super_args(self, node):
            return node
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformerTest.run(tree)
    _ = compile(tree, '<test>', 'exec')

# Generated at 2022-06-12 04:18:14.954669
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    node1 = ast.FunctionDef(
        name='f',
        args=ast.arguments(
            args=[ast.arg(arg='self', annotation=None)],
            vararg=None,
            kwonlyargs=[],
            kw_defaults=[],
            kwarg=None,
            defaults=[]
        ),
        body=[
            ast.Return(ast.Call(
                func=ast.Name(id='super'),
                args=[],
                keywords=[]
            ))
        ],
        decorator_list=[],
    )

# Generated at 2022-06-12 04:18:23.779853
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_code
    from .transformer import Transformer

    code = source_to_code('''
        class A:
            def __init__(self):
                super().__init__(a, b)  # super() will be replaced
                super().method()  # super() will be replaced
        ''')

    t = Transformer()
    t.register(SuperWithoutArgumentsTransformer)
    tree = t.visit(ast.parse(code))

    assert ast.dump(tree) == source_to_code('''
        class A(object):
          def __init__(self, a_1, b_2):
            super(A, self).__init__(a, b)
            super(A, self).method()
        ''')

# Generated at 2022-06-12 04:18:28.366323
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()
    code = '''
    class A():
        def __init__(self):
            super()
    '''
    tree = ast.parse(code)
    tree = transformer.visit(tree)
    code_after = compile(tree, "<string>", "exec")
    assert str(code_after) == "exec('\\n    class A():\\n        def __init__(self):\\n            super(A, self)\\n    ')"

# Generated at 2022-06-12 04:18:37.156685
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_node
    from ..fixer_util import untokenize
    from textwrap import dedent

    source = dedent("""
    class Foo():
        def __init__(self):
            super().__init__()
    """)
    tree = source_to_node(source)
    node = tree.body[0].body[0].body[0]

    assert node.func.id == 'super' and not node.args

    # Apply fix
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert node.func.id == 'super' and node.args

    # Check if it works
    assert untokenize(node) == 'super(Foo, self).__init__()'

# Generated at 2022-06-12 04:18:40.812656
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Test(metaclass=ClassWithFuncBody):
        def func(self):
            super()

    assert Test().compiled_func.body[1].value.args[0].id == 'Test'
    assert Test().compiled_func.body[1].value.args[1].id == 'self'

# Generated at 2022-06-12 04:18:45.373958
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_code = '''a = super()'''
    expected_output = '''class A(object):
    def __init__(self):
        a = super(A, self)'''

    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(input_code))

    assert expected_output == t.result()

# Generated at 2022-06-12 04:18:55.445001
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # super().test()
    node = ast.parse("""
super().test()
""")
    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert(ast.dump(tree) == ast.dump(ast.parse("""
super(Cls, cls).test()
""")))

    # super().call_me(1, 2)
    node = ast.parse("""
super().call_me(1, 2)
""")
    tree = SuperWithoutArgumentsTransformer().visit(node)
    assert (ast.dump(tree) == ast.dump(ast.parse("""
super(Cls, cls).call_me(1, 2)
""")))

    # super().call_me(x=1, y=2)

# Generated at 2022-06-12 04:18:59.753034
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Test:
        def __init__(self):
            super()
    """
    t = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(t)
    expected_code = """
    class Test:
        def __init__(self):
            super(Test, self)
    """
    expected_tree = ast.parse(expected_code)
    assert ast.dump(t) == ast.dump(expected_tree)

# Generated at 2022-06-12 04:19:04.881256
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.example import FUNC_WITH_SUPER
    from ..utils.example import FUNC_WITH_SUPER_TRANSFORMED

    tree = ast.parse(FUNC_WITH_SUPER)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == FUNC_WITH_SUPER_TRANSFORMED

# Generated at 2022-06-12 04:19:05.452240
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:16.466603
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:17.009025
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:27.197121
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    module = ast.parse(
        '''
        class Foo(object):
            def __init__(self):
                super()
        '''
    )
    SuperWithoutArgumentsTransformer().visit(module)

# Generated at 2022-06-12 04:19:36.561154
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.testing import assert_code
    from .base import BaseNodeTransformer
    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        target = (2, 7)
        def _replace_super_args(self, node: ast.Call) -> None:
            pass
        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                self._replace_super_args(node)
                self._tree_changed = True
            return self.generic_visit(node)

# Generated at 2022-06-12 04:19:37.208681
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:38.695482
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:42.913796
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'super()'
    expected_code = 'super(Cls, self)'
    
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    actual_code = astor.to_source(tree)

    assert actual_code == expected_code

# Generated at 2022-06-12 04:19:45.014868
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.source import source_to_unicode

# Generated at 2022-06-12 04:19:50.854181
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class MyClass(object):
            def __init__(self):
                super()
    """

    expected = """
        class MyClass(object):
            def __init__(self):
                super(MyClass, self)
    """

    t = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(t)
    assert(compile(t, filename='', mode='exec') == compile(expected, filename='', mode='exec'))

# Generated at 2022-06-12 04:19:59.433160
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..builder.builder import build_module
    from ..builder.compat import get_ast_arg

    code = '''super()'''
    module = build_module(code, (2, 7))
    assert module.body[0].args == [ast.Name(id='C'), ast.Name(id='self')]

    code = '''self.__init__(**kwargs)'''
    module = build_module(code, (2, 7))
    assert isinstance(module.body[0].body[0].value.func, ast.Name)
    assert module.body[0].body[0].value.func.id == 'super'
    assert module.body[0].body[0].value.args == [ast.Name(id='C'), ast.Name(id='self')]

# Generated at 2022-06-12 04:20:28.900744
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast
    import typed_ast.ast3 as typed_ast

    tree = typed_ast.parse("""
        class A:
            def b(self):
                super()
        class B():
            def c(self):
                super()
        def d():
            class E:
                def f(self):
                    super()
        """)
    ty_tree = typed_ast.ast3.parse("""
        class A:
            def b(self):
                super(A, self)
        class B():
            def c(self):
                super(B, self)
        def d():
            class E:
                def f(self):
                    super(E, self)
        """)
    ty_tree = SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-12 04:20:37.590507
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target_transformer = SuperWithoutArgumentsTransformer
        target_version = (2, 7)
        tree_before_transform = ast3.parse("""
        class A:
            def __init__(self):
                super()
            def method(self):
                super()
        class B(A):
            def __init__(self):
                super()
            def method(self):
                super()
        """)

# Generated at 2022-06-12 04:20:41.974837
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import generate_code
    from ..utils.ast_builder import build_ast
    code = "super()"
    tree = build_ast(code)
    node = tree.body[0].value
    t = SuperWithoutArgumentsTransformer("Class", 2)
    new_node = t.visit(node)
    assert generate_code(new_node) == "super(Class, self)"


# Generated at 2022-06-12 04:20:49.980539
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse, dump
    from .transformer_utils import compare_source, transform_source
    import astunparse

    def test_good_case(source: str) -> str:
        tree = parse(source)
        Transformer = SuperWithoutArgumentsTransformer()
        new_tree = Transformer.visit(tree)
        return astunparse.unparse(new_tree)

    source = 'class C: def f(self): super()'
    expected = 'class C: def f(self): super(C, self)'
    compare_source(test_good_case(source), expected)

    source = 'class C: def f(self, a, c): super()'
    expected = 'class C: def f(self, a, c): super(C, self)'

# Generated at 2022-06-12 04:20:50.717530
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:55.490601
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def fn(self):
            super()
    '''
    expected_code = '''
    class A:
        def fn(self):
            super(A, self)
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    actual_code = astor.to_source(tree)
    assert actual_code == expected_code

# Generated at 2022-06-12 04:20:55.975542
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:56.756804
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:03.220050
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
        
        def foo(self):
            super()
    """
    exp_code = """
    class A:
        def __init__(self):
            super(A, self)
        
        def foo(self):
            super(A, self)
    """

    import astor
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer.run_upgrade(tree)
    result_code = astor.to_source(tree).strip()
    assert result_code == exp_code

# Generated at 2022-06-12 04:21:08.694853
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = """
        class X():
            def __init__(self):
                super()

    """
    expect = """
        class X():
            def __init__(self):
                super(X, self)
        """

    node = parse(source)
    result = SuperWithoutArgumentsTransformer(2, 7).visit(node)
    assert astor.to_source(result) == expect


# Generated at 2022-06-12 04:22:11.657107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    import inspect

    class NodeTransformerTester(ast.NodeTransformer):
        def visit_Call(self, node):
            return ast.copy_location(ast.parse('"TESTING"').body[0].value, node)

    source = inspect.getsource(NodeTransformerTester)
    tree = ast.parse(source)

    # Before
    print(astor.to_source(tree))

    # After
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    print(astor.to_source(tree))



# Generated at 2022-06-12 04:22:14.048254
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    from ..utils.source import source_to_node

    # Input code

# Generated at 2022-06-12 04:22:21.772230
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test that SuperWithoutArgumentsTransformer works as expected in every supported version of python"""
    import ast
    import textwrap

    def assert_super_arguments(target_code, expected_code, version):
        tree = ast.parse(textwrap.dedent(target_code))
        SuperWithoutArgumentsTransformer(version=version).visit(tree)
        converted_result = ast.fix_missing_locations(tree)
        expected_result = textwrap.dedent(expected_code)
        assert ast.dump(converted_result) == ast.dump(ast.parse(expected_result))

    # Python 2.7.18

# Generated at 2022-06-12 04:22:23.881023
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:29.032468
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # check super() inside function
    a = (2, 7)
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    assert transformer.visit(tree) == ast.parse('super(Cls, self)')

    # check super() inside class
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(tree)
    assert transformer.visit(tree) == ast.parse('super(Cls, cls)')

# Generated at 2022-06-12 04:22:33.547461
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from .util import round_trip

    class Dummy(ast3.AST):
        _fields = ()

    node = ast3.Call(func=Dummy(), args=[], keywords=[], starargs=None, kwargs=None)
    node = round_trip(node, True)
    assert isinstance(node, ast3.Call) and isinstance(node.func, Dummy) and not node.args  # type: ignore

# Generated at 2022-06-12 04:22:38.215415
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import parse
    from .ast_transformer import ASTTransformer
    from .super_arguments_transformer import SuperArgumentsTransformer
    from .helpers import remove_redundant_parentheses_transformer
    from .functional_default_arguments_transformer import FunctionalDefaultArgumentsTransformer
    """Tests function SuperWithoutArgumentsTransformer.visit_Call.
    Compiles:
        class Cls:
            def __init__(self):
                super()
    To:
        class Cls:
            def __init__(self):
                super(Cls, self)
    """

# Generated at 2022-06-12 04:22:39.006264
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:42.145772
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.run()
    assert ast.dump(node_transformer.tree) == ast.dump(ast.parse('super(Cls, self)'))

# Generated at 2022-06-12 04:22:42.855637
# Unit test for constructor of class SuperWithoutArgumentsTransformer