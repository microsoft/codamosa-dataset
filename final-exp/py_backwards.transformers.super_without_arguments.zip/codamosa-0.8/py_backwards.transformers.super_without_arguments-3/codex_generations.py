

# Generated at 2022-06-12 04:14:19.866553
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:24.818755
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    _transform = SuperWithoutArgumentsTransformer().visit

    _code = """
    class A:
        def __init__(self):
            super()
    """
    _expected = """
    class A:
        def __init__(self):
            super(A, self)
    """
    _tree = ast.parse(_code)
    _transform(_tree)
    assert ast.unparse(_tree) == _expected

# Generated at 2022-06-12 04:14:26.002996
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:27.284713
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_ast, parse


# Generated at 2022-06-12 04:14:31.440573
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    obj = SuperWithoutArgumentsTransformer()
    obj.visit(node)
    assert str(node) == 'super(Cls, self)'


# Generated at 2022-06-12 04:14:38.487195
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def method(self):
            return super()
    """
    tree = ast.parse(code)
    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.visit(tree)
    assert isinstance(tree.body[0].body[0].body.value, ast.Call)
    assert isinstance(tree.body[0].body[0].body.value.func, ast.Name)
    assert isinstance(tree.body[0].body[0].body.value.args, list)
    assert len(tree.body[0].body[0].body.value.args) == 2
    assert isinstance(tree.body[0].body[0].body.value.args[0], ast.Name)

# Generated at 2022-06-12 04:14:39.439243
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:40.570598
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:47.724490
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Cls:
        def __init__(self):
            super()

    code = dedent(inspect.getsource(Cls))
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    new_code = compile(tree, '', 'exec')
    ns = {}
    exec(new_code, ns)

    assert(new_code == dedent('''
        class Cls:
            def __init__(self):
                super(Cls, self)
    '''))

# Generated at 2022-06-12 04:14:52.539720
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from env_2_7 import TESTS_2_7
    from env_3_6 import TESTS_3_6
    from ..transpile_ast import TranspileAST
    from ..utils.helpers import get_python_version

    def execute(version: tuple, test: str) -> str:
        transpiler = TranspileAST(get_python_version(version))
        transpiler.add_transformer(SuperWithoutArgumentsTransformer)
        transpiler.parse_code(test)
        return transpiler.transpile_code()

    for version, test in TESTS_2_7.items():
        if version in TESTS_3_6:
            continue
        result = execute(version, test)
        statement = test.split('\n')[0]

# Generated at 2022-06-12 04:14:59.089641
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Cls:
        def func(self):
            super()
    """
    tree = ast.parse(code)
    fixer = SuperWithoutArgumentsTransformer()
    fixed = fixer.visit(tree)
    assert fixed
    assert 'super(Cls, self)' in astor.to_source(fixed)

# Generated at 2022-06-12 04:15:00.842108
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:08.416276
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse("""
    class A:
        def __init__(self):
            super()
        def f(self):
            super()
    """)
    t = SuperWithoutArgumentsTransformer(node)
    t.run()
    assert ast.dump(node) == ast.dump(ast.parse("""
    class A:
        def __init__(self):
            super(A, self)
        def f(self):
            super(A, self)
    """), include_attributes=True)

# Generated at 2022-06-12 04:15:10.881513
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "super()"
    tree = ast.parse(code)

    tree = SuperWithoutArgumentsTransformer().visit(tree)
    compiled = compile(tree, '', 'exec')
    exec(compiled)

# Generated at 2022-06-12 04:15:17.066013
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    def test_method(foo):
        super().__init__(foo)
                
    tree = ast.parse(inspect.getsource(test_method))
    expected = ast.parse(inspect.getsource(test_method).replace("super(", "super("))
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert ast.dump(expected) == ast.dump(tree)

# Generated at 2022-06-12 04:15:26.109424
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests if SuperWithoutArgumentsTransformer works."""

    tree = """class Test():
            def __init__(self, a):
                super()
                super(Abc)
            def test(self):
                super()
                super(Abc)
    """
    cls_name = 'Test'

    expected_tree = """class Test():
            def __init__(self, a):
                super(Test, self)
                super(Abc)
            def test(self):
                super(Test, self)
                super(Abc)
    """
    
    transpiled_tree = SuperWithoutArgumentsTransformer().visit(ast.parse(tree))
    assert ast.dump(transpiled_tree) == ast.dump(ast.parse(expected_tree))

# Generated at 2022-06-12 04:15:28.547604
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_astunparse
    from ..utils.helpers import get_ast


# Generated at 2022-06-12 04:15:36.892811
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import cast

    class SuperTransformerProgramTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            super().__init__(
                tree=ast.parse('super()'),
                file_name='<test>',
                file_text='super()',
            )

    actual = cast(ast.Call, SuperTransformerProgramTransformer().visit(SuperTransformerProgramTransformer().tree))
    expected = ast.parse('super(Cls, self)').body[0]

    assert ast.dump(actual) == ast.dump(expected)

# Generated at 2022-06-12 04:15:45.483335
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_with_ast import source_to_ast

    code = 'class A: def a(self): super()'

# Generated at 2022-06-12 04:15:55.886217
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .ast_transformer_registry import get_ast_transformer
    import astunparse

    tree = ast.parse(
        'class A:\n'
        '    def __init__(self):\n'
        '        super()\n'
        'class B(A):\n'
        '    def __init__(self, c):\n'
        '        super()\n'
    )

    transformer = get_ast_transformer(SuperWithoutArgumentsTransformer)
    transformer.visit(tree)
    transformer.leave(tree)


# Generated at 2022-06-12 04:16:08.374490
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Forward
    input = """
        class Foo(object):
            def m1(self):
                super()
    """
    expected_output = """
        class Foo(object):
            def m1(self):
                super(Foo, self)
    """
    utils.assert_converted(input, expected_output, SuperWithoutArgumentsTransformer)

    # Backward
    input = """
        class Foo:
            def m1(self):
                super(Foo, self)
    """
    expected_output = """
        class Foo:
            def m1(self):
                super()
    """
    utils.assert_converted(input, expected_output, SuperWithoutArgumentsTransformer,
                           backward=True)

# Generated at 2022-06-12 04:16:09.254984
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor


# Generated at 2022-06-12 04:16:13.360852
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    sample = 'super()'
    expected = 'super(__class__, self)'

    tree = ast.parse(sample)
    transformer = SuperWithoutArgumentsTransformer()
    match = transformer.visit(tree)  # type: ignore

    try:
        codeobj = compile(match, '', 'exec')
        code = codeobj.co_code
        assert expected in code.decode()
    except Exception:
        assert False

# Generated at 2022-06-12 04:16:18.097791
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import transform
    from .. import _pre_parse

    code = "super()"
    tree = _pre_parse(code)
    res = transform(code, tree=tree, tricks=[SuperWithoutArgumentsTransformer])
    assert res == "super(__main__.Cls, self)\n"

# Generated at 2022-06-12 04:16:20.212384
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    a = SuperWithoutArgumentsTransformer()
    node = ast.parse("super()")
    print(node)
    a.visit(node)
    print(node)

# Generated at 2022-06-12 04:16:20.703574
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:29.864699
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_converter import ast_to_source

    tree = ast.parse(source_to_unicode(
        """
            class A:
                def __init__(self):
                    pass
                
                def method(self):
                    return super()
        """))

    node = tree.body[0].body[1].body[0]

    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(tree)

    assert ast_to_source(node) == source_to_unicode(
        """
            return super(A, self)
        """)



# Generated at 2022-06-12 04:16:31.527657
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:37.658613
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def compile_tree(tree):
        return SuperWithoutArgumentsTransformer(tree).result()

    tree = ast.parse('super()')
    result = compile_tree(tree)
    expected = ast.parse('super(Cls, self)')
    assert ast.dump(result) == ast.dump(expected) is not None

    tree = ast.parse('class Cls: pass\nsuper()')
    result = compile_tree(tree)
    expected = ast.parse('class Cls: pass\nsuper(Cls, self)')
    assert ast.dump(result) == ast.dump(expected) is not None

    tree = ast.parse('class Cls: def f(): super()')
    result = compile_tree(tree)
    expected = ast.parse('class Cls: def f(): super(Cls, self)')

# Generated at 2022-06-12 04:16:39.245400
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:16:52.188303
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformation


# Generated at 2022-06-12 04:16:53.645751
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:02.926242
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("Test: SuperWithoutArgumentsTransformer")
    code = """
    class A:
       def __init__(self):
           super()
    class B(A):
       def __init__(self):
           super()
    class C(B):
       def __init__(self):
           super()

    a = A()
    b = B()
    c = C()
    """
    expected_code = """
    class A:
       def __init__(self):
           super(A, self)
    class B(A):
       def __init__(self):
           super(B, self)
    class C(B):
       def __init__(self):
           super(C, self)

    a = A()
    b = B()
    c = C()
    """
    tree = ast

# Generated at 2022-06-12 04:17:09.159272
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .unittest_tools import compile_source
    tree = compile_source(SuperWithoutArgumentsTransformer, '''
        class A(object):
            def f(self):
                super()
                super(A, self)
        ''')

    assert tree == compile_source(BaseNodeTransformer, '''
        class A(object):
            def f(self):
                super(A, self)
                super(A, self)
        ''')

# Generated at 2022-06-12 04:17:10.869688
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast

# Generated at 2022-06-12 04:17:16.935625
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class Bar:
            def __init__(self):
                super()
        '''
    expected_code = '''
        class Bar:
            def __init__(self):
                super(Bar, self)
        '''
    node = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    new_node = transformer.visit(node)
    print(transformer.target)
    gencode = compile(new_node, '', mode='exec')
    exec(gencode, globals())
    assert (code in expected_code)

# Generated at 2022-06-12 04:17:22.784017
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    
    t = SuperWithoutArgumentsTransformer()
    node = ast3.Call(func=ast3.Name(id='super'),
                     args=[],
                     keywords=[])
    node = t.visit_Call(node)
    assert isinstance(node, ast3.Call)
    assert isinstance(node.func, ast3.Name)
    assert node.func.id == 'super'
    assert len(node.args)==2
    assert isinstance(node.args[0], ast3.Name)
    assert node.args[0].id == 'Cls'
    assert isinstance(node.args[1], ast3.Name)
    assert node.args[1].id == 'self'
    

# Generated at 2022-06-12 04:17:30.696874
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast

    code_orig = """
        class Foo(object):
            def method(self):
                super().something()
    """
    code_test = """
        class Foo(object):
            def method(self):
                super(Foo, self).something()
    """
    tree_orig = get_ast(code_orig)
    tree_test = get_ast(code_test)
    try:
        transformer = SuperWithoutArgumentsTransformer()
        transformer.visit(tree_orig)
        print(ast.dump(tree_orig))
        assert ast.dump(tree_orig) == ast.dump(tree_test)
    except Exception as e:
        print(e)
        raise e

# Generated at 2022-06-12 04:17:31.190276
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:34.461421
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():

    from typed_ast import ast3 as ast
    from ..utils import set_pos_info

    # Test case where self is used correctly

# Generated at 2022-06-12 04:17:55.145647
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:17:56.798459
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:17:58.928802
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_code_transformation
    from ...utils.helpers import AstLikeType

    # Simple test case for super()

# Generated at 2022-06-12 04:18:09.080389
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from .test_helpers import assert_source
    from .test_helpers import get_ast_tree
    from .test_helpers import get_source
    from .test_helpers import node_factory

    classNode = ast.ClassDef(name='ClassName', body=[node_factory('Pass')], decorator_list=[], keywords=[])
    functionNode = ast.FunctionDef(name='method_name', args=ast.arguments(args=[ast.arg(arg='self', annotation=None)], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[node_factory('Pass'), node_factory('Pass')], decorator_list=[], returns=None)

# Generated at 2022-06-12 04:18:18.214098
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # old
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    transformer = SuperWithoutArgumentsTransformer(tree=None)
    new = transformer.visit_Call(node)

    assert new == node

    # new
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    transformer = SuperWithoutArgumentsTransformer(tree=None)
    transformer._tree = ast.parse('class A():def a():super()')
    transformer.visit_Call(ast.parse('class A():def a():super()').body[0].body[0].body[0])
    new = transformer.visit_Call(node)

    assert new != node

# Generated at 2022-06-12 04:18:24.807599
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""
    code = """
        class A:
            def m(self):
                super()
        class B(A):
            def m(self):
                pass
    """
    expected_code = """
        class A:
            def m(self):
                super(A, self)
        class B(A):
            def m(self):
                super(B, self)
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-12 04:18:29.522285
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert transformer._tree_changed
    assert len(tree.body[0].value.args) == 2
    assert tree.body[0].value.args[0].id == 'Cls'
    assert tree.body[0].value.args[1].id == 'self'

    tree = ast.parse('super(Foo, cls)')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert not transformer._tree_changed

# Generated at 2022-06-12 04:18:30.469773
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:39.702862
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # type: () -> None
    test_str = '''
    class Cls:
        def __init__(self):
            super().__init__()
    '''
    test_ast = ast.parse(test_str)
    tree_changed = SuperWithoutArgumentsTransformer().visit(test_ast)
    assert tree_changed
    assert isinstance(test_ast.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(test_ast.body[0].body[0].body[0].value.func, ast.Name)
    assert test_ast.body[0].body[0].body[0].value.func.id == 'super'
    assert len(test_ast.body[0].body[0].body[0].value.args) == 2

# Generated at 2022-06-12 04:18:45.414241
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_ast
    from ..utils.unparse import dump_ast
    code = 'super()'
    tree = source_to_ast(code, TranspileOptions(target=(2, 7)).asdict())
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert dump_ast(tree) == 'super(__main__.py_67, self)'


# Generated at 2022-06-12 04:19:32.623821
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..utils.helpers import generate_code

    tree = ast3.parse('a = super()')
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert generate_code(tree) == 'a = super(Cls, self)'

    tree = ast3.parse('def a():\n\tclass A:\n\t\tdef b():\n\t\t\tb = super()')
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert generate_code(tree) == 'def a():\n\tclass A:\n\t\tdef b():\n\t\t\tb = super(A, cls)'

# Generated at 2022-06-12 04:19:40.610008
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_code = """
    class Bar:
        def bar(self):
            pass

    class Foo(Bar):
        def __init__(self):
            super().bar()
    """

    expected_code = """
    class Bar:
        def bar(self):
            pass


    class Foo(Bar):
        def __init__(self):
            super(Foo, self).bar()
    """

    tree = ast.parse(input_code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == expected_code

# Generated at 2022-06-12 04:19:44.628220
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_astunparse import unparse
    tt = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super()')
    tt.visit(tree)
    code = unparse(tree)
    print(code)

# Example of use for class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:49.161712
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    node = ast3.parse("super()")
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert str(node) == "super(Cls, self)\n"
    node = ast3.parse("super(Lol, 'a')")
    node = SuperWithoutArgumentsTransformer().visit(node)
    assert str(node) == "super(Lol, 'a')\n"

# Generated at 2022-06-12 04:19:55.682594
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    ast_tree = ast.parse("super()")
    transf = SuperWithoutArgumentsTransformer(ast_tree)
    transf.visit(ast_tree)
    assert(ast.dump(ast_tree) == "Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[])")


# Generated at 2022-06-12 04:19:56.868168
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # SuperWithoutArgumentsTransformer is tested in class BaseNodeTransformer
    pass

# Generated at 2022-06-12 04:19:59.132101
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import run_transformer_on_single_file
    from ..utils.tree import transform_to_tree

    transformer = SuperWithoutArgumentsTransformer()


# Generated at 2022-06-12 04:20:04.931541
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    source = 'class X:\n    def __init__(self):\n        super()'
    tree = ast.parse(source, mode='exec')

    node_transformer = SuperWithoutArgumentsTransformer(tree)
    node_transformer.visit()
    node_transformer.generic_visit()

    output = astor.to_source(node_transformer.tree)

    assert output == 'class X:\n    def __init__(self):\n        super(X, self)\n'

# Generated at 2022-06-12 04:20:09.122448
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse("assert super()")
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    expected_output = ast.parse("assert super(__class__, self)")
    assert ast.dump(tree) == ast.dump(expected_output)

# Generated at 2022-06-12 04:20:15.933451
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # We only test for 2.7 because it is the only version that does not support super() without arguments and does
    # support super() with class and self as arguments
    from python_minifier.shared.helpers import try_compile_for_target
    from python_minifier.shared.helpers import assert_equal_code_str
    from ast_helpers import dump

    assert_equal_code_str(
        dump(try_compile_for_target(
            'super()',
            target=(2, 7),
        )),
        dump(try_compile_for_target(
            'super(foo, self)',
            target=(2, 7),
        ))
    )


# Generated at 2022-06-12 04:20:59.041641
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class Path(str):
        def __new__(cls, value):
            if not isinstance(value, str):
                value = str(value)
            return str.__new__(cls, value)

        def __init__(self, value):
            return super()
    """

    expected_output = """
    class Path(str):
        def __new__(cls, value):
            if not isinstance(value, str):
                value = str(value)
            return str.__new__(cls, value)

        def __init__(self, value):
            return super(Path, cls)
    """
    module = ast.parse(input)
    SuperWithoutArgumentsTransformer.run_default(module)
    assert ast.dump(module) == expected_output

# Generated at 2022-06-12 04:21:08.652744
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from .base import BaseNodeTransformerTest

    code = '''
    class A:
        def __init__(self):
            super()
            '''
    ast_tree = compile_to_ast(code)
    res = SuperWithoutArgumentsTransformer().visit(ast_tree)
    output = BaseNodeTransformerTest.compile_ast(res, code)
    assert output == 'class A:\n    def __init__(self):\n        super(A, self)\n        \n'

    code = '''
    class A:
        def __init__(self):
            super(A, self)
            '''
    ast_tree = compile_to_ast(code)
    res = SuperWithoutArgumentsTransformer().visit(ast_tree)

# Generated at 2022-06-12 04:21:14.525739
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    class MockTree:
        def __init__(self, tree):
            self.tree = tree

        def insert_import(self, module, name, as_name=None):  # noqa: N802
            pass

    # Example 1
    module = ast.parse("class A(object): def __init__(self): super().__init__()")

    transformer = SuperWithoutArgumentsTransformer(MockTree(module), {}, {}, {})

    assert transformer._replace_super_args(module.body[0].body[0].body[0].func.args[0].func) is None
    assert transformer._tree_changed is True

    assert astor.to_source(module).strip("\n") == "class A(object): def __init__(self): super(A, self).__init__()"

# Generated at 2022-06-12 04:21:16.734289
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    transformer = SuperWithoutArgumentsTransformer()
    node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    transformer._tree = node
    transformer.visit_Call(node)


# Generated at 2022-06-12 04:21:23.486304
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    def test_code(code: str) -> None:
        tree = ast.parse(code)
        SuperWithoutArgumentsTransformer().visit(tree)
        exec(compile(tree, filename="<ast>", mode="exec"))

    code = """
if True:
    class ClsA:
        def __init__(self, b):
            self.a = b

    class ClsB(ClsA):
        def __init__(self):
            super()

    b = ClsB()
    print(b.a)
"""
    test_code(code)


# Generated at 2022-06-12 04:21:26.321276
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from . import TreeInstance

    tree = TreeInstance()
    tree.import_module('typed_ast.ast3')
    tree.import_module('common_utils')


# Generated at 2022-06-12 04:21:31.026752
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Test(object):
            def __init__(self):
                super()
    """
    expected_code = """
        class Test(object):
            def __init__(self):
                super(Test, self)
    """

    t = SuperWithoutArgumentsTransformer()
    t.visit(ast.parse(code))
    actual_code = astor.to_source(t.tree)

    assert actual_code == expected_code

# Generated at 2022-06-12 04:21:31.732298
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:32.958048
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor, typed_ast.ast3 as ast


# Generated at 2022-06-12 04:21:37.124000
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode_python2
    from ..utils.helpers import byte_to_unicode
    from ..visitors.base import BaseNodeTransformer
    from ..visitors.to_target import ToPython27Visitor
    from ..visitors.remove_stars import RemoveStarsVisitor


# Generated at 2022-06-12 04:23:18.507736
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast


# Generated at 2022-06-12 04:23:20.349594
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert_code_equal(
        """
        super()
        """,
        """
        super(Cls, self)
        """
    )



# Generated at 2022-06-12 04:23:22.943331
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer



# Generated at 2022-06-12 04:23:31.930496
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A(object):
        def __init__(self):
            return super()

    class B(A):
        def __init__(self):
            return super()
    """

    # Compile code to AST
    tree = ast.parse(code)

    # Optimize AST
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    # Compile AST to code object
    codeobj = compile(tree, filename="<ast>", mode="exec")

    # Execute code object
    locs = {}
    exec(codeobj, {}, locs)

    # Check if the result is what we expect it to be
    assert 'A' in locs
    assert 'B' in locs
    assert len(locs['A'].__init__.__code__.co_varnames)

# Generated at 2022-06-12 04:23:34.028210
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast27
    assert ast27.parse('super()') == SuperWithoutArgumentsTransformer(ast27.parse('super(Cls, cls)')).visit(ast27.parse('super()'))

# Generated at 2022-06-12 04:23:42.742465
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            super().__init__(None)
            self._tree_changed = False
        def get_tree_changed(self):
            return self._tree_changed
    transformer = TestTransformer()
    node = ast.parse('super()', mode='eval')
    transformer.visit(node)
    transformer.generic_visit(node)
    node = ast.parse('super(Cls, self)', mode='eval')
    transformer.visit(node)
    transformer.generic_visit(node)
    node = ast.parse('super(Cls, cls)', mode='eval')
    transformer.visit(node)
    transformer.generic_visit(node)

# Generated at 2022-06-12 04:23:46.510195
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
super()
    """
    expected_code = """
super(Cls, self)
    """
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert ast.dump(tree) == expected_code 


# Generated at 2022-06-12 04:23:55.177481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from astor.code_gen import to_source
    from ..compiler import Compiler

    test = '''
    class Parent:
        def __init__(self):
            self.x = 1
            
    class Child(Parent):
        def __init__(self):
            super()
    '''
    tree = ast3.parse(test)
    compiler = Compiler(tree)
    result = compiler.compile()
    expected = "class Parent:\n    def __init__(self):\n        self.x = 1\n\n\nclass Child(Parent):\n    def __init__(self):\n        super(Child, self)\n"
    assert expected == to_source(result)

# Generated at 2022-06-12 04:23:55.939941
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    

# Generated at 2022-06-12 04:23:59.259322
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    try:
        t = ast.parse("super()")
    except:
        t = ast.parse("super()", mode='eval')

    t = SuperWithoutArgumentsTransformer().visit(t)
    print(astor.to_source(t))