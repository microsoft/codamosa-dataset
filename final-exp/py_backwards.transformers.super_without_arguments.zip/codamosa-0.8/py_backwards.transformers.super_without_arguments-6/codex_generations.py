

# Generated at 2022-06-12 04:14:25.463600
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super()')
    t.visit(tree)
    assert ast.dump(tree) == "Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-12 04:14:31.103248
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transpiler = SuperWithoutArgumentsTransformer()

    def test(code_from: str, code_to: str):
        tree = ast.parse(code_from)
        transpiler.visit(tree)
        assert ast.dump(tree) == ast.dump(ast.parse(code_to))


# Generated at 2022-06-12 04:14:38.364072
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .test_util import round_trip, dump, round_trip_dump
    tree = ast.parse("super()")
    node = tree.body[0]
    node = SuperWithoutArgumentsTransformer(tree).visit(node)
    dump_result = dump(node)
    expected_dump_result = '[Call(func=Name(id=\'super\', ctx=Load()), args=[Name(id=\'Cls\', ctx=Load()), Name(id=\'self\', ctx=Load())], keywords=[], starargs=None, kwargs=None)]'
    assert expected_dump_result == dump_result
    round_trip_dump_result = round_trip_dump(node)
    assert expected_dump_result == round_trip_dump_result

# Generated at 2022-06-12 04:14:38.918479
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:40.529632
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:41.463223
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse


# Generated at 2022-06-12 04:14:51.267010
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """It should transform `super()` to `super(Class, self)`"""
    from typed_ast import ast3
    import textwrap

    snippet = textwrap.dedent(r'''
    class Foo:
        def func(self):
            super()
    ''')
    tree = ast3.parse(snippet)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert len(tree.body) == 1
    cls: ast3.ClassDef = tree.body[0]
    func = cls.body[0]

    assert transformer.tree_changed
    assert isinstance(func.body[0], ast3.Expr)

    expr: ast3.Expr = func.body[0]
    assert isinstance(expr.value, ast3.Call)


# Generated at 2022-06-12 04:14:53.303457
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..utils.analyzer import DependencyAnalyzer


# Generated at 2022-06-12 04:14:54.792600
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:59.900266
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    t = ast.parse("super()")
    n = t.body[0]
    n = SuperWithoutArgumentsTransformer().visit(n)
    assert isinstance(n, ast.Call)
    assert isinstance(n.func, ast.Name)
    assert n.func.id == "super"
    assert len(n.args) == 2
    assert isinstance(n.args[0], ast.Name)
    assert isinstance(n.args[1], ast.Name)

# Generated at 2022-06-12 04:15:11.303949
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing function for class SuperWithoutArgumentsTransformer."""
    from ..parser import Parser

    parser = Parser()

    input_string = """
    class A:
        def __init__(self):
            super()
    """

    print('INPUT CODE:')
    print(input_string)

    module = parser.parse(input_string)

    # print('MODULE:')
    # print(module)

    assert module is not None, 'Parsing should be successful.'

    # print('MODULE STR:')
    # print(ast.dump(module))

    transformer = SuperWithoutArgumentsTransformer(module)
    module = transformer.process()

    # print('OUTPUT CODE:')
    # print(ast.dump(module))


# Generated at 2022-06-12 04:15:20.549024
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import module, ClassDef, FunctionDef, Assign, Name, Lt, For, Num, Print, Super, Expr,  Break, Pass
    from ..transpile import transpile


# Generated at 2022-06-12 04:15:29.388912
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from python_modernize.fixer_util import NodeTransformerWithContext

    code = """\
    class Foo:
        def __init__(self):
            super()

    class Bar(Foo):
        pass
    """
    tree = ast.parse(code)
    ctx = NodeTransformerWithContext({'tree': tree, 'aux': None})
    actual = SuperWithoutArgumentsTransformer(ctx).visit(tree)
    expected = """\
    class Foo:
        def __init__(self):
            super(Foo, self)

    class Bar(Foo):
        pass
    """
    assert astor.to_source(actual).strip() == expected

# Generated at 2022-06-12 04:15:41.392210
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from .tests_transpile.util import transpile
    from .base import BaseNodeTransformer
    from .context import Context
    import sys

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
             
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-12 04:15:42.537459
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:15:46.126535
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    module = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer()
    new_module = transformer.visit(module)
    code = astor.to_source(new_module)
    res = code
    assert res.strip() == "super(__module__, self)"

# Generated at 2022-06-12 04:15:56.468379
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_node
    from .. import compile_source
    from .rewrite_attribute import AttributeToGetItemTransformer

    source_1 = """
    class Foo:
        def __init__(self):
            super()
            """

    source_2 = """
    class Foo:
        def __init__(self):
            super(Foo, self)
            """

    tree_1 = compile_source(source_1, '<string>', transformer=SuperWithoutArgumentsTransformer)
    tree_2 = compile_source(source_2, '<string>')
    assert AttributeToGetItemTransformer.compare_trees(tree_1, tree_2)


# Generated at 2022-06-12 04:15:58.310049
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ..transformer import Transformer


# Generated at 2022-06-12 04:16:02.058984
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils import compile_source
    from ..context import Context
    from ..python_versions import (
        PY_VERSION,
        PY_27,
    )


# Generated at 2022-06-12 04:16:05.950137
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer().visit(tree)
    super_node = tree.body[0].value
    assert isinstance(super_node, ast.Call)
    assert super_node.args[0].id == 'Cls'
    assert super_node.args[1].id == 'self'

# Generated at 2022-06-12 04:16:22.521944
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = inspect.cleandoc(
        '''
        class Test:
            def __init__(self):
                super()
        ''')
    from typed_ast import ast3
    module: ast3.Module = ast3.parse(code)
    module = SuperWithoutArgumentsTransformer().visit(module)

    assert code != ast3.unparse(module)
    assert len(list(ast3.walk(module))), 9 == len(list(ast3.walk(module)))
    assert isinstance(module.body[0].body[0].body[0], ast3.Expr)
    assert isinstance(module.body[0].body[0].body[0].value, ast3.Call)

# Generated at 2022-06-12 04:16:26.388150
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()", 'Test', 'exec')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    assert tree == ast.parse("super(Cls, self)", 'Test', 'exec')

# Generated at 2022-06-12 04:16:27.039247
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:31.933968
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class MyClass:

            def __init__(self):
                super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert "super(MyClass, self)" in ast.dump(tree)

# Generated at 2022-06-12 04:16:33.394153
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    transformer = SuperWithoutArgumentsTransformer(None)

# Generated at 2022-06-12 04:16:44.682510
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from utils.test_utils import find_test_files
    from inspect import cleandoc
    from typed_ast import ast3
    from .cst_transforms import CSTTransformer
    from . import remove_type_comments, convert_to_annotated

    pth = os.path.dirname(os.path.abspath(__file__))
    for file in find_test_files(pth):
        tree = ast3.parse(file)
        tree = remove_type_comments(tree)
        tree = convert_to_annotated(tree)
        tree = CSTTransformer().visit(tree)


# Generated at 2022-06-12 04:16:45.557812
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:55.348831
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast

    # from: 
    # def foo(self):
    #   super()
    # to:
    # def foo(self):
    #   super(Cls, self)
    s = """
    class Cls:
      def foo(self):
        super()
    """
    expected = """
    class Cls:
      def foo(self):
        super(Cls, self)
    """
    tree = get_ast(s)
    swat = SuperWithoutArgumentsTransformer(tree)
    swat.run()
    assert expected == swat._writer.as_string()

    # from: 
    # @classmethod
    # def foo(self):
    #   super()
    # to:
    # @classmethod
    # def foo(self):
    #  

# Generated at 2022-06-12 04:16:56.857329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import typed_ast.ast3

# Generated at 2022-06-12 04:17:04.720639
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    """
    def method(self):
        super()
    """
    def init(tree):
        tree.body[0].body[0].value.args = [ast.Name(id='Cls'), ast.Name(id='self')]
        return tree

    nodes = astor.parse_file(__file__)
    nodes = nodes.body
    node = nodes[0].body[0].body[0].value
    SuperWithoutArgumentsTransformer().visit(node)
    astor.to_source(node)
    assert node == init(node), 'not equal'

# Generated at 2022-06-12 04:17:28.533291
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("super()")
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)
    assert isinstance(tree.body[0].value, ast.Call)
    assert isinstance(tree.body[0].value.func, ast.Name)
    assert isinstance(tree.body[0].value.func.ctx, ast.Load)
    assert tree.body[0].value.func.id == "super"
    assert isinstance(tree.body[0].value.args[0], ast.Name)
    assert isinstance(tree.body[0].value.args[0].ctx, ast.Load)
    assert tree.body[0].value.args[0].id == "Cls"
    assert isinstance(tree.body[0].value.args[1], ast.Name)

# Generated at 2022-06-12 04:17:38.226786
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.helpers import get_ast
    from ..utils.fixtures import (
        super_no_arguments,
        super_no_arguments_expected,
    )
    from astunparse import unparse
    from .base import BaseNodeTransformer

    class Test(BaseNodeTransformer):
        def visit_Call(self, node):
            node.func = ast.Name(id='super_test')
            return self.generic_visit(node)  # type: ignore

    tree = get_ast(super_no_arguments)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    tree = Test().visit(tree)
    expected = get_ast(super_no_arguments_expected)
    assert unparse(tree) == unparse(expected)

# Generated at 2022-06-12 04:17:41.319927
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    node = tree.body[0].value
    assert isinstance(node, ast.Call)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert len(node.args) == 2

# Generated at 2022-06-12 04:17:49.369979
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing constructor of class SuperWithoutArgumentsTransformer."""
    root = ast.parse(dedent(
        '''
        class Foo():
            def __init__(self):
                super()
        '''
    ))
    super_without_arguments = SuperWithoutArgumentsTransformer(ast.parse(
        '''
        class Foo():
            def __init__(self):
                super()
        '''
    ))
    assert super_without_arguments is not None
    new_tree = super_without_arguments.visit(root)
    assert new_tree is not None


# Generated at 2022-06-12 04:17:52.065457
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer(): 
    code = 'super()'
    tr = SuperWithoutArgumentsTransformer()
    tr.process_code(code)

    assert code == 'super(Cls, self)'


# Generated at 2022-06-12 04:17:52.574635
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor


# Generated at 2022-06-12 04:17:56.381041
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .helper_transformers import FunctionDefinitionTransformer

    ast_module = ast.parse(
        'class Class: def func(): print(super())'
    )
    fd_transformer = FunctionDefinitionTransformer()
    swa_transformer = SuperWithoutArgumentsTransformer()

    fd_transformer.visit(ast_module)

    swa_transformer.visit(ast_module)

    assert ast.dump(ast_module) == ast.dump(ast.parse(
        'class Class:\n'
        '    def func():\n'
        '        print(super(Class, func))'
    ))

    assert swa_transformer._tree_changed == True

# Generated at 2022-06-12 04:18:02.367209
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
            class A(list):
                def __init__(self):
                    super()
                    super()
    """
    tree = ast.parse(code)
    refactored_tree = SuperWithoutArgumentsTransformer().visit(tree)
    refactored_code = compile(refactored_tree, filename="", mode="exec")

    assert refactored_code.co_consts[2] == 'A'
    assert refactored_code.co_consts[3] == 'self'
    assert refactored_code.co_consts[4] == 'A'
    assert refactored_code.co_consts[5] == 'self'

# Generated at 2022-06-12 04:18:08.206474
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    mod = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer().visit(mod)
    assert isinstance(tree, ast.AST)
    assert isinstance(tree.body[0].value, ast.Call)
    assert tree.body[0].value.args[0].id == 'Cls'
    assert tree.body[0].value.args[1].id == 'self'


# Generated at 2022-06-12 04:18:11.459224
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import prettify
    from typed_ast import ast3 as ast
    from typed_ast import parse as ast_parse


# Generated at 2022-06-12 04:18:19.433321
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:20.313052
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:21.115937
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:28.539416
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # class Foo(object):
    #     def bar():
    #         super()
    tree = ast.parse(dedent('''\
    class Foo(object):
        def bar():
            super()
    '''))
    SuperWithoutArgumentsTransformer(tree).run()
    assert astunparse(tree).strip() == dedent('''\
    class Foo(object):
        def bar():
            super(Foo, self)
    ''').strip()

    # class Foo(object):
    #     def bar():
    #         super()
    #     def baz():
    #         super()
    tree = ast.parse(dedent('''\
    class Foo(object):
        def bar():
            super()
        def baz():
            super()
    '''))
    SuperWithoutArg

# Generated at 2022-06-12 04:18:33.944858
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from typed_ast import parse

    tree = parse('super()')
    super_transformer = SuperWithoutArgumentsTransformer(tree, {})
    super_transformer.run()
    expected_ast = parse('''
        class Cls:
          def func(self):
            super(Cls, self)
    ''')
    assert ast.dump(expected_ast) == ast.dump(tree)

# Generated at 2022-06-12 04:18:37.556201
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = make_tree("super()")
    assert tree_to_str(tree) == "super()"

    t = SuperWithoutArgumentsTransformer()
    tree = t.visit(tree)
    assert tree_to_str(tree) == "super(Cls, self)"

# Generated at 2022-06-12 04:18:47.083952
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # pylint: disable=import-error,no-name-in-module
    from typed_ast import ast3 as ast
    from .helper import assert_transform, assert_transform_back
    for fn_type in ['func', 'clsmethod', 'staticmethod']:
        if fn_type == 'staticmethod':
            transform_to = 'lambda: super(Cls, None)'
        elif fn_type == 'clsmethod':
            transform_to = 'lambda cls: super(Cls, cls)'
        else:
            transform_to = 'lambda self: super(Cls, self)'

        transform = '''
            class Cls:
                @%s
                def fn():
                    super()
        ''' % fn_type
        assert_transform(transform, transform_to)
        assert_transform_back

# Generated at 2022-06-12 04:18:48.074941
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:57.798910
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast
    import sys
    import collections
    import textwrap

    from typed_ast import ast3 as typed_ast
    from ..utils import tree
    from ..processors import Processor

    tree_orig = typed_ast.parse(textwrap.dedent(
        """
        class Test:
            def __init__(self):
                a = [x for x in super()]
                self.a = super().test()
                super().test().a
        """
    ))

    tree_expected = typed_ast.parse(textwrap.dedent(
        """
        class Test:
            def __init__(self):
                a = [x for x in super(Test, self)]
                self.a = super(Test, self).test()
                super(Test, self).test().a
        """
    ))

    processor_

# Generated at 2022-06-12 04:18:58.786794
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:19:22.113454
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    # Assert that: super() -> super(Cls, self)
    module_ast = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer(module_ast)
    new_module_ast = transformer.visit(module_ast)
    assert isinstance(new_module_ast.body[0], ast.Expr)

    node = new_module_ast.body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)

    node = node.func
    assert node.id == 'super'

    node = node.args
    assert isinstance(node, list)
    assert len(node) == 2

    node = node[0]
    assert isinstance(node, ast.Name)
    assert node.id == 'Cls'

   

# Generated at 2022-06-12 04:19:32.318295
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    class TreeBuilder:
        def __init__(self):
            self._name_counter = 0

        def new_name(self) -> ast.Name:
            self._name_counter += 1
            # Don't use `str(self._name_counter)` for py 2.7 compatibility
            return ast.Name(id=repr(self._name_counter))

        def build(self) -> ast.AST:
            name1 = self.new_name()
            name2 = self.new_name()
            name3 = self.new_name()
            name4 = self.new_name()
        

# Generated at 2022-06-12 04:19:39.319006
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.source_code import PythonSource
    class T(SuperWithoutArgumentsTransformer):
        @property
        def tree(self) -> ast.Module: return PythonSource('''
            class Foo:
                def foo(self):
                    super()
        ''').tree
    assert str(T().tree) == '''
        class Foo:
            def foo(self):
                super(Foo, self)
    '''



# Generated at 2022-06-12 04:19:41.456546
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..testing import assert_code_equal, assert_tree_equal


# Generated at 2022-06-12 04:19:42.737326
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse

# Generated at 2022-06-12 04:19:43.568734
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:53.268343
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast    
    from ..utils import as_tuple
    from ..intrinsic import SuperIntrinsic

    class MockSuperIntrinsic(SuperIntrinsic):
        def __call__(self, cls: str, instance: ast.Name) -> ast.Call:
            return ast.Call(
                func=ast.Name(id=cls), args=[instance], keywords=[], starargs=None, kwargs=None
            )

    source = inspect.cleandoc("""
        class A:
            def __init__(self):
                super().__init__()
    """)

    SuperIntrinsic.set_super_klass(MockSuperIntrinsic)

# Generated at 2022-06-12 04:19:55.864519
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''super()'''
    from .. import compiler
    tree = compiler.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert code != compiler.to_source(tree)

# Generated at 2022-06-12 04:20:02.019414
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # ! TODO
    # def f():
    #     return super()
    #
    # class C:
    #     def f(self):
    #         return super()
    #
    # assert SuperWithoutArgumentsTransformer().visit(ast.parse(inspect.cleandoc(f.__doc__))) == \
    #        ast.parse(inspect.cleandoc(f.__doc__)).body[0].value
    #
    # assert SuperWithoutArgumentsTransformer().visit(ast.parse(inspect.cleandoc(C.f.__doc__))) == \
    #        ast.parse(inspect.cleandoc(C.f.__doc__)).body[0].value.body[0].value

    pass

# Generated at 2022-06-12 04:20:11.370404
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        target = (2, 7)

        def visit_Call(self, node: ast.Call) -> ast.Call:
            if isinstance(node.func, ast.Name) and node.func.id == 'super' and not len(node.args):
                try:
                    func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
                except NodeNotFound:
                    warn('super() outside of function')
                    return node

                try:
                    cls = get_closest_parent_of(self._tree, node, ast.ClassDef)
                except NodeNotFound:
                    warn('super() outside of class')
                    return node

                node.args

# Generated at 2022-06-12 04:20:50.913942
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import ast_to_source
    transformer = SuperWithoutArgumentsTransformer(None)
    source = source_to_unicode("""
    class Cls(object):
        def __init__(self):
            super()
    """)
    expected = source_to_unicode("""
    class Cls(object):
        def __init__(self):
            super(Cls, self)
    """)
    tree = ast.parse(source)
    transformer.visit(tree)
    assert ast_to_source(tree) == expected

# Generated at 2022-06-12 04:20:58.899978
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from ..utils.tree_builder.tree_builder import parse_ast_tree
    from ..utils import ast_transformer_test_helper

    code = """
        class A:
            def __init__(self, xxx):
                self.xxx = xxx
        class B(A):
            def __init__(self, xxx):
                super().__init__(xxx)
        class C:
            def __init__(self, xxx):
                super().__init__()
    """
    lines = code.split('\n')

# Generated at 2022-06-12 04:20:59.692821
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:00.474269
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:10.194388
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests that the SuperWithoutArgumentsTransformer class performs the correct conversion."""
    transformer = SuperWithoutArgumentsTransformer()
    tree = ast.parse('super()')
    ast.fix_missing_locations(tree)
    new_tree = transformer.visit(tree)
    assert ast.dump(tree) != ast.dump(new_tree)

# Generated at 2022-06-12 04:21:15.407446
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        super()
    """
    expected_code = """
        super(Cls, self)
    """
    tree = ast.parse(code)
    trans = SuperWithoutArgumentsTransformer.from_code(tree, 'Cls')
    new_tree = trans.visit(tree)
    code2 = compile(new_tree, '', 'exec')
    assert expected_code in code2

# Generated at 2022-06-12 04:21:18.039273
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Makes sure that the visitor does not return anything."""
    tree = ast.parse('super()')  # type: ignore
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super' not in ast.dump(tree)  # type: ignore

# Generated at 2022-06-12 04:21:20.482651
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    assert compile('''
foo = super()
baz = super()''') == b'''foo = super(Cls, self)
baz = super(Cls, self)'''

# Generated at 2022-06-12 04:21:25.587091
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import transform
    module = ast.parse('''
    class Foo:
        def bar(self):
            return super().baz()

    class Baz:
        def bar(self):
            return super().baz()

    class Qux:
        @staticmethod
        def bar():
            return super().baz()
    ''')
    expected = ast.parse('''
    class Foo:
        def bar(self):
            return super(Foo, self).baz()

    class Baz:
        def bar(self):
            return super(Baz, self).baz()

    class Qux:
        @staticmethod
        def bar():
            return super(Qux, cls).baz()
    ''')
    transform(module, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-12 04:21:33.222944
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.builders import make_call, make_cls_node, make_func_node, make_name_node
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return ast.Call(func=make_name_node('super'), args=[ast.Name(id='Cls'), ast.Name(id='self')], keywords=[])

    code = '''class Cls():
        def func():
            super()'''

    root = ast.parse(code)
    tree = TestTransformer().visit(root)

    assert isinstance(tree.body[0], ast.ClassDef)

# Generated at 2022-06-12 04:22:56.254471
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    
    node = ast.parse(source_to_unicode('''
        class A:
            def __init__(self):
                super()
    '''))

    SuperWithoutArgumentsTransformer().visit(node)
    print(ast.dump(node))

# Generated at 2022-06-12 04:23:04.270107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class SuperWithoutArgumentsTransformerTest(SuperWithoutArgumentsTransformer):
        def _visit_function(self, node: ast.AST) -> None:
            return self.visit_FunctionDef(node)

        def _visit_class(self, node: ast.AST) -> None:
            return self.visit_ClassDef(node)

    tree = ast.parse(
        '\n'.join([
            'def fcn():',
            '    super()',
            '    x()',  # super() with arguments
            'super()',  # super() outside of function
            '',
            'class C:',
            '    super()',  # super() inside class
            '    x()',
            '',
            'super()',  # super() outside of class
            '',
        ])
    )



# Generated at 2022-06-12 04:23:09.660479
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    tree = astor.parse_file("""
    class A:
        def __init__(self):
            self.test = super()
    """)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree).strip() == """
    class A:
        def __init__(self):
            self.test = super(A, self)
    """.strip()

# Generated at 2022-06-12 04:23:17.685120
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import ast, textwrap
    ast_tree = ast.parse(textwrap.dedent(
        '''\
        class A:
            def __init__(self):
                super().__init__()
            def b(self):
                super().c()
        '''
    ))
    SuperWithoutArgumentsTransformer.apply_to_ast(ast_tree)

# Generated at 2022-06-12 04:23:19.285862
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:23:27.488517
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
    class A:
        def __init__(self):
            super()
    '''
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree, None)
    defs = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
    cls = [node for node in tree.body if isinstance(node, ast.ClassDef)][0]
    func = defs[0]
    assert isinstance(func.body[0].value.args[0], ast.Name)
    assert isinstance(func.body[0].value.args[1], ast.Name)
    assert func.body[0].value.args[0].id == cls.name
    assert func.body[0].value.args[1].id == func.args.args

# Generated at 2022-06-12 04:23:30.691276
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..unittest_tools import assert_transformed_ast

    source = 'super()'
    result = 'super(Test, self)'

    assert_transformed_ast(SuperWithoutArgumentsTransformer, source, result)


# Generated at 2022-06-12 04:23:37.033386
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..examples.super_without_args import example_tree

    tree = SuperWithoutArgumentsTransformer().visit(example_tree)

    # The tree should change
    assert SuperWithoutArgumentsTransformer.tree_changed


# Generated at 2022-06-12 04:23:39.617630
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..python_to_python import PythonToPython
    x = '''super()'''
    module = ast.parse(x)
    PythonToPython(module, {}).print()

# Generated at 2022-06-12 04:23:42.859546
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class T: pass
    tree = ast.parse("super()", "<test>", "exec")  # type: ignore
    tree = SuperWithoutArgumentsTransformer(tree, T).visit()

    assert ast.dump(tree) == ast.dump(ast.parse("super(T, cls)", "<test>", "exec"))  # type: ignore