

# Generated at 2022-06-12 04:14:23.733182
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import dump_ast
    

# Generated at 2022-06-12 04:14:26.363237
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3 as ast
    from ..utils.context import Context
    from ..utils.helpers import dump_code


# Generated at 2022-06-12 04:14:36.250792
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class NodeTransformer(ast.NodeTransformer):
        def visit_Call(self, node: ast.Call) -> ast.Call:
            return node

    t = SuperWithoutArgumentsTransformer(NodeTransformer())

    a = ast.Name(id='a', ctx=ast.Load())
    b = ast.Name(id='b', ctx=ast.Load())
    call_node = ast.Call(func=a, args=[b], keywords=[])
    t.visit(call_node)
    assert call_node is not None

    cls = ast.Name(id='Cls', ctx=ast.Load())
    func = ast.Name(id='func', ctx=ast.Load())

# Generated at 2022-06-12 04:14:41.276329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    from .base import BaseNodeTransformerTestCase

    class Test(BaseNodeTransformerTestCase):
        target = SuperWithoutArgumentsTransformer

        def test_super(self):
            tree = ast.parse('super()')
            node = tree.body[0].value
            self.check_equal(node, 'super(Cls, self)')

    Test().test()

# Generated at 2022-06-12 04:14:42.297441
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:51.542277
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_transformed_code, check_visitor_with_code
    transformer = SuperWithoutArgumentsTransformer()
    assert_transformed_code(
        transformer,
        '''
        class C:
            def f(self):
                super()
        ''',
        '''
        class C:
            def f(self):
                super(C, self)
        '''
    )
    check_visitor_with_code(transformer, 'super()', 'super(Cls, self)')
    check_visitor_with_code(transformer, 'super("a")', 'super("a")')
    check_visitor_with_code(transformer, 'super("a", "b")', 'super("a", "b")')

# Generated at 2022-06-12 04:14:53.595093
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import ast2tree


# Generated at 2022-06-12 04:15:01.520567
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from typed_ast.ast3 import parse
    from .. import fixer_util
    from ..fixer_util import Call, Name, Arg
    
    tree = parse("""
    class A(object):
        def __init__(self):
            super()
    """)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast3.Expr)
    assert isinstance(node.value, ast3.Call)

    fixer = SuperWithoutArgumentsTransformer(tree)
    fixer.visit(tree)

    assert isinstance(node.value, ast3.Call)
    assert isinstance(node.value.func, ast3.Name)
    assert node.value.func.id == "super"

# Generated at 2022-06-12 04:15:10.751753
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    class SuperWithoutArgumentsTransformerTestCase(unittest.TestCase):
        def test_super_no_args(self):
            s = """
            class A:
                def hello(self):
                    super()
            """
            expected_result = """
            class A:
                def hello(self):
                    super(A, self)
            """
            tree = ast.parse(s)
            inliner = SuperWithoutArgumentsTransformer()
            inliner.visit(tree)
            result = astor.to_source(tree).strip()
            self.assertEqual(expected_result.strip(), result)

        def test_super_args_no_change(self):
            s = """
            class A:
                def hello(self):
                    super(A, self)
            """
            expected

# Generated at 2022-06-12 04:15:15.418893
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = SuperWithoutArgumentsTransformer()
    new_node = t.visit(ast.parse('super()'))
    assert new_node.body[0].value.args[0].id == 'Cls'
    assert new_node.body[0].value.args[1].id == 'self'

# Generated at 2022-06-12 04:15:18.701792
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:21.746567
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    node = ast.parse("super().__init__()")
    node = SuperWithoutArgumentsTransformer().visit(node)

# Generated at 2022-06-12 04:15:23.827567
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import python_to_python_ast
    from ..utils import python_ast_to_python

# Generated at 2022-06-12 04:15:33.964856
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..visitor import NodeTransformer
    from .base import BaseNodeTransformer
    import unittest

    class TestSuperWithoutArgumentsTransformer(unittest.TestCase):
        def test_super_without_arguments(self):
            a = ast.parse(
                r'''
                class A:
                    def __init__(self):
                        super()
                class B(A):
                    def __init__(self):
                        super()
                '''
            )
            transformer = NodeTransformer()
            transformer.register_transformer(SuperWithoutArgumentsTransformer)
            transformer.visit(a)


# Generated at 2022-06-12 04:15:43.297244
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import textwrap
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_source

    source = textwrap.dedent(u'''\
        class A:
            def f(self):
                return super()
        ''')
    expected = textwrap.dedent(u'''\
        class A:
            def f(self):
                return super(A, self)
        ''')

    tree = source_to_unicode(source)
    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)
    assert_equal_source(expected, tree)

# Generated at 2022-06-12 04:15:51.783734
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import parse, dump
    from . import get_ast

    input_code = '''
    class Foo:
        def __init__(self):
            super()
        def bar(self):
            super()
    '''
    output_code = '''
    class Foo:
        def __init__(self):
            super(Foo, self)
        def bar(self):
            super(Foo, self)
    '''
    tree = parse(input_code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert dump(tree) == output_code
    assert get_ast(input_code) == get_ast(output_code)

# Generated at 2022-06-12 04:15:52.819369
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:53.809913
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:55.569653
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer."""

# Generated at 2022-06-12 04:16:02.937371
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import parse

    def test_compile(code: str, expected: str) -> None:
        node = parse(code)
        SuperWithoutArgumentsTransformer(node).visit(node)
        assert ast.dump(node) == expected

    # warn('super() outside of function')
    test_compile('super()', 'Expr(value=Call(func=Name(id=\'super\', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))')

# Generated at 2022-06-12 04:16:14.135483
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ast_helper import ast_to_object
    from textwrap import dedent
    code = dedent('''
        class Foo:
            bar = super()
        class Bar:
            def __init__(self):
                self.bar = super()
    ''')
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    tree = transformer.visit(tree)
    expected = dedent('''
        class Foo:
            bar = super(Foo, super)
        class Bar:
            def __init__(self):
                self.bar = super(Bar, self)
    ''')
    assert astor.to_source(tree) == expected



# Generated at 2022-06-12 04:16:15.501231
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:16:19.541714
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """super()"""
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert ast.dump(tree) == "Call(func=Name(id='super', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None)"

# Generated at 2022-06-12 04:16:26.348309
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class TestTransformer(SuperWithoutArgumentsTransformer):  # type: ignore
        def _replace_super_args(self, node: ast.Call) -> None:
            assert isinstance(node.args[0], ast.Name)
            assert node.args[0].id == 'Cls'
            assert isinstance(node.args[1], ast.Name)
            assert node.args[1].id == 'self'

    test_obj = TestTransformer()
    test_obj.visit(ast.parse('super()'))

# Generated at 2022-06-12 04:16:28.669871
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer."""


# Generated at 2022-06-12 04:16:29.632019
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:34.935891
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input = """
    class Cls:
        def __init__(self):
            super().__init__()
    """
    expected_output = """
    class Cls:
        def __init__(self):
            super(Cls, self).__init__()
    """
    tree = ast.parse(input)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert astor.to_source(tree) == expected_output

# Generated at 2022-06-12 04:16:39.868757
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import ast_transformer
    import_module = ast_transformer.ImportTransformer.transform(
        """
import sys
""")
    transformer = ast_transformer.ASTTransformer([SuperWithoutArgumentsTransformer, ],
                                                 default_target=3)

# Generated at 2022-06-12 04:16:41.388976
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:42.354849
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:54.112744
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
    Test case for super without arguments in method of class
    """

# Generated at 2022-06-12 04:16:54.738652
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:02.063999
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing import assert_source
    from ..testing import assert_transformed

    tree = assert_source(r"""
    super()
    """)
    assert_transformed(SuperWithoutArgumentsTransformer, tree, r"""
    super(Cls, self)
    """)

    tree = assert_source(r"""
    class Cls:
        def method(self):
            super()
    """)
    assert_transformed(SuperWithoutArgumentsTransformer, tree, r"""
    class Cls:
        def method(self):
            super(Cls, self)
    """)

# Generated at 2022-06-12 04:17:03.014894
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:04.321432
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils import get_ast, compare_ast

# Generated at 2022-06-12 04:17:12.812653
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import Source
    #from ..utils.helpers import print_ast
    #from ..utils.compat import StringIO

    #from typed_ast import ast3 as ast
    #import sys

    #from typed_astunparse import unparse

    #tree = ast.parse("""
    #class Test(object):
    #    def func(self):
    #        super()
    #""")

    #old_stdout = sys.stdout
    #sys.stdout = mystdout = StringIO()

    #print_ast(tree)

    #sys.stdout = old_stdout
    #print(mystdout.getvalue())


# Generated at 2022-06-12 04:17:17.011871
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    code = compile(tree, '', 'exec')

    # The result should be: super(Cls, self)
    glb = {}
    exec(code, glb)
    assert glb['super']().__name__ == 'super'

# Generated at 2022-06-12 04:17:19.329907
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer =  SuperWithoutArgumentsTransformer()
    assert transformer.visit(ast.parse("super()", mode='eval')) == ast.parse("super('Cls', self)", mode='eval')

# Generated at 2022-06-12 04:17:29.453289
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..transpilers.base import NoneTranspiler

    code = """
    class A:
        def __init__(self):
            super()
    """

    tree = ast.parse(code)
    transpiler = NoneTranspiler(tree)
    transformer = SuperWithoutArgumentsTransformer(tree, transpiler)

    assert isinstance(tree.body[0].body[0].body[0], ast.Call)
    assert tree.body[0].body[0].body[0].func.id == 'super'
    assert not len(tree.body[0].body[0].body[0].args)

    transformer.visit(tree)

    assert isinstance(tree.body[0].body[0].body[0], ast.Call)
    assert tree.body

# Generated at 2022-06-12 04:17:39.406475
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from .test_base import BaseTestTransformer, transform_and_compare

    class TestTransformer(
        BaseTestTransformer,
        SuperWithoutArgumentsTransformer
    ):
        pass

    # Test super(A, self) without arguments
    transform_and_compare(
        TestTransformer,
        'class Foo:',
        'class Foo:'
    )

    # Test super(A, cls) without arguments

# Generated at 2022-06-12 04:18:06.870027
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import generate_inner_code
    from ..testing_utils import format_code
    from typed_ast import ast3 as ast

    print(generate_inner_code(
        'SuperWithoutArgumentsTransformer',
        SuperWithoutArgumentsTransformer,
        'SuperWithoutArgumentsTransformer'
    ))

    source = '''
    class Foo:
        def bar(self):
            super()
    '''

    expect = '''
    class Foo:
        def bar(self):
            super(Foo, self)
    '''

    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    result = format_code(tree)
    assert result == expect


# Generated at 2022-06-12 04:18:12.546759
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super()
    
    
    class B(A):
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed == True

# Generated at 2022-06-12 04:18:19.223374
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    new_node = transformer.visit(node)
    expected = ast.parse('super(Cls, self)')
    assert ast.dump(new_node) == ast.dump(expected)

    node = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    new_node = transformer.visit(node)
    expected = ast.parse('super(Cls, self)')
    assert ast.dump(new_node) == ast.dump(expected)

# Generated at 2022-06-12 04:18:22.239506
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import os
    import astunparse
    from ..utils.python_compat import StringIO
    print_stdout = sys.stdout
    stringout = StringIO()
    sys.stdout = stringout


# Generated at 2022-06-12 04:18:27.495821
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ...automata import Automata
    from ...parse_python import parse_python_string
    from ...parsed_python import ParsedPython
    from ...utils import create_cst

    tree = parse_python_string('super().method()')
    parsed_python = ParsedPython(create_cst(tree))
    automata = Automata(parsed_python)
    automata.process()
    automata.compile()
    assert automata._compiled_ast == 'super(Cls, self).method()'

# Generated at 2022-06-12 04:18:30.923054
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import textwrap
    from ..utils.testing import assert_transformation

    text = textwrap.dedent('''\
        class C:
            def __init__(self):
                super()
        ''')
    assert_transformation(SuperWithoutArgumentsTransformer, text, text)

# Generated at 2022-06-12 04:18:32.713141
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:18:42.036739
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import unittest


# Generated at 2022-06-12 04:18:52.587737
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """
        class A:
            def __init__(self):
                super()
        --->
        class A:
            def __init__(self):
                super(A, self)
    """

# Generated at 2022-06-12 04:18:55.093818
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # should be able to compile
    class SuperWithoutArgumentsTransformerTester(SuperWithoutArgumentsTransformer):
        pass
    # should be able to instantiate
    SuperWithoutArgumentsTransformerTester()

# Generated at 2022-06-12 04:19:36.166626
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_ast
    source = 'super()'
    tree = compile_ast(source)
    Transformer = SuperWithoutArgumentsTransformer(tree)
    result = Transformer.visit(tree)
    assert hasattr(result.body[0].value, 'args[1].id')
    assert result.body[0].value.args[1].id == 'self'
    assert result.body[0].value.args[0].id == 'Cls'


# Generated at 2022-06-12 04:19:46.207768
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # test super() in function ->
    # super(Cls, self)
    tree = ast.parse("super()")
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(tree)
    assert ast.dump(tree) == 'FunctionDef(name=None, args=arguments(args=[], vararg=None, kwonlyargs=[], kw_defaults=[], kwarg=None, defaults=[]), body=[Expr(value=Call(func=Name(id=super, ctx=Load()), args=[Name(id=Cls, ctx=Load()), Name(id=self, ctx=Load())], keywords=[], starargs=None, kwargs=None))], decorator_list=[], returns=None)'

    # test super() in class ->
    # super(Cls, cls)


# Generated at 2022-06-12 04:19:47.178878
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:51.677356
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    ast_tree = ast.parse('''
    class A():
        def method(self):
            super()
    ''')
    tree = SuperWithoutArgumentsTransformer()
    tree.visit(ast_tree)

    assert isinstance(ast_tree.body[0].body[0].body[0].value, ast.Call)

# Generated at 2022-06-12 04:19:56.062367
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    cases = [
        ('super()', 'super(__class__, self)'),
        ('x.super()', 'x.super()'),
        ('super(Spam, ham)', 'super(Spam, ham)')
    ]
    tt = TranspileTest(SuperWithoutArgumentsTransformer, cases)
    tt.run_tests()

# Generated at 2022-06-12 04:20:02.537918
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..compile.parse import parse_string
    from ..compile.ast_compiler import compile_ast, CompiledCode
    from ..compile.compile import python_to_pythonjs
    from ..compile.ast_to_js import ASTToJS
    from ..compile.shared import Shared
    p = parse_string("class A():\n  def __init__(self):\n    super()\n")
    tree = p.body[0]
    c = SuperWithoutArgumentsTransformer()
    c.visit(tree)
    result = compile_ast(tree, '<string>')

# Generated at 2022-06-12 04:20:04.295885
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from testing.utils import build_ir
    from ..utils.helpers import generate_code
    from ..utils import tests_state


# Generated at 2022-06-12 04:20:13.327225
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from textwrap import dedent
    from .test_helpers import round_trip

    tree = ast.parse("""
        class A(object):
            def __init__(self):
                super()
    """)
    assert isinstance(tree, ast.Module)
    assert len(tree.body) == 1
    assert isinstance(tree.body[0], ast.ClassDef)
    assert isinstance(tree.body[0].body[0], ast.FunctionDef)
    super_node = tree.body[0].body[0].body[0]
    assert isinstance(super_node, ast.Expr)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformed_tree = transformer.visit(tree)

# Generated at 2022-06-12 04:20:21.496327
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class Base:
        def __init__(self, a):
            pass
        
    class Derived(Base):
        def __init__(self, a):
            super()
    """
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    expected = """
    class Base:
        def __init__(self, a):
            pass
    
    
    class Derived(Base):
        def __init__(self, a):
            super(Derived, self)
    """
    assert astor.to_source(tree) == expected



# Generated at 2022-06-12 04:20:25.479253
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    from ..utils.ast_factory import AstFactory

    ast_factory = AstFactory()
    tree = ast_factory.parse("assert isinstance(super(), super)\nassert isinstance(super(super, super), super)")
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    assert astor.code_gen.to_source(tree) == "assert isinstance(super(x, self), super)\nassert isinstance(super(super, super), super)\n"

# Generated at 2022-06-12 04:22:05.119514
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3 as ast3
    from .test_helpers import assert_source_equal, roundtrip

    class SuperWithoutArgumentsTester(object):
        def __init__(self, a, b, c=None, d=4):
            super()
            super()
            pass
    
    source_code = inspect.getsource(SuperWithoutArgumentsTester)
    module_node = ast.parse(source_code)
    roundtripped = roundtrip(module_node, SuperWithoutArgumentsTransformer)
    assert_source_equal(roundtripped, source_code.replace('super()', 'super(SuperWithoutArgumentsTester, self)'))

# Generated at 2022-06-12 04:22:13.773777
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ast import parse
    from ..utils.tree import print_tree, get_all_of_type
    from .mock_tree import render_module_ast
    from ..utils.helpers import assert_equal_ignore_whitespaces

    tree = parse('''
    class A:
        def fun(self, a: int) -> str:
            return super()
        @property
        def value(self) -> str:
            return super()
    class B(A):
        def fun(self, a: int) -> str:
            return super()
        @property
        def value(self) -> str:
            return super()
    ''')
    transpiled_ast = render_module_ast(
        tree,
        (SuperWithoutArgumentsTransformer,)
    )
    assert_equal_ignore_whitespaces

# Generated at 2022-06-12 04:22:21.477798
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:22.537067
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import assert_code_equal

# Generated at 2022-06-12 04:22:25.658540
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source_code_helper import SourceCodeHelper
    from ..utils.tree import get_arg_of
    from ..utils.tree import get_node_by_type


# Generated at 2022-06-12 04:22:26.425488
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

# Generated at 2022-06-12 04:22:34.056581
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Testing on:
        class A:
            def f(self):
                super().__init__(i)
        
        class B:
            def g(self):
                super().g(10)
    """

    tree = ast.parse(textwrap.dedent("""
    class A:
        def f(self):
            super().__init__(i)
    
    class B:
        def g(self):
            super().g(10)
    """))  # type: ignore

    SuperWithoutArgumentsTransformer().visit(tree)

# Generated at 2022-06-12 04:22:39.658075
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode

    code = """
    class A:
        def __init__(self):
            super()
            super()

    class B(A):
        pass
    """
    tree = ast.parse(source_to_unicode(code))

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert transformer._tree_changed is True
    assert isinstance(tree.body[1].body[0].value.args[0], ast.Name)

# Generated at 2022-06-12 04:22:47.036538
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import List

    res = SuperWithoutArgumentsTransformer().visit(ast.parse('''
        class A:
            def __init__(self):
                super()
    '''))
        
    assert isinstance(res, ast.Module)
    assert isinstance(res.body[0], ast.ClassDef)
    assert len(res.body[0].body) == 2

    assert isinstance(res.body[0].body[1], ast.FunctionDef)
    assert res.body[0].body[1].name == '__init__'

    assert isinstance(res.body[0].body[1].body[0], ast.Expr)
    assert isinstance(res.body[0].body[1].body[0].value, ast.Call)

# Generated at 2022-06-12 04:22:54.566056
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.helpers import print_ast
    source = """
    class Foo:
        def __init__(self, arg):
            super().__init__(arg)
    """

    expected = """
    class Foo:
        def __init__(self, arg):
            super(Foo, self).__init__(arg)
    """
    tree = sta(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    result = print_ast(tree)
    assert result == expected