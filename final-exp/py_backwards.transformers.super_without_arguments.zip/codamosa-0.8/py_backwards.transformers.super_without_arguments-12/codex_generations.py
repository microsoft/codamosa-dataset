

# Generated at 2022-06-12 04:14:23.203563
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:27.670177
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astunparse
    code = "super()"
    expected_code = "super(Cls, self)"
    tree = ast.parse(code)
    node = tree.body[0].value
    func = tree.body[0].value.func
    SuperWithoutArgumentsTransformer().visit_Call(func) # no exception

# Generated at 2022-06-12 04:14:37.152736
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformerTest
    from .super import SuperWithoutArgumentsTransformer

    class Test(BaseNodeTransformerTest):
        TRANSFORMER = SuperWithoutArgumentsTransformer
        EXAMPLE_A = """
        class A:
            def __init__(self):
                super()
        """
        EXPECTED_A = """
        class A:
            def __init__(self):
                super(A, self)
        """

        EXAMPLE_B = """
        class A:
            def __init__(self):
                super()

            @staticmethod
            def _test():
                super()
        """

# Generated at 2022-06-12 04:14:40.854308
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    node = ast.parse("""
        class C:
            def __init__(self):
                super()
    """)
    SuperWithoutArgumentsTransformer().visit(node)
    assert len(node.body[0].body[0].body.args) == 2

# Generated at 2022-06-12 04:14:41.813043
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:47.044354
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    #super() is a call
    assert isinstance(super(), ast.Call)
    # super() is a call with func super
    assert isinstance(super(), ast.Call) and isinstance(super().func, ast.Name)
    # super() is a call with func super and args empty
    assert isinstance(super(), ast.Call) and isinstance(super().func, ast.Name) and not len(super().args)

# Generated at 2022-06-12 04:14:52.183702
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import override, get_nodes, get_func_name
    from ..utils.constants import UNITTEST_SUPER_WITHOUT_ARGUMENTS_MAIN_SUCCESS

    def run_test(code: str, expected: str) -> None:
        tree = ast.parse(code)

        transformer = SuperWithoutArgumentsTransformer(tree)

        # override node.args to compare them easily
        # and override node.func.id to compare them easily
        @override(ast.Call)
        def args(node: ast.Call) -> str:
            return ''.join([str(a) for a in node.args])

        @override(ast.Name)
        def id(node: ast.Name) -> str:
            return node.id


# Generated at 2022-06-12 04:14:54.158514
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    assert SuperWithoutArgumentsTransformer({'a': 'b'})._kwargs == {'a': 'b'}


# Generated at 2022-06-12 04:14:57.897155
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    transformer = SuperWithoutArgumentsTransformer()
    call = ast3.Call()
    call.func = ast3.Name()
    call.func.id = 'super'
    assert transformer._replace_super_args(call) == None

# Generated at 2022-06-12 04:15:06.692810
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import check_transformer

    check_transformer(SuperWithoutArgumentsTransformer, 'foo', '''x = super()''', '''x = super(foo, super())''')
    check_transformer(SuperWithoutArgumentsTransformer, 'foo', '''x = super(bar)''', '''x = super(bar)''')
    check_transformer(SuperWithoutArgumentsTransformer, 'foo', '''x = super(bar, xx)''', '''x = super(bar, xx)''')


# Generated at 2022-06-12 04:15:13.531746
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import typed_ast.ast3
    tree = typed_ast.ast3.parse("super()")
    SuperWithoutArgumentsTransformer().visit(tree)
    assert 'super(Cls, self)' == typed_ast.ast3.dump(tree)

# Generated at 2022-06-12 04:15:16.230796
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    assert SuperWithoutArgumentsTransformer(None).visit_Call(ast.parse('super()').body[0]) == ast.parse('super(Cls, self)').body[0]

# Generated at 2022-06-12 04:15:17.007027
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:18.212373
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:20.154261
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..fixes import SuperWithoutArgumentsTransformer as Fixer
    from ..patcher import Patcher
    from typed_ast import parse


# Generated at 2022-06-12 04:15:30.388080
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_code

    class_def = source_to_code("""
        class Class(object):
            def __init__(self):
                super()
            @classmethod
            def method(cls):
                super()
    """)
    node = class_def.body[0]
    func_def1 = node.body[0]
    func_def2 = node.body[1]
    assert isinstance(func_def1, ast.FunctionDef)
    assert isinstance(func_def2, ast.FunctionDef)

    transformer = SuperWithoutArgumentsTransformer(None)

    def node_generator(node):
        yield node

    transformer.visit(node)
    assert isinstance(func_def1, ast.FunctionDef)

# Generated at 2022-06-12 04:15:37.562241
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    class SuperWithoutArgumentsTransformer_test:
        @staticmethod
        def test_SuperWithoutArgumentsTransformer():
            
            node = ast.Call(func=ast.Name(),
                            args=[], keywords=[])
            node = SuperWithoutArgumentsTransformer().visit(node)
            return node

    node = SuperWithoutArgumentsTransformer_test.test_SuperWithoutArgumentsTransformer()
    assert node is not None

# Generated at 2022-06-12 04:15:43.846233
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_string, parse_string
    module_ast = parse_string('''
        class Cls:
            def __init__(self, x):
                super(x)
                pass
    ''')
    module_ast = compile_string(module_ast, target=SuperWithoutArgumentsTransformer.target)

    assert module_ast == parse_string('''
        class Cls:

            def __init__(self, x):
                super(Cls, self)
                pass
    ''')

# Generated at 2022-06-12 04:15:53.999303
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import findall_nodes

    class Cls(object):
        def func(self):
            super()


# Generated at 2022-06-12 04:15:54.649888
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:05.235182
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # type: () -> None
    """Tests if Call node with right args is transformed to correct node
    """
    transformer = SuperWithoutArgumentsTransformer()
    node = ast.parse('super()').body[0]  # type: ignore
    new_node = transformer.visit(node)
    assert isinstance(new_node, ast.Call)
    assert not new_node.args


# Generated at 2022-06-12 04:16:05.733837
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:07.289600
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass
    # Constructor cannot be tested as it's an abstract class.


# Generated at 2022-06-12 04:16:13.112033
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import ast
    import sys
    from .base import NodeTransformerBaseTest

    class SuperWithoutArgumentsTransformerTest(NodeTransformerBaseTest):
        target = (2, 7)
        transformer = SuperWithoutArgumentsTransformer

        def make_node(self) -> ast.AST:
            return ast.parse("super()")

        def expected_result(self) -> ast.AST:
            return ast.parse("super(Cls, self)")

        def compare_types(self, node: ast.AST, expected: ast.AST) -> None:
            return

    sys.exit(SuperWithoutArgumentsTransformerTest().test())

# Generated at 2022-06-12 04:16:18.850574
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import Source
    from .. import compile

    src = Source("""
        class Test:

            def init(self):
                super()

            def cls_method(cls):
                super()
                
            def cls_method_incorrect(self):
                def test():
                    super()
                super()
    """)

    module = compile(src)

# Generated at 2022-06-12 04:16:25.603080
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ... import helpers

    x = "class A:\n    def __init__(self):\n        super()"
    x = helpers.complete_statement(x)
    y = "class A:\n    def __init__(self):\n        super(A, self)"
    y = helpers.complete_statement(y)
    t = ast.parse(x)
    tx = SuperWithoutArgumentsTransformer()
    tx.visit(t)
    assert ast.dump(t) == ast.dump(ast.parse(y))

# Generated at 2022-06-12 04:16:35.348314
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import transform
    import types

    module_name = 'math'
    module = types.ModuleType(module_name)

    code_original = \
        """class A:
            def b(self):
                super()
        """
    code_expected = \
        """class A:
            def b(self):
                super(A, self)
        """
    tree = compile(code_original, filename=module_name, mode='exec')
    transform(tree, SuperWithoutArgumentsTransformer)

    code_actual = compile(tree, filename=module_name, mode='exec')
    exec(code_actual, module.__dict__)
    assert code_expected == code_actual


# Generated at 2022-06-12 04:16:46.179348
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    
    module = ast.parse('super()')
    SuperWithoutArgumentsTransformer(module).visit(module)
    assert str(module) == 'super(Cls, self)'

    module = ast.parse('super(B, self)')
    SuperWithoutArgumentsTransformer(module).visit(module)
    assert str(module) == 'super(Cls, self)'

    module = ast.parse('super(B, cls)')
    SuperWithoutArgumentsTransformer(module).visit(module)
    assert str(module) == 'super(Cls, cls)'

    module = ast.parse('super(B, self, *args)')
    SuperWithoutArgumentsTransformer(module).visit(module)

# Generated at 2022-06-12 04:16:46.653932
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:50.933003
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.testing import assert_expression_to_source

    tree = SuperWithoutArgumentsTransformer._parse('super()')
    SuperWithoutArgumentsTransformer(tree).run()
    assert_expression_to_source(tree, 'super(Cls, self)')

# Generated at 2022-06-12 04:17:04.448375
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast.ast3 import parse
    from ..utils.helpers import get_ast_diff
    from .base import BaseNodeTransformer
    # test constructor
    try:
        BaseNodeTransformer(None, None)
        raise AssertionError('should raise a exception')
    except AssertionError:
        pass
    # test visit_Call
    node = parse('super()')
    classtransformer = SuperWithoutArgumentsTransformer(node,None)
    expected = parse('super(cls, self)')
    result = classtransformer.visit(node)
    diff = get_ast_diff(expected, result)
    assert diff == []
    #test visit_Call
    node = parse('super()')
    defstransformer = SuperWithoutArgumentsTransformer(node,None)
    expected

# Generated at 2022-06-12 04:17:11.981308
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..example_visitor import ExampleVisitor
    from ..analyser import Analyser
    from .base import BaseNodeTransformer

    class TestTransformer(BaseNodeTransformer):
        pass

    source = """
    class A(object):
        def __init__(self):
            super().__init__(1, 2)
    """
    analyser = Analyser(source, ExampleVisitor)
    analyser.add_transformer(SuperWithoutArgumentsTransformer)
    analyser.add_transformer(TestTransformer)
    analyser.analyse()


# Generated at 2022-06-12 04:17:16.781872
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    input = """
    def foo(self):
        super()
    """
    expected_output = """
    def foo(self):
        super(Cls, self)
    """
    tree = ast.parse(input)
    tree.body[0].name = 'Cls'
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert ast.dump(tree) == expected_output

# Generated at 2022-06-12 04:17:18.499603
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import generate_source


# Generated at 2022-06-12 04:17:23.097592
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    source = dedent('''
    class Test():

        def __init__(self):
            super()

        def get_super(self):
            return super()
    ''')
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    result = unicode(tree)
    expect_result = dedent('''
    class Test():

        def __init__(self):
            super(Test, self)

        def get_super(self):
            return super(Test, self)
    ''')
    assert unicode(expect_result) == unicode(result)

# Generated at 2022-06-12 04:17:24.898832
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    print('test_SuperWithoutArgumentsTransformer_visit_Call')

# Generated at 2022-06-12 04:17:29.485852
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    code = """
        class Cls:
            def method(self):
                super()
    """
    tree = ast.parse(code)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    expected_code = """
        class Cls:
            def method(self):
                super(Cls, self)
    """
    assert astor.to_source(tree) == expected_code

# Generated at 2022-06-12 04:17:30.961327
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    assert (compile('super()') ==
            'super(self.__class__, self)')

# Generated at 2022-06-12 04:17:32.381299
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:38.419212
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import run_test_node
    node = ast.Call(func=ast.Name(id="super"), args=[])
    result = run_test_node(node, 2, 7, SuperWithoutArgumentsTransformer)
    expected = ast.Call(func=ast.Name(id="super"), args=[ast.Name(id="Cls"), ast.Name(id="self")])
    assert result == expected

# Generated at 2022-06-12 04:17:55.820212
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""
    module = ast.Module([
        ast.ClassDef(
            name='Foo',
            body=[
                ast.FunctionDef(
                    name='__init__',
                    args=ast.arguments([], None, None, []),
                    body=[ast.Expr(value=ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[]))]
                )
            ],
            decorator_list=[]
        )
    ])


# Generated at 2022-06-12 04:18:02.666251
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..testing_utils import make_fixture_super_in_func
    from ..testing_utils import make_fixture_super_in_class
    from ..testing_utils import transform
    from ..testing_utils import builtin_module
    from ..testing_utils import get_tree_str

    tree = make_fixture_super_in_func()
    transformer = SuperWithoutArgumentsTransformer(tree, builtin_module.ast)
    transformed = transform(transformer, tree)
    assert get_tree_str(transformed) == 'def func(self):\n    super(Cls, self)'

    tree = make_fixture_super_in_class()
    transformer = SuperWithoutArgumentsTransformer(tree, builtin_module.ast)
    transformed = transform(transformer, tree)

# Generated at 2022-06-12 04:18:03.222160
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:14.565080
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'

    transformer = SuperWithoutArgumentsTransformer()
    tree = transformer.visit(tree)
    node = tree.body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 2
    assert isinstance(node.value.args[0], ast.Name)
   

# Generated at 2022-06-12 04:18:16.006092
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import typed_ast.ast3

# Generated at 2022-06-12 04:18:24.845869
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer.

    Arguments:
        node (ast.FunctionDef) -- structure of FunctionDef node to test

    """
    t = SuperWithoutArgumentsTransformer()
    node = ast.parse("super()\n").body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert len(node.value.args) == 0
    node = t.visit(node)
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node

# Generated at 2022-06-12 04:18:25.230829
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:26.031398
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:30.018869
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    program = ['class Cls:', '    def method(self):', '        super()']
    program = '\n'.join(program)
    tree = ast.parse(program)
    s = SuperWithoutArgumentsTransformer(tree)
    print(ast.dump(tree))
    s.visit(tree)
    print(ast.dump(tree))

# Generated at 2022-06-12 04:18:36.207799
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'class A():\n    def __init__(self):\n        super().__init__()'
    expected_result = 'class A():\n    def __init__(self):\n        super(A, self).__init__()'

    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    result = compile(tree, '', 'exec')
    result = result.co_consts[0]

    assert result == expected_result

# Generated at 2022-06-12 04:18:50.927861
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:18:55.227713
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    super_call = ast.parse("super()").body[0].value
    transformer = SuperWithoutArgumentsTransformer("foo")
    transformer.visit_Call(super_call)
    assert str(super_call.args[0]) == "Cls"
    assert str(super_call.args[1]) == "foo"

# Generated at 2022-06-12 04:18:56.866495
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer."""

# Generated at 2022-06-12 04:19:01.809893
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class A:
        def __init__(self):
            super().__init__()
    
    class B(A):
        def __init__(self):
            super().__init__()
    """
    parser = ast.build_ast(code, mode="exec")
    visitor = SuperWithoutArgumentsTransformer()
    visitor.visit(parser)
    assert code == visitor.result

# Generated at 2022-06-12 04:19:02.865120
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:04.301572
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:19:08.767621
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
    class C:
        def __init__(self):
            super()
    
    class D(C):
        def __init__(self):
            super()
    """
    tree = ast.parse(code)
    t = SuperWithoutArgumentsTransformer(tree=tree)
    t.run()
    assert len(list(ast.walk(tree))) == 20

# Generated at 2022-06-12 04:19:10.778875
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # setup
    from ..parser import Parser
    from ..codegen import to_source


# Generated at 2022-06-12 04:19:20.285935
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("test_SuperWithoutArgumentsTransformer() running...\n")

    transformer = SuperWithoutArgumentsTransformer(None)

    # Test node.args assignment (call super())
    test_call = ast.Call(func=ast.Name(id='super', ctx=ast.Load()), args=[], keywords=[])
    transformer._replace_super_args(test_call)
    assert len(test_call.args) == 2
    assert type(test_call.args[0]) == ast.Name
    assert test_call.args[0].id == 'Cls'
    assert type(test_call.args[1]) == ast.Name
    assert test_call.args[1].id == 'self'

    print("test_SuperWithoutArgumentsTransformer() succesful!\n")


# Generated at 2022-06-12 04:19:21.464065
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast


# Generated at 2022-06-12 04:19:53.267238
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

# Generated at 2022-06-12 04:19:56.553812
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    
    class TestTrans(BaseNodeTransformer):
        def visit_Name(self, node):
            return node

    node = ast.parse("super()")
    TestTrans().visit(node)
    assert 'self' in str(node)

# Generated at 2022-06-12 04:19:58.588461
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Tests that this transformer can actually compile super() to
    super(cls, self) or super(cls, cls)
    """

# Generated at 2022-06-12 04:20:04.411150
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode as u
    from ..utils.helpers import node_to_str

    src = u("""
    def f():
        super()
    """)
    expected_src = u("""
    def f():
        super(Cls, self)
    """)
    module = ast.parse(src)
    SuperWithoutArgumentsTransformer(2, 7).visit(module)
    assert node_to_str(module) == expected_src

# Generated at 2022-06-12 04:20:04.932690
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:11.720073
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Test SuperWithoutArgumentsTransformer constructor"""

    # Code 1
    code1 = "super()"

    # Code 1 AST
    module1 = ast.Module(body=[
        ast.Expr(value=ast.Call(
            func=ast.Name(id='super', ctx=ast.Load()),
            args=[],
            keywords=[]
        ))
    ])

    # Test 1
    obj = SuperWithoutArgumentsTransformer(module1)
    obj.run()

    # Code 2

# Generated at 2022-06-12 04:20:21.126072
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils import get_ast
    from ..utils.helpers import get_tree_string
    tree = get_ast("""
        class Foo:
            def __init__(self):
                super()
                super(Foo, self)""")

    # This is the expected AST (as defined by typed_ast)
    expected = get_ast("""
    class Foo:
        def __init__(self):
            super(Foo, self)
            super(Foo, self)""")

    SuperWithoutArgumentsTransformer().visit(tree)
    assert get_tree_string(tree) == get_tree_string(expected)
    assert SuperWithoutArgumentsTransformer().generic_visit(tree)  # type: ignore

# Generated at 2022-06-12 04:20:21.548398
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass

# Generated at 2022-06-12 04:20:23.799792
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = "super()"

    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert "super(Foo, self)" in ast.dump(tree)

# Generated at 2022-06-12 04:20:29.048794
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test for super without arguments
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert dump_ast(tree) == 'super(Cls, self)'
    # Test for super with arguments, only the first argument is recognized.
    tree = ast.parse('super(1, 2)')
    SuperWithoutArgumentsTransformer().visit(tree)
    assert dump_ast(tree) == 'super(1, 2)'

# Generated at 2022-06-12 04:21:03.506813
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import TypedAstUnparser


# Generated at 2022-06-12 04:21:12.020373
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from textwrap import dedent
    from ..utils.source import source_to_unicode
    from ..utils.tree import module_to_str
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        target_class = SuperWithoutArgumentsTransformer

        def test_super_call_method(self) -> None:
            code = dedent("""\
            class Cls:

                def method(self):
                    super().test()
            """)
            tree = self.transform(source_to_unicode(code))

            assert module_to_str(tree) == dedent("""\
            class Cls:
                def method(self):
                    super(Cls, self).test()
            """)


# Generated at 2022-06-12 04:21:12.765438
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:18.641004
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Create a SubTree
    super_node = ast.Call(func=ast.Name(id='super'), args=[], keywords=[])
    func_node = ast.FunctionDef(name='__init', args=ast.arguments(args=[ast.Name(id='self', ctx=ast.Param())],
                                                                  vararg=None, varargannotation=None,
                                                                  kwonlyargs=[], kw_defaults=[], kwarg=None,
                                                                  kwargannotation=None, defaults=[]),
                                decorator_list=[], returns=None, body=[ast.Expr(value=super_node)])
    class_node = ast.ClassDef(name='DummyClass', bases=[], keywords=[], body=[func_node], lineno=1, col_offset=1)


# Generated at 2022-06-12 04:21:21.751265
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    tree = SuperWithoutArgumentsTransformer(source='', target='').visit(tree)
    expected = ast.parse('super(Cls, self)')
    assert ast_equal(tree, expected)



# Generated at 2022-06-12 04:21:23.262719
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astunparse
    from ..utils.helpers import get_ast
    from .super_without_arguments import SuperWithoutArgumentsTransformer


# Generated at 2022-06-12 04:21:30.313640
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from recommonmark.transform import Doc
    from ..transformers.super_without_args import SuperWithoutArgumentsTransformer
    from ..utils.parser import transform, parse

    class_def = 'class AClass(object):\n    def __init__(self):\n        super()'
    transformer = SuperWithoutArgumentsTransformer(class_def, Doc(parse('', '')))
    assert transformer.__class__.__name__ == 'SuperWithoutArgumentsTransformer'
    assert transform(class_def, transformer) == '\nclass AClass(object):\n    def __init__(self):\n        super(AClass, self)\n\n'



# Generated at 2022-06-12 04:21:36.811402
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..utils.helpers import get_node_of_class
    node = ast3.parse('''
        class Test:
            def __init__(self):
                super().__init__()        
        ''')
    obj = SuperWithoutArgumentsTransformer()
    call = get_node_of_class(node, ast3.Call)
    node = obj.visit(node) # type: ignore
    call = get_node_of_class(node, ast3.Call)
    assert call.args[0].id == "Test"
    assert call.args[1].id == "self"

# Generated at 2022-06-12 04:21:37.595171
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:21:39.143881
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..ast_compile import ast_compile, to_source
    from ..utils.helpers import assert_equal_text

# Generated at 2022-06-12 04:22:55.964950
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:23:00.820056
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class Cls:
            def __init__(self):
                super()
    '''
    expected_code = '''
        class Cls:
            def __init__(self):
                super(Cls, self)
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert expected_code == astor.to_source(tree)

# Generated at 2022-06-12 04:23:09.219634
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from ..utils.helpers import get_python_node, get_normalized_python, get_normalized_ast

    from ..level2.super_without_arguments import SuperWithoutArgumentsTransformer as real

    node = get_python_node('''
        class Test:
            def __init__(self):
                super()

        class Test2(object):
            def __init__(self):
                super()
    ''')

    result = get_normalized_python(node)
    expect = get_normalized_python('''
        class Test:
            def __init__(self):
                super(Test, self)

        class Test2(object):
            def __init__(self):
                super(Test2, self)
    ''')
    assert result == expect


# Generated at 2022-06-12 04:23:11.938329
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert "super(Cls, self)" == ast.dump(tree)

# Generated at 2022-06-12 04:23:19.515550
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    node_super = ast.Call(func=ast.Name(id='super'), args=[])
    node_call = ast.Call(func=node_super, args=[], keywords=[])
    node_arg = ast.arguments(args=[ast.arg(arg='cls', annotation=None)])
    node_func_def = ast.FunctionDef(name='method', args=node_arg,  body=[node_call], decorator_list=[], returns=None)
    node_class_def = ast.ClassDef(name='Cls', bases=[], keywords=[], body=[node_func_def], decorator_list=[])
    node_module = ast.Module(body=[node_class_def])

    node_module_expected = ast.Module(body=[node_class_def])

# Generated at 2022-06-12 04:23:20.471059
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import tree_to_str

# Generated at 2022-06-12 04:23:25.714002
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Source(object):
        def method(self):
            super()

        def method(cls):
            super()

    expected = "super(Cls, self)"
    assert SuperWithoutArgumentsTransformer.run_on_code(Source, 'super()') == expected, expected

    expected = "super(Cls, cls)"
    assert SuperWithoutArgumentsTransformer.run_on_code(Source, 'super()', ['cls']) == expected, expected

# Generated at 2022-06-12 04:23:26.642993
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:23:32.829823
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import textwrap
    from .. import compile_for_version

    code = textwrap.dedent(
        """\
        class Foo:
            def func(self):
                super()
        """
    )
    expected_code = textwrap.dedent(
        """\
        class Foo:
            def func(self):
                super(Foo, self)
        """
    )
    compiled_code = compile_for_version(code, (2, 7))
    assert compiled_code == expected_code, 'super() -> super(Foo, self)'



# Generated at 2022-06-12 04:23:33.276752
# Unit test for constructor of class SuperWithoutArgumentsTransformer