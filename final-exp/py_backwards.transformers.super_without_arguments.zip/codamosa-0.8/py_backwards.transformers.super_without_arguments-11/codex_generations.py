

# Generated at 2022-06-12 04:14:26.895590
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        super()
    """

    expected_code = """
        super(ClassName, self)
    """

    tree = ast.parse(code)
    tree2 = ast.parse(expected_code)
    cls = ast.ClassDef(name='ClassName')
    func = ast.FunctionDef(name='some_func', args=ast.arguments(args=[ast.arg(arg='self')]))
    cls.body = [func]
    tree.body = [cls]
    tree2.body = [cls]
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree == tree2

# Generated at 2022-06-12 04:14:27.534569
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:28.607589
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

# Generated at 2022-06-12 04:14:30.808585
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor

    # Compile AST code

# Generated at 2022-06-12 04:14:31.765702
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:37.685215
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Test:
            super()
        To:
            super(Cls, self)
            
    """
    import astor
    from textwrap import dedent
    tree = astor.parse_file(dedent('''\
        class Cls:
            def __init__(self):
                super()
        '''))
    SuperWithoutArgumentsTransformer().visit(tree)
    expected = dedent('''\
        class Cls:
            def __init__(self):
                super(Cls, self)
        ''')
    assert astor.to_source(tree) == expected

# Generated at 2022-06-12 04:14:47.729303
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_wrapper import AstWrapper
    from ..context import Context
    from ..bytecode_generation.ast_to_bytecode import convert as generate_bytecode
    from ..bytecode_generation.opcodes import (
        LOAD_BUILD_CLASS, CALL_FUNCTION, LOAD_CONST, LOAD_ATTR, LOAD_METHOD,
        LOAD_LOCALS, CALL_FUNCTION_VAR, DUP_TOP, RAISE_VARARGS
    )
    from ..transformers.super_without_arguments import SuperWithoutArgumentsTransformer

    class SuperWithout(object):
        def test_super(self):
            super()

            def method_with_super():
                super()

    context = Context(source=SuperWithout.test_super)


# Generated at 2022-06-12 04:14:48.308165
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:14:57.898744
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code_1 = """super()"""
    code_2 = """class C(object):
        def __init__(self):
            super()
    """
    tree_1 = ast.parse(code_1)
    SuperWithoutArgumentsTransformer().visit(tree_1)
    assert ast.dump(tree_1) == 'Module(body=[Expr(value=Call(func=Name(id=super, ctx=Load()), args=[Name(id=Cls, ctx=Load()), Name(id=self, ctx=Load())], keywords=[], starargs=None, kwargs=None))])'
    tree_2 = ast.parse(code_2)
    SuperWithoutArgumentsTransformer().visit(tree_2)

# Generated at 2022-06-12 04:14:58.718661
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:03.605611
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    tree = ast.parse("super()")
    SuperWithoutArgumentsTransformer.run(tree)

# Generated at 2022-06-12 04:15:06.181305
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer"""


# Generated at 2022-06-12 04:15:10.448146
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .base import BaseNodeTransformerTest

    class Test(BaseNodeTransformerTest):
        target_node = ast.Call
        transformer = SuperWithoutArgumentsTransformer
        expected_code = "super(Cls, self)"

        @property
        def ast(self) -> ast.AST:
            return ast.parse('super()').body[0]

    ok, err = Test().run()

    assert ok
    assert not err



# Generated at 2022-06-12 04:15:11.324703
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:15:13.630005
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    """Unit test for constructor of class SuperWithoutArgumentsTransformer."""
    # initializing source

# Generated at 2022-06-12 04:15:18.169390
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    pass
#     code = """
# class Cls:
#     def __init__(self):
#         super().__init__()
#     """
#     tree = ast.parse(code)
#     transformer = SuperWithoutArgumentsTransformer()
#     transformer.visit(tree)
#     print(astor.to_source(tree))

# Generated at 2022-06-12 04:15:27.823193
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import inspect
    import astor
    from tstypy.interpreter.transformer.python_to_python import PythonToPythonTransformer

    tr = PythonToPythonTransformer()

    code = inspect.getsource(test_SuperWithoutArgumentsTransformer_visit_Call)
    tr.transform_code(code)

    assert astor.to_source(tr.out.body[0]) == inspect.getsource(SuperWithoutArgumentsTransformer)
    assert astor.to_source(tr.out.body[1]) == inspect.getsource(SuperWithoutArgumentsTransformer._replace_super_args)
    assert astor.to_source(tr.out.body[2]) == inspect.getsource(test_SuperWithoutArgumentsTransformer_visit_Call)



# Generated at 2022-06-12 04:15:39.470673
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    code = """
        class Foo:
            def __init__(self):
                super()  # 1
        class Bar:
            def __init__(self, cls):
                super()  # 2
        class Waz:
            def __init__(self):
                super()  # 3
        class Baz(Foo, Bar, Waz):
            def __init__(self, cls):
                super()  # 4
        super()  # 5
        """
    parsed = ast3.parse(code)
    SuperWithoutArgumentsTransformer(parsed).visit(parsed)
    compiled = compile(parsed, '<test>', 'exec')
    glb = {}
    exec(compiled, glb)
    assert glb['Foo'].__m

# Generated at 2022-06-12 04:15:41.116739
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_code_object

# Generated at 2022-06-12 04:15:43.658174
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .utils import parse_to_ast_node
    from .scope import ScopeTransformer
    from .imports import InlineImportsTransformer
    from ..utils import compare_ast

# Generated at 2022-06-12 04:15:51.738491
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.test_utils import should_transform
    src = 'super()'
    dst = 'super(Cls, self)'
    assert should_transform(src, dst, SuperWithoutArgumentsTransformer)

# Generated at 2022-06-12 04:16:00.797298
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astor
    source = '''
        class A(object):
            def f(self):
                super()
                super()
                
        class B(object):
            def g(self):
                super()
    '''
    expected = '''
        class A(object):
            def f(self):
                super(A, self)
                super(A, self)

        class B(object):
            def g(self):
                super(B, self)
    '''

    tree = ast.parse(textwrap.dedent(source))
    node_transformer = SuperWithoutArgumentsTransformer()
    new_tree = node_transformer.visit(tree)
    code = astor.to_source(new_tree)

    assert code == textwrap.dedent(expected)



# Generated at 2022-06-12 04:16:01.785196
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:06.582524
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import run_local_tests

    tree = ast.parse('class A: def __init__(self): super()\n', mode='exec')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert tree == ast.parse('class A: def __init__(self): super(A, self)\n', mode='exec')

    run_local_tests()

# Generated at 2022-06-12 04:16:08.493769
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .context import TypyContext
    from .transpile import TypyTranspiler


# Generated at 2022-06-12 04:16:13.410666
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    from textwrap import dedent
    code = dedent('''\
    class Base:
        def m(self):
            super()
            self.x
    ''')
    tree = ast.parse(code)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    code = astor.to_source(tree)
    assert code == dedent('''\
    class Base:
        def m(self):
            super(Base, self)
            self.x
    ''')

# Generated at 2022-06-12 04:16:15.997206
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    from .. import ast
    from .. import mapper
    from .. import visitor


# Generated at 2022-06-12 04:16:18.365589
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile
    import ast

    assert compile('super()') == compile('super(C, self)')



# Generated at 2022-06-12 04:16:22.952789
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    # Arrange
    from ..utils.source import Source
    source = Source("""
                    class A():
                        def __init__(self):
                            super()
                    """)

    # Act
    source.infer()

    # Assert
    assert str(source) == """
                    class A():
                        def __init__(self):
                            super(A, self)
                    """

# Generated at 2022-06-12 04:16:23.906404
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:33.990311
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:16:42.486356
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest
    import typed_astunparse
    from .base import BaseNodeTransformerTest
    
    class Test(BaseNodeTransformerTest):
        def test_transform(self):
            tree = self.parse("""
super()
            """)
            node = tree.body[0]
            node = SuperWithoutArgumentsTransformer(tree).visit(node)
            expected_code = """super(Cls, self)"""
            self.assertEqual(expected_code, typed_astunparse.unparse(node))

    unittest.main(exit=False)

# Generated at 2022-06-12 04:16:45.874118
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse('super()')
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)


# Adding SuperWithoutArgumentsTransformer to TRANSFORMERS
TRANSFORMERS.append(SuperWithoutArgumentsTransformer)  # type: ignore

# Generated at 2022-06-12 04:16:49.025500
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .test_helpers import get_ast_root
    from .. import register_transformer
    from ..utils.tree import get_node, are_trees_equals
    # Simple case

# Generated at 2022-06-12 04:16:54.067555
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..test_utils import extract_and_check, transform_and_check

    def assert_equivalent(target: str, expected: str):
        transform_and_check(target, SuperWithoutArgumentsTransformer, expected)
        extract_and_check(target, SuperWithoutArgumentsTransformer, expected)


# Generated at 2022-06-12 04:16:55.454159
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from ..utils import cst_to_ast


# Generated at 2022-06-12 04:17:06.094631
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3
    from typed_ast import convert
    from textwrap import dedent

    # Only for type annotations
    from .. import LegacyNodeTransformer
    from ..context import Context

    class MockTransformer(LegacyNodeTransformer):
        def __init__(self, tree: ast3.AST) -> None:
            super().__init__(Context(), tree)

    module = dedent("""
    class Cls:
        def __init__(self):
            super()
    
    class Cls2:
        def __init__(cls):
            super()
    """)
    tree = convert(module, to_ast=True)

    transformer = MockTransformer(tree)
    transformer.visit(tree)

    # Ensure it has been modified

# Generated at 2022-06-12 04:17:12.172102
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
            class A:
                def __init__(self):
                    super()
            """
    expected_code = """
            class A:
                def __init__(self):
                    super(A, self)
            """

    tree = ast.parse(code)
    assert compile(tree, '', 'exec') == compile(expected_code, '', 'exec')
    SuperWithoutArgumentsTransformer.transform_code(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(expected_code))



# Generated at 2022-06-12 04:17:17.929886
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast

    source = """
    super()
    """

    expected = """
    super(Cls, self)
    """

    tree = ast.parse(source)
    tree = SuperWithoutArgumentsTransformer().visit(tree)

    result = compile(tree, filename='<ast>', mode='exec')

    code1 = result.co_consts[0]
    code2 = compile(expected, filename='<ast>', mode='exec').co_consts[0]
    assert code1 == code2

# Generated at 2022-06-12 04:17:24.381973
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor

    code = '''
    class MyClass(object):
        def __init__(self):
            super().__init__()
    '''
    t = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(t)
    code_transformed = astor.to_source(t)

    expected = '''
    class MyClass(object):
        def __init__(self):
            super(MyClass, self).__init__()
    '''
    assert code_transformed == expected



# Generated at 2022-06-12 04:17:43.819276
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:53.119089
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile
    import textwrap

    code = textwrap.dedent('''\
    class TestClass:
        def __init__(self):
            super()
        def __str__(self):
            super()
    ''')

    expected = textwrap.dedent('''\
    class TestClass:
        def __init__(self):
            super(TestClass, self)
        def __str__(self):
            super(TestClass, self)
    ''')

    tree = compile(code, 'test', 'exec')
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert expected == compile(tree, 'test', 'exec')

# Generated at 2022-06-12 04:17:53.685754
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:17:59.614983
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = 'class C(object): def m(self): super()'
    tree = ast.parse(code)
    node = tree.body[0].body[0].body[0]
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert transformer.tree_changed is True
    expected = 'class C(object): def m(self): super(C, self)'
    code_new = astor.to_source(tree)
    assert code_new == expected


# Generated at 2022-06-12 04:18:08.207817
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from .base import BaseNodeTransformer
    from .super_without_arguments import SuperWithoutArgumentsTransformer

    class MockNodeTransformer(BaseNodeTransformer):
        def visit_Call(self, node):
            return node

    tree = ast.parse('super()')
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert ast.dump(tree) == "Expr(value=Call(func=Attribute(value=Name(id='super', ctx=Load()), attr='__init__', ctx=Load()), args=[], keywords=[], starargs=None, kwargs=None))"

# Generated at 2022-06-12 04:18:18.387102
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # Test for subclass
    class SubClassSuperWithoutArgumentsTransformer(SuperWithoutArgumentsTransformer):
        target = (3, 8)
    t = SubClassSuperWithoutArgumentsTransformer('''
        class A:
            def f(self):
                super()
    ''')
    t.visit(t.tree)

    assert t.tree.body[0].body[0].body[0].args[0].id == 'A'
    assert t.tree.body[0].body[0].body[0].args[1].id == 'self'

    # Test for superclass
    t = SuperWithoutArgumentsTransformer('''
        class A:
            def f(self):
                super()
    ''')
    t.visit(t.tree)


# Generated at 2022-06-12 04:18:26.694471
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    """Unit test for method visit_Call of class SuperWithoutArgumentsTransformer.
    """
    code = """
        class Cls:
            def __init__(self):
                super()
    """
    tree = ast.parse(code)
    transformer = SuperWithoutArgumentsTransformer(tree, {})
    transformer.visit(tree)

    assert isinstance(tree.body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].value.args[0], ast.Name)
    assert tree.body[0].body[0].value.args[0].id == 'Cls'

    assert isinstance(tree.body[0].body[0].value.args[1], ast.Name)

# Generated at 2022-06-12 04:18:29.666516
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3
    from typed_ast.ast3 import Call, Name, FunctionDef, ClassDef
    from ..utils.tree import get_ast
    from ..utils.helpers import is_type_of

# Generated at 2022-06-12 04:18:38.380229
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import parse
    from ..utils.helpers import eq_ast
    from ..utils.tree import get_ast

    code_to_transform = """
        class Cls:
            x = 10
            def __init__(self):
                super()
                super()
    """

    expected_code = """
        class Cls:
            x = 10
            def __init__(self):
                super(Cls, self)
                super(Cls, self)
    """
    node = parse(code_to_transform)
    tree = get_ast(node)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed
    eq_ast(tree, expected_code)

# Generated at 2022-06-12 04:18:43.283689
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class A:
            def b(self):
                super()
    """
    parsed = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(parsed)
    compiled = compile(parsed, '', 'exec')
    ns = {}
    exec(compiled, ns)
    it = ns['A']().b()
    assert isinstance(it, object)

# Generated at 2022-06-12 04:19:07.346843
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typing import Type
    from ..utils.source import source_to_unicode as u
    from ..visitors.stream import Stream

    class C(object):
        def f(self):
            super()
            super()
    source = u("""
    class C(object):
        def f(self):
            super()
            super()
    """)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree, source)
    transformer.visit(tree)

    assert source == u("""
    class C(object):
        def f(self):
            super(C, self)
            super(C, self)
    """)

    class C(object):
        def f(self):
            super()
            super()

        def g(cls):
            super()
            super

# Generated at 2022-06-12 04:19:07.817338
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:09.712642
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:10.921410
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:19:12.223633
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    transformer = SuperWithoutArgumentsTransformer()

# Generated at 2022-06-12 04:19:13.306987
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():

    import astor

# Generated at 2022-06-12 04:19:16.653529
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import unittest

    from typed_ast import ast3 as ast
    from vyper.compiler.ast_transformers import SuperWithoutArgumentsTransformer
    from vyper.utils import decompile_to_ast


# Generated at 2022-06-12 04:19:22.868772
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    s = ("class Foo:\n"
         "    def __init__(self):\n"
         "        super()\n")

    tree = ast.parse(s)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    code = compile(tree, '<test>', 'exec')
    locals = {}
    exec(code, {}, locals)
    assert locals['Foo'].__init__.__name__ == '__init__'
    assert locals['Foo']().__class__.__name__ == 'Foo'

# Generated at 2022-06-12 04:19:30.748183
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import textwrap

    tree = ast.parse(textwrap.dedent('''
    class Foo(object):
        def __init__(self):
            pass

        def method(self):
            super()
    '''))
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    code = compile(tree, filename='<test>', mode='exec')
    ns = {}
    exec(code, ns)
    assert ns['Foo']().method() is None

# Generated at 2022-06-12 04:19:31.296823
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:04.217182
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import print_ast
    from .. import parse


# Generated at 2022-06-12 04:20:13.263176
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    # TEST CASE 1
    inp = """
    class A(object):
        def __init__(self):
            super()
    
    def f():
        pass
    """
    out = """
    class A(object):
        def __init__(self):
            super(A, self)
    
    def f():
        pass
    """
    kwargs = {'add_line_information': False}
    t, _ = run_transformer(SuperWithoutArgumentsTransformer, inp, **kwargs)
    assert t == out

    # TEST CASE 2
    inp = """
    from __future__ import annotations
    class A:
        def __init__(self):
            super()
    
    def f():
        pass
    """

# Generated at 2022-06-12 04:20:15.491324
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_for_version
    assert compile_for_version('super()', 2) == 'super(Cls, self)'
    assert compile_for_version('super()', 3) == 'super()'

# Generated at 2022-06-12 04:20:16.318140
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:16.846647
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:25.879121
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import Compiler
    from textwrap import dedent
    code = dedent('''
    class A(object):
        def __init__(self):
            pass
    class B(A):
        def __init__(self):
            super()
    ''')
    compiler = Compiler(2, 7)
    compiler.add_transformer(SuperWithoutArgumentsTransformer)
    code = compiler.compile_ast(code)
    assert code == dedent('''
    class A(object):
        def __init__(self):
            pass
    class B(A):
        def __init__(self):
            super(A, self)
    ''')

# Generated at 2022-06-12 04:20:30.486949
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils import dump
    from .base import BaseNodeTransformer

    source = """
yield from [1, 2, 3]
    """.strip()

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)

    expected_source = """
yield from [1, 2, 3]
    """.strip()

    assert dump(tree) == expected_source

# Generated at 2022-06-12 04:20:37.599671
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    import astor
    import textwrap
    source = textwrap.dedent('''\
        class Cls(object):
            def __init__(self):
                super().__init__()
        ''')

    expected = textwrap.dedent('''\
        class Cls(object):
            def __init__(self):
                super(Cls, self).__init__()
        ''')

    tree = ast.parse(source)
    trans = SuperWithoutArgumentsTransformer()
    new_tree = trans.visit(tree)
    result = astor.to_source(new_tree)
    assert result == expected

# Generated at 2022-06-12 04:20:38.414965
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:20:39.731000
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .unittest_transformer_util import compile_source


# Generated at 2022-06-12 04:21:57.635260
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:03.476383
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    input_code = """
        class A:
            def __init__(self):
                super()
        """
    expected_code = """
        class A:
            def __init__(self):
                super(A, self)
        """
    tree = ast.parse(input_code)
    tree = SuperWithoutArgumentsTransformer(tree).visit(tree)
    code = CodeIO.getvalue(tree)
    assert code == expected_code

# Generated at 2022-06-12 04:22:04.279928
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:12.833907
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    t = ast.parse('super()', mode='exec')
    mysuper = SuperWithoutArgumentsTransformer()
    mysuper.visit(t)

    assert isinstance(t, ast.Module)
    assert isinstance(t.body[0], ast.Expr)
    assert isinstance(t.body[0].value, ast.Call)
    assert isinstance(t.body[0].value.func, ast.Name)
    assert t.body[0].value.func.id == 'super'
    assert len(t.body[0].value.args) == 2
    assert isinstance(t.body[0].value.args[0], ast.Name)
    assert isinstance(t.body[0].value.args[1], ast.Name)

# Generated at 2022-06-12 04:22:13.710295
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:15.556584
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    class Source:
        @classmethod
        def __init__(cls):
            super() # need to compile this to super(cls, cls)

# Generated at 2022-06-12 04:22:16.307568
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:22:20.242859
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = """
        class Foo:
            def bar(self):
                super()
        """

    expected_code = """
        class Foo:
            def bar(self):
                super(Foo, self)
        """

    transpiled_code = Transpiler().transpile_code(code, target=(2, 7))
    assert transpiled_code == expected_code

# Generated at 2022-06-12 04:22:22.321498
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    import astunparse
    from typing import List
    from ..utils.ast_helpers import is_unsupported_call


# Generated at 2022-06-12 04:22:30.018015
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    source = '''class A(object):
                    def f(self):
                        return self + 1

                    def g(self):
                        return super()

                    def h(self):
                        return self + super()
    '''
    target = '''class A(object):
                    def f(self):
                        return self + 1

                    def g(self):
                        return super(A, self)

                    def h(self):
                        return self + super(A, self)
    '''
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert ast.dump(tree) == ast.dump(ast.parse(target))



# Generated at 2022-06-12 04:23:44.727432
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-12 04:23:50.307265
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    print("test_SuperWithoutArgumentsTransformer")

    import astor
    import inspect
    from ..utils.helpers import get_code_object
    code_obj = get_code_object(inspect.currentframe())
    mod = ast.parse(code_obj)

    print("input:")
    print(astor.to_source(mod))

    SuperWithoutArgumentsTransformer(mod).visit(mod)

    print("\noutput:")
    print(astor.to_source(mod))

# Generated at 2022-06-12 04:23:55.106267
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..utils.test_utils import should_transform_equal

    test_cases = (
        ('super()', 'super(ClassName, a)'),
    )

    for before, after in test_cases:
        should_transform_equal(before, after, [SuperWithoutArgumentsTransformer])

# Generated at 2022-06-12 04:23:58.665988
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    tree = ast.parse("""class A:
    def __init__(self):
        super()
        pass
""")

    node_transformer = SuperWithoutArgumentsTransformer(tree)
    tree = node_transformer.visit(tree)

# Generated at 2022-06-12 04:24:03.942032
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .transformer_util import transformer_test_utils as tu

    source = """
        class A:
            def some_method(self):
                super()
    """
    expected = """
        class A:
            def some_method(self):
                super(A, self)
    """
    tree = tu.ast_from_source(source)
    t = SuperWithoutArgumentsTransformer()
    t.visit(tree)
    assert tu.ast2str(tree) == expected
    assert t._tree_changed == True

# Generated at 2022-06-12 04:24:07.774331
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_restricted
    from ..utils.helpers import get_first_argument_name, is_first_argument_self
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound
    from typed_ast import ast3 as ast
    

# Generated at 2022-06-12 04:24:11.686531
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    code = '''
        class a:
            def __init__(self):
                super()
    '''
    tree = ast.parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    compiler.ast_compile(tree, '', 'exec')

# Generated at 2022-06-12 04:24:19.159178
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast, get_class_method_name
    from ..utils.helpers import dumps_ast

    class_source = """
        class MyClass(object):
            """

    super_test_source = """
    super()
    """

    expected_source = """
    super(MyClass, self)
    """

    class_ast = source_to_ast(class_source)
    super_test_ast = source_to_ast(super_test_source)
    expected_ast = source_to_ast(expected_source)

    method_name = 'test'
    super_test_class_method_ast = get_class_method_name(super_test_ast, method_name)