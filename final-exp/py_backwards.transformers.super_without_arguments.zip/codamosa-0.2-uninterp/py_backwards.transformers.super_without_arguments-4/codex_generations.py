

# Generated at 2022-06-18 00:41:17.765045
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:41:26.359259
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    tree = ast_call(
        ast_name('super'),
        []
    )

    func = ast_function_def(
        'func',
        args=ast_name('self'),
        body=[tree]
    )

    cls = ast_class_def(
        'Cls',
        body=[func]
    )

    tree = ast.Module(body=[cls])

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == 'class Cls:\n    def func(self):\n        super(Cls, self)\n'

# Generated at 2022-06-18 00:41:27.457020
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:41:34.895187
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:41:37.293247
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:41:44.213125
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:41:51.697470
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:41:59.307560
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast

    tree = build_ast("""
    class A:
        def __init__(self):
            super()
    """)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].body[0].value.func, ast.Name)
    assert tree.body[0].body[0].body[0].value.func.id == 'super'
    assert len(tree.body[0].body[0].body[0].value.args) == 2

# Generated at 2022-06-18 00:42:07.849814
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_class, ast_func, ast_name
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_all_nodes_of_type

    tree = ast_class(
        name='Cls',
        body=[
            ast_func(
                name='method',
                args=ast.arguments(args=[ast.arg(arg='self', annotation=None)]),
                body=[
                    ast_call(func=ast_name(id='super'))
                ]
            )
        ]
    )

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:42:15.971072
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_str
    from ..utils.tree import print_tree

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast_from_str(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert print_tree(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:42:24.699744
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:34.375384
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef

    source = source_to_unicode("""
    class Cls:
        def method(self):
            super()
    """)

    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert isinstance(tree.body[0].body[0].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].body[0].value.func, ast_name)
    assert tree.body[0].body[0].body

# Generated at 2022-06-18 00:42:41.033017
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class Cls(object):
            def func(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class Cls(object):
            def func(self):
                super(Cls, self)
    """)

# Generated at 2022-06-18 00:42:51.394994
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_name, ast_arguments, ast_functiondef, ast_classdef
    from ..utils.tree import get_closest_parent_of

    tree = ast.parse('super()')
    node = get_closest_parent_of(tree, tree.body[0].value, ast.Call)
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len(node.args) == 0

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed


# Generated at 2022-06-18 00:42:59.950842
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:43:06.672330
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from ..utils.source import source_to_ast as parse

    code = u('''
    class A:
        def __init__(self):
            super()
    ''')
    expected = u('''
    class A:
        def __init__(self):
            super(A, self)
    ''')
    tree = parse(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert expected == astor.to_source(tree).strip()

# Generated at 2022-06-18 00:43:08.800147
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:43:09.999820
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:43:16.293786
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:20.825836
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source
    from ..utils.tree import get_all_subclasses
    from ..utils.helpers import get_all_subclasses_recursive


# Generated at 2022-06-18 00:43:29.637547
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:36.036312
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:43:43.985262
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:43:45.710366
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name


# Generated at 2022-06-18 00:43:50.890033
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast_node_at_line
    from ..utils.helpers import get_ast_of_code
    from ..utils.helpers import get_code_of_ast
    from ..utils.helpers import get_code_of_node


# Generated at 2022-06-18 00:43:57.128280
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.source import Source
    from ..utils.helpers import get_ast
    from ..utils.tree import print_tree

    source = Source("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    print_tree(tree)
    assert tree.body[0].body[0].args.args[1].id == 'self'

# Generated at 2022-06-18 00:44:01.144543
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:44:02.835500
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:44:04.898850
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name


# Generated at 2022-06-18 00:44:14.699738
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    tree = ast.parse('super()')
    node = tree.body[0].value
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert get_ast_node_name(node) == 'Call'
    assert len(node.args) == 2
    assert get_ast_node_name(node.args[0]) == 'Name'
    assert node.args[0].id == 'Cls'
    assert get_ast_node_name(node.args[1]) == 'Name'
    assert node.args[1].id == 'self'

    tree

# Generated at 2022-06-18 00:44:20.373746
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:44:28.529501
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:44:38.064631
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast

    tree = get_ast(source_to_unicode('''
    class A:
        def __init__(self):
            super()
    '''))

    SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert tree == get_ast(source_to_unicode('''
    class A:
        def __init__(self):
            super(A, self)
    '''))


# Generated at 2022-06-18 00:44:44.435107
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode as u
    from ..utils.source import source_to_ast as parse

    code = u('''
    class A(object):
        def __init__(self):
            super()
    ''')

    tree = parse(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert u(tree) == u('''
    class A(object):
        def __init__(self):
            super(A, self)
    ''')

# Generated at 2022-06-18 00:44:51.627864
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:44:54.314016
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.helpers import ast_to_source as ats
    from ..utils.helpers import ast_to_code as atc


# Generated at 2022-06-18 00:45:04.593972
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast as c2a
    from ..utils.helpers import get_ast_node_name

    code = 'super()'
    tree = c2a(code)
    node = tree.body[0].value

    assert get_ast_node_name(node) == 'Call'
    assert len(node.args) == 0

    SuperWithoutArgumentsTransformer(tree).visit(tree)

    assert get_ast_node_name(node) == 'Call'
    assert len(node.args) == 2
    assert get_ast_node_name(node.args[0]) == 'Name'
    assert node.args[0].id == 'Cls'
    assert get_ast_node_name(node.args[1]) == 'Name'

# Generated at 2022-06-18 00:45:14.923435
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from .. import compile_restricted
    from .. import parse
    from .. import fix_missing_locations
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = parse(source)
    tree = SuperWithoutArgumentsTransformer().visit(tree)
    tree = fix_missing_locations(tree)
    code = compile_restricted(tree, '<test>', 'exec')
    exec(code)


# Generated at 2022-06-18 00:45:17.156401
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-18 00:45:20.590902
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:45:34.176648
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:42.169098
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    expected_source = source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(expected_source, tree)

# Generated at 2022-06-18 00:45:51.157729
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-18 00:45:58.769899
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast
    from ..utils.ast_helpers import get_func_name, get_func_args, get_func_body, get_class_name, get_class_bases, get_class_body

    source = source_to_unicode('''
    class A:
        def __init__(self):
            super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert get_func_name(get_class_body(tree)[0]) == '__init__'
    assert get_func_args(get_class_body(tree)[0]) == ['self']

# Generated at 2022-06-18 00:46:06.557914
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:46:08.743519
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast


# Generated at 2022-06-18 00:46:16.465614
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:21.736262
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:46:27.828595
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast
    from ..utils.compare import compare_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    expected_ast = get_ast(source)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert compare_ast(tree, expected_ast)

# Generated at 2022-06-18 00:46:33.861481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:58.006949
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    node = get_closest_parent_of(tree, ast_call(ast_name('super')), ast.FunctionDef)
    assert get_ast_node_name(node) == '__init__'

# Generated at 2022-06-18 00:46:58.507397
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:46:58.966132
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:47:03.712425
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:47:09.316743
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(tree_to_str(tree), '''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:47:17.170332
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')

    tree = ast_from_str(source)
    SuperWithoutArgumentsTransformer().visit(tree)

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:47:24.132402
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:47:30.660791
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class Foo:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class Foo:
            def __init__(self):
                super(Foo, self)
    """)

# Generated at 2022-06-18 00:47:34.706517
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:47:38.582910
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_ast_node_at_position
    from ..utils.helpers import get_ast_of_code


# Generated at 2022-06-18 00:48:20.483322
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast_node_name

    # Test 1
    tree = ast_class_def(
        name='Cls',
        body=[
            ast_function_def(
                name='method',
                args=ast_call(
                    func=ast_name(id='args'),
                    args=[ast_name(id='self')]
                ),
                body=[
                    ast_call(
                        func=ast_name(id='super')
                    )
                ]
            )
        ]
    )
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert get_ast_node

# Generated at 2022-06-18 00:48:25.538094
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:48:26.109825
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:48:33.163926
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_source

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast_from_source(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:48:39.686905
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:48:45.697989
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:48:53.405295
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str
    from ..utils.ast_helpers import get_ast

    src = source_to_unicode('''
    class A:
        def __init__(self):
            super()
    ''')
    tree = get_ast(src)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert_equal_ignore_ws(tree_to_str(tree), '''
    class A:
        def __init__(self):
            super(A, self)
    ''')

# Generated at 2022-06-18 00:49:01.340272
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import dump_ast
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound
    from ..compiler import compile_src
    from .base import BaseNodeTransformer

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)


# Generated at 2022-06-18 00:49:07.565853
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_source

    source = source_to_unicode('''
        class Foo:
            def __init__(self):
                super()
    ''')
    tree = ast_from_source(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode('''
        class Foo:
            def __init__(self):
                super(Foo, self)
    ''')

# Generated at 2022-06-18 00:49:13.512410
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:50:39.539340
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:50:47.478607
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_arguments, ast_arg, ast_classdef
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    class_name = 'MyClass'
    function_name = 'my_function'
    arg_name = 'my_arg'

    tree = ast_classdef(class_name, [
        ast_functiondef(function_name, ast_arguments([ast_arg(arg_name)], None, None, []), [
            ast_call(ast_name('super'))
        ])
    ])

    transformer = SuperWithoutArgumentsTrans

# Generated at 2022-06-18 00:50:54.371826
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:51:02.662054
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    tree = ast_call(
        ast_name('super'),
        []
    )

    func = ast_function_def(
        'foo',
        [],
        [],
        [],
        [],
        [],
        tree
    )

    cls = ast_class_def(
        'Cls',
        [],
        [],
        [],
        [],
        [],
        [func]
    )

    expected = ast_call(
        ast_name('super'),
        [ast_name('Cls'), ast_name('self')]
    )


# Generated at 2022-06-18 00:51:07.530789
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_nodes
    from ..utils.source import source_to_code
    from ..utils.helpers import get_ast_node


# Generated at 2022-06-18 00:51:15.849192
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_node_names
    from ..utils.tree import get_all_nodes_of_type

    code = '''
    class A:
        def __init__(self):
            super()
    '''
    tree = build_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert get_node_names(get_all_nodes_of_type(tree, ast.Call)[0]) == ['super', 'A', 'self']