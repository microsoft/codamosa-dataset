

# Generated at 2022-06-18 00:41:23.800225
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:41:29.354897
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    code = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(code)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree.body[0].body[0].value.args[0].id == 'A'
    assert tree.body[0].body[0].value.args[1].id == 'self'

# Generated at 2022-06-18 00:41:37.986849
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast

    class TestTransformer(SuperWithoutArgumentsTransformer):
        def __init__(self):
            self._tree = ast.parse('super()')
            self._tree_changed = False

    t = TestTransformer()
    t.visit(t._tree)
    assert t._tree_changed
    assert ast.dump(t._tree) == "Module(body=[Expr(value=Call(func=Name(id='super', ctx=Load()), args=[Name(id='Cls', ctx=Load()), Name(id='self', ctx=Load())], keywords=[], starargs=None, kwargs=None))])"

# Generated at 2022-06-18 00:41:48.169417
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def, ast_arguments
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-18 00:41:49.377758
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:41:58.177989
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound
    from ..utils.helpers import get_ast_node

    tree = get_ast_node('''
    class A:
        def __init__(self):
            super()
    ''')

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    try:
        func = get_closest_parent_of(tree, get_ast_node('super()'), ast.FunctionDef)
    except NodeNotFound:
        assert False


# Generated at 2022-06-18 00:42:03.138617
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:09.608353
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    expected_source = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(astor.to_source(tree).strip(), expected_source.strip())

# Generated at 2022-06-18 00:42:10.155154
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:42:10.630976
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:42:20.343387
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    code = """
    class A:
        def __init__(self):
            super()
    """
    expected = """
    class A:
        def __init__(self):
            super(A, self)
    """
    tree = ast.parse(source_to_unicode(code))
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(ast.dump(tree), expected)

# Generated at 2022-06-18 00:42:27.219956
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:32.453200
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed == True

# Generated at 2022-06-18 00:42:33.052440
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:42:41.888767
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def


# Generated at 2022-06-18 00:42:49.949026
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:43:00.486160
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_classdef, ast_functiondef, ast_name

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].body[0].value.func, ast_name)
    assert tree.body[0].body[0].body[0].value.func.id == 'super'

# Generated at 2022-06-18 00:43:06.846062
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
    class A:
        def __init__(self):
            super()
    ''')
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode('''
    class A:
        def __init__(self):
            super(A, self)
    ''')

# Generated at 2022-06-18 00:43:07.475478
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:43:13.318680
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = """
    class A:
        def __init__(self):
            super()
    """
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:43:16.593629
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:43:24.928808
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:33.277960
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(tree_to_str(tree), '''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:43:38.079361
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:40.072645
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast


# Generated at 2022-06-18 00:43:47.187252
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:54.804677
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:44:00.916792
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of

    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = build_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    node = tree.body[0].body[0].body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert len(node.args) == 2

# Generated at 2022-06-18 00:44:03.289714
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast


# Generated at 2022-06-18 00:44:13.583338
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_arguments, ast_arg, ast_functiondef, ast_classdef
    from ..utils.helpers import get_ast_node_at_line

    source = source_to_unicode('''
        class Cls:
            def method(self):
                super()
    ''')

    tree = ast.parse(source)
    node = get_ast_node_at_line(tree, 3)
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert not node.args

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-18 00:44:28.670989
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.helpers import get_ast_node_name as gann
    from ..utils.helpers import get_ast_node_lineno as ganl
    from ..utils.helpers import get_ast_node_col_offset as ganco
    from ..utils.helpers import get_ast_node_end_lineno as gane
    from ..utils.helpers import get_ast_node_end_col_offset as ganeco
    from ..utils.helpers import get_ast_node_type as gant
    from ..utils.helpers import get_ast_node_fields as ganf


# Generated at 2022-06-18 00:44:35.166209
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-18 00:44:45.359636
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)

    node = get_closest_parent_of(tree, ast_call(ast_name('super')), ast_function_def('__init__'))
    cls = get_closest_parent_of(tree, node, ast_class_def('A'))

    transformer = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-18 00:44:48.210055
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name


# Generated at 2022-06-18 00:44:56.117659
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert isinstance(tree.body[0].body[0].body[0], ast.Expr)
    assert isinstance(tree.body[0].body[0].body[0].value, ast.Call)
    assert isinstance(tree.body[0].body[0].body[0].value.func, ast_name)

# Generated at 2022-06-18 00:44:56.663822
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:45:03.006698
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_src
    src = """
    class Cls:
        def __init__(self):
            super()
    """
    expected = """
    class Cls:
        def __init__(self):
            super(Cls, self)
    """
    tree = compile_src(src, 2)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert expected == tree_to_src(tree)

# Generated at 2022-06-18 00:45:03.598747
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:45:11.695136
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:18.818110
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:34.683838
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_node_of_class
    from ..utils.tree import get_closest_parent_of

    class_node = build_ast("""
    class A:
        def __init__(self):
            super()
    """)

    transformer = SuperWithoutArgumentsTransformer(class_node)
    transformer.visit(class_node)

    super_node = get_node_of_class(class_node, ast.Call)
    assert len(super_node.args) == 2
    assert isinstance(super_node.args[0], ast.Name)
    assert super_node.args[0].id == 'A'

# Generated at 2022-06-18 00:45:42.077602
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class Cls:
            def method(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class Cls:
            def method(self):
                super(Cls, self)
    """)

# Generated at 2022-06-18 00:45:51.120281
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_arguments, ast_arg, ast_functiondef, ast_classdef

    source = source_to_unicode("""
        class Cls:
            def method(self):
                super()
    """)
    expected = source_to_unicode("""
        class Cls:
            def method(self):
                super(Cls, self)
    """)
    tree = ast.parse(source)
    node = tree.body[0].body[0].body[0].value
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(node)
    assert transformer._tree_changed is True

# Generated at 2022-06-18 00:45:57.088706
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A(object):
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A(object):
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:02.061488
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:46:08.698324
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:09.616546
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:46:19.898854
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast.Call)
    assert isinstance(node.value.func, ast.Name)
    assert node.value.func.id == 'super'
    assert not node.value.args

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert isinstance(node.value, ast.Call)

# Generated at 2022-06-18 00:46:27.867536
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert node_to_str(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:46:30.919485
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str


# Generated at 2022-06-18 00:46:51.071213
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:46:56.550334
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer(tree).run()
    assert_equal_ignore_ws(tree_to_str(tree), '''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:47:05.099985
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef, ast_arguments

    tree = ast_classdef(
        name='Cls',
        body=[
            ast_functiondef(
                name='__init__',
                args=ast_arguments(
                    args=[ast_arg(arg='self')],
                    vararg=None,
                    kwonlyargs=[],
                    kw_defaults=[],
                    kwarg=None,
                    defaults=[]
                ),
                body=[
                    ast_call(
                        func=ast_name(id='super'),
                        args=[],
                        keywords=[]
                    )
                ]
            )
        ]
    )

    expected_tree = ast_class

# Generated at 2022-06-18 00:47:09.724383
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:47:17.356633
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A(object):
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A(object):
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:47:26.972283
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef

    tree = ast_call(
        func=ast_name(id='super'),
        args=[]
    )
    func = ast_functiondef(
        name='foo',
        args=ast_arguments(args=[ast_arg(arg='self')])
    )
    cls = ast_classdef(name='Foo')

    tree.parent = func
    func.parent = cls

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert source_to_unicode(tree) == 'super(Foo, self)'

# Generated at 2022-06-18 00:47:35.488603
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..transpilers.base import BaseTranspiler
    from ..transpilers.super_without_arguments import SuperWithoutArgumentsTransformer

    class TestTranspiler(BaseTranspiler):
        def __init__(self, tree: ast.AST, context: Context) -> None:
            super().__init__(tree, context)
            self._transpilers = [SuperWithoutArgumentsTransformer]

    tree = ast.parse('super()')
    transpiler = TestTranspiler(tree, Context())
    transpiler.transpile()
    assert str(tree) == 'super(Cls, self)'

    tree = ast.parse('super(1, 2)')
    transpiler = TestTranspiler(tree, Context())

# Generated at 2022-06-18 00:47:36.013034
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:47:42.967548
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super().__init__()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self).__init__()
    """)

# Generated at 2022-06-18 00:47:43.784764
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:48:15.267350
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast, compare_asts

    source = source_to_unicode("""
        class Cls:
            def method(self):
                super()
    """)
    expected_ast = get_ast(source_to_unicode("""
        class Cls:
            def method(self):
                super(Cls, self)
    """))

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert compare_asts(tree, expected_ast)

# Generated at 2022-06-18 00:48:22.654068
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:48:24.137103
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_nodes
    from ..utils.compare import compare_ast


# Generated at 2022-06-18 00:48:31.044479
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:48:31.552784
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:48:38.632568
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:48:45.409200
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class Cls:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert tree_to_str(tree) == source_to_unicode('''
        class Cls:
            def __init__(self):
                super(Cls, self)
    ''')

# Generated at 2022-06-18 00:48:54.506461
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_arguments, ast_arg, ast_class_def

    source = source_to_unicode("""
    class Cls:
        def method(self):
            super()
    """)
    tree = ast.parse(source)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast_call())
    assert isinstance(node.value.func, ast_name())
    assert node.value.func.id == 'super'
    assert not len(node.value.args)

    transformer = SuperWithoutArgumentsTransformer(tree)

# Generated at 2022-06-18 00:48:57.753976
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_all_nodes_of_type


# Generated at 2022-06-18 00:48:59.123441
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:49:58.301572
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast


# Generated at 2022-06-18 00:49:58.796060
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:50:07.614263
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:50:16.314333
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name

    code = """
    class A:
        def __init__(self):
            super()
    """
    tree = compile_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert get_ast_node_name(tree.body[0].body[0].body[0].value.args[0]) == 'A'
    assert get_ast_node_name(tree.body[0].body[0].body[0].value.args[1]) == 'self'

# Generated at 2022-06-18 00:50:21.791937
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = """
    class A:
        def __init__(self):
            super()
    """
    tree = ast.parse(source_to_unicode(source))
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == """
    class A:
        def __init__(self):
            super(A, self)
    """

# Generated at 2022-06-18 00:50:27.126845
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:50:33.316463
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:50:37.363160
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:50:47.014097
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn

    # Test 1: super() outside of function
    node = ast_call(ast_name('super'))
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert node.args == []
    assert transformer._tree_changed == False

    # Test 2: super() outside of class
    node = ast_call(ast_name('super'))
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(node)
    assert node.args == []
    assert transformer._tree_changed == False

    # Test 3:

# Generated at 2022-06-18 00:50:54.173481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)