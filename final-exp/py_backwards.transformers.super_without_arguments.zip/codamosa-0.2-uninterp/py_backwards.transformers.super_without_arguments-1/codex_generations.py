

# Generated at 2022-06-18 00:41:25.619291
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:41:26.156346
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:41:26.683073
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:41:32.125004
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(tree_to_str(tree), '''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:41:41.728239
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class Cls:
            def method(self):
                super()
    """)

    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)


# Generated at 2022-06-18 00:41:43.645104
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_src
    from ..utils.helpers import assert_code_equal


# Generated at 2022-06-18 00:41:44.254124
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:41:47.982856
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:41:57.471049
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.tree import get_closest_parent_of

    tree = ast_class_def('Cls', [
        ast_function_def('func', [ast_name('self')], [
            ast_call('super')
        ])
    ])

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert transformer._tree_changed
    assert len(tree.body[0].body[0].args) == 2
    assert tree.body[0].body[0].args[0].id == 'Cls'
    assert tree.body[0].body[0].args[1].id == 'self'



# Generated at 2022-06-18 00:42:04.032581
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class Cls:
            def method(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class Cls:
            def method(self):
                super(Cls, self)
    """)

# Generated at 2022-06-18 00:42:12.780266
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:13.286182
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:42:23.543979
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_helpers import get_ast_node_name
    from ..utils.ast_helpers import get_ast_node_args
    from ..utils.ast_helpers import get_ast_node_func
    from ..utils.ast_helpers import get_ast_node_keywords
    from ..utils.ast_helpers import get_ast_node_starargs
    from ..utils.ast_helpers import get_ast_node_kwargs
    from ..utils.ast_helpers import get_ast_node_keyword_arg
    from ..utils.ast_helpers import get_ast_node_keyword_name
    from ..utils.ast_helpers import get_ast_node_keyword_value
    from ..utils.ast_helpers import get_ast_

# Generated at 2022-06-18 00:42:24.069964
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:42:33.703482
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_builder import ast_from_source
    from ..utils.helpers import get_ast_node_name

    code = """
    class Foo:
        def __init__(self):
            super()
    """
    tree = ast_from_source(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == """
    class Foo:
        def __init__(self):
            super(Foo, self)
    """

    code = """
    class Foo:
        def __init__(self):
            super()
    """
    tree = ast_from_source(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()


# Generated at 2022-06-18 00:42:40.454194
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    code = source_to_unicode('''
        class A:
            def __init__(self):
                super()
        ''')
    tree = get_ast(code)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
        ''')

# Generated at 2022-06-18 00:42:43.258213
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast


# Generated at 2022-06-18 00:42:50.367563
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def f(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def f(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:42:58.542052
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import ast_from_source

    source = source_to_unicode('''
    class Foo:
        def __init__(self):
            super()
    ''')
    tree = ast_from_source(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode('''
    class Foo:
        def __init__(self):
            super(Foo, self)
    ''')

# Generated at 2022-06-18 00:43:05.653866
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(tree_to_str(tree), '''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:43:16.856438
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef
    from ..utils.helpers import get_ast_node_name

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert get_ast_node_name(tree.body[0].body[0].body[0].args[0]) == 'A'
    assert get_ast_node_name(tree.body[0].body[0].body[0].args[1]) == 'self'

# Generated at 2022-06-18 00:43:25.583487
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:35.428271
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def, ast_arguments
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    class_name = 'TestClass'
    func_name = 'test_func'
    arg_name = 'arg'
    super_call = ast_call(ast_name('super'))
    func_def = ast_function_def(func_name, ast_arguments([ast_arg(arg_name)], None, None, []), [super_call])

# Generated at 2022-06-18 00:43:43.945561
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class Cls:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode("""
        class Cls:
            def __init__(self):
                super(Cls, self)
    """)

# Generated at 2022-06-18 00:43:49.031194
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:43:57.765915
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class Cls:
            def method(self):
                super()
    ''')
    tree = get_ast(source)
    node = tree.body[0].body[0].body[0].value
    assert isinstance(node, ast.Call)
    assert isinstance(node.func, ast.Name)
    assert node.func.id == 'super'
    assert not node.args

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed

    node = tree

# Generated at 2022-06-18 00:43:58.496067
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:43:59.068955
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:44:05.647149
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:44:13.451754
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:44:32.976316
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name

    code = '''
        class A:
            def __init__(self):
                super()
    '''

    tree = compile_to_ast(code)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    node = tree.body[0].body[0].body[0].value
    assert get_ast_node_name(node.args[0]) == 'Name'
    assert node.args[0].id == 'A'
    assert get_ast_node_name(node.args[1]) == 'Name'
    assert node.args[1].id == 'self'

# Generated at 2022-06-18 00:44:33.541549
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:44:41.512955
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast, dump_ast
    from ..utils.helpers import get_func_arg_names
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound

    source = source_to_unicode('''
        class Foo:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert dump_ast(tree) == source_to_unicode('''
        class Foo:
            def __init__(self):
                super(Foo, self)
    ''')
    assert transformer._tree_changed is True

    source

# Generated at 2022-06-18 00:44:49.543690
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    code = """
    class A:
        def __init__(self):
            super()
    """
    expected = """
    class A:
        def __init__(self):
            super(A, self)
    """
    tree = ast.parse(source_to_unicode(code))
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(ast.dump(tree), expected)

# Generated at 2022-06-18 00:44:52.236507
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.helpers import get_ast_node
    from ..utils.tree import get_all_nodes_of_type


# Generated at 2022-06-18 00:44:53.979699
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source
    from ..utils.helpers import compare_source


# Generated at 2022-06-18 00:45:01.558663
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_parser import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:45:09.571977
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert source_to_unicode(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:45:18.485965
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_functiondef, ast_classdef, ast_arguments

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed

    expected = ast.parse(source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """))

    assert ast.dump(tree) == ast.dump(expected)

# Generated at 2022-06-18 00:45:19.017264
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:45:46.629577
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)

    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:45:52.990317
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer(tree).visit(tree)
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:45:58.634117
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer()
    transformer.visit(tree)
    assert transformer.tree_changed
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:01.554585
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = get_ast(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:46:11.780016
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.tree import get_closest_parent_of
    from ..utils.helpers import warn
    from ..exceptions import NodeNotFound
    from .base import BaseNodeTransformer

    class SuperWithoutArgumentsTransformer(BaseNodeTransformer):
        """Compiles:
            super()
        To:
            super(Cls, self)
            super(Cls, cls)
                
        """
        target = (2, 7)

        def _replace_super_args(self, node: ast.Call) -> None:
            try:
                func = get_closest_parent_of(self._tree, node, ast.FunctionDef)
            except NodeNotFound:
                warn('super() outside of function')
                return


# Generated at 2022-06-18 00:46:19.295217
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:46:23.165233
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast as sta
    from ..utils.source import source_to_code as stc
    from ..utils.helpers import get_ast_node_at_line


# Generated at 2022-06-18 00:46:29.866171
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = ast.parse(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    expected = source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')
    assert tree_to_str(tree) == expected

# Generated at 2022-06-18 00:46:33.015871
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source
    from ..utils.tree import print_tree


# Generated at 2022-06-18 00:46:38.329692
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_ast
    from ..utils.helpers import ast_to_source
    from ..utils.helpers import get_ast_node_name
    from ..utils.helpers import get_ast_node_lineno
    from ..utils.helpers import get_ast_node_col_offset


# Generated at 2022-06-18 00:47:18.576543
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:47:19.001131
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:47:27.315706
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.ast_builder import build_ast

    source = source_to_unicode('''
        class A:
            def __init__(self):
                super()
    ''')
    tree = build_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()
    assert transformer._tree_changed == True
    assert source_to_unicode(tree) == source_to_unicode('''
        class A:
            def __init__(self):
                super(A, self)
    ''')

# Generated at 2022-06-18 00:47:34.117553
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    expected_result = source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(astor.to_source(tree), expected_result)

# Generated at 2022-06-18 00:47:38.581732
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_all_nodes_of_type


# Generated at 2022-06-18 00:47:44.549994
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast

    source = source_to_unicode('''
        class Cls:
            def method(self):
                super()
    ''')
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert source_to_unicode(tree) == source_to_unicode('''
        class Cls:
            def method(self):
                super(Cls, self)
    ''')

# Generated at 2022-06-18 00:47:47.817373
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import node_to_str


# Generated at 2022-06-18 00:47:57.372328
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast_factory import ast_call, ast_name, ast_function_def, ast_class_def

    source = source_to_unicode("""
        class A:
            def f(self):
                super()
    """)

    tree = ast.parse(source)
    node = tree.body[0].body[0].body[0]
    assert isinstance(node, ast.Expr)
    assert isinstance(node.value, ast_call('super'))

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert isinstance(node.value, ast_call('super', [ast_name('A'), ast_name('self')]))



# Generated at 2022-06-18 00:47:59.456486
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast


# Generated at 2022-06-18 00:48:04.950958
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast
    from ..utils.helpers import get_func_args
    from ..utils.helpers import get_func_name
    from ..utils.helpers import get_class_name
    from ..utils.helpers import get_super_args
    from ..utils.helpers import get_super_name
    from ..utils.helpers import get_super_func_name

    source = source_to_unicode("""
        class Cls(object):
            def __init__(self):
                super()
    """)
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)

    assert get_super_name(tree) == 'super'
    assert get_

# Generated at 2022-06-18 00:49:33.615617
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.context import Context
    from ..transforms import SuperWithoutArgumentsTransformer
    from ..exceptions import ParseError


# Generated at 2022-06-18 00:49:41.405256
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from ..utils.source import source_to_unicode
    from ..utils.ast import get_ast
    from ..utils.helpers import get_func_args
    from ..utils.helpers import get_func_name
    from ..utils.helpers import get_func_body
    from ..utils.helpers import get_class_name
    from ..utils.helpers import get_class_body

    source = source_to_unicode('''
        class Cls:
            def method(self):
                super()
    ''')
    tree = get_ast(source)
    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.visit(tree)
    assert transformer._tree_changed is True


# Generated at 2022-06-18 00:49:41.868455
# Unit test for constructor of class SuperWithoutArgumentsTransformer

# Generated at 2022-06-18 00:49:45.957939
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert tree_to_str(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:49:49.010481
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from .. import compile_to_ast
    from ..utils.helpers import get_ast_node_name


# Generated at 2022-06-18 00:49:57.162439
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import assert_equal_ignore_ws

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)
    expected = source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)
    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert_equal_ignore_ws(ast.dump(tree), expected)

# Generated at 2022-06-18 00:50:01.742370
# Unit test for method visit_Call of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer_visit_Call():
    from typed_ast import ast3 as ast
    from ..utils.ast_builder import build_ast
    from ..utils.helpers import get_ast_node_name
    from ..utils.tree import get_closest_parent_of
    from ..exceptions import NodeNotFound


# Generated at 2022-06-18 00:50:08.816803
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.helpers import get_ast

    source = source_to_unicode("""
        class A:
            def __init__(self):
                super()
    """)
    tree = get_ast(source)

    transformer = SuperWithoutArgumentsTransformer(tree)
    transformer.run()

    assert transformer._tree_changed is True
    assert source_to_unicode(tree) == source_to_unicode("""
        class A:
            def __init__(self):
                super(A, self)
    """)

# Generated at 2022-06-18 00:50:16.772285
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from ..utils.source import source_to_unicode
    from ..utils.tree import tree_to_str

    source = source_to_unicode("""
    class A:
        def __init__(self):
            super()
    """)

    tree = ast.parse(source)
    SuperWithoutArgumentsTransformer().visit(tree)
    assert tree_to_str(tree) == source_to_unicode("""
    class A:
        def __init__(self):
            super(A, self)
    """)

# Generated at 2022-06-18 00:50:19.698124
# Unit test for constructor of class SuperWithoutArgumentsTransformer
def test_SuperWithoutArgumentsTransformer():
    from typed_ast import ast3 as ast
    from ..utils.tree import parse_tree
    from ..utils.helpers import dump_ast
